/**
 * FEELHAUS ERP_CORE Route Dispatcher
 * Patch: ERP_CORE_ROUTE_BLANK_HOTFIX_SAFE_V2
 * Scope: route/read-only UI only. No create/save/deploy execution.
 */
var ERP_CORE_CLEAN_BUILD = 'ERP_CORE_ROUTE_BLANK_HOTFIX_SAFE_V2';

function doGet(e) {
  e = e || {};
  var p = e.parameter || {};
  var page = String(p.page || p.route || p.view || p.mode || '').trim();
  var lower = page.toLowerCase();

  // Hotfix V2: direct route requests render a complete HTML page.
  var r1501 = ['validationsimui','requiredfieldsimui','formatrulesimui','duplicatechecksimui','permissionsimui','statetransitionsimui','auditlogsimui','settlementguardsimui','qrvalidationsimui','portalreportsimui','finalsimui','erp1501','erp1640'];
  if (r1501.indexOf(lower) >= 0 && typeof erpCoreRouteBlankHotfixV2_render1501 === 'function') {
    return erpCoreRouteBlankHotfixV2_render1501(p);
  }

  var r1261 = ['financepermissiondetailui','financedetailui','settlementdetailui','cancelsettlementdetailui','depositbonddetailui','benefitgiftdetailui','fundreturndetailui','staffpermissiondetailui','formqrdetailui','portalreportdetailui','finalvalidationdetailui','erp1261','erp1500'];
  if (r1261.indexOf(lower) >= 0 && typeof erpCoreRouteBlankHotfixV2_render1261 === 'function') {
    return erpCoreRouteBlankHotfixV2_render1261(p);
  }

  var r981 = ['routesplit','screensplit','rolemain','customerui','salescontractui','signstatusui','fieldworkui','asui','settlementui','cancelsettlementui','depositbondui','benefitgiftui','fundreturnui','staffui','permissionui','formqrui','portalreportui','finalcheckui','erp981','erp1120'];
  if (r981.indexOf(lower) >= 0 && typeof erpCoreRouteBlankHotfixV2_render981 === 'function') {
    return erpCoreRouteBlankHotfixV2_render981(p);
  }

  // Existing route compatibility, if these functions exist in the project.
  var r1641 = ['finalreport','precreatereport','approvalfinal','createapprovalreport','precreateapproval','erpfinalreport','erp1641','erp1780'];
  if (r1641.indexOf(lower) >= 0 && typeof erpCoreB06J41_1641_1780_renderFinalPreCreateReportHtml === 'function') {
    return erpCoreB06J41_1641_1780_renderFinalPreCreateReportHtml(p);
  }
  var r1121 = ['detailui','roledetail','customerdetailui','saledetailui','contractdetailui','signdetailui','fielddetailui','asdetailui','emptyguideui'];
  if (r1121.indexOf(lower) >= 0 && typeof erpIntegratedB06J41_1121_1260_renderDetailUiHtml === 'function') {
    return erpIntegratedB06J41_1121_1260_renderDetailUiHtml(p);
  }
  var r861 = ['staffpermissionportalui','staffpermissionui','erp861','erp980'];
  if (r861.indexOf(lower) >= 0 && typeof erpIntegratedB06J41_861_980_renderStaffPermissionFormPortalFinalHtml === 'function') {
    return erpIntegratedB06J41_861_980_renderStaffPermissionFormPortalFinalHtml(p);
  }
  var r701 = ['settlementbenefitui','financeui','erp701','erp860'];
  if (r701.indexOf(lower) >= 0 && typeof erpIntegratedB06J41_701_860_renderSettlementBenefitFinanceUiHtml === 'function') {
    return erpIntegratedB06J41_701_860_renderSettlementBenefitFinanceUiHtml(p);
  }
  var r521 = ['rolecustomerui','erp521','erp700'];
  if (r521.indexOf(lower) >= 0 && typeof erpIntegratedB06J41_521_700_renderRoleCustomerSaleFieldHtml === 'function') {
    return erpIntegratedB06J41_521_700_renderRoleCustomerSaleFieldHtml(p);
  }
  var r421 = ['gapreport','realusegap','uigapreport','screengap','erpgap','realuseui','nextgap','uiworkplan'];
  if ((r421.indexOf(lower) >= 0 || p.gapReport === '1') && typeof erpIntegratedB06J41_421_520_renderGapReportHtml === 'function') {
    return erpIntegratedB06J41_421_520_renderGapReportHtml(p);
  }
  var r321 = ['integratedhub','erpintegrated','uifunctionhub','predeployhub','erpmainhub','erpstatusreport','portalstatusreport','formqrhub'];
  if (r321.indexOf(lower) >= 0 && typeof erpIntegratedB06J41_321_420_renderHubHtml === 'function') {
    return erpIntegratedB06J41_321_420_renderHubHtml(p);
  }
  var r241 = ['sheetapproval','missingapproval','headerapproval','approvaldecision','createdecision','coreapproval'];
  if ((r241.indexOf(lower) >= 0 || p.approvalDecision === '1') && typeof erpCoreB06J41_241_320_renderApprovalDecisionHtml === 'function') {
    return erpCoreB06J41_241_320_renderApprovalDecisionHtml(p);
  }
  var r161 = ['coreaudit','audit','predeploy','uicheck','functionaudit'];
  if (r161.indexOf(lower) >= 0 && typeof erpCoreB06J41_161_240_renderAuditHtml === 'function') {
    return erpCoreB06J41_161_240_renderAuditHtml(p);
  }

  var t = HtmlService.createTemplateFromFile('H_Index');
  t.build = ERP_CORE_CLEAN_BUILD;
  return t.evaluate().setTitle('FEELHAUS ERP_CORE').setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL);
}

function include(filename) { return HtmlService.createHtmlOutputFromFile(filename).getContent(); }

function erpCoreCleanB06J41_safety_() {
  return {
    readOnlyCleanBundle: true,
    deployAllowed: false,
    actualCreateConfirm: false,
    actualExecutionBlocked: true,
    noSheetCreate: true,
    noHeaderAutoCreate: true,
    noDbInjection: true,
    noCustomerSave: true,
    noSaleSave: true,
    noContractCreate: true,
    noSignDocumentCreate: true,
    noInstallAsSave: true,
    noSettlementExecution: true,
    noCancelSettlementConfirm: true,
    noRoleMutation: true,
    noFormAutoRegister: true,
    noDeployExecution: true,
    noBackupRecoveryRollbackExecution: true,
    vendorBranchUserGroup: true,
    qrInitialEntryTargetSearchProtected: true,
    directRegularMemberLink: false,
    noOriginalSlipMutation: true
  };
}
