@echo off
setlocal EnableExtensions
title FEELHAUS UPLOAD ERP_CORE

cd /d D:\pepsi308\OneDrive\feelhaus_pull\ERP_CORE
if errorlevel 1 (
  echo [ERROR] ERP_CORE folder not found.
  pause
  exit /b 1
)

if not exist ".clasp.json" (
  echo [ERROR] ERP_CORE .clasp.json not found.
  pause
  exit /b 1
)

echo ==========================================
echo ERP_CORE upload start
echo Current folder:
cd
echo ==========================================
echo.

clasp.cmd push 
set RC=%ERRORLEVEL%

echo.
echo ==========================================
if %RC%==0 (
  echo [OK] ERP_CORE upload complete
) else (
  echo [ERROR] ERP_CORE upload failed
  echo ERRORLEVEL=%RC%
)
echo ==========================================
echo.

pause
