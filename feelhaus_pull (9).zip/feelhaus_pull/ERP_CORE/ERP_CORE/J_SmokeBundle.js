/**
 * ERP_CORE_POST_WEBAPP_DEPLOY_UI_SMOKE_BUNDLE_SAFE
 * Post webapp deploy UI smoke bundled checklist.
 * Safe: no write, no deploy, no permission mutation.
 */
const ERP_POST_WEBAPP_DEPLOY_UI_SMOKE_BUNDLE_BUILD = 'ERP_CORE_POST_WEBAPP_DEPLOY_UI_SMOKE_BUNDLE_SAFE';

function erpPostWebappDeployUiSmokeBundle_safety_() {
  return {
    build: ERP_POST_WEBAPP_DEPLOY_UI_SMOKE_BUNDLE_BUILD,
    readOnly: true,
    simulationOnly: true,
    noSheetCreate: true,
    noHeaderAutoAdd: true,
    noPolicyWrite: true,
    noDbInjection: true,
    noDeployExecution: true,
    deployAllowed: false,
    actualDeployExecution: false,
    noBusinessDataWrite: true,
    noCustomerSave: true,
    noSaleSave: true,
    noContractCreate: true,
    noInstallAsSave: true,
    noSettlementExecution: true,
    noCancelSettlementConfirm: true,
    noSignDocumentCreate: true,
    noFormAutoRegister: true,
    noRoleMutation: true,
    noDeleteSheet: true,
    noExistingDataClear: true,
    headerMapRequired: true,
    idBasedConnectionRequired: true,
    vendorBranchUserGroup: true,
    qrInitialEntryTargetSearchProtected: true,
    directRegularMemberLink: false,
    noOriginalSlipMutation: true
  };
}

function erpPostWebappDeployUiSmokeBundle_expectedRoutes_() {
  return [
    { route: 'ERP_HOME', label: 'ERP 홈', requiredRole: 'HQ_OR_VENDOR' },
    { route: 'ERP_SALES', label: '판매관리', requiredRole: 'SALES_OR_HQ' },
    { route: 'ERP_CONTRACTS', label: '계약관리', requiredRole: 'SALES_OR_HQ' },
    { route: 'ERP_INSTALLS', label: '설치관리', requiredRole: 'INSTALL_OR_HQ' },
    { route: 'ERP_AS', label: 'A/S관리', requiredRole: 'AS_OR_HQ' },
    { route: 'ERP_SETTLEMENTS', label: '정산관리', requiredRole: 'SETTLEMENT_APPROVED_OR_HQ' },
    { route: 'ERP_USERS', label: '사용자관리', requiredRole: 'HQ_OR_VENDOR_ADMIN' }
  ];
}

function erpPostWebappDeployUiSmokeBundle_dryRun(ctx) {
  ctx = ctx || {};
  return {
    ok: true,
    build: ERP_POST_WEBAPP_DEPLOY_UI_SMOKE_BUNDLE_BUILD,
    mode: 'DRY_RUN_ONLY',
    message: '웹앱 배포 후 UI 스모크 묶음 점검 계획만 확인합니다. 실제 저장/배포/권한변경은 없습니다.',
    webAppUrlProvided: !!ctx.webAppUrl,
    webAppUrl: ctx.webAppUrl || '',
    expectedRoutes: erpPostWebappDeployUiSmokeBundle_expectedRoutes_(),
    fatal: [],
    warnings: ctx.webAppUrl ? [] : ['webAppUrl이 제공되지 않았습니다. 실제 브라우저 URL 확인은 수동으로 진행하세요.'],
    safety: erpPostWebappDeployUiSmokeBundle_safety_(),
    ctx: ctx
  };
}

function erpPostWebappDeployUiSmokeBundle_manualChecklist(ctx) {
  ctx = ctx || {};
  const routes = erpPostWebappDeployUiSmokeBundle_expectedRoutes_();
  return {
    ok: true,
    build: ERP_POST_WEBAPP_DEPLOY_UI_SMOKE_BUNDLE_BUILD,
    mode: 'MANUAL_UI_CHECKLIST',
    message: '아래 화면은 배포된 웹앱 URL에서 사용자가 직접 확인해야 합니다. 저장/정산/권한변경 버튼은 누르지 않습니다.',
    webAppUrlProvided: !!ctx.webAppUrl,
    webAppUrl: ctx.webAppUrl || '',
    checks: routes.map(function(r) {
      return {
        route: r.route,
        label: r.label,
        requiredRole: r.requiredRole,
        manualCheckRequired: true,
        expected: ['빈 화면 없음', '오류 팝업 없음', '메뉴 진입 가능', '저장 버튼 클릭 금지', '정산 실행 금지', '권한 변경 금지']
      };
    }),
    fatal: [],
    warnings: [],
    businessDataWrite: false,
    deployAllowed: false,
    safety: erpPostWebappDeployUiSmokeBundle_safety_()
  };
}

function erpPostWebappDeployUiSmokeBundle_resultTemplate(ctx) {
  ctx = ctx || {};
  const routes = erpPostWebappDeployUiSmokeBundle_expectedRoutes_();
  return {
    ok: true,
    build: ERP_POST_WEBAPP_DEPLOY_UI_SMOKE_BUNDLE_BUILD,
    mode: 'UI_RESULT_TEMPLATE',
    message: '브라우저 수동 확인 결과를 아래 형식으로 기록하세요.',
    webAppUrl: ctx.webAppUrl || '[여기에 배포된 웹앱 URL 입력]',
    resultTemplate: {
      checkedBy: Session && Session.getActiveUser ? Session.getActiveUser().getEmail() : '',
      checkedAt: new Date().toISOString(),
      overall: 'PASS / FAIL / HOLD',
      routes: routes.map(function(r) {
        return {
          route: r.route,
          label: r.label,
          opened: 'YES / NO',
          blankPage: 'YES / NO',
          errorPopup: 'YES / NO',
          menuClickable: 'YES / NO',
          saveButtonClicked: 'NO',
          note: ''
        };
      })
    },
    fatal: [],
    warnings: [],
    businessDataWrite: false,
    deployAllowed: false,
    safety: erpPostWebappDeployUiSmokeBundle_safety_()
  };
}

function erpPostWebappDeployUiSmokeBundle_selfTest() {
  const routes = erpPostWebappDeployUiSmokeBundle_expectedRoutes_();
  const fatal = [];
  if (!routes || routes.length !== 7) fatal.push('UI route count mismatch');
  if (!erpPostWebappDeployUiSmokeBundle_safety_().readOnly) fatal.push('readOnly safety flag is not true');
  if (erpPostWebappDeployUiSmokeBundle_safety_().deployAllowed !== false) fatal.push('deployAllowed safety flag must be false');
  return {
    ok: fatal.length === 0,
    build: ERP_POST_WEBAPP_DEPLOY_UI_SMOKE_BUNDLE_BUILD,
    mode: 'SELFTEST',
    fatal: fatal,
    warnings: [],
    expectedRouteCount: 7,
    actualRouteCount: routes.length,
    safety: erpPostWebappDeployUiSmokeBundle_safety_()
  };
}

function erpPostWebappDeployUiSmokeBundle_runAll(ctx) {
  ctx = ctx || {};
  const dryRun = erpPostWebappDeployUiSmokeBundle_dryRun(ctx);
  const checklist = erpPostWebappDeployUiSmokeBundle_manualChecklist(ctx);
  const template = erpPostWebappDeployUiSmokeBundle_resultTemplate(ctx);
  const selfTest = erpPostWebappDeployUiSmokeBundle_selfTest();
  const fatal = [];
  [dryRun, checklist, template, selfTest].forEach(function(stage) {
    if (!stage.ok) fatal.push(stage.mode + ' failed');
    if (stage.fatal && stage.fatal.length) fatal.push.apply(fatal, stage.fatal);
  });
  return {
    ok: fatal.length === 0,
    build: ERP_POST_WEBAPP_DEPLOY_UI_SMOKE_BUNDLE_BUILD,
    mode: 'ALL_UI_SMOKE_BUNDLE_NO_WRITE',
    checkedAt: new Date().toISOString(),
    fatal: fatal,
    warnings: [].concat(dryRun.warnings || []),
    stages: {
      dryRun: dryRun,
      manualChecklist: checklist,
      resultTemplate: template,
      selfTest: selfTest
    },
    manualBrowserCheckStillRequired: true,
    businessDataWrite: false,
    deployAllowed: false,
    safety: erpPostWebappDeployUiSmokeBundle_safety_()
  };
}
