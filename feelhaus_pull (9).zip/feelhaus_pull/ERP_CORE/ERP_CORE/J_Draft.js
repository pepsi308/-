/**
 * FEELHAUS ERP_CORE Actual Create Dedicated Build Draft
 * Build: ERP_CORE_ACTUAL_CREATE_DEDICATED_BUILD_DRAFT_SAFE
 * Project: ERP_CORE only
 * Safety:
 *  - create-only dedicated draft for 6 ERP_CORE sheets and 67 core headers
 *  - no DB injection, no deploy, no business data write, no permission mutation
 *  - actual execution requires explicit runtime confirmation and approval code
 */
var ERP_CORE_ACTUAL_CREATE_DEDICATED_BUILD = 'ERP_CORE_ACTUAL_CREATE_DEDICATED_BUILD_DRAFT_SAFE';
var ERP_CORE_ACTUAL_CREATE_APPROVAL_CODE = 'ERP_CORE_ACTUAL_CREATE_APPROVED_6_SHEETS_ONLY';

var ERP_CORE_ACTUAL_CREATE_SHEET_POLICIES = [
  { key:'sales', order:1, sheetName:'ERP_판매관리', label:'판매관리', protectionLevel:'CORE_PROTECTED', headers:['eventId','vendorId','customerId','status','statusReason','createdAt','createdBy','updatedAt','updatedBy','saleId'] },
  { key:'contracts', order:2, sheetName:'ERP_계약관리', label:'계약관리', protectionLevel:'CORE_PROTECTED', headers:['eventId','vendorId','customerId','status','statusReason','createdAt','createdBy','updatedAt','updatedBy','contractId','saleId'] },
  { key:'installs', order:3, sheetName:'ERP_설치관리', label:'설치관리', protectionLevel:'CORE_PROTECTED', headers:['eventId','vendorId','customerId','status','statusReason','createdAt','createdBy','updatedAt','updatedBy','installId','saleId','contractId'] },
  { key:'as', order:4, sheetName:'ERP_AS관리', label:'A/S관리', protectionLevel:'CORE_PROTECTED', headers:['eventId','vendorId','customerId','status','statusReason','createdAt','createdBy','updatedAt','updatedBy','asId','saleId'] },
  { key:'settlements', order:5, sheetName:'ERP_정산관리', label:'정산관리', protectionLevel:'CRITICAL_PROTECTED', headers:['eventId','vendorId','customerId','status','statusReason','createdAt','createdBy','updatedAt','updatedBy','settlementId','saleId','contractId'] },
  { key:'users', order:6, sheetName:'ERP_사용자관리', label:'사용자관리', protectionLevel:'CRITICAL_PROTECTED', headers:['eventId','vendorId','customerId','status','statusReason','createdAt','createdBy','updatedAt','updatedBy','userId','roleCode'] }
];

function erpCoreActualCreateDedicatedDraft_safety_() {
  return {
    build: ERP_CORE_ACTUAL_CREATE_DEDICATED_BUILD,
    createOnlyMode: true,
    actualCreateConfirmDefault: false,
    dbInjectAllowed: false,
    deployAllowed: false,
    noDbInjection: true,
    noDeployExecution: true,
    noCustomerSave: true,
    noSaleSave: true,
    noContractCreate: true,
    noInstallAsSave: true,
    noSettlementExecution: true,
    noCancelSettlementConfirm: true,
    noSignDocumentCreate: true,
    noFormAutoRegister: true,
    noRoleMutation: true,
    noBusinessDataWrite: true,
    noDeleteSheet: true,
    noExistingDataClear: true,
    headerMapRequired: true,
    idBasedConnectionRequired: true,
    vendorBranchUserGroup: true,
    qrInitialEntryTargetSearchProtected: true,
    directRegularMemberLink: false,
    noOriginalSlipMutation: true
  };
}

function erpCoreActualCreateDedicatedDraft_buildPlan_() {
  var sheets = [];
  var headerRows = [];
  var duplicateProblems = [];
  var auditHeaders = ['createdAt','createdBy','updatedAt','updatedBy'];
  var auditProblems = [];

  for (var i = 0; i < ERP_CORE_ACTUAL_CREATE_SHEET_POLICIES.length; i++) {
    var policy = ERP_CORE_ACTUAL_CREATE_SHEET_POLICIES[i];
    var duplicate = erpCoreActualCreateDedicatedDraft_findDuplicates_(policy.headers);
    if (duplicate.length) {
      duplicateProblems.push({ sheetName: policy.sheetName, duplicates: duplicate });
    }
    for (var a = 0; a < auditHeaders.length; a++) {
      if (policy.headers.indexOf(auditHeaders[a]) < 0) {
        auditProblems.push({ sheetName: policy.sheetName, missingHeader: auditHeaders[a] });
      }
    }
    sheets.push({
      key: policy.key,
      order: policy.order,
      sheetName: policy.sheetName,
      label: policy.label,
      protectionLevel: policy.protectionLevel,
      headerCount: policy.headers.length,
      headers: policy.headers.slice(),
      deleteCandidate: false,
      archiveCandidate: false,
      createRequired: true
    });
    for (var h = 0; h < policy.headers.length; h++) {
      headerRows.push({
        sheetName: policy.sheetName,
        headerName: policy.headers[h],
        headerOrder: h + 1,
        required: true,
        protected: true
      });
    }
  }

  return {
    ok: duplicateProblems.length === 0 && auditProblems.length === 0 && sheets.length === 6 && headerRows.length === 67,
    build: ERP_CORE_ACTUAL_CREATE_DEDICATED_BUILD,
    sheetPolicyCandidateCount: sheets.length,
    headerPolicyCandidateCount: headerRows.length,
    sheets: sheets,
    headerRows: headerRows,
    duplicateProblems: duplicateProblems,
    auditProblems: auditProblems,
    safety: erpCoreActualCreateDedicatedDraft_safety_()
  };
}

function erpCoreActualCreateDedicatedDraft_dryRun(ctx) {
  ctx = ctx || {};
  var plan = erpCoreActualCreateDedicatedDraft_buildPlan_();
  var out = {
    ok: plan.ok,
    build: ERP_CORE_ACTUAL_CREATE_DEDICATED_BUILD,
    mode: 'DRY_RUN_ONLY',
    actualCreateConfirm: false,
    dbInjectAllowed: false,
    deployAllowed: false,
    message: '실제 생성 없이 6개 시트 / 67개 핵심 헤더 생성 계획만 검증했습니다.',
    plan: plan,
    ctx: ctx || {}
  };
  Logger.log('[ERP_CORE ACTUAL CREATE DRAFT DRY RUN] ' + JSON.stringify(out));
  return out;
}

function erpCoreActualCreateDedicatedDraft_selfTest() {
  var plan = erpCoreActualCreateDedicatedDraft_buildPlan_();
  var fatal = [];
  var warnings = [];
  var safety = erpCoreActualCreateDedicatedDraft_safety_();

  if (plan.sheetPolicyCandidateCount !== 6) fatal.push('SheetPolicy 후보 수 불일치: ' + plan.sheetPolicyCandidateCount);
  if (plan.headerPolicyCandidateCount !== 67) fatal.push('HeaderPolicy 후보 수 불일치: ' + plan.headerPolicyCandidateCount);
  if (plan.duplicateProblems.length > 0) fatal.push('중복 헤더 존재');
  if (plan.auditProblems.length > 0) fatal.push('감사 헤더 4종 누락');
  if (safety.dbInjectAllowed !== false) fatal.push('dbInjectAllowed must remain false');
  if (safety.deployAllowed !== false) fatal.push('deployAllowed must remain false');
  if (safety.noBusinessDataWrite !== true) fatal.push('business data write must remain blocked');

  var required = [
    'erpCoreActualCreateDedicatedDraft_dryRun',
    'erpCoreActualCreateDedicatedDraft_execute',
    'erpCoreActualCreateDedicatedDraft_postCreateCheck',
    'erpCoreActualCreateDedicatedDraft_buildPlan_',
    'erpCoreActualCreateDedicatedDraft_selfTest'
  ];
  var missing = [];
  for (var i = 0; i < required.length; i++) {
    try { if (typeof this[required[i]] !== 'function') missing.push(required[i]); }
    catch (e) { missing.push(required[i]); }
  }
  if (missing.length) fatal.push('필수 함수 누락: ' + missing.join(', '));

  var result = {
    ok: fatal.length === 0,
    build: ERP_CORE_ACTUAL_CREATE_DEDICATED_BUILD,
    fatal: fatal,
    warnings: warnings,
    checks: {
      plan: {
        ok: plan.ok,
        sheetPolicyCandidateCount: plan.sheetPolicyCandidateCount,
        headerPolicyCandidateCount: plan.headerPolicyCandidateCount,
        duplicateProblemCount: plan.duplicateProblems.length,
        auditProblemCount: plan.auditProblems.length
      },
      requiredFunctions: { ok: missing.length === 0, missing: missing },
      safety: safety
    }
  };
  Logger.log('[ERP_CORE ACTUAL CREATE DRAFT SELFTEST] ' + JSON.stringify(result));
  return result;
}

function erpCoreActualCreateDedicatedDraft_execute(ctx) {
  ctx = ctx || {};
  var guard = erpCoreActualCreateDedicatedDraft_checkExecuteGuard_(ctx);
  if (!guard.ok) {
    var blocked = {
      ok: false,
      blocked: true,
      build: ERP_CORE_ACTUAL_CREATE_DEDICATED_BUILD,
      action: 'ACTUAL_CREATE_6_SHEETS_ONLY',
      reason: guard.reason,
      required: guard.required,
      safety: erpCoreActualCreateDedicatedDraft_safety_()
    };
    Logger.log('[ERP_CORE ACTUAL CREATE DRAFT EXECUTE BLOCKED] ' + JSON.stringify(blocked));
    return blocked;
  }

  var plan = erpCoreActualCreateDedicatedDraft_buildPlan_();
  if (!plan.ok) throw new Error('PLAN_NOT_READY');

  var ss = erpCoreActualCreateDedicatedDraft_openMaster_();
  var result = {
    ok: true,
    build: ERP_CORE_ACTUAL_CREATE_DEDICATED_BUILD,
    action: 'ACTUAL_CREATE_6_SHEETS_ONLY',
    createOnlyMode: true,
    createdSheets: [],
    existingSheets: [],
    headerWrites: [],
    warnings: [],
    fatal: [],
    dbInjectAllowed: false,
    deployAllowed: false
  };

  for (var i = 0; i < plan.sheets.length; i++) {
    var policy = plan.sheets[i];
    var sh = ss.getSheetByName(policy.sheetName);
    if (!sh) {
      sh = ss.insertSheet(policy.sheetName);
      result.createdSheets.push(policy.sheetName);
    } else {
      result.existingSheets.push(policy.sheetName);
    }
    erpCoreActualCreateDedicatedDraft_applyHeaders_(sh, policy.headers, result);
  }

  result.postCreateCheck = erpCoreActualCreateDedicatedDraft_postCreateCheck();
  result.ok = result.fatal.length === 0 && result.postCreateCheck.ok === true;
  Logger.log('[ERP_CORE ACTUAL CREATE DRAFT EXECUTE RESULT] ' + JSON.stringify(result));
  return result;
}

function erpCoreActualCreateDedicatedDraft_postCreateCheck() {
  var plan = erpCoreActualCreateDedicatedDraft_buildPlan_();
  var ss = erpCoreActualCreateDedicatedDraft_openMaster_();
  var out = {
    ok: true,
    build: ERP_CORE_ACTUAL_CREATE_DEDICATED_BUILD,
    checkedAt: new Date().toISOString(),
    fatal: [],
    warnings: [],
    sheetCount: 0,
    headerPolicyCandidateCount: plan.headerPolicyCandidateCount,
    sheets: []
  };

  for (var i = 0; i < plan.sheets.length; i++) {
    var policy = plan.sheets[i];
    var sh = ss.getSheetByName(policy.sheetName);
    var row = {
      sheetName: policy.sheetName,
      exists: !!sh,
      expectedHeaderCount: policy.headers.length,
      actualHeaderCount: 0,
      missingHeaders: [],
      duplicateHeaders: []
    };
    if (!sh) {
      out.fatal.push('시트 없음: ' + policy.sheetName);
      out.ok = false;
      out.sheets.push(row);
      continue;
    }
    out.sheetCount++;
    var values = sh.getLastColumn() > 0 ? sh.getRange(1, 1, 1, sh.getLastColumn()).getValues()[0] : [];
    var headers = [];
    for (var h = 0; h < values.length; h++) headers.push(String(values[h] || '').trim());
    row.actualHeaderCount = headers.length;
    for (var m = 0; m < policy.headers.length; m++) {
      if (headers.indexOf(policy.headers[m]) < 0) row.missingHeaders.push(policy.headers[m]);
    }
    row.duplicateHeaders = erpCoreActualCreateDedicatedDraft_findDuplicates_(headers);
    if (row.missingHeaders.length) {
      out.fatal.push(policy.sheetName + ' 필수 헤더 누락: ' + row.missingHeaders.join(', '));
      out.ok = false;
    }
    if (row.duplicateHeaders.length) {
      out.fatal.push(policy.sheetName + ' 중복 헤더: ' + row.duplicateHeaders.join(', '));
      out.ok = false;
    }
    out.sheets.push(row);
  }

  if (out.sheetCount !== 6) {
    out.fatal.push('생성/존재 시트 수 불일치: ' + out.sheetCount);
    out.ok = false;
  }
  Logger.log('[ERP_CORE ACTUAL CREATE DRAFT POST CREATE CHECK] ' + JSON.stringify(out));
  return out;
}

function erpCoreActualCreateDedicatedDraft_checkExecuteGuard_(ctx) {
  var required = {
    actualCreateConfirm: true,
    approvalCode: ERP_CORE_ACTUAL_CREATE_APPROVAL_CODE,
    dbInjectAllowed: false,
    deployAllowed: false
  };
  if (ctx.actualCreateConfirm !== true) {
    return { ok:false, reason:'actualCreateConfirm=true 승인이 없습니다.', required:required };
  }
  if (String(ctx.approvalCode || '') !== ERP_CORE_ACTUAL_CREATE_APPROVAL_CODE) {
    return { ok:false, reason:'승인 코드가 일치하지 않습니다.', required:required };
  }
  if (ctx.dbInjectAllowed === true) {
    return { ok:false, reason:'DB 주입 허용 상태에서는 시트 생성 전용 실행을 중단합니다.', required:required };
  }
  if (ctx.deployAllowed === true) {
    return { ok:false, reason:'배포 허용 상태에서는 시트 생성 전용 실행을 중단합니다.', required:required };
  }
  return { ok:true, required:required };
}

function erpCoreActualCreateDedicatedDraft_openMaster_() {
  if (typeof erpCore_getMasterSpreadsheet_ === 'function') return erpCore_getMasterSpreadsheet_();
  if (typeof erpCoreB06J41_161_240_readSystemConfig_ === 'function' && typeof erpCoreB06J41_161_240_openMaster_ === 'function') {
    var cfg = erpCoreB06J41_161_240_readSystemConfig_();
    if (!cfg.ok) throw new Error('SYSTEMCONFIG_NOT_READY');
    var master = erpCoreB06J41_161_240_openMaster_(cfg.configMap);
    if (!master.ok) throw new Error('MASTER_NOT_READY');
    return master.spreadsheet;
  }
  throw new Error('MASTER_CONNECTOR_NOT_FOUND');
}

function erpCoreActualCreateDedicatedDraft_applyHeaders_(sh, expectedHeaders, result) {
  var lastCol = sh.getLastColumn();
  var current = [];
  if (lastCol > 0) {
    current = sh.getRange(1, 1, 1, lastCol).getValues()[0].map(function(v) { return String(v || '').trim(); });
  }
  if (current.length === 0 || (current.length === 1 && !current[0])) {
    sh.getRange(1, 1, 1, expectedHeaders.length).setValues([expectedHeaders]);
    result.headerWrites.push({ sheetName: sh.getName(), mode: 'SET_HEADER_ROW', count: expectedHeaders.length });
    return;
  }

  var missing = [];
  for (var i = 0; i < expectedHeaders.length; i++) {
    if (current.indexOf(expectedHeaders[i]) < 0) missing.push(expectedHeaders[i]);
  }
  if (missing.length > 0) {
    sh.getRange(1, current.length + 1, 1, missing.length).setValues([missing]);
    result.headerWrites.push({ sheetName: sh.getName(), mode: 'APPEND_MISSING_HEADERS', count: missing.length, headers: missing });
  } else {
    result.headerWrites.push({ sheetName: sh.getName(), mode: 'NO_HEADER_WRITE_NEEDED', count: 0 });
  }
}

function erpCoreActualCreateDedicatedDraft_findDuplicates_(list) {
  var seen = {};
  var dup = [];
  for (var i = 0; i < list.length; i++) {
    var v = String(list[i] || '').trim();
    if (!v) continue;
    var key = v.toLowerCase();
    if (seen[key] && dup.indexOf(v) < 0) dup.push(v);
    seen[key] = true;
  }
  return dup;
}
