/**
 * ERP_CORE_ROUTE_BLANK_HOTFIX_SAFE_V2
 * Fix: card click blank page by using SPA rendering and direct-route fallback.
 * Scope: UI read-only. No save, no deploy, no sheet mutation.
 */
var ERP_CORE_ROUTE_BLANK_HOTFIX_V2_BUILD = 'ERP_CORE_ROUTE_BLANK_HOTFIX_SAFE_V2';

function erpCoreRouteBlankHotfixV2_safety_() {
  return {
    build: ERP_CORE_ROUTE_BLANK_HOTFIX_V2_BUILD,
    readOnly: true,
    uiOnly: true,
    spaClientRouting: true,
    noSheetCreate: true,
    noHeaderAutoAdd: true,
    noPolicyWrite: true,
    noDbInjection: true,
    noDeployExecution: true,
    deployAllowed: false,
    actualDeployExecution: false,
    noBusinessDataWrite: true,
    noCustomerSave: true,
    noSaleSave: true,
    noContractCreate: true,
    noInstallAsSave: true,
    noSettlementExecution: true,
    noCancelSettlementConfirm: true,
    noSignDocumentCreate: true,
    noFormAutoRegister: true,
    noRoleMutation: true,
    noDeleteSheet: true,
    noExistingDataClear: true,
    headerMapRequired: true,
    idBasedConnectionRequired: true,
    vendorBranchUserGroup: true,
    qrInitialEntryTargetSearchProtected: true,
    directRegularMemberLink: false,
    noOriginalSlipMutation: true
  };
}

function erpCoreRouteBlankHotfixV2_escape_(v) {
  return String(v == null ? '' : v)
    .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;').replace(/'/g, '&#39;');
}

function erpCoreRouteBlankHotfixV2_page_(cfg) {
  var cards = (cfg.cards || []).map(function(c) {
    return '<div class="card"><div class="k">' + erpCoreRouteBlankHotfixV2_escape_(c.no || '') + '</div><h3>' + erpCoreRouteBlankHotfixV2_escape_(c.title) + '</h3><p>' + erpCoreRouteBlankHotfixV2_escape_(c.desc) + '</p><span class="badge green">READ ONLY</span></div>';
  }).join('');
  var list = (cfg.items || []).map(function(x) { return '<li>' + erpCoreRouteBlankHotfixV2_escape_(x) + '</li>'; }).join('');
  var html = '<!doctype html><html lang="ko"><head><base target="_top"><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>' + erpCoreRouteBlankHotfixV2_escape_(cfg.title) + '</title>' +
    '<style>body{margin:0;background:#f7f4ee;color:#111827;font-family:Arial,\'Noto Sans KR\',sans-serif}.wrap{max-width:1120px;margin:0 auto;padding:28px}.hero{background:#111827;color:#fff;border-radius:22px;padding:26px}.build{color:#f8d27a;font-size:12px}.grid{display:grid;grid-template-columns:repeat(3,1fr);gap:14px;margin-top:18px}.card{background:#fff;border:1px solid #e5e7eb;border-radius:16px;padding:18px;box-shadow:0 8px 22px rgba(0,0,0,.05)}.k{font-weight:800;color:#92400e}.badge{display:inline-block;border-radius:999px;padding:5px 9px;font-size:12px;font-weight:700}.green{background:#ecfdf5;color:#047857}.red{background:#fef2f2;color:#b91c1c}.section{background:#fff;border:1px solid #e5e7eb;border-radius:18px;padding:18px;margin-top:16px}.back{display:inline-block;margin-top:14px;color:#f8d27a;text-decoration:none;font-weight:800}.footer{text-align:center;color:#6b7280;font-size:12px;margin-top:24px}@media(max-width:800px){.grid{grid-template-columns:1fr}}</style></head><body>' +
    '<div class="wrap"><div class="hero"><h1>' + erpCoreRouteBlankHotfixV2_escape_(cfg.title) + '</h1><p>' + erpCoreRouteBlankHotfixV2_escape_(cfg.subtitle) + '</p><div class="build">' + ERP_CORE_ROUTE_BLANK_HOTFIX_V2_BUILD + ' · route=' + erpCoreRouteBlankHotfixV2_escape_(cfg.route) + ' · 실제 저장/정산/배포 차단</div><a class="back" href="?">← ERP_CORE 홈으로</a></div>' +
    '<div class="grid">' + cards + '</div><div class="section"><h2>점검 기준</h2><ul>' + list + '</ul></div><div class="section"><h2>차단 유지</h2><span class="badge red">실제 저장 금지</span> <span class="badge red">정산 실행 금지</span> <span class="badge red">권한 변경 금지</span> <span class="badge red">배포 실행 금지</span></div><div class="footer">© 2026 FEELHAUS. All rights reserved. · (주)필하우스 · 총괄/최고운영자: 이용필 · 메인 개발/기획: 이용필 · 개발 참여: 최유라</div></div></body></html>';
  return HtmlService.createHtmlOutput(html).setTitle(cfg.title).setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL);
}

function erpCoreRouteBlankHotfixV2_render1501(params) {
  return erpCoreRouteBlankHotfixV2_page_({
    route: String((params||{}).page || 'validationSimUi'),
    title: '1501~1640 입력검증 / 권한 / 상태전이',
    subtitle: '필수값, 형식, 권한, 상태전이, 감사로그 시뮬레이션 화면입니다. 실제 저장은 차단됩니다.',
    cards: [
      {no:'1501', title:'필수값·형식 검사', desc:'고객/판매/계약/설치/A/S/정산 저장 전 필수값과 형식을 시뮬레이션합니다.'},
      {no:'1541', title:'권한 검사', desc:'roleCode, vendorId, eventId 기준 접근 가능 범위를 확인합니다.'},
      {no:'1601', title:'상태전이 보호', desc:'잠금/완료 후 일반 수정 차단과 승인 기반 재오픈 구조를 표시합니다.'}
    ],
    items: ['필수값 검사 → 형식 검사 → 권한 검사 → 중복 검사 → 저장 준비 → 감사로그 순서 유지', '완료/잠금/마감 상태 일반 수정 차단', '정산 원전표 직접 수정 금지', 'QR 초기 진입은 대상검색 기반 유지']
  });
}

function erpCoreRouteBlankHotfixV2_render1261(params) {
  return erpCoreRouteBlankHotfixV2_page_({
    route: String((params||{}).page || 'financePermissionDetailUi'),
    title: '1261~1500 정산 / 권한 / FORM 상세',
    subtitle: '정산, 혜택, FORM/QR, PORTAL 상세 UI 점검 화면입니다. 실제 정산과 FORM 자동등록은 차단됩니다.',
    cards: [
      {no:'1261', title:'정산 상세', desc:'정산 후보, 취소정산, 환수/추가지급 구조를 읽기 전용으로 확인합니다.'},
      {no:'1361', title:'혜택 / 상품권', desc:'혜택·상품권·예치금·환수 후보 구조를 안내합니다.'},
      {no:'1461', title:'FORM/QR/PORTAL', desc:'FORM/QR 유입과 PORTAL 상태 표시를 시뮬레이션합니다.'}
    ],
    items: ['취소정산은 정정전표/환수전표/추가지급전표 구조 유지', '민감 권한 및 정산 수정은 승인 기반', 'FORM은 독립 DB가 아닌 ERP 연결 통로', '실제 QR 자동등록과 SIGN 문서 생성 금지']
  });
}

function erpCoreRouteBlankHotfixV2_render981(params) {
  return erpCoreRouteBlankHotfixV2_page_({
    route: String((params||{}).page || 'routeSplit'),
    title: '981~1120 route별 화면 분리 허브',
    subtitle: 'ERP 홈/판매/계약/설치/A/S/정산/사용자관리 route를 화면 단위로 확인하는 허브입니다.',
    cards: [
      {no:'981', title:'ERP 홈', desc:'본사/업체/직원 진입 기준을 표시합니다.'},
      {no:'1001', title:'판매·계약·설치/A/S', desc:'핵심 업무 화면 라우트 분리 상태를 확인합니다.'},
      {no:'1081', title:'정산·사용자관리', desc:'정산/권한/사용자 화면 진입 기준을 확인합니다.'}
    ],
    items: ['route별 화면이 빈 화면 대신 안내문을 출력해야 함', '업체는 ERP 내부 지점형 사용자 그룹으로 유지', '운영 데이터 저장과 권한 변경은 아직 차단', '개별 route 화면 분리 후 CONTROL 최종 게이트 기준 유지']
  });
}

function erpCoreRouteBlankHotfixV2_routeSmokeTest() {
  var required = ['erpCoreRouteBlankHotfixV2_render1501','erpCoreRouteBlankHotfixV2_render1261','erpCoreRouteBlankHotfixV2_render981'];
  var missing = [];
  for (var i = 0; i < required.length; i++) if (typeof this[required[i]] !== 'function') missing.push(required[i]);
  var result = {ok: missing.length === 0, build: ERP_CORE_ROUTE_BLANK_HOTFIX_V2_BUILD, fatal: missing, warnings: [], safety: erpCoreRouteBlankHotfixV2_safety_()};
  Logger.log('[ERP_CORE ROUTE BLANK HOTFIX V2 SMOKE] ' + JSON.stringify(result));
  return result;
}

function erpCoreRouteBlankHotfixV2_renderCheck() {
  var routes = [
    {name:'1501', fn:'erpCoreRouteBlankHotfixV2_render1501', page:'validationSimUi'},
    {name:'1261', fn:'erpCoreRouteBlankHotfixV2_render1261', page:'financePermissionDetailUi'},
    {name:'981', fn:'erpCoreRouteBlankHotfixV2_render981', page:'routeSplit'}
  ];
  var checks = routes.map(function(r){
    var ok = false;
    var error = '';
    try {
      var out = this[r.fn]({page:r.page});
      ok = !!out && typeof out.getContent === 'function' && out.getContent().indexOf('실제 저장') >= 0;
    } catch (e) { error = String(e && e.message ? e.message : e); }
    return {route:r.name, functionName:r.fn, page:r.page, ok:ok, error:error};
  }, this);
  var fatal = checks.filter(function(x){return !x.ok;}).map(function(x){return x.functionName + ':' + x.error;});
  return {ok:fatal.length===0, build:ERP_CORE_ROUTE_BLANK_HOTFIX_V2_BUILD, checks:checks, fatal:fatal, warnings:[], businessDataWrite:false, deployAllowed:false, safety:erpCoreRouteBlankHotfixV2_safety_()};
}
