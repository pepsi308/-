/**
 * FEELHAUS ERP Core Schema Prep V15
 * Controlled schema preparation for runtime gate fatal items.
 * Dry run is safe. Apply creates missing control sheets/headers only.
 */
var ERP_SCHEMA_PREP_V15_SETUP_DB_ID = '17VMSpgSZCvIrUlgcw8yCNcnl8WQWo2IcRf5tDCcuJGM';
var ERP_SCHEMA_PREP_V15_CONFIG_SHEET_NAME = 'SystemConfig';

function runErpCoreSchemaPrepV15DryRun() {
  return erpCoreSchemaPrepV15_run_({ apply: false });
}

function runErpCoreSchemaPrepV15Apply() {
  return erpCoreSchemaPrepV15_run_({ apply: true });
}

function erpCoreSchemaPrepV15_run_(options) {
  options = options || {};
  var apply = options.apply === true;
  var master = erpCoreSchemaPrepV15_openMaster_();
  var result = {
    ok: true,
    build: 'ERP_CORE_SCHEMA_PREP_V15',
    checkedAt: new Date().toISOString(),
    mode: apply ? 'APPLY_SCHEMA_ONLY' : 'DRY_RUN',
    businessDataChanged: false,
    sheets: [],
    warnings: [],
    nextAction: ''
  };

  var specs = erpCoreSchemaPrepV15_specs_();
  for (var i = 0; i < specs.length; i++) {
    var row = erpCoreSchemaPrepV15_prepareSheet_(master, specs[i], apply);
    result.sheets.push(row);
    if (!row.ok) result.ok = false;
  }

  result.nextAction = apply
    ? 'runErpPrebuildRuntimeGateV7Summary 실행 후 fatalChecks 확인'
    : '문제 없으면 runErpCoreSchemaPrepV15Apply 1회 실행';
  Logger.log(JSON.stringify(result, null, 2));
  return result;
}

function erpCoreSchemaPrepV15_specs_() {
  return [
    {
      purpose: '권한 구조 점검(roleCode/vendorId/eventId)',
      sheetName: 'ERP_권한관리',
      headers: ['roleCode','vendorId','eventId','status','permissionScope','canView','canEdit','canDownload','sensitiveAccess','approvalRequired','createdAt','createdBy','updatedAt','updatedBy','memo']
    },
    {
      purpose: '상태전이 구조 점검',
      sheetName: 'ERP_상태전이정책',
      headers: ['fromStatus','toStatus','roleCode','approvalRequired','status','domain','statusReason','createdAt','createdBy','updatedAt','updatedBy','memo']
    },
    {
      purpose: '감사로그 구조 점검',
      sheetName: 'ERP_CoreLog',
      headers: ['logId','action','status','statusReason','targetSheet','targetId','eventId','vendorId','customerId','saleId','contractId','installId','asId','settlementId','documentId','createdAt','createdBy','detail']
    },
    {
      purpose: '정산/취소정산/환수/추가지급 보호 구조 점검',
      sheetName: 'ERP_정산관리',
      headers: ['settlementId','eventId','vendorId','customerId','saleId','contractId','status','statusReason','cancelSettlementId','correctionSaleId','recoveryAmount','additionalPaymentAmount','feelhausBurdenAmount','originalSaleId','paymentId','approvalId','createdAt','createdBy','updatedAt','updatedBy','memo']
    }
  ];
}

function erpCoreSchemaPrepV15_prepareSheet_(ss, spec, apply) {
  var sh = ss.getSheetByName(spec.sheetName);
  var row = {
    sheetName: spec.sheetName,
    purpose: spec.purpose,
    existed: !!sh,
    created: false,
    addedHeaders: [],
    duplicateHeaders: [],
    ok: true
  };
  if (!sh && apply) {
    sh = ss.insertSheet(spec.sheetName);
    row.created = true;
  }
  if (!sh) {
    row.ok = false;
    row.missingSheet = true;
    row.addedHeaders = spec.headers.slice();
    return row;
  }

  var lastCol = Math.max(sh.getLastColumn(), 1);
  var headers = sh.getRange(1, 1, 1, lastCol).getValues()[0].map(function(v){ return String(v || '').trim(); });
  var seen = {};
  for (var i = 0; i < headers.length; i++) {
    var h = headers[i];
    if (!h) continue;
    if (seen[h]) row.duplicateHeaders.push(h);
    seen[h] = true;
  }
  for (var j = 0; j < spec.headers.length; j++) {
    var need = spec.headers[j];
    if (!seen[need]) row.addedHeaders.push(need);
  }
  if (apply && row.addedHeaders.length) {
    var startCol = Math.max(sh.getLastColumn(), 1) + 1;
    if (sh.getLastRow() < 1) sh.getRange(1, 1).setValue('');
    sh.getRange(1, startCol, 1, row.addedHeaders.length).setValues([row.addedHeaders]);
  }
  row.ok = row.duplicateHeaders.length === 0;
  return row;
}

function erpCoreSchemaPrepV15_openMaster_() {
  var setup = SpreadsheetApp.openById(ERP_SCHEMA_PREP_V15_SETUP_DB_ID);
  var cfg = setup.getSheetByName(ERP_SCHEMA_PREP_V15_CONFIG_SHEET_NAME);
  if (!cfg) throw new Error('SystemConfig 시트를 찾을 수 없습니다.');
  var values = cfg.getDataRange().getValues();
  var map = {};
  for (var r = 1; r < values.length; r++) {
    var k = String(values[r][0] || '').trim();
    var v = String(values[r][1] || '').trim();
    if (k) map[k] = v;
  }
  var id = map.FEELHAUS_DB_MASTER_ID || map.DB_MASTER_ID || map.SPREADSHEET_ID;
  if (!id) throw new Error('FEELHAUS_DB_MASTER_ID / DB_MASTER_ID 설정을 찾을 수 없습니다.');
  return SpreadsheetApp.openById(id);
}
