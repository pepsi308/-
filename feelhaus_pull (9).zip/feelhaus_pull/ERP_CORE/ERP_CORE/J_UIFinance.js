/**
 * FEELHAUS ERP_CORE CLEAN MODULE: ERP_FinanceUI.js
 * Consolidated from: ERP_Integrated_SettlementBenefitFinance_UI.js, ERP_Integrated_FinancePermissionFormPortal_Detail_UI.js
 * Safety: read-only/check/simulation only. actualExecutionBlocked must remain true.
 */



/* ===== BEGIN ERP_Integrated_SettlementBenefitFinance_UI.js ===== */

/**
 * Build: ERP_INTEGRATED_B06J41_701_860_SETTLEMENT_BENEFIT_FINANCE_UI_SAFE
 * File: ERP_Integrated_SettlementBenefitFinance_UI.js
 * Project: ERP_CORE
 * Purpose: read-only UI skeleton/report for settlement, cancellation settlement, deposit/bond, benefits, gift certificate, development fund, deposit return.
 */

var ERP_INTEGRATED_B06J41_701_860_MODULE_BUILD = 'ERP_INTEGRATED_B06J41_701_860_SETTLEMENT_BENEFIT_FINANCE_UI_SAFE';
var ERP_INTEGRATED_B06J41_701_860_MODULE_FILE = 'ERP_Integrated_SettlementBenefitFinance_UI.js';

function erpIntegratedB06J41_701_860_renderSettlementBenefitFinanceUiHtml(ctx) {
  var model = erpIntegratedB06J41_701_860_buildModel_(ctx || {});
  var template = HtmlService.createTemplateFromFile('H_Finance');
  template.model = model;
  return template.evaluate()
    .setTitle('FEELHAUS ERP 정산/혜택 UI 701~860')
    .setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL);
}

function erpIntegratedB06J41_701_860_buildModel_(ctx) {
  var screens = erpIntegratedB06J41_701_860_buildScreens_();
  var blockers = erpIntegratedB06J41_701_860_buildBlockers_();
  var workflow = erpIntegratedB06J41_701_860_buildWorkflow_();
  var financeRules = erpIntegratedB06J41_701_860_buildFinanceRules_();
  var status = {
    fatalCount: 0,
    screenCount: screens.length,
    financeRuleCount: financeRules.length,
    approvalRequiredCount: screens.filter(function(s){ return s.approvalRequired; }).length,
    blockedCount: blockers.length,
    actualCreateConfirm: false,
    deployAllowed: false,
    actualExecutionBlocked: true,
    vendorBranchUserGroup: true
  };
  return {
    ok: true,
    build: ERP_INTEGRATED_B06J41_701_860_MODULE_BUILD,
    checkedAt: new Date().toISOString(),
    ctx: ctx || {},
    status: status,
    screens: screens,
    blockers: blockers,
    workflow: workflow,
    financeRules: financeRules,
    roleRules: erpIntegratedB06J41_701_860_buildRoleRules_(),
    nextSteps: erpIntegratedB06J41_701_860_buildNextSteps_(),
    safety: erpIntegratedB06J41_701_860_safety_()
  };
}

function erpIntegratedB06J41_701_860_buildScreens_() {
  return [
    {no:'701', area:'정산조회', project:'ERP_ADMIN/ERP_FIELD', route:'settlementUi', priority:'HIGH', status:'SCREEN_SKELETON', approvalRequired:false, summary:'본사 전체 정산 조회와 업체별 내 정산 조회를 분리 표시'},
    {no:'721', area:'취소정산', project:'ERP_ADMIN', route:'cancelSettlementUi', priority:'HIGH', status:'REPORT_ONLY', approvalRequired:true, summary:'원전표 직접 수정 금지, 취소정정전표/환수/추가지급 구조 안내'},
    {no:'741', area:'환수/추가지급', project:'ERP_ADMIN', route:'financeUi', priority:'HIGH', status:'BLOCKED_ACTION', approvalRequired:true, summary:'환수전표와 추가지급전표는 승인 필요로 표시, 실행은 차단'},
    {no:'761', area:'예치금/채권', project:'ERP_ADMIN/ERP_FIELD', route:'depositBondUi', priority:'HIGH', status:'SCREEN_SKELETON', approvalRequired:true, summary:'예치금 잔액, 채권 잔액, 차감 가능 여부를 회계형식으로 표시'},
    {no:'781', area:'혜택/상품권', project:'ERP_ADMIN/ERP_FIELD', route:'benefitGiftUi', priority:'HIGH', status:'SCREEN_SKELETON', approvalRequired:true, summary:'방문혜택, 정회원혜택, 상품권 지급/사용/정산 여부를 분리 표시'},
    {no:'801', area:'발전기금', project:'ERP_ADMIN', route:'fundReturnUi', priority:'HIGH', status:'SCREEN_SKELETON', approvalRequired:true, summary:'단지발전혜택 약정, 사용현황, 집행요청, 증빙 상태 표시'},
    {no:'821', area:'예치·환입', project:'ERP_ADMIN', route:'fundReturnUi', priority:'MEDIUM', status:'REPORT_ONLY', approvalRequired:true, summary:'예치/환입은 회계팀장 또는 본사 승인 필요, 실제 입출금 처리 차단'},
    {no:'841', area:'회계형 금액 표시', project:'ERP_CORE', route:'financeUi', priority:'MEDIUM', status:'UI_RULE', approvalRequired:false, summary:'금액은 KRW 회계형식으로 표시하고 잔금/차액/부담액 구분'},
    {no:'851', area:'상태/로그/감사', project:'ERP_CORE/CONTROL', route:'erp860', priority:'HIGH', status:'AUDIT_REQUIRED', approvalRequired:true, summary:'상태전이, 승인 요청, 감사로그, CONTROL 진단 연계 표시'},
    {no:'860', area:'빈화면 안내', project:'ERP_CORE', route:'erp860', priority:'MEDIUM', status:'EMPTY_GUIDE', approvalRequired:false, summary:'정산/혜택 데이터가 없으면 빈화면 대신 안내문과 다음 작업 표시'}
  ];
}

function erpIntegratedB06J41_701_860_buildBlockers_() {
  return [
    {key:'actualCreateConfirm', value:false, state:'BLOCKED', message:'실제 생성 승인 전환 금지'},
    {key:'deployAllowed', value:false, state:'BLOCKED', message:'실제 배포 승인 전환 금지'},
    {key:'actualExecutionBlocked', value:true, state:'ACTIVE', message:'실제 실행 차단 유지'},
    {key:'settlementExecution', value:false, state:'BLOCKED', message:'정산 실행 차단'},
    {key:'cancelSettlementConfirm', value:false, state:'BLOCKED', message:'취소정산 확정 차단'},
    {key:'paymentRecoveryOffset', value:false, state:'BLOCKED', message:'지급/환수/차감 실행 차단'},
    {key:'depositReturnExecution', value:false, state:'BLOCKED', message:'예치·환입 실제 처리 차단'},
    {key:'benefitPayoutExecution', value:false, state:'BLOCKED', message:'혜택/상품권 실제 지급 차단'},
    {key:'fundExecution', value:false, state:'BLOCKED', message:'발전기금 집행 실행 차단'},
    {key:'sheetCreate', value:false, state:'BLOCKED', message:'시트 생성 차단'},
    {key:'dbInjection', value:false, state:'BLOCKED', message:'DB 주입 차단'},
    {key:'roleMutation', value:false, state:'BLOCKED', message:'권한 실제 변경 차단'}
  ];
}

function erpIntegratedB06J41_701_860_buildWorkflow_() {
  return [
    '판매 → 계약 → SIGN 보관완료 → 정산 후보 표시',
    '정산 검토 → 승인 필요 표시 → 실제 정산 실행 차단',
    '취소 발생 → 취소정산 계산 리포트 → 원전표 직접 수정 금지 안내',
    '환수/추가지급 후보 → 승인 필요 표시 → 지급/차감 실행 차단',
    '혜택/상품권/발전기금 → 정책/증빙/상태 조회 → 실제 집행 차단',
    '예치금/채권/예치·환입 → 회계형식 조회 → 실제 입출금 차단',
    'CONTROL 진단 / 감사로그 / 배포통제 기준과 연결'
  ];
}

function erpIntegratedB06J41_701_860_buildFinanceRules_() {
  return [
    {name:'원전표 직접 수정 금지', status:'PROTECTED', detail:'사후 취소는 취소정정전표, 환수전표, 추가지급전표 구조로 처리'},
    {name:'고객 환불액 분리', status:'REQUIRED', detail:'고객 실결제액과 고객 귀책 공제액을 분리 표시'},
    {name:'업체 환수액 분리', status:'REQUIRED', detail:'원업체 정산액에서 보전 인정액을 분리 계산'},
    {name:'업체 추가지급액 분리', status:'REQUIRED', detail:'정책 보전/설치비/운영 보전 사유를 구분'},
    {name:'필하우스 부담액 분리', status:'REQUIRED', detail:'추가지급, 환불지원, 복구지원, 환수액을 분리 표시'},
    {name:'상품권 정산형/비정산형 분리', status:'REQUIRED', detail:'고객 할인 이력과 업체 정산 인정액을 분리'},
    {name:'회계형 금액 표시', status:'UI_RULE', detail:'KRW 기준 천단위 구분, 음수/차감/환입 구분'},
    {name:'승인 기반 실행', status:'BLOCKED', detail:'민감 금액, 집행, 환수, 추가지급은 승인 전 실행 불가'}
  ];
}

function erpIntegratedB06J41_701_860_buildRoleRules_() {
  return [
    {role:'HQ_ADMIN', scope:'전체 정산/혜택/발전기금 조회, 승인 요청 검토'},
    {role:'FINANCE_MANAGER', scope:'지급/환수/예치·환입 검토, 실제 처리는 승인 전 차단'},
    {role:'VENDOR_OWNER', scope:'자기 업체 정산/혜택/채권 조회, 민감 항목 일부 마스킹'},
    {role:'STAFF_SALES', scope:'자기 판매건 기준 정산 후보 및 혜택 상태 조회'},
    {role:'STAFF_INSTALL_AS', scope:'설치/A/S 비용 관련 상태 조회'}
  ];
}

function erpIntegratedB06J41_701_860_buildNextSteps_() {
  return [
    '861~980 직원관리/권한관리/FORM·QR/PORTAL 상태 리포트 최종 묶음 점검',
    '정산/혜택 화면을 실제 개별 route로 분리할지 여부 결정',
    'SheetPolicy/HeaderPolicy 확정 전 실제 시트 생성 금지 유지',
    '정산·환수·추가지급 실행 버튼은 CONTROL 승인 전까지 숨김 또는 차단',
    'ERP_FIELD/ERP_ADMIN/PORTAL 표시용 상태값 명칭 통일'
  ];
}

function erpIntegratedB06J41_701_860_safety_() {
  return {
    readOnlyUiSkeleton: true,
    deployAllowed: false,
    actualCreateConfirm: false,
    actualExecutionBlocked: true,
    noSheetCreate: true,
    noHeaderAutoCreate: true,
    noDbInjection: true,
    noSettlementExecution: true,
    noCancelSettlementConfirm: true,
    noPaymentRecoveryOffset: true,
    noDepositReturnExecution: true,
    noBenefitPayoutExecution: true,
    noFundExecution: true,
    noRoleMutation: true,
    noDeployExecution: true,
    vendorBranchUserGroup: true
  };
}

function erpIntegratedB06J41_701_860_routeSmokeTest() {
  var routes = ['settlementBenefitUi','settlementUi','cancelSettlementUi','depositBondUi','benefitGiftUi','fundReturnUi','financeUi','erp701','erp860'];
  var result = {
    ok: true,
    build: ERP_INTEGRATED_B06J41_701_860_MODULE_BUILD,
    routeFile: 'Code.js',
    moduleFile: ERP_INTEGRATED_B06J41_701_860_MODULE_FILE,
    routes: routes,
    renderFunctionExists: typeof erpIntegratedB06J41_701_860_renderSettlementBenefitFinanceUiHtml === 'function',
    selfTestExists: typeof erpIntegratedB06J41_701_860_selfTest === 'function',
    safety: erpIntegratedB06J41_701_860_safety_()
  };
  console.log('[ERP_INTEGRATED 701-860 ROUTE SMOKE TEST] ' + JSON.stringify(result));
  return result;
}

function erpIntegratedB06J41_701_860_selfTest() {
  var model = erpIntegratedB06J41_701_860_buildModel_({test:true});
  var required = [
    'erpIntegratedB06J41_701_860_renderSettlementBenefitFinanceUiHtml',
    'erpIntegratedB06J41_701_860_selfTest',
    'erpIntegratedB06J41_701_860_routeSmokeTest',
    'erpIntegratedB06J41_701_860_buildModel_',
    'erpIntegratedB06J41_701_860_buildScreens_',
    'erpIntegratedB06J41_701_860_buildBlockers_'
  ];
  var missing = [];
  for (var i = 0; i < required.length; i++) {
    if (typeof this[required[i]] !== 'function') missing.push(required[i]);
  }
  var result = {
    ok: missing.length === 0 && model.status.fatalCount === 0,
    build: ERP_INTEGRATED_B06J41_701_860_MODULE_BUILD,
    checkedAt: new Date().toISOString(),
    fatal: [],
    warnings: [],
    checks: {
      requiredFunctions: {ok: missing.length === 0, missing: missing},
      screens: {ok: model.screens.length === 10, screenCount: model.screens.length},
      financeRules: {ok: model.financeRules.length === 8, financeRuleCount: model.financeRules.length},
      blockers: {ok: model.blockers.length === 12, blockedCount: model.blockers.length},
      safety: erpIntegratedB06J41_701_860_safety_()
    }
  };
  console.log('[ERP_INTEGRATED 701-860 SELFTEST] ' + JSON.stringify(result));
  return result;
}


/* ===== END ERP_Integrated_SettlementBenefitFinance_UI.js ===== */



/* ===== BEGIN ERP_Integrated_FinancePermissionFormPortal_Detail_UI.js ===== */

/**
 * ERP_INTEGRATED_B06J41_1261_1500_FINANCE_PERMISSION_FORM_PORTAL_DETAIL_UI_SAFE
 * 적용 프로젝트: ERP_CORE
 * 목적: 정산/혜택/권한/FORM/PORTAL 상세 UI 2차 점검. 실제 실행 없음.
 */
var ERP_INTEGRATED_B06J41_1261_1500_BUILD = 'ERP_INTEGRATED_B06J41_1261_1500_FINANCE_PERMISSION_FORM_PORTAL_DETAIL_UI_SAFE';

function erpIntegratedB06J41_1261_1500_routes_() {
  return [
    'financePermissionDetailUi',
    'financeDetailUi',
    'settlementDetailUi',
    'cancelSettlementDetailUi',
    'depositBondDetailUi',
    'benefitGiftDetailUi',
    'fundReturnDetailUi',
    'staffPermissionDetailUi',
    'formQrDetailUi',
    'portalReportDetailUi',
    'finalValidationDetailUi',
    'erp1261',
    'erp1500'
  ];
}

function erpIntegratedB06J41_1261_1500_renderFinancePermissionFormPortalDetailHtml(ctx) {
  ctx = ctx || {};
  var model = erpIntegratedB06J41_1261_1500_buildModel_(ctx);
  var tpl = HtmlService.createTemplateFromFile('H_FinDetail');
  tpl.modelJson = JSON.stringify(model);
  return tpl.evaluate()
    .setTitle('FEELHAUS ERP 상세 UI 1261~1500')
    .setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL);
}

function erpIntegratedB06J41_1261_1500_buildModel_(ctx) {
  ctx = ctx || {};
  var route = String(ctx.page || ctx.route || ctx.view || ctx.mode || 'financePermissionDetailUi');
  var screens = erpIntegratedB06J41_1261_1500_screenMap_();
  var selected = screens[route] || screens.financePermissionDetailUi;
  return {
    ok: true,
    build: ERP_INTEGRATED_B06J41_1261_1500_BUILD,
    checkedAt: new Date().toISOString(),
    project: 'ERP_CORE',
    route: route,
    selected: selected,
    routes: erpIntegratedB06J41_1261_1500_routes_(),
    screens: screens,
    summary: {
      fatal: 0,
      detailScreens: Object.keys(screens).length,
      financeRules: erpIntegratedB06J41_1261_1500_financeRules_().length,
      permissionRules: erpIntegratedB06J41_1261_1500_permissionRules_().length,
      qrSteps: erpIntegratedB06J41_1261_1500_qrSteps_().length,
      portalReportItems: erpIntegratedB06J41_1261_1500_portalReportItems_().length,
      blockers: erpIntegratedB06J41_1261_1500_blockers_().length
    },
    financeRules: erpIntegratedB06J41_1261_1500_financeRules_(),
    permissionRules: erpIntegratedB06J41_1261_1500_permissionRules_(),
    qrSteps: erpIntegratedB06J41_1261_1500_qrSteps_(),
    portalReportItems: erpIntegratedB06J41_1261_1500_portalReportItems_(),
    validationChecks: erpIntegratedB06J41_1261_1500_validationChecks_(),
    blockers: erpIntegratedB06J41_1261_1500_blockers_(),
    safety: erpIntegratedB06J41_1261_1500_safety_()
  };
}

function erpIntegratedB06J41_1261_1500_screenMap_() {
  return {
    financePermissionDetailUi: {
      title: '정산/혜택/권한/FORM/PORTAL 상세 UI 2차 허브',
      domain: 'ERP_CORE',
      status: 'DETAIL_UI_READY',
      fields: ['settlementId','saleId','contractId','vendorId','customerId','status','approvalStatus','blocked'],
      description: '1261~1500 상세 UI 2차 전체 항목을 한 화면에서 확인합니다.',
      note: '개별 route 버튼을 선택하면 업무별 상세 점검 화면으로 분리 표시됩니다.'
    },
    financeDetailUi: {
      title: '정산조회 상세 UI',
      domain: 'ERP_ADMIN/ERP_FIELD',
      status: 'DETAIL_UI_READY',
      fields: ['settlementId','vendorId','eventId','saleId','contractId','settlementAmount','settlementStatus','locked'],
      description: '정산조회 화면의 요약/목록/상세/회계형 금액 표시 기준을 점검합니다.',
      note: '실제 정산 실행은 CONTROL 승인 전까지 차단됩니다.'
    },
    settlementDetailUi: {
      title: '정산 상세 UI',
      domain: 'ERP_ADMIN/ERP_FIELD',
      status: 'DETAIL_UI_READY',
      fields: ['settlementId','baseAmount','feeAmount','deductionAmount','payableAmount','approvalStatus','locked'],
      description: '정산 대상, 공제, 지급예정, 보류 사유, 승인 상태를 분리 표시합니다.',
      note: '지급/차감/확정 실행은 차단 상태입니다.'
    },
    cancelSettlementDetailUi: {
      title: '취소정산 / 환수 / 추가지급 상세 UI',
      domain: 'ERP_ADMIN',
      status: 'DETAIL_UI_READY',
      fields: ['cancelId','originalSettlementId','refundAmount','recoveryAmount','additionalPaymentAmount','reason','approvalStatus'],
      description: '원전표 직접 수정 금지 원칙과 취소정정전표 → 환수/추가지급 전표 구조를 표시합니다.',
      note: '취소정산 확정과 환수/추가지급 실행은 차단됩니다.'
    },
    depositBondDetailUi: {
      title: '예치금 / 채권 / 예치·환입 상세 UI',
      domain: 'ERP_ADMIN',
      status: 'DETAIL_UI_READY',
      fields: ['vendorId','depositBalance','bondBalance','returnRequestAmount','evidenceStatus','approvalStatus'],
      description: '예치금 잔액, 채권, 환입 요청, 증빙 상태를 회계형으로 표시합니다.',
      note: '실제 예치·환입 처리는 차단됩니다.'
    },
    benefitGiftDetailUi: {
      title: '혜택 / 상품권 상세 UI',
      domain: 'ERP_ADMIN/ERP_FIELD',
      status: 'DETAIL_UI_READY',
      fields: ['benefitId','eventId','customerId','memberType','giftType','payoutStatus','approvalStatus'],
      description: '방문혜택, 정회원혜택, 상품권 지급 상태와 승인 필요 여부를 표시합니다.',
      note: '실제 혜택/상품권 지급은 차단됩니다.'
    },
    fundReturnDetailUi: {
      title: '발전기금 / 예치·환입 상세 UI',
      domain: 'ERP_ADMIN',
      status: 'DETAIL_UI_READY',
      fields: ['fundId','eventId','agreementAmount','executionAmount','evidenceStatus','returnStatus','approvalStatus'],
      description: '발전기금 약정/집행/증빙/환입 상태를 민감 권한 기준으로 표시합니다.',
      note: '발전기금 집행은 차단됩니다.'
    },
    staffPermissionDetailUi: {
      title: '직원관리 / 권한관리 상세 UI',
      domain: 'ERP_ADMIN/ERP_FIELD',
      status: 'DETAIL_UI_READY',
      fields: ['userId','vendorId','roleCode','menuScope','dataScope','permissionStatus','approvalStatus'],
      description: '업체 직원 관리와 민감 권한 승인 필요 구조를 표시합니다.',
      note: '직원 생성과 권한 변경은 차단됩니다.'
    },
    formQrDetailUi: {
      title: 'FORM / QR 초기 진입 상세 UI',
      domain: 'FORM/ERP_FIELD',
      status: 'QR_TARGET_SEARCH_PROTECTED',
      fields: ['eventId','requestId','customerId','memberType','dong','ho','phone','inquiryType','handoffStatus'],
      description: '행사장 QR 스캔 후 대상 검색, 정회원/준회원/조합원/일반 분기와 문의 분기를 표시합니다.',
      note: '정회원 전용 바로 링크가 아니라 대상검색 기반 통합 진입입니다.'
    },
    portalReportDetailUi: {
      title: 'PORTAL 표시용 ERP 상태 리포트 상세 UI',
      domain: 'PORTAL/ERP_CORE',
      status: 'DETAIL_UI_READY',
      fields: ['erpCoreStatus','fieldStatus','adminStatus','signStatus','controlStatus','blocked','updatedAt'],
      description: 'PORTAL에서 표시할 ERP 상태 카드와 차단 상태를 리포트로 표시합니다.',
      note: 'PORTAL 상태값 실제 변경은 차단됩니다.'
    },
    finalValidationDetailUi: {
      title: '최종 검증 시뮬레이션 / 빈화면 안내 상세 UI',
      domain: 'ERP_CORE',
      status: 'SIMULATION_ONLY',
      fields: ['required','format','permission','duplicate','stateTransition','emptyGuide','blocked'],
      description: '필수값/형식/권한/중복/상태전이 검증 순서와 빈화면 안내를 표시합니다.',
      note: '실제 감사로그 쓰기와 상태변경은 차단됩니다.'
    }
  };
}

function erpIntegratedB06J41_1261_1500_financeRules_() {
  return [
    {key:'ACCOUNTING_FORMAT', title:'금액 회계형 표시', detail:'원화, 천단위 구분, 음수/차감/환수 표기 분리'},
    {key:'NO_ORIGINAL_SLIP_MUTATION', title:'원전표 직접 수정 금지', detail:'취소/정정은 별도 전표로 처리'},
    {key:'CANCEL_CORRECTION_SLIP', title:'취소정정전표 생성 구조', detail:'취소정산 계산 후 별도 정정전표 후보 표시'},
    {key:'RECOVERY_SLIP', title:'환수전표 후보', detail:'업체 환수액과 차기정산 차감 후보 분리'},
    {key:'ADDITIONAL_PAYMENT_SLIP', title:'추가지급전표 후보', detail:'정책/설치/협의 보전 사유 표시'},
    {key:'DEPOSIT_BOND_MASKING', title:'예치/채권 민감정보', detail:'권한에 따라 잔액/메모/증빙 노출 차등'},
    {key:'BENEFIT_APPROVAL_REQUIRED', title:'혜택/상품권 승인', detail:'민감 지급은 본사 승인 필요 표시'},
    {key:'FUND_EXECUTION_APPROVAL', title:'발전기금 집행 승인', detail:'대표/회계 승인 전 실행 차단'}
  ];
}

function erpIntegratedB06J41_1261_1500_permissionRules_() {
  return [
    {key:'VENDOR_SCOPE_ONLY', title:'업체 범위 제한', detail:'업체 사용자는 자기 vendorId 범위만 표시'},
    {key:'HQ_FULL_VIEW', title:'본사 전체 조회', detail:'HQ 권한은 전체 조회 가능하나 실행은 차단'},
    {key:'SENSITIVE_ROLE_APPROVAL', title:'민감 권한 승인', detail:'정산/예치/채권/다운로드 권한은 승인 필요'},
    {key:'NO_SUPER_ADMIN_GRANT', title:'최고권한 부여 차단', detail:'업체대표/관리자는 SUPER_ADMIN 부여 불가'},
    {key:'MENU_DATA_DOWNLOAD_SPLIT', title:'메뉴/데이터/다운로드 분리', detail:'권한 종류별 승인 조건 분리'},
    {key:'AUDIT_REQUIRED', title:'감사추적 필요', detail:'권한 변경 요청과 승인 이력 추적 필요'}
  ];
}

function erpIntegratedB06J41_1261_1500_qrSteps_() {
  return [
    'QR_INITIAL_ENTRY',
    'QR_EVENT_VALIDATE',
    'QR_TARGET_SEARCH',
    'QR_MEMBER_MATCH',
    'QR_ASSOCIATE_MEMBER_MATCH',
    'QR_UNION_MEMBER_MATCH',
    'QR_GENERAL_VISITOR_FULL_INPUT',
    'QR_INFO_UPDATE_REQUEST',
    'QR_COUNCIL_INQUIRY',
    'QR_BOOTH_INQUIRY',
    'QR_AS_INQUIRY',
    'QR_COUNSEL_REQUEST',
    'ERP_CUSTOMER_FORM_HANDOFF'
  ];
}

function erpIntegratedB06J41_1261_1500_portalReportItems_() {
  return [
    'ERP_FIELD_SIGN_STATUS_LINK_DONE',
    'ERP_ADMIN_SIGN_DASHBOARD_DONE',
    'ERP_CORE_PRE_DEPLOY_AUDIT_DONE',
    'ERP_CORE_APPROVAL_DECISION_DONE',
    'ERP_ROUTE_SPLIT_DONE',
    'FORM_QR_TARGET_SEARCH_PROTECTED',
    'EXECUTION_STILL_BLOCKED',
    'CONTROL_APPROVAL_REQUIRED'
  ];
}

function erpIntegratedB06J41_1261_1500_validationChecks_() {
  return [
    {key:'REQUIRED_CHECK', title:'필수값 검사', status:'SIMULATED'},
    {key:'FORMAT_CHECK', title:'형식 검사', status:'SIMULATED'},
    {key:'PERMISSION_CHECK', title:'권한 검사', status:'SIMULATED'},
    {key:'DUPLICATE_CHECK', title:'중복 검사', status:'SIMULATED'},
    {key:'STATE_TRANSITION_CHECK', title:'상태전이 검사', status:'SIMULATED'},
    {key:'LOCKED_RECORD_CHECK', title:'잠금/보관완료 검사', status:'SIMULATED'},
    {key:'EMPTY_GUIDE_CHECK', title:'빈화면 안내 검사', status:'SIMULATED'}
  ];
}

function erpIntegratedB06J41_1261_1500_blockers_() {
  return [
    'SHEET_CREATE_BLOCKED','HEADER_AUTO_CREATE_BLOCKED','DB_INJECTION_BLOCKED','CUSTOMER_SAVE_BLOCKED',
    'SALE_SAVE_BLOCKED','CONTRACT_CREATE_BLOCKED','SIGN_DOCUMENT_CREATE_BLOCKED','INSTALL_AS_SAVE_BLOCKED',
    'SETTLEMENT_EXECUTION_BLOCKED','CANCEL_SETTLEMENT_CONFIRM_BLOCKED','PAYMENT_RECOVERY_OFFSET_BLOCKED',
    'DEPOSIT_RETURN_EXECUTION_BLOCKED','BENEFIT_PAYOUT_EXECUTION_BLOCKED','FUND_EXECUTION_BLOCKED',
    'STAFF_CREATE_BLOCKED','ROLE_MUTATION_BLOCKED','FORM_AUTO_REGISTER_BLOCKED','PORTAL_MUTATION_BLOCKED',
    'AUDIT_WRITE_BLOCKED','DEPLOY_EXECUTION_BLOCKED','BACKUP_RECOVERY_ROLLBACK_BLOCKED'
  ];
}

function erpIntegratedB06J41_1261_1500_safety_() {
  return {
    readOnlyDetailUi: true,
    deployAllowed: false,
    actualCreateConfirm: false,
    actualExecutionBlocked: true,
    noSheetCreate: true,
    noHeaderAutoCreate: true,
    noDbInjection: true,
    noCustomerSave: true,
    noSaleSave: true,
    noContractCreate: true,
    noSignDocumentCreate: true,
    noInstallAsSave: true,
    noSettlementExecution: true,
    noCancelSettlementConfirm: true,
    noPaymentRecoveryOffset: true,
    noDepositReturnExecution: true,
    noBenefitPayoutExecution: true,
    noFundExecution: true,
    noStaffCreate: true,
    noRoleMutation: true,
    noFormAutoRegister: true,
    noPortalMutation: true,
    noAuditWrite: true,
    noDeployExecution: true,
    noBackupRecoveryRollbackExecution: true,
    vendorBranchUserGroup: true,
    qrInitialEntryTargetSearchProtected: true,
    directRegularMemberLink: false,
    noOriginalSlipMutation: true
  };
}

function erpIntegratedB06J41_1261_1500_selfTest() {
  var model = erpIntegratedB06J41_1261_1500_buildModel_({page:'financePermissionDetailUi'});
  var required = [
    'erpIntegratedB06J41_1261_1500_renderFinancePermissionFormPortalDetailHtml',
    'erpIntegratedB06J41_1261_1500_selfTest',
    'erpIntegratedB06J41_1261_1500_routeSmokeTest',
    'erpIntegratedB06J41_1261_1500_buildModel_',
    'erpIntegratedB06J41_1261_1500_screenMap_',
    'erpIntegratedB06J41_1261_1500_qrSteps_'
  ];
  var missing = [];
  for (var i = 0; i < required.length; i++) {
    if (typeof this[required[i]] !== 'function') missing.push(required[i]);
  }
  var result = {
    ok: missing.length === 0 && model.summary.detailScreens === 11 && model.summary.qrSteps === 13,
    build: ERP_INTEGRATED_B06J41_1261_1500_BUILD,
    checkedAt: new Date().toISOString(),
    fatal: [],
    warnings: [],
    checks: {
      requiredFunctions: {ok: missing.length === 0, missing: missing},
      screens: {ok: model.summary.detailScreens === 11, screenCount: model.summary.detailScreens},
      financeRules: {ok: model.summary.financeRules === 8, financeRuleCount: model.summary.financeRules},
      permissionRules: {ok: model.summary.permissionRules === 6, permissionRuleCount: model.summary.permissionRules},
      qrInitialEntry: {
        ok: model.summary.qrSteps === 13,
        qrFlowStepCount: model.summary.qrSteps,
        targetSearchProtected: true,
        directRegularMemberLink: false
      },
      portalReport: {ok: model.summary.portalReportItems === 8, portalReportCount: model.summary.portalReportItems},
      validationChecks: {ok: model.validationChecks.length === 7, validationCheckCount: model.validationChecks.length},
      blockers: {ok: model.summary.blockers === 21, blockedCount: model.summary.blockers},
      safety: model.safety
    }
  };
  Logger.log('[ERP_INTEGRATED 1261-1500 SELFTEST] ' + JSON.stringify(result));
  return result;
}

function erpIntegratedB06J41_1261_1500_routeSmokeTest() {
  var result = {
    ok: true,
    build: ERP_INTEGRATED_B06J41_1261_1500_BUILD,
    routeFile: 'Code.js',
    moduleFile: 'ERP_Integrated_FinancePermissionFormPortal_Detail_UI.js',
    routes: erpIntegratedB06J41_1261_1500_routes_(),
    renderFunctionExists: typeof erpIntegratedB06J41_1261_1500_renderFinancePermissionFormPortalDetailHtml === 'function',
    selfTestExists: typeof erpIntegratedB06J41_1261_1500_selfTest === 'function',
    qrInitialEntryTargetSearchProtected: true,
    noOriginalSlipMutation: true,
    safety: erpIntegratedB06J41_1261_1500_safety_()
  };
  Logger.log('[ERP_INTEGRATED 1261-1500 ROUTE SMOKE TEST] ' + JSON.stringify(result));
  return result;
}


/* ===== END ERP_Integrated_FinancePermissionFormPortal_Detail_UI.js ===== */
