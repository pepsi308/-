/**
 * ERP_CORE_OPERATIONAL_DATA_OPEN_APPROVAL_SAFE
 * Operational data open approval gate. Safe: approval review only, no operational write.
 */
const ERP_OPERATIONAL_DATA_OPEN_APPROVAL_BUILD = 'ERP_CORE_OPERATIONAL_DATA_OPEN_APPROVAL_SAFE';
const ERP_OPERATIONAL_DATA_OPEN_APPROVAL_CODE = 'ERP_CORE_OPERATIONAL_DATA_OPEN_APPROVED_LIMITED_GATE_ONLY';

function erpOperationalDataOpenApproval_safety_() {
  return {
    build: ERP_OPERATIONAL_DATA_OPEN_APPROVAL_BUILD,
    approvalReviewOnly: true,
    readOnly: true,
    simulationOnly: true,
    deployAllowed: false,
    actualDeployExecution: false,
    noSheetCreate: true,
    noHeaderAutoAdd: true,
    noPolicyWrite: true,
    noDbInjection: true,
    noDeployExecution: true,
    noCustomerSave: true,
    noSaleSave: true,
    noContractCreate: true,
    noInstallAsSave: true,
    noSettlementExecution: true,
    noCancelSettlementConfirm: true,
    noSignDocumentCreate: true,
    noFormAutoRegister: true,
    noRoleMutation: true,
    noDeleteSheet: true,
    noExistingDataClear: true,
    limitedOperationalOpenGateOnly: true,
    headerMapRequired: true,
    idBasedConnectionRequired: true,
    vendorBranchUserGroup: true,
    qrInitialEntryTargetSearchProtected: true,
    directRegularMemberLink: false,
    noOriginalSlipMutation: true
  };
}

function erpOperationalDataOpenApproval_expected_() {
  return {
    requiredPrechecks: [
      'ERP_CORE structure created',
      'HeaderPolicy 67 confirmed',
      'SheetPolicy 6 confirmed',
      'CONTROL sync check PASS',
      'Save pipeline simulation PASS',
      'TEST record save PASS',
      'CONTROL final gate PASS',
      'DeployLog safe execution recorded',
      'Webapp UI smoke PASS',
      'Route blank hotfix PASS'
    ],
    limitedOpenScope: [
      'limited operational save review only',
      'HQ/admin approved tester only',
      'no settlement execution',
      'no SIGN/FORM auto creation',
      'no role mutation',
      'no deploy execution'
    ]
  };
}

function erpOperationalDataOpenApproval_dryRun(ctx) {
  ctx = ctx || {};
  return {
    ok: true,
    build: ERP_OPERATIONAL_DATA_OPEN_APPROVAL_BUILD,
    mode: 'DRY_RUN_ONLY',
    message: '운영 데이터 저장 오픈 승인 전 게이트 계획만 확인합니다. 실제 저장/배포/권한변경은 없습니다.',
    expected: erpOperationalDataOpenApproval_expected_(),
    fatal: [],
    warnings: [],
    operationalDataOpenReady: false,
    actualOperationalDataWrite: false,
    deployAllowed: false,
    safety: erpOperationalDataOpenApproval_safety_(),
    ctx: ctx
  };
}

function erpOperationalDataOpenApproval_blockedTest(ctx) {
  ctx = ctx || {};
  return erpOperationalDataOpenApproval_execute({
    openConfirm: false,
    approvalCode: '',
    limitedOperationalOpenOnly: true,
    actualOperationalDataWrite: false,
    deployAllowed: false,
    runner: ctx.runner || 'runStep2_BlockedOperationalDataOpenApprovalTest'
  });
}

function erpOperationalDataOpenApproval_checkGuard_(ctx) {
  ctx = ctx || {};
  const required = {
    openConfirm: true,
    approvalCode: ERP_OPERATIONAL_DATA_OPEN_APPROVAL_CODE,
    limitedOperationalOpenOnly: true,
    actualOperationalDataWrite: false,
    deployAllowed: false
  };
  if (ctx.openConfirm !== true) {
    return { ok: false, reason: 'openConfirm=true 승인이 없습니다.', required: required };
  }
  if (ctx.approvalCode !== ERP_OPERATIONAL_DATA_OPEN_APPROVAL_CODE) {
    return { ok: false, reason: '승인코드가 일치하지 않습니다.', required: required };
  }
  if (ctx.limitedOperationalOpenOnly !== true) {
    return { ok: false, reason: 'limitedOperationalOpenOnly=true 조건이 필요합니다.', required: required };
  }
  if (ctx.actualOperationalDataWrite !== false) {
    return { ok: false, reason: 'actualOperationalDataWrite=false 조건이 필요합니다.', required: required };
  }
  if (ctx.deployAllowed !== false) {
    return { ok: false, reason: 'deployAllowed=false 조건이 필요합니다.', required: required };
  }
  return { ok: true, required: required };
}

function erpOperationalDataOpenApproval_execute(ctx) {
  ctx = ctx || {};
  const guard = erpOperationalDataOpenApproval_checkGuard_(ctx);
  if (!guard.ok) {
    return {
      ok: false,
      blocked: true,
      build: ERP_OPERATIONAL_DATA_OPEN_APPROVAL_BUILD,
      action: 'OPERATIONAL_DATA_OPEN_APPROVAL_GATE_ONLY',
      reason: guard.reason,
      required: guard.required,
      safety: erpOperationalDataOpenApproval_safety_()
    };
  }
  return {
    ok: true,
    build: ERP_OPERATIONAL_DATA_OPEN_APPROVAL_BUILD,
    action: 'OPERATIONAL_DATA_OPEN_APPROVAL_GATE_ONLY',
    checkedAt: new Date().toISOString(),
    operationalDataOpenReviewReady: true,
    limitedOperationalOpenOnly: true,
    actualOperationalDataWrite: false,
    deployAllowed: false,
    fatal: [],
    warnings: [],
    allowedNextStep: 'ERP_CORE_LIMITED_OPERATIONAL_SAVE_GATE_SAFE',
    deniedActions: [
      'actualCustomerSave',
      'actualSaleSave',
      'actualContractCreate',
      'actualInstallAsSave',
      'actualSettlementExecution',
      'actualSignDocumentCreate',
      'actualFormAutoRegister',
      'actualRoleMutation',
      'actualDeployExecution'
    ],
    safety: erpOperationalDataOpenApproval_safety_()
  };
}

function erpOperationalDataOpenApproval_selfTest() {
  const safety = erpOperationalDataOpenApproval_safety_();
  const fatal = [];
  if (safety.actualDeployExecution !== false) fatal.push('actualDeployExecution must be false');
  if (safety.noSaleSave !== true) fatal.push('noSaleSave must be true');
  if (safety.limitedOperationalOpenGateOnly !== true) fatal.push('limitedOperationalOpenGateOnly must be true');
  if (ERP_OPERATIONAL_DATA_OPEN_APPROVAL_CODE.indexOf('APPROVED') < 0) fatal.push('approval code missing APPROVED marker');
  return {
    ok: fatal.length === 0,
    build: ERP_OPERATIONAL_DATA_OPEN_APPROVAL_BUILD,
    mode: 'SELFTEST',
    fatal: fatal,
    warnings: [],
    expected: erpOperationalDataOpenApproval_expected_(),
    safety: safety
  };
}
