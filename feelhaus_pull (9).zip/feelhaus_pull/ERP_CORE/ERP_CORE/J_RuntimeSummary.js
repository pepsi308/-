/**
 * FEELHAUS ERP Runtime Gate Summary V21
 * Quiet summary runner: avoids the very large full JSON Logger output from runErpPrebuildRuntimeGateV7().
 * Depends on J_RuntimeV7.js helper functions.
 */
function runErpPrebuildRuntimeGateV7Summary() {
  var result = erpRuntimeSummaryV21_runQuietRuntimeGate_({ sandboxAuditWrite: false });
  var summary = erpRuntimeSummaryV21_fromResult_(result);
  Logger.log(JSON.stringify(summary, null, 2));
  return summary;
}

function runErpPrebuildRuntimeGateV7QuietResult() {
  var result = erpRuntimeSummaryV21_runQuietRuntimeGate_({ sandboxAuditWrite: false });
  return erpRuntimeSummaryV21_fromResult_(result);
}

function erpRuntimeSummaryV21_runQuietRuntimeGate_(options) {
  options = options || {};
  var result = {
    ok: true,
    build: typeof ERP_PREBUILD_GATE_V7_BUILD_NAME !== 'undefined' ? ERP_PREBUILD_GATE_V7_BUILD_NAME : 'ERP_PREBUILD_RUNTIME_GATE_V7',
    checkedAt: new Date().toISOString(),
    actualAppsScriptRuntime: true,
    buildAllowed: false,
    mode: options.sandboxAuditWrite ? 'SANDBOX_AUDIT_WRITE' : 'READ_ONLY',
    requiredSaveOrder: ['requiredValueCheck','formatCheck','permissionCheck','duplicateCheck','stateTransitionCheck','save','auditLog'],
    checks: [],
    fatal: [],
    warnings: [],
    protectedDomains: ['event','vendor','customer','sale','contract','install','as','settlement'],
    nextAction: ''
  };

  function add(name, ok, detail, severity) {
    var sev = severity || (ok ? 'PASS' : 'FATAL');
    var safeDetail = typeof erpPrebuildGateV7_safeDetail_ === 'function'
      ? erpPrebuildGateV7_safeDetail_(detail || {})
      : (detail || {});
    var row = { name: name, ok: !!ok, severity: sev, detail: safeDetail };
    result.checks.push(row);
    if (!ok) {
      result.ok = false;
      if (sev === 'WARN') result.warnings.push(name);
      else result.fatal.push(name);
    }
    return row;
  }

  try {
    var config = erpPrebuildGateV7_readSystemConfig_();
    add('SystemConfig 자동 읽기', config.ok, config);

    var master = config.ok ? erpPrebuildGateV7_openMaster_(config.configMap) : { ok:false, message:'SystemConfig 실패로 MASTER 연결 생략' };
    add('FEELHAUS_DB_MASTER 자동 연결', master.ok, master);

    if (master.ok && master.spreadsheet) {
      var sheetResult = erpPrebuildGateV7_checkBusinessSheets_(master.spreadsheet);
      add('고객/행사/판매/계약/설치/A/S/정산 화면 원장 및 필수 헤더 점검', sheetResult.ok, sheetResult);

      var perm = erpPrebuildGateV7_checkPermissionStructure_(master.spreadsheet);
      add('권한 구조 점검(roleCode/vendorId/eventId)', perm.ok, perm);

      var status = erpPrebuildGateV7_checkStatusTransitionStructure_(master.spreadsheet);
      add('상태전이 구조 점검', status.ok, status);

      var audit = erpPrebuildGateV7_checkAuditStructure_(master.spreadsheet);
      add('감사로그 구조 점검', audit.ok, audit);

      var settlement = erpPrebuildGateV7_checkSettlementProtection_(master.spreadsheet);
      add('정산/취소정산/환수/추가지급 보호 구조 점검', settlement.ok, settlement);

      var saveOrder = erpPrebuildGateV7_checkSaveOrderPolicy_();
      add('저장 순서 보호 기준 점검', saveOrder.ok, saveOrder);

      if (options.sandboxAuditWrite) {
        var sandbox = erpPrebuildGateV7_writeSandboxAudit_(master.spreadsheet);
        add('샌드박스 감사로그 기록 테스트', sandbox.ok, sandbox);
      } else {
        result.warnings.push('샌드박스 감사로그 기록 테스트는 미실행: runErpPrebuildRuntimeGateV7SandboxAuditWrite() 별도 승인 후 실행');
      }
    }

    result.buildAllowed = result.ok && result.fatal.length === 0;
    result.nextAction = result.buildAllowed
      ? 'CONTROL 최종 게이트 후 배포 빌드파일 생성 가능'
      : '빌드 중지: fatal 항목 수정 후 V7 런타임 게이트 재실행';
  } catch (e) {
    result.ok = false;
    result.buildAllowed = false;
    result.fatal.push(e && e.message ? e.message : String(e));
    result.nextAction = '오류 수정 후 재실행';
  }

  return result;
}

function erpRuntimeSummaryV21_fromResult_(result) {
  var summary = {
    ok: result && result.ok === true,
    build: result && result.build,
    checkedAt: result && result.checkedAt,
    buildAllowed: result && result.buildAllowed === true,
    mode: result && result.mode,
    requiredSaveOrder: result && result.requiredSaveOrder,
    fatalChecks: [],
    failedChecks: [],
    fatal: result && result.fatal ? result.fatal : [],
    warnings: result && result.warnings ? result.warnings : [],
    nextAction: result && result.nextAction
  };
  var checks = (result && result.checks) || [];
  for (var i = 0; i < checks.length; i++) {
    var c = checks[i] || {};
    if (c.ok === true && c.severity !== 'FATAL') continue;
    var item = erpRuntimeSummaryV21_summarizeCheck_(c);
    summary.failedChecks.push(item);
    if (c.severity === 'FATAL') summary.fatalChecks.push(item);
  }
  return summary;
}

function erpRuntimeSummaryV21_summarizeCheck_(check) {
  var d = check.detail || {};
  var item = {
    name: check.name || '',
    ok: check.ok === true,
    severity: check.severity || '',
    selectedSheet: d.selectedSheet || '',
    missingSheet: d.missingSheet === true,
    candidates: d.candidates || [],
    missingHeaders: d.missingHeaders || [],
    duplicateHeaders: d.duplicateHeaders || [],
    failedDomains: d.failedDomains || [],
    message: d.message || '',
    requiredPurpose: d.requiredPurpose || '',
    missingSettlementProtectionEvidence: d.missingSettlementProtectionEvidence || [],
    settlementProtectionHeadersFound: d.settlementProtectionHeadersFound || [],
    sheets: []
  };

  if (Array.isArray(d.fatal)) item.fatal = d.fatal;

  if (Array.isArray(d.sheets)) {
    for (var s = 0; s < d.sheets.length; s++) {
      var sh = d.sheets[s] || {};
      if (sh.ok === true) continue;
      item.sheets.push({
        domain: sh.domain || '',
        selectedSheet: sh.selectedSheet || '',
        missingSheet: sh.missingSheet === true,
        candidates: sh.candidates || [],
        missingHeaders: sh.missingHeaders || [],
        duplicateHeaders: sh.duplicateHeaders || [],
        missingSettlementProtectionEvidence: sh.missingSettlementProtectionEvidence || []
      });
    }
  }

  item.actionHint = erpRuntimeSummaryV21_actionHint_(item);
  return item;
}

function erpRuntimeSummaryV21_actionHint_(item) {
  if (item.missingSheet) {
    return '후보 시트 중 하나를 생성하고 필수 헤더를 1행에 추가하세요. 권장 시트명: ' + (item.candidates[0] || '');
  }
  if (item.missingHeaders && item.missingHeaders.length) {
    return '선택된 시트 1행에 누락 헤더를 추가하세요: ' + item.missingHeaders.join(', ');
  }
  if (item.duplicateHeaders && item.duplicateHeaders.length) {
    return '선택된 시트 1행의 중복 헤더를 정리하세요: ' + item.duplicateHeaders.join(', ');
  }
  if (item.missingSettlementProtectionEvidence && item.missingSettlementProtectionEvidence.length) {
    return '정산 보호 근거 헤더를 최소 3개 이상 추가하세요: ' + item.missingSettlementProtectionEvidence.join(', ');
  }
  return '세부 원인은 selectedSheet, missingSheet, missingHeaders, duplicateHeaders 값을 확인하세요.';
}
