@echo off
setlocal EnableExtensions
title FEELHAUS DOWNLOAD ERP_CORE

if not exist "D:\pepsi308\OneDrive\feelhaus_pull\ERP_CORE" mkdir "D:\pepsi308\OneDrive\feelhaus_pull\ERP_CORE"
cd /d D:\pepsi308\OneDrive\feelhaus_pull\ERP_CORE

if exist ".clasp.json" (
  echo [ERP_CORE] clasp pull
  clasp.cmd pull
) else (
  echo [ERP_CORE] clasp clone
  clasp.cmd clone 1qFqtAErjdwcXm1FT7G89lArBrS1ZEC1ZmOLkP62G9h8fWMezzNbkxxLf
)

pause
