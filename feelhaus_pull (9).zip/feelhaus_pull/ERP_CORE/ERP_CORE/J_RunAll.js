/**
 * FEELHAUS ERP CORE V24
 * One-click compact final gate runner.
 * READ ONLY: does not open real save/write mode.
 */
function runErpCoreFinalGateAll() {
  var result = {
    ok: false,
    build: 'ERP_CORE_FINAL_GATE_ALL_V37',
    checkedAt: new Date().toISOString(),
    mode: 'ONE_CLICK_COMPACT_GATE_WITH_SALES_AND_CONTRACT_SIGN_PREP_V37',
    steps: [],
    fatal: [],
    warnings: [],
    buildAllowed: false,
    operationReady: false,
    limitedOpenReady: false,
    nextAction: ''
  };

  function requireFunction(fnName) {
    var fn = this[fnName];
    if (typeof fn !== 'function') throw new Error('필수 함수 없음: ' + fnName);
    return fn;
  }

  function uniqPush(list, values) {
    values = values || [];
    for (var i = 0; i < values.length; i++) {
      if (list.indexOf(values[i]) < 0) list.push(values[i]);
    }
  }

  function pushStep(name, fnName, data, options) {
    options = options || {};
    var fatalChecks = data && data.fatalChecks ? data.fatalChecks : [];
    var failedChecks = data && data.failedChecks ? data.failedChecks : [];
    var fatal = data && data.fatal ? data.fatal : [];
    var warnings = data && data.warnings ? data.warnings : [];
    var ok = data && data.ok === true;
    var step = {
      name: name,
      functionName: fnName,
      ok: ok,
      buildAllowed: data && data.buildAllowed === true,
      operationReady: data && (data.operationReady === true || data.ok === true && name === 'operationReadiness'),
      limitedOpenReady: data && (data.limitedOpenReady === true || data.ok === true && name === 'limitedOpenReadiness'),
      fatalChecksCount: fatalChecks.length,
      failedChecksCount: failedChecks.length,
      fatalCount: fatal.length,
      warningCount: warnings.length
    };
    result.steps.push(step);
    if (!ok && options.fatalOnFail !== false) result.fatal.push(name + ' failed');
    if (fatalChecks.length) result.fatal.push(name + ' fatalChecks: ' + fatalChecks.length);
    if (failedChecks.length) result.fatal.push(name + ' failedChecks: ' + failedChecks.length);
    uniqPush(result.fatal, fatal);
    uniqPush(result.warnings, warnings);
    return data;
  }

  try {
    var summary1 = requireFunction('runErpPrebuildRuntimeGateV7Summary')();
    pushStep('preSummaryBefore', 'runErpPrebuildRuntimeGateV7Summary', summary1);

    var controlDry = requireFunction('runErpControlLogPrepV17DryRun')();
    pushStep('controlLogPrepDryRun', 'runErpControlLogPrepV17DryRun', controlDry, { fatalOnFail: false });

    var controlApply = requireFunction('runErpControlLogPrepV17Apply')();
    pushStep('controlLogPrepApply', 'runErpControlLogPrepV17Apply', controlApply, { fatalOnFail: false });

    var salesSchemaDry = requireFunction('runErpCoreSalesSchemaPrepV31DryRun')();
    pushStep('salesSchemaPrepDryRun', 'runErpCoreSalesSchemaPrepV31DryRun', salesSchemaDry, { fatalOnFail: false });

    var salesSchemaApply = requireFunction('runErpCoreSalesSchemaPrepV31Apply')();
    pushStep('salesSchemaPrepApply', 'runErpCoreSalesSchemaPrepV31Apply', salesSchemaApply);

    var contractSignDry = requireFunction('runErpCoreContractSignPrepV37DryRun')();
    pushStep('contractSignPrepDryRun', 'runErpCoreContractSignPrepV37DryRun', contractSignDry, { fatalOnFail: false });

    var contractSignApply = requireFunction('runErpCoreContractSignPrepV37Apply')();
    pushStep('contractSignPrepApply', 'runErpCoreContractSignPrepV37Apply', contractSignApply);

    var operationReady = requireFunction('runErpCoreOperationReadinessV22')();
    pushStep('operationReadiness', 'runErpCoreOperationReadinessV22', operationReady);

    var limitedOpen = requireFunction('runErpCoreLimitedOpenV23')();
    pushStep('limitedOpenReadiness', 'runErpCoreLimitedOpenV23', limitedOpen);

    var summary2 = requireFunction('runErpPrebuildRuntimeGateV7Summary')();
    pushStep('preSummaryAfter', 'runErpPrebuildRuntimeGateV7Summary', summary2);

    result.buildAllowed = !!(summary2 && summary2.buildAllowed === true && (summary2.fatalChecks || []).length === 0 && (summary2.failedChecks || []).length === 0 && result.fatal.length === 0);
    result.operationReady = !!(operationReady && operationReady.ok === true && result.buildAllowed);
    result.limitedOpenReady = !!(limitedOpen && limitedOpen.ok === true && result.operationReady);
    result.ok = result.limitedOpenReady;
    result.nextAction = result.ok
      ? 'ERP_계약관리 필수 헤더 보정 완료. FIELD V37/V38 contractPrecheck READ ONLY smoke 재실행'
      : 'fatal/failedChecks 확인 후 재실행 필요';
  } catch (err) {
    result.ok = false;
    result.buildAllowed = false;
    result.operationReady = false;
    result.limitedOpenReady = false;
    result.fatal.push(err && err.message ? err.message : String(err));
    result.nextAction = '오류 수정 후 runErpCoreFinalGateAll 재실행';
  }

  var compact = {
    ok: result.ok,
    build: result.build,
    checkedAt: result.checkedAt,
    buildAllowed: result.buildAllowed,
    operationReady: result.operationReady,
    limitedOpenReady: result.limitedOpenReady,
    fatal: result.fatal,
    warnings: result.warnings,
    steps: result.steps,
    nextAction: result.nextAction
  };
  Logger.log(JSON.stringify(compact, null, 2));
  return compact;
}
