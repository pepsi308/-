/**
 * FEELHAUS ERP PREBUILD RUNTIME GATE V7
 * Purpose: final release gate before ERP build-file creation.
 * Default mode is READ_ONLY. It does not save business data and does not deploy.
 * Protected save order:
 * requiredValueCheck -> formatCheck -> permissionCheck -> duplicateCheck -> stateTransitionCheck -> save -> auditLog
 */
var ERP_PREBUILD_GATE_V7_SETUP_DB_ID = '17VMSpgSZCvIrUlgcw8yCNcnl8WQWo2IcRf5tDCcuJGM';
var ERP_PREBUILD_GATE_V7_CONFIG_SHEET_NAME = 'SystemConfig';
var ERP_PREBUILD_GATE_V7_BUILD_NAME = 'ERP_PREBUILD_RUNTIME_GATE_V7';

function runErpPrebuildRuntimeGateV7() {
  return erpPrebuildGateV7_run_({ sandboxAuditWrite: false });
}

function runErpPrebuildRuntimeGateV7SandboxAuditWrite() {
  return erpPrebuildGateV7_run_({ sandboxAuditWrite: true });
}

function erpPrebuildGateV7_run_(options) {
  options = options || {};
  var result = {
    ok: true,
    build: ERP_PREBUILD_GATE_V7_BUILD_NAME,
    checkedAt: new Date().toISOString(),
    actualAppsScriptRuntime: true,
    buildAllowed: false,
    mode: options.sandboxAuditWrite ? 'SANDBOX_AUDIT_WRITE' : 'READ_ONLY',
    requiredSaveOrder: ['requiredValueCheck','formatCheck','permissionCheck','duplicateCheck','stateTransitionCheck','save','auditLog'],
    checks: [],
    fatal: [],
    warnings: [],
    protectedDomains: ['event','vendor','customer','sale','contract','install','as','settlement'],
    nextAction: ''
  };
  function add(name, ok, detail, severity) {
    var sev = severity || (ok ? 'PASS' : 'FATAL');
    var row = { name: name, ok: !!ok, severity: sev, detail: erpPrebuildGateV7_safeDetail_(detail || {}) };
    result.checks.push(row);
    if (!ok) {
      result.ok = false;
      if (sev === 'WARN') result.warnings.push(name);
      else result.fatal.push(name);
    }
    return row;
  }

  var config = erpPrebuildGateV7_readSystemConfig_();
  add('SystemConfig 자동 읽기', config.ok, config);

  var master = config.ok ? erpPrebuildGateV7_openMaster_(config.configMap) : { ok:false, message:'SystemConfig 실패로 MASTER 연결 생략' };
  add('FEELHAUS_DB_MASTER 자동 연결', master.ok, master);

  if (master.ok && master.spreadsheet) {
    var sheetResult = erpPrebuildGateV7_checkBusinessSheets_(master.spreadsheet);
    add('고객/행사/판매/계약/설치/A/S/정산 화면 원장 및 필수 헤더 점검', sheetResult.ok, sheetResult);

    var perm = erpPrebuildGateV7_checkPermissionStructure_(master.spreadsheet);
    add('권한 구조 점검(roleCode/vendorId/eventId)', perm.ok, perm);

    var status = erpPrebuildGateV7_checkStatusTransitionStructure_(master.spreadsheet);
    add('상태전이 구조 점검', status.ok, status);

    var audit = erpPrebuildGateV7_checkAuditStructure_(master.spreadsheet);
    add('감사로그 구조 점검', audit.ok, audit);

    var settlement = erpPrebuildGateV7_checkSettlementProtection_(master.spreadsheet);
    add('정산/취소정산/환수/추가지급 보호 구조 점검', settlement.ok, settlement);

    var saveOrder = erpPrebuildGateV7_checkSaveOrderPolicy_();
    add('저장 순서 보호 기준 점검', saveOrder.ok, saveOrder);

    if (options.sandboxAuditWrite) {
      var sandbox = erpPrebuildGateV7_writeSandboxAudit_(master.spreadsheet);
      add('샌드박스 감사로그 기록 테스트', sandbox.ok, sandbox);
    } else {
      result.warnings.push('샌드박스 감사로그 기록 테스트는 미실행: runErpPrebuildRuntimeGateV7SandboxAuditWrite() 별도 승인 후 실행');
    }
  }

  result.buildAllowed = result.ok && result.fatal.length === 0;
  result.nextAction = result.buildAllowed
    ? 'CONTROL 최종 게이트 후 배포 빌드파일 생성 가능'
    : '빌드 중지: fatal 항목 수정 후 V7 런타임 게이트 재실행';
  Logger.log(JSON.stringify(result, null, 2));
  return result;
}

function erpPrebuildGateV7_readSystemConfig_() {
  var out = { ok:true, setupDbId:ERP_PREBUILD_GATE_V7_SETUP_DB_ID, configSheetName:ERP_PREBUILD_GATE_V7_CONFIG_SHEET_NAME, keyCount:0, configMap:{}, fatal:[] };
  try {
    var setup = SpreadsheetApp.openById(ERP_PREBUILD_GATE_V7_SETUP_DB_ID);
    var sh = setup.getSheetByName(ERP_PREBUILD_GATE_V7_CONFIG_SHEET_NAME);
    if (!sh) return erpPrebuildGateV7_fail_(out, 'SystemConfig 시트 없음');
    var values = sh.getDataRange().getValues();
    if (!values || values.length < 2) return erpPrebuildGateV7_fail_(out, 'SystemConfig 데이터 없음');
    var headers = values[0].map(function(v){ return String(v || '').trim().toLowerCase(); });
    var keyCol = erpPrebuildGateV7_firstIndex_(headers, ['config_key','key','name','configkey']);
    var valCol = erpPrebuildGateV7_firstIndex_(headers, ['value','config_value','configvalue','val']);
    if (keyCol < 0) keyCol = 0;
    if (valCol < 0) valCol = 1;
    for (var r = 1; r < values.length; r++) {
      var k = String(values[r][keyCol] || '').trim();
      if (!k) continue;
      out.configMap[k] = String(values[r][valCol] || '').trim();
    }
    out.keyCount = Object.keys(out.configMap).length;
    if (!out.keyCount) return erpPrebuildGateV7_fail_(out, 'SystemConfig 키 없음');
    return out;
  } catch (e) {
    return erpPrebuildGateV7_fail_(out, 'SystemConfig 읽기 예외: ' + erpPrebuildGateV7_err_(e));
  }
}

function erpPrebuildGateV7_openMaster_(configMap) {
  var keys = ['FEELHAUS_DB_MASTER_ID','FEELHAUS_DB_MASTER','MASTER_SPREADSHEET_ID','MASTER_DB_ID','DB_MASTER_ID','SPREADSHEET_ID'];
  var id = '';
  for (var i = 0; i < keys.length; i++) {
    if (configMap[keys[i]]) { id = configMap[keys[i]]; break; }
  }
  if (!id) return { ok:false, triedKeys:keys, message:'FEELHAUS_DB_MASTER ID 설정 없음' };
  try {
    var ss = SpreadsheetApp.openById(id);
    return { ok:true, masterId:id, spreadsheetName:ss.getName(), spreadsheet:ss };
  } catch (e) {
    return { ok:false, masterId:id, message:'MASTER 열기 예외: ' + erpPrebuildGateV7_err_(e) };
  }
}

function erpPrebuildGateV7_checkBusinessSheets_(ss) {
  var specs = [
    { domain:'행사', candidates:['ERP_행사관리','EVENT_MASTER','Events'], required:['eventId','vendorId','status','createdAt','createdBy','updatedAt','updatedBy'] },
    { domain:'업체', candidates:['ERP_업체관리','VENDOR_MASTER','Vendors'], required:['vendorId','status','createdAt','createdBy','updatedAt','updatedBy'] },
    { domain:'고객', candidates:['ERP_고객관리','CUSTOMER_MASTER','Customers'], required:['eventId','vendorId','customerId','status','createdAt','createdBy','updatedAt','updatedBy'] },
    { domain:'판매', candidates:['ERP_판매관리','ERP_Sales','SALES_MASTER','Sales'], required:['eventId','vendorId','customerId','saleId','status','statusReason','createdAt','createdBy','updatedAt','updatedBy'] },
    { domain:'계약', candidates:['ERP_계약관리','ERP_Contracts','CONTRACT_MASTER','Contracts'], required:['eventId','vendorId','customerId','saleId','contractId','status','statusReason','createdAt','createdBy','updatedAt','updatedBy'] },
    { domain:'설치', candidates:['ERP_설치관리','ERP_Install','INSTALL_MASTER','Installs'], required:['eventId','vendorId','customerId','saleId','contractId','installId','status','statusReason','createdAt','createdBy','updatedAt','updatedBy'] },
    { domain:'A/S', candidates:['ERP_AS관리','ERP_A/S관리','ERP_Service','AS_MASTER'], required:['eventId','vendorId','customerId','saleId','asId','status','statusReason','createdAt','createdBy','updatedAt','updatedBy'] },
    { domain:'정산', candidates:['ERP_정산관리','ERP_Settlement','SETTLEMENT_MASTER','Settlements'], required:['eventId','vendorId','customerId','saleId','contractId','settlementId','status','statusReason','createdAt','createdBy','updatedAt','updatedBy'] }
  ];
  var out = { ok:true, sheets:[], failedDomains:[] };
  specs.forEach(function(spec){
    var row = erpPrebuildGateV7_checkSheetCandidate_(ss, spec.candidates, spec.required);
    row.domain = spec.domain;
    out.sheets.push(row);
    if (!row.ok) { out.ok = false; out.failedDomains.push(spec.domain); }
  });
  return out;
}

function erpPrebuildGateV7_checkPermissionStructure_(ss) {
  var candidates = ['ERP_권한관리','ERP_Permission','ERP_UserPermission','UserPermissions','ERP_사용자권한'];
  var required = ['roleCode','vendorId','eventId','status'];
  var row = erpPrebuildGateV7_checkSheetCandidate_(ss, candidates, required);
  row.requiredPurpose = '본사/업체/직원 화면과 데이터 분리';
  return row;
}

function erpPrebuildGateV7_checkStatusTransitionStructure_(ss) {
  var candidates = ['ERP_상태전이정책','ERP_StatusTransition','StatusTransition','ERP_StatusPolicy','StatusPolicy'];
  var required = ['fromStatus','toStatus','roleCode','approvalRequired','status'];
  var row = erpPrebuildGateV7_checkSheetCandidate_(ss, candidates, required);
  row.requiredPurpose = '자유입력 금지, 허용 전이, 재오픈/예외 승인 기반 처리';
  return row;
}

function erpPrebuildGateV7_checkAuditStructure_(ss) {
  var candidates = ['ERP_CoreLog','ERP_AuditLog','ERP_감사로그','AUDIT_LOG','ERP_LOG'];
  var required = ['logId','action','createdAt','createdBy'];
  var row = erpPrebuildGateV7_checkSheetCandidate_(ss, candidates, required);
  row.requiredPurpose = '권한 변경과 중요 작업 감사추적';
  return row;
}

function erpPrebuildGateV7_checkSettlementProtection_(ss) {
  var candidates = ['ERP_정산관리','ERP_Settlement','SETTLEMENT_MASTER','Settlements'];
  var required = ['settlementId','saleId','vendorId','customerId','status','statusReason'];
  var recommendedAny = ['cancelSettlementId','correctionSaleId','recoveryAmount','additionalPaymentAmount','feelhausBurdenAmount','originalSaleId','paymentId','approvalId'];
  var row = erpPrebuildGateV7_checkSheetCandidate_(ss, candidates, required);
  if (row.ok) {
    var headers = row.headers || [];
    var foundRecommended = recommendedAny.filter(function(h){ return headers.indexOf(h) >= 0; });
    row.settlementProtectionHeadersFound = foundRecommended;
    row.noOriginalSlipMutationRequired = true;
    row.cancelCorrectionSlipRequired = true;
    row.recoveryOrAdditionalPaymentSlipRequired = true;
    if (foundRecommended.length < 3) {
      row.ok = false;
      row.missingSettlementProtectionEvidence = recommendedAny.filter(function(h){ return headers.indexOf(h) < 0; });
    }
  }
  return row;
}

function erpPrebuildGateV7_checkSaveOrderPolicy_() {
  return {
    ok:true,
    order:['requiredValueCheck','formatCheck','permissionCheck','duplicateCheck','stateTransitionCheck','save','auditLog'],
    koreanOrder:'필수값 -> 형식 -> 권한 -> 중복 -> 상태전이 -> 저장 -> 로그',
    businessSaveExecuted:false,
    policy:'순서 우회 또는 상태전이 누락 시 빌드 중지'
  };
}

function erpPrebuildGateV7_writeSandboxAudit_(ss) {
  try {
    var name = 'ERP_RuntimeGateLog';
    var sh = ss.getSheetByName(name);
    if (!sh) sh = ss.insertSheet(name);
    var headers = ['logId','action','status','createdAt','createdBy','detail'];
    if (sh.getLastRow() < 1 || sh.getLastColumn() < headers.length) {
      sh.getRange(1, 1, 1, headers.length).setValues([headers]);
    }
    var logId = 'RUNTIME_GATE_' + Utilities.formatDate(new Date(), Session.getScriptTimeZone(), 'yyyyMMdd_HHmmss');
    sh.appendRow([logId, 'PREBUILD_RUNTIME_GATE_V7', 'PASS', new Date(), Session.getActiveUser().getEmail(), 'non-business sandbox audit write']);
    return { ok:true, sheetName:name, logId:logId, businessDataSaved:false };
  } catch (e) {
    return { ok:false, message:'샌드박스 감사로그 기록 실패: ' + erpPrebuildGateV7_err_(e) };
  }
}

function erpPrebuildGateV7_checkSheetCandidate_(ss, candidates, requiredHeaders) {
  var row = { ok:false, candidates:candidates, selectedSheet:'', missingSheet:false, missingHeaders:[], duplicateHeaders:[], headers:[] };
  var sh = null;
  for (var i = 0; i < candidates.length; i++) {
    sh = ss.getSheetByName(candidates[i]);
    if (sh) { row.selectedSheet = candidates[i]; break; }
  }
  if (!sh) { row.missingSheet = true; row.missingHeaders = requiredHeaders.slice(); return row; }
  var lastCol = Math.max(sh.getLastColumn(), 1);
  var headers = sh.getRange(1, 1, 1, lastCol).getValues()[0].map(function(v){ return String(v || '').trim(); });
  var seen = {};
  headers.forEach(function(h){ if (!h) return; if (seen[h]) row.duplicateHeaders.push(h); seen[h] = true; });
  requiredHeaders.forEach(function(h){ if (!seen[h]) row.missingHeaders.push(h); });
  row.headers = headers;
  row.lastRow = sh.getLastRow();
  row.lastCol = sh.getLastColumn();
  row.ok = row.missingHeaders.length === 0 && row.duplicateHeaders.length === 0;
  return row;
}

function erpPrebuildGateV7_firstIndex_(arr, names) {
  for (var i = 0; i < names.length; i++) {
    var idx = arr.indexOf(names[i]);
    if (idx >= 0) return idx;
  }
  return -1;
}

function erpPrebuildGateV7_fail_(out, msg) {
  out.ok = false;
  out.fatal = out.fatal || [];
  out.fatal.push(msg);
  return out;
}

function erpPrebuildGateV7_err_(e) {
  return e && e.message ? e.message : String(e);
}

function erpPrebuildGateV7_safeDetail_(detail) {
  var copy = {};
  for (var k in detail) {
    if (!Object.prototype.hasOwnProperty.call(detail, k)) continue;
    if (k === 'spreadsheet' || k === 'ss') continue;
    if (k === 'configMap') {
      copy.keyCount = Object.keys(detail.configMap || {}).length;
      copy.configKeys = Object.keys(detail.configMap || {});
      continue;
    }
    copy[k] = detail[k];
  }
  return copy;
}
