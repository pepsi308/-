/**
 * ERP_CORE_POST_WEBAPP_DEPLOY_UI_SMOKE_SAFE
 * Purpose: Post webapp deploy UI smoke checklist/report for ERP_CORE.
 * Safety: No writes, no deploy, no URL mutation, no business data changes.
 */

var ERP_CORE_POST_WEBAPP_DEPLOY_UI_SMOKE_SAFE_BUILD = 'ERP_CORE_POST_WEBAPP_DEPLOY_UI_SMOKE_SAFE';

function erpCorePostWebappDeployUiSmoke_safety_() {
  return {
    build: ERP_CORE_POST_WEBAPP_DEPLOY_UI_SMOKE_SAFE_BUILD,
    readOnly: true,
    manualUiCheckRequired: true,
    simulationOnly: true,
    noSheetCreate: true,
    noHeaderAutoAdd: true,
    noPolicyWrite: true,
    noDbInjection: true,
    noDeployExecution: true,
    deployAllowedMutation: false,
    actualDeployExecution: false,
    operationalUrlMutation: false,
    versionSwitch: false,
    noBusinessDataWrite: true,
    noCustomerSave: true,
    noSaleSave: true,
    noContractCreate: true,
    noInstallAsSave: true,
    noSettlementExecution: true,
    noCancelSettlementConfirm: true,
    noSignDocumentCreate: true,
    noFormAutoRegister: true,
    noRoleMutation: true,
    noDeleteSheet: true,
    noExistingDataClear: true,
    headerMapRequired: true,
    idBasedConnectionRequired: true,
    vendorBranchUserGroup: true,
    qrInitialEntryTargetSearchProtected: true,
    directRegularMemberLink: false,
    noOriginalSlipMutation: true
  };
}

function erpCorePostWebappDeployUiSmoke_expectedRoutes_() {
  return [
    { route: 'ERP_HOME', label: 'ERP 홈', requiredRole: 'HQ_OR_VENDOR', manualCheck: '웹앱 URL 접속 시 홈이 열리는지 확인' },
    { route: 'ERP_SALES', label: '판매관리', requiredRole: 'SALES_OR_HQ', manualCheck: '판매관리 메뉴 클릭 시 빈 화면 없이 진입되는지 확인' },
    { route: 'ERP_CONTRACTS', label: '계약관리', requiredRole: 'SALES_OR_HQ', manualCheck: '계약관리 메뉴 클릭 시 빈 화면 없이 진입되는지 확인' },
    { route: 'ERP_INSTALLS', label: '설치관리', requiredRole: 'INSTALL_OR_HQ', manualCheck: '설치관리 메뉴 클릭 시 빈 화면 없이 진입되는지 확인' },
    { route: 'ERP_AS', label: 'A/S관리', requiredRole: 'AS_OR_HQ', manualCheck: 'A/S관리 메뉴 클릭 시 빈 화면 없이 진입되는지 확인' },
    { route: 'ERP_SETTLEMENTS', label: '정산관리', requiredRole: 'SETTLEMENT_APPROVED_OR_HQ', manualCheck: '정산관리 메뉴 클릭 시 빈 화면 없이 진입되는지 확인. 저장/마감은 누르지 않음' },
    { route: 'ERP_USERS', label: '사용자관리', requiredRole: 'HQ_OR_VENDOR_ADMIN', manualCheck: '사용자관리 메뉴 클릭 시 빈 화면 없이 진입되는지 확인. 권한 변경은 하지 않음' }
  ];
}

function erpCorePostWebappDeployUiSmoke_dryRun(ctx) {
  ctx = ctx || {};
  var routes = erpCorePostWebappDeployUiSmoke_expectedRoutes_();
  return {
    ok: true,
    build: ERP_CORE_POST_WEBAPP_DEPLOY_UI_SMOKE_SAFE_BUILD,
    mode: 'DRY_RUN_ONLY',
    message: '웹앱 배포 후 UI 스모크 점검 계획만 확인합니다. 실제 저장/배포/권한변경은 없습니다.',
    webAppUrlProvided: !!ctx.webAppUrl,
    expectedRouteCount: routes.length,
    routes: routes,
    fatal: [],
    warnings: [],
    safety: erpCorePostWebappDeployUiSmoke_safety_(),
    ctx: ctx
  };
}

function erpCorePostWebappDeployUiSmoke_manualChecklist(ctx) {
  ctx = ctx || {};
  var routes = erpCorePostWebappDeployUiSmoke_expectedRoutes_();
  var checks = routes.map(function(r) {
    return {
      ok: true,
      route: r.route,
      label: r.label,
      requiredRole: r.requiredRole,
      manualCheck: r.manualCheck,
      expected: {
        blankPageDetected: false,
        errorPopupDetected: false,
        actualSaveClicked: false,
        roleMutationClicked: false,
        settlementExecutionClicked: false
      },
      mode: 'MANUAL_UI_CHECK_REQUIRED'
    };
  });
  return {
    ok: true,
    build: ERP_CORE_POST_WEBAPP_DEPLOY_UI_SMOKE_SAFE_BUILD,
    mode: 'POST_WEBAPP_DEPLOY_UI_MANUAL_CHECKLIST',
    checkedAt: new Date().toISOString(),
    webAppUrl: String(ctx.webAppUrl || ''),
    fatal: [],
    warnings: ctx.webAppUrl ? [] : ['webAppUrl이 입력되지 않았습니다. 실제 브라우저에서 수동 확인 후 결과를 붙여주세요.'],
    checks: checks,
    routeCount: checks.length,
    businessDataWrite: false,
    deployAllowedMutation: false,
    actualDeployExecution: false,
    operationalUrlMutation: false,
    safety: erpCorePostWebappDeployUiSmoke_safety_()
  };
}

function erpCorePostWebappDeployUiSmoke_resultTemplate(ctx) {
  ctx = ctx || {};
  return {
    ok: true,
    build: ERP_CORE_POST_WEBAPP_DEPLOY_UI_SMOKE_SAFE_BUILD,
    mode: 'USER_RESULT_TEMPLATE',
    message: '아래 항목을 실제 화면 확인 후 이 방에 붙여넣으세요.',
    template: {
      webAppUrlOpened: 'YES / NO',
      ERP_HOME: 'PASS / FAIL',
      ERP_SALES: 'PASS / FAIL',
      ERP_CONTRACTS: 'PASS / FAIL',
      ERP_INSTALLS: 'PASS / FAIL',
      ERP_AS: 'PASS / FAIL',
      ERP_SETTLEMENTS: 'PASS / FAIL',
      ERP_USERS: 'PASS / FAIL',
      blankPageDetected: 'NO / YES',
      errorPopupDetected: 'NO / YES',
      actualSaveClicked: 'NO',
      notes: ''
    },
    fatal: [],
    warnings: [],
    safety: erpCorePostWebappDeployUiSmoke_safety_(),
    ctx: ctx
  };
}

function erpCorePostWebappDeployUiSmoke_selfTest() {
  var routes = erpCorePostWebappDeployUiSmoke_expectedRoutes_();
  var fatal = [];
  if (routes.length !== 7) fatal.push('routeCount must be 7');
  var seen = {};
  routes.forEach(function(r) {
    if (!r.route || !r.label || !r.requiredRole) fatal.push('route definition incomplete');
    if (seen[r.route]) fatal.push('duplicate route: ' + r.route);
    seen[r.route] = true;
  });
  var safety = erpCorePostWebappDeployUiSmoke_safety_();
  if (safety.noDeployExecution !== true) fatal.push('noDeployExecution must be true');
  if (safety.noBusinessDataWrite !== true) fatal.push('noBusinessDataWrite must be true');
  return {
    ok: fatal.length === 0,
    build: ERP_CORE_POST_WEBAPP_DEPLOY_UI_SMOKE_SAFE_BUILD,
    fatal: fatal,
    warnings: [],
    expected: { routeCount: 7 },
    safety: safety
  };
}
