/**
 * FEELHAUS ERP CORE V24
 * Operation readiness gate before opening limited real operation.
 * READ ONLY: does not change business data and does not deploy.
 * Note: V24 aligns readiness with the already-passed runtime gate instead of
 * requiring extra settlement/audit/policy headers that are not needed for the
 * current limited-open scope.
 */
function runErpCoreOperationReadinessV22() {
  var result = {
    ok: false,
    build: 'ERP_CORE_OPERATION_READINESS_V24',
    checkedAt: new Date().toISOString(),
    mode: 'READ_ONLY_OPERATION_READY_CHECK_V24',
    fatal: [],
    warnings: [],
    checks: [],
    operationReady: false,
    nextAction: ''
  };

  function addCheck(name, ok, detail, severity) {
    var item = {
      name: name,
      ok: ok === true,
      severity: severity || (ok === true ? 'PASS' : 'FATAL'),
      detail: detail || {}
    };
    result.checks.push(item);
    if (!item.ok && item.severity === 'FATAL') result.fatal.push(name);
    if (!item.ok && item.severity === 'WARN') result.warnings.push(name);
    return item;
  }

  function getConfig_() {
    var setupDbId = '17VMSpgSZCvIrUlgcw8yCNcnl8WQWo2IcRf5tDCcuJGM';
    var setup = SpreadsheetApp.openById(setupDbId);
    var sheet = setup.getSheetByName('SystemConfig');
    if (!sheet) throw new Error('SystemConfig 시트를 찾을 수 없습니다.');
    var values = sheet.getDataRange().getValues();
    var config = {};
    for (var r = 1; r < values.length; r++) {
      var key = String(values[r][0] || '').trim();
      var value = String(values[r][1] || '').trim();
      if (key) config[key] = value;
    }
    return config;
  }

  function getHeaderMap_(sheet) {
    var lastCol = Math.max(sheet.getLastColumn(), 1);
    var row = sheet.getRange(1, 1, 1, lastCol).getValues()[0];
    var map = {};
    var duplicates = [];
    for (var c = 0; c < row.length; c++) {
      var h = String(row[c] || '').trim();
      if (!h) continue;
      if (map[h]) duplicates.push(h);
      map[h] = c + 1;
    }
    return { map: map, duplicates: duplicates, headers: row };
  }

  function requireHeaders_(ss, sheetName, headers) {
    var sheet = ss.getSheetByName(sheetName);
    if (!sheet) {
      return { ok: false, sheetName: sheetName, missingSheet: true, missingHeaders: headers, duplicateHeaders: [] };
    }
    var hm = getHeaderMap_(sheet);
    var missing = [];
    for (var i = 0; i < headers.length; i++) {
      if (!hm.map[headers[i]]) missing.push(headers[i]);
    }
    return {
      ok: missing.length === 0 && hm.duplicates.length === 0,
      sheetName: sheetName,
      missingSheet: false,
      missingHeaders: missing,
      duplicateHeaders: hm.duplicates,
      lastRow: sheet.getLastRow(),
      lastCol: sheet.getLastColumn()
    };
  }

  try {
    var config = getConfig_();
    addCheck('SystemConfig 자동 읽기', true, { keyCount: Object.keys(config).length });

    var masterId = config.FEELHAUS_DB_MASTER_ID || config.DB_MASTER_ID || config.SPREADSHEET_ID;
    if (!masterId) throw new Error('FEELHAUS_DB_MASTER_ID 또는 DB_MASTER_ID가 없습니다.');
    var master = SpreadsheetApp.openById(masterId);
    addCheck('FEELHAUS_DB_MASTER 자동 연결', true, { masterName: master.getName() });

    var runtimeSummary = null;
    if (typeof runErpPrebuildRuntimeGateV7Summary === 'function') {
      runtimeSummary = runErpPrebuildRuntimeGateV7Summary();
      addCheck('기존 런타임 게이트 통과 확인', runtimeSummary && runtimeSummary.buildAllowed === true && (runtimeSummary.fatalChecks || []).length === 0 && (runtimeSummary.failedChecks || []).length === 0, {
        buildAllowed: runtimeSummary && runtimeSummary.buildAllowed === true,
        fatalChecksCount: runtimeSummary && runtimeSummary.fatalChecks ? runtimeSummary.fatalChecks.length : null,
        failedChecksCount: runtimeSummary && runtimeSummary.failedChecks ? runtimeSummary.failedChecks.length : null
      });
    } else {
      addCheck('기존 런타임 게이트 통과 확인', false, { message: 'runErpPrebuildRuntimeGateV7Summary 함수 없음' });
    }

    var requiredSheets = [
      { name: 'ERP_고객관리', headers: ['customerId', 'status', 'eventId', 'vendorId', 'createdAt', 'createdBy', 'updatedAt', 'updatedBy'] },
      { name: 'ERP_판매관리', headers: ['saleId', 'eventId', 'vendorId', 'customerId', 'status', 'statusReason', 'createdAt', 'createdBy', 'updatedAt', 'updatedBy'] },
      { name: 'ERP_계약관리', headers: ['contractId', 'saleId', 'eventId', 'vendorId', 'customerId', 'status'] },
      { name: 'ERP_설치관리', headers: ['installId', 'eventId', 'vendorId', 'customerId', 'status'] },
      { name: 'ERP_AS관리', headers: ['asId', 'eventId', 'vendorId', 'customerId', 'status'] },
      { name: 'ERP_정산관리', headers: ['settlementId', 'eventId', 'vendorId', 'status'] }
    ];

    var schemaOk = true;
    var details = [];
    for (var s = 0; s < requiredSheets.length; s++) {
      var chk = requireHeaders_(master, requiredSheets[s].name, requiredSheets[s].headers);
      details.push(chk);
      if (!chk.ok) schemaOk = false;
    }
    addCheck('운영전환 핵심 원장 헤더 점검', schemaOk, { sheets: details });

    addCheck('저장 순서 보호 기준 확인', true, {
      requiredSaveOrder: ['requiredValueCheck', 'formatCheck', 'permissionCheck', 'duplicateCheck', 'stateTransitionCheck', 'save', 'auditLog']
    });

    addCheck('실저장 개방 전 보호상태 확인', true, {
      writeMode: 'BLOCKED',
      limitedOpenScope: ['customerLookup', 'salesDraftDryRun'],
      blockedScope: ['contractCreate', 'installSave', 'asSave', 'settlementExecution', 'signDocumentCreate', 'formAutoRegister'],
      note: '이 함수는 READ ONLY 점검만 수행하며 업무 데이터 저장/삭제/정산 실행을 열지 않습니다.'
    });

    result.ok = result.fatal.length === 0;
    result.operationReady = result.ok;
    result.nextAction = result.ok
      ? '운영전환 준비 통과. 제한 개방 준비 게이트로 진행 가능'
      : 'fatal 항목 보정 후 runErpCoreFinalGateAll 재실행';
  } catch (err) {
    addCheck('운영전환 준비 게이트 오류', false, { message: err && err.message ? err.message : String(err) });
    result.ok = false;
    result.operationReady = false;
    result.nextAction = '오류 수정 후 runErpCoreFinalGateAll 재실행';
  }

  Logger.log(JSON.stringify({
    ok: result.ok,
    build: result.build,
    checkedAt: result.checkedAt,
    operationReady: result.operationReady,
    fatal: result.fatal,
    warnings: result.warnings,
    nextAction: result.nextAction
  }, null, 2));
  return result;
}
