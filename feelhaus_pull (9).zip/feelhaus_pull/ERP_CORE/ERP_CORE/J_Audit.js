/**
 * FEELHAUS ERP_CORE CLEAN MODULE: ERP_Audit.js
 * Consolidated from: ERP_Core_PreDeploy_Audit.js, ERP_Core_MissingSheet_ApprovalDecision.js, ERP_Integrated_PreDeploy_Hub.js, ERP_Integrated_RealUse_GapReport.js
 * Safety: read-only/check/simulation only. actualExecutionBlocked must remain true.
 */



/* ===== BEGIN ERP_Core_PreDeploy_Audit.js ===== */

/**
 * build: ERP_CORE_B06J41_161_240_PRE_DEPLOY_UI_FUNCTION_AUDIT_SAFE
 * role:
 *  - ERP_CORE 운영 배포 전 UI/기능 완성도 점검
 *  - 본사/업체/직원 권한별 메인 진입 점검
 *  - 고객/판매/계약/SIGN/설치/A/S/정산/직원/권한 화면 준비 상태 점검
 * safety:
 *  - read only
 *  - no sheet create
 *  - no DB injection
 *  - no deploy execution
 *  - CONTROL deployAllowed / actualCreateConfirm / actualExecutionBlocked 해제 금지
 */
var ERP_CORE_B06J41_161_240_MODULE_BUILD = 'ERP_CORE_B06J41_161_240_PRE_DEPLOY_UI_FUNCTION_AUDIT_SAFE';
var ERP_CORE_B06J41_161_240_SETUP_DB_ID = '17VMSpgSZCvIrUlgcw8yCNcnl8WQWo2IcRf5tDCcuJGM';
var ERP_CORE_B06J41_161_240_CONFIG_SHEET_NAME = 'SystemConfig';

var ERP_CORE_B06J41_161_240_REQUIRED_SHEETS = [
  { key:'events', label:'행사관리', sheetName:'ERP_행사관리', required:['eventId','status','statusReason','createdAt','createdBy','updatedAt','updatedBy'] },
  { key:'vendors', label:'업체관리', sheetName:'ERP_업체관리', required:['vendorId','status','statusReason','createdAt','createdBy','updatedAt','updatedBy'] },
  { key:'customers', label:'고객관리', sheetName:'ERP_고객관리', required:['customerId','eventId','vendorId','status','statusReason','createdAt','createdBy','updatedAt','updatedBy'] },
  { key:'eventVendors', label:'행사업체연결', sheetName:'ERP_행사업체연결', required:['eventVendorId','eventId','vendorId','status','statusReason','createdAt','createdBy','updatedAt','updatedBy'] },
  { key:'sales', label:'판매관리', sheetName:'ERP_판매관리', required:['saleId','eventId','vendorId','customerId','status','createdAt','createdBy','updatedAt','updatedBy'] },
  { key:'contracts', label:'계약관리', sheetName:'ERP_계약관리', required:['contractId','saleId','customerId','eventId','vendorId','status','createdAt','createdBy','updatedAt','updatedBy'] },
  { key:'installs', label:'설치관리', sheetName:'ERP_설치관리', required:['installId','contractId','customerId','eventId','vendorId','status','createdAt','createdBy','updatedAt','updatedBy'] },
  { key:'as', label:'A/S관리', sheetName:'ERP_AS관리', required:['asId','customerId','eventId','vendorId','status','createdAt','createdBy','updatedAt','updatedBy'] },
  { key:'settlements', label:'정산관리', sheetName:'ERP_정산관리', required:['settlementId','saleId','contractId','vendorId','eventId','status','createdAt','createdBy','updatedAt','updatedBy'] },
  { key:'users', label:'직원/권한관리', sheetName:'ERP_사용자관리', required:['userId','vendorId','roleCode','status','createdAt','createdBy','updatedAt','updatedBy'] },
  { key:'signDocs', label:'SIGN 문서', sheetName:'SIGN_Documents', required:['documentId','contractId','saleId','customerId','eventId','vendorId','status'] },
  { key:'coreLog', label:'감사로그', sheetName:'ERP_CoreLog', required:['logId','build','moduleCode','actionCode','targetSheet','targetId','actor','actedAt','status','createdAt','createdBy'] }
];

var ERP_CORE_B06J41_161_240_BLOCKS = [
  { action:'SHEET_CREATE', message:'실제 시트 생성은 ERP_CORE 배포 전 점검 단계에서 차단됩니다.' },
  { action:'DB_INJECTION', message:'실제 DB 주입은 차단됩니다. 조회/시뮬레이션만 가능합니다.' },
  { action:'DEPLOY_EXECUTE', message:'실제 배포 실행은 CONTROL 승인 전까지 차단됩니다.' },
  { action:'HEADER_AUTO_CREATE', message:'헤더 자동 추가는 차단됩니다. 누락은 점검 리포트로만 표시합니다.' },
  { action:'SETTLEMENT_EXECUTE', message:'정산 실행/지급/환수/추가지급은 차단됩니다.' },
  { action:'ROLE_MUTATION', message:'권한 실제 변경은 차단됩니다. 권한 점검/안내만 가능합니다.' }
];

function erpCoreB06J41_161_240_routeSmokeTest() {
  var out = {
    ok: true,
    build: ERP_CORE_B06J41_161_240_MODULE_BUILD,
    routeFile: 'Code.js',
    moduleFile: 'ERP_Core_PreDeploy_Audit.js',
    routes: ['coreAudit','audit','preDeploy','uiCheck','functionAudit'],
    renderFunctionExists: typeof erpCoreB06J41_161_240_renderAuditHtml === 'function',
    selfTestExists: typeof erpCoreB06J41_161_240_selfTest === 'function',
    safety: erpCoreB06J41_161_240_safety_()
  };
  out.ok = out.renderFunctionExists && out.selfTestExists;
  console.log('[ERP_CORE 161-240 ROUTE SMOKE TEST] ' + JSON.stringify(out));
  return out;
}

function erpCoreB06J41_161_240_selfTest() {
  var result = {
    ok: true,
    build: ERP_CORE_B06J41_161_240_MODULE_BUILD,
    checkedAt: new Date().toISOString(),
    fatal: [],
    warnings: [],
    checks: {},
    safety: erpCoreB06J41_161_240_safety_(),
    blocks: erpCoreB06J41_161_240_getBlocks_()
  };

  try {
    result.checks.requiredFunctions = erpCoreB06J41_161_240_checkRequiredFunctions_();
    erpCoreB06J41_161_240_collect_(result, 'requiredFunctions', result.checks.requiredFunctions);

    result.checks.config = erpCoreB06J41_161_240_readSystemConfig_();
    erpCoreB06J41_161_240_collect_(result, 'config', result.checks.config);

    if (result.checks.config.ok) {
      result.checks.master = erpCoreB06J41_161_240_openMaster_(result.checks.config.configMap);
      erpCoreB06J41_161_240_collect_(result, 'master', result.checks.master);
    }

    if (result.checks.master && result.checks.master.ok) {
      result.checks.sheets = erpCoreB06J41_161_240_probeSheets_(result.checks.master.spreadsheet);
      erpCoreB06J41_161_240_collect_(result, 'sheets', result.checks.sheets);
      delete result.checks.master.spreadsheet;
    }

    result.checks.roleEntrances = erpCoreB06J41_161_240_checkRoleEntrances_();
    erpCoreB06J41_161_240_collect_(result, 'roleEntrances', result.checks.roleEntrances);

    result.checks.workflow = erpCoreB06J41_161_240_checkWorkflowPolicy_();
    erpCoreB06J41_161_240_collect_(result, 'workflow', result.checks.workflow);

  } catch (e) {
    result.fatal.push('ERP_CORE 161~240 selfTest 예외: ' + erpCoreB06J41_161_240_err_(e));
    result.exceptionStack = String(e && e.stack ? e.stack : '');
  }

  result.fatalCount = result.fatal.length;
  result.warningCount = result.warnings.length;
  result.ok = result.fatalCount === 0;
  console.log('[ERP_CORE 161-240 SELFTEST] ' + JSON.stringify(result));
  return result;
}

function erpCoreB06J41_161_240_renderAuditHtml(ctx) {
  var model = erpCoreB06J41_161_240_buildAuditModel_(ctx || {});
  var t = HtmlService.createTemplateFromFile('H_Audit');
  t.modelJson = JSON.stringify(model);
  return t.evaluate()
    .setTitle('FEELHAUS ERP_CORE 배포 전 점검')
    .setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL);
}

function erpCoreB06J41_161_240_buildAuditModel_(ctx) {
  var self = erpCoreB06J41_161_240_selfTest();
  var model = {
    ok: self.ok,
    build: ERP_CORE_B06J41_161_240_MODULE_BUILD,
    params: ctx || {},
    checkedAt: new Date().toISOString(),
    summary: {
      fatalCount: self.fatalCount || 0,
      warningCount: self.warningCount || 0,
      sheetCount: self.checks && self.checks.sheets ? self.checks.sheets.sheetCount : 0,
      readySheetCount: self.checks && self.checks.sheets ? self.checks.sheets.readyCount : 0,
      missingSheetCount: self.checks && self.checks.sheets ? self.checks.sheets.missingCount : 0
    },
    checks: self.checks || {},
    fatal: self.fatal || [],
    warnings: self.warnings || [],
    safety: self.safety,
    blocks: self.blocks,
    menus: erpCoreB06J41_161_240_menuBlueprint_(),
    nextGuide: [
      '권한별 메인 진입 화면에서 빈화면 대신 안내문이 보이는지 확인',
      '고객/판매/계약/SIGN/설치/A/S/정산 각 메뉴의 조회 화면을 먼저 확인',
      '저장/상태변경/정산 실행은 CONTROL 승인 전까지 열지 않음'
    ]
  };
  return model;
}

function erpCoreB06J41_161_240_readSystemConfig_() {
  var out = { ok:true, fatal:[], warnings:[], setupDbId:ERP_CORE_B06J41_161_240_SETUP_DB_ID, configSheetName:ERP_CORE_B06J41_161_240_CONFIG_SHEET_NAME, configMap:{}, configCount:0 };
  try {
    var setup = SpreadsheetApp.openById(ERP_CORE_B06J41_161_240_SETUP_DB_ID);
    out.setupDbName = setup.getName();
    var sh = setup.getSheetByName(ERP_CORE_B06J41_161_240_CONFIG_SHEET_NAME);
    if (!sh) { out.ok=false; out.fatal.push('SystemConfig 시트를 찾지 못했습니다.'); return out; }
    var values = sh.getDataRange().getValues();
    if (!values || values.length < 2) { out.ok=false; out.fatal.push('SystemConfig 데이터가 비어 있습니다.'); return out; }
    var headers = values[0].map(function(h){ return erpCoreB06J41_161_240_s_(h); });
    var lower = headers.map(function(h){ return h.toLowerCase(); });
    var keyIdx = lower.indexOf('config_key');
    if (keyIdx < 0) keyIdx = lower.indexOf('configkey');
    if (keyIdx < 0) keyIdx = lower.indexOf('key');
    if (keyIdx < 0) keyIdx = lower.indexOf('name');
    if (keyIdx < 0) keyIdx = 0;
    var valIdx = lower.indexOf('value');
    if (valIdx < 0) valIdx = lower.indexOf('config_value');
    if (valIdx < 0) valIdx = lower.indexOf('configvalue');
    if (valIdx < 0) valIdx = lower.indexOf('spreadsheetid');
    if (valIdx < 0) valIdx = 1;
    for (var r=1; r<values.length; r++) {
      var k = erpCoreB06J41_161_240_s_(values[r][keyIdx]);
      var v = erpCoreB06J41_161_240_s_(values[r][valIdx]);
      if (k) out.configMap[k] = v;
    }
    out.configCount = Object.keys(out.configMap).length;
  } catch (e) {
    out.ok=false; out.fatal.push('SystemConfig 읽기 예외: ' + erpCoreB06J41_161_240_err_(e));
  }
  return out;
}

function erpCoreB06J41_161_240_openMaster_(configMap) {
  var out = { ok:true, fatal:[], warnings:[], usedMasterKey:'', masterId:'', masterName:'' };
  var keys = ['FEELHAUS_DB_MASTER_ID','FEELHAUS_DB_MASTER','MASTER_SPREADSHEET_ID','MASTER_DB_ID','DB_MASTER_ID','SPREADSHEET_ID'];
  for (var i=0; i<keys.length; i++) {
    if (configMap && configMap[keys[i]]) {
      out.usedMasterKey = keys[i];
      out.masterId = erpCoreB06J41_161_240_extractSpreadsheetId_(configMap[keys[i]]);
      break;
    }
  }
  if (!out.masterId) { out.ok=false; out.fatal.push('FEELHAUS_DB_MASTER ID를 SystemConfig에서 찾지 못했습니다.'); return out; }
  try {
    out.spreadsheet = SpreadsheetApp.openById(out.masterId);
    out.masterName = out.spreadsheet.getName();
  } catch (e) {
    out.ok=false; out.fatal.push('FEELHAUS_DB_MASTER 열기 예외: ' + erpCoreB06J41_161_240_err_(e));
  }
  return out;
}

function erpCoreB06J41_161_240_probeSheets_(ss) {
  var out = { ok:true, fatal:[], warnings:[], sheets:[], sheetCount:ERP_CORE_B06J41_161_240_REQUIRED_SHEETS.length, readyCount:0, missingCount:0 };
  for (var i=0; i<ERP_CORE_B06J41_161_240_REQUIRED_SHEETS.length; i++) {
    var spec = ERP_CORE_B06J41_161_240_REQUIRED_SHEETS[i];
    var sh = ss.getSheetByName(spec.sheetName);
    var one = { key:spec.key, label:spec.label, sheetName:spec.sheetName, exists:!!sh, lastRow:0, lastCol:0, missingHeaders:[], ready:false };
    if (!sh) {
      one.missingHeaders = spec.required.slice();
      out.missingCount++;
      if (spec.key === 'signDocs' || spec.key === 'coreLog') out.warnings.push('연계/로그 시트 없음: ' + spec.sheetName);
      else out.warnings.push('ERP_CORE 점검 대상 시트 없음: ' + spec.sheetName);
    } else {
      one.lastRow = sh.getLastRow();
      one.lastCol = sh.getLastColumn();
      var headers = erpCoreB06J41_161_240_headers_(sh);
      one.missingHeaders = spec.required.filter(function(h){ return headers.indexOf(h) < 0; });
      one.ready = one.missingHeaders.length === 0;
      if (one.ready) out.readyCount++;
      else out.warnings.push(spec.sheetName + ' 누락 헤더: ' + one.missingHeaders.join(', '));
    }
    out.sheets.push(one);
  }
  return out;
}

function erpCoreB06J41_161_240_checkRequiredFunctions_() {
  var required = [
    'doGet',
    'erpCoreB06J41_161_240_renderAuditHtml',
    'erpCoreB06J41_161_240_selfTest',
    'erpCoreB06J41_161_240_routeSmokeTest',
    'erpCore_getConfig',
    'erpCore_getMasterInfo',
    'erpCore_getHeaderMap',
    'erpCore_getRows',
    'erpCore_getDataScope'
  ];
  var missing = [];
  for (var i=0; i<required.length; i++) {
    if (typeof this[required[i]] !== 'function') missing.push(required[i]);
  }
  return { ok:missing.length === 0, fatal:missing.length ? ['필수 함수 누락: ' + missing.join(', ')] : [], warnings:[], missing:missing, required:required };
}

function erpCoreB06J41_161_240_checkRoleEntrances_() {
  var roles = [
    { roleCode:'HQ_ADMIN', label:'본사 메인', scope:'ALL', vendorRequired:false },
    { roleCode:'VENDOR_OWNER', label:'업체대표 메인', scope:'VENDOR', vendorRequired:true },
    { roleCode:'STAFF_SALES', label:'직원 메인', scope:'STAFF', vendorRequired:true }
  ];
  return { ok:true, fatal:[], warnings:[], roles:roles, policy:'ERP 하나 안에서 roleCode/vendorId/eventId 기준으로 화면 분리' };
}

function erpCoreB06J41_161_240_checkWorkflowPolicy_() {
  return {
    ok:true,
    fatal:[],
    warnings:[],
    flows:[
      '고객검색 → 고객등록/상세 → 판매등록 → 계약생성 → SIGN 상태 표시',
      '계약 → 설치관리 → A/S관리 → 정산조회',
      '정산조회 → 취소정산 계산 → 환수/추가지급 후보 표시',
      '직원관리 → 권한관리 → 민감권한은 승인 기반'
    ],
    locked:'저장/상태변경/정산 실행은 배포 전 점검 단계에서 실제 실행 금지'
  };
}

function erpCoreB06J41_161_240_menuBlueprint_() {
  return [
    { group:'본사', items:['전체 현황','행사관리','업체관리','고객/판매/계약','정산/취소정산','권한/감사로그'] },
    { group:'업체', items:['내 고객','내 판매','내 계약','설치/A/S','정산조회','직원관리'] },
    { group:'직원', items:['고객검색','판매등록','계약/SIGN','설치 일정','A/S 처리','내 업무'] }
  ];
}

function erpCoreB06J41_161_240_getBlocks_() {
  var out = {};
  for (var i=0; i<ERP_CORE_B06J41_161_240_BLOCKS.length; i++) {
    var b = ERP_CORE_B06J41_161_240_BLOCKS[i];
    out[b.action] = { ok:false, blocked:true, action:b.action, message:b.message };
  }
  return out;
}

function erpCoreB06J41_161_240_safety_() {
  return {
    readOnlyAudit:true,
    deployAllowed:false,
    actualCreateConfirm:false,
    actualExecutionBlocked:true,
    noSheetCreate:true,
    noDbInjection:true,
    noDeployExecution:true,
    noHeaderAutoCreate:true,
    noSettlementExecution:true,
    noPaymentRecoveryOffset:true,
    noRoleMutation:true,
    vendorBranchUserGroup:true
  };
}

function erpCoreB06J41_161_240_collect_(result, label, check) {
  if (!check) return;
  if (check.fatal && check.fatal.length) result.fatal = result.fatal.concat(check.fatal.map(function(x){ return label + ': ' + x; }));
  if (check.warnings && check.warnings.length) result.warnings = result.warnings.concat(check.warnings.map(function(x){ return label + ': ' + x; }));
}

function erpCoreB06J41_161_240_headers_(sh) {
  if (!sh || sh.getLastRow() < 1 || sh.getLastColumn() < 1) return [];
  return sh.getRange(1, 1, 1, sh.getLastColumn()).getValues()[0].map(function(h){ return erpCoreB06J41_161_240_s_(h); });
}

function erpCoreB06J41_161_240_extractSpreadsheetId_(raw) {
  var s = erpCoreB06J41_161_240_s_(raw);
  var m = s.match(/\/d\/([a-zA-Z0-9-_]+)/);
  return m && m[1] ? m[1] : s;
}

function erpCoreB06J41_161_240_s_(v) { return String(v == null ? '' : v).trim(); }
function erpCoreB06J41_161_240_err_(e) { return String(e && e.message ? e.message : e); }


/* ===== END ERP_Core_PreDeploy_Audit.js ===== */



/* ===== BEGIN ERP_Core_MissingSheet_ApprovalDecision.js ===== */

/**
 * build: ERP_CORE_B06J41_241_320_APPROVAL_DECISION_ROUTE_FIX_V2
 * role:
 *  - CONTROL 결과를 ERP_CORE에서 승인 결정 리포트로 표시
 *  - 누락 시트 6개 / HeaderPolicy 후보 67개 / SheetPolicy 후보 6개 표시
 *  - actualCreateConfirm / deployAllowed / DB 주입 / 배포 실행 승인 여부 표시
 * safety:
 *  - decision report only
 *  - no sheet creation
 *  - no header auto add
 *  - no DB injection
 *  - no deploy execution
 *  - no backup / recovery / rollback execution
 */
var ERP_CORE_B06J41_241_320_MODULE_BUILD = 'ERP_CORE_B06J41_241_320_APPROVAL_DECISION_ROUTE_FIX_V2';
var ERP_CORE_B06J41_241_320_SETUP_DB_ID = '17VMSpgSZCvIrUlgcw8yCNcnl8WQWo2IcRf5tDCcuJGM';
var ERP_CORE_B06J41_241_320_CONFIG_SHEET_NAME = 'SystemConfig';

var ERP_CORE_B06J41_241_320_MISSING_SHEETS = [
  { key:'sales', order:1, sheetName:'ERP_판매관리', label:'판매관리', policy:'CREATE_REQUIRED_PROTECTED', decision:'APPROVAL_REQUIRED', headers:['eventId','vendorId','customerId','status','statusReason','createdAt','createdBy','updatedAt','updatedBy','saleId'] },
  { key:'contracts', order:2, sheetName:'ERP_계약관리', label:'계약관리', policy:'CREATE_REQUIRED_PROTECTED', decision:'APPROVAL_REQUIRED', headers:['eventId','vendorId','customerId','status','statusReason','createdAt','createdBy','updatedAt','updatedBy','contractId','saleId'] },
  { key:'installs', order:3, sheetName:'ERP_설치관리', label:'설치관리', policy:'CREATE_REQUIRED_PROTECTED', decision:'APPROVAL_REQUIRED', headers:['eventId','vendorId','customerId','status','statusReason','createdAt','createdBy','updatedAt','updatedBy','installId','saleId','contractId'] },
  { key:'as', order:4, sheetName:'ERP_AS관리', label:'A/S관리', policy:'CREATE_REQUIRED_PROTECTED', decision:'APPROVAL_REQUIRED', headers:['eventId','vendorId','customerId','status','statusReason','createdAt','createdBy','updatedAt','updatedBy','asId','saleId'] },
  { key:'settlements', order:5, sheetName:'ERP_정산관리', label:'정산관리', policy:'CREATE_REQUIRED_PROTECTED', decision:'APPROVAL_REQUIRED', headers:['eventId','vendorId','customerId','status','statusReason','createdAt','createdBy','updatedAt','updatedBy','settlementId','saleId','contractId'] },
  { key:'users', order:6, sheetName:'ERP_사용자관리', label:'사용자관리', policy:'CREATE_REQUIRED_PROTECTED', decision:'APPROVAL_REQUIRED', headers:['eventId','vendorId','customerId','status','statusReason','createdAt','createdBy','updatedAt','updatedBy','userId','roleCode'] }
];

var ERP_CORE_B06J41_241_320_APPROVAL_ITEMS = [
  { key:'createSheets', label:'ERP_CORE 누락 시트 6개 생성 승인', status:'PENDING', executionBlocked:true },
  { key:'headerPolicy', label:'HeaderPolicy 67개 확정 승인', status:'PENDING', executionBlocked:true },
  { key:'sheetPolicy', label:'SheetPolicy 6개 등록 승인', status:'PENDING', executionBlocked:true },
  { key:'actualCreateConfirm', label:'actualCreateConfirm=true 전환 승인', status:'PENDING', executionBlocked:true },
  { key:'deployAllowed', label:'deployAllowed=true 전환 승인', status:'PENDING', executionBlocked:true },
  { key:'dbInjection', label:'실제 DB 주입 승인', status:'PENDING', executionBlocked:true },
  { key:'deployExecution', label:'실제 배포 실행 승인', status:'PENDING', executionBlocked:true }
];

var ERP_CORE_B06J41_241_320_BLOCKS = [
  { action:'SHEET_CREATE', blocked:true, message:'실제 시트 생성은 ERP_CORE 241~320 승인 결정 단계에서 차단됩니다.' },
  { action:'HEADER_AUTO_CREATE', blocked:true, message:'실제 헤더 자동 추가는 차단됩니다. HeaderPolicy 후보만 표시합니다.' },
  { action:'DB_INJECTION', blocked:true, message:'실제 DB 주입은 차단됩니다. 승인 결정 리포트만 출력합니다.' },
  { action:'DEPLOY_EXECUTE', blocked:true, message:'실제 배포 실행은 CONTROL 승인 전까지 차단됩니다.' },
  { action:'BACKUP_RECOVERY_ROLLBACK', blocked:true, message:'실제 백업/복구/롤백 실행은 이 단계에서 열지 않습니다.' },
  { action:'SETTLEMENT_PAYMENT_RECOVERY', blocked:true, message:'정산/지급/환수/차감 실행은 차단됩니다.' },
  { action:'ROLE_MUTATION', blocked:true, message:'권한 실제 변경은 차단됩니다.' }
];

function erpCoreB06J41_241_320_routeSmokeTest() {
  var out = {
    ok: true,
    build: ERP_CORE_B06J41_241_320_MODULE_BUILD,
    routeFile: 'Code.js',
    moduleFile: 'ERP_Core_MissingSheet_ApprovalDecision.js',
    routes: ['sheetApproval','missingApproval','headerApproval','approvalDecision','createDecision','coreApproval'],
    renderFunctionExists: typeof erpCoreB06J41_241_320_renderApprovalDecisionHtml === 'function',
    selfTestExists: typeof erpCoreB06J41_241_320_selfTest === 'function',
    safety: erpCoreB06J41_241_320_safety_()
  };
  out.ok = out.renderFunctionExists && out.selfTestExists && out.safety.actualExecutionBlocked === true;
  console.log('[ERP_CORE 241-320 ROUTE SMOKE TEST] ' + JSON.stringify(out));
  return out;
}

function erpCoreB06J41_241_320_selfTest() {
  var result = {
    ok: true,
    build: ERP_CORE_B06J41_241_320_MODULE_BUILD,
    checkedAt: new Date().toISOString(),
    fatal: [],
    warnings: [],
    checks: {},
    safety: erpCoreB06J41_241_320_safety_(),
    blocks: ERP_CORE_B06J41_241_320_BLOCKS
  };

  try {
    result.checks.requiredFunctions = erpCoreB06J41_241_320_checkRequiredFunctions_();
    erpCoreB06J41_241_320_collect_(result, 'requiredFunctions', result.checks.requiredFunctions);

    result.checks.candidates = erpCoreB06J41_241_320_buildCandidateSummary_();
    erpCoreB06J41_241_320_collect_(result, 'candidates', result.checks.candidates);

    result.checks.approvalItems = erpCoreB06J41_241_320_checkApprovalItems_();
    erpCoreB06J41_241_320_collect_(result, 'approvalItems', result.checks.approvalItems);

    result.checks.config = erpCoreB06J41_241_320_readSystemConfig_();
    erpCoreB06J41_241_320_collect_(result, 'config', result.checks.config);

    if (result.checks.config.ok) {
      result.checks.master = erpCoreB06J41_241_320_openMaster_(result.checks.config.configMap);
      erpCoreB06J41_241_320_collect_(result, 'master', result.checks.master);
    }

    if (result.checks.master && result.checks.master.ok) {
      result.checks.currentSheetProbe = erpCoreB06J41_241_320_probeMissingSheets_(result.checks.master.spreadsheet);
      erpCoreB06J41_241_320_collect_(result, 'currentSheetProbe', result.checks.currentSheetProbe);
      delete result.checks.master.spreadsheet;
    }
  } catch (e) {
    result.fatal.push('ERP_CORE 241~320 selfTest 예외: ' + erpCoreB06J41_241_320_err_(e));
    result.exceptionStack = String(e && e.stack ? e.stack : '');
  }

  result.fatalCount = result.fatal.length;
  result.warningCount = result.warnings.length;
  result.ok = result.fatalCount === 0 && result.safety.actualExecutionBlocked === true;
  console.log('[ERP_CORE 241-320 SELFTEST] ' + JSON.stringify(result));
  return result;
}

function erpCoreB06J41_241_320_renderApprovalDecisionHtml(ctx) {
  var model = erpCoreB06J41_241_320_buildApprovalDecisionModel_(ctx || {});
  var t = HtmlService.createTemplateFromFile('H_Approve');
  t.modelJson = JSON.stringify(model);
  return t.evaluate()
    .setTitle('FEELHAUS ERP_CORE 승인 결정 리포트')
    .setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL);
}

function erpCoreB06J41_241_320_buildApprovalDecisionModel_(ctx) {
  var self = erpCoreB06J41_241_320_selfTest();
  var candidates = erpCoreB06J41_241_320_buildCandidates_();
  var headerRows = erpCoreB06J41_241_320_flattenHeaderCandidates_(candidates);
  return {
    ok: self.ok,
    build: ERP_CORE_B06J41_241_320_MODULE_BUILD,
    params: ctx || {},
    checkedAt: new Date().toISOString(),
    summary: {
      fatalCount: self.fatalCount || 0,
      warningCount: self.warningCount || 0,
      missingSheetCount: candidates.length,
      sheetPolicyCandidateCount: candidates.length,
      headerPolicyCandidateCount: headerRows.length,
      approvalItemCount: ERP_CORE_B06J41_241_320_APPROVAL_ITEMS.length,
      actualCreateConfirm: false,
      deployAllowed: false,
      actualExecutionBlocked: true
    },
    candidates: candidates,
    headerRows: headerRows,
    approvalItems: ERP_CORE_B06J41_241_320_APPROVAL_ITEMS,
    safety: self.safety,
    blocks: ERP_CORE_B06J41_241_320_BLOCKS,
    checks: self.checks || {},
    fatal: self.fatal || [],
    warnings: self.warnings || [],
    decisionGuide: [
      '1. SheetPolicy 6개를 ERP_CORE 실무 본체 보호 시트로 확정',
      '2. HeaderPolicy 67개 헤더명을 확정',
      '3. actualCreateConfirm=true 전환은 CONTROL 승인 후 별도 진행',
      '4. deployAllowed=true 전환은 생성/헤더/검증 완료 후 별도 진행',
      '5. 이 화면에서는 승인 결정 리포트만 제공하고 실제 생성은 하지 않음'
    ]
  };
}

function erpCoreB06J41_241_320_buildCandidates_() {
  var rows = [];
  for (var i=0; i<ERP_CORE_B06J41_241_320_MISSING_SHEETS.length; i++) {
    var src = ERP_CORE_B06J41_241_320_MISSING_SHEETS[i];
    rows.push({
      key: src.key,
      order: src.order,
      sheetName: src.sheetName,
      label: src.label,
      sheetPolicyStatus: src.policy,
      headerPolicyStatus: 'HEADER_POLICY_REQUIRED',
      protection: 'PROTECTED_CORE_WORK_SHEET',
      decision: src.decision,
      deleteCandidate: false,
      archiveCandidate: false,
      createBlocked: true,
      headerCreateBlocked: true,
      headers: src.headers.slice(),
      headerCount: src.headers.length
    });
  }
  return rows;
}

function erpCoreB06J41_241_320_flattenHeaderCandidates_(candidates) {
  var out = [];
  for (var i=0; i<candidates.length; i++) {
    var c = candidates[i];
    for (var j=0; j<c.headers.length; j++) {
      out.push({
        sheetName: c.sheetName,
        label: c.label,
        headerName: c.headers[j],
        headerOrder: j + 1,
        status: 'HEADER_POLICY_REQUIRED',
        createBlocked: true,
        approvalRequired: true
      });
    }
  }
  return out;
}

function erpCoreB06J41_241_320_buildCandidateSummary_() {
  var candidates = erpCoreB06J41_241_320_buildCandidates_();
  var headerRows = erpCoreB06J41_241_320_flattenHeaderCandidates_(candidates);
  var out = {
    ok: true,
    fatal: [],
    warnings: [],
    missingSheetCount: candidates.length,
    sheetPolicyCandidateCount: candidates.length,
    headerPolicyCandidateCount: headerRows.length,
    expectedMissingSheetCount: 6,
    expectedHeaderPolicyCandidateCount: 67
  };
  if (out.missingSheetCount !== out.expectedMissingSheetCount) {
    out.ok = false;
    out.fatal.push('누락 시트 후보 수 불일치: ' + out.missingSheetCount);
  }
  if (out.headerPolicyCandidateCount !== out.expectedHeaderPolicyCandidateCount) {
    out.ok = false;
    out.fatal.push('HeaderPolicy 후보 수 불일치: ' + out.headerPolicyCandidateCount);
  }
  return out;
}

function erpCoreB06J41_241_320_checkApprovalItems_() {
  var out = { ok:true, fatal:[], warnings:[], approvalItemCount:ERP_CORE_B06J41_241_320_APPROVAL_ITEMS.length, pendingCount:0, blockedCount:0, expectedApprovalItemCount:7 };
  for (var i=0; i<ERP_CORE_B06J41_241_320_APPROVAL_ITEMS.length; i++) {
    var item = ERP_CORE_B06J41_241_320_APPROVAL_ITEMS[i];
    if (item.status === 'PENDING') out.pendingCount++;
    if (item.executionBlocked) out.blockedCount++;
  }
  if (out.approvalItemCount !== out.expectedApprovalItemCount) {
    out.ok = false;
    out.fatal.push('승인 필요 항목 수 불일치: ' + out.approvalItemCount);
  }
  if (out.blockedCount !== out.approvalItemCount) {
    out.ok = false;
    out.fatal.push('승인 항목 중 실행 차단이 아닌 항목이 있습니다.');
  }
  return out;
}

function erpCoreB06J41_241_320_checkRequiredFunctions_() {
  var required = [
    'doGet',
    'erpCoreB06J41_241_320_renderApprovalDecisionHtml',
    'erpCoreB06J41_241_320_selfTest',
    'erpCoreB06J41_241_320_routeSmokeTest',
    'erpCoreB06J41_241_320_buildApprovalDecisionModel_',
    'erpCoreB06J41_241_320_buildCandidates_',
    'erpCoreB06J41_241_320_flattenHeaderCandidates_'
  ];
  var missing = [];
  for (var i=0; i<required.length; i++) {
    try { if (typeof this[required[i]] !== 'function') missing.push(required[i]); }
    catch (e) { missing.push(required[i]); }
  }
  return { ok:missing.length === 0, fatal:missing.length ? ['필수 함수 누락: ' + missing.join(', ')] : [], warnings:[], missing:missing, required:required };
}

function erpCoreB06J41_241_320_probeMissingSheets_(ss) {
  var out = { ok:true, fatal:[], warnings:[], sheets:[], existingCount:0, missingCount:0 };
  for (var i=0; i<ERP_CORE_B06J41_241_320_MISSING_SHEETS.length; i++) {
    var c = ERP_CORE_B06J41_241_320_MISSING_SHEETS[i];
    var sh = ss.getSheetByName(c.sheetName);
    var row = { sheetName:c.sheetName, label:c.label, exists:!!sh, createBlocked:true, headerCreateBlocked:true, approvalRequired:true };
    if (sh) {
      row.lastRow = sh.getLastRow();
      row.lastCol = sh.getLastColumn();
      out.existingCount++;
      out.warnings.push('승인 결정 후보 시트가 이미 존재합니다: ' + c.sheetName + ' / 기존 시트 보호 기준으로 재점검 필요');
    } else {
      row.lastRow = 0;
      row.lastCol = 0;
      out.missingCount++;
    }
    out.sheets.push(row);
  }
  return out;
}

function erpCoreB06J41_241_320_readSystemConfig_() {
  if (typeof erpCoreB06J41_161_240_readSystemConfig_ === 'function') {
    return erpCoreB06J41_161_240_readSystemConfig_();
  }
  return { ok:false, fatal:['기존 SystemConfig 읽기 함수가 없습니다: erpCoreB06J41_161_240_readSystemConfig_'], warnings:[], configMap:{} };
}

function erpCoreB06J41_241_320_openMaster_(configMap) {
  if (typeof erpCoreB06J41_161_240_openMaster_ === 'function') {
    return erpCoreB06J41_161_240_openMaster_(configMap);
  }
  return { ok:false, fatal:['기존 Master 연결 함수가 없습니다: erpCoreB06J41_161_240_openMaster_'], warnings:[] };
}

function erpCoreB06J41_241_320_safety_() {
  return {
    decisionReportOnly: true,
    readOnlyAudit: true,
    deployAllowed: false,
    actualCreateConfirm: false,
    actualExecutionBlocked: true,
    noSheetCreate: true,
    noHeaderAutoCreate: true,
    noDbInjection: true,
    noDeployExecution: true,
    noBackupRecoveryRollbackExecution: true,
    noSettlementExecution: true,
    noPaymentRecoveryOffset: true,
    noRoleMutation: true,
    vendorBranchUserGroup: true
  };
}

function erpCoreB06J41_241_320_collect_(root, key, part) {
  if (!part) return;
  if (part.fatal && part.fatal.length) {
    for (var i=0; i<part.fatal.length; i++) root.fatal.push(key + ': ' + part.fatal[i]);
  }
  if (part.warnings && part.warnings.length) {
    for (var j=0; j<part.warnings.length; j++) root.warnings.push(key + ': ' + part.warnings[j]);
  }
}

function erpCoreB06J41_241_320_s_(v) { return String(v == null ? '' : v).trim(); }
function erpCoreB06J41_241_320_err_(e) { return String(e && e.message ? e.message : e); }


/* ===== END ERP_Core_MissingSheet_ApprovalDecision.js ===== */



/* ===== BEGIN ERP_Integrated_PreDeploy_Hub.js ===== */

/**
 * build: ERP_INTEGRATED_B06J41_321_420_PRE_DEPLOY_UI_FUNCTION_HUB_SAFE
 * role:
 *  - ERP / ERP_CORE / ERP_ADMIN / ERP_FIELD 통합 개발 메인방용 사전 점검 허브
 *  - 운영 배포 전 실사용 UI/기능 완성도 점검 및 보강 범위를 화면화
 *  - 본사/업체/직원 권한별 진입, 고객/판매/계약/SIGN/설치/A/S/정산/혜택/직원/PORTAL/FORM_QR 상태 리포트
 * safety:
 *  - read only report only
 *  - no sheet creation
 *  - no header auto add
 *  - no DB injection
 *  - no settlement / payment / recovery / role mutation execution
 *  - no deploy execution
 */
var ERP_INTEGRATED_B06J41_321_420_MODULE_BUILD = 'ERP_INTEGRATED_B06J41_321_420_PRE_DEPLOY_UI_FUNCTION_HUB_SAFE';
var ERP_INTEGRATED_B06J41_321_420_SETUP_DB_ID = '17VMSpgSZCvIrUlgcw8yCNcnl8WQWo2IcRf5tDCcuJGM';
var ERP_INTEGRATED_B06J41_321_420_CONFIG_SHEET_NAME = 'SystemConfig';

var ERP_INTEGRATED_B06J41_321_420_AREAS = [
  { code:'ROLE_ENTRY', group:'권한별 진입', title:'본사/업체/직원 권한별 메인 진입', status:'READY_TO_REVIEW', protect:['권한','vendorId','eventId','roleCode'], route:'erpIntegrated' },
  { code:'VENDOR_BRANCH', group:'구조', title:'업체는 ERP 내부 지점형 화면 유지', status:'PROTECTED', protect:['업체 독립 앱 금지','업체 독립 DB 금지'], route:'erpIntegrated' },
  { code:'CUSTOMER_FLOW', group:'고객', title:'고객검색/고객등록/고객상세', status:'READY_TO_REVIEW', protect:['customerId','헤더맵','감사로그'], route:'erpIntegrated' },
  { code:'SALE_CONTRACT_SIGN', group:'판매/계약/SIGN', title:'판매등록/계약생성/SIGN 상태 표시', status:'READY_TO_REVIEW', protect:['saleId','contractId','documentId','SIGN 상태'], route:'erpIntegrated' },
  { code:'INSTALL_AS', group:'설치/A/S', title:'설치관리/A/S관리', status:'READY_TO_REVIEW', protect:['installId','asId','상태전이'], route:'erpIntegrated' },
  { code:'FINANCE_SETTLEMENT', group:'정산/재무', title:'정산조회/취소정산/예치금/채권', status:'BLOCKED_EXECUTION_REVIEW_ONLY', protect:['settlementId','취소정산','환수','추가지급'], route:'erpIntegrated' },
  { code:'BENEFIT_FUND', group:'혜택/기금', title:'혜택/상품권/발전기금/예치·환입', status:'READY_TO_REVIEW', protect:['benefitId','paymentId','민감금액 권한'], route:'erpIntegrated' },
  { code:'USER_PERMISSION', group:'직원/권한', title:'직원관리/권한관리', status:'BLOCKED_EXECUTION_REVIEW_ONLY', protect:['userId','roleCode','승인 기반 권한'], route:'erpIntegrated' },
  { code:'PORTAL_REPORT', group:'PORTAL', title:'PORTAL 표시용 ERP 상태 리포트', status:'READY_TO_REVIEW', protect:['상태요약','민감정보 미노출'], route:'portalStatusReport' },
  { code:'FORM_QR', group:'FORM/QR', title:'FORM/QR 유입 고객 연결', status:'READY_TO_REVIEW', protect:['requestId','customerId','중복검사'], route:'formQrHub' },
  { code:'EMPTY_GUIDE', group:'공통 UI', title:'빈화면 안내문', status:'READY_TO_REVIEW', protect:['빈페이지 금지','안내문 출력'], route:'erpIntegrated' },
  { code:'SAVE_AUTH_LOG_STATUS', group:'핵심 테스트', title:'저장/조회/권한/로그/상태변경 테스트', status:'SIMULATION_ONLY', protect:['권한','감사로그','상태전이'], route:'erpIntegrated' }
];

var ERP_INTEGRATED_B06J41_321_420_SHEETS = [
  { key:'events', title:'행사관리', sheetName:'ERP_행사관리', headers:['eventId','status','statusReason','createdAt','createdBy','updatedAt','updatedBy'] },
  { key:'vendors', title:'업체관리', sheetName:'ERP_업체관리', headers:['vendorId','status','statusReason','createdAt','createdBy','updatedAt','updatedBy'] },
  { key:'customers', title:'고객관리', sheetName:'ERP_고객관리', headers:['customerId','eventId','vendorId','status','createdAt','createdBy','updatedAt','updatedBy'] },
  { key:'eventVendors', title:'행사업체연결', sheetName:'ERP_행사업체연결', headers:['eventId','vendorId','status','createdAt','createdBy','updatedAt','updatedBy'] },
  { key:'sales', title:'판매관리', sheetName:'ERP_판매관리', headers:['saleId','eventId','vendorId','customerId','status','createdAt','createdBy','updatedAt','updatedBy'] },
  { key:'contracts', title:'계약관리', sheetName:'ERP_계약관리', headers:['contractId','saleId','customerId','eventId','vendorId','status','createdAt','createdBy','updatedAt','updatedBy'] },
  { key:'installs', title:'설치관리', sheetName:'ERP_설치관리', headers:['installId','saleId','contractId','customerId','eventId','vendorId','status','createdAt','createdBy','updatedAt','updatedBy'] },
  { key:'as', title:'A/S관리', sheetName:'ERP_AS관리', headers:['asId','saleId','customerId','eventId','vendorId','status','createdAt','createdBy','updatedAt','updatedBy'] },
  { key:'settlements', title:'정산관리', sheetName:'ERP_정산관리', headers:['settlementId','saleId','contractId','vendorId','status','createdAt','createdBy','updatedAt','updatedBy'] },
  { key:'users', title:'사용자관리', sheetName:'ERP_사용자관리', headers:['userId','vendorId','roleCode','status','createdAt','createdBy','updatedAt','updatedBy'] },
  { key:'signDocs', title:'SIGN 문서', sheetName:'SIGN_Documents', headers:['documentId','contractId','saleId','customerId','eventId','vendorId','status'] },
  { key:'settlementQueue', title:'SIGN 정산 인계 후보', sheetName:'SIGN_SettlementHandoffQueue', headers:['documentId','saleId','contractId','status'] }
];

function erpIntegratedB06J41_321_420_renderHubHtml(ctx) {
  ctx = ctx || {};
  var model = erpIntegratedB06J41_321_420_buildModel_(ctx);
  var t = HtmlService.createTemplateFromFile('H_Hub');
  t.modelJson = JSON.stringify(model);
  return t.evaluate()
    .setTitle('FEELHAUS ERP 통합 점검 허브')
    .setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL);
}

function erpIntegratedB06J41_321_420_buildModel_(ctx) {
  ctx = ctx || {};
  var config = erpIntegratedB06J41_321_420_readConfig_();
  var master = erpIntegratedB06J41_321_420_openMaster_(config.configMap);
  var sheetProbe = erpIntegratedB06J41_321_420_probeSheets_(master.ss);
  var areaProbe = erpIntegratedB06J41_321_420_probeAreas_(sheetProbe);
  var roleProbe = erpIntegratedB06J41_321_420_buildRoleProbe_(ctx);
  var safety = erpIntegratedB06J41_321_420_buildSafety_();
  var portalReport = erpIntegratedB06J41_321_420_buildPortalReport_(sheetProbe, areaProbe, safety);
  var formQr = erpIntegratedB06J41_321_420_buildFormQrProbe_(sheetProbe);

  var fatal = [];
  if (!config.ok) fatal = fatal.concat(config.fatal || []);
  if (!master.ok) fatal = fatal.concat(master.fatal || []);

  return {
    ok: fatal.length === 0,
    build: ERP_INTEGRATED_B06J41_321_420_MODULE_BUILD,
    checkedAt: new Date().toISOString(),
    fatal: fatal,
    warnings: [].concat(config.warnings || [], master.warnings || [], sheetProbe.warnings || []),
    ctx: ctx,
    config: config,
    master: { ok: master.ok, masterName: master.masterName, masterId: master.masterId, fatal: master.fatal, warnings: master.warnings },
    safety: safety,
    areas: areaProbe,
    roles: roleProbe,
    sheets: sheetProbe,
    portalReport: portalReport,
    formQr: formQr,
    nextActions: erpIntegratedB06J41_321_420_nextActions_()
  };
}

function erpIntegratedB06J41_321_420_probeAreas_(sheetProbe) {
  var byKey = {};
  (sheetProbe.sheets || []).forEach(function(s){ byKey[s.key] = s; });
  return ERP_INTEGRATED_B06J41_321_420_AREAS.map(function(area) {
    var readiness = '점검대기';
    var message = '화면 진입/권한/빈화면 안내문을 시뮬레이션 기준으로 점검합니다.';
    if (area.code === 'SALE_CONTRACT_SIGN') {
      readiness = (byKey.sales && byKey.sales.exists && byKey.contracts && byKey.contracts.exists) ? '기능점검가능' : '시트승인대기';
      message = '판매/계약 핵심 시트는 승인 전 생성 차단 상태를 유지합니다. SIGN 상태 표시는 FIELD/ADMIN 완료 상태를 참조합니다.';
    }
    if (area.code === 'FINANCE_SETTLEMENT') {
      readiness = '조회전용/실행차단';
      message = '정산/취소정산/환수/추가지급은 구조 보호 대상이며 실제 실행은 차단합니다.';
    }
    if (area.code === 'PORTAL_REPORT') {
      readiness = '요약표시가능';
      message = 'PORTAL 표시용 ERP 상태 리포트는 민감정보 없이 요약 상태만 제공합니다.';
    }
    if (area.code === 'FORM_QR') {
      readiness = '연결점검';
      message = 'FORM/QR 유입 고객 연결은 requestId/customerId 기준 중복검사 후 조회만 점검합니다.';
    }
    return {
      code: area.code,
      group: area.group,
      title: area.title,
      status: area.status,
      readiness: readiness,
      message: message,
      route: area.route,
      protect: area.protect,
      blockedExecution: /BLOCKED|SIMULATION/.test(area.status)
    };
  });
}

function erpIntegratedB06J41_321_420_probeSheets_(ss) {
  var warnings = [];
  var sheets = ERP_INTEGRATED_B06J41_321_420_SHEETS.map(function(spec) {
    var sh = ss ? ss.getSheetByName(spec.sheetName) : null;
    var exists = !!sh;
    var headers = exists ? erpIntegratedB06J41_321_420_headers_(sh) : [];
    var missing = spec.headers.filter(function(h){ return headers.indexOf(h) < 0; });
    var protectedCandidate = /SIGN|정산|Log|Queue|사용자|계약|판매|설치|AS/.test(spec.sheetName);
    if (!exists && spec.key !== 'sales' && spec.key !== 'contracts' && spec.key !== 'installs' && spec.key !== 'as' && spec.key !== 'settlements' && spec.key !== 'users') {
      warnings.push('필수/연계 시트 없음: ' + spec.sheetName);
    }
    return {
      key: spec.key,
      title: spec.title,
      sheetName: spec.sheetName,
      exists: exists,
      ready: exists && missing.length === 0,
      createBlocked: !exists,
      headerCreateBlocked: missing.length > 0,
      approvalRequired: !exists || missing.length > 0,
      protectedCandidate: protectedCandidate,
      lastRow: exists ? sh.getLastRow() : 0,
      lastCol: exists ? sh.getLastColumn() : 0,
      missingHeaders: missing,
      requiredHeaders: spec.headers
    };
  });
  var readyCount = sheets.filter(function(s){ return s.ready; }).length;
  var missingCount = sheets.filter(function(s){ return !s.exists; }).length;
  var headerMissingCount = sheets.reduce(function(n, s){ return n + (s.missingHeaders || []).length; }, 0);
  return {
    ok: true,
    warnings: warnings,
    sheets: sheets,
    readyCount: readyCount,
    missingCount: missingCount,
    headerMissingCount: headerMissingCount,
    protectedCandidateCount: sheets.filter(function(s){ return s.protectedCandidate; }).length
  };
}

function erpIntegratedB06J41_321_420_buildRoleProbe_(ctx) {
  var roles = [
    { roleCode:'HQ_ADMIN', label:'본사', scope:'전체 행사/업체/고객 조회 가능', vendorRequired:false, sensitive:'민감정보는 권한별 표시' },
    { roleCode:'VENDOR_OWNER', label:'업체대표', scope:'자기 vendorId / eventId 범위', vendorRequired:true, sensitive:'정산/예치금/채권/다운로드는 승인 기반' },
    { roleCode:'STAFF_SALES', label:'영업직원', scope:'배정 고객/판매/계약 중심', vendorRequired:true, sensitive:'정산/민감금액 비노출' },
    { roleCode:'STAFF_INSTALL', label:'설치담당', scope:'배정 설치/A/S 중심', vendorRequired:true, sensitive:'판매/정산 민감정보 비노출' },
    { roleCode:'VIEWER', label:'조회전용', scope:'허용된 요약만', vendorRequired:false, sensitive:'다운로드/민감정보 차단' }
  ];
  return roles.map(function(r) {
    return {
      roleCode: r.roleCode,
      label: r.label,
      scope: r.scope,
      vendorRequired: r.vendorRequired,
      sensitive: r.sensitive,
      routeAllowed: true,
      mutationAllowed: false,
      saveSimulationOnly: true,
      vendorBranchUserGroup: true
    };
  });
}

function erpIntegratedB06J41_321_420_buildSafety_() {
  return {
    readOnlyAudit: true,
    deployAllowed: false,
    actualCreateConfirm: false,
    actualExecutionBlocked: true,
    noSheetCreate: true,
    noHeaderAutoCreate: true,
    noDbInjection: true,
    noDeployExecution: true,
    noSettlementExecution: true,
    noPaymentRecoveryOffset: true,
    noRoleMutation: true,
    noBackupRecoveryRollbackExecution: true,
    vendorBranchUserGroup: true,
    noIndependentVendorApp: true,
    noIndependentVendorDb: true,
    noSeparateSalesSettlementSource: true
  };
}

function erpIntegratedB06J41_321_420_buildPortalReport_(sheetProbe, areaProbe, safety) {
  var missing = (sheetProbe.sheets || []).filter(function(s){ return !s.exists; }).map(function(s){ return s.sheetName; });
  return {
    status:'PRE_DEPLOY_REVIEW',
    erpFieldSignLink:'DONE',
    erpAdminSignDashboard:'DONE',
    erpCoreAudit:'PASSED_CREATE_STILL_BLOCKED',
    integratedHub:'READY_TO_REVIEW',
    missingSheetCount: missing.length,
    missingSheets: missing,
    executionBlocked: safety.actualExecutionBlocked,
    deployAllowed: safety.deployAllowed,
    message:'PORTAL에는 ERP 상태 요약만 표시하고 실제 생성/정산/배포 실행은 열지 않습니다.'
  };
}

function erpIntegratedB06J41_321_420_buildFormQrProbe_(sheetProbe) {
  return {
    status:'LINK_CHECK_ONLY',
    rules:['requestId 기준 추적','customerId 중복검사','FORM은 ERP/SIGN/PORTAL/CONTROL 연결 통로','독립 DB 금지'],
    executionBlocked:true,
    message:'FORM/QR 유입 고객은 자동등록 전 조회/중복/권한 검사 흐름만 점검합니다.'
  };
}

function erpIntegratedB06J41_321_420_nextActions_() {
  return [
    '본사/업체/직원 권한별 메인 진입 화면 확인',
    '고객검색/고객등록/고객상세 빈화면 안내문 확인',
    '판매등록/계약생성/SIGN 상태 표시 연결 확인',
    '설치/A/S/정산/취소정산/예치금/채권 조회 전용 안내 확인',
    '혜택/상품권/발전기금/FORM/QR/PORTAL 상태 리포트 확인',
    '저장/조회/권한/로그/상태변경은 시뮬레이션 기준으로만 점검'
  ];
}

function erpIntegratedB06J41_321_420_readConfig_() {
  var out = { ok:false, fatal:[], warnings:[], setupDbId:ERP_INTEGRATED_B06J41_321_420_SETUP_DB_ID, configSheetName:ERP_INTEGRATED_B06J41_321_420_CONFIG_SHEET_NAME, configMap:{}, configCount:0 };
  try {
    var setup = SpreadsheetApp.openById(ERP_INTEGRATED_B06J41_321_420_SETUP_DB_ID);
    var sh = setup.getSheetByName(ERP_INTEGRATED_B06J41_321_420_CONFIG_SHEET_NAME);
    if (!sh) throw new Error('SystemConfig 시트 없음');
    var values = sh.getDataRange().getValues();
    if (!values || values.length < 2) throw new Error('SystemConfig 데이터 없음');
    var header = values[0].map(function(v){ return erpIntegratedB06J41_321_420_s_(v); });
    var keyCol = header.indexOf('CONFIG_KEY');
    var valCol = header.indexOf('VALUE');
    if (keyCol < 0) keyCol = header.indexOf('key');
    if (valCol < 0) valCol = header.indexOf('value');
    if (keyCol < 0 || valCol < 0) {
      keyCol = 0; valCol = 1;
      out.warnings.push('SystemConfig 헤더 CONFIG_KEY/VALUE 미검출: 1~2열 fallback 사용');
    }
    for (var r=1; r<values.length; r++) {
      var k = erpIntegratedB06J41_321_420_s_(values[r][keyCol]);
      if (k) out.configMap[k] = values[r][valCol];
    }
    out.configCount = Object.keys(out.configMap).length;
    out.ok = true;
  } catch (err) {
    out.fatal.push(String(err && err.message ? err.message : err));
  }
  return out;
}

function erpIntegratedB06J41_321_420_openMaster_(configMap) {
  var out = { ok:false, fatal:[], warnings:[], ss:null, masterId:'', masterName:'' };
  try {
    configMap = configMap || {};
    var id = configMap.FEELHAUS_DB_MASTER_ID || configMap.DB_MASTER_ID || configMap.SPREADSHEET_ID || configMap.CUSTOMER_DB_SPREADSHEET_ID;
    if (!id) throw new Error('FEELHAUS_DB_MASTER_ID / DB_MASTER_ID 설정 없음');
    var ss = SpreadsheetApp.openById(id);
    out.ss = ss;
    out.masterId = id;
    out.masterName = ss.getName();
    out.ok = true;
  } catch (err) {
    out.fatal.push(String(err && err.message ? err.message : err));
  }
  return out;
}

function erpIntegratedB06J41_321_420_headers_(sh) {
  if (!sh || sh.getLastRow() < 1 || sh.getLastColumn() < 1) return [];
  return sh.getRange(1, 1, 1, sh.getLastColumn()).getValues()[0].map(function(v){ return erpIntegratedB06J41_321_420_s_(v); }).filter(Boolean);
}

function erpIntegratedB06J41_321_420_routeSmokeTest() {
  return {
    ok: true,
    build: ERP_INTEGRATED_B06J41_321_420_MODULE_BUILD,
    routeFile:'Code.js',
    moduleFile:'ERP_Integrated_PreDeploy_Hub.js',
    routes:['integratedHub','erpIntegrated','uiFunctionHub','preDeployHub','erpMainHub','erpStatusReport','portalStatusReport','formQrHub'],
    preservedRoutes:['approvalDecision','sheetApproval','headerApproval','coreAudit','preDeploy','uiCheck'],
    renderFunctionExists: typeof erpIntegratedB06J41_321_420_renderHubHtml === 'function',
    selfTestExists: typeof erpIntegratedB06J41_321_420_selfTest === 'function',
    safety: erpIntegratedB06J41_321_420_buildSafety_()
  };
}

function erpIntegratedB06J41_321_420_selfTest() {
  var fatal = [];
  var warnings = [];
  var required = [
    'doGet',
    'erpIntegratedB06J41_321_420_renderHubHtml',
    'erpIntegratedB06J41_321_420_selfTest',
    'erpIntegratedB06J41_321_420_routeSmokeTest',
    'erpIntegratedB06J41_321_420_buildModel_',
    'erpIntegratedB06J41_321_420_probeAreas_',
    'erpIntegratedB06J41_321_420_probeSheets_'
  ];
  var missing = required.filter(function(fn){ return typeof this[fn] !== 'function'; }, this);
  if (missing.length) fatal.push('missing functions: ' + missing.join(', '));

  var model = erpIntegratedB06J41_321_420_buildModel_({ selfTest:true });
  if (!model.ok) fatal = fatal.concat(model.fatal || []);
  if ((model.areas || []).length !== 12) fatal.push('expected 12 integrated areas');
  if (!model.safety || model.safety.deployAllowed !== false) fatal.push('deployAllowed must remain false');
  if (!model.safety || model.safety.actualCreateConfirm !== false) fatal.push('actualCreateConfirm must remain false');
  if (!model.safety || model.safety.actualExecutionBlocked !== true) fatal.push('actualExecutionBlocked must remain true');

  return {
    ok: fatal.length === 0,
    build: ERP_INTEGRATED_B06J41_321_420_MODULE_BUILD,
    checkedAt: new Date().toISOString(),
    fatal: fatal,
    warnings: warnings.concat(model.warnings || []),
    checks: {
      requiredFunctions:{ ok:missing.length===0, missing:missing, required:required },
      config:{ ok:model.config && model.config.ok, configCount:model.config ? model.config.configCount : 0 },
      master:{ ok:model.master && model.master.ok, masterName:model.master ? model.master.masterName : '' },
      integratedAreas:{ ok:(model.areas || []).length === 12, count:(model.areas || []).length },
      sheets:{ ok:model.sheets && model.sheets.ok, readyCount:model.sheets ? model.sheets.readyCount : 0, missingCount:model.sheets ? model.sheets.missingCount : 0, headerMissingCount:model.sheets ? model.sheets.headerMissingCount : 0 },
      portalReport:{ ok:!!model.portalReport, status:model.portalReport ? model.portalReport.status : '' },
      safety:model.safety
    }
  };
}

function erpIntegratedB06J41_321_420_s_(v) {
  return v === null || v === undefined ? '' : String(v).trim();
}


/* ===== END ERP_Integrated_PreDeploy_Hub.js ===== */



/* ===== BEGIN ERP_Integrated_RealUse_GapReport.js ===== */

/**
 * build: ERP_INTEGRATED_B06J41_421_520_REAL_USE_UI_GAP_REPORT_SAFE
 * project: ERP_CORE
 * role:
 *  - ERP / ERP_CORE / ERP_ADMIN / ERP_FIELD 통합 개발 메인방용 실사용 UI gap 리포트
 *  - 본사/업체/직원 화면, 고객/판매/계약/SIGN/설치/A/S/정산/혜택/직원/FORM/QR/PORTAL 화면 완성도 차이를 정리
 * safety:
 *  - report only
 *  - read only
 *  - no sheet creation
 *  - no header auto add
 *  - no DB injection
 *  - no settlement/payment/recovery/role mutation execution
 *  - no deploy/backup/recovery/rollback execution
 */
var ERP_INTEGRATED_B06J41_421_520_MODULE_BUILD = 'ERP_INTEGRATED_B06J41_421_520_REAL_USE_UI_GAP_REPORT_SAFE';
var ERP_INTEGRATED_B06J41_421_520_SETUP_DB_ID = '17VMSpgSZCvIrUlgcw8yCNcnl8WQWo2IcRf5tDCcuJGM';
var ERP_INTEGRATED_B06J41_421_520_CONFIG_SHEET_NAME = 'SystemConfig';

var ERP_INTEGRATED_B06J41_421_520_GAP_ITEMS = [
  { no:421, area:'권한별 메인', title:'본사/업체/직원 메인 진입 상세 점검', status:'NEEDS_UI_REVIEW', priority:'HIGH', owner:'ERP_CORE', protected:['roleCode','vendorId','eventId','권한검사'], next:'권한별 허브 카드와 빈화면 안내문 보강' },
  { no:431, area:'고객', title:'고객검색/고객등록/고객상세 UI gap 점검', status:'NEEDS_UI_REVIEW', priority:'HIGH', owner:'ERP_FIELD', protected:['customerId','전화번호 규칙','중복검사','감사로그'], next:'검색 결과/상세/신규 등록 화면 흐름 보강' },
  { no:441, area:'판매/계약/SIGN', title:'판매등록/계약생성/SIGN 상태 표시 gap 점검', status:'NEEDS_UI_REVIEW', priority:'HIGH', owner:'ERP_FIELD', protected:['saleId','contractId','documentId','SIGN URL','QR URL'], next:'판매-계약-SIGN 카드 연결과 보관완료 잠금 안내 보강' },
  { no:451, area:'설치/A/S', title:'설치관리/A/S관리 UI gap 점검', status:'NEEDS_UI_REVIEW', priority:'MEDIUM', owner:'ERP_FIELD', protected:['installId','asId','상태전이','담당자 배정'], next:'예정/진행/완료/지연 탭과 A/S 처리 안내문 보강' },
  { no:461, area:'정산/취소정산', title:'정산조회/취소정산/예치금/채권 UI gap 점검', status:'EXECUTION_BLOCKED_REVIEW_ONLY', priority:'HIGH', owner:'ERP_ADMIN', protected:['settlementId','취소정산','환수','추가지급','예치금','채권'], next:'조회 전용 화면과 실행 차단 안내를 분리' },
  { no:471, area:'혜택/기금', title:'혜택/상품권/발전기금/예치·환입 UI gap 점검', status:'NEEDS_POLICY_REVIEW', priority:'MEDIUM', owner:'ERP_ADMIN', protected:['benefitId','paymentId','민감금액 권한','승인흐름'], next:'요약/상세/민감정보 표시 권한을 분리' },
  { no:481, area:'직원/권한', title:'직원관리/권한관리 UI gap 점검', status:'EXECUTION_BLOCKED_REVIEW_ONLY', priority:'HIGH', owner:'ERP_ADMIN', protected:['userId','roleCode','승인 기반 권한','권한변경 로그'], next:'즉시 변경/승인 필요 권한을 화면에서 명확히 분리' },
  { no:491, area:'FORM/QR', title:'FORM/QR 유입 고객 연결 gap 점검', status:'NEEDS_LINK_REVIEW', priority:'MEDIUM', owner:'ERP_FIELD', protected:['requestId','customerId','eventId','vendorId','중복검사'], next:'QR/FORM 유입 고객을 기존 고객과 연결하는 안내 화면 보강' },
  { no:501, area:'PORTAL 리포트', title:'PORTAL 표시용 ERP 상태 리포트 gap 점검', status:'READY_TO_SUMMARY', priority:'MEDIUM', owner:'ERP_CORE', protected:['요약 리포트','민감정보 미노출','상태 집계'], next:'PORTAL이 읽을 상태 요약값과 진입 링크 기준 정리' },
  { no:511, area:'공통 품질', title:'빈화면/저장/조회/권한/로그/상태변경 테스트 gap 점검', status:'SIMULATION_ONLY', priority:'HIGH', owner:'ERP_CORE', protected:['빈페이지 금지','권한','감사로그','상태전이'], next:'각 화면별 빈 데이터 안내문과 테스트 기준 확정' }
];

function erpIntegratedB06J41_421_520_renderGapReportHtml(ctx) {
  ctx = ctx || {};
  var model = erpIntegratedB06J41_421_520_buildGapModel_(ctx);
  var t = HtmlService.createTemplateFromFile('H_Gap');
  t.modelJson = JSON.stringify(model);
  return t.evaluate()
    .setTitle('FEELHAUS ERP 실사용 UI Gap 리포트')
    .setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL);
}

function erpIntegratedB06J41_421_520_buildGapModel_(ctx) {
  ctx = ctx || {};
  var safety = erpIntegratedB06J41_421_520_buildSafety_();
  var items = erpIntegratedB06J41_421_520_buildGapItems_(ctx);
  var summary = erpIntegratedB06J41_421_520_buildSummary_(items, safety);
  var projectLinks = erpIntegratedB06J41_421_520_buildProjectLinks_();
  var nextOrder = erpIntegratedB06J41_421_520_buildNextOrder_();
  return {
    ok: true,
    build: ERP_INTEGRATED_B06J41_421_520_MODULE_BUILD,
    checkedAt: new Date().toISOString(),
    ctx: ctx,
    safety: safety,
    summary: summary,
    items: items,
    projectLinks: projectLinks,
    nextOrder: nextOrder,
    notes: [
      '본 리포트는 운영 배포 전 실사용 UI/기능 gap 점검용입니다.',
      '실제 생성, 실제 DB 주입, 정산 실행, 권한 변경, 배포 실행은 모두 차단 상태입니다.',
      '업체는 별도 앱이 아니라 ERP 내부 지점형 화면으로 유지합니다.'
    ]
  };
}

function erpIntegratedB06J41_421_520_buildGapItems_(ctx) {
  return ERP_INTEGRATED_B06J41_421_520_GAP_ITEMS.map(function(item) {
    var blocked = /BLOCKED|SIMULATION/.test(item.status);
    var ready = item.status === 'READY_TO_SUMMARY';
    return {
      no: item.no,
      area: item.area,
      title: item.title,
      status: item.status,
      priority: item.priority,
      owner: item.owner,
      protected: item.protected,
      next: item.next,
      blockedExecution: blocked,
      reportOnly: true,
      readyToPlan: !blocked || ready,
      approvalRequired: item.priority === 'HIGH' || blocked
    };
  });
}

function erpIntegratedB06J41_421_520_buildSummary_(items, safety) {
  var high = items.filter(function(x){ return x.priority === 'HIGH'; }).length;
  var medium = items.filter(function(x){ return x.priority === 'MEDIUM'; }).length;
  var blocked = items.filter(function(x){ return x.blockedExecution; }).length;
  var approval = items.filter(function(x){ return x.approvalRequired; }).length;
  return {
    fatalCount: 0,
    gapItemCount: items.length,
    highPriorityCount: high,
    mediumPriorityCount: medium,
    executionBlockedCount: blocked,
    approvalRequiredCount: approval,
    stage: 'REAL_USE_UI_GAP_REPORT',
    actualCreateConfirm: safety.actualCreateConfirm,
    deployAllowed: safety.deployAllowed,
    actualExecutionBlocked: safety.actualExecutionBlocked
  };
}

function erpIntegratedB06J41_421_520_buildProjectLinks_() {
  return [
    { project:'ERP_CORE', role:'통합 허브 / 승인 결정 / PORTAL 리포트 기준', status:'ACTIVE_REVIEW', route:'gapReport' },
    { project:'ERP_FIELD', role:'현장 고객/판매/계약/SIGN/설치/A/S 화면', status:'NEEDS_UI_DETAIL_REVIEW', route:'fieldReview' },
    { project:'ERP_ADMIN', role:'본사 SIGN/정산/권한/혜택 관리 화면', status:'NEEDS_ADMIN_UI_REVIEW', route:'adminReview' },
    { project:'PORTAL', role:'ERP 상태 요약 표시', status:'SUMMARY_LINK_READY', route:'portalStatusReport' },
    { project:'FORM/QR', role:'외부 유입 고객 연결', status:'LINK_REVIEW_ONLY', route:'formQrHub' }
  ];
}

function erpIntegratedB06J41_421_520_buildSafety_() {
  return {
    reportOnly: true,
    readOnlyAudit: true,
    deployAllowed: false,
    actualCreateConfirm: false,
    actualExecutionBlocked: true,
    noSheetCreate: true,
    noHeaderAutoCreate: true,
    noDbInjection: true,
    noSettlementExecution: true,
    noPaymentRecoveryOffset: true,
    noRoleMutation: true,
    noDeployExecution: true,
    noBackupRecoveryRollbackExecution: true,
    vendorBranchUserGroup: true,
    noVendorStandaloneApp: true,
    noVendorStandaloneDb: true
  };
}

function erpIntegratedB06J41_421_520_buildNextOrder_() {
  return [
    '본사/업체/직원 권한별 메인 진입 상세 보강 항목 확정',
    '고객검색/등록/상세 화면의 필수 입력·중복검사·빈화면 안내문 정리',
    '판매등록/계약생성/SIGN 상태 표시 화면 보강 계획 확정',
    '정산/취소정산/예치금/채권은 조회 전용과 실행 차단 안내를 분리',
    '혜택/상품권/발전기금/예치·환입 민감정보 권한 표시 기준 확정',
    'FORM/QR 유입 고객 연결 기준과 PORTAL 표시용 ERP 상태 리포트 기준 확정'
  ];
}

function erpIntegratedB06J41_421_520_selfTest() {
  var required = [
    'doGet',
    'erpIntegratedB06J41_421_520_renderGapReportHtml',
    'erpIntegratedB06J41_421_520_selfTest',
    'erpIntegratedB06J41_421_520_routeSmokeTest',
    'erpIntegratedB06J41_421_520_buildGapModel_',
    'erpIntegratedB06J41_421_520_buildGapItems_',
    'erpIntegratedB06J41_421_520_buildSafety_'
  ];
  var missing = required.filter(function(name){ return typeof this[name] !== 'function'; }, this);
  var safety = erpIntegratedB06J41_421_520_buildSafety_();
  var items = erpIntegratedB06J41_421_520_buildGapItems_({});
  var fatal = [];
  if (missing.length) fatal.push('필수 함수 누락: ' + missing.join(', '));
  if (items.length !== 10) fatal.push('gap item count mismatch: ' + items.length);
  if (safety.deployAllowed !== false) fatal.push('deployAllowed must remain false');
  if (safety.actualCreateConfirm !== false) fatal.push('actualCreateConfirm must remain false');
  if (safety.actualExecutionBlocked !== true) fatal.push('actualExecutionBlocked must remain true');
  return {
    ok: fatal.length === 0,
    build: ERP_INTEGRATED_B06J41_421_520_MODULE_BUILD,
    fatal: fatal,
    warnings: [],
    checks: {
      requiredFunctions: { ok: missing.length === 0, missing: missing, required: required },
      gapItems: { ok: items.length === 10, gapItemCount: items.length, highPriorityCount: items.filter(function(x){return x.priority === 'HIGH';}).length },
      safety: safety
    }
  };
}

function erpIntegratedB06J41_421_520_routeSmokeTest() {
  return {
    ok: true,
    build: ERP_INTEGRATED_B06J41_421_520_MODULE_BUILD,
    project: 'ERP_CORE',
    routeFile: 'Code.js',
    moduleFile: 'ERP_Integrated_RealUse_GapReport.js',
    routes: ['gapReport','realUseGap','uiGapReport','screenGap','erpGap','realUseUi','nextGap','uiWorkPlan'],
    renderFunctionExists: typeof erpIntegratedB06J41_421_520_renderGapReportHtml === 'function',
    selfTestExists: typeof erpIntegratedB06J41_421_520_selfTest === 'function',
    safety: erpIntegratedB06J41_421_520_buildSafety_()
  };
}

function erpIntegratedB06J41_421_520_s_(v) {
  return (v === null || v === undefined) ? '' : String(v).trim();
}


/* ===== END ERP_Integrated_RealUse_GapReport.js ===== */
