/**
 * FEELHAUS ERP CORE V17 CONTROL log preparation
 * Purpose: prepare non-business CONTROL log sheets before final deployment gate.
 * Scope: creates/repairs BackupLog, DeployLog, RecoveryLog headers only.
 * Business data is not modified.
 */
var ERP_CONTROL_LOG_PREP_V17_BUILD = 'ERP_CONTROL_LOG_PREP_V17';
var ERP_CONTROL_LOG_PREP_V17_SETUP_DB_ID = '17VMSpgSZCvIrUlgcw8yCNcnl8WQWo2IcRf5tDCcuJGM';
var ERP_CONTROL_LOG_PREP_V17_CONFIG_SHEET_NAME = 'SystemConfig';

function runErpControlLogPrepV17DryRun() {
  return erpControlLogPrepV17_run_({ apply: false });
}

function runErpControlLogPrepV17Apply() {
  return erpControlLogPrepV17_run_({ apply: true });
}

function erpControlLogPrepV17_run_(options) {
  options = options || {};
  var apply = options.apply === true;
  var result = {
    ok: true,
    build: ERP_CONTROL_LOG_PREP_V17_BUILD,
    checkedAt: new Date().toISOString(),
    mode: apply ? 'APPLY' : 'DRY_RUN',
    setupDbId: ERP_CONTROL_LOG_PREP_V17_SETUP_DB_ID,
    configSheetName: ERP_CONTROL_LOG_PREP_V17_CONFIG_SHEET_NAME,
    masterId: '',
    masterName: '',
    sheets: [],
    fatal: [],
    warnings: [],
    nextAction: ''
  };

  try {
    var config = erpControlLogPrepV17_readConfig_();
    result.masterId = config.FEELHAUS_DB_MASTER_ID || config.DB_MASTER_ID || config.SPREADSHEET_ID || '';
    if (!result.masterId) {
      result.ok = false;
      result.fatal.push('FEELHAUS_DB_MASTER_ID 또는 DB_MASTER_ID를 찾을 수 없습니다.');
      result.nextAction = 'SystemConfig의 MASTER DB ID 설정 확인 필요';
      Logger.log(JSON.stringify(result, null, 2));
      return result;
    }

    var master = SpreadsheetApp.openById(result.masterId);
    result.masterName = master.getName();

    var specs = erpControlLogPrepV17_specs_();
    for (var i = 0; i < specs.length; i++) {
      result.sheets.push(erpControlLogPrepV17_checkOrApplySheet_(master, specs[i], apply));
    }

    for (var j = 0; j < result.sheets.length; j++) {
      var item = result.sheets[j];
      if (!item.ok) {
        result.ok = false;
        result.fatal.push(item.sheetName + ' 준비 실패');
      }
      if (item.warning) result.warnings.push(item.warning);
    }

    result.nextAction = result.ok
      ? 'runErpPrebuildRuntimeGateV7Summary 실행 후 buildAllowed 확인'
      : 'fatal 항목 수정 후 재실행';
  } catch (err) {
    result.ok = false;
    result.fatal.push(String(err && err.message ? err.message : err));
    result.nextAction = '오류 확인 후 재실행';
  }

  Logger.log(JSON.stringify(result, null, 2));
  return result;
}

function erpControlLogPrepV17_readConfig_() {
  var setup = SpreadsheetApp.openById(ERP_CONTROL_LOG_PREP_V17_SETUP_DB_ID);
  var sheet = setup.getSheetByName(ERP_CONTROL_LOG_PREP_V17_CONFIG_SHEET_NAME);
  if (!sheet) throw new Error('SystemConfig 시트를 찾을 수 없습니다.');

  var values = sheet.getDataRange().getValues();
  var config = {};
  for (var r = 1; r < values.length; r++) {
    var key = String(values[r][0] || '').trim();
    var value = String(values[r][1] || '').trim();
    if (key) config[key] = value;
  }
  return config;
}

function erpControlLogPrepV17_specs_() {
  var commonHeaders = [
    'logId',
    'logType',
    'targetApp',
    'targetId',
    'status',
    'statusReason',
    'createdAt',
    'createdBy',
    'updatedAt',
    'updatedBy',
    'requestId',
    'approvalId',
    'backupId',
    'deployId',
    'recoveryId',
    'sourceDbId',
    'targetDbId',
    'fileId',
    'fileUrl',
    'memo'
  ];
  return [
    { sheetName: 'BackupLog', headers: commonHeaders },
    { sheetName: 'DeployLog', headers: commonHeaders },
    { sheetName: 'RecoveryLog', headers: commonHeaders }
  ];
}

function erpControlLogPrepV17_checkOrApplySheet_(spreadsheet, spec, apply) {
  var item = {
    sheetName: spec.sheetName,
    existsBefore: false,
    created: false,
    missingHeadersBefore: [],
    addedHeaders: [],
    duplicateHeaders: [],
    ok: true,
    warning: ''
  };

  var sheet = spreadsheet.getSheetByName(spec.sheetName);
  item.existsBefore = !!sheet;

  if (!sheet) {
    if (apply) {
      sheet = spreadsheet.insertSheet(spec.sheetName);
      item.created = true;
    } else {
      item.missingHeadersBefore = spec.headers.slice(0);
      item.warning = spec.sheetName + ' 시트가 없습니다. APPLY 실행 시 생성됩니다.';
      return item;
    }
  }

  var lastCol = Math.max(sheet.getLastColumn(), 1);
  var headers = sheet.getRange(1, 1, 1, lastCol).getValues()[0];
  var map = {};
  for (var i = 0; i < headers.length; i++) {
    var h = String(headers[i] || '').trim();
    if (!h) continue;
    if (map[h]) item.duplicateHeaders.push(h);
    map[h] = true;
  }

  for (var j = 0; j < spec.headers.length; j++) {
    var required = spec.headers[j];
    if (!map[required]) item.missingHeadersBefore.push(required);
  }

  if (item.duplicateHeaders.length) {
    item.ok = false;
    return item;
  }

  if (apply && item.missingHeadersBefore.length) {
    var startCol = Math.max(sheet.getLastColumn(), 0) + 1;
    sheet.getRange(1, startCol, 1, item.missingHeadersBefore.length).setValues([item.missingHeadersBefore]);
    item.addedHeaders = item.missingHeadersBefore.slice(0);
  }

  return item;
}
