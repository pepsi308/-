/**
 * FEELHAUS ERP_CORE Operational Link Precheck
 * Build: ERP_CORE_OPERATIONAL_LINK_PRECHECK_SAFE
 * Project: ERP_CORE only
 * Purpose:
 *  - Read-only precheck after 6 ERP_CORE sheets and policy meta were created.
 *  - Verify operational link readiness for sale/contract/install/AS/settlement/user sheets.
 * Safety:
 *  - no business data write, no policy write, no deploy, no sheet/header mutation.
 */
var ERP_CORE_OPERATIONAL_LINK_PRECHECK_BUILD = 'ERP_CORE_OPERATIONAL_LINK_PRECHECK_SAFE';

var ERP_CORE_OPERATIONAL_LINK_PRECHECK_EXPECTED = {
  sheetCount: 6,
  headerPolicyCount: 67,
  sheetPolicyCount: 6,
  coreSheets: [
    { key:'sales', sheetName:'ERP_판매관리', primaryId:'saleId', required:['eventId','vendorId','customerId','status','statusReason','createdAt','createdBy','updatedAt','updatedBy','saleId'], links:['eventId','vendorId','customerId'] },
    { key:'contracts', sheetName:'ERP_계약관리', primaryId:'contractId', required:['eventId','vendorId','customerId','status','statusReason','createdAt','createdBy','updatedAt','updatedBy','contractId','saleId'], links:['saleId','eventId','vendorId','customerId'] },
    { key:'installs', sheetName:'ERP_설치관리', primaryId:'installId', required:['eventId','vendorId','customerId','status','statusReason','createdAt','createdBy','updatedAt','updatedBy','installId','saleId','contractId'], links:['contractId','saleId','eventId','vendorId','customerId'] },
    { key:'as', sheetName:'ERP_AS관리', primaryId:'asId', required:['eventId','vendorId','customerId','status','statusReason','createdAt','createdBy','updatedAt','updatedBy','asId','saleId'], links:['saleId','eventId','vendorId','customerId'] },
    { key:'settlements', sheetName:'ERP_정산관리', primaryId:'settlementId', required:['eventId','vendorId','customerId','status','statusReason','createdAt','createdBy','updatedAt','updatedBy','settlementId','saleId','contractId'], links:['saleId','contractId','eventId','vendorId','customerId'] },
    { key:'users', sheetName:'ERP_사용자관리', primaryId:'userId', required:['eventId','vendorId','customerId','status','statusReason','createdAt','createdBy','updatedAt','updatedBy','userId','roleCode'], links:['vendorId','roleCode'] }
  ],
  statusHeaders: ['status','statusReason'],
  auditHeaders: ['createdAt','createdBy','updatedAt','updatedBy']
};

function erpCoreOperationalLinkPrecheck_safety_() {
  return {
    build: ERP_CORE_OPERATIONAL_LINK_PRECHECK_BUILD,
    readOnly: true,
    noSheetCreate: true,
    noHeaderAutoAdd: true,
    noPolicyWrite: true,
    noDbInjection: true,
    noDeployExecution: true,
    noBusinessDataWrite: true,
    noCustomerSave: true,
    noSaleSave: true,
    noContractCreate: true,
    noInstallAsSave: true,
    noSettlementExecution: true,
    noCancelSettlementConfirm: true,
    noSignDocumentCreate: true,
    noFormAutoRegister: true,
    noRoleMutation: true,
    noDeleteSheet: true,
    noExistingDataClear: true,
    headerMapRequired: true,
    idBasedConnectionRequired: true,
    vendorBranchUserGroup: true,
    qrInitialEntryTargetSearchProtected: true,
    directRegularMemberLink: false,
    noOriginalSlipMutation: true
  };
}

function erpCoreOperationalLinkPrecheck_dryRun(ctx) {
  ctx = ctx || {};
  var out = {
    ok: true,
    build: ERP_CORE_OPERATIONAL_LINK_PRECHECK_BUILD,
    mode: 'DRY_RUN_ONLY',
    message: 'ERP_CORE 실무 기능 연결 전 읽기 전용 점검 계획만 확인했습니다. 실제 저장/쓰기/배포는 없습니다.',
    expected: {
      sheetCount: ERP_CORE_OPERATIONAL_LINK_PRECHECK_EXPECTED.sheetCount,
      headerPolicyCount: ERP_CORE_OPERATIONAL_LINK_PRECHECK_EXPECTED.headerPolicyCount,
      sheetPolicyCount: ERP_CORE_OPERATIONAL_LINK_PRECHECK_EXPECTED.sheetPolicyCount,
      sheets: ERP_CORE_OPERATIONAL_LINK_PRECHECK_EXPECTED.coreSheets.map(function(s){ return s.sheetName; })
    },
    fatal: [],
    warnings: [],
    safety: erpCoreOperationalLinkPrecheck_safety_(),
    ctx: ctx
  };
  Logger.log('[ERP_CORE OPERATIONAL LINK PRECHECK DRY RUN] ' + JSON.stringify(out));
  return out;
}

function erpCoreOperationalLinkPrecheck_run(ctx) {
  ctx = ctx || {};
  var fatal = [];
  var warnings = [];
  var ss = null;
  try {
    ss = erpCoreOperationalLinkPrecheck_openMaster_();
  } catch (e) {
    fatal.push('MASTER 연결 실패: ' + (e && e.message ? e.message : e));
  }

  var coreSheets = [];
  var linkMatrix = [];
  var policyMeta = { headerPolicy: { ok:false, skipped:true }, sheetPolicy: { ok:false, skipped:true } };
  var postCreate = { ok:false, skipped:true };
  var postInject = { ok:false, skipped:true };

  if (ss) {
    for (var i = 0; i < ERP_CORE_OPERATIONAL_LINK_PRECHECK_EXPECTED.coreSheets.length; i++) {
      coreSheets.push(erpCoreOperationalLinkPrecheck_checkCoreSheet_(ss, ERP_CORE_OPERATIONAL_LINK_PRECHECK_EXPECTED.coreSheets[i]));
    }
    linkMatrix = erpCoreOperationalLinkPrecheck_buildLinkMatrix_(coreSheets);
    policyMeta = erpCoreOperationalLinkPrecheck_checkPolicyMeta_(ss);
  }

  try {
    if (typeof erpCoreActualCreateDedicatedDraft_postCreateCheck === 'function') {
      postCreate = erpCoreActualCreateDedicatedDraft_postCreateCheck();
      if (!postCreate.ok) fatal.push('ERP_CORE post-create 점검 실패');
    } else {
      warnings.push('post-create 점검 함수 없음: erpCoreActualCreateDedicatedDraft_postCreateCheck');
    }
  } catch (pc) {
    fatal.push('post-create 점검 오류: ' + (pc && pc.message ? pc.message : pc));
  }

  try {
    if (typeof erpCorePolicyMetaDbInjectDraft_postInjectCheck === 'function') {
      postInject = erpCorePolicyMetaDbInjectDraft_postInjectCheck();
      if (!postInject.ok) fatal.push('ERP_CORE post-inject 점검 실패');
    } else {
      warnings.push('post-inject 점검 함수 없음: erpCorePolicyMetaDbInjectDraft_postInjectCheck');
    }
  } catch (pi) {
    fatal.push('post-inject 점검 오류: ' + (pi && pi.message ? pi.message : pi));
  }

  for (var c = 0; c < coreSheets.length; c++) {
    if (!coreSheets[c].ok) fatal.push(coreSheets[c].sheetName + ' 실무 연결 헤더 점검 실패');
  }
  if (!policyMeta.headerPolicy.ok) fatal.push('HeaderPolicy 정책 메타 연결 점검 실패');
  if (!policyMeta.sheetPolicy.ok) fatal.push('SheetPolicy 정책 메타 연결 점검 실패');

  var result = {
    ok: fatal.length === 0,
    build: ERP_CORE_OPERATIONAL_LINK_PRECHECK_BUILD,
    checkedAt: new Date().toISOString(),
    fatal: fatal,
    warnings: warnings,
    expected: {
      sheetCount: ERP_CORE_OPERATIONAL_LINK_PRECHECK_EXPECTED.sheetCount,
      headerPolicyCount: ERP_CORE_OPERATIONAL_LINK_PRECHECK_EXPECTED.headerPolicyCount,
      sheetPolicyCount: ERP_CORE_OPERATIONAL_LINK_PRECHECK_EXPECTED.sheetPolicyCount
    },
    coreSheets: coreSheets,
    linkMatrix: linkMatrix,
    policyMeta: policyMeta,
    postCreateCheck: postCreate,
    postInjectCheck: postInject,
    savePipelineReadiness: erpCoreOperationalLinkPrecheck_savePipelineReadiness_(coreSheets, linkMatrix),
    businessDataWrite: false,
    deployAllowed: false,
    safety: erpCoreOperationalLinkPrecheck_safety_()
  };
  Logger.log('[ERP_CORE OPERATIONAL LINK PRECHECK RESULT] ' + JSON.stringify(result));
  return result;
}

function erpCoreOperationalLinkPrecheck_selfTest() {
  var fatal = [];
  var warnings = [];
  var safety = erpCoreOperationalLinkPrecheck_safety_();
  var expected = ERP_CORE_OPERATIONAL_LINK_PRECHECK_EXPECTED;

  if (expected.coreSheets.length !== 6) fatal.push('coreSheets expected count must be 6');
  if (expected.headerPolicyCount !== 67) fatal.push('HeaderPolicy expected count must be 67');
  if (expected.sheetPolicyCount !== 6) fatal.push('SheetPolicy expected count must be 6');
  if (safety.readOnly !== true) fatal.push('readOnly must be true');
  if (safety.noBusinessDataWrite !== true) fatal.push('business data write must remain blocked');
  if (safety.noDeployExecution !== true) fatal.push('deploy execution must remain blocked');

  var required = [
    'erpCoreOperationalLinkPrecheck_dryRun',
    'erpCoreOperationalLinkPrecheck_run',
    'erpCoreOperationalLinkPrecheck_selfTest',
    'erpCoreOperationalLinkPrecheck_openMaster_',
    'erpCoreOperationalLinkPrecheck_checkCoreSheet_'
  ];
  var missing = [];
  for (var i = 0; i < required.length; i++) {
    try { if (typeof this[required[i]] !== 'function') missing.push(required[i]); }
    catch (e) { missing.push(required[i]); }
  }
  if (missing.length) fatal.push('필수 함수 누락: ' + missing.join(', '));

  var result = {
    ok: fatal.length === 0,
    build: ERP_CORE_OPERATIONAL_LINK_PRECHECK_BUILD,
    fatal: fatal,
    warnings: warnings,
    expected: {
      sheetCount: expected.sheetCount,
      headerPolicyCount: expected.headerPolicyCount,
      sheetPolicyCount: expected.sheetPolicyCount
    },
    safety: safety
  };
  Logger.log('[ERP_CORE OPERATIONAL LINK PRECHECK SELFTEST] ' + JSON.stringify(result));
  return result;
}

function erpCoreOperationalLinkPrecheck_openMaster_() {
  if (typeof erpCoreActualCreateDedicatedDraft_openMaster_ === 'function') return erpCoreActualCreateDedicatedDraft_openMaster_();
  if (typeof erpCore_getMasterSpreadsheet_ === 'function') return erpCore_getMasterSpreadsheet_();
  throw new Error('MASTER_CONNECTOR_NOT_FOUND');
}

function erpCoreOperationalLinkPrecheck_checkCoreSheet_(ss, spec) {
  var sh = ss.getSheetByName(spec.sheetName);
  var fatal = [];
  var warnings = [];
  var headers = [];
  var headerMap = {};
  var duplicateHeaders = [];
  var missingHeaders = [];
  var dataRowCount = 0;

  if (!sh) {
    fatal.push('시트 없음');
  } else {
    var lastCol = sh.getLastColumn();
    var lastRow = sh.getLastRow();
    dataRowCount = Math.max(0, lastRow - 1);
    if (lastCol > 0) {
      headers = sh.getRange(1, 1, 1, lastCol).getValues()[0].map(function(v){ return String(v || '').trim(); });
    }
    duplicateHeaders = erpCoreOperationalLinkPrecheck_findDuplicates_(headers);
    headerMap = erpCoreOperationalLinkPrecheck_buildHeaderMap_(headers);
    for (var i = 0; i < spec.required.length; i++) {
      if (!headerMap[spec.required[i]]) missingHeaders.push(spec.required[i]);
    }
    if (duplicateHeaders.length) fatal.push('중복 헤더 존재');
    if (missingHeaders.length) fatal.push('필수 헤더 누락');
    if (dataRowCount > 0) warnings.push('실무 데이터 행이 존재합니다. 현재 단계에서는 원칙적으로 빈 시트가 권장됩니다. dataRowCount=' + dataRowCount);
  }

  return {
    ok: fatal.length === 0,
    key: spec.key,
    sheetName: spec.sheetName,
    exists: !!sh,
    primaryId: spec.primaryId,
    expectedHeaderCount: spec.required.length,
    actualHeaderCount: headers.length,
    dataRowCount: dataRowCount,
    missingHeaders: missingHeaders,
    duplicateHeaders: duplicateHeaders,
    headerMapBuild: fatal.length === 0 ? 'PASS' : 'FAIL',
    links: erpCoreOperationalLinkPrecheck_checkLinks_(headerMap, spec.links),
    statusHeaders: erpCoreOperationalLinkPrecheck_checkLinks_(headerMap, ERP_CORE_OPERATIONAL_LINK_PRECHECK_EXPECTED.statusHeaders),
    auditHeaders: erpCoreOperationalLinkPrecheck_checkLinks_(headerMap, ERP_CORE_OPERATIONAL_LINK_PRECHECK_EXPECTED.auditHeaders),
    fatal: fatal,
    warnings: warnings
  };
}

function erpCoreOperationalLinkPrecheck_checkPolicyMeta_(ss) {
  var hp = erpCoreOperationalLinkPrecheck_checkPolicySheet_(ss, 'HeaderPolicy', 'HEADER', ERP_CORE_OPERATIONAL_LINK_PRECHECK_EXPECTED.headerPolicyCount);
  var sp = erpCoreOperationalLinkPrecheck_checkPolicySheet_(ss, 'SheetPolicy', 'SHEET', ERP_CORE_OPERATIONAL_LINK_PRECHECK_EXPECTED.sheetPolicyCount);
  return { headerPolicy: hp, sheetPolicy: sp };
}

function erpCoreOperationalLinkPrecheck_checkPolicySheet_(ss, sheetName, prefix, expectedCount) {
  var sh = ss.getSheetByName(sheetName);
  var fatal = [];
  var missingHeaders = [];
  var duplicatePolicyIds = [];
  var foundRowCount = 0;
  var policyIds = [];
  var requiredHeaders = ['policyId','sheetName','policyStatus','sourceBuild'];

  if (!sh) {
    fatal.push('정책 시트 없음');
  } else {
    var lastCol = sh.getLastColumn();
    var lastRow = sh.getLastRow();
    var headers = lastCol > 0 ? sh.getRange(1, 1, 1, lastCol).getValues()[0].map(function(v){ return String(v || '').trim(); }) : [];
    var headerMap = erpCoreOperationalLinkPrecheck_buildHeaderMap_(headers);
    for (var r = 0; r < requiredHeaders.length; r++) {
      if (!headerMap[requiredHeaders[r]]) missingHeaders.push(requiredHeaders[r]);
    }
    if (missingHeaders.length) fatal.push('정책 시트 필수 헤더 누락');
    if (lastRow > 1 && headerMap.policyId) {
      var values = sh.getRange(2, headerMap.policyId, lastRow - 1, 1).getValues();
      for (var i = 0; i < values.length; i++) {
        var id = String(values[i][0] || '').trim();
        if (id.indexOf(prefix + '|') === 0) policyIds.push(id);
      }
    }
    foundRowCount = policyIds.length;
    duplicatePolicyIds = erpCoreOperationalLinkPrecheck_findDuplicates_(policyIds);
    if (foundRowCount !== expectedCount) fatal.push('정책 row 수 불일치');
    if (duplicatePolicyIds.length) fatal.push('policyId 중복');
  }

  return {
    ok: fatal.length === 0,
    sheetName: sheetName,
    exists: !!sh,
    expectedRowCount: expectedCount,
    foundRowCount: foundRowCount,
    missingHeaders: missingHeaders,
    duplicatePolicyIds: duplicatePolicyIds,
    fatal: fatal
  };
}

function erpCoreOperationalLinkPrecheck_buildLinkMatrix_(coreSheets) {
  var matrix = [];
  for (var i = 0; i < coreSheets.length; i++) {
    var s = coreSheets[i];
    matrix.push({
      sheetName: s.sheetName,
      primaryId: s.primaryId,
      idReady: s.missingHeaders.indexOf(s.primaryId) < 0,
      linksReady: s.links.ok,
      statusReady: s.statusHeaders.ok,
      auditReady: s.auditHeaders.ok,
      headerMapReady: s.headerMapBuild === 'PASS'
    });
  }
  return matrix;
}

function erpCoreOperationalLinkPrecheck_savePipelineReadiness_(coreSheets, linkMatrix) {
  var fatal = [];
  for (var i = 0; i < linkMatrix.length; i++) {
    var m = linkMatrix[i];
    if (!m.idReady) fatal.push(m.sheetName + ': primaryId not ready');
    if (!m.linksReady) fatal.push(m.sheetName + ': link IDs not ready');
    if (!m.statusReady) fatal.push(m.sheetName + ': status headers not ready');
    if (!m.auditReady) fatal.push(m.sheetName + ': audit headers not ready');
    if (!m.headerMapReady) fatal.push(m.sheetName + ': headerMap not ready');
  }
  return {
    ok: fatal.length === 0,
    mode: 'READ_ONLY_PRECHECK',
    saveEnabled: false,
    actualBusinessWrite: false,
    requiredSaveOrder: ['requiredValueCheck','formatCheck','permissionCheck','duplicateCheck','save','auditLog'],
    fatal: fatal
  };
}

function erpCoreOperationalLinkPrecheck_checkLinks_(headerMap, names) {
  var missing = [];
  for (var i = 0; i < names.length; i++) {
    if (!headerMap[names[i]]) missing.push(names[i]);
  }
  return { ok: missing.length === 0, required: names.slice(), missing: missing };
}

function erpCoreOperationalLinkPrecheck_buildHeaderMap_(headers) {
  var map = {};
  for (var i = 0; i < headers.length; i++) {
    var h = String(headers[i] || '').trim();
    if (h) map[h] = i + 1;
  }
  return map;
}

function erpCoreOperationalLinkPrecheck_findDuplicates_(list) {
  var seen = {};
  var dup = [];
  for (var i = 0; i < list.length; i++) {
    var v = String(list[i] || '').trim();
    if (!v) continue;
    var key = v.toLowerCase();
    if (seen[key] && dup.indexOf(v) < 0) dup.push(v);
    seen[key] = true;
  }
  return dup;
}
