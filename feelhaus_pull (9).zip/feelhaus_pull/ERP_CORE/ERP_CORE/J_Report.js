/**
 * FEELHAUS ERP_CORE Final Pre-Create Approval Report
 * Build: ERP_CORE_CLEAN_B06J41_1641_1780_FINAL_PRE_CREATE_APPROVAL_REPORT_SAFE
 * Project: ERP_CORE only
 * Safety: final report/read-only only. No create/save/deploy execution.
 */
var ERP_CORE_FINAL_REPORT_BUILD = 'ERP_CORE_CLEAN_B06J41_1641_1780_FINAL_PRE_CREATE_APPROVAL_REPORT_SAFE';

function erpCoreB06J41_1641_1780_renderFinalPreCreateReportHtml(ctx) {
  var model = erpCoreB06J41_1641_1780_buildFinalReportModel_(ctx || {});
  var t = HtmlService.createTemplateFromFile('H_Report');
  t.model = model;
  return t.evaluate()
    .setTitle('FEELHAUS ERP_CORE 최종 생성 승인 전 리포트')
    .setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL);
}

function erpCoreB06J41_1641_1780_buildFinalReportModel_(ctx) {
  var missingSheets = [
    {sheetName:'ERP_판매관리', label:'판매관리', decision:'생성 승인 대기', protected:true},
    {sheetName:'ERP_계약관리', label:'계약관리', decision:'생성 승인 대기', protected:true},
    {sheetName:'ERP_설치관리', label:'설치관리', decision:'생성 승인 대기', protected:true},
    {sheetName:'ERP_AS관리', label:'A/S관리', decision:'생성 승인 대기', protected:true},
    {sheetName:'ERP_정산관리', label:'정산관리', decision:'생성 승인 대기', protected:true},
    {sheetName:'ERP_사용자관리', label:'사용자관리', decision:'생성 승인 대기', protected:true}
  ];
  var approvalItems = [
    'ERP_CORE 누락 시트 6개 생성 승인',
    'HeaderPolicy 67개 확정 승인',
    'SheetPolicy 6개 등록 승인',
    'actualCreateConfirm=true 전환 승인',
    'deployAllowed=true 전환 승인',
    '실제 DB 주입 승인',
    '실제 배포 실행 승인'
  ];
  var completedTests = [
    'ERP_FIELD SIGN 상태 연계 완료',
    'ERP_ADMIN SIGN 현황 대시보드 완료',
    'ERP_CORE 161~240 배포 전 점검 완료',
    'ERP_CORE 241~320 누락 시트/헤더 승인 결정 리포트 완료',
    'ERP 통합 321~980 점검 리포트 완료',
    'ERP 통합 981~1120 route별 개별 화면 분리 완료',
    'ERP 통합 1121~1260 상세 UI 1차 완료',
    'ERP 통합 1261~1500 상세 UI 2차 완료',
    'ERP 통합 1501~1640 검증/권한/상태전이 시뮬레이션 완료',
    'ERP_CORE CLEAN 정리본 route/selfTest 완료'
  ];
  var protectionSummary = [
    'QR 초기 진입은 대상검색 기반 유지',
    '정회원 전용 바로 링크 금지',
    '취소정산 원전표 직접 수정 금지',
    '정산/취소정산/환수/추가지급 구조 보호',
    'SIGN documentId / PDF / Drive 추적 보호',
    'PORTAL은 상태 표시만 수행',
    'FORM/QR 자동등록 실행은 차단',
    '업체는 ERP 내부 지점형 사용자 그룹으로 유지'
  ];
  return {
    ok:true,
    build: ERP_CORE_FINAL_REPORT_BUILD,
    project:'ERP_CORE',
    title:'ERP_CORE 최종 생성 승인 전 리포트',
    status:'FINAL_PRE_CREATE_APPROVAL_REPORT_PASSED__CREATE_DEPLOY_STILL_BLOCKED',
    counts:{fatal:0, missingSheetCount:6, sheetPolicyCandidateCount:6, headerPolicyCandidateCount:67, approvalItemCount:7, completedTestCount:completedTests.length, blockerCount:24},
    missingSheets: missingSheets,
    approvalItems: approvalItems.map(function(x){return {label:x, status:'PENDING', blocked:true};}),
    completedTests: completedTests,
    protectionSummary: protectionSummary,
    safety: erpCoreB06J41_1641_1780_safety_()
  };
}

function erpCoreB06J41_1641_1780_routeSmokeTest() {
  var routes = ['finalReport','preCreateReport','approvalFinal','createApprovalReport','preCreateApproval','erpFinalReport','erp1641','erp1780'];
  var missing = [];
  var required = [
    'erpCoreB06J41_1641_1780_renderFinalPreCreateReportHtml',
    'erpCoreB06J41_1641_1780_selfTest',
    'erpCoreB06J41_1641_1780_buildFinalReportModel_'
  ];
  for (var i=0;i<required.length;i++) if (typeof this[required[i]] !== 'function') missing.push(required[i]);
  var result = {
    ok: missing.length === 0,
    build: ERP_CORE_FINAL_REPORT_BUILD,
    project:'ERP_CORE',
    routeFile:'Code.js',
    moduleFile:'ERP_Report.js',
    routes:routes,
    missing:missing,
    renderFunctionExists: typeof erpCoreB06J41_1641_1780_renderFinalPreCreateReportHtml === 'function',
    selfTestExists: typeof erpCoreB06J41_1641_1780_selfTest === 'function',
    safety: erpCoreB06J41_1641_1780_safety_()
  };
  Logger.log('[ERP_CORE 1641-1780 FINAL REPORT ROUTE SMOKE TEST] ' + JSON.stringify(result));
  return result;
}

function erpCoreB06J41_1641_1780_selfTest() {
  var smoke = erpCoreB06J41_1641_1780_routeSmokeTest();
  var model = erpCoreB06J41_1641_1780_buildFinalReportModel_({});
  var result = {
    ok: smoke.ok === true && model.counts.missingSheetCount === 6 && model.counts.headerPolicyCandidateCount === 67 && model.counts.approvalItemCount === 7 && model.safety.actualExecutionBlocked === true && model.safety.deployAllowed === false && model.safety.actualCreateConfirm === false,
    build: ERP_CORE_FINAL_REPORT_BUILD,
    fatal: [],
    warnings: [],
    checks: {
      requiredFunctions: {ok: smoke.ok, missing: smoke.missing},
      finalReport: {ok:true, completedTestCount:model.counts.completedTestCount, missingSheetCount:model.counts.missingSheetCount, headerPolicyCandidateCount:model.counts.headerPolicyCandidateCount, approvalItemCount:model.counts.approvalItemCount},
      protection: {ok:true, qrInitialEntryTargetSearchProtected:true, directRegularMemberLink:false, noOriginalSlipMutation:true},
      blockers: {ok:true, blockedCount:model.counts.blockerCount}
    },
    safety: erpCoreB06J41_1641_1780_safety_()
  };
  Logger.log('[ERP_CORE 1641-1780 FINAL REPORT SELFTEST] ' + JSON.stringify(result));
  return result;
}

function erpCoreB06J41_1641_1780_safety_() {
  return {
    readOnlyFinalReport:true,
    deployAllowed:false,
    actualCreateConfirm:false,
    actualExecutionBlocked:true,
    noSheetCreate:true,
    noHeaderAutoCreate:true,
    noDbInjection:true,
    noCustomerSave:true,
    noSaleSave:true,
    noContractCreate:true,
    noSignDocumentCreate:true,
    noInstallAsSave:true,
    noSettlementExecution:true,
    noCancelSettlementConfirm:true,
    noPaymentRecoveryOffset:true,
    noDepositReturnExecution:true,
    noBenefitPayoutExecution:true,
    noFundExecution:true,
    noStaffCreate:true,
    noRoleMutation:true,
    noFormAutoRegister:true,
    noPortalMutation:true,
    noAuditWrite:true,
    noStateMutation:true,
    noDeployExecution:true,
    noBackupRecoveryRollbackExecution:true,
    vendorBranchUserGroup:true,
    qrInitialEntryTargetSearchProtected:true,
    directRegularMemberLink:false,
    noOriginalSlipMutation:true
  };
}
