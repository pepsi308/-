/**
 * FEELHAUS ERP_CORE Save To Deploy Precheck Bundle
 * Build: ERP_CORE_SAVE_TO_DEPLOY_PRECHECK_BUNDLE_SAFE
 * Project: ERP_CORE only
 * Purpose:
 *  - Bundle remaining pre-deploy validation steps after ERP_CORE core sheets/policy meta sync.
 *  - Simulate save pipeline and sample business-save dry run with no writes.
 *  - Optionally write one TEST chain only after explicit approval code.
 *  - Prepare deploy pre-approval check without executing deploy.
 * Safety:
 *  - deploy execution always blocked
 *  - operational/customer/sale/contract/install/AS/settlement real data blocked
 *  - actual write function only permits TEST records with TEST_* IDs and explicit approval
 */
var ERP_CORE_SAVE_TO_DEPLOY_BUNDLE_BUILD = 'ERP_CORE_SAVE_TO_DEPLOY_PRECHECK_BUNDLE_SAFE';
var ERP_CORE_SAVE_TO_DEPLOY_TEST_SAVE_APPROVAL_CODE = 'ERP_CORE_TEST_RECORD_SAVE_APPROVED_ONE_CHAIN_ONLY';

var ERP_CORE_SAVE_TO_DEPLOY_EXPECTED = {
  sheetCount: 6,
  headerPolicyCount: 67,
  sheetPolicyCount: 6,
  coreSheets: [
    { key:'sales', sheetName:'ERP_판매관리', primaryId:'saleId', required:['eventId','vendorId','customerId','status','statusReason','createdAt','createdBy','updatedAt','updatedBy','saleId'], links:['eventId','vendorId','customerId'] },
    { key:'contracts', sheetName:'ERP_계약관리', primaryId:'contractId', required:['eventId','vendorId','customerId','status','statusReason','createdAt','createdBy','updatedAt','updatedBy','contractId','saleId'], links:['saleId','eventId','vendorId','customerId'] },
    { key:'installs', sheetName:'ERP_설치관리', primaryId:'installId', required:['eventId','vendorId','customerId','status','statusReason','createdAt','createdBy','updatedAt','updatedBy','installId','saleId','contractId'], links:['contractId','saleId','eventId','vendorId','customerId'] },
    { key:'as', sheetName:'ERP_AS관리', primaryId:'asId', required:['eventId','vendorId','customerId','status','statusReason','createdAt','createdBy','updatedAt','updatedBy','asId','saleId'], links:['saleId','eventId','vendorId','customerId'] },
    { key:'settlements', sheetName:'ERP_정산관리', primaryId:'settlementId', required:['eventId','vendorId','customerId','status','statusReason','createdAt','createdBy','updatedAt','updatedBy','settlementId','saleId','contractId'], links:['saleId','contractId','eventId','vendorId','customerId'] },
    { key:'users', sheetName:'ERP_사용자관리', primaryId:'userId', required:['eventId','vendorId','customerId','status','statusReason','createdAt','createdBy','updatedAt','updatedBy','userId','roleCode'], links:['vendorId','roleCode'] }
  ],
  saveOrder: ['requiredValueCheck','formatCheck','permissionCheck','duplicateCheck','save','auditLog']
};

function erpCoreSaveToDeployBundle_safety_() {
  return {
    build: ERP_CORE_SAVE_TO_DEPLOY_BUNDLE_BUILD,
    bundleMode: true,
    deployAllowed: false,
    noDeployExecution: true,
    noPolicyWrite: true,
    noSheetCreate: true,
    noHeaderAutoAdd: true,
    noDeleteSheet: true,
    noExistingDataClear: true,
    noCustomerSave: true,
    noOperationalSaleSave: true,
    noOperationalContractCreate: true,
    noOperationalInstallAsSave: true,
    noOperationalSettlementExecution: true,
    noCancelSettlementConfirm: true,
    noSignDocumentCreate: true,
    noFormAutoRegister: true,
    noRoleMutation: true,
    testRecordOnlyWriteGate: true,
    maxActualTestRowsPerRun: 6,
    headerMapRequired: true,
    idBasedConnectionRequired: true,
    vendorBranchUserGroup: true,
    qrInitialEntryTargetSearchProtected: true,
    directRegularMemberLink: false,
    noOriginalSlipMutation: true
  };
}

function erpCoreSaveToDeployBundle_dryRun(ctx) {
  ctx = ctx || {};
  var result = {
    ok: true,
    build: ERP_CORE_SAVE_TO_DEPLOY_BUNDLE_BUILD,
    mode: 'DRY_RUN_ONLY',
    message: '저장 시뮬레이션부터 배포 전 승인 준비까지 통합 점검 계획만 확인합니다. 실제 저장/배포는 없습니다.',
    stages: [
      'SAVE_PIPELINE_SIMULATION_READ_ONLY',
      'BUSINESS_SAVE_DRY_RUN_NO_WRITE',
      'TEST_RECORD_ACTUAL_SAVE_APPROVAL_GATE',
      'TEST_RECORD_POST_SAVE_CHECK',
      'DEPLOY_PRE_APPROVAL_CHECK_NO_DEPLOY'
    ],
    expected: {
      sheetCount: ERP_CORE_SAVE_TO_DEPLOY_EXPECTED.sheetCount,
      headerPolicyCount: ERP_CORE_SAVE_TO_DEPLOY_EXPECTED.headerPolicyCount,
      sheetPolicyCount: ERP_CORE_SAVE_TO_DEPLOY_EXPECTED.sheetPolicyCount,
      sheets: ERP_CORE_SAVE_TO_DEPLOY_EXPECTED.coreSheets.map(function(s){ return s.sheetName; })
    },
    fatal: [],
    warnings: [],
    safety: erpCoreSaveToDeployBundle_safety_(),
    ctx: ctx
  };
  Logger.log('[ERP_CORE SAVE TO DEPLOY BUNDLE DRY RUN] ' + JSON.stringify(result));
  return result;
}

function erpCoreSaveToDeployBundle_runReadOnlyPrechecks(ctx) {
  ctx = ctx || {};
  var simulation = erpCoreSaveToDeployBundle_savePipelineSimulation(ctx);
  var drySave = erpCoreSaveToDeployBundle_businessSaveDryRun(ctx);
  var deployPre = erpCoreSaveToDeployBundle_deployPreApprovalCheck(ctx);
  var fatal = [];
  if (!simulation.ok) fatal.push('저장 파이프라인 시뮬레이션 실패');
  if (!drySave.ok) fatal.push('샘플 저장 Dry Run 실패');
  if (!deployPre.ok) fatal.push('배포 전 승인 준비 점검 실패');
  var result = {
    ok: fatal.length === 0,
    build: ERP_CORE_SAVE_TO_DEPLOY_BUNDLE_BUILD,
    mode: 'READ_ONLY_BUNDLE_PRECHECKS',
    fatal: fatal,
    warnings: [],
    simulation: simulation,
    businessSaveDryRun: drySave,
    deployPreApproval: deployPre,
    businessDataWrite: false,
    deployAllowed: false,
    safety: erpCoreSaveToDeployBundle_safety_()
  };
  Logger.log('[ERP_CORE SAVE TO DEPLOY READ ONLY BUNDLE RESULT] ' + JSON.stringify(result));
  return result;
}

function erpCoreSaveToDeployBundle_savePipelineSimulation(ctx) {
  ctx = ctx || {};
  var fatal = [];
  var warnings = [];
  var precheck = erpCoreSaveToDeployBundle_callOperationalPrecheck_();
  if (!precheck.ok) fatal.push('운영 연결 사전점검 실패');

  var pipeline = [];
  for (var i = 0; i < ERP_CORE_SAVE_TO_DEPLOY_EXPECTED.saveOrder.length; i++) {
    pipeline.push({ order: i + 1, step: ERP_CORE_SAVE_TO_DEPLOY_EXPECTED.saveOrder[i], mode: 'SIMULATION_ONLY', ok: true });
  }

  var sample = erpCoreSaveToDeployBundle_buildSampleChain_(ctx.runId || 'SIM_' + erpCoreSaveToDeployBundle_timestamp_());
  var requiredCheck = erpCoreSaveToDeployBundle_validateRequired_(sample);
  var formatCheck = erpCoreSaveToDeployBundle_validateFormat_(sample);
  var permissionCheck = { ok: true, mode: 'SIMULATION_ONLY', requiredRole: 'HQ_OR_APPROVED_TESTER', actualPermissionMutation: false };
  var duplicateCheck = { ok: true, mode: 'SIMULATION_ONLY', actualScan: false, note: '실제 중복 스캔은 BusinessSaveDryRun 또는 TestSave 단계에서 수행' };
  var saveReady = { ok: true, mode: 'NO_WRITE', appendRow: false, setValues: false };
  var auditReady = { ok: true, headers: ['createdAt','createdBy','updatedAt','updatedBy'], actualAuditLogWrite: false };

  if (!requiredCheck.ok) fatal.push('필수값 시뮬레이션 실패');
  if (!formatCheck.ok) fatal.push('형식 시뮬레이션 실패');

  var result = {
    ok: fatal.length === 0,
    build: ERP_CORE_SAVE_TO_DEPLOY_BUNDLE_BUILD,
    mode: 'SAVE_PIPELINE_SIMULATION_READ_ONLY',
    checkedAt: new Date().toISOString(),
    fatal: fatal,
    warnings: warnings,
    operationalPrecheckOk: precheck.ok,
    pipelineOrder: pipeline,
    requiredValueCheck: requiredCheck,
    formatCheck: formatCheck,
    permissionCheck: permissionCheck,
    duplicateCheck: duplicateCheck,
    saveReady: saveReady,
    auditReady: auditReady,
    businessDataWrite: false,
    deployAllowed: false,
    safety: erpCoreSaveToDeployBundle_safety_()
  };
  Logger.log('[ERP_CORE SAVE PIPELINE SIMULATION RESULT] ' + JSON.stringify(result));
  return result;
}

function erpCoreSaveToDeployBundle_businessSaveDryRun(ctx) {
  ctx = ctx || {};
  var fatal = [];
  var warnings = [];
  var ss = erpCoreSaveToDeployBundle_openMaster_();
  var runId = ctx.runId || 'DRY_' + erpCoreSaveToDeployBundle_timestamp_();
  var sample = erpCoreSaveToDeployBundle_buildSampleChain_(runId);
  var sheetChecks = [];
  var duplicateChecks = [];
  var rowsPreview = [];

  var requiredCheck = erpCoreSaveToDeployBundle_validateRequired_(sample);
  var formatCheck = erpCoreSaveToDeployBundle_validateFormat_(sample);
  if (!requiredCheck.ok) fatal.push('필수값 검사 실패');
  if (!formatCheck.ok) fatal.push('형식 검사 실패');

  for (var i = 0; i < ERP_CORE_SAVE_TO_DEPLOY_EXPECTED.coreSheets.length; i++) {
    var spec = ERP_CORE_SAVE_TO_DEPLOY_EXPECTED.coreSheets[i];
    var sh = ss.getSheetByName(spec.sheetName);
    var check = erpCoreSaveToDeployBundle_checkSheetReady_(sh, spec);
    sheetChecks.push(check);
    if (!check.ok) fatal.push(spec.sheetName + ' 저장 준비 실패');
    var d = check.ok ? erpCoreSaveToDeployBundle_checkDuplicatePrimary_(sh, check.headerMap, spec.primaryId, sample[spec.primaryId]) : { ok:false, skipped:true };
    duplicateChecks.push({ sheetName: spec.sheetName, primaryId: spec.primaryId, value: sample[spec.primaryId], duplicateCheck: d });
    if (d.ok === false && !d.skipped) fatal.push(spec.sheetName + ' 중복 ID 존재: ' + sample[spec.primaryId]);
    if (check.ok) rowsPreview.push({ sheetName: spec.sheetName, mode:'DRY_RUN_NO_WRITE', row: erpCoreSaveToDeployBundle_buildRowObject_(spec, sample, check.headers) });
  }

  var result = {
    ok: fatal.length === 0,
    build: ERP_CORE_SAVE_TO_DEPLOY_BUNDLE_BUILD,
    mode: 'BUSINESS_SAVE_DRY_RUN_NO_WRITE',
    checkedAt: new Date().toISOString(),
    runId: runId,
    fatal: fatal,
    warnings: warnings,
    requiredValueCheck: requiredCheck,
    formatCheck: formatCheck,
    permissionCheck: { ok:true, mode:'DRY_RUN_ONLY', actualPermissionMutation:false },
    duplicateChecks: duplicateChecks,
    rowsPreview: rowsPreview,
    actualWrite: false,
    businessDataWrite: false,
    deployAllowed: false,
    safety: erpCoreSaveToDeployBundle_safety_()
  };
  Logger.log('[ERP_CORE BUSINESS SAVE DRY RUN RESULT] ' + JSON.stringify(result));
  return result;
}

function erpCoreSaveToDeployBundle_testRecordActualSave(ctx) {
  ctx = ctx || {};
  var guard = erpCoreSaveToDeployBundle_checkTestSaveGuard_(ctx);
  if (!guard.ok) {
    var blocked = {
      ok: false,
      blocked: true,
      build: ERP_CORE_SAVE_TO_DEPLOY_BUNDLE_BUILD,
      action: 'TEST_RECORD_ACTUAL_SAVE_ONE_CHAIN_ONLY',
      reason: guard.reason,
      required: guard.required,
      safety: erpCoreSaveToDeployBundle_safety_()
    };
    Logger.log('[ERP_CORE TEST RECORD ACTUAL SAVE BLOCKED] ' + JSON.stringify(blocked));
    return blocked;
  }

  var ss = erpCoreSaveToDeployBundle_openMaster_();
  var runId = ctx.runId || 'TEST_' + erpCoreSaveToDeployBundle_timestamp_();
  var sample = erpCoreSaveToDeployBundle_buildSampleChain_(runId);
  var fatal = [];
  var warnings = [];
  var writes = [];

  var dry = erpCoreSaveToDeployBundle_businessSaveDryRun({ runId: runId });
  if (!dry.ok) fatal.push('저장 전 Dry Run 실패');

  if (fatal.length === 0) {
    for (var i = 0; i < ERP_CORE_SAVE_TO_DEPLOY_EXPECTED.coreSheets.length; i++) {
      var spec = ERP_CORE_SAVE_TO_DEPLOY_EXPECTED.coreSheets[i];
      var sh = ss.getSheetByName(spec.sheetName);
      var headers = erpCoreSaveToDeployBundle_getHeaders_(sh);
      var headerMap = erpCoreSaveToDeployBundle_buildHeaderMap_(headers);
      var duplicate = erpCoreSaveToDeployBundle_checkDuplicatePrimary_(sh, headerMap, spec.primaryId, sample[spec.primaryId]);
      if (!duplicate.ok) {
        fatal.push(spec.sheetName + ' 중복 ID 존재로 저장 중단: ' + sample[spec.primaryId]);
        break;
      }
      var row = erpCoreSaveToDeployBundle_buildRow_(headers, spec, sample);
      sh.appendRow(row);
      writes.push({ sheetName: spec.sheetName, primaryId: spec.primaryId, idValue: sample[spec.primaryId], mode: 'APPEND_TEST_RECORD_ONLY' });
    }
  }

  if (fatal.length === 0) {
    try {
      PropertiesService.getScriptProperties().setProperty('ERP_CORE_SAVE_TO_DEPLOY_LAST_TEST_RUN_ID', runId);
    } catch (e) {
      warnings.push('last test run id 저장 실패: ' + (e && e.message ? e.message : e));
    }
  }

  var post = fatal.length === 0 ? erpCoreSaveToDeployBundle_testRecordPostSaveCheck({ runId: runId }) : { ok:false, skipped:true };
  if (post.ok === false && !post.skipped) fatal.push('테스트 레코드 post-save 점검 실패');

  var result = {
    ok: fatal.length === 0,
    build: ERP_CORE_SAVE_TO_DEPLOY_BUNDLE_BUILD,
    action: 'TEST_RECORD_ACTUAL_SAVE_ONE_CHAIN_ONLY',
    runId: runId,
    testRecordOnly: true,
    writeCount: writes.length,
    writes: writes,
    fatal: fatal,
    warnings: warnings,
    postSaveCheck: post,
    businessDataWrite: true,
    operationalDataWrite: false,
    deployAllowed: false,
    safety: erpCoreSaveToDeployBundle_safety_()
  };
  Logger.log('[ERP_CORE TEST RECORD ACTUAL SAVE RESULT] ' + JSON.stringify(result));
  return result;
}

function erpCoreSaveToDeployBundle_testRecordPostSaveCheck(ctx) {
  ctx = ctx || {};
  var fatal = [];
  var warnings = [];
  var ss = erpCoreSaveToDeployBundle_openMaster_();
  var runId = ctx.runId || '';
  if (!runId) {
    try { runId = PropertiesService.getScriptProperties().getProperty('ERP_CORE_SAVE_TO_DEPLOY_LAST_TEST_RUN_ID') || ''; }
    catch (e) { warnings.push('last test run id 읽기 실패: ' + (e && e.message ? e.message : e)); }
  }
  if (!runId) fatal.push('점검할 runId 없음');

  var sample = runId ? erpCoreSaveToDeployBundle_buildSampleChain_(runId) : {};
  var checks = [];
  if (runId) {
    for (var i = 0; i < ERP_CORE_SAVE_TO_DEPLOY_EXPECTED.coreSheets.length; i++) {
      var spec = ERP_CORE_SAVE_TO_DEPLOY_EXPECTED.coreSheets[i];
      var sh = ss.getSheetByName(spec.sheetName);
      var headers = erpCoreSaveToDeployBundle_getHeaders_(sh);
      var headerMap = erpCoreSaveToDeployBundle_buildHeaderMap_(headers);
      var found = erpCoreSaveToDeployBundle_findRowsByPrimary_(sh, headerMap, spec.primaryId, sample[spec.primaryId]);
      var check = { sheetName: spec.sheetName, primaryId: spec.primaryId, idValue: sample[spec.primaryId], foundCount: found.length, rows: found, ok: found.length === 1 };
      if (!check.ok) fatal.push(spec.sheetName + ' 테스트 레코드 발견 수 불일치: ' + found.length);
      checks.push(check);
    }
  }

  var result = {
    ok: fatal.length === 0,
    build: ERP_CORE_SAVE_TO_DEPLOY_BUNDLE_BUILD,
    mode: 'TEST_RECORD_POST_SAVE_CHECK',
    checkedAt: new Date().toISOString(),
    runId: runId,
    fatal: fatal,
    warnings: warnings,
    checks: checks,
    businessDataWrite: false,
    deployAllowed: false,
    safety: erpCoreSaveToDeployBundle_safety_()
  };
  Logger.log('[ERP_CORE TEST RECORD POST SAVE CHECK RESULT] ' + JSON.stringify(result));
  return result;
}

function erpCoreSaveToDeployBundle_deployPreApprovalCheck(ctx) {
  ctx = ctx || {};
  var fatal = [];
  var warnings = [];
  var op = erpCoreSaveToDeployBundle_callOperationalPrecheck_();
  if (!op.ok) fatal.push('운영 연결 사전점검 실패');
  var lastRunId = '';
  try { lastRunId = PropertiesService.getScriptProperties().getProperty('ERP_CORE_SAVE_TO_DEPLOY_LAST_TEST_RUN_ID') || ''; }
  catch (e) { warnings.push('last test run id 읽기 실패: ' + (e && e.message ? e.message : e)); }

  var postTest = lastRunId ? erpCoreSaveToDeployBundle_testRecordPostSaveCheck({ runId: lastRunId }) : { ok:false, skipped:true, reason:'아직 테스트 레코드 실제 저장이 없습니다.' };
  if (lastRunId && !postTest.ok) fatal.push('테스트 레코드 저장 후 점검 실패');

  var result = {
    ok: fatal.length === 0,
    build: ERP_CORE_SAVE_TO_DEPLOY_BUNDLE_BUILD,
    mode: 'DEPLOY_PRE_APPROVAL_CHECK_NO_DEPLOY',
    checkedAt: new Date().toISOString(),
    fatal: fatal,
    warnings: warnings,
    operationalLinkPrecheck: { ok: op.ok, fatal: op.fatal || [] },
    testRecordPostSaveCheck: postTest,
    deployPreApproval: {
      readyForDeployApprovalReview: fatal.length === 0,
      deployAllowed: false,
      actualDeployExecution: false,
      requiredBeforeDeploy: ['CONTROL final read-only check','UI route smoke','permission filter smoke','state transition simulation','backup/rollback confirmation']
    },
    businessDataWrite: false,
    deployAllowed: false,
    safety: erpCoreSaveToDeployBundle_safety_()
  };
  Logger.log('[ERP_CORE DEPLOY PRE APPROVAL CHECK RESULT] ' + JSON.stringify(result));
  return result;
}

function erpCoreSaveToDeployBundle_selfTest() {
  var fatal = [];
  var safety = erpCoreSaveToDeployBundle_safety_();
  if (ERP_CORE_SAVE_TO_DEPLOY_EXPECTED.coreSheets.length !== 6) fatal.push('coreSheets count must be 6');
  if (ERP_CORE_SAVE_TO_DEPLOY_EXPECTED.headerPolicyCount !== 67) fatal.push('HeaderPolicy count must be 67');
  if (ERP_CORE_SAVE_TO_DEPLOY_EXPECTED.sheetPolicyCount !== 6) fatal.push('SheetPolicy count must be 6');
  if (safety.noDeployExecution !== true) fatal.push('deploy must remain blocked');
  if (safety.testRecordOnlyWriteGate !== true) fatal.push('test record write gate required');

  var result = {
    ok: fatal.length === 0,
    build: ERP_CORE_SAVE_TO_DEPLOY_BUNDLE_BUILD,
    fatal: fatal,
    warnings: [],
    expected: {
      sheetCount: ERP_CORE_SAVE_TO_DEPLOY_EXPECTED.sheetCount,
      headerPolicyCount: ERP_CORE_SAVE_TO_DEPLOY_EXPECTED.headerPolicyCount,
      sheetPolicyCount: ERP_CORE_SAVE_TO_DEPLOY_EXPECTED.sheetPolicyCount
    },
    safety: safety
  };
  Logger.log('[ERP_CORE SAVE TO DEPLOY BUNDLE SELFTEST] ' + JSON.stringify(result));
  return result;
}

function erpCoreSaveToDeployBundle_checkTestSaveGuard_(ctx) {
  var required = {
    testSaveConfirm: true,
    approvalCode: ERP_CORE_SAVE_TO_DEPLOY_TEST_SAVE_APPROVAL_CODE,
    businessDataWriteAllowed: true,
    deployAllowed: false,
    testRecordOnly: true
  };
  if (ctx.testSaveConfirm !== true) return { ok:false, reason:'testSaveConfirm=true 승인이 없습니다.', required: required };
  if (ctx.approvalCode !== ERP_CORE_SAVE_TO_DEPLOY_TEST_SAVE_APPROVAL_CODE) return { ok:false, reason:'승인코드가 일치하지 않습니다.', required: required };
  if (ctx.businessDataWriteAllowed !== true) return { ok:false, reason:'테스트 레코드 저장을 위한 businessDataWriteAllowed=true 승인이 없습니다.', required: required };
  if (ctx.deployAllowed !== false) return { ok:false, reason:'deployAllowed=false 상태에서만 테스트 저장이 가능합니다.', required: required };
  if (ctx.testRecordOnly !== true) return { ok:false, reason:'testRecordOnly=true 조건이 필요합니다.', required: required };
  return { ok:true, required: required };
}

function erpCoreSaveToDeployBundle_callOperationalPrecheck_() {
  try {
    if (typeof erpCoreOperationalLinkPrecheck_run === 'function') return erpCoreOperationalLinkPrecheck_run({ calledBy: ERP_CORE_SAVE_TO_DEPLOY_BUNDLE_BUILD });
    return { ok:false, fatal:['erpCoreOperationalLinkPrecheck_run 함수 없음'] };
  } catch (e) {
    return { ok:false, fatal:['운영 연결 사전점검 호출 오류: ' + (e && e.message ? e.message : e)] };
  }
}

function erpCoreSaveToDeployBundle_openMaster_() {
  if (typeof erpCoreActualCreateDedicatedDraft_openMaster_ === 'function') return erpCoreActualCreateDedicatedDraft_openMaster_();
  if (typeof erpCoreOperationalLinkPrecheck_openMaster_ === 'function') return erpCoreOperationalLinkPrecheck_openMaster_();
  if (typeof erpCore_getMasterSpreadsheet_ === 'function') return erpCore_getMasterSpreadsheet_();
  throw new Error('MASTER_CONNECTOR_NOT_FOUND');
}

function erpCoreSaveToDeployBundle_buildSampleChain_(runId) {
  var now = new Date().toISOString();
  var by = erpCoreSaveToDeployBundle_actor_();
  var base = {
    eventId: 'EVT_TEST_SAFE',
    vendorId: 'VENDOR_TEST_SAFE',
    customerId: 'CUS_TEST_SAFE',
    status: 'TEST_SAVED',
    statusReason: 'SAFE_TEST_RECORD|' + runId,
    createdAt: now,
    createdBy: by,
    updatedAt: now,
    updatedBy: by,
    saleId: 'SALE_' + runId,
    contractId: 'CONTRACT_' + runId,
    installId: 'INSTALL_' + runId,
    asId: 'AS_' + runId,
    settlementId: 'SETTLEMENT_' + runId,
    userId: 'USER_' + runId,
    roleCode: 'TEST_ROLE'
  };
  return base;
}

function erpCoreSaveToDeployBundle_actor_() {
  try {
    var email = Session.getActiveUser().getEmail();
    return email || 'system';
  } catch (e) {
    return 'system';
  }
}

function erpCoreSaveToDeployBundle_validateRequired_(sample) {
  var missing = [];
  var required = ['eventId','vendorId','customerId','status','statusReason','createdAt','createdBy','updatedAt','updatedBy','saleId','contractId','installId','asId','settlementId','userId','roleCode'];
  for (var i = 0; i < required.length; i++) {
    if (!sample[required[i]]) missing.push(required[i]);
  }
  return { ok: missing.length === 0, missing: missing };
}

function erpCoreSaveToDeployBundle_validateFormat_(sample) {
  var fatal = [];
  var idFields = ['eventId','vendorId','customerId','saleId','contractId','installId','asId','settlementId','userId'];
  for (var i = 0; i < idFields.length; i++) {
    var v = String(sample[idFields[i]] || '');
    if (!/^[A-Z0-9_]+$/.test(v)) fatal.push(idFields[i] + ' 형식 오류: ' + v);
  }
  if (sample.status !== 'TEST_SAVED') fatal.push('status must be TEST_SAVED');
  if (String(sample.statusReason || '').indexOf('SAFE_TEST_RECORD|') !== 0) fatal.push('statusReason must start with SAFE_TEST_RECORD|');
  return { ok: fatal.length === 0, fatal: fatal };
}

function erpCoreSaveToDeployBundle_checkSheetReady_(sh, spec) {
  var fatal = [];
  var headers = [];
  var headerMap = {};
  var missingHeaders = [];
  var duplicateHeaders = [];
  if (!sh) {
    fatal.push('시트 없음');
  } else {
    headers = erpCoreSaveToDeployBundle_getHeaders_(sh);
    headerMap = erpCoreSaveToDeployBundle_buildHeaderMap_(headers);
    duplicateHeaders = erpCoreSaveToDeployBundle_findDuplicates_(headers);
    for (var i = 0; i < spec.required.length; i++) {
      if (!headerMap[spec.required[i]]) missingHeaders.push(spec.required[i]);
    }
    if (duplicateHeaders.length) fatal.push('중복 헤더 존재');
    if (missingHeaders.length) fatal.push('필수 헤더 누락');
  }
  return { ok: fatal.length === 0, sheetName: spec.sheetName, headers: headers, headerMap: headerMap, missingHeaders: missingHeaders, duplicateHeaders: duplicateHeaders, fatal: fatal };
}

function erpCoreSaveToDeployBundle_getHeaders_(sh) {
  if (!sh || sh.getLastColumn() < 1) return [];
  return sh.getRange(1, 1, 1, sh.getLastColumn()).getValues()[0].map(function(v){ return String(v || '').trim(); });
}

function erpCoreSaveToDeployBundle_buildHeaderMap_(headers) {
  var map = {};
  for (var i = 0; i < headers.length; i++) {
    var h = String(headers[i] || '').trim();
    if (h) map[h] = i + 1;
  }
  return map;
}

function erpCoreSaveToDeployBundle_findDuplicates_(list) {
  var seen = {};
  var dup = [];
  for (var i = 0; i < list.length; i++) {
    var v = String(list[i] || '').trim();
    if (!v) continue;
    var key = v.toLowerCase();
    if (seen[key] && dup.indexOf(v) < 0) dup.push(v);
    seen[key] = true;
  }
  return dup;
}

function erpCoreSaveToDeployBundle_checkDuplicatePrimary_(sh, headerMap, primaryId, idValue) {
  if (!sh || !headerMap[primaryId]) return { ok:false, skipped:true, reason:'primary header missing' };
  var lastRow = sh.getLastRow();
  if (lastRow <= 1) return { ok:true, foundCount:0 };
  var values = sh.getRange(2, headerMap[primaryId], lastRow - 1, 1).getValues();
  var found = 0;
  for (var i = 0; i < values.length; i++) {
    if (String(values[i][0] || '').trim() === String(idValue || '').trim()) found++;
  }
  return { ok: found === 0, foundCount: found };
}

function erpCoreSaveToDeployBundle_findRowsByPrimary_(sh, headerMap, primaryId, idValue) {
  var rows = [];
  if (!sh || !headerMap[primaryId]) return rows;
  var lastRow = sh.getLastRow();
  if (lastRow <= 1) return rows;
  var values = sh.getRange(2, 1, lastRow - 1, sh.getLastColumn()).getValues();
  for (var i = 0; i < values.length; i++) {
    if (String(values[i][headerMap[primaryId] - 1] || '').trim() === String(idValue || '').trim()) {
      rows.push({ rowNumber: i + 2, primaryId: idValue, status: headerMap.status ? values[i][headerMap.status - 1] : '', statusReason: headerMap.statusReason ? values[i][headerMap.statusReason - 1] : '' });
    }
  }
  return rows;
}

function erpCoreSaveToDeployBundle_buildRow_(headers, spec, sample) {
  var rowObj = erpCoreSaveToDeployBundle_buildRowObject_(spec, sample, headers);
  var row = [];
  for (var i = 0; i < headers.length; i++) row.push(rowObj[headers[i]] || '');
  return row;
}

function erpCoreSaveToDeployBundle_buildRowObject_(spec, sample, headers) {
  var obj = {};
  for (var i = 0; i < headers.length; i++) obj[headers[i]] = '';
  for (var h = 0; h < spec.required.length; h++) {
    var name = spec.required[h];
    obj[name] = sample[name] || '';
  }
  return obj;
}

function erpCoreSaveToDeployBundle_timestamp_() {
  try { return Utilities.formatDate(new Date(), 'GMT', 'yyyyMMddHHmmss'); }
  catch (e) { return String(new Date().getTime()); }
}
