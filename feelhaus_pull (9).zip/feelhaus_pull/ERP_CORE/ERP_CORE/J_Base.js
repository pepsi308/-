/**
 * FEELHAUS ERP_CORE CLEAN MODULE: ERP_Base.js
 * Consolidated from: ERP_CoreBase_B06J37_03.js, ERP_ModuleSplit_B06J37_01.js, ERP_ModuleSplit_B06J37_02.js
 * Safety: read-only/check/simulation only. actualExecutionBlocked must remain true.
 */



/* ===== BEGIN ERP_CoreBase_B06J37_03.js ===== */

/**
 * build: ERP_B06J37_03_CORE_MIN_BASE_ENGINE_SAFE
 * role:
 *  - ERP_CORE 최소 공통 엔진
 *
 * purpose:
 *  - SystemConfig 자동 읽기
 *  - FEELHAUS_DB_MASTER 자동 연결
 *  - HeaderMap 기반 읽기/쓰기 보조
 *  - 공통 ID 생성
 *  - 공통 상태값 검증
 *  - vendorId/eventId/roleCode 데이터 범위 판정
 *  - 공통 로그 시트 준비/기록
 *  - 필수 시트/헤더 점검
 *
 * apply:
 *  - ERP_CORE 폴더에 새 파일로 추가
 *  - 권장 파일명: ERP_CoreBase_B06J37_03.js
 *
 * safety:
 *  - 자동 실행으로 업무 데이터 변경 없음
 *  - confirmed 함수만 로그 시트/헤더 보정 가능
 *  - 지급/환수/재정산/외부회계 실행 없음
 */

var ERP_B06J37_03_BUILD = 'ERP_B06J37_03_CORE_MIN_BASE_ENGINE_SAFE';

var ERP_CORE_SETUP_DB_ID = '17VMSpgSZCvIrUlgcw8yCNcnl8WQWo2IcRf5tDCcuJGM';
var ERP_CORE_CONFIG_SHEET_NAME = 'SystemConfig';

var ERP_CORE_COMMON_STATUS = [
  'DRAFT',
  'ACTIVE',
  'HOLD',
  'CLOSED',
  'CANCELLED',
  'ARCHIVED'
];

var ERP_CORE_REQUIRED_SHEETS = [
  {
    sheetName: 'ERP_행사관리',
    requiredHeaders: ['eventId','status','statusReason','createdAt','createdBy','updatedAt','updatedBy']
  },
  {
    sheetName: 'ERP_업체관리',
    requiredHeaders: ['vendorId','status','statusReason','createdAt','createdBy','updatedAt','updatedBy']
  },
  {
    sheetName: 'ERP_고객관리',
    requiredHeaders: ['customerId','eventId','vendorId','status','statusReason','createdAt','createdBy','updatedAt','updatedBy']
  },
  {
    sheetName: 'ERP_행사업체연결',
    requiredHeaders: ['eventVendorId','eventId','vendorId','status','statusReason','createdAt','createdBy','updatedAt','updatedBy']
  },
  {
    sheetName: 'ERP_CoreLog',
    requiredHeaders: ['logId','build','moduleCode','actionCode','targetSheet','targetId','actor','actedAt','snapshot','status','statusReason','createdAt','createdBy']
  }
];

/**
 * 표준 자동 점검.
 * 데이터 변경 없음.
 */
function erpB06J37_03_autoRunSafe() {
  return erpCoreB06J37_03_fullCheck();
}

/**
 * CORE 최소 엔진 전체 점검.
 * 데이터 변경 없음.
 */
function erpCoreB06J37_03_fullCheck() {
  var result = {
    ok: true,
    build: ERP_B06J37_03_BUILD,
    moduleCode: 'ERP_CORE',
    checkedAt: new Date().toISOString(),
    fatal: [],
    warnings: [],
    checks: {},
    safety: erpCoreB06J37_03_safetyFlags_()
  };

  console.log('======================================================');
  console.log('[B06J37-03 ERP CORE MIN BASE ENGINE] FULL CHECK START');

  try {
    result.checks.config = erpCore_getConfig();
    erpCoreB06J37_03_collect_(result, 'config', result.checks.config);

    result.checks.master = erpCore_getMasterInfo();
    erpCoreB06J37_03_collect_(result, 'master', result.checks.master);

    result.checks.requiredSheets = erpCore_checkRequiredSheets();
    erpCoreB06J37_03_collect_(result, 'requiredSheets', result.checks.requiredSheets);

    result.checks.status = erpCore_checkStatusPolicy();
    erpCoreB06J37_03_collect_(result, 'status', result.checks.status);

    result.checks.roles = erpCore_checkRolePolicy();
    erpCoreB06J37_03_collect_(result, 'roles', result.checks.roles);

    result.checks.idGenerator = erpCore_testIdGenerator();
    erpCoreB06J37_03_collect_(result, 'idGenerator', result.checks.idGenerator);

  } catch (e) {
    result.fatal.push('B06J37-03 CORE 점검 예외: ' + String(e && e.message ? e.message : e));
    result.exceptionStack = String(e && e.stack ? e.stack : '');
  }

  result.fatalCount = result.fatal.length;
  result.warningCount = result.warnings.length;
  result.ok = result.fatalCount === 0;

  console.log('[B06J37-03 ERP CORE MIN BASE ENGINE] FULL CHECK RESULT');
  console.log(JSON.stringify(result, null, 2));
  console.log('======================================================');

  return result;
}

/**
 * CORE 기준 시트/헤더 보정.
 * ERP_CoreLog는 없으면 생성하고, 누락 헤더는 마지막 열 뒤에 추가합니다.
 * 기존 데이터/헤더 삭제 없음.
 */
function erpCoreB06J37_03_confirmed() {
  return {
    ok: false,
    blocked: true,
    build: ERP_B06J37_03_BUILD,
    action: 'CORE_CONFIRMED_WRITE',
    message: 'ERP_CORE 배포 전 점검 단계에서는 시트 생성/헤더 자동추가/로그 기록 실행이 차단됩니다. CONTROL 승인 후 별도 빌드에서만 실행합니다.',
    safety: erpCoreB06J37_03_safetyFlags_()
  };
}

/** ============================================================
 *  PUBLIC CORE ENGINE FUNCTIONS
 * ============================================================ */

/**
 * SystemConfig 전체를 읽어 configMap 반환.
 */
function erpCore_getConfig() {
  var setup = SpreadsheetApp.openById(ERP_CORE_SETUP_DB_ID);
  var sh = setup.getSheetByName(ERP_CORE_CONFIG_SHEET_NAME);

  var fatal = [];
  var warnings = [];
  var configMap = {};

  if (!sh) {
    fatal.push('SystemConfig 시트를 찾을 수 없습니다.');
    return {
      ok: false,
      fatal: fatal,
      warnings: warnings,
      setupDbId: ERP_CORE_SETUP_DB_ID,
      configSheetName: ERP_CORE_CONFIG_SHEET_NAME,
      configMap: configMap
    };
  }

  var values = sh.getDataRange().getValues();
  if (!values || values.length < 2) {
    fatal.push('SystemConfig 데이터가 비어 있습니다.');
    return {
      ok: false,
      fatal: fatal,
      warnings: warnings,
      setupDbName: setup.getName(),
      configMap: configMap
    };
  }

  var headers = values[0].map(function(h) { return String(h || '').trim(); });
  var lower = headers.map(function(h) { return h.toLowerCase(); });

  var keyIdx = lower.indexOf('key');
  if (keyIdx < 0) keyIdx = lower.indexOf('configkey');
  if (keyIdx < 0) keyIdx = lower.indexOf('name');
  if (keyIdx < 0) keyIdx = 0;

  var valIdx = lower.indexOf('value');
  if (valIdx < 0) valIdx = lower.indexOf('configvalue');
  if (valIdx < 0) valIdx = lower.indexOf('spreadsheetid');
  if (valIdx < 0) valIdx = 1;

  for (var r = 1; r < values.length; r++) {
    var k = String(values[r][keyIdx] || '').trim();
    var v = String(values[r][valIdx] || '').trim();
    if (k) configMap[k] = v;
  }

  return {
    ok: true,
    fatal: fatal,
    warnings: warnings,
    setupDbId: ERP_CORE_SETUP_DB_ID,
    setupDbName: setup.getName(),
    configSheetName: ERP_CORE_CONFIG_SHEET_NAME,
    configCount: Object.keys(configMap).length,
    configMap: configMap
  };
}

/**
 * MASTER 정보 반환.
 */
function erpCore_getMasterInfo() {
  var master = erpCore_getMasterSpreadsheet_();
  return {
    ok: true,
    fatal: [],
    warnings: [],
    masterId: master.getId(),
    masterName: master.getName()
  };
}

/**
 * MASTER Spreadsheet 객체.
 */
function erpCore_getMasterSpreadsheet_() {
  var cfg = erpCore_getConfig();
  if (!cfg.ok) throw new Error('CONFIG_NOT_READY');

  var keys = [
    'FEELHAUS_DB_MASTER_ID',
    'FEELHAUS_DB_MASTER',
    'MASTER_SPREADSHEET_ID',
    'MASTER_DB_ID',
    'DB_MASTER_ID',
    'SPREADSHEET_ID'
  ];

  var raw = '';
  for (var i = 0; i < keys.length; i++) {
    if (cfg.configMap[keys[i]]) {
      raw = cfg.configMap[keys[i]];
      break;
    }
  }

  if (!raw) throw new Error('MASTER_ID_NOT_FOUND_IN_SYSTEMCONFIG');

  var id = erpCore_extractSpreadsheetId_(raw);
  return SpreadsheetApp.openById(id);
}

/**
 * 헤더맵 반환.
 */
function erpCore_getHeaderMap(sheetName) {
  var sh = erpCore_getSheet_(sheetName);
  var headers = erpCore_getHeaders_(sh);
  var map = {};
  headers.forEach(function(h, idx) {
    if (h) map[h] = idx + 1;
  });
  return {
    ok: true,
    sheetName: sheetName,
    headers: headers,
    map: map
  };
}

/**
 * 헤더 기반 row object 목록 반환.
 */
function erpCore_getRows(sheetName) {
  var sh = erpCore_getSheet_(sheetName);
  var headers = erpCore_getHeaders_(sh);
  if (sh.getLastRow() < 2) return [];

  var values = sh.getRange(2, 1, sh.getLastRow() - 1, sh.getLastColumn()).getValues();
  return values.map(function(row, idx) {
    var obj = { _rowIndex: idx + 2 };
    headers.forEach(function(h, i) {
      if (h) obj[h] = row[i];
    });
    return obj;
  });
}

/**
 * 공통 ID 생성.
 * prefix 예: EVT, VND, CUS, SALE, CON, INS, AS, DOC
 */
function erpCore_generateId(prefix) {
  var p = String(prefix || 'ID').replace(/[^A-Z0-9_-]/gi, '').toUpperCase();
  if (!p) p = 'ID';
  var ts = Utilities.formatDate(new Date(), Session.getScriptTimeZone(), 'yyyyMMddHHmmss');
  var rand = Math.floor(Math.random() * 9000) + 1000;
  return p + '-' + ts + '-' + rand;
}

/**
 * 상태값 검증.
 */
function erpCore_validateStatus(status) {
  var s = String(status || '').trim().toUpperCase();
  return {
    ok: ERP_CORE_COMMON_STATUS.indexOf(s) >= 0,
    status: s,
    allowedStatuses: ERP_CORE_COMMON_STATUS
  };
}

/**
 * 데이터 범위 판정.
 * SUPER_ADMIN / HQ_ADMIN / HQ_MANAGER는 전체,
 * VENDOR 계열은 vendorId 필수,
 * STAFF 계열은 roleCode/eventId/vendorId 기준 필터.
 */
function erpCore_getDataScope(userContext) {
  var ctx = userContext || {};
  var roleCode = String(ctx.roleCode || '').trim().toUpperCase();
  var vendorId = String(ctx.vendorId || '').trim();
  var eventId = String(ctx.eventId || '').trim();

  var hqRoles = ['SUPER_ADMIN','HQ_ADMIN','HQ_MANAGER','ACCOUNTING_MANAGER','OPERATION_MANAGER'];
  var vendorRoles = ['VENDOR_OWNER','VENDOR_MANAGER'];
  var staffRoles = ['STAFF_SALES','STAFF_INSTALL','STAFF_AS','VIEWER'];

  if (hqRoles.indexOf(roleCode) >= 0) {
    return {
      ok: true,
      roleCode: roleCode,
      scopeType: 'ALL',
      requiresVendorId: false,
      requiresEventId: false,
      vendorId: vendorId,
      eventId: eventId
    };
  }

  if (vendorRoles.indexOf(roleCode) >= 0) {
    return {
      ok: !!vendorId,
      roleCode: roleCode,
      scopeType: 'VENDOR',
      requiresVendorId: true,
      requiresEventId: false,
      vendorId: vendorId,
      eventId: eventId
    };
  }

  if (staffRoles.indexOf(roleCode) >= 0) {
    return {
      ok: !!vendorId,
      roleCode: roleCode,
      scopeType: 'STAFF',
      requiresVendorId: true,
      requiresEventId: false,
      vendorId: vendorId,
      eventId: eventId
    };
  }

  return {
    ok: false,
    roleCode: roleCode,
    scopeType: 'UNKNOWN',
    requiresVendorId: true,
    requiresEventId: false,
    vendorId: vendorId,
    eventId: eventId,
    message: '알 수 없는 roleCode'
  };
}

/**
 * 공통 로그 기록.
 * ERP_CoreLog 시트가 없으면 생성합니다.
 */
function erpCore_log(actionCode, data) {
  return {
    ok: false,
    blocked: true,
    build: ERP_B06J37_03_BUILD,
    actionCode: actionCode || '',
    targetSheet: data && data.targetSheet ? data.targetSheet : '',
    targetId: data && data.targetId ? data.targetId : '',
    message: 'ERP_CORE 배포 전 점검 단계에서는 실제 로그 appendRow 실행이 차단됩니다.',
    safety: erpCoreB06J37_03_safetyFlags_()
  };
}

/**
 * 필수 시트/헤더 점검.
 */
function erpCore_checkRequiredSheets() {
  var master = erpCore_getMasterSpreadsheet_();
  var fatal = [];
  var warnings = [];
  var sheets = [];

  ERP_CORE_REQUIRED_SHEETS.forEach(function(spec) {
    var sh = master.getSheetByName(spec.sheetName);
    if (!sh) {
      if (spec.sheetName === 'ERP_CoreLog') {
        warnings.push('로그 시트 없음. confirmed 실행 시 생성 가능: ' + spec.sheetName);
      } else {
        fatal.push('필수 시트 없음: ' + spec.sheetName);
      }
      sheets.push({
        sheetName: spec.sheetName,
        exists: false,
        missingHeaders: spec.requiredHeaders
      });
      return;
    }

    var headers = erpCore_getHeaders_(sh);
    var missing = spec.requiredHeaders.filter(function(h) { return headers.indexOf(h) < 0; });

    if (missing.length) {
      if (spec.sheetName === 'ERP_CoreLog') {
        warnings.push(spec.sheetName + ' 누락 헤더: ' + missing.join(', '));
      } else {
        fatal.push(spec.sheetName + ' 누락 헤더: ' + missing.join(', '));
      }
    }

    sheets.push({
      sheetName: spec.sheetName,
      exists: true,
      lastRow: sh.getLastRow(),
      lastCol: sh.getLastColumn(),
      missingHeaders: missing
    });
  });

  return {
    ok: fatal.length === 0,
    fatal: fatal,
    warnings: warnings,
    sheets: sheets
  };
}

function erpCore_checkStatusPolicy() {
  return {
    ok: true,
    fatal: [],
    warnings: [],
    allowedStatuses: ERP_CORE_COMMON_STATUS,
    deletePolicy: '삭제 대신 상태변경',
    reopenPolicy: 'CLOSED/ARCHIVED 이후 수정은 승인 기반'
  };
}

function erpCore_checkRolePolicy() {
  return {
    ok: true,
    fatal: [],
    warnings: [],
    roles: [
      'SUPER_ADMIN',
      'HQ_ADMIN',
      'HQ_MANAGER',
      'ACCOUNTING_MANAGER',
      'OPERATION_MANAGER',
      'VENDOR_OWNER',
      'VENDOR_MANAGER',
      'STAFF_SALES',
      'STAFF_INSTALL',
      'STAFF_AS',
      'VIEWER'
    ],
    vendorPolicy: '업체는 별도 앱이 아니라 ERP 내부 지점형 사용자 그룹',
    dataScopePolicy: 'vendorId/eventId/roleCode 기준 데이터 범위 제한'
  };
}

function erpCore_testIdGenerator() {
  var id = erpCore_generateId('TEST');
  return {
    ok: /^TEST-\d{14}-\d{4}$/.test(id),
    fatal: /^TEST-\d{14}-\d{4}$/.test(id) ? [] : ['ID 생성 형식 오류'],
    warnings: [],
    sampleId: id
  };
}

/** ============================================================
 *  INTERNAL HELPERS
 * ============================================================ */

function erpCore_getSheet_(sheetName) {
  var master = erpCore_getMasterSpreadsheet_();
  var sh = master.getSheetByName(sheetName);
  if (!sh) throw new Error('SHEET_NOT_FOUND: ' + sheetName);
  return sh;
}

function erpCore_getHeaders_(sh) {
  if (!sh || sh.getLastRow() < 1 || sh.getLastColumn() < 1) return [];
  return sh.getRange(1, 1, 1, sh.getLastColumn()).getValues()[0].map(function(h) {
    return String(h || '').trim();
  });
}

function erpCore_getHeaderMapFromSheet_(sh) {
  var headers = erpCore_getHeaders_(sh);
  var map = {};
  headers.forEach(function(h, i) {
    if (h) map[h] = i + 1;
  });
  return map;
}

function erpCore_extractSpreadsheetId_(raw) {
  var s = String(raw || '').trim();
  var m = s.match(/\/d\/([a-zA-Z0-9-_]+)/);
  return m && m[1] ? m[1] : s;
}

function erpCore_getActiveUser_() {
  try {
    return Session.getActiveUser().getEmail() || 'UNKNOWN_USER';
  } catch (e) {
    return 'UNKNOWN_USER';
  }
}

function erpCoreB06J37_03_collect_(result, label, check) {
  if (!check) return;
  if (check.fatal && check.fatal.length) {
    result.fatal = result.fatal.concat(check.fatal.map(function(x) { return label + ': ' + x; }));
  }
  if (check.warnings && check.warnings.length) {
    result.warnings = result.warnings.concat(check.warnings.map(function(x) { return label + ': ' + x; }));
  }
}

function erpCoreB06J37_03_safetyFlags_() {
  return {
    coreBaseEngineOnly: true,
    noBusinessStateMutationInAutoRun: true,
    noSheetDataMutationInAutoRun: true,
    confirmedMayCreateCoreLogOnly: true,
    confirmedMayAppendMissingHeadersOnly: true,
    noHeaderDelete: true,
    noHeaderReorder: true,
    noPaymentExecution: true,
    noRecoveryExecution: true,
    noAutoRecalculation: true,
    noExternalAccountingTransfer: true,
    independentVendorDbBlocked: true,
    vendorIsBranchUserGroupInsideErp: true
  };
}


/* ===== END ERP_CoreBase_B06J37_03.js ===== */



/* ===== BEGIN ERP_ModuleSplit_B06J37_01.js ===== */

/**
 * build: ERP_B06J37_01_MODULE_SPLIT_BASELINE_CHECK_SAFE
 * purpose:
 *  - ERP_CORE / ERP_ADMIN / ERP_FIELD 모듈 분리 기준점검
 *  - 업체 독립 앱/독립 DB 구조 차단 확인
 *  - FEELHAUS_SETUP_DB > SystemConfig 자동 읽기 확인
 *  - FEELHAUS_DB_MASTER 자동 연결 확인
 *  - 공통 ID / 핵심 시트 / 핵심 헤더 기준 확인
 *
 * apply:
 *  - 이 파일은 기존 파일에 붙이지 말고 새 파일로 추가합니다.
 *  - 권장 파일명: ERP_ModuleSplit_B06J37_01.gs
 *
 * standard auto:
 *  - erpB06J37_01_autoRunSafe()
 */

var ERP_B06J37_01_BUILD = 'ERP_B06J37_01_MODULE_SPLIT_BASELINE_CHECK_SAFE';

var ERP_B06J37_01_SETUP_DB_ID = '17VMSpgSZCvIrUlgcw8yCNcnl8WQWo2IcRf5tDCcuJGM';
var ERP_B06J37_01_CONFIG_SHEET_NAME = 'SystemConfig';

var ERP_B06J37_01_ALLOWED_MODULES = ['ERP_CORE', 'ERP_ADMIN', 'ERP_FIELD'];

var ERP_B06J37_01_CORE_SHEETS = [
  {
    sheetName: 'ERP_행사관리',
    requiredHeaders: ['eventId','status','statusReason','createdAt','createdBy','updatedAt','updatedBy']
  },
  {
    sheetName: 'ERP_업체관리',
    requiredHeaders: ['vendorId','status','statusReason','createdAt','createdBy','updatedAt','updatedBy']
  },
  {
    sheetName: 'ERP_고객관리',
    requiredHeaders: ['customerId','eventId','vendorId','status','statusReason','createdAt','createdBy','updatedAt','updatedBy']
  },
  {
    sheetName: 'ERP_행사업체연결',
    requiredHeaders: ['eventVendorId','eventId','vendorId','status','statusReason','createdAt','createdBy','updatedAt','updatedBy']
  }
];

var ERP_B06J37_01_COMMON_ID_HEADERS = [
  'eventId',
  'vendorId',
  'customerId',
  'saleId',
  'contractId',
  'installId',
  'asId',
  'documentId',
  'status',
  'statusReason',
  'createdAt',
  'createdBy',
  'updatedAt',
  'updatedBy'
];

function erpB06J37_01_autoRunSafe(moduleCode) {
  var result = {
    ok: true,
    build: ERP_B06J37_01_BUILD,
    checkedAt: new Date().toISOString(),
    moduleCode: moduleCode || erpB06J37_01_guessModuleCode_(),
    scriptId: erpB06J37_01_getScriptId_(),
    fatal: [],
    warnings: [],
    checks: {},
    safety: erpB06J37_01_safetyFlags_()
  };

  console.log('======================================================');
  console.log('[B06J37-01 MODULE SPLIT BASELINE CHECK] START');
  console.log(JSON.stringify({
    build: ERP_B06J37_01_BUILD,
    moduleCode: result.moduleCode,
    scriptId: result.scriptId
  }, null, 2));

  try {
    result.checks.moduleCodeAllowed = erpB06J37_01_checkModuleCode_(result.moduleCode);
    erpB06J37_01_collect_(result, 'moduleCodeAllowed', result.checks.moduleCodeAllowed);

    result.checks.setupDb = erpB06J37_01_checkSetupDb_();
    erpB06J37_01_collect_(result, 'setupDb', result.checks.setupDb);

    result.checks.masterDb = erpB06J37_01_checkMasterDb_(result.checks.setupDb.configMap);
    erpB06J37_01_collect_(result, 'masterDb', result.checks.masterDb);

    result.checks.coreSheets = erpB06J37_01_checkCoreSheets_(result.checks.masterDb.masterSpreadsheet);
    erpB06J37_01_collect_(result, 'coreSheets', result.checks.coreSheets);

    result.checks.independentDbGuard = erpB06J37_01_checkIndependentDbGuard_(result.checks.setupDb.configMap);
    erpB06J37_01_collect_(result, 'independentDbGuard', result.checks.independentDbGuard);

    result.checks.roleSplitPolicy = erpB06J37_01_checkRoleSplitPolicy_(result.moduleCode);
    erpB06J37_01_collect_(result, 'roleSplitPolicy', result.checks.roleSplitPolicy);

    result.checks.requiredCommonIds = erpB06J37_01_checkCommonIds_();
    erpB06J37_01_collect_(result, 'requiredCommonIds', result.checks.requiredCommonIds);

  } catch (e) {
    result.ok = false;
    result.fatal.push('B06J37-01 점검 중 예외: ' + String(e && e.message ? e.message : e));
    result.exceptionStack = String(e && e.stack ? e.stack : '');
  }

  result.fatalCount = result.fatal.length;
  result.warningCount = result.warnings.length;
  result.ok = result.fatalCount === 0;

  // Spreadsheet 객체는 로그 직렬화에서 제외
  if (result.checks.masterDb && result.checks.masterDb.masterSpreadsheet) {
    result.checks.masterDb.masterSpreadsheetName = result.checks.masterDb.masterSpreadsheet.getName();
    delete result.checks.masterDb.masterSpreadsheet;
  }

  console.log('[B06J37-01 MODULE SPLIT BASELINE CHECK] RESULT');
  console.log(JSON.stringify(result, null, 2));
  console.log('======================================================');

  return result;
}

function erpB06J37_01_checkModuleCode_(moduleCode) {
  var ok = ERP_B06J37_01_ALLOWED_MODULES.indexOf(String(moduleCode || '').trim()) >= 0;
  return {
    ok: ok,
    fatal: ok ? [] : ['moduleCode가 허용값이 아닙니다. ERP_CORE / ERP_ADMIN / ERP_FIELD 중 하나여야 합니다.'],
    warnings: [],
    moduleCode: moduleCode,
    allowedModules: ERP_B06J37_01_ALLOWED_MODULES
  };
}

function erpB06J37_01_checkSetupDb_() {
  var ss = SpreadsheetApp.openById(ERP_B06J37_01_SETUP_DB_ID);
  var sh = ss.getSheetByName(ERP_B06J37_01_CONFIG_SHEET_NAME);

  var fatal = [];
  var warnings = [];
  var configMap = {};

  if (!sh) {
    fatal.push('FEELHAUS_SETUP_DB에서 SystemConfig 시트를 찾지 못했습니다.');
    return {
      ok: false,
      fatal: fatal,
      warnings: warnings,
      setupDbId: ERP_B06J37_01_SETUP_DB_ID,
      configSheetName: ERP_B06J37_01_CONFIG_SHEET_NAME,
      configMap: configMap
    };
  }

  var values = sh.getDataRange().getValues();
  if (!values || values.length < 2) {
    fatal.push('SystemConfig 데이터가 비어 있습니다.');
    return {
      ok: false,
      fatal: fatal,
      warnings: warnings,
      setupDbId: ERP_B06J37_01_SETUP_DB_ID,
      configSheetName: ERP_B06J37_01_CONFIG_SHEET_NAME,
      configMap: configMap
    };
  }

  var headers = values[0].map(function(h) { return String(h || '').trim(); });
  var lower = headers.map(function(h) { return h.toLowerCase(); });

  var keyIdx = lower.indexOf('key');
  if (keyIdx < 0) keyIdx = lower.indexOf('configkey');
  if (keyIdx < 0) keyIdx = lower.indexOf('name');
  if (keyIdx < 0) keyIdx = 0;

  var valIdx = lower.indexOf('value');
  if (valIdx < 0) valIdx = lower.indexOf('configvalue');
  if (valIdx < 0) valIdx = lower.indexOf('spreadsheetid');
  if (valIdx < 0) valIdx = 1;

  for (var r = 1; r < values.length; r++) {
    var k = String(values[r][keyIdx] || '').trim();
    var v = String(values[r][valIdx] || '').trim();
    if (k) configMap[k] = v;
  }

  return {
    ok: true,
    fatal: fatal,
    warnings: warnings,
    setupDbId: ERP_B06J37_01_SETUP_DB_ID,
    setupDbName: ss.getName(),
    configSheetName: ERP_B06J37_01_CONFIG_SHEET_NAME,
    configCount: Object.keys(configMap).length,
    configMap: configMap
  };
}

function erpB06J37_01_checkMasterDb_(configMap) {
  var fatal = [];
  var warnings = [];

  var candidateKeys = [
    'FEELHAUS_DB_MASTER_ID',
    'FEELHAUS_DB_MASTER',
    'MASTER_SPREADSHEET_ID',
    'MASTER_DB_ID',
    'DB_MASTER_ID'
  ];

  var raw = '';
  var usedKey = '';

  for (var i = 0; i < candidateKeys.length; i++) {
    var k = candidateKeys[i];
    if (configMap && configMap[k]) {
      raw = String(configMap[k]).trim();
      usedKey = k;
      break;
    }
  }

  if (!raw) {
    fatal.push('SystemConfig에서 FEELHAUS_DB_MASTER ID를 찾지 못했습니다.');
    return {
      ok: false,
      fatal: fatal,
      warnings: warnings,
      usedKey: usedKey,
      rawValue: raw,
      masterId: ''
    };
  }

  var m = raw.match(/\/d\/([a-zA-Z0-9-_]+)/);
  var masterId = m && m[1] ? m[1] : raw;

  var masterSpreadsheet = SpreadsheetApp.openById(masterId);

  return {
    ok: true,
    fatal: fatal,
    warnings: warnings,
    usedKey: usedKey,
    rawValue: raw,
    masterId: masterId,
    masterName: masterSpreadsheet.getName(),
    masterSpreadsheet: masterSpreadsheet
  };
}

function erpB06J37_01_checkCoreSheets_(masterSpreadsheet) {
  var fatal = [];
  var warnings = [];
  var sheetChecks = [];

  ERP_B06J37_01_CORE_SHEETS.forEach(function(spec) {
    var sh = masterSpreadsheet.getSheetByName(spec.sheetName);
    if (!sh) {
      fatal.push('MASTER 필수 시트 누락: ' + spec.sheetName);
      sheetChecks.push({
        sheetName: spec.sheetName,
        exists: false,
        missingHeaders: spec.requiredHeaders
      });
      return;
    }

    var headers = erpB06J37_01_getHeaders_(sh);
    var missing = spec.requiredHeaders.filter(function(h) {
      return headers.indexOf(h) < 0;
    });

    if (missing.length) {
      fatal.push(spec.sheetName + ' 필수 헤더 누락: ' + missing.join(', '));
    }

    sheetChecks.push({
      sheetName: spec.sheetName,
      exists: true,
      lastRow: sh.getLastRow(),
      lastCol: sh.getLastColumn(),
      missingHeaders: missing
    });
  });

  return {
    ok: fatal.length === 0,
    fatal: fatal,
    warnings: warnings,
    sheetChecks: sheetChecks
  };
}

function erpB06J37_01_checkIndependentDbGuard_(configMap) {
  var fatal = [];
  var warnings = [];
  var suspicious = [];

  Object.keys(configMap || {}).forEach(function(k) {
    var key = String(k || '').toUpperCase();
    var val = String(configMap[k] || '').trim();

    // 업체별 독립 DB를 암시하는 설정 키는 금지 후보로 잡습니다.
    if (
      key.indexOf('VENDOR_DB') >= 0 ||
      key.indexOf('VENDOR_SPREADSHEET') >= 0 ||
      key.indexOf('PARTNER_DB') >= 0 ||
      key.indexOf('BRANCH_DB') >= 0
    ) {
      suspicious.push({ key: k, value: val });
    }
  });

  if (suspicious.length) {
    warnings.push('업체/지점 독립 DB로 오해될 수 있는 설정 키가 있습니다. 실제 운영 연결로 사용 중인지 확인 필요.');
  }

  return {
    ok: true,
    fatal: fatal,
    warnings: warnings,
    independentVendorDbBlocked: true,
    suspiciousConfigKeys: suspicious,
    message: '업체는 ERP 내부 지점형 사용자 그룹이며, 업체별 독립 DB 구조는 금지입니다.'
  };
}

function erpB06J37_01_checkRoleSplitPolicy_(moduleCode) {
  var fatal = [];
  var warnings = [];

  var policy = {
    ERP_CORE: {
      role: '공통 엔진 / 설정 / MASTER 연결 / 공통 ID / 헤더맵 / 공통 저장조회',
      screenScope: '공통/백엔드 중심',
      mustNotOwnIndependentDb: true
    },
    ERP_ADMIN: {
      role: '본사 관리자 화면 / 행사 / 업체 / 승인 / 정산 / 통제',
      screenScope: '본사 HQ 화면',
      mustNotOwnIndependentDb: true
    },
    ERP_FIELD: {
      role: '현장/업체/직원용 화면 / 판매 / 계약 / 설치 / A/S / 조회',
      screenScope: 'vendorId / eventId / roleCode 기준 화면 분기',
      mustNotOwnIndependentDb: true
    }
  };

  var p = policy[moduleCode] || null;
  if (!p) {
    fatal.push('모듈 정책을 찾을 수 없습니다: ' + moduleCode);
  }

  return {
    ok: fatal.length === 0,
    fatal: fatal,
    warnings: warnings,
    moduleCode: moduleCode,
    policy: p,
    allPolicies: policy
  };
}

function erpB06J37_01_checkCommonIds_() {
  return {
    ok: true,
    fatal: [],
    warnings: [],
    commonIdHeaders: ERP_B06J37_01_COMMON_ID_HEADERS,
    connectionRule: '모든 연결은 이름/전화번호/문서명이 아니라 공통 ID 기준입니다.',
    headerRule: '다른 프로젝트는 열 위치가 아니라 헤더명으로 자동 추적해야 합니다.'
  };
}

function erpB06J37_01_collect_(result, label, check) {
  if (!check) return;
  if (check.fatal && check.fatal.length) {
    result.fatal = result.fatal.concat(check.fatal.map(function(x) {
      return label + ': ' + x;
    }));
  }
  if (check.warnings && check.warnings.length) {
    result.warnings = result.warnings.concat(check.warnings.map(function(x) {
      return label + ': ' + x;
    }));
  }
}

function erpB06J37_01_getHeaders_(sh) {
  if (!sh || sh.getLastRow() < 1 || sh.getLastColumn() < 1) return [];
  return sh.getRange(1, 1, 1, sh.getLastColumn()).getValues()[0].map(function(h) {
    return String(h || '').trim();
  });
}

function erpB06J37_01_guessModuleCode_() {
  try {
    var name = DriveApp.getFileById(ScriptApp.getScriptId()).getName();
    var upper = String(name || '').toUpperCase();
    if (upper.indexOf('ERP_CORE') >= 0) return 'ERP_CORE';
    if (upper.indexOf('ERP_ADMIN') >= 0) return 'ERP_ADMIN';
    if (upper.indexOf('ERP_FIELD') >= 0) return 'ERP_FIELD';
    if (upper.indexOf('CORE') >= 0) return 'ERP_CORE';
    if (upper.indexOf('ADMIN') >= 0) return 'ERP_ADMIN';
    if (upper.indexOf('FIELD') >= 0) return 'ERP_FIELD';
  } catch (e) {}
  return 'ERP_ADMIN';
}

function erpB06J37_01_getScriptId_() {
  try {
    return ScriptApp.getScriptId();
  } catch (e) {
    return '';
  }
}

function erpB06J37_01_safetyFlags_() {
  return {
    baselineCheckOnly: true,
    noSheetMutation: true,
    noBusinessDataMutation: true,
    noUiMutation: true,
    noPaymentExecution: true,
    noRecoveryExecution: true,
    noAutoRecalculation: true,
    noExternalAccountingTransfer: true,
    independentVendorDbBlocked: true,
    vendorIsBranchUserGroupInsideErp: true
  };
}


/* ===== END ERP_ModuleSplit_B06J37_01.js ===== */



/* ===== BEGIN ERP_ModuleSplit_B06J37_02.js ===== */

/**
 * build: ERP_B06J37_02_MASTER_CORE_HEADER_REPAIR_SAFE
 * purpose:
 *  - B06J37-01 기준점검 실패 원인 보정
 *  - FEELHAUS_DB_MASTER의 ERP_행사관리 / ERP_업체관리 누락 헤더 추가
 *  - 누락 헤더: statusReason, createdBy
 *
 * apply:
 *  - 기존 파일에 붙이지 말고 새 파일로 추가합니다.
 *  - 권장 파일명: ERP_ModuleSplit_B06J37_02.js
 *
 * safety:
 *  - 기존 헤더/데이터 삭제 없음
 *  - 기존 열 순서 변경 없음
 *  - 누락 헤더만 마지막 열 뒤에 추가
 *  - 기본 점검은 dryRun
 *
 * functions:
 *  - erpB06J37_02_dryRun()
 *  - erpB06J37_02_confirmed()
 */

var ERP_B06J37_02_BUILD = 'ERP_B06J37_02_MASTER_CORE_HEADER_REPAIR_SAFE';
var ERP_B06J37_02_SETUP_DB_ID = '17VMSpgSZCvIrUlgcw8yCNcnl8WQWo2IcRf5tDCcuJGM';
var ERP_B06J37_02_CONFIG_SHEET_NAME = 'SystemConfig';

var ERP_B06J37_02_TARGETS = [
  {
    sheetName: 'ERP_행사관리',
    requiredHeaders: ['statusReason', 'createdBy']
  },
  {
    sheetName: 'ERP_업체관리',
    requiredHeaders: ['statusReason', 'createdBy']
  }
];

function erpB06J37_02_dryRun() {
  return erpB06J37_02_run_(true);
}

function erpB06J37_02_confirmed() {
  return {
    ok: false,
    blocked: true,
    build: ERP_B06J37_02_BUILD,
    action: 'HEADER_REPAIR_CONFIRMED',
    message: 'ERP_CORE 배포 전 점검 단계에서는 헤더 자동 추가 실행이 차단됩니다. erpB06J37_02_dryRun()만 사용하세요.'
  };
}

function erpB06J37_02_run_(dryRun) {
  var result = {
    ok: true,
    build: ERP_B06J37_02_BUILD,
    dryRun: dryRun === true,
    checkedAt: new Date().toISOString(),
    fatal: [],
    warnings: [],
    targets: [],
    safety: {
      headerRepairOnly: true,
      appendMissingHeadersOnly: true,
      noHeaderDelete: true,
      noHeaderReorder: true,
      noDataDelete: true,
      noBusinessStateMutation: true,
      noPaymentExecution: true,
      noRecoveryExecution: true,
      noAutoRecalculation: true,
      noExternalAccountingTransfer: true
    }
  };

  console.log('======================================================');
  console.log('[B06J37-02 MASTER CORE HEADER REPAIR] START');
  console.log(JSON.stringify({ build: ERP_B06J37_02_BUILD, dryRun: result.dryRun }, null, 2));

  try {
    var setup = erpB06J37_02_getSetupConfig_();
    result.setup = {
      ok: setup.ok,
      setupDbName: setup.setupDbName,
      configCount: setup.configCount,
      usedMasterKey: setup.usedMasterKey,
      masterId: setup.masterId
    };

    if (!setup.ok) {
      result.fatal = result.fatal.concat(setup.fatal || []);
    } else {
      var master = SpreadsheetApp.openById(setup.masterId);
      result.masterName = master.getName();

      ERP_B06J37_02_TARGETS.forEach(function(target) {
        var one = erpB06J37_02_repairSheetHeaders_(master, target, result.dryRun);
        result.targets.push(one);
        if (!one.ok && one.fatal && one.fatal.length) {
          result.fatal = result.fatal.concat(one.fatal);
        }
        if (one.warnings && one.warnings.length) {
          result.warnings = result.warnings.concat(one.warnings);
        }
      });
    }
  } catch (e) {
    result.ok = false;
    result.fatal.push('B06J37-02 실행 예외: ' + String(e && e.message ? e.message : e));
    result.exceptionStack = String(e && e.stack ? e.stack : '');
  }

  result.fatalCount = result.fatal.length;
  result.warningCount = result.warnings.length;
  result.ok = result.fatalCount === 0;

  console.log('[B06J37-02 MASTER CORE HEADER REPAIR] RESULT');
  console.log(JSON.stringify(result, null, 2));
  console.log('======================================================');

  return result;
}

function erpB06J37_02_repairSheetHeaders_(master, target, dryRun) {
  var out = {
    ok: true,
    sheetName: target.sheetName,
    dryRun: dryRun === true,
    exists: false,
    beforeLastCol: 0,
    afterLastCol: 0,
    existingHeaders: [],
    missingHeaders: [],
    appendedHeaders: [],
    fatal: [],
    warnings: []
  };

  var sh = master.getSheetByName(target.sheetName);
  if (!sh) {
    out.ok = false;
    out.fatal.push('대상 시트를 찾지 못했습니다: ' + target.sheetName);
    return out;
  }

  out.exists = true;
  out.beforeLastCol = sh.getLastColumn();
  out.existingHeaders = erpB06J37_02_getHeaders_(sh);

  out.missingHeaders = target.requiredHeaders.filter(function(h) {
    return out.existingHeaders.indexOf(h) < 0;
  });

  if (!out.missingHeaders.length) {
    out.afterLastCol = out.beforeLastCol;
    out.message = '누락 헤더 없음';
    return out;
  }

  out.afterLastCol = out.beforeLastCol + out.missingHeaders.length;
  out.appendedHeaders = [];
  out.blocked = dryRun ? false : true;

  out.message = dryRun
    ? 'DRY_RUN: 누락 헤더 추가 예정'
    : 'BLOCKED: ERP_CORE 배포 전 점검 단계에서는 누락 헤더를 실제 추가하지 않음';

  return out;
}

function erpB06J37_02_getSetupConfig_() {
  var out = {
    ok: true,
    fatal: [],
    configMap: {},
    configCount: 0,
    setupDbName: '',
    usedMasterKey: '',
    masterId: ''
  };

  var setup = SpreadsheetApp.openById(ERP_B06J37_02_SETUP_DB_ID);
  out.setupDbName = setup.getName();

  var sh = setup.getSheetByName(ERP_B06J37_02_CONFIG_SHEET_NAME);
  if (!sh) {
    out.ok = false;
    out.fatal.push('SystemConfig 시트를 찾지 못했습니다.');
    return out;
  }

  var values = sh.getDataRange().getValues();
  if (!values || values.length < 2) {
    out.ok = false;
    out.fatal.push('SystemConfig 데이터가 비어 있습니다.');
    return out;
  }

  var headers = values[0].map(function(h) { return String(h || '').trim(); });
  var lower = headers.map(function(h) { return h.toLowerCase(); });

  var keyIdx = lower.indexOf('key');
  if (keyIdx < 0) keyIdx = lower.indexOf('configkey');
  if (keyIdx < 0) keyIdx = lower.indexOf('name');
  if (keyIdx < 0) keyIdx = 0;

  var valIdx = lower.indexOf('value');
  if (valIdx < 0) valIdx = lower.indexOf('configvalue');
  if (valIdx < 0) valIdx = lower.indexOf('spreadsheetid');
  if (valIdx < 0) valIdx = 1;

  for (var r = 1; r < values.length; r++) {
    var k = String(values[r][keyIdx] || '').trim();
    var v = String(values[r][valIdx] || '').trim();
    if (k) out.configMap[k] = v;
  }

  out.configCount = Object.keys(out.configMap).length;

  var keys = [
    'FEELHAUS_DB_MASTER_ID',
    'FEELHAUS_DB_MASTER',
    'MASTER_SPREADSHEET_ID',
    'MASTER_DB_ID',
    'DB_MASTER_ID',
    'SPREADSHEET_ID'
  ];

  for (var i = 0; i < keys.length; i++) {
    var key = keys[i];
    if (out.configMap[key]) {
      out.usedMasterKey = key;
      out.masterId = erpB06J37_02_extractSpreadsheetId_(out.configMap[key]);
      break;
    }
  }

  if (!out.masterId) {
    out.ok = false;
    out.fatal.push('SystemConfig에서 FEELHAUS_DB_MASTER ID를 찾지 못했습니다.');
  }

  return out;
}

function erpB06J37_02_extractSpreadsheetId_(raw) {
  var s = String(raw || '').trim();
  var m = s.match(/\/d\/([a-zA-Z0-9-_]+)/);
  return m && m[1] ? m[1] : s;
}

function erpB06J37_02_getHeaders_(sh) {
  if (!sh || sh.getLastRow() < 1 || sh.getLastColumn() < 1) return [];
  return sh.getRange(1, 1, 1, sh.getLastColumn()).getValues()[0].map(function(h) {
    return String(h || '').trim();
  });
}


/* ===== END ERP_ModuleSplit_B06J37_02.js ===== */
