/**
 * FEELHAUS ERP_CORE CLEAN MODULE: ERP_WorkUI.js
 * Consolidated from: ERP_Integrated_RoleCustomerSaleField_UI.js, ERP_Integrated_RouteSplit_Screens.js, ERP_Integrated_Detail_UI.js
 * Safety: read-only/check/simulation only. actualExecutionBlocked must remain true.
 */



/* ===== BEGIN ERP_Integrated_RoleCustomerSaleField_UI.js ===== */

/**
 * ERP Integrated 521~700
 * Role main / customer / sale / contract / SIGN / install / A/S UI safe skeleton.
 * This module is intentionally read-only and report-only.
 */
var ERP_INTEGRATED_B06J41_521_700_MODULE_FILE = 'ERP_Integrated_RoleCustomerSaleField_UI.js';

function erpIntegratedB06J41_521_700_s_(v) {
  return String(v == null ? '' : v).trim();
}

function erpIntegratedB06J41_521_700_renderRoleCustomerSaleFieldHtml(params) {
  params = params || {};
  var t = HtmlService.createTemplateFromFile('H_Work');
  t.model = erpIntegratedB06J41_521_700_buildModel_(params);
  return t.evaluate()
    .setTitle('FEELHAUS ERP 실사용 UI 521~700')
    .setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL);
}

function erpIntegratedB06J41_521_700_buildModel_(params) {
  params = params || {};
  var roleCode = erpIntegratedB06J41_521_700_s_(params.roleCode || 'HQ_ADMIN');
  var vendorId = erpIntegratedB06J41_521_700_s_(params.vendorId || '');
  var eventId = erpIntegratedB06J41_521_700_s_(params.eventId || '');
  var customerId = erpIntegratedB06J41_521_700_s_(params.customerId || '');

  var screens = erpIntegratedB06J41_521_700_screenItems_();
  var blockers = erpIntegratedB06J41_521_700_blockers_();
  var summary = {
    fatal: 0,
    screenCount: screens.length,
    immediateSkeleton: screens.filter(function(x){ return x.phase === 'SKELETON_READY'; }).length,
    permissionRequired: screens.filter(function(x){ return x.permissionRequired; }).length,
    saveBlocked: true,
    actualCreateConfirm: false,
    deployAllowed: false,
    actualExecutionBlocked: true
  };

  return {
    build: ERP_INTEGRATED_B06J41_521_700_BUILD,
    buildNo: ERP_INTEGRATED_B06J41_521_700_BUILD_NO,
    checkedAt: new Date().toISOString(),
    params: { roleCode: roleCode, vendorId: vendorId, eventId: eventId, customerId: customerId },
    summary: summary,
    screens: screens,
    roleCards: erpIntegratedB06J41_521_700_roleCards_(roleCode, vendorId, eventId),
    sampleFlows: erpIntegratedB06J41_521_700_sampleFlows_(),
    emptyGuides: erpIntegratedB06J41_521_700_emptyGuides_(),
    blockers: blockers,
    next: erpIntegratedB06J41_521_700_next_()
  };
}

function erpIntegratedB06J41_521_700_screenItems_() {
  return [
    {no:'521', area:'권한별 메인', screen:'본사 메인', owner:'ERP_CORE', route:'roleMain&roleCode=HQ_ADMIN', phase:'SKELETON_READY', permissionRequired:true, status:'PREVIEW_ONLY', notes:'전체 현황, 승인 필요, CONTROL 차단 상태를 보여준다.'},
    {no:'522', area:'권한별 메인', screen:'업체 메인', owner:'ERP_CORE', route:'roleMain&roleCode=VENDOR_OWNER&vendorId=VND_SAMPLE', phase:'SKELETON_READY', permissionRequired:true, status:'PREVIEW_ONLY', notes:'업체는 별도 앱이 아니라 ERP 내부 지점형 화면으로 유지한다.'},
    {no:'523', area:'권한별 메인', screen:'직원 메인', owner:'ERP_CORE', route:'roleMain&roleCode=STAFF_SALES', phase:'SKELETON_READY', permissionRequired:true, status:'PREVIEW_ONLY', notes:'roleCode 기준으로 업무 메뉴만 안내한다.'},
    {no:'541', area:'고객', screen:'고객검색', owner:'ERP_FIELD', route:'customerSearch', phase:'SKELETON_READY', permissionRequired:true, status:'READ_ONLY', notes:'이름/전화번호/동호수 검색 UI. 저장 없음.'},
    {no:'542', area:'고객', screen:'고객등록', owner:'ERP_FIELD', route:'customerCreate', phase:'SKELETON_READY', permissionRequired:true, status:'SAVE_BLOCKED', notes:'필수값/중복검사 안내만 표시. 실제 저장 차단.'},
    {no:'543', area:'고객', screen:'고객상세', owner:'ERP_FIELD', route:'customerDetail', phase:'SKELETON_READY', permissionRequired:true, status:'READ_ONLY', notes:'고객 기본정보, 판매/계약/SIGN 연결 안내.'},
    {no:'561', area:'판매', screen:'판매등록', owner:'ERP_FIELD', route:'saleCreate', phase:'SKELETON_READY', permissionRequired:true, status:'SAVE_BLOCKED', notes:'품목, 금액, 결제구조, 계약 연결 뼈대. 실제 판매 저장 차단.'},
    {no:'581', area:'계약', screen:'계약생성', owner:'ERP_FIELD', route:'contractCreate', phase:'SKELETON_READY', permissionRequired:true, status:'SAVE_BLOCKED', notes:'판매 기반 계약 DRAFT 생성 UI. 실제 계약 생성 차단.'},
    {no:'601', area:'SIGN', screen:'SIGN 상태 표시', owner:'ERP_FIELD', route:'signStatusLink', phase:'SKELETON_READY', permissionRequired:true, status:'READ_ONLY', notes:'documentId, signStatus, pdfStatus, archiveStatus 표시.'},
    {no:'621', area:'설치', screen:'설치관리', owner:'ERP_FIELD', route:'installManage', phase:'SKELETON_READY', permissionRequired:true, status:'SAVE_BLOCKED', notes:'설치 예정/진행/완료 탭 뼈대. 실제 저장 차단.'},
    {no:'641', area:'A/S', screen:'A/S관리', owner:'ERP_FIELD', route:'asManage', phase:'SKELETON_READY', permissionRequired:true, status:'SAVE_BLOCKED', notes:'신규/처리중/완료/긴급 탭 뼈대. 실제 저장 차단.'},
    {no:'681', area:'공통', screen:'빈화면/권한/차단 안내', owner:'ERP_CORE', route:'emptyGuide', phase:'SKELETON_READY', permissionRequired:false, status:'READY', notes:'빈 데이터일 때 안내문을 출력한다.'}
  ];
}

function erpIntegratedB06J41_521_700_roleCards_(roleCode, vendorId, eventId) {
  var base = [
    {role:'HQ_ADMIN', label:'본사 관리자', visible:'전체 행사/업체/고객/계약/SIGN/정산 현황', restriction:'실제 생성·정산·배포 실행 차단'},
    {role:'VENDOR_OWNER', label:'업체대표', visible:'자기 vendorId 고객/판매/계약/설치/A/S/정산 조회', restriction:'민감 권한과 정산 수정은 본사 승인 필요'},
    {role:'STAFF_SALES', label:'영업직원', visible:'배정 고객/판매/계약/SIGN 상태', restriction:'정산·권한·민감정보 미노출'}
  ];
  return base.map(function(x){
    x.active = (String(x.role).toUpperCase() === String(roleCode).toUpperCase());
    x.vendorFilter = vendorId || 'vendorId 미지정 시 업체 화면은 차단/안내';
    x.eventFilter = eventId || 'eventId 미지정 시 행사 필터 안내';
    return x;
  });
}

function erpIntegratedB06J41_521_700_sampleFlows_() {
  return [
    {name:'고객 → 판매 → 계약 → SIGN', steps:'고객검색 → 고객상세 → 판매등록 뼈대 → 계약생성 뼈대 → SIGN 상태 표시', execution:'저장/생성 차단'},
    {name:'설치/A/S 현장', steps:'계약상태 확인 → 설치 예정/진행/완료 탭 → A/S 접수/처리 탭', execution:'저장 차단'},
    {name:'업체 지점형 화면', steps:'roleCode 확인 → vendorId 필터 → 내 고객/판매/계약/SIGN 표시', execution:'업체 독립 앱/DB 없음'},
    {name:'본사 점검', steps:'전체 요약 → 승인 필요 → CONTROL 차단 상태 확인', execution:'배포/생성 차단'}
  ];
}

function erpIntegratedB06J41_521_700_emptyGuides_() {
  return [
    {caseName:'고객 없음', message:'검색 결과가 없습니다. 고객등록은 현재 시뮬레이션/차단 상태입니다.'},
    {caseName:'판매 없음', message:'판매 내역이 없습니다. 판매등록 화면은 뼈대만 표시되며 실제 저장은 차단됩니다.'},
    {caseName:'계약 없음', message:'계약 내역이 없습니다. 계약생성은 승인 전까지 실행되지 않습니다.'},
    {caseName:'SIGN 문서 없음', message:'연결된 documentId가 없습니다. SIGN 상태는 documentId 기준으로만 표시됩니다.'},
    {caseName:'권한 부족', message:'현재 roleCode 또는 vendorId 기준으로 접근할 수 없습니다.'}
  ];
}

function erpIntegratedB06J41_521_700_blockers_() {
  return [
    {key:'actualCreateConfirm', value:false, status:'BLOCKED', message:'실제 생성 승인 전환 금지'},
    {key:'deployAllowed', value:false, status:'BLOCKED', message:'실제 배포 허용 금지'},
    {key:'actualExecutionBlocked', value:true, status:'LOCKED', message:'실제 실행 차단 유지'},
    {key:'sheetCreate', value:false, status:'BLOCKED', message:'실제 시트 생성 금지'},
    {key:'dbInjection', value:false, status:'BLOCKED', message:'실제 DB 주입 금지'},
    {key:'customerSave', value:false, status:'BLOCKED', message:'고객 실제 저장 금지'},
    {key:'saleSave', value:false, status:'BLOCKED', message:'판매 실제 저장 금지'},
    {key:'contractCreate', value:false, status:'BLOCKED', message:'계약 실제 생성 금지'},
    {key:'installAsSave', value:false, status:'BLOCKED', message:'설치/A/S 실제 저장 금지'},
    {key:'settlementExecution', value:false, status:'BLOCKED', message:'정산 실제 실행 금지'},
    {key:'roleMutation', value:false, status:'BLOCKED', message:'권한 실제 변경 금지'}
  ];
}

function erpIntegratedB06J41_521_700_next_() {
  return [
    '701~860 정산조회/취소정산/예치금/채권/혜택/상품권/발전기금/예치·환입 화면 보강',
    '861~980 직원관리/권한관리/FORM·QR 유입/PORTAL 상태 리포트/최종 통합 점검',
    'CONTROL 승인 전까지 actualCreateConfirm/deployAllowed/actualExecutionBlocked 상태 유지',
    '실제 저장/생성/정산/배포 기능은 열지 않고 화면·조회·안내·차단만 유지'
  ];
}

function erpIntegratedB06J41_521_700_routeSmokeTest() {
  var fnRender = (typeof erpIntegratedB06J41_521_700_renderRoleCustomerSaleFieldHtml === 'function');
  var fnSelf = (typeof erpIntegratedB06J41_521_700_selfTest === 'function');
  var result = {
    ok: !!(fnRender && fnSelf),
    build: ERP_INTEGRATED_B06J41_521_700_BUILD,
    routeFile: 'Code.js',
    moduleFile: ERP_INTEGRATED_B06J41_521_700_MODULE_FILE,
    routes: ['roleCustomerUi','roleMain','customerUi','salesContractUi','fieldWorkUi','asUi','signStatusUi','erp521','erp700'],
    renderFunctionExists: fnRender,
    selfTestExists: fnSelf,
    safety: erpIntegratedB06J41_521_700_safety_()
  };
  Logger.log('[ERP_INTEGRATED 521-700 ROUTE SMOKE TEST] ' + JSON.stringify(result));
  return result;
}

function erpIntegratedB06J41_521_700_selfTest() {
  var model = erpIntegratedB06J41_521_700_buildModel_({roleCode:'HQ_ADMIN'});
  var required = [
    'doGet',
    'erpIntegratedB06J41_521_700_renderRoleCustomerSaleFieldHtml',
    'erpIntegratedB06J41_521_700_selfTest',
    'erpIntegratedB06J41_521_700_routeSmokeTest',
    'erpIntegratedB06J41_521_700_buildModel_',
    'erpIntegratedB06J41_521_700_screenItems_',
    'erpIntegratedB06J41_521_700_blockers_'
  ];
  var missing = required.filter(function(name){ return typeof this[name] !== 'function'; }, this);
  var blockers = erpIntegratedB06J41_521_700_blockers_();
  var result = {
    ok: missing.length === 0 && model.summary.fatal === 0 && model.summary.screenCount === 12,
    build: ERP_INTEGRATED_B06J41_521_700_BUILD,
    checkedAt: new Date().toISOString(),
    fatal: [],
    warnings: [],
    checks: {
      requiredFunctions: {ok: missing.length === 0, missing: missing},
      screens: {ok: model.summary.screenCount === 12, screenCount: model.summary.screenCount, immediateSkeleton: model.summary.immediateSkeleton},
      blockers: {ok: blockers.length === 11, blockedCount: blockers.filter(function(x){ return x.status === 'BLOCKED' || x.status === 'LOCKED'; }).length},
      safety: erpIntegratedB06J41_521_700_safety_()
    }
  };
  Logger.log('[ERP_INTEGRATED 521-700 SELFTEST] ' + JSON.stringify(result));
  return result;
}

function erpIntegratedB06J41_521_700_safety_() {
  return {
    readOnlyUiSkeleton:true,
    deployAllowed:false,
    actualCreateConfirm:false,
    actualExecutionBlocked:true,
    noSheetCreate:true,
    noHeaderAutoCreate:true,
    noDbInjection:true,
    noCustomerSave:true,
    noSaleSave:true,
    noContractCreate:true,
    noInstallAsSave:true,
    noSignDocumentCreate:true,
    noSettlementExecution:true,
    noPaymentRecoveryOffset:true,
    noRoleMutation:true,
    vendorBranchUserGroup:true
  };
}


/* ===== END ERP_Integrated_RoleCustomerSaleField_UI.js ===== */



/* ===== BEGIN ERP_Integrated_RouteSplit_Screens.js ===== */

/**
 * Build: ERP_INTEGRATED_B06J41_981_1120_ROUTE_SPLIT_SCREEN_SAFE
 * File: ERP_Integrated_RouteSplit_Screens.js
 * Project: ERP_CORE
 * Purpose: split prior grouped report routes into distinct read-only screen skeletons while keeping all execution blocked.
 */

var ERP_INTEGRATED_B06J41_981_1120_MODULE_BUILD = 'ERP_INTEGRATED_B06J41_981_1120_ROUTE_SPLIT_SCREEN_SAFE';
var ERP_INTEGRATED_B06J41_981_1120_MODULE_FILE = 'ERP_Integrated_RouteSplit_Screens.js';

function erpIntegratedB06J41_981_1120_renderRouteSplitScreenHtml(ctx) {
  var model = erpIntegratedB06J41_981_1120_buildModel_(ctx || {});
  var template = HtmlService.createTemplateFromFile('H_Split');
  template.model = model;
  return template.evaluate()
    .setTitle('FEELHAUS ERP 개별 화면 분리 981~1120')
    .setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL);
}

function erpIntegratedB06J41_981_1120_buildModel_(ctx) {
  var route = erpIntegratedB06J41_981_1120_normalizeRoute_(ctx);
  var screens = erpIntegratedB06J41_981_1120_buildScreens_();
  var selected = erpIntegratedB06J41_981_1120_findScreen_(route, screens);
  var blockers = erpIntegratedB06J41_981_1120_buildBlockers_();
  var qrFlow = erpIntegratedB06J41_981_1120_buildQrInitialEntryFlow_();
  var status = {
    fatalCount: 0,
    screenCount: screens.length,
    distinctRouteScreenCount: erpIntegratedB06J41_981_1120_countDistinctScreens_(screens),
    selectedRoute: route,
    selectedScreen: selected.key,
    selectedTitle: selected.title,
    qrInitialEntryProtected: true,
    qrFlowStepCount: qrFlow.length,
    blockedCount: blockers.length,
    actualCreateConfirm: false,
    deployAllowed: false,
    actualExecutionBlocked: true,
    vendorBranchUserGroup: true
  };
  return {
    ok: true,
    build: ERP_INTEGRATED_B06J41_981_1120_MODULE_BUILD,
    checkedAt: new Date().toISOString(),
    ctx: ctx || {},
    status: status,
    selected: selected,
    screens: screens,
    qrFlow: qrFlow,
    blockers: blockers,
    protection: erpIntegratedB06J41_981_1120_buildProtection_(),
    nextSteps: erpIntegratedB06J41_981_1120_buildNextSteps_(),
    safety: erpIntegratedB06J41_981_1120_safety_()
  };
}

function erpIntegratedB06J41_981_1120_normalizeRoute_(ctx) {
  ctx = ctx || {};
  var route = String(ctx.page || ctx.route || ctx.view || ctx.mode || '').trim();
  if (!route) {
    var aliases = erpIntegratedB06J41_981_1120_routes_();
    for (var i = 0; i < aliases.length; i++) {
      if (String(ctx[aliases[i]] || '') === '1') return aliases[i];
    }
  }
  return route || 'routeSplit';
}

function erpIntegratedB06J41_981_1120_routes_() {
  return ['routeSplit','screenSplit','roleMain','customerUi','salesContractUi','signStatusUi','fieldWorkUi','asUi','settlementUi','cancelSettlementUi','depositBondUi','benefitGiftUi','fundReturnUi','staffUi','permissionUi','formQrUi','portalReportUi','finalCheckUi','erp981','erp1120'];
}

function erpIntegratedB06J41_981_1120_buildScreens_() {
  return [
    {no:'981', key:'routeSplit', route:'routeSplit', title:'ERP route별 개별 화면 분리 허브', group:'ERP_CORE', project:'ERP_CORE', priority:'HIGH', status:'OVERVIEW_ONLY', actionBlocked:true, description:'321~980 묶음 리포트를 route별 개별 화면으로 분리하는 안전 허브', visibleFields:['route','screenKey','project','status','blocked'], emptyGuide:'개별 route를 선택하면 화면별 점검 항목을 표시합니다.'},
    {no:'1001', key:'roleMain', route:'roleMain', title:'권한별 메인 진입 화면', group:'권한/메인', project:'ERP_CORE', priority:'HIGH', status:'SPLIT_SCREEN_READY', actionBlocked:true, description:'본사/업체/직원 역할별 메인 화면을 roleCode, vendorId, eventId 기준으로 분리 표시', visibleFields:['roleCode','vendorId','eventId','menuScope','dataScope'], emptyGuide:'권한 정보가 없으면 권한별 메뉴가 비어 있다는 안내문을 표시합니다.'},
    {no:'1021', key:'customerUi', route:'customerUi', title:'고객검색 / 고객등록 / 고객상세 화면', group:'고객', project:'ERP_FIELD', priority:'HIGH', status:'SPLIT_SCREEN_READY', actionBlocked:true, description:'고객 검색, 신규 입력, 기존 고객 상세 확인 화면을 분리 표시. 실제 저장은 차단', visibleFields:['customerId','eventId','vendorId','name','phone','dong','ho','memberType','status'], emptyGuide:'검색 결과가 없으면 전체 정보 입력 안내와 FORM/QR 연결 안내를 표시합니다.'},
    {no:'1041', key:'salesContractUi', route:'salesContractUi', title:'판매등록 / 계약생성 화면', group:'판매/계약', project:'ERP_FIELD', priority:'HIGH', status:'SPLIT_SCREEN_READY', actionBlocked:true, description:'판매등록 화면과 계약생성 화면을 분리 표시. 실제 sale/contract 생성은 차단', visibleFields:['saleId','contractId','customerId','eventId','vendorId','amount','contractStatus'], emptyGuide:'판매/계약 데이터가 없으면 임시저장 전 안내와 SIGN 연결 안내를 표시합니다.'},
    {no:'1051', key:'signStatusUi', route:'signStatusUi', title:'SIGN 상태 표시 화면', group:'SIGN', project:'ERP_FIELD/ERP_ADMIN', priority:'HIGH', status:'SPLIT_SCREEN_READY', actionBlocked:true, description:'documentId 기준 signStatus, pdfStatus, archiveStatus, SIGN URL, QR URL, PDF 링크 표시', visibleFields:['documentId','saleId','contractId','signStatus','pdfStatus','archiveStatus','signUrl','qrUrl','pdfUrl'], emptyGuide:'문서가 없으면 SIGN 문서 생성이 아닌 생성 필요 안내만 표시합니다.'},
    {no:'1061', key:'fieldWorkUi', route:'fieldWorkUi', title:'설치관리 화면', group:'설치', project:'ERP_FIELD', priority:'HIGH', status:'SPLIT_SCREEN_READY', actionBlocked:true, description:'설치 예정/진행/완료/지연 상태와 기사배정 안내를 표시. 실제 저장은 차단', visibleFields:['installId','saleId','contractId','customerId','scheduleDate','installerId','status'], emptyGuide:'설치 대상이 없으면 계약/SIGN 완료 후 생성 대상 안내를 표시합니다.'},
    {no:'1071', key:'asUi', route:'asUi', title:'A/S관리 화면', group:'A/S', project:'ERP_FIELD/FORM', priority:'HIGH', status:'SPLIT_SCREEN_READY', actionBlocked:true, description:'A/S 접수, 배정, 일정, 처리, 비용 후보를 표시. 실제 등록/처리는 차단', visibleFields:['asId','requestId','customerId','saleId','asType','priority','status','assignedTo'], emptyGuide:'A/S 데이터가 없으면 FORM/카페 접수 연결 안내를 표시합니다.'},
    {no:'1081', key:'settlementUi', route:'settlementUi', title:'정산조회 화면', group:'정산', project:'ERP_ADMIN/ERP_FIELD', priority:'HIGH', status:'SPLIT_SCREEN_READY', actionBlocked:true, description:'정산 후보, 지급예정, 수수료, 차감, 상태를 조회형으로 표시. 실제 정산 실행은 차단', visibleFields:['settlementId','saleId','contractId','vendorId','amount','fee','deduction','status'], emptyGuide:'정산 후보가 없으면 보관완료 문서와 정산 인계 후보 조건 안내를 표시합니다.'},
    {no:'1085', key:'cancelSettlementUi', route:'cancelSettlementUi', title:'취소정산 화면', group:'취소정산', project:'ERP_ADMIN', priority:'HIGH', status:'SPLIT_SCREEN_READY', actionBlocked:true, description:'원전표 수정 없이 취소정정전표/환수/추가지급 계산 후보를 표시. 확정은 차단', visibleFields:['settlementId','saleId','contractId','cancelReason','refundAmount','recoveryAmount','additionalPaymentAmount'], emptyGuide:'취소정산 후보가 없으면 원전표 직접 수정 금지 안내를 표시합니다.'},
    {no:'1091', key:'depositBondUi', route:'depositBondUi', title:'예치금 / 채권 화면', group:'예치/채권', project:'ERP_ADMIN', priority:'HIGH', status:'SPLIT_SCREEN_READY', actionBlocked:true, description:'예치금, 채권, 잔액, 차감 후보를 회계형 금액으로 표시. 실제 처리 차단', visibleFields:['vendorId','depositBalance','bondBalance','offsetCandidate','status'], emptyGuide:'예치/채권 데이터가 없으면 회계담당 승인 필요 안내를 표시합니다.'},
    {no:'1095', key:'benefitGiftUi', route:'benefitGiftUi', title:'혜택 / 상품권 화면', group:'혜택/상품권', project:'ERP_ADMIN/ERP_FIELD', priority:'HIGH', status:'SPLIT_SCREEN_READY', actionBlocked:true, description:'방문혜택, 정회원혜택, 상품권 지급 후보와 승인 필요 상태를 표시. 실제 지급 차단', visibleFields:['benefitId','eventId','customerId','memberType','giftType','payoutStatus'], emptyGuide:'혜택 대상이 없으면 대상 조건과 중복 지급 방지 안내를 표시합니다.'},
    {no:'1099', key:'fundReturnUi', route:'fundReturnUi', title:'발전기금 / 예치·환입 화면', group:'발전기금/환입', project:'ERP_ADMIN', priority:'HIGH', status:'SPLIT_SCREEN_READY', actionBlocked:true, description:'발전기금 약정/집행/잔액, 예치·환입 후보를 표시. 실제 집행 차단', visibleFields:['eventId','fundId','agreementAmount','executionAmount','returnAmount','approvalStatus'], emptyGuide:'발전기금 데이터가 없으면 본사/대표/회계 승인 흐름 안내를 표시합니다.'},
    {no:'1101', key:'staffUi', route:'staffUi', title:'직원관리 화면', group:'직원', project:'ERP_ADMIN/ERP_FIELD', priority:'HIGH', status:'SPLIT_SCREEN_READY', actionBlocked:true, description:'직원 목록, 부서, 역할, 상태를 표시. 실제 직원 생성/수정은 차단', visibleFields:['userId','vendorId','name','roleCode','department','status'], emptyGuide:'직원이 없으면 업체대표의 직원 생성 요청과 본사 승인 안내를 표시합니다.'},
    {no:'1105', key:'permissionUi', route:'permissionUi', title:'권한관리 화면', group:'권한', project:'ERP_ADMIN', priority:'HIGH', status:'SPLIT_SCREEN_READY', actionBlocked:true, description:'즉시 가능 권한과 본사 승인 필요 권한을 분리 표시. 실제 권한 변경은 차단', visibleFields:['userId','vendorId','roleCode','permissionCode','approvalRequired','status'], emptyGuide:'권한 데이터가 없으면 roleCode 기준 기본 권한 안내를 표시합니다.'},
    {no:'1111', key:'formQrUi', route:'formQrUi', title:'FORM / QR 초기 진입 화면', group:'FORM/QR', project:'FORM/ERP_FIELD', priority:'CRITICAL', status:'SPLIT_SCREEN_READY', actionBlocked:true, description:'행사장 QR 스캔 후 대상 검색, 정회원/준회원/조합원/일반 분기, 정보 보완/전체입력/문의 분기를 표시', visibleFields:['eventId','requestId','customerId','memberType','dong','ho','phone','inquiryType','handoffStatus'], emptyGuide:'QR 검색 결과가 없으면 전체 정보 입력과 협의회/부스/A/S/상담 문의 선택을 표시합니다.', protectedFlow:'QR_INITIAL_ENTRY_REQUIRED'},
    {no:'1115', key:'portalReportUi', route:'portalReportUi', title:'PORTAL 표시용 ERP 상태 리포트 화면', group:'PORTAL', project:'PORTAL/ERP_CORE', priority:'HIGH', status:'SPLIT_SCREEN_READY', actionBlocked:true, description:'PORTAL 본사 허브에 표시할 ERP/SIGN/CONTROL/FORM 상태를 리포트로 표시. 실제 PORTAL 상태 변경은 차단', visibleFields:['erpFieldStatus','erpAdminStatus','signDocumentCount','archiveCount','reopenCandidateCount','settlementQueueCount','controlDeployStatus'], emptyGuide:'상태 데이터가 없으면 점검 필요로 표시하고 실행 버튼은 숨깁니다.'},
    {no:'1120', key:'finalCheckUi', route:'finalCheckUi', title:'최종 점검 화면', group:'최종점검', project:'ERP_CORE/CONTROL', priority:'HIGH', status:'SPLIT_SCREEN_READY', actionBlocked:true, description:'저장/조회/권한/로그/상태변경 최종 점검과 차단 상태를 표시', visibleFields:['testName','result','blocked','message','nextAction'], emptyGuide:'점검 결과가 없으면 selfTest와 routeSmokeTest 실행 안내를 표시합니다.'}
  ];
}

function erpIntegratedB06J41_981_1120_findScreen_(route, screens) {
  var r = String(route || '').toLowerCase();
  if (r === 'screensplit' || r === 'erp981' || r === 'erp1120') r = 'routesplit';
  for (var i = 0; i < screens.length; i++) {
    if (String(screens[i].route).toLowerCase() === r || String(screens[i].key).toLowerCase() === r) return screens[i];
  }
  return screens[0];
}

function erpIntegratedB06J41_981_1120_countDistinctScreens_(screens) {
  var m = {};
  for (var i = 0; i < screens.length; i++) {
    if (screens[i].key !== 'routeSplit') m[screens[i].key] = true;
  }
  return Object.keys(m).length;
}

function erpIntegratedB06J41_981_1120_buildQrInitialEntryFlow_() {
  return [
    {code:'QR_INITIAL_ENTRY', label:'행사장 QR 초기 진입', required:true, protected:true, detail:'정회원 전용 링크가 아니라 eventId 기준 통합 초기 진입 화면으로 시작'},
    {code:'QR_EVENT_VALIDATE', label:'eventId 확인', required:true, protected:true, detail:'행사 연결이 없으면 안내문을 표시하고 자동등록은 차단'},
    {code:'QR_TARGET_SEARCH', label:'대상 검색', required:true, protected:true, detail:'동/호/전화번호/이름 등으로 사전 DB와 고객 후보 검색'},
    {code:'QR_MEMBER_MATCH', label:'정회원 매칭', required:true, protected:true, detail:'정회원이 검색되면 기존 정보 확인 후 부족 정보만 보완 입력'},
    {code:'QR_ASSOCIATE_MEMBER_MATCH', label:'준회원 매칭', required:true, protected:true, detail:'준회원은 기존 후보가 있으면 보완 입력, 없으면 전체 정보 입력'},
    {code:'QR_UNION_MEMBER_MATCH', label:'조합원 매칭', required:true, protected:true, detail:'조합원 또는 협의회 관련 대상은 별도 문의 분기 유지'},
    {code:'QR_GENERAL_VISITOR_FULL_INPUT', label:'일반/미검색 전체 정보 입력', required:true, protected:true, detail:'검색 결과가 없으면 이름/전화/동호/문의유형 등 전체 입력'},
    {code:'QR_INFO_UPDATE_REQUEST', label:'정보 수정 요청', required:true, protected:true, detail:'동호수, 전화번호, 가족/대리 등록 등 수정 요청 분기'},
    {code:'QR_COUNCIL_INQUIRY', label:'협의회 문의', required:true, protected:true, detail:'협의회 관련 문의는 고객 등록과 분리해 문의 후보로 표시'},
    {code:'QR_BOOTH_INQUIRY', label:'부스 문의', required:true, protected:true, detail:'부스/행사 운영 문의는 상담 또는 업무 후보로 인계'},
    {code:'QR_AS_INQUIRY', label:'A/S 문의', required:true, protected:true, detail:'A/S성 문의는 FORM/AS 후보로 연결하고 실제 등록은 차단'},
    {code:'QR_COUNSEL_REQUEST', label:'상담 요청', required:true, protected:true, detail:'상담 희망 고객은 ERP 고객/상담 후보로 인계'},
    {code:'ERP_CUSTOMER_FORM_HANDOFF', label:'ERP 고객/FORM 인계', required:true, protected:true, detail:'customerId/requestId/eventId/vendorId 기준 후보 연결, 실제 저장은 승인 전 차단'}
  ];
}

function erpIntegratedB06J41_981_1120_buildBlockers_() {
  return [
    {key:'actualCreateConfirm', value:false, state:'BLOCKED', message:'actualCreateConfirm=true 전환 금지'},
    {key:'deployAllowed', value:false, state:'BLOCKED', message:'deployAllowed=true 전환 금지'},
    {key:'actualExecutionBlocked', value:true, state:'ACTIVE', message:'actualExecutionBlocked=true 유지'},
    {key:'sheetCreate', value:false, state:'BLOCKED', message:'실제 시트 생성 차단'},
    {key:'headerAutoCreate', value:false, state:'BLOCKED', message:'실제 헤더 자동 추가 차단'},
    {key:'dbInjection', value:false, state:'BLOCKED', message:'실제 DB 주입 차단'},
    {key:'customerSave', value:false, state:'BLOCKED', message:'실제 고객 저장 차단'},
    {key:'saleSave', value:false, state:'BLOCKED', message:'실제 판매 저장 차단'},
    {key:'contractCreate', value:false, state:'BLOCKED', message:'실제 계약 생성 차단'},
    {key:'signDocumentCreate', value:false, state:'BLOCKED', message:'실제 SIGN 문서 생성 차단'},
    {key:'installAsSave', value:false, state:'BLOCKED', message:'실제 설치/A/S 저장 차단'},
    {key:'settlementExecution', value:false, state:'BLOCKED', message:'실제 정산 실행 차단'},
    {key:'cancelSettlementConfirm', value:false, state:'BLOCKED', message:'실제 취소정산 확정 차단'},
    {key:'paymentRecoveryOffset', value:false, state:'BLOCKED', message:'실제 지급/환수/차감 차단'},
    {key:'depositReturnExecution', value:false, state:'BLOCKED', message:'실제 예치·환입 처리 차단'},
    {key:'benefitPayoutExecution', value:false, state:'BLOCKED', message:'실제 혜택/상품권 지급 차단'},
    {key:'fundExecution', value:false, state:'BLOCKED', message:'실제 발전기금 집행 차단'},
    {key:'staffCreate', value:false, state:'BLOCKED', message:'실제 직원 생성 차단'},
    {key:'roleMutation', value:false, state:'BLOCKED', message:'실제 권한 변경 차단'},
    {key:'formAutoRegister', value:false, state:'BLOCKED', message:'FORM/QR 자동등록 실행 차단'},
    {key:'portalMutation', value:false, state:'BLOCKED', message:'PORTAL 상태값 실제 변경 차단'},
    {key:'auditWrite', value:false, state:'BLOCKED', message:'실제 감사로그 쓰기 차단'},
    {key:'deployExecution', value:false, state:'BLOCKED', message:'실제 배포 실행 차단'},
    {key:'backupRecoveryRollback', value:false, state:'BLOCKED', message:'실제 백업/복구/롤백 실행 차단'}
  ];
}

function erpIntegratedB06J41_981_1120_buildProtection_() {
  return [
    'SystemConfig 자동 읽기 보호',
    'FEELHAUS_DB_MASTER 연결 보호',
    '공통 ID 보호: eventId/vendorId/customerId/saleId/contractId/installId/asId/documentId',
    '헤더맵 자동추적 보호',
    '업체는 ERP 내부 지점형 사용자 그룹으로 유지',
    'SIGN documentId/PDF/Drive 저장 추적 보호',
    '정산/취소정산/환수/추가지급 구조 보호',
    'FORM/QR 초기 진입은 정회원 전용 링크가 아니라 대상 검색 기반 통합 진입으로 보호',
    'CONTROL 차단 상태 유지: deployAllowed=false, actualCreateConfirm=false, actualExecutionBlocked=true'
  ];
}

function erpIntegratedB06J41_981_1120_buildNextSteps_() {
  return [
    '981~1120 route별 화면 분리 selfTest 및 routeSmokeTest 확인',
    'roleMain/customerUi/salesContractUi 등 주요 route별 화면이 서로 다른 제목/항목을 표시하는지 확인',
    'formQrUi에서 QR_INITIAL_ENTRY → QR_TARGET_SEARCH → 유형별 분기 흐름이 보호 표시되는지 확인',
    '개별 화면 분리 후에도 실제 저장/생성/정산/배포가 모두 차단되는지 확인',
    '다음 단계는 1121~1300 개별 화면 세부 UI 입력폼/상세 카드 보강으로 진행하되 실제 저장은 계속 차단'
  ];
}

function erpIntegratedB06J41_981_1120_safety_() {
  return {
    readOnlyRouteSplit: true,
    deployAllowed: false,
    actualCreateConfirm: false,
    actualExecutionBlocked: true,
    noSheetCreate: true,
    noHeaderAutoCreate: true,
    noDbInjection: true,
    noCustomerSave: true,
    noSaleSave: true,
    noContractCreate: true,
    noSignDocumentCreate: true,
    noInstallAsSave: true,
    noSettlementExecution: true,
    noCancelSettlementConfirm: true,
    noPaymentRecoveryOffset: true,
    noDepositReturnExecution: true,
    noBenefitPayoutExecution: true,
    noFundExecution: true,
    noStaffCreate: true,
    noRoleMutation: true,
    noFormAutoRegister: true,
    noPortalMutation: true,
    noAuditWrite: true,
    noDeployExecution: true,
    noBackupRecoveryRollbackExecution: true,
    vendorBranchUserGroup: true,
    qrInitialEntryTargetSearchProtected: true
  };
}

function erpIntegratedB06J41_981_1120_selfTest() {
  var screens = erpIntegratedB06J41_981_1120_buildScreens_();
  var qrFlow = erpIntegratedB06J41_981_1120_buildQrInitialEntryFlow_();
  var blockers = erpIntegratedB06J41_981_1120_buildBlockers_();
  var missing = [];
  var required = [
    'erpIntegratedB06J41_981_1120_renderRouteSplitScreenHtml',
    'erpIntegratedB06J41_981_1120_selfTest',
    'erpIntegratedB06J41_981_1120_routeSmokeTest',
    'erpIntegratedB06J41_981_1120_buildScreens_',
    'erpIntegratedB06J41_981_1120_buildQrInitialEntryFlow_',
    'erpIntegratedB06J41_981_1120_safety_'
  ];
  for (var i = 0; i < required.length; i++) {
    if (typeof this[required[i]] !== 'function') missing.push(required[i]);
  }
  var distinct = erpIntegratedB06J41_981_1120_countDistinctScreens_(screens);
  var fatal = [];
  if (missing.length) fatal.push('필수 함수 누락: ' + missing.join(', '));
  if (screens.length !== 17) fatal.push('화면 정의 수 불일치: ' + screens.length);
  if (distinct !== 16) fatal.push('개별 화면 수 불일치: ' + distinct);
  if (qrFlow.length !== 13) fatal.push('QR 초기 진입 보호 흐름 수 불일치: ' + qrFlow.length);
  var result = {
    ok: fatal.length === 0,
    build: ERP_INTEGRATED_B06J41_981_1120_MODULE_BUILD,
    checkedAt: new Date().toISOString(),
    fatal: fatal,
    warnings: [],
    checks: {
      requiredFunctions: {ok: missing.length === 0, missing: missing},
      screens: {ok: screens.length === 17, screenCount: screens.length, distinctRouteScreenCount: distinct},
      qrInitialEntry: {ok: qrFlow.length === 13, qrFlowStepCount: qrFlow.length, targetSearchProtected: true, directRegularMemberLink: false},
      blockers: {ok: blockers.length >= 20, blockedCount: blockers.length},
      safety: erpIntegratedB06J41_981_1120_safety_()
    }
  };
  Logger.log('[ERP_INTEGRATED 981-1120 SELFTEST] ' + JSON.stringify(result));
  return result;
}

function erpIntegratedB06J41_981_1120_routeSmokeTest() {
  var routes = erpIntegratedB06J41_981_1120_routes_();
  var result = {
    ok: true,
    build: ERP_INTEGRATED_B06J41_981_1120_MODULE_BUILD,
    routeFile: 'Code.js',
    moduleFile: ERP_INTEGRATED_B06J41_981_1120_MODULE_FILE,
    routes: routes,
    splitRoutes: ['roleMain','customerUi','salesContractUi','signStatusUi','fieldWorkUi','asUi','settlementUi','cancelSettlementUi','depositBondUi','benefitGiftUi','fundReturnUi','staffUi','permissionUi','formQrUi','portalReportUi','finalCheckUi'],
    renderFunctionExists: typeof erpIntegratedB06J41_981_1120_renderRouteSplitScreenHtml === 'function',
    selfTestExists: typeof erpIntegratedB06J41_981_1120_selfTest === 'function',
    qrInitialEntryTargetSearchProtected: true,
    safety: erpIntegratedB06J41_981_1120_safety_()
  };
  Logger.log('[ERP_INTEGRATED 981-1120 ROUTE SMOKE TEST] ' + JSON.stringify(result));
  return result;
}


/* ===== END ERP_Integrated_RouteSplit_Screens.js ===== */



/* ===== BEGIN ERP_Integrated_Detail_UI.js ===== */

/**
 * Build: ERP_INTEGRATED_B06J41_1121_1260_ROLE_CUSTOMER_SALE_DETAIL_UI_SAFE
 * File: ERP_Integrated_Detail_UI.js
 * Project: ERP_CORE
 * Purpose: route-level detailed UI skeletons for role/customer/sale/contract/SIGN/install/A/S while all execution remains blocked.
 */

var ERP_INTEGRATED_B06J41_1121_1260_BUILD = 'ERP_INTEGRATED_B06J41_1121_1260_ROLE_CUSTOMER_SALE_DETAIL_UI_SAFE';
var ERP_INTEGRATED_B06J41_1121_1260_FILE = 'ERP_Integrated_Detail_UI.js';

function erpIntegratedB06J41_1121_1260_renderDetailUiHtml(ctx) {
  var model = erpIntegratedB06J41_1121_1260_buildModel_(ctx || {});
  var template = HtmlService.createTemplateFromFile('H_Detail');
  template.model = model;
  return template.evaluate()
    .setTitle('FEELHAUS ERP 실사용 상세 UI 1121~1260')
    .setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL);
}

function erpIntegratedB06J41_1121_1260_buildModel_(ctx) {
  var route = erpIntegratedB06J41_1121_1260_normalizeRoute_(ctx);
  var screens = erpIntegratedB06J41_1121_1260_screens_();
  var selected = erpIntegratedB06J41_1121_1260_findScreen_(route, screens);
  var validationRules = erpIntegratedB06J41_1121_1260_validationRules_();
  var blockers = erpIntegratedB06J41_1121_1260_blockers_();
  var selectedSections = erpIntegratedB06J41_1121_1260_sectionsFor_(selected.key);
  return {
    ok: true,
    build: ERP_INTEGRATED_B06J41_1121_1260_BUILD,
    checkedAt: new Date().toISOString(),
    route: route,
    selected: selected,
    screens: screens,
    sections: selectedSections,
    validationRules: validationRules,
    blockers: blockers,
    emptyGuides: erpIntegratedB06J41_1121_1260_emptyGuides_(selected.key),
    safety: erpIntegratedB06J41_1121_1260_safety_(),
    status: {
      fatalCount: 0,
      detailScreenCount: screens.length,
      sectionCount: selectedSections.length,
      validationRuleCount: validationRules.length,
      blockedCount: blockers.length,
      actualCreateConfirm: false,
      deployAllowed: false,
      actualExecutionBlocked: true,
      readOnlyDetailUi: true,
      vendorBranchUserGroup: true
    },
    nextSteps: erpIntegratedB06J41_1121_1260_nextSteps_(),
    protection: erpIntegratedB06J41_1121_1260_protection_()
  };
}

function erpIntegratedB06J41_1121_1260_normalizeRoute_(ctx) {
  ctx = ctx || {};
  var route = String(ctx.page || ctx.route || ctx.view || ctx.mode || '').trim();
  if (!route) {
    var routes = erpIntegratedB06J41_1121_1260_routes_();
    for (var i = 0; i < routes.length; i++) {
      if (String(ctx[routes[i]] || '') === '1') return routes[i];
    }
  }
  return route || 'detailUi';
}

function erpIntegratedB06J41_1121_1260_routes_() {
  return ['detailUi','roleDetail','roleMain','customerDetailUi','customerUi','saleDetailUi','salesContractUi','contractDetailUi','signDetailUi','signStatusUi','fieldDetailUi','fieldWorkUi','asDetailUi','asUi','emptyGuideUi','validationSimUi','erp1121','erp1260'];
}

function erpIntegratedB06J41_1121_1260_screens_() {
  return [
    {no:'1121', key:'detailUi', route:'detailUi', title:'ERP 실사용 상세 UI 허브', project:'ERP_CORE', status:'DETAIL_OVERVIEW', target:'전체 상세 UI', purpose:'route별 상세 UI 진입과 차단 상태를 한 화면에서 확인', fields:['route','screenKey','status','blocked','nextAction']},
    {no:'1121', key:'roleDetail', route:'roleDetail', title:'권한별 메인 화면 상세화', project:'ERP_CORE', status:'DETAIL_READY', target:'본사/업체/직원 메인', purpose:'roleCode, vendorId, eventId 기준으로 메뉴/데이터 범위를 분리 표시', fields:['roleCode','vendorId','eventId','menuScope','dataScope','notice']},
    {no:'1141', key:'customerDetailUi', route:'customerDetailUi', title:'고객검색 / 고객등록 / 고객상세 UI 상세화', project:'ERP_FIELD', status:'DETAIL_READY', target:'고객 실무 화면', purpose:'고객 검색, 기존 고객 상세, 신규 입력 폼, 빈 결과 안내를 분리 표시', fields:['customerId','eventId','vendorId','name','phone','dong','ho','memberType','status']},
    {no:'1161', key:'saleDetailUi', route:'saleDetailUi', title:'판매등록 UI 상세화', project:'ERP_FIELD', status:'DETAIL_READY', target:'판매 실무 화면', purpose:'고객 선택, 품목, 금액, 결제구조, 잔금 계산, 카드 매칭 안내를 표시', fields:['saleId','customerId','items','amount','deposit','balance','paymentMethod','cardMatchStatus']},
    {no:'1181', key:'contractDetailUi', route:'contractDetailUi', title:'계약생성 UI 상세화', project:'ERP_FIELD/SIGN', status:'DETAIL_READY', target:'계약 실무 화면', purpose:'판매 기반 계약 초안, 계약 상태, SIGN 문서 연결, 보관완료 잠금 안내 표시', fields:['contractId','saleId','customerId','documentId','contractStatus','signStatus','archiveStatus']},
    {no:'1201', key:'signDetailUi', route:'signDetailUi', title:'SIGN 상태 표시 UI 상세화', project:'ERP_FIELD/ERP_ADMIN/SIGN', status:'DETAIL_READY', target:'SIGN 상태 화면', purpose:'documentId 기준 sign/pdf/archive 상태와 SIGN URL/QR/PDF 링크를 표시', fields:['documentId','signStatus','pdfStatus','archiveStatus','signUrl','qrUrl','pdfUrl']},
    {no:'1221', key:'fieldDetailUi', route:'fieldDetailUi', title:'설치관리 UI 상세화', project:'ERP_FIELD', status:'DETAIL_READY', target:'설치 실무 화면', purpose:'설치 예정/진행/완료/지연 상태, 기사 배정 안내, 사진/서명 연결 안내 표시', fields:['installId','saleId','contractId','customerId','scheduleAt','installerId','installStatus']},
    {no:'1231', key:'asDetailUi', route:'asDetailUi', title:'A/S관리 UI 상세화', project:'ERP_FIELD/FORM', status:'DETAIL_READY', target:'A/S 실무 화면', purpose:'A/S 접수, 처리상태, 긴급도, 담당자, 비용 부담 주체, FORM 유입 연결 안내 표시', fields:['asId','customerId','saleId','requestId','priority','assigneeId','asStatus','costOwner']},
    {no:'1241', key:'emptyGuideUi', route:'emptyGuideUi', title:'빈화면 안내 / 권한 안내 상세화', project:'ERP_CORE', status:'DETAIL_READY', target:'공통 안내', purpose:'데이터 없음, 권한 없음, 승인 필요, 생성 차단 상태를 사용자 친화적으로 표시', fields:['emptyType','message','requiredRole','nextAction','blocked']},
    {no:'1251', key:'validationSimUi', route:'validationSimUi', title:'검증 시뮬레이션 / 실행 차단 안내', project:'ERP_CORE/CONTROL', status:'DETAIL_READY', target:'저장 전 검증', purpose:'필수값/형식/권한/중복/상태전이 검증 순서를 시뮬레이션하고 실제 저장은 차단', fields:['validationStep','result','reason','blocked','controlRequired']}
  ];
}

function erpIntegratedB06J41_1121_1260_findScreen_(route, screens) {
  var r = String(route || '').toLowerCase();
  var aliases = {
    rolemain:'roleDetail', customerui:'customerDetailUi', salescontractui:'saleDetailUi', signstatusui:'signDetailUi',
    fieldworkui:'fieldDetailUi', asui:'asDetailUi', erp1121:'detailUi', erp1260:'validationSimUi'
  };
  if (aliases[r]) r = String(aliases[r]).toLowerCase();
  for (var i = 0; i < screens.length; i++) {
    if (String(screens[i].route).toLowerCase() === r || String(screens[i].key).toLowerCase() === r) return screens[i];
  }
  return screens[0];
}

function erpIntegratedB06J41_1121_1260_sectionsFor_(screenKey) {
  var base = [
    {title:'상단 상태 영역', detail:'빌드번호, 차단 상태, 현재 route, 권한/이벤트/업체 기준을 표시'},
    {title:'권한/데이터 범위', detail:'roleCode, vendorId, eventId 기준으로 표시 가능 범위를 안내'},
    {title:'검증 순서', detail:'필수값 → 형식 → 권한 → 중복 → 상태전이 순서로 시뮬레이션'},
    {title:'실행 차단', detail:'CONTROL 승인 전 실제 저장/생성/변경은 열지 않음'}
  ];
  var map = {
    roleDetail:[{title:'본사 메인',detail:'전체 현황, 승인 필요, 리스크, CONTROL 진단 링크 표시'},{title:'업체 메인',detail:'내 고객/판매/계약/설치/A/S/정산 조회 범위 표시'},{title:'직원 메인',detail:'오늘 할 일, 내 배정건, 서명대기, 설치/A/S 처리 안내'}],
    customerDetailUi:[{title:'고객 검색',detail:'이름/전화/동/호/고객ID 검색 입력 UI'},{title:'고객 등록',detail:'신규 입력 폼과 QR/FORM 유입 연결 안내'},{title:'고객 상세',detail:'고객 기본정보, 판매/계약/SIGN/설치/A/S 연결 상태 표시'}],
    saleDetailUi:[{title:'고객 선택',detail:'기존 고객 선택 또는 신규 입력 후보 안내'},{title:'품목/금액',detail:'품목 추가, 수량, 단가, 합계, 회계형 표시 기준'},{title:'결제/잔금',detail:'계약금/잔금 자동 계산, 카드 매칭 리스트 선택 안내'}],
    contractDetailUi:[{title:'계약 초안',detail:'saleId 기반 계약 초안 상태와 필수값 표시'},{title:'SIGN 연결',detail:'documentId, SIGN URL, QR URL, PDF 상태 표시'},{title:'잠금 안내',detail:'보관완료 후 일반 수정 금지 및 재오픈 승인 필요 안내'}],
    signDetailUi:[{title:'SIGN 상태 카드',detail:'서명/PDF/보관 상태 뱃지 표시'},{title:'문서 링크',detail:'SIGN URL, QR URL, PDF Drive 링크 표시'},{title:'정산 후보',detail:'보관완료 후 정산 인계 후보 상태 안내'}],
    fieldDetailUi:[{title:'설치 리스트',detail:'예정/진행/완료/지연 탭 뼈대'},{title:'설치 상세',detail:'주소, 요청사항, 기사, 사진, 서명 연결 안내'},{title:'상태변경 시뮬레이션',detail:'실제 완료 저장은 차단하고 검증 단계만 표시'}],
    asDetailUi:[{title:'A/S 접수',detail:'FORM/QR/카페 유입 requestId 연결 안내'},{title:'처리 상세',detail:'내용, 사진, 처리이력, 비용, 부담 주체 표시'},{title:'정산 반영 안내',detail:'A/S 비용 정산 반영은 승인 전 차단'}],
    emptyGuideUi:[{title:'데이터 없음',detail:'빈화면 대신 다음 작업 안내 표시'},{title:'권한 없음',detail:'요청 권한과 현재 roleCode 차이를 설명'},{title:'승인 필요',detail:'본사/CONTROL 승인 필요 상태 표시'}],
    validationSimUi:[{title:'필수값 검사',detail:'필수 ID와 상태값 누락 안내'},{title:'권한 검사',detail:'role/vendor/event 기준 통과 여부 표시'},{title:'저장 차단',detail:'실제 저장 전 CONTROL 승인 필요 표시'}]
  };
  return base.concat(map[screenKey] || []);
}

function erpIntegratedB06J41_1121_1260_validationRules_() {
  return [
    {step:'REQUIRED_VALUES', label:'필수값 검사', blocked:false, detail:'eventId, vendorId, customerId 등 핵심 ID 확인'},
    {step:'FORMAT_CHECK', label:'형식 검사', blocked:false, detail:'전화번호, 금액, 날짜, 상태값 형식 확인'},
    {step:'ROLE_SCOPE_CHECK', label:'권한 검사', blocked:false, detail:'roleCode, vendorId, eventId 기준 접근 범위 확인'},
    {step:'DUPLICATE_CHECK', label:'중복 검사', blocked:false, detail:'고객/판매/계약 중복 후보 안내'},
    {step:'STATUS_TRANSITION_CHECK', label:'상태전이 검사', blocked:false, detail:'허용된 상태전이만 안내'},
    {step:'SAVE_EXECUTION', label:'저장 실행', blocked:true, detail:'actualExecutionBlocked=true 상태라 실제 저장은 차단'},
    {step:'AUDIT_WRITE', label:'감사로그 기록', blocked:true, detail:'실제 감사로그 쓰기는 차단하고 시뮬레이션만 표시'}
  ];
}

function erpIntegratedB06J41_1121_1260_blockers_() {
  return [
    'SHEET_CREATE','HEADER_AUTO_CREATE','DB_INJECTION','CUSTOMER_SAVE','SALE_SAVE','CONTRACT_CREATE','SIGN_DOCUMENT_CREATE','INSTALL_SAVE','AS_SAVE','SETTLEMENT_EXECUTE','PAYMENT_RECOVERY_OFFSET','ROLE_MUTATION','FORM_AUTO_REGISTER','PORTAL_MUTATION','AUDIT_WRITE','DEPLOY_EXECUTE','BACKUP_RECOVERY_ROLLBACK'
  ].map(function(k){ return {key:k, state:'BLOCKED'}; });
}

function erpIntegratedB06J41_1121_1260_emptyGuides_(screenKey) {
  return [
    '데이터가 없으면 빈 화면 대신 쉬운 한글 안내문을 표시합니다.',
    '권한이 없으면 필요한 roleCode와 본사 승인 필요 여부를 표시합니다.',
    '저장 버튼은 실제 저장이 아니라 검증 시뮬레이션 또는 차단 안내만 표시합니다.',
    '보관완료/마감/잠금 상태는 일반 수정 금지 안내를 표시합니다.'
  ];
}

function erpIntegratedB06J41_1121_1260_safety_() {
  return {
    readOnlyDetailUi:true,
    deployAllowed:false,
    actualCreateConfirm:false,
    actualExecutionBlocked:true,
    noSheetCreate:true,
    noHeaderAutoCreate:true,
    noDbInjection:true,
    noCustomerSave:true,
    noSaleSave:true,
    noContractCreate:true,
    noSignDocumentCreate:true,
    noInstallAsSave:true,
    noSettlementExecution:true,
    noPaymentRecoveryOffset:true,
    noRoleMutation:true,
    noFormAutoRegister:true,
    noPortalMutation:true,
    noAuditWrite:true,
    noDeployExecution:true,
    vendorBranchUserGroup:true
  };
}

function erpIntegratedB06J41_1121_1260_protection_() {
  return [
    'SystemConfig 자동 읽기와 FEELHAUS_DB_MASTER 연결 기준 유지',
    '공통 ID와 헤더맵 기반 연결 유지',
    '업체는 별도 앱이 아니라 ERP 내부 지점형 화면 유지',
    'SIGN documentId / PDF / Drive 저장 추적 구조 보호',
    '정산/취소정산/환수/추가지급 실제 실행 차단 유지',
    '빈화면 대신 쉬운 한글 안내문 표시'
  ];
}

function erpIntegratedB06J41_1121_1260_nextSteps_() {
  return [
    '1121~1260 상세 UI route별 화면 테스트',
    '1261~1400 정산/혜택/직원/권한/FORM/PORTAL 상세 UI 분리',
    '실제 저장 전 CONTROL 승인 조건 재검토',
    'SheetPolicy/HeaderPolicy 확정 전 실제 생성 금지 유지'
  ];
}

function erpIntegratedB06J41_1121_1260_routeSmokeTest() {
  return {
    ok:true,
    build:ERP_INTEGRATED_B06J41_1121_1260_BUILD,
    routeFile:'Code.js',
    moduleFile:ERP_INTEGRATED_B06J41_1121_1260_FILE,
    routes:erpIntegratedB06J41_1121_1260_routes_(),
    renderFunctionExists: typeof erpIntegratedB06J41_1121_1260_renderDetailUiHtml === 'function',
    selfTestExists: typeof erpIntegratedB06J41_1121_1260_selfTest === 'function',
    safety: erpIntegratedB06J41_1121_1260_safety_()
  };
}

function erpIntegratedB06J41_1121_1260_selfTest() {
  var screens = erpIntegratedB06J41_1121_1260_screens_();
  var rules = erpIntegratedB06J41_1121_1260_validationRules_();
  var blockers = erpIntegratedB06J41_1121_1260_blockers_();
  var required = ['erpIntegratedB06J41_1121_1260_renderDetailUiHtml','erpIntegratedB06J41_1121_1260_selfTest','erpIntegratedB06J41_1121_1260_routeSmokeTest','erpIntegratedB06J41_1121_1260_buildModel_'];
  var missing = [];
  for (var i=0;i<required.length;i++) if (typeof this[required[i]] !== 'function') missing.push(required[i]);
  return {
    ok: missing.length === 0 && screens.length === 10 && rules.length === 7 && blockers.length === 17,
    build: ERP_INTEGRATED_B06J41_1121_1260_BUILD,
    checkedAt: new Date().toISOString(),
    fatal: [],
    warnings: [],
    checks: {
      requiredFunctions:{ok:missing.length===0, missing:missing},
      screens:{ok:screens.length===10, screenCount:screens.length, detailScreenCount:9},
      validation:{ok:rules.length===7, validationRuleCount:rules.length, saveExecutionBlocked:true},
      blockers:{ok:blockers.length===17, blockedCount:blockers.length},
      safety: erpIntegratedB06J41_1121_1260_safety_()
    }
  };
}


/* ===== END ERP_Integrated_Detail_UI.js ===== */
