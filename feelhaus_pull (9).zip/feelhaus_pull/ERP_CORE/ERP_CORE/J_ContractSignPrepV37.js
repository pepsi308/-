/**
 * FEELHAUS ERP CORE V37
 * Purpose: prepare ERP_계약관리 headers and check SIGN connection keys for FIELD contractPrecheck READ ONLY.
 * Safe rule: header-map based, append missing ERP_계약관리 headers only, no row data changes,
 * no contract creation, no SIGN documentId creation, no PDF, no settlement, no external handoff.
 */
var ERP_CORE_CONTRACT_SIGN_V37_BUILD = 'ERP_CORE_CONTRACT_SIGN_PREP_V37';
var ERP_CORE_CONTRACT_SIGN_V37_SETUP_DB_ID = '17VMSpgSZCvIrUlgcw8yCNcnl8WQWo2IcRf5tDCcuJGM';
var ERP_CORE_CONTRACT_SIGN_V37_CONFIG_SHEET = 'SystemConfig';

function runErpCoreContractSignPrepV37DryRun() {
  return erpCoreContractSignPrepV37_({ apply: false });
}

function runErpCoreContractSignPrepV37Apply() {
  return erpCoreContractSignPrepV37_({ apply: true });
}

function erpCoreContractSignPrepV37_(options) {
  options = options || {};
  var apply = options.apply === true;
  var result = {
    ok: false,
    build: ERP_CORE_CONTRACT_SIGN_V37_BUILD,
    checkedAt: new Date().toISOString(),
    mode: apply ? 'APPLY_APPEND_MISSING_CONTRACT_HEADERS' : 'DRY_RUN_NO_WRITE',
    protectedMode: 'READ_ONLY_PRECHECK_ONLY',
    blocked: ['contractCreate', 'signDocumentCreate', 'pdfCreate', 'settlementApply', 'externalHandoff', 'update', 'delete'],
    contractSheetName: 'ERP_계약관리',
    signSheetName: 'SIGN_Documents',
    salesSheetName: 'ERP_판매관리',
    contractRequiredHeaders: erpCoreContractSignPrepV37_contractHeaders_(),
    signRequiredKeys: ['documentId', 'contractId', 'saleId', 'customerId', 'eventId', 'vendorId', 'status'],
    salesRequiredKeys: ['saleId', 'eventId', 'vendorId', 'customerId', 'status'],
    missingBefore: [],
    addedHeaders: [],
    finalMissing: [],
    duplicateHeaders: [],
    sign: { exists: false, missingKeys: [], duplicateHeaders: [] },
    sales: { exists: false, missingKeys: [], duplicateHeaders: [] },
    fatal: [],
    warnings: [],
    nextAction: ''
  };

  try {
    var config = erpCoreContractSignPrepV37_loadConfig_();
    var masterId = config.FEELHAUS_DB_MASTER_ID || config.DB_MASTER_ID || config.SPREADSHEET_ID;
    if (!masterId) throw new Error('FEELHAUS_DB_MASTER_ID 또는 DB_MASTER_ID 없음');

    var ss = SpreadsheetApp.openById(masterId);
    var contractSheet = ss.getSheetByName(result.contractSheetName);
    if (!contractSheet) throw new Error(result.contractSheetName + ' 시트 없음');

    var contractHeaderState = erpCoreContractSignPrepV37_readHeaderState_(contractSheet, result.contractRequiredHeaders);
    result.missingBefore = contractHeaderState.missing.slice();
    result.duplicateHeaders = contractHeaderState.duplicates.slice();

    if (apply && result.missingBefore.length) {
      var startCol = contractSheet.getLastColumn() + 1;
      contractSheet.getRange(1, startCol, 1, result.missingBefore.length).setValues([result.missingBefore]);
      result.addedHeaders = result.missingBefore.slice();
    }

    var finalContractState = erpCoreContractSignPrepV37_readHeaderState_(contractSheet, result.contractRequiredHeaders);
    result.finalMissing = finalContractState.missing.slice();

    var signSheet = ss.getSheetByName(result.signSheetName);
    if (signSheet) {
      result.sign.exists = true;
      var signState = erpCoreContractSignPrepV37_readHeaderState_(signSheet, result.signRequiredKeys);
      result.sign.missingKeys = signState.missing.slice();
      result.sign.duplicateHeaders = signState.duplicates.slice();
    } else {
      result.sign.exists = false;
      result.warnings.push(result.signSheetName + ' 시트 없음: SIGN 연결 키는 FIELD precheck에서 생성 없이 경고로 표시');
    }

    var salesSheet = ss.getSheetByName(result.salesSheetName);
    if (salesSheet) {
      result.sales.exists = true;
      var salesState = erpCoreContractSignPrepV37_readHeaderState_(salesSheet, result.salesRequiredKeys);
      result.sales.missingKeys = salesState.missing.slice();
      result.sales.duplicateHeaders = salesState.duplicates.slice();
    } else {
      result.sales.exists = false;
      result.fatal.push(result.salesSheetName + ' 시트 없음');
    }

    if (result.duplicateHeaders.length) result.warnings.push('ERP_계약관리 중복 헤더 확인 필요: ' + result.duplicateHeaders.join(', '));
    if (result.sign.duplicateHeaders.length) result.warnings.push('SIGN_Documents 중복 헤더 확인 필요: ' + result.sign.duplicateHeaders.join(', '));
    if (result.sales.duplicateHeaders.length) result.warnings.push('ERP_판매관리 중복 헤더 확인 필요: ' + result.sales.duplicateHeaders.join(', '));
    if (result.sign.exists && result.sign.missingKeys.length) result.warnings.push('SIGN 연결 키 미통과: ' + result.sign.missingKeys.join(', '));
    if (result.sales.missingKeys.length) result.fatal.push('Sales DRAFT precheck 필수 키 누락: ' + result.sales.missingKeys.join(', '));
    if (apply && result.finalMissing.length) result.fatal.push('계약관리 필수 헤더 보정 후에도 누락: ' + result.finalMissing.join(', '));

    result.ok = result.fatal.length === 0 && (!apply || result.finalMissing.length === 0);
    result.nextAction = apply
      ? 'FIELD V37/V38 contractPrecheck READ ONLY smoke 실행. 계약/SIGN/PDF/정산 실제 생성은 계속 차단'
      : '문제 없으면 runErpCoreContractSignPrepV37Apply 실행';
  } catch (err) {
    result.ok = false;
    result.fatal.push(err && err.message ? err.message : String(err));
    result.nextAction = '오류 수정 후 재실행';
  }

  Logger.log(JSON.stringify({
    ok: result.ok,
    build: result.build,
    mode: result.mode,
    protectedMode: result.protectedMode,
    missingBefore: result.missingBefore,
    addedHeaders: result.addedHeaders,
    finalMissing: result.finalMissing,
    sign: result.sign,
    sales: result.sales,
    fatal: result.fatal,
    warnings: result.warnings,
    nextAction: result.nextAction
  }, null, 2));
  return result;
}

function erpCoreContractSignPrepV37_contractHeaders_() {
  return [
    'documentId',
    'contractStatus',
    'signStatus',
    'pdfStatus',
    'contractAmount',
    'totalAmount',
    'depositAmount',
    'balanceAmount',
    'paymentStructure',
    'paymentMethod',
    'saleId',
    'eventId',
    'vendorId',
    'customerId',
    'status',
    'statusReason',
    'createdAt',
    'createdBy',
    'updatedAt',
    'updatedBy'
  ];
}

function erpCoreContractSignPrepV37_readHeaderState_(sheet, requiredHeaders) {
  var lastCol = Math.max(sheet.getLastColumn(), 1);
  var headers = sheet.getRange(1, 1, 1, lastCol).getValues()[0].map(function (v) {
    return String(v || '').trim();
  });
  var seen = {};
  var duplicates = [];
  for (var i = 0; i < headers.length; i++) {
    if (!headers[i]) continue;
    if (seen[headers[i]] && duplicates.indexOf(headers[i]) < 0) duplicates.push(headers[i]);
    seen[headers[i]] = true;
  }
  var missing = [];
  for (var r = 0; r < requiredHeaders.length; r++) {
    if (!seen[requiredHeaders[r]]) missing.push(requiredHeaders[r]);
  }
  return { headers: headers, missing: missing, duplicates: duplicates };
}

function erpCoreContractSignPrepV37_loadConfig_() {
  var setupSs = SpreadsheetApp.openById(ERP_CORE_CONTRACT_SIGN_V37_SETUP_DB_ID);
  var sheet = setupSs.getSheetByName(ERP_CORE_CONTRACT_SIGN_V37_CONFIG_SHEET);
  if (!sheet) throw new Error('SystemConfig 시트 없음');

  var values = sheet.getDataRange().getValues();
  var config = {};
  for (var r = 1; r < values.length; r++) {
    var key = String(values[r][0] || '').trim();
    var value = String(values[r][1] || '').trim();
    if (key) config[key] = value;
  }
  return config;
}
