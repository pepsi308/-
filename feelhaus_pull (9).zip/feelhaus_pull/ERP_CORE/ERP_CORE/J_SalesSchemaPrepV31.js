/**
 * FEELHAUS ERP CORE V31
 * Purpose: prepare ERP_판매관리 headers required for FIELD Sales DRAFT limited save.
 * Safe rule: header-map based, append missing headers only, no row data changes.
 */
var ERP_CORE_SALES_SCHEMA_V31_BUILD = 'ERP_CORE_SALES_SCHEMA_PREP_V31';
var ERP_CORE_SALES_SCHEMA_V31_SETUP_DB_ID = '17VMSpgSZCvIrUlgcw8yCNcnl8WQWo2IcRf5tDCcuJGM';
var ERP_CORE_SALES_SCHEMA_V31_CONFIG_SHEET = 'SystemConfig';

function runErpCoreSalesSchemaPrepV31DryRun() {
  return erpCoreSalesSchemaPrepV31_({ apply: false });
}

function runErpCoreSalesSchemaPrepV31Apply() {
  return erpCoreSalesSchemaPrepV31_({ apply: true });
}

function erpCoreSalesSchemaPrepV31_(options) {
  options = options || {};
  var apply = options.apply === true;
  var result = {
    ok: false,
    build: ERP_CORE_SALES_SCHEMA_V31_BUILD,
    checkedAt: new Date().toISOString(),
    mode: apply ? 'APPLY_APPEND_MISSING_HEADERS' : 'DRY_RUN_NO_WRITE',
    sheetName: 'ERP_판매관리',
    requiredHeaders: [
      'saleId', 'eventId', 'vendorId', 'customerId', 'status', 'statusReason',
      'createdAt', 'createdBy', 'updatedAt', 'updatedBy',
      'productName', 'quantity', 'unitPrice', 'totalAmount',
      'depositAmount', 'balanceAmount', 'paymentStructure', 'paymentMethod'
    ],
    missingBefore: [],
    addedHeaders: [],
    duplicateHeaders: [],
    finalMissing: [],
    fatal: [],
    warnings: [],
    nextAction: ''
  };

  try {
    var config = erpCoreSalesSchemaPrepV31_loadConfig_();
    var masterId = config.FEELHAUS_DB_MASTER_ID || config.DB_MASTER_ID || config.SPREADSHEET_ID;
    if (!masterId) throw new Error('FEELHAUS_DB_MASTER_ID 또는 DB_MASTER_ID 없음');

    var ss = SpreadsheetApp.openById(masterId);
    var sheet = ss.getSheetByName('ERP_판매관리');
    if (!sheet) throw new Error('ERP_판매관리 시트 없음');

    var lastCol = Math.max(sheet.getLastColumn(), 1);
    var headers = sheet.getRange(1, 1, 1, lastCol).getValues()[0].map(function (v) {
      return String(v || '').trim();
    });

    var seen = {};
    for (var i = 0; i < headers.length; i++) {
      if (!headers[i]) continue;
      if (seen[headers[i]]) result.duplicateHeaders.push(headers[i]);
      seen[headers[i]] = true;
    }

    for (var r = 0; r < result.requiredHeaders.length; r++) {
      var h = result.requiredHeaders[r];
      if (!seen[h]) result.missingBefore.push(h);
    }

    if (apply && result.missingBefore.length) {
      var startCol = sheet.getLastColumn() + 1;
      sheet.getRange(1, startCol, 1, result.missingBefore.length).setValues([result.missingBefore]);
      result.addedHeaders = result.missingBefore.slice();
    }

    var finalLastCol = Math.max(sheet.getLastColumn(), 1);
    var finalHeaders = sheet.getRange(1, 1, 1, finalLastCol).getValues()[0].map(function (v) {
      return String(v || '').trim();
    });
    var finalMap = {};
    for (var f = 0; f < finalHeaders.length; f++) {
      if (finalHeaders[f]) finalMap[finalHeaders[f]] = true;
    }
    for (var q = 0; q < result.requiredHeaders.length; q++) {
      if (!finalMap[result.requiredHeaders[q]]) result.finalMissing.push(result.requiredHeaders[q]);
    }

    if (result.duplicateHeaders.length) {
      result.warnings.push('중복 헤더 확인 필요: ' + result.duplicateHeaders.join(', '));
    }
    if (apply && result.finalMissing.length) {
      result.fatal.push('필수 헤더 보정 후에도 누락: ' + result.finalMissing.join(', '));
    }

    result.ok = result.fatal.length === 0 && (!apply || result.finalMissing.length === 0);
    result.nextAction = apply
      ? 'FIELD V30 selfCheck 또는 salesSave 제한 저장 테스트 재실행'
      : '문제 없으면 runErpCoreSalesSchemaPrepV31Apply 실행';
  } catch (err) {
    result.ok = false;
    result.fatal.push(err && err.message ? err.message : String(err));
    result.nextAction = '오류 수정 후 재실행';
  }

  Logger.log(JSON.stringify({
    ok: result.ok,
    build: result.build,
    mode: result.mode,
    missingBefore: result.missingBefore,
    addedHeaders: result.addedHeaders,
    finalMissing: result.finalMissing,
    fatal: result.fatal,
    warnings: result.warnings,
    nextAction: result.nextAction
  }, null, 2));
  return result;
}

function erpCoreSalesSchemaPrepV31_loadConfig_() {
  var setupSs = SpreadsheetApp.openById(ERP_CORE_SALES_SCHEMA_V31_SETUP_DB_ID);
  var sheet = setupSs.getSheetByName(ERP_CORE_SALES_SCHEMA_V31_CONFIG_SHEET);
  if (!sheet) throw new Error('SystemConfig 시트 없음');

  var values = sheet.getDataRange().getValues();
  var config = {};
  for (var r = 1; r < values.length; r++) {
    var key = String(values[r][0] || '').trim();
    var value = String(values[r][1] || '').trim();
    if (key) config[key] = value;
  }
  return config;
}
