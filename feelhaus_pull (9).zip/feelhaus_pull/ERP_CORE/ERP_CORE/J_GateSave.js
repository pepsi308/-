/**
 * ERP_CORE_LIMITED_OPERATIONAL_SAVE_GATE_SAFE
 * Limited operational save gate only.
 * Safe: no actual operational write, no deploy, no permission mutation.
 */
const ERP_LIMITED_OPERATIONAL_SAVE_GATE_BUILD = 'ERP_CORE_LIMITED_OPERATIONAL_SAVE_GATE_SAFE';

function erpLimitedOperationalSaveGate_safety_() {
  return {
    build: ERP_LIMITED_OPERATIONAL_SAVE_GATE_BUILD,
    gateOnly: true,
    limitedOperationalOpenOnly: true,
    actualOperationalDataWrite: false,
    noCustomerSave: true,
    noSaleSave: true,
    noContractCreate: true,
    noInstallAsSave: true,
    noSettlementExecution: true,
    noCancelSettlementConfirm: true,
    noSignDocumentCreate: true,
    noFormAutoRegister: true,
    noRoleMutation: true,
    noDeployExecution: true,
    deployAllowed: false,
    actualDeployExecution: false,
    noSheetCreate: true,
    noHeaderAutoAdd: true,
    noPolicyWrite: true,
    noDeleteSheet: true,
    noExistingDataClear: true,
    headerMapRequired: true,
    idBasedConnectionRequired: true,
    approvalRequired: true,
    hqOrApprovedTesterOnly: true,
    vendorBranchUserGroup: true,
    qrInitialEntryTargetSearchProtected: true,
    directRegularMemberLink: false,
    noOriginalSlipMutation: true
  };
}

function erpLimitedOperationalSaveGate_scope_() {
  return {
    allowedReviewScope: [
      'HQ_ADMIN 또는 APPROVED_TESTER 한정 제한 운영 저장 검토',
      '고객/판매/계약/설치/A/S/정산 전체 오픈 전 게이트 확인',
      '저장 순서: 필수값→형식→권한→중복→저장→감사로그 유지 확인',
      '헤더맵 기반 저장만 허용 검토'
    ],
    stillBlocked: [
      '실제 고객 저장',
      '실제 판매 저장',
      '실제 계약 생성',
      '실제 설치/A/S 저장',
      '실제 정산 실행',
      '취소정산 확정',
      'SIGN 문서 생성',
      'FORM/QR 자동등록',
      '권한 변경',
      '배포 실행'
    ],
    nextStep: 'ERP_CORE_LIMITED_OPERATIONAL_SAVE_DRY_RUN_SAFE'
  };
}

function erpLimitedOperationalSaveGate_dryRun(ctx) {
  ctx = ctx || {};
  return {
    ok: true,
    build: ERP_LIMITED_OPERATIONAL_SAVE_GATE_BUILD,
    mode: 'DRY_RUN_ONLY',
    message: '제한 운영 저장 게이트 계획만 확인합니다. 실제 운영 저장/배포/권한변경은 없습니다.',
    fatal: [],
    warnings: [],
    scope: erpLimitedOperationalSaveGate_scope_(),
    safety: erpLimitedOperationalSaveGate_safety_(),
    ctx: ctx
  };
}

function erpLimitedOperationalSaveGate_checkGuard_(ctx) {
  ctx = ctx || {};
  const required = {
    limitedSaveGateConfirm: true,
    approvalCode: 'ERP_CORE_LIMITED_OPERATIONAL_SAVE_GATE_APPROVED_REVIEW_ONLY',
    actualOperationalDataWrite: false,
    deployAllowed: false,
    hqOrApprovedTesterOnly: true
  };
  if (ctx.limitedSaveGateConfirm !== true) {
    return { ok: false, blocked: true, reason: 'limitedSaveGateConfirm=true 승인이 없습니다.', required: required };
  }
  if (ctx.approvalCode !== required.approvalCode) {
    return { ok: false, blocked: true, reason: '승인코드가 일치하지 않습니다.', required: required };
  }
  if (ctx.actualOperationalDataWrite !== false) {
    return { ok: false, blocked: true, reason: 'actualOperationalDataWrite=false 상태만 허용됩니다.', required: required };
  }
  if (ctx.deployAllowed !== false) {
    return { ok: false, blocked: true, reason: 'deployAllowed=false 상태만 허용됩니다.', required: required };
  }
  if (ctx.hqOrApprovedTesterOnly !== true) {
    return { ok: false, blocked: true, reason: 'HQ 또는 승인된 테스트 담당자 한정 조건이 없습니다.', required: required };
  }
  return { ok: true, blocked: false, required: required };
}

function erpLimitedOperationalSaveGate_execute(ctx) {
  ctx = ctx || {};
  const guard = erpLimitedOperationalSaveGate_checkGuard_(ctx);
  if (!guard.ok) {
    return {
      ok: false,
      blocked: true,
      build: ERP_LIMITED_OPERATIONAL_SAVE_GATE_BUILD,
      action: 'LIMITED_OPERATIONAL_SAVE_GATE_REVIEW_ONLY',
      reason: guard.reason,
      required: guard.required,
      safety: erpLimitedOperationalSaveGate_safety_()
    };
  }

  const fatal = [];
  const warnings = [];
  return {
    ok: fatal.length === 0,
    build: ERP_LIMITED_OPERATIONAL_SAVE_GATE_BUILD,
    action: 'LIMITED_OPERATIONAL_SAVE_GATE_REVIEW_ONLY',
    limitedOperationalSaveGateReady: true,
    limitedOperationalOpenOnly: true,
    actualOperationalDataWrite: false,
    businessDataWrite: false,
    deployAllowed: false,
    actualDeployExecution: false,
    approvalCode: ctx.approvalCode,
    approvedScope: erpLimitedOperationalSaveGate_scope_(),
    allowedNextStep: 'ERP_CORE_LIMITED_OPERATIONAL_SAVE_DRY_RUN_SAFE',
    fatal: fatal,
    warnings: warnings,
    safety: erpLimitedOperationalSaveGate_safety_()
  };
}

function erpLimitedOperationalSaveGate_selfTest() {
  const fatal = [];
  const safety = erpLimitedOperationalSaveGate_safety_();
  if (!safety.gateOnly) fatal.push('gateOnly safety flag is not true');
  if (safety.actualOperationalDataWrite !== false) fatal.push('actualOperationalDataWrite must be false');
  if (safety.deployAllowed !== false) fatal.push('deployAllowed must be false');
  if (!safety.hqOrApprovedTesterOnly) fatal.push('hqOrApprovedTesterOnly safety flag is not true');
  const scope = erpLimitedOperationalSaveGate_scope_();
  if (!scope.nextStep) fatal.push('nextStep is missing');
  return {
    ok: fatal.length === 0,
    build: ERP_LIMITED_OPERATIONAL_SAVE_GATE_BUILD,
    mode: 'SELFTEST',
    fatal: fatal,
    warnings: [],
    scope: scope,
    safety: safety
  };
}
