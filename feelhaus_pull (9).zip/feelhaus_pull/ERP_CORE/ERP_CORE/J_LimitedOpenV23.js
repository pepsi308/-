/**
 * FEELHAUS ERP CORE V24
 * Limited operation opening readiness gate.
 * READ ONLY: does not save customer/sale/contract/install/as/settlement data.
 */
function runErpCoreLimitedOpenV23() {
  var result = {
    ok: false,
    build: 'ERP_CORE_LIMITED_OPEN_V24',
    checkedAt: new Date().toISOString(),
    mode: 'READ_ONLY_LIMITED_OPEN_READY_CHECK_V24',
    openScope: {
      customerLookup: 'READY',
      salesDraftSave: 'DRY_RUN_ONLY',
      contractCreate: 'BLOCKED',
      installSave: 'BLOCKED',
      asSave: 'BLOCKED',
      settlementExecution: 'BLOCKED',
      signDocumentCreate: 'BLOCKED',
      formAutoRegister: 'BLOCKED'
    },
    fatal: [],
    warnings: [],
    checks: [],
    limitedOpenReady: false,
    nextAction: ''
  };

  function addCheck(name, ok, detail, severity) {
    var item = {
      name: name,
      ok: ok === true,
      severity: severity || (ok === true ? 'PASS' : 'FATAL'),
      detail: detail || {}
    };
    result.checks.push(item);
    if (!item.ok && item.severity === 'FATAL') result.fatal.push(name);
    if (!item.ok && item.severity === 'WARN') result.warnings.push(name);
    return item;
  }

  function getConfig_() {
    var setupDbId = '17VMSpgSZCvIrUlgcw8yCNcnl8WQWo2IcRf5tDCcuJGM';
    var setup = SpreadsheetApp.openById(setupDbId);
    var sheet = setup.getSheetByName('SystemConfig');
    if (!sheet) throw new Error('SystemConfig 시트를 찾을 수 없습니다.');
    var values = sheet.getDataRange().getValues();
    var config = {};
    for (var r = 1; r < values.length; r++) {
      var key = String(values[r][0] || '').trim();
      var value = String(values[r][1] || '').trim();
      if (key) config[key] = value;
    }
    return config;
  }

  function getHeaderMap_(sheet) {
    var lastCol = Math.max(sheet.getLastColumn(), 1);
    var row = sheet.getRange(1, 1, 1, lastCol).getValues()[0];
    var map = {};
    var duplicates = [];
    for (var c = 0; c < row.length; c++) {
      var h = String(row[c] || '').trim();
      if (!h) continue;
      if (map[h]) duplicates.push(h);
      map[h] = c + 1;
    }
    return { map: map, duplicates: duplicates, headers: row };
  }

  function requireHeaders_(ss, sheetName, headers) {
    var sheet = ss.getSheetByName(sheetName);
    if (!sheet) {
      return { ok: false, sheetName: sheetName, missingSheet: true, missingHeaders: headers, duplicateHeaders: [] };
    }
    var hm = getHeaderMap_(sheet);
    var missing = [];
    for (var i = 0; i < headers.length; i++) {
      if (!hm.map[headers[i]]) missing.push(headers[i]);
    }
    return {
      ok: missing.length === 0 && hm.duplicates.length === 0,
      sheetName: sheetName,
      missingSheet: false,
      missingHeaders: missing,
      duplicateHeaders: hm.duplicates,
      lastRow: sheet.getLastRow(),
      lastCol: sheet.getLastColumn()
    };
  }

  try {
    var config = getConfig_();
    addCheck('SystemConfig 자동 읽기', true, { keyCount: Object.keys(config).length });

    var masterId = config.FEELHAUS_DB_MASTER_ID || config.DB_MASTER_ID || config.SPREADSHEET_ID;
    if (!masterId) throw new Error('FEELHAUS_DB_MASTER_ID 또는 DB_MASTER_ID가 없습니다.');
    var master = SpreadsheetApp.openById(masterId);
    addCheck('FEELHAUS_DB_MASTER 자동 연결', true, { masterName: master.getName() });

    var runtimeSummary = null;
    if (typeof runErpPrebuildRuntimeGateV7Summary === 'function') {
      runtimeSummary = runErpPrebuildRuntimeGateV7Summary();
      addCheck('권한/상태전이/감사로그 구조 기존 게이트 통과 확인', runtimeSummary && runtimeSummary.buildAllowed === true && (runtimeSummary.fatalChecks || []).length === 0 && (runtimeSummary.failedChecks || []).length === 0, {
        buildAllowed: runtimeSummary && runtimeSummary.buildAllowed === true,
        fatalChecksCount: runtimeSummary && runtimeSummary.fatalChecks ? runtimeSummary.fatalChecks.length : null,
        failedChecksCount: runtimeSummary && runtimeSummary.failedChecks ? runtimeSummary.failedChecks.length : null,
        note: 'V24는 제한 개방 범위에 필요한 구조를 기존 런타임 게이트 통과 상태와 핵심 원장 헤더로 판정합니다.'
      });
    } else {
      addCheck('권한/상태전이/감사로그 구조 기존 게이트 통과 확인', false, { message: 'runErpPrebuildRuntimeGateV7Summary 함수 없음' });
    }

    var customer = requireHeaders_(master, 'ERP_고객관리', ['customerId', 'name', 'phone', 'status', 'eventId', 'vendorId', 'createdAt', 'createdBy', 'updatedAt', 'updatedBy']);
    addCheck('고객 조회 개방 필수 헤더 점검', customer.ok, customer);

    var sales = requireHeaders_(master, 'ERP_판매관리', ['saleId', 'eventId', 'vendorId', 'customerId', 'status', 'statusReason', 'createdAt', 'createdBy', 'updatedAt', 'updatedBy']);
    addCheck('판매 DRAFT 저장 드라이런 필수 헤더 점검', sales.ok, sales);

    addCheck('저장 순서 보호 확인', true, {
      requiredSaveOrder: ['requiredValueCheck', 'formatCheck', 'permissionCheck', 'duplicateCheck', 'stateTransitionCheck', 'save', 'auditLog'],
      salesDraftSaveMode: 'DRY_RUN_ONLY',
      actualBusinessDataWrite: false
    });

    addCheck('1차 개방 범위 제한 확인', true, result.openScope);

    result.ok = result.fatal.length === 0;
    result.limitedOpenReady = result.ok;
    result.nextAction = result.ok
      ? '고객 조회와 판매 DRAFT 드라이런 준비 통과. FIELD 1차 제한 개방 빌드로 진행 가능'
      : 'fatal 항목 보정 후 runErpCoreFinalGateAll 재실행';
  } catch (err) {
    addCheck('제한 개방 준비 게이트 오류', false, { message: err && err.message ? err.message : String(err) });
    result.ok = false;
    result.limitedOpenReady = false;
    result.nextAction = '오류 수정 후 runErpCoreFinalGateAll 재실행';
  }

  Logger.log(JSON.stringify({
    ok: result.ok,
    build: result.build,
    checkedAt: result.checkedAt,
    mode: result.mode,
    limitedOpenReady: result.limitedOpenReady,
    fatal: result.fatal,
    warnings: result.warnings,
    openScope: result.openScope,
    nextAction: result.nextAction
  }, null, 2));
  return result;
}
