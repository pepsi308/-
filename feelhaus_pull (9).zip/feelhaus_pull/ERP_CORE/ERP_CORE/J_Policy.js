/**
 * FEELHAUS ERP_CORE Policy Meta DB Inject Draft
 * Build: ERP_CORE_POLICY_META_DB_INJECT_DRAFT_SAFE
 * Project: ERP_CORE only
 * Purpose:
 *  - Inject ONLY policy meta records for HeaderPolicy 67 and SheetPolicy 6.
 *  - Upsert by stable policy keys; prevent duplicate policy rows.
 * Safety:
 *  - no business data write, no deploy, no settlement, no SIGN/FORM/permission mutation
 *  - actual execution requires explicit runtime confirmation and approval code
 */
var ERP_CORE_POLICY_META_DB_INJECT_BUILD = 'ERP_CORE_POLICY_META_DB_INJECT_DRAFT_SAFE';
var ERP_CORE_POLICY_META_DB_INJECT_APPROVAL_CODE = 'ERP_CORE_POLICY_META_DB_INJECT_APPROVED_POLICY_META_ONLY';

var ERP_CORE_POLICY_META_TARGETS = {
  headerPolicySheetName: 'HeaderPolicy',
  sheetPolicySheetName: 'SheetPolicy'
};

var ERP_CORE_POLICY_META_HEADER_POLICY_HEADERS = [
  'policyId', 'sheetName', 'headerName', 'headerOrder', 'required', 'protected',
  'protectionLevel', 'policyStatus', 'sourceBuild', 'createdAt', 'createdBy', 'updatedAt', 'updatedBy'
];

var ERP_CORE_POLICY_META_SHEET_POLICY_HEADERS = [
  'policyId', 'sheetName', 'sheetOrder', 'sheetRole', 'protectionLevel', 'createRequired',
  'deleteCandidate', 'archiveCandidate', 'headerMapRequired', 'idBasedConnectionRequired',
  'policyStatus', 'sourceBuild', 'createdAt', 'createdBy', 'updatedAt', 'updatedBy'
];

function erpCorePolicyMetaDbInjectDraft_safety_() {
  return {
    build: ERP_CORE_POLICY_META_DB_INJECT_BUILD,
    policyMetaOnlyMode: true,
    dbInjectConfirmDefault: false,
    deployAllowed: false,
    noBusinessDataWrite: true,
    noCustomerSave: true,
    noSaleSave: true,
    noContractCreate: true,
    noInstallAsSave: true,
    noSettlementExecution: true,
    noCancelSettlementConfirm: true,
    noSignDocumentCreate: true,
    noFormAutoRegister: true,
    noRoleMutation: true,
    noDeployExecution: true,
    noDeleteSheet: true,
    noExistingDataClear: true,
    upsertOnly: true,
    duplicatePolicyRowsBlocked: true,
    targetSheets: ERP_CORE_POLICY_META_TARGETS,
    vendorBranchUserGroup: true,
    qrInitialEntryTargetSearchProtected: true,
    directRegularMemberLink: false,
    noOriginalSlipMutation: true
  };
}

function erpCorePolicyMetaDbInjectDraft_buildPlan_() {
  var basePlan = erpCoreActualCreateDedicatedDraft_buildPlan_();
  var fatal = [];
  var warnings = [];

  if (!basePlan || basePlan.sheetPolicyCandidateCount !== 6) fatal.push('SheetPolicy 후보 수가 6개가 아닙니다.');
  if (!basePlan || basePlan.headerPolicyCandidateCount !== 67) fatal.push('HeaderPolicy 후보 수가 67개가 아닙니다.');
  if (basePlan && basePlan.duplicateProblems && basePlan.duplicateProblems.length) fatal.push('생성 계획에 중복 헤더가 있습니다.');
  if (basePlan && basePlan.auditProblems && basePlan.auditProblems.length) fatal.push('생성 계획에 감사 헤더 누락이 있습니다.');

  var headerRows = [];
  var sheetRows = [];

  if (basePlan && basePlan.sheets) {
    for (var s = 0; s < basePlan.sheets.length; s++) {
      var sp = basePlan.sheets[s];
      sheetRows.push({
        policyId: erpCorePolicyMetaDbInjectDraft_makePolicyId_('SHEET', sp.sheetName),
        sheetName: sp.sheetName,
        sheetOrder: sp.order,
        sheetRole: sp.label,
        protectionLevel: sp.protectionLevel,
        createRequired: true,
        deleteCandidate: false,
        archiveCandidate: false,
        headerMapRequired: true,
        idBasedConnectionRequired: true,
        policyStatus: 'APPROVED_CREATED',
        sourceBuild: ERP_CORE_POLICY_META_DB_INJECT_BUILD
      });
      for (var h = 0; h < sp.headers.length; h++) {
        headerRows.push({
          policyId: erpCorePolicyMetaDbInjectDraft_makePolicyId_('HEADER', sp.sheetName, sp.headers[h]),
          sheetName: sp.sheetName,
          headerName: sp.headers[h],
          headerOrder: h + 1,
          required: true,
          protected: true,
          protectionLevel: sp.protectionLevel,
          policyStatus: 'APPROVED_CREATED',
          sourceBuild: ERP_CORE_POLICY_META_DB_INJECT_BUILD
        });
      }
    }
  }

  if (sheetRows.length !== 6) fatal.push('주입할 SheetPolicy row 수 불일치: ' + sheetRows.length);
  if (headerRows.length !== 67) fatal.push('주입할 HeaderPolicy row 수 불일치: ' + headerRows.length);

  return {
    ok: fatal.length === 0,
    build: ERP_CORE_POLICY_META_DB_INJECT_BUILD,
    sourceBuild: ERP_CORE_ACTUAL_CREATE_DEDICATED_BUILD,
    targetSheets: ERP_CORE_POLICY_META_TARGETS,
    headerPolicyRowCount: headerRows.length,
    sheetPolicyRowCount: sheetRows.length,
    headerPolicyHeaders: ERP_CORE_POLICY_META_HEADER_POLICY_HEADERS.slice(),
    sheetPolicyHeaders: ERP_CORE_POLICY_META_SHEET_POLICY_HEADERS.slice(),
    headerRows: headerRows,
    sheetRows: sheetRows,
    fatal: fatal,
    warnings: warnings,
    safety: erpCorePolicyMetaDbInjectDraft_safety_()
  };
}

function erpCorePolicyMetaDbInjectDraft_dryRun(ctx) {
  ctx = ctx || {};
  var plan = erpCorePolicyMetaDbInjectDraft_buildPlan_();
  var out = {
    ok: plan.ok,
    build: ERP_CORE_POLICY_META_DB_INJECT_BUILD,
    mode: 'DRY_RUN_ONLY',
    message: '실제 주입 없이 HeaderPolicy 67 / SheetPolicy 6 정책 메타 주입 계획만 검증했습니다.',
    planSummary: {
      targetSheets: plan.targetSheets,
      headerPolicyRowCount: plan.headerPolicyRowCount,
      sheetPolicyRowCount: plan.sheetPolicyRowCount,
      fatal: plan.fatal,
      warnings: plan.warnings
    },
    ctx: ctx
  };
  Logger.log('[ERP_CORE POLICY META DB INJECT DRAFT DRY RUN] ' + JSON.stringify(out));
  return out;
}

function erpCorePolicyMetaDbInjectDraft_selfTest() {
  var plan = erpCorePolicyMetaDbInjectDraft_buildPlan_();
  var fatal = [];
  var warnings = [];
  var safety = erpCorePolicyMetaDbInjectDraft_safety_();

  if (!plan.ok) fatal = fatal.concat(plan.fatal);
  if (plan.sheetPolicyRowCount !== 6) fatal.push('SheetPolicy row count must be 6');
  if (plan.headerPolicyRowCount !== 67) fatal.push('HeaderPolicy row count must be 67');
  if (safety.noBusinessDataWrite !== true) fatal.push('business data write must remain blocked');
  if (safety.noDeployExecution !== true) fatal.push('deploy execution must remain blocked');
  if (safety.upsertOnly !== true) fatal.push('policy injection must be upsert only');

  var headerPolicyIds = [];
  for (var h = 0; h < plan.headerRows.length; h++) headerPolicyIds.push(plan.headerRows[h].policyId);
  var sheetPolicyIds = [];
  for (var s = 0; s < plan.sheetRows.length; s++) sheetPolicyIds.push(plan.sheetRows[s].policyId);
  var headerDup = erpCorePolicyMetaDbInjectDraft_findDuplicates_(headerPolicyIds);
  var sheetDup = erpCorePolicyMetaDbInjectDraft_findDuplicates_(sheetPolicyIds);
  if (headerDup.length) fatal.push('HeaderPolicy policyId 중복: ' + headerDup.join(', '));
  if (sheetDup.length) fatal.push('SheetPolicy policyId 중복: ' + sheetDup.join(', '));

  var required = [
    'erpCorePolicyMetaDbInjectDraft_dryRun',
    'erpCorePolicyMetaDbInjectDraft_selfTest',
    'erpCorePolicyMetaDbInjectDraft_execute',
    'erpCorePolicyMetaDbInjectDraft_postInjectCheck',
    'erpCorePolicyMetaDbInjectDraft_buildPlan_'
  ];
  var missing = [];
  for (var i = 0; i < required.length; i++) {
    try { if (typeof this[required[i]] !== 'function') missing.push(required[i]); }
    catch (e) { missing.push(required[i]); }
  }
  if (missing.length) fatal.push('필수 함수 누락: ' + missing.join(', '));

  var result = {
    ok: fatal.length === 0,
    build: ERP_CORE_POLICY_META_DB_INJECT_BUILD,
    fatal: fatal,
    warnings: warnings,
    checks: {
      plan: {
        ok: plan.ok,
        headerPolicyRowCount: plan.headerPolicyRowCount,
        sheetPolicyRowCount: plan.sheetPolicyRowCount,
        headerPolicyIdDuplicateCount: headerDup.length,
        sheetPolicyIdDuplicateCount: sheetDup.length
      },
      requiredFunctions: { ok: missing.length === 0, missing: missing },
      safety: safety
    }
  };
  Logger.log('[ERP_CORE POLICY META DB INJECT DRAFT SELFTEST] ' + JSON.stringify(result));
  return result;
}

function erpCorePolicyMetaDbInjectDraft_execute(ctx) {
  ctx = ctx || {};
  var guard = erpCorePolicyMetaDbInjectDraft_checkExecuteGuard_(ctx);
  if (!guard.ok) {
    var blocked = {
      ok: false,
      blocked: true,
      build: ERP_CORE_POLICY_META_DB_INJECT_BUILD,
      action: 'POLICY_META_DB_INJECT_ONLY',
      reason: guard.reason,
      required: guard.required,
      safety: erpCorePolicyMetaDbInjectDraft_safety_()
    };
    Logger.log('[ERP_CORE POLICY META DB INJECT DRAFT EXECUTE BLOCKED] ' + JSON.stringify(blocked));
    return blocked;
  }

  var postCreate = erpCoreActualCreateDedicatedDraft_postCreateCheck();
  if (!postCreate || postCreate.ok !== true) {
    throw new Error('POST_CREATE_CHECK_NOT_PASS');
  }

  var plan = erpCorePolicyMetaDbInjectDraft_buildPlan_();
  if (!plan.ok) throw new Error('POLICY_META_INJECT_PLAN_NOT_READY');

  var ss = erpCoreActualCreateDedicatedDraft_openMaster_();
  var actor = erpCorePolicyMetaDbInjectDraft_getActor_();
  var now = new Date().toISOString();

  var result = {
    ok: true,
    build: ERP_CORE_POLICY_META_DB_INJECT_BUILD,
    action: 'POLICY_META_DB_INJECT_ONLY',
    targetSheets: plan.targetSheets,
    headerPolicy: null,
    sheetPolicy: null,
    fatal: [],
    warnings: [],
    businessDataWrite: false,
    deployAllowed: false
  };

  var headerSheet = erpCorePolicyMetaDbInjectDraft_getOrCreatePolicySheet_(ss, plan.targetSheets.headerPolicySheetName, plan.headerPolicyHeaders, result);
  var sheetSheet = erpCorePolicyMetaDbInjectDraft_getOrCreatePolicySheet_(ss, plan.targetSheets.sheetPolicySheetName, plan.sheetPolicyHeaders, result);

  result.headerPolicy = erpCorePolicyMetaDbInjectDraft_upsertRows_(
    headerSheet,
    plan.headerPolicyHeaders,
    'policyId',
    plan.headerRows,
    now,
    actor
  );
  result.sheetPolicy = erpCorePolicyMetaDbInjectDraft_upsertRows_(
    sheetSheet,
    plan.sheetPolicyHeaders,
    'policyId',
    plan.sheetRows,
    now,
    actor
  );

  result.postInjectCheck = erpCorePolicyMetaDbInjectDraft_postInjectCheck();
  result.ok = result.fatal.length === 0 && result.postInjectCheck.ok === true;
  Logger.log('[ERP_CORE POLICY META DB INJECT DRAFT EXECUTE RESULT] ' + JSON.stringify(result));
  return result;
}

function erpCorePolicyMetaDbInjectDraft_postInjectCheck() {
  var plan = erpCorePolicyMetaDbInjectDraft_buildPlan_();
  var ss = erpCoreActualCreateDedicatedDraft_openMaster_();
  var out = {
    ok: true,
    build: ERP_CORE_POLICY_META_DB_INJECT_BUILD,
    checkedAt: new Date().toISOString(),
    fatal: [],
    warnings: [],
    targetSheets: plan.targetSheets,
    headerPolicy: null,
    sheetPolicy: null,
    businessDataWrite: false,
    deployAllowed: false
  };

  var headerSheet = ss.getSheetByName(plan.targetSheets.headerPolicySheetName);
  var sheetSheet = ss.getSheetByName(plan.targetSheets.sheetPolicySheetName);
  out.headerPolicy = erpCorePolicyMetaDbInjectDraft_checkPolicySheet_(headerSheet, plan.headerPolicyHeaders, plan.headerRows, 'policyId');
  out.sheetPolicy = erpCorePolicyMetaDbInjectDraft_checkPolicySheet_(sheetSheet, plan.sheetPolicyHeaders, plan.sheetRows, 'policyId');

  if (!out.headerPolicy.ok) {
    out.ok = false;
    out.fatal = out.fatal.concat(out.headerPolicy.fatal);
  }
  if (!out.sheetPolicy.ok) {
    out.ok = false;
    out.fatal = out.fatal.concat(out.sheetPolicy.fatal);
  }
  Logger.log('[ERP_CORE POLICY META DB INJECT DRAFT POST INJECT CHECK] ' + JSON.stringify(out));
  return out;
}

function erpCorePolicyMetaDbInjectDraft_checkExecuteGuard_(ctx) {
  var required = {
    dbInjectConfirm: true,
    approvalCode: ERP_CORE_POLICY_META_DB_INJECT_APPROVAL_CODE,
    businessDataWriteAllowed: false,
    deployAllowed: false
  };
  if (ctx.dbInjectConfirm !== true) {
    return { ok:false, reason:'dbInjectConfirm=true 승인이 없습니다.', required:required };
  }
  if (String(ctx.approvalCode || '') !== ERP_CORE_POLICY_META_DB_INJECT_APPROVAL_CODE) {
    return { ok:false, reason:'승인 코드가 일치하지 않습니다.', required:required };
  }
  if (ctx.businessDataWriteAllowed === true) {
    return { ok:false, reason:'업무 데이터 쓰기 허용 상태에서는 정책 메타 주입을 중단합니다.', required:required };
  }
  if (ctx.deployAllowed === true) {
    return { ok:false, reason:'배포 허용 상태에서는 정책 메타 주입을 중단합니다.', required:required };
  }
  return { ok:true, required:required };
}

function erpCorePolicyMetaDbInjectDraft_getOrCreatePolicySheet_(ss, sheetName, headers, result) {
  var sh = ss.getSheetByName(sheetName);
  if (!sh) {
    sh = ss.insertSheet(sheetName);
    if (result && result.warnings) result.warnings.push('정책 시트 생성: ' + sheetName);
  }
  erpCorePolicyMetaDbInjectDraft_ensureHeaders_(sh, headers, result);
  return sh;
}

function erpCorePolicyMetaDbInjectDraft_ensureHeaders_(sh, expectedHeaders, result) {
  var lastCol = sh.getLastColumn();
  var current = [];
  if (lastCol > 0) {
    current = sh.getRange(1, 1, 1, lastCol).getValues()[0].map(function(v) { return String(v || '').trim(); });
  }
  if (current.length === 0 || (current.length === 1 && !current[0])) {
    sh.getRange(1, 1, 1, expectedHeaders.length).setValues([expectedHeaders]);
    return;
  }
  var missing = [];
  for (var i = 0; i < expectedHeaders.length; i++) {
    if (current.indexOf(expectedHeaders[i]) < 0) missing.push(expectedHeaders[i]);
  }
  if (missing.length) {
    sh.getRange(1, current.length + 1, 1, missing.length).setValues([missing]);
    if (result && result.warnings) result.warnings.push(sh.getName() + ' 정책 헤더 추가: ' + missing.join(', '));
  }
}

function erpCorePolicyMetaDbInjectDraft_upsertRows_(sh, headers, keyHeader, rows, now, actor) {
  var headerMap = erpCorePolicyMetaDbInjectDraft_getHeaderMap_(sh);
  var keyCol = headerMap[keyHeader];
  if (!keyCol) throw new Error('KEY_HEADER_NOT_FOUND: ' + keyHeader + ' in ' + sh.getName());

  var lastRow = sh.getLastRow();
  var keyToRow = {};
  if (lastRow >= 2) {
    var keyValues = sh.getRange(2, keyCol, lastRow - 1, 1).getValues();
    for (var i = 0; i < keyValues.length; i++) {
      var key = String(keyValues[i][0] || '').trim();
      if (!key) continue;
      if (!keyToRow[key]) keyToRow[key] = i + 2;
    }
  }

  var inserted = 0;
  var updated = 0;
  for (var r = 0; r < rows.length; r++) {
    var rowObj = rows[r];
    var keyVal = String(rowObj[keyHeader] || '').trim();
    if (!keyVal) throw new Error('EMPTY_POLICY_KEY');
    var targetRow = keyToRow[keyVal] || 0;
    var rowValues = [];
    for (var h = 0; h < headers.length; h++) {
      var name = headers[h];
      if (name === 'createdAt') {
        rowValues.push(targetRow ? erpCorePolicyMetaDbInjectDraft_getCellByHeader_(sh, targetRow, headerMap, 'createdAt') || now : now);
      } else if (name === 'createdBy') {
        rowValues.push(targetRow ? erpCorePolicyMetaDbInjectDraft_getCellByHeader_(sh, targetRow, headerMap, 'createdBy') || actor : actor);
      } else if (name === 'updatedAt') {
        rowValues.push(now);
      } else if (name === 'updatedBy') {
        rowValues.push(actor);
      } else {
        rowValues.push(rowObj[name] === undefined ? '' : rowObj[name]);
      }
    }
    if (targetRow) {
      sh.getRange(targetRow, 1, 1, headers.length).setValues([rowValues]);
      updated++;
    } else {
      sh.getRange(sh.getLastRow() + 1, 1, 1, headers.length).setValues([rowValues]);
      inserted++;
    }
  }
  return { ok:true, sheetName: sh.getName(), inserted: inserted, updated: updated, total: rows.length };
}

function erpCorePolicyMetaDbInjectDraft_checkPolicySheet_(sh, expectedHeaders, expectedRows, keyHeader) {
  var out = { ok:true, sheetName: sh ? sh.getName() : '', exists: !!sh, expectedRowCount: expectedRows.length, foundRowCount: 0, missingPolicyIds: [], duplicatePolicyIds: [], missingHeaders: [], fatal: [] };
  if (!sh) {
    out.ok = false;
    out.fatal.push('정책 시트 없음');
    return out;
  }
  var values = sh.getLastColumn() > 0 ? sh.getRange(1, 1, 1, sh.getLastColumn()).getValues()[0] : [];
  var headers = [];
  for (var h = 0; h < values.length; h++) headers.push(String(values[h] || '').trim());
  for (var i = 0; i < expectedHeaders.length; i++) {
    if (headers.indexOf(expectedHeaders[i]) < 0) out.missingHeaders.push(expectedHeaders[i]);
  }
  if (out.missingHeaders.length) {
    out.ok = false;
    out.fatal.push(sh.getName() + ' 정책 헤더 누락: ' + out.missingHeaders.join(', '));
    return out;
  }
  var headerMap = erpCorePolicyMetaDbInjectDraft_getHeaderMap_(sh);
  var keyCol = headerMap[keyHeader];
  var existingKeys = [];
  if (sh.getLastRow() >= 2) {
    var keyValues = sh.getRange(2, keyCol, sh.getLastRow() - 1, 1).getValues();
    for (var k = 0; k < keyValues.length; k++) {
      var key = String(keyValues[k][0] || '').trim();
      if (key) existingKeys.push(key);
    }
  }
  out.duplicatePolicyIds = erpCorePolicyMetaDbInjectDraft_findDuplicates_(existingKeys);
  for (var r = 0; r < expectedRows.length; r++) {
    var expectedKey = String(expectedRows[r][keyHeader] || '').trim();
    if (existingKeys.indexOf(expectedKey) >= 0) out.foundRowCount++;
    else out.missingPolicyIds.push(expectedKey);
  }
  if (out.duplicatePolicyIds.length) {
    out.ok = false;
    out.fatal.push(sh.getName() + ' policyId 중복: ' + out.duplicatePolicyIds.join(', '));
  }
  if (out.missingPolicyIds.length) {
    out.ok = false;
    out.fatal.push(sh.getName() + ' policyId 누락 수: ' + out.missingPolicyIds.length);
  }
  return out;
}

function erpCorePolicyMetaDbInjectDraft_getHeaderMap_(sh) {
  var values = sh.getLastColumn() > 0 ? sh.getRange(1, 1, 1, sh.getLastColumn()).getValues()[0] : [];
  var map = {};
  for (var i = 0; i < values.length; i++) {
    var key = String(values[i] || '').trim();
    if (key && !map[key]) map[key] = i + 1;
  }
  return map;
}

function erpCorePolicyMetaDbInjectDraft_getCellByHeader_(sh, row, headerMap, headerName) {
  var col = headerMap[headerName];
  if (!col) return '';
  return sh.getRange(row, col).getValue();
}

function erpCorePolicyMetaDbInjectDraft_getActor_() {
  try {
    if (typeof Session !== 'undefined' && Session.getActiveUser) {
      return Session.getActiveUser().getEmail() || 'system';
    }
  } catch (e) {}
  return 'system';
}

function erpCorePolicyMetaDbInjectDraft_makePolicyId_(type, sheetName, headerName) {
  var raw = String(type || '') + '|' + String(sheetName || '') + '|' + String(headerName || '');
  return raw.replace(/\s+/g, '').replace(/[^A-Za-z0-9_가-힣|]/g, '_');
}

function erpCorePolicyMetaDbInjectDraft_findDuplicates_(list) {
  var seen = {};
  var dup = [];
  for (var i = 0; i < list.length; i++) {
    var v = String(list[i] || '').trim();
    if (!v) continue;
    var key = v.toLowerCase();
    if (seen[key] && dup.indexOf(v) < 0) dup.push(v);
    seen[key] = true;
  }
  return dup;
}
