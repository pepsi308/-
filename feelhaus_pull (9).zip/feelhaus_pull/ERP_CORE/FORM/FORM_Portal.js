function formGetPortalSummary() {
  formExecutionLog_('START', 'formGetPortalSummary', {});
  try {
    const dashboardData = formBuildDashboardData_();
    const response = formResponse_(true, 'PORTAL FORM B44 SAFE MODE 수요조사 폼센터 운영 요약', {
      dashboard: dashboardData,
      recentRequests: dashboardData.recentRequestListFiltered || [],
      approvalSummary: dashboardData.approvalSummary || null,
      retrySummary: dashboardData.retrySummary || null,
      requestListSummary: dashboardData.requestListSummary || null,
      fieldPanelSummary: dashboardData.fieldPanelSummary || null,
      dashboardCards: dashboardData.dashboardCards || [],
      counts: dashboardData.counts || {},
      operationalSummary: { portalUsesDashboardHelper: true, duplicateDashboardCallRemoved: true, fieldPanelFilteredDirect: true, dashboardCardFix: true, readOnly: true },
      safeMode: FORM_SAFE_MODE
    });
    Object.keys(dashboardData.cardMap || {}).forEach(k => response[k] = dashboardData.cardMap[k]);
    response.rawCount = dashboardData.rawCount;
    response.masterCount = dashboardData.masterCount;
    response.customerBufferCount = dashboardData.customerBufferCount;
    response.documentBufferCount = dashboardData.documentBufferCount;
    response.retryCount = dashboardData.retryCount;
    response.cards = dashboardData.cards;
    response.dashboardCards = dashboardData.dashboardCards;
    response.counts = dashboardData.counts;
    return formExecutionReturn_('formGetPortalSummary', response);
  } catch (err) {
    return formExecutionError_('formGetPortalSummary', err, null, 'PORTAL_SUMMARY_FAILED');
  }
}
