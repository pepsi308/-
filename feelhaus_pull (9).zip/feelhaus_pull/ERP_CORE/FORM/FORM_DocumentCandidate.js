function formCreateDocumentCandidate(requestId, raw, candidate) {
  const documentCandidateId = formUuid_('DOC_TMP');
  const documentId = '';
  const status = 'READY_FOR_SIGN';
  const doc = {
    documentCandidateId: documentCandidateId,
    documentId: documentId,
    status: status,
    signUrl: '',
    qrUrl: raw && raw.qrUrl ? raw.qrUrl : '',
    dryRunOnly: true,
    message: 'SIGN 문서 생성 후보 / 실제 SIGN 저장 차단'
  };
  formSaveDocumentCandidateBuffer_(requestId, raw || {}, candidate || {}, doc);
  return doc;
}

function formSaveDocumentCandidateBuffer_(requestId, raw, candidate, doc) {
  const ss = formGetMasterSpreadsheet_();
  const sheet = formEnsureSheet_(ss, FORM_SHEETS.DOCUMENT_BUFFER, FORM_REQUIRED_HEADERS.FORM_DOCUMENT_BUFFER);
  const now = formNow_();
  const bufferId = formUuid_('DBUF');
  formAppendByHeader_(sheet, {
    bufferId: bufferId,
    requestId: requestId,
    documentCandidateId: doc.documentCandidateId || '',
    documentId: doc.documentId || '',
    customerId: candidate.customerId || '',
    eventId: raw.eventId || '',
    vendorId: raw.vendorId || '',
    documentType: raw.documentType || 'QR_CUSTOMER_SIGN',
    documentStatus: doc.status || 'READY_FOR_SIGN',
    signUrl: doc.signUrl || '',
    qrUrl: doc.qrUrl || '',
    dryRunOnly: true,
    approvalStatus: 'PENDING_OR_DRYRUN',
    createdAt: now,
    createdBy: formUser_(),
    updatedAt: now,
    updatedBy: formUser_()
  });
  return bufferId;
}
