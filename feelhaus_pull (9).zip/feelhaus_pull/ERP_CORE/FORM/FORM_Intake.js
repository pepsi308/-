
function formReceiveExternal(payload) {
  formExecutionLog_('START', 'formReceiveExternal', null);
  try {
    return formExecutionReturn_('formReceiveExternal', formReceive_(payload || {}, FORM_WORK_TYPES.EXTERNAL));
  } catch (err) {
    return formExecutionError_('formReceiveExternal', err, { payload: payload || {} }, 'FORM_RECEIVE_EXTERNAL_FAILED');
  }
}


function formReceiveCafeForm(payload) {
  formExecutionLog_('START', 'formReceiveCafeForm', null);
  try {
    return formExecutionReturn_('formReceiveCafeForm', formReceive_(payload || {}, FORM_WORK_TYPES.CAFE_FORM));
  } catch (err) {
    return formExecutionError_('formReceiveCafeForm', err, { payload: payload || {} }, 'FORM_RECEIVE_CAFE_FAILED');
  }
}


function formReceiveAsRequest(payload) {
  formExecutionLog_('START', 'formReceiveAsRequest', null);
  try {
    return formExecutionReturn_('formReceiveAsRequest', formReceive_(Object.assign({}, payload || {}, { workType: FORM_WORK_TYPES.AS }), FORM_WORK_TYPES.AS));
  } catch (err) {
    return formExecutionError_('formReceiveAsRequest', err, { payload: payload || {} }, 'FORM_RECEIVE_AS_FAILED');
  }
}


function formReceiveClaimRefund(payload) {
  formExecutionLog_('START', 'formReceiveClaimRefund', null);
  try {
    return formExecutionReturn_('formReceiveClaimRefund', formReceive_(Object.assign({}, payload || {}, { workType: FORM_WORK_TYPES.CLAIM_REFUND }), FORM_WORK_TYPES.CLAIM_REFUND));
  } catch (err) {
    return formExecutionError_('formReceiveClaimRefund', err, { payload: payload || {} }, 'FORM_RECEIVE_CLAIM_FAILED');
  }
}

function formGetDuplicateWindowHours_() {
  try {
    const config = formGetSetupConfig_();
    const value = config.FORM_DUPLICATE_WINDOW_HOURS || config.formDuplicateWindowHours || config.duplicateWindowHours;
    const hours = Number(value);
    if (hours > 0) return hours;
  } catch (err) {
    // SystemConfig 조회 실패 시 기본값으로만 판단한다.
  }
  return 24;
}

function formNormalizeKey_(value) {
  return String(value == null ? '' : value).trim();
}

function formNormalizePhone_(value) {
  return String(value == null ? '' : value).replace(/[^0-9]/g, '');
}

function formDuplicateCreatedInWindow_(createdAt, now, windowHours) {
  if (!createdAt) return true;
  const created = createdAt instanceof Date ? createdAt : new Date(createdAt);
  if (isNaN(created.getTime())) return true;
  return (now.getTime() - created.getTime()) <= windowHours * 60 * 60 * 1000;
}

function formDuplicateTypeMatches_(rowType, criteria) {
  const rowKey = formNormalizeKey_(rowType);
  return !!rowKey && (rowKey === criteria.formType || rowKey === criteria.workType);
}

function formBuildDuplicateCriteria_(payload, workType, requestId) {
  return {
    requestId: formNormalizeKey_(requestId || payload.requestId || ''),
    sourceType: formNormalizeKey_(payload.sourceType),
    formType: formNormalizeKey_(payload.formType || workType),
    workType: formNormalizeKey_(workType || payload.workType || payload.formType || ''),
    eventId: formNormalizeKey_(payload.eventId),
    vendorId: formNormalizeKey_(payload.vendorId),
    customerId: formNormalizeKey_(payload.customerId),
    phone: formNormalizePhone_(payload.phone),
    dong: formNormalizeKey_(payload.dong),
    hosu: formNormalizeKey_(payload.hosu || payload.ho)
  };
}

function formIsSameDuplicateContext_(row, criteria) {
  return formNormalizeKey_(row.sourceType) === criteria.sourceType
    && formDuplicateTypeMatches_(row.formType || row.workType, criteria)
    && formNormalizeKey_(row.eventId) === criteria.eventId
    && formNormalizeKey_(row.vendorId) === criteria.vendorId;
}

function formDuplicateMatchReason_(row, criteria) {
  const rowRequestId = formNormalizeKey_(row.requestId);
  if (criteria.requestId && rowRequestId === criteria.requestId) return 'REQUEST_ID_MATCH';
  if (!formIsSameDuplicateContext_(row, criteria)) return '';
  if (criteria.customerId && formNormalizeKey_(row.customerId) === criteria.customerId) return 'CUSTOMER_ID_MATCH';
  if (criteria.phone && formNormalizePhone_(row.phone) === criteria.phone) return 'PHONE_MATCH';
  if (criteria.dong && criteria.hosu && formNormalizeKey_(row.dong) === criteria.dong && formNormalizeKey_(row.hosu) === criteria.hosu) return 'DONG_HOSU_MATCH';
  return '';
}

function formBuildDuplicateRowObject_(row, map, typeHeader) {
  return {
    requestId: map.requestId == null ? '' : row[map.requestId],
    sourceType: map.sourceType == null ? '' : row[map.sourceType],
    formType: map[typeHeader] == null ? '' : row[map[typeHeader]],
    workType: map.workType == null ? '' : row[map.workType],
    eventId: map.eventId == null ? '' : row[map.eventId],
    vendorId: map.vendorId == null ? '' : row[map.vendorId],
    customerId: map.customerId == null ? '' : row[map.customerId],
    phone: map.phone == null ? '' : row[map.phone],
    dong: map.dong == null ? '' : row[map.dong],
    hosu: map.hosu == null ? (map.ho == null ? '' : row[map.ho]) : row[map.hosu],
    createdAt: map.createdAt == null ? '' : row[map.createdAt]
  };
}

function formFindDuplicateIntake_(ss, payload, workType, requestId) {
  const criteria = formBuildDuplicateCriteria_(payload, workType, requestId);
  const now = formNow_();
  const windowHours = formGetDuplicateWindowHours_();
  const sheets = [
    { sheetName: FORM_SHEETS.RAW, typeHeader: 'formType' },
    { sheetName: FORM_SHEETS.MASTER, typeHeader: 'workType' }
  ];

  for (let s = 0; s < sheets.length; s++) {
    const sheet = ss.getSheetByName(sheets[s].sheetName);
    if (!sheet || sheet.getLastRow() < 2) continue;
    const values = sheet.getDataRange().getValues();
    const map = formHeaderMap_(values[0].map(String));
    for (let i = 1; i < values.length; i++) {
      const rowObj = formBuildDuplicateRowObject_(values[i], map, sheets[s].typeHeader);
      const reason = formDuplicateMatchReason_(rowObj, criteria);
      if (!reason) continue;
      if (reason !== 'REQUEST_ID_MATCH' && !formDuplicateCreatedInWindow_(rowObj.createdAt, now, windowHours)) continue;
      return {
        duplicate: true,
        requestId: formNormalizeKey_(rowObj.requestId),
        reason: reason,
        sheetName: sheets[s].sheetName,
        windowHours: windowHours
      };
    }
  }
  return { duplicate: false, requestId: '', reason: '', sheetName: '', windowHours: windowHours };
}

function formReturnDuplicateIntake_(duplicate, payload, workType, requestedRequestId) {
  const existingRequestId = duplicate.requestId || requestedRequestId || '';
  const detail = {
    duplicate: true,
    requestId: existingRequestId,
    requestedRequestId: requestedRequestId || '',
    workType: workType,
    sourceType: payload.sourceType || '',
    duplicateReason: duplicate.reason,
    duplicateSheet: duplicate.sheetName,
    duplicateWindowHours: duplicate.windowHours
  };
  formWriteLog_('FORM_DUPLICATE_BLOCKED', existingRequestId, duplicate.sheetName || FORM_SHEETS.RAW, '', JSON.stringify(detail), '중복 접수 차단');
  formWriteTimeline_(existingRequestId, FORM_STATUS.DUPLICATE_CANDIDATE, '중복 접수 차단', JSON.stringify(detail));
  return formResponse_(true, '중복 접수로 신규 저장하지 않고 기존 requestId를 반환합니다.', detail, '', { duplicate: true });
}

function formReceive_(payload, workType) {
  try {
    formAssertRequired_(payload, ['sourceType']);
    const ss = formGetMasterSpreadsheet_();
    const rawSheet = formEnsureSheet_(ss, FORM_SHEETS.RAW, FORM_REQUIRED_HEADERS.FORM_RAW);
    const masterSheet = formEnsureSheet_(ss, FORM_SHEETS.MASTER, FORM_REQUIRED_HEADERS.FORM_MASTER);
    const requestId = payload.requestId || formUuid_('REQ');
    const duplicate = workType === FORM_WORK_TYPES.DEMAND_SURVEY ? { duplicate: false, requestId: '', reason: '', sheetName: '', windowHours: 0 } : formFindDuplicateIntake_(ss, payload, workType, requestId);
    if (duplicate.duplicate) return formReturnDuplicateIntake_(duplicate, payload, workType, requestId);

    const now = formNow_();
    const actor = formUser_();
    const asId = workType === FORM_WORK_TYPES.AS ? (payload.asId || formUuid_('AS')) : (payload.asId || '');

    const rawRecord = {
      requestId: requestId,
      sourceType: payload.sourceType,
      formType: payload.formType || workType,
      memberType: payload.memberType || '',
      eventId: payload.eventId || '',
      vendorId: payload.vendorId || '',
      customerId: payload.customerId || '',
      saleId: payload.saleId || '',
      contractId: payload.contractId || '',
      installId: payload.installId || '',
      asId: asId,
      documentId: payload.documentId || '',
      attachmentId: payload.attachmentId || '',
      customerName: payload.customerName || payload.name || '',
      phone: payload.phone || '',
      dong: payload.dong || '',
      hosu: payload.hosu || payload.ho || '',
      title: payload.title || '',
      content: payload.content || payload.memo || '',
      rawPayload: JSON.stringify(payload),
      status: FORM_STATUS.RECEIVED,
      statusReason: workType === FORM_WORK_TYPES.DEMAND_SURVEY ? (payload.duplicateCandidate ? '수요조사 접수 / 중복 가능' : '수요조사 접수') : '접수 완료',
      retryCount: 0,
      createdAt: now,
      createdBy: actor,
      updatedAt: now,
      updatedBy: actor
    };
    formAppendByHeader_(rawSheet, rawRecord);

    const masterRecord = {
      requestId: requestId,
      sourceType: payload.sourceType,
      workType: workType,
      memberType: payload.memberType || '',
      eventId: payload.eventId || '',
      vendorId: payload.vendorId || '',
      customerId: payload.customerId || '',
      saleId: payload.saleId || '',
      contractId: payload.contractId || '',
      installId: payload.installId || '',
      asId: asId,
      documentId: payload.documentId || '',
      attachmentId: payload.attachmentId || '',
      candidateStatus: '',
      priority: workType === FORM_WORK_TYPES.CLAIM_REFUND ? 'HIGH' : (workType === FORM_WORK_TYPES.DEMAND_SURVEY && String(payload.interestLevel || '').indexOf('견적') !== -1 ? 'HIGH' : 'NORMAL'),
      assignedTo: '',
      scheduledAt: '',
      status: FORM_STATUS.ERP_DRYRUN_BLOCKED,
      statusReason: workType === FORM_WORK_TYPES.DEMAND_SURVEY ? (payload.duplicateCandidate ? '수요조사 접수 / 중복 가능 / SAFE MODE' : '수요조사 접수 / SAFE MODE') : 'ERP 원본 저장 차단 / 버퍼 보존',
      erpLinkedAt: '',
      createdAt: now,
      createdBy: actor,
      updatedAt: now,
      updatedBy: actor
    };
    formAppendByHeader_(masterSheet, masterRecord);
    formWriteTimeline_(requestId, FORM_STATUS.RECEIVED, '접수 완료', workType);
    formWriteLog_('FORM_RECEIVE', requestId, FORM_SHEETS.RAW, '', JSON.stringify(rawRecord), 'FORM 접수');
    return formLinkToErp(requestId);
  } catch (err) {
    return formResponse_(false, err.message, null, 'FORM_RECEIVE_FAILED');
  }
}
