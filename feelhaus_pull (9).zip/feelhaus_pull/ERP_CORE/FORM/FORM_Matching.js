const FORM_MATCH_TARGETS = Object.freeze({
  CUSTOMER: { sheet: 'ERP_고객관리', id: 'customerId', helpers: ['phone','customerName','dong','hosu'] },
  EVENT: { sheet: 'ERP_행사관리', id: 'eventId', helpers: ['eventName','eventNo'] },
  VENDOR: { sheet: 'ERP_업체관리', id: 'vendorId', helpers: ['vendorName','vendorNo'] }
});

function formMatchRequest(requestId) {
  try {
    const ss = formGetMasterSpreadsheet_();
    const rawSheet = formEnsureSheet_(ss, FORM_SHEETS.RAW, FORM_REQUIRED_HEADERS.FORM_RAW);
    const masterSheet = formEnsureSheet_(ss, FORM_SHEETS.MASTER, FORM_REQUIRED_HEADERS.FORM_MASTER);
    const foundRaw = formFindRowById_(rawSheet, 'requestId', requestId);
    const foundMaster = formFindRowById_(masterSheet, 'requestId', requestId);
    if (!foundRaw || !foundMaster) return formResponse_(false, '매칭 대상 접수 데이터를 찾을 수 없습니다.', { requestId: requestId }, 'MATCH_TARGET_NOT_FOUND');

    const raw = formRowObject_(foundRaw.row, foundRaw.map);
    const current = formRowObject_(foundMaster.row, foundMaster.map);
    const patch = {};

    if (!current.customerId) {
      const m = formFindCustomer_(ss, raw);
      if (m.ok) patch.customerId = m.id;
    }
    if (!current.eventId) {
      const m = formFindByIdOrName_(ss, FORM_MATCH_TARGETS.EVENT, raw.eventId, raw.eventName || raw.title);
      if (m.ok) patch.eventId = m.id;
    }
    if (!current.vendorId) {
      const m = formFindByIdOrName_(ss, FORM_MATCH_TARGETS.VENDOR, raw.vendorId, raw.vendorName || '');
      if (m.ok) patch.vendorId = m.id;
    }

    const hasAny = patch.customerId || patch.eventId || patch.vendorId || current.customerId || current.eventId || current.vendorId;
    patch.candidateStatus = hasAny ? FORM_STATUS.MATCHED : FORM_STATUS.RETRY_PENDING;
    patch.status = hasAny ? FORM_STATUS.ERP_DRYRUN_BLOCKED : FORM_STATUS.RETRY_PENDING;
    patch.statusReason = hasAny ? 'B03 매칭 완료 / ERP 원본 저장 차단' : 'B03 매칭 실패: 관리자 확인 필요';
    patch.updatedAt = formNow_();
    patch.updatedBy = formUser_();

    formUpdateRowByHeader_(masterSheet, foundMaster.rowIndex, patch);
    formUpdateRowByHeader_(rawSheet, foundRaw.rowIndex, {
      customerId: patch.customerId || raw.customerId || '',
      eventId: patch.eventId || raw.eventId || '',
      vendorId: patch.vendorId || raw.vendorId || '',
      status: patch.status,
      statusReason: patch.statusReason,
      updatedAt: formNow_(),
      updatedBy: formUser_()
    });

    formWriteTimeline_(requestId, patch.status, patch.statusReason, JSON.stringify(patch));
    formWriteLog_('FORM_MATCH', requestId, FORM_SHEETS.MASTER, JSON.stringify(current), JSON.stringify(patch), patch.statusReason);

    if (!hasAny) {
      formRegisterRetry_(requestId, raw.sourceType || '', current.workType || raw.formType || '', FORM_SHEETS.MASTER, 'MATCH_FAILED', 'customerId/eventId/vendorId 매칭 실패');
      return formResponse_(true, '매칭 실패, 재처리 대기 등록', { requestId: requestId, status: patch.status });
    }
    return formResponse_(true, '매칭 완료 / 원본 저장 차단', { requestId: requestId, patch: patch, dryRunOnly: true });
  } catch (err) {
    return formResponse_(false, err.message, { requestId: requestId }, 'MATCH_FAILED');
  }
}

function formFindCustomer_(ss, raw) {
  const sheet = ss.getSheetByName(FORM_MATCH_TARGETS.CUSTOMER.sheet);
  if (!sheet || sheet.getLastRow() < 2) return { ok: false };
  const values = sheet.getDataRange().getValues();
  const map = formHeaderMap_(values[0].map(String));
  const idCol = map.customerId;
  if (idCol == null) return { ok: false };

  const wantedId = String(raw.customerId || '').trim();
  if (wantedId) {
    for (let r = 1; r < values.length; r++) if (String(values[r][idCol]).trim() === wantedId) return { ok: true, id: wantedId };
  }

  const phone = String(raw.phone || '').replace(/[^0-9]/g, '');
  const dong = String(raw.dong || '').trim();
  const hosu = String(raw.hosu || raw.ho || '').trim();
  const name = String(raw.customerName || raw.name || '').trim();
  for (let r = 1; r < values.length; r++) {
    const rowPhone = String(map.phone == null ? '' : values[r][map.phone]).replace(/[^0-9]/g, '');
    const rowDong = String(map.dong == null ? '' : values[r][map.dong]).trim();
    const rowHosu = String(map.hosu == null ? '' : values[r][map.hosu]).trim();
    const rowName = String(map.customerName == null ? (map.name == null ? '' : values[r][map.name]) : values[r][map.customerName]).trim();
    if (phone && rowPhone && phone === rowPhone) return { ok: true, id: values[r][idCol] };
    if (dong && hosu && rowDong === dong && rowHosu === hosu) return { ok: true, id: values[r][idCol] };
    if (name && phone && rowName === name && rowPhone === phone) return { ok: true, id: values[r][idCol] };
  }
  return { ok: false };
}

function formFindByIdOrName_(ss, target, idValue, nameValue) {
  const sheet = ss.getSheetByName(target.sheet);
  if (!sheet || sheet.getLastRow() < 2) return { ok: false };
  const values = sheet.getDataRange().getValues();
  const map = formHeaderMap_(values[0].map(String));
  const idCol = map[target.id];
  if (idCol == null) return { ok: false };
  const id = String(idValue || '').trim();
  if (id) {
    for (let r = 1; r < values.length; r++) if (String(values[r][idCol]).trim() === id) return { ok: true, id: id };
  }
  const name = String(nameValue || '').trim();
  if (!name) return { ok: false };
  const nameHeaders = target.id === 'eventId' ? ['eventName','name','title'] : ['vendorName','name','companyName'];
  for (let r = 1; r < values.length; r++) {
    for (const h of nameHeaders) if (map[h] != null && String(values[r][map[h]]).trim() === name) return { ok: true, id: values[r][idCol] };
  }
  return { ok: false };
}
