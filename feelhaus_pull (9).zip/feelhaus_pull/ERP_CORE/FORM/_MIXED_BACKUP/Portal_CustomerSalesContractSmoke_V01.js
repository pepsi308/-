/*
 * Build: PORTAL_CUSTOMER_SALES_CONTRACT_SMOKE_V01_20260526
 * Purpose: Read-only smoke test for PORTAL customer/sales/contract menu wiring.
 * Safety: .js only / no write / no create / no send / no sheet mutation.
 */
var PORTAL_CUSTOMER_SALES_CONTRACT_SMOKE_V01_BUILD = 'PORTAL_CUSTOMER_SALES_CONTRACT_SMOKE_V01_20260526';

function runPortalCustomerSalesContractSmokeV01() {
  var report = {
    ok: true,
    build: PORTAL_CUSTOMER_SALES_CONTRACT_SMOKE_V01_BUILD,
    mode: 'CUSTOMER_SALES_CONTRACT_MENU_READONLY_SMOKE',
    checkedAt: new Date().toISOString(),
    fatal: [],
    warnings: [],
    results: [],
    summary: {}
  };

  function add(name, ok, message, data) {
    report.results.push({ name: name, ok: !!ok, message: message || '', data: data || null });
    if (!ok) report.ok = false;
  }

  try {
    add('isCustomerSalesPage exists', typeof isCustomerSalesPage_ === 'function', 'isCustomerSalesPage_ must exist', null);
    add('renderRouteContent exists', typeof renderRouteContent_ === 'function', 'renderRouteContent_ must exist', null);
    add('portalData exists', typeof portalData_ === 'function', 'portalData_ must exist', null);
    add('q04 source policy exists', typeof q04bSelectedSourcePolicy_ === 'function', 'q04bSelectedSourcePolicy_ should exist', null);
    add('q04 read rows exists', typeof q04ReadRowsByCode_ === 'function', 'q04ReadRowsByCode_ should exist', null);

    if (typeof isCustomerSalesPage_ === 'function') {
      var pages = ['customerSaleContract', 'customerDashboard', 'customerSearch', 'customerList', 'saleList', 'contractList', 'privacyAccess'];
      pages.forEach(function (page) {
        add('customer page recognized: ' + page, isCustomerSalesPage_(page) === true, page + ' should be recognized', { page: page });
      });
    }

    if (typeof q04bSelectedSourcePolicy_ === 'function') {
      var policy = q04bSelectedSourcePolicy_();
      var p = policy && policy.customerSalesContract;
      add('customerSalesContract source policy exists', !!p, 'customerSalesContract policy should exist', p || null);
      if (p) {
        add('customerSalesContract source is Sales', String(p.selectedCandidate || '') === 'Sales', 'selectedCandidate should be Sales', { selectedCandidate: p.selectedCandidate || '' });
        add('customerSalesContract id fields include customerId', (p.idFields || []).indexOf('customerId') >= 0, 'customerId should be included', { idFields: p.idFields || [] });
        add('customerSalesContract id fields include saleId', (p.idFields || []).indexOf('saleId') >= 0, 'saleId should be included', { idFields: p.idFields || [] });
        add('customerSalesContract id fields include contractId', (p.idFields || []).indexOf('contractId') >= 0, 'contractId should be included', { idFields: p.idFields || [] });
      }
    }

    if (typeof renderRouteContent_ === 'function' && typeof portalData_ === 'function') {
      var data = portalData_();
      var renderPages = ['customerSaleContract', 'customerDashboard', 'customerSearch', 'customerList', 'saleList', 'contractList', 'privacyAccess'];
      renderPages.forEach(function (page) {
        var html = renderRouteContent_(page, data);
        add('render customer page: ' + page, String(html || '').length > 100, page + ' should render non-empty html', {
          page: page,
          length: String(html || '').length,
          hasCustomerTree: String(html || '').indexOf('customerSalesTreeShell') >= 0,
          hasReadonlyGuard: String(html || '').indexOf('S01 보호 기준') >= 0 || String(html || '').indexOf('읽기 전용') >= 0
        });
      });
    }

    if (typeof q04ReadRowsByCode_ === 'function') {
      var read = q04ReadRowsByCode_('customerSalesContract', 3);
      add('customerSalesContract read only data probe', !!read && read.ok !== false, 'q04 customerSalesContract read should not fail', {
        sourceSheet: read && read.sourceSheet,
        dataRowCount: read && read.dataRowCount,
        previewRows: read && read.rows ? read.rows.length : 0,
        missingSheet: !!(read && read.missingSheet),
        error: read && read.error ? read.error : ''
      });
      if (read && read.missingSheet) {
        report.warnings.push({ name: 'source sheet missing', message: 'Sales sheet was not found. Menu can render, but list preview will show zero/guide state.', data: { sourceSheet: read.sourceSheet || 'Sales' } });
      }
    }
  } catch (err) {
    report.ok = false;
    report.fatal.push({ name: 'exception', message: String(err && err.message ? err.message : err), data: null });
  }

  var pass = 0;
  var fail = 0;
  report.results.forEach(function (r) { if (r.ok) pass++; else fail++; });
  report.summary = {
    targetMenu: 'customerSaleContract',
    targetPages: ['customerSaleContract', 'customerDashboard', 'customerSearch', 'customerList', 'saleList', 'contractList', 'privacyAccess'],
    sourcePolicy: 'Sales',
    total: report.results.length,
    pass: pass,
    fail: fail,
    warning: report.warnings.length,
    writePerformed: false,
    createdSheetCount: 0
  };
  report.ok = report.fatal.length === 0 && fail === 0;
  Logger.log(JSON.stringify(report, null, 2));
  return report;
}
