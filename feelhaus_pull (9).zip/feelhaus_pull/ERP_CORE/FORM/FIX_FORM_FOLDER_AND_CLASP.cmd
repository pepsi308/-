@echo off
chcp 65001 >nul
setlocal EnableExtensions EnableDelayedExpansion

title [FORM] 폴더 혼합파일 정리 + .clasp.json 보정

set "FORM_DIR=D:\pepsi308\OneDrive\feelhaus_pull\FORM"
set "FORM_SCRIPT_ID=1YN133k7c3rKHBU-sWMkGmtEi6GROK1e8VMcBXeU48FfZp_jWEERBOZYJ"
set "FORM_PROJECT_ID=modified-legacy-495118-p7"

cd /d "%FORM_DIR%"
if errorlevel 1 (
  echo [ERROR] FORM 폴더로 이동하지 못했습니다: %FORM_DIR%
  pause
  exit /b 1
)

echo ======================================================
echo [FORM 폴더 정리 시작]
echo 현재 경로: %CD%
echo ======================================================

if not exist "_MIXED_BACKUP" mkdir "_MIXED_BACKUP"

if exist "Portal_*.js" (
  echo [정리] Portal_*.js 파일을 _MIXED_BACKUP 폴더로 이동합니다.
  move /Y Portal_*.js "_MIXED_BACKUP\"
) else (
  echo [확인] Portal_*.js 혼합 파일 없음.
)

if exist ".clasp.json" (
  copy /Y ".clasp.json" ".clasp.json.backup_before_form_fix" >nul
  echo [백업] 기존 .clasp.json 백업 완료: .clasp.json.backup_before_form_fix
)

> ".clasp.json" echo {
>> ".clasp.json" echo   "scriptId": "%FORM_SCRIPT_ID%",
>> ".clasp.json" echo   "projectId": "%FORM_PROJECT_ID%",
>> ".clasp.json" echo   "rootDir": "./",
>> ".clasp.json" echo   "scriptExtensions": [
>> ".clasp.json" echo     ".js",
>> ".clasp.json" echo     ".gs"
>> ".clasp.json" echo   ],
>> ".clasp.json" echo   "htmlExtensions": [
>> ".clasp.json" echo     ".html"
>> ".clasp.json" echo   ],
>> ".clasp.json" echo   "jsonExtensions": [
>> ".clasp.json" echo     ".json"
>> ".clasp.json" echo   ],
>> ".clasp.json" echo   "filePushOrder": [],
>> ".clasp.json" echo   "skipSubdirectories": true
>> ".clasp.json" echo }

echo.
echo [확인] 수정된 .clasp.json:
type ".clasp.json"
echo.
echo ======================================================
echo [완료] FORM 폴더 정리 완료
echo 다음 명령으로 FORM만 다시 올리세요:
echo cd /d %FORM_DIR%
echo clasp push -f
echo ======================================================
pause
