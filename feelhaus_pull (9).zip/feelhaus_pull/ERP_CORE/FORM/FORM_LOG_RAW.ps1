$ErrorActionPreference = "Continue"
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
$OutputEncoding = [System.Text.Encoding]::UTF8
$SelfTest = $args -contains "--self-test"

function Stop-WithMessage {
  param([string]$Message)
  Write-Host ""
  Write-Host "======================================================"
  Write-Host $Message
  Write-Host "======================================================"
  Write-Host ""
  exit 1
}

$FormDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$LogDir = Join-Path $FormDir "logs"
$LatestFile = Join-Path $LogDir "form_latest_raw.log"
$ExpectedScriptId = "1YN133k7c3rKHBU-sWMkGmtEi6GROK1e8VMcBXeU48FfZp_jWEERBOZYJ"

Write-Host "======================================================"
Write-Host "[FORM RAW LOG]"
Write-Host "FORM folder : $FormDir"
Write-Host "Save file   : $LatestFile"
Write-Host "Stop        : Ctrl + C"
Write-Host "======================================================"
Write-Host ""

if (-not (Test-Path -LiteralPath $FormDir)) {
  Stop-WithMessage "[ERROR] FORM folder was not found: $FormDir"
}

Set-Location -LiteralPath $FormDir

if (-not (Test-Path -LiteralPath ".clasp.json")) {
  Stop-WithMessage "[ERROR] .clasp.json was not found in FORM folder: $(Get-Location)"
}

try {
  $claspJson = Get-Content -LiteralPath ".clasp.json" -Raw | ConvertFrom-Json
} catch {
  Stop-WithMessage "[ERROR] .clasp.json could not be parsed as JSON. $($_.Exception.Message)"
}

Write-Host "[INFO] scriptId : $($claspJson.scriptId)"
Write-Host "[INFO] projectId: $($claspJson.projectId)"
Write-Host "[INFO] skipSubdirectories: $($claspJson.skipSubdirectories)"

if ($claspJson.scriptId -ne $ExpectedScriptId) {
  Stop-WithMessage "[ERROR] FORM scriptId mismatch. Stop before reading logs."
}

if (-not $claspJson.projectId) {
  Stop-WithMessage "[ERROR] projectId is missing. clasp logs requires projectId."
}

if ($SelfTest) {
  Write-Host "[OK] FORM raw log self-test passed. No clasp command was executed."
  exit 0
}

if (-not (Test-Path -LiteralPath $LogDir)) {
  New-Item -ItemType Directory -Path $LogDir -Force | Out-Null
}

@(
  "======================================================"
  "[FORM RAW LOG START] $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')"
  "FORM folder : $(Get-Location)"
  "Save file   : $LatestFile"
  "scriptId    : $($claspJson.scriptId)"
  "projectId   : $($claspJson.projectId)"
  "======================================================"
) | Set-Content -LiteralPath $LatestFile -Encoding UTF8

$clasp = Get-Command "clasp.cmd" -ErrorAction SilentlyContinue
if (-not $clasp) { $clasp = Get-Command "clasp" -ErrorAction SilentlyContinue }
if (-not $clasp) {
  Stop-WithMessage "[ERROR] clasp was not found. Install Node.js and @google/clasp, then try again."
}

Write-Host ""
Write-Host "[INFO] clasp login --status"
& $clasp.Source login --status
Write-Host ""

Write-Host "[INFO] Starting raw log watch."
Write-Host "[INFO] Existing log file was overwritten: $LatestFile"
Write-Host ""

& $clasp.Source logs --watch 2>&1 | ForEach-Object {
  $line = [string]$_
  Write-Host $line
  Add-Content -LiteralPath $LatestFile -Value $line -Encoding UTF8
}
