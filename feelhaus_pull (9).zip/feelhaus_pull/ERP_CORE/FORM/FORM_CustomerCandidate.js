function formResolveCustomerCandidate(raw) {
  const duplicate = formDetectDuplicate(raw || {});
  if (duplicate.type === 'MATCHED') {
    return {
      status: FORM_STATUS.MATCHED,
      customerId: duplicate.customerId,
      duplicateCount: 1,
      duplicates: duplicate.list || []
    };
  }
  if (duplicate.type === 'DUPLICATE') {
    return {
      status: FORM_STATUS.DUPLICATE_CANDIDATE,
      customerId: '',
      customerCandidateId: formUuid_('CUST_TMP'),
      duplicateCount: duplicate.list.length,
      duplicates: duplicate.list
    };
  }
  return {
    status: FORM_STATUS.NEW_CANDIDATE,
    customerId: '',
    customerCandidateId: formUuid_('CUST_TMP'),
    duplicateCount: 0,
    duplicates: []
  };
}

function formDetectDuplicate(raw) {
  const ss = formGetMasterSpreadsheet_();
  const sheet = ss.getSheetByName('ERP_고객관리');
  if (!sheet || sheet.getLastRow() < 2) return { type: 'NEW', list: [] };

  const values = sheet.getDataRange().getValues();
  const map = formHeaderMap_(values[0].map(String));
  if (map.customerId == null) return { type: 'NEW', list: [] };

  const inputPhone = String(raw.phone || '').replace(/[^0-9]/g, '');
  const inputName = String(raw.customerName || raw.name || '').trim();
  const inputDong = String(raw.dong || '').trim();
  const inputHosu = String(raw.hosu || raw.ho || '').trim();
  const duplicates = [];

  for (let i = 1; i < values.length; i++) {
    const customerId = values[i][map.customerId];
    const rowPhone = String(map.phone == null ? '' : values[i][map.phone]).replace(/[^0-9]/g, '');
    const rowName = String(map.customerName == null ? (map.name == null ? '' : values[i][map.name]) : values[i][map.customerName]).trim();
    const rowDong = String(map.dong == null ? '' : values[i][map.dong]).trim();
    const rowHosu = String(map.hosu == null ? (map.ho == null ? '' : values[i][map.ho]) : values[i][map.hosu]).trim();

    if (inputPhone && rowPhone && inputPhone === rowPhone) {
      return { type: 'MATCHED', customerId: customerId, list: [{ customerId: customerId, reason: 'PHONE_MATCH' }] };
    }
    if (inputDong && inputHosu && rowDong === inputDong && rowHosu === inputHosu) {
      duplicates.push({ customerId: customerId, reason: 'DONG_HOSU_MATCH' });
    } else if (inputName && rowName === inputName) {
      duplicates.push({ customerId: customerId, reason: 'NAME_MATCH' });
    }
  }

  if (duplicates.length > 0) return { type: 'DUPLICATE', list: duplicates };
  return { type: 'NEW', list: [] };
}

function formSaveCustomerCandidateBuffer_(requestId, raw, candidate) {
  const ss = formGetMasterSpreadsheet_();
  const sheet = formEnsureSheet_(ss, FORM_SHEETS.CUSTOMER_BUFFER, FORM_REQUIRED_HEADERS.FORM_CUSTOMER_BUFFER);
  const now = formNow_();
  const bufferId = formUuid_('CBUF');
  formAppendByHeader_(sheet, {
    bufferId: bufferId,
    requestId: requestId,
    customerCandidateId: candidate.customerCandidateId || '',
    customerId: candidate.customerId || '',
    candidateStatus: candidate.status || '',
    memberType: raw.memberType || (raw.isMember ? 'REGULAR' : 'ASSOCIATE'),
    eventId: raw.eventId || '',
    vendorId: raw.vendorId || '',
    customerName: raw.customerName || raw.name || '',
    phone: raw.phone || '',
    dong: raw.dong || '',
    hosu: raw.hosu || raw.ho || '',
    duplicateCount: candidate.duplicateCount || 0,
    duplicateJson: JSON.stringify(candidate.duplicates || []),
    dryRunOnly: true,
    approvalStatus: 'PENDING_OR_DRYRUN',
    createdAt: now,
    createdBy: formUser_(),
    updatedAt: now,
    updatedBy: formUser_()
  });
  return bufferId;
}
