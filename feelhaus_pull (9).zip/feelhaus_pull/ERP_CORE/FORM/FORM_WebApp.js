/**
 * B48-12 WEBAPP LOG FALLBACK
 * Prevents doGet/doPost from failing at the first line if an older deployment or
 * partial upload resolves FORM_WebApp before FORM_Core's private log helper.
 * FORM_Core's full helper remains the standard logger when available.
 */
if (typeof formExecutionLog_ !== 'function') {
  var formExecutionLog_ = function(phase, functionName, value) {
    try {
      Logger.log('[FORM_EXEC] ' + String(phase || 'RUN') + ' | ' + String(functionName || '') + ' | WEBAPP_FALLBACK');
    } catch (err) {}
  };
}

function doGet(e) {
  formExecutionLog_('START', 'doGet', null);
  try {
    let output;
    try {
      const tpl = HtmlService.createTemplateFromFile('FORM_UI');
      const initialState = formBuildInitialUiState_(e);
      tpl.build = FORM_BUILD;
      tpl.safeMode = FORM_SAFE_MODE;
      tpl.initialStateJson = JSON.stringify(initialState);
      output = tpl.evaluate();
      output.setTitle(initialState && initialState.shareTitle ? initialState.shareTitle : 'FEELHAUS 수요조사 폼센터');
    } catch (tplErr) {
      output = HtmlService.createHtmlOutput(formWebAppFallbackHtml_(tplErr));
    }
    output
      .setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL);
    return formExecutionReturn_('doGet', output);
  } catch (err) {
    formExecutionLog_('ERROR', 'doGet', null);
    throw err;
  }
}

function formBuildInitialUiState_(e) {
  const p = e && e.parameter ? e.parameter : {};
  const mode = String(p.mode || p.view || '').toLowerCase();
  const surveyId = String(p.d || p.surveyId || '').trim();
  const saved = surveyId ? formLoadDemandSurveyConfig_(surveyId) : null;
  const isDemand = !!saved || mode === 'demand' || mode === 'survey' || String(p.demand || '') === '1';
  return {
    mode: isDemand ? 'demand' : 'admin',
    surveyId: surveyId || (saved && saved.surveyId) || '',
    eventId: String((saved && saved.eventId) || p.eventId || ''),
    vendorId: String((saved && saved.vendorId) || p.vendorId || ''),
    apartmentName: String((saved && saved.apartmentName) || p.apartmentName || p.apt || ''),
    apartmentKey: String((saved && saved.apartmentKey) || p.apartmentKey || ''),
    items: String((saved && (saved.selectedItemsText || saved.itemsText)) || p.items || ''),
    shareTitle: String((saved && saved.shareTitle) || ((saved && saved.apartmentName) ? saved.apartmentName + ' 입주박람회 사전 수요조사' : '입주박람회 사전 수요조사')),
    privacyText: String((saved && saved.privacyConsentText) || '동/호수 정보와 선택한 관심 품목을 입주박람회 사전 수요조사 및 상담 준비 목적으로 수집·이용하는 데 동의합니다.'),
    marketingText: String((saved && saved.marketingConsentText) || '입주박람회 혜택 안내, 상품 상담, 견적 안내 및 관련 영업활동에 활용하는 데 동의합니다.'),
    build: FORM_BUILD
  };
}


function doPost(e) {
  formExecutionLog_('START', 'doPost', null);
  try {
    const payload = formParseWebAppPayload_(e);
    const result = formSubmitFromUi(payload);
    const output = ContentService
      .createTextOutput(JSON.stringify(result))
      .setMimeType(ContentService.MimeType.JSON);
    return formExecutionReturn_('doPost', output);
  } catch (err) {
    const result = formResponse_(false, err && err.message ? err.message : String(err), null, 'WEBAPP_POST_FAILED');
    formExecutionLog_('ERROR', 'doPost', null);
    return ContentService
      .createTextOutput(JSON.stringify(result))
      .setMimeType(ContentService.MimeType.JSON);
  }
}

function formWebAppFallbackHtml_(err) {
  const msg = err && err.message ? err.message : 'FORM_UI 템플릿을 불러오지 못했습니다.';
  return '<!doctype html><html><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">'
    + '<title>FEELHAUS FORM</title></head><body style="font-family:Arial,sans-serif;margin:24px;line-height:1.6">'
    + '<h2>FEELHAUS FORM SAFE MODE</h2>'
    + '<p>화면 템플릿을 찾지 못해 안내 화면을 표시합니다.</p>'
    + '<p>FORM_UI.html 파일 또는 WebApp 배포 설정을 확인하세요.</p>'
    + '<p>Build: ' + FORM_BUILD + '</p>'
    + '<p>Detail: ' + String(msg).replace(/[<>]/g, '') + '</p>'
    + '<footer style="margin-top:32px;color:#777;font-size:12px">© 2026 FEELHAUS. All rights reserved. / (주)필하우스</footer>'
    + '</body></html>';
}

function formParseWebAppPayload_(e) {
  if (!e) return {};
  if (e.postData && e.postData.contents) {
    const text = String(e.postData.contents || '').trim();
    if (!text) return {};
    try {
      return JSON.parse(text);
    } catch (jsonErr) {
      const params = {};
      text.split('&').forEach(part => {
        const pair = part.split('=');
        if (!pair[0]) return;
        params[decodeURIComponent(pair[0])] = decodeURIComponent((pair[1] || '').replace(/\+/g, ' '));
      });
      return params;
    }
  }
  if (e.parameter) return Object.assign({}, e.parameter);
  if (e.parameters) {
    const out = {};
    Object.keys(e.parameters).forEach(k => {
      const v = e.parameters[k];
      out[k] = Array.isArray(v) ? v[0] : v;
    });
    return out;
  }
  return {};
}

function formNormalizeUiPayload_(payload) {
  const input = payload || {};
  const out = Object.assign({}, input);
  Object.keys(out).forEach(k => {
    if (typeof out[k] === 'string') out[k] = out[k].trim();
  });

  out.sourceType = out.sourceType || out.source || out.channel || 'WEBAPP_UI';
  out.formType = out.formType || out.formName || out.category || out.requestType || out.type || '';
  out.workType = formNormalizeUiWorkType_(out.workType || out.requestType || out.type || out.formType);
  out.customerName = out.customerName || out.name || out.applicantName || '';
  out.phone = out.phone || out.mobile || out.tel || '';
  out.hosu = out.hosu || out.ho || out.unit || '';
  out.content = out.content || out.memo || out.description || out.message || '';
  out.title = out.title || out.subject || out.formType || out.workType || 'FORM 접수';

  if (!out.formType) out.formType = out.workType;
  return out;
}

function formNormalizeUiWorkType_(value) {
  const text = String(value || '').trim().toUpperCase();
  if (!text) return FORM_WORK_TYPES.EXTERNAL;
  if (text === FORM_WORK_TYPES.QR_CUSTOMER || text === 'QR' || text === 'QR_CUSTOMER' || text.indexOf('QR') !== -1) return FORM_WORK_TYPES.QR_CUSTOMER;
  if (text === FORM_WORK_TYPES.AS || text === 'AS' || text === 'A/S' || text.indexOf('A/S') !== -1 || text.indexOf('AS_') !== -1) return FORM_WORK_TYPES.AS;
  if (text === FORM_WORK_TYPES.CLAIM_REFUND || text.indexOf('CLAIM') !== -1 || text.indexOf('REFUND') !== -1 || text.indexOf('클레임') !== -1 || text.indexOf('환불') !== -1) return FORM_WORK_TYPES.CLAIM_REFUND;
  if (text === FORM_WORK_TYPES.DEMAND_SURVEY || text.indexOf('DEMAND') !== -1 || text.indexOf('SURVEY') !== -1 || text.indexOf('수요') !== -1) return FORM_WORK_TYPES.DEMAND_SURVEY;
  if (text === FORM_WORK_TYPES.CAFE_FORM || text.indexOf('CAFE') !== -1 || text.indexOf('카페') !== -1 || text.indexOf('폼') !== -1) return FORM_WORK_TYPES.CAFE_FORM;
  return FORM_WORK_TYPES.EXTERNAL;
}

function formBuildUiMessage_(result) {
  const data = result && result.data ? result.data : {};
  if (!result || result.ok !== true) return '접수 처리 중 오류가 발생했습니다. 관리자에게 문의하세요.';
  if (data.duplicate === true) return '이미 접수된 건입니다. 기존 접수번호를 확인하세요.';
  if (data.dryRunOnly === true || data.liveWriteBlocked === true) return '접수 완료. SAFE MODE로 ERP 원본 저장은 차단되었습니다.';
  return '접수 완료.';
}

function formWrapUiSubmitResult_(result) {
  const base = result || formResponse_(false, '접수 결과가 없습니다.', null, 'FORM_UI_EMPTY_RESULT');
  const data = Object.assign({}, base.data || {});
  data.uiMessage = formBuildUiMessage_(base);
  data.webAppBuild = FORM_BUILD;
  data.erpWriteAllowed = FORM_SAFE_MODE.ERP_WRITE_ALLOWED === true;
  return formResponse_(base.ok, data.uiMessage || base.message, data, base.errorCode || '', Object.assign({}, base.meta || {}, { webApp: true }));
}


function formRequestFilterDateMs_(value) {
  if (!value) return null;
  const date = value instanceof Date ? value : new Date(value);
  if (isNaN(date.getTime())) return null;
  return date.getTime();
}

function formRequestFilterString_(value) {
  return String(value == null ? '' : value).trim();
}

function formRequestFilterMatchValue_(rowValue, filterValue) {
  const wanted = formRequestFilterString_(filterValue);
  if (!wanted) return true;
  return formRequestFilterString_(rowValue) === wanted;
}

function formRequestFilterMatchAny_(rowValue, filterValues) {
  if (!filterValues) return true;
  const list = Array.isArray(filterValues) ? filterValues : String(filterValues).split(',');
  const normalized = list.map(v => formRequestFilterString_(v)).filter(Boolean);
  if (!normalized.length) return true;
  return normalized.indexOf(formRequestFilterString_(rowValue)) !== -1;
}

function formRequestMatchesFilters_(row, filters) {
  const f = filters || {};
  if (!formRequestFilterMatchAny_(row.status, f.statuses || f.statusList || f.status)) return false;
  if (!formRequestFilterMatchAny_(row.workType, f.workTypes || f.workTypeList || f.workType)) return false;
  if (!formRequestFilterMatchValue_(row.sourceType, f.sourceType)) return false;
  if (!formRequestFilterMatchValue_(row.assignedTo, f.assignedTo)) return false;
  if (!formRequestFilterMatchValue_(row.eventId, f.eventId)) return false;
  if (!formRequestFilterMatchValue_(row.vendorId, f.vendorId)) return false;
  if (!formRequestFilterMatchValue_(row.customerId, f.customerId)) return false;
  if (!formRequestFilterMatchValue_(row.requestId, f.requestId)) return false;

  const createdMs = formRequestFilterDateMs_(row.createdAt);
  const fromMs = formRequestFilterDateMs_(f.createdFrom || f.fromDate || f.from);
  const toMs = formRequestFilterDateMs_(f.createdTo || f.toDate || f.to);
  if (fromMs != null && createdMs != null && createdMs < fromMs) return false;
  if (toMs != null && createdMs != null && createdMs > toMs) return false;

  const keyword = formRequestFilterString_(f.keyword || f.q).toLowerCase();
  if (keyword) {
    const haystack = [
      row.requestId, row.sourceType, row.workType, row.eventId, row.vendorId,
      row.customerId, row.asId, row.documentId, row.assignedTo, row.status,
      row.statusReason, row.priority
    ].map(v => formRequestFilterString_(v).toLowerCase()).join(' ');
    if (haystack.indexOf(keyword) === -1) return false;
  }
  return true;
}

function formListRequestsFiltered(filters, limit) {
  formExecutionLog_('START', 'formListRequestsFiltered', null);
  try {
    const ss = formGetMasterSpreadsheet_();
    const sheet = ss.getSheetByName(FORM_SHEETS.MASTER);
    if (!sheet || sheet.getLastRow() < 2) {
      return formExecutionReturn_('formListRequestsFiltered', formResponse_(true, 'FORM B44 요청 목록 데이터가 없습니다.', [], '', {
        readOnly: true,
        filtered: true
      }));
    }
    const values = sheet.getDataRange().getValues();
    const headers = values[0].map(String);
    const maxLimit = Math.min(Math.max(Number(limit) || 50, 1), 200);
    const rows = [];
    for (let i = values.length - 1; i >= 1; i--) {
      const obj = {};
      headers.forEach((h, idx) => obj[h] = values[i][idx]);
      if (!formRequestMatchesFilters_(obj, filters || {})) continue;
      rows.push(formApplyMask_(obj));
      if (rows.length >= maxLimit) break;
    }
    return formExecutionReturn_('formListRequestsFiltered', formResponse_(true, rows.length ? 'FORM B44 요청 목록 조회 완료' : 'FORM B44 조건에 맞는 요청이 없습니다.', rows, '', {
      readOnly: true,
      filtered: true,
      limit: maxLimit,
      filterKeys: Object.keys(filters || {}).filter(k => filters[k] !== undefined && filters[k] !== null && String(filters[k]).trim() !== '')
    }));
  } catch (err) {
    return formExecutionError_('formListRequestsFiltered', err, { filters: filters || {}, limit: limit || '' }, 'REQUEST_LIST_FAILED');
  }
}

function formGetRequestListSummary(filters) {
  formExecutionLog_('START', 'formGetRequestListSummary', null);
  try {
    const listResult = formListRequestsFiltered(filters || {}, 200);
    const rows = listResult && listResult.ok && Array.isArray(listResult.data) ? listResult.data : [];
    const byStatus = {};
    const byWorkType = {};
    const byAssignee = {};
    rows.forEach(row => {
      const status = String(row.status || 'EMPTY');
      const workType = String(row.workType || 'EMPTY');
      const assignee = String(row.assignedTo || 'UNASSIGNED');
      byStatus[status] = (byStatus[status] || 0) + 1;
      byWorkType[workType] = (byWorkType[workType] || 0) + 1;
      byAssignee[assignee] = (byAssignee[assignee] || 0) + 1;
    });
    const data = {
      count: rows.length,
      byStatus: byStatus,
      byWorkType: byWorkType,
      byAssignee: byAssignee,
      sample: rows.slice(0, 10),
      readOnly: true,
      sourceSheet: FORM_SHEETS.MASTER,
      filtered: true,
      safeMode: FORM_SAFE_MODE
    };
    return formExecutionReturn_('formGetRequestListSummary', formResponse_(true, 'FORM B44 요청 목록 요약', data));
  } catch (err) {
    return formExecutionError_('formGetRequestListSummary', err, { filters: filters || {} }, 'REQUEST_LIST_SUMMARY_FAILED');
  }
}


function formListRequestTimeline(requestId, limit) {
  formExecutionLog_('START', 'formListRequestTimeline', null);
  try {
    const ss = formGetMasterSpreadsheet_();
    const sheet = ss.getSheetByName(FORM_SHEETS.TIMELINE);
    if (!sheet || sheet.getLastRow() < 2) {
      return formExecutionReturn_('formListRequestTimeline', formResponse_(true, 'FORM B44 request timeline is empty.', [], '', {
        readOnly: true,
        sourceSheet: FORM_SHEETS.TIMELINE
      }));
    }
    const values = sheet.getDataRange().getValues();
    const headers = values[0].map(String);
    const maxLimit = Math.min(Math.max(Number(limit) || 50, 1), 200);
    const rows = [];
    for (let i = values.length - 1; i >= 1; i--) {
      const obj = {};
      headers.forEach((h, idx) => obj[h] = values[i][idx]);
      if (requestId && String(obj.requestId || '') !== String(requestId)) continue;
      rows.push(formApplyMask_(obj));
      if (rows.length >= maxLimit) break;
    }
    return formExecutionReturn_('formListRequestTimeline', formResponse_(true, rows.length ? 'FORM B44 request timeline read complete.' : 'FORM B44 no matching timeline rows.', rows, '', {
      readOnly: true,
      sourceSheet: FORM_SHEETS.TIMELINE,
      requestId: requestId || '',
      limit: maxLimit
    }));
  } catch (err) {
    return formExecutionError_('formListRequestTimeline', err, { requestId: requestId || '', limit: limit || '' }, 'REQUEST_TIMELINE_FAILED');
  }
}

function formFindRowsByHeaderValue_(sheet, idHeader, idValue, limit) {
  if (!sheet || sheet.getLastRow() < 2) return [];
  const values = sheet.getDataRange().getValues();
  const headers = values[0].map(String);
  const map = formHeaderMap_(headers);
  if (map[idHeader] == null) return [];
  const maxLimit = Math.min(Math.max(Number(limit) || 50, 1), 200);
  const rows = [];
  for (let i = values.length - 1; i >= 1; i--) {
    if (String(values[i][map[idHeader]] || '') !== String(idValue || '')) continue;
    const obj = {};
    headers.forEach((h, idx) => obj[h] = values[i][idx]);
    rows.push(formApplyMask_(obj));
    if (rows.length >= maxLimit) break;
  }
  return rows;
}

function formGetRequestDetail(requestId) {
  formExecutionLog_('START', 'formGetRequestDetail', null);
  try {
    if (!requestId) return formExecutionReturn_('formGetRequestDetail', formResponse_(false, 'requestId is required.', null, 'REQUEST_ID_REQUIRED'));
    const ss = formGetMasterSpreadsheet_();
    const masterSheet = formEnsureSheet_(ss, FORM_SHEETS.MASTER, FORM_REQUIRED_HEADERS.FORM_MASTER);
    const found = formFindRowById_(masterSheet, 'requestId', requestId);
    if (!found) return formExecutionReturn_('formGetRequestDetail', formResponse_(false, 'Request not found.', { requestId: requestId }, 'REQUEST_NOT_FOUND'));
    const master = formApplyMask_(formRowObject_(found.row, found.map));
    const rawSheet = ss.getSheetByName(FORM_SHEETS.RAW);
    const retrySheet = ss.getSheetByName(FORM_SHEETS.RETRY);
    const approvalSheet = ss.getSheetByName(FORM_SHEETS.APPROVAL);
    const attachSheet = ss.getSheetByName(FORM_SHEETS.ATTACH);
    const documentSheet = ss.getSheetByName(FORM_SHEETS.DOCUMENT_BUFFER);
    const timeline = formListRequestTimeline(requestId, 100);
    const memoRowsResult = formListRequestMemos(requestId, 100);
    const memoAuditSummaryResult = formGetMemoAuditSummary(requestId, 50);
    const rawRows = formFindRowsByHeaderValue_(rawSheet, 'requestId', requestId, 20);
    const retryRows = formFindRowsByHeaderValue_(retrySheet, 'requestId', requestId, 20);
    const approvalRows = formFindRowsByHeaderValue_(approvalSheet, 'requestId', requestId, 20);
    const attachmentRows = formFindRowsByHeaderValue_(attachSheet, 'requestId', requestId, 50);
    const documentRows = formFindRowsByHeaderValue_(documentSheet, 'requestId', requestId, 50);
    const data = {
      requestId: requestId,
      master: master,
      rawRows: rawRows,
      timeline: timeline && timeline.ok ? (timeline.data || []) : [],
      memoRows: memoRowsResult && memoRowsResult.ok ? (memoRowsResult.data || []) : [],
      memoAuditSummary: memoAuditSummaryResult && memoAuditSummaryResult.ok ? memoAuditSummaryResult.data : null,
      retryRows: retryRows,
      approvalRows: approvalRows,
      attachmentRows: attachmentRows,
      documentRows: documentRows,
      counts: {
        raw: rawRows.length,
        timeline: timeline && timeline.data ? timeline.data.length : 0,
        memo: memoRowsResult && memoRowsResult.data ? memoRowsResult.data.length : 0,
        memoAudit: memoAuditSummaryResult && memoAuditSummaryResult.data ? memoAuditSummaryResult.data.count : 0,
        retry: retryRows.length,
        approval: approvalRows.length,
        attachment: attachmentRows.length,
        document: documentRows.length
      },
      readOnly: true,
      safeMode: FORM_SAFE_MODE
    };
    return formExecutionReturn_('formGetRequestDetail', formResponse_(true, 'FORM B44 request detail read complete.', data));
  } catch (err) {
    return formExecutionError_('formGetRequestDetail', err, { requestId: requestId || '' }, 'REQUEST_DETAIL_FAILED');
  }
}


function formListRequestAttachments(requestId, limit) {
  formExecutionLog_('START', 'formListRequestAttachments', null);
  try {
    if (!requestId) return formExecutionReturn_('formListRequestAttachments', formResponse_(false, 'requestId is required.', [], 'REQUEST_ID_REQUIRED'));
    const ss = formGetMasterSpreadsheet_();
    const sheet = ss.getSheetByName(FORM_SHEETS.ATTACH);
    const rows = formFindRowsByHeaderValue_(sheet, 'requestId', requestId, limit || 50);
    return formExecutionReturn_('formListRequestAttachments', formResponse_(true, rows.length ? 'FORM B44 attachment link read complete.' : 'FORM B44 no matching attachment rows.', rows, '', {
      readOnly: true,
      sourceSheet: FORM_SHEETS.ATTACH,
      requestId: requestId,
      count: rows.length
    }));
  } catch (err) {
    return formExecutionError_('formListRequestAttachments', err, { requestId: requestId || '', limit: limit || '' }, 'REQUEST_ATTACHMENTS_FAILED');
  }
}

function formListRequestDocuments(requestId, limit) {
  formExecutionLog_('START', 'formListRequestDocuments', null);
  try {
    if (!requestId) return formExecutionReturn_('formListRequestDocuments', formResponse_(false, 'requestId is required.', [], 'REQUEST_ID_REQUIRED'));
    const ss = formGetMasterSpreadsheet_();
    const sheet = ss.getSheetByName(FORM_SHEETS.DOCUMENT_BUFFER);
    const rows = formFindRowsByHeaderValue_(sheet, 'requestId', requestId, limit || 50);
    return formExecutionReturn_('formListRequestDocuments', formResponse_(true, rows.length ? 'FORM B44 document candidate link read complete.' : 'FORM B44 no matching document candidate rows.', rows, '', {
      readOnly: true,
      sourceSheet: FORM_SHEETS.DOCUMENT_BUFFER,
      requestId: requestId,
      count: rows.length,
      signWriteAllowed: FORM_SAFE_MODE.SIGN_WRITE_ALLOWED === true
    }));
  } catch (err) {
    return formExecutionError_('formListRequestDocuments', err, { requestId: requestId || '', limit: limit || '' }, 'REQUEST_DOCUMENTS_FAILED');
  }
}

function formGetRequestEvidence(requestId) {
  formExecutionLog_('START', 'formGetRequestEvidence', null);
  try {
    if (!requestId) return formExecutionReturn_('formGetRequestEvidence', formResponse_(false, 'requestId is required.', null, 'REQUEST_ID_REQUIRED'));
    const detail = formGetRequestDetail(requestId);
    const attachments = formListRequestAttachments(requestId, 50);
    const documents = formListRequestDocuments(requestId, 50);
    const timeline = formListRequestTimeline(requestId, 50);
    const memos = formListRequestMemos(requestId, 50);
    const memoAuditSummary = formGetMemoAuditSummary(requestId, 50);
    const data = {
      requestId: requestId,
      detail: detail && detail.ok ? detail.data : null,
      attachments: attachments && attachments.ok ? (attachments.data || []) : [],
      documents: documents && documents.ok ? (documents.data || []) : [],
      timeline: timeline && timeline.ok ? (timeline.data || []) : [],
      memos: memos && memos.ok ? (memos.data || []) : [],
      memoAuditSummary: memoAuditSummary && memoAuditSummary.ok ? memoAuditSummary.data : null,
      counts: {
        attachment: attachments && attachments.data ? attachments.data.length : 0,
        document: documents && documents.data ? documents.data.length : 0,
        timeline: timeline && timeline.data ? timeline.data.length : 0,
        memo: memos && memos.data ? memos.data.length : 0,
        memoAudit: memoAuditSummary && memoAuditSummary.data ? memoAuditSummary.data.count : 0
      },
      readOnly: true,
      safeMode: FORM_SAFE_MODE,
      originalWriteBlocked: {
        sign: FORM_SAFE_MODE.SIGN_WRITE_ALLOWED !== true,
        erp: FORM_SAFE_MODE.ERP_WRITE_ALLOWED !== true,
        settlement: FORM_SAFE_MODE.SETTLEMENT_WRITE_ALLOWED !== true,
        externalSync: FORM_SAFE_MODE.EXTERNAL_SYNC_ALLOWED !== true
      }
    };
    return formExecutionReturn_('formGetRequestEvidence', formResponse_(true, 'FORM B44 request evidence links read complete.', data));
  } catch (err) {
    return formExecutionError_('formGetRequestEvidence', err, { requestId: requestId || '' }, 'REQUEST_EVIDENCE_FAILED');
  }
}


function formListRequestMemos(requestId, limit) {
  formExecutionLog_('START', 'formListRequestMemos', null);
  try {
    if (!requestId) return formExecutionReturn_('formListRequestMemos', formResponse_(false, 'requestId is required.', [], 'REQUEST_ID_REQUIRED'));
    const ss = formGetMasterSpreadsheet_();
    const sheet = ss.getSheetByName(FORM_SHEETS.TIMELINE);
    const rows = formFindRowsByHeaderValue_(sheet, 'requestId', requestId, limit || 50).filter(row => {
      const reason = String(row.statusReason || '');
      return reason.indexOf('MEMO') !== -1 || reason.indexOf('NOTE') !== -1;
    });
    return formExecutionReturn_('formListRequestMemos', formResponse_(true, rows.length ? 'FORM B44 request memo read complete.' : 'FORM B44 no matching request memo rows.', rows, '', {
      readOnly: true,
      sourceSheet: FORM_SHEETS.TIMELINE,
      requestId: requestId,
      count: rows.length
    }));
  } catch (err) {
    return formExecutionError_('formListRequestMemos', err, { requestId: requestId || '', limit: limit || '' }, 'REQUEST_MEMOS_FAILED');
  }
}

function formGetRequestMemoSummary(requestId, limit) {
  formExecutionLog_('START', 'formGetRequestMemoSummary', null);
  try {
    if (!requestId) return formExecutionReturn_('formGetRequestMemoSummary', formResponse_(false, 'requestId is required.', null, 'REQUEST_ID_REQUIRED'));
    const memos = formListRequestMemos(requestId, limit || 50);
    const rows = memos && memos.ok && Array.isArray(memos.data) ? memos.data : [];
    const latest = rows.length ? rows[0] : null;
    const byMemoType = {};
    rows.forEach(row => {
      const key = String(row.statusReason || 'EMPTY');
      byMemoType[key] = (byMemoType[key] || 0) + 1;
    });
    const data = {
      requestId: requestId,
      count: rows.length,
      latestMemo: latest,
      byMemoType: byMemoType,
      readOnly: true,
      sourceSheet: FORM_SHEETS.TIMELINE
    };
    return formExecutionReturn_('formGetRequestMemoSummary', formResponse_(true, 'FORM B44 request memo summary read complete.', data));
  } catch (err) {
    return formExecutionError_('formGetRequestMemoSummary', err, { requestId: requestId || '', limit: limit || '' }, 'REQUEST_MEMO_SUMMARY_FAILED');
  }
}


function formGetMemoAuditSummary(requestId, limit) {
  formExecutionLog_('START', 'formGetMemoAuditSummary', null);
  try {
    if (!requestId) return formExecutionReturn_('formGetMemoAuditSummary', formResponse_(false, 'requestId is required.', null, 'REQUEST_ID_REQUIRED'));
    const ss = formGetMasterSpreadsheet_();
    const logSheet = ss.getSheetByName(FORM_SHEETS.LOG);
    const logRows = formFindRowsByHeaderValue_(logSheet, 'targetId', requestId, limit || 100).filter(row => String(row.actionType || '').indexOf('REQUEST_MEMO_') === 0);
    const timelineRows = formListRequestTimeline(requestId, limit || 100);
    const timelineAuditRows = timelineRows && timelineRows.ok && Array.isArray(timelineRows.data) ? timelineRows.data.filter(row => {
      const reason = String(row.statusReason || '');
      return reason === 'MEMO_UPDATE_BLOCKED' || reason === 'MEMO_DELETE_BLOCKED';
    }) : [];
    const byAction = {};
    logRows.forEach(row => {
      const action = String(row.actionType || 'EMPTY');
      byAction[action] = (byAction[action] || 0) + 1;
    });
    const data = {
      requestId: requestId,
      count: logRows.length,
      blockedUpdateCount: byAction.REQUEST_MEMO_UPDATE_BLOCKED || 0,
      blockedDeleteCount: byAction.REQUEST_MEMO_DELETE_BLOCKED || 0,
      addCount: byAction.REQUEST_MEMO_ADD || 0,
      byAction: byAction,
      recentAuditLogs: logRows.slice(0, Math.min(Number(limit) || 50, 50)),
      blockedTimelineRows: timelineAuditRows.slice(0, Math.min(Number(limit) || 50, 50)),
      readOnly: true,
      sourceSheets: [FORM_SHEETS.LOG, FORM_SHEETS.TIMELINE],
      memoOriginalMutationAllowed: false,
      suggestedCorrectionFlow: 'formAddRequestMemo'
    };
    return formExecutionReturn_('formGetMemoAuditSummary', formResponse_(true, 'FORM B44 request memo audit summary read complete.', data));
  } catch (err) {
    return formExecutionError_('formGetMemoAuditSummary', err, { requestId: requestId || '', limit: limit || '' }, 'REQUEST_MEMO_AUDIT_SUMMARY_FAILED');
  }
}


function formDashboardSheet_(ss, sheetName) {
  return formEnsureSheet_(ss, sheetName, FORM_REQUIRED_HEADERS[sheetName]);
}

function formDashboardCount_(ss, sheetName) {
  const sheet = formDashboardSheet_(ss, sheetName);
  return Math.max(0, sheet.getLastRow() - 1);
}

function formDashboardRecentRequests_(ss, limit) {
  const sheet = formDashboardSheet_(ss, FORM_SHEETS.MASTER);
  if (sheet.getLastRow() < 2) return [];
  const values = sheet.getDataRange().getValues();
  const headers = values[0].map(String);
  const rows = [];
  const max = Math.min(Math.max(Number(limit) || 10, 1), 50);
  for (let i = values.length - 1; i >= 1 && rows.length < max; i--) {
    const obj = {};
    headers.forEach((h, idx) => obj[h] = values[i][idx]);
    rows.push(formApplyMask_(obj));
  }
  return rows;
}


function formDashboardFieldCounts_(ss) {
  const sheet = formDashboardSheet_(ss, FORM_SHEETS.MASTER);
  const out = { status: {}, assignee: {}, workType: {}, total: Math.max(0, sheet.getLastRow() - 1) };
  if (sheet.getLastRow() < 2) return out;
  const values = sheet.getDataRange().getValues();
  const map = formHeaderMap_(values[0].map(String));
  for (let i = 1; i < values.length; i++) {
    const row = values[i];
    const status = String(map.status == null ? '' : row[map.status] || 'UNKNOWN');
    const assignee = String(map.assignedTo == null ? '' : row[map.assignedTo] || 'UNASSIGNED');
    const workType = String(map.workType == null ? '' : row[map.workType] || 'UNKNOWN');
    out.status[status] = (out.status[status] || 0) + 1;
    out.assignee[assignee] = (out.assignee[assignee] || 0) + 1;
    out.workType[workType] = (out.workType[workType] || 0) + 1;
  }
  return out;
}

function formBuildDashboardData_() {
  const ss = formGetMasterSpreadsheet_();
  Object.keys(FORM_REQUIRED_HEADERS).forEach(name => formDashboardSheet_(ss, name));
  const rawCount = formDashboardCount_(ss, FORM_SHEETS.RAW);
  const masterCount = formDashboardCount_(ss, FORM_SHEETS.MASTER);
  const customerBufferCount = formDashboardCount_(ss, FORM_SHEETS.CUSTOMER_BUFFER);
  const documentBufferCount = formDashboardCount_(ss, FORM_SHEETS.DOCUMENT_BUFFER);
  const retryCount = formDashboardCount_(ss, FORM_SHEETS.RETRY);
  const approvalCount = formDashboardCount_(ss, FORM_SHEETS.APPROVAL);
  const recent = formDashboardRecentRequests_(ss, 10);
  const fieldCounts = formDashboardFieldCounts_(ss);
  const cards = [
    { key: 'RAW', id: 'raw', label: 'RAW', value: rawCount, count: rawCount },
    { key: 'MASTER', id: 'master', label: 'MASTER', value: masterCount, count: masterCount },
    { key: 'CUSTOMER_BUFFER', id: 'customerBuffer', label: '고객버퍼', value: customerBufferCount, count: customerBufferCount },
    { key: 'DOCUMENT_BUFFER', id: 'documentBuffer', label: '문서버퍼', value: documentBufferCount, count: documentBufferCount },
    { key: 'RETRY', id: 'retry', label: '재처리', value: retryCount, count: retryCount }
  ];
  const cardMap = {
    raw: rawCount,
    master: masterCount,
    customerBuffer: customerBufferCount,
    documentBuffer: documentBufferCount,
    retry: retryCount,
    RAW: rawCount,
    MASTER: masterCount,
    CUSTOMER_BUFFER: customerBufferCount,
    DOCUMENT_BUFFER: documentBufferCount,
    RETRY: retryCount
  };
  return {
    build: FORM_BUILD,
    compactDashboard: true,
    helperBasedDashboard: true,
    dashboardCardFix: true,
    rawCount: rawCount,
    masterCount: masterCount,
    retryCount: retryCount,
    approvalCount: approvalCount,
    customerBufferCount: customerBufferCount,
    documentBufferCount: documentBufferCount,
    raw: rawCount,
    master: masterCount,
    customerBuffer: customerBufferCount,
    documentBuffer: documentBufferCount,
    retry: retryCount,
    RAW: rawCount,
    MASTER: masterCount,
    CUSTOMER_BUFFER: customerBufferCount,
    DOCUMENT_BUFFER: documentBufferCount,
    RETRY: retryCount,
    cards: cards,
    dashboardCards: cards,
    statCards: cards,
    cardMap: cardMap,
    counts: cardMap,
    stats: cardMap,
    approvalSummary: { total: approvalCount, compact: true, readOnly: true },
    retrySummary: { total: retryCount, compact: true, dryRunOnly: FORM_SAFE_MODE.ERP_WRITE_ALLOWED !== true },
    requestListSummary: { count: recent.length, sample: recent, compact: true, readOnly: true },
    fieldPanelSummary: { statusCounts: fieldCounts.status, assigneeCounts: fieldCounts.assignee, workTypeCounts: fieldCounts.workType, total: fieldCounts.total, readOnly: true },
    recentRequestListFiltered: recent,
    sampleRequestId: recent.length ? String(recent[0].requestId || '') : '',
    operationalSummary: { dashboardCardFix: true, dashboardReadOnly: true, actualRetryExecutionBlocked: FORM_SAFE_MODE.ERP_WRITE_ALLOWED !== true },
    safeMode: FORM_SAFE_MODE,
    webApp: { doGet: true, doPost: true, fallbackScreen: true, payloadNormalize: true, jsOnlyBuild: true },
    menu: ['QR 고객등록','외부접수','A/S 접수','재처리','요청 목록','현장 메모']
  };
}

function formGetDashboard() {
  formExecutionLog_('START', 'formGetDashboard', {});
  try {
    const data = formBuildDashboardData_();
    const response = formResponse_(true, 'FORM B44 SAFE MODE 상단 카드 표시 보정 대시보드 요약', data);
    Object.keys(data.cardMap || {}).forEach(k => response[k] = data.cardMap[k]);
    response.rawCount = data.rawCount;
    response.masterCount = data.masterCount;
    response.customerBufferCount = data.customerBufferCount;
    response.documentBufferCount = data.documentBufferCount;
    response.retryCount = data.retryCount;
    response.cards = data.cards;
    response.dashboardCards = data.dashboardCards;
    response.counts = data.counts;
    response.stats = data.stats;
    return formExecutionReturn_('formGetDashboard', response);
  } catch (err) {
    return formExecutionError_('formGetDashboard', err, null, 'DASHBOARD_FAILED');
  }
}

function formFieldPanelFilters_(options) {
  const opt = options || {};
  const source = opt.filters || opt;
  const allowed = ['status','statuses','workType','workTypes','assignedTo','eventId','vendorId','customerId','requestId','keyword','q'];
  const out = {};
  allowed.forEach(k => {
    if (source[k] !== undefined && source[k] !== null && String(source[k]).trim() !== '') out[k] = source[k];
  });
  return out;
}

function formGetFieldPanel(options) {
  formExecutionLog_('START', 'formGetFieldPanel', {});
  try {
    const opt = options || {};
    const data = formBuildDashboardData_();
    const max = Math.min(Math.max(Number(opt.limit) || 10, 1), 30);
    const filters = formFieldPanelFilters_(opt);
    const hasFilters = Object.keys(filters).length > 0;
    const listResult = hasFilters ? formListRequestsFiltered(filters, max) : null;
    const recent = hasFilters && listResult && listResult.ok && Array.isArray(listResult.data)
      ? listResult.data
      : (data.recentRequestListFiltered || []).slice(0, max);
    return formExecutionReturn_('formGetFieldPanel', formResponse_(true, 'FORM B44 SAFE MODE 현장 패널 필터 요약', {
      build: FORM_BUILD,
      counts: { raw: data.rawCount, master: data.masterCount, retry: data.retryCount, approval: data.approvalCount },
      statusCounts: data.fieldPanelSummary ? data.fieldPanelSummary.statusCounts : {},
      assigneeCounts: data.fieldPanelSummary ? data.fieldPanelSummary.assigneeCounts : {},
      workTypeCounts: data.fieldPanelSummary ? data.fieldPanelSummary.workTypeCounts : {},
      recentRequests: recent,
      activeFilters: filters,
      filtered: hasFilters,
      quickActions: ['요청 목록', '필터 조회', '요청 상세', '타임라인', '메모 추가', '증빙 확인'],
      safeMode: FORM_SAFE_MODE,
      readOnlySummary: true,
      dryRunOnly: true
    }));
  } catch (err) {
    return formExecutionError_('formGetFieldPanel', err, { options: options || {} }, 'FIELD_PANEL_FAILED');
  }
}

function formGetFieldPanelFiltered(filters, limit) {
  formExecutionLog_('START', 'formGetFieldPanelFiltered', {});
  try {
    const max = Math.min(Math.max(Number(limit) || 10, 1), 30);
    const activeFilters = formFieldPanelFilters_(filters || {});
    const listResult = formListRequestsFiltered(activeFilters, max);
    const rows = listResult && listResult.ok && Array.isArray(listResult.data) ? listResult.data : [];
    return formExecutionReturn_('formGetFieldPanelFiltered', formResponse_(true, 'FORM B44 SAFE MODE 현장 패널 직접 필터 조회', {
      build: FORM_BUILD,
      recentRequests: rows,
      activeFilters: activeFilters,
      filtered: Object.keys(activeFilters).length > 0,
      total: rows.length,
      directFilter: true,
      noFieldPanelNestedCall: true,
      safeMode: FORM_SAFE_MODE,
      readOnlySummary: true,
      dryRunOnly: true
    }));
  } catch (err) {
    return formExecutionError_('formGetFieldPanelFiltered', err, { filters: filters || {}, limit: limit || '' }, 'FIELD_PANEL_FILTER_FAILED');
  }
}

function formSubmitFromUi(payload) {
  formExecutionLog_('START', 'formSubmitFromUi', null);
  try {
    const normalized = formNormalizeUiPayload_(payload || {});
    const type = String(normalized.workType || '').toUpperCase();
    let result;
    if (type === FORM_WORK_TYPES.QR_CUSTOMER || type === 'QR_CUSTOMER') result = formCreateQRIntake(normalized);
    else if (type === FORM_WORK_TYPES.AS) result = formReceiveAsRequest(normalized);
    else if (type === FORM_WORK_TYPES.CLAIM_REFUND) result = formReceiveClaimRefund(normalized);
    else if (type === FORM_WORK_TYPES.DEMAND_SURVEY) result = formSubmitDemandSurvey(normalized);
    else if (type === FORM_WORK_TYPES.CAFE_FORM) result = formReceiveCafeForm(normalized);
    else result = formReceiveExternal(normalized);
    return formExecutionReturn_('formSubmitFromUi', formWrapUiSubmitResult_(result));
  } catch (err) {
    return formExecutionError_('formSubmitFromUi', err, { payload: payload || {} }, 'FORM_UI_SUBMIT_FAILED');
  }
}


function formDemandClientSafe_(value) {
  if (value === null || value === undefined) return '';
  if (value instanceof Date) return value.toISOString();
  if (Array.isArray(value)) return value.map(function(v) { return formDemandClientSafe_(v); });
  if (typeof value === 'object') {
    const out = {};
    Object.keys(value).forEach(function(k) { if (typeof value[k] !== 'function') out[k] = formDemandClientSafe_(value[k]); });
    return out;
  }
  return value;
}

function formDemandBaseUrl_() {
  try { return ScriptApp.getService().getUrl() || ''; } catch (err) { return ''; }
}

function formDemandNormalizeItems_(items, customItems) {
  let list = [];
  if (Array.isArray(items)) list = items.slice();
  else if (items) list = String(items).split(',');
  if (customItems) {
    const extra = Array.isArray(customItems) ? customItems : String(customItems).split(',');
    list = list.concat(extra);
  }
  return list.map(function(x) { return String(x || '').trim(); }).filter(Boolean).filter(function(v, idx, arr) { return arr.indexOf(v) === idx; });
}

function formDemandSelectedItemsText_(items) {
  return formDemandNormalizeItems_(items).join(', ');
}

function formDemandSurveyPropertyKey_(surveyId) {
  return 'FEELHAUS_DEMAND_SURVEY_CONFIG_' + String(surveyId || '').trim();
}

function formDemandGenerateSurveyId_() {
  const stamp = Utilities.formatDate(new Date(), 'Asia/Seoul', 'yyyyMMddHHmmss');
  const suffix = Utilities.getUuid().replace(/-/g, '').slice(0, 6).toUpperCase();
  return 'DSV_' + stamp + '_' + suffix;
}

function formDemandDefaultItems_() {
  return formDemandNormalizeItems_(FORM_DEMAND_DEFAULT_ITEMS);
}

function formDemandConfigSheet_() {
  const ss = formGetMasterSpreadsheet_();
  return formEnsureSheet_(ss, FORM_SHEETS.DEMAND_CONFIG, FORM_REQUIRED_HEADERS.FORM_DEMAND_FORM_CONFIG);
}

function formDemandBuildConfig_(input, existing) {
  const ctx = Object.assign({}, existing || {}, input || {});
  const baseItems = formDemandDefaultItems_();
  const selected = formDemandNormalizeItems_(ctx.selectedItems || ctx.enabledItems || ctx.items || baseItems, ctx.customItems || '');
  const customItems = formDemandNormalizeItems_(ctx.customItems || selected.filter(function(x) { return baseItems.indexOf(x) === -1; }));
  const disabledItems = baseItems.filter(function(x) { return selected.indexOf(x) === -1; });
  const finalItems = selected.filter(function(x) { return disabledItems.indexOf(x) === -1; });
  const now = new Date().toISOString();
  const surveyId = String(ctx.surveyId || (existing && existing.surveyId) || formDemandGenerateSurveyId_()).trim();
  const baseItemsText = formDemandSelectedItemsText_(baseItems);
  const selectedItemsText = formDemandSelectedItemsText_(finalItems);
  return {
    surveyId: surveyId,
    eventId: String(ctx.eventId || '').trim(),
    apartmentName: String(ctx.apartmentName || '선택 아파트').trim(),
    apartmentKey: String(ctx.apartmentKey || '').trim(),
    eventName: String(ctx.eventName || '').trim(),
    eventPlace: String(ctx.eventPlace || '').trim(),
    startDate: formDemandPlainValue_(ctx.startDate || ''),
    endDate: formDemandPlainValue_(ctx.endDate || ''),
    vendorId: String(ctx.vendorId || '').trim(),
    itemPresetCode: String(ctx.itemPresetCode || 'DEFAULT_MOVEIN_FAIR').trim(),
    baseItems: baseItemsText,
    enabledItems: selectedItemsText,
    disabledItems: formDemandSelectedItemsText_(disabledItems),
    customItems: formDemandSelectedItemsText_(customItems),
    selectedItems: selectedItemsText,
    items: finalItems,
    itemsText: selectedItemsText,
    selectedItemsText: selectedItemsText,
    noticeText: String(ctx.noticeText || '입주박람회 전 관심 품목을 미리 선택해 주시면 행사 당일 상담과 혜택 안내를 더 빠르게 도와드립니다.').trim(),
    warningText: String(ctx.warningText || '입력하신 동/호수 정보가 부정확한 경우,\n입주박람회 사전 혜택 및 상담 안내를 받지 못할 수 있으니 정확한 정보를 입력해 주세요.').trim(),
    privacyConsentText: String(ctx.privacyConsentText || '동/호수 정보와 선택한 관심 품목을 입주박람회 사전 수요조사 및 상담 준비 목적으로 수집·이용하는 데 동의합니다.').trim(),
    marketingConsentText: String(ctx.marketingConsentText || '입주박람회 혜택 안내, 상품 상담, 견적 안내 및 관련 영업활동에 활용하는 데 동의합니다.').trim(),
    shareTitle: String(ctx.shareTitle || ((ctx.apartmentName || '선택 아파트') + ' 입주박람회 사전 수요조사')).trim(),
    shareMessage: String(ctx.shareMessage || '').trim(),
    shortLink: String(ctx.shortLink || '').trim(),
    qrUrl: String(ctx.qrUrl || '').trim(),
    configStatus: String(ctx.configStatus || 'ACTIVE').trim(),
    configVersion: String(ctx.configVersion || 'B44-18').trim(),
    createdAt: String((existing && existing.createdAt) || ctx.createdAt || now),
    createdBy: String((existing && existing.createdBy) || ctx.createdBy || formUser_()),
    updatedAt: now,
    updatedBy: String(ctx.updatedBy || formUser_())
  };
}

function formDemandConfigFromRow_(row, map) {
  const obj = formRowObject_(row, map);
  obj.items = formDemandNormalizeItems_(obj.selectedItems || obj.enabledItems || obj.itemsText || FORM_DEMAND_DEFAULT_ITEMS, obj.customItems || '');
  obj.itemsText = formDemandSelectedItemsText_(obj.items);
  obj.selectedItemsText = obj.itemsText;
  return obj;
}

function formFindDemandConfigRowBy_(key, value) {
  const sheet = formDemandConfigSheet_();
  if (!sheet || sheet.getLastRow() < 2) return null;
  const values = sheet.getDataRange().getValues();
  const map = formHeaderMap_(values[0].map(String));
  const col = map[key];
  if (col == null) return null;
  for (let i = values.length - 1; i >= 1; i--) {
    if (String(values[i][col] || '').trim() === String(value || '').trim()) return { rowIndex: i + 1, row: values[i], map: map };
  }
  return null;
}

function formSaveDemandSurveyConfig_(config) {
  const eventId = String(config && config.eventId || '').trim();
  const surveyId = String(config && config.surveyId || '').trim();
  const existingBySurvey = surveyId ? formLoadDemandSurveyConfig_(surveyId) : null;
  const existingByEvent = !existingBySurvey && eventId ? formLoadDemandSurveyConfigByEvent_(eventId) : null;
  const existing = existingBySurvey || existingByEvent || null;
  const cfg = formDemandBuildConfig_(config, existing);
  const link = formBuildDemandSurveyLink_(cfg);
  cfg.shortLink = link;
  cfg.qrUrl = link ? 'https://quickchart.io/qr?size=260&text=' + encodeURIComponent(link) : '';
  const sheet = formDemandConfigSheet_();
  const rowMatch = formFindDemandConfigRowBy_('surveyId', cfg.surveyId) || (cfg.eventId ? formFindDemandConfigRowBy_('eventId', cfg.eventId) : null);
  const record = {
    surveyId: cfg.surveyId,
    eventId: cfg.eventId,
    apartmentName: cfg.apartmentName,
    apartmentKey: cfg.apartmentKey,
    eventName: cfg.eventName,
    eventPlace: cfg.eventPlace,
    startDate: cfg.startDate,
    endDate: cfg.endDate,
    vendorId: cfg.vendorId,
    itemPresetCode: cfg.itemPresetCode,
    baseItems: cfg.baseItems,
    enabledItems: cfg.enabledItems,
    disabledItems: cfg.disabledItems,
    customItems: cfg.customItems,
    selectedItems: cfg.selectedItems,
    noticeText: cfg.noticeText,
    warningText: cfg.warningText,
    privacyConsentText: cfg.privacyConsentText,
    marketingConsentText: cfg.marketingConsentText,
    shareTitle: cfg.shareTitle,
    shareMessage: cfg.shareMessage,
    shortLink: cfg.shortLink,
    qrUrl: cfg.qrUrl,
    configStatus: cfg.configStatus,
    configVersion: cfg.configVersion,
    createdAt: cfg.createdAt,
    createdBy: cfg.createdBy,
    updatedAt: cfg.updatedAt,
    updatedBy: cfg.updatedBy
  };
  if (rowMatch) formUpdateRowByHeader_(sheet, rowMatch.rowIndex, record);
  else formAppendByHeader_(sheet, record);
  PropertiesService.getScriptProperties().setProperty(formDemandSurveyPropertyKey_(cfg.surveyId), JSON.stringify(cfg));
  return cfg;
}

function formLoadDemandSurveyConfig_(surveyId) {
  const id = String(surveyId || '').trim();
  if (!id) return null;
  try {
    const raw = PropertiesService.getScriptProperties().getProperty(formDemandSurveyPropertyKey_(id));
    if (raw) {
      const cfg = formDemandBuildConfig_(JSON.parse(raw), null);
      cfg.surveyId = id;
      return cfg;
    }
  } catch (err) {}
  try {
    const found = formFindDemandConfigRowBy_('surveyId', id);
    return found ? formDemandBuildConfig_(formDemandConfigFromRow_(found.row, found.map), null) : null;
  } catch (err2) { return null; }
}

function formLoadDemandSurveyConfigByEvent_(eventId) {
  const id = String(eventId || '').trim();
  if (!id) return null;
  try {
    const found = formFindDemandConfigRowBy_('eventId', id);
    return found ? formDemandBuildConfig_(formDemandConfigFromRow_(found.row, found.map), null) : null;
  } catch (err) { return null; }
}

function formBuildDemandSurveyLink_(context) {
  const ctx = context || {};
  const base = formDemandBaseUrl_();
  const surveyId = String(ctx.surveyId || '').trim();
  const query = surveyId ? 'd=' + encodeURIComponent(surveyId) : 'mode=demand';
  return base + (query ? '?' + query : '');
}

function formGetDemandFormConfig(context) {
  formExecutionLog_('START', 'formGetDemandFormConfig', null);
  try {
    const ctx = context || {};
    const cfg = String(ctx.surveyId || '').trim() ? formLoadDemandSurveyConfig_(ctx.surveyId) : formLoadDemandSurveyConfigByEvent_(ctx.eventId);
    const fresh = cfg || formDemandBuildConfig_(ctx, null);
    const link = fresh.shortLink || formBuildDemandSurveyLink_(fresh);
    const data = Object.assign({}, fresh, {
      items: formDemandNormalizeItems_(fresh.items || fresh.selectedItems || fresh.enabledItems || FORM_DEMAND_DEFAULT_ITEMS),
      defaultItems: formDemandDefaultItems_(),
      surveyLink: link,
      qrImageUrl: fresh.qrUrl || (link ? 'https://quickchart.io/qr?size=260&text=' + encodeURIComponent(link) : ''),
      exists: !!cfg,
      clientSafe: true,
      readOnly: true,
      build: FORM_BUILD
    });
    return formExecutionReturn_('formGetDemandFormConfig', formResponse_(true, cfg ? '아파트별 수요조사 세팅을 불러왔습니다.' : '저장된 세팅이 없어 기본 품목을 표시합니다.', formDemandClientSafe_(data), '', { clientSafe: true }));
  } catch (err) {
    return formExecutionError_('formGetDemandFormConfig', err, { context: context || {} }, 'DEMAND_CONFIG_LOAD_FAILED');
  }
}

function formSaveDemandFormConfig(context) {
  formExecutionLog_('START', 'formSaveDemandFormConfig', null);
  try {
    const ctx = context || {};
    if (!String(ctx.eventId || '').trim()) return formExecutionReturn_('formSaveDemandFormConfig', formResponse_(false, '아파트 eventId가 필요합니다.', null, 'EVENT_ID_REQUIRED'));
    const cfg = formSaveDemandSurveyConfig_(ctx);
    const link = cfg.shortLink || formBuildDemandSurveyLink_(cfg);
    const data = Object.assign({}, cfg, {
      items: formDemandNormalizeItems_(cfg.items || cfg.selectedItems || cfg.enabledItems || FORM_DEMAND_DEFAULT_ITEMS),
      defaultItems: formDemandDefaultItems_(),
      surveyLink: link,
      qrImageUrl: cfg.qrUrl || (link ? 'https://quickchart.io/qr?size=260&text=' + encodeURIComponent(link) : ''),
      savedAt: cfg.updatedAt || formNow_(),
      clientSafe: true,
      build: FORM_BUILD
    });
    return formExecutionReturn_('formSaveDemandFormConfig', formResponse_(true, '수요조사 세팅이 저장되었습니다.', formDemandClientSafe_(data), '', { clientSafe: true, demandConfigSaved: true }));
  } catch (err) {
    return formExecutionError_('formSaveDemandFormConfig', err, { context: context || {} }, 'DEMAND_CONFIG_SAVE_FAILED');
  }
}

function formGetDemandFormCenterPayload(context) {
  formExecutionLog_('START', 'formGetDemandFormCenterPayload', null);
  try {
    const ctx = context || {};
    const apartmentName = ctx.apartmentName || '선택 아파트';
    const config = formSaveDemandSurveyConfig_(Object.assign({}, ctx, { apartmentName: apartmentName }));
    const link = formBuildDemandSurveyLink_(config);
    const shareTitle = config.shareTitle || (apartmentName + ' 입주박람회 사전 수요조사');
    const shareText = [
      '[' + shareTitle + ']',
      '',
      '입주박람회 전 관심 품목을 미리 선택해 주세요.',
      '행사 당일 상담과 혜택 안내를 더 빠르게 도와드립니다.',
      '',
      '수요조사 참여 링크:',
      link
    ].join('\n');
    const data = {
      build: FORM_BUILD,
      surveyId: config.surveyId,
      apartmentName: apartmentName,
      eventId: config.eventId || ctx.eventId || '',
      vendorId: config.vendorId || ctx.vendorId || '',
      items: formDemandNormalizeItems_(config.items || config.selectedItems || FORM_DEMAND_DEFAULT_ITEMS),
      defaultItems: formDemandDefaultItems_(),
      enabledItems: config.enabledItems,
      disabledItems: config.disabledItems,
      customItems: config.customItems,
      interestLevels: FORM_DEMAND_INTEREST_LEVELS,
      surveyLink: link,
      shortLink: link,
      shortLinkMode: true,
      qrImageUrl: link ? 'https://quickchart.io/qr?size=260&text=' + encodeURIComponent(link) : '',
      shareTitle: config.shareTitle || (apartmentName + ' 입주박람회 사전 수요조사'),
      qrTitle: config.shareTitle || (apartmentName + ' 입주박람회 사전 수요조사'),
      kakaoShareText: shareText,
      naverCafeShareText: shareText,
      warningText: config.warningText,
      privacyText: config.privacyConsentText,
      marketingText: config.marketingConsentText,
      configStatus: config.configStatus,
      readOnly: true,
      clientSafe: true,
      dryRunOnly: true
    };
    return formExecutionReturn_('formGetDemandFormCenterPayload', formResponse_(true, '수요조사 링크/QR 생성 및 아파트별 세팅 저장 완료', formDemandClientSafe_(data), '', { clientSafe: true }));
  } catch (err) {
    return formExecutionError_('formGetDemandFormCenterPayload', err, { context: context || {} }, 'DEMAND_FORM_CENTER_FAILED');
  }
}



function formDemandNormalizeDongHosuPart_(value) {
  const text = String(value == null ? '' : value).trim();
  if (!text) return '';
  const digits = text.replace(/[^0-9]/g, '');
  return digits || text;
}

function formNormalizeDemandReportSheet_(sheet) {
  if (!sheet) return null;
  const headers = FORM_REQUIRED_HEADERS.FORM_DEMAND_SURVEY_REPORT;
  const lastRow = sheet.getLastRow();
  const lastCol = sheet.getLastColumn();
  if (!lastCol) {
    sheet.getRange(1, 1, 1, headers.length).setValues([headers]);
    sheet.setFrozenRows(1);
    return sheet;
  }
  const values = sheet.getDataRange().getValues();
  const current = values.length ? values[0].map(String) : [];
  const same = current.length === headers.length && headers.every(function(h, i) { return current[i] === h; });
  if (same) return sheet;
  const map = formHeaderMap_(current);
  const rows = [headers];
  for (let r = 1; r < values.length; r++) {
    const row = values[r];
    const dong = formDemandNormalizeDongHosuPart_((map.dong == null ? '' : row[map.dong]) || '');
    const hosu = formDemandNormalizeDongHosuPart_((map.hosu == null ? '' : row[map.hosu]) || '');
    const dongHosu = (map.dongHosu == null ? '' : row[map.dongHosu]) || ((dong || '') + (dong ? '동 ' : '') + (hosu || '') + (hosu ? '호' : ''));
    const duplicateValue = (map.duplicate == null ? (map.duplicateCandidate == null ? '' : row[map.duplicateCandidate]) : row[map.duplicate]);
    const requestMemo = (map.requestMemo == null ? '' : row[map.requestMemo]) || (map.memo == null ? '' : row[map.memo]);
    const record = {
      requestId: map.requestId == null ? '' : row[map.requestId],
      eventId: map.eventId == null ? '' : row[map.eventId],
      apartmentName: map.apartmentName == null ? '' : row[map.apartmentName],
      dong: dong,
      hosu: hosu,
      dongHosu: dongHosu,
      selectedItems: map.selectedItems == null ? '' : row[map.selectedItems],
      interestLevel: map.interestLevel == null ? '' : row[map.interestLevel],
      requestMemo: requestMemo,
      duplicate: (duplicateValue === true || String(duplicateValue).toUpperCase() === 'Y' || String(duplicateValue).toLowerCase() === 'true') ? 'Y' : 'N',
      duplicateRequestId: map.duplicateRequestId == null ? '' : row[map.duplicateRequestId],
      surveyStatus: map.surveyStatus == null ? '' : row[map.surveyStatus],
      createdAt: map.createdAt == null ? '' : row[map.createdAt],
      updatedAt: map.updatedAt == null ? '' : row[map.updatedAt],
      build: map.build == null ? FORM_BUILD : row[map.build]
    };
    record.reportSummary = formDemandBuildReportLine_(record);
    rows.push(headers.map(function(h) { return record[h] !== undefined ? record[h] : ''; }));
  }
  sheet.clearContents();
  sheet.getRange(1, 1, rows.length, headers.length).setValues(rows);
  if (lastCol > headers.length) sheet.deleteColumns(headers.length + 1, lastCol - headers.length);
  sheet.setFrozenRows(1);
  return sheet;
}

function formFindDemandDuplicateCandidate_(payload) {
  const ss = formGetMasterSpreadsheet_();
  const sheet = ss.getSheetByName(FORM_SHEETS.RAW);
  const wantedEventId = String(payload.eventId || '').trim();
  const wantedDong = formDemandNormalizeDongHosuPart_(payload.dong || '');
  const wantedHosu = formDemandNormalizeDongHosuPart_(payload.hosu || payload.ho || '');
  if (!sheet || sheet.getLastRow() < 2 || !wantedEventId || !wantedDong || !wantedHosu) return { duplicateCandidate: false, requestId: '', reason: '' };
  const values = sheet.getDataRange().getValues();
  const headers = values[0].map(String);
  const map = formHeaderMap_(headers);
  for (let i = values.length - 1; i >= 1; i--) {
    const row = values[i];
    const rawPayloadText = map.rawPayload == null ? '' : String(row[map.rawPayload] || '');
    const raw = formDemandParseRawPayload_(rawPayloadText);
    const eventId = String((map.eventId == null ? '' : row[map.eventId]) || raw.eventId || '').trim();
    const dong = formDemandNormalizeDongHosuPart_((map.dong == null ? '' : row[map.dong]) || raw.dong || '');
    const hosu = formDemandNormalizeDongHosuPart_((map.hosu == null ? '' : row[map.hosu]) || raw.hosu || raw.ho || '');
    const isDemand = !rawPayloadText || formDemandRecentIsDemand_(row, map, raw);
    if (isDemand && eventId === wantedEventId && dong === wantedDong && hosu === wantedHosu) {
      return { duplicateCandidate: true, requestId: map.requestId == null ? String(raw.requestId || '') : String(row[map.requestId] || raw.requestId || ''), reason: 'EVENT_DONG_HOSU' };
    }
  }
  return { duplicateCandidate: false, requestId: '', reason: '' };
}


function formDemandReportSheet_() {
  const ss = formGetMasterSpreadsheet_();
  const sheet = formEnsureSheet_(ss, FORM_SHEETS.DEMAND_REPORT, FORM_REQUIRED_HEADERS.FORM_DEMAND_SURVEY_REPORT);
  return formNormalizeDemandReportSheet_(sheet);
}

function formDemandBuildReportLine_(record) {
  const dongHosu = String(record.dongHosu || ((record.dong || '') + '동 ' + (record.hosu || '') + '호')).trim();
  const parts = [
    '동호수: ' + dongHosu,
    '품목: ' + (record.selectedItems || ''),
    '관심도: ' + (record.interestLevel || ''),
    '요청사항: ' + (record.requestMemo || record.memo || ''),
    '중복: ' + (String(record.duplicate || '').toUpperCase() === 'Y' || record.duplicateCandidate ? 'Y' : 'N'),
    '접수번호: ' + (record.requestId || '')
  ];
  return parts.join(' / ');
}

function formWriteDemandSurveyReport_(input, submitData) {
  const sheet = formDemandReportSheet_();
  const now = formNow_();
  const requestId = String((submitData && submitData.requestId) || input.requestId || '').trim();
  if (!requestId) throw new Error('수요조사 보고서 저장 실패: requestId 없음');
  const dong = formDemandNormalizeDongHosuPart_(input.dong || '');
  const hosu = formDemandNormalizeDongHosuPart_(input.hosu || input.ho || '');
  const record = {
    requestId: requestId,
    eventId: String(input.eventId || '').trim(),
    apartmentName: String(input.apartmentName || '').trim(),
    dong: dong,
    hosu: hosu,
    selectedItems: formDemandPlainValue_(input.selectedItems || ''),
    interestLevel: formDemandPlainValue_(input.interestLevel || ''),
    dongHosu: (dong || '') + (dong ? '동 ' : '') + (hosu || '') + (hosu ? '호' : ''),
    requestMemo: formDemandPlainValue_(input.requestMemo || input.memo || ''),
    duplicate: input.duplicateCandidate ? 'Y' : 'N',
    duplicateRequestId: formDemandPlainValue_(input.duplicateRequestId || ''),
    surveyStatus: formDemandPlainValue_(input.surveyStatus || ''),
    createdAt: now,
    updatedAt: now,
    build: FORM_BUILD
  };
  record.reportSummary = formDemandBuildReportLine_(record);
  const found = formFindRowById_(sheet, 'requestId', requestId);
  if (found && found.rowIndex) {
    formUpdateRowByHeader_(sheet, found.rowIndex, Object.assign({}, record, { updatedAt: now }));
  } else {
    formAppendByHeader_(sheet, record);
  }
  return {
    reportSaved: true,
    reportSheet: FORM_SHEETS.DEMAND_REPORT,
    reportId: requestId,
    reportSummary: record.reportSummary
  };
}

function formSubmitDemandSurvey(payload) {
  formExecutionLog_('START', 'formSubmitDemandSurvey', null);
  try {
    const input = Object.assign({}, payload || {});
    input.workType = FORM_WORK_TYPES.DEMAND_SURVEY;
    input.formType = FORM_WORK_TYPES.DEMAND_SURVEY;
    input.sourceType = input.sourceType || 'CAFE_FORM';
    input.intakeType = 'PRE_EVENT_DEMAND';
    input.customerName = '';
    input.phone = '';
    input.title = input.title || '입주박람회 사전 수요조사';
    input.surveyId = String(input.surveyId || '').trim();
    input.dong = formDemandNormalizeDongHosuPart_(input.dong || '');
    input.hosu = formDemandNormalizeDongHosuPart_(input.hosu || input.ho || '');
    input.selectedItems = formDemandNormalizeItems_(input.selectedItems || input.items, input.customItems || '').join(', ');
    input.content = ['품목: ' + input.selectedItems, '관심도: ' + (input.interestLevel || ''), '요청사항: ' + (input.memo || input.content || '')].join(' / ');
    input.privacyConsent = input.privacyConsent === true || String(input.privacyConsent || '').toUpperCase() === 'Y' || String(input.privacyConsent || '') === 'true';
    input.marketingConsent = input.marketingConsent === true || input.salesConsent === true || input.businessConsent === true || String(input.marketingConsent || input.salesConsent || input.businessConsent || '').toUpperCase() === 'Y' || String(input.marketingConsent || input.salesConsent || input.businessConsent || '') === 'true';
    if (!input.eventId) return formExecutionReturn_('formSubmitDemandSurvey', formResponse_(false, '행사 eventId가 필요합니다.', null, 'EVENT_ID_REQUIRED'));
    if (!input.dong || !(input.hosu || input.ho)) return formExecutionReturn_('formSubmitDemandSurvey', formResponse_(false, '동/호수를 입력하세요.', null, 'DONG_HOSU_REQUIRED'));
    if (!input.selectedItems) return formExecutionReturn_('formSubmitDemandSurvey', formResponse_(false, '관심 품목을 1개 이상 선택하세요.', null, 'DEMAND_ITEMS_REQUIRED'));
    if (!input.privacyConsent) return formExecutionReturn_('formSubmitDemandSurvey', formResponse_(false, '개인정보 수집·이용 동의가 필요합니다.', null, 'PRIVACY_CONSENT_REQUIRED'));
    if (!input.marketingConsent) return formExecutionReturn_('formSubmitDemandSurvey', formResponse_(false, '혜택 안내 및 영업활동 동의가 필요합니다.', null, 'MARKETING_CONSENT_REQUIRED'));
    const dup = formFindDemandDuplicateCandidate_(input);
    input.duplicateCandidate = dup.duplicateCandidate;
    input.duplicateReason = dup.reason || '';
    input.duplicateRequestId = dup.requestId || '';
    input.surveyStatus = dup.duplicateCandidate ? 'DUPLICATE_CANDIDATE' : 'SURVEY_RECEIVED';
    const result = formReceive_(input, FORM_WORK_TYPES.DEMAND_SURVEY);
    let reportInfo = { reportSaved: false, reportSheet: FORM_SHEETS.DEMAND_REPORT, reportId: '', reportSummary: '' };
    if (result && result.ok && result.data && result.data.requestId) {
      reportInfo = formWriteDemandSurveyReport_(input, result.data);
    }
    const data = Object.assign({}, result && result.data ? result.data : {}, {
      demandSurvey: true,
      requestId: result && result.data ? result.data.requestId : '',
      eventId: input.eventId,
      apartmentName: input.apartmentName || '',
      dong: input.dong || '',
      hosu: input.hosu || input.ho || '',
      selectedItems: input.selectedItems,
      interestLevel: input.interestLevel || '',
      duplicateCandidate: dup.duplicateCandidate,
      duplicateRequestId: dup.requestId || '',
      surveyStatus: input.surveyStatus,
      privacyConsent: input.privacyConsent,
      marketingConsent: input.marketingConsent,
      reportSaved: !!reportInfo.reportSaved,
      reportSheet: reportInfo.reportSheet || FORM_SHEETS.DEMAND_REPORT,
      reportId: reportInfo.reportId || '',
      reportSummary: reportInfo.reportSummary || '',
      dryRunOnly: true
    });
    return formExecutionReturn_('formSubmitDemandSurvey', formResponse_(result.ok, result.ok ? '수요조사가 접수되었습니다.' : result.message, data, result.errorCode || '', { build: FORM_BUILD, demandSurvey: true }));
  } catch (err) {
    return formExecutionError_('formSubmitDemandSurvey', err, { payload: payload || {} }, 'DEMAND_SURVEY_SUBMIT_FAILED');
  }
}

function formDemandLookupRequest(requestId, eventId) {
  formExecutionLog_('START', 'formDemandLookupRequest', null);
  try {
    const rid = String(requestId || '').trim();
    if (!rid) return formExecutionReturn_('formDemandLookupRequest', formResponse_(false, '접수번호가 필요합니다.', null, 'REQUEST_ID_REQUIRED'));
    const rowsResult = formListRequestsFiltered({ requestId: rid, eventId: eventId || '' }, 1);
    const row = rowsResult && rowsResult.ok && rowsResult.data && rowsResult.data.length ? rowsResult.data[0] : null;
    return formExecutionReturn_('formDemandLookupRequest', formResponse_(true, row ? '수요조사 접수 조회 완료' : '조회 결과가 없습니다.', { found: !!row, request: formDemandClientSafe_(row || {}), readOnly: true, clientSafe: true }));
  } catch (err) {
    return formExecutionError_('formDemandLookupRequest', err, { requestId: requestId || '', eventId: eventId || '' }, 'DEMAND_LOOKUP_FAILED');
  }
}



function formDemandPlainValue_(value) {
  if (value === null || value === undefined) return '';
  if (value instanceof Date) return value.toISOString();
  if (Array.isArray(value)) return value.map(function(v) { return formDemandPlainValue_(v); }).join(', ');
  if (typeof value === 'object') {
    try { return JSON.stringify(value); } catch (err) { return String(value); }
  }
  return String(value);
}

function formDemandParseRawPayload_(text) {
  try { return JSON.parse(String(text || '{}')); } catch (err) { return {}; }
}

function formDemandRecentPick_(row, map, key) {
  return map && map[key] != null ? row[map[key]] : '';
}

function formDemandRecentIsDemand_(row, map, raw) {
  const workType = String(formDemandRecentPick_(row, map, 'workType') || raw.workType || raw.formType || '').trim();
  const formType = String(formDemandRecentPick_(row, map, 'formType') || raw.formType || raw.workType || '').trim();
  const sourceType = String(formDemandRecentPick_(row, map, 'sourceType') || raw.sourceType || '').trim();
  const statusReason = String(formDemandRecentPick_(row, map, 'statusReason') || raw.statusReason || '');
  const content = String(formDemandRecentPick_(row, map, 'content') || raw.content || raw.memo || '');
  return workType === FORM_WORK_TYPES.DEMAND_SURVEY || formType === FORM_WORK_TYPES.DEMAND_SURVEY || sourceType === 'CAFE_FORM' || statusReason.indexOf('수요조사') !== -1 || content.indexOf('품목:') !== -1;
}

function formDemandRecentRow_(row, map, raw, eventIdFallback) {
  raw = raw || {};
  const statusReason = String(formDemandRecentPick_(row, map, 'statusReason') || raw.statusReason || '');
  const content = String(formDemandRecentPick_(row, map, 'content') || raw.content || '');
  let selectedItems = raw.selectedItems || raw.items || '';
  let interestLevel = raw.interestLevel || '';
  let memoText = raw.memo || raw.requestMemo || raw.memoText || raw.contentMemo || '';
  if (!selectedItems && content.indexOf('품목:') !== -1) selectedItems = content.replace(/^.*품목:\s*/,'').split('/')[0].trim();
  if (!interestLevel && content.indexOf('관심도:') !== -1) interestLevel = content.replace(/^.*관심도:\s*/,'').split('/')[0].trim();
  if (!memoText && content.indexOf('요청사항:') !== -1) memoText = content.replace(/^.*요청사항:\s*/,'').trim();
  return {
    requestId: formDemandPlainValue_(formDemandRecentPick_(row, map, 'requestId') || raw.requestId || ''),
    eventId: formDemandPlainValue_(formDemandRecentPick_(row, map, 'eventId') || raw.eventId || eventIdFallback || ''),
    sourceType: formDemandPlainValue_(formDemandRecentPick_(row, map, 'sourceType') || raw.sourceType || ''),
    apartmentName: formDemandPlainValue_(raw.apartmentName || formDemandRecentPick_(row, map, 'apartmentName') || ''),
    dong: formDemandPlainValue_(formDemandNormalizeDongHosuPart_(raw.dong || formDemandRecentPick_(row, map, 'dong') || '')),
    hosu: formDemandPlainValue_(formDemandNormalizeDongHosuPart_(raw.hosu || raw.ho || formDemandRecentPick_(row, map, 'hosu') || '')),
    selectedItems: formDemandPlainValue_(selectedItems),
    interestLevel: formDemandPlainValue_(interestLevel),
    memo: formDemandPlainValue_(memoText || ''),
    requestMemo: formDemandPlainValue_(memoText || ''),
    duplicateCandidate: raw.duplicateCandidate === true || String(raw.duplicateCandidate || '') === 'true' || statusReason.indexOf('중복') !== -1,
    surveyStatus: formDemandPlainValue_(raw.surveyStatus || (statusReason.indexOf('중복') !== -1 ? 'DUPLICATE_CANDIDATE' : 'SURVEY_RECEIVED')),
    privacyConsent: raw.privacyConsent === true || String(raw.privacyConsent || '') === 'true',
    marketingConsent: raw.marketingConsent === true || String(raw.marketingConsent || '') === 'true',
    createdAt: formDemandPlainValue_(formDemandRecentPick_(row, map, 'createdAt') || raw.createdAt || ''),
    updatedAt: formDemandPlainValue_(formDemandRecentPick_(row, map, 'updatedAt') || raw.updatedAt || ''),
    reportSheet: FORM_SHEETS.DEMAND_REPORT
  };
}


function formDemandRecentRowsForEvent_(eventIdFilter, limit) {
  const ss = formGetMasterSpreadsheet_();
  const max = Math.min(Math.max(Number(limit) || 200, 1), 1000);
  const filterEventId = String(eventIdFilter || '').trim();
  const rows = [];
  const seen = {};

  function pushRowsFromSheet_(sheetName) {
    const sheet = ss.getSheetByName(sheetName);
    if (!sheet || sheet.getLastRow() < 2) return;
    const values = sheet.getDataRange().getValues();
    const headers = values[0].map(String);
    const map = formHeaderMap_(headers);
    for (let i = values.length - 1; i >= 1 && rows.length < max; i--) {
      const row = values[i];
      const rawPayloadText = map.rawPayload == null ? '' : String(row[map.rawPayload] || '');
      const raw = formDemandParseRawPayload_(rawPayloadText);
      const eventId = String(formDemandRecentPick_(row, map, 'eventId') || raw.eventId || '').trim();
      if (filterEventId && eventId !== filterEventId) continue;
      if (!formDemandRecentIsDemand_(row, map, raw)) continue;
      const item = formDemandRecentRow_(row, map, raw, eventId);
      if (!item.requestId || seen[item.requestId]) continue;
      seen[item.requestId] = true;
      rows.push(item);
    }
  }

  // 관리자 화면과 PDF가 같은 데이터로 집계되도록 동일한 원천/순서를 사용한다.
  pushRowsFromSheet_(FORM_SHEETS.RAW);
  if (rows.length < max) pushRowsFromSheet_(FORM_SHEETS.MASTER);

  const duplicateKeys = {};
  rows.forEach(function(r) {
    const key = [r.eventId || filterEventId || '', r.dong || '', r.hosu || ''].join('|');
    if ((r.eventId || filterEventId) && (r.dong || r.hosu)) duplicateKeys[key] = (duplicateKeys[key] || 0) + 1;
  });
  rows.forEach(function(r) {
    const key = [r.eventId || filterEventId || '', r.dong || '', r.hosu || ''].join('|');
    const isDup = duplicateKeys[key] > 1 || r.duplicateCandidate === true || String(r.duplicate || '').toUpperCase() === 'Y';
    r.duplicateCandidate = !!isDup;
    r.duplicate = isDup ? 'Y' : 'N';
    if (isDup && (!r.surveyStatus || r.surveyStatus === 'SURVEY_RECEIVED')) r.surveyStatus = 'DUPLICATE_CANDIDATE';
    if (!r.dongHosu) r.dongHosu = (r.dong || '') + (r.dong ? '동 ' : '') + (r.hosu || '') + (r.hosu ? '호' : '');
  });
  return rows;
}

function formListDemandSurveyRecent(filters, limit) {
  formExecutionLog_('START', 'formListDemandSurveyRecent', null);
  try {
    const f = filters || {};
    const eventIdFilter = String(f.eventId || '').trim();
    const max = Math.min(Math.max(Number(limit) || 20, 1), 100);
    const rows = formDemandRecentRowsForEvent_(eventIdFilter, max);
    const data = {
      rows: rows.slice(0, max),
      total: rows.length,
      eventId: eventIdFilter,
      sourceSheet: FORM_SHEETS.RAW + '/' + FORM_SHEETS.MASTER,
      readOnly: true,
      clientSafe: true,
      build: FORM_BUILD
    };
    return formExecutionReturn_('formListDemandSurveyRecent', formResponse_(true, rows.length ? '최근 수요조사 제출 결과 조회 완료' : '조건에 맞는 수요조사 제출 결과가 없습니다.', data, '', { build: FORM_BUILD, clientSafe: true, recentDemand: true }));
  } catch (err) {
    return formExecutionError_('formListDemandSurveyRecent', err, { filters: filters || {}, limit: limit || '' }, 'DEMAND_RECENT_LIST_FAILED');
  }
}



function formDemandHtmlEscape_(value) {
  return String(value == null ? '' : value)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

function formDemandReportRowsForEvent_(eventId) {
  const ss = formGetMasterSpreadsheet_();
  const sheet = ss.getSheetByName(FORM_SHEETS.DEMAND_REPORT);
  if (!sheet || sheet.getLastRow() < 2) return [];
  const values = sheet.getDataRange().getValues();
  const headers = values[0].map(String);
  const map = formHeaderMap_(headers);
  const eventFilter = String(eventId || '').trim();
  const rows = [];
  for (let i = 1; i < values.length; i++) {
    const row = values[i];
    const eventValue = String(map.eventId == null ? '' : row[map.eventId] || '').trim();
    if (eventFilter && eventValue !== eventFilter) continue;
    rows.push({
      requestId: formDemandPlainValue_(map.requestId == null ? '' : row[map.requestId]),
      eventId: eventValue,
      apartmentName: formDemandPlainValue_(map.apartmentName == null ? '' : row[map.apartmentName]),
      dong: formDemandPlainValue_(map.dong == null ? '' : row[map.dong]),
      hosu: formDemandPlainValue_(map.hosu == null ? '' : row[map.hosu]),
      dongHosu: formDemandPlainValue_(map.dongHosu == null ? '' : row[map.dongHosu]),
      selectedItems: formDemandPlainValue_(map.selectedItems == null ? '' : row[map.selectedItems]),
      interestLevel: formDemandPlainValue_(map.interestLevel == null ? '' : row[map.interestLevel]),
      requestMemo: formDemandPlainValue_(map.requestMemo == null ? '' : row[map.requestMemo]),
      duplicate: formDemandPlainValue_(map.duplicate == null ? '' : row[map.duplicate]),
      surveyStatus: formDemandPlainValue_(map.surveyStatus == null ? '' : row[map.surveyStatus]),
      createdAt: formDemandPlainValue_(map.createdAt == null ? '' : row[map.createdAt]),
      reportSummary: formDemandPlainValue_(map.reportSummary == null ? '' : row[map.reportSummary])
    });
  }
  return rows;
}

function formDemandSplitItemsForReport_(text) {
  return String(text || '')
    .split(',')
    .map(function(v) { return String(v || '').trim(); })
    .filter(Boolean);
}

function formDemandReportStats_(rows, context) {
  const itemCounts = {};
  const interestCounts = {};
  const householdMap = {};
  const configuredItems = formDemandNormalizeItems_((context && (context.items || context.selectedItems || context.enabledItems)) || '', (context && context.customItems) || '');
  configuredItems.forEach(function(item) { if (item) itemCounts[item] = itemCounts[item] || 0; });
  let duplicateCount = 0;
  let totalItemSelections = 0;
  let positiveInterestCount = 0;
  let visitIntentCount = 0;
  let quoteIntentCount = 0;
  let undecidedCount = 0;
  rows.forEach(function(r) {
    const houseKey = [r.eventId || (context && context.eventId) || '', r.dong || '', r.hosu || ''].join('|');
    if (r.dong || r.hosu) householdMap[houseKey] = true;
    if (String(r.duplicate || '').toUpperCase() === 'Y') duplicateCount++;
    formDemandSplitItemsForReport_(r.selectedItems).forEach(function(item) {
      itemCounts[item] = (itemCounts[item] || 0) + 1;
      totalItemSelections++;
    });
    const interest = String(r.interestLevel || '미입력').trim() || '미입력';
    interestCounts[interest] = (interestCounts[interest] || 0) + 1;
    if (interest === '행사 당일 방문 예정') visitIntentCount++;
    if (interest === '견적이 궁금함') quoteIntentCount++;
    if (interest === '아직 미정') undecidedCount++;
    if (['관심 있음', '행사 당일 방문 예정', '견적이 궁금함'].indexOf(interest) >= 0) positiveInterestCount++;
  });
  const configuredOrder = {};
  configuredItems.forEach(function(item, idx) { configuredOrder[item] = idx + 1; });
  const itemList = Object.keys(itemCounts).map(function(k) { return { name: k, count: itemCounts[k] }; }).sort(function(a,b){
    if ((b.count || 0) !== (a.count || 0)) return (b.count || 0) - (a.count || 0);
    const ao = configuredOrder[a.name] || 9999;
    const bo = configuredOrder[b.name] || 9999;
    if (ao !== bo) return ao - bo;
    return a.name.localeCompare(b.name);
  });
  const interestList = Object.keys(interestCounts).map(function(k) { return { name: k, count: interestCounts[k] }; }).sort(function(a,b){ return b.count - a.count || a.name.localeCompare(b.name); });
  const responseCount = rows.length;
  const validResponseCount = Math.max(responseCount - duplicateCount, 0);
  return {
    responseCount: responseCount,
    householdCount: Object.keys(householdMap).length,
    duplicateCount: duplicateCount,
    validResponseCount: validResponseCount,
    itemList: itemList,
    interestList: interestList,
    topItem: itemList.length ? itemList[0].name : '',
    topItemCount: itemList.length ? itemList[0].count : 0,
    totalItemSelections: totalItemSelections,
    positiveInterestCount: positiveInterestCount,
    visitIntentCount: visitIntentCount,
    quoteIntentCount: quoteIntentCount,
    undecidedCount: undecidedCount
  };
}

function formDemandReportPercent_(num, den) {
  const n = Number(num) || 0;
  const d = Number(den) || 0;
  if (!d) return '0.0%';
  return ((n / d) * 100).toFixed(1) + '%';
}

function formDemandReportBarsHtml_(list, labelText, denominator) {
  const safeList = list || [];
  const max = Math.max.apply(null, safeList.map(function(x){ return Number(x.count) || 0; }).concat([1]));
  const den = Number(denominator) || max;
  if (!safeList.length) return '<div style="color:#7a8796;padding:10px;border:1px dashed #dbe4ee;border-radius:12px">집계 데이터가 없습니다.</div>';
  return '<table cellpadding="0" cellspacing="0" style="width:100%;border-collapse:separate;border-spacing:0 8px;table-layout:fixed;font-size:9px">' + safeList.map(function(item) {
    const count = Number(item.count) || 0;
    const pct = formDemandReportPercent_(count, den);
    const barSlots = 18;
    const fillCount = count > 0 ? Math.max(1, Math.round((count / max) * barSlots)) : 0;
    const restCount = Math.max(0, barSlots - fillCount);
    const blue = new Array(fillCount + 1).join('█');
    const gray = new Array(restCount + 1).join('█');
    const safeName = formDemandHtmlEscape_(item.name);
    const safeCount = formDemandHtmlEscape_(count);
    return '<tr>' +
      '<td style="width:72px;border:0;padding:4px 4px 4px 0;vertical-align:middle;font-weight:bold;color:#172033;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">' + safeName + '</td>' +
      '<td style="width:96px;border:0;padding:4px 1px 4px 2px;vertical-align:middle;white-space:nowrap;line-height:13px;font-size:9px;font-family:Arial,\'Noto Sans KR\',sans-serif;letter-spacing:-0.72px;overflow:hidden">' +
        '<span style="color:#0159e8;white-space:nowrap">' + blue + '</span><span style="color:#aab1b8;white-space:nowrap">' + gray + '</span>' +
      '</td>' +
      '<td style="width:72px;border:0;padding:4px 0 4px 2px;vertical-align:middle;text-align:left;font-size:8.4px;font-weight:bold;color:#172033;white-space:nowrap;overflow:hidden;letter-spacing:-0.25px">' + safeCount + (labelText || '건') + '/' + pct + '</td>' +
      '</tr>';
  }).join('') + '</table>';
}

function formBuildDemandSurveyPdfHtml_(context, rows, stats) {
  const apt = String((context && context.apartmentName) || (rows[0] && rows[0].apartmentName) || '입주박람회').trim();
  const now = Utilities.formatDate(new Date(), 'Asia/Seoul', 'yyyy.MM.dd HH:mm');
  const title = apt + ' 입주박람회 사전 수요조사 결과 보고서';
  const itemBars = formDemandReportBarsHtml_(stats.itemList, '건', stats.responseCount);
  const interestBars = formDemandReportBarsHtml_(stats.interestList, '건', stats.responseCount);
  const validRate = formDemandReportPercent_(stats.validResponseCount, stats.responseCount);
  const duplicateRate = formDemandReportPercent_(stats.duplicateCount, stats.responseCount);
  const topItemRate = formDemandReportPercent_(stats.topItemCount, stats.responseCount);
  const positiveRate = formDemandReportPercent_(stats.positiveInterestCount, stats.responseCount);
  const visitRate = formDemandReportPercent_(stats.visitIntentCount, stats.responseCount);
  const quoteRate = formDemandReportPercent_(stats.quoteIntentCount, stats.responseCount);
  const topRows = rows.slice(0, 60).map(function(r, idx) {
    return '<tr><td>' + (idx + 1) + '</td><td>' + formDemandHtmlEscape_(r.dongHosu || ((r.dong || '') + '동 ' + (r.hosu || '') + '호')) + '</td><td>' + formDemandHtmlEscape_(r.selectedItems || '') + '</td><td>' + formDemandHtmlEscape_(r.interestLevel || '') + '</td><td>' + formDemandHtmlEscape_(String(r.duplicate || '').toUpperCase() === 'Y' ? 'Y' : 'N') + '</td></tr>';
  }).join('');
  return '<!doctype html><html><head><meta charset="utf-8"><style>' +
    '@page{size:A4;margin:18mm}body{font-family:Arial,"Noto Sans KR",sans-serif;color:#172033;margin:0;background:#fff}h1{font-size:24px;margin:0 0 8px}h2{font-size:17px;margin:28px 0 12px}.muted{color:#667085}.cover{border-bottom:3px solid #0159e8;padding-bottom:18px;margin-bottom:20px}.brand{font-size:14px;font-weight:bold;color:#0159e8;margin-bottom:8px}.summary{display:table;width:100%;border-spacing:8px;table-layout:fixed}.card{display:table-cell;border:1px solid #dbe4ee;border-radius:14px;padding:12px;background:#f8fbff}.num{font-size:22px;font-weight:bold;color:#0159e8;margin-top:5px}.metric-name{font-size:11px;color:#667085}.metric-value{font-size:20px;font-weight:bold;color:#0159e8;margin-top:4px}.metric-desc{font-size:10px;color:#7a8796;margin-top:4px;line-height:1.4}.graph-wrap{width:100%;text-align:center}.graph-layout{width:91%;margin-left:auto;margin-right:auto;border-collapse:separate;border-spacing:10px 0;table-layout:fixed}.graph-panel{border:1px solid #dbe4ee;border-radius:14px;padding:14px 14px 14px 14px;vertical-align:top;background:#fff}.graph-title{font-size:14px;font-weight:bold;margin:0 0 10px;color:#172033;text-align:left}.bar-table{width:100%;border-collapse:separate;border-spacing:0 8px;font-size:11px;table-layout:fixed}.bar-table td{border:0;padding:4px 6px;vertical-align:middle}.bar-name{width:88px;font-weight:bold;color:#172033;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.bar-cell{width:92px;white-space:nowrap;font-size:13px;line-height:16px;letter-spacing:-1px;font-family:Arial,"Noto Sans KR",sans-serif}.pdf-bar-text{display:inline-block;white-space:nowrap}.bar-fill-text{color:#0159e8}.bar-rest-text{color:#edf3f8}.bar-num{width:72px;text-align:right;font-weight:bold;color:#172033;white-space:nowrap}.note{border:1px solid #dbe4ee;background:#f8fbff;border-radius:14px;padding:13px;line-height:1.6}table{width:100%;border-collapse:collapse;font-size:11px}th,td{border:1px solid #dbe4ee;padding:7px;text-align:left;vertical-align:top}th{background:#f1f5f9}.footer{font-size:10px;color:#7a8796;text-align:center;margin-top:26px}.empty{color:#7a8796;padding:10px;border:1px dashed #dbe4ee;border-radius:12px}' +
    '</style></head><body>' +
    '<div class="cover"><div class="brand">(주)필하우스</div><h1>' + formDemandHtmlEscape_(title) + '</h1><div class="muted">작성일: ' + formDemandHtmlEscape_(now) + ' / 기준 eventId: ' + formDemandHtmlEscape_(context.eventId || '') + '</div></div>' +
    '<h2>1. 전체 요약</h2><div class="summary"><div class="card">전체 응답<div class="num">' + stats.responseCount + '</div></div><div class="card">참여 세대<div class="num">' + stats.householdCount + '</div></div><div class="card">중복 응답<div class="num">' + stats.duplicateCount + '</div></div><div class="card">최고 수요 품목<div class="num" style="font-size:16px">' + formDemandHtmlEscape_(stats.topItem || '-') + '</div></div></div>' +
    '<h2>2. 보고 지표</h2><div class="summary"><div class="card"><div class="metric-name">유효 응답률</div><div class="metric-value">' + validRate + '</div><div class="metric-desc">중복 제외 응답 비율</div></div><div class="card"><div class="metric-name">중복률</div><div class="metric-value">' + duplicateRate + '</div><div class="metric-desc">전체 응답 대비 중복</div></div><div class="card"><div class="metric-name">최고 품목 비중</div><div class="metric-value">' + topItemRate + '</div><div class="metric-desc">전체 응답 대비 ' + formDemandHtmlEscape_(stats.topItem || '-') + '</div></div><div class="card"><div class="metric-name">호응 응답률</div><div class="metric-value">' + positiveRate + '</div><div class="metric-desc">관심/방문/견적 응답 비율</div></div></div>' +
    '<div class="summary"><div class="card"><div class="metric-name">방문 예정률</div><div class="metric-value">' + visitRate + '</div><div class="metric-desc">행사 당일 방문 예정</div></div><div class="card"><div class="metric-name">견적 문의율</div><div class="metric-value">' + quoteRate + '</div><div class="metric-desc">견적이 궁금함</div></div><div class="card"><div class="metric-name">수요조사 진척도</div><div class="metric-value">' + stats.householdCount + '세대</div><div class="metric-desc">현재 참여 세대 누적</div></div><div class="card"><div class="metric-name">품목 선택량</div><div class="metric-value">' + stats.totalItemSelections + '건</div><div class="metric-desc">복수 선택 포함</div></div></div>' +
    '<h2>3. 수요도/호응도 그래프</h2><div class="graph-wrap"><table class="graph-layout" align="center"><tr><td class="graph-panel"><div class="graph-title">품목별 수요도</div>' + itemBars + '</td><td class="graph-panel"><div class="graph-title">관심도/호응도</div>' + interestBars + '</td></tr></table></div>' +
    '<h2>4. 운영 참고 의견</h2><div class="note">총 ' + stats.householdCount + '세대가 사전 수요조사에 참여했습니다. 가장 높은 수요 품목은 <b>' + formDemandHtmlEscape_(stats.topItem || '-') + '</b>이며, 해당 품목 중심으로 행사 상담 동선과 상담 인력을 우선 배치하는 것을 권장합니다. 중복 응답은 ' + stats.duplicateCount + '건으로 별도 검토가 필요합니다.</div>' +
    '<h2>5. 응답 상세 요약</h2><table><thead><tr><th>No</th><th>동/호수</th><th>선택 품목</th><th>관심도</th><th>중복</th></tr></thead><tbody>' + (topRows || '<tr><td colspan="5">응답 데이터가 없습니다.</td></tr>') + '</tbody></table>' +
    '<div class="footer">© 2026 FEELHAUS. All rights reserved. / (주)필하우스</div>' +
    '</body></html>';
}


function formDemandPdfSafeName_(value) {
  return String(value || '').replace(/[\\/:*?"<>|]/g, '_').replace(/\s+/g, ' ').trim().slice(0, 80) || '미지정';
}

function formDemandFindOrCreateChildFolder_(parent, name) {
  const safeName = formDemandPdfSafeName_(name);
  const it = parent.getFolders();
  while (it.hasNext()) {
    const folder = it.next();
    if (folder.getName() === safeName) return folder;
  }
  return parent.createFolder(safeName);
}

function formDemandPdfStorageFolder_(context) {
  const rootName = 'FEELHAUS_FORM_DEMAND_PDF_REPORT';
  const rootIter = DriveApp.getFoldersByName(rootName);
  const root = rootIter.hasNext() ? rootIter.next() : DriveApp.createFolder(rootName);
  const ctx = context || {};
  const eventId = String(ctx.eventId || 'NO_EVENT').trim() || 'NO_EVENT';
  const apt = String(ctx.apartmentName || '선택아파트').trim() || '선택아파트';
  const childName = eventId + '_' + apt;
  return formDemandFindOrCreateChildFolder_(root, childName);
}

function formDemandPdfReportLogSheet_() {
  const ss = formGetMasterSpreadsheet_();
  return formEnsureSheet_(ss, FORM_SHEETS.DEMAND_PDF_REPORT, FORM_REQUIRED_HEADERS.FORM_DEMAND_PDF_REPORT);
}

function formWriteDemandPdfReportLog_(record) {
  const sheet = formDemandPdfReportLogSheet_();
  formAppendByHeader_(sheet, record);
}

function formGenerateDemandSurveyPdfReport(filters) {
  formExecutionLog_('START', 'formGenerateDemandSurveyPdfReport', null);
  try {
    const f = filters || {};
    const eventId = String(f.eventId || '').trim();
    if (!eventId) return formExecutionReturn_('formGenerateDemandSurveyPdfReport', formResponse_(false, '아파트 eventId가 필요합니다.', null, 'EVENT_ID_REQUIRED'));
    const rows = formDemandRecentRowsForEvent_(eventId, 500);
    if (!rows.length) return formExecutionReturn_('formGenerateDemandSurveyPdfReport', formResponse_(false, 'PDF로 만들 수요조사 데이터가 없습니다.', { rows: [] }, 'DEMAND_REPORT_EMPTY'));
    const savedConfig = formLoadDemandSurveyConfigByEvent_(eventId) || null;
    const context = Object.assign({}, savedConfig || {}, {
      eventId: eventId,
      apartmentName: String(f.apartmentName || (savedConfig && savedConfig.apartmentName) || (rows[0] && rows[0].apartmentName) || '').trim()
    });
    context.items = formDemandNormalizeItems_(context.items || context.selectedItems || context.enabledItems || '', context.customItems || '');
    const stats = formDemandReportStats_(rows, context);
    const html = formBuildDemandSurveyPdfHtml_(context, rows, stats);
    const reportId = formUuid_('RPT');
    const reportTitle = (context.apartmentName || '입주박람회') + ' 입주박람회 사전 수요조사 결과 보고서';
    const safeName = reportTitle.replace(/[\\/:*?"<>|]/g, '_') + '_' + Utilities.formatDate(new Date(), 'Asia/Seoul', 'yyyyMMdd_HHmm') + '.pdf';
    if (f.dryRun === true || String(f.dryRun || '').toLowerCase() === 'true') {
      return formExecutionReturn_('formGenerateDemandSurveyPdfReport', formResponse_(true, 'PDF 리포트 생성 시뮬레이션 완료', {
        reportId: reportId,
        reportTitle: reportTitle,
        dryRunOnly: true,
        responseCount: stats.responseCount,
        householdCount: stats.householdCount,
        duplicateCount: stats.duplicateCount,
        topItem: stats.topItem,
        itemSummary: stats.itemList,
        interestSummary: stats.interestList,
        clientSafe: true
      }, '', { build: FORM_BUILD, pdfReport: true, dryRunOnly: true }));
    }
    const blob = Utilities.newBlob(html, 'text/html', safeName.replace(/\.pdf$/i, '.html')).getAs(MimeType.PDF).setName(safeName);
    const pdfFolder = formDemandPdfStorageFolder_(context);
    const file = pdfFolder.createFile(blob);
    const pdfUrl = file.getUrl();
    let downloadUrl = '';
    try { downloadUrl = file.getDownloadUrl(); } catch (err) { downloadUrl = pdfUrl; }
    const now = formNow_();
    formWriteDemandPdfReportLog_({
      reportId: reportId,
      eventId: eventId,
      apartmentName: context.apartmentName,
      reportTitle: reportTitle,
      responseCount: stats.responseCount,
      householdCount: stats.householdCount,
      duplicateCount: stats.duplicateCount,
      topItem: stats.topItem,
      pdfFolderId: pdfFolder.getId(),
      pdfFolderUrl: pdfFolder.getUrl(),
      pdfFileId: file.getId(),
      pdfUrl: pdfUrl,
      downloadUrl: downloadUrl,
      createdAt: now,
      createdBy: formUser_(),
      build: FORM_BUILD
    });
    return formExecutionReturn_('formGenerateDemandSurveyPdfReport', formResponse_(true, 'PDF가 생성되었습니다.', {
      reportId: reportId,
      reportTitle: reportTitle,
      pdfFolderId: pdfFolder.getId(),
      pdfFolderUrl: pdfFolder.getUrl(),
      pdfFileId: file.getId(),
      pdfUrl: pdfUrl,
      downloadUrl: downloadUrl,
      responseCount: stats.responseCount,
      householdCount: stats.householdCount,
      duplicateCount: stats.duplicateCount,
      topItem: stats.topItem,
      itemSummary: stats.itemList,
      interestSummary: stats.interestList,
      clientSafe: true
    }, '', { build: FORM_BUILD, pdfReport: true }));
  } catch (err) {
    return formExecutionError_('formGenerateDemandSurveyPdfReport', err, { filters: filters || {} }, 'DEMAND_PDF_REPORT_FAILED');
  }
}


function formDemandApartmentSourceSheetName_() { return 'ERP_행사관리'; }

function formDemandApartmentNormalize_(value) { return String(value == null ? '' : value).trim().replace(/\s+/g, '').toLowerCase(); }

function formDemandApartmentPick_(row, keys) {
  for (let i = 0; i < keys.length; i++) {
    const k = keys[i];
    if (row && row[k] !== undefined && row[k] !== null && String(row[k]).trim() !== '') return row[k];
  }
  return '';
}

function formDemandApartmentName_(row) {
  return String(formDemandApartmentPick_(row || {}, ['apartmentName','apartment','aptName','complexName','siteName','eventName','eventTitle','fieldName','placeName','projectName','단지명','아파트명','현장명','행사명','아파트','단지','현장']) || (row && row.eventId) || '미지정 아파트').trim();
}

function formDemandApartmentKey_(row) {
  return formDemandApartmentNormalize_([formDemandApartmentName_(row || {}), row && row.eventId ? row.eventId : '', row && row.vendorId ? row.vendorId : ''].filter(Boolean).join('|')) || 'unknown';
}

function formDemandErpEventRows_() {
  const ss = formGetMasterSpreadsheet_();
  const sheetName = formDemandApartmentSourceSheetName_();
  const sheet = ss.getSheetByName(sheetName);
  if (!sheet) throw new Error('FEELHAUS_DB_MASTER 안의 ' + sheetName + ' 시트를 찾을 수 없습니다.');
  if (sheet.getLastRow() < 2) return [];
  const values = sheet.getDataRange().getValues();
  const headers = values[0].map(String);
  const rows = [];
  for (let i = 1; i < values.length; i++) {
    const obj = {};
    headers.forEach(function(h, idx) { obj[h] = values[i][idx]; });
    obj.apartmentName = formDemandApartmentName_(obj);
    obj.apartmentKey = formDemandApartmentKey_(obj);
    obj.sourceDb = 'FEELHAUS_DB_MASTER';
    obj.sourceSheet = sheetName;
    rows.push(obj);
  }
  return rows;
}

function formListApartmentsFromErpEvent(query, limit) {
  formExecutionLog_('START', 'formListApartmentsFromErpEvent', null);
  try {
    const q = formDemandApartmentNormalize_(query || '');
    const max = Math.min(Math.max(Number(limit) || 100, 1), 300);
    const grouped = {};
    formDemandErpEventRows_().forEach(function(row) {
      const key = row.apartmentKey;
      const search = formDemandApartmentNormalize_(Object.keys(row).map(function(k) { return row[k]; }).join(' '));
      if (q && search.indexOf(q) === -1) return;
      if (!grouped[key]) grouped[key] = {
        apartmentKey: key,
        apartmentName: row.apartmentName || '',
        eventId: row.eventId || '',
        vendorId: row.vendorId || '',
        eventName: row.eventName || row.eventTitle || '',
        eventPlace: row.eventPlace || row.placeName || '',
        startDate: formDemandClientSafe_(row.startDate || ''),
        endDate: formDemandClientSafe_(row.endDate || ''),
        manager: row.manager || '',
        sourceDb: 'FEELHAUS_DB_MASTER',
        sourceSheet: formDemandApartmentSourceSheetName_(),
        requestCount: 0
      };
      grouped[key].requestCount++;
    });
    const list = Object.keys(grouped).map(function(k) { return grouped[k]; }).slice(0, max);
    return formExecutionReturn_('formListApartmentsFromErpEvent', formResponse_(true, list.length ? 'ERP_행사관리 아파트 목록 조회 완료' : 'ERP_행사관리 아파트 데이터가 없습니다.', formDemandClientSafe_(list), '', { sourceSheet: formDemandApartmentSourceSheetName_(), count: list.length, clientSafe: true }));
  } catch (err) {
    return formExecutionError_('formListApartmentsFromErpEvent', err, { query: query || '', limit: limit || '' }, 'ERP_EVENT_APARTMENT_LIST_FAILED');
  }
}
