
function formLinkToErp(requestId) {
  formExecutionLog_('START', 'formLinkToErp', null);
  try {
    const result = FORM_SAFE_MODE.ERP_WRITE_ALLOWED !== true ? formLinkToErpDryRun(requestId) : formLinkToErpLive_(requestId);
    return formExecutionReturn_('formLinkToErp', result);
  } catch (err) {
    return formExecutionError_('formLinkToErp', err, { requestId: requestId }, 'ERP_LINK_FAILED');
  }
}

function formLinkToErpDryRun(requestId) {
  try {
    const ss = formGetMasterSpreadsheet_();
    const masterSheet = formEnsureSheet_(ss, FORM_SHEETS.MASTER, FORM_REQUIRED_HEADERS.FORM_MASTER);
    const found = formFindRowById_(masterSheet, 'requestId', requestId);
    if (!found) throw new Error('MASTER 데이터를 찾을 수 없습니다: ' + requestId);
    const row = formRowObject_(found.row, found.map);

    let targetSheetName = 'ERP_업무요청';
    if (row.workType === FORM_WORK_TYPES.AS) targetSheetName = 'ERP_AS_MASTER';
    if (row.workType === FORM_WORK_TYPES.CLAIM_REFUND) targetSheetName = 'ERP_클레임환불요청';
    if (row.workType === FORM_WORK_TYPES.CAFE_FORM) targetSheetName = 'ERP_카페폼접수';
    if (row.workType === FORM_WORK_TYPES.QR_CUSTOMER || row.workType === FORM_WORK_TYPES.CUSTOMER_REGISTER) targetSheetName = 'ERP_고객관리';
    if (row.workType === FORM_WORK_TYPES.DEMAND_SURVEY) {
      targetSheetName = FORM_SHEETS.DEMAND_REPORT;
      formUpdateRowByHeader_(masterSheet, found.rowIndex, {
        status: FORM_STATUS.ERP_DRYRUN_BLOCKED,
        statusReason: '수요조사 접수 / 보고서 시트 저장 / ERP 원본 저장 차단',
        updatedAt: formNow_(),
        updatedBy: formUser_()
      });
      return formResponse_(true, '수요조사 접수 완료 / 보고서 저장 대상', { requestId: requestId, targetSheet: targetSheetName, dryRunOnly: true, liveWriteBlocked: true, retryRegistered: false, demandSurvey: true });
    }

    formUpdateRowByHeader_(masterSheet, found.rowIndex, {
      status: FORM_STATUS.ERP_DRYRUN_BLOCKED,
      statusReason: 'ERP 원본 저장 차단: ' + targetSheetName + ' 등록 후보만 생성',
      updatedAt: formNow_(),
      updatedBy: formUser_()
    });
    const retryMessage = 'SAFE MODE ERP 원본 저장 차단 / 운영 전환 시 재처리 대상';
    formWriteTimeline_(requestId, FORM_STATUS.ERP_DRYRUN_BLOCKED, 'ERP 원본 저장 차단', targetSheetName);
    formWriteLog_('ERP_DRYRUN_BLOCKED', requestId, targetSheetName, '', JSON.stringify(row), '실제 ERP 원본 저장 차단');
    formRegisterRetry_(requestId, row.sourceType || '', row.workType || '', targetSheetName, 'ERP_DRYRUN_BLOCKED', retryMessage);
    return formResponse_(true, 'ERP 등록 후보 생성 완료 / 실제 저장 차단', { requestId: requestId, targetSheet: targetSheetName, dryRunOnly: true, liveWriteBlocked: true, retryRegistered: true });
  } catch (err) {
    formRegisterRetry_(requestId, '', '', 'ERP', 'ERP_DRYRUN_FAILED', err.message);
    return formResponse_(false, err.message, { requestId: requestId }, 'ERP_DRYRUN_FAILED');
  }
}

function formLinkToErpLive_(requestId) {
  const message = '메인 개발자 확인 필요: ERP 운영 원본 자동등록은 SheetPolicy/권한/승인정책 확정 전까지 차단됩니다.';
  formWriteTimeline_(requestId, FORM_STATUS.ERP_DRYRUN_BLOCKED, 'ERP 운영모드 차단', message);
  formWriteLog_('ERP_LIVE_BLOCKED', requestId, 'ERP', '', '', message);
  return formResponse_(false, message, { requestId: requestId, dryRunOnly: false, liveWriteBlocked: true }, 'ERP_LIVE_BLOCKED');
}

function formRegisterRetry_(requestId, sourceType, workType, targetSheet, errorCode, message) {
  const ss = formGetMasterSpreadsheet_();
  const sheet = formEnsureSheet_(ss, FORM_SHEETS.RETRY, FORM_REQUIRED_HEADERS.FORM_RETRY);
  const existing = requestId ? formFindRowById_(sheet, 'requestId', requestId) : null;
  const now = formNow_();
  const record = {
    requestId: requestId,
    sourceType: sourceType || '',
    workType: workType || '',
    targetSheet: targetSheet || '',
    errorCode: errorCode || 'ERROR',
    message: message || '',
    retryStatus: FORM_STATUS.RETRY_PENDING,
    retryCount: 0,
    lastTriedAt: '',
    createdAt: now,
    createdBy: formUser_(),
    updatedAt: now,
    updatedBy: formUser_()
  };
  if (existing) {
    delete record.createdAt;
    delete record.createdBy;
    formUpdateRowByHeader_(sheet, existing.rowIndex, record);
  } else {
    formAppendByHeader_(sheet, record);
  }
  formWriteTimeline_(requestId, FORM_STATUS.RETRY_PENDING, errorCode, message);
}


function formRetryRequest(requestId) {
  formExecutionLog_('START', 'formRetryRequest', null);
  try {
    const ss = formGetMasterSpreadsheet_();
    const retrySheet = formEnsureSheet_(ss, FORM_SHEETS.RETRY, FORM_REQUIRED_HEADERS.FORM_RETRY);
    const found = formFindRowById_(retrySheet, 'requestId', requestId);
    if (!found) return formExecutionReturn_('formRetryRequest', formResponse_(false, '재처리 대상을 찾을 수 없습니다.', { requestId: requestId }, 'RETRY_NOT_FOUND'));
    formUpdateRowByHeader_(retrySheet, found.rowIndex, {
      retryStatus: 'RETRYING',
      retryCount: Number(found.row[found.map.retryCount] || 0) + 1,
      lastTriedAt: formNow_(),
      updatedAt: formNow_(),
      updatedBy: formUser_()
    });
    return formExecutionReturn_('formRetryRequest', formLinkToErp(requestId));
  } catch (err) {
    return formExecutionError_('formRetryRequest', err, { requestId: requestId }, 'RETRY_FAILED');
  }
}


function formListRetryQueue() {
  formExecutionLog_('START', 'formListRetryQueue', null);
  try {
    const ss = formGetMasterSpreadsheet_();
    const sheet = formEnsureSheet_(ss, FORM_SHEETS.RETRY, FORM_REQUIRED_HEADERS.FORM_RETRY);
    const values = sheet.getDataRange().getValues();
    if (values.length < 2) return formExecutionReturn_('formListRetryQueue', formResponse_(true, '재처리 대기 데이터가 없습니다.', []));
    const headers = values[0].map(String);
    const data = values.slice(1).map(row => {
      const obj = {};
      headers.forEach((h, i) => obj[h] = row[i]);
      return obj;
    }).filter(row => row.retryStatus !== 'RESOLVED');
    return formExecutionReturn_('formListRetryQueue', formResponse_(true, data.length ? '재처리 대기 목록' : '재처리 대기 데이터가 없습니다.', data));
  } catch (err) {
    return formExecutionError_('formListRetryQueue', err, null, 'RETRY_LIST_FAILED');
  }
}

function formGetRetrySummary() {
  formExecutionLog_('START', 'formGetRetrySummary', null);
  try {
    const ss = formGetMasterSpreadsheet_();
    const sheet = formEnsureSheet_(ss, FORM_SHEETS.RETRY, FORM_REQUIRED_HEADERS.FORM_RETRY);
    const values = sheet.getDataRange().getValues();
    const summary = {
      total: Math.max(0, values.length - 1),
      pending: 0,
      retrying: 0,
      resolved: 0,
      failed: 0,
      dryRunBlocked: 0,
      erpDryRunBlocked: 0,
      targetSheets: {},
      errorCodes: {},
      workTypes: {},
      latestCreatedAt: '',
      latestTriedAt: '',
      dryRunOnly: FORM_SAFE_MODE.ERP_WRITE_ALLOWED !== true,
      liveWriteBlocked: FORM_SAFE_MODE.ERP_WRITE_ALLOWED !== true
    };
    const recent = [];
    if (values.length > 1) {
      const headers = values[0].map(String);
      const map = formHeaderMap_(headers);
      for (let i = 1; i < values.length; i++) {
        const obj = {};
        headers.forEach((h, idx) => obj[h] = values[i][idx]);
        const status = String(obj.retryStatus || '');
        const errorCode = String(obj.errorCode || '');
        const targetSheet = String(obj.targetSheet || '');
        const workType = String(obj.workType || '');
        if (status === FORM_STATUS.RETRY_PENDING || status === 'PENDING') summary.pending++;
        else if (status === 'RETRYING') summary.retrying++;
        else if (status === 'RESOLVED') summary.resolved++;
        else if (status) summary.failed++;
        if (errorCode === 'ERP_DRYRUN_BLOCKED') summary.erpDryRunBlocked++;
        if (errorCode.indexOf('DRYRUN') !== -1 || errorCode.indexOf('BLOCKED') !== -1) summary.dryRunBlocked++;
        if (targetSheet) summary.targetSheets[targetSheet] = (summary.targetSheets[targetSheet] || 0) + 1;
        if (errorCode) summary.errorCodes[errorCode] = (summary.errorCodes[errorCode] || 0) + 1;
        if (workType) summary.workTypes[workType] = (summary.workTypes[workType] || 0) + 1;
        if (obj.createdAt) summary.latestCreatedAt = obj.createdAt;
        if (obj.lastTriedAt) summary.latestTriedAt = obj.lastTriedAt;
        if (status !== 'RESOLVED') recent.push(formApplyMask_(obj));
      }
    }
    recent.reverse();
    return formExecutionReturn_('formGetRetrySummary', formResponse_(true, 'FORM B14 재처리 대기 요약', Object.assign({}, summary, {
      recentRetryQueue: recent.slice(0, 20),
      recentRetryCount: recent.length,
      masked: !formIsAdmin_()
    })));
  } catch (err) {
    return formExecutionError_('formGetRetrySummary', err, null, 'RETRY_SUMMARY_FAILED');
  }
}

function formRetryDateValue_(value) {
  if (!value) return 0;
  if (value instanceof Date) return value.getTime();
  const d = new Date(value);
  return isNaN(d.getTime()) ? 0 : d.getTime();
}

function formGetRetryDiagnostics() {
  formExecutionLog_('START', 'formGetRetryDiagnostics', null);
  try {
    const ss = formGetMasterSpreadsheet_();
    const sheet = formEnsureSheet_(ss, FORM_SHEETS.RETRY, FORM_REQUIRED_HEADERS.FORM_RETRY);
    const values = sheet.getDataRange().getValues();
    const now = formNow_();
    const diagnostics = {
      total: Math.max(0, values.length - 1),
      active: 0,
      pending: 0,
      retrying: 0,
      blocked: 0,
      stalePending: 0,
      staleHours: 24,
      oldestPendingAt: '',
      latestCreatedAt: '',
      latestUpdatedAt: '',
      latestTriedAt: '',
      topErrorCode: '',
      topTargetSheet: '',
      errorCodes: {},
      targetSheets: {},
      diagnosticOnly: true,
      dryRunOnly: FORM_SAFE_MODE.ERP_WRITE_ALLOWED !== true,
      actualRetryExecutionBlocked: FORM_SAFE_MODE.ERP_WRITE_ALLOWED !== true
    };
    const activeRows = [];
    let oldestPendingTime = 0;
    if (values.length > 1) {
      const headers = values[0].map(String);
      for (let i = 1; i < values.length; i++) {
        const obj = {};
        headers.forEach((h, idx) => obj[h] = values[i][idx]);
        const status = String(obj.retryStatus || '');
        const errorCode = String(obj.errorCode || '');
        const targetSheet = String(obj.targetSheet || '');
        const createdTime = formRetryDateValue_(obj.createdAt);
        const updatedTime = formRetryDateValue_(obj.updatedAt);
        const triedTime = formRetryDateValue_(obj.lastTriedAt);
        if (createdTime && createdTime >= formRetryDateValue_(diagnostics.latestCreatedAt)) diagnostics.latestCreatedAt = obj.createdAt;
        if (updatedTime && updatedTime >= formRetryDateValue_(diagnostics.latestUpdatedAt)) diagnostics.latestUpdatedAt = obj.updatedAt;
        if (triedTime && triedTime >= formRetryDateValue_(diagnostics.latestTriedAt)) diagnostics.latestTriedAt = obj.lastTriedAt;
        if (errorCode) diagnostics.errorCodes[errorCode] = (diagnostics.errorCodes[errorCode] || 0) + 1;
        if (targetSheet) diagnostics.targetSheets[targetSheet] = (diagnostics.targetSheets[targetSheet] || 0) + 1;
        if (status !== 'RESOLVED') {
          diagnostics.active++;
          activeRows.push(obj);
        }
        if (status === FORM_STATUS.RETRY_PENDING || status === 'PENDING') {
          diagnostics.pending++;
          if (createdTime && (oldestPendingTime === 0 || createdTime < oldestPendingTime)) {
            oldestPendingTime = createdTime;
            diagnostics.oldestPendingAt = obj.createdAt;
          }
          if (createdTime && (now.getTime() - createdTime) > diagnostics.staleHours * 60 * 60 * 1000) diagnostics.stalePending++;
        } else if (status === 'RETRYING') {
          diagnostics.retrying++;
        }
        if (errorCode.indexOf('BLOCKED') !== -1 || errorCode.indexOf('DRYRUN') !== -1) diagnostics.blocked++;
      }
    }
    Object.keys(diagnostics.errorCodes).forEach(code => {
      if (!diagnostics.topErrorCode || diagnostics.errorCodes[code] > diagnostics.errorCodes[diagnostics.topErrorCode]) diagnostics.topErrorCode = code;
    });
    Object.keys(diagnostics.targetSheets).forEach(name => {
      if (!diagnostics.topTargetSheet || diagnostics.targetSheets[name] > diagnostics.targetSheets[diagnostics.topTargetSheet]) diagnostics.topTargetSheet = name;
    });
    activeRows.sort((a, b) => formRetryDateValue_(b.updatedAt || b.createdAt) - formRetryDateValue_(a.updatedAt || a.createdAt));
    diagnostics.recentRetryQueue = activeRows.slice(0, 20).map(row => formApplyMask_(row));
    diagnostics.recentRetryCount = diagnostics.recentRetryQueue.length;
    return formExecutionReturn_('formGetRetryDiagnostics', formResponse_(true, 'FORM B14 재처리 진단 요약', diagnostics));
  } catch (err) {
    return formExecutionError_('formGetRetryDiagnostics', err, null, 'RETRY_DIAGNOSTICS_FAILED');
  }
}

