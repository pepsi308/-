const FORM_ALLOWED_TRANSITIONS = Object.freeze({
  RECEIVED: ['NORMALIZED','RETRY_PENDING','ERROR'],
  QR_RECEIVED: ['NORMALIZED','MATCHED','DUPLICATE_CANDIDATE','NEW_CANDIDATE','ERROR'],
  NORMALIZED: ['MATCHED','DUPLICATE_CANDIDATE','NEW_CANDIDATE','ERP_DRYRUN_BLOCKED','RETRY_PENDING','ERROR'],
  MATCHED: ['DOCUMENT_READY','ERP_DRYRUN_BLOCKED','APPROVAL_PENDING'],
  DUPLICATE_CANDIDATE: ['APPROVAL_PENDING','RETRY_PENDING','HOLD'],
  NEW_CANDIDATE: ['DOCUMENT_READY','APPROVAL_PENDING','ERP_DRYRUN_BLOCKED'],
  DOCUMENT_READY: ['ERP_DRYRUN_BLOCKED','SIGN_DRYRUN_BLOCKED','APPROVAL_PENDING'],
  ERP_DRYRUN_BLOCKED: ['ASSIGNED','SCHEDULED','APPROVAL_PENDING','RETRY_PENDING','HOLD'],
  SIGN_DRYRUN_BLOCKED: ['APPROVAL_PENDING','RETRY_PENDING','HOLD'],
  APPROVAL_PENDING: ['ERP_DRYRUN_BLOCKED','SIGN_DRYRUN_BLOCKED','HOLD','CANCELLED'],
  ASSIGNED: ['SCHEDULED','IN_PROGRESS','HOLD','CANCELLED'],
  SCHEDULED: ['IN_PROGRESS','HOLD','CANCELLED'],
  IN_PROGRESS: ['COMPLETED','HOLD','CANCELLED'],
  HOLD: ['ASSIGNED','SCHEDULED','IN_PROGRESS','CANCELLED'],
  RETRY_PENDING: ['ERP_DRYRUN_BLOCKED','SIGN_DRYRUN_BLOCKED','ERROR'],
  ERROR: ['RETRY_PENDING'],
  COMPLETED: [],
  CANCELLED: []
});


function formChangeStatus(requestId, nextStatus, reason) {
  formExecutionLog_('START', 'formChangeStatus', null);
  try {
    const ss = formGetMasterSpreadsheet_();
    const sheet = formEnsureSheet_(ss, FORM_SHEETS.MASTER, FORM_REQUIRED_HEADERS.FORM_MASTER);
    const found = formFindRowById_(sheet, 'requestId', requestId);
    if (!found) return formExecutionReturn_('formChangeStatus', formResponse_(false, '대상 요청을 찾을 수 없습니다.', { requestId: requestId }, 'REQUEST_NOT_FOUND'));

    const current = String(found.row[found.map.status] || '');
    const allowed = FORM_ALLOWED_TRANSITIONS[current] || [];
    if (current && allowed.indexOf(nextStatus) === -1) {
      return formExecutionReturn_('formChangeStatus', formResponse_(false, '허용되지 않은 상태 전이입니다: ' + current + ' → ' + nextStatus, { current: current, next: nextStatus }, 'INVALID_STATUS_TRANSITION'));
    }

    formUpdateRowByHeader_(sheet, found.rowIndex, {
      status: nextStatus,
      statusReason: reason || '',
      updatedAt: formNow_(),
      updatedBy: formUser_()
    });
    formWriteTimeline_(requestId, nextStatus, reason || '', '상태 변경');
    formWriteLog_('STATUS_CHANGE', requestId, FORM_SHEETS.MASTER, current, nextStatus, reason || '');
    return formExecutionReturn_('formChangeStatus', formResponse_(true, '상태 변경 완료', { requestId: requestId, status: nextStatus }));
  } catch (err) {
    return formExecutionError_('formChangeStatus', err, { requestId: requestId, nextStatus: nextStatus }, 'STATUS_CHANGE_FAILED');
  }
}


function formAssignRequest(requestId, assignee, scheduledAt) {
  formExecutionLog_('START', 'formAssignRequest', null);
  try {
    if (!assignee) return formExecutionReturn_('formAssignRequest', formResponse_(false, '담당자 값이 없습니다.', { requestId: requestId }, 'ASSIGNEE_REQUIRED'));
    const ss = formGetMasterSpreadsheet_();
    const sheet = formEnsureSheet_(ss, FORM_SHEETS.MASTER, FORM_REQUIRED_HEADERS.FORM_MASTER);
    const found = formFindRowById_(sheet, 'requestId', requestId);
    if (!found) return formExecutionReturn_('formAssignRequest', formResponse_(false, '대상 요청을 찾을 수 없습니다.', { requestId: requestId }, 'REQUEST_NOT_FOUND'));

    const current = String(found.row[found.map.status] || '');
    if (['COMPLETED','CANCELLED'].indexOf(current) !== -1) {
      return formExecutionReturn_('formAssignRequest', formResponse_(false, '완료/취소 상태는 일반 배정 변경이 불가합니다.', { requestId: requestId, status: current }, 'LOCKED_STATUS'));
    }

    const nextStatus = scheduledAt ? FORM_STATUS.SCHEDULED : FORM_STATUS.ASSIGNED;
    const allowed = FORM_ALLOWED_TRANSITIONS[current] || [];
    if (current && allowed.indexOf(nextStatus) === -1) {
      return formExecutionReturn_('formAssignRequest', formResponse_(false, '허용되지 않은 배정 상태 전이입니다: ' + current + ' → ' + nextStatus, { requestId: requestId, current: current, next: nextStatus }, 'INVALID_ASSIGN_TRANSITION'));
    }

    const beforeValue = JSON.stringify({ status: current, assignedTo: found.map.assignedTo == null ? '' : found.row[found.map.assignedTo], scheduledAt: found.map.scheduledAt == null ? '' : found.row[found.map.scheduledAt] });
    const afterValue = JSON.stringify({ status: nextStatus, assignedTo: assignee, scheduledAt: scheduledAt || '' });

    formUpdateRowByHeader_(sheet, found.rowIndex, {
      assignedTo: assignee,
      scheduledAt: scheduledAt || '',
      status: nextStatus,
      statusReason: '담당자 배정',
      updatedAt: formNow_(),
      updatedBy: formUser_()
    });
    formWriteTimeline_(requestId, nextStatus, '담당자 배정', assignee);
    formWriteLog_('ASSIGN_REQUEST', requestId, FORM_SHEETS.MASTER, beforeValue, afterValue, '담당자 배정');
    return formExecutionReturn_('formAssignRequest', formResponse_(true, '담당자 배정 완료', { requestId: requestId, assignedTo: assignee, status: nextStatus, scheduledAt: scheduledAt || '' }));
  } catch (err) {
    return formExecutionError_('formAssignRequest', err, { requestId: requestId, assignee: assignee, scheduledAt: scheduledAt || '' }, 'ASSIGN_REQUEST_FAILED');
  }
}

function formReopenRequest(requestId, approvalId, nextStatus, reason) {
  formExecutionLog_('START', 'formReopenRequest', null);
  try {
    if (!requestId) return formExecutionReturn_('formReopenRequest', formResponse_(false, '요청 ID가 없습니다.', { requestId: requestId }, 'REQUEST_ID_REQUIRED'));
    if (!approvalId) return formExecutionReturn_('formReopenRequest', formResponse_(false, '승인 ID가 없습니다.', { requestId: requestId }, 'APPROVAL_REQUIRED'));

    const targetStatus = nextStatus || FORM_STATUS.ASSIGNED;
    const reopenAllowed = [FORM_STATUS.ASSIGNED, FORM_STATUS.IN_PROGRESS, FORM_STATUS.HOLD];
    if (reopenAllowed.indexOf(targetStatus) === -1) {
      return formExecutionReturn_('formReopenRequest', formResponse_(false, '재오픈 대상 상태가 허용되지 않습니다: ' + targetStatus, { requestId: requestId, nextStatus: targetStatus }, 'INVALID_REOPEN_TARGET_STATUS'));
    }

    const ss = formGetMasterSpreadsheet_();
    const masterSheet = formEnsureSheet_(ss, FORM_SHEETS.MASTER, FORM_REQUIRED_HEADERS.FORM_MASTER);
    const found = formFindRowById_(masterSheet, 'requestId', requestId);
    if (!found) return formExecutionReturn_('formReopenRequest', formResponse_(false, '대상 요청을 찾을 수 없습니다.', { requestId: requestId }, 'REQUEST_NOT_FOUND'));

    const current = String(found.row[found.map.status] || '');
    if (['COMPLETED','CANCELLED'].indexOf(current) === -1) {
      return formExecutionReturn_('formReopenRequest', formResponse_(false, '완료/취소 상태만 승인 기반 재오픈 가능합니다.', { requestId: requestId, status: current }, 'INVALID_REOPEN_SOURCE_STATUS'));
    }

    const approvalSheet = formEnsureSheet_(ss, FORM_SHEETS.APPROVAL, FORM_REQUIRED_HEADERS.FORM_APPROVAL);
    const approvalFound = formFindRowById_(approvalSheet, 'approvalId', approvalId);
    if (!approvalFound) return formExecutionReturn_('formReopenRequest', formResponse_(false, '재오픈 승인 요청을 찾을 수 없습니다.', { requestId: requestId, approvalId: approvalId }, 'REOPEN_APPROVAL_NOT_FOUND'));

    const approval = formRowObject_(approvalFound.row, approvalFound.map);
    if (String(approval.requestId || '') !== String(requestId)) {
      return formExecutionReturn_('formReopenRequest', formResponse_(false, '승인 요청의 requestId가 대상과 일치하지 않습니다.', { requestId: requestId, approvalId: approvalId, approvalRequestId: approval.requestId || '' }, 'REOPEN_APPROVAL_MISMATCH'));
    }
    if (String(approval.targetId || '') !== String(requestId)) {
      return formExecutionReturn_('formReopenRequest', formResponse_(false, '승인 요청의 targetId가 대상과 일치하지 않습니다.', { requestId: requestId, approvalId: approvalId, targetId: approval.targetId || '' }, 'REOPEN_APPROVAL_TARGET_MISMATCH'));
    }
    if (String(approval.targetSheet || '') !== FORM_SHEETS.MASTER) {
      return formExecutionReturn_('formReopenRequest', formResponse_(false, '승인 요청의 targetSheet가 FORM_MASTER가 아닙니다.', { requestId: requestId, approvalId: approvalId, targetSheet: approval.targetSheet || '' }, 'INVALID_REOPEN_APPROVAL_TARGET_SHEET'));
    }
    const approvalType = String(approval.approvalType || '');
    if (['FORM_REOPEN_REQUEST','FORM_REOPEN_APPROVAL'].indexOf(approvalType) === -1) {
      return formExecutionReturn_('formReopenRequest', formResponse_(false, '재오픈 승인 유형이 아닙니다.', { requestId: requestId, approvalId: approvalId, approvalType: approvalType }, 'INVALID_REOPEN_APPROVAL_TYPE'));
    }
    if (String(approval.approvalStatus || '') === 'USED') {
      return formExecutionReturn_('formReopenRequest', formResponse_(false, '이미 사용 완료된 재오픈 승인입니다.', { requestId: requestId, approvalId: approvalId, approvalStatus: approval.approvalStatus || '' }, 'REOPEN_APPROVAL_ALREADY_USED'));
    }
    if (String(approval.approvalStatus || '') !== 'APPROVED') {
      return formExecutionReturn_('formReopenRequest', formResponse_(false, '승인 완료 전에는 재오픈할 수 없습니다.', { requestId: requestId, approvalId: approvalId, approvalStatus: approval.approvalStatus || '' }, 'REOPEN_APPROVAL_NOT_APPROVED'));
    }

    const beforeObj = formRowObject_(found.row, found.map);
    const patch = {
      status: targetStatus,
      statusReason: reason || '승인 기반 재오픈',
      updatedAt: formNow_(),
      updatedBy: formUser_()
    };
    if (targetStatus !== FORM_STATUS.HOLD) patch.scheduledAt = '';
    formUpdateRowByHeader_(masterSheet, found.rowIndex, patch);

    const usedReason = (approval.approvalReason ? String(approval.approvalReason) + ' / ' : '') + 'USED_BY_REOPEN:' + requestId;
    formUpdateRowByHeader_(approvalSheet, approvalFound.rowIndex, {
      approvalStatus: 'USED',
      approvalReason: usedReason,
      updatedAt: formNow_(),
      updatedBy: formUser_()
    });

    const afterObj = Object.assign({}, beforeObj, patch);
    formWriteTimeline_(requestId, targetStatus, reason || '승인 기반 재오픈', 'approvalId=' + approvalId + ' / approvalStatus=USED');
    formWriteLog_('REOPEN_APPROVAL_USED', approvalId, FORM_SHEETS.APPROVAL, 'APPROVED', 'USED', '재오픈 승인 1회 사용 처리', approval.approvedBy || '');
    formWriteLog_('REOPEN_APPROVED', requestId, FORM_SHEETS.MASTER, JSON.stringify(beforeObj), JSON.stringify(afterObj), reason || '승인 기반 재오픈', approval.approvedBy || '');
    return formExecutionReturn_('formReopenRequest', formResponse_(true, '승인 기반 재오픈 완료 / 승인 사용 처리 완료', {
      requestId: requestId,
      approvalId: approvalId,
      fromStatus: current,
      status: targetStatus,
      approvalStatus: 'USED',
      approvedBy: approval.approvedBy || ''
    }));
  } catch (err) {
    return formExecutionError_('formReopenRequest', err, { requestId: requestId, approvalId: approvalId, nextStatus: nextStatus }, 'REOPEN_REQUEST_FAILED');
  }
}

function formListReopenHistory(requestId, limit) {
  formExecutionLog_('START', 'formListReopenHistory', null);
  try {
    if (!requestId) return formExecutionReturn_('formListReopenHistory', formResponse_(false, '요청 ID가 없습니다.', { requestId: requestId }, 'REQUEST_ID_REQUIRED'));
    const ss = formGetMasterSpreadsheet_();
    const logSheet = formEnsureSheet_(ss, FORM_SHEETS.LOG, FORM_REQUIRED_HEADERS.FORM_LOG);
    const timelineSheet = formEnsureSheet_(ss, FORM_SHEETS.TIMELINE, FORM_REQUIRED_HEADERS.FORM_TIMELINE);
    const max = Math.max(1, Math.min(Number(limit) || 50, 200));
    const logs = [];
    const logValues = logSheet.getDataRange().getValues();
    if (logValues.length > 1) {
      const headers = logValues[0].map(String);
      const map = formHeaderMap_(headers);
      for (let i = 1; i < logValues.length; i++) {
        const actionType = String(map.actionType == null ? '' : logValues[i][map.actionType]);
        const targetId = String(map.targetId == null ? '' : logValues[i][map.targetId]);
        if (targetId === String(requestId) && actionType.indexOf('REOPEN') !== -1) {
          const obj = {};
          headers.forEach((h, idx) => obj[h] = logValues[i][idx]);
          logs.push(formApplyMask_(obj));
        }
      }
    }
    const timeline = [];
    const tlValues = timelineSheet.getDataRange().getValues();
    if (tlValues.length > 1) {
      const headers = tlValues[0].map(String);
      const map = formHeaderMap_(headers);
      for (let j = 1; j < tlValues.length; j++) {
        const rowRequestId = String(map.requestId == null ? '' : tlValues[j][map.requestId]);
        const memo = String(map.memo == null ? '' : tlValues[j][map.memo]);
        if (rowRequestId === String(requestId) && memo.indexOf('approvalId=') !== -1) {
          const obj = {};
          headers.forEach((h, idx) => obj[h] = tlValues[j][idx]);
          timeline.push(formApplyMask_(obj));
        }
      }
    }
    logs.reverse();
    timeline.reverse();
    return formExecutionReturn_('formListReopenHistory', formResponse_(true, logs.length || timeline.length ? '재오픈 이력 조회' : '재오픈 이력이 없습니다.', {
      requestId: requestId,
      logs: logs.slice(0, max),
      timeline: timeline.slice(0, max),
      logCount: logs.length,
      timelineCount: timeline.length,
      masked: !formIsAdmin_()
    }));
  } catch (err) {
    return formExecutionError_('formListReopenHistory', err, { requestId: requestId, limit: limit || '' }, 'REOPEN_HISTORY_FAILED');
  }
}

function formAddRequestMemo(requestId, memo, memoType) {
  formExecutionLog_('START', 'formAddRequestMemo', null);
  try {
    if (!requestId) return formExecutionReturn_('formAddRequestMemo', formResponse_(false, '요청 ID가 없습니다.', { requestId: requestId }, 'REQUEST_ID_REQUIRED'));
    const memoText = String(memo == null ? '' : memo).trim();
    if (!memoText) return formExecutionReturn_('formAddRequestMemo', formResponse_(false, '메모 내용이 없습니다.', { requestId: requestId }, 'MEMO_REQUIRED'));

    const ss = formGetMasterSpreadsheet_();
    const masterSheet = formEnsureSheet_(ss, FORM_SHEETS.MASTER, FORM_REQUIRED_HEADERS.FORM_MASTER);
    const found = formFindRowById_(masterSheet, 'requestId', requestId);
    if (!found) return formExecutionReturn_('formAddRequestMemo', formResponse_(false, '대상 요청을 찾을 수 없습니다.', { requestId: requestId }, 'REQUEST_NOT_FOUND'));

    const current = formRowObject_(found.row, found.map);
    const currentStatus = String(current.status || '');
    const type = String(memoType || 'FIELD_MEMO').trim() || 'FIELD_MEMO';
    const memoLimited = memoText.slice(0, 500);
    const afterValue = JSON.stringify({ requestId: requestId, status: currentStatus, memoType: type, memo: memoLimited });

    formWriteTimeline_(requestId, currentStatus || 'MEMO', type, memoLimited);
    formWriteLog_('REQUEST_MEMO_ADD', requestId, FORM_SHEETS.TIMELINE, '', afterValue, '현장 처리 메모 기록');
    return formExecutionReturn_('formAddRequestMemo', formResponse_(true, '현장 처리 메모 기록 완료', {
      requestId: requestId,
      status: currentStatus,
      memoType: type,
      memoLength: memoLimited.length,
      timelineWritten: true,
      masterUpdated: false,
      originalWriteBlocked: {
        erp: FORM_SAFE_MODE.ERP_WRITE_ALLOWED !== true,
        sign: FORM_SAFE_MODE.SIGN_WRITE_ALLOWED !== true,
        settlement: FORM_SAFE_MODE.SETTLEMENT_WRITE_ALLOWED !== true,
        externalSync: FORM_SAFE_MODE.EXTERNAL_SYNC_ALLOWED !== true
      }
    }));
  } catch (err) {
    return formExecutionError_('formAddRequestMemo', err, { requestId: requestId || '', memoType: memoType || '' }, 'REQUEST_MEMO_ADD_FAILED');
  }
}



function formFindMemoAuditTarget_(requestId, memoLogId) {
  const ss = formGetMasterSpreadsheet_();
  const sheet = ss.getSheetByName(FORM_SHEETS.TIMELINE);
  if (!sheet || sheet.getLastRow() < 2) return { found: false, memo: null };
  const values = sheet.getDataRange().getValues();
  const headers = values[0].map(String);
  const map = formHeaderMap_(headers);
  for (let i = values.length - 1; i >= 1; i--) {
    const rowRequestId = map.requestId == null ? '' : values[i][map.requestId];
    if (String(rowRequestId) !== String(requestId || '')) continue;
    const reason = String(map.statusReason == null ? '' : values[i][map.statusReason]);
    if (reason.indexOf('MEMO') === -1 && reason.indexOf('NOTE') === -1) continue;
    const logId = map.logId == null ? '' : values[i][map.logId];
    if (memoLogId && String(logId) !== String(memoLogId)) continue;
    const obj = {};
    headers.forEach((h, idx) => obj[h] = values[i][idx]);
    return { found: true, memo: obj };
  }
  return { found: false, memo: null };
}

function formRejectRequestMemoUpdate(requestId, memoLogId, newMemo, reason) {
  formExecutionLog_('START', 'formRejectRequestMemoUpdate', null);
  try {
    if (!requestId) return formExecutionReturn_('formRejectRequestMemoUpdate', formResponse_(false, '요청 ID가 없습니다.', { requestId: requestId }, 'REQUEST_ID_REQUIRED'));
    if (!memoLogId) return formExecutionReturn_('formRejectRequestMemoUpdate', formResponse_(false, '메모 logId가 없습니다.', { requestId: requestId }, 'MEMO_ID_REQUIRED'));
    const target = formFindMemoAuditTarget_(requestId, memoLogId);
    if (!target.found) return formExecutionReturn_('formRejectRequestMemoUpdate', formResponse_(false, '대상 메모를 찾을 수 없습니다.', { requestId: requestId, memoLogId: memoLogId }, 'REQUEST_MEMO_NOT_FOUND'));

    const requestReason = reason || '현장 메모 원본 수정 차단 / 정정 메모 추가 필요';
    const beforeValue = JSON.stringify({ requestId: requestId, memoLogId: memoLogId, originalStatusReason: target.memo.statusReason || '', originalMemo: target.memo.memo || '' });
    const afterValue = JSON.stringify({ requestedMemo: String(newMemo == null ? '' : newMemo).slice(0, 500), blocked: true, suggestedAction: 'ADD_CORRECTION_MEMO' });

    formWriteTimeline_(requestId, target.memo.status || 'MEMO', 'MEMO_UPDATE_BLOCKED', 'memoLogId=' + memoLogId + ' / ' + requestReason);
    formWriteLog_('REQUEST_MEMO_UPDATE_BLOCKED', requestId, FORM_SHEETS.TIMELINE, beforeValue, afterValue, requestReason);
    return formExecutionReturn_('formRejectRequestMemoUpdate', formResponse_(false, '현장 메모는 원본 수정할 수 없습니다. 정정 메모를 추가하세요.', {
      requestId: requestId,
      memoLogId: memoLogId,
      auditLogWritten: true,
      timelineWritten: true,
      memoMutated: false,
      deleteExecuted: false,
      masterUpdated: false,
      suggestedAction: 'ADD_CORRECTION_MEMO'
    }, 'MEMO_UPDATE_BLOCKED'));
  } catch (err) {
    return formExecutionError_('formRejectRequestMemoUpdate', err, { requestId: requestId || '', memoLogId: memoLogId || '' }, 'REQUEST_MEMO_UPDATE_REJECT_FAILED');
  }
}

function formRejectRequestMemoDelete(requestId, memoLogId, reason) {
  formExecutionLog_('START', 'formRejectRequestMemoDelete', null);
  try {
    if (!requestId) return formExecutionReturn_('formRejectRequestMemoDelete', formResponse_(false, '요청 ID가 없습니다.', { requestId: requestId }, 'REQUEST_ID_REQUIRED'));
    if (!memoLogId) return formExecutionReturn_('formRejectRequestMemoDelete', formResponse_(false, '메모 logId가 없습니다.', { requestId: requestId }, 'MEMO_ID_REQUIRED'));
    const target = formFindMemoAuditTarget_(requestId, memoLogId);
    if (!target.found) return formExecutionReturn_('formRejectRequestMemoDelete', formResponse_(false, '대상 메모를 찾을 수 없습니다.', { requestId: requestId, memoLogId: memoLogId }, 'REQUEST_MEMO_NOT_FOUND'));

    const requestReason = reason || '현장 메모 원본 삭제 차단 / 정정 메모 추가 필요';
    const beforeValue = JSON.stringify({ requestId: requestId, memoLogId: memoLogId, originalStatusReason: target.memo.statusReason || '', originalMemo: target.memo.memo || '' });
    const afterValue = JSON.stringify({ deleteBlocked: true, suggestedAction: 'ADD_CORRECTION_MEMO' });

    formWriteTimeline_(requestId, target.memo.status || 'MEMO', 'MEMO_DELETE_BLOCKED', 'memoLogId=' + memoLogId + ' / ' + requestReason);
    formWriteLog_('REQUEST_MEMO_DELETE_BLOCKED', requestId, FORM_SHEETS.TIMELINE, beforeValue, afterValue, requestReason);
    return formExecutionReturn_('formRejectRequestMemoDelete', formResponse_(false, '현장 메모는 삭제할 수 없습니다. 정정 메모를 추가하세요.', {
      requestId: requestId,
      memoLogId: memoLogId,
      auditLogWritten: true,
      timelineWritten: true,
      memoMutated: false,
      deleteExecuted: false,
      masterUpdated: false,
      suggestedAction: 'ADD_CORRECTION_MEMO'
    }, 'MEMO_DELETE_BLOCKED'));
  } catch (err) {
    return formExecutionError_('formRejectRequestMemoDelete', err, { requestId: requestId || '', memoLogId: memoLogId || '' }, 'REQUEST_MEMO_DELETE_REJECT_FAILED');
  }
}
