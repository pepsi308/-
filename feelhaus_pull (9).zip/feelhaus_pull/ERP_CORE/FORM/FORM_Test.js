function formInternalTestLog_(label, value) {
  formExecutionLog_('TEST', 'formInternalTest_B44', null);
}

function formTestPush_(results, ok, message, data, errorCode) {
  const result = formResponse_(ok, message, data || null, errorCode || '');
  results.push(result);
  return result;
}

function formTestSafeModeResult_(label) {
  const ok = FORM_SAFE_MODE.ERP_WRITE_ALLOWED === false
    && FORM_SAFE_MODE.SIGN_WRITE_ALLOWED === false
    && FORM_SAFE_MODE.SETTLEMENT_WRITE_ALLOWED === false
    && FORM_SAFE_MODE.EXTERNAL_SYNC_ALLOWED === false
    && FORM_SAFE_MODE.ORIGINAL_HEADER_AUTO_ADD_ALLOWED === false;
  return formResponse_(ok, label + (ok ? ' SAFE MODE ok' : ' SAFE MODE changed'), FORM_SAFE_MODE, ok ? '' : label + '_SAFE_MODE_CHANGED');
}

function formInternalTest_B44() {
  formExecutionLog_('START', 'formInternalTest_B44', { build: typeof FORM_BUILD !== 'undefined' ? FORM_BUILD : '' });
  const results = [];
  const stamp = Utilities.formatDate(new Date(), 'Asia/Seoul', 'yyyyMMddHHmmss') + '_' + Utilities.getUuid().replace(/-/g, '').slice(0, 6).toUpperCase();
  const eventId = 'TEST_EVENT_B44_' + stamp;
  const apartmentName = 'B44수요조사아파트_' + stamp;
  formInternalTestLog_('B44_START', null);

  try {
    results.push(formEnsureAllSheets());
  } catch (err) {
    formTestPush_(results, false, err.message, null, 'B44_ENSURE_FAILED');
  }

  try {
    const center = formGetDemandFormCenterPayload({ apartmentName: apartmentName, eventId: eventId, items: ['줄눈','중문'], customItems: '붙박이장' });
    const saved = formSaveDemandFormConfig({ apartmentName: apartmentName, eventId: eventId, items: ['줄눈','중문'], customItems: '붙박이장', surveyId: center && center.data ? center.data.surveyId : '' });
    const link = center && center.data ? String(center.data.surveyLink || '') : '';
    const shortOk = link.indexOf('d=DSV_') !== -1 && link.indexOf('items=') === -1 && link.indexOf('apartmentName=') === -1;
    const titleOk = !!(center && center.data && String(center.data.shareTitle || '').indexOf('입주박람회 사전 수요조사') !== -1);
    formTestPush_(results, !!(center && center.ok && saved && saved.ok && center.data && center.data.surveyId && center.data.qrImageUrl && shortOk && titleOk), 'B44 short demand link/QR/config save ok', center && center.data ? { link: link, surveyId: center.data.surveyId, shareTitle: center.data.shareTitle, itemCount: center.data.items.length, configSaved: !!(saved && saved.ok) } : null, 'B44_LINK_QR_FAILED');
  } catch (err) {
    formTestPush_(results, false, err.message, null, 'B44_LINK_QR_FAILED');
  }

  let requestId = '';
  try {
    const submit = formSubmitDemandSurvey({
      eventId: eventId,
      apartmentName: apartmentName,
      dong: '101',
      hosu: '1101',
      selectedItems: ['줄눈','중문','붙박이장'],
      interestLevel: '견적이 궁금함',
      memo: 'B44 수요조사 테스트',
      privacyConsent: true,
      marketingConsent: true
    });
    requestId = submit && submit.data ? String(submit.data.requestId || '') : '';
    const lookup = requestId ? formDemandLookupRequest(requestId, eventId) : null;
    const reportSheet = formGetMasterSpreadsheet_().getSheetByName(FORM_SHEETS.DEMAND_REPORT);
    const reportFound = requestId && reportSheet ? formFindRowById_(reportSheet, 'requestId', requestId) : null;
    const reportHeaders = reportSheet ? reportSheet.getRange(1, 1, 1, reportSheet.getLastColumn()).getValues()[0].map(String) : [];
    const reportClean = reportHeaders.indexOf('reportId') === -1 && reportHeaders.indexOf('reportLine') === -1 && reportHeaders.indexOf('memo') === -1 && reportHeaders.indexOf('dongHosu') !== -1 && reportHeaders.indexOf('requestMemo') !== -1 && reportHeaders.indexOf('reportSummary') !== -1 && reportHeaders.indexOf('duplicate') !== -1;
    const reportHosuOk = reportFound && String(reportFound.row[reportFound.map.hosu] || '') === '1101';
    formTestPush_(results, !!(submit && submit.ok && requestId && lookup && lookup.ok && submit.data && submit.data.reportSaved === true && reportFound && reportClean && reportHosuOk), 'B44 demand submit/lookup/report sheet ok', { requestId: requestId, lookupOk: !!(lookup && lookup.ok), reportSaved: !!(submit && submit.data && submit.data.reportSaved), reportSheet: FORM_SHEETS.DEMAND_REPORT, reportClean: reportClean, reportHosuOk: reportHosuOk }, 'B44_SUBMIT_LOOKUP_FAILED');
  } catch (err) {
    formTestPush_(results, false, err.message, null, 'B44_SUBMIT_LOOKUP_FAILED');
  }

  try {
    const dup = formSubmitDemandSurvey({
      eventId: eventId,
      apartmentName: apartmentName,
      dong: '101',
      hosu: '1101',
      selectedItems: ['줄눈','중문','붙박이장'],
      interestLevel: '관심 있음',
      memo: 'B44 중복 가능 저장 테스트',
      privacyConsent: true,
      marketingConsent: true
    });
    formTestPush_(results, !!(dup && dup.ok && dup.data && dup.data.duplicateCandidate === true), 'B44 duplicate candidate allowed ok', dup && dup.data ? { requestId: dup.data.requestId, duplicateCandidate: dup.data.duplicateCandidate } : null, 'B44_DUPLICATE_CANDIDATE_FAILED');
  } catch (err) {
    formTestPush_(results, false, err.message, null, 'B44_DUPLICATE_CANDIDATE_FAILED');
  }

  try {
    const recent = formListDemandSurveyRecent({ eventId: eventId }, 10);
    const rows = recent && recent.data && Array.isArray(recent.data.rows) ? recent.data.rows : [];
    const memoOk = rows.some(function(r){ return String(r.memo || r.requestMemo || '').indexOf('B44') !== -1; });
    formTestPush_(results, !!(recent && recent.ok && recent.data && recent.data.total >= 1 && memoOk), 'B44 recent demand list memo ok', recent && recent.data ? { total: recent.data.total, memoOk: memoOk } : null, 'B44_RECENT_DEMAND_LIST_FAILED');
  } catch (err) {
    formTestPush_(results, false, err.message, null, 'B44_RECENT_DEMAND_LIST_FAILED');
  }



  try {
    const pdf = formGenerateDemandSurveyPdfReport({ eventId: eventId, apartmentName: apartmentName, dryRun: true });
    formTestPush_(results, !!(pdf && pdf.ok && pdf.data && pdf.data.responseCount >= 1 && pdf.data.householdCount >= 1 && pdf.data.topItem), 'B44 demand PDF report dryrun ok', pdf && pdf.data ? { responseCount: pdf.data.responseCount, householdCount: pdf.data.householdCount, topItem: pdf.data.topItem } : null, 'B44_PDF_REPORT_DRYRUN_FAILED');
  } catch (err) {
    formTestPush_(results, false, err.message, null, 'B44_PDF_REPORT_DRYRUN_FAILED');
  }

  results.push(formTestSafeModeResult_('B44'));
  const failed = results.filter(r => !r.ok);
  const finalResult = formResponse_(failed.length === 0, failed.length ? 'B44 demand form center check failed' : 'B44 demand form center check passed', results, failed.length ? 'B44_INTERNAL_TEST_FAILED' : '', { demandFormCenter: true, shortLinkQr: true, demandSurveySubmit: true, duplicateCandidateAllowed: true, marketingConsentRequired: true, recentList: true, reportSheet: true, reportSheetCleaned: true, pdfReport: true, dryRunConfirm: FORM_SAFE_MODE });
  formInternalTestLog_('B44_RESULT', null);
  return formExecutionReturn_('formInternalTest_B44', finalResult);
}

function formSmoke_B44() {
  formExecutionLog_('START', 'formSmoke_B44', {});
  return formExecutionReturn_('formSmoke_B44', formInternalTest_B44());
}


function formInternalTest_B45() {
  formExecutionLog_('START', 'formInternalTest_B45', { build: typeof FORM_BUILD !== 'undefined' ? FORM_BUILD : '' });
  return formExecutionReturn_('formInternalTest_B45', formInternalTest_B44());
}

function formSmoke_B45() {
  formExecutionLog_('START', 'formSmoke_B45', {});
  return formExecutionReturn_('formSmoke_B45', formInternalTest_B45());
}


function formInternalTest_B46() {
  formExecutionLog_('START', 'formInternalTest_B46', { build: typeof FORM_BUILD !== 'undefined' ? FORM_BUILD : '' });
  const result = formInternalTest_B45();
  return formExecutionReturn_('formInternalTest_B46', result);
}

function formSmoke_B46() {
  formExecutionLog_('START', 'formSmoke_B46', {});
  return formExecutionReturn_('formSmoke_B46', formInternalTest_B46());
}


function formInternalTest_B47() {
  formExecutionLog_('START', 'formInternalTest_B47', { build: typeof FORM_BUILD !== 'undefined' ? FORM_BUILD : '' });
  const result = formInternalTest_B46();
  return formExecutionReturn_('formInternalTest_B47', result);
}

function formSmoke_B47() {
  formExecutionLog_('START', 'formSmoke_B47', {});
  return formExecutionReturn_('formSmoke_B47', formInternalTest_B47());
}

function formInternalTest_B48() {
  formExecutionLog_('START', 'formInternalTest_B48', { build: typeof FORM_BUILD !== 'undefined' ? FORM_BUILD : '', baseTest: 'formInternalTest_B47' });
  const result = formInternalTest_B47();
  return formExecutionReturn_('formInternalTest_B48', result);
}

function formSmoke_B48() {
  formExecutionLog_('START', 'formSmoke_B48', { baseTest: 'formSmoke_B47' });
  return formExecutionReturn_('formSmoke_B48', formInternalTest_B48());
}

