@echo off
chcp 65001 >nul
setlocal EnableExtensions
title [FORM] FILTERED LOG

powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0FORM_LOG_FILTERED.ps1" %*
set "EC=%ERRORLEVEL%"

echo.
echo ======================================================
echo [FORM FILTERED LOG] finished. exit=%EC%
echo The window stays open so the error message can be checked.
echo ======================================================
if /I "%~1"=="--self-test" exit /b %EC%
pause
exit /b %EC%
