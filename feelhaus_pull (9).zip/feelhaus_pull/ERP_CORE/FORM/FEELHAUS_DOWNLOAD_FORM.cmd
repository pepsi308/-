@echo off
setlocal EnableExtensions
title FEELHAUS DOWNLOAD FORM
if not exist "D:\pepsi308\OneDrive\feelhaus_pull\FORM" mkdir "D:\pepsi308\OneDrive\feelhaus_pull\FORM"
cd /d D:\pepsi308\OneDrive\feelhaus_pull\FORM
if exist ".clasp.json" (
  echo [FORM] clasp pull
  clasp.cmd pull
) else (
  echo [FORM] clasp clone
  clasp.cmd clone 1YN133k7c3rKHBU-sWMkGmtEi6GROK1e8VMcBXeU48FfZp_jWEERBOZYJ
)
pause
