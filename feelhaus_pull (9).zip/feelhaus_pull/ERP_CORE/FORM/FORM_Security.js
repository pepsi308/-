const FORM_ADMIN_ROLES = Object.freeze(['SUPER_ADMIN','HQ_ADMIN','HQ_MANAGER','OPERATION_MANAGER']);
const FORM_SENSITIVE_KEYS = Object.freeze(['phone','rawPayload','content','statusReason','approvalReason']);

function formGetUserRole_() {
  try {
    const config = formGetSetupConfig_();
    const email = formUser_();
    const roleKey = 'ROLE_' + String(email).toLowerCase();
    return String(config[roleKey] || config.DEFAULT_FORM_ROLE || 'VIEWER');
  } catch (err) {
    return 'VIEWER';
  }
}

function formIsAdmin_() {
  return FORM_ADMIN_ROLES.indexOf(formGetUserRole_()) !== -1;
}

function formMaskValue_(key, value) {
  if (value === '' || value == null) return value;
  if (key === 'phone') return String(value).replace(/(\d{3})\d+(\d{4})/, '$1****$2');
  if (key === 'rawPayload') return '[권한 필요]';
  if (key === 'content') return String(value).slice(0, 20) + (String(value).length > 20 ? '…' : '');
  return '[권한 필요]';
}

function formApplyMask_(rowObj) {
  if (formIsAdmin_()) return rowObj;
  const copied = Object.assign({}, rowObj || {});
  FORM_SENSITIVE_KEYS.forEach(k => {
    if (copied[k] !== undefined) copied[k] = formMaskValue_(k, copied[k]);
  });
  return copied;
}

function formListMasterMasked(limit) {
  const ss = formGetMasterSpreadsheet_();
  const sheet = formEnsureSheet_(ss, FORM_SHEETS.MASTER, FORM_REQUIRED_HEADERS.FORM_MASTER);
  const values = sheet.getDataRange().getValues();
  if (values.length < 2) return formResponse_(true, '접수 데이터가 없습니다.', []);
  const headers = values[0].map(String);
  const rows = values.slice(1).slice(-(Number(limit) || 50)).map(row => {
    const obj = {};
    headers.forEach((h, i) => obj[h] = row[i]);
    return formApplyMask_(obj);
  });
  return formResponse_(true, 'FORM MASTER 목록', rows);
}


function formRequestApproval(requestId, approvalType, reason) {
  formExecutionLog_('START', 'formRequestApproval', null);
  try {
    const ss = formGetMasterSpreadsheet_();
    const sheet = formEnsureSheet_(ss, FORM_SHEETS.APPROVAL, FORM_REQUIRED_HEADERS.FORM_APPROVAL);
    const type = approvalType || 'FORM_REOPEN_OR_SENSITIVE_ACTION';
    const isReopenType = ['FORM_REOPEN_REQUEST','FORM_REOPEN_APPROVAL'].indexOf(String(type || '')) !== -1;
    if (isReopenType && requestId) {
      const values = sheet.getDataRange().getValues();
      if (values.length > 1) {
        const map = formHeaderMap_(values[0].map(String));
        for (let i = 1; i < values.length; i++) {
          const sameRequest = String(map.requestId == null ? '' : values[i][map.requestId]) === String(requestId);
          const sameTarget = String(map.targetId == null ? '' : values[i][map.targetId]) === String(requestId);
          const sameType = String(map.approvalType == null ? '' : values[i][map.approvalType]) === String(type);
          const status = String(map.approvalStatus == null ? '' : values[i][map.approvalStatus]);
          if ((sameRequest || sameTarget) && sameType && ['PENDING','APPROVED'].indexOf(status) !== -1) {
            return formExecutionReturn_('formRequestApproval', formResponse_(false, '이미 처리 대기 또는 승인 완료된 재오픈 승인요청이 있습니다.', {
              requestId: requestId,
              approvalId: map.approvalId == null ? '' : values[i][map.approvalId],
              approvalStatus: status
            }, 'DUPLICATE_APPROVAL_REQUEST'));
          }
        }
      }
    }
    const approvalId = formUuid_('APR');
    const now = formNow_();
    formAppendByHeader_(sheet, {
      approvalId: approvalId,
      requestId: requestId,
      approvalType: type,
      targetId: requestId,
      targetSheet: FORM_SHEETS.MASTER,
      requestedBy: formUser_(),
      requestedAt: now,
      approvalStatus: 'PENDING',
      approvalReason: reason || '',
      approvedBy: '',
      approvedAt: '',
      createdAt: now,
      createdBy: formUser_(),
      updatedAt: now,
      updatedBy: formUser_()
    });
    formWriteLog_('APPROVAL_REQUEST', requestId, FORM_SHEETS.APPROVAL, '', approvalId, reason || '승인 요청');
    return formExecutionReturn_('formRequestApproval', formResponse_(true, '승인 요청 등록 완료', { approvalId: approvalId, requestId: requestId }));
  } catch (err) {
    return formExecutionError_('formRequestApproval', err, { requestId: requestId, approvalType: approvalType || '' }, 'APPROVAL_REQUEST_FAILED');
  }
}


function formApproveRequest(approvalId, approve, reason) {
  formExecutionLog_('START', 'formApproveRequest', null);
  try {
    if (!formIsAdmin_()) return formExecutionReturn_('formApproveRequest', formResponse_(false, '승인 권한이 없습니다.', { approvalId: approvalId }, 'PERMISSION_DENIED'));
    const ss = formGetMasterSpreadsheet_();
    const sheet = formEnsureSheet_(ss, FORM_SHEETS.APPROVAL, FORM_REQUIRED_HEADERS.FORM_APPROVAL);
    const found = formFindRowById_(sheet, 'approvalId', approvalId);
    if (!found) return formExecutionReturn_('formApproveRequest', formResponse_(false, '승인 요청을 찾을 수 없습니다.', { approvalId: approvalId }, 'APPROVAL_NOT_FOUND'));
    const currentStatus = String(found.map.approvalStatus == null ? '' : found.row[found.map.approvalStatus]);
    if (currentStatus === 'USED') {
      return formExecutionReturn_('formApproveRequest', formResponse_(false, '이미 사용 완료된 승인 요청입니다.', { approvalId: approvalId, approvalStatus: currentStatus }, 'APPROVAL_ALREADY_USED'));
    }
    const status = approve ? 'APPROVED' : 'REJECTED';
    formUpdateRowByHeader_(sheet, found.rowIndex, {
      approvalStatus: status,
      approvalReason: reason || '',
      approvedBy: formUser_(),
      approvedAt: formNow_(),
      updatedAt: formNow_(),
      updatedBy: formUser_()
    });
    formWriteLog_('APPROVAL_' + status, approvalId, FORM_SHEETS.APPROVAL, currentStatus || 'PENDING', status, reason || '');
    return formExecutionReturn_('formApproveRequest', formResponse_(true, '승인 처리 완료', { approvalId: approvalId, status: status }));
  } catch (err) {
    return formExecutionError_('formApproveRequest', err, { approvalId: approvalId, approve: approve === true }, 'APPROVAL_PROCESS_FAILED');
  }
}

function formApprovalFilterMatches_(row, filter) {
  const f = filter || {};
  if (f.requestId && String(row.requestId || '') !== String(f.requestId)) return false;
  if (f.approvalId && String(row.approvalId || '') !== String(f.approvalId)) return false;
  if (f.approvalStatus && String(row.approvalStatus || '') !== String(f.approvalStatus)) return false;
  if (f.approvalType && String(row.approvalType || '') !== String(f.approvalType)) return false;
  if (f.reopenOnly === true && ['FORM_REOPEN_REQUEST','FORM_REOPEN_APPROVAL'].indexOf(String(row.approvalType || '')) === -1) return false;
  return true;
}

function formListApprovalsMasked(limit, filter) {
  formExecutionLog_('START', 'formListApprovalsMasked', null);
  try {
    const ss = formGetMasterSpreadsheet_();
    const sheet = formEnsureSheet_(ss, FORM_SHEETS.APPROVAL, FORM_REQUIRED_HEADERS.FORM_APPROVAL);
    const values = sheet.getDataRange().getValues();
    if (values.length < 2) return formExecutionReturn_('formListApprovalsMasked', formResponse_(true, '승인 요청 데이터가 없습니다.', []));
    const headers = values[0].map(String);
    const map = formHeaderMap_(headers);
    const rows = [];
    for (let i = 1; i < values.length; i++) {
      const obj = {};
      headers.forEach((h, idx) => obj[h] = values[i][idx]);
      if (formApprovalFilterMatches_(obj, filter || {})) rows.push(formApplyMask_(obj));
    }
    rows.reverse();
    const max = Math.max(1, Math.min(Number(limit) || 50, 200));
    return formExecutionReturn_('formListApprovalsMasked', formResponse_(true, rows.length ? '승인 요청 목록' : '조건에 맞는 승인 요청이 없습니다.', rows.slice(0, max), '', {
      filter: filter || {},
      totalMatched: rows.length,
      masked: !formIsAdmin_()
    }));
  } catch (err) {
    return formExecutionError_('formListApprovalsMasked', err, { limit: limit || '', filter: filter || {} }, 'APPROVAL_LIST_FAILED');
  }
}

function formGetApprovalSummary() {
  formExecutionLog_('START', 'formGetApprovalSummary', null);
  try {
    const ss = formGetMasterSpreadsheet_();
    const sheet = formEnsureSheet_(ss, FORM_SHEETS.APPROVAL, FORM_REQUIRED_HEADERS.FORM_APPROVAL);
    const values = sheet.getDataRange().getValues();
    const summary = {
      total: Math.max(0, values.length - 1),
      pending: 0,
      approved: 0,
      rejected: 0,
      used: 0,
      reopenTotal: 0,
      reopenPending: 0,
      reopenApproved: 0,
      reopenUsed: 0,
      sensitiveMasked: !formIsAdmin_()
    };
    if (values.length > 1) {
      const map = formHeaderMap_(values[0].map(String));
      for (let i = 1; i < values.length; i++) {
        const status = String(map.approvalStatus == null ? '' : values[i][map.approvalStatus]);
        const type = String(map.approvalType == null ? '' : values[i][map.approvalType]);
        if (status === 'PENDING') summary.pending++;
        else if (status === 'APPROVED') summary.approved++;
        else if (status === 'REJECTED') summary.rejected++;
        else if (status === 'USED') summary.used++;
        if (['FORM_REOPEN_REQUEST','FORM_REOPEN_APPROVAL'].indexOf(type) !== -1) {
          summary.reopenTotal++;
          if (status === 'PENDING') summary.reopenPending++;
          else if (status === 'APPROVED') summary.reopenApproved++;
          else if (status === 'USED') summary.reopenUsed++;
        }
      }
    }
    const recent = formListApprovalsMasked(10, { reopenOnly: true });
    return formExecutionReturn_('formGetApprovalSummary', formResponse_(true, 'FORM B14 승인/재오픈 요약', Object.assign({}, summary, {
      recentReopenApprovals: recent && recent.ok ? (recent.data || []) : []
    })));
  } catch (err) {
    return formExecutionError_('formGetApprovalSummary', err, null, 'APPROVAL_SUMMARY_FAILED');
  }
}

function formApprovalDateValue_(value) {
  if (!value) return 0;
  if (value instanceof Date) return value.getTime();
  const d = new Date(value);
  return isNaN(d.getTime()) ? 0 : d.getTime();
}

function formGetApprovalDiagnostics() {
  formExecutionLog_('START', 'formGetApprovalDiagnostics', null);
  try {
    const ss = formGetMasterSpreadsheet_();
    const sheet = formEnsureSheet_(ss, FORM_SHEETS.APPROVAL, FORM_REQUIRED_HEADERS.FORM_APPROVAL);
    const values = sheet.getDataRange().getValues();
    const now = formNow_();
    const diagnostics = {
      total: Math.max(0, values.length - 1),
      pending: 0,
      approved: 0,
      rejected: 0,
      used: 0,
      reopenPending: 0,
      reopenApproved: 0,
      reopenUsed: 0,
      stalePending: 0,
      staleHours: 24,
      approvalTypes: {},
      latestRequestedAt: '',
      latestApprovedAt: '',
      diagnosticOnly: true,
      approvalWriteExecuted: false,
      sensitiveMasked: !formIsAdmin_()
    };
    const recent = [];
    if (values.length > 1) {
      const headers = values[0].map(String);
      const map = formHeaderMap_(headers);
      for (let i = 1; i < values.length; i++) {
        const obj = {};
        headers.forEach((h, idx) => obj[h] = values[i][idx]);
        const status = String(obj.approvalStatus || '');
        const type = String(obj.approvalType || '');
        const requestedTime = formApprovalDateValue_(obj.requestedAt || obj.createdAt);
        const approvedTime = formApprovalDateValue_(obj.approvedAt);
        const isReopen = ['FORM_REOPEN_REQUEST','FORM_REOPEN_APPROVAL'].indexOf(type) !== -1;
        if (status === 'PENDING') diagnostics.pending++;
        else if (status === 'APPROVED') diagnostics.approved++;
        else if (status === 'REJECTED') diagnostics.rejected++;
        else if (status === 'USED') diagnostics.used++;
        if (isReopen && status === 'PENDING') diagnostics.reopenPending++;
        else if (isReopen && status === 'APPROVED') diagnostics.reopenApproved++;
        else if (isReopen && status === 'USED') diagnostics.reopenUsed++;
        if (type) diagnostics.approvalTypes[type] = (diagnostics.approvalTypes[type] || 0) + 1;
        if (requestedTime && requestedTime >= formApprovalDateValue_(diagnostics.latestRequestedAt)) diagnostics.latestRequestedAt = obj.requestedAt || obj.createdAt;
        if (approvedTime && approvedTime >= formApprovalDateValue_(diagnostics.latestApprovedAt)) diagnostics.latestApprovedAt = obj.approvedAt;
        if (status === 'PENDING' && requestedTime && (now.getTime() - requestedTime) > diagnostics.staleHours * 60 * 60 * 1000) diagnostics.stalePending++;
        if (status === 'PENDING' || status === 'APPROVED' || isReopen) recent.push(obj);
      }
    }
    recent.sort((a, b) => formApprovalDateValue_(b.updatedAt || b.requestedAt || b.createdAt) - formApprovalDateValue_(a.updatedAt || a.requestedAt || a.createdAt));
    diagnostics.recentApprovals = recent.slice(0, 20).map(row => formApplyMask_(row));
    diagnostics.recentApprovalCount = diagnostics.recentApprovals.length;
    return formExecutionReturn_('formGetApprovalDiagnostics', formResponse_(true, 'FORM B14 승인 진단 요약', diagnostics));
  } catch (err) {
    return formExecutionError_('formGetApprovalDiagnostics', err, null, 'APPROVAL_DIAGNOSTICS_FAILED');
  }
}

