function formResponse_(ok, message, data, errorCode, meta) {
  return {
    ok: !!ok,
    message: message || '',
    data: data || null,
    errorCode: errorCode || '',
    meta: Object.assign({ build: FORM_BUILD, timestamp: new Date().toISOString() }, meta || {})
  };
}

function formNow_() {
  return new Date();
}

function formUser_() {
  try {
    return Session.getActiveUser().getEmail() || 'unknown';
  } catch (err) {
    return 'unknown';
  }
}

function formLogMaskPhone_(value) {
  const digits = String(value == null ? '' : value).replace(/[^0-9]/g, '');
  if (!digits) return value;
  if (digits.length <= 7) return digits.slice(0, 3) + '****';
  return digits.slice(0, 3) + '****' + digits.slice(-4);
}

function formLogRedact_(value, key, seen) {
  if (value === null || value === undefined) return value;
  const lowerKey = String(key || '').toLowerCase();
  if (value instanceof Date) return value.toISOString();
  if (value instanceof Error) return { message: value.message, stack: String(value.stack || '').split('\n').slice(0, 3).join('\n') };
  if (typeof value !== 'object') {
    if (lowerKey === 'phone') return formLogMaskPhone_(value);
    if (lowerKey === 'rawpayload') return '[RAW_PAYLOAD_HIDDEN]';
    if (lowerKey === 'content' || lowerKey === 'memo') return String(value).slice(0, 80);
    return value;
  }
  seen = seen || [];
  if (seen.indexOf(value) !== -1) return '[CIRCULAR]';
  seen.push(value);
  if (Array.isArray(value)) {
    const arr = value.slice(0, 30).map(v => formLogRedact_(v, key, seen));
    seen.pop();
    return arr;
  }
  const out = {};
  Object.keys(value).slice(0, 80).forEach(k => out[k] = formLogRedact_(value[k], k, seen));
  seen.pop();
  return out;
}

function formLogStringify_(value) {
  try {
    const text = JSON.stringify(formLogRedact_(value), null, 2);
    return text.length > 6000 ? text.slice(0, 6000) + '...[TRUNCATED]' : text;
  } catch (err) {
    return String(value);
  }
}

function formExecutionFileName_(functionName) {
  const map = {
    formEnsureAllSheets: 'FORM_Core.js',
    formInternalTest_B44: 'FORM_Test.js',
    formSmoke_B44: 'FORM_Test.js',
    formInternalTest_B45: 'FORM_Test.js',
    formSmoke_B45: 'FORM_Test.js',
    formInternalTest_B46: 'FORM_Test.js',
    formSmoke_B46: 'FORM_Test.js',
    doGet: 'FORM_WebApp.js',
    doPost: 'FORM_WebApp.js',
    formGetDashboard: 'FORM_WebApp.js',
    formGetFieldPanel: 'FORM_WebApp.js',
    formGetFieldPanelFiltered: 'FORM_WebApp.js',
    formListRequestsFiltered: 'FORM_WebApp.js',
    formGetRequestListSummary: 'FORM_WebApp.js',
    formGetRequestDetail: 'FORM_WebApp.js',
    formListRequestTimeline: 'FORM_WebApp.js',
    formListRequestAttachments: 'FORM_WebApp.js',
    formListRequestDocuments: 'FORM_WebApp.js',
    formGetRequestEvidence: 'FORM_WebApp.js',
    formListRequestMemos: 'FORM_WebApp.js',
    formGetRequestMemoSummary: 'FORM_WebApp.js',
    formGetMemoAuditSummary: 'FORM_WebApp.js',
    formCreateQRIntake: 'FORM_QR.js',
    formReceiveExternal: 'FORM_Intake.js',
    formReceiveCafeForm: 'FORM_Intake.js',
    formReceiveAsRequest: 'FORM_Intake.js',
    formReceiveClaimRefund: 'FORM_Intake.js',
    formSubmitFromUi: 'FORM_WebApp.js',
    formListRetryQueue: 'FORM_ErpLink.js',
    formGetRetrySummary: 'FORM_ErpLink.js',
    formGetRetryDiagnostics: 'FORM_ErpLink.js',
    formRetryRequest: 'FORM_ErpLink.js',
    formLinkToErp: 'FORM_ErpLink.js',
    formChangeStatus: 'FORM_State.js',
    formAssignRequest: 'FORM_State.js',
    formReopenRequest: 'FORM_State.js',
    formListReopenHistory: 'FORM_State.js',
    formAddRequestMemo: 'FORM_State.js',
    formRejectRequestMemoUpdate: 'FORM_State.js',
    formRejectRequestMemoDelete: 'FORM_State.js',
    formRequestApproval: 'FORM_Security.js',
    formApproveRequest: 'FORM_Security.js',
    formListApprovalsMasked: 'FORM_Security.js',
    formGetApprovalSummary: 'FORM_Security.js',
    formGetApprovalDiagnostics: 'FORM_Security.js',
    formGetPortalSummary: 'FORM_Portal.js',
    formGetDemandFormCenterPayload: 'FORM_WebApp.js',
    formGetDemandFormConfig: 'FORM_WebApp.js',
    formSaveDemandFormConfig: 'FORM_WebApp.js',
    formSubmitDemandSurvey: 'FORM_WebApp.js',
    formDemandLookupRequest: 'FORM_WebApp.js',
    formListDemandSurveyRecent: 'FORM_WebApp.js',
    formGenerateDemandSurveyPdfReport: 'FORM_WebApp.js',
    formListApartmentsFromErpEvent: 'FORM_WebApp.js',
    formInternalTest_B47: 'FORM_Test.js',
    formSmoke_B47: 'FORM_Test.js'
  };
  return map[String(functionName || '')] || 'UNKNOWN_FILE';
}

function formExecutionLog_(phase, functionName, value) {
  const fileName = formExecutionFileName_(functionName);
  const msg = '[FORM_EXEC] ' + String(phase || 'RUN') + ' | ' + String(functionName || '') + ' | ' + fileName;
  try { Logger.log(msg); } catch (err) {}
}

function formExecutionReturn_(functionName, result) {
  formExecutionLog_('END', functionName, null);
  return result;
}

function formExecutionError_(functionName, err, data, errorCode) {
  const result = formResponse_(false, err && err.message ? err.message : String(err), data || null, errorCode || 'EXECUTION_FAILED');
  formExecutionLog_('ERROR', functionName, null);
  return result;
}


function formUuid_(prefix) {
  const stamp = Utilities.formatDate(new Date(), 'Asia/Seoul', 'yyyyMMddHHmmss');
  const random = Utilities.getUuid().replace(/-/g, '').slice(0, 10).toUpperCase();
  return String(prefix || 'ID') + '_' + stamp + '_' + random;
}

function formHeaderMap_(headers) {
  const map = {};
  (headers || []).forEach((h, i) => {
    const key = String(h || '').trim();
    if (key) map[key] = i;
  });
  return map;
}

function formEnsureSheet_(ss, sheetName, headers) {
  let sheet = ss.getSheetByName(sheetName);
  if (!sheet) sheet = ss.insertSheet(sheetName);

  const lastColumn = sheet.getLastColumn();
  const firstRow = lastColumn ? sheet.getRange(1, 1, 1, lastColumn).getValues()[0] : [];
  const existing = firstRow.map(String).filter(Boolean);

  if (existing.length === 0) {
    sheet.getRange(1, 1, 1, headers.length).setValues([headers]);
    sheet.setFrozenRows(1);
    return sheet;
  }

  const map = formHeaderMap_(existing);
  const missing = headers.filter(h => map[h] == null);
  if (missing.length) {
    // FORM_* 버퍼 시트만 보정 허용. ERP/SIGN 원본 헤더 자동 추가는 금지.
    if (String(sheetName).indexOf('FORM_') !== 0) {
      throw new Error('원본 시트 헤더 자동 추가 금지: ' + sheetName + ' / missing=' + missing.join(','));
    }
    sheet.getRange(1, existing.length + 1, 1, missing.length).setValues([missing]);
  }
  sheet.setFrozenRows(1);
  return sheet;
}


function formEnsureAllSheets() {
  formExecutionLog_('START', 'formEnsureAllSheets', { build: FORM_BUILD });
  try {
    const ss = formGetMasterSpreadsheet_();
    Object.keys(FORM_REQUIRED_HEADERS).forEach(name => formEnsureSheet_(ss, name, FORM_REQUIRED_HEADERS[name]));
    if (typeof formNormalizeDemandReportSheet_ === 'function') formNormalizeDemandReportSheet_(ss.getSheetByName(FORM_SHEETS.DEMAND_REPORT));
    formWriteLog_('SYSTEM_INIT', 'FORM_CENTER', 'FEELHAUS_DB_MASTER', '', 'FORM sheets ensured', 'FORM full install');
    return formExecutionReturn_('formEnsureAllSheets', formResponse_(true, 'FORM B44 SAFE MODE 기본 시트 점검 완료', { sheets: Object.keys(FORM_REQUIRED_HEADERS) }));
  } catch (err) {
    return formExecutionError_('formEnsureAllSheets', err, null, 'SHEET_INIT_FAILED');
  }
}

function formAppendByHeader_(sheet, record) {
  const headers = sheet.getRange(1, 1, 1, Math.max(1, sheet.getLastColumn())).getValues()[0].map(String);
  const row = headers.map(h => record[h] !== undefined ? record[h] : '');
  sheet.appendRow(row);
  return row;
}

function formFindRowById_(sheet, idHeader, idValue) {
  const values = sheet.getDataRange().getValues();
  if (values.length < 2) return null;
  const map = formHeaderMap_(values[0].map(String));
  const col = map[idHeader];
  if (col == null) throw new Error('필수 헤더 누락: ' + idHeader);
  for (let r = 1; r < values.length; r++) {
    if (String(values[r][col]) === String(idValue)) return { rowIndex: r + 1, row: values[r], map: map };
  }
  return null;
}

function formUpdateRowByHeader_(sheet, rowIndex, patch) {
  const headers = sheet.getRange(1, 1, 1, sheet.getLastColumn()).getValues()[0].map(String);
  const map = formHeaderMap_(headers);
  Object.keys(patch).forEach(key => {
    if (map[key] != null) sheet.getRange(rowIndex, map[key] + 1).setValue(patch[key]);
  });
}

function formRowObject_(row, map) {
  const obj = {};
  Object.keys(map || {}).forEach(k => obj[k] = row[map[k]]);
  return obj;
}

function formWriteLog_(actionType, targetId, targetSheet, beforeValue, afterValue, reason, approvedBy) {
  const ss = formGetMasterSpreadsheet_();
  const sheet = formEnsureSheet_(ss, FORM_SHEETS.LOG, FORM_REQUIRED_HEADERS.FORM_LOG);
  formAppendByHeader_(sheet, {
    logId: formUuid_('LOG'),
    actionType: actionType,
    targetId: targetId,
    targetSheet: targetSheet,
    actor: formUser_(),
    beforeValue: beforeValue || '',
    afterValue: afterValue || '',
    reason: reason || '',
    approvedBy: approvedBy || '',
    documentNo: '',
    createdAt: formNow_()
  });
}

function formWriteTimeline_(requestId, status, reason, memo) {
  const ss = formGetMasterSpreadsheet_();
  const sheet = formEnsureSheet_(ss, FORM_SHEETS.TIMELINE, FORM_REQUIRED_HEADERS.FORM_TIMELINE);
  formAppendByHeader_(sheet, {
    logId: formUuid_('TL'),
    requestId: requestId,
    status: status,
    statusReason: reason || '',
    actor: formUser_(),
    memo: memo || '',
    createdAt: formNow_()
  });
}

function formAssertRequired_(payload, required) {
  const missing = required.filter(k => payload[k] === undefined || payload[k] === null || String(payload[k]).trim() === '');
  if (missing.length) throw new Error('필수값 누락: ' + missing.join(', '));
}
