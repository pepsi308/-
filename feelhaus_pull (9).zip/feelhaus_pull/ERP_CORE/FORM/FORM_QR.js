function formCreateQRIntake(payload) {
  formExecutionLog_('START', 'formCreateQRIntake', null);
  try {
    const raw = Object.assign({}, payload || {});
    formAssertRequired_(raw, ['phone']);

    const ss = formGetMasterSpreadsheet_();
    const rawSheet = formEnsureSheet_(ss, FORM_SHEETS.RAW, FORM_REQUIRED_HEADERS.FORM_RAW);
    const masterSheet = formEnsureSheet_(ss, FORM_SHEETS.MASTER, FORM_REQUIRED_HEADERS.FORM_MASTER);
    const requestId = raw.requestId || formUuid_('REQ');
    const now = formNow_();
    const actor = formUser_();
    const memberType = raw.memberType || (raw.isMember === true ? 'REGULAR' : 'ASSOCIATE');
    const customerName = raw.customerName || raw.name || '';
    const hosu = raw.hosu || raw.ho || '';

    if (memberType === 'REGULAR' && (!raw.dong || !hosu)) {
      throw new Error('정회원 QR 접수는 동/호수 검색값이 필요합니다.');
    }
    if (memberType !== 'REGULAR') {
      formAssertRequired_({ customerName: customerName, phone: raw.phone }, ['customerName','phone']);
    }

    const rawRecord = {
      requestId: requestId,
      sourceType: 'QR',
      formType: 'QR_CUSTOMER',
      memberType: memberType,
      eventId: raw.eventId || '',
      vendorId: raw.vendorId || '',
      customerId: raw.customerId || '',
      saleId: raw.saleId || '',
      contractId: raw.contractId || '',
      installId: raw.installId || '',
      asId: raw.asId || '',
      documentId: '',
      attachmentId: raw.attachmentId || '',
      customerName: customerName,
      phone: raw.phone || '',
      dong: raw.dong || '',
      hosu: hosu,
      title: raw.title || 'QR 고객 등록',
      content: raw.content || raw.memo || '',
      rawPayload: JSON.stringify(raw),
      status: FORM_STATUS.QR_RECEIVED,
      statusReason: 'QR 고객 접수 원본 보존',
      retryCount: 0,
      createdAt: now,
      createdBy: actor,
      updatedAt: now,
      updatedBy: actor
    };
    formAppendByHeader_(rawSheet, rawRecord);

    const masterRecord = {
      requestId: requestId,
      sourceType: 'QR',
      workType: FORM_WORK_TYPES.QR_CUSTOMER,
      memberType: memberType,
      eventId: raw.eventId || '',
      vendorId: raw.vendorId || '',
      customerId: raw.customerId || '',
      saleId: raw.saleId || '',
      contractId: raw.contractId || '',
      installId: raw.installId || '',
      asId: raw.asId || '',
      documentId: '',
      attachmentId: raw.attachmentId || '',
      candidateStatus: '',
      priority: 'NORMAL',
      assignedTo: '',
      scheduledAt: '',
      status: FORM_STATUS.QR_RECEIVED,
      statusReason: 'QR 접수 / ERP·SIGN 원본 저장 차단',
      erpLinkedAt: '',
      createdAt: now,
      createdBy: actor,
      updatedAt: now,
      updatedBy: actor
    };
    formAppendByHeader_(masterSheet, masterRecord);
    formWriteTimeline_(requestId, FORM_STATUS.QR_RECEIVED, 'QR 고객 접수', memberType);
    formWriteLog_('QR_RECEIVE', requestId, FORM_SHEETS.RAW, '', JSON.stringify(rawRecord), 'QR 고객 등록 버퍼 접수');

    const candidate = formResolveCustomerCandidate(rawRecord);
    const customerBufferId = formSaveCustomerCandidateBuffer_(requestId, rawRecord, candidate);
    const doc = formCreateDocumentCandidate(requestId, rawRecord, candidate);

    const finalStatus = candidate.status === FORM_STATUS.DUPLICATE_CANDIDATE ? FORM_STATUS.DUPLICATE_CANDIDATE : FORM_STATUS.DOCUMENT_READY;
    formUpdateRowByHeader_(masterSheet, formFindRowById_(masterSheet, 'requestId', requestId).rowIndex, {
      customerId: candidate.customerId || '',
      documentId: doc.documentId || '',
      candidateStatus: candidate.status,
      status: finalStatus,
      statusReason: 'customerId/documentId 후보 생성 완료 / 실제 저장 차단',
      updatedAt: formNow_(),
      updatedBy: actor
    });

    formWriteTimeline_(requestId, finalStatus, 'QR 고객 후보 및 SIGN 문서 후보 생성', JSON.stringify({ customerBufferId: customerBufferId, documentCandidateId: doc.documentCandidateId }));
    formWriteLog_('QR_BUFFER_READY', requestId, FORM_SHEETS.MASTER, '', JSON.stringify({ candidate: candidate, document: doc }), 'ERP/SIGN 원본 저장 차단');

    return formExecutionReturn_('formCreateQRIntake', formResponse_(true, 'QR 고객 등록 버퍼 생성 완료 / ERP·SIGN 실제 저장 차단', {
      requestId: requestId,
      memberType: memberType,
      candidate: candidate,
      customerBufferId: customerBufferId,
      document: doc,
      dryRunOnly: true,
      blocked: {
        erpWrite: true,
        signWrite: true,
        settlementWrite: true,
        externalSync: true
      }
    }));
  } catch (err) {
    return formExecutionError_('formCreateQRIntake', err, { payload: payload || {} }, 'QR_CUSTOMER_BUFFER_FAILED');
  }
}

function formSearchRegularMemberByDongHosu(dong, hosu, eventId) {
  try {
    const ss = formGetMasterSpreadsheet_();
    const sheet = ss.getSheetByName('ERP_고객관리');
    if (!sheet || sheet.getLastRow() < 2) return formResponse_(true, '검색 결과가 없습니다.', []);
    const values = sheet.getDataRange().getValues();
    const headers = values[0].map(String);
    const map = formHeaderMap_(headers);
    const result = [];
    for (let i = 1; i < values.length; i++) {
      const rowDong = String(map.dong == null ? '' : values[i][map.dong]).trim();
      const rowHosu = String(map.hosu == null ? (map.ho == null ? '' : values[i][map.ho]) : values[i][map.hosu]).trim();
      const rowEventId = String(map.eventId == null ? '' : values[i][map.eventId]).trim();
      const eventOk = !eventId || !rowEventId || String(eventId) === rowEventId;
      if (rowDong === String(dong).trim() && rowHosu === String(hosu).trim() && eventOk) {
        const obj = {};
        headers.forEach((h, idx) => obj[h] = values[i][idx]);
        result.push(formApplyMask_(obj));
      }
    }
    return formResponse_(true, result.length ? '정회원 동/호수 검색 결과' : '검색 결과가 없습니다.', result);
  } catch (err) {
    return formResponse_(false, err.message, null, 'REGULAR_MEMBER_SEARCH_FAILED');
  }
}
