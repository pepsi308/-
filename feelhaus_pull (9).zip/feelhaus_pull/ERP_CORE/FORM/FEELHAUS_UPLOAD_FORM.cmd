@echo off
setlocal EnableExtensions
title FEELHAUS UPLOAD FORM

cd /d D:\pepsi308\OneDrive\feelhaus_pull\FORM
if errorlevel 1 (
  echo [ERROR] FORM folder not found.
  pause
  exit /b 1
)

if not exist ".clasp.json" (
  echo [ERROR] .clasp.json not found in FORM.
  pause
  exit /b 1
)

echo ==========================================
echo FORM upload start
echo Current folder:
cd
echo ==========================================
echo.

clasp.cmd push 
set RC=%ERRORLEVEL%

echo.
echo ==========================================
if %RC%==0 (
  echo [OK] FORM upload complete
) else (
  echo [ERROR] FORM upload failed
  echo ERRORLEVEL=%RC%
)
echo ==========================================
echo.

pause
