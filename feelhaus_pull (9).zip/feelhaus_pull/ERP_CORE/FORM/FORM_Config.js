/**
 * FEELHAUS FORM SIGN/ERP B48-7 SAFE MODE COMPLETE MOBILE B48-5 PC SPLIT FIX CONFIG
 * Build: FORM_B48-14_SAFE_MODE_COMPLETE_TEST_ALIAS_SUBMIT_ICON_UP
 * Safe mode: ERP/SIGN original write blocked. Buffer/DryRun only.
 */
const FORM_BUILD = 'FORM_B48-14_SAFE_MODE_COMPLETE_TEST_ALIAS_SUBMIT_ICON_UP';
const SETUP_DB_ID = '17VMSpgSZCvIrUlgcw8yCNcnl8WQWo2IcRf5tDCcuJGM';
const CONFIG_SHEET_NAME = 'SystemConfig';
const SOURCE_DB = 'FEELHAUS_SETUP_DB';

const FORM_SAFE_MODE = Object.freeze({
  ERP_WRITE_ALLOWED: false,
  SIGN_WRITE_ALLOWED: false,
  EXTERNAL_SYNC_ALLOWED: false,
  SETTLEMENT_WRITE_ALLOWED: false,
  ORIGINAL_HEADER_AUTO_ADD_ALLOWED: false
});

const FORM_SHEETS = Object.freeze({
  RAW: 'FORM_RAW',
  MASTER: 'FORM_MASTER',
  CUSTOMER_BUFFER: 'FORM_CUSTOMER_BUFFER',
  DOCUMENT_BUFFER: 'FORM_DOCUMENT_BUFFER',
  RETRY: 'FORM_RETRY',
  LOG: 'FORM_LOG',
  TIMELINE: 'FORM_TIMELINE',
  ATTACH: 'FORM_ATTACH',
  REPORT: 'FORM_REPORT',
  APPROVAL: 'FORM_APPROVAL',
  DEMAND_CONFIG: 'FORM_DEMAND_FORM_CONFIG',
  DEMAND_REPORT: 'FORM_DEMAND_SURVEY_REPORT',
  DEMAND_PDF_REPORT: 'FORM_DEMAND_PDF_REPORT'
});

const FORM_REQUIRED_HEADERS = Object.freeze({
  FORM_RAW: [
    'requestId','sourceType','formType','memberType','eventId','vendorId','customerId','saleId','contractId','installId','asId','documentId','attachmentId',
    'customerName','phone','dong','hosu','title','content','rawPayload','status','statusReason','retryCount','createdAt','createdBy','updatedAt','updatedBy'
  ],
  FORM_MASTER: [
    'requestId','sourceType','workType','memberType','eventId','vendorId','customerId','saleId','contractId','installId','asId','documentId','attachmentId',
    'candidateStatus','priority','assignedTo','scheduledAt','status','statusReason','erpLinkedAt','createdAt','createdBy','updatedAt','updatedBy'
  ],
  FORM_CUSTOMER_BUFFER: [
    'bufferId','requestId','customerCandidateId','customerId','candidateStatus','memberType','eventId','vendorId','customerName','phone','dong','hosu',
    'duplicateCount','duplicateJson','dryRunOnly','approvalStatus','createdAt','createdBy','updatedAt','updatedBy'
  ],
  FORM_DOCUMENT_BUFFER: [
    'bufferId','requestId','documentCandidateId','documentId','customerId','eventId','vendorId','documentType','documentStatus','signUrl','qrUrl',
    'dryRunOnly','approvalStatus','createdAt','createdBy','updatedAt','updatedBy'
  ],
  FORM_RETRY: [
    'requestId','sourceType','workType','targetSheet','errorCode','message','retryStatus','retryCount','lastTriedAt','createdAt','createdBy','updatedAt','updatedBy'
  ],
  FORM_LOG: [
    'logId','actionType','targetId','targetSheet','actor','beforeValue','afterValue','reason','approvedBy','documentNo','createdAt'
  ],
  FORM_TIMELINE: [
    'logId','requestId','status','statusReason','actor','memo','createdAt'
  ],
  FORM_ATTACH: [
    'attachmentId','requestId','documentId','fileName','fileUrl','fileType','status','createdAt','createdBy','updatedAt','updatedBy'
  ],
  FORM_REPORT: [
    'reportId','reportDate','sourceType','workType','status','count','createdAt','createdBy'
  ],
  FORM_APPROVAL: [
    'approvalId','requestId','approvalType','targetId','targetSheet','requestedBy','requestedAt','approvalStatus','approvalReason','approvedBy','approvedAt','createdAt','createdBy','updatedAt','updatedBy'
  ],

  FORM_DEMAND_SURVEY_REPORT: [
    'requestId','eventId','apartmentName','dong','hosu','dongHosu','selectedItems','interestLevel','requestMemo',
    'duplicate','duplicateRequestId','surveyStatus','createdAt','updatedAt','reportSummary','build'
  ],
  FORM_DEMAND_PDF_REPORT: [
    'reportId','eventId','apartmentName','reportTitle','responseCount','householdCount','duplicateCount','topItem','pdfFolderId','pdfFolderUrl','pdfFileId','pdfUrl','downloadUrl','createdAt','createdBy','build'
  ],
  FORM_DEMAND_FORM_CONFIG: [
    'surveyId','eventId','apartmentName','apartmentKey','eventName','eventPlace','startDate','endDate','vendorId',
    'itemPresetCode','baseItems','enabledItems','disabledItems','customItems','selectedItems',
    'noticeText','warningText','privacyConsentText','marketingConsentText','shareTitle','shareMessage','shortLink','qrUrl',
    'configStatus','configVersion','createdAt','createdBy','updatedAt','updatedBy'
  ]
});

const FORM_STATUS = Object.freeze({
  RECEIVED: 'RECEIVED',
  QR_RECEIVED: 'QR_RECEIVED',
  NORMALIZED: 'NORMALIZED',
  MATCHED: 'MATCHED',
  DUPLICATE_CANDIDATE: 'DUPLICATE_CANDIDATE',
  NEW_CANDIDATE: 'NEW_CANDIDATE',
  DOCUMENT_READY: 'DOCUMENT_READY',
  ERP_PENDING: 'ERP_PENDING',
  ERP_DRYRUN_BLOCKED: 'ERP_DRYRUN_BLOCKED',
  SIGN_DRYRUN_BLOCKED: 'SIGN_DRYRUN_BLOCKED',
  ERP_LINKED: 'ERP_LINKED',
  ASSIGNED: 'ASSIGNED',
  SCHEDULED: 'SCHEDULED',
  IN_PROGRESS: 'IN_PROGRESS',
  COMPLETED: 'COMPLETED',
  HOLD: 'HOLD',
  CANCELLED: 'CANCELLED',
  ERROR: 'ERROR',
  RETRY_PENDING: 'RETRY_PENDING',
  APPROVAL_PENDING: 'APPROVAL_PENDING'
});

const FORM_WORK_TYPES = Object.freeze({
  EXTERNAL: 'EXTERNAL_INTAKE',
  CAFE_FORM: 'CAFE_FORM',
  AS: 'AS_REQUEST',
  CLAIM_REFUND: 'CLAIM_REFUND',
  QR_CUSTOMER: 'QR_CUSTOMER',
  CUSTOMER_REGISTER: 'CUSTOMER_REGISTER',
  DEMAND_SURVEY: 'DEMAND_SURVEY'
});

const FORM_DEMAND_DEFAULT_ITEMS = Object.freeze([
  '줄눈','탄성코트','중문','커튼/블라인드','시스템에어컨','입주청소','새집증후군','방충망','욕실/나노코팅','조명','가전','가구','기타'
]);

const FORM_DEMAND_INTEREST_LEVELS = Object.freeze([
  '관심 있음','상담 받아보고 싶음','견적이 궁금함','행사 당일 방문 예정','아직 미정'
]);

function formGetSetupConfig_() {
  const setup = SpreadsheetApp.openById(SETUP_DB_ID);
  const sheet = setup.getSheetByName(CONFIG_SHEET_NAME);
  if (!sheet) throw new Error('SystemConfig 시트를 찾을 수 없습니다.');

  const values = sheet.getDataRange().getValues();
  if (values.length < 2) throw new Error('SystemConfig 데이터가 비어 있습니다.');

  const headers = values[0].map(String);
  const map = formHeaderMap_(headers);
  const config = {};

  values.slice(1).forEach(row => {
    const key = row[map.CONFIG_KEY] || row[map.configKey] || row[map.key] || row[0];
    const value = row[map.VALUE] || row[map.CONFIG_VALUE] || row[map.configValue] || row[map.value] || row[1];
    if (key !== '' && key != null) config[String(key).trim()] = value;
  });

  return config;
}

function formGetMasterSpreadsheet_() {
  const config = formGetSetupConfig_();
  const id = config.FEELHAUS_DB_MASTER_ID || config.MASTER_DB_ID || config.masterDbId || config.FEELHAUS_DB_MASTER;
  if (!id) throw new Error('SystemConfig에 FEELHAUS_DB_MASTER_ID가 없습니다.');
  return SpreadsheetApp.openById(String(id).trim());
}
