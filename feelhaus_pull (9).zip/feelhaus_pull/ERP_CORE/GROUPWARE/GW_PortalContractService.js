/**
 * B11 PORTAL Contract Service.
 * This file is the single module-side contract output for PORTAL registration review.
 * It does not render menus and must not be used as a standalone Shell.
 */
const GW_B11_MODULE_CODE = 'GROUPWARE';
const GW_B11_FORBIDDEN_UI_TERMS = Object.freeze(['iframe', 'preview', 'fragment', 'standalone', 'devshell', 'GW_DevShell']);

const GW_B11_PORTAL_MENU_CONTRACTS = Object.freeze([
  {
    moduleCode: 'GROUPWARE', menuId: 'gw.account', menuLabel: '내 계정 / 계정 설정',
    route: '/groupware/account', handler: 'gwHandleAccountBody', viewFile: 'GW_AccountBody.html',
    permissionCode: 'canAccessPortal', status: 'READY', sortOrder: 1100
  },
  {
    moduleCode: 'GROUPWARE', menuId: 'gw.users', menuLabel: '직원관리',
    route: '/groupware/users', handler: 'gwHandleUsersBody', viewFile: 'GW_UsersBody.html',
    permissionCode: 'canAccessDevConsole', status: 'READY', sortOrder: 1110
  },
  {
    moduleCode: 'GROUPWARE', menuId: 'gw.permissions', menuLabel: '권한관리',
    route: '/groupware/permissions', handler: 'gwHandlePermissionsBody', viewFile: 'GW_PermissionsBody.html',
    permissionCode: 'canAccessDevConsole', status: 'READY', sortOrder: 1120
  },
  {
    moduleCode: 'GROUPWARE', menuId: 'gw.notices', menuLabel: '공지 / 게시판',
    route: '/groupware/notices', handler: 'gwHandleNoticesBody', viewFile: 'GW_NoticesBody.html',
    permissionCode: 'canAccessPortal', status: 'READY', sortOrder: 1130
  },
  {
    moduleCode: 'GROUPWARE', menuId: 'gw.library', menuLabel: '사내 자료실',
    route: '/groupware/library', handler: 'gwHandleLibraryBody', viewFile: 'GW_LibraryBody.html',
    permissionCode: 'canDownloadFiles', status: 'READY', sortOrder: 1140
  },
  {
    moduleCode: 'GROUPWARE', menuId: 'gw.requests', menuLabel: '전자결재 / 업무요청',
    route: '/groupware/requests', handler: 'gwHandleRequestsBody', viewFile: 'GW_RequestsBody.html',
    permissionCode: 'canApprove', status: 'READY', sortOrder: 1150
  },
  {
    moduleCode: 'GROUPWARE', menuId: 'gw.attendance.caps', menuLabel: 'CAPS 근태 연동',
    route: '/groupware/attendance/caps', handler: 'gwHandleCapsAttendanceBody', viewFile: 'GW_CapsAttendanceBody.html',
    permissionCode: 'canAccessPortal', status: 'READY', sortOrder: 1160
  },
  {
    moduleCode: 'GROUPWARE', menuId: 'gw.attendance.mine', menuLabel: '내 근태',
    route: '/groupware/attendance/mine', handler: 'gwHandleMyAttendanceBody', viewFile: 'GW_MyAttendanceBody.html',
    permissionCode: 'canAccessPortal', status: 'READY', sortOrder: 1170
  },
  {
    moduleCode: 'GROUPWARE', menuId: 'gw.attendance.admin', menuLabel: '근태 현황',
    route: '/groupware/attendance/admin', handler: 'gwHandleAttendanceAdminBody', viewFile: 'GW_AttendanceAdminBody.html',
    permissionCode: 'canViewLogs', status: 'READY', sortOrder: 1180
  },
  {
    moduleCode: 'GROUPWARE', menuId: 'gw.kpi', menuLabel: '직원 KPI / 성과관리',
    route: '/groupware/kpi', handler: 'gwHandleKpiBody', viewFile: 'GW_KpiBody.html',
    permissionCode: 'canAccessPortal', status: 'READY', sortOrder: 1190
  },
  {
    moduleCode: 'GROUPWARE', menuId: 'gw.assets', menuLabel: '총무 / 자산 / 비품',
    route: '/groupware/assets', handler: 'gwHandleAssetsBody', viewFile: 'GW_AssetsBody.html',
    permissionCode: 'canAccessPortal', status: 'READY', sortOrder: 1200
  },
  {
    moduleCode: 'GROUPWARE', menuId: 'gw.expenses', menuLabel: '구매 / 지출 / 비용',
    route: '/groupware/expenses', handler: 'gwHandleExpensesBody', viewFile: 'GW_ExpensesBody.html',
    permissionCode: 'canApprove', status: 'READY', sortOrder: 1210
  },
  {
    moduleCode: 'GROUPWARE', menuId: 'gw.diagnostics', menuLabel: '진단 / 설정',
    route: '/groupware/diagnostics', handler: 'gwHandleDiagnosticsBody', viewFile: 'GW_DiagnosticsBody.html',
    permissionCode: 'canAccessDevConsole', status: 'READY', sortOrder: 1220
  },
  {
    moduleCode: 'GROUPWARE', menuId: 'gw.auditLogs', menuLabel: '감사로그',
    route: '/groupware/audit-logs', handler: 'gwHandleAuditLogBody', viewFile: 'GW_AuditLogBody.html',
    permissionCode: 'canViewLogs', status: 'READY', sortOrder: 1221
  },
  {
    moduleCode: 'GROUPWARE', menuId: 'gw.featureFlags', menuLabel: '기능 상태 / FeatureFlag',
    route: '/groupware/feature-flags', handler: 'gwHandleFeatureFlagBody', viewFile: 'GW_FeatureFlagBody.html',
    permissionCode: 'canAccessDevConsole', status: 'READY', sortOrder: 1222
  },
  {
    moduleCode: 'GROUPWARE', menuId: 'gw.limitGuard', menuLabel: '셀 한도 보호',
    route: '/groupware/limit-guard', handler: 'gwHandleLimitGuardBody', viewFile: 'GW_LimitGuardBody.html',
    permissionCode: 'canAccessDevConsole', status: 'READY', sortOrder: 1223
  },
  {
    moduleCode: 'GROUPWARE', menuId: 'gw.calendar', menuLabel: '일정 / 회의 / 캘린더',
    route: '/groupware/calendar', handler: 'gwHandleCalendarBody', viewFile: 'GW_CalendarBody.html',
    permissionCode: 'canAccessCalendar', status: 'PREPARING', sortOrder: 1230
  },
  {
    moduleCode: 'GROUPWARE', menuId: 'gw.knowledge', menuLabel: '지식관리 / 노하우 DB',
    route: '/groupware/knowledge', handler: 'gwHandleKnowledgeBody', viewFile: 'GW_KnowledgeBody.html',
    permissionCode: 'canAccessPortal', status: 'PREPARING', sortOrder: 1240
  }
]);

const GW_B11_BODY_RESPONSIBILITIES = Object.freeze([
  {
    screenId: 'GW_AccountBody', duty: '현재 사용자 계정, employeeId, roleCode, 접근권한 조회',
    buttons: ['새로고침'], calls: ['getModuleBootstrap'], sheets: ['PortalUsers'], logSheet: 'Portal_AuditLog', permissionCode: 'canAccessPortal'
  },
  {
    screenId: 'GW_UsersBody', duty: '직원 목록, 직원 상세, 직원 추가/수정, 상태관리',
    buttons: ['조회', '새 직원', '저장', '상태변경'], calls: ['listUsers', 'getUserDetail', 'saveUser', 'setUserStatus'], sheets: ['PortalUsers'], logSheet: 'Portal_AuditLog', permissionCode: 'canAccessDevConsole'
  },
  {
    screenId: 'GW_PermissionsBody', duty: '권한 체크값 조회/저장 및 권한 없는 접근 차단 안내',
    buttons: ['조회', '권한 저장'], calls: ['getUserDetail', 'saveUser'], sheets: ['PortalUsers'], logSheet: 'Portal_AuditLog', permissionCode: 'canAccessDevConsole'
  },
  {
    screenId: 'GW_NoticesBody', duty: '공지 목록, 상세, 등록/수정, 상단고정, 게시기간, 대상필터',
    buttons: ['조회', '새 공지', '저장', '상태변경'], calls: ['listNotices', 'getNoticeDetail', 'saveNotice', 'setNoticeStatus'], sheets: ['Portal_Notices', 'Portal_NoticeReads'], logSheet: 'Portal_AuditLog', permissionCode: 'canAccessPortal'
  },
  {
    screenId: 'GW_LibraryBody', duty: '자료 목록, 상세, Drive fileId 등록, 다운로드 로그',
    buttons: ['조회', '새 자료', '저장', '다운로드 기록'], calls: ['listLibraryFiles', 'getLibraryFileDetail', 'saveLibraryFile', 'logLibraryDownload'], sheets: ['Documents', 'Portal_FileDownloadLogs'], logSheet: 'Portal_AuditLog', permissionCode: 'canDownloadFiles'
  },
  {
    screenId: 'GW_RequestsBody', duty: '업무요청 등록, 내 요청, 승인대기, 승인/반려',
    buttons: ['조회', '새 요청', '저장', '승인', '반려'], calls: ['listRequests', 'getRequestDetail', 'saveRequest', 'approveRequest', 'rejectRequest'], sheets: ['Portal_Requests', 'Portal_Approvals'], logSheet: 'Portal_AuditLog', permissionCode: 'canApprove'
  },
  {
    screenId: 'GW_CapsAttendanceBody', duty: 'CAPS Mock/CSV/Drive 수집 대기, Raw 저장, 직원 매칭, 근태 반영',
    buttons: ['동기화', '근태조회', '예외조회'], calls: ['syncCapsMock', 'listAttendance', 'listAttendanceExceptions', 'listCapsRaw'], sheets: ['Portal_AttendanceRaw_CAPS', 'Portal_AttendanceCapsMap', 'Portal_Attendance', 'Portal_AttendanceExceptions'], logSheet: 'Portal_AuditLog', permissionCode: 'canAccessPortal'
  },
  {
    screenId: 'GW_KpiBody', duty: 'KPI 목록, 상세, 등록/수정, 평가',
    buttons: ['조회', '새 KPI', '저장', '평가'], calls: ['listKpis', 'getKpiDetail', 'saveKpi', 'evaluateKpi'], sheets: ['Portal_KPI'], logSheet: 'Portal_AuditLog', permissionCode: 'canAccessPortal'
  },
  {
    screenId: 'GW_AssetsBody', duty: '자산/비품 목록, 상세, 비품요청, 승인/반려',
    buttons: ['조회', '자산 저장', '비품 저장', '요청 저장', '승인', '반려'], calls: ['listAssets', 'getAssetDetail', 'saveAsset', 'listSupplies', 'getSupplyDetail', 'saveSupply', 'listSupplyRequests', 'getSupplyRequestDetail', 'saveSupplyRequest', 'approveSupplyRequest', 'rejectSupplyRequest'], sheets: ['Portal_Assets', 'Portal_Supplies', 'Portal_Requests'], logSheet: 'Portal_AuditLog', permissionCode: 'canAccessPortal'
  },
  {
    screenId: 'GW_ExpensesBody', duty: '비용요청 등록, 영수증 fileId, 승인/반려, 정산 원장 직접 반영 금지',
    buttons: ['조회', '새 비용요청', '저장', '승인', '반려'], calls: ['listExpenses', 'getExpenseDetail', 'saveExpense', 'approveExpense', 'rejectExpense'], sheets: ['Portal_Requests', 'Portal_Approvals'], logSheet: 'Portal_AuditLog', permissionCode: 'canApprove'
  },
  {
    screenId: 'GW_DiagnosticsBody', duty: '시트 readiness, 회귀테스트, 셀 한도 보호, AuditLog 점검',
    buttons: ['진단 실행'], calls: ['getAdminDiagnosticSnapshot', 'runB10Diagnostics'], sheets: ['Portal_AuditLog'], logSheet: 'Portal_AuditLog', permissionCode: 'canAccessDevConsole'
  },
  {
    screenId: 'GW_AuditLogBody', duty: 'Portal_AuditLog 최근 기록 조회와 감사 추적 점검',
    buttons: ['감사로그 조회'], calls: ['listAuditLogs'], sheets: ['Portal_AuditLog'], logSheet: 'Portal_AuditLog', permissionCode: 'canViewLogs'
  },
  {
    screenId: 'GW_FeatureFlagBody', duty: 'SystemConfig/기본값 기준 FeatureFlag 상태 조회',
    buttons: ['기능 상태 조회'], calls: ['getFeatureFlagSnapshot'], sheets: ['SystemConfig'], logSheet: 'Portal_AuditLog', permissionCode: 'canAccessDevConsole'
  },
  {
    screenId: 'GW_LimitGuardBody', duty: 'MASTER 셀 사용량과 신규 시트 생성 위험도 점검',
    buttons: ['셀 한도 조회'], calls: ['getCellLimitSnapshot'], sheets: ['FEELHAUS_DB_MASTER'], logSheet: 'Portal_AuditLog', permissionCode: 'canAccessDevConsole'
  }
]);

const GW_B11_PROTECTED_ASSETS = Object.freeze({
  centralRegistries: ['PORTAL_MenuRegistry', 'RouteRegistry', 'PermissionRegistry', 'FeatureFlag', 'StatusPolicy'],
  protectedSheets: [
    'SystemConfig', 'PortalUsers', 'Portal_AuditLog', 'Portal_Notices', 'Portal_NoticeReads',
    'Documents', 'Portal_FileDownloadLogs', 'Portal_Requests', 'Portal_Approvals',
    'Portal_AttendanceRaw_CAPS', 'Portal_AttendanceCapsMap', 'Portal_Attendance', 'Portal_AttendanceExceptions',
    'Portal_KPI', 'Portal_Assets', 'Portal_Supplies'
  ],
  protectedEngines: ['B01_CONFIG', 'B02_USERS', 'B03_NOTICE', 'B04_LIBRARY', 'B05_REQUESTS', 'B06_ATTENDANCE', 'B07_KPI', 'B08_ASSET_SUPPLY', 'B09_EXPENSE'],
  forbiddenArtifacts: ['GW_DevShell.html', 'standalone menu', 'fragment menu', 'preview route', 'iframe', 'module internal menu']
});

function gwGetPortalMenuContracts_B11() {
  return GW_B11_PORTAL_MENU_CONTRACTS.map(function (r) { return Object.assign({}, r); });
}

function gwGetBodyResponsibilityContracts_B11() {
  return GW_B11_BODY_RESPONSIBILITIES.map(function (r) { return Object.assign({}, r); });
}

function gwGetProtectedAssets_B11() {
  return JSON.parse(JSON.stringify(GW_B11_PROTECTED_ASSETS));
}

function gwGetForbiddenUiPolicy_B11() {
  return {
    portalOnlyShell: true,
    moduleOwnMenuForbidden: true,
    iframeForbidden: true,
    previewRouteForbidden: true,
    fragmentMenuForbidden: true,
    standaloneShellForbidden: true,
    allowedScreenStructure: ['화면 제목', '화면 설명', '주요 작업 버튼', '검색 / 필터', '목록 / 입력폼 / 상세', '성공 / 실패 안내문']
  };
}

function gwValidatePortalContracts_B11(payload) {
  var errors = [];
  var warnings = [];
  var contracts = gwGetPortalMenuContracts_B11();
  var bodies = gwGetBodyResponsibilityContracts_B11();
  var seenMenuIds = {};
  var seenRoutes = {};
  var seenSort = {};
  var required = ['moduleCode', 'menuId', 'menuLabel', 'route', 'handler', 'viewFile', 'permissionCode', 'status', 'sortOrder'];

  contracts.forEach(function (row, idx) {
    required.forEach(function (field) {
      if (row[field] === undefined || row[field] === null || row[field] === '') errors.push('계약표 필수값 누락 row=' + idx + ' field=' + field);
    });
    if (row.moduleCode !== GW_B11_MODULE_CODE) errors.push('moduleCode 불일치 menuId=' + row.menuId);
    if (seenMenuIds[row.menuId]) errors.push('menuId 중복: ' + row.menuId);
    seenMenuIds[row.menuId] = true;
    if (seenRoutes[row.route]) errors.push('route 중복: ' + row.route);
    seenRoutes[row.route] = true;
    if (seenSort[row.sortOrder]) warnings.push('sortOrder 중복 가능: ' + row.sortOrder);
    seenSort[row.sortOrder] = true;
    GW_B11_FORBIDDEN_UI_TERMS.forEach(function (term) {
      var joined = [row.menuId, row.route, row.handler, row.viewFile].join(' ').toLowerCase();
      if (joined.indexOf(term.toLowerCase()) >= 0) errors.push('금지 UI/route 용어 포함 menuId=' + row.menuId + ' term=' + term);
    });
    if (String(row.route).indexOf('/groupware/') !== 0) errors.push('route prefix 불일치: ' + row.route);
    if (['READY', 'PREPARING', 'DISABLED', 'NO_PERMISSION', 'ERROR'].indexOf(row.status) < 0) errors.push('허용되지 않은 status: ' + row.status);
  });

  bodies.forEach(function (body, idx) {
    ['screenId', 'duty', 'buttons', 'calls', 'sheets', 'logSheet', 'permissionCode'].forEach(function (field) {
      if (body[field] === undefined || body[field] === null || body[field] === '') errors.push('본문 책임표 필수값 누락 row=' + idx + ' field=' + field);
    });
    if (!body.calls || !body.calls.length) errors.push('호출 함수 없음 screenId=' + body.screenId);
    if (body.screenId && String(body.screenId).toLowerCase().indexOf('menu') >= 0) errors.push('본문 screenId에 menu 포함 금지: ' + body.screenId);
  });

  return gwOk_({
    ok: errors.length === 0,
    errors: errors,
    warnings: warnings,
    menuContractCount: contracts.length,
    bodyResponsibilityCount: bodies.length,
    protectedSheetCount: GW_B11_PROTECTED_ASSETS.protectedSheets.length,
    portalOnlyShell: true,
    mainDeveloperReviewRequired: true
  }, errors.length ? 'PORTAL_CONTRACT_HAS_ERRORS' : 'PORTAL_CONTRACT_OK');
}

function gwCheckNoStandaloneArtifacts_B11() {
  return {
    ok: true,
    note: 'B11 배포 패키지는 GW_DevShell.html, appsscript.json, README_BUILD.md, BUILD_TEST_REPORT.md를 포함하지 않는 JS 중심 계약 패키지입니다.',
    forbiddenFiles: ['GW_DevShell.html', 'appsscript.json', 'README_BUILD.md', 'BUILD_TEST_REPORT.md'],
    moduleOwnMenuForbidden: true,
    portalShellOnly: true
  };
}

function gwWriteB11ContractAudit_(context) {
  context = context || gwGetUserContextSafe_();
  return gwWriteAuditLog_({
    moduleCode: 'GROUPWARE',
    actionType: 'B11_PORTAL_CONTRACT_BODY_BASE_CHECK',
    targetId: 'GROUPWARE_B11_PORTAL_CONTRACT_BODY_BASE',
    employeeId: context.employeeId || 'UNKNOWN',
    resultStatus: 'SUCCESS',
    detailMessage: '[11/20] PORTAL 계약/본문 구조 베이스 진단 완료. 자체 Shell/메뉴/preview/iframe 금지 기준 고정.',
    createdBy: context.employeeId || 'SYSTEM'
  });
}
