const GW_AUDIT_SHEET_CANDIDATES = Object.freeze(['Portal_AuditLog', 'PORTAL_AuditLog', 'PORTAL_Log', 'AuditLogs']);
const GW_AUDIT_PREFERRED_SHEET_NAME = 'Portal_AuditLog';
const GW_AUDIT_HEADERS = Object.freeze([
  'logId',
  'createdAt',
  'createdBy',
  'employeeId',
  'actionType',
  'targetType',
  'targetId',
  'result',
  'statusReason',
  'payload',
  'module',
  'action',
  'reason'
]);

function gwGetAuditSheet_() {
  var ss = gwGetMasterSpreadsheet_();
  for (var i = 0; i < GW_AUDIT_SHEET_CANDIDATES.length; i++) {
    var sheet = ss.getSheetByName(GW_AUDIT_SHEET_CANDIDATES[i]);
    if (sheet) return sheet;
  }
  var created = ss.insertSheet(GW_AUDIT_PREFERRED_SHEET_NAME);
  created.getRange(1, 1, 1, GW_AUDIT_HEADERS.length).setValues([GW_AUDIT_HEADERS]);
  return created;
}

function gwWriteAuditLog_(entry) {
  entry = entry || {};
  var sheet = gwGetAuditSheet_();
  var headers = gwGetHeaders_(sheet).filter(function (h) { return h; });
  if (headers.length === 0) {
    sheet.getRange(1, 1, 1, GW_AUDIT_HEADERS.length).setValues([GW_AUDIT_HEADERS]);
    headers = GW_AUDIT_HEADERS.slice();
  }

  var employeeId = gwToSafeText_(entry.employeeId) || gwGetCurrentEmployeeIdSafe_();
  var actionType = gwToSafeText_(entry.actionType) || 'UNKNOWN';
  var moduleCode = gwToSafeText_(entry.moduleCode) || 'GROUPWARE';
  var resultStatus = gwToSafeText_(entry.resultStatus) || 'SUCCESS';
  var detailMessage = gwToSafeText_(entry.detailMessage).slice(0, 1000);
  var logId = gwUuid_('GWLOG');
  var payload = JSON.stringify({
    build: GW_BUILD_INFO.build,
    moduleCode: moduleCode,
    actionType: actionType,
    targetId: gwToSafeText_(entry.targetId),
    resultStatus: resultStatus,
    detailMessage: detailMessage
  });

  var rowObj = {
    auditLogId: logId,
    logId: logId,
    moduleCode: moduleCode,
    module: moduleCode,
    actionType: actionType,
    action: actionType,
    targetType: moduleCode,
    targetId: gwToSafeText_(entry.targetId),
    employeeId: employeeId,
    resultStatus: resultStatus,
    result: resultStatus,
    detailMessage: detailMessage,
    statusReason: detailMessage,
    reason: detailMessage,
    payload: payload,
    createdAt: gwNow_(),
    createdBy: employeeId
  };

  var row = headers.map(function (h) {
    return Object.prototype.hasOwnProperty.call(rowObj, h) ? rowObj[h] : '';
  });
  sheet.appendRow(row);
  return { ok: true, rowNumber: sheet.getLastRow(), auditLogId: logId, sheetName: sheet.getName() };
}

function gwAuditSafe_(entry) {
  try {
    return gwWriteAuditLog_(entry);
  } catch (err) {
    return { ok: false, message: gwErrorMessage_(err) };
  }
}
