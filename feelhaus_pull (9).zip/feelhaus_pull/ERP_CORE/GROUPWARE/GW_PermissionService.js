const GW_PORTAL_USER_PERMISSION_HEADERS = Object.freeze([
  'canAccessPortal',
  'canAccessMail',
  'canSendMail',
  'canAccessCalendar',
  'canCreateCalendarEvent',
  'canAccessSign',
  'canAccessErp',
  'canAccessForm',
  'canAccessControl',
  'canAccessDevConsole',
  'canApprove',
  'canViewLogs',
  'canDownloadFiles',
  'canViewSensitiveInfo'
]);

function gwCanSafe_(context, permissionCode) {
  if (!permissionCode) return true;
  context = context || gwGetUserContextSafe_();
  if (!context.ok) return false;

  var roleCode = gwToSafeText_(context.roleCode).toUpperCase();
  var isAdmin = gwIsAdminRole_(roleCode);
  var permissions = context.permissions || {};

  if (permissionCode === 'canAccessPortal') return !!permissions.canAccessPortal || isAdmin;
  if (isAdmin) return true;
  return !!permissions[permissionCode];
}

function gwAssertPermission_(permissionCode) {
  var context = gwGetUserContextSafe_();
  if (!gwCanSafe_(context, permissionCode)) {
    gwAuditSafe_({
      moduleCode: 'GROUPWARE_PERMISSION',
      actionType: 'PERMISSION_DENIED',
      targetId: permissionCode,
      employeeId: context.employeeId || 'UNKNOWN',
      resultStatus: 'FAILED',
      detailMessage: '권한 없음: ' + permissionCode
    });
    throw new Error('권한이 없습니다: ' + permissionCode);
  }
  return context;
}
