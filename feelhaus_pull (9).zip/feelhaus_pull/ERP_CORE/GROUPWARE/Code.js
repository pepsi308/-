/**
 * GROUPWARE B18 Code entry.
 * PORTAL is the only allowed Shell. This module exposes body-only handlers and server APIs.
 */
function doGet(e) {
  return HtmlService.createHtmlOutput(
    '<!doctype html><html><head><meta charset="UTF-8"><title>GROUPWARE PORTAL BODY ONLY</title></head>' +
    '<body style="font-family:Arial,sans-serif;padding:24px;line-height:1.6">' +
    '<h2>GROUPWARE 모듈은 PORTAL 본문 전용입니다.</h2>' +
    '<p>자체 상단/좌측 메뉴와 별도 Shell은 사용하지 않습니다.</p>' +
    '<p>PORTAL 중앙 메뉴/라우트/권한 원장 기준으로 본문 업무 화면만 연결하십시오.</p>' +
    '</body></html>'
  ).setTitle('GROUPWARE PORTAL BODY ONLY');
}

function gwApi(action, payload) {
  try {
    payload = payload || {};
    switch (action) {
      case 'getModuleBootstrap':
      case 'getBootstrap':
        return gwOk_({
          buildInfo: gwGetBuildInfo(),
          userContext: gwGetUserContextSafe_(),
          portalMenuContracts: gwGetPortalMenuContracts_B11(),
          bodyResponsibilities: gwGetBodyResponsibilityContracts_B11(),
          b12BodySpecs: gwGetB12BodySpecs(),
          b13BodySpecs: gwGetB13BodySpecs(),
          b14BodySpecs: gwGetB14BodySpecs(),
          b15BodySpecs: gwGetB15BodySpecs(),
          b16BodySpecs: gwGetB16BodySpecs(),
          b17BodySpecs: gwGetB17BodySpecs(),
          b18BodySpecs: gwGetB18BodySpecs(),
          b19BodySpecs: gwGetB19BodySpecs(),
          b20BodySpecs: gwGetB20BodySpecs(),
          b21BodySpecs: gwGetB21BodySpecs(),
          protectedAssets: gwGetProtectedAssets_B11(),
          forbiddenUiPolicy: gwGetForbiddenUiPolicy_B11(),
          moduleMode: 'PORTAL_BODY_ONLY',
          shellOwner: 'PORTAL'
        }, 'PORTAL_BODY_BOOTSTRAP_OK');
      case 'getPortalContracts':
        return gwOk_({
          menuContracts: gwGetPortalMenuContracts_B11(),
          bodyResponsibilities: gwGetBodyResponsibilityContracts_B11(),
          b12BodySpecs: gwGetB12BodySpecs(),
          b13BodySpecs: gwGetB13BodySpecs(),
          b14BodySpecs: gwGetB14BodySpecs(),
          b15BodySpecs: gwGetB15BodySpecs(),
          b16BodySpecs: gwGetB16BodySpecs(),
          b17BodySpecs: gwGetB17BodySpecs(),
          b18BodySpecs: gwGetB18BodySpecs(),
          b19BodySpecs: gwGetB19BodySpecs(),
          b20BodySpecs: gwGetB20BodySpecs(),
          b21BodySpecs: gwGetB21BodySpecs(),
          protectedAssets: gwGetProtectedAssets_B11(),
          forbiddenUiPolicy: gwGetForbiddenUiPolicy_B11()
        }, 'PORTAL_CONTRACTS_OK');
      case 'validatePortalContracts':
        return gwValidatePortalContracts_B11(payload);
      case 'runB11Diagnostics':
        return gwRunB11Diagnostics(payload);
      case 'runDiagnostics':
        return gwRunB11Diagnostics(payload);

      case 'handleUsersBody':
      case 'gwHandleUsersBody':
        return gwHandleUsersBody(payload);
      case 'handlePermissionsBody':
      case 'gwHandlePermissionsBody':
        return gwHandlePermissionsBody(payload);
      case 'getB12BodySpecs':
        return gwOk_({ bodySpecs: gwGetB12BodySpecs() }, 'B12_BODY_SPECS_OK');
      case 'validateB12BodyContracts':
        return gwValidateB12BodyContracts(payload);
      case 'runB12Diagnostics':
        return gwRunB12Diagnostics(payload);

      case 'handleNoticeBoardBody':
      case 'gwHandleNoticeBoardBody':
        return gwHandleNoticeBoardBody(payload);
      case 'getB13BodySpecs':
        return gwOk_({ bodySpecs: gwGetB13BodySpecs() }, 'B13_BODY_SPECS_OK');
      case 'validateB13BodyContracts':
        return gwValidateB13BodyContracts(payload);
      case 'runB13Diagnostics':
        return gwRunB13Diagnostics(payload);



      case 'handleDocLibraryBody':
      case 'gwHandleDocLibraryBody':
        return gwHandleDocLibraryBody(payload);
      case 'getB14BodySpecs':
        return gwOk_({ bodySpecs: gwGetB14BodySpecs() }, 'B14_BODY_SPECS_OK');
      case 'validateB14BodyContracts':
        return gwValidateB14BodyContracts(payload);
      case 'runB14Diagnostics':
        return gwRunB14Diagnostics(payload);

      case 'handleRequestsBody':
      case 'gwHandleRequestsBody':
      case 'handleRequestApprovalBody':
      case 'gwHandleRequestApprovalBody':
        return gwHandleRequestsBody(payload);
      case 'getB15BodySpecs':
        return gwOk_({ bodySpecs: gwGetB15BodySpecs() }, 'B15_BODY_SPECS_OK');
      case 'validateB15BodyContracts':
        return gwValidateB15BodyContracts(payload);
      case 'runB15Diagnostics':
        return gwRunB15Diagnostics(payload);

      case 'handleCapsAttendanceBody':
      case 'gwHandleCapsAttendanceBody':
        return gwHandleCapsAttendanceBody(payload);
      case 'handleMyAttendanceBody':
      case 'gwHandleMyAttendanceBody':
        return gwHandleMyAttendanceBody(payload);
      case 'handleAttendanceAdminBody':
      case 'gwHandleAttendanceAdminBody':
        return gwHandleAttendanceAdminBody(payload);
      case 'handleAttendanceExceptionsBody':
      case 'gwHandleAttendanceExceptionsBody':
        return gwHandleAttendanceExceptionsBody(payload);
      case 'handleAttendanceBody':
      case 'gwHandleAttendanceBody':
        return gwHandleAttendanceBody(payload);
      case 'getB16BodySpecs':
        return gwOk_({ bodySpecs: gwGetB16BodySpecs() }, 'B16_BODY_SPECS_OK');
      case 'validateB16BodyContracts':
        return gwValidateB16BodyContracts(payload);
      case 'runB16Diagnostics':
        return gwRunB16Diagnostics(payload);

            // Existing business APIs remain protected and callable by PORTAL handlers only.

      case 'handleKpiBody':
      case 'gwHandleKpiBody':
        return gwHandleKpiBody(payload);
      case 'handleAssetSupplyBody':
      case 'gwHandleAssetSupplyBody':
        return gwHandleAssetSupplyBody(payload);
      case 'handleSupplyRequestBody':
      case 'gwHandleSupplyRequestBody':
        return gwHandleSupplyRequestBody(payload);
      case 'handleExpenseBody':
      case 'gwHandleExpenseBody':
        return gwHandleExpenseBody(payload);
      case 'handleManagementBody':
      case 'gwHandleManagementBody':
        return gwHandleManagementBody(payload);
      case 'getB17BodySpecs':
        return gwOk_({ bodySpecs: gwGetB17BodySpecs() }, 'B17_BODY_SPECS_OK');
      case 'validateB17BodyContracts':
        return gwValidateB17BodyContracts(payload);
      case 'runB17Diagnostics':
        return gwRunB17Diagnostics(payload);

      case 'handleAdminDiagnosticsBody':
      case 'gwHandleAdminDiagnosticsBody':
      case 'handleDiagnosticsBody':
      case 'gwHandleDiagnosticsBody':
        return gwHandleAdminDiagnosticsBody(payload);
      case 'handleAuditLogBody':
      case 'gwHandleAuditLogBody':
        return gwHandleAuditLogBody(payload);
      case 'handleFeatureFlagBody':
      case 'gwHandleFeatureFlagBody':
        return gwHandleFeatureFlagBody(payload);
      case 'handleLimitGuardBody':
      case 'gwHandleLimitGuardBody':
        return gwHandleLimitGuardBody(payload);
      case 'getB18BodySpecs':
        return gwOk_({ bodySpecs: gwGetB18BodySpecs() }, 'B18_BODY_SPECS_OK');
      case 'validateB18BodyContracts':
        return gwValidateB18BodyContracts(payload);
      case 'runB18Diagnostics':
        return gwRunB18Diagnostics(payload);
      case 'getAdminDiagnosticSnapshot':
        return gwGetAdminDiagnosticSnapshotForUi(payload);
      case 'listAuditLogs':
        return gwListAuditLogsForUi(payload);
      case 'getFeatureFlagSnapshot':
        return gwGetFeatureFlagSnapshotForUi(payload);
      case 'getCellLimitSnapshot':
        return gwGetCellLimitSnapshotForUi(payload);



      case 'handleStabilityGuardBody':
      case 'gwHandleStabilityGuardBody':
        return gwHandleStabilityGuardBody(payload);
      case 'handlePermissionGuardBody':
      case 'gwHandlePermissionGuardBody':
        return gwHandlePermissionGuardBody(payload);
      case 'handleInputValidationBody':
      case 'gwHandleInputValidationBody':
        return gwHandleInputValidationBody(payload);
      case 'handleStatusGuardBody':
      case 'gwHandleStatusGuardBody':
        return gwHandleStatusGuardBody(payload);
      case 'getB19BodySpecs':
        return gwOk_({ bodySpecs: gwGetB19BodySpecs() }, 'B19_BODY_SPECS_OK');
      case 'validateB19BodyContracts':
        return gwValidateB19BodyContracts(payload);
      case 'runB19Diagnostics':
        return gwRunB19Diagnostics(payload);
      case 'validateStabilityGuards':
        return gwValidateStabilityGuards(payload);
      case 'validatePermissionGuards':
        return gwValidatePermissionGuards(payload);
      case 'validateInputRules':
        return gwValidateInputRules(payload);
      case 'validateStatusRules':
        return gwValidateStatusRules(payload);

      case 'listUsers':
        return gwListPortalUsersForUi(payload);
      case 'getUserDetail':
        return gwGetPortalUserDetailForUi(payload);
      case 'saveUser':
        return gwSavePortalUserForUi(payload);
      case 'setUserStatus':
        return gwSetPortalUserStatusForUi(payload);
      case 'listNotices':
        return gwListNoticesForUi(payload);
      case 'getNoticeDetail':
        return gwGetNoticeDetailForUi(payload);
      case 'saveNotice':
        return gwSaveNoticeForUi(payload);
      case 'setNoticeStatus':
        return gwSetNoticeStatusForUi(payload);
      case 'listLibraryFiles':
        return gwListLibraryFilesForUi(payload);
      case 'getLibraryFileDetail':
        return gwGetLibraryFileDetailForUi(payload);
      case 'saveLibraryFile':
        return gwSaveLibraryFileForUi(payload);
      case 'setLibraryFileStatus':
        return gwSetLibraryFileStatusForUi(payload);
      case 'logLibraryDownload':
        return gwLogLibraryDownloadForUi(payload);
      case 'listRequests':
        return gwListRequestsForUi(payload);
      case 'getRequestDetail':
        return gwGetRequestDetailForUi(payload);
      case 'saveRequest':
        return gwSaveRequestForUi(payload);
      case 'approveRequest':
        return gwApproveRequestForUi(payload);
      case 'rejectRequest':
        return gwRejectRequestForUi(payload);
      case 'syncCapsMock':
        return gwSyncCapsMockForUi(payload);
      case 'listAttendance':
        return gwListAttendanceForUi(payload);
      case 'listAttendanceExceptions':
        return gwListAttendanceExceptionsForUi(payload);
      case 'listCapsRaw':
        return gwListCapsRawForUi(payload);
      case 'listKpis':
        return gwListKpisForUi(payload);
      case 'getKpiDetail':
        return gwGetKpiDetailForUi(payload);
      case 'saveKpi':
        return gwSaveKpiForUi(payload);
      case 'evaluateKpi':
        return gwEvaluateKpiForUi(payload);
      case 'listAssets':
        return gwListAssetsForUi(payload);
      case 'getAssetDetail':
        return gwGetAssetDetailForUi(payload);
      case 'saveAsset':
        return gwSaveAssetForUi(payload);
      case 'listSupplies':
        return gwListSuppliesForUi(payload);
      case 'getSupplyDetail':
        return gwGetSupplyDetailForUi(payload);
      case 'saveSupply':
        return gwSaveSupplyForUi(payload);
      case 'listSupplyRequests':
        return gwListSupplyRequestsForUi(payload);
      case 'getSupplyRequestDetail':
        return gwGetSupplyRequestDetailForUi(payload);
      case 'saveSupplyRequest':
        return gwSaveSupplyRequestForUi(payload);
      case 'approveSupplyRequest':
        return gwApproveSupplyRequestForUi(payload);
      case 'rejectSupplyRequest':
        return gwRejectSupplyRequestForUi(payload);
      case 'listExpenses':
        return gwListExpensesForUi(payload);
      case 'getExpenseDetail':
        return gwGetExpenseDetailForUi(payload);
      case 'saveExpense':
        return gwSaveExpenseForUi(payload);
      case 'approveExpense':
        return gwApproveExpenseForUi(payload);
      case 'rejectExpense':
        return gwRejectExpenseForUi(payload);

      case 'handleReleaseCandidateBody':
      case 'gwHandleReleaseCandidateBody':
        return gwHandleReleaseCandidateBody(payload);
      case 'getB20BodySpecs':
        return gwOk_({ bodySpecs: gwGetB20BodySpecs() }, 'B20_BODY_SPECS_OK');
      case 'validateB20BodyContracts':
        return gwValidateB20BodyContracts(payload);
      case 'validateB20ReleaseCandidate':
        return gwValidateB20ReleaseCandidate(payload);
      case 'runB20Diagnostics':
        return gwRunB20Diagnostics(payload);


      case 'handleActionGuardBody':
      case 'gwHandleActionGuardBody':
        return gwHandleActionGuardBody(payload);
      case 'getB21BodySpecs':
        return gwOk_({ bodySpecs: gwGetB21BodySpecs() }, 'B21_BODY_SPECS_OK');
      case 'validateB21BodyContracts':
        return gwValidateB21BodyContracts(payload);
      case 'validateCommonActionRegistry':
        return gwValidateCommonActionRegistry(payload);
      case 'runB21Diagnostics':
        return gwRunB21Diagnostics(payload);

      default:
        return gwFail_('UNKNOWN_ACTION', '알 수 없는 요청입니다: ' + action);
    }
  } catch (err) {
    return gwFail_('API_ERROR', gwErrorMessage_(err), { stack: gwErrorStack_(err) });
  }
}
