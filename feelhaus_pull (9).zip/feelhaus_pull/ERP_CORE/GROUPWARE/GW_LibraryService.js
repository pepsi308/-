
const GW_LIBRARY_SHEET_CANDIDATES = Object.freeze(['Portal_DocLibrary', 'PORTAL_DocLibrary', 'Portal_DocumentLibrary', 'DocLibrary', 'GW_DocLibrary', 'Documents']);
const GW_LIBRARY_PREFERRED_SHEET_NAME = 'Portal_DocLibrary';
const GW_FILE_DOWNLOAD_LOG_SHEET_CANDIDATES = Object.freeze(['Portal_FileDownloadLogs', 'PORTAL_FileDownloadLogs', 'FileDownloadLogs', 'GW_FileDownloadLogs']);
const GW_FILE_DOWNLOAD_LOG_PREFERRED_SHEET_NAME = 'Portal_FileDownloadLogs';

const GW_LIBRARY_HEADERS = Object.freeze([
  'libraryFileId', 'category', 'title', 'description',
  'driveFileId', 'driveFolderId', 'fileName', 'fileType', 'fileSize',
  'targetRoleCode', 'targetVendorId', 'targetEventId',
  'downloadAllowedYn', 'status', 'statusReason',
  'createdAt', 'createdBy', 'updatedAt', 'updatedBy'
]);

const GW_FILE_DOWNLOAD_LOG_HEADERS = Object.freeze([
  'downloadLogId', 'libraryFileId', 'employeeId', 'downloadedAt',
  'resultStatus', 'createdAt', 'createdBy', 'ip', 'userAgent'
]);

const GW_LIBRARY_STATUSES = Object.freeze(['DRAFT', 'ACTIVE', 'INACTIVE', 'ARCHIVED']);
const GW_LIBRARY_CATEGORIES = Object.freeze(['GENERAL', 'MANUAL', 'FORM', 'CONTRACT_SAMPLE', 'INSTALL', 'EVENT', 'HR', 'SYSTEM']);

function gwGetLibrarySheet_(createIfMissing) {
  var ss = gwGetMasterSpreadsheet_();
  for (var i = 0; i < GW_LIBRARY_SHEET_CANDIDATES.length; i++) {
    var sheet = ss.getSheetByName(GW_LIBRARY_SHEET_CANDIDATES[i]);
    if (sheet) return sheet;
  }
  if (createIfMissing) {
    var created = ss.insertSheet(GW_LIBRARY_PREFERRED_SHEET_NAME);
    created.getRange(1, 1, 1, GW_LIBRARY_HEADERS.length).setValues([GW_LIBRARY_HEADERS]);
    return created;
  }
  throw new Error('사내 자료실 시트를 찾을 수 없습니다. 허용 시트명: ' + GW_LIBRARY_SHEET_CANDIDATES.join(', '));
}

function gwGetFileDownloadLogSheet_(createIfMissing) {
  var ss = gwGetMasterSpreadsheet_();
  for (var i = 0; i < GW_FILE_DOWNLOAD_LOG_SHEET_CANDIDATES.length; i++) {
    var sheet = ss.getSheetByName(GW_FILE_DOWNLOAD_LOG_SHEET_CANDIDATES[i]);
    if (sheet) return sheet;
  }
  if (createIfMissing) {
    var created = ss.insertSheet(GW_FILE_DOWNLOAD_LOG_PREFERRED_SHEET_NAME);
    created.getRange(1, 1, 1, GW_FILE_DOWNLOAD_LOG_HEADERS.length).setValues([GW_FILE_DOWNLOAD_LOG_HEADERS]);
    return created;
  }
  throw new Error('자료실 다운로드 로그 시트를 찾을 수 없습니다. 허용 시트명: ' + GW_FILE_DOWNLOAD_LOG_SHEET_CANDIDATES.join(', '));
}

function gwEnsureLibraryHeaders_() {
  var sheet = gwGetLibrarySheet_(true);
  var before = gwGetHeaders_(sheet).filter(function (h) { return h; });
  var result = gwEnsureHeaders_(sheet, GW_LIBRARY_HEADERS.slice());
  var after = gwGetHeaders_(sheet).filter(function (h) { return h; });
  return {
    ok: result.ok,
    sheetName: sheet.getName(),
    beforeCount: before.length,
    afterCount: after.length,
    addedHeaders: after.filter(function (h) { return before.indexOf(h) < 0; }),
    missing: result.missing || []
  };
}

function gwEnsureFileDownloadLogHeaders_() {
  var sheet = gwGetFileDownloadLogSheet_(true);
  var before = gwGetHeaders_(sheet).filter(function (h) { return h; });
  var result = gwEnsureHeaders_(sheet, GW_FILE_DOWNLOAD_LOG_HEADERS.slice());
  var after = gwGetHeaders_(sheet).filter(function (h) { return h; });
  return {
    ok: result.ok,
    sheetName: sheet.getName(),
    beforeCount: before.length,
    afterCount: after.length,
    addedHeaders: after.filter(function (h) { return before.indexOf(h) < 0; }),
    missing: result.missing || []
  };
}

function gwInspectLibraryHeadersNoWrite_B04_() {
  var ss = gwGetMasterSpreadsheet_();
  var librarySheet = null;
  var downloadLogSheet = null;
  for (var i = 0; i < GW_LIBRARY_SHEET_CANDIDATES.length; i++) {
    librarySheet = ss.getSheetByName(GW_LIBRARY_SHEET_CANDIDATES[i]);
    if (librarySheet) break;
  }
  for (var j = 0; j < GW_FILE_DOWNLOAD_LOG_SHEET_CANDIDATES.length; j++) {
    downloadLogSheet = ss.getSheetByName(GW_FILE_DOWNLOAD_LOG_SHEET_CANDIDATES[j]);
    if (downloadLogSheet) break;
  }

  var result = {
    ok: true,
    mode: 'NO_WRITE_INSPECT',
    librarySheetExists: !!librarySheet,
    downloadLogSheetExists: !!downloadLogSheet,
    librarySheetName: librarySheet ? librarySheet.getName() : '',
    downloadLogSheetName: downloadLogSheet ? downloadLogSheet.getName() : '',
    preferredLibrarySheetName: GW_LIBRARY_PREFERRED_SHEET_NAME,
    preferredDownloadLogSheetName: GW_FILE_DOWNLOAD_LOG_PREFERRED_SHEET_NAME,
    requiredLibraryHeaderCount: GW_LIBRARY_HEADERS.length,
    requiredDownloadLogHeaderCount: GW_FILE_DOWNLOAD_LOG_HEADERS.length,
    prepareRequired: false,
    missingLibraryHeaders: [],
    missingDownloadLogHeaders: []
  };

  if (!librarySheet) {
    result.prepareRequired = true;
    result.message = '사내 자료실 시트가 아직 없습니다. gwInternalTest_B04_HeaderEnsure()에서 생성됩니다.';
  } else {
    var libraryCheck = gwCheckRequiredHeaders_(librarySheet, GW_LIBRARY_HEADERS.slice());
    result.libraryHeaderCount = libraryCheck.headers.length;
    result.missingLibraryHeaders = libraryCheck.missing || [];
    if (!libraryCheck.ok) result.prepareRequired = true;
  }

  if (!downloadLogSheet) {
    result.prepareRequired = true;
    result.logMessage = '다운로드 로그 시트가 아직 없습니다. gwInternalTest_B04_HeaderEnsure()에서 생성됩니다.';
  } else {
    var logCheck = gwCheckRequiredHeaders_(downloadLogSheet, GW_FILE_DOWNLOAD_LOG_HEADERS.slice());
    result.downloadLogHeaderCount = logCheck.headers.length;
    result.missingDownloadLogHeaders = logCheck.missing || [];
    if (!logCheck.ok) result.prepareRequired = true;
  }

  return result;
}

function gwGetB04LibraryMeta_() {
  return {
    buildStep: '04/10',
    librarySheetCandidates: GW_LIBRARY_SHEET_CANDIDATES.slice(),
    downloadLogSheetCandidates: GW_FILE_DOWNLOAD_LOG_SHEET_CANDIDATES.slice(),
    libraryStatuses: GW_LIBRARY_STATUSES.slice(),
    categories: GW_LIBRARY_CATEGORIES.slice(),
    requiredHeaders: GW_LIBRARY_HEADERS.slice()
  };
}

function gwListLibraryFilesForUi(payload) {
  payload = payload || {};
  var context = gwAssertPermission_('canAccessPortal');
  var sheet = gwGetLibrarySheet_(true);
  gwEnsureHeaders_(sheet, GW_LIBRARY_HEADERS.slice());
  var rows = gwReadRowsAsObjects_(sheet).map(function (row) { return gwNormalizeLibraryRow_(row); });
  var query = gwToSafeText_(payload.query).toLowerCase();
  var category = gwToSafeText_(payload.category).toUpperCase();
  var includeAll = payload.includeAll === true && gwCanSafe_(context, 'canAccessDevConsole');
  var limit = Math.min(Number(payload.limit || 100), 500);

  rows = rows.filter(function (file) {
    if (!includeAll && !gwIsLibraryFileVisibleToContext_(file, context)) return false;
    if (category && category !== 'ALL' && file.category !== category) return false;
    if (query) {
      var hay = [file.libraryFileId, file.category, file.title, file.description, file.fileName, file.fileType, file.targetRoleCode, file.targetVendorId, file.targetEventId, file.status].join(' ').toLowerCase();
      if (hay.indexOf(query) < 0) return false;
    }
    return true;
  });

  rows.sort(function (a, b) {
    return gwLibraryDateToMillis_(b.updatedAt || b.createdAt) - gwLibraryDateToMillis_(a.updatedAt || a.createdAt);
  });

  rows = rows.slice(0, limit).map(function (file) { return gwLibraryFileToUiRow_(file); });
  return gwOk_({ rows: rows, totalReturned: rows.length, sheetName: sheet.getName() }, '자료 목록 조회 완료');
}

function gwGetLibraryFileDetailForUi(payload) {
  payload = payload || {};
  var context = gwAssertPermission_('canAccessPortal');
  var libraryFileId = gwToSafeText_(payload.libraryFileId);
  if (!libraryFileId) return gwFail_('MISSING_LIBRARY_FILE_ID', 'libraryFileId가 필요합니다.');
  var file = gwFindLibraryFileById_(libraryFileId);
  if (!file) return gwFail_('LIBRARY_FILE_NOT_FOUND', '자료를 찾을 수 없습니다.', { libraryFileId: libraryFileId });
  if (!gwCanSafe_(context, 'canAccessDevConsole') && !gwIsLibraryFileVisibleToContext_(file, context)) {
    return gwFail_('LIBRARY_NO_PERMISSION', '해당 자료를 조회할 권한이 없습니다.', { libraryFileId: libraryFileId });
  }
  return gwOk_({ file: gwLibraryFileToUiRow_(file) }, '자료 상세 조회 완료');
}

function gwSaveLibraryFileForUi(payload) {
  payload = payload || {};
  var context = gwAssertPermission_('canAccessDevConsole');
  var result = gwSaveLibraryFile_(payload, context, { mode: 'UI' });
  return gwOk_(result, result.action === 'CREATE' ? '자료 등록 완료' : '자료 수정 완료');
}

function gwSetLibraryFileStatusForUi(payload) {
  payload = payload || {};
  var context = gwAssertPermission_('canAccessDevConsole');
  var libraryFileId = gwToSafeText_(payload.libraryFileId);
  if (!libraryFileId) return gwFail_('MISSING_LIBRARY_FILE_ID', 'libraryFileId가 필요합니다.');
  var file = gwFindLibraryFileById_(libraryFileId);
  if (!file) return gwFail_('LIBRARY_FILE_NOT_FOUND', '자료 상태 변경 대상을 찾을 수 없습니다.', { libraryFileId: libraryFileId });
  var result = gwSaveLibraryFile_(Object.assign({}, file._sourceRow, {
    libraryFileId: file.libraryFileId,
    title: file.title,
    driveFileId: file.driveFileId,
    status: gwNormalizeLibraryStatus_(payload.status || 'INACTIVE'),
    statusReason: gwToSafeText_(payload.statusReason) || 'B04 상태 변경'
  }), context, { mode: 'STATUS' });
  return gwOk_(result, '자료 상태 변경 완료');
}

function gwLogLibraryDownloadForUi(payload) {
  payload = payload || {};
  var context = gwAssertPermission_('canDownloadFiles');
  var libraryFileId = gwToSafeText_(payload.libraryFileId);
  if (!libraryFileId) return gwFail_('MISSING_LIBRARY_FILE_ID', 'libraryFileId가 필요합니다.');
  var file = gwFindLibraryFileById_(libraryFileId);
  if (!file) return gwFail_('LIBRARY_FILE_NOT_FOUND', '다운로드 로그 대상 자료를 찾을 수 없습니다.', { libraryFileId: libraryFileId });
  if (!gwIsLibraryFileVisibleToContext_(file, context) && !gwCanSafe_(context, 'canAccessDevConsole')) {
    return gwFail_('LIBRARY_DOWNLOAD_NO_PERMISSION', '해당 자료를 다운로드할 권한이 없습니다.', { libraryFileId: libraryFileId });
  }
  if (!gwNormalizeYn_(file.downloadAllowedYn) && !gwCanSafe_(context, 'canAccessDevConsole')) {
    return gwFail_('LIBRARY_DOWNLOAD_BLOCKED', '다운로드가 허용되지 않은 자료입니다.', { libraryFileId: libraryFileId });
  }
  var log = gwCreateLibraryDownloadLog_(libraryFileId, context, 'SUCCESS', payload);
  return gwOk_({ log: log, file: gwLibraryFileToUiRow_(file) }, '다운로드 로그 기록 완료');
}

function gwSaveLibraryFile_(payload, context, options) {
  payload = gwSanitizeLibraryPayload_(payload || {});
  context = context || gwGetUserContextSafe_();
  options = options || {};
  var sheet = gwGetLibrarySheet_(true);
  gwEnsureHeaders_(sheet, GW_LIBRARY_HEADERS.slice());
  var headers = gwGetHeaders_(sheet).filter(function (h) { return h; });
  var rows = gwReadRowsAsObjects_(sheet);
  var existing = gwFindExistingLibraryFileForSave_(rows, payload);
  var validation = gwValidateLibraryPayload_(payload, existing);
  if (!validation.ok) throw new Error(validation.message);

  var now = gwNow_();
  var libraryFileId = gwToSafeText_(payload.libraryFileId) || (existing ? existing.libraryFileId : gwUuid_('LIB'));
  var rowObj = existing ? Object.assign({}, existing._sourceRow) : {};
  var action = existing ? 'UPDATE' : 'CREATE';
  var status = gwNormalizeLibraryStatus_(payload.status || (existing ? existing.status : 'ACTIVE'));

  rowObj.libraryFileId = libraryFileId;
  rowObj.category = gwNormalizeLibraryCategory_(payload.category || 'GENERAL');
  rowObj.title = gwToSafeText_(payload.title).slice(0, 200);
  rowObj.description = gwToSafeText_(payload.description).slice(0, 2000);
  rowObj.driveFileId = gwToSafeText_(payload.driveFileId).slice(0, 300);
  rowObj.driveFolderId = gwToSafeText_(payload.driveFolderId).slice(0, 300);
  rowObj.fileName = gwToSafeText_(payload.fileName).slice(0, 300);
  rowObj.fileType = gwToSafeText_(payload.fileType).slice(0, 80);
  rowObj.fileSize = gwToSafeText_(payload.fileSize).slice(0, 80);
  rowObj.targetRoleCode = gwToSafeText_(payload.targetRoleCode || 'ALL');
  rowObj.targetVendorId = gwToSafeText_(payload.targetVendorId || 'ALL');
  rowObj.targetEventId = gwToSafeText_(payload.targetEventId || 'ALL');
  rowObj.downloadAllowedYn = gwPayloadYn_(payload.downloadAllowedYn);
  rowObj.status = status;
  rowObj.statusReason = gwToSafeText_(payload.statusReason).slice(0, 500);
  if (!existing) {
    rowObj.createdAt = now;
    rowObj.createdBy = context.employeeId || 'UNKNOWN';
  }
  rowObj.updatedAt = now;
  rowObj.updatedBy = context.employeeId || 'UNKNOWN';

  var rowNumber;
  if (existing && existing._rowNumber) {
    rowNumber = existing._rowNumber;
    var row = headers.map(function (h) { return Object.prototype.hasOwnProperty.call(rowObj, h) ? rowObj[h] : ''; });
    sheet.getRange(rowNumber, 1, 1, headers.length).setValues([row]);
  } else {
    rowNumber = gwAppendObjectRow_(sheet, rowObj, GW_LIBRARY_HEADERS.slice());
  }

  gwAuditSafe_({
    moduleCode: 'GROUPWARE_LIBRARY',
    actionType: action === 'CREATE' ? 'LIBRARY_FILE_CREATE' : 'LIBRARY_FILE_UPDATE',
    targetId: libraryFileId,
    employeeId: context.employeeId,
    resultStatus: 'SUCCESS',
    detailMessage: 'B04 자료 저장: ' + rowObj.title
  });

  return {
    ok: true,
    action: action,
    sheetName: sheet.getName(),
    rowNumber: rowNumber,
    file: gwLibraryFileToUiRow_(gwNormalizeLibraryRow_(Object.assign({ _rowNumber: rowNumber }, rowObj)))
  };
}

function gwCreateLibraryDownloadLog_(libraryFileId, context, resultStatus, payload) {
  var sheet = gwGetFileDownloadLogSheet_(true);
  gwEnsureHeaders_(sheet, GW_FILE_DOWNLOAD_LOG_HEADERS.slice());
  var rowObj = {
    downloadLogId: gwUuid_('DL'),
    libraryFileId: libraryFileId,
    employeeId: context.employeeId || 'UNKNOWN',
    downloadedAt: gwNow_(),
    resultStatus: resultStatus || 'SUCCESS',
    createdAt: gwNow_(),
    createdBy: context.employeeId || 'UNKNOWN',
    ip: gwToSafeText_(payload && payload.ip),
    userAgent: gwToSafeText_(payload && payload.userAgent)
  };
  var rowNumber = gwAppendObjectRow_(sheet, rowObj, GW_FILE_DOWNLOAD_LOG_HEADERS.slice());
  gwAuditSafe_({
    moduleCode: 'GROUPWARE_LIBRARY',
    actionType: 'LIBRARY_DOWNLOAD_LOG',
    targetId: libraryFileId,
    employeeId: context.employeeId,
    resultStatus: resultStatus || 'SUCCESS',
    detailMessage: 'B04 자료 다운로드 로그 기록'
  });
  return { ok: true, rowNumber: rowNumber, downloadLogId: rowObj.downloadLogId, sheetName: sheet.getName() };
}

function gwFindLibraryFileById_(libraryFileId) {
  libraryFileId = gwToSafeText_(libraryFileId);
  if (!libraryFileId) return null;
  var sheet = gwGetLibrarySheet_(true);
  var rows = gwReadRowsAsObjects_(sheet);
  for (var i = 0; i < rows.length; i++) {
    var file = gwNormalizeLibraryRow_(rows[i]);
    if (file.libraryFileId === libraryFileId) return file;
  }
  return null;
}

function gwFindExistingLibraryFileForSave_(rows, payload) {
  var libraryFileId = gwToSafeText_(payload.libraryFileId);
  if (!libraryFileId) return null;
  for (var i = 0; i < rows.length; i++) {
    var file = gwNormalizeLibraryRow_(rows[i]);
    if (file.libraryFileId === libraryFileId) return file;
  }
  return null;
}

function gwNormalizeLibraryRow_(row) {
  row = row || {};
  return {
    libraryFileId: gwToSafeText_(row.libraryFileId),
    category: gwNormalizeLibraryCategory_(row.category),
    title: gwToSafeText_(row.title),
    description: gwToSafeText_(row.description),
    driveFileId: gwToSafeText_(row.driveFileId),
    driveFolderId: gwToSafeText_(row.driveFolderId),
    fileName: gwToSafeText_(row.fileName),
    fileType: gwToSafeText_(row.fileType),
    fileSize: gwToSafeText_(row.fileSize),
    targetRoleCode: gwToSafeText_(row.targetRoleCode || 'ALL'),
    targetVendorId: gwToSafeText_(row.targetVendorId || 'ALL'),
    targetEventId: gwToSafeText_(row.targetEventId || 'ALL'),
    downloadAllowedYn: gwPayloadYn_(row.downloadAllowedYn),
    status: gwNormalizeLibraryStatus_(row.status),
    statusReason: gwToSafeText_(row.statusReason),
    createdAt: row.createdAt,
    createdBy: gwToSafeText_(row.createdBy),
    updatedAt: row.updatedAt,
    updatedBy: gwToSafeText_(row.updatedBy),
    _rowNumber: row._rowNumber,
    _sourceRow: row
  };
}

function gwLibraryFileToUiRow_(file) {
  return {
    libraryFileId: gwToSafeText_(file.libraryFileId),
    category: gwToSafeText_(file.category),
    title: gwToSafeText_(file.title),
    description: gwToSafeText_(file.description),
    driveFileId: gwToSafeText_(file.driveFileId),
    driveFolderId: gwToSafeText_(file.driveFolderId),
    fileName: gwToSafeText_(file.fileName),
    fileType: gwToSafeText_(file.fileType),
    fileSize: gwToSafeText_(file.fileSize),
    targetRoleCode: gwToSafeText_(file.targetRoleCode),
    targetVendorId: gwToSafeText_(file.targetVendorId),
    targetEventId: gwToSafeText_(file.targetEventId),
    downloadAllowedYn: gwPayloadYn_(file.downloadAllowedYn),
    status: gwToSafeText_(file.status),
    statusReason: gwToSafeText_(file.statusReason),
    createdAt: gwDateDisplayText_(file.createdAt),
    createdBy: gwToSafeText_(file.createdBy),
    updatedAt: gwDateDisplayText_(file.updatedAt),
    updatedBy: gwToSafeText_(file.updatedBy),
    _rowNumber: file._rowNumber
  };
}

function gwIsLibraryFileVisibleToContext_(file, context) {
  if (!file) return false;
  context = context || gwGetUserContextSafe_();
  if (gwCanSafe_(context, 'canAccessDevConsole')) return true;
  if (file.status !== 'ACTIVE') return false;
  if (!gwNormalizeYn_(file.downloadAllowedYn) && !gwCanSafe_(context, 'canDownloadFiles')) return false;
  if (!gwLibraryTargetMatches_(file.targetRoleCode, context.roleCode)) return false;
  if (!gwLibraryTargetMatches_(file.targetVendorId, context.vendorId)) return false;
  if (!gwLibraryTargetMatches_(file.targetEventId, context.eventId)) return false;
  return true;
}

function gwLibraryTargetMatches_(targetText, actualValue) {
  targetText = gwToSafeText_(targetText);
  actualValue = gwToSafeText_(actualValue);
  if (!targetText || targetText.toUpperCase() === 'ALL' || targetText === '*') return true;
  var parts = targetText.split(',').map(function (p) { return gwToSafeText_(p); }).filter(function (p) { return p; });
  if (parts.length === 0) return true;
  return parts.some(function (p) { return p.toUpperCase() === 'ALL' || p === '*' || p === actualValue || p.toUpperCase() === actualValue.toUpperCase(); });
}

function gwValidateLibraryPayload_(payload, existing) {
  if (!gwToSafeText_(payload.title)) return { ok: false, message: '자료 제목은 필수입니다.' };
  if (!gwToSafeText_(payload.driveFileId)) return { ok: false, message: 'Drive fileId는 필수입니다.' };
  var status = gwNormalizeLibraryStatus_(payload.status || (existing ? existing.status : 'ACTIVE'));
  if (GW_LIBRARY_STATUSES.indexOf(status) < 0) return { ok: false, message: '허용되지 않은 자료 상태입니다: ' + status };
  return { ok: true };
}

function gwSanitizeLibraryPayload_(payload) {
  var clean = {};
  ['libraryFileId', 'category', 'title', 'description', 'driveFileId', 'driveFolderId', 'fileName', 'fileType', 'fileSize', 'targetRoleCode', 'targetVendorId', 'targetEventId', 'downloadAllowedYn', 'status', 'statusReason'].forEach(function (key) {
    if (typeof payload[key] !== 'undefined') clean[key] = payload[key];
  });
  return clean;
}

function gwNormalizeLibraryStatus_(value) {
  var text = gwToSafeText_(value).toUpperCase();
  if (!text) return 'ACTIVE';
  if (text === 'PUBLISHED' || text === 'POSTED' || text === 'OPEN') return 'ACTIVE';
  if (text === 'DISABLED' || text === 'CLOSED') return 'INACTIVE';
  if (GW_LIBRARY_STATUSES.indexOf(text) >= 0) return text;
  return text;
}

function gwNormalizeLibraryCategory_(value) {
  var text = gwToSafeText_(value).toUpperCase();
  if (!text) return 'GENERAL';
  if (GW_LIBRARY_CATEGORIES.indexOf(text) >= 0) return text;
  return 'GENERAL';
}

function gwLibraryDateToMillis_(value) {
  if (!value) return 0;
  if (Object.prototype.toString.call(value) === '[object Date]') return value.getTime();
  var text = gwToSafeText_(value);
  if (!text) return 0;
  var date = new Date(text.replace(/\./g, '-'));
  var time = date.getTime();
  return isNaN(time) ? 0 : time;
}
