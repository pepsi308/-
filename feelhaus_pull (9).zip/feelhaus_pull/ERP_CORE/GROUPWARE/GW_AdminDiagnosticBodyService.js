/**
 * B18 PORTAL body-only UI service for admin diagnostics / logs / feature flags / cell limit guard.
 * This file returns body-only screen models and bodyHtml strings for PORTAL handlers.
 * It must not render module navigation, its own top bar, its own side bar, iframe, preview route, or standalone shell.
 */
const GW_B18_MODULE_CODE = 'GROUPWARE';
const GW_B18_BODY_IDS = Object.freeze(['GW_AdminDiagnosticsBody', 'GW_AuditLogBody', 'GW_FeatureFlagBody', 'GW_LimitGuardBody']);
const GW_B18_FORBIDDEN_VISIBLE_TOKENS = Object.freeze(['<iframe', 'preview route', 'standalone shell', 'data-module-menu', 'gw-own-menu', 'gw-side-menu', 'gw-top-menu', 'fragment menu']);
const GW_B18_CELL_LIMIT = 10000000;

function gwGetB18BodySpecs() {
  return [
    {
      moduleCode: GW_B18_MODULE_CODE,
      menuId: 'gw.diagnostics',
      route: '/groupware/diagnostics',
      handler: 'gwHandleAdminDiagnosticsBody',
      viewFile: 'GW_AdminDiagnosticsBody.html',
      screenId: 'GW_AdminDiagnosticsBody',
      title: '진단 / 설정',
      description: 'GROUPWARE 시트 readiness, 보호 원장, 회귀테스트 상태를 확인하는 PORTAL 본문 화면입니다.',
      permissionCode: 'canAccessDevConsole',
      buttons: [
        { id: 'btnRunDiagnostics', label: '진단 실행', call: 'getAdminDiagnosticSnapshot', style: 'primary' },
        { id: 'btnRunRegression', label: '회귀테스트 확인', call: 'runB10Diagnostics', style: 'secondary' }
      ],
      calls: ['getAdminDiagnosticSnapshot', 'runB10Diagnostics'],
      sheets: ['Portal_AuditLog'],
      logSheet: 'Portal_AuditLog',
      screenStructure: ['화면 제목', '화면 설명', '주요 작업 버튼', '검색 / 필터', '목록 / 입력폼 / 상세', '성공 / 실패 안내문']
    },
    {
      moduleCode: GW_B18_MODULE_CODE,
      menuId: 'gw.auditLogs',
      route: '/groupware/audit-logs',
      handler: 'gwHandleAuditLogBody',
      viewFile: 'GW_AuditLogBody.html',
      screenId: 'GW_AuditLogBody',
      title: '감사로그',
      description: 'Portal_AuditLog 최근 기록을 조회하고 중요 작업 추적 상태를 확인하는 PORTAL 본문 화면입니다.',
      permissionCode: 'canViewLogs',
      buttons: [
        { id: 'btnReloadAuditLogs', label: '감사로그 조회', call: 'listAuditLogs', style: 'primary' }
      ],
      calls: ['listAuditLogs'],
      sheets: ['Portal_AuditLog'],
      logSheet: 'Portal_AuditLog',
      screenStructure: ['화면 제목', '화면 설명', '주요 작업 버튼', '검색 / 필터', '목록 / 입력폼 / 상세', '성공 / 실패 안내문']
    },
    {
      moduleCode: GW_B18_MODULE_CODE,
      menuId: 'gw.featureFlags',
      route: '/groupware/feature-flags',
      handler: 'gwHandleFeatureFlagBody',
      viewFile: 'GW_FeatureFlagBody.html',
      screenId: 'GW_FeatureFlagBody',
      title: '기능 상태 / FeatureFlag',
      description: 'SystemConfig와 기본값 기준 FeatureFlag 상태를 확인하는 PORTAL 본문 화면입니다. 이 화면은 직접 수정하지 않습니다.',
      permissionCode: 'canAccessDevConsole',
      buttons: [
        { id: 'btnReloadFeatureFlags', label: '기능 상태 조회', call: 'getFeatureFlagSnapshot', style: 'primary' }
      ],
      calls: ['getFeatureFlagSnapshot'],
      sheets: ['SystemConfig'],
      logSheet: 'Portal_AuditLog',
      screenStructure: ['화면 제목', '화면 설명', '주요 작업 버튼', '검색 / 필터', '목록 / 입력폼 / 상세', '성공 / 실패 안내문']
    },
    {
      moduleCode: GW_B18_MODULE_CODE,
      menuId: 'gw.limitGuard',
      route: '/groupware/limit-guard',
      handler: 'gwHandleLimitGuardBody',
      viewFile: 'GW_LimitGuardBody.html',
      screenId: 'GW_LimitGuardBody',
      title: '셀 한도 보호',
      description: 'MASTER 스프레드시트 셀 사용량, 위험도, 신규 시트 생성 제한 상태를 확인하는 PORTAL 본문 화면입니다.',
      permissionCode: 'canAccessDevConsole',
      buttons: [
        { id: 'btnReloadLimitGuard', label: '셀 한도 조회', call: 'getCellLimitSnapshot', style: 'primary' }
      ],
      calls: ['getCellLimitSnapshot'],
      sheets: ['FEELHAUS_DB_MASTER'],
      logSheet: 'Portal_AuditLog',
      screenStructure: ['화면 제목', '화면 설명', '주요 작업 버튼', '검색 / 필터', '목록 / 입력폼 / 상세', '성공 / 실패 안내문']
    }
  ];
}

function gwHandleAdminDiagnosticsBody(payload) { return gwBuildB18AdminBody_('GW_AdminDiagnosticsBody', payload || {}); }
function gwHandleAuditLogBody(payload) { return gwBuildB18AdminBody_('GW_AuditLogBody', payload || {}); }
function gwHandleFeatureFlagBody(payload) { return gwBuildB18AdminBody_('GW_FeatureFlagBody', payload || {}); }
function gwHandleLimitGuardBody(payload) { return gwBuildB18AdminBody_('GW_LimitGuardBody', payload || {}); }
function gwHandleDiagnosticsBody(payload) { payload = payload || {}; return gwBuildB18AdminBody_(payload.screenId || 'GW_AdminDiagnosticsBody', payload); }

function gwBuildB18AdminBody_(screenId, payload) {
  payload = payload || {};
  var spec = gwFindB18BodySpec_(screenId);
  gwAssertPermission_(spec.permissionCode || 'canAccessDevConsole');
  var ctx = gwGetUserContextSafe_();
  var diagnostics = screenId === 'GW_AdminDiagnosticsBody' ? gwGetAdminDiagnosticSnapshotForUi({ limit: payload.limit || 10 }) : gwOk_({ modules: [], summary: {} }, 'SKIPPED');
  var auditLogs = screenId === 'GW_AuditLogBody' ? gwListAuditLogsForUi({ limit: payload.limit || 10, query: payload.query || '' }) : gwOk_({ rows: [], totalReturned: 0, sheetName: 'Portal_AuditLog' }, 'SKIPPED');
  var featureFlags = screenId === 'GW_FeatureFlagBody' ? gwGetFeatureFlagSnapshotForUi({}) : gwOk_({ rows: [], flagCounts: {} }, 'SKIPPED');
  var limitGuard = screenId === 'GW_LimitGuardBody' ? gwGetCellLimitSnapshotForUi({ limit: payload.limit || 20 }) : gwOk_({ totalCells: 0, usageRate: 0, riskLevel: 'UNKNOWN', sheets: [] }, 'SKIPPED');
  if (!diagnostics.ok) return diagnostics;
  if (!auditLogs.ok) return auditLogs;
  if (!featureFlags.ok) return featureFlags;
  if (!limitGuard.ok) return limitGuard;
  var model = gwBuildB18AdminBodyModel_(spec, ctx, diagnostics.data, auditLogs.data, featureFlags.data, limitGuard.data, payload);
  return gwOk_(model, spec.title + ' 본문 구성 완료');
}

function gwGetAdminDiagnosticSnapshotForUi(payload) {
  payload = payload || {};
  var protectedAssets = gwGetProtectedAssets_B11();
  var ss = gwGetMasterSpreadsheet_();
  var sheets = protectedAssets.protectedSheets || [];
  var modules = sheets.map(function (sheetName) {
    var sheet = ss.getSheetByName(sheetName);
    return {
      sheetName: sheetName,
      exists: !!sheet,
      maxRows: sheet ? sheet.getMaxRows() : 0,
      maxColumns: sheet ? sheet.getMaxColumns() : 0,
      lastRow: sheet ? sheet.getLastRow() : 0,
      lastColumn: sheet ? sheet.getLastColumn() : 0
    };
  });
  var missing = modules.filter(function (m) { return !m.exists; });
  return gwOk_({
    moduleCode: 'GROUPWARE',
    summary: { protectedSheetCount: modules.length, missingSheetCount: missing.length, missingSheets: missing.map(function (m) { return m.sheetName; }) },
    modules: modules,
    protectedEngineCount: (protectedAssets.protectedEngines || []).length,
    centralRegistryCount: (protectedAssets.centralRegistries || []).length
  }, 'ADMIN_DIAGNOSTIC_SNAPSHOT_OK');
}

function gwListAuditLogsForUi(payload) {
  payload = payload || {};
  var limit = Math.max(1, Math.min(Number(payload.limit || 20), 50));
  var sheet = gwFindAuditSheetNoWrite_();
  if (!sheet) return gwOk_({ rows: [], totalReturned: 0, sheetName: '', message: 'Portal_AuditLog 시트를 찾을 수 없습니다.' }, 'AUDIT_LOG_LIST_EMPTY');
  var headers = gwGetHeaders_(sheet);
  var lastRow = sheet.getLastRow();
  if (lastRow < 2) return gwOk_({ rows: [], totalReturned: 0, sheetName: sheet.getName() }, 'AUDIT_LOG_LIST_EMPTY');
  var startRow = Math.max(2, lastRow - limit + 1);
  var values = sheet.getRange(startRow, 1, lastRow - startRow + 1, Math.max(headers.length, sheet.getLastColumn())).getValues();
  var rows = values.map(function (row, idx) {
    var obj = { rowNumber: startRow + idx };
    headers.forEach(function (h, i) { if (h) obj[h] = row[i]; });
    return obj;
  }).reverse();
  return gwOk_({ rows: rows, totalReturned: rows.length, sheetName: sheet.getName(), lastRow: lastRow }, 'AUDIT_LOG_LIST_OK');
}

function gwGetFeatureFlagSnapshotForUi(payload) {
  var flags = gwGetFeatureFlagSnapshotSafe_();
  var rows = Object.keys(flags).sort().map(function (key) { return { featureKey: key, value: flags[key], enabled: String(flags[key]).toUpperCase() === 'Y' }; });
  var counts = { Y: 0, N: 0, OTHER: 0 };
  rows.forEach(function (r) { if (r.value === 'Y') counts.Y++; else if (r.value === 'N') counts.N++; else counts.OTHER++; });
  return gwOk_({ rows: rows, totalReturned: rows.length, flagCounts: counts }, 'FEATURE_FLAG_SNAPSHOT_OK');
}

function gwGetCellLimitSnapshotForUi(payload) {
  payload = payload || {};
  var ss = gwGetMasterSpreadsheet_();
  var sheets = ss.getSheets();
  var totalCells = 0;
  var sheetRows = sheets.map(function (sheet) {
    var cells = sheet.getMaxRows() * sheet.getMaxColumns();
    totalCells += cells;
    return {
      sheetName: sheet.getName(),
      maxRows: sheet.getMaxRows(),
      maxColumns: sheet.getMaxColumns(),
      cells: cells,
      lastRow: sheet.getLastRow(),
      lastColumn: sheet.getLastColumn()
    };
  }).sort(function (a, b) { return b.cells - a.cells; });
  var usageRate = totalCells / GW_B18_CELL_LIMIT;
  var riskLevel = usageRate >= 0.95 ? 'CRITICAL' : usageRate >= 0.85 ? 'WARNING' : 'OK';
  return gwOk_({
    spreadsheetName: ss.getName(),
    spreadsheetId: ss.getId(),
    sheetCount: sheets.length,
    totalCells: totalCells,
    cellLimit: GW_B18_CELL_LIMIT,
    usageRate: usageRate,
    usagePercent: Math.round(usageRate * 10000) / 100,
    riskLevel: riskLevel,
    newSheetGuard: riskLevel === 'CRITICAL' ? 'BLOCK_NEW_SHEET' : 'ALLOW_WITH_CAUTION',
    sheets: sheetRows.slice(0, Math.max(1, Math.min(Number(payload.limit || 20), 50)))
  }, 'CELL_LIMIT_SNAPSHOT_OK');
}

function gwBuildB18AdminBodyModel_(spec, ctx, diagnostics, auditLogs, featureFlags, limitGuard, payload) {
  var model = {
    moduleCode: GW_B18_MODULE_CODE,
    screenId: spec.screenId,
    menuId: spec.menuId,
    route: spec.route,
    handler: spec.handler,
    title: spec.title,
    description: spec.description,
    permissionCode: spec.permissionCode,
    actions: spec.buttons,
    filters: [
      { id: 'gwB18Query', label: '검색', field: 'query', value: gwToSafeText_(payload.query || ''), placeholder: '검색어' }
    ],
    diagnostics: diagnostics,
    auditLogList: { title: '감사로그', totalReturned: auditLogs.totalReturned || 0, columns: ['rowNumber', 'createdAt', 'employeeId', 'actionType', 'targetId', 'result'], rows: auditLogs.rows || [], sheetName: auditLogs.sheetName || 'Portal_AuditLog' },
    featureFlagList: { title: 'FeatureFlag', totalReturned: featureFlags.totalReturned || 0, columns: ['featureKey', 'value', 'enabled'], rows: featureFlags.rows || [], flagCounts: featureFlags.flagCounts || {} },
    limitGuard: limitGuard,
    messages: [
      { type: 'info', text: 'PORTAL 중앙 메뉴에서 열린 본문 화면입니다. 이 화면은 메뉴를 렌더링하지 않습니다.' },
      { type: 'success', text: '진단 결과와 셀 한도 위험은 성공/실패 안내문 영역에 표시합니다.' },
      { type: 'warning', text: '셀 한도 위험이 CRITICAL이면 신규 시트 생성 대신 기존 원장 fallback을 우선합니다.' }
    ],
    apiCalls: spec.calls,
    readSheets: spec.sheets,
    logSheet: 'Portal_AuditLog',
    currentUser: { employeeId: ctx.employeeId, roleCode: ctx.roleCode }
  };
  model.bodyHtml = gwRenderB18AdminBodyHtml_(model);
  model.bodyAudit = gwValidateB18BodyModel_(model);
  return model;
}

function gwRenderB18AdminBodyHtml_(model) {
  var rows = [];
  if (model.screenId === 'GW_AdminDiagnosticsBody') rows = (model.diagnostics.modules || []).slice(0, 10).map(function (m) { return '<tr><td>' + gwEscHtml_(m.sheetName) + '</td><td>' + (m.exists ? 'OK' : 'MISSING') + '</td><td>' + m.lastRow + '</td><td>' + m.lastColumn + '</td></tr>'; });
  if (model.screenId === 'GW_AuditLogBody') rows = (model.auditLogList.rows || []).slice(0, 10).map(function (r) { return '<tr><td>' + gwEscHtml_(r.rowNumber) + '</td><td>' + gwEscHtml_(r.createdAt || '') + '</td><td>' + gwEscHtml_(r.employeeId || '') + '</td><td>' + gwEscHtml_(r.actionType || r.action || '') + '</td></tr>'; });
  if (model.screenId === 'GW_FeatureFlagBody') rows = (model.featureFlagList.rows || []).slice(0, 15).map(function (r) { return '<tr><td>' + gwEscHtml_(r.featureKey) + '</td><td>' + gwEscHtml_(r.value) + '</td><td>' + (r.enabled ? '활성' : '비활성') + '</td></tr>'; });
  if (model.screenId === 'GW_LimitGuardBody') rows = (model.limitGuard.sheets || []).slice(0, 15).map(function (r) { return '<tr><td>' + gwEscHtml_(r.sheetName) + '</td><td>' + gwEscHtml_(r.maxRows) + '</td><td>' + gwEscHtml_(r.maxColumns) + '</td><td>' + gwEscHtml_(r.cells) + '</td></tr>'; });
  return '' +
    '<section class="gw-body gw-b18-body" data-screen-id="' + gwEscHtml_(model.screenId) + '">' +
    '<header class="gw-body-header"><h2>' + gwEscHtml_(model.title) + '</h2><p>' + gwEscHtml_(model.description) + '</p></header>' +
    '<div class="gw-actions">' + model.actions.map(function (a) { return '<button type="button" data-gw-action="' + gwEscHtml_(a.call) + '">' + gwEscHtml_(a.label) + '</button>'; }).join('') + '</div>' +
    '<div class="gw-filters"><label>검색 <input type="text" data-gw-field="query" placeholder="검색어"></label></div>' +
    '<div class="gw-message-area" data-gw-message-area="true">' + model.messages.map(function (m) { return '<p class="gw-message gw-message-' + gwEscHtml_(m.type) + '">' + gwEscHtml_(m.text) + '</p>'; }).join('') + '</div>' +
    '<div class="gw-summary"><strong>현재 사용자:</strong> ' + gwEscHtml_(model.currentUser.employeeId) + ' / ' + gwEscHtml_(model.currentUser.roleCode) + '</div>' +
    '<div class="gw-limit-summary"><strong>셀 한도:</strong> ' + gwEscHtml_(model.limitGuard.riskLevel || '') + ' ' + gwEscHtml_(model.limitGuard.usagePercent || '') + '%</div>' +
    '<table class="gw-list"><tbody>' + (rows.length ? rows.join('') : '<tr><td>표시할 항목이 없습니다.</td></tr>') + '</tbody></table>' +
    '</section>';
}

function gwFindB18BodySpec_(screenId) {
  var specs = gwGetB18BodySpecs();
  for (var i = 0; i < specs.length; i++) if (specs[i].screenId === screenId) return specs[i];
  throw new Error('B18 본문 스펙을 찾을 수 없습니다: ' + screenId);
}

function gwValidateB18BodyModel_(model) {
  var errors = [];
  var html = String(model.bodyHtml || '');
  if (!model.title) errors.push('화면 제목 누락');
  if (!model.description) errors.push('화면 설명 누락');
  if (!model.actions || model.actions.length === 0) errors.push('주요 작업 버튼 누락');
  if (html.indexOf('data-gw-message-area') < 0) errors.push('성공 / 실패 안내문 영역 누락');
  GW_B18_FORBIDDEN_VISIBLE_TOKENS.forEach(function (token) {
    if (html.toLowerCase().indexOf(String(token).toLowerCase()) >= 0) errors.push('금지 UI 토큰 포함: ' + token);
  });
  return { ok: errors.length === 0, errors: errors, htmlLength: html.length };
}

function gwValidateB18BodyContracts(payload) {
  var specs = gwGetB18BodySpecs();
  var errors = [];
  specs.forEach(function (spec) {
    ['moduleCode', 'menuId', 'route', 'handler', 'viewFile', 'permissionCode', 'screenId'].forEach(function (field) {
      if (!spec[field]) errors.push(spec.screenId + ' 필수 계약 누락: ' + field);
    });
    if (!spec.screenStructure || spec.screenStructure.indexOf('화면 제목') < 0 || spec.screenStructure.indexOf('성공 / 실패 안내문') < 0) {
      errors.push(spec.screenId + ' 허용 화면 구조 누락');
    }
  });
  return gwOk_({ ok: errors.length === 0, errors: errors, specCount: specs.length, portalShellOnly: true }, errors.length ? 'B18_BODY_CONTRACT_ERROR' : 'B18_BODY_CONTRACT_OK');
}

function gwFindAuditSheetNoWrite_() {
  var ss = gwGetMasterSpreadsheet_();
  var candidates = ['Portal_AuditLog', 'PORTAL_AuditLog', 'PORTAL_Log', 'AuditLogs'];
  for (var i = 0; i < candidates.length; i++) {
    var sheet = ss.getSheetByName(candidates[i]);
    if (sheet) return sheet;
  }
  return null;
}

function gwEscHtml_(value) {
  return String(value === null || typeof value === 'undefined' ? '' : value)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}
