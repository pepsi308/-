/**
 * B17 PORTAL body-only UI service for KPI / Asset / Supply / Expense modules.
 * This file returns body-only screen models and bodyHtml strings for PORTAL handlers.
 * It must not render module navigation, its own top bar, its own side bar, iframe, preview route, or standalone shell.
 */
const GW_B17_MODULE_CODE = 'GROUPWARE';
const GW_B17_BODY_IDS = Object.freeze(['GW_KpiBody', 'GW_AssetSupplyBody', 'GW_SupplyRequestBody', 'GW_ExpenseBody']);
const GW_B17_FORBIDDEN_VISIBLE_TOKENS = Object.freeze(['<iframe', 'preview route', 'standalone shell', 'data-module-menu', 'gw-own-menu', 'gw-side-menu', 'gw-top-menu', 'fragment menu']);

function gwGetB17BodySpecs() {
  return [
    {
      moduleCode: GW_B17_MODULE_CODE,
      menuId: 'gw.kpi',
      route: '/groupware/kpi',
      handler: 'gwHandleKpiBody',
      viewFile: 'GW_KpiBody.html',
      screenId: 'GW_KpiBody',
      title: '직원 KPI / 성과관리',
      description: '직원별 KPI 목록, 상세, 수기 등록, score 평가를 담당하는 PORTAL 본문 화면입니다.',
      permissionCode: 'canAccessPortal',
      buttons: [
        { id: 'btnReloadKpis', label: 'KPI 조회', call: 'listKpis', style: 'primary' },
        { id: 'btnSaveKpi', label: 'KPI 저장', call: 'saveKpi', style: 'secondary' },
        { id: 'btnEvaluateKpi', label: 'KPI 평가', call: 'evaluateKpi', style: 'success' }
      ],
      calls: ['listKpis', 'getKpiDetail', 'saveKpi', 'evaluateKpi'],
      sheets: ['Portal_KPI'],
      logSheet: 'Portal_AuditLog',
      screenStructure: ['화면 제목', '화면 설명', '주요 작업 버튼', '검색 / 필터', '목록 / 입력폼 / 상세', '성공 / 실패 안내문']
    },
    {
      moduleCode: GW_B17_MODULE_CODE,
      menuId: 'gw.assets',
      route: '/groupware/assets',
      handler: 'gwHandleAssetSupplyBody',
      viewFile: 'GW_AssetSupplyBody.html',
      screenId: 'GW_AssetSupplyBody',
      title: '총무 / 자산 / 비품',
      description: '자산대장과 비품 목록을 조회하고 등록/수정하는 PORTAL 본문 화면입니다. 회계/재고 원장 직접 반영은 하지 않습니다.',
      permissionCode: 'canAccessPortal',
      buttons: [
        { id: 'btnReloadAssets', label: '자산 조회', call: 'listAssets', style: 'primary' },
        { id: 'btnSaveAsset', label: '자산 저장', call: 'saveAsset', style: 'secondary' },
        { id: 'btnReloadSupplies', label: '비품 조회', call: 'listSupplies', style: 'primary' },
        { id: 'btnSaveSupply', label: '비품 저장', call: 'saveSupply', style: 'secondary' }
      ],
      calls: ['listAssets', 'getAssetDetail', 'saveAsset', 'listSupplies', 'getSupplyDetail', 'saveSupply'],
      sheets: ['Portal_Assets', 'Portal_Supplies'],
      logSheet: 'Portal_AuditLog',
      screenStructure: ['화면 제목', '화면 설명', '주요 작업 버튼', '검색 / 필터', '목록 / 입력폼 / 상세', '성공 / 실패 안내문']
    },
    {
      moduleCode: GW_B17_MODULE_CODE,
      menuId: 'gw.supplyRequests',
      route: '/groupware/supply-requests',
      handler: 'gwHandleSupplyRequestBody',
      viewFile: 'GW_SupplyRequestBody.html',
      screenId: 'GW_SupplyRequestBody',
      title: '비품 요청 / 승인',
      description: '비품 요청 등록, 목록, 상세, 승인/반려를 담당하는 PORTAL 본문 화면입니다. 셀 한도 보호를 위해 Portal_Requests fallback 구조를 지원합니다.',
      permissionCode: 'canAccessPortal',
      buttons: [
        { id: 'btnReloadSupplyRequests', label: '비품요청 조회', call: 'listSupplyRequests', style: 'primary' },
        { id: 'btnSaveSupplyRequest', label: '비품요청 저장', call: 'saveSupplyRequest', style: 'secondary' },
        { id: 'btnApproveSupplyRequest', label: '승인', call: 'approveSupplyRequest', style: 'success' },
        { id: 'btnRejectSupplyRequest', label: '반려', call: 'rejectSupplyRequest', style: 'danger' }
      ],
      calls: ['listSupplyRequests', 'getSupplyRequestDetail', 'saveSupplyRequest', 'approveSupplyRequest', 'rejectSupplyRequest'],
      sheets: ['Portal_Requests', 'Portal_Approvals'],
      logSheet: 'Portal_AuditLog',
      screenStructure: ['화면 제목', '화면 설명', '주요 작업 버튼', '검색 / 필터', '목록 / 입력폼 / 상세', '성공 / 실패 안내문']
    },
    {
      moduleCode: GW_B17_MODULE_CODE,
      menuId: 'gw.expenses',
      route: '/groupware/expenses',
      handler: 'gwHandleExpenseBody',
      viewFile: 'GW_ExpenseBody.html',
      screenId: 'GW_ExpenseBody',
      title: '구매 / 지출 / 비용',
      description: '비용요청 등록, 목록, 상세, 영수증 fileId, 승인/반려를 담당하는 PORTAL 본문 화면입니다. 정산 원장 직접 반영은 금지합니다.',
      permissionCode: 'canAccessPortal',
      buttons: [
        { id: 'btnReloadExpenses', label: '비용요청 조회', call: 'listExpenses', style: 'primary' },
        { id: 'btnSaveExpense', label: '비용요청 저장', call: 'saveExpense', style: 'secondary' },
        { id: 'btnApproveExpense', label: '승인', call: 'approveExpense', style: 'success' },
        { id: 'btnRejectExpense', label: '반려', call: 'rejectExpense', style: 'danger' }
      ],
      calls: ['listExpenses', 'getExpenseDetail', 'saveExpense', 'approveExpense', 'rejectExpense'],
      sheets: ['Portal_Requests', 'Portal_Approvals'],
      logSheet: 'Portal_AuditLog',
      screenStructure: ['화면 제목', '화면 설명', '주요 작업 버튼', '검색 / 필터', '목록 / 입력폼 / 상세', '성공 / 실패 안내문']
    }
  ];
}

function gwHandleKpiBody(payload) { return gwBuildB17ManagementBody_('GW_KpiBody', payload || {}); }
function gwHandleAssetSupplyBody(payload) { return gwBuildB17ManagementBody_('GW_AssetSupplyBody', payload || {}); }
function gwHandleSupplyRequestBody(payload) { return gwBuildB17ManagementBody_('GW_SupplyRequestBody', payload || {}); }
function gwHandleExpenseBody(payload) { return gwBuildB17ManagementBody_('GW_ExpenseBody', payload || {}); }
function gwHandleManagementBody(payload) { payload = payload || {}; return gwBuildB17ManagementBody_(payload.screenId || 'GW_KpiBody', payload); }

function gwBuildB17ManagementBody_(screenId, payload) {
  payload = payload || {};
  var spec = gwFindB17BodySpec_(screenId);
  gwAssertPermission_(spec.permissionCode || 'canAccessPortal');
  var ctx = gwGetUserContextSafe_();
  var includeAll = payload.includeAll !== false;
  var kpis = [];
  var assets = [];
  var supplies = [];
  var supplyRequests = [];
  var expenses = [];
  if (screenId === 'GW_KpiBody') {
    var kpiResult = gwListKpisForUi({ includeAll: includeAll, limit: payload.limit || 10, kpiStatus: payload.kpiStatus || 'ALL', kpiCategory: payload.kpiCategory || 'ALL', query: payload.query || '' });
    if (!kpiResult.ok) return kpiResult;
    kpis = (kpiResult.data && kpiResult.data.rows) || [];
  } else if (screenId === 'GW_AssetSupplyBody') {
    var assetResult = gwListAssetsForUi({ includeAll: includeAll, limit: payload.limit || 10, status: payload.assetStatus || 'ALL', category: payload.assetCategory || 'ALL', query: payload.query || '' });
    if (!assetResult.ok) return assetResult;
    var supplyResult = gwListSuppliesForUi({ limit: payload.limit || 10, status: payload.supplyStatus || 'ALL', category: payload.supplyCategory || 'ALL', query: payload.query || '' });
    if (!supplyResult.ok) return supplyResult;
    assets = (assetResult.data && assetResult.data.rows) || [];
    supplies = (supplyResult.data && supplyResult.data.rows) || [];
  } else if (screenId === 'GW_SupplyRequestBody') {
    var srResult = gwListSupplyRequestsForUi({ includeAll: includeAll, limit: payload.limit || 10, requestStatus: payload.requestStatus || 'ALL' });
    if (!srResult.ok) return srResult;
    supplyRequests = (srResult.data && srResult.data.rows) || [];
  } else if (screenId === 'GW_ExpenseBody') {
    var expenseResult = gwListExpensesForUi({ includeAll: includeAll, limit: payload.limit || 10, requestStatus: payload.requestStatus || 'ALL', query: payload.query || '' });
    if (!expenseResult.ok) return expenseResult;
    expenses = (expenseResult.data && expenseResult.data.rows) || [];
  }
  var model = gwBuildB17ManagementBodyModel_(spec, ctx, kpis, assets, supplies, supplyRequests, expenses, payload);
  return gwOk_(model, spec.title + ' 본문 구성 완료');
}

function gwBuildB17ManagementBodyModel_(spec, ctx, kpis, assets, supplies, supplyRequests, expenses, payload) {
  var model = {
    moduleCode: GW_B17_MODULE_CODE,
    screenId: spec.screenId,
    menuId: spec.menuId,
    route: spec.route,
    handler: spec.handler,
    title: spec.title,
    description: spec.description,
    permissionCode: spec.permissionCode,
    actions: spec.buttons,
    filters: [
      { id: 'gwB17Query', label: '검색', field: 'query', value: gwToSafeText_(payload.query || ''), placeholder: '검색어' },
      { id: 'gwB17Status', label: '상태', field: 'status', value: gwToSafeText_(payload.status || payload.requestStatus || 'ALL'), placeholder: 'ALL' }
    ],
    kpiList: { title: 'KPI 목록', totalReturned: kpis.length, columns: ['kpiId', 'employeeId', 'period', 'kpiCategory', 'kpiTitle', 'score', 'kpiStatus'], rows: kpis },
    assetList: { title: '자산 목록', totalReturned: assets.length, columns: ['assetId', 'assetCategory', 'assetName', 'assignedEmployeeId', 'location', 'assetStatus'], rows: assets },
    supplyList: { title: '비품 목록', totalReturned: supplies.length, columns: ['supplyId', 'supplyName', 'category', 'stockQty', 'minQty', 'status'], rows: supplies },
    supplyRequestList: { title: '비품 요청', totalReturned: supplyRequests.length, columns: ['supplyRequestId', 'employeeId', 'supplyId', 'requestQty', 'requestStatus'], rows: supplyRequests },
    expenseList: { title: '비용요청', totalReturned: expenses.length, columns: ['expenseRequestId', 'title', 'amount', 'expenseType', 'paymentMethod', 'receiptFileId', 'requestStatus'], rows: expenses },
    messages: [
      { type: 'info', text: 'PORTAL 중앙 메뉴에서 열린 본문 화면입니다. 이 화면은 메뉴를 렌더링하지 않습니다.' },
      { type: 'success', text: '조회, 저장, 승인, 반려 결과는 성공/실패 안내문 영역에 표시합니다.' },
      { type: 'warning', text: '비품요청과 비용요청은 셀 한도 보호를 위해 Portal_Requests fallback 구조를 사용할 수 있습니다.' }
    ],
    apiCalls: spec.calls,
    readSheets: spec.sheets,
    logSheet: 'Portal_AuditLog',
    currentUser: { employeeId: ctx.employeeId, roleCode: ctx.roleCode }
  };
  model.bodyHtml = gwRenderB17ManagementBodyHtml_(model);
  model.bodyAudit = gwValidateB17BodyModel_(model);
  return model;
}

function gwFindB17BodySpec_(screenId) {
  var specs = gwGetB17BodySpecs();
  for (var i = 0; i < specs.length; i++) if (specs[i].screenId === screenId) return specs[i];
  throw new Error('B17 본문 책임표를 찾을 수 없습니다: ' + screenId);
}

function gwRenderB17ManagementBodyHtml_(model) {
  var mainListHtml = '';
  if (model.screenId === 'GW_KpiBody') mainListHtml = gwRenderB17Table_(model.kpiList, 'data-kpi-id', 'kpiId');
  if (model.screenId === 'GW_AssetSupplyBody') mainListHtml = gwRenderB17Table_(model.assetList, 'data-asset-id', 'assetId') + gwRenderB17Table_(model.supplyList, 'data-supply-id', 'supplyId');
  if (model.screenId === 'GW_SupplyRequestBody') mainListHtml = gwRenderB17Table_(model.supplyRequestList, 'data-supply-request-id', 'supplyRequestId');
  if (model.screenId === 'GW_ExpenseBody') mainListHtml = gwRenderB17Table_(model.expenseList, 'data-expense-request-id', 'expenseRequestId');
  return '' +
    '<section class="gw-body gw-b17-body" data-module-code="' + gwEscHtml_(model.moduleCode) + '" data-screen-id="' + gwEscHtml_(model.screenId) + '">' +
    '<header class="gw-body-header"><h2>' + gwEscHtml_(model.title) + '</h2><p>' + gwEscHtml_(model.description) + '</p></header>' +
    '<div class="gw-body-actions">' + model.actions.map(function (a) { return '<button type="button" data-gw-action="' + gwEscHtml_(a.call) + '" class="gw-action gw-action-' + gwEscHtml_(a.style || 'secondary') + '">' + gwEscHtml_(a.label) + '</button>'; }).join('') + '</div>' +
    '<div class="gw-body-filters">' + model.filters.map(function (f) { return '<label>' + gwEscHtml_(f.label) + '<input data-gw-field="' + gwEscHtml_(f.field) + '" value="' + gwEscHtml_(f.value) + '" placeholder="' + gwEscHtml_(f.placeholder || '') + '"></label>'; }).join('') + '</div>' +
    '<div class="gw-body-content">' + mainListHtml + gwRenderB17InputForm_(model) + '</div>' +
    '<div class="gw-body-messages">' + model.messages.map(function (m) { return '<p class="gw-message gw-message-' + gwEscHtml_(m.type) + '">' + gwEscHtml_(m.text) + '</p>'; }).join('') + '</div>' +
    '</section>';
}

function gwRenderB17Table_(list, dataAttr, idField) {
  var rows = (list.rows || []).map(function (row) {
    var idValue = row[idField] || '';
    return '<tr ' + dataAttr + '="' + gwEscHtml_(idValue) + '">' + list.columns.map(function (col) { return '<td>' + gwEscHtml_(row[col]) + '</td>'; }).join('') + '</tr>';
  }).join('') || '<tr><td colspan="' + list.columns.length + '">표시할 ' + gwEscHtml_(list.title) + ' 데이터가 없습니다.</td></tr>';
  return '<section class="gw-list-block"><h3>' + gwEscHtml_(list.title) + ' <span>(' + list.totalReturned + ')</span></h3><table><thead><tr>' + list.columns.map(function (c) { return '<th>' + gwEscHtml_(c) + '</th>'; }).join('') + '</tr></thead><tbody>' + rows + '</tbody></table></section>';
}

function gwRenderB17InputForm_(model) {
  var fields = [];
  if (model.screenId === 'GW_KpiBody') fields = ['kpiId', 'employeeId', 'period', 'kpiCategory', 'kpiTitle', 'targetValue', 'actualValue', 'score', 'evaluationComment'];
  if (model.screenId === 'GW_AssetSupplyBody') fields = ['assetId', 'assetName', 'assignedEmployeeId', 'supplyId', 'supplyName', 'stockQty', 'location'];
  if (model.screenId === 'GW_SupplyRequestBody') fields = ['supplyRequestId', 'supplyId', 'requestQty', 'statusReason'];
  if (model.screenId === 'GW_ExpenseBody') fields = ['expenseRequestId', 'title', 'amount', 'expenseType', 'paymentMethod', 'receiptFileId'];
  return '<section class="gw-form-block"><h3>입력 / 상세</h3>' + fields.map(function (f) { return '<label>' + gwEscHtml_(f) + '<input data-gw-input="' + gwEscHtml_(f) + '" placeholder="' + gwEscHtml_(f) + '"></label>'; }).join('') + '</section>';
}

function gwValidateB17BodyModel_(model) {
  var errors = [];
  var html = String(model.bodyHtml || '').toLowerCase();
  GW_B17_FORBIDDEN_VISIBLE_TOKENS.forEach(function (token) {
    if (html.indexOf(String(token).toLowerCase()) >= 0) errors.push('금지 UI 토큰 발견: ' + token);
  });
  if (!model.title) errors.push('화면 제목 누락');
  if (!model.description) errors.push('화면 설명 누락');
  if (!model.actions || !model.actions.length) errors.push('주요 작업 버튼 누락');
  if (!model.filters || !model.filters.length) errors.push('검색 / 필터 누락');
  if (!model.messages || !model.messages.length) errors.push('성공 / 실패 안내문 누락');
  if (!model.apiCalls || !model.apiCalls.length) errors.push('API 호출 매핑 누락');
  return { ok: errors.length === 0, errors: errors, htmlLength: model.bodyHtml ? model.bodyHtml.length : 0 };
}

function gwValidateB17BodyContracts(payload) {
  var specs = gwGetB17BodySpecs();
  var errors = [];
  specs.forEach(function (spec) {
    ['moduleCode', 'menuId', 'route', 'handler', 'viewFile', 'permissionCode', 'screenId'].forEach(function (field) {
      if (!spec[field]) errors.push(spec.screenId + ' 필수 계약 누락: ' + field);
    });
    if (!spec.screenStructure || spec.screenStructure.indexOf('화면 제목') < 0 || spec.screenStructure.indexOf('성공 / 실패 안내문') < 0) {
      errors.push(spec.screenId + ' 허용 화면 구조 누락');
    }
  });
  return gwOk_({ ok: errors.length === 0, errors: errors, specCount: specs.length, portalShellOnly: true }, errors.length ? 'B17_BODY_CONTRACT_ERROR' : 'B17_BODY_CONTRACT_OK');
}
