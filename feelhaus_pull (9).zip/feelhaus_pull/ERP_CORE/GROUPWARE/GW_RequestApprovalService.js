const GW_REQUEST_SHEET_CANDIDATES = Object.freeze(['Portal_Requests', 'PORTAL_Requests', 'GW_Requests', 'Requests', 'TaskRequests']);
const GW_REQUEST_PREFERRED_SHEET_NAME = 'Portal_Requests';
const GW_APPROVAL_SHEET_CANDIDATES = Object.freeze(['Portal_Approvals', 'PORTAL_Approvals', 'GW_Approvals', 'Approvals', 'ApprovalLogs']);
const GW_APPROVAL_PREFERRED_SHEET_NAME = 'Portal_Approvals';

const GW_REQUEST_HEADERS = Object.freeze([
  'requestId', 'requestType', 'title', 'content',
  'requesterEmployeeId', 'targetEmployeeId', 'targetVendorId', 'targetEventId',
  'relatedCustomerId', 'relatedContractId', 'relatedDocumentId', 'relatedSettlementId',
  'priority', 'requestStatus', 'statusReason',
  'createdAt', 'createdBy', 'updatedAt', 'updatedBy'
]);

const GW_APPROVAL_HEADERS = Object.freeze([
  'approvalId', 'requestId', 'approvalType', 'approverEmployeeId',
  'approvalStep', 'approvalStatus', 'approvalComment', 'approvedAt', 'rejectedAt',
  'createdAt', 'createdBy', 'updatedAt', 'updatedBy'
]);

const GW_REQUEST_STATUSES = Object.freeze(['DRAFT', 'REQUESTED', 'IN_REVIEW', 'APPROVED', 'REJECTED', 'CANCELED', 'COMPLETED']);
const GW_APPROVAL_STATUSES = Object.freeze(['PENDING', 'APPROVED', 'REJECTED', 'CANCELED', 'SKIPPED']);
const GW_REQUEST_TYPES = Object.freeze(['GENERAL', 'PERMISSION_CHANGE', 'REOPEN', 'DOCUMENT_REISSUE', 'SETTLEMENT_CHANGE', 'CANCEL_SETTLEMENT', 'RECOVERY_PAYMENT', 'ADDITIONAL_PAYMENT', 'SCHEDULE_CHANGE', 'SUPPLY_REQUEST', 'EXPENSE_REQUEST', 'SYSTEM']);
const GW_REQUEST_PRIORITIES = Object.freeze(['LOW', 'NORMAL', 'HIGH', 'URGENT']);

const GW_REQUEST_ALLOWED_TRANSITIONS = Object.freeze({
  DRAFT: ['REQUESTED', 'CANCELED'],
  REQUESTED: ['IN_REVIEW', 'APPROVED', 'REJECTED', 'CANCELED'],
  IN_REVIEW: ['APPROVED', 'REJECTED', 'CANCELED'],
  APPROVED: ['COMPLETED'],
  REJECTED: [],
  CANCELED: [],
  COMPLETED: []
});

function gwGetRequestSheet_(createIfMissing) {
  var ss = gwGetMasterSpreadsheet_();
  for (var i = 0; i < GW_REQUEST_SHEET_CANDIDATES.length; i++) {
    var sheet = ss.getSheetByName(GW_REQUEST_SHEET_CANDIDATES[i]);
    if (sheet) return sheet;
  }
  if (createIfMissing) {
    var created = ss.insertSheet(GW_REQUEST_PREFERRED_SHEET_NAME);
    created.getRange(1, 1, 1, GW_REQUEST_HEADERS.length).setValues([GW_REQUEST_HEADERS]);
    return created;
  }
  throw new Error('업무요청 시트를 찾을 수 없습니다. 허용 시트명: ' + GW_REQUEST_SHEET_CANDIDATES.join(', '));
}

function gwGetApprovalSheet_(createIfMissing) {
  var ss = gwGetMasterSpreadsheet_();
  for (var i = 0; i < GW_APPROVAL_SHEET_CANDIDATES.length; i++) {
    var sheet = ss.getSheetByName(GW_APPROVAL_SHEET_CANDIDATES[i]);
    if (sheet) return sheet;
  }
  if (createIfMissing) {
    var created = ss.insertSheet(GW_APPROVAL_PREFERRED_SHEET_NAME);
    created.getRange(1, 1, 1, GW_APPROVAL_HEADERS.length).setValues([GW_APPROVAL_HEADERS]);
    return created;
  }
  throw new Error('전자결재 시트를 찾을 수 없습니다. 허용 시트명: ' + GW_APPROVAL_SHEET_CANDIDATES.join(', '));
}

function gwEnsureRequestHeaders_() {
  var sheet = gwGetRequestSheet_(true);
  var before = gwGetHeaders_(sheet).filter(function (h) { return h; });
  var result = gwEnsureHeaders_(sheet, GW_REQUEST_HEADERS.slice());
  var after = gwGetHeaders_(sheet).filter(function (h) { return h; });
  return {
    ok: result.ok,
    sheetName: sheet.getName(),
    beforeCount: before.length,
    afterCount: after.length,
    addedHeaders: after.filter(function (h) { return before.indexOf(h) < 0; }),
    missing: result.missing || []
  };
}

function gwEnsureApprovalHeaders_() {
  var sheet = gwGetApprovalSheet_(true);
  var before = gwGetHeaders_(sheet).filter(function (h) { return h; });
  var result = gwEnsureHeaders_(sheet, GW_APPROVAL_HEADERS.slice());
  var after = gwGetHeaders_(sheet).filter(function (h) { return h; });
  return {
    ok: result.ok,
    sheetName: sheet.getName(),
    beforeCount: before.length,
    afterCount: after.length,
    addedHeaders: after.filter(function (h) { return before.indexOf(h) < 0; }),
    missing: result.missing || []
  };
}

function gwInspectRequestHeadersNoWrite_B05_() {
  var ss = gwGetMasterSpreadsheet_();
  var requestSheet = null;
  var approvalSheet = null;
  for (var i = 0; i < GW_REQUEST_SHEET_CANDIDATES.length; i++) {
    requestSheet = ss.getSheetByName(GW_REQUEST_SHEET_CANDIDATES[i]);
    if (requestSheet) break;
  }
  for (var j = 0; j < GW_APPROVAL_SHEET_CANDIDATES.length; j++) {
    approvalSheet = ss.getSheetByName(GW_APPROVAL_SHEET_CANDIDATES[j]);
    if (approvalSheet) break;
  }
  var result = {
    ok: true,
    mode: 'NO_WRITE_INSPECT',
    requestSheetExists: !!requestSheet,
    approvalSheetExists: !!approvalSheet,
    requestSheetName: requestSheet ? requestSheet.getName() : '',
    approvalSheetName: approvalSheet ? approvalSheet.getName() : '',
    preferredRequestSheetName: GW_REQUEST_PREFERRED_SHEET_NAME,
    preferredApprovalSheetName: GW_APPROVAL_PREFERRED_SHEET_NAME,
    requiredRequestHeaderCount: GW_REQUEST_HEADERS.length,
    requiredApprovalHeaderCount: GW_APPROVAL_HEADERS.length,
    prepareRequired: false,
    missingRequestHeaders: [],
    missingApprovalHeaders: []
  };
  if (!requestSheet) {
    result.prepareRequired = true;
    result.message = '업무요청 시트가 아직 없습니다. gwInternalTest_B05_HeaderEnsure()에서 생성됩니다.';
  } else {
    var reqCheck = gwCheckRequiredHeaders_(requestSheet, GW_REQUEST_HEADERS.slice());
    result.requestHeaderCount = reqCheck.headers.length;
    result.missingRequestHeaders = reqCheck.missing || [];
    if (!reqCheck.ok) result.prepareRequired = true;
  }
  if (!approvalSheet) {
    result.prepareRequired = true;
    result.approvalMessage = '전자결재 시트가 아직 없습니다. gwInternalTest_B05_HeaderEnsure()에서 생성됩니다.';
  } else {
    var appCheck = gwCheckRequiredHeaders_(approvalSheet, GW_APPROVAL_HEADERS.slice());
    result.approvalHeaderCount = appCheck.headers.length;
    result.missingApprovalHeaders = appCheck.missing || [];
    if (!appCheck.ok) result.prepareRequired = true;
  }
  return result;
}

function gwGetB05RequestApprovalMeta_() {
  return {
    buildStep: '05/10',
    requestSheetCandidates: GW_REQUEST_SHEET_CANDIDATES.slice(),
    approvalSheetCandidates: GW_APPROVAL_SHEET_CANDIDATES.slice(),
    requestStatuses: GW_REQUEST_STATUSES.slice(),
    approvalStatuses: GW_APPROVAL_STATUSES.slice(),
    requestTypes: GW_REQUEST_TYPES.slice(),
    priorities: GW_REQUEST_PRIORITIES.slice(),
    requiredRequestHeaders: GW_REQUEST_HEADERS.slice(),
    requiredApprovalHeaders: GW_APPROVAL_HEADERS.slice()
  };
}

function gwListRequestsForUi(payload) {
  payload = payload || {};
  var context = gwAssertPermission_('canAccessPortal');
  var sheet = gwGetRequestSheet_(true);
  gwEnsureHeaders_(sheet, GW_REQUEST_HEADERS.slice());
  var rows = gwReadRowsAsObjects_(sheet).map(function (row) { return gwNormalizeRequestRow_(row); });
  var query = gwToSafeText_(payload.query).toLowerCase();
  var status = gwToSafeText_(payload.requestStatus || payload.status).toUpperCase();
  var type = gwToSafeText_(payload.requestType).toUpperCase();
  var includeAll = payload.includeAll === true && (gwCanSafe_(context, 'canApprove') || gwCanSafe_(context, 'canAccessDevConsole'));
  var limit = Math.min(Number(payload.limit || 100), 500);
  rows = rows.filter(function (req) {
    if (!includeAll && !gwIsRequestVisibleToContext_(req, context)) return false;
    if (status && status !== 'ALL' && req.requestStatus !== status) return false;
    if (type && type !== 'ALL' && req.requestType !== type) return false;
    if (query) {
      var hay = [req.requestId, req.requestType, req.title, req.content, req.requesterEmployeeId, req.targetEmployeeId, req.targetVendorId, req.targetEventId, req.relatedCustomerId, req.relatedContractId, req.relatedDocumentId, req.relatedSettlementId, req.priority, req.requestStatus].join(' ').toLowerCase();
      if (hay.indexOf(query) < 0) return false;
    }
    return true;
  });
  rows.sort(function (a, b) { return gwRequestDateToMillis_(b.updatedAt || b.createdAt) - gwRequestDateToMillis_(a.updatedAt || a.createdAt); });
  rows = rows.slice(0, limit).map(function (req) { return gwRequestToUiRow_(req); });
  return gwOk_({ rows: rows, totalReturned: rows.length, sheetName: sheet.getName() }, '업무요청 목록 조회 완료');
}

function gwGetRequestDetailForUi(payload) {
  payload = payload || {};
  var context = gwAssertPermission_('canAccessPortal');
  var requestId = gwToSafeText_(payload.requestId);
  if (!requestId) return gwFail_('MISSING_REQUEST_ID', 'requestId가 필요합니다.');
  var req = gwFindRequestById_(requestId);
  if (!req) return gwFail_('REQUEST_NOT_FOUND', '업무요청을 찾을 수 없습니다.', { requestId: requestId });
  if (!gwIsRequestVisibleToContext_(req, context) && !gwCanSafe_(context, 'canApprove') && !gwCanSafe_(context, 'canAccessDevConsole')) {
    return gwFail_('REQUEST_NO_PERMISSION', '해당 업무요청을 조회할 권한이 없습니다.', { requestId: requestId });
  }
  var approvals = gwListApprovalsByRequestId_(requestId).map(function (app) { return gwApprovalToUiRow_(app); });
  return gwOk_({ request: gwRequestToUiRow_(req), approvals: approvals }, '업무요청 상세 조회 완료');
}

function gwSaveRequestForUi(payload) {
  payload = payload || {};
  var context = gwAssertPermission_('canAccessPortal');
  var result = gwSaveRequest_(payload, context, { mode: 'UI' });
  return gwOk_(result, result.action === 'CREATE' ? '업무요청 등록 완료' : '업무요청 수정 완료');
}

function gwApproveRequestForUi(payload) {
  payload = payload || {};
  var context = gwAssertPermission_('canApprove');
  var result = gwProcessRequestDecision_(payload, context, 'APPROVED');
  return gwOk_(result, '업무요청 승인 완료');
}

function gwRejectRequestForUi(payload) {
  payload = payload || {};
  var context = gwAssertPermission_('canApprove');
  var reason = gwToSafeText_(payload.approvalComment || payload.rejectedReason || payload.statusReason);
  if (!reason) return gwFail_('REJECT_REASON_REQUIRED', '반려 사유는 필수입니다.');
  var result = gwProcessRequestDecision_(payload, context, 'REJECTED');
  return gwOk_(result, '업무요청 반려 완료');
}

function gwSaveRequest_(payload, context, options) {
  payload = gwSanitizeRequestPayload_(payload || {});
  context = context || gwGetUserContextSafe_();
  options = options || {};
  var sheet = gwGetRequestSheet_(true);
  gwEnsureHeaders_(sheet, GW_REQUEST_HEADERS.slice());
  var headers = gwGetHeaders_(sheet).filter(function (h) { return h; });
  var rows = gwReadRowsAsObjects_(sheet);
  var existing = gwFindExistingRequestForSave_(rows, payload);
  var validation = gwValidateRequestPayload_(payload, existing);
  if (!validation.ok) throw new Error(validation.message);
  var now = gwNow_();
  var requestId = gwToSafeText_(payload.requestId) || (existing ? existing.requestId : gwUuid_('REQ'));
  var rowObj = existing ? Object.assign({}, existing._sourceRow) : {};
  var action = existing ? 'UPDATE' : 'CREATE';
  var nextStatus = gwNormalizeRequestStatus_(payload.requestStatus || payload.status || (existing ? existing.requestStatus : 'REQUESTED'));

  if (existing && existing.requestStatus !== nextStatus && !gwCanRequestTransition_(existing.requestStatus, nextStatus, context)) {
    throw new Error('허용되지 않은 업무요청 상태전이입니다: ' + existing.requestStatus + ' → ' + nextStatus);
  }

  rowObj.requestId = requestId;
  rowObj.requestType = gwNormalizeRequestType_(payload.requestType || 'GENERAL');
  rowObj.title = gwToSafeText_(payload.title).slice(0, 200);
  rowObj.content = gwToSafeText_(payload.content).slice(0, 3000);
  rowObj.requesterEmployeeId = gwToSafeText_(payload.requesterEmployeeId) || (existing ? existing.requesterEmployeeId : context.employeeId || 'UNKNOWN');
  rowObj.targetEmployeeId = gwToSafeText_(payload.targetEmployeeId);
  rowObj.targetVendorId = gwToSafeText_(payload.targetVendorId);
  rowObj.targetEventId = gwToSafeText_(payload.targetEventId);
  rowObj.relatedCustomerId = gwToSafeText_(payload.relatedCustomerId);
  rowObj.relatedContractId = gwToSafeText_(payload.relatedContractId);
  rowObj.relatedDocumentId = gwToSafeText_(payload.relatedDocumentId);
  rowObj.relatedSettlementId = gwToSafeText_(payload.relatedSettlementId);
  rowObj.priority = gwNormalizeRequestPriority_(payload.priority || 'NORMAL');
  rowObj.requestStatus = nextStatus;
  rowObj.statusReason = gwToSafeText_(payload.statusReason).slice(0, 800);
  if (!existing) {
    rowObj.createdAt = now;
    rowObj.createdBy = context.employeeId || 'UNKNOWN';
  }
  rowObj.updatedAt = now;
  rowObj.updatedBy = context.employeeId || 'UNKNOWN';

  var rowNumber;
  if (existing && existing._rowNumber) {
    rowNumber = existing._rowNumber;
    var row = headers.map(function (h) { return Object.prototype.hasOwnProperty.call(rowObj, h) ? rowObj[h] : ''; });
    sheet.getRange(rowNumber, 1, 1, headers.length).setValues([row]);
  } else {
    rowNumber = gwAppendObjectRow_(sheet, rowObj, GW_REQUEST_HEADERS.slice());
  }

  var approverId = gwToSafeText_(payload.approverEmployeeId) || gwToSafeText_(payload.targetEmployeeId) || '';
  if (approverId && nextStatus === 'REQUESTED') {
    gwCreateOrUpdateApproval_(requestId, approverId, 'REQUEST', 1, 'PENDING', '', context);
  }

  gwAuditSafe_({
    moduleCode: 'GROUPWARE_REQUEST',
    actionType: action === 'CREATE' ? 'REQUEST_CREATE' : 'REQUEST_UPDATE',
    targetId: requestId,
    employeeId: context.employeeId,
    resultStatus: 'SUCCESS',
    detailMessage: 'B05 업무요청 저장: ' + rowObj.title
  });

  return {
    ok: true,
    action: action,
    sheetName: sheet.getName(),
    rowNumber: rowNumber,
    request: gwRequestToUiRow_(gwNormalizeRequestRow_(Object.assign({ _rowNumber: rowNumber }, rowObj)))
  };
}

function gwProcessRequestDecision_(payload, context, decisionStatus) {
  var requestId = gwToSafeText_(payload.requestId);
  if (!requestId) throw new Error('requestId가 필요합니다.');
  var req = gwFindRequestById_(requestId);
  if (!req) throw new Error('업무요청을 찾을 수 없습니다: ' + requestId);
  var nextStatus = gwNormalizeRequestStatus_(decisionStatus);
  if (!gwCanRequestTransition_(req.requestStatus, nextStatus, context)) {
    throw new Error('허용되지 않은 승인 상태전이입니다: ' + req.requestStatus + ' → ' + nextStatus);
  }
  var comment = gwToSafeText_(payload.approvalComment || payload.statusReason || payload.rejectedReason).slice(0, 1000);
  if (nextStatus === 'REJECTED' && !comment) throw new Error('반려 사유는 필수입니다.');

  var saved = gwSaveRequest_(Object.assign({}, req._sourceRow, {
    requestId: req.requestId,
    requestStatus: nextStatus,
    statusReason: comment || (nextStatus === 'APPROVED' ? '승인 완료' : '반려 처리')
  }), context, { mode: 'DECISION' });

  var approval = gwCreateOrUpdateApproval_(req.requestId, context.employeeId || 'UNKNOWN', 'REQUEST', 1, nextStatus, comment, context);

  gwAuditSafe_({
    moduleCode: 'GROUPWARE_APPROVAL',
    actionType: nextStatus === 'APPROVED' ? 'REQUEST_APPROVE' : 'REQUEST_REJECT',
    targetId: req.requestId,
    employeeId: context.employeeId,
    resultStatus: 'SUCCESS',
    detailMessage: 'B05 업무요청 ' + (nextStatus === 'APPROVED' ? '승인' : '반려') + ': ' + req.title
  });

  return { ok: true, request: saved.request, approval: approval };
}

function gwCreateOrUpdateApproval_(requestId, approverEmployeeId, approvalType, approvalStep, approvalStatus, comment, context) {
  var sheet = gwGetApprovalSheet_(true);
  gwEnsureHeaders_(sheet, GW_APPROVAL_HEADERS.slice());
  var headers = gwGetHeaders_(sheet).filter(function (h) { return h; });
  var rows = gwReadRowsAsObjects_(sheet).map(function (row) { return gwNormalizeApprovalRow_(row); });
  var existing = null;
  for (var i = 0; i < rows.length; i++) {
    if (rows[i].requestId === requestId && rows[i].approverEmployeeId === approverEmployeeId && String(rows[i].approvalStep) === String(approvalStep || 1)) {
      existing = rows[i];
      break;
    }
  }
  var now = gwNow_();
  var status = gwNormalizeApprovalStatus_(approvalStatus || 'PENDING');
  var rowObj = existing ? Object.assign({}, existing._sourceRow) : {};
  rowObj.approvalId = existing ? existing.approvalId : gwUuid_('APR');
  rowObj.requestId = requestId;
  rowObj.approvalType = gwToSafeText_(approvalType || 'REQUEST');
  rowObj.approverEmployeeId = gwToSafeText_(approverEmployeeId);
  rowObj.approvalStep = approvalStep || 1;
  rowObj.approvalStatus = status;
  rowObj.approvalComment = gwToSafeText_(comment).slice(0, 1000);
  rowObj.approvedAt = status === 'APPROVED' ? now : (existing ? existing.approvedAt : '');
  rowObj.rejectedAt = status === 'REJECTED' ? now : (existing ? existing.rejectedAt : '');
  if (!existing) {
    rowObj.createdAt = now;
    rowObj.createdBy = context.employeeId || 'UNKNOWN';
  }
  rowObj.updatedAt = now;
  rowObj.updatedBy = context.employeeId || 'UNKNOWN';

  var rowNumber;
  if (existing && existing._rowNumber) {
    rowNumber = existing._rowNumber;
    var row = headers.map(function (h) { return Object.prototype.hasOwnProperty.call(rowObj, h) ? rowObj[h] : ''; });
    sheet.getRange(rowNumber, 1, 1, headers.length).setValues([row]);
  } else {
    rowNumber = gwAppendObjectRow_(sheet, rowObj, GW_APPROVAL_HEADERS.slice());
  }
  return { ok: true, rowNumber: rowNumber, approvalId: rowObj.approvalId, requestId: requestId, approvalStatus: status, sheetName: sheet.getName() };
}

function gwFindRequestById_(requestId) {
  requestId = gwToSafeText_(requestId);
  if (!requestId) return null;
  var sheet = gwGetRequestSheet_(true);
  var rows = gwReadRowsAsObjects_(sheet);
  for (var i = 0; i < rows.length; i++) {
    var req = gwNormalizeRequestRow_(rows[i]);
    if (req.requestId === requestId) return req;
  }
  return null;
}

function gwListApprovalsByRequestId_(requestId) {
  var sheet = gwGetApprovalSheet_(true);
  gwEnsureHeaders_(sheet, GW_APPROVAL_HEADERS.slice());
  return gwReadRowsAsObjects_(sheet).map(function (row) { return gwNormalizeApprovalRow_(row); }).filter(function (app) { return app.requestId === requestId; });
}

function gwFindExistingRequestForSave_(rows, payload) {
  var requestId = gwToSafeText_(payload.requestId);
  if (!requestId) return null;
  for (var i = 0; i < rows.length; i++) {
    var req = gwNormalizeRequestRow_(rows[i]);
    if (req.requestId === requestId) return req;
  }
  return null;
}

function gwNormalizeRequestRow_(row) {
  row = row || {};
  return {
    requestId: gwToSafeText_(row.requestId),
    requestType: gwNormalizeRequestType_(row.requestType),
    title: gwToSafeText_(row.title),
    content: gwToSafeText_(row.content),
    requesterEmployeeId: gwToSafeText_(row.requesterEmployeeId),
    targetEmployeeId: gwToSafeText_(row.targetEmployeeId),
    targetVendorId: gwToSafeText_(row.targetVendorId),
    targetEventId: gwToSafeText_(row.targetEventId),
    relatedCustomerId: gwToSafeText_(row.relatedCustomerId),
    relatedContractId: gwToSafeText_(row.relatedContractId),
    relatedDocumentId: gwToSafeText_(row.relatedDocumentId),
    relatedSettlementId: gwToSafeText_(row.relatedSettlementId),
    priority: gwNormalizeRequestPriority_(row.priority),
    requestStatus: gwNormalizeRequestStatus_(row.requestStatus || row.status),
    statusReason: gwToSafeText_(row.statusReason),
    createdAt: row.createdAt,
    createdBy: gwToSafeText_(row.createdBy),
    updatedAt: row.updatedAt,
    updatedBy: gwToSafeText_(row.updatedBy),
    _rowNumber: row._rowNumber,
    _sourceRow: row
  };
}

function gwNormalizeApprovalRow_(row) {
  row = row || {};
  return {
    approvalId: gwToSafeText_(row.approvalId),
    requestId: gwToSafeText_(row.requestId),
    approvalType: gwToSafeText_(row.approvalType || 'REQUEST'),
    approverEmployeeId: gwToSafeText_(row.approverEmployeeId),
    approvalStep: row.approvalStep || 1,
    approvalStatus: gwNormalizeApprovalStatus_(row.approvalStatus),
    approvalComment: gwToSafeText_(row.approvalComment),
    approvedAt: row.approvedAt,
    rejectedAt: row.rejectedAt,
    createdAt: row.createdAt,
    createdBy: gwToSafeText_(row.createdBy),
    updatedAt: row.updatedAt,
    updatedBy: gwToSafeText_(row.updatedBy),
    _rowNumber: row._rowNumber,
    _sourceRow: row
  };
}

function gwRequestToUiRow_(req) {
  return {
    requestId: req.requestId,
    requestType: req.requestType,
    title: req.title,
    content: req.content,
    requesterEmployeeId: req.requesterEmployeeId,
    targetEmployeeId: req.targetEmployeeId,
    targetVendorId: req.targetVendorId,
    targetEventId: req.targetEventId,
    relatedCustomerId: req.relatedCustomerId,
    relatedContractId: req.relatedContractId,
    relatedDocumentId: req.relatedDocumentId,
    relatedSettlementId: req.relatedSettlementId,
    priority: req.priority,
    requestStatus: req.requestStatus,
    statusReason: req.statusReason,
    createdAt: gwDateDisplayText_(req.createdAt),
    createdBy: req.createdBy,
    updatedAt: gwDateDisplayText_(req.updatedAt),
    updatedBy: req.updatedBy,
    _rowNumber: req._rowNumber
  };
}

function gwApprovalToUiRow_(app) {
  return {
    approvalId: app.approvalId,
    requestId: app.requestId,
    approvalType: app.approvalType,
    approverEmployeeId: app.approverEmployeeId,
    approvalStep: app.approvalStep,
    approvalStatus: app.approvalStatus,
    approvalComment: app.approvalComment,
    approvedAt: gwDateDisplayText_(app.approvedAt),
    rejectedAt: gwDateDisplayText_(app.rejectedAt),
    createdAt: gwDateDisplayText_(app.createdAt),
    createdBy: app.createdBy,
    updatedAt: gwDateDisplayText_(app.updatedAt),
    updatedBy: app.updatedBy,
    _rowNumber: app._rowNumber
  };
}

function gwIsRequestVisibleToContext_(req, context) {
  if (!req) return false;
  context = context || gwGetUserContextSafe_();
  if (gwCanSafe_(context, 'canAccessDevConsole') || gwCanSafe_(context, 'canApprove')) return true;
  if (req.requesterEmployeeId && req.requesterEmployeeId === context.employeeId) return true;
  if (req.targetEmployeeId && req.targetEmployeeId === context.employeeId) return true;
  if (req.targetVendorId && req.targetVendorId === context.vendorId) return true;
  if (req.targetEventId && req.targetEventId === context.eventId) return true;
  return false;
}

function gwValidateRequestPayload_(payload, existing) {
  if (!gwToSafeText_(payload.title)) return { ok: false, message: '업무요청 제목은 필수입니다.' };
  if (!gwToSafeText_(payload.content)) return { ok: false, message: '업무요청 내용은 필수입니다.' };
  var type = gwNormalizeRequestType_(payload.requestType || (existing ? existing.requestType : 'GENERAL'));
  if (GW_REQUEST_TYPES.indexOf(type) < 0) return { ok: false, message: '허용되지 않은 요청 유형입니다: ' + type };
  var status = gwNormalizeRequestStatus_(payload.requestStatus || payload.status || (existing ? existing.requestStatus : 'REQUESTED'));
  if (GW_REQUEST_STATUSES.indexOf(status) < 0) return { ok: false, message: '허용되지 않은 요청 상태입니다: ' + status };
  var priority = gwNormalizeRequestPriority_(payload.priority || 'NORMAL');
  if (GW_REQUEST_PRIORITIES.indexOf(priority) < 0) return { ok: false, message: '허용되지 않은 우선순위입니다: ' + priority };
  return { ok: true };
}

function gwSanitizeRequestPayload_(payload) {
  var clean = {};
  ['requestId', 'requestType', 'title', 'content', 'requesterEmployeeId', 'targetEmployeeId', 'targetVendorId', 'targetEventId', 'relatedCustomerId', 'relatedContractId', 'relatedDocumentId', 'relatedSettlementId', 'priority', 'requestStatus', 'status', 'statusReason', 'approverEmployeeId'].forEach(function (key) {
    if (typeof payload[key] !== 'undefined') clean[key] = payload[key];
  });
  return clean;
}

function gwCanRequestTransition_(fromStatus, toStatus, context) {
  fromStatus = gwNormalizeRequestStatus_(fromStatus || 'DRAFT');
  toStatus = gwNormalizeRequestStatus_(toStatus || fromStatus);
  if (fromStatus === toStatus) return true;
  if (gwCanSafe_(context || gwGetUserContextSafe_(), 'canAccessDevConsole')) return true;
  var allowed = GW_REQUEST_ALLOWED_TRANSITIONS[fromStatus] || [];
  return allowed.indexOf(toStatus) >= 0;
}

function gwNormalizeRequestStatus_(value) {
  var text = gwToSafeText_(value).toUpperCase();
  if (!text) return 'REQUESTED';
  if (text === 'OPEN') return 'REQUESTED';
  if (text === 'DONE') return 'COMPLETED';
  if (text === 'CANCELLED') return 'CANCELED';
  if (GW_REQUEST_STATUSES.indexOf(text) >= 0) return text;
  return text;
}

function gwNormalizeApprovalStatus_(value) {
  var text = gwToSafeText_(value).toUpperCase();
  if (!text) return 'PENDING';
  if (text === 'REQUESTED') return 'PENDING';
  if (text === 'CANCELLED') return 'CANCELED';
  if (GW_APPROVAL_STATUSES.indexOf(text) >= 0) return text;
  return text;
}

function gwNormalizeRequestType_(value) {
  var text = gwToSafeText_(value).toUpperCase();
  if (!text) return 'GENERAL';
  if (text === 'PERMISSION') return 'PERMISSION_CHANGE';
  if (text === 'DOCUMENT') return 'DOCUMENT_REISSUE';
  if (GW_REQUEST_TYPES.indexOf(text) >= 0) return text;
  return 'GENERAL';
}

function gwNormalizeRequestPriority_(value) {
  var text = gwToSafeText_(value).toUpperCase();
  if (!text) return 'NORMAL';
  if (GW_REQUEST_PRIORITIES.indexOf(text) >= 0) return text;
  return 'NORMAL';
}

function gwRequestDateToMillis_(value) {
  if (!value) return 0;
  if (Object.prototype.toString.call(value) === '[object Date]') return value.getTime();
  var text = gwToSafeText_(value);
  if (!text) return 0;
  var date = new Date(text.replace(/\./g, '-'));
  var time = date.getTime();
  return isNaN(time) ? 0 : time;
}
