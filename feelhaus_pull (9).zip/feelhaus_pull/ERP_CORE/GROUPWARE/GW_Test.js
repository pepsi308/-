function gwInternalTest_B01_All() {
  var result = gwRunB01Diagnostics({ writeAudit: true });
  Logger.log('JSON_COMPACT_RESULT: ' + JSON.stringify(gwCompactLogResult_(result)));
  return result;
}

function gwInternalTest_B01_Smoke_NoWrite() {
  var result = gwRunB01Diagnostics({ writeAudit: false });
  Logger.log('JSON_COMPACT_RESULT: ' + JSON.stringify(gwCompactLogResult_(result)));
  return result;
}

function gwInternalTest_B01_MenuOnly() {
  var result = gwOk_({ menus: gwGetMenusForCurrentUser() }, 'B01 메뉴 테스트 완료');
  Logger.log('JSON_COMPACT_RESULT: ' + JSON.stringify(gwCompactLogResult_(result)));
  return result;
}

function gwInternalTest_B01_SystemConfigInspect() {
  var result = gwInspectSystemConfig_B01();
  Logger.log('JSON_COMPACT_RESULT: ' + JSON.stringify(gwCompactLogResult_(result)));
  return result;
}

function gwInternalTest_B02_Smoke_NoWrite() {
  var result = gwRunB02Diagnostics({ ensureHeaders: false, writeTestUser: false });
  Logger.log('JSON_COMPACT_RESULT: ' + JSON.stringify(gwCompactLogResult_(result)));
  return result;
}

function gwInternalTest_B02_HeaderEnsure() {
  var result = gwRunB02Diagnostics({ ensureHeaders: true, writeTestUser: false });
  Logger.log('JSON_COMPACT_RESULT: ' + JSON.stringify(gwCompactLogResult_(result)));
  return result;
}

function gwInternalTest_B02_All() {
  var result = gwRunB02Diagnostics({ ensureHeaders: true, writeTestUser: true });
  Logger.log('JSON_COMPACT_RESULT: ' + JSON.stringify(gwCompactLogResult_(result)));
  return result;
}

function gwInternalTest_B03_Smoke_NoWrite() {
  var result = gwRunB03Diagnostics({ ensureHeaders: false, writeTestNotice: false });
  Logger.log('JSON_COMPACT_RESULT: ' + JSON.stringify(gwCompactLogResult_(result)));
  return result;
}

function gwInternalTest_B03_HeaderEnsure() {
  var result = gwRunB03Diagnostics({ ensureHeaders: true, writeTestNotice: false });
  Logger.log('JSON_COMPACT_RESULT: ' + JSON.stringify(gwCompactLogResult_(result)));
  return result;
}

function gwInternalTest_B03_All() {
  var result = gwRunB03Diagnostics({ ensureHeaders: true, writeTestNotice: true });
  Logger.log('JSON_COMPACT_RESULT: ' + JSON.stringify(gwCompactLogResult_(result)));
  return result;
}


function gwInternalTest_B04_Smoke_NoWrite() {
  var result = gwRunB04Diagnostics({ ensureHeaders: false, writeTestFile: false });
  Logger.log('JSON_COMPACT_RESULT: ' + JSON.stringify(gwCompactLogResult_(result)));
  return result;
}

function gwInternalTest_B04_HeaderEnsure() {
  var result = gwRunB04Diagnostics({ ensureHeaders: true, writeTestFile: false });
  Logger.log('JSON_COMPACT_RESULT: ' + JSON.stringify(gwCompactLogResult_(result)));
  return result;
}

function gwInternalTest_B04_All() {
  var result = gwRunB04Diagnostics({ ensureHeaders: true, writeTestFile: true });
  Logger.log('JSON_COMPACT_RESULT: ' + JSON.stringify(gwCompactLogResult_(result)));
  return result;
}


function gwInternalTest_B05_Smoke_NoWrite() {
  var result = gwRunB05Diagnostics({ ensureHeaders: false, writeTestRequest: false });
  Logger.log('JSON_COMPACT_RESULT: ' + JSON.stringify(gwCompactLogResult_(result)));
  return result;
}

function gwInternalTest_B05_HeaderEnsure() {
  var result = gwRunB05Diagnostics({ ensureHeaders: true, writeTestRequest: false });
  Logger.log('JSON_COMPACT_RESULT: ' + JSON.stringify(gwCompactLogResult_(result)));
  return result;
}

function gwInternalTest_B05_All() {
  var result = gwRunB05Diagnostics({ ensureHeaders: true, writeTestRequest: true });
  Logger.log('JSON_COMPACT_RESULT: ' + JSON.stringify(gwCompactLogResult_(result)));
  return result;
}


function gwInternalTest_B06_Smoke_NoWrite() {
  var result = gwRunB06Diagnostics({ ensureHeaders: false, writeTestAttendance: false });
  Logger.log('JSON_COMPACT_RESULT: ' + JSON.stringify(gwCompactLogResult_(result)));
  return result;
}

function gwInternalTest_B06_HeaderEnsure() {
  var result = gwRunB06Diagnostics({ ensureHeaders: true, writeTestAttendance: false });
  Logger.log('JSON_COMPACT_RESULT: ' + JSON.stringify(gwCompactLogResult_(result)));
  return result;
}

function gwInternalTest_B06_All() {
  var result = gwRunB06Diagnostics({ ensureHeaders: true, writeTestAttendance: true });
  Logger.log('JSON_COMPACT_RESULT: ' + JSON.stringify(gwCompactLogResult_(result)));
  return result;
}



function gwInternalTest_B07_Smoke_NoWrite() {
  var result = gwRunB07Diagnostics({ ensureHeaders: false, writeTestKpi: false });
  Logger.log('JSON_COMPACT_RESULT: ' + JSON.stringify(gwCompactLogResult_(result)));
  return result;
}

function gwInternalTest_B07_HeaderEnsure() {
  var result = gwRunB07Diagnostics({ ensureHeaders: true, writeTestKpi: false });
  Logger.log('JSON_COMPACT_RESULT: ' + JSON.stringify(gwCompactLogResult_(result)));
  return result;
}

function gwInternalTest_B07_All() {
  var result = gwRunB07Diagnostics({ ensureHeaders: true, writeTestKpi: true });
  Logger.log('JSON_COMPACT_RESULT: ' + JSON.stringify(gwCompactLogResult_(result)));
  return result;
}


function gwInternalTest_B08_Smoke_NoWrite() {
  var result = gwRunB08Diagnostics({ ensureHeaders: false, writeTestAssetSupply: false });
  Logger.log('JSON_COMPACT_RESULT: ' + JSON.stringify(gwCompactLogResult_(result)));
  return result;
}

function gwInternalTest_B08_HeaderEnsure() {
  var result = gwRunB08Diagnostics({ ensureHeaders: true, writeTestAssetSupply: false });
  Logger.log('JSON_COMPACT_RESULT: ' + JSON.stringify(gwCompactLogResult_(result)));
  return result;
}

function gwInternalTest_B08_All() {
  var result = gwRunB08Diagnostics({ ensureHeaders: true, writeTestAssetSupply: true });
  Logger.log('JSON_COMPACT_RESULT: ' + JSON.stringify(gwCompactLogResult_(result)));
  return result;
}


function gwInternalTest_B09_Smoke_NoWrite() {
  var result = gwRunB09Diagnostics({ ensureHeaders: false, writeTestExpense: false });
  Logger.log('JSON_COMPACT_RESULT: ' + JSON.stringify(gwCompactLogResult_(result)));
  return result;
}

function gwInternalTest_B09_HeaderEnsure() {
  var result = gwRunB09Diagnostics({ ensureHeaders: true, writeTestExpense: false });
  Logger.log('JSON_COMPACT_RESULT: ' + JSON.stringify(gwCompactLogResult_(result)));
  return result;
}

function gwInternalTest_B09_All() {
  var result = gwRunB09Diagnostics({ ensureHeaders: true, writeTestExpense: true });
  Logger.log('JSON_COMPACT_RESULT: ' + JSON.stringify(gwCompactLogResult_(result)));
  return result;
}



function gwInternalTest_B10_Smoke_NoWrite() {
  var result = gwRunB10Diagnostics({ writeAudit: false, runRegression: false });
  Logger.log('JSON_COMPACT_RESULT: ' + JSON.stringify(gwCompactLogResult_(result)));
  return result;
}

function gwInternalTest_B10_Regression_NoWrite() {
  var result = gwRunB10Diagnostics({ writeAudit: false, runRegression: true });
  Logger.log('JSON_COMPACT_RESULT: ' + JSON.stringify(gwCompactLogResult_(result)));
  return result;
}

function gwInternalTest_B10_All() {
  var result = gwRunB10Diagnostics({ writeAudit: true, runRegression: true });
  Logger.log('JSON_COMPACT_RESULT: ' + JSON.stringify(gwCompactLogResult_(result)));
  return result;
}

function gwCompactLogResult_(result) {
  if (!result) return result;
  var root = {
    ok: result.ok,
    build: result.build,
    generatedAt: result.generatedAt,
    code: result.code || '',
    message: result.message || ''
  };
  var body = result.data || result.detail || {};
  if (body.buildInfo) root.buildInfo = body.buildInfo;
  if (body.checkedAt) root.checkedAt = body.checkedAt;
  if (typeof body.fatalCount !== 'undefined') root.fatalCount = body.fatalCount;
  if (body.sheetName) root.sheetName = body.sheetName;
  if (body.parsedOk !== undefined) {
    root.parsedOk = body.parsedOk;
    root.parsedMode = body.parsedMode;
    root.detectedHeaderRow = body.detectedHeaderRow;
    root.detectedKeyHeader = body.detectedKeyHeader;
    root.detectedValueHeader = body.detectedValueHeader;
    root.masterDbIdPreview = body.masterDbIdPreview;
    root.configKeyCount = body.configKeyCount || 0;
    root.configKeyPreview = body.configKeyPreview || [];
  }
  if (body.checks && body.checks.length) {
    root.checks = body.checks.map(function (c) {
      var item = { name: c.name, ok: c.ok, message: c.message || '' };
      if (c.data) item.data = gwCompactCheckData_(c.name, c.data);
      if (c.stack) item.stack = String(c.stack).slice(0, 500);
      return item;
    });
  }
  return root;
}

function gwCompactCheckData_(name, data) {
  if (name === 'SYSTEM_CONFIG_LOAD') {
    return { ok: data.ok, masterDbIdFound: data.masterDbIdFound, configKeyCount: data.configKeyCount, configKeyPreview: data.configKeyPreview };
  }
  if (name === 'MASTER_DB_CONNECT') return { spreadsheetName: data.spreadsheetName, spreadsheetId: data.spreadsheetId };
  if (name === 'PORTAL_USERS_HEADERS' || name === 'PORTAL_USERS_HEADERS_READ') {
    return { ok: data.ok, sheetName: data.sheetName, headerCount: data.headers ? data.headers.length : data.headerCount || 0, resolvedHeaders: data.resolvedHeaders, missingFieldGroups: data.missingFieldGroups };
  }
  if (name === 'MENU_STATE') {
    var counts = {};
    (data || []).forEach(function (m) { counts[m.status] = (counts[m.status] || 0) + 1; });
    return { menuCount: (data || []).length, statusCounts: counts };
  }
  if (name === 'USER_CONTEXT' || name === 'CURRENT_USER_CONTEXT') {
    return { ok: data.ok, email: data.email, employeeId: data.employeeId, employeeName: data.employeeName, roleCode: data.roleCode, status: data.status };
  }
  if (name === 'FEATURE_FLAGS') {
    var flagCounts = { Y: 0, N: 0, OTHER: 0 };
    Object.keys(data || {}).forEach(function (k) {
      var v = String(data[k] || '').toUpperCase();
      if (v === 'Y') flagCounts.Y++; else if (v === 'N') flagCounts.N++; else flagCounts.OTHER++;
    });
    return { flagCounts: flagCounts };
  }
  if (name === 'B02_PERMISSION_ASSERT') return { ok: data.ok, employeeId: data.employeeId, roleCode: data.roleCode };
  if (name === 'B02_META') return { buildStep: data.buildStep, permissionFieldCount: data.permissionFields ? data.permissionFields.length : 0, ynFieldCount: data.ynFields ? data.ynFields.length : 0 };
  if (name === 'B02_ENSURE_HEADERS') return { ok: data.ok, addedHeaders: data.addedHeaders || [], beforeCount: data.beforeCount, afterCount: data.afterCount };
  if (name === 'B02_TEST_USER_UPSERT') return { ok: data.ok, action: data.action, sheetName: data.sheetName, rowNumber: data.rowNumber, employeeId: data.user && data.user.employeeId, email: data.user && data.user.email, ensuredHeaders: data.ensuredHeaders || [] };
  if (name === 'B02_DUPLICATE_EMAIL_BLOCK') return { ok: data.ok, blocked: data.blocked, message: data.message };
  if (name === 'B03_PERMISSION_ASSERT') return { ok: data.ok, employeeId: data.employeeId, roleCode: data.roleCode };
  if (name === 'B03_META') return { buildStep: data.buildStep, noticeStatuses: data.noticeStatuses, noticeTypes: data.noticeTypes, requiredHeaderCount: data.requiredHeaders ? data.requiredHeaders.length : 0 };
  if (name === 'B03_NOTICE_HEADERS_READ') return { ok: data.ok, mode: data.mode, prepareRequired: data.prepareRequired, noticeSheetExists: data.noticeSheetExists, noticeReadSheetExists: data.noticeReadSheetExists, noticeSheetName: data.noticeSheetName, noticeReadSheetName: data.noticeReadSheetName, missingNoticeHeaders: data.missingNoticeHeaders || [], missingNoticeReadHeaders: data.missingNoticeReadHeaders || [] };
  if (name === 'B03_ENSURE_NOTICE_HEADERS' || name === 'B03_ENSURE_NOTICE_READ_HEADERS') return { ok: data.ok, sheetName: data.sheetName, addedHeaders: data.addedHeaders || [], beforeCount: data.beforeCount, afterCount: data.afterCount };
  if (name === 'B03_TEST_NOTICE_UPSERT') return { ok: data.ok, action: data.action, sheetName: data.sheetName, rowNumber: data.rowNumber, noticeId: data.notice && data.notice.noticeId, title: data.notice && data.notice.title, status: data.notice && data.notice.status };
  if (name === 'B03_NOTICE_LIST') return { ok: data.ok, totalReturned: data.data && data.data.totalReturned, sheetName: data.data && data.data.sheetName };
  if (name === 'B03_NOTICE_DETAIL') return { ok: data.ok, noticeId: data.data && data.data.notice && data.data.notice.noticeId, title: data.data && data.data.notice && data.data.notice.title, status: data.data && data.data.notice && data.data.notice.status };

  if (name === 'B04_PERMISSION_ASSERT') return { ok: data.ok, employeeId: data.employeeId, roleCode: data.roleCode };
  if (name === 'B04_META') return { buildStep: data.buildStep, libraryStatuses: data.libraryStatuses, categories: data.categories, requiredHeaderCount: data.requiredHeaders ? data.requiredHeaders.length : 0 };
  if (name === 'B04_LIBRARY_HEADERS_READ') return { ok: data.ok, mode: data.mode, prepareRequired: data.prepareRequired, librarySheetExists: data.librarySheetExists, downloadLogSheetExists: data.downloadLogSheetExists, librarySheetName: data.librarySheetName, downloadLogSheetName: data.downloadLogSheetName, missingLibraryHeaders: data.missingLibraryHeaders || [], missingDownloadLogHeaders: data.missingDownloadLogHeaders || [] };
  if (name === 'B04_ENSURE_LIBRARY_HEADERS' || name === 'B04_ENSURE_DOWNLOAD_LOG_HEADERS') return { ok: data.ok, sheetName: data.sheetName, addedHeaders: data.addedHeaders || [], beforeCount: data.beforeCount, afterCount: data.afterCount };
  if (name === 'B04_TEST_LIBRARY_UPSERT') return { ok: data.ok, action: data.action, sheetName: data.sheetName, rowNumber: data.rowNumber, libraryFileId: data.file && data.file.libraryFileId, title: data.file && data.file.title, status: data.file && data.file.status };
  if (name === 'B04_LIBRARY_LIST') return { ok: data.ok, totalReturned: data.data && data.data.totalReturned, sheetName: data.data && data.data.sheetName };
  if (name === 'B04_LIBRARY_DETAIL') return { ok: data.ok, libraryFileId: data.data && data.data.file && data.data.file.libraryFileId, title: data.data && data.data.file && data.data.file.title, status: data.data && data.data.file && data.data.file.status };
  if (name === 'B04_DOWNLOAD_LOG') return { ok: data.ok, downloadLogId: data.data && data.data.log && data.data.log.downloadLogId, sheetName: data.data && data.data.log && data.data.log.sheetName };

  if (name === 'B05_PERMISSION_ASSERT') return { ok: data.ok, employeeId: data.employeeId, roleCode: data.roleCode };
  if (name === 'B05_META') return { buildStep: data.buildStep, requestStatuses: data.requestStatuses, approvalStatuses: data.approvalStatuses, requestTypes: data.requestTypes, requiredRequestHeaderCount: data.requiredRequestHeaders ? data.requiredRequestHeaders.length : 0, requiredApprovalHeaderCount: data.requiredApprovalHeaders ? data.requiredApprovalHeaders.length : 0 };
  if (name === 'B05_REQUEST_HEADERS_READ') return { ok: data.ok, mode: data.mode, prepareRequired: data.prepareRequired, requestSheetExists: data.requestSheetExists, approvalSheetExists: data.approvalSheetExists, requestSheetName: data.requestSheetName, approvalSheetName: data.approvalSheetName, missingRequestHeaders: data.missingRequestHeaders || [], missingApprovalHeaders: data.missingApprovalHeaders || [] };
  if (name === 'B05_ENSURE_REQUEST_HEADERS' || name === 'B05_ENSURE_APPROVAL_HEADERS') return { ok: data.ok, sheetName: data.sheetName, addedHeaders: data.addedHeaders || [], beforeCount: data.beforeCount, afterCount: data.afterCount };
  if (name === 'B05_TEST_REQUEST_UPSERT') return { ok: data.ok, action: data.action, sheetName: data.sheetName, rowNumber: data.rowNumber, requestId: data.request && data.request.requestId, title: data.request && data.request.title, requestStatus: data.request && data.request.requestStatus };
  if (name === 'B05_REQUEST_LIST') return { ok: data.ok, totalReturned: data.data && data.data.totalReturned, sheetName: data.data && data.data.sheetName };
  if (name === 'B05_REQUEST_DETAIL') return { ok: data.ok, requestId: data.data && data.data.request && data.data.request.requestId, title: data.data && data.data.request && data.data.request.title, requestStatus: data.data && data.data.request && data.data.request.requestStatus, approvalCount: data.data && data.data.approvals ? data.data.approvals.length : 0 };
  if (name === 'B05_APPROVE_REQUEST') return { ok: data.ok, requestId: data.data && data.data.request && data.data.request.requestId, requestStatus: data.data && data.data.request && data.data.request.requestStatus, approvalStatus: data.data && data.data.approval && data.data.approval.approvalStatus };

  if (name === 'B06_PERMISSION_ASSERT') return { ok: data.ok, employeeId: data.employeeId, roleCode: data.roleCode };
  if (name === 'B06_META') return { buildStep: data.buildStep, sourceSystem: data.sourceSystem, inputModes: data.inputModes, requiredRawHeaderCount: data.requiredRawHeaderCount, requiredMapHeaderCount: data.requiredMapHeaderCount, requiredAttendanceHeaderCount: data.requiredAttendanceHeaderCount, requiredExceptionHeaderCount: data.requiredExceptionHeaderCount };
  if (name === 'B06_ATTENDANCE_HEADERS_READ') return { ok: data.ok, mode: data.mode, prepareRequired: data.prepareRequired, rawSheetExists: data.rawSheetExists, mapSheetExists: data.mapSheetExists, attendanceSheetExists: data.attendanceSheetExists, exceptionSheetExists: data.exceptionSheetExists, rawSheetName: data.rawSheetName, mapSheetName: data.mapSheetName, attendanceSheetName: data.attendanceSheetName, exceptionSheetName: data.exceptionSheetName, missingRawHeaders: data.missingRawHeaders || [], missingMapHeaders: data.missingMapHeaders || [], missingAttendanceHeaders: data.missingAttendanceHeaders || [], missingExceptionHeaders: data.missingExceptionHeaders || [] };
  if (name === 'B06_ENSURE_CAPS_RAW_HEADERS' || name === 'B06_ENSURE_CAPS_MAP_HEADERS' || name === 'B06_ENSURE_ATTENDANCE_HEADERS' || name === 'B06_ENSURE_ATTENDANCE_EXCEPTION_HEADERS') return { ok: data.ok, sheetName: data.sheetName, addedHeaders: data.addedHeaders || [], beforeCount: data.beforeCount, afterCount: data.afterCount };
  if (name === 'B06_CAPS_TEST_MAP') return { ok: data.ok, action: data.action, sheetName: data.sheetName, rowNumber: data.rowNumber, capsUserId: data.capsUserId, employeeId: data.employeeId };
  if (name === 'B06_CAPS_MOCK_SYNC') return { ok: data.ok, raw: data.data && data.data.raw, apply: data.data && data.data.apply };
  if (name === 'B06_ATTENDANCE_LIST') return { ok: data.ok, totalReturned: data.data && data.data.totalReturned, sheetName: data.data && data.data.sheetName };
  if (name === 'B06_EXCEPTION_LIST') return { ok: data.ok, totalReturned: data.data && data.data.totalReturned, sheetName: data.data && data.data.sheetName };

  if (name === 'B07_PERMISSION_ASSERT') return { ok: data.ok, employeeId: data.employeeId, roleCode: data.roleCode };
  if (name === 'B07_META') return { buildStep: data.buildStep, kpiStatuses: data.kpiStatuses, kpiCategories: data.kpiCategories, requiredKpiHeaderCount: data.requiredKpiHeaders ? data.requiredKpiHeaders.length : 0, mode: data.mode };
  if (name === 'B07_KPI_HEADERS_READ') return { ok: data.ok, mode: data.mode, prepareRequired: data.prepareRequired, kpiSheetExists: data.kpiSheetExists, kpiSheetName: data.kpiSheetName, missingKpiHeaders: data.missingKpiHeaders || [] };
  if (name === 'B07_ENSURE_KPI_HEADERS') return { ok: data.ok, sheetName: data.sheetName, addedHeaders: data.addedHeaders || [], beforeCount: data.beforeCount, afterCount: data.afterCount };
  if (name === 'B07_TEST_KPI_UPSERT') return { ok: data.ok, action: data.action, sheetName: data.sheetName, rowNumber: data.rowNumber, kpiId: data.kpi && data.kpi.kpiId, employeeId: data.kpi && data.kpi.employeeId, score: data.kpi && data.kpi.score, kpiStatus: data.kpi && data.kpi.kpiStatus };
  if (name === 'B07_KPI_LIST') return { ok: data.ok, totalReturned: data.data && data.data.totalReturned, sheetName: data.data && data.data.sheetName };
  if (name === 'B07_KPI_DETAIL') return { ok: data.ok, kpiId: data.data && data.data.kpi && data.data.kpi.kpiId, score: data.data && data.data.kpi && data.data.kpi.score, kpiStatus: data.data && data.data.kpi && data.data.kpi.kpiStatus };
  if (name === 'B07_KPI_EVALUATE') return { ok: data.ok, action: data.action, sheetName: data.sheetName, rowNumber: data.rowNumber, kpiId: data.kpi && data.kpi.kpiId, score: data.kpi && data.kpi.score, kpiStatus: data.kpi && data.kpi.kpiStatus, appliedScore: data.appliedScore };

  if (name === 'B08_PERMISSION_ASSERT') return { ok: data.ok, employeeId: data.employeeId, roleCode: data.roleCode };
  if (name === 'B08_META') return { buildStep: data.buildStep, assetStatuses: data.assetStatuses, supplyStatuses: data.supplyStatuses, supplyRequestStatuses: data.supplyRequestStatuses, requiredAssetHeaderCount: data.requiredAssetHeaders ? data.requiredAssetHeaders.length : 0, requiredSupplyHeaderCount: data.requiredSupplyHeaders ? data.requiredSupplyHeaders.length : 0, requiredSupplyRequestHeaderCount: data.requiredSupplyRequestHeaders ? data.requiredSupplyRequestHeaders.length : 0, mode: data.mode };
  if (name === 'B08_ASSET_SUPPLY_HEADERS_READ') return { ok: data.ok, mode: data.mode, prepareRequired: data.prepareRequired, assetSheetExists: data.assetSheetExists, supplySheetExists: data.supplySheetExists, supplyRequestSheetExists: data.supplyRequestSheetExists, assetSheetName: data.assetSheetName, supplySheetName: data.supplySheetName, supplyRequestSheetName: data.supplyRequestSheetName, missingAssetHeaders: data.missingAssetHeaders || [], missingSupplyHeaders: data.missingSupplyHeaders || [], missingSupplyRequestHeaders: data.missingSupplyRequestHeaders || [] };
  if (name === 'B08_ENSURE_ASSET_HEADERS' || name === 'B08_ENSURE_SUPPLY_HEADERS' || name === 'B08_ENSURE_SUPPLY_REQUEST_HEADERS') return { ok: data.ok, sheetName: data.sheetName, addedHeaders: data.addedHeaders || [], beforeCount: data.beforeCount, afterCount: data.afterCount };
  if (name === 'B08_TEST_ASSET_UPSERT') return { ok: data.ok, action: data.action, sheetName: data.sheetName, rowNumber: data.rowNumber, assetId: data.asset && data.asset.assetId, assetName: data.asset && data.asset.assetName, assetStatus: data.asset && data.asset.assetStatus };
  if (name === 'B08_TEST_SUPPLY_UPSERT') return { ok: data.ok, action: data.action, sheetName: data.sheetName, rowNumber: data.rowNumber, supplyId: data.supply && data.supply.supplyId, supplyName: data.supply && data.supply.supplyName, stockQty: data.supply && data.supply.stockQty, status: data.supply && data.supply.status };
  if (name === 'B08_TEST_SUPPLY_REQUEST_UPSERT') return { ok: data.ok, action: data.action, sheetName: data.sheetName, rowNumber: data.rowNumber, supplyRequestId: data.supplyRequest && data.supplyRequest.supplyRequestId, supplyId: data.supplyRequest && data.supplyRequest.supplyId, requestStatus: data.supplyRequest && data.supplyRequest.requestStatus };
  if (name === 'B08_ASSET_LIST') return { ok: data.ok, totalReturned: data.data && data.data.totalReturned, sheetName: data.data && data.data.sheetName };
  if (name === 'B08_SUPPLY_LIST') return { ok: data.ok, totalReturned: data.data && data.data.totalReturned, sheetName: data.data && data.data.sheetName };
  if (name === 'B08_SUPPLY_REQUEST_LIST') return { ok: data.ok, totalReturned: data.data && data.data.totalReturned, sheetName: data.data && data.data.sheetName };
  if (name === 'B08_ASSET_DETAIL') return { ok: data.ok, assetId: data.data && data.data.asset && data.data.asset.assetId, assetName: data.data && data.data.asset && data.data.asset.assetName, assetStatus: data.data && data.data.asset && data.data.asset.assetStatus };
  if (name === 'B08_SUPPLY_DETAIL') return { ok: data.ok, supplyId: data.data && data.data.supply && data.data.supply.supplyId, supplyName: data.data && data.data.supply && data.data.supply.supplyName, status: data.data && data.data.supply && data.data.supply.status };
  if (name === 'B08_SUPPLY_REQUEST_DETAIL') return { ok: data.ok, supplyRequestId: data.data && data.data.supplyRequest && data.data.supplyRequest.supplyRequestId, requestStatus: data.data && data.data.supplyRequest && data.data.supplyRequest.requestStatus };
  if (name === 'B08_APPROVE_SUPPLY_REQUEST') return { ok: data.ok, action: data.action, sheetName: data.sheetName, rowNumber: data.rowNumber, supplyRequestId: data.supplyRequest && data.supplyRequest.supplyRequestId, requestStatus: data.supplyRequest && data.supplyRequest.requestStatus, approvalStatus: data.approvalStatus };

  if (name === 'B09_PERMISSION_ASSERT') return { ok: data.ok, employeeId: data.employeeId, roleCode: data.roleCode };
  if (name === 'B09_META') return { buildStep: data.buildStep, storageMode: data.storageMode, requestType: data.requestType, expenseStatuses: data.expenseStatuses, expenseTypes: data.expenseTypes, paymentMethods: data.paymentMethods, mode: data.mode, settlementLedgerDirectWrite: data.settlementLedgerDirectWrite, receiptRequiredForApproval: data.receiptRequiredForApproval };
  if (name === 'B09_EXPENSE_HEADERS_READ') return { ok: data.ok, mode: data.mode, storageMode: data.storageMode, expenseSheetExists: data.expenseSheetExists, expenseSheetName: data.expenseSheetName, approvalSheetExists: data.approvalSheetExists, approvalSheetName: data.approvalSheetName, prepareRequired: data.prepareRequired, missingExpenseHeaders: data.missingExpenseHeaders || [], missingApprovalHeaders: data.missingApprovalHeaders || [] };
  if (name === 'B09_ENSURE_EXPENSE_HEADERS') return { ok: data.ok, storageMode: data.storageMode, expenseSheetName: data.expenseSheetName, approvalSheetName: data.approvalSheetName, requestAddedHeaders: data.requestAddedHeaders || [], approvalAddedHeaders: data.approvalAddedHeaders || [], requestBeforeCount: data.requestBeforeCount, requestAfterCount: data.requestAfterCount, approvalBeforeCount: data.approvalBeforeCount, approvalAfterCount: data.approvalAfterCount };
  if (name === 'B09_TEST_EXPENSE_UPSERT') return { ok: data.ok, action: data.action, sheetName: data.sheetName, rowNumber: data.rowNumber, expenseRequestId: data.expense && data.expense.expenseRequestId, title: data.expense && data.expense.title, amount: data.expense && data.expense.amount, requestStatus: data.expense && data.expense.requestStatus };
  if (name === 'B09_EXPENSE_LIST') return { ok: data.ok, totalReturned: data.data && data.data.totalReturned, sheetName: data.data && data.data.sheetName, storageMode: data.data && data.data.storageMode };
  if (name === 'B09_EXPENSE_DETAIL') return { ok: data.ok, expenseRequestId: data.data && data.data.expense && data.data.expense.expenseRequestId, title: data.data && data.data.expense && data.data.expense.title, amount: data.data && data.data.expense && data.data.expense.amount, requestStatus: data.data && data.data.expense && data.data.expense.requestStatus, approvalCount: data.data && data.data.approvals ? data.data.approvals.length : 0 };
  if (name === 'B09_APPROVE_EXPENSE') return { ok: data.ok, action: data.action, sheetName: data.sheetName, expenseRequestId: data.expenseRequestId, requestStatus: data.expense && data.expense.requestStatus, approvalStatus: data.approvalStatus };



  if (name === 'B10_PERMISSION_ASSERT') return { ok: data.ok, employeeId: data.employeeId, roleCode: data.roleCode };
  if (name === 'B10_META') return { buildStep: data.buildStep, importMode: data.importMode, candidateFileCount: data.candidateFileCount, doNotImportFileCount: data.doNotImportFileCount, protectedSheetCount: data.protectedSheetCount, nextPhase: data.nextPhase };
  if (name === 'B10_IMPORT_CANDIDATES') return { ok: data.ok, candidateFileCount: data.candidateFileCount, doNotImportFiles: data.doNotImportFiles, actionCounts: data.actionCounts, typeCounts: data.typeCounts, portalShellHandling: data.portalShellHandling };
  if (name === 'B10_SHEET_READINESS') return { ok: data.ok, moduleCount: data.moduleCount, failedModuleCount: data.failedModuleCount, modules: data.modules, fallbackModes: data.fallbackModes };
  if (name === 'B10_PORTAL_IMPORT_PLAN') return { ok: data.ok, importOrderCount: data.importOrder ? data.importOrder.length : 0, blockedItemCount: data.blockedItems ? data.blockedItems.length : 0, mainDeveloperReviewRequired: data.mainDeveloperReviewRequired, portalImportReadyAfterB10Pass: data.portalImportReadyAfterB10Pass };
  if (name === 'B10_NO_WRITE_REGRESSION') return { ok: data.ok, mode: data.mode, stepCount: data.stepCount, passedCount: data.passedCount, failedCount: data.failedCount, results: data.results };
  if (name === 'B10_AUDIT_LOG') return { ok: data.ok, sheetName: data.sheetName, rowNumber: data.rowNumber, auditLogId: data.auditLogId, message: data.message };

  if (name === 'B12_PERMISSION_ASSERT') return { ok: data.ok, employeeId: data.employeeId, roleCode: data.roleCode };
  if (name === 'B12_BODY_SPECS') return { ok: data.ok, buildStep: data.buildStep, bodySpecCount: data.bodySpecCount, screenIds: data.screenIds, routeCount: data.routeCount, portalShellOnly: data.portalShellOnly };
  if (name === 'B12_BODY_CONTRACT_VALIDATE') return { ok: data.ok, specCount: data.data ? data.data.specCount : data.specCount, errorCount: data.data && data.data.errors ? data.data.errors.length : (data.errors ? data.errors.length : 0), portalShellOnly: data.data ? data.data.portalShellOnly : data.portalShellOnly };
  if (name === 'B12_USERS_BODY_RENDER') return { ok: data.ok, screenId: data.screenId, title: data.title, rowCount: data.rowCount, actionCount: data.actionCount, apiCallCount: data.apiCallCount, htmlLength: data.htmlLength, bodyAudit: data.bodyAudit };
  if (name === 'B12_PERMISSIONS_BODY_RENDER') return { ok: data.ok, screenId: data.screenId, title: data.title, rowCount: data.rowCount, actionCount: data.actionCount, apiCallCount: data.apiCallCount, permissionFieldCount: data.permissionFieldCount, htmlLength: data.htmlLength, bodyAudit: data.bodyAudit };
  if (name === 'B12_API_HANDLER_MAP') return { ok: data.ok, usersHandlerOk: data.usersHandlerOk, permissionsHandlerOk: data.permissionsHandlerOk, usersMessage: data.usersMessage, permissionsMessage: data.permissionsMessage };
  if (name === 'B12_AUDIT_LOG') return { ok: data.ok, sheetName: data.sheetName, rowNumber: data.rowNumber, auditLogId: data.auditLogId };

  if (name === 'B13_PERMISSION_ASSERT') return { ok: data.ok, employeeId: data.employeeId, roleCode: data.roleCode };
  if (name === 'B13_BODY_SPECS') return { ok: data.ok, buildStep: data.buildStep, bodySpecCount: data.bodySpecCount, screenIds: data.screenIds, routeCount: data.routeCount, portalShellOnly: data.portalShellOnly };
  if (name === 'B13_BODY_CONTRACT_VALIDATE') return { ok: data.ok, specCount: data.data ? data.data.specCount : data.specCount, errorCount: data.data && data.data.errors ? data.data.errors.length : (data.errors ? data.errors.length : 0), portalShellOnly: data.data ? data.data.portalShellOnly : data.portalShellOnly };
  if (name === 'B13_NOTICE_BODY_RENDER') return { ok: data.ok, screenId: data.screenId, title: data.title, rowCount: data.rowCount, actionCount: data.actionCount, apiCallCount: data.apiCallCount, htmlLength: data.htmlLength, bodyAudit: data.bodyAudit };
  if (name === 'B13_API_HANDLER_MAP') return { ok: data.ok, noticeHandlerOk: data.noticeHandlerOk, noticeMessage: data.noticeMessage };
  if (name === 'B13_AUDIT_LOG') return { ok: data.ok, sheetName: data.sheetName, rowNumber: data.rowNumber, auditLogId: data.auditLogId };


  if (name === 'B14_PERMISSION_ASSERT') return { ok: data.ok, employeeId: data.employeeId, roleCode: data.roleCode };
  if (name === 'B14_BODY_SPECS') return { ok: data.ok, buildStep: data.buildStep, bodySpecCount: data.bodySpecCount, screenIds: data.screenIds, routeCount: data.routeCount, portalShellOnly: data.portalShellOnly };
  if (name === 'B14_BODY_CONTRACT_VALIDATE') return { ok: data.ok, specCount: data.data ? data.data.specCount : data.specCount, errorCount: data.data && data.data.errors ? data.data.errors.length : (data.errors ? data.errors.length : 0), portalShellOnly: data.data ? data.data.portalShellOnly : data.portalShellOnly };
  if (name === 'B14_LIBRARY_BODY_RENDER') return { ok: data.ok, screenId: data.screenId, title: data.title, rowCount: data.rowCount, actionCount: data.actionCount, apiCallCount: data.apiCallCount, htmlLength: data.htmlLength, bodyAudit: data.bodyAudit };
  if (name === 'B14_API_HANDLER_MAP') return { ok: data.ok, libraryHandlerOk: data.libraryHandlerOk, libraryMessage: data.libraryMessage };
  if (name === 'B14_AUDIT_LOG') return { ok: data.ok, sheetName: data.sheetName, rowNumber: data.rowNumber, auditLogId: data.auditLogId };


  if (name === 'B15_PERMISSION_ASSERT') return { ok: data.ok, employeeId: data.employeeId, roleCode: data.roleCode };
  if (name === 'B15_BODY_SPECS') return { ok: data.ok, buildStep: data.buildStep, bodySpecCount: data.bodySpecCount, screenIds: data.screenIds, routeCount: data.routeCount, portalShellOnly: data.portalShellOnly };
  if (name === 'B15_BODY_CONTRACT_VALIDATE') return { ok: data.ok, specCount: data.data ? data.data.specCount : data.specCount, errorCount: data.data && data.data.errors ? data.data.errors.length : (data.errors ? data.errors.length : 0), portalShellOnly: data.data ? data.data.portalShellOnly : data.portalShellOnly };
  if (name === 'B15_REQUEST_BODY_RENDER') return { ok: data.ok, screenId: data.screenId, title: data.title, rowCount: data.rowCount, approvalCount: data.approvalCount, actionCount: data.actionCount, apiCallCount: data.apiCallCount, htmlLength: data.htmlLength, bodyAudit: data.bodyAudit };
  if (name === 'B15_API_HANDLER_MAP') return { ok: data.ok, requestsHandlerOk: data.requestsHandlerOk, requestsMessage: data.requestsMessage };
  if (name === 'B15_AUDIT_LOG') return { ok: data.ok, sheetName: data.sheetName, rowNumber: data.rowNumber, auditLogId: data.auditLogId };


  if (name === 'B16_PERMISSION_ASSERT') return { ok: data.ok, employeeId: data.employeeId, roleCode: data.roleCode };
  if (name === 'B16_BODY_SPECS') return { ok: data.ok, buildStep: data.buildStep, bodySpecCount: data.bodySpecCount, screenIds: data.screenIds, routeCount: data.routeCount, portalShellOnly: data.portalShellOnly };
  if (name === 'B16_BODY_CONTRACT_VALIDATE') return { ok: data.ok, specCount: data.data ? data.data.specCount : data.specCount, errorCount: data.data && data.data.errors ? data.data.errors.length : (data.errors ? data.errors.length : 0), portalShellOnly: data.data ? data.data.portalShellOnly : data.portalShellOnly };
  if (name === 'B16_ATTENDANCE_CAPS_BODY_RENDER' || name === 'B16_MY_ATTENDANCE_BODY_RENDER' || name === 'B16_ATTENDANCE_ADMIN_BODY_RENDER' || name === 'B16_ATTENDANCE_EXCEPTIONS_BODY_RENDER') return { ok: data.ok, kind: data.kind, screenId: data.screenId, title: data.title, attendanceCount: data.attendanceCount, exceptionCount: data.exceptionCount, rawCount: data.rawCount, actionCount: data.actionCount, apiCallCount: data.apiCallCount, htmlLength: data.htmlLength, bodyAudit: data.bodyAudit };
  if (name === 'B16_API_HANDLER_MAP') return { ok: data.ok, capsHandlerOk: data.capsHandlerOk, myHandlerOk: data.myHandlerOk, adminHandlerOk: data.adminHandlerOk, exceptionsHandlerOk: data.exceptionsHandlerOk, capsMessage: data.capsMessage, myMessage: data.myMessage, adminMessage: data.adminMessage, exceptionsMessage: data.exceptionsMessage };
  if (name === 'B16_AUDIT_LOG') return { ok: data.ok, sheetName: data.sheetName, rowNumber: data.rowNumber, auditLogId: data.auditLogId };

  if (name === 'B17_PERMISSION_ASSERT') return { ok: data.ok, employeeId: data.employeeId, roleCode: data.roleCode };
  if (name === 'B17_BODY_SPECS') return { ok: data.ok, buildStep: data.buildStep, bodySpecCount: data.bodySpecCount, screenIds: data.screenIds, routeCount: data.routeCount, portalShellOnly: data.portalShellOnly };
  if (name === 'B17_BODY_CONTRACT_VALIDATE') return { ok: data.ok, specCount: data.data ? data.data.specCount : data.specCount, errorCount: data.data && data.data.errors ? data.data.errors.length : (data.errors ? data.errors.length : 0), portalShellOnly: data.data ? data.data.portalShellOnly : data.portalShellOnly };
  if (name === 'B17_KPI_BODY_RENDER' || name === 'B17_ASSET_SUPPLY_BODY_RENDER' || name === 'B17_SUPPLY_REQUEST_BODY_RENDER' || name === 'B17_EXPENSE_BODY_RENDER') return { ok: data.ok, kind: data.kind, screenId: data.screenId, title: data.title, kpiCount: data.kpiCount, assetCount: data.assetCount, supplyCount: data.supplyCount, supplyRequestCount: data.supplyRequestCount, expenseCount: data.expenseCount, actionCount: data.actionCount, apiCallCount: data.apiCallCount, htmlLength: data.htmlLength, bodyAudit: data.bodyAudit };
  if (name === 'B17_API_HANDLER_MAP') return { ok: data.ok, kpiHandlerOk: data.kpiHandlerOk, assetHandlerOk: data.assetHandlerOk, supplyRequestHandlerOk: data.supplyRequestHandlerOk, expenseHandlerOk: data.expenseHandlerOk, kpiMessage: data.kpiMessage, assetMessage: data.assetMessage, supplyRequestMessage: data.supplyRequestMessage, expenseMessage: data.expenseMessage };
  if (name === 'B17_AUDIT_LOG') return { ok: data.ok, sheetName: data.sheetName, rowNumber: data.rowNumber, auditLogId: data.auditLogId };

  if (name === 'B18_PERMISSION_ASSERT') return { ok: data.ok, employeeId: data.employeeId, roleCode: data.roleCode };
  if (name === 'B18_BODY_SPECS') return { ok: data.ok, buildStep: data.buildStep, bodySpecCount: data.bodySpecCount, screenIds: data.screenIds, routeCount: data.routeCount, portalShellOnly: data.portalShellOnly };
  if (name === 'B18_BODY_CONTRACT_VALIDATE') return { ok: data.ok, specCount: data.data ? data.data.specCount : data.specCount, errorCount: data.data && data.data.errors ? data.data.errors.length : (data.errors ? data.errors.length : 0), portalShellOnly: data.data ? data.data.portalShellOnly : data.portalShellOnly };
  if (name === 'B18_ADMIN_DIAGNOSTICS_BODY_RENDER' || name === 'B18_AUDIT_LOG_BODY_RENDER' || name === 'B18_FEATURE_FLAG_BODY_RENDER' || name === 'B18_LIMIT_GUARD_BODY_RENDER') return { ok: data.ok, kind: data.kind, screenId: data.screenId, title: data.title, diagnosticMissingSheetCount: data.diagnosticMissingSheetCount, auditLogCount: data.auditLogCount, featureFlagCount: data.featureFlagCount, cellRiskLevel: data.cellRiskLevel, cellUsagePercent: data.cellUsagePercent, actionCount: data.actionCount, apiCallCount: data.apiCallCount, htmlLength: data.htmlLength, bodyAudit: data.bodyAudit };
  if (name === 'B18_API_HANDLER_MAP') return { ok: data.ok, adminHandlerOk: data.adminHandlerOk, auditHandlerOk: data.auditHandlerOk, featureFlagHandlerOk: data.featureFlagHandlerOk, limitGuardHandlerOk: data.limitGuardHandlerOk, adminMessage: data.adminMessage, auditMessage: data.auditMessage, featureFlagMessage: data.featureFlagMessage, limitGuardMessage: data.limitGuardMessage };
  if (name === 'B18_AUDIT_LOG') return { ok: data.ok, sheetName: data.sheetName, rowNumber: data.rowNumber, auditLogId: data.auditLogId };


  if (name === 'B19_PERMISSION_ASSERT') return { ok: data.ok, employeeId: data.employeeId, roleCode: data.roleCode };
  if (name === 'B19_BODY_SPECS') return { ok: data.ok, buildStep: data.buildStep, bodySpecCount: data.bodySpecCount, screenIds: data.screenIds, routeCount: data.routeCount, portalShellOnly: data.portalShellOnly };
  if (name === 'B19_BODY_CONTRACT_VALIDATE') return { ok: data.ok, specCount: data.data ? data.data.specCount : data.specCount, errorCount: data.data && data.data.errors ? data.data.errors.length : (data.errors ? data.errors.length : 0), portalShellOnly: data.data ? data.data.portalShellOnly : data.portalShellOnly };
  if (name === 'B19_STABILITY_BODY_RENDER' || name === 'B19_PERMISSION_GUARD_BODY_RENDER' || name === 'B19_INPUT_VALIDATION_BODY_RENDER' || name === 'B19_STATUS_GUARD_BODY_RENDER') return { ok: data.ok, kind: data.kind, screenId: data.screenId, title: data.title, guardRowCount: data.guardRowCount, cellRiskLevel: data.cellRiskLevel, newSheetGuard: data.newSheetGuard, inputRuleCount: data.inputRuleCount, statusGroupCount: data.statusGroupCount, actionCount: data.actionCount, apiCallCount: data.apiCallCount, htmlLength: data.htmlLength, bodyAudit: data.bodyAudit };
  if (name === 'B19_GUARD_POLICY') return { ok: data.ok, cellRiskLevel: data.cellRiskLevel, cellUsagePercent: data.cellUsagePercent, newSheetGuard: data.newSheetGuard, permissionMissingCount: data.permissionMissingCount, inputRuleCount: data.inputRuleCount, statusGroupCount: data.statusGroupCount, freeTextStatusForbidden: data.freeTextStatusForbidden };
  if (name === 'B19_API_HANDLER_MAP') return { ok: data.ok, stabilityHandlerOk: data.stabilityHandlerOk, permissionHandlerOk: data.permissionHandlerOk, inputHandlerOk: data.inputHandlerOk, statusHandlerOk: data.statusHandlerOk, stabilityMessage: data.stabilityMessage, permissionMessage: data.permissionMessage, inputMessage: data.inputMessage, statusMessage: data.statusMessage };
  if (name === 'B19_AUDIT_LOG') return { ok: data.ok, sheetName: data.sheetName, rowNumber: data.rowNumber, auditLogId: data.auditLogId };


  if (name === 'B20_PERMISSION_ASSERT') return { ok: data.ok, employeeId: data.employeeId, roleCode: data.roleCode };
  if (name === 'B20_BODY_SPECS') return { ok: data.ok, buildStep: data.buildStep, bodySpecCount: data.bodySpecCount, screenIds: data.screenIds, routeCount: data.routeCount, portalShellOnly: data.portalShellOnly };
  if (name === 'B20_BODY_CONTRACT_VALIDATE') return { ok: data.ok, specCount: data.data ? data.data.specCount : data.specCount, errorCount: data.data && data.data.errors ? data.data.errors.length : (data.errors ? data.errors.length : 0), portalShellOnly: data.data ? data.data.portalShellOnly : data.portalShellOnly };
  if (name === 'B20_RELEASE_CANDIDATE_VALIDATE') return { ok: data.ok, releaseStatus: data.data ? data.data.releaseStatus : data.releaseStatus, bodySpecCount: data.data ? data.data.bodySpecCount : data.bodySpecCount, regressionFailedCount: data.data ? data.data.regressionFailedCount : data.regressionFailedCount, cellRiskLevel: data.data ? data.data.cellRiskLevel : data.cellRiskLevel, newSheetGuard: data.data ? data.data.newSheetGuard : data.newSheetGuard, finalGate: data.data ? data.data.finalGate : data.finalGate };
  if (name === 'B20_RELEASE_BODY_RENDER') return { ok: data.ok, kind: data.kind, screenId: data.screenId, title: data.title, releaseStatus: data.releaseStatus, bodySpecCount: data.bodySpecCount, regressionFailedCount: data.regressionFailedCount, cellRiskLevel: data.cellRiskLevel, newSheetGuard: data.newSheetGuard, actionCount: data.actionCount, apiCallCount: data.apiCallCount, htmlLength: data.htmlLength, bodyAudit: data.bodyAudit };
  if (name === 'B20_NO_WRITE_REGRESSION') return { ok: data.ok, mode: data.mode, stepCount: data.stepCount, passedCount: data.passedCount, failedCount: data.failedCount, results: data.results };
  if (name === 'B20_API_HANDLER_MAP') return { ok: data.ok, releaseHandlerOk: data.releaseHandlerOk, validateHandlerOk: data.validateHandlerOk, releaseMessage: data.releaseMessage, validateMessage: data.validateMessage };
  if (name === 'B20_AUDIT_LOG') return { ok: data.ok, sheetName: data.sheetName, rowNumber: data.rowNumber, auditLogId: data.auditLogId };

  return data;
}

function gwInternalTest_B11_Smoke_NoWrite() {
  var result = gwRunB11Diagnostics({ writeAudit: false });
  Logger.log('JSON_COMPACT_RESULT: ' + JSON.stringify(gwCompactLogResult_(result)));
  return result;
}

function gwInternalTest_B11_All() {
  var result = gwRunB11Diagnostics({ writeAudit: true });
  Logger.log('JSON_COMPACT_RESULT: ' + JSON.stringify(gwCompactLogResult_(result)));
  return result;
}

function gwInternalTest_B11_ContractsOnly() {
  var result = gwValidatePortalContracts_B11({});
  Logger.log('JSON_COMPACT_RESULT: ' + JSON.stringify(gwCompactLogResult_(result)));
  return result;
}


function gwInternalTest_B12_Smoke_NoWrite() {
  var result = gwRunB12Diagnostics({ writeAudit: false, limit: 10 });
  Logger.log('JSON_COMPACT_RESULT: ' + JSON.stringify(gwCompactLogResult_(result)));
  return result;
}

function gwInternalTest_B12_ContractsOnly() {
  var result = gwValidateB12BodyContracts({});
  Logger.log('JSON_COMPACT_RESULT: ' + JSON.stringify(gwCompactLogResult_(result)));
  return result;
}

function gwInternalTest_B12_All() {
  var result = gwRunB12Diagnostics({ writeAudit: true, limit: 10 });
  Logger.log('JSON_COMPACT_RESULT: ' + JSON.stringify(gwCompactLogResult_(result)));
  return result;
}


function gwInternalTest_B13_Smoke_NoWrite() {
  var result = gwRunB13Diagnostics({ writeAudit: false, limit: 10 });
  Logger.log('JSON_COMPACT_RESULT: ' + JSON.stringify(gwCompactLogResult_(result)));
  return result;
}

function gwInternalTest_B13_ContractsOnly() {
  var result = gwValidateB13BodyContracts({});
  Logger.log('JSON_COMPACT_RESULT: ' + JSON.stringify(gwCompactLogResult_(result)));
  return result;
}

function gwInternalTest_B13_All() {
  var result = gwRunB13Diagnostics({ writeAudit: true, limit: 10 });
  Logger.log('JSON_COMPACT_RESULT: ' + JSON.stringify(gwCompactLogResult_(result)));
  return result;
}


function gwInternalTest_B14_Smoke_NoWrite() {
  var result = gwRunB14Diagnostics({ writeAudit: false, limit: 10 });
  Logger.log('JSON_COMPACT_RESULT: ' + JSON.stringify(gwCompactLogResult_(result)));
  return result;
}

function gwInternalTest_B14_ContractsOnly() {
  var result = gwValidateB14BodyContracts({});
  Logger.log('JSON_COMPACT_RESULT: ' + JSON.stringify(gwCompactLogResult_(result)));
  return result;
}

function gwInternalTest_B14_All() {
  var result = gwRunB14Diagnostics({ writeAudit: true, limit: 10 });
  Logger.log('JSON_COMPACT_RESULT: ' + JSON.stringify(gwCompactLogResult_(result)));
  return result;
}

function gwInternalTest_B14_RunAll() {
  var steps = [];
  var smoke = gwInternalTest_B14_Smoke_NoWrite();
  steps.push({ name: 'Smoke_NoWrite', ok: smoke.ok === true, fatalCount: smoke.fatalCount || 0, message: smoke.message });
  if (!smoke.ok || (smoke.fatalCount || 0) > 0) {
    var stoppedSmoke = gwBuildB14RunAllResult_(steps, 'B14 통합 테스트 중단: Smoke_NoWrite 실패');
    Logger.log('JSON_COMPACT_RESULT: ' + JSON.stringify(stoppedSmoke));
    return stoppedSmoke;
  }
  var contracts = gwInternalTest_B14_ContractsOnly();
  steps.push({ name: 'ContractsOnly', ok: contracts.ok === true, fatalCount: contracts.fatalCount || 0, message: contracts.message });
  if (!contracts.ok || (contracts.fatalCount || 0) > 0) {
    var stoppedContracts = gwBuildB14RunAllResult_(steps, 'B14 통합 테스트 중단: ContractsOnly 실패');
    Logger.log('JSON_COMPACT_RESULT: ' + JSON.stringify(stoppedContracts));
    return stoppedContracts;
  }
  var all = gwInternalTest_B14_All();
  steps.push({ name: 'All', ok: all.ok === true, fatalCount: all.fatalCount || 0, message: all.message });
  var result = gwBuildB14RunAllResult_(steps, 'B14 통합 테스트 완료');
  Logger.log('JSON_COMPACT_RESULT: ' + JSON.stringify(result));
  return result;
}

function gwBuildB14RunAllResult_(steps, message) {
  var failed = steps.filter(function (step) { return !step.ok || (step.fatalCount || 0) > 0; });
  return {
    ok: failed.length === 0,
    build: GW_BUILD_INFO.build,
    generatedAt: gwNow_(),
    code: failed.length === 0 ? '' : 'B14_RUNALL_FAILED',
    message: failed.length === 0 ? 'B14 사내 자료실 PORTAL 본문 UI 통합 테스트 통과' : message,
    buildInfo: gwGetBuildInfo(),
    fatalCount: failed.length,
    steps: steps
  };
}


function gwInternalTest_B15_Smoke_NoWrite() {
  var result = gwRunB15Diagnostics({ writeAudit: false, limit: 10 });
  Logger.log('JSON_COMPACT_RESULT: ' + JSON.stringify(gwCompactLogResult_(result)));
  return result;
}

function gwInternalTest_B15_ContractsOnly() {
  var result = gwValidateB15BodyContracts({});
  Logger.log('JSON_COMPACT_RESULT: ' + JSON.stringify(gwCompactLogResult_(result)));
  return result;
}

function gwInternalTest_B15_All() {
  var result = gwRunB15Diagnostics({ writeAudit: true, limit: 10 });
  Logger.log('JSON_COMPACT_RESULT: ' + JSON.stringify(gwCompactLogResult_(result)));
  return result;
}

function gwInternalTest_B15_RunAll() {
  var steps = [];
  var smoke = gwInternalTest_B15_Smoke_NoWrite();
  steps.push({ name: 'Smoke_NoWrite', ok: smoke.ok === true, fatalCount: smoke.fatalCount || 0, message: smoke.message });
  if (!smoke.ok || (smoke.fatalCount || 0) > 0) {
    var stoppedSmoke = gwBuildB15RunAllResult_(steps, 'B15 통합 테스트 중단: Smoke_NoWrite 실패');
    Logger.log('JSON_COMPACT_RESULT: ' + JSON.stringify(stoppedSmoke));
    return stoppedSmoke;
  }
  var contracts = gwInternalTest_B15_ContractsOnly();
  steps.push({ name: 'ContractsOnly', ok: contracts.ok === true, fatalCount: contracts.fatalCount || 0, message: contracts.message });
  if (!contracts.ok || (contracts.fatalCount || 0) > 0) {
    var stoppedContracts = gwBuildB15RunAllResult_(steps, 'B15 통합 테스트 중단: ContractsOnly 실패');
    Logger.log('JSON_COMPACT_RESULT: ' + JSON.stringify(stoppedContracts));
    return stoppedContracts;
  }
  var all = gwInternalTest_B15_All();
  steps.push({ name: 'All', ok: all.ok === true, fatalCount: all.fatalCount || 0, message: all.message });
  var result = gwBuildB15RunAllResult_(steps, 'B15 통합 테스트 완료');
  Logger.log('JSON_COMPACT_RESULT: ' + JSON.stringify(result));
  return result;
}

function gwBuildB15RunAllResult_(steps, message) {
  var failed = steps.filter(function (step) { return !step.ok || (step.fatalCount || 0) > 0; });
  return {
    ok: failed.length === 0,
    build: GW_BUILD_INFO.build,
    generatedAt: gwNow_(),
    code: failed.length === 0 ? '' : 'B15_RUNALL_FAILED',
    message: failed.length === 0 ? 'B15 업무요청/전자결재 PORTAL 본문 UI 통합 테스트 통과' : message,
    buildInfo: gwGetBuildInfo(),
    fatalCount: failed.length,
    steps: steps
  };
}


function gwInternalTest_B16_Smoke_NoWrite() {
  var result = gwRunB16Diagnostics({ writeAudit: false, limit: 10 });
  Logger.log('JSON_COMPACT_RESULT: ' + JSON.stringify(gwCompactLogResult_(result)));
  return result;
}

function gwInternalTest_B16_ContractsOnly() {
  var result = gwValidateB16BodyContracts({});
  Logger.log('JSON_COMPACT_RESULT: ' + JSON.stringify(gwCompactLogResult_(result)));
  return result;
}

function gwInternalTest_B16_All() {
  var result = gwRunB16Diagnostics({ writeAudit: true, limit: 10 });
  Logger.log('JSON_COMPACT_RESULT: ' + JSON.stringify(gwCompactLogResult_(result)));
  return result;
}

function gwInternalTest_B16_RunAll() {
  var steps = [];
  var smoke = gwInternalTest_B16_Smoke_NoWrite();
  steps.push({ name: 'Smoke_NoWrite', ok: smoke.ok === true, fatalCount: smoke.fatalCount || 0, message: smoke.message });
  if (!smoke.ok || (smoke.fatalCount || 0) > 0) {
    var stoppedSmoke = gwBuildB16RunAllResult_(steps, 'B16 통합 테스트 중단: Smoke_NoWrite 실패');
    Logger.log('JSON_COMPACT_RESULT: ' + JSON.stringify(stoppedSmoke));
    return stoppedSmoke;
  }
  var contracts = gwInternalTest_B16_ContractsOnly();
  steps.push({ name: 'ContractsOnly', ok: contracts.ok === true, fatalCount: contracts.fatalCount || 0, message: contracts.message });
  if (!contracts.ok || (contracts.fatalCount || 0) > 0) {
    var stoppedContracts = gwBuildB16RunAllResult_(steps, 'B16 통합 테스트 중단: ContractsOnly 실패');
    Logger.log('JSON_COMPACT_RESULT: ' + JSON.stringify(stoppedContracts));
    return stoppedContracts;
  }
  var all = gwInternalTest_B16_All();
  steps.push({ name: 'All', ok: all.ok === true, fatalCount: all.fatalCount || 0, message: all.message });
  var result = gwBuildB16RunAllResult_(steps, 'B16 통합 테스트 완료');
  Logger.log('JSON_COMPACT_RESULT: ' + JSON.stringify(result));
  return result;
}

function gwBuildB16RunAllResult_(steps, message) {
  var failed = steps.filter(function (step) { return !step.ok || (step.fatalCount || 0) > 0; });
  return {
    ok: failed.length === 0,
    build: GW_BUILD_INFO.build,
    generatedAt: gwNow_(),
    code: failed.length === 0 ? '' : 'B16_RUNALL_FAILED',
    message: failed.length === 0 ? 'B16 CAPS 근태 PORTAL 본문 UI 통합 테스트 통과' : message,
    buildInfo: gwGetBuildInfo(),
    fatalCount: failed.length,
    steps: steps
  };
}

function gwInternalTest_B17_Smoke_NoWrite() {
  var result = gwRunB17Diagnostics({ writeAudit: false, limit: 10 });
  Logger.log('JSON_COMPACT_RESULT: ' + JSON.stringify(gwCompactLogResult_(result)));
  return result;
}

function gwInternalTest_B17_ContractsOnly() {
  var result = gwValidateB17BodyContracts({});
  Logger.log('JSON_COMPACT_RESULT: ' + JSON.stringify(gwCompactLogResult_(result)));
  return result;
}

function gwInternalTest_B17_All() {
  var result = gwRunB17Diagnostics({ writeAudit: true, limit: 10 });
  Logger.log('JSON_COMPACT_RESULT: ' + JSON.stringify(gwCompactLogResult_(result)));
  return result;
}

function gwInternalTest_B17_RunAll() {
  var steps = [];
  var smoke = gwInternalTest_B17_Smoke_NoWrite();
  steps.push({ name: 'Smoke_NoWrite', ok: smoke.ok === true, fatalCount: smoke.fatalCount || 0, message: smoke.message });
  if (!smoke.ok || (smoke.fatalCount || 0) > 0) {
    var stoppedSmoke = gwBuildB17RunAllResult_(steps, 'B17 통합 테스트 중단: Smoke_NoWrite 실패');
    Logger.log('JSON_COMPACT_RESULT: ' + JSON.stringify(stoppedSmoke));
    return stoppedSmoke;
  }
  var contracts = gwInternalTest_B17_ContractsOnly();
  steps.push({ name: 'ContractsOnly', ok: contracts.ok === true, fatalCount: contracts.fatalCount || 0, message: contracts.message });
  if (!contracts.ok || (contracts.fatalCount || 0) > 0) {
    var stoppedContracts = gwBuildB17RunAllResult_(steps, 'B17 통합 테스트 중단: ContractsOnly 실패');
    Logger.log('JSON_COMPACT_RESULT: ' + JSON.stringify(stoppedContracts));
    return stoppedContracts;
  }
  var all = gwInternalTest_B17_All();
  steps.push({ name: 'All', ok: all.ok === true, fatalCount: all.fatalCount || 0, message: all.message });
  var result = gwBuildB17RunAllResult_(steps, 'B17 통합 테스트 완료');
  Logger.log('JSON_COMPACT_RESULT: ' + JSON.stringify(result));
  return result;
}

function gwBuildB17RunAllResult_(steps, message) {
  var failed = steps.filter(function (step) { return !step.ok || (step.fatalCount || 0) > 0; });
  return {
    ok: failed.length === 0,
    build: GW_BUILD_INFO.build,
    generatedAt: gwNow_(),
    code: failed.length === 0 ? '' : 'B17_RUNALL_FAILED',
    message: failed.length === 0 ? 'B17 KPI/자산/비품/비용 PORTAL 본문 UI 통합 테스트 통과' : message,
    buildInfo: gwGetBuildInfo(),
    fatalCount: failed.length,
    steps: steps
  };
}

function gwInternalTest_B18_Smoke_NoWrite() {
  var result = gwRunB18Diagnostics({ writeAudit: false, limit: 10 });
  Logger.log('JSON_COMPACT_RESULT: ' + JSON.stringify(gwCompactLogResult_(result)));
  return result;
}

function gwInternalTest_B18_ContractsOnly() {
  var result = gwValidateB18BodyContracts({});
  Logger.log('JSON_COMPACT_RESULT: ' + JSON.stringify(gwCompactLogResult_(result)));
  return result;
}

function gwInternalTest_B18_All() {
  var result = gwRunB18Diagnostics({ writeAudit: true, limit: 10 });
  Logger.log('JSON_COMPACT_RESULT: ' + JSON.stringify(gwCompactLogResult_(result)));
  return result;
}

function gwInternalTest_B18_RunAll() {
  var steps = [];
  var smoke = gwInternalTest_B18_Smoke_NoWrite();
  steps.push({ name: 'Smoke_NoWrite', ok: smoke.ok === true, fatalCount: smoke.fatalCount || 0, message: smoke.message });
  if (!smoke.ok || (smoke.fatalCount || 0) > 0) {
    var stoppedSmoke = gwBuildB18RunAllResult_(steps, 'B18 통합 테스트 중단: Smoke_NoWrite 실패');
    Logger.log('JSON_COMPACT_RESULT: ' + JSON.stringify(stoppedSmoke));
    return stoppedSmoke;
  }
  var contracts = gwInternalTest_B18_ContractsOnly();
  steps.push({ name: 'ContractsOnly', ok: contracts.ok === true, fatalCount: contracts.fatalCount || 0, message: contracts.message });
  if (!contracts.ok || (contracts.fatalCount || 0) > 0) {
    var stoppedContracts = gwBuildB18RunAllResult_(steps, 'B18 통합 테스트 중단: ContractsOnly 실패');
    Logger.log('JSON_COMPACT_RESULT: ' + JSON.stringify(stoppedContracts));
    return stoppedContracts;
  }
  var all = gwInternalTest_B18_All();
  steps.push({ name: 'All', ok: all.ok === true, fatalCount: all.fatalCount || 0, message: all.message });
  var result = gwBuildB18RunAllResult_(steps, 'B18 통합 테스트 완료');
  Logger.log('JSON_COMPACT_RESULT: ' + JSON.stringify(result));
  return result;
}

function gwBuildB18RunAllResult_(steps, message) {
  var failed = steps.filter(function (step) { return !step.ok || (step.fatalCount || 0) > 0; });
  return {
    ok: failed.length === 0,
    build: GW_BUILD_INFO.build,
    generatedAt: gwNow_(),
    code: failed.length === 0 ? '' : 'B18_RUNALL_FAILED',
    message: failed.length === 0 ? 'B18 관리자 진단/로그/셀 한도 보호 PORTAL 본문 UI 통합 테스트 통과' : message,
    buildInfo: gwGetBuildInfo(),
    fatalCount: failed.length,
    steps: steps
  };
}


function gwInternalTest_B19_Smoke_NoWrite() {
  var result = gwRunB19Diagnostics({ writeAudit: false, limit: 10 });
  Logger.log('JSON_COMPACT_RESULT: ' + JSON.stringify(gwCompactLogResult_(result)));
  return result;
}

function gwInternalTest_B19_ContractsOnly() {
  var result = gwValidateB19BodyContracts({});
  Logger.log('JSON_COMPACT_RESULT: ' + JSON.stringify(gwCompactLogResult_(result)));
  return result;
}

function gwInternalTest_B19_All() {
  var result = gwRunB19Diagnostics({ writeAudit: true, limit: 10 });
  Logger.log('JSON_COMPACT_RESULT: ' + JSON.stringify(gwCompactLogResult_(result)));
  return result;
}

function gwInternalTest_B19_RunAll() {
  var steps = [];
  if (typeof gwClearB19GuardSnapshotCache_ === 'function') gwClearB19GuardSnapshotCache_();

  var smoke = gwRunB19Diagnostics({ writeAudit: false, limit: 3, fastMode: true, forceRefresh: true });
  Logger.log('JSON_COMPACT_RESULT: ' + JSON.stringify(gwCompactLogResult_(smoke)));
  steps.push({ name: 'Smoke_NoWrite', ok: smoke.ok === true, fatalCount: smoke.fatalCount || 0, message: smoke.message });
  if (!smoke.ok || (smoke.fatalCount || 0) > 0) {
    var stoppedSmoke = gwBuildB19RunAllResult_(steps, 'B19 통합 테스트 중단: Smoke_NoWrite 실패');
    Logger.log('JSON_COMPACT_RESULT: ' + JSON.stringify(stoppedSmoke));
    return stoppedSmoke;
  }

  var contracts = gwValidateB19BodyContracts({});
  Logger.log('JSON_COMPACT_RESULT: ' + JSON.stringify(gwCompactLogResult_(contracts)));
  steps.push({ name: 'ContractsOnly', ok: contracts.ok === true, fatalCount: contracts.fatalCount || 0, message: contracts.message });
  if (!contracts.ok || (contracts.fatalCount || 0) > 0) {
    var stoppedContracts = gwBuildB19RunAllResult_(steps, 'B19 통합 테스트 중단: ContractsOnly 실패');
    Logger.log('JSON_COMPACT_RESULT: ' + JSON.stringify(stoppedContracts));
    return stoppedContracts;
  }

  var all = gwRunB19Diagnostics({ writeAudit: true, limit: 3, fastMode: true });
  Logger.log('JSON_COMPACT_RESULT: ' + JSON.stringify(gwCompactLogResult_(all)));
  steps.push({ name: 'All', ok: all.ok === true, fatalCount: all.fatalCount || 0, message: all.message });
  var result = gwBuildB19RunAllResult_(steps, 'B19 통합 테스트 완료');
  result.fastMode = true;
  result.cacheMode = 'B19_SINGLE_EXECUTION_CACHE';
  Logger.log('JSON_COMPACT_RESULT: ' + JSON.stringify(result));
  return result;
}

function gwBuildB19RunAllResult_(steps, message) {
  var failed = steps.filter(function (step) { return !step.ok || (step.fatalCount || 0) > 0; });
  return {
    ok: failed.length === 0,
    build: GW_BUILD_INFO.build,
    generatedAt: gwNow_(),
    code: failed.length === 0 ? '' : 'B19_RUNALL_FAILED',
    message: failed.length === 0 ? 'B19 PORTAL 본문 안정화 통합 테스트 통과' : message,
    buildInfo: gwGetBuildInfo(),
    fatalCount: failed.length,
    steps: steps
  };
}


function gwInternalTest_B20_Smoke_NoWrite() {
  var result = gwRunB20Diagnostics({ writeAudit: false, limit: 3 });
  Logger.log('JSON_COMPACT_RESULT: ' + JSON.stringify(gwCompactLogResult_(result)));
  return result;
}

function gwInternalTest_B20_ContractsOnly() {
  var result = gwValidateB20BodyContracts({});
  Logger.log('JSON_COMPACT_RESULT: ' + JSON.stringify(gwCompactLogResult_(result)));
  return result;
}

function gwInternalTest_B20_All() {
  var result = gwRunB20Diagnostics({ writeAudit: true, limit: 3 });
  Logger.log('JSON_COMPACT_RESULT: ' + JSON.stringify(gwCompactLogResult_(result)));
  return result;
}

function gwInternalTest_B20_RunAll() {
  var steps = [];
  if (typeof gwClearB19GuardSnapshotCache_ === 'function') gwClearB19GuardSnapshotCache_();
  var smoke = gwRunB20Diagnostics({ writeAudit: false, limit: 3 });
  Logger.log('JSON_COMPACT_RESULT: ' + JSON.stringify(gwCompactLogResult_(smoke)));
  steps.push({ name: 'Smoke_NoWrite', ok: smoke.ok === true, fatalCount: smoke.fatalCount || 0, message: smoke.message });
  if (!smoke.ok || (smoke.fatalCount || 0) > 0) {
    var stoppedSmoke = gwBuildB20RunAllResult_(steps, 'B20 통합 테스트 중단: Smoke_NoWrite 실패');
    Logger.log('JSON_COMPACT_RESULT: ' + JSON.stringify(stoppedSmoke));
    return stoppedSmoke;
  }
  var contracts = gwValidateB20BodyContracts({});
  Logger.log('JSON_COMPACT_RESULT: ' + JSON.stringify(gwCompactLogResult_(contracts)));
  steps.push({ name: 'ContractsOnly', ok: contracts.ok === true, fatalCount: contracts.fatalCount || 0, message: contracts.message });
  if (!contracts.ok || (contracts.fatalCount || 0) > 0) {
    var stoppedContracts = gwBuildB20RunAllResult_(steps, 'B20 통합 테스트 중단: ContractsOnly 실패');
    Logger.log('JSON_COMPACT_RESULT: ' + JSON.stringify(stoppedContracts));
    return stoppedContracts;
  }
  var all = gwRunB20Diagnostics({ writeAudit: true, limit: 3 });
  Logger.log('JSON_COMPACT_RESULT: ' + JSON.stringify(gwCompactLogResult_(all)));
  steps.push({ name: 'All', ok: all.ok === true, fatalCount: all.fatalCount || 0, message: all.message });
  var result = gwBuildB20RunAllResult_(steps, 'B20 통합 테스트 완료');
  result.fastMode = true;
  result.cacheMode = 'B20_LIGHT_CONTRACT_REGRESSION';
  Logger.log('JSON_COMPACT_RESULT: ' + JSON.stringify(result));
  return result;
}

function gwBuildB20RunAllResult_(steps, message) {
  var failed = steps.filter(function (step) { return !step.ok || (step.fatalCount || 0) > 0; });
  return {
    ok: failed.length === 0,
    build: GW_BUILD_INFO.build,
    generatedAt: gwNow_(),
    code: failed.length === 0 ? '' : 'B20_RUNALL_FAILED',
    message: failed.length === 0 ? 'B20 PORTAL 본문 릴리즈 후보 통합 테스트 통과' : message,
    buildInfo: gwGetBuildInfo(),
    fatalCount: failed.length,
    steps: steps
  };
}


function gwInternalTest_B21_Smoke_NoWrite() {
  var result = gwRunB21Diagnostics({ writeAudit: false, limit: 3 });
  Logger.log('JSON_COMPACT_RESULT: ' + JSON.stringify(gwCompactLogResult_(result)));
  return result;
}

function gwInternalTest_B21_ContractsOnly() {
  var result = gwValidateB21BodyContracts({});
  Logger.log('JSON_COMPACT_RESULT: ' + JSON.stringify(gwCompactLogResult_(result)));
  return result;
}

function gwInternalTest_B21_All() {
  var result = gwRunB21Diagnostics({ writeAudit: true, limit: 3 });
  Logger.log('JSON_COMPACT_RESULT: ' + JSON.stringify(gwCompactLogResult_(result)));
  return result;
}

function gwInternalTest_B21_RunAll() {
  var steps = [];
  var smoke = gwRunB21Diagnostics({ writeAudit: false, limit: 3 });
  Logger.log('JSON_COMPACT_RESULT: ' + JSON.stringify(gwCompactLogResult_(smoke)));
  steps.push({ name: 'Smoke_NoWrite', ok: smoke.ok === true, fatalCount: smoke.fatalCount || 0, message: smoke.message });
  if (!smoke.ok || (smoke.fatalCount || 0) > 0) {
    var stoppedSmoke = gwBuildB21RunAllResult_(steps, 'B21 통합 테스트 중단: Smoke_NoWrite 실패');
    Logger.log('JSON_COMPACT_RESULT: ' + JSON.stringify(stoppedSmoke));
    return stoppedSmoke;
  }
  var contracts = gwValidateB21BodyContracts({});
  Logger.log('JSON_COMPACT_RESULT: ' + JSON.stringify(gwCompactLogResult_(contracts)));
  steps.push({ name: 'ContractsOnly', ok: contracts.ok === true, fatalCount: contracts.fatalCount || 0, message: contracts.message });
  if (!contracts.ok || (contracts.fatalCount || 0) > 0) {
    var stoppedContracts = gwBuildB21RunAllResult_(steps, 'B21 통합 테스트 중단: ContractsOnly 실패');
    Logger.log('JSON_COMPACT_RESULT: ' + JSON.stringify(stoppedContracts));
    return stoppedContracts;
  }
  var all = gwRunB21Diagnostics({ writeAudit: true, limit: 3 });
  Logger.log('JSON_COMPACT_RESULT: ' + JSON.stringify(gwCompactLogResult_(all)));
  steps.push({ name: 'All', ok: all.ok === true, fatalCount: all.fatalCount || 0, message: all.message });
  var result = gwBuildB21RunAllResult_(steps, 'B21 통합 테스트 완료');
  result.fastMode = true;
  result.actionRegistryMode = 'B21_COMMON_ACTION_STANDARDIZATION';
  Logger.log('JSON_COMPACT_RESULT: ' + JSON.stringify(result));
  return result;
}

function gwBuildB21RunAllResult_(steps, message) {
  var failed = steps.filter(function (step) { return !step.ok || (step.fatalCount || 0) > 0; });
  return {
    ok: failed.length === 0,
    build: GW_BUILD_INFO.build,
    generatedAt: gwNow_(),
    code: failed.length === 0 ? '' : 'B21_RUNALL_FAILED',
    message: failed.length === 0 ? 'B21 공통 액션 핸들러 고도화 통합 테스트 통과' : message,
    buildInfo: gwGetBuildInfo(),
    fatalCount: failed.length,
    steps: steps
  };
}
