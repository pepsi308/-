const GW_KPI_SHEET_CANDIDATES = Object.freeze(['Portal_KPI', 'PORTAL_KPI', 'GW_KPI', 'KPI', 'EmployeeKPI']);
const GW_KPI_PREFERRED_SHEET_NAME = 'Portal_KPI';

const GW_KPI_HEADERS = Object.freeze([
  'kpiId', 'employeeId', 'period', 'kpiCategory', 'kpiTitle',
  'targetValue', 'actualValue', 'score', 'evaluatorEmployeeId', 'evaluationComment',
  'kpiStatus', 'status', 'statusReason',
  'createdAt', 'createdBy', 'updatedAt', 'updatedBy'
]);

const GW_KPI_STATUSES = Object.freeze(['DRAFT', 'ACTIVE', 'EVALUATED', 'CLOSED', 'ARCHIVED']);
const GW_KPI_CATEGORIES = Object.freeze(['GENERAL', 'SALES', 'CONTRACT', 'INSTALL', 'AS', 'SETTLEMENT', 'ATTENDANCE', 'CUSTOMER', 'SYSTEM']);

function gwGetKpiSheet_(createIfMissing) {
  var ss = gwGetMasterSpreadsheet_();
  for (var i = 0; i < GW_KPI_SHEET_CANDIDATES.length; i++) {
    var sheet = ss.getSheetByName(GW_KPI_SHEET_CANDIDATES[i]);
    if (sheet) return sheet;
  }
  if (createIfMissing) {
    var created = ss.insertSheet(GW_KPI_PREFERRED_SHEET_NAME);
    created.getRange(1, 1, 1, GW_KPI_HEADERS.length).setValues([GW_KPI_HEADERS]);
    return created;
  }
  throw new Error('KPI 시트를 찾을 수 없습니다. 허용 시트명: ' + GW_KPI_SHEET_CANDIDATES.join(', '));
}

function gwEnsureKpiHeaders_() {
  var sheet = gwGetKpiSheet_(true);
  var before = gwGetHeaders_(sheet).filter(function (h) { return h; });
  var result = gwEnsureHeaders_(sheet, GW_KPI_HEADERS.slice());
  var after = gwGetHeaders_(sheet).filter(function (h) { return h; });
  return {
    ok: result.ok,
    sheetName: sheet.getName(),
    beforeCount: before.length,
    afterCount: after.length,
    addedHeaders: after.filter(function (h) { return before.indexOf(h) < 0; }),
    missing: result.missing || []
  };
}

function gwInspectKpiHeadersNoWrite_B07_() {
  var ss = gwGetMasterSpreadsheet_();
  var sheet = null;
  for (var i = 0; i < GW_KPI_SHEET_CANDIDATES.length; i++) {
    sheet = ss.getSheetByName(GW_KPI_SHEET_CANDIDATES[i]);
    if (sheet) break;
  }
  var result = {
    ok: true,
    mode: 'NO_WRITE_INSPECT',
    prepareRequired: false,
    kpiSheetExists: !!sheet,
    kpiSheetName: sheet ? sheet.getName() : '',
    preferredKpiSheetName: GW_KPI_PREFERRED_SHEET_NAME,
    requiredKpiHeaderCount: GW_KPI_HEADERS.length,
    missingKpiHeaders: []
  };
  if (!sheet) {
    result.prepareRequired = true;
    result.message = 'KPI 시트가 아직 없습니다. gwInternalTest_B07_HeaderEnsure()에서 생성됩니다.';
    return result;
  }
  var check = gwCheckRequiredHeaders_(sheet, GW_KPI_HEADERS.slice());
  result.kpiHeaderCount = check.headers.length;
  result.missingKpiHeaders = check.missing || [];
  if (!check.ok) result.prepareRequired = true;
  return result;
}

function gwGetB07KpiMeta_() {
  return {
    buildStep: '07/10',
    kpiSheetCandidates: GW_KPI_SHEET_CANDIDATES.slice(),
    kpiStatuses: GW_KPI_STATUSES.slice(),
    kpiCategories: GW_KPI_CATEGORIES.slice(),
    requiredKpiHeaders: GW_KPI_HEADERS.slice(),
    mode: 'MANUAL_KPI_FIRST_AUTO_LINK_LATER'
  };
}

function gwListKpisForUi(payload) {
  payload = payload || {};
  var context = gwAssertPermission_('canAccessPortal');
  var sheet = gwGetKpiSheet_(true);
  gwEnsureHeaders_(sheet, GW_KPI_HEADERS.slice());
  var rows = gwReadRowsAsObjects_(sheet).map(function (row) { return gwNormalizeKpiRow_(row); });
  var includeAll = payload.includeAll === true && (gwCanSafe_(context, 'canViewLogs') || gwCanSafe_(context, 'canAccessDevConsole'));
  var employeeId = gwToSafeText_(payload.employeeId);
  var period = gwToSafeText_(payload.period);
  var status = gwToSafeText_(payload.kpiStatus || payload.status).toUpperCase();
  var category = gwToSafeText_(payload.kpiCategory).toUpperCase();
  var query = gwToSafeText_(payload.query).toLowerCase();
  var limit = Math.min(Number(payload.limit || 100), 500);
  rows = rows.filter(function (kpi) {
    if (!includeAll && kpi.employeeId !== context.employeeId && kpi.evaluatorEmployeeId !== context.employeeId) return false;
    if (employeeId && employeeId !== 'ALL' && kpi.employeeId !== employeeId) return false;
    if (period && kpi.period !== period) return false;
    if (status && status !== 'ALL' && kpi.kpiStatus !== status && kpi.status !== status) return false;
    if (category && category !== 'ALL' && kpi.kpiCategory !== category) return false;
    if (query) {
      var hay = [kpi.kpiId, kpi.employeeId, kpi.period, kpi.kpiCategory, kpi.kpiTitle, kpi.evaluationComment, kpi.kpiStatus].join(' ').toLowerCase();
      if (hay.indexOf(query) < 0) return false;
    }
    return true;
  });
  rows.sort(function (a, b) { return gwKpiDateToMillis_(b.updatedAt || b.createdAt) - gwKpiDateToMillis_(a.updatedAt || a.createdAt); });
  rows = rows.slice(0, limit).map(function (kpi) { return gwKpiToUiRow_(kpi); });
  return gwOk_({ rows: rows, totalReturned: rows.length, sheetName: sheet.getName() }, 'KPI 목록 조회 완료');
}

function gwGetKpiDetailForUi(payload) {
  payload = payload || {};
  var context = gwAssertPermission_('canAccessPortal');
  var kpiId = gwToSafeText_(payload.kpiId);
  if (!kpiId) return gwFail_('MISSING_KPI_ID', 'kpiId가 필요합니다.');
  var found = gwFindKpiById_(kpiId);
  if (!found) return gwFail_('KPI_NOT_FOUND', 'KPI를 찾을 수 없습니다.', { kpiId: kpiId });
  if (found.employeeId !== context.employeeId && found.evaluatorEmployeeId !== context.employeeId && !gwCanSafe_(context, 'canViewLogs') && !gwCanSafe_(context, 'canAccessDevConsole')) {
    return gwFail_('KPI_NO_PERMISSION', '해당 KPI를 조회할 권한이 없습니다.', { kpiId: kpiId });
  }
  return gwOk_({ kpi: gwKpiToUiRow_(found) }, 'KPI 상세 조회 완료');
}

function gwSaveKpiForUi(payload) {
  payload = payload || {};
  var context = gwAssertPermission_('canApprove');
  var result = gwSaveKpi_(payload, context, { mode: 'UI' });
  return gwOk_(result, result.action === 'CREATE' ? 'KPI 등록 완료' : 'KPI 수정 완료');
}

function gwEvaluateKpiForUi(payload) {
  payload = payload || {};
  var context = gwAssertPermission_('canApprove');
  var result = gwEvaluateKpi_(payload, context, { mode: 'UI' });
  return gwOk_(result, 'KPI 평가 완료');
}

function gwSaveKpi_(payload, context, options) {
  payload = gwSanitizeKpiPayload_(payload || {});
  context = context || gwGetUserContextSafe_();
  options = options || {};
  var sheet = gwGetKpiSheet_(true);
  gwEnsureHeaders_(sheet, GW_KPI_HEADERS.slice());
  var headers = gwGetHeaders_(sheet).filter(function (h) { return h; });
  var rows = gwReadRowsAsObjects_(sheet);
  var existing = gwFindExistingKpiForSave_(rows, payload);
  var validation = gwValidateKpiPayload_(payload, existing);
  if (!validation.ok) throw new Error(validation.message);
  var now = gwNow_();
  var kpiId = gwToSafeText_(payload.kpiId) || (existing ? existing.kpiId : gwUuid_('KPI'));
  var rowObj = existing ? Object.assign({}, existing._sourceRow) : {};
  var action = existing ? 'UPDATE' : 'CREATE';
  var nextStatus = gwNormalizeKpiStatus_(payload.kpiStatus || payload.status || (existing ? existing.kpiStatus : 'ACTIVE'));

  if (existing && gwKpiIsLocked_(existing) && options.mode !== 'B07_TEST') {
    throw new Error('종료/잠금 KPI는 일반 수정할 수 없습니다: ' + existing.kpiStatus);
  }

  rowObj.kpiId = kpiId;
  rowObj.employeeId = gwToSafeText_(payload.employeeId) || (existing ? existing.employeeId : context.employeeId);
  rowObj.period = gwToSafeText_(payload.period);
  rowObj.kpiCategory = gwNormalizeKpiCategory_(payload.kpiCategory || 'GENERAL');
  rowObj.kpiTitle = gwToSafeText_(payload.kpiTitle);
  rowObj.targetValue = gwToSafeText_(payload.targetValue);
  rowObj.actualValue = gwToSafeText_(payload.actualValue);
  rowObj.score = gwToSafeText_(payload.score);
  rowObj.evaluatorEmployeeId = gwToSafeText_(payload.evaluatorEmployeeId) || context.employeeId;
  rowObj.evaluationComment = gwToSafeText_(payload.evaluationComment);
  rowObj.kpiStatus = nextStatus;
  rowObj.status = nextStatus;
  rowObj.statusReason = gwToSafeText_(payload.statusReason);
  if (!existing) {
    rowObj.createdAt = now;
    rowObj.createdBy = context.employeeId || 'SYSTEM';
  }
  rowObj.updatedAt = now;
  rowObj.updatedBy = context.employeeId || 'SYSTEM';

  var rowNumber;
  if (existing) {
    rowNumber = existing._rowNumber;
    var row = headers.map(function (h) { return Object.prototype.hasOwnProperty.call(rowObj, h) ? rowObj[h] : ''; });
    sheet.getRange(rowNumber, 1, 1, headers.length).setValues([row]);
  } else {
    rowNumber = gwAppendObjectRow_(sheet, rowObj, GW_KPI_HEADERS.slice());
  }

  gwAuditSafe_({
    moduleCode: 'GROUPWARE_KPI',
    actionType: action + '_KPI',
    targetId: kpiId,
    employeeId: context.employeeId,
    resultStatus: 'SUCCESS',
    detailMessage: 'B07 KPI ' + action + ' 완료: ' + kpiId
  });

  return { ok: true, action: action, sheetName: sheet.getName(), rowNumber: rowNumber, kpi: gwKpiToUiRow_(gwNormalizeKpiRow_(rowObj)) };
}

function gwEvaluateKpi_(payload, context, options) {
  payload = payload || {};
  context = context || gwGetUserContextSafe_();
  options = options || {};
  var kpiId = gwToSafeText_(payload.kpiId);
  if (!kpiId) throw new Error('kpiId가 필요합니다.');
  var found = gwFindKpiById_(kpiId);
  if (!found) throw new Error('KPI를 찾을 수 없습니다: ' + kpiId);
  var score = gwToSafeText_(payload.score);
  if (score === '') throw new Error('score는 필수입니다.');
  var numeric = Number(score);
  if (isNaN(numeric) || numeric < 0 || numeric > 100) throw new Error('score는 0~100 숫자여야 합니다.');
  var savePayload = Object.assign({}, found._sourceRow, {
    kpiId: kpiId,
    score: String(numeric),
    actualValue: gwToSafeText_(payload.actualValue || found.actualValue),
    evaluationComment: gwToSafeText_(payload.evaluationComment || payload.comment || found.evaluationComment),
    evaluatorEmployeeId: context.employeeId,
    kpiStatus: 'EVALUATED',
    status: 'EVALUATED',
    statusReason: gwToSafeText_(payload.statusReason || 'B07 KPI 평가 완료')
  });
  var result = gwSaveKpi_(savePayload, context, { mode: options.mode || 'EVALUATE' });
  result.appliedScore = numeric;
  return result;
}

function gwFindKpiById_(kpiId) {
  var sheet = gwGetKpiSheet_(true);
  gwEnsureHeaders_(sheet, GW_KPI_HEADERS.slice());
  var rows = gwReadRowsAsObjects_(sheet);
  for (var i = 0; i < rows.length; i++) {
    var row = gwNormalizeKpiRow_(rows[i]);
    if (row.kpiId === kpiId) return row;
  }
  return null;
}

function gwFindExistingKpiForSave_(rows, payload) {
  var kpiId = gwToSafeText_(payload.kpiId);
  if (!kpiId) return null;
  for (var i = 0; i < rows.length; i++) {
    var row = gwNormalizeKpiRow_(rows[i]);
    if (row.kpiId === kpiId) return row;
  }
  return null;
}

function gwValidateKpiPayload_(payload, existing) {
  if (!gwToSafeText_(payload.employeeId) && !existing) return { ok: false, message: 'employeeId가 필요합니다.' };
  if (!gwToSafeText_(payload.period)) return { ok: false, message: 'period가 필요합니다. 예: 2026-06 또는 2026-Q2' };
  if (!gwToSafeText_(payload.kpiTitle)) return { ok: false, message: 'kpiTitle이 필요합니다.' };
  var score = gwToSafeText_(payload.score);
  if (score !== '') {
    var numeric = Number(score);
    if (isNaN(numeric) || numeric < 0 || numeric > 100) return { ok: false, message: 'score는 0~100 숫자여야 합니다.' };
  }
  return { ok: true };
}

function gwSanitizeKpiPayload_(payload) {
  return {
    kpiId: gwToSafeText_(payload.kpiId),
    employeeId: gwToSafeText_(payload.employeeId),
    period: gwToSafeText_(payload.period),
    kpiCategory: gwToSafeText_(payload.kpiCategory),
    kpiTitle: gwToSafeText_(payload.kpiTitle).slice(0, 200),
    targetValue: gwToSafeText_(payload.targetValue),
    actualValue: gwToSafeText_(payload.actualValue),
    score: gwToSafeText_(payload.score),
    evaluatorEmployeeId: gwToSafeText_(payload.evaluatorEmployeeId),
    evaluationComment: gwToSafeText_(payload.evaluationComment).slice(0, 1000),
    kpiStatus: gwToSafeText_(payload.kpiStatus),
    status: gwToSafeText_(payload.status),
    statusReason: gwToSafeText_(payload.statusReason).slice(0, 500)
  };
}

function gwNormalizeKpiRow_(row) {
  row = row || {};
  var normalized = {
    _rowNumber: row._rowNumber,
    _sourceRow: row,
    kpiId: gwToSafeText_(row.kpiId),
    employeeId: gwToSafeText_(row.employeeId),
    period: gwToSafeText_(row.period),
    kpiCategory: gwNormalizeKpiCategory_(row.kpiCategory || 'GENERAL'),
    kpiTitle: gwToSafeText_(row.kpiTitle),
    targetValue: gwToSafeText_(row.targetValue),
    actualValue: gwToSafeText_(row.actualValue),
    score: gwToSafeText_(row.score),
    evaluatorEmployeeId: gwToSafeText_(row.evaluatorEmployeeId),
    evaluationComment: gwToSafeText_(row.evaluationComment),
    kpiStatus: gwNormalizeKpiStatus_(row.kpiStatus || row.status || 'ACTIVE'),
    status: gwNormalizeKpiStatus_(row.status || row.kpiStatus || 'ACTIVE'),
    statusReason: gwToSafeText_(row.statusReason),
    createdAt: gwToSafeText_(row.createdAt),
    createdBy: gwToSafeText_(row.createdBy),
    updatedAt: gwToSafeText_(row.updatedAt),
    updatedBy: gwToSafeText_(row.updatedBy)
  };
  return normalized;
}

function gwKpiToUiRow_(kpi) {
  return {
    kpiId: kpi.kpiId,
    employeeId: kpi.employeeId,
    period: kpi.period,
    kpiCategory: kpi.kpiCategory,
    kpiTitle: kpi.kpiTitle,
    targetValue: kpi.targetValue,
    actualValue: kpi.actualValue,
    score: kpi.score,
    evaluatorEmployeeId: kpi.evaluatorEmployeeId,
    evaluationComment: kpi.evaluationComment,
    kpiStatus: kpi.kpiStatus,
    status: kpi.status,
    statusReason: kpi.statusReason,
    createdAt: kpi.createdAt,
    createdBy: kpi.createdBy,
    updatedAt: kpi.updatedAt,
    updatedBy: kpi.updatedBy
  };
}

function gwNormalizeKpiStatus_(value) {
  var status = gwToSafeText_(value || 'ACTIVE').toUpperCase();
  return GW_KPI_STATUSES.indexOf(status) >= 0 ? status : 'ACTIVE';
}

function gwNormalizeKpiCategory_(value) {
  var category = gwToSafeText_(value || 'GENERAL').toUpperCase();
  return GW_KPI_CATEGORIES.indexOf(category) >= 0 ? category : 'GENERAL';
}

function gwKpiIsLocked_(kpi) {
  var status = gwNormalizeKpiStatus_(kpi && (kpi.kpiStatus || kpi.status));
  return status === 'CLOSED' || status === 'ARCHIVED';
}

function gwKpiDateToMillis_(value) {
  var text = gwToSafeText_(value);
  if (!text) return 0;
  var parsed = Date.parse(text.replace(/-/g, '/'));
  return isNaN(parsed) ? 0 : parsed;
}
