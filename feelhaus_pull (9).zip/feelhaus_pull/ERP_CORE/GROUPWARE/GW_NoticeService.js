const GW_NOTICE_SHEET_CANDIDATES = Object.freeze(['Portal_Notices', 'PORTAL_Notices', 'PORTAL_NOTICE', 'Notices', 'GW_Notices']);
const GW_NOTICE_PREFERRED_SHEET_NAME = 'Portal_Notices';
const GW_NOTICE_READ_SHEET_CANDIDATES = Object.freeze(['Portal_NoticeReads', 'PORTAL_NoticeReads', 'NoticeReads', 'GW_NoticeReads']);
const GW_NOTICE_READ_PREFERRED_SHEET_NAME = 'Portal_NoticeReads';

const GW_NOTICE_HEADERS = Object.freeze([
  'noticeId', 'title', 'content', 'noticeType',
  'targetRoleCode', 'targetVendorId', 'targetEventId',
  'pinnedYn', 'displayStartAt', 'displayEndAt', 'attachmentFileIds',
  'status', 'statusReason', 'viewCount',
  'createdAt', 'createdBy', 'updatedAt', 'updatedBy'
]);

const GW_NOTICE_READ_HEADERS = Object.freeze([
  'noticeReadId', 'noticeId', 'employeeId', 'readAt', 'createdAt', 'createdBy'
]);

const GW_NOTICE_STATUSES = Object.freeze(['DRAFT', 'ACTIVE', 'INACTIVE', 'ARCHIVED']);
const GW_NOTICE_TYPES = Object.freeze(['GENERAL', 'EVENT', 'VENDOR', 'HR', 'SYSTEM']);

function gwGetNoticeSheet_(createIfMissing) {
  var ss = gwGetMasterSpreadsheet_();
  for (var i = 0; i < GW_NOTICE_SHEET_CANDIDATES.length; i++) {
    var sheet = ss.getSheetByName(GW_NOTICE_SHEET_CANDIDATES[i]);
    if (sheet) return sheet;
  }
  if (createIfMissing) {
    var created = ss.insertSheet(GW_NOTICE_PREFERRED_SHEET_NAME);
    created.getRange(1, 1, 1, GW_NOTICE_HEADERS.length).setValues([GW_NOTICE_HEADERS]);
    return created;
  }
  throw new Error('공지 시트를 찾을 수 없습니다. 허용 시트명: ' + GW_NOTICE_SHEET_CANDIDATES.join(', '));
}

function gwGetNoticeReadSheet_(createIfMissing) {
  var ss = gwGetMasterSpreadsheet_();
  for (var i = 0; i < GW_NOTICE_READ_SHEET_CANDIDATES.length; i++) {
    var sheet = ss.getSheetByName(GW_NOTICE_READ_SHEET_CANDIDATES[i]);
    if (sheet) return sheet;
  }
  if (createIfMissing) {
    var created = ss.insertSheet(GW_NOTICE_READ_PREFERRED_SHEET_NAME);
    created.getRange(1, 1, 1, GW_NOTICE_READ_HEADERS.length).setValues([GW_NOTICE_READ_HEADERS]);
    return created;
  }
  throw new Error('공지 읽음 시트를 찾을 수 없습니다. 허용 시트명: ' + GW_NOTICE_READ_SHEET_CANDIDATES.join(', '));
}

function gwEnsureNoticeHeaders_() {
  var sheet = gwGetNoticeSheet_(true);
  var before = gwGetHeaders_(sheet).filter(function (h) { return h; });
  var result = gwEnsureHeaders_(sheet, GW_NOTICE_HEADERS.slice());
  var after = gwGetHeaders_(sheet).filter(function (h) { return h; });
  return {
    ok: result.ok,
    sheetName: sheet.getName(),
    beforeCount: before.length,
    afterCount: after.length,
    addedHeaders: after.filter(function (h) { return before.indexOf(h) < 0; }),
    missing: result.missing || []
  };
}

function gwEnsureNoticeReadHeaders_() {
  var sheet = gwGetNoticeReadSheet_(true);
  var before = gwGetHeaders_(sheet).filter(function (h) { return h; });
  var result = gwEnsureHeaders_(sheet, GW_NOTICE_READ_HEADERS.slice());
  var after = gwGetHeaders_(sheet).filter(function (h) { return h; });
  return {
    ok: result.ok,
    sheetName: sheet.getName(),
    beforeCount: before.length,
    afterCount: after.length,
    addedHeaders: after.filter(function (h) { return before.indexOf(h) < 0; }),
    missing: result.missing || []
  };
}

function gwCheckNoticeHeaders_() {
  var sheet = gwGetNoticeSheet_(false);
  var check = gwCheckRequiredHeaders_(sheet, GW_NOTICE_HEADERS.slice());
  return {
    ok: check.ok,
    sheetName: sheet.getName(),
    sheetExists: true,
    prepareRequired: !check.ok,
    headerCount: check.headers.length,
    missing: check.missing,
    expectedHeaders: GW_NOTICE_HEADERS.slice()
  };
}

function gwInspectNoticeHeadersNoWrite_B03_() {
  var ss = gwGetMasterSpreadsheet_();
  var noticeSheet = null;
  var noticeReadSheet = null;
  for (var i = 0; i < GW_NOTICE_SHEET_CANDIDATES.length; i++) {
    noticeSheet = ss.getSheetByName(GW_NOTICE_SHEET_CANDIDATES[i]);
    if (noticeSheet) break;
  }
  for (var j = 0; j < GW_NOTICE_READ_SHEET_CANDIDATES.length; j++) {
    noticeReadSheet = ss.getSheetByName(GW_NOTICE_READ_SHEET_CANDIDATES[j]);
    if (noticeReadSheet) break;
  }

  var result = {
    ok: true,
    mode: 'NO_WRITE_INSPECT',
    noticeSheetExists: !!noticeSheet,
    noticeReadSheetExists: !!noticeReadSheet,
    noticeSheetName: noticeSheet ? noticeSheet.getName() : '',
    noticeReadSheetName: noticeReadSheet ? noticeReadSheet.getName() : '',
    preferredNoticeSheetName: GW_NOTICE_PREFERRED_SHEET_NAME,
    preferredNoticeReadSheetName: GW_NOTICE_READ_PREFERRED_SHEET_NAME,
    requiredNoticeHeaderCount: GW_NOTICE_HEADERS.length,
    requiredNoticeReadHeaderCount: GW_NOTICE_READ_HEADERS.length,
    prepareRequired: false,
    missingNoticeHeaders: [],
    missingNoticeReadHeaders: []
  };

  if (!noticeSheet) {
    result.prepareRequired = true;
    result.message = '공지 시트가 아직 없습니다. gwInternalTest_B03_HeaderEnsure()에서 생성됩니다.';
  } else {
    var noticeCheck = gwCheckRequiredHeaders_(noticeSheet, GW_NOTICE_HEADERS.slice());
    result.noticeHeaderCount = noticeCheck.headers.length;
    result.missingNoticeHeaders = noticeCheck.missing || [];
    if (!noticeCheck.ok) result.prepareRequired = true;
  }

  if (!noticeReadSheet) {
    result.prepareRequired = true;
    result.readMessage = '공지 읽음 시트가 아직 없습니다. gwInternalTest_B03_HeaderEnsure()에서 생성됩니다.';
  } else {
    var readCheck = gwCheckRequiredHeaders_(noticeReadSheet, GW_NOTICE_READ_HEADERS.slice());
    result.noticeReadHeaderCount = readCheck.headers.length;
    result.missingNoticeReadHeaders = readCheck.missing || [];
    if (!readCheck.ok) result.prepareRequired = true;
  }

  return result;
}

function gwGetB03NoticeMeta_() {
  return {
    buildStep: '03/10',
    noticeSheetCandidates: GW_NOTICE_SHEET_CANDIDATES.slice(),
    noticeReadSheetCandidates: GW_NOTICE_READ_SHEET_CANDIDATES.slice(),
    noticeStatuses: GW_NOTICE_STATUSES.slice(),
    noticeTypes: GW_NOTICE_TYPES.slice(),
    requiredHeaders: GW_NOTICE_HEADERS.slice()
  };
}

function gwListNoticesForUi(payload) {
  payload = payload || {};
  var context = gwAssertPermission_('canAccessPortal');
  var sheet = gwGetNoticeSheet_(true);
  gwEnsureHeaders_(sheet, GW_NOTICE_HEADERS.slice());
  var rows = gwReadRowsAsObjects_(sheet).map(function (row) { return gwNormalizeNoticeRow_(row); });
  var query = gwToSafeText_(payload.query).toLowerCase();
  var includeAll = payload.includeAll === true && gwCanSafe_(context, 'canAccessDevConsole');
  var limit = Math.min(Number(payload.limit || 100), 500);

  rows = rows.filter(function (notice) {
    if (!includeAll && !gwIsNoticeVisibleToContext_(notice, context)) return false;
    if (query) {
      var hay = [notice.noticeId, notice.title, notice.content, notice.noticeType, notice.targetRoleCode, notice.targetVendorId, notice.targetEventId, notice.status].join(' ').toLowerCase();
      if (hay.indexOf(query) < 0) return false;
    }
    return true;
  });

  rows.sort(function (a, b) {
    var pa = gwNormalizeYn_(a.pinnedYn) ? 1 : 0;
    var pb = gwNormalizeYn_(b.pinnedYn) ? 1 : 0;
    if (pa !== pb) return pb - pa;
    return gwNoticeDateToMillis_(b.updatedAt || b.createdAt || b.displayStartAt) - gwNoticeDateToMillis_(a.updatedAt || a.createdAt || a.displayStartAt);
  });

  rows = rows.slice(0, limit).map(function (notice) { return gwNoticeToUiRow_(notice); });
  return gwOk_({ rows: rows, totalReturned: rows.length, sheetName: sheet.getName() }, '공지 목록 조회 완료');
}

function gwGetNoticeDetailForUi(payload) {
  payload = payload || {};
  var context = gwAssertPermission_('canAccessPortal');
  var noticeId = gwToSafeText_(payload.noticeId);
  if (!noticeId) return gwFail_('MISSING_NOTICE_ID', 'noticeId가 필요합니다.');
  var notice = gwFindNoticeById_(noticeId);
  if (!notice) return gwFail_('NOTICE_NOT_FOUND', '공지를 찾을 수 없습니다.', { noticeId: noticeId });
  if (!gwCanSafe_(context, 'canAccessDevConsole') && !gwIsNoticeVisibleToContext_(notice, context)) {
    return gwFail_('NOTICE_NO_PERMISSION', '해당 공지를 조회할 권한이 없습니다.', { noticeId: noticeId });
  }
  if (payload.markRead === true) gwMarkNoticeReadSafe_(noticeId, context.employeeId);
  return gwOk_({ notice: gwNoticeToUiRow_(notice) }, '공지 상세 조회 완료');
}

function gwSaveNoticeForUi(payload) {
  payload = payload || {};
  var context = gwAssertPermission_('canAccessDevConsole');
  var result = gwSaveNotice_(payload, context, { mode: 'UI' });
  return gwOk_(result, result.action === 'CREATE' ? '공지 등록 완료' : '공지 수정 완료');
}

function gwSetNoticeStatusForUi(payload) {
  payload = payload || {};
  var context = gwAssertPermission_('canAccessDevConsole');
  var noticeId = gwToSafeText_(payload.noticeId);
  if (!noticeId) return gwFail_('MISSING_NOTICE_ID', 'noticeId가 필요합니다.');
  var notice = gwFindNoticeById_(noticeId);
  if (!notice) return gwFail_('NOTICE_NOT_FOUND', '공지 상태 변경 대상을 찾을 수 없습니다.', { noticeId: noticeId });
  var result = gwSaveNotice_(Object.assign({}, notice._sourceRow, {
    noticeId: notice.noticeId,
    title: notice.title,
    content: notice.content,
    status: gwNormalizeNoticeStatus_(payload.status || 'INACTIVE'),
    statusReason: gwToSafeText_(payload.statusReason) || 'B03 상태 변경'
  }), context, { mode: 'STATUS' });
  return gwOk_(result, '공지 상태 변경 완료');
}

function gwSaveNotice_(payload, context, options) {
  payload = gwSanitizeNoticePayload_(payload || {});
  context = context || gwGetUserContextSafe_();
  options = options || {};
  var sheet = gwGetNoticeSheet_(true);
  gwEnsureHeaders_(sheet, GW_NOTICE_HEADERS.slice());
  var headers = gwGetHeaders_(sheet).filter(function (h) { return h; });
  var rows = gwReadRowsAsObjects_(sheet);
  var existing = gwFindExistingNoticeForSave_(rows, payload);
  var validation = gwValidateNoticePayload_(payload, existing);
  if (!validation.ok) throw new Error(validation.message);

  var now = gwNow_();
  var noticeId = gwToSafeText_(payload.noticeId) || (existing ? existing.noticeId : gwUuid_('NTC'));
  var rowObj = existing ? Object.assign({}, existing._sourceRow) : {};
  var action = existing ? 'UPDATE' : 'CREATE';
  var status = gwNormalizeNoticeStatus_(payload.status || (existing ? existing.status : 'ACTIVE'));

  rowObj.noticeId = noticeId;
  rowObj.title = gwToSafeText_(payload.title).slice(0, 200);
  rowObj.content = gwToSafeText_(payload.content).slice(0, 10000);
  rowObj.noticeType = gwNormalizeNoticeType_(payload.noticeType || 'GENERAL');
  rowObj.targetRoleCode = gwToSafeText_(payload.targetRoleCode || 'ALL');
  rowObj.targetVendorId = gwToSafeText_(payload.targetVendorId || 'ALL');
  rowObj.targetEventId = gwToSafeText_(payload.targetEventId || 'ALL');
  rowObj.pinnedYn = gwPayloadYn_(payload.pinnedYn);
  rowObj.displayStartAt = gwToSafeText_(payload.displayStartAt) || now;
  rowObj.displayEndAt = gwToSafeText_(payload.displayEndAt);
  rowObj.attachmentFileIds = gwNormalizeCsvText_(payload.attachmentFileIds);
  rowObj.status = status;
  rowObj.statusReason = gwToSafeText_(payload.statusReason).slice(0, 500);
  rowObj.viewCount = existing ? (Number(existing.viewCount || 0) || 0) : 0;
  if (!existing) {
    rowObj.createdAt = now;
    rowObj.createdBy = context.employeeId || 'UNKNOWN';
  }
  rowObj.updatedAt = now;
  rowObj.updatedBy = context.employeeId || 'UNKNOWN';

  var rowNumber;
  if (existing && existing._rowNumber) {
    rowNumber = existing._rowNumber;
    var row = headers.map(function (h) { return Object.prototype.hasOwnProperty.call(rowObj, h) ? rowObj[h] : ''; });
    sheet.getRange(rowNumber, 1, 1, headers.length).setValues([row]);
  } else {
    rowNumber = gwAppendObjectRow_(sheet, rowObj, GW_NOTICE_HEADERS.slice());
  }

  gwAuditSafe_({
    moduleCode: 'GROUPWARE_NOTICE',
    actionType: action === 'CREATE' ? 'NOTICE_CREATE' : 'NOTICE_UPDATE',
    targetId: noticeId,
    employeeId: context.employeeId,
    resultStatus: 'SUCCESS',
    detailMessage: 'B03 공지 저장: ' + rowObj.title
  });

  return {
    ok: true,
    action: action,
    sheetName: sheet.getName(),
    rowNumber: rowNumber,
    notice: gwNoticeToUiRow_(gwNormalizeNoticeRow_(Object.assign({ _rowNumber: rowNumber }, rowObj)))
  };
}

function gwFindNoticeById_(noticeId) {
  noticeId = gwToSafeText_(noticeId);
  if (!noticeId) return null;
  var sheet = gwGetNoticeSheet_(true);
  var rows = gwReadRowsAsObjects_(sheet);
  for (var i = 0; i < rows.length; i++) {
    var notice = gwNormalizeNoticeRow_(rows[i]);
    if (notice.noticeId === noticeId) return notice;
  }
  return null;
}

function gwFindExistingNoticeForSave_(rows, payload) {
  var noticeId = gwToSafeText_(payload.noticeId);
  if (!noticeId) return null;
  for (var i = 0; i < rows.length; i++) {
    var notice = gwNormalizeNoticeRow_(rows[i]);
    if (notice.noticeId === noticeId) return notice;
  }
  return null;
}

function gwNormalizeNoticeRow_(row) {
  row = row || {};
  var notice = {
    noticeId: gwToSafeText_(row.noticeId),
    title: gwToSafeText_(row.title),
    content: gwToSafeText_(row.content),
    noticeType: gwNormalizeNoticeType_(row.noticeType),
    targetRoleCode: gwToSafeText_(row.targetRoleCode || 'ALL'),
    targetVendorId: gwToSafeText_(row.targetVendorId || 'ALL'),
    targetEventId: gwToSafeText_(row.targetEventId || 'ALL'),
    pinnedYn: gwPayloadYn_(row.pinnedYn),
    displayStartAt: row.displayStartAt,
    displayEndAt: row.displayEndAt,
    attachmentFileIds: gwToSafeText_(row.attachmentFileIds),
    status: gwNormalizeNoticeStatus_(row.status),
    statusReason: gwToSafeText_(row.statusReason),
    viewCount: Number(row.viewCount || 0) || 0,
    createdAt: row.createdAt,
    createdBy: gwToSafeText_(row.createdBy),
    updatedAt: row.updatedAt,
    updatedBy: gwToSafeText_(row.updatedBy),
    _rowNumber: row._rowNumber,
    _sourceRow: row
  };
  return notice;
}

function gwNoticeToUiRow_(notice) {
  return {
    noticeId: gwToSafeText_(notice.noticeId),
    title: gwToSafeText_(notice.title),
    content: gwToSafeText_(notice.content),
    noticeType: gwToSafeText_(notice.noticeType),
    targetRoleCode: gwToSafeText_(notice.targetRoleCode),
    targetVendorId: gwToSafeText_(notice.targetVendorId),
    targetEventId: gwToSafeText_(notice.targetEventId),
    pinnedYn: gwPayloadYn_(notice.pinnedYn),
    displayStartAt: gwDateDisplayText_(notice.displayStartAt),
    displayEndAt: gwDateDisplayText_(notice.displayEndAt),
    attachmentFileIds: gwToSafeText_(notice.attachmentFileIds),
    status: gwToSafeText_(notice.status),
    statusReason: gwToSafeText_(notice.statusReason),
    viewCount: Number(notice.viewCount || 0) || 0,
    createdAt: gwDateDisplayText_(notice.createdAt),
    createdBy: gwToSafeText_(notice.createdBy),
    updatedAt: gwDateDisplayText_(notice.updatedAt),
    updatedBy: gwToSafeText_(notice.updatedBy),
    _rowNumber: notice._rowNumber
  };
}

function gwIsNoticeVisibleToContext_(notice, context) {
  if (!notice) return false;
  context = context || gwGetUserContextSafe_();
  if (gwCanSafe_(context, 'canAccessDevConsole')) return true;
  if (notice.status !== 'ACTIVE') return false;
  var nowMs = new Date().getTime();
  var startMs = gwNoticeDateToMillis_(notice.displayStartAt);
  var endMs = gwNoticeDateToMillis_(notice.displayEndAt);
  if (startMs && startMs > nowMs) return false;
  if (endMs && endMs < nowMs) return false;
  if (!gwNoticeTargetMatches_(notice.targetRoleCode, context.roleCode)) return false;
  if (!gwNoticeTargetMatches_(notice.targetVendorId, context.vendorId)) return false;
  if (!gwNoticeTargetMatches_(notice.targetEventId, context.eventId)) return false;
  return true;
}

function gwNoticeTargetMatches_(targetText, actualValue) {
  targetText = gwToSafeText_(targetText);
  actualValue = gwToSafeText_(actualValue);
  if (!targetText || targetText.toUpperCase() === 'ALL' || targetText === '*') return true;
  var parts = targetText.split(',').map(function (p) { return gwToSafeText_(p); }).filter(function (p) { return p; });
  if (parts.length === 0) return true;
  return parts.some(function (p) { return p.toUpperCase() === 'ALL' || p === '*' || p === actualValue || p.toUpperCase() === actualValue.toUpperCase(); });
}

function gwValidateNoticePayload_(payload, existing) {
  if (!gwToSafeText_(payload.title)) return { ok: false, message: '공지 제목은 필수입니다.' };
  if (!gwToSafeText_(payload.content)) return { ok: false, message: '공지 내용은 필수입니다.' };
  var status = gwNormalizeNoticeStatus_(payload.status || (existing ? existing.status : 'ACTIVE'));
  if (GW_NOTICE_STATUSES.indexOf(status) < 0) return { ok: false, message: '허용되지 않은 공지 상태입니다: ' + status };
  return { ok: true };
}

function gwSanitizeNoticePayload_(payload) {
  var clean = {};
  ['noticeId', 'title', 'content', 'noticeType', 'targetRoleCode', 'targetVendorId', 'targetEventId', 'pinnedYn', 'displayStartAt', 'displayEndAt', 'attachmentFileIds', 'status', 'statusReason'].forEach(function (key) {
    if (typeof payload[key] !== 'undefined') clean[key] = payload[key];
  });
  return clean;
}

function gwNormalizeNoticeStatus_(value) {
  var text = gwToSafeText_(value).toUpperCase();
  if (!text) return 'ACTIVE';
  if (text === 'PUBLISHED' || text === 'POSTED' || text === 'OPEN') return 'ACTIVE';
  if (text === 'DISABLED' || text === 'CLOSED') return 'INACTIVE';
  if (GW_NOTICE_STATUSES.indexOf(text) >= 0) return text;
  return text;
}

function gwNormalizeNoticeType_(value) {
  var text = gwToSafeText_(value).toUpperCase();
  if (!text) return 'GENERAL';
  if (GW_NOTICE_TYPES.indexOf(text) >= 0) return text;
  return 'GENERAL';
}

function gwNormalizeCsvText_(value) {
  return gwToSafeText_(value).split(',').map(function (p) { return gwToSafeText_(p); }).filter(function (p) { return p; }).join(',');
}

function gwNoticeDateToMillis_(value) {
  if (!value) return 0;
  if (Object.prototype.toString.call(value) === '[object Date]') return value.getTime();
  var text = gwToSafeText_(value);
  if (!text) return 0;
  var date = new Date(text.replace(/\./g, '-'));
  var time = date.getTime();
  return isNaN(time) ? 0 : time;
}

function gwDateDisplayText_(value) {
  if (!value) return '';
  if (Object.prototype.toString.call(value) === '[object Date]') return Utilities.formatDate(value, 'Asia/Seoul', 'yyyy-MM-dd HH:mm:ss');
  return gwToSafeText_(value);
}

function gwMarkNoticeReadSafe_(noticeId, employeeId) {
  try {
    var sheet = gwGetNoticeReadSheet_(true);
    gwEnsureHeaders_(sheet, GW_NOTICE_READ_HEADERS.slice());
    var rows = gwReadRowsAsObjects_(sheet);
    for (var i = 0; i < rows.length; i++) {
      if (gwToSafeText_(rows[i].noticeId) === noticeId && gwToSafeText_(rows[i].employeeId) === employeeId) return { ok: true, duplicate: true };
    }
    var row = {
      noticeReadId: gwUuid_('NTRD'),
      noticeId: noticeId,
      employeeId: employeeId,
      readAt: gwNow_(),
      createdAt: gwNow_(),
      createdBy: employeeId
    };
    var rowNumber = gwAppendObjectRow_(sheet, row, GW_NOTICE_READ_HEADERS.slice());
    return { ok: true, rowNumber: rowNumber };
  } catch (err) {
    return { ok: false, message: gwErrorMessage_(err) };
  }
}
