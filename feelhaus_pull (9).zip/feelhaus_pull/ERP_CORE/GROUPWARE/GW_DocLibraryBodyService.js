/**
 * B14 PORTAL body-only UI service for Document Library.
 * This file returns body-only screen models and bodyHtml strings for PORTAL handlers.
 * It must not render module navigation, its own top bar, its own side bar, iframe, preview route, or standalone shell.
 */
const GW_B14_MODULE_CODE = 'GROUPWARE';
const GW_B14_BODY_IDS = Object.freeze(['GW_DocLibraryBody']);
const GW_B14_FORBIDDEN_VISIBLE_TOKENS = Object.freeze(['<iframe', 'preview route', 'standalone shell', 'data-module-menu', 'gw-own-menu', 'gw-side-menu', 'gw-top-menu']);

const GW_B14_LIBRARY_FORM_FIELDS = Object.freeze([
  'libraryFileId', 'category', 'title', 'description', 'driveFileId', 'driveFolderId',
  'fileName', 'fileType', 'fileSize', 'targetRoleCode', 'targetVendorId', 'targetEventId',
  'downloadAllowedYn', 'status', 'statusReason'
]);

function gwGetB14BodySpecs() {
  return [
    {
      moduleCode: GW_B14_MODULE_CODE,
      menuId: 'gw.library',
      route: '/groupware/library',
      handler: 'gwHandleDocLibraryBody',
      viewFile: 'GW_DocLibraryBody.html',
      screenId: 'GW_DocLibraryBody',
      title: '사내 자료실',
      description: 'Documents 또는 Portal_DocLibrary 기준 자료 목록, 상세, Drive fileId 등록, 다운로드 권한 안내, 다운로드 로그를 담당하는 PORTAL 본문 화면입니다.',
      permissionCode: 'canDownloadFiles',
      adminPermissionCode: 'canAccessDevConsole',
      buttons: [
        { id: 'btnReloadLibrary', label: '조회', call: 'listLibraryFiles', style: 'primary' },
        { id: 'btnNewLibraryFile', label: '새 자료', call: 'prepareNewLibraryFile', style: 'secondary' },
        { id: 'btnSaveLibraryFile', label: '저장', call: 'saveLibraryFile', style: 'primary' },
        { id: 'btnLogLibraryDownload', label: '다운로드 로그', call: 'logLibraryDownload', style: 'secondary' }
      ],
      calls: ['listLibraryFiles', 'getLibraryFileDetail', 'saveLibraryFile', 'logLibraryDownload'],
      sheets: ['Documents', 'Portal_DocLibrary', 'Portal_FileDownloadLogs'],
      logSheet: 'Portal_AuditLog',
      screenStructure: ['화면 제목', '화면 설명', '주요 작업 버튼', '검색 / 필터', '목록 / 입력폼 / 상세', '성공 / 실패 안내문']
    }
  ];
}

function gwHandleDocLibraryBody(payload) {
  payload = payload || {};
  gwAssertPermission_('canAccessPortal');
  var listResult = gwListLibraryFilesForUi({
    query: payload.query || '',
    category: payload.category || 'ALL',
    limit: payload.limit || 50,
    includeAll: payload.includeAll === true
  });
  if (!listResult.ok) return listResult;
  var rows = (listResult.data && listResult.data.rows) || [];
  var selected = null;
  if (payload.libraryFileId) {
    var detailResult = gwGetLibraryFileDetailForUi({ libraryFileId: payload.libraryFileId });
    if (detailResult.ok) selected = detailResult.data.file;
  } else if (rows.length > 0) {
    selected = rows[0];
  }
  var model = gwBuildDocLibraryBodyModel_(rows, selected, payload);
  return gwOk_(model, '사내 자료실 본문 구성 완료');
}

function gwBuildDocLibraryBodyModel_(rows, selected, payload) {
  var spec = gwFindB14BodySpec_('GW_DocLibraryBody');
  var model = {
    moduleCode: GW_B14_MODULE_CODE,
    screenId: spec.screenId,
    menuId: spec.menuId,
    route: spec.route,
    handler: spec.handler,
    title: spec.title,
    description: spec.description,
    permissionCode: spec.permissionCode,
    actions: spec.buttons,
    filters: [
      { id: 'librarySearchKeyword', label: '검색어', field: 'query', value: gwToSafeText_(payload.query), placeholder: '제목, 설명, 파일명, 카테고리, 대상 role/vendor/event' },
      { id: 'libraryCategoryFilter', label: '카테고리', field: 'category', value: gwToSafeText_(payload.category || 'ALL'), options: ['ALL'].concat(GW_LIBRARY_CATEGORIES || []) }
    ],
    list: {
      title: '자료 목록',
      totalReturned: rows.length,
      columns: ['libraryFileId', 'category', 'title', 'fileName', 'fileType', 'targetRoleCode', 'downloadAllowedYn', 'status'],
      rows: rows
    },
    form: {
      title: selected ? '자료 상세 / 수정' : '새 자료 / 상세',
      fields: gwBuildB14LibraryFormFields_(selected)
    },
    messages: [
      { type: 'info', text: 'PORTAL 중앙 메뉴에서 열린 본문 화면입니다. 이 화면은 메뉴를 렌더링하지 않습니다.' },
      { type: 'success', text: '자료 저장 또는 다운로드 로그 기록 성공 시 목록을 다시 조회합니다.' },
      { type: 'error', text: '필수값, Drive fileId, 권한 오류가 있으면 이 영역에 실패 안내문을 표시합니다.' }
    ],
    apiCalls: spec.calls,
    saveSheet: 'Documents',
    readSheet: 'Portal_FileDownloadLogs',
    logSheet: 'Portal_AuditLog'
  };
  model.bodyHtml = gwRenderB14DocLibraryBodyHtml_(model);
  model.bodyAudit = gwValidateB14BodyModel_(model);
  return model;
}

function gwFindB14BodySpec_(screenId) {
  var specs = gwGetB14BodySpecs();
  for (var i = 0; i < specs.length; i++) {
    if (specs[i].screenId === screenId) return specs[i];
  }
  throw new Error('B14 본문 책임표를 찾을 수 없습니다: ' + screenId);
}

function gwBuildB14LibraryFormFields_(file) {
  file = file || {};
  return GW_B14_LIBRARY_FORM_FIELDS.map(function (field) {
    return {
      field: field,
      label: gwGetB14LibraryFieldLabel_(field),
      value: gwToSafeText_(file[field]),
      required: field === 'title' || field === 'category' || field === 'driveFileId' || field === 'status',
      inputType: field === 'description' || field === 'statusReason' ? 'textarea' : (field === 'downloadAllowedYn' ? 'checkbox' : 'text')
    };
  });
}

function gwGetB14LibraryFieldLabel_(field) {
  var labels = {
    libraryFileId: '자료 ID', category: '카테고리', title: '자료명', description: '설명',
    driveFileId: 'Drive fileId', driveFolderId: 'Drive folderId', fileName: '파일명', fileType: '파일 유형', fileSize: '파일 크기',
    targetRoleCode: '대상 역할', targetVendorId: '대상 업체', targetEventId: '대상 행사',
    downloadAllowedYn: '다운로드 허용', status: '상태', statusReason: '상태 사유'
  };
  return labels[field] || field;
}

function gwRenderB14DocLibraryBodyHtml_(model) {
  var rowsHtml = model.list.rows.map(function (row) {
    return '<tr data-library-file-id="' + gwEscHtml_(row.libraryFileId) + '">' +
      '<td>' + gwEscHtml_(row.libraryFileId) + '</td>' +
      '<td>' + gwEscHtml_(row.category) + '</td>' +
      '<td>' + gwEscHtml_(row.title) + '</td>' +
      '<td>' + gwEscHtml_(row.fileName) + '</td>' +
      '<td>' + gwEscHtml_(row.fileType) + '</td>' +
      '<td>' + gwEscHtml_(row.targetRoleCode) + '</td>' +
      '<td>' + gwEscHtml_(row.downloadAllowedYn) + '</td>' +
      '<td>' + gwEscHtml_(row.status) + '</td>' +
    '</tr>';
  }).join('') || '<tr><td colspan="8">표시할 자료가 없습니다.</td></tr>';
  var fieldsHtml = model.form.fields.map(function (field) {
    if (field.inputType === 'textarea') {
      return '<label>' + gwEscHtml_(field.label) + '<textarea data-field="' + gwEscHtml_(field.field) + '">' + gwEscHtml_(field.value) + '</textarea></label>';
    }
    if (field.inputType === 'checkbox') {
      var checked = gwNormalizeYnText_(field.value) === 'Y' ? ' checked' : '';
      return '<label><input type="checkbox" data-field="' + gwEscHtml_(field.field) + '" value="Y"' + checked + ' /> ' + gwEscHtml_(field.label) + '</label>';
    }
    return '<label>' + gwEscHtml_(field.label) + '<input type="text" data-field="' + gwEscHtml_(field.field) + '" value="' + gwEscHtml_(field.value) + '" /></label>';
  }).join('');
  return '<section class="gw-body gw-library-body" data-screen-id="GW_DocLibraryBody">' +
    '<h2>' + gwEscHtml_(model.title) + '</h2>' +
    '<p>' + gwEscHtml_(model.description) + '</p>' +
    '<div class="gw-actions">' + gwRenderB14ActionButtons_(model.actions) + '</div>' +
    '<div class="gw-filter"><label>검색 / 필터<input type="text" data-field="query" value="' + gwEscHtml_(model.filters[0].value) + '" /></label></div>' +
    '<div class="gw-message-zone"><p data-message-type="info">자료를 선택하거나 Drive fileId를 입력한 뒤 저장합니다.</p></div>' +
    '<div class="gw-layout-two"><div class="gw-list"><h3>목록</h3><table><thead><tr><th>자료 ID</th><th>카테고리</th><th>자료명</th><th>파일명</th><th>유형</th><th>대상</th><th>다운로드</th><th>상태</th></tr></thead><tbody>' + rowsHtml + '</tbody></table></div>' +
    '<div class="gw-detail"><h3>입력폼 / 상세</h3>' + fieldsHtml + '</div></div>' +
  '</section>';
}

function gwRenderB14ActionButtons_(actions) {
  return actions.map(function (action) {
    return '<button type="button" data-gw-action="' + gwEscHtml_(action.call) + '" data-button-id="' + gwEscHtml_(action.id) + '">' + gwEscHtml_(action.label) + '</button>';
  }).join('');
}

function gwValidateB14BodyModel_(model) {
  var errors = [];
  var html = gwToSafeText_(model.bodyHtml);
  if (html.indexOf('<h2>') < 0) errors.push('화면 제목 누락: ' + model.screenId);
  if (html.indexOf('<p>') < 0) errors.push('화면 설명 누락: ' + model.screenId);
  if (html.indexOf('data-gw-action') < 0) errors.push('주요 작업 버튼 연결 누락: ' + model.screenId);
  if (html.indexOf('gw-filter') < 0) errors.push('검색 / 필터 영역 누락: ' + model.screenId);
  if (html.indexOf('gw-list') < 0 || html.indexOf('gw-detail') < 0) errors.push('목록 / 입력폼 / 상세 영역 누락: ' + model.screenId);
  if (html.indexOf('gw-message-zone') < 0) errors.push('성공 / 실패 안내문 영역 누락: ' + model.screenId);
  GW_B14_FORBIDDEN_VISIBLE_TOKENS.forEach(function (token) {
    if (html.toLowerCase().indexOf(token.toLowerCase()) >= 0) errors.push('금지 UI 토큰 포함: ' + token);
  });
  return { ok: errors.length === 0, errors: errors, htmlLength: html.length };
}

function gwValidateB14BodyContracts(payload) {
  var errors = [];
  var specs = gwGetB14BodySpecs();
  var expectedHandlers = { gwHandleDocLibraryBody: true };
  var expectedRoutes = { '/groupware/library': true };
  specs.forEach(function (spec) {
    if (spec.moduleCode !== GW_B14_MODULE_CODE) errors.push('moduleCode 오류: ' + spec.screenId);
    if (!expectedHandlers[spec.handler]) errors.push('handler 오류: ' + spec.handler);
    if (!expectedRoutes[spec.route]) errors.push('route 오류: ' + spec.route);
    if (spec.permissionCode !== 'canDownloadFiles') errors.push('permissionCode 오류: ' + spec.screenId);
    if (!spec.buttons || spec.buttons.length === 0) errors.push('버튼 목록 누락: ' + spec.screenId);
    if (!spec.calls || spec.calls.length === 0) errors.push('호출 함수 누락: ' + spec.screenId);
    if (spec.sheets.indexOf('Portal_FileDownloadLogs') < 0) errors.push('다운로드 로그 시트 누락: ' + spec.screenId);
    if (spec.logSheet !== 'Portal_AuditLog') errors.push('로그 시트 오류: ' + spec.screenId);
  });
  return gwOk_({ ok: errors.length === 0, errors: errors, specCount: specs.length, portalShellOnly: true }, errors.length === 0 ? 'B14_BODY_CONTRACT_OK' : 'B14_BODY_CONTRACT_ERROR');
}
