var GW_CONFIG_CACHE_ = null;
var GW_MASTER_DB_ID_CACHE_ = null;

function gwGetSetupSpreadsheet_() {
  return gwOpenSpreadsheetById_(GW_SETUP_DB_ID, GW_SOURCE_DB_NAME);
}

function gwGetSystemConfigMap_() {
  if (GW_CONFIG_CACHE_) return GW_CONFIG_CACHE_;

  var ss = gwGetSetupSpreadsheet_();
  var sheet = ss.getSheetByName(GW_CONFIG_SHEET_NAME);
  if (!sheet) throw new Error(GW_CONFIG_SHEET_NAME + ' 시트를 찾을 수 없습니다.');

  var range = sheet.getDataRange();
  var values = range ? range.getDisplayValues() : [];
  if (!values || values.length < 1) {
    GW_CONFIG_CACHE_ = {};
    return GW_CONFIG_CACHE_;
  }

  var parsed = gwParseSystemConfigValues_(values);
  if (!parsed.ok) {
    throw new Error(parsed.message);
  }

  GW_CONFIG_CACHE_ = parsed.map;
  return GW_CONFIG_CACHE_;
}

function gwParseSystemConfigValues_(values) {
  var keyCandidates = [
    'CONFIG_KEY', 'configKey', 'config_key', 'key', 'KEY', 'settingKey', 'setting_key', 'settingName',
    'configName', 'name', 'code', 'property', 'param', 'parameter', 'envKey', 'systemKey', 'field', 'item',
    '항목', '키', '설정키', '설정명', '설정항목', '이름', '코드', '구분', '변수'
  ];
  var valueCandidates = [
    'VALUE', 'configValue', 'config_value', 'value', 'settingValue', 'setting_value', 'spreadsheetId',
    'spreadsheet_id', 'spreadsheetUrl', 'url', 'id', 'dbId', 'db_id', 'targetId', 'documentId',
    'fileId', 'folderId', '값', '설정값', '아이디', 'ID', '문서ID', '파일ID', '폴더ID', '스프레드시트ID', '연결값'
  ];
  var descCandidates = ['DESCRIPTION', 'description', 'memo', 'label', 'note', 'desc', '설명', '메모', '비고', '라벨'];

  var headerInfo = gwFindSystemConfigHeaderRow_(values, keyCandidates, valueCandidates, descCandidates);
  if (headerInfo) {
    return gwBuildConfigMapFromHeader_(values, headerInfo);
  }

  var fallback = gwBuildConfigMapFromLooseRows_(values);
  if (Object.keys(fallback).length > 0) {
    return { ok: true, map: fallback, mode: 'LOOSE_ROWS' };
  }

  return {
    ok: false,
    message: 'SystemConfig에서 key/value 헤더를 찾을 수 없습니다. 실제 기준 예시: CONFIG_KEY/VALUE. 허용 예시: configKey/configValue, key/value, settingKey/settingValue, configName/spreadsheetId, 항목/값, 설정키/설정값. 헤더가 1행이 아니어도 20행까지 자동 탐색합니다.'
  };
}

function gwFindSystemConfigHeaderRow_(values, keyCandidates, valueCandidates, descCandidates) {
  var maxRows = Math.min(values.length, 20);
  for (var r = 0; r < maxRows; r++) {
    var headers = values[r].map(function (h) { return gwToSafeText_(h); });
    var keyIndex = gwFindFirstHeaderIndex_(headers, keyCandidates);
    var valueIndex = gwFindFirstHeaderIndex_(headers, valueCandidates);
    var descIndex = gwFindFirstHeaderIndex_(headers, descCandidates || []);
    if (keyIndex >= 0 && valueIndex >= 0 && keyIndex !== valueIndex) {
      return { headerRowIndex: r, keyIndex: keyIndex, valueIndex: valueIndex, descIndex: descIndex, headers: headers };
    }
  }
  return null;
}

function gwBuildConfigMapFromHeader_(values, headerInfo) {
  var map = {};
  for (var r = headerInfo.headerRowIndex + 1; r < values.length; r++) {
    var row = values[r] || [];
    var key = gwToSafeText_(row[headerInfo.keyIndex]);
    if (!key) continue;
    map[key] = {
      value: gwToSafeText_(row[headerInfo.valueIndex]),
      description: headerInfo.descIndex >= 0 ? gwToSafeText_(row[headerInfo.descIndex]) : '',
      row: row,
      rowNumber: r + 1
    };
  }
  return {
    ok: true,
    map: map,
    mode: 'HEADER_ROW',
    headerRowNumber: headerInfo.headerRowIndex + 1,
    keyHeader: headerInfo.headers[headerInfo.keyIndex],
    valueHeader: headerInfo.headers[headerInfo.valueIndex]
  };
}

function gwBuildConfigMapFromLooseRows_(values) {
  var map = {};
  for (var r = 0; r < values.length; r++) {
    var row = values[r] || [];
    var nonEmpty = [];
    for (var c = 0; c < row.length; c++) {
      var text = gwToSafeText_(row[c]);
      if (text) nonEmpty.push({ index: c, value: text });
    }
    if (nonEmpty.length < 2) continue;
    var key = nonEmpty[0].value;
    var value = nonEmpty[1].value;
    if (!gwLooksLikeConfigKey_(key)) continue;
    map[key] = {
      value: value,
      description: nonEmpty.length >= 3 ? nonEmpty[2].value : '',
      row: row,
      rowNumber: r + 1
    };
  }
  return map;
}

function gwLooksLikeConfigKey_(key) {
  key = gwToSafeText_(key);
  if (!key) return false;
  if (key.indexOf(' ') >= 0 && key.length > 40) return false;
  if (/^(FEELHAUS_|MASTER_|SOURCE_|CONFIG_|PORTAL_|SIGN_|ERP_|FORM_|CONTROL_|GROUPWARE_|GW_|FEATURE_|DB_)/i.test(key)) return true;
  if (/(_ID|_URL|_NAME|_KEY|_ENABLED)$/i.test(key)) return true;
  return /^[A-Za-z0-9_\.\-]{2,80}$/.test(key);
}

function gwFindFirstHeaderIndex_(headers, candidates) {
  var normalized = headers.map(function (h) { return gwNormalizeHeaderName_(h); });
  for (var i = 0; i < candidates.length; i++) {
    var target = gwNormalizeHeaderName_(candidates[i]);
    var idx = normalized.indexOf(target);
    if (idx >= 0) return idx;
  }
  return -1;
}

function gwNormalizeHeaderName_(value) {
  return String(value || '')
    .trim()
    .replace(/[\s_\-\.()[\]{}<>:：\/\\]/g, '')
    .toLowerCase();
}

function gwGetConfigValue_(keys, defaultValue) {
  var map = gwGetSystemConfigMap_();
  if (!Array.isArray(keys)) keys = [keys];
  for (var i = 0; i < keys.length; i++) {
    var key = keys[i];
    if (map[key] && map[key].value !== '') return map[key].value;
  }

  var normalizedMap = {};
  Object.keys(map).forEach(function (key) {
    normalizedMap[gwNormalizeConfigKey_(key)] = map[key].value;
  });
  for (var j = 0; j < keys.length; j++) {
    var normalizedKey = gwNormalizeConfigKey_(keys[j]);
    if (Object.prototype.hasOwnProperty.call(normalizedMap, normalizedKey) && normalizedMap[normalizedKey] !== '') {
      return normalizedMap[normalizedKey];
    }
  }

  return defaultValue;
}

function gwNormalizeConfigKey_(value) {
  return String(value || '').trim().replace(/[\s_\-\.]/g, '').toLowerCase();
}

function gwGetMasterDbId_() {
  if (GW_MASTER_DB_ID_CACHE_) return GW_MASTER_DB_ID_CACHE_;
  var id = gwGetConfigValue_([
    'DB_MASTER_ID',
    'FEELHAUS_DB_MASTER_ID',
    'FEELHAUS_DB_MASTER',
    'FEELHAUS_DB_MASTER_SPREADSHEET_ID',
    'FEELHAUS_DB_MASTER_URL',
    'MASTER_DB_ID',
    'MASTER_DB',
    'MASTER_DB_URL',
    'MASTER_ID',
    'MASTER_SPREADSHEET_ID',
    'DB_MASTER',
    'FEELHAUS_MASTER_DB_ID'
  ], '');
  id = gwExtractSpreadsheetId_(id);
  if (!id) {
    throw new Error('SystemConfig에서 FEELHAUS_DB_MASTER ID를 찾을 수 없습니다. 실제 기준 키: DB_MASTER_ID. 허용 키: FEELHAUS_DB_MASTER_ID, FEELHAUS_DB_MASTER, MASTER_DB_ID, MASTER_SPREADSHEET_ID 등');
  }
  GW_MASTER_DB_ID_CACHE_ = id;
  return id;
}

function gwGetMasterSpreadsheet_() {
  return gwOpenSpreadsheetById_(gwGetMasterDbId_(), GW_MASTER_DB_NAME);
}

function gwGetConfigSnapshotSafe_() {
  try {
    var map = gwGetSystemConfigMap_();
    return {
      ok: true,
      setupDbId: GW_SETUP_DB_ID,
      configSheetName: GW_CONFIG_SHEET_NAME,
      masterDbIdFound: !!gwGetMasterDbId_(),
      masterDbId: gwGetMasterDbId_(),
      configKeyCount: Object.keys(map).length,
      configKeyPreview: Object.keys(map).sort().slice(0, 20),
      note: '전체 configKeys는 gwInternalTest_B01_SystemConfigInspect()에서 별도 확인'
    };
  } catch (err) {
    return { ok: false, message: gwErrorMessage_(err) };
  }
}

function gwInspectSystemConfig_B01() {
  var ss = gwGetSetupSpreadsheet_();
  var sheet = ss.getSheetByName(GW_CONFIG_SHEET_NAME);
  if (!sheet) return gwFail_('SYSTEM_CONFIG_MISSING', GW_CONFIG_SHEET_NAME + ' 시트를 찾을 수 없습니다.');
  var values = sheet.getDataRange().getDisplayValues();
  var preview = values.slice(0, Math.min(values.length, 10)).map(function (row, index) {
    return { rowNumber: index + 1, values: row.slice(0, 10) };
  });
  var parsed = gwParseSystemConfigValues_(values);
  return gwOk_({
    sheetName: GW_CONFIG_SHEET_NAME,
    rowCount: values.length,
    colCount: values[0] ? values[0].length : 0,
    parsedOk: parsed.ok,
    parsedMode: parsed.mode || '',
    detectedHeaderRow: parsed.headerRowNumber || '',
    detectedKeyHeader: parsed.keyHeader || '',
    detectedValueHeader: parsed.valueHeader || '',
    masterDbIdPreview: parsed.ok && parsed.map.DB_MASTER_ID ? parsed.map.DB_MASTER_ID.value : '',
    configKeyCount: parsed.ok ? Object.keys(parsed.map).length : 0,
    configKeyPreview: parsed.ok ? Object.keys(parsed.map).sort().slice(0, 30) : [],
    preview: preview,
    message: parsed.ok ? 'SystemConfig 구조 인식 성공' : parsed.message
  }, 'SystemConfig 구조 점검 완료');
}
