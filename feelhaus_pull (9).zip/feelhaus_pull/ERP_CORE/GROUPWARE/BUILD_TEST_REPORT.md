# BUILD TEST REPORT

Build: [10/10] GROUPWARE_B10_PORTAL_BODY_IMPORT_CANDIDATE_JS_ONLY

Local package checks:
- JS syntax check: PASS
- `.gs` file absence: PASS
- Required file presence: PASS
- ZIP build: PASS

Apps Script required tests:
- `gwInternalTest_B10_Smoke_NoWrite()`
- `gwInternalTest_B10_Regression_NoWrite()`
- `gwInternalTest_B10_All()`
