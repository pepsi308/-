/**
 * PR01 PORTAL Registry Integration Review Service.
 * This package does not write to PORTAL_MenuRegistry, RouteRegistry, or PermissionRegistry.
 * It only exports candidates, validates contracts, checks handlers, and produces review gates.
 */
const GW_PR01_MODULE_CODE = 'GROUPWARE';
const GW_PR01_FORBIDDEN_TERMS = Object.freeze(['iframe', 'preview', 'fragment', 'standalone', 'devshell', 'GW_DevShell']);
const GW_PR01_STATUS_VALUES = Object.freeze(['READY', 'PREPARING', 'DISABLED', 'NO_PERMISSION', 'ERROR']);
const GW_PR01_REQUIRED_REGISTRIES = Object.freeze(['PORTAL_MenuRegistry', 'RouteRegistry', 'PermissionRegistry']);

const GW_PR01_CANONICAL_MENU_CANDIDATES = Object.freeze([
  { moduleCode: 'GROUPWARE', menuId: 'gw.users', menuLabel: '직원관리', route: '/groupware/users', handler: 'gwHandleUsersBody', viewFile: 'GW_UsersPermissionBodyService.js', permissionCode: 'canAccessDevConsole', status: 'READY', sortOrder: 1110, sourceBuild: 'B12' },
  { moduleCode: 'GROUPWARE', menuId: 'gw.permissions', menuLabel: '권한관리', route: '/groupware/permissions', handler: 'gwHandlePermissionsBody', viewFile: 'GW_UsersPermissionBodyService.js', permissionCode: 'canAccessDevConsole', status: 'READY', sortOrder: 1120, sourceBuild: 'B12' },
  { moduleCode: 'GROUPWARE', menuId: 'gw.notices', menuLabel: '공지 / 게시판', route: '/groupware/notices', handler: 'gwHandleNoticeBoardBody', viewFile: 'GW_NoticeBoardBodyService.js', permissionCode: 'canAccessPortal', status: 'READY', sortOrder: 1130, sourceBuild: 'B13' },
  { moduleCode: 'GROUPWARE', menuId: 'gw.library', menuLabel: '사내 자료실', route: '/groupware/library', handler: 'gwHandleDocLibraryBody', viewFile: 'GW_DocLibraryBodyService.js', permissionCode: 'canDownloadFiles', status: 'READY', sortOrder: 1140, sourceBuild: 'B14' },
  { moduleCode: 'GROUPWARE', menuId: 'gw.requests', menuLabel: '전자결재 / 업무요청', route: '/groupware/requests', handler: 'gwHandleRequestsBody', viewFile: 'GW_RequestApprovalBodyService.js', permissionCode: 'canApprove', status: 'READY', sortOrder: 1150, sourceBuild: 'B15' },
  { moduleCode: 'GROUPWARE', menuId: 'gw.attendance.caps', menuLabel: 'CAPS 근태 연동', route: '/groupware/attendance/caps', handler: 'gwHandleCapsAttendanceBody', viewFile: 'GW_AttendanceBodyService.js', permissionCode: 'canAccessPortal', status: 'READY', sortOrder: 1160, sourceBuild: 'B16' },
  { moduleCode: 'GROUPWARE', menuId: 'gw.attendance.mine', menuLabel: '내 근태', route: '/groupware/attendance/mine', handler: 'gwHandleMyAttendanceBody', viewFile: 'GW_AttendanceBodyService.js', permissionCode: 'canAccessPortal', status: 'READY', sortOrder: 1170, sourceBuild: 'B16' },
  { moduleCode: 'GROUPWARE', menuId: 'gw.attendance.admin', menuLabel: '근태 현황', route: '/groupware/attendance/admin', handler: 'gwHandleAttendanceAdminBody', viewFile: 'GW_AttendanceBodyService.js', permissionCode: 'canViewLogs', status: 'READY', sortOrder: 1180, sourceBuild: 'B16' },
  { moduleCode: 'GROUPWARE', menuId: 'gw.attendance.exceptions', menuLabel: '근태 예외처리', route: '/groupware/attendance/exceptions', handler: 'gwHandleAttendanceExceptionsBody', viewFile: 'GW_AttendanceBodyService.js', permissionCode: 'canApprove', status: 'READY', sortOrder: 1185, sourceBuild: 'B16' },
  { moduleCode: 'GROUPWARE', menuId: 'gw.kpi', menuLabel: '직원 KPI / 성과관리', route: '/groupware/kpi', handler: 'gwHandleKpiBody', viewFile: 'GW_ManagementModulesBodyService.js', permissionCode: 'canAccessPortal', status: 'READY', sortOrder: 1190, sourceBuild: 'B17' },
  { moduleCode: 'GROUPWARE', menuId: 'gw.assets', menuLabel: '총무 / 자산 / 비품', route: '/groupware/assets', handler: 'gwHandleAssetSupplyBody', viewFile: 'GW_ManagementModulesBodyService.js', permissionCode: 'canAccessPortal', status: 'READY', sortOrder: 1200, sourceBuild: 'B17' },
  { moduleCode: 'GROUPWARE', menuId: 'gw.supplyRequests', menuLabel: '비품 요청 / 승인', route: '/groupware/supply-requests', handler: 'gwHandleSupplyRequestBody', viewFile: 'GW_ManagementModulesBodyService.js', permissionCode: 'canApprove', status: 'READY', sortOrder: 1205, sourceBuild: 'B17' },
  { moduleCode: 'GROUPWARE', menuId: 'gw.expenses', menuLabel: '구매 / 지출 / 비용', route: '/groupware/expenses', handler: 'gwHandleExpenseBody', viewFile: 'GW_ManagementModulesBodyService.js', permissionCode: 'canApprove', status: 'READY', sortOrder: 1210, sourceBuild: 'B17' },
  { moduleCode: 'GROUPWARE', menuId: 'gw.diagnostics', menuLabel: '진단 / 설정', route: '/groupware/diagnostics', handler: 'gwHandleAdminDiagnosticsBody', viewFile: 'GW_AdminDiagnosticBodyService.js', permissionCode: 'canAccessDevConsole', status: 'READY', sortOrder: 1220, sourceBuild: 'B18' },
  { moduleCode: 'GROUPWARE', menuId: 'gw.auditLogs', menuLabel: '감사로그', route: '/groupware/audit-logs', handler: 'gwHandleAuditLogBody', viewFile: 'GW_AdminDiagnosticBodyService.js', permissionCode: 'canViewLogs', status: 'READY', sortOrder: 1221, sourceBuild: 'B18' },
  { moduleCode: 'GROUPWARE', menuId: 'gw.featureFlags', menuLabel: '기능 상태 / FeatureFlag', route: '/groupware/feature-flags', handler: 'gwHandleFeatureFlagBody', viewFile: 'GW_AdminDiagnosticBodyService.js', permissionCode: 'canAccessDevConsole', status: 'READY', sortOrder: 1222, sourceBuild: 'B18' },
  { moduleCode: 'GROUPWARE', menuId: 'gw.limitGuard', menuLabel: '셀 한도 보호', route: '/groupware/limit-guard', handler: 'gwHandleLimitGuardBody', viewFile: 'GW_AdminDiagnosticBodyService.js', permissionCode: 'canAccessDevConsole', status: 'READY', sortOrder: 1223, sourceBuild: 'B18' },
  { moduleCode: 'GROUPWARE', menuId: 'gw.stabilityGuard', menuLabel: '운영 안정화 점검', route: '/groupware/stability-guard', handler: 'gwHandleStabilityGuardBody', viewFile: 'GW_StabilityHardeningService.js', permissionCode: 'canAccessDevConsole', status: 'READY', sortOrder: 1230, sourceBuild: 'B19' },
  { moduleCode: 'GROUPWARE', menuId: 'gw.permissionGuard', menuLabel: '권한 차단 점검', route: '/groupware/permission-guard', handler: 'gwHandlePermissionGuardBody', viewFile: 'GW_StabilityHardeningService.js', permissionCode: 'canAccessDevConsole', status: 'READY', sortOrder: 1231, sourceBuild: 'B19' },
  { moduleCode: 'GROUPWARE', menuId: 'gw.inputValidation', menuLabel: '입력값 검증', route: '/groupware/input-validation', handler: 'gwHandleInputValidationBody', viewFile: 'GW_StabilityHardeningService.js', permissionCode: 'canAccessDevConsole', status: 'READY', sortOrder: 1232, sourceBuild: 'B19' },
  { moduleCode: 'GROUPWARE', menuId: 'gw.statusGuard', menuLabel: '상태값 보호', route: '/groupware/status-guard', handler: 'gwHandleStatusGuardBody', viewFile: 'GW_StabilityHardeningService.js', permissionCode: 'canAccessDevConsole', status: 'READY', sortOrder: 1233, sourceBuild: 'B19' },
  { moduleCode: 'GROUPWARE', menuId: 'gw.releaseCandidate', menuLabel: 'GROUPWARE 릴리즈 후보 점검', route: '/groupware/release-candidate', handler: 'gwHandleReleaseCandidateBody', viewFile: 'GW_ReleaseCandidateService.js', permissionCode: 'canAccessDevConsole', status: 'READY', sortOrder: 1240, sourceBuild: 'B20' }
]);

function gwGetPortalRegistryCandidates_PR01() {
  var menuRows = GW_PR01_CANONICAL_MENU_CANDIDATES.map(function (row) {
    return Object.assign({ registry: 'PORTAL_MenuRegistry', importAction: 'REVIEW_THEN_REGISTER' }, row);
  });
  var routeRows = menuRows.map(function (row) {
    return {
      registry: 'RouteRegistry',
      moduleCode: row.moduleCode,
      route: row.route,
      handler: row.handler,
      viewFile: row.viewFile,
      permissionCode: row.permissionCode,
      status: row.status,
      menuId: row.menuId,
      importAction: 'REVIEW_THEN_REGISTER'
    };
  });
  var permissionSeen = {};
  var permissionRows = [];
  menuRows.forEach(function (row) {
    if (!permissionSeen[row.permissionCode]) {
      permissionSeen[row.permissionCode] = true;
      permissionRows.push({
        registry: 'PermissionRegistry',
        permissionCode: row.permissionCode,
        moduleCode: row.moduleCode,
        permissionLabel: gwPermissionLabel_PR01_(row.permissionCode),
        source: 'PortalUsers',
        importAction: 'REVIEW_THEN_REGISTER'
      });
    }
  });
  return {
    ok: true,
    moduleCode: GW_PR01_MODULE_CODE,
    menuRegistryRows: menuRows,
    routeRegistryRows: routeRows,
    permissionRegistryRows: permissionRows,
    counts: {
      menuRegistry: menuRows.length,
      routeRegistry: routeRows.length,
      permissionRegistry: permissionRows.length
    },
    blockedWrites: ['No direct write to PORTAL_MenuRegistry', 'No direct write to RouteRegistry', 'No direct write to PermissionRegistry'],
    mainDeveloperReviewRequired: true
  };
}

function gwPermissionLabel_PR01_(permissionCode) {
  var map = {
    canAccessPortal: 'PORTAL 접근',
    canAccessDevConsole: '개발/진단 접근',
    canDownloadFiles: '파일 다운로드',
    canApprove: '승인 처리',
    canViewLogs: '로그 조회'
  };
  return map[permissionCode] || permissionCode;
}

function gwValidatePortalMenuRegistryCandidates_PR01(payload) {
  var candidates = gwGetPortalRegistryCandidates_PR01();
  var errors = [];
  var warnings = [];
  var seenMenu = {};
  var seenRoute = {};
  var seenSort = {};
  var required = ['moduleCode', 'menuId', 'menuLabel', 'route', 'handler', 'viewFile', 'permissionCode', 'status', 'sortOrder'];
  candidates.menuRegistryRows.forEach(function (row, idx) {
    required.forEach(function (field) {
      if (row[field] === undefined || row[field] === null || row[field] === '') errors.push('menu candidate 필수값 누락 row=' + idx + ' field=' + field);
    });
    if (row.moduleCode !== GW_PR01_MODULE_CODE) errors.push('moduleCode 불일치 menuId=' + row.menuId);
    if (seenMenu[row.menuId]) errors.push('menuId 중복: ' + row.menuId);
    seenMenu[row.menuId] = true;
    if (seenRoute[row.route]) errors.push('route 중복: ' + row.route);
    seenRoute[row.route] = true;
    if (seenSort[row.sortOrder]) warnings.push('sortOrder 중복 검토 필요: ' + row.sortOrder);
    seenSort[row.sortOrder] = true;
    if (String(row.route).indexOf('/groupware/') !== 0) errors.push('route prefix 불일치: ' + row.route);
    if (GW_PR01_STATUS_VALUES.indexOf(row.status) < 0) errors.push('허용되지 않은 status: ' + row.status);
    var joined = [row.menuId, row.menuLabel, row.route, row.handler, row.viewFile].join(' ').toLowerCase();
    GW_PR01_FORBIDDEN_TERMS.forEach(function (term) {
      if (joined.indexOf(term.toLowerCase()) >= 0) errors.push('금지 용어 포함 menuId=' + row.menuId + ' term=' + term);
    });
  });
  return gwOk_({
    ok: errors.length === 0,
    menuCandidateCount: candidates.menuRegistryRows.length,
    errors: errors,
    warnings: warnings,
    portalShellOnly: true,
    moduleOwnMenuForbidden: true
  }, errors.length ? 'PORTAL_MENU_REGISTRY_CANDIDATE_HAS_ERRORS' : 'PORTAL_MENU_REGISTRY_CANDIDATE_OK');
}

function gwValidatePortalRouteRegistryCandidates_PR01(payload) {
  var candidates = gwGetPortalRegistryCandidates_PR01();
  var errors = [];
  var handlerMissing = [];
  candidates.routeRegistryRows.forEach(function (row) {
    if (String(row.route).indexOf('/groupware/') !== 0) errors.push('route prefix 불일치: ' + row.route);
    if (!gwIsFunctionAvailable_PR01_(row.handler)) handlerMissing.push(row.handler);
  });
  return gwOk_({
    ok: errors.length === 0 && handlerMissing.length === 0,
    routeCandidateCount: candidates.routeRegistryRows.length,
    handlerMissingCount: handlerMissing.length,
    handlerMissing: handlerMissing,
    errors: errors,
    routeMode: 'PORTAL_BODY_ROUTE_ONLY',
    previewRouteForbidden: true,
    iframeForbidden: true,
    fragmentMenuForbidden: true
  }, errors.length || handlerMissing.length ? 'PORTAL_ROUTE_REGISTRY_CANDIDATE_HAS_ERRORS' : 'PORTAL_ROUTE_REGISTRY_CANDIDATE_OK');
}

function gwValidatePortalPermissionRegistryCandidates_PR01(payload) {
  var candidates = gwGetPortalRegistryCandidates_PR01();
  var errors = [];
  var userHeaderCheck = { ok: true, missingFieldGroups: [] };
  try {
    if (typeof gwCheckPortalUsersHeaders_ === 'function') userHeaderCheck = gwCheckPortalUsersHeaders_();
  } catch (err) {
    errors.push('PortalUsers 헤더 확인 실패: ' + gwErrorMessage_(err));
  }
  var permissionCodes = candidates.permissionRegistryRows.map(function (r) { return r.permissionCode; });
  if (permissionCodes.length < 1) errors.push('permission candidate 없음');
  return gwOk_({
    ok: errors.length === 0,
    permissionCandidateCount: candidates.permissionRegistryRows.length,
    permissionCodes: permissionCodes,
    portalUsersHeaderOk: userHeaderCheck.ok === true,
    portalUsersMissingFieldGroups: userHeaderCheck.missingFieldGroups || [],
    errors: errors,
    source: 'PortalUsers'
  }, errors.length ? 'PORTAL_PERMISSION_REGISTRY_CANDIDATE_HAS_ERRORS' : 'PORTAL_PERMISSION_REGISTRY_CANDIDATE_OK');
}

function gwIsFunctionAvailable_PR01_(functionName) {
  try {
    return typeof eval(functionName) === 'function';
  } catch (err) {
    return false;
  }
}

function gwGetPortalRegistryIntegrationReviewSnapshot_PR01(payload) {
  payload = payload || {};
  var candidates = gwGetPortalRegistryCandidates_PR01();
  var menu = gwValidatePortalMenuRegistryCandidates_PR01(payload).data;
  var route = gwValidatePortalRouteRegistryCandidates_PR01(payload).data;
  var permission = gwValidatePortalPermissionRegistryCandidates_PR01(payload).data;
  var limit = { riskLevel: 'UNKNOWN', usagePercent: null, newSheetGuard: 'BLOCK_NEW_SHEET' };
  try {
    if (typeof gwGetCellLimitSnapshotForUi === 'function') {
      var limitRes = gwGetCellLimitSnapshotForUi({ limit: 3 });
      limit = limitRes.data || limit;
    }
  } catch (err) {
    limit = { riskLevel: 'UNKNOWN', usagePercent: null, newSheetGuard: 'BLOCK_NEW_SHEET', message: gwErrorMessage_(err) };
  }
  return {
    ok: menu.ok && route.ok && permission.ok,
    menuCandidateCount: candidates.counts.menuRegistry,
    routeCandidateCount: candidates.counts.routeRegistry,
    permissionCandidateCount: candidates.counts.permissionRegistry,
    menuOk: menu.ok,
    routeOk: route.ok,
    permissionOk: permission.ok,
    handlerMissingCount: route.handlerMissingCount || 0,
    portalShellOnly: true,
    directPortalWrite: false,
    registryReviewOnly: true,
    mainDeveloperReviewRequired: true,
    finalGate: 'READY_FOR_PORTAL_REGISTRY_REVIEW_NOT_AUTO_MERGE',
    cellRiskLevel: limit.riskLevel || 'UNKNOWN',
    cellUsagePercent: limit.usagePercent,
    newSheetGuard: limit.newSheetGuard || 'BLOCK_NEW_SHEET',
    blockedActions: [
      'Do not create module-owned menu',
      'Do not create standalone shell',
      'Do not use iframe/preview/fragment',
      'Do not write registries automatically',
      'Do not create new sheets while cell risk is CRITICAL'
    ]
  };
}

function gwRunPortalRegistryIntegrationReview_PR01(payload) {
  payload = payload || {};
  var checks = [];
  var fatalCount = 0;
  function addCheck(name, fn) {
    try {
      var data = fn();
      var ok = data && (data.ok !== false);
      if (!ok) fatalCount++;
      checks.push({ name: name, ok: ok, message: ok ? 'OK' : 'CHECK_FAILED', data: data });
    } catch (err) {
      fatalCount++;
      checks.push({ name: name, ok: false, message: gwErrorMessage_(err), stack: gwErrorStack_(err) });
    }
  }

  addCheck('BUILD_INFO', function () { return gwGetBuildInfo(); });
  addCheck('MASTER_DB_CONNECT', function () { var ss = gwGetMasterSpreadsheet_(); return { ok: true, spreadsheetName: ss.getName(), spreadsheetId: ss.getId() }; });
  addCheck('CURRENT_USER_CONTEXT', function () { return gwGetUserContextSafe_(); });
  addCheck('PR01_PERMISSION_ASSERT', function () { var ctx = gwGetUserContextSafe_(); return { ok: !!ctx.employeeId && ctx.employeeId !== 'UNKNOWN', employeeId: ctx.employeeId, roleCode: ctx.roleCode }; });
  addCheck('PR01_CANDIDATE_EXPORT', function () { return gwGetPortalRegistryCandidates_PR01(); });
  addCheck('PR01_MENU_REGISTRY_VALIDATE', function () { return gwValidatePortalMenuRegistryCandidates_PR01(payload).data; });
  addCheck('PR01_ROUTE_REGISTRY_VALIDATE', function () { return gwValidatePortalRouteRegistryCandidates_PR01(payload).data; });
  addCheck('PR01_PERMISSION_REGISTRY_VALIDATE', function () { return gwValidatePortalPermissionRegistryCandidates_PR01(payload).data; });
  addCheck('PR01_REVIEW_SNAPSHOT', function () { return gwGetPortalRegistryIntegrationReviewSnapshot_PR01(payload); });
  addCheck('PR01_NO_DIRECT_PORTAL_WRITE', function () { return { ok: true, modifiesPortalRegistry: false, registryReviewOnly: true, requiredRegistries: GW_PR01_REQUIRED_REGISTRIES.slice() }; });

  if (payload.writeAudit) {
    addCheck('PR01_AUDIT_LOG', function () {
      return gwWriteAuditLog_({
        moduleCode: 'GROUPWARE',
        actionType: 'PR01_PORTAL_REGISTRY_INTEGRATION_REVIEW',
        targetId: 'PORTAL_REGISTRY_REVIEW',
        employeeId: (gwGetUserContextSafe_().employeeId || 'UNKNOWN'),
        resultStatus: fatalCount === 0 ? 'SUCCESS' : 'FAILED',
        detailMessage: 'PORTAL registry integration review only. No registry writes.'
      });
    });
  }

  return {
    ok: fatalCount === 0,
    build: GW_BUILD_INFO.build,
    generatedAt: gwNow_(),
    code: fatalCount === 0 ? '' : 'PR01_REGISTRY_REVIEW_FAILED',
    message: fatalCount === 0 ? 'PR01 PORTAL 원장 통합 검토 통과' : 'PR01 PORTAL 원장 통합 검토 중 실패 항목이 있습니다.',
    buildInfo: gwGetBuildInfo(),
    fatalCount: fatalCount,
    checks: checks
  };
}

function gwCompactPortalRegistryReviewResult_PR01(result) {
  result = result || {};
  return {
    ok: result.ok === true,
    build: result.build || GW_BUILD_INFO.build,
    generatedAt: gwNow_(),
    code: result.code || '',
    message: result.message || '',
    fatalCount: result.fatalCount || 0,
    checkCount: (result.checks || []).length,
    summary: gwGetPortalRegistryIntegrationReviewSnapshot_PR01({})
  };
}
