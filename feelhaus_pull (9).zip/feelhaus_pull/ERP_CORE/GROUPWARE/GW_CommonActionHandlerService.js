
/**
 * B21 common action handler hardening service.
 * PORTAL is the only Shell. This file does not create menus, routes, iframes, fragments, previews, or sheets.
 * It standardizes button/action -> handler -> service -> message -> audit flow for existing GROUPWARE bodies.
 */
const GW_B21_MODULE_CODE = 'GROUPWARE';
const GW_B21_FORBIDDEN_VISIBLE_TOKENS = Object.freeze(['<iframe', 'data-module-menu', 'gw-own-menu', 'gw-side-menu', 'gw-top-menu', 'preview', 'fragment']);
const GW_B21_RESPONSE_STATUSES = Object.freeze(['SUCCESS', 'FAILED', 'NO_PERMISSION', 'VALIDATION_FAILED', 'CONFLICT', 'LIMIT_BLOCKED']);

function gwGetB21BodySpecs() {
  return [
    {
      moduleCode: GW_B21_MODULE_CODE,
      menuId: 'gw.actionGuard',
      route: '/groupware/action-guard',
      handler: 'gwHandleActionGuardBody',
      viewFile: 'GW_ActionGuardBody.html',
      screenId: 'GW_ActionGuardBody',
      title: '공통 액션 핸들러 점검',
      description: '본문 버튼과 google.script.run action, 서버 handler, 성공/실패 메시지, AuditLog 흐름을 표준화하는 PORTAL 본문 전용 화면입니다.',
      permissionCode: 'canAccessDevConsole',
      buttons: [
        { id: 'btnValidateActionRegistry', label: '액션 연결 점검', call: 'validateCommonActionRegistry', style: 'primary' },
        { id: 'btnRunActionGuardDiagnostics', label: '공통 응답 점검', call: 'runB21Diagnostics', style: 'secondary' }
      ],
      calls: ['validateCommonActionRegistry', 'runB21Diagnostics'],
      sheets: ['Portal_AuditLog'],
      logSheet: 'Portal_AuditLog',
      screenStructure: ['화면 제목', '화면 설명', '주요 작업 버튼', '검색 / 필터', '목록 / 입력폼 / 상세', '성공 / 실패 안내문']
    }
  ];
}

function gwGetCommonActionRegistry_B21() {
  return [
    // Users / permissions
    { action: 'listUsers', handler: 'gwListPortalUsersForUi', permissionCode: 'canAccessPortal', write: false, successMessage: '직원 목록을 조회했습니다.', failMessage: '직원 목록 조회에 실패했습니다.' },
    { action: 'getUserDetail', handler: 'gwGetPortalUserDetailForUi', permissionCode: 'canAccessPortal', write: false, successMessage: '직원 상세를 조회했습니다.', failMessage: '직원 상세 조회에 실패했습니다.' },
    { action: 'saveUser', handler: 'gwSavePortalUserForUi', permissionCode: 'canAccessDevConsole', write: true, successMessage: '직원 정보를 저장했습니다.', failMessage: '직원 정보 저장에 실패했습니다.' },
    { action: 'saveUserPermissions', handler: 'gwSavePortalUserPermissionsForUi', permissionCode: 'canAccessDevConsole', write: true, successMessage: '권한 정보를 저장했습니다.', failMessage: '권한 정보 저장에 실패했습니다.', optional: true },

    // Notices
    { action: 'listNotices', handler: 'gwListNoticesForUi', permissionCode: 'canAccessPortal', write: false, successMessage: '공지 목록을 조회했습니다.', failMessage: '공지 목록 조회에 실패했습니다.' },
    { action: 'getNoticeDetail', handler: 'gwGetNoticeDetailForUi', permissionCode: 'canAccessPortal', write: false, successMessage: '공지 상세를 조회했습니다.', failMessage: '공지 상세 조회에 실패했습니다.' },
    { action: 'saveNotice', handler: 'gwSaveNoticeForUi', permissionCode: 'canAccessDevConsole', write: true, successMessage: '공지를 저장했습니다.', failMessage: '공지 저장에 실패했습니다.' },

    // Library
    { action: 'listLibraryFiles', handler: 'gwListLibraryFilesForUi', permissionCode: 'canAccessPortal', write: false, successMessage: '자료 목록을 조회했습니다.', failMessage: '자료 목록 조회에 실패했습니다.' },
    { action: 'getLibraryFileDetail', handler: 'gwGetLibraryFileDetailForUi', permissionCode: 'canAccessPortal', write: false, successMessage: '자료 상세를 조회했습니다.', failMessage: '자료 상세 조회에 실패했습니다.' },
    { action: 'saveLibraryFile', handler: 'gwSaveLibraryFileForUi', permissionCode: 'canAccessDevConsole', write: true, successMessage: '자료 정보를 저장했습니다.', failMessage: '자료 저장에 실패했습니다.' },
    { action: 'logLibraryDownload', handler: 'gwLogLibraryDownloadForUi', permissionCode: 'canDownloadFiles', write: true, successMessage: '다운로드 로그를 기록했습니다.', failMessage: '다운로드 로그 기록에 실패했습니다.' },

    // Requests / approval
    { action: 'listRequests', handler: 'gwListRequestsForUi', permissionCode: 'canAccessPortal', write: false, successMessage: '요청 목록을 조회했습니다.', failMessage: '요청 목록 조회에 실패했습니다.' },
    { action: 'getRequestDetail', handler: 'gwGetRequestDetailForUi', permissionCode: 'canAccessPortal', write: false, successMessage: '요청 상세를 조회했습니다.', failMessage: '요청 상세 조회에 실패했습니다.' },
    { action: 'saveRequest', handler: 'gwSaveRequestForUi', permissionCode: 'canAccessPortal', write: true, successMessage: '업무요청을 저장했습니다.', failMessage: '업무요청 저장에 실패했습니다.' },
    { action: 'approveRequest', handler: 'gwApproveRequestForUi', permissionCode: 'canApprove', write: true, successMessage: '요청을 승인했습니다.', failMessage: '요청 승인에 실패했습니다.' },
    { action: 'rejectRequest', handler: 'gwRejectRequestForUi', permissionCode: 'canApprove', write: true, successMessage: '요청을 반려했습니다.', failMessage: '요청 반려에 실패했습니다.' },

    // Attendance
    { action: 'syncCapsMock', handler: 'gwSyncCapsMockForUi', permissionCode: 'canAccessDevConsole', write: true, successMessage: 'CAPS Mock 동기화를 완료했습니다.', failMessage: 'CAPS Mock 동기화에 실패했습니다.' },
    { action: 'listAttendance', handler: 'gwListAttendanceForUi', permissionCode: 'canAccessPortal', write: false, successMessage: '근태 목록을 조회했습니다.', failMessage: '근태 목록 조회에 실패했습니다.' },
    { action: 'listAttendanceExceptions', handler: 'gwListAttendanceExceptionsForUi', permissionCode: 'canViewLogs', write: false, successMessage: '근태 예외 목록을 조회했습니다.', failMessage: '근태 예외 조회에 실패했습니다.' },
    { action: 'listCapsRaw', handler: 'gwListCapsRawForUi', permissionCode: 'canViewLogs', write: false, successMessage: 'CAPS Raw 목록을 조회했습니다.', failMessage: 'CAPS Raw 조회에 실패했습니다.' },

    // KPI
    { action: 'listKpis', handler: 'gwListKpisForUi', permissionCode: 'canAccessPortal', write: false, successMessage: 'KPI 목록을 조회했습니다.', failMessage: 'KPI 목록 조회에 실패했습니다.' },
    { action: 'saveKpi', handler: 'gwSaveKpiForUi', permissionCode: 'canAccessDevConsole', write: true, successMessage: 'KPI를 저장했습니다.', failMessage: 'KPI 저장에 실패했습니다.' },
    { action: 'evaluateKpi', handler: 'gwEvaluateKpiForUi', permissionCode: 'canApprove', write: true, successMessage: 'KPI 평가를 저장했습니다.', failMessage: 'KPI 평가 저장에 실패했습니다.' },

    // Asset / supply / expense
    { action: 'saveAsset', handler: 'gwSaveAssetForUi', permissionCode: 'canAccessDevConsole', write: true, successMessage: '자산 정보를 저장했습니다.', failMessage: '자산 저장에 실패했습니다.' },
    { action: 'saveSupply', handler: 'gwSaveSupplyForUi', permissionCode: 'canAccessDevConsole', write: true, successMessage: '비품 정보를 저장했습니다.', failMessage: '비품 저장에 실패했습니다.' },
    { action: 'saveSupplyRequest', handler: 'gwSaveSupplyRequestForUi', permissionCode: 'canAccessPortal', write: true, successMessage: '비품 요청을 저장했습니다.', failMessage: '비품 요청 저장에 실패했습니다.' },
    { action: 'approveSupplyRequest', handler: 'gwApproveSupplyRequestForUi', permissionCode: 'canApprove', write: true, successMessage: '비품 요청을 승인했습니다.', failMessage: '비품 요청 승인에 실패했습니다.' },
    { action: 'saveExpense', handler: 'gwSaveExpenseForUi', permissionCode: 'canAccessPortal', write: true, successMessage: '비용요청을 저장했습니다.', failMessage: '비용요청 저장에 실패했습니다.' },
    { action: 'approveExpense', handler: 'gwApproveExpenseForUi', permissionCode: 'canApprove', write: true, successMessage: '비용요청을 승인했습니다.', failMessage: '비용요청 승인에 실패했습니다.' },

    // Admin / release / guard
    { action: 'getAdminDiagnosticSnapshot', handler: 'gwGetAdminDiagnosticSnapshotForUi', permissionCode: 'canAccessDevConsole', write: false, successMessage: '진단 스냅샷을 조회했습니다.', failMessage: '진단 스냅샷 조회에 실패했습니다.' },
    { action: 'listAuditLogs', handler: 'gwListAuditLogsForUi', permissionCode: 'canViewLogs', write: false, successMessage: '감사로그를 조회했습니다.', failMessage: '감사로그 조회에 실패했습니다.' },
    { action: 'validateStabilityGuards', handler: 'gwValidateStabilityGuards', permissionCode: 'canAccessDevConsole', write: false, successMessage: '안정화 보호 기준을 점검했습니다.', failMessage: '안정화 보호 점검에 실패했습니다.' },
    { action: 'validateB20ReleaseCandidate', handler: 'gwValidateB20ReleaseCandidate', permissionCode: 'canAccessDevConsole', write: false, successMessage: '릴리즈 후보 기준을 점검했습니다.', failMessage: '릴리즈 후보 점검에 실패했습니다.' }
  ];
}

function gwHandleActionGuardBody(payload) {
  payload = payload || {};
  var spec = gwGetB21BodySpecs()[0];
  gwAssertPermission_(spec.permissionCode || 'canAccessDevConsole');
  var validation = gwValidateCommonActionRegistry({ noWrite: true });
  if (!validation.ok) return validation;
  var model = gwBuildB21ActionGuardBodyModel_(spec, validation.data, payload);
  return gwOk_(model, '공통 액션 핸들러 점검 본문 구성 완료');
}

function gwBuildB21ActionGuardBodyModel_(spec, data, payload) {
  var rows = data.registry.map(function (item) {
    return {
      action: item.action,
      handler: item.handler,
      permissionCode: item.permissionCode,
      write: item.write ? 'Y' : 'N',
      status: item.handlerExists ? 'READY' : (item.optional ? 'OPTIONAL' : 'MISSING'),
      message: item.handlerExists ? item.successMessage : item.failMessage
    };
  });
  var model = {
    moduleCode: GW_B21_MODULE_CODE,
    screenId: spec.screenId,
    menuId: spec.menuId,
    route: spec.route,
    handler: spec.handler,
    title: spec.title,
    description: spec.description,
    permissionCode: spec.permissionCode,
    actions: spec.buttons,
    filters: [
      { id: 'gwB21Query', label: '검색', field: 'query', value: gwToSafeText_(payload.query || ''), placeholder: 'action 또는 handler 검색' }
    ],
    list: {
      title: '공통 액션 연결 목록',
      totalReturned: rows.length,
      columns: ['action', 'handler', 'permissionCode', 'write', 'status', 'message'],
      rows: rows
    },
    form: {
      title: '공통 응답 표준',
      fields: [
        { field: 'totalActionCount', label: '액션 수', value: data.actionCount, inputType: 'readonly' },
        { field: 'handlerMissingCount', label: 'handler 누락', value: data.handlerMissingCount, inputType: 'readonly' },
        { field: 'writeActionCount', label: '쓰기 액션 수', value: data.writeActionCount, inputType: 'readonly' },
        { field: 'newSheetGuard', label: '신규 시트 보호', value: data.newSheetGuard, inputType: 'readonly' }
      ]
    },
    messages: [
      { type: 'info', text: '모든 본문 버튼은 data-gw-action → gwApi(action,payload) → service → 표준 결과로 연결되어야 합니다.' },
      { type: data.handlerMissingCount === 0 ? 'success' : 'error', text: data.handlerMissingCount === 0 ? '필수 handler 누락이 없습니다.' : '필수 handler 누락이 있습니다.' },
      { type: 'error', text: '셀 한도 CRITICAL 상태에서는 신규 시트 생성 액션을 허용하지 않습니다.' }
    ],
    apiCalls: spec.calls,
    standardResponse: gwBuildStandardActionResult_B21('DRY_RUN', true, 'SUCCESS', '공통 응답 표준 샘플입니다.', { dryRun: true }),
    logSheet: 'Portal_AuditLog'
  };
  model.bodyHtml = gwRenderB21ActionGuardBodyHtml_(model);
  model.bodyAudit = gwValidateB21BodyModel_(model);
  return model;
}

function gwRenderB21ActionGuardBodyHtml_(model) {
  var rowsHtml = model.list.rows.map(function (row) {
    return '<tr><td>' + gwEscHtml_(row.action) + '</td><td>' + gwEscHtml_(row.handler) + '</td><td>' + gwEscHtml_(row.permissionCode) + '</td><td>' + gwEscHtml_(row.write) + '</td><td>' + gwEscHtml_(row.status) + '</td><td>' + gwEscHtml_(row.message) + '</td></tr>';
  }).join('') || '<tr><td colspan="6">표시할 액션이 없습니다.</td></tr>';
  var fieldsHtml = model.form.fields.map(function (field) {
    return '<label>' + gwEscHtml_(field.label) + '<input type="text" data-field="' + gwEscHtml_(field.field) + '" value="' + gwEscHtml_(String(field.value)) + '" readonly /></label>';
  }).join('');
  return '<section class="gw-body gw-action-guard-body" data-screen-id="' + gwEscHtml_(model.screenId) + '">' +
    '<h2>' + gwEscHtml_(model.title) + '</h2>' +
    '<p>' + gwEscHtml_(model.description) + '</p>' +
    '<div class="gw-actions">' + gwRenderB21ActionButtons_(model.actions) + '</div>' +
    '<div class="gw-filter"><label>검색 / 필터<input type="text" data-field="query" value="' + gwEscHtml_(model.filters[0].value) + '" /></label></div>' +
    '<div class="gw-message-zone"><p data-message-type="info">공통 액션 연결과 표준 응답을 점검합니다.</p></div>' +
    '<div class="gw-layout-two"><div class="gw-list"><h3>목록</h3><table><thead><tr><th>Action</th><th>Handler</th><th>권한</th><th>쓰기</th><th>상태</th><th>메시지</th></tr></thead><tbody>' + rowsHtml + '</tbody></table></div>' +
    '<div class="gw-detail"><h3>입력폼 / 상세</h3>' + fieldsHtml + '</div></div>' +
  '</section>';
}

function gwRenderB21ActionButtons_(actions) {
  return actions.map(function (action) {
    return '<button type="button" data-gw-action="' + gwEscHtml_(action.call) + '" data-button-id="' + gwEscHtml_(action.id) + '">' + gwEscHtml_(action.label) + '</button>';
  }).join('');
}

function gwValidateB21BodyModel_(model) {
  var errors = [];
  var html = gwToSafeText_(model.bodyHtml);
  if (html.indexOf('<h2>') < 0) errors.push('화면 제목 누락: ' + model.screenId);
  if (html.indexOf('<p>') < 0) errors.push('화면 설명 누락: ' + model.screenId);
  if (html.indexOf('data-gw-action') < 0) errors.push('주요 작업 버튼 연결 누락: ' + model.screenId);
  if (html.indexOf('gw-filter') < 0) errors.push('검색 / 필터 영역 누락: ' + model.screenId);
  if (html.indexOf('gw-list') < 0 || html.indexOf('gw-detail') < 0) errors.push('목록 / 입력폼 / 상세 영역 누락: ' + model.screenId);
  if (html.indexOf('gw-message-zone') < 0) errors.push('성공 / 실패 안내문 영역 누락: ' + model.screenId);
  GW_B21_FORBIDDEN_VISIBLE_TOKENS.forEach(function (token) {
    if (html.toLowerCase().indexOf(token.toLowerCase()) >= 0) errors.push('금지 UI 토큰 포함: ' + token);
  });
  return { ok: errors.length === 0, errors: errors, htmlLength: html.length };
}

function gwValidateB21BodyContracts(payload) {
  var errors = [];
  var specs = gwGetB21BodySpecs();
  specs.forEach(function (spec) {
    if (spec.moduleCode !== 'GROUPWARE') errors.push('moduleCode 오류: ' + spec.screenId);
    if (!spec.menuId || spec.menuId.indexOf('gw.') !== 0) errors.push('menuId 오류: ' + spec.screenId);
    if (!spec.route || spec.route.indexOf('/groupware/') !== 0) errors.push('route 오류: ' + spec.screenId);
    if (!spec.handler || typeof this[spec.handler] === 'undefined') errors.push('handler 미정의: ' + spec.handler);
    if (!spec.viewFile || spec.viewFile.indexOf('.html') < 0) errors.push('viewFile 오류: ' + spec.screenId);
    if (!spec.permissionCode) errors.push('permissionCode 누락: ' + spec.screenId);
    if (!spec.calls || spec.calls.length < 2) errors.push('호출 함수 부족: ' + spec.screenId);
  }, this);
  return {
    ok: errors.length === 0,
    build: GW_BUILD_INFO.build,
    generatedAt: gwNow_(),
    code: errors.length === 0 ? '' : 'B21_BODY_CONTRACT_FAILED',
    message: errors.length === 0 ? 'B21_BODY_CONTRACT_OK' : 'B21_BODY_CONTRACT_FAILED',
    fatalCount: errors.length,
    data: {
      ok: errors.length === 0,
      errors: errors,
      specCount: specs.length,
      portalShellOnly: true
    }
  };
}

function gwValidateCommonActionRegistry(payload) {
  payload = payload || {};
  var registry = gwGetCommonActionRegistry_B21();
  var seen = {};
  var errors = [];
  var writeCount = 0;
  var normalized = registry.map(function (item) {
    var copy = Object.assign({}, item);
    copy.handlerExists = typeof this[copy.handler] === 'function';
    copy.optional = copy.optional === true;
    if (seen[copy.action]) errors.push('중복 action: ' + copy.action);
    seen[copy.action] = true;
    if (!copy.action) errors.push('action 누락');
    if (!copy.handler) errors.push('handler 누락: ' + copy.action);
    if (!copy.handlerExists && !copy.optional) errors.push('필수 handler 미정의: ' + copy.action + ' -> ' + copy.handler);
    if (!copy.permissionCode) errors.push('permissionCode 누락: ' + copy.action);
    if (!copy.successMessage || !copy.failMessage) errors.push('성공/실패 메시지 누락: ' + copy.action);
    if (copy.write) writeCount++;
    return copy;
  }, this);
  var missing = normalized.filter(function (item) { return !item.handlerExists && !item.optional; });
  var guard = gwGetB21CellLimitGuardSnapshot_();
  if (guard.cellRiskLevel === 'CRITICAL' && guard.newSheetGuard !== 'BLOCK_NEW_SHEET') {
    errors.push('CRITICAL 셀 한도에서 신규 시트 차단 미적용');
  }
  var responseSample = gwBuildStandardActionResult_B21('VALIDATE_COMMON_ACTION_REGISTRY', errors.length === 0, errors.length === 0 ? 'SUCCESS' : 'FAILED', errors.length === 0 ? '공통 액션 레지스트리 검증 통과' : '공통 액션 레지스트리 검증 실패', { errorCount: errors.length });
  return gwOk_({
    ok: errors.length === 0,
    errors: errors,
    registry: normalized,
    actionCount: normalized.length,
    writeActionCount: writeCount,
    readActionCount: normalized.length - writeCount,
    handlerMissingCount: missing.length,
    optionalMissingCount: normalized.filter(function (item) { return !item.handlerExists && item.optional; }).length,
    permissionCodeCount: gwCountUniqueB21_(normalized.map(function (item) { return item.permissionCode; })),
    cellRiskLevel: guard.cellRiskLevel,
    cellUsagePercent: guard.cellUsagePercent,
    newSheetGuard: guard.newSheetGuard,
    standardResponseSample: responseSample,
    directPortalWrite: false,
    registryReviewOnly: false
  }, errors.length === 0 ? 'B21_COMMON_ACTION_REGISTRY_OK' : 'B21_COMMON_ACTION_REGISTRY_FAILED');
}

function gwBuildStandardActionResult_B21(action, ok, status, message, data) {
  if (GW_B21_RESPONSE_STATUSES.indexOf(status) < 0) status = ok ? 'SUCCESS' : 'FAILED';
  return {
    ok: ok === true,
    action: action,
    status: status,
    message: message || (ok ? '처리되었습니다.' : '처리하지 못했습니다.'),
    data: data || {},
    messageType: ok ? 'success' : (status === 'NO_PERMISSION' || status === 'VALIDATION_FAILED' ? 'warning' : 'error'),
    generatedAt: gwNow_(),
    auditRequired: status === 'SUCCESS' || status === 'FAILED' || status === 'NO_PERMISSION'
  };
}

function gwGetB21CellLimitGuardSnapshot_() {
  try {
    if (typeof gwBuildB19GuardSnapshotForUi === 'function') {
      var guard = gwBuildB19GuardSnapshotForUi({ limit: 3, fastMode: true });
      if (guard && guard.ok && guard.data && guard.data.stability) {
        return {
          cellRiskLevel: guard.data.stability.cellRiskLevel || 'UNKNOWN',
          cellUsagePercent: guard.data.stability.cellUsagePercent || 0,
          newSheetGuard: guard.data.stability.newSheetGuard || 'BLOCK_NEW_SHEET'
        };
      }
    }
  } catch (err) {}
  return { cellRiskLevel: 'CRITICAL', cellUsagePercent: 99.79, newSheetGuard: 'BLOCK_NEW_SHEET' };
}

function gwCountUniqueB21_(values) {
  var map = {};
  values.forEach(function (v) { if (v) map[v] = true; });
  return Object.keys(map).length;
}

function gwRunB21Diagnostics(payload) {
  payload = payload || {};
  var checks = [];
  checks.push(gwDiagCheck_('BUILD_INFO', function () { return gwGetBuildInfo(); }));
  checks.push(gwDiagCheck_('MASTER_DB_CONNECT', function () {
    var ss = gwGetMasterSpreadsheet_();
    return { spreadsheetName: ss.getName(), spreadsheetId: ss.getId() };
  }));
  checks.push(gwDiagCheck_('CURRENT_USER_CONTEXT', function () { return gwGetUserContextSafe_(); }));
  checks.push(gwDiagCheck_('B21_PERMISSION_ASSERT', function () {
    var ctx = gwAssertPermission_('canAccessDevConsole');
    return { ok: true, employeeId: ctx.employeeId, roleCode: ctx.roleCode };
  }));
  checks.push(gwDiagCheck_('B21_BODY_SPECS', function () {
    var specs = gwGetB21BodySpecs();
    return { ok: true, buildStep: '21/60', bodySpecCount: specs.length, screenIds: specs.map(function (s) { return s.screenId; }), routeCount: specs.length, portalShellOnly: true };
  }));
  checks.push(gwDiagCheck_('B21_BODY_CONTRACT_VALIDATE', function () { return gwValidateB21BodyContracts({}).data; }));
  checks.push(gwDiagCheck_('B21_COMMON_ACTION_REGISTRY', function () { return gwValidateCommonActionRegistry({ noWrite: true }).data; }));
  checks.push(gwDiagCheck_('B21_ACTION_GUARD_BODY_RENDER', function () {
    var result = gwHandleActionGuardBody({ limit: payload.limit || 3 });
    if (!result.ok) throw new Error(result.message || 'Action guard body render failed');
    var model = result.data;
    return {
      ok: true,
      screenId: model.screenId,
      title: model.title,
      actionCount: model.list.totalReturned,
      apiCallCount: model.apiCalls.length,
      htmlLength: model.bodyHtml.length,
      bodyAudit: model.bodyAudit
    };
  }));
  checks.push(gwDiagCheck_('B21_STANDARD_RESPONSE_MODEL', function () {
    var okSample = gwBuildStandardActionResult_B21('SAMPLE_OK', true, 'SUCCESS', '성공 샘플', { sample: true });
    var failSample = gwBuildStandardActionResult_B21('SAMPLE_FAIL', false, 'VALIDATION_FAILED', '실패 샘플', { sample: true });
    return { ok: true, okStatus: okSample.status, okMessageType: okSample.messageType, failStatus: failSample.status, failMessageType: failSample.messageType };
  }));
  checks.push(gwDiagCheck_('B21_API_HANDLER_MAP', function () {
    return {
      ok: true,
      actionGuardHandlerOk: typeof gwHandleActionGuardBody === 'function',
      validateRegistryOk: typeof gwValidateCommonActionRegistry === 'function',
      diagnosticsOk: typeof gwRunB21Diagnostics === 'function',
      message: '공통 액션 핸들러 본문 구성 완료'
    };
  }));
  if (payload.writeAudit) {
    checks.push(gwDiagCheck_('B21_AUDIT_LOG', function () {
      return gwWriteAuditLog_({ moduleCode: 'GROUPWARE', actionType: 'B21_COMMON_ACTION_HANDLER_DIAGNOSTIC', targetId: 'B21', resultStatus: 'OK', detailMessage: 'B21 common action handler hardening diagnostics passed' });
    }));
  }
  var fatal = checks.filter(function (c) { return !c.ok; });
  return {
    ok: fatal.length === 0,
    build: GW_BUILD_INFO.build,
    generatedAt: gwNow_(),
    code: fatal.length === 0 ? '' : 'B21_DIAGNOSTIC_FAILED',
    message: fatal.length === 0 ? 'B21 공통 액션 핸들러 고도화 진단 통과' : 'B21 진단 중 실패 항목이 있습니다.',
    buildInfo: gwGetBuildInfo(),
    checkedAt: gwNow_(),
    fatalCount: fatal.length,
    checks: checks
  };
}
