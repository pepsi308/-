const GW_PORTAL_USERS_SHEET_CANDIDATES = Object.freeze(['PortalUsers', 'PORTAL_Users', 'Users', 'Employees']);
const GW_PORTAL_USERS_CANONICAL_NAME = 'PortalUsers';

const GW_PORTAL_USERS_STANDARD_HEADERS = Object.freeze([
  'userId', 'loginId', 'loginEmail', 'employeeId', 'employeeName', 'displayName',
  'mobile', 'department', 'team', 'position', 'roleCode', 'roleName',
  'vendorId', 'eventId', 'primaryEventId', 'allowedEventIds', 'allowedVendorIds',
  'isActive', 'status', 'statusReason',
  'canAccessPortal', 'canAccessMail', 'canSendMail', 'canAccessCalendar', 'canCreateCalendarEvent',
  'canAccessSign', 'canAccessErp', 'canAccessForm', 'canAccessControl', 'canAccessDevConsole',
  'canApprove', 'canViewLogs', 'canDownloadFiles', 'canViewSensitiveInfo',
  'lastLoginAt', 'createdAt', 'createdBy', 'updatedAt', 'updatedBy',
  'passwordResetRequiredYn', 'memo', 'recordMode', 'reviewStatus', 'batchTag', 'remarks'
]);

const GW_PORTAL_USER_FIELD_ALIASES = Object.freeze({
  userId: ['userId', 'portalUserId', 'id'],
  loginId: ['loginId', 'userLoginId'],
  employeeId: ['employeeId', 'staffId', 'empId'],
  employeeName: ['employeeName', 'displayName', 'userName', 'name'],
  displayName: ['displayName', 'employeeName', 'userName', 'name'],
  email: ['email', 'loginEmail', 'userEmail', 'mail', 'emailAddress'],
  loginEmail: ['loginEmail', 'email', 'userEmail', 'mail', 'emailAddress'],
  phone: ['phone', 'mobile', 'tel'],
  mobile: ['mobile', 'phone', 'tel'],
  department: ['department', 'dept'],
  team: ['team', 'department', 'dept'],
  position: ['position', 'jobTitle', 'title'],
  roleCode: ['roleCode', 'role', 'roleId'],
  roleName: ['roleName', 'roleLabel'],
  vendorId: ['vendorId', 'primaryVendorId'],
  eventId: ['eventId', 'primaryEventId'],
  primaryEventId: ['primaryEventId', 'eventId'],
  allowedEventIds: ['allowedEventIds'],
  allowedVendorIds: ['allowedVendorIds'],
  userType: ['userType', 'ownerType', 'dataScopeCode'],
  dataScopeCode: ['dataScopeCode', 'userType'],
  approvalLevel: ['approvalLevel'],
  isActive: ['isActive', 'canAccessPortal'],
  status: ['status', 'userStatus', 'isActive'],
  statusReason: ['statusReason', 'reason'],
  canAccessPortal: ['canAccessPortal', 'portalAccessYn', 'isActive'],
  canAccessMail: ['canAccessMail', 'mailAccessYn'],
  canSendMail: ['canSendMail', 'mailSendYn'],
  canAccessCalendar: ['canAccessCalendar', 'calendarAccessYn'],
  canCreateCalendarEvent: ['canCreateCalendarEvent', 'calendarCreateYn'],
  canAccessSign: ['canAccessSign', 'signAccessYn'],
  canAccessErp: ['canAccessErp', 'erpAccessYn'],
  canAccessForm: ['canAccessForm', 'formAccessYn'],
  canAccessControl: ['canAccessControl', 'controlAccessYn'],
  canAccessDevConsole: ['canAccessDevConsole', 'devConsoleAccessYn', 'unlockAccessYn'],
  canApprove: ['canApprove', 'approveYn'],
  canViewLogs: ['canViewLogs', 'logAccessYn'],
  canDownloadFiles: ['canDownloadFiles', 'downloadAccessYn'],
  canViewSensitiveInfo: ['canViewSensitiveInfo', 'sensitiveAccessYn'],
  sensitiveAccessYn: ['sensitiveAccessYn', 'canViewSensitiveInfo'],
  downloadAccessYn: ['downloadAccessYn', 'canDownloadFiles'],
  settlementEditYn: ['settlementEditYn'],
  cancelSettlementYn: ['cancelSettlementYn'],
  recoveryPaymentYn: ['recoveryPaymentYn'],
  additionalPaymentYn: ['additionalPaymentYn'],
  unlockAccessYn: ['unlockAccessYn', 'canAccessDevConsole'],
  reopenAccessYn: ['reopenAccessYn'],
  lastLoginAt: ['lastLoginAt'],
  createdAt: ['createdAt'],
  createdBy: ['createdBy'],
  updatedAt: ['updatedAt'],
  updatedBy: ['updatedBy'],
  memo: ['memo'],
  recordMode: ['recordMode'],
  reviewStatus: ['reviewStatus'],
  batchTag: ['batchTag'],
  remarks: ['remarks'],
  passwordResetRequiredYn: ['passwordResetRequiredYn']
});

const GW_PORTAL_USERS_REQUIRED_FIELD_GROUPS = Object.freeze([
  { field: 'userId', aliases: GW_PORTAL_USER_FIELD_ALIASES.userId },
  { field: 'employeeId', aliases: GW_PORTAL_USER_FIELD_ALIASES.employeeId },
  { field: 'employeeName', aliases: GW_PORTAL_USER_FIELD_ALIASES.employeeName },
  { field: 'email', aliases: GW_PORTAL_USER_FIELD_ALIASES.email },
  { field: 'roleCode', aliases: GW_PORTAL_USER_FIELD_ALIASES.roleCode },
  { field: 'status', aliases: GW_PORTAL_USER_FIELD_ALIASES.status }
]);

const GW_B02_WRITABLE_PROFILE_FIELDS = Object.freeze([
  'employeeName', 'displayName', 'loginEmail', 'mobile', 'department', 'team', 'position',
  'roleCode', 'roleName', 'vendorId', 'eventId', 'primaryEventId', 'allowedEventIds',
  'allowedVendorIds', 'dataScopeCode', 'approvalLevel', 'memo', 'remarks', 'statusReason'
]);

const GW_B02_DIRECT_YN_FIELDS = Object.freeze([
  'sensitiveAccessYn', 'downloadAccessYn', 'settlementEditYn', 'cancelSettlementYn',
  'recoveryPaymentYn', 'additionalPaymentYn', 'unlockAccessYn', 'reopenAccessYn',
  'passwordResetRequiredYn'
]);

const GW_B02_STANDARD_PERMISSION_FIELDS = Object.freeze([
  'canAccessMail', 'canSendMail', 'canAccessCalendar', 'canCreateCalendarEvent',
  'canAccessSign', 'canAccessErp', 'canAccessForm', 'canAccessControl',
  'canApprove', 'canViewLogs'
]);

function gwGetPortalUsersSheet_() {
  var ss = gwGetMasterSpreadsheet_();
  for (var i = 0; i < GW_PORTAL_USERS_SHEET_CANDIDATES.length; i++) {
    var sheet = ss.getSheetByName(GW_PORTAL_USERS_SHEET_CANDIDATES[i]);
    if (sheet) return sheet;
  }
  throw new Error('PORTAL 계정 원본 시트를 찾을 수 없습니다. 허용 시트명: ' + GW_PORTAL_USERS_SHEET_CANDIDATES.join(', '));
}

function gwCheckPortalUsersHeaders_() {
  var sheet = gwGetPortalUsersSheet_();
  var headers = gwGetHeaders_(sheet);
  var missingGroups = [];
  var resolved = {};
  GW_PORTAL_USERS_REQUIRED_FIELD_GROUPS.forEach(function (group) {
    var header = gwFindExistingHeaderByAliases_(headers, group.aliases);
    if (header) resolved[group.field] = header;
    else missingGroups.push({ field: group.field, acceptedAliases: group.aliases });
  });
  return {
    ok: missingGroups.length === 0,
    sheetName: sheet.getName(),
    expectedCanonicalSheetName: GW_PORTAL_USERS_CANONICAL_NAME,
    headers: headers,
    resolvedHeaders: resolved,
    missingFieldGroups: missingGroups,
    note: 'B02는 업로드 MASTER 기준 PortalUsers를 PORTAL 계정 원본으로 사용합니다. 저장 시 헤더명 기준으로만 반영합니다.'
  };
}

function gwFindExistingHeaderByAliases_(headers, aliases) {
  var normalizedHeaders = headers.map(function (h) { return { raw: h, normalized: gwNormalizeHeaderName_(h) }; });
  for (var i = 0; i < aliases.length; i++) {
    var target = gwNormalizeHeaderName_(aliases[i]);
    for (var j = 0; j < normalizedHeaders.length; j++) {
      if (normalizedHeaders[j].normalized === target) return normalizedHeaders[j].raw;
    }
  }
  return '';
}

function gwGetPortalUserField_(row, fieldName) {
  var aliases = GW_PORTAL_USER_FIELD_ALIASES[fieldName] || [fieldName];
  for (var i = 0; i < aliases.length; i++) {
    var alias = aliases[i];
    if (Object.prototype.hasOwnProperty.call(row, alias) && gwToSafeText_(row[alias]) !== '') return row[alias];
    var normalizedAlias = gwNormalizeHeaderName_(alias);
    for (var key in row) {
      if (!Object.prototype.hasOwnProperty.call(row, key)) continue;
      if (gwNormalizeHeaderName_(key) === normalizedAlias && gwToSafeText_(row[key]) !== '') return row[key];
    }
  }
  return '';
}

function gwNormalizePortalUserRow_(row) {
  row = row || {};
  var normalized = {};
  Object.keys(GW_PORTAL_USER_FIELD_ALIASES).forEach(function (field) {
    normalized[field] = gwGetPortalUserField_(row, field);
  });
  normalized.email = gwToSafeText_(normalized.email || normalized.loginEmail).toLowerCase();
  normalized.loginEmail = normalized.email;
  normalized.employeeId = gwToSafeText_(normalized.employeeId);
  normalized.employeeName = gwToSafeText_(normalized.employeeName) || normalized.email || '미확인 사용자';
  normalized.displayName = gwToSafeText_(normalized.displayName) || normalized.employeeName;
  normalized.roleCode = gwToSafeText_(normalized.roleCode).toUpperCase();
  normalized.status = gwNormalizeUserStatus_(normalized.status || normalized.isActive);
  normalized.vendorId = gwToSafeText_(normalized.vendorId);
  normalized.eventId = gwToSafeText_(normalized.eventId);
  normalized._rowNumber = row._rowNumber;
  normalized._sourceRow = row;
  normalized.permissions = gwResolvePortalUserPermissions_(normalized, row);
  return normalized;
}

function gwNormalizeUserStatus_(value) {
  if (value === true) return 'ACTIVE';
  if (value === false) return 'INACTIVE';
  var text = gwToSafeText_(value).toUpperCase();
  if (text === 'ACTIVE' || text === 'ENABLED' || text === '정상') return 'ACTIVE';
  if (text === 'INACTIVE' || text === 'DISABLED' || text === 'LOCKED' || text === '퇴사' || text === '중지') return 'INACTIVE';
  if (text === 'TRUE' || text === 'Y' || text === 'YES' || text === '1') return 'ACTIVE';
  if (text === 'FALSE' || text === 'N' || text === 'NO' || text === '0') return 'INACTIVE';
  return text || 'UNKNOWN';
}

function gwIsAdminRole_(roleCode) {
  roleCode = gwToSafeText_(roleCode).toUpperCase();
  return roleCode === 'SUPER_ADMIN' || roleCode === 'HQ_ADMIN' || roleCode === 'ADMIN' || roleCode === 'DEV' || roleCode === 'SYSTEM_ADMIN';
}

function gwResolvePortalUserPermissions_(normalized, rawRow) {
  var roleCode = gwToSafeText_(normalized.roleCode).toUpperCase();
  var isActive = normalized.status === 'ACTIVE';
  var isAdmin = gwIsAdminRole_(roleCode);
  var permissions = {};
  GW_PORTAL_USER_PERMISSION_HEADERS.forEach(function (key) {
    var rawValue = gwGetPortalUserField_(rawRow, key);
    if (gwToSafeText_(rawValue) !== '') permissions[key] = gwNormalizePermissionValue_(rawValue);
    else permissions[key] = false;
  });

  permissions.canAccessPortal = permissions.canAccessPortal || isActive;
  permissions.canDownloadFiles = permissions.canDownloadFiles || gwNormalizePermissionValue_(gwGetPortalUserField_(rawRow, 'downloadAccessYn'));
  permissions.canViewSensitiveInfo = permissions.canViewSensitiveInfo || gwNormalizePermissionValue_(gwGetPortalUserField_(rawRow, 'sensitiveAccessYn'));
  permissions.canAccessDevConsole = permissions.canAccessDevConsole || gwNormalizePermissionValue_(gwGetPortalUserField_(rawRow, 'unlockAccessYn'));
  permissions.canApprove = permissions.canApprove || Number(gwGetPortalUserField_(rawRow, 'approvalLevel') || 0) > 0;

  if (isAdmin) {
    GW_PORTAL_USER_PERMISSION_HEADERS.forEach(function (key) { permissions[key] = true; });
  }
  if (roleCode === 'HQ_STAFF' || roleCode === 'STAFF') {
    permissions.canAccessPortal = isActive;
    permissions.canAccessMail = true;
    permissions.canAccessCalendar = true;
    permissions.canDownloadFiles = true;
  }
  return permissions;
}

function gwNormalizePermissionValue_(value) {
  if (value === true) return true;
  if (value === false) return false;
  var text = gwToSafeText_(value).toUpperCase();
  if (!text) return false;
  if (text === 'Y' || text === 'YES' || text === 'TRUE' || text === '1' || text === 'ALLOW' || text === 'ALLOWED') return true;
  var numeric = Number(text);
  if (!isNaN(numeric) && numeric > 0) return true;
  return false;
}

function gwFindPortalUserByEmail_(email) {
  email = gwToSafeText_(email).toLowerCase();
  if (!email) return null;
  var sheet = gwGetPortalUsersSheet_();
  var rows = gwReadRowsAsObjects_(sheet);
  for (var i = 0; i < rows.length; i++) {
    var normalized = gwNormalizePortalUserRow_(rows[i]);
    if (normalized.email === email) return normalized;
  }
  return null;
}

function gwFindPortalUserByIdOrEmployee_(identifier) {
  identifier = gwToSafeText_(identifier);
  if (!identifier) return null;
  var sheet = gwGetPortalUsersSheet_();
  var rows = gwReadRowsAsObjects_(sheet);
  for (var i = 0; i < rows.length; i++) {
    var user = gwNormalizePortalUserRow_(rows[i]);
    if (gwToSafeText_(user.userId) === identifier || gwToSafeText_(user.employeeId) === identifier) return user;
  }
  return null;
}

function gwListPortalUsersForUi(payload) {
  payload = payload || {};
  gwAssertPermission_('canAccessPortal');
  var sheet = gwGetPortalUsersSheet_();
  var headerCheck = gwCheckPortalUsersHeaders_();
  if (!headerCheck.ok) return gwFail_('MISSING_PORTAL_USER_FIELDS', 'PortalUsers 필수 필드 그룹이 누락되었습니다.', headerCheck);

  var query = gwToSafeText_(payload.query).toLowerCase();
  var limit = Math.min(Number(payload.limit || 100), 500);
  var rows = gwReadRowsAsObjects_(sheet).map(function (row) { return gwNormalizePortalUserRow_(row); });
  if (query) {
    rows = rows.filter(function (u) {
      return [u.employeeId, u.employeeName, u.email, u.department, u.team, u.roleCode, u.vendorId, u.eventId].join(' ').toLowerCase().indexOf(query) >= 0;
    });
  }
  rows = rows.slice(0, limit).map(function (user) { return gwPortalUserToUiRow_(user); });
  return gwOk_({ rows: rows, headerCheck: gwCompactPortalUserHeaderCheck_(headerCheck), totalReturned: rows.length }, 'PortalUsers 조회 완료');
}

function gwPortalUserToUiRow_(user) {
  return {
    userId: gwToSafeText_(user.userId),
    employeeId: gwToSafeText_(user.employeeId),
    employeeName: gwToSafeText_(user.employeeName),
    displayName: gwToSafeText_(user.displayName),
    email: gwToSafeText_(user.email),
    loginEmail: gwToSafeText_(user.loginEmail || user.email),
    mobile: gwToSafeText_(user.mobile || user.phone),
    department: gwToSafeText_(user.department),
    team: gwToSafeText_(user.team),
    position: gwToSafeText_(user.position),
    roleCode: gwToSafeText_(user.roleCode),
    roleName: gwToSafeText_(user.roleName),
    vendorId: gwToSafeText_(user.vendorId),
    eventId: gwToSafeText_(user.eventId),
    primaryEventId: gwToSafeText_(user.primaryEventId || user.eventId),
    allowedEventIds: gwToSafeText_(user.allowedEventIds),
    allowedVendorIds: gwToSafeText_(user.allowedVendorIds),
    dataScopeCode: gwToSafeText_(user.dataScopeCode || user.userType),
    approvalLevel: gwToSafeText_(user.approvalLevel),
    status: gwToSafeText_(user.status),
    statusReason: gwToSafeText_(user.statusReason),
    canAccessPortal: user.permissions.canAccessPortal ? 'Y' : 'N',
    canAccessMail: user.permissions.canAccessMail ? 'Y' : 'N',
    canSendMail: user.permissions.canSendMail ? 'Y' : 'N',
    canAccessCalendar: user.permissions.canAccessCalendar ? 'Y' : 'N',
    canCreateCalendarEvent: user.permissions.canCreateCalendarEvent ? 'Y' : 'N',
    canAccessSign: user.permissions.canAccessSign ? 'Y' : 'N',
    canAccessErp: user.permissions.canAccessErp ? 'Y' : 'N',
    canAccessForm: user.permissions.canAccessForm ? 'Y' : 'N',
    canAccessControl: user.permissions.canAccessControl ? 'Y' : 'N',
    canAccessDevConsole: user.permissions.canAccessDevConsole ? 'Y' : 'N',
    canApprove: user.permissions.canApprove ? 'Y' : 'N',
    canViewLogs: user.permissions.canViewLogs ? 'Y' : 'N',
    canDownloadFiles: user.permissions.canDownloadFiles ? 'Y' : 'N',
    canViewSensitiveInfo: user.permissions.canViewSensitiveInfo ? 'Y' : 'N',
    sensitiveAccessYn: gwGetPortalUserField_(user._sourceRow || {}, 'sensitiveAccessYn'),
    downloadAccessYn: gwGetPortalUserField_(user._sourceRow || {}, 'downloadAccessYn'),
    unlockAccessYn: gwGetPortalUserField_(user._sourceRow || {}, 'unlockAccessYn'),
    reopenAccessYn: gwGetPortalUserField_(user._sourceRow || {}, 'reopenAccessYn'),
    memo: gwToSafeText_(user.memo),
    remarks: gwToSafeText_(user.remarks),
    updatedAt: gwToSafeText_(user.updatedAt),
    _rowNumber: user._rowNumber
  };
}

function gwGetPortalUserDetailForUi(payload) {
  payload = payload || {};
  gwAssertPermission_('canAccessPortal');
  var identifier = payload.userId || payload.employeeId;
  var user = gwFindPortalUserByIdOrEmployee_(identifier);
  if (!user) return gwFail_('USER_NOT_FOUND', '직원을 찾을 수 없습니다.', { identifier: identifier });
  return gwOk_({ user: gwPortalUserToUiRow_(user) }, '직원 상세 조회 완료');
}

function gwGetB02UserPermissionMeta_() {
  return {
    roleCodes: ['HQ_ADMIN', 'HQ_STAFF', 'STAFF', 'VENDOR_ADMIN', 'VENDOR_STAFF', 'PARTNER', 'VIEWER'],
    statuses: ['ACTIVE', 'INACTIVE'],
    permissionFields: GW_PORTAL_USER_PERMISSION_HEADERS.slice(),
    ynFields: GW_B02_DIRECT_YN_FIELDS.slice(),
    buildStep: '02/10'
  };
}

function gwSavePortalUserForUi(payload) {
  payload = payload || {};
  var context = gwAssertPermission_('canAccessDevConsole');
  var result = gwSavePortalUser_(payload, context, { mode: 'UI' });
  return gwOk_(result, result.action === 'CREATE' ? '직원 추가 완료' : '직원 수정 완료');
}

function gwSetPortalUserStatusForUi(payload) {
  payload = payload || {};
  var context = gwAssertPermission_('canAccessDevConsole');
  var identifier = payload.userId || payload.employeeId;
  var user = gwFindPortalUserByIdOrEmployee_(identifier);
  if (!user) return gwFail_('USER_NOT_FOUND', '상태 변경 대상 직원을 찾을 수 없습니다.', { identifier: identifier });
  var nextStatus = gwNormalizeUserStatus_(payload.status || 'INACTIVE');
  var savePayload = {
    userId: user.userId,
    employeeId: user.employeeId,
    loginEmail: user.email,
    employeeName: user.employeeName,
    roleCode: user.roleCode,
    status: nextStatus,
    statusReason: gwToSafeText_(payload.statusReason) || 'B02 상태 변경'
  };
  var result = gwSavePortalUser_(savePayload, context, { mode: 'STATUS' });
  return gwOk_(result, '직원 상태 변경 완료');
}

function gwSavePortalUser_(payload, context, options) {
  payload = gwSanitizePortalUserPayload_(payload || {});
  context = context || gwGetUserContextSafe_();
  options = options || {};
  var sheet = gwGetPortalUsersSheet_();
  var ensureResult = gwEnsurePortalUsersB02Headers_(sheet);
  var headers = gwGetHeaders_(sheet).filter(function (h) { return h; });
  var rows = gwReadRowsAsObjects_(sheet);

  var existing = gwFindExistingPortalUserForSave_(rows, payload);
  var action = existing ? 'UPDATE' : 'CREATE';
  var validation = gwValidatePortalUserPayload_(payload, rows, existing);
  if (!validation.ok) throw new Error(validation.message);

  var now = gwNow_();
  var employeeId = gwToSafeText_(payload.employeeId) || (existing ? existing.employeeId : gwGenerateEmployeeId_());
  var userId = gwToSafeText_(payload.userId) || (existing ? existing.userId : gwUuid_('USER'));
  var status = gwNormalizeUserStatus_(payload.status || payload.isActive || (existing ? existing.status : 'ACTIVE'));
  if (status === 'UNKNOWN') status = 'ACTIVE';
  var rowObj = existing ? Object.assign({}, existing._sourceRow) : {};

  gwPutByAlias_(rowObj, headers, 'userId', userId, true);
  gwPutByAlias_(rowObj, headers, 'employeeId', employeeId, true);
  gwPutByAlias_(rowObj, headers, 'loginEmail', payload.loginEmail || payload.email, true);
  gwPutByAlias_(rowObj, headers, 'email', payload.loginEmail || payload.email, false);
  gwPutByExactIfExists_(rowObj, headers, 'loginId', payload.loginId || payload.loginEmail || payload.email);
  gwPutByAlias_(rowObj, headers, 'employeeName', payload.employeeName, true);
  gwPutByAlias_(rowObj, headers, 'displayName', payload.displayName || payload.employeeName, false);
  gwPutByAlias_(rowObj, headers, 'roleCode', payload.roleCode, true);
  gwPutByExactIfExists_(rowObj, headers, 'isActive', status === 'ACTIVE');
  gwPutByExactIfExists_(rowObj, headers, 'status', status);

  GW_B02_WRITABLE_PROFILE_FIELDS.forEach(function (field) {
    if (typeof payload[field] !== 'undefined') gwPutByAlias_(rowObj, headers, field, payload[field], false);
  });

  GW_B02_DIRECT_YN_FIELDS.forEach(function (field) {
    if (typeof payload[field] !== 'undefined') gwPutByAlias_(rowObj, headers, field, gwPayloadYn_(payload[field]), false);
  });
  GW_B02_STANDARD_PERMISSION_FIELDS.forEach(function (field) {
    if (typeof payload[field] !== 'undefined') gwPutByAlias_(rowObj, headers, field, gwPayloadYn_(payload[field]), true);
  });

  if (typeof payload.canAccessPortal !== 'undefined') {
    gwPutByAlias_(rowObj, headers, 'canAccessPortal', gwPayloadYn_(payload.canAccessPortal), false);
    gwPutByExactIfExists_(rowObj, headers, 'isActive', gwPayloadYn_(payload.canAccessPortal) === 'Y');
  }
  if (typeof payload.canAccessDevConsole !== 'undefined') {
    gwPutByAlias_(rowObj, headers, 'canAccessDevConsole', gwPayloadYn_(payload.canAccessDevConsole), true);
    gwPutByAlias_(rowObj, headers, 'unlockAccessYn', gwPayloadYn_(payload.canAccessDevConsole), false);
  }
  if (typeof payload.canDownloadFiles !== 'undefined') {
    gwPutByAlias_(rowObj, headers, 'canDownloadFiles', gwPayloadYn_(payload.canDownloadFiles), true);
    gwPutByAlias_(rowObj, headers, 'downloadAccessYn', gwPayloadYn_(payload.canDownloadFiles), false);
  }
  if (typeof payload.canViewSensitiveInfo !== 'undefined') {
    gwPutByAlias_(rowObj, headers, 'canViewSensitiveInfo', gwPayloadYn_(payload.canViewSensitiveInfo), true);
    gwPutByAlias_(rowObj, headers, 'sensitiveAccessYn', gwPayloadYn_(payload.canViewSensitiveInfo), false);
  }

  if (!existing) {
    gwPutByExactIfExists_(rowObj, headers, 'passwordResetRequiredYn', 'Y');
    gwPutByExactIfExists_(rowObj, headers, 'recordMode', payload.recordMode || 'NORMAL');
    gwPutByExactIfExists_(rowObj, headers, 'reviewStatus', payload.reviewStatus || 'READY');
    gwPutByExactIfExists_(rowObj, headers, 'createdAt', now);
    gwPutByExactIfExists_(rowObj, headers, 'createdBy', context.employeeId || 'SYSTEM');
  }
  gwPutByExactIfExists_(rowObj, headers, 'updatedAt', now);
  gwPutByExactIfExists_(rowObj, headers, 'updatedBy', context.employeeId || 'SYSTEM');

  var rowValues = headers.map(function (h) { return Object.prototype.hasOwnProperty.call(rowObj, h) ? rowObj[h] : ''; });
  var rowNumber;
  if (existing && existing._rowNumber) {
    rowNumber = existing._rowNumber;
    sheet.getRange(rowNumber, 1, 1, headers.length).setValues([rowValues]);
  } else {
    rowNumber = sheet.getLastRow() + 1;
    sheet.getRange(rowNumber, 1, 1, headers.length).setValues([rowValues]);
  }

  var normalizedSaved = gwNormalizePortalUserRow_(Object.assign({_rowNumber: rowNumber}, rowObj));
  gwAuditSafe_({
    moduleCode: 'GROUPWARE_USERS',
    actionType: action === 'CREATE' ? 'CREATE_USER_B02' : 'UPDATE_USER_B02',
    targetId: employeeId,
    employeeId: context.employeeId,
    resultStatus: 'SUCCESS',
    detailMessage: action + ' PortalUsers employeeId=' + employeeId + ', email=' + normalizedSaved.email + ', mode=' + (options.mode || '')
  });

  return {
    ok: true,
    action: action,
    sheetName: sheet.getName(),
    rowNumber: rowNumber,
    user: gwPortalUserToUiRow_(normalizedSaved),
    ensuredHeaders: ensureResult.addedHeaders || []
  };
}

function gwSanitizePortalUserPayload_(payload) {
  var sanitized = {};
  Object.keys(payload || {}).forEach(function (key) {
    if (key === 'password' || key === 'passwordHash' || key === 'passwordSalt') return;
    sanitized[key] = typeof payload[key] === 'string' ? payload[key].trim() : payload[key];
  });
  if (!sanitized.loginEmail && sanitized.email) sanitized.loginEmail = sanitized.email;
  sanitized.loginEmail = gwToSafeText_(sanitized.loginEmail).toLowerCase();
  sanitized.email = sanitized.loginEmail;
  sanitized.employeeName = gwToSafeText_(sanitized.employeeName || sanitized.displayName);
  sanitized.roleCode = gwToSafeText_(sanitized.roleCode || 'HQ_STAFF').toUpperCase();
  sanitized.status = gwNormalizeUserStatus_(sanitized.status || sanitized.isActive || 'ACTIVE');
  return sanitized;
}

function gwValidatePortalUserPayload_(payload, existingRows, existing) {
  if (!gwToSafeText_(payload.loginEmail)) return { ok: false, message: 'loginEmail은 필수입니다.' };
  if (!gwToSafeText_(payload.employeeName)) return { ok: false, message: 'employeeName은 필수입니다.' };
  if (!gwToSafeText_(payload.roleCode)) return { ok: false, message: 'roleCode는 필수입니다.' };
  if (payload.loginEmail.indexOf('@') < 0) return { ok: false, message: 'loginEmail 형식이 올바르지 않습니다.' };

  var targetEmail = gwToSafeText_(payload.loginEmail).toLowerCase();
  var targetEmployeeId = gwToSafeText_(payload.employeeId);
  for (var i = 0; i < existingRows.length; i++) {
    var u = gwNormalizePortalUserRow_(existingRows[i]);
    var sameExisting = existing && u._rowNumber === existing._rowNumber;
    if (!sameExisting && u.email === targetEmail) return { ok: false, message: '이미 사용 중인 loginEmail입니다: ' + targetEmail };
    if (targetEmployeeId && !sameExisting && u.employeeId === targetEmployeeId) return { ok: false, message: '이미 사용 중인 employeeId입니다: ' + targetEmployeeId };
  }
  return { ok: true };
}

function gwFindExistingPortalUserForSave_(rows, payload) {
  var targetUserId = gwToSafeText_(payload.userId);
  var targetEmployeeId = gwToSafeText_(payload.employeeId);
  var targetEmail = gwToSafeText_(payload.loginEmail || payload.email).toLowerCase();
  for (var i = 0; i < rows.length; i++) {
    var user = gwNormalizePortalUserRow_(rows[i]);
    if (targetUserId && gwToSafeText_(user.userId) === targetUserId) return user;
    if (targetEmployeeId && gwToSafeText_(user.employeeId) === targetEmployeeId) return user;
    if (targetEmail && user.email === targetEmail) return user;
  }
  return null;
}

function gwGenerateEmployeeId_() {
  var time = Utilities.formatDate(new Date(), 'Asia/Seoul', 'yyyyMMddHHmmss');
  var suffix = Utilities.getUuid().replace(/-/g, '').slice(0, 4).toUpperCase();
  return 'EMP-GW-' + time + '-' + suffix;
}

function gwEnsurePortalUsersB02Headers_(sheet) {
  var before = gwGetHeaders_(sheet).filter(function (h) { return h; });
  var required = ['userId', 'employeeId', 'employeeName', 'loginEmail', 'roleCode', 'status', 'isActive', 'createdAt', 'createdBy', 'updatedAt', 'updatedBy'];
  var add = [];
  required.concat(GW_B02_STANDARD_PERMISSION_FIELDS).forEach(function (field) {
    if (!gwFindExistingHeaderByAliases_(before.concat(add), GW_PORTAL_USER_FIELD_ALIASES[field] || [field])) add.push(field);
  });
  if (add.length) {
    sheet.getRange(1, before.length + 1, 1, add.length).setValues([add]);
  }
  return { ok: true, addedHeaders: add, beforeCount: before.length, afterCount: before.length + add.length };
}

function gwPutByAlias_(rowObj, headers, field, value, createIfMissing) {
  var h = gwFindExistingHeaderByAliases_(headers, GW_PORTAL_USER_FIELD_ALIASES[field] || [field]);
  if (!h && createIfMissing) h = field;
  if (!h) return false;
  rowObj[h] = value;
  return true;
}

function gwPutByExactIfExists_(rowObj, headers, field, value) {
  if (headers.indexOf(field) < 0) return false;
  rowObj[field] = value;
  return true;
}

function gwPayloadYn_(value) {
  if (value === true) return 'Y';
  if (value === false) return 'N';
  var text = gwToSafeText_(value).toUpperCase();
  if (!text) return 'N';
  return (text === 'Y' || text === 'YES' || text === 'TRUE' || text === '1' || text === 'ACTIVE') ? 'Y' : 'N';
}

function gwCompactPortalUserHeaderCheck_(headerCheck) {
  return {
    ok: headerCheck.ok,
    sheetName: headerCheck.sheetName,
    headerCount: headerCheck.headers ? headerCheck.headers.length : 0,
    resolvedHeaders: headerCheck.resolvedHeaders,
    missingFieldGroups: headerCheck.missingFieldGroups
  };
}
