/**
 * B12 PORTAL body-only UI service for Users / Permissions.
 * This file returns body-only screen models and bodyHtml strings for PORTAL handlers.
 * It must not render module navigation, its own top bar, its own side bar, iframe, or preview route.
 */
const GW_B12_MODULE_CODE = 'GROUPWARE';
const GW_B12_BODY_IDS = Object.freeze(['GW_UsersBody', 'GW_PermissionsBody']);
const GW_B12_FORBIDDEN_VISIBLE_TOKENS = Object.freeze(['<iframe', 'preview route', 'standalone shell', 'data-module-menu', 'gw-own-menu', 'gw-side-menu', 'gw-top-menu']);

const GW_B12_USER_FIELDS = Object.freeze([
  'employeeId', 'employeeName', 'loginEmail', 'mobile', 'department', 'team', 'position',
  'roleCode', 'roleName', 'vendorId', 'eventId', 'status', 'statusReason', 'memo'
]);

const GW_B12_PERMISSION_FIELDS = Object.freeze([
  'canAccessPortal', 'canAccessMail', 'canSendMail', 'canAccessCalendar', 'canCreateCalendarEvent',
  'canAccessSign', 'canAccessErp', 'canAccessForm', 'canAccessControl', 'canAccessDevConsole',
  'canApprove', 'canViewLogs', 'canDownloadFiles', 'canViewSensitiveInfo'
]);

function gwGetB12BodySpecs() {
  return [
    {
      moduleCode: GW_B12_MODULE_CODE,
      menuId: 'gw.users',
      route: '/groupware/users',
      handler: 'gwHandleUsersBody',
      viewFile: 'GW_UsersBody.html',
      screenId: 'GW_UsersBody',
      title: '직원관리',
      description: 'PortalUsers 기준 직원 목록, 상세, 추가, 수정, 상태 관리를 담당하는 PORTAL 본문 화면입니다.',
      permissionCode: 'canAccessDevConsole',
      buttons: [
        { id: 'btnReloadUsers', label: '조회', call: 'listUsers', style: 'primary' },
        { id: 'btnNewUser', label: '새 직원', call: 'prepareNewUser', style: 'secondary' },
        { id: 'btnSaveUser', label: '저장', call: 'saveUser', style: 'primary' },
        { id: 'btnSetUserStatus', label: '상태변경', call: 'setUserStatus', style: 'warning' }
      ],
      calls: ['listUsers', 'getUserDetail', 'saveUser', 'setUserStatus'],
      sheets: ['PortalUsers'],
      logSheet: 'Portal_AuditLog',
      screenStructure: ['화면 제목', '화면 설명', '주요 작업 버튼', '검색 / 필터', '목록 / 입력폼 / 상세', '성공 / 실패 안내문']
    },
    {
      moduleCode: GW_B12_MODULE_CODE,
      menuId: 'gw.permissions',
      route: '/groupware/permissions',
      handler: 'gwHandlePermissionsBody',
      viewFile: 'GW_PermissionsBody.html',
      screenId: 'GW_PermissionsBody',
      title: '권한관리',
      description: 'PortalUsers 권한 컬럼 기준으로 직원별 권한 체크값을 조회하고 저장하는 PORTAL 본문 화면입니다.',
      permissionCode: 'canAccessDevConsole',
      buttons: [
        { id: 'btnReloadPermissions', label: '조회', call: 'listUsers', style: 'primary' },
        { id: 'btnLoadPermissionUser', label: '권한 불러오기', call: 'getUserDetail', style: 'secondary' },
        { id: 'btnSavePermissionUser', label: '권한 저장', call: 'saveUser', style: 'primary' }
      ],
      calls: ['listUsers', 'getUserDetail', 'saveUser'],
      sheets: ['PortalUsers'],
      logSheet: 'Portal_AuditLog',
      screenStructure: ['화면 제목', '화면 설명', '주요 작업 버튼', '검색 / 필터', '목록 / 입력폼 / 상세', '성공 / 실패 안내문']
    }
  ];
}

function gwHandleUsersBody(payload) {
  payload = payload || {};
  gwAssertPermission_('canAccessDevConsole');
  var listResult = gwListPortalUsersForUi({ query: payload.query || '', limit: payload.limit || 50 });
  if (!listResult.ok) return listResult;
  var rows = (listResult.data && listResult.data.rows) || [];
  var selected = null;
  if (payload.employeeId || payload.userId) {
    var detailResult = gwGetPortalUserDetailForUi({ employeeId: payload.employeeId, userId: payload.userId });
    if (detailResult.ok) selected = detailResult.data.user;
  }
  var model = gwBuildUsersBodyModel_(rows, selected, payload);
  return gwOk_(model, '직원관리 본문 구성 완료');
}

function gwHandlePermissionsBody(payload) {
  payload = payload || {};
  gwAssertPermission_('canAccessDevConsole');
  var listResult = gwListPortalUsersForUi({ query: payload.query || '', limit: payload.limit || 50 });
  if (!listResult.ok) return listResult;
  var rows = (listResult.data && listResult.data.rows) || [];
  var selected = null;
  if (payload.employeeId || payload.userId) {
    var detailResult = gwGetPortalUserDetailForUi({ employeeId: payload.employeeId, userId: payload.userId });
    if (detailResult.ok) selected = detailResult.data.user;
  } else if (rows.length > 0) {
    selected = rows[0];
  }
  var model = gwBuildPermissionsBodyModel_(rows, selected, payload);
  return gwOk_(model, '권한관리 본문 구성 완료');
}

function gwBuildUsersBodyModel_(rows, selected, payload) {
  var spec = gwFindB12BodySpec_('GW_UsersBody');
  var model = {
    moduleCode: GW_B12_MODULE_CODE,
    screenId: spec.screenId,
    menuId: spec.menuId,
    route: spec.route,
    handler: spec.handler,
    title: spec.title,
    description: spec.description,
    permissionCode: spec.permissionCode,
    actions: spec.buttons,
    filters: [
      { id: 'userSearchKeyword', label: '검색어', field: 'query', value: gwToSafeText_(payload.query), placeholder: '이름, 이메일, employeeId, 부서, roleCode' },
      { id: 'userStatusFilter', label: '상태', field: 'status', value: gwToSafeText_(payload.status || ''), options: ['ALL', 'ACTIVE', 'INACTIVE'] }
    ],
    list: {
      title: '직원 목록',
      totalReturned: rows.length,
      columns: ['employeeId', 'employeeName', 'loginEmail', 'department', 'position', 'roleCode', 'status'],
      rows: rows
    },
    form: {
      title: selected ? '직원 상세 / 수정' : '새 직원 / 상세',
      fields: gwBuildB12UserFormFields_(selected)
    },
    messages: [
      { type: 'info', text: 'PORTAL 중앙 메뉴에서 열린 본문 화면입니다. 이 화면은 메뉴를 렌더링하지 않습니다.' },
      { type: 'success', text: '저장 성공 시 직원 목록을 다시 조회합니다.' },
      { type: 'error', text: '필수값 또는 권한 오류가 있으면 이 영역에 실패 안내문을 표시합니다.' }
    ],
    apiCalls: spec.calls,
    saveSheet: 'PortalUsers',
    logSheet: 'Portal_AuditLog'
  };
  model.bodyHtml = gwRenderB12UsersBodyHtml_(model);
  model.bodyAudit = gwValidateB12BodyModel_(model);
  return model;
}

function gwBuildPermissionsBodyModel_(rows, selected, payload) {
  var spec = gwFindB12BodySpec_('GW_PermissionsBody');
  var model = {
    moduleCode: GW_B12_MODULE_CODE,
    screenId: spec.screenId,
    menuId: spec.menuId,
    route: spec.route,
    handler: spec.handler,
    title: spec.title,
    description: spec.description,
    permissionCode: spec.permissionCode,
    actions: spec.buttons,
    filters: [
      { id: 'permissionSearchKeyword', label: '직원 검색', field: 'query', value: gwToSafeText_(payload.query), placeholder: '이름, 이메일, employeeId' }
    ],
    list: {
      title: '권한 대상 직원 목록',
      totalReturned: rows.length,
      columns: ['employeeId', 'employeeName', 'loginEmail', 'roleCode', 'status'],
      rows: rows
    },
    form: {
      title: selected ? '권한 상세 / 저장' : '직원을 선택하세요',
      employeeId: selected ? selected.employeeId : '',
      employeeName: selected ? selected.employeeName : '',
      loginEmail: selected ? selected.loginEmail : '',
      permissionFields: gwBuildB12PermissionFields_(selected)
    },
    messages: [
      { type: 'info', text: '권한은 PortalUsers 헤더맵 기준으로 저장합니다.' },
      { type: 'success', text: '권한 저장 성공 시 선택 직원의 상세를 다시 조회합니다.' },
      { type: 'error', text: '권한 없는 접근 또는 저장 실패 시 실패 안내문을 표시합니다.' }
    ],
    apiCalls: spec.calls,
    saveSheet: 'PortalUsers',
    logSheet: 'Portal_AuditLog'
  };
  model.bodyHtml = gwRenderB12PermissionsBodyHtml_(model);
  model.bodyAudit = gwValidateB12BodyModel_(model);
  return model;
}

function gwFindB12BodySpec_(screenId) {
  var specs = gwGetB12BodySpecs();
  for (var i = 0; i < specs.length; i++) {
    if (specs[i].screenId === screenId) return specs[i];
  }
  throw new Error('B12 본문 책임표를 찾을 수 없습니다: ' + screenId);
}

function gwBuildB12UserFormFields_(user) {
  user = user || {};
  return GW_B12_USER_FIELDS.map(function (field) {
    return {
      field: field,
      label: gwGetB12FieldLabel_(field),
      value: gwToSafeText_(user[field]),
      required: field === 'employeeName' || field === 'loginEmail' || field === 'roleCode',
      inputType: field === 'statusReason' || field === 'memo' ? 'textarea' : 'text'
    };
  });
}

function gwBuildB12PermissionFields_(user) {
  user = user || {};
  return GW_B12_PERMISSION_FIELDS.map(function (field) {
    return {
      field: field,
      label: gwGetB12FieldLabel_(field),
      value: gwNormalizeYnText_(user[field]),
      inputType: 'checkbox'
    };
  });
}

function gwGetB12FieldLabel_(field) {
  var labels = {
    employeeId: '직원 ID', employeeName: '이름', loginEmail: '업무 이메일', mobile: '휴대폰',
    department: '부서', team: '팀', position: '직책', roleCode: '역할 코드', roleName: '역할명',
    vendorId: '업체 ID', eventId: '행사 ID', status: '상태', statusReason: '상태 사유', memo: '메모',
    canAccessPortal: 'PORTAL 접근', canAccessMail: '메일 접근', canSendMail: '메일 발송',
    canAccessCalendar: '일정 접근', canCreateCalendarEvent: '일정 생성', canAccessSign: 'SIGN 접근',
    canAccessErp: 'ERP 접근', canAccessForm: 'FORM 접근', canAccessControl: 'CONTROL 접근',
    canAccessDevConsole: '개발/진단 접근', canApprove: '승인 권한', canViewLogs: '로그 조회',
    canDownloadFiles: '파일 다운로드', canViewSensitiveInfo: '민감정보 조회'
  };
  return labels[field] || field;
}

function gwNormalizeYnText_(value) {
  var text = gwToSafeText_(value).toUpperCase();
  if (value === true || text === 'Y' || text === 'YES' || text === 'TRUE' || text === '1') return 'Y';
  return 'N';
}

function gwRenderB12UsersBodyHtml_(model) {
  var rowsHtml = model.list.rows.map(function (row) {
    return '<tr data-employee-id="' + gwEscHtml_(row.employeeId) + '">' +
      '<td>' + gwEscHtml_(row.employeeId) + '</td>' +
      '<td>' + gwEscHtml_(row.employeeName) + '</td>' +
      '<td>' + gwEscHtml_(row.loginEmail) + '</td>' +
      '<td>' + gwEscHtml_(row.department) + '</td>' +
      '<td>' + gwEscHtml_(row.position) + '</td>' +
      '<td>' + gwEscHtml_(row.roleCode) + '</td>' +
      '<td>' + gwEscHtml_(row.status) + '</td>' +
    '</tr>';
  }).join('') || '<tr><td colspan="7">표시할 직원이 없습니다.</td></tr>';
  var fieldsHtml = model.form.fields.map(function (field) {
    var tag = field.inputType === 'textarea' ? 'textarea' : 'input';
    if (tag === 'textarea') {
      return '<label>' + gwEscHtml_(field.label) + '<textarea data-field="' + gwEscHtml_(field.field) + '">' + gwEscHtml_(field.value) + '</textarea></label>';
    }
    return '<label>' + gwEscHtml_(field.label) + '<input type="text" data-field="' + gwEscHtml_(field.field) + '" value="' + gwEscHtml_(field.value) + '" /></label>';
  }).join('');
  return '<section class="gw-body gw-users-body" data-screen-id="GW_UsersBody">' +
    '<h2>' + gwEscHtml_(model.title) + '</h2>' +
    '<p>' + gwEscHtml_(model.description) + '</p>' +
    '<div class="gw-actions">' + gwRenderB12ActionButtons_(model.actions) + '</div>' +
    '<div class="gw-filter"><label>검색 / 필터<input type="text" data-field="query" value="' + gwEscHtml_(model.filters[0].value) + '" /></label></div>' +
    '<div class="gw-message-zone"><p data-message-type="info">직원 목록을 선택하거나 새 직원을 입력한 뒤 저장합니다.</p></div>' +
    '<div class="gw-layout-two"><div class="gw-list"><h3>목록</h3><table><thead><tr><th>직원 ID</th><th>이름</th><th>이메일</th><th>부서</th><th>직책</th><th>역할</th><th>상태</th></tr></thead><tbody>' + rowsHtml + '</tbody></table></div>' +
    '<div class="gw-detail"><h3>입력폼 / 상세</h3>' + fieldsHtml + '</div></div>' +
  '</section>';
}

function gwRenderB12PermissionsBodyHtml_(model) {
  var rowsHtml = model.list.rows.map(function (row) {
    return '<tr data-employee-id="' + gwEscHtml_(row.employeeId) + '"><td>' + gwEscHtml_(row.employeeId) + '</td><td>' + gwEscHtml_(row.employeeName) + '</td><td>' + gwEscHtml_(row.loginEmail) + '</td><td>' + gwEscHtml_(row.roleCode) + '</td><td>' + gwEscHtml_(row.status) + '</td></tr>';
  }).join('') || '<tr><td colspan="5">표시할 직원이 없습니다.</td></tr>';
  var permissionsHtml = model.form.permissionFields.map(function (field) {
    var checked = field.value === 'Y' ? ' checked' : '';
    return '<label><input type="checkbox" data-field="' + gwEscHtml_(field.field) + '" value="Y"' + checked + ' /> ' + gwEscHtml_(field.label) + '</label>';
  }).join('');
  return '<section class="gw-body gw-permissions-body" data-screen-id="GW_PermissionsBody">' +
    '<h2>' + gwEscHtml_(model.title) + '</h2>' +
    '<p>' + gwEscHtml_(model.description) + '</p>' +
    '<div class="gw-actions">' + gwRenderB12ActionButtons_(model.actions) + '</div>' +
    '<div class="gw-filter"><label>검색 / 필터<input type="text" data-field="query" value="' + gwEscHtml_(model.filters[0].value) + '" /></label></div>' +
    '<div class="gw-message-zone"><p data-message-type="info">직원을 선택한 뒤 권한을 저장합니다.</p></div>' +
    '<div class="gw-layout-two"><div class="gw-list"><h3>목록</h3><table><thead><tr><th>직원 ID</th><th>이름</th><th>이메일</th><th>역할</th><th>상태</th></tr></thead><tbody>' + rowsHtml + '</tbody></table></div>' +
    '<div class="gw-detail"><h3>입력폼 / 상세</h3><p>' + gwEscHtml_(model.form.employeeName || '직원을 선택하세요') + '</p><div class="gw-permission-grid">' + permissionsHtml + '</div></div></div>' +
  '</section>';
}

function gwRenderB12ActionButtons_(actions) {
  return actions.map(function (action) {
    return '<button type="button" data-gw-action="' + gwEscHtml_(action.call) + '" data-button-id="' + gwEscHtml_(action.id) + '">' + gwEscHtml_(action.label) + '</button>';
  }).join('');
}

function gwValidateB12BodyModel_(model) {
  var errors = [];
  var html = gwToSafeText_(model.bodyHtml);
  if (html.indexOf('<h2>') < 0) errors.push('화면 제목 누락: ' + model.screenId);
  if (html.indexOf('<p>') < 0) errors.push('화면 설명 누락: ' + model.screenId);
  if (html.indexOf('data-gw-action') < 0) errors.push('주요 작업 버튼 연결 누락: ' + model.screenId);
  if (html.indexOf('gw-filter') < 0) errors.push('검색 / 필터 영역 누락: ' + model.screenId);
  if (html.indexOf('gw-list') < 0 || html.indexOf('gw-detail') < 0) errors.push('목록 / 입력폼 / 상세 영역 누락: ' + model.screenId);
  if (html.indexOf('gw-message-zone') < 0) errors.push('성공 / 실패 안내문 영역 누락: ' + model.screenId);
  GW_B12_FORBIDDEN_VISIBLE_TOKENS.forEach(function (token) {
    if (html.toLowerCase().indexOf(token.toLowerCase()) >= 0) errors.push('금지 UI 토큰 포함: ' + token);
  });
  return { ok: errors.length === 0, errors: errors, htmlLength: html.length };
}

function gwValidateB12BodyContracts(payload) {
  var errors = [];
  var specs = gwGetB12BodySpecs();
  var expectedHandlers = { gwHandleUsersBody: true, gwHandlePermissionsBody: true };
  var expectedRoutes = { '/groupware/users': true, '/groupware/permissions': true };
  specs.forEach(function (spec) {
    if (spec.moduleCode !== GW_B12_MODULE_CODE) errors.push('moduleCode 오류: ' + spec.screenId);
    if (!expectedHandlers[spec.handler]) errors.push('handler 오류: ' + spec.handler);
    if (!expectedRoutes[spec.route]) errors.push('route 오류: ' + spec.route);
    if (spec.permissionCode !== 'canAccessDevConsole') errors.push('permissionCode 오류: ' + spec.screenId);
    if (!spec.buttons || spec.buttons.length === 0) errors.push('버튼 목록 누락: ' + spec.screenId);
    if (!spec.calls || spec.calls.length === 0) errors.push('호출 함수 누락: ' + spec.screenId);
    if (spec.sheets.indexOf('PortalUsers') < 0) errors.push('저장 시트 누락: ' + spec.screenId);
    if (spec.logSheet !== 'Portal_AuditLog') errors.push('로그 시트 오류: ' + spec.screenId);
  });
  return gwOk_({ ok: errors.length === 0, errors: errors, specCount: specs.length, portalShellOnly: true }, errors.length === 0 ? 'B12_BODY_CONTRACT_OK' : 'B12_BODY_CONTRACT_ERROR');
}

function gwEscHtml_(value) {
  var text = gwToSafeText_(value);
  return text.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;').replace(/'/g, '&#39;');
}
