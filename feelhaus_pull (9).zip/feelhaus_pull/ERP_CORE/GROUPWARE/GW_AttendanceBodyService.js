/**
 * B16 PORTAL body-only UI service for CAPS Attendance.
 * This file returns body-only screen models and bodyHtml strings for PORTAL handlers.
 * It must not render module navigation, its own top bar, its own side bar, iframe, preview route, or standalone shell.
 */
const GW_B16_MODULE_CODE = 'GROUPWARE';
const GW_B16_BODY_IDS = Object.freeze(['GW_AttendanceCapsBody', 'GW_MyAttendanceBody', 'GW_AttendanceAdminBody', 'GW_AttendanceExceptionsBody']);
const GW_B16_FORBIDDEN_VISIBLE_TOKENS = Object.freeze(['<iframe', 'preview route', 'standalone shell', 'data-module-menu', 'gw-own-menu', 'gw-side-menu', 'gw-top-menu', 'fragment menu']);

function gwGetB16BodySpecs() {
  return [
    {
      moduleCode: GW_B16_MODULE_CODE,
      menuId: 'gw.attendance.caps',
      route: '/groupware/attendance/caps',
      handler: 'gwHandleCapsAttendanceBody',
      viewFile: 'GW_AttendanceCapsBody.html',
      screenId: 'GW_AttendanceCapsBody',
      title: 'CAPS 근태 연동',
      description: 'CAPS 원본 Raw, Mock/API/CSV/Drive 수집 준비, employeeId 매칭, 원장 반영 상태를 담당하는 PORTAL 본문 화면입니다.',
      permissionCode: 'canAccessPortal',
      buttons: [
        { id: 'btnSyncCapsMock', label: 'CAPS Mock 동기화', call: 'syncCapsMock', style: 'primary' },
        { id: 'btnReloadCapsRaw', label: 'Raw 조회', call: 'listCapsRaw', style: 'secondary' },
        { id: 'btnReloadAttendance', label: '근태 원장 조회', call: 'listAttendance', style: 'secondary' },
        { id: 'btnReloadAttendanceExceptions', label: '예외 조회', call: 'listAttendanceExceptions', style: 'warning' }
      ],
      calls: ['syncCapsMock', 'listCapsRaw', 'listAttendance', 'listAttendanceExceptions'],
      sheets: ['Portal_AttendanceRaw_CAPS', 'Portal_AttendanceCapsMap', 'Portal_Attendance', 'Portal_AttendanceExceptions'],
      logSheet: 'Portal_AuditLog',
      screenStructure: ['화면 제목', '화면 설명', '주요 작업 버튼', '검색 / 필터', '목록 / 입력폼 / 상세', '성공 / 실패 안내문']
    },
    {
      moduleCode: GW_B16_MODULE_CODE,
      menuId: 'gw.attendance.mine',
      route: '/groupware/attendance/mine',
      handler: 'gwHandleMyAttendanceBody',
      viewFile: 'GW_MyAttendanceBody.html',
      screenId: 'GW_MyAttendanceBody',
      title: '내 근태',
      description: '현재 employeeId 기준 내 근태 목록과 누락/예외 안내를 담당하는 PORTAL 본문 화면입니다.',
      permissionCode: 'canAccessPortal',
      buttons: [
        { id: 'btnReloadMyAttendance', label: '내 근태 조회', call: 'listAttendance', style: 'primary' },
        { id: 'btnReloadMyExceptions', label: '내 예외 조회', call: 'listAttendanceExceptions', style: 'secondary' }
      ],
      calls: ['listAttendance', 'listAttendanceExceptions'],
      sheets: ['Portal_Attendance', 'Portal_AttendanceExceptions'],
      logSheet: 'Portal_AuditLog',
      screenStructure: ['화면 제목', '화면 설명', '주요 작업 버튼', '검색 / 필터', '목록 / 입력폼 / 상세', '성공 / 실패 안내문']
    },
    {
      moduleCode: GW_B16_MODULE_CODE,
      menuId: 'gw.attendance.admin',
      route: '/groupware/attendance/admin',
      handler: 'gwHandleAttendanceAdminBody',
      viewFile: 'GW_AttendanceAdminBody.html',
      screenId: 'GW_AttendanceAdminBody',
      title: '근태 현황',
      description: '관리자 기준 전체 근태 원장 조회, 직원/일자 필터, CAPS 반영 상태 확인을 담당하는 PORTAL 본문 화면입니다.',
      permissionCode: 'canViewLogs',
      buttons: [
        { id: 'btnReloadAttendanceAdmin', label: '전체 근태 조회', call: 'listAttendance', style: 'primary' },
        { id: 'btnReloadCapsRawAdmin', label: 'CAPS Raw 조회', call: 'listCapsRaw', style: 'secondary' }
      ],
      calls: ['listAttendance', 'listCapsRaw'],
      sheets: ['Portal_Attendance', 'Portal_AttendanceRaw_CAPS'],
      logSheet: 'Portal_AuditLog',
      screenStructure: ['화면 제목', '화면 설명', '주요 작업 버튼', '검색 / 필터', '목록 / 입력폼 / 상세', '성공 / 실패 안내문']
    },
    {
      moduleCode: GW_B16_MODULE_CODE,
      menuId: 'gw.attendance.exceptions',
      route: '/groupware/attendance/exceptions',
      handler: 'gwHandleAttendanceExceptionsBody',
      viewFile: 'GW_AttendanceExceptionsBody.html',
      screenId: 'GW_AttendanceExceptionsBody',
      title: '근태 예외처리',
      description: '매칭 실패, 퇴근 누락, 수기 보정 필요 항목을 조회하고 승인 요청 흐름으로 연결하는 PORTAL 본문 화면입니다.',
      permissionCode: 'canApprove',
      buttons: [
        { id: 'btnReloadAttendanceExceptionsAdmin', label: '예외 목록 조회', call: 'listAttendanceExceptions', style: 'primary' },
        { id: 'btnOpenRelatedRequest', label: '관련 요청 확인', call: 'listRequests', style: 'secondary' }
      ],
      calls: ['listAttendanceExceptions', 'listRequests'],
      sheets: ['Portal_AttendanceExceptions', 'Portal_Requests'],
      logSheet: 'Portal_AuditLog',
      screenStructure: ['화면 제목', '화면 설명', '주요 작업 버튼', '검색 / 필터', '목록 / 입력폼 / 상세', '성공 / 실패 안내문']
    }
  ];
}

function gwHandleCapsAttendanceBody(payload) { return gwBuildB16AttendanceBody_('GW_AttendanceCapsBody', payload || {}); }
function gwHandleMyAttendanceBody(payload) { return gwBuildB16AttendanceBody_('GW_MyAttendanceBody', payload || {}); }
function gwHandleAttendanceAdminBody(payload) { return gwBuildB16AttendanceBody_('GW_AttendanceAdminBody', payload || {}); }
function gwHandleAttendanceExceptionsBody(payload) { return gwBuildB16AttendanceBody_('GW_AttendanceExceptionsBody', payload || {}); }
function gwHandleAttendanceBody(payload) { payload = payload || {}; return gwBuildB16AttendanceBody_(payload.screenId || 'GW_AttendanceCapsBody', payload); }

function gwBuildB16AttendanceBody_(screenId, payload) {
  payload = payload || {};
  var spec = gwFindB16BodySpec_(screenId);
  gwAssertPermission_(spec.permissionCode || 'canAccessPortal');
  var ctx = gwGetUserContextSafe_();
  var includeAll = payload.includeAll === true || spec.permissionCode === 'canViewLogs' || spec.permissionCode === 'canApprove';
  var attendanceResult = gwListAttendanceForUi({ includeAll: includeAll, limit: payload.limit || 20, employeeId: payload.employeeId || '', workDate: payload.workDate || '' });
  if (!attendanceResult.ok) return attendanceResult;
  var exceptionResult = gwListAttendanceExceptionsForUi({ includeAll: includeAll, limit: payload.limit || 20 });
  if (!exceptionResult.ok) return exceptionResult;
  var rawRows = [];
  var rawMessage = '';
  if (screenId === 'GW_AttendanceCapsBody' || screenId === 'GW_AttendanceAdminBody') {
    var rawResult = gwListCapsRawForUi({ limit: payload.limit || 20 });
    if (rawResult.ok) rawRows = (rawResult.data && rawResult.data.rows) || [];
    else rawMessage = rawResult.message || 'CAPS Raw 조회 권한 또는 데이터 상태를 확인하십시오.';
  }
  var model = gwBuildB16AttendanceBodyModel_(spec, ctx, (attendanceResult.data && attendanceResult.data.rows) || [], (exceptionResult.data && exceptionResult.data.rows) || [], rawRows, rawMessage, payload);
  return gwOk_(model, spec.title + ' 본문 구성 완료');
}

function gwBuildB16AttendanceBodyModel_(spec, ctx, attendanceRows, exceptionRows, rawRows, rawMessage, payload) {
  var model = {
    moduleCode: GW_B16_MODULE_CODE,
    screenId: spec.screenId,
    menuId: spec.menuId,
    route: spec.route,
    handler: spec.handler,
    title: spec.title,
    description: spec.description,
    permissionCode: spec.permissionCode,
    actions: spec.buttons,
    filters: [
      { id: 'attendanceEmployeeFilter', label: '직원 ID', field: 'employeeId', value: gwToSafeText_(payload.employeeId || ''), placeholder: 'employeeId' },
      { id: 'attendanceWorkDateFilter', label: '근무일', field: 'workDate', value: gwToSafeText_(payload.workDate || ''), placeholder: 'YYYY-MM-DD' }
    ],
    attendanceList: { title: '근태 원장', totalReturned: attendanceRows.length, columns: ['attendanceId', 'employeeId', 'workDate', 'checkInAt', 'checkOutAt', 'workStatus', 'exceptionYn'], rows: attendanceRows },
    exceptionList: { title: '근태 예외', totalReturned: exceptionRows.length, columns: ['attendanceExceptionId', 'employeeId', 'workDate', 'exceptionType', 'requestStatus', 'status'], rows: exceptionRows },
    rawList: { title: 'CAPS Raw', totalReturned: rawRows.length, columns: ['rawAttendanceId', 'externalEmployeeKey', 'rawEventType', 'rawEventAt', 'syncBatchId', 'syncStatus'], rows: rawRows },
    messages: [
      { type: 'info', text: 'PORTAL 중앙 메뉴에서 열린 본문 화면입니다. 이 화면은 메뉴를 렌더링하지 않습니다.' },
      { type: 'success', text: 'CAPS Mock 동기화, 근태 원장 조회, 예외 조회 성공 시 목록을 다시 표시합니다.' },
      { type: 'error', text: rawMessage || 'CAPS API 실제 연결 전에는 Mock/CSV/Drive 수집 구조로 검수합니다.' }
    ],
    apiCalls: spec.calls,
    readSheets: spec.sheets,
    logSheet: 'Portal_AuditLog',
    currentUser: { employeeId: ctx.employeeId, roleCode: ctx.roleCode }
  };
  model.bodyHtml = gwRenderB16AttendanceBodyHtml_(model);
  model.bodyAudit = gwValidateB16BodyModel_(model);
  return model;
}

function gwFindB16BodySpec_(screenId) {
  var specs = gwGetB16BodySpecs();
  for (var i = 0; i < specs.length; i++) if (specs[i].screenId === screenId) return specs[i];
  throw new Error('B16 본문 책임표를 찾을 수 없습니다: ' + screenId);
}

function gwRenderB16AttendanceBodyHtml_(model) {
  var attendanceHtml = model.attendanceList.rows.map(function (row) {
    return '<tr data-attendance-id="' + gwEscHtml_(row.attendanceId) + '"><td>' + gwEscHtml_(row.attendanceId) + '</td><td>' + gwEscHtml_(row.employeeId) + '</td><td>' + gwEscHtml_(row.workDate) + '</td><td>' + gwEscHtml_(row.checkInAt) + '</td><td>' + gwEscHtml_(row.checkOutAt) + '</td><td>' + gwEscHtml_(row.workStatus) + '</td><td>' + gwEscHtml_(row.exceptionYn) + '</td></tr>';
  }).join('') || '<tr><td colspan="7">표시할 근태 원장이 없습니다.</td></tr>';
  var exceptionHtml = model.exceptionList.rows.map(function (row) {
    return '<tr data-attendance-exception-id="' + gwEscHtml_(row.attendanceExceptionId) + '"><td>' + gwEscHtml_(row.attendanceExceptionId) + '</td><td>' + gwEscHtml_(row.employeeId) + '</td><td>' + gwEscHtml_(row.workDate) + '</td><td>' + gwEscHtml_(row.exceptionType) + '</td><td>' + gwEscHtml_(row.requestStatus) + '</td><td>' + gwEscHtml_(row.status) + '</td></tr>';
  }).join('') || '<tr><td colspan="6">표시할 근태 예외가 없습니다.</td></tr>';
  var rawHtml = model.rawList.rows.map(function (row) {
    return '<tr data-caps-raw-id="' + gwEscHtml_(row.rawAttendanceId) + '"><td>' + gwEscHtml_(row.rawAttendanceId) + '</td><td>' + gwEscHtml_(row.externalEmployeeKey) + '</td><td>' + gwEscHtml_(row.rawEventType) + '</td><td>' + gwEscHtml_(row.rawEventAt) + '</td><td>' + gwEscHtml_(row.syncBatchId) + '</td><td>' + gwEscHtml_(row.syncStatus) + '</td></tr>';
  }).join('') || '<tr><td colspan="6">표시할 CAPS Raw가 없습니다.</td></tr>';
  return '<section class="gw-body gw-attendance-body" data-screen-id="' + gwEscHtml_(model.screenId) + '">' +
    '<h2>' + gwEscHtml_(model.title) + '</h2>' +
    '<p>' + gwEscHtml_(model.description) + '</p>' +
    '<div class="gw-actions">' + gwRenderB16ActionButtons_(model.actions) + '</div>' +
    '<div class="gw-filter"><label>직원 ID<input type="text" data-field="employeeId" value="' + gwEscHtml_(model.filters[0].value) + '" /></label><label>근무일<input type="text" data-field="workDate" value="' + gwEscHtml_(model.filters[1].value) + '" /></label></div>' +
    '<div class="gw-message-zone"><p data-message-type="info">CAPS 원본은 직접 수정하지 않고 Raw → 매칭 → 근태 원장 → 예외처리 흐름으로 확인합니다.</p></div>' +
    '<div class="gw-list"><h3>근태 원장</h3><table><thead><tr><th>근태 ID</th><th>직원</th><th>근무일</th><th>출근</th><th>퇴근</th><th>상태</th><th>예외</th></tr></thead><tbody>' + attendanceHtml + '</tbody></table></div>' +
    '<div class="gw-detail"><h3>근태 예외</h3><table><thead><tr><th>예외 ID</th><th>직원</th><th>근무일</th><th>유형</th><th>요청상태</th><th>상태</th></tr></thead><tbody>' + exceptionHtml + '</tbody></table></div>' +
    '<div class="gw-detail"><h3>CAPS Raw</h3><table><thead><tr><th>Raw ID</th><th>외부직원키</th><th>이벤트</th><th>시간</th><th>배치</th><th>동기화</th></tr></thead><tbody>' + rawHtml + '</tbody></table></div>' +
  '</section>';
}

function gwRenderB16ActionButtons_(actions) {
  return actions.map(function (action) { return '<button type="button" data-gw-action="' + gwEscHtml_(action.call) + '" data-button-id="' + gwEscHtml_(action.id) + '">' + gwEscHtml_(action.label) + '</button>'; }).join('');
}

function gwValidateB16BodyModel_(model) {
  var errors = [];
  var html = gwToSafeText_(model.bodyHtml);
  if (html.indexOf('<h2>') < 0) errors.push('화면 제목 누락: ' + model.screenId);
  if (html.indexOf('<p>') < 0) errors.push('화면 설명 누락: ' + model.screenId);
  if (html.indexOf('data-gw-action') < 0) errors.push('주요 작업 버튼 연결 누락: ' + model.screenId);
  if (html.indexOf('gw-filter') < 0) errors.push('검색 / 필터 영역 누락: ' + model.screenId);
  if (html.indexOf('gw-list') < 0 || html.indexOf('gw-detail') < 0) errors.push('목록 / 입력폼 / 상세 영역 누락: ' + model.screenId);
  if (html.indexOf('gw-message-zone') < 0) errors.push('성공 / 실패 안내문 영역 누락: ' + model.screenId);
  GW_B16_FORBIDDEN_VISIBLE_TOKENS.forEach(function (token) { if (html.toLowerCase().indexOf(token.toLowerCase()) >= 0) errors.push('금지 UI 토큰 포함: ' + token); });
  return { ok: errors.length === 0, errors: errors, htmlLength: html.length };
}

function gwValidateB16BodyContracts(payload) {
  var errors = [];
  var specs = gwGetB16BodySpecs();
  var expectedHandlers = { gwHandleCapsAttendanceBody: true, gwHandleMyAttendanceBody: true, gwHandleAttendanceAdminBody: true, gwHandleAttendanceExceptionsBody: true };
  var expectedRoutes = { '/groupware/attendance/caps': true, '/groupware/attendance/mine': true, '/groupware/attendance/admin': true, '/groupware/attendance/exceptions': true };
  specs.forEach(function (spec) {
    if (spec.moduleCode !== GW_B16_MODULE_CODE) errors.push('moduleCode 오류: ' + spec.screenId);
    if (!expectedHandlers[spec.handler]) errors.push('handler 오류: ' + spec.handler);
    if (!expectedRoutes[spec.route]) errors.push('route 오류: ' + spec.route);
    if (!spec.permissionCode) errors.push('permissionCode 누락: ' + spec.screenId);
    if (spec.viewFile.indexOf('.html') < 0) errors.push('viewFile 명시 오류: ' + spec.screenId);
    if (spec.screenStructure.join('|').indexOf('성공 / 실패 안내문') < 0) errors.push('성공/실패 안내문 구조 누락: ' + spec.screenId);
  });
  return gwOk_({ ok: errors.length === 0, errors: errors, specCount: specs.length, portalShellOnly: true }, errors.length ? 'B16_BODY_CONTRACT_ERROR' : 'B16_BODY_CONTRACT_OK');
}
