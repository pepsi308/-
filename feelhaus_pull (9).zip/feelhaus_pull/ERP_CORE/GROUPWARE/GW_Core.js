const GW_SETUP_DB_ID = '17VMSpgSZCvIrUlgcw8yCNcnl8WQWo2IcRf5tDCcuJGM';
const GW_CONFIG_SHEET_NAME = 'SystemConfig';
const GW_SOURCE_DB_NAME = 'FEELHAUS_SETUP_DB';
const GW_MASTER_DB_NAME = 'FEELHAUS_DB_MASTER';

const GW_STATUS = Object.freeze({
  READY: 'READY',
  PREPARING: 'PREPARING',
  DISABLED: 'DISABLED',
  NO_PERMISSION: 'NO_PERMISSION',
  ERROR: 'ERROR',
  ACTIVE: 'ACTIVE',
  INACTIVE: 'INACTIVE'
});

function gwNow_() {
  return Utilities.formatDate(new Date(), 'Asia/Seoul', 'yyyy-MM-dd HH:mm:ss');
}

function gwUuid_(prefix) {
  var raw = Utilities.getUuid().replace(/-/g, '').slice(0, 12).toUpperCase();
  var time = Utilities.formatDate(new Date(), 'Asia/Seoul', 'yyyyMMddHHmmss');
  return (prefix || 'GW') + '-' + time + '-' + raw;
}

function gwOk_(data, message) {
  return {
    ok: true,
    build: GW_BUILD_INFO.build,
    generatedAt: gwNow_(),
    message: message || 'OK',
    data: data || {}
  };
}

function gwFail_(code, message, detail) {
  return {
    ok: false,
    build: GW_BUILD_INFO.build,
    generatedAt: gwNow_(),
    code: code || 'ERROR',
    message: message || '처리 중 오류가 발생했습니다.',
    detail: detail || {}
  };
}

function gwErrorMessage_(err) {
  if (!err) return '알 수 없는 오류';
  if (err.message) return err.message;
  return String(err);
}

function gwErrorStack_(err) {
  if (!err || !err.stack) return '';
  return String(err.stack).slice(0, 2000);
}

function gwNormalizeYn_(value) {
  var text = String(value || '').trim().toUpperCase();
  return text === 'Y' || text === 'YES' || text === 'TRUE' || text === '1';
}

function gwToSafeText_(value) {
  if (value === null || typeof value === 'undefined') return '';
  return String(value).trim();
}

function gwExtractSpreadsheetId_(value) {
  var text = gwToSafeText_(value);
  if (!text) return '';
  var match = text.match(/[-\w]{25,}/);
  return match ? match[0] : text;
}

function gwOpenSpreadsheetById_(spreadsheetId, label) {
  if (!spreadsheetId) throw new Error((label || 'Spreadsheet') + ' ID가 비어 있습니다.');
  try {
    return SpreadsheetApp.openById(spreadsheetId);
  } catch (err) {
    throw new Error((label || 'Spreadsheet') + ' 열기 실패: ' + gwErrorMessage_(err));
  }
}
