const GW_MENU_DEFINITIONS = Object.freeze([
  { menuId: 'home', label: '홈 / 현황', group: '홈', featureKey: 'FEATURE_GW_HOME_ENABLED', permission: 'canAccessPortal', b01Ready: true },
  { menuId: 'account', label: '내 계정 / 계정 설정', group: '내 업무', featureKey: 'FEATURE_GW_ACCOUNT_ENABLED', permission: 'canAccessPortal', b01Ready: true },
  { menuId: 'groupware', label: '그룹웨어 / 사내업무', group: '사내업무', featureKey: 'FEATURE_GW_HOME_ENABLED', permission: 'canAccessPortal', b01Ready: true },
  { menuId: 'hr', label: '인사 / 조직 / 근태', group: '인사관리', featureKey: 'FEATURE_HR_ENABLED', permission: 'canAccessPortal', b01Ready: true },
  { menuId: 'users', label: '직원관리', group: '인사관리', featureKey: 'FEATURE_HR_ENABLED', permission: 'canAccessPortal', b01Ready: true },
  { menuId: 'permissions', label: '권한관리', group: '인사관리', featureKey: 'FEATURE_PERMISSION_ENABLED', permission: 'canAccessDevConsole', b01Ready: true },
  { menuId: 'attendanceCaps', label: 'CAPS 근태 연동', group: '인사관리', featureKey: 'FEATURE_CAPS_ATTENDANCE_SYNC_ENABLED', permission: 'canAccessPortal', b01Ready: true },
  { menuId: 'attendanceMine', label: '내 근태', group: '인사관리', featureKey: 'FEATURE_ATTENDANCE_ENABLED', permission: 'canAccessPortal', b01Ready: true },
  { menuId: 'attendanceAdmin', label: '근태 현황', group: '인사관리', featureKey: 'FEATURE_ATTENDANCE_ENABLED', permission: 'canViewLogs', b01Ready: true },
  { menuId: 'attendanceExceptions', label: '근태 예외처리', group: '인사관리', featureKey: 'FEATURE_ATTENDANCE_ENABLED', permission: 'canApprove', b01Ready: true },
  { menuId: 'requests', label: '전자결재 / 업무요청', group: '내 업무', featureKey: 'FEATURE_REQUEST_ENABLED', permission: 'canApprove', b01Ready: true },
  { menuId: 'calendar', label: '일정 / 회의 / 캘린더', group: '내 업무', featureKey: 'FEATURE_CALENDAR_ENABLED', permission: 'canAccessCalendar', b01Ready: false },
  { menuId: 'notices', label: '공지 / 게시판', group: '사내업무', featureKey: 'FEATURE_NOTICE_ENABLED', permission: 'canAccessPortal', b01Ready: true },
  { menuId: 'library', label: '사내 자료실', group: '사내업무', featureKey: 'FEATURE_DOC_LIBRARY_ENABLED', permission: 'canDownloadFiles', b01Ready: true },
  { menuId: 'knowledge', label: '지식관리 / 노하우 DB', group: '사내업무', featureKey: 'FEATURE_KNOWLEDGE_ENABLED', permission: 'canAccessPortal', b01Ready: false },
  { menuId: 'kpi', label: '직원 KPI / 성과관리', group: '인사관리', featureKey: 'FEATURE_KPI_ENABLED', permission: 'canAccessPortal', b01Ready: true },
  { menuId: 'assets', label: '총무 / 자산 / 비품', group: '관리업무', featureKey: 'FEATURE_ASSET_ENABLED', permission: 'canAccessPortal', b01Ready: true },
  { menuId: 'expenses', label: '구매 / 지출 / 비용', group: '관리업무', featureKey: 'FEATURE_EXPENSE_ENABLED', permission: 'canApprove', b01Ready: true },
  { menuId: 'diagnostics', label: '진단 / 설정', group: '시스템', featureKey: 'FEATURE_GW_DIAGNOSTIC_ENABLED', permission: 'canAccessDevConsole', b01Ready: true }
]);

function gwGetMenusForCurrentUser() {
  var context = gwGetUserContextSafe_();
  return GW_MENU_DEFINITIONS.map(function (menu) {
    var featureOn = gwGetFeatureFlagSafe_(menu.featureKey);
    var hasPermission = gwCanSafe_(context, menu.permission);
    var status = GW_STATUS.READY;
    var statusReason = '';

    if (!featureOn) {
      status = GW_STATUS.PREPARING;
      statusReason = 'FeatureFlag 비활성 또는 후속 빌드 예정입니다.';
    } else if (!hasPermission) {
      status = GW_STATUS.NO_PERMISSION;
      statusReason = '현재 계정에 필요한 권한이 없습니다.';
    } else if (!menu.b01Ready) {
      status = GW_STATUS.PREPARING;
      statusReason = '현재 빌드에서는 메뉴만 등록되고 기능은 후속 빌드에서 활성화됩니다.';
    }

    return {
      menuId: menu.menuId,
      label: menu.label,
      group: menu.group,
      featureKey: menu.featureKey,
      permission: menu.permission,
      status: status,
      statusReason: statusReason
    };
  });
}

function gwGetFeatureFlagSafe_(key) {
  try {
    return gwGetFeatureFlag_(key);
  } catch (err) {
    return GW_FEATURE_DEFAULTS[key] === 'Y';
  }
}
