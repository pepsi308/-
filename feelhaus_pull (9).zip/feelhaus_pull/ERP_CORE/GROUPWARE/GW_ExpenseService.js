const GW_EXPENSE_REQUEST_TYPE = 'EXPENSE_REQUEST';
const GW_EXPENSE_STORE_MODE = 'REQUESTS_FALLBACK';
const GW_EXPENSE_STATUSES = Object.freeze(['DRAFT', 'REQUESTED', 'IN_REVIEW', 'APPROVED', 'REJECTED', 'CANCELED', 'COMPLETED']);
const GW_EXPENSE_TYPES = Object.freeze(['GENERAL', 'TRANSPORT', 'MEAL', 'SUPPLY', 'EVENT', 'INSTALL', 'AS', 'OFFICE', 'SYSTEM']);
const GW_EXPENSE_PAYMENT_METHODS = Object.freeze(['CARD', 'CASH', 'TRANSFER', 'COMPANY_CARD', 'ETC']);

function gwGetB09ExpenseMeta_() {
  return {
    buildStep: '09/10',
    storageMode: GW_EXPENSE_STORE_MODE,
    requestType: GW_EXPENSE_REQUEST_TYPE,
    sheetName: GW_REQUEST_PREFERRED_SHEET_NAME,
    expenseStatuses: GW_EXPENSE_STATUSES.slice(),
    expenseTypes: GW_EXPENSE_TYPES.slice(),
    paymentMethods: GW_EXPENSE_PAYMENT_METHODS.slice(),
    mode: 'EXPENSE_REQUEST_APPROVAL_FIRST_SETTLEMENT_LATER',
    settlementLedgerDirectWrite: 'FORBIDDEN',
    receiptRequiredForApproval: true
  };
}

function gwInspectExpenseHeadersNoWrite_B09_() {
  var requestInfo = gwInspectRequestHeadersNoWrite_B05_();
  return {
    ok: true,
    mode: 'NO_WRITE_INSPECT',
    storageMode: GW_EXPENSE_STORE_MODE,
    requestType: GW_EXPENSE_REQUEST_TYPE,
    expenseSheetExists: requestInfo.requestSheetExists,
    expenseSheetName: requestInfo.requestSheetName,
    approvalSheetExists: requestInfo.approvalSheetExists,
    approvalSheetName: requestInfo.approvalSheetName,
    prepareRequired: !!requestInfo.prepareRequired,
    missingExpenseHeaders: requestInfo.missingRequestHeaders || [],
    missingApprovalHeaders: requestInfo.missingApprovalHeaders || [],
    note: '셀 한도 보호를 위해 비용요청은 Portal_Requests에 requestType=EXPENSE_REQUEST로 저장합니다.'
  };
}

function gwEnsureExpenseHeaders_() {
  var req = gwEnsureRequestHeaders_();
  var app = gwEnsureApprovalHeaders_();
  return {
    ok: req.ok && app.ok,
    storageMode: GW_EXPENSE_STORE_MODE,
    requestType: GW_EXPENSE_REQUEST_TYPE,
    expenseSheetName: req.sheetName,
    approvalSheetName: app.sheetName,
    requestAddedHeaders: req.addedHeaders || [],
    approvalAddedHeaders: app.addedHeaders || [],
    requestBeforeCount: req.beforeCount,
    requestAfterCount: req.afterCount,
    approvalBeforeCount: app.beforeCount,
    approvalAfterCount: app.afterCount,
    note: 'Portal_ExpenseRequests 신규 시트 생성 없이 Portal_Requests를 재사용합니다.'
  };
}

function gwListExpensesForUi(payload) {
  payload = payload || {};
  var context = gwAssertPermission_('canAccessPortal');
  var response = gwListRequestsForUi({
    includeAll: payload.includeAll === true,
    limit: payload.limit || 100,
    requestType: GW_EXPENSE_REQUEST_TYPE,
    requestStatus: payload.requestStatus || payload.status || 'ALL',
    query: payload.query || ''
  });
  if (!response.ok) return response;
  var rows = ((response.data && response.data.rows) || []).map(function (req) { return gwRequestToExpenseRow_(req); });
  return gwOk_({ rows: rows, totalReturned: rows.length, sheetName: response.data && response.data.sheetName, storageMode: GW_EXPENSE_STORE_MODE }, '비용요청 목록 조회 완료');
}

function gwGetExpenseDetailForUi(payload) {
  payload = payload || {};
  var expenseRequestId = gwToSafeText_(payload.expenseRequestId || payload.requestId);
  if (!expenseRequestId) return gwFail_('MISSING_EXPENSE_REQUEST_ID', 'expenseRequestId가 필요합니다.');
  var detail = gwGetRequestDetailForUi({ requestId: expenseRequestId });
  if (!detail.ok) return detail;
  var req = detail.data && detail.data.request;
  if (!req || req.requestType !== GW_EXPENSE_REQUEST_TYPE) return gwFail_('EXPENSE_NOT_FOUND', '비용요청을 찾을 수 없습니다.', { expenseRequestId: expenseRequestId });
  return gwOk_({ expense: gwRequestToExpenseRow_(req), approvals: detail.data.approvals || [], storageMode: GW_EXPENSE_STORE_MODE }, '비용요청 상세 조회 완료');
}

function gwSaveExpenseForUi(payload) {
  payload = payload || {};
  var context = gwAssertPermission_('canAccessPortal');
  var result = gwSaveExpense_(payload, context, { mode: 'UI' });
  return gwOk_(result, result.action === 'CREATE' ? '비용요청 등록 완료' : '비용요청 수정 완료');
}

function gwApproveExpenseForUi(payload) {
  payload = payload || {};
  var context = gwAssertPermission_('canApprove');
  var result = gwApproveExpense_(payload, context, { mode: 'UI' });
  return gwOk_(result, '비용요청 승인 완료');
}

function gwRejectExpenseForUi(payload) {
  payload = payload || {};
  var context = gwAssertPermission_('canApprove');
  var reason = gwToSafeText_(payload.approvalComment || payload.rejectedReason || payload.statusReason);
  if (!reason) return gwFail_('REJECT_REASON_REQUIRED', '반려 사유는 필수입니다.');
  var result = gwRejectExpense_(payload, context, { mode: 'UI' });
  return gwOk_(result, '비용요청 반려 완료');
}

function gwSaveExpense_(payload, context, options) {
  payload = payload || {};
  context = context || gwGetUserContextSafe_();
  options = options || {};
  var validation = gwValidateExpensePayload_(payload, false);
  if (!validation.ok) throw new Error(validation.message);
  var expenseRequestId = gwToSafeText_(payload.expenseRequestId || payload.requestId) || gwUuid_('EXP');
  var content = gwBuildExpenseContent_(payload);
  var requestPayload = {
    requestId: expenseRequestId,
    requestType: GW_EXPENSE_REQUEST_TYPE,
    title: gwToSafeText_(payload.title || payload.expenseTitle || '비용 요청').slice(0, 200),
    content: content,
    requesterEmployeeId: gwToSafeText_(payload.employeeId || payload.requesterEmployeeId) || context.employeeId || 'UNKNOWN',
    targetVendorId: gwToSafeText_(payload.vendorId || payload.targetVendorId),
    targetEventId: gwToSafeText_(payload.eventId || payload.targetEventId),
    relatedSettlementId: gwToSafeText_(payload.relatedSettlementId),
    priority: gwToSafeText_(payload.priority || 'NORMAL'),
    requestStatus: gwToSafeText_(payload.requestStatus || payload.status || 'REQUESTED'),
    statusReason: gwToSafeText_(payload.statusReason || 'B09 비용요청 저장'),
    approverEmployeeId: gwToSafeText_(payload.approverEmployeeId || payload.targetEmployeeId || '')
  };
  var saved = gwSaveRequest_(requestPayload, context, options);
  var expense = gwRequestToExpenseRow_(saved.request);
  gwAuditSafe_({
    moduleCode: 'GROUPWARE_EXPENSE',
    actionType: saved.action === 'CREATE' ? 'EXPENSE_CREATE' : 'EXPENSE_UPDATE',
    targetId: expenseRequestId,
    employeeId: context.employeeId,
    resultStatus: 'SUCCESS',
    detailMessage: 'B09 비용요청 저장: ' + expense.title + ' / ' + expense.amount
  });
  return { ok: true, action: saved.action, sheetName: saved.sheetName, rowNumber: saved.rowNumber, expense: expense, storageMode: GW_EXPENSE_STORE_MODE };
}

function gwApproveExpense_(payload, context, options) {
  payload = payload || {};
  context = context || gwGetUserContextSafe_();
  var expenseRequestId = gwToSafeText_(payload.expenseRequestId || payload.requestId);
  if (!expenseRequestId) throw new Error('expenseRequestId가 필요합니다.');
  var detail = gwGetExpenseDetailForUi({ expenseRequestId: expenseRequestId });
  if (!detail.ok) throw new Error(detail.message || '비용요청을 찾을 수 없습니다.');
  var expense = detail.data.expense;
  if (!gwToSafeText_(expense.receiptFileId)) throw new Error('증빙 없는 지출은 승인할 수 없습니다. receiptFileId가 필요합니다.');
  var approved = gwProcessRequestDecision_({ requestId: expenseRequestId, approvalComment: gwToSafeText_(payload.approvalComment || payload.statusReason || '비용요청 승인') }, context, 'APPROVED');
  var approvedExpense = gwRequestToExpenseRow_(approved.request);
  gwAuditSafe_({
    moduleCode: 'GROUPWARE_EXPENSE',
    actionType: 'EXPENSE_APPROVE',
    targetId: expenseRequestId,
    employeeId: context.employeeId,
    resultStatus: 'SUCCESS',
    detailMessage: 'B09 비용요청 승인: ' + approvedExpense.title
  });
  return { ok: true, action: 'UPDATE', sheetName: GW_REQUEST_PREFERRED_SHEET_NAME, expenseRequestId: expenseRequestId, expense: approvedExpense, approvalStatus: approved.approval && approved.approval.approvalStatus };
}

function gwRejectExpense_(payload, context, options) {
  payload = payload || {};
  context = context || gwGetUserContextSafe_();
  var expenseRequestId = gwToSafeText_(payload.expenseRequestId || payload.requestId);
  if (!expenseRequestId) throw new Error('expenseRequestId가 필요합니다.');
  var rejected = gwProcessRequestDecision_({ requestId: expenseRequestId, approvalComment: gwToSafeText_(payload.approvalComment || payload.rejectedReason || payload.statusReason) }, context, 'REJECTED');
  var expense = gwRequestToExpenseRow_(rejected.request);
  gwAuditSafe_({
    moduleCode: 'GROUPWARE_EXPENSE',
    actionType: 'EXPENSE_REJECT',
    targetId: expenseRequestId,
    employeeId: context.employeeId,
    resultStatus: 'SUCCESS',
    detailMessage: 'B09 비용요청 반려: ' + expense.title
  });
  return { ok: true, action: 'UPDATE', sheetName: GW_REQUEST_PREFERRED_SHEET_NAME, expenseRequestId: expenseRequestId, expense: expense, approvalStatus: rejected.approval && rejected.approval.approvalStatus };
}

function gwValidateExpensePayload_(payload, approving) {
  if (!gwToSafeText_(payload.title || payload.expenseTitle)) return { ok: false, message: '비용요청 제목은 필수입니다.' };
  var amount = gwNormalizeExpenseAmount_(payload.amount);
  if (amount === '' || isNaN(Number(amount)) || Number(amount) < 0) return { ok: false, message: '비용 금액 형식이 올바르지 않습니다.' };
  var method = gwNormalizeExpensePaymentMethod_(payload.paymentMethod || 'ETC');
  if (GW_EXPENSE_PAYMENT_METHODS.indexOf(method) < 0) return { ok: false, message: '허용되지 않은 결제수단입니다: ' + method };
  if (approving && !gwToSafeText_(payload.receiptFileId)) return { ok: false, message: '증빙 없는 지출은 승인할 수 없습니다.' };
  return { ok: true };
}

function gwBuildExpenseContent_(payload) {
  var lines = [];
  lines.push('EXPENSE_TYPE=' + gwNormalizeExpenseType_(payload.expenseType || 'GENERAL'));
  lines.push('AMOUNT=' + gwNormalizeExpenseAmount_(payload.amount));
  lines.push('PAYMENT_METHOD=' + gwNormalizeExpensePaymentMethod_(payload.paymentMethod || 'ETC'));
  lines.push('RECEIPT_FILE_ID=' + gwToSafeText_(payload.receiptFileId));
  lines.push('MEMO=' + gwToSafeText_(payload.memo || payload.content).slice(0, 1000));
  lines.push('DIRECT_SETTLEMENT_WRITE=FORBIDDEN');
  return lines.join('\n');
}

function gwParseExpenseContent_(content) {
  var result = { expenseType: '', amount: '', paymentMethod: '', receiptFileId: '', memo: '' };
  String(content || '').split(/\n/).forEach(function (line) {
    var idx = line.indexOf('=');
    if (idx < 0) return;
    var key = line.slice(0, idx).trim().toUpperCase();
    var value = line.slice(idx + 1).trim();
    if (key === 'EXPENSE_TYPE') result.expenseType = value;
    if (key === 'AMOUNT') result.amount = value;
    if (key === 'PAYMENT_METHOD') result.paymentMethod = value;
    if (key === 'RECEIPT_FILE_ID') result.receiptFileId = value;
    if (key === 'MEMO') result.memo = value;
  });
  return result;
}

function gwRequestToExpenseRow_(req) {
  req = req || {};
  var parsed = gwParseExpenseContent_(req.content);
  return {
    expenseRequestId: req.requestId,
    requestId: req.requestId,
    employeeId: req.requesterEmployeeId,
    vendorId: req.targetVendorId,
    eventId: req.targetEventId,
    expenseType: parsed.expenseType,
    title: req.title,
    amount: parsed.amount,
    paymentMethod: parsed.paymentMethod,
    receiptFileId: parsed.receiptFileId,
    memo: parsed.memo,
    requestStatus: req.requestStatus,
    statusReason: req.statusReason,
    createdAt: req.createdAt,
    createdBy: req.createdBy,
    updatedAt: req.updatedAt,
    updatedBy: req.updatedBy,
    storageMode: GW_EXPENSE_STORE_MODE,
    _rowNumber: req._rowNumber
  };
}

function gwNormalizeExpenseAmount_(value) {
  var text = gwToSafeText_(value).replace(/,/g, '');
  if (!text) return '';
  var n = Number(text);
  if (isNaN(n)) return text;
  return String(n);
}

function gwNormalizeExpenseType_(value) {
  var text = gwToSafeText_(value).toUpperCase();
  if (!text) return 'GENERAL';
  if (GW_EXPENSE_TYPES.indexOf(text) >= 0) return text;
  return 'GENERAL';
}

function gwNormalizeExpensePaymentMethod_(value) {
  var text = gwToSafeText_(value).toUpperCase();
  if (!text) return 'ETC';
  if (GW_EXPENSE_PAYMENT_METHODS.indexOf(text) >= 0) return text;
  return 'ETC';
}
