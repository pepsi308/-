function gwRunB01Diagnostics(payload) {
  payload = payload || {};
  var checks = [];
  checks.push(gwDiagCheck_('BUILD_INFO', function () { return gwGetBuildInfo(); }));
  checks.push(gwDiagCheck_('SYSTEM_CONFIG_LOAD', function () { return gwGetConfigSnapshotSafe_(); }));
  checks.push(gwDiagCheck_('MASTER_DB_CONNECT', function () {
    var ss = gwGetMasterSpreadsheet_();
    return { spreadsheetName: ss.getName(), spreadsheetId: ss.getId() };
  }));
  checks.push(gwDiagCheck_('PORTAL_USERS_HEADERS', function () { return gwCheckPortalUsersHeaders_(); }));
  checks.push(gwDiagCheck_('FEATURE_FLAGS', function () { return gwGetFeatureFlagSnapshotSafe_(); }));
  checks.push(gwDiagCheck_('MENU_STATE', function () { return gwGetMenusForCurrentUser(); }));
  checks.push(gwDiagCheck_('USER_CONTEXT', function () { return gwGetUserContextSafe_(); }));
  if (payload.writeAudit === true) {
    checks.push(gwDiagCheck_('AUDIT_LOG_WRITE', function () {
      return gwWriteAuditLog_({
        moduleCode: 'GROUPWARE_DIAGNOSTIC',
        actionType: 'B01_DIAGNOSTIC',
        targetId: GW_BUILD_INFO.build,
        resultStatus: 'SUCCESS',
        detailMessage: 'B01 진단 실행'
      });
    }));
  }
  return gwBuildDiagnosticResult_('B01', checks, 'B01 진단 통과', 'B01_DIAGNOSTIC_FAILED', 'B01 진단 중 실패 항목이 있습니다.');
}

function gwRunB02Diagnostics(payload) {
  payload = payload || {};
  var checks = [];
  checks.push(gwDiagCheck_('BUILD_INFO', function () { return gwGetBuildInfo(); }));
  checks.push(gwDiagCheck_('MASTER_DB_CONNECT', function () {
    var ss = gwGetMasterSpreadsheet_();
    return { spreadsheetName: ss.getName(), spreadsheetId: ss.getId() };
  }));
  checks.push(gwDiagCheck_('PORTAL_USERS_HEADERS_READ', function () { return gwCheckPortalUsersHeaders_(); }));
  checks.push(gwDiagCheck_('CURRENT_USER_CONTEXT', function () { return gwGetUserContextSafe_(); }));
  checks.push(gwDiagCheck_('B02_PERMISSION_ASSERT', function () {
    var ctx = gwAssertPermission_('canAccessDevConsole');
    return { ok: true, employeeId: ctx.employeeId, roleCode: ctx.roleCode };
  }));
  checks.push(gwDiagCheck_('B02_META', function () { return gwGetB02UserPermissionMeta_(); }));

  if (payload.ensureHeaders === true || payload.writeTestUser === true) {
    checks.push(gwDiagCheck_('B02_ENSURE_HEADERS', function () {
      return gwEnsurePortalUsersB02Headers_(gwGetPortalUsersSheet_());
    }));
  }

  if (payload.writeTestUser === true) {
    checks.push(gwDiagCheck_('B02_TEST_USER_UPSERT', function () {
      var ctx = gwGetUserContextSafe_();
      return gwSavePortalUser_({
        loginEmail: 'gw-b02-test@feelhaus.local',
        employeeName: 'B02 테스트 직원',
        displayName: 'B02 테스트 직원',
        mobile: '010-0000-0000',
        department: '내부테스트',
        team: 'GROUPWARE',
        position: '테스트',
        roleCode: 'HQ_STAFF',
        roleName: '본사 직원',
        vendorId: '',
        eventId: '',
        status: 'INACTIVE',
        statusReason: 'B02 내부 테스트 계정 - 로그인 사용 금지',
        canAccessPortal: 'N',
        canAccessMail: 'N',
        canSendMail: 'N',
        canAccessCalendar: 'N',
        canCreateCalendarEvent: 'N',
        canAccessSign: 'N',
        canAccessErp: 'N',
        canAccessForm: 'N',
        canAccessControl: 'N',
        canAccessDevConsole: 'N',
        canApprove: 'N',
        canViewLogs: 'N',
        canDownloadFiles: 'N',
        canViewSensitiveInfo: 'N',
        sensitiveAccessYn: 'N',
        downloadAccessYn: 'N',
        unlockAccessYn: 'N',
        reopenAccessYn: 'N',
        recordMode: 'TEST',
        reviewStatus: 'B02_TEST',
        batchTag: 'GROUPWARE_B02_TEST',
        memo: 'B02 내부 테스트 자동 생성/갱신 행입니다.'
      }, ctx, { mode: 'B02_TEST' });
    }));
    checks.push(gwDiagCheck_('B02_DUPLICATE_EMAIL_BLOCK', function () {
      var rows = gwReadRowsAsObjects_(gwGetPortalUsersSheet_());
      var validation = gwValidatePortalUserPayload_({
        loginEmail: 'gw-b02-test@feelhaus.local',
        employeeName: '중복 이메일 테스트',
        roleCode: 'HQ_STAFF',
        employeeId: 'EMP-GW-DUPLICATE-CHECK'
      }, rows, null);
      return { ok: validation.ok === false, blocked: validation.ok === false, message: validation.message };
    }));
  }

  return gwBuildDiagnosticResult_('B02', checks, 'B02 직원관리/권한 엔진 진단 통과', 'B02_DIAGNOSTIC_FAILED', 'B02 진단 중 실패 항목이 있습니다.');
}

function gwRunB03Diagnostics(payload) {
  payload = payload || {};
  var checks = [];
  checks.push(gwDiagCheck_('BUILD_INFO', function () { return gwGetBuildInfo(); }));
  checks.push(gwDiagCheck_('MASTER_DB_CONNECT', function () {
    var ss = gwGetMasterSpreadsheet_();
    return { spreadsheetName: ss.getName(), spreadsheetId: ss.getId() };
  }));
  checks.push(gwDiagCheck_('CURRENT_USER_CONTEXT', function () { return gwGetUserContextSafe_(); }));
  checks.push(gwDiagCheck_('B03_PERMISSION_ASSERT', function () {
    var ctx = gwAssertPermission_('canAccessDevConsole');
    return { ok: true, employeeId: ctx.employeeId, roleCode: ctx.roleCode };
  }));
  checks.push(gwDiagCheck_('B03_META', function () { return gwGetB03NoticeMeta_(); }));

  if (payload.ensureHeaders === true || payload.writeTestNotice === true) {
    checks.push(gwDiagCheck_('B03_ENSURE_NOTICE_HEADERS', function () { return gwEnsureNoticeHeaders_(); }));
    checks.push(gwDiagCheck_('B03_ENSURE_NOTICE_READ_HEADERS', function () { return gwEnsureNoticeReadHeaders_(); }));
  } else {
    checks.push(gwDiagCheck_('B03_NOTICE_HEADERS_READ', function () { return gwInspectNoticeHeadersNoWrite_B03_(); }));
  }

  if (payload.writeTestNotice === true) {
    checks.push(gwDiagCheck_('B03_TEST_NOTICE_UPSERT', function () {
      var ctx = gwGetUserContextSafe_();
      return gwSaveNotice_({
        noticeId: 'NTC-GW-B03-TEST',
        title: 'B03 테스트 공지',
        content: 'B03 공지/게시판 엔진 내부 테스트 공지입니다. 운영 공지가 아니며 삭제 대신 상태 변경 테스트에 사용합니다.',
        noticeType: 'SYSTEM',
        targetRoleCode: 'ALL',
        targetVendorId: 'ALL',
        targetEventId: 'ALL',
        pinnedYn: 'Y',
        displayStartAt: gwNow_(),
        displayEndAt: '',
        attachmentFileIds: '',
        status: 'ACTIVE',
        statusReason: 'B03 내부 테스트 공지'
      }, ctx, { mode: 'B03_TEST' });
    }));
    checks.push(gwDiagCheck_('B03_NOTICE_LIST', function () {
      return gwListNoticesForUi({ includeAll: true, limit: 20 });
    }));
    checks.push(gwDiagCheck_('B03_NOTICE_DETAIL', function () {
      return gwGetNoticeDetailForUi({ noticeId: 'NTC-GW-B03-TEST', markRead: false });
    }));
  }

  return gwBuildDiagnosticResult_('B03', checks, 'B03 공지/게시판 엔진 진단 통과', 'B03_DIAGNOSTIC_FAILED', 'B03 진단 중 실패 항목이 있습니다.');
}


function gwRunB04Diagnostics(payload) {
  payload = payload || {};
  var checks = [];
  checks.push(gwDiagCheck_('BUILD_INFO', function () { return gwGetBuildInfo(); }));
  checks.push(gwDiagCheck_('MASTER_DB_CONNECT', function () {
    var ss = gwGetMasterSpreadsheet_();
    return { spreadsheetName: ss.getName(), spreadsheetId: ss.getId() };
  }));
  checks.push(gwDiagCheck_('CURRENT_USER_CONTEXT', function () { return gwGetUserContextSafe_(); }));
  checks.push(gwDiagCheck_('B04_PERMISSION_ASSERT', function () {
    var ctx = gwAssertPermission_('canAccessDevConsole');
    return { ok: true, employeeId: ctx.employeeId, roleCode: ctx.roleCode };
  }));
  checks.push(gwDiagCheck_('B04_META', function () { return gwGetB04LibraryMeta_(); }));

  if (payload.ensureHeaders === true || payload.writeTestFile === true) {
    checks.push(gwDiagCheck_('B04_ENSURE_LIBRARY_HEADERS', function () { return gwEnsureLibraryHeaders_(); }));
    checks.push(gwDiagCheck_('B04_ENSURE_DOWNLOAD_LOG_HEADERS', function () { return gwEnsureFileDownloadLogHeaders_(); }));
  } else {
    checks.push(gwDiagCheck_('B04_LIBRARY_HEADERS_READ', function () { return gwInspectLibraryHeadersNoWrite_B04_(); }));
  }

  if (payload.writeTestFile === true) {
    checks.push(gwDiagCheck_('B04_TEST_LIBRARY_UPSERT', function () {
      var ctx = gwGetUserContextSafe_();
      return gwSaveLibraryFile_({
        libraryFileId: 'LIB-GW-B04-TEST',
        category: 'SYSTEM',
        title: 'B04 테스트 자료',
        description: 'B04 사내 자료실 엔진 내부 테스트 자료입니다. 실제 Drive 파일이 아니며 Drive fileId 저장 구조 검증용입니다.',
        driveFileId: 'DRIVE_FILE_ID_B04_TEST_ONLY',
        driveFolderId: 'DRIVE_FOLDER_ID_B04_TEST_ONLY',
        fileName: 'B04_TEST_DOCUMENT.pdf',
        fileType: 'application/pdf',
        fileSize: '0',
        targetRoleCode: 'ALL',
        targetVendorId: 'ALL',
        targetEventId: 'ALL',
        downloadAllowedYn: 'Y',
        status: 'ACTIVE',
        statusReason: 'B04 내부 테스트 자료'
      }, ctx, { mode: 'B04_TEST' });
    }));
    checks.push(gwDiagCheck_('B04_LIBRARY_LIST', function () {
      return gwListLibraryFilesForUi({ includeAll: true, limit: 20 });
    }));
    checks.push(gwDiagCheck_('B04_LIBRARY_DETAIL', function () {
      return gwGetLibraryFileDetailForUi({ libraryFileId: 'LIB-GW-B04-TEST' });
    }));
    checks.push(gwDiagCheck_('B04_DOWNLOAD_LOG', function () {
      return gwLogLibraryDownloadForUi({ libraryFileId: 'LIB-GW-B04-TEST', userAgent: 'B04_INTERNAL_TEST' });
    }));
  }

  return gwBuildDiagnosticResult_('B04', checks, 'B04 사내 자료실 엔진 진단 통과', 'B04_DIAGNOSTIC_FAILED', 'B04 진단 중 실패 항목이 있습니다.');
}


function gwRunB05Diagnostics(payload) {
  payload = payload || {};
  var checks = [];
  checks.push(gwDiagCheck_('BUILD_INFO', function () { return gwGetBuildInfo(); }));
  checks.push(gwDiagCheck_('MASTER_DB_CONNECT', function () {
    var ss = gwGetMasterSpreadsheet_();
    return { spreadsheetName: ss.getName(), spreadsheetId: ss.getId() };
  }));
  checks.push(gwDiagCheck_('CURRENT_USER_CONTEXT', function () { return gwGetUserContextSafe_(); }));
  checks.push(gwDiagCheck_('B05_PERMISSION_ASSERT', function () {
    var ctx = gwAssertPermission_('canApprove');
    return { ok: true, employeeId: ctx.employeeId, roleCode: ctx.roleCode };
  }));
  checks.push(gwDiagCheck_('B05_META', function () { return gwGetB05RequestApprovalMeta_(); }));

  if (payload.ensureHeaders === true || payload.writeTestRequest === true) {
    checks.push(gwDiagCheck_('B05_ENSURE_REQUEST_HEADERS', function () { return gwEnsureRequestHeaders_(); }));
    checks.push(gwDiagCheck_('B05_ENSURE_APPROVAL_HEADERS', function () { return gwEnsureApprovalHeaders_(); }));
  } else {
    checks.push(gwDiagCheck_('B05_REQUEST_HEADERS_READ', function () { return gwInspectRequestHeadersNoWrite_B05_(); }));
  }

  if (payload.writeTestRequest === true) {
    checks.push(gwDiagCheck_('B05_TEST_REQUEST_UPSERT', function () {
      var ctx = gwGetUserContextSafe_();
      return gwSaveRequest_({
        requestId: 'REQ-GW-B05-TEST',
        requestType: 'GENERAL',
        title: 'B05 테스트 업무요청',
        content: 'B05 업무요청/전자결재 엔진 내부 테스트 요청입니다. 운영 요청이 아니며 상태전이 검증에 사용합니다.',
        requesterEmployeeId: ctx.employeeId,
        targetEmployeeId: ctx.employeeId,
        targetVendorId: 'ALL',
        targetEventId: 'ALL',
        priority: 'NORMAL',
        requestStatus: 'REQUESTED',
        statusReason: 'B05 내부 테스트 요청',
        approverEmployeeId: ctx.employeeId
      }, ctx, { mode: 'B05_TEST' });
    }));
    checks.push(gwDiagCheck_('B05_REQUEST_LIST', function () {
      return gwListRequestsForUi({ includeAll: true, limit: 20 });
    }));
    checks.push(gwDiagCheck_('B05_REQUEST_DETAIL', function () {
      return gwGetRequestDetailForUi({ requestId: 'REQ-GW-B05-TEST' });
    }));
    checks.push(gwDiagCheck_('B05_APPROVE_REQUEST', function () {
      return gwApproveRequestForUi({ requestId: 'REQ-GW-B05-TEST', approvalComment: 'B05 내부 테스트 승인' });
    }));
  }

  return gwBuildDiagnosticResult_('B05', checks, 'B05 업무요청/전자결재 엔진 진단 통과', 'B05_DIAGNOSTIC_FAILED', 'B05 진단 중 실패 항목이 있습니다.');
}


function gwRunB06Diagnostics(payload) {
  payload = payload || {};
  var checks = [];
  checks.push(gwDiagCheck_('BUILD_INFO', function () { return gwGetBuildInfo(); }));
  checks.push(gwDiagCheck_('MASTER_DB_CONNECT', function () {
    var ss = gwGetMasterSpreadsheet_();
    return { spreadsheetName: ss.getName(), spreadsheetId: ss.getId() };
  }));
  checks.push(gwDiagCheck_('CURRENT_USER_CONTEXT', function () { return gwGetUserContextSafe_(); }));
  checks.push(gwDiagCheck_('B06_PERMISSION_ASSERT', function () {
    var ctx = gwAssertPermission_('canAccessPortal');
    return { ok: true, employeeId: ctx.employeeId, roleCode: ctx.roleCode };
  }));
  checks.push(gwDiagCheck_('B06_META', function () { return gwGetB06AttendanceMeta_(); }));

  if (payload.ensureHeaders === true || payload.writeTestAttendance === true) {
    checks.push(gwDiagCheck_('B06_ENSURE_CAPS_RAW_HEADERS', function () { return gwEnsureCapsRawHeaders_(); }));
    checks.push(gwDiagCheck_('B06_ENSURE_CAPS_MAP_HEADERS', function () { return gwEnsureCapsMapHeaders_(); }));
    checks.push(gwDiagCheck_('B06_ENSURE_ATTENDANCE_HEADERS', function () { return gwEnsureAttendanceHeaders_(); }));
    checks.push(gwDiagCheck_('B06_ENSURE_ATTENDANCE_EXCEPTION_HEADERS', function () { return gwEnsureAttendanceExceptionHeaders_(); }));
  } else {
    checks.push(gwDiagCheck_('B06_ATTENDANCE_HEADERS_READ', function () { return gwInspectAttendanceHeadersNoWrite_B06_(); }));
  }

  if (payload.writeTestAttendance === true) {
    checks.push(gwDiagCheck_('B06_CAPS_TEST_MAP', function () {
      var ctx = gwGetUserContextSafe_();
      return gwEnsureCapsTestMap_(ctx);
    }));
    checks.push(gwDiagCheck_('B06_CAPS_MOCK_SYNC', function () {
      return gwSyncCapsMockForUi({});
    }));
    checks.push(gwDiagCheck_('B06_ATTENDANCE_LIST', function () {
      return gwListAttendanceForUi({ includeAll: true, limit: 20 });
    }));
    checks.push(gwDiagCheck_('B06_EXCEPTION_LIST', function () {
      return gwListAttendanceExceptionsForUi({ includeAll: true, limit: 20 });
    }));
  }

  return gwBuildDiagnosticResult_('B06', checks, 'B06 CAPS 근태 연동 엔진 진단 통과', 'B06_DIAGNOSTIC_FAILED', 'B06 진단 중 실패 항목이 있습니다.');
}


function gwRunB07Diagnostics(payload) {
  payload = payload || {};
  var checks = [];
  checks.push(gwDiagCheck_('BUILD_INFO', function () { return gwGetBuildInfo(); }));
  checks.push(gwDiagCheck_('MASTER_DB_CONNECT', function () {
    var ss = gwGetMasterSpreadsheet_();
    return { spreadsheetName: ss.getName(), spreadsheetId: ss.getId() };
  }));
  checks.push(gwDiagCheck_('CURRENT_USER_CONTEXT', function () { return gwGetUserContextSafe_(); }));
  checks.push(gwDiagCheck_('B07_PERMISSION_ASSERT', function () {
    var ctx = gwAssertPermission_('canApprove');
    return { ok: true, employeeId: ctx.employeeId, roleCode: ctx.roleCode };
  }));
  checks.push(gwDiagCheck_('B07_META', function () { return gwGetB07KpiMeta_(); }));

  if (payload.ensureHeaders === true || payload.writeTestKpi === true) {
    checks.push(gwDiagCheck_('B07_ENSURE_KPI_HEADERS', function () { return gwEnsureKpiHeaders_(); }));
  } else {
    checks.push(gwDiagCheck_('B07_KPI_HEADERS_READ', function () { return gwInspectKpiHeadersNoWrite_B07_(); }));
  }

  if (payload.writeTestKpi === true) {
    checks.push(gwDiagCheck_('B07_TEST_KPI_UPSERT', function () {
      var ctx = gwGetUserContextSafe_();
      return gwSaveKpi_({
        kpiId: 'KPI-GW-B07-TEST',
        employeeId: ctx.employeeId,
        period: '2026-06',
        kpiCategory: 'SYSTEM',
        kpiTitle: 'B07 테스트 KPI',
        targetValue: '100',
        actualValue: '85',
        score: '85',
        evaluatorEmployeeId: ctx.employeeId,
        evaluationComment: 'B07 KPI 엔진 내부 테스트 평가입니다.',
        kpiStatus: 'ACTIVE',
        statusReason: 'B07 내부 테스트 KPI'
      }, ctx, { mode: 'B07_TEST' });
    }));
    checks.push(gwDiagCheck_('B07_KPI_LIST', function () {
      return gwListKpisForUi({ includeAll: true, limit: 20 });
    }));
    checks.push(gwDiagCheck_('B07_KPI_DETAIL', function () {
      return gwGetKpiDetailForUi({ kpiId: 'KPI-GW-B07-TEST' });
    }));
    checks.push(gwDiagCheck_('B07_KPI_EVALUATE', function () {
      var ctx = gwGetUserContextSafe_();
      return gwEvaluateKpi_({
        kpiId: 'KPI-GW-B07-TEST',
        score: '90',
        actualValue: '90',
        evaluationComment: 'B07 내부 테스트 평가 완료',
        statusReason: 'B07 내부 테스트 평가 완료'
      }, ctx, { mode: 'B07_TEST' });
    }));
  }

  return gwBuildDiagnosticResult_('B07', checks, 'B07 직원 KPI/성과관리 엔진 진단 통과', 'B07_DIAGNOSTIC_FAILED', 'B07 진단 중 실패 항목이 있습니다.');
}


function gwRunB08Diagnostics(payload) {
  payload = payload || {};
  var checks = [];
  checks.push(gwDiagCheck_('BUILD_INFO', function () { return gwGetBuildInfo(); }));
  checks.push(gwDiagCheck_('MASTER_DB_CONNECT', function () {
    var ss = gwGetMasterSpreadsheet_();
    return { spreadsheetName: ss.getName(), spreadsheetId: ss.getId() };
  }));
  checks.push(gwDiagCheck_('CURRENT_USER_CONTEXT', function () { return gwGetUserContextSafe_(); }));
  checks.push(gwDiagCheck_('B08_PERMISSION_ASSERT', function () {
    var ctx = gwAssertPermission_('canApprove');
    return { ok: true, employeeId: ctx.employeeId, roleCode: ctx.roleCode };
  }));
  checks.push(gwDiagCheck_('B08_META', function () { return gwGetB08AssetSupplyMeta_(); }));

  if (payload.ensureHeaders === true || payload.writeTestAssetSupply === true) {
    checks.push(gwDiagCheck_('B08_ENSURE_ASSET_HEADERS', function () { return gwEnsureAssetHeaders_(); }));
    checks.push(gwDiagCheck_('B08_ENSURE_SUPPLY_HEADERS', function () { return gwEnsureSupplyHeaders_(); }));
    checks.push(gwDiagCheck_('B08_ENSURE_SUPPLY_REQUEST_HEADERS', function () { return gwEnsureSupplyRequestHeaders_(); }));
  } else {
    checks.push(gwDiagCheck_('B08_ASSET_SUPPLY_HEADERS_READ', function () { return gwInspectAssetSupplyHeadersNoWrite_B08_(); }));
  }

  if (payload.writeTestAssetSupply === true) {
    checks.push(gwDiagCheck_('B08_TEST_ASSET_UPSERT', function () {
      var ctx = gwGetUserContextSafe_();
      return gwSaveAsset_({
        assetId: 'AST-GW-B08-TEST',
        assetCategory: 'SYSTEM',
        assetName: 'B08 테스트 자산',
        serialNo: 'B08-ASSET-TEST-SERIAL',
        assignedEmployeeId: ctx.employeeId,
        assignedVendorId: '',
        purchaseDate: '2026-06-07',
        assetStatus: 'ASSIGNED',
        location: 'GROUPWARE_TEST',
        memo: 'B08 총무/자산/비품 엔진 내부 테스트 자산입니다.',
        statusReason: 'B08 내부 테스트 자산'
      }, ctx, { mode: 'B08_TEST' });
    }));
    checks.push(gwDiagCheck_('B08_TEST_SUPPLY_UPSERT', function () {
      var ctx = gwGetUserContextSafe_();
      return gwSaveSupply_({
        supplyId: 'SUP-GW-B08-TEST',
        supplyName: 'B08 테스트 비품',
        category: 'SYSTEM',
        stockQty: '20',
        minQty: '5',
        location: 'GROUPWARE_TEST',
        status: 'ACTIVE',
        statusReason: 'B08 내부 테스트 비품'
      }, ctx, { mode: 'B08_TEST' });
    }));
    checks.push(gwDiagCheck_('B08_TEST_SUPPLY_REQUEST_UPSERT', function () {
      var ctx = gwGetUserContextSafe_();
      return gwSaveSupplyRequest_({
        supplyRequestId: 'SUPREQ-GW-B08-TEST',
        employeeId: ctx.employeeId,
        supplyId: 'SUP-GW-B08-TEST',
        requestQty: '2',
        requestStatus: 'REQUESTED',
        statusReason: 'B08 내부 테스트 비품 요청'
      }, ctx, { mode: 'B08_TEST' });
    }));
    checks.push(gwDiagCheck_('B08_ASSET_LIST', function () {
      return gwListAssetsForUi({ includeAll: true, limit: 20 });
    }));
    checks.push(gwDiagCheck_('B08_SUPPLY_LIST', function () {
      return gwListSuppliesForUi({ limit: 20 });
    }));
    checks.push(gwDiagCheck_('B08_SUPPLY_REQUEST_LIST', function () {
      return gwListSupplyRequestsForUi({ includeAll: true, limit: 20 });
    }));
    checks.push(gwDiagCheck_('B08_ASSET_DETAIL', function () {
      return gwGetAssetDetailForUi({ assetId: 'AST-GW-B08-TEST' });
    }));
    checks.push(gwDiagCheck_('B08_SUPPLY_DETAIL', function () {
      return gwGetSupplyDetailForUi({ supplyId: 'SUP-GW-B08-TEST' });
    }));
    checks.push(gwDiagCheck_('B08_SUPPLY_REQUEST_DETAIL', function () {
      return gwGetSupplyRequestDetailForUi({ supplyRequestId: 'SUPREQ-GW-B08-TEST' });
    }));
    checks.push(gwDiagCheck_('B08_APPROVE_SUPPLY_REQUEST', function () {
      var ctx = gwGetUserContextSafe_();
      return gwApproveSupplyRequest_({
        supplyRequestId: 'SUPREQ-GW-B08-TEST',
        statusReason: 'B08 내부 테스트 비품 요청 승인'
      }, ctx, { mode: 'B08_TEST' });
    }));
  }

  return gwBuildDiagnosticResult_('B08', checks, 'B08 총무/자산/비품 엔진 진단 통과', 'B08_DIAGNOSTIC_FAILED', 'B08 진단 중 실패 항목이 있습니다.');
}

function gwBuildDiagnosticResult_(label, checks, okMessage, failCode, failMessage) {
  var fatal = checks.filter(function (c) { return !c.ok; });
  var result = {
    buildInfo: gwGetBuildInfo(),
    checkedAt: gwNow_(),
    ok: fatal.length === 0,
    fatalCount: fatal.length,
    checks: checks
  };
  return result.ok ? gwOk_(result, okMessage) : gwFail_(failCode, failMessage, result);
}

function gwDiagCheck_(name, fn) {
  try {
    var data = fn();
    var ok = data && typeof data.ok !== 'undefined' ? !!data.ok : true;
    return { name: name, ok: ok, data: data, message: ok ? 'OK' : 'CHECK_FAILED' };
  } catch (err) {
    return { name: name, ok: false, message: gwErrorMessage_(err), stack: gwErrorStack_(err) };
  }
}

function gwRunB09Diagnostics(payload) {
  payload = payload || {};
  var checks = [];
  checks.push(gwDiagCheck_('BUILD_INFO', function () { return gwGetBuildInfo(); }));
  checks.push(gwDiagCheck_('MASTER_DB_CONNECT', function () {
    var ss = gwGetMasterSpreadsheet_();
    return { spreadsheetName: ss.getName(), spreadsheetId: ss.getId() };
  }));
  checks.push(gwDiagCheck_('CURRENT_USER_CONTEXT', function () { return gwGetUserContextSafe_(); }));
  checks.push(gwDiagCheck_('B09_PERMISSION_ASSERT', function () {
    var ctx = gwAssertPermission_('canApprove');
    return { ok: true, employeeId: ctx.employeeId, roleCode: ctx.roleCode };
  }));
  checks.push(gwDiagCheck_('B09_META', function () { return gwGetB09ExpenseMeta_(); }));

  if (payload.ensureHeaders === true || payload.writeTestExpense === true) {
    checks.push(gwDiagCheck_('B09_ENSURE_EXPENSE_HEADERS', function () { return gwEnsureExpenseHeaders_(); }));
  } else {
    checks.push(gwDiagCheck_('B09_EXPENSE_HEADERS_READ', function () { return gwInspectExpenseHeadersNoWrite_B09_(); }));
  }

  if (payload.writeTestExpense === true) {
    checks.push(gwDiagCheck_('B09_TEST_EXPENSE_UPSERT', function () {
      var ctx = gwGetUserContextSafe_();
      return gwSaveExpense_({
        expenseRequestId: 'EXP-GW-B09-TEST',
        employeeId: ctx.employeeId,
        vendorId: '',
        eventId: '',
        expenseType: 'SYSTEM',
        title: 'B09 테스트 비용요청',
        amount: '12000',
        paymentMethod: 'COMPANY_CARD',
        receiptFileId: 'DRIVE-FILE-ID-B09-TEST',
        memo: 'B09 구매/지출/비용 엔진 내부 테스트 비용요청입니다.',
        requestStatus: 'REQUESTED',
        statusReason: 'B09 내부 테스트 비용요청'
      }, ctx, { mode: 'B09_TEST' });
    }));
    checks.push(gwDiagCheck_('B09_EXPENSE_LIST', function () {
      return gwListExpensesForUi({ includeAll: true, limit: 20 });
    }));
    checks.push(gwDiagCheck_('B09_EXPENSE_DETAIL', function () {
      return gwGetExpenseDetailForUi({ expenseRequestId: 'EXP-GW-B09-TEST' });
    }));
    checks.push(gwDiagCheck_('B09_APPROVE_EXPENSE', function () {
      var ctx = gwGetUserContextSafe_();
      return gwApproveExpense_({
        expenseRequestId: 'EXP-GW-B09-TEST',
        statusReason: 'B09 내부 테스트 비용요청 승인'
      }, ctx, { mode: 'B09_TEST' });
    }));
  }

  return gwBuildDiagnosticResult_('B09', checks, 'B09 구매/지출/비용 엔진 진단 통과', 'B09_DIAGNOSTIC_FAILED', 'B09 진단 중 실패 항목이 있습니다.');
}

function gwRunB10Diagnostics(payload) {
  payload = payload || {};
  var checks = [];
  checks.push(gwDiagCheck_('BUILD_INFO', function () { return gwGetBuildInfo(); }));
  checks.push(gwDiagCheck_('MASTER_DB_CONNECT', function () {
    var ss = gwGetMasterSpreadsheet_();
    return { spreadsheetName: ss.getName(), spreadsheetId: ss.getId() };
  }));
  checks.push(gwDiagCheck_('CURRENT_USER_CONTEXT', function () { return gwGetUserContextSafe_(); }));
  checks.push(gwDiagCheck_('B10_PERMISSION_ASSERT', function () {
    var ctx = gwAssertPermission_('canAccessDevConsole');
    return { ok: true, employeeId: ctx.employeeId, roleCode: ctx.roleCode };
  }));
  checks.push(gwDiagCheck_('B10_META', function () { return gwGetB10PortalImportMeta_(); }));
  checks.push(gwDiagCheck_('B10_IMPORT_CANDIDATES', function () { return gwInspectB10ImportCandidates_(); }));
  checks.push(gwDiagCheck_('B10_SHEET_READINESS', function () { return gwInspectB10SheetReadiness_(); }));
  checks.push(gwDiagCheck_('B10_PORTAL_IMPORT_PLAN', function () { return gwInspectB10PortalImportPlan_(); }));
  if (payload.runRegression === true) {
    checks.push(gwDiagCheck_('B10_NO_WRITE_REGRESSION', function () { return gwRunB10NoWriteRegression_(); }));
  }
  if (payload.writeAudit === true) {
    checks.push(gwDiagCheck_('B10_AUDIT_LOG', function () {
      return gwWriteB10ImportCandidateAudit_(gwGetUserContextSafe_());
    }));
  }
  return gwBuildDiagnosticResult_('B10', checks, 'B10 PORTAL 본문 이관 후보 진단 통과', 'B10_DIAGNOSTIC_FAILED', 'B10 진단 중 실패 항목이 있습니다.');
}

function gwRunB11Diagnostics(payload) {
  payload = payload || {};
  var checks = [];
  checks.push(gwDiagCheck_('BUILD_INFO', function () { return gwGetBuildInfo(); }));
  checks.push(gwDiagCheck_('MASTER_DB_CONNECT', function () {
    var ss = gwGetMasterSpreadsheet_();
    return { spreadsheetName: ss.getName(), spreadsheetId: ss.getId() };
  }));
  checks.push(gwDiagCheck_('CURRENT_USER_CONTEXT', function () { return gwGetUserContextSafe_(); }));
  checks.push(gwDiagCheck_('B11_PERMISSION_ASSERT', function () {
    var ctx = gwAssertPermission_('canAccessDevConsole');
    return { ok: true, employeeId: ctx.employeeId, roleCode: ctx.roleCode };
  }));
  checks.push(gwDiagCheck_('B11_PORTAL_CONTRACTS', function () {
    var contracts = gwGetPortalMenuContracts_B11();
    return {
      ok: true,
      moduleCode: GW_B11_MODULE_CODE,
      menuContractCount: contracts.length,
      readyCount: contracts.filter(function (r) { return r.status === 'READY'; }).length,
      preparingCount: contracts.filter(function (r) { return r.status === 'PREPARING'; }).length,
      firstMenuId: contracts.length ? contracts[0].menuId : ''
    };
  }));
  checks.push(gwDiagCheck_('B11_BODY_RESPONSIBILITIES', function () {
    var bodies = gwGetBodyResponsibilityContracts_B11();
    return {
      ok: true,
      bodyResponsibilityCount: bodies.length,
      callCount: bodies.reduce(function (sum, b) { return sum + ((b.calls || []).length); }, 0),
      sheetRefCount: bodies.reduce(function (sum, b) { return sum + ((b.sheets || []).length); }, 0)
    };
  }));
  checks.push(gwDiagCheck_('B11_PROTECTED_ASSETS', function () {
    var assets = gwGetProtectedAssets_B11();
    return {
      ok: true,
      centralRegistryCount: assets.centralRegistries.length,
      protectedSheetCount: assets.protectedSheets.length,
      protectedEngineCount: assets.protectedEngines.length,
      forbiddenArtifactCount: assets.forbiddenArtifacts.length
    };
  }));
  checks.push(gwDiagCheck_('B11_FORBIDDEN_UI_POLICY', function () { return gwGetForbiddenUiPolicy_B11(); }));
  checks.push(gwDiagCheck_('B11_NO_STANDALONE_ARTIFACTS', function () { return gwCheckNoStandaloneArtifacts_B11(); }));
  checks.push(gwDiagCheck_('B11_CONTRACT_VALIDATE', function () { return gwValidatePortalContracts_B11(payload); }));
  if (payload.writeAudit === true) {
    checks.push(gwDiagCheck_('B11_AUDIT_LOG', function () { return gwWriteB11ContractAudit_(gwGetUserContextSafe_()); }));
  }
  return gwBuildDiagnosticResult_('B11', checks, 'B11 PORTAL 계약/본문 구조 베이스 진단 통과', 'B11_DIAGNOSTIC_FAILED', 'B11 진단 중 실패 항목이 있습니다.');
}

function gwRunB12Diagnostics(payload) {
  payload = payload || {};
  var checks = [];
  checks.push(gwDiagCheck_('BUILD_INFO', function () { return gwGetBuildInfo(); }));
  checks.push(gwDiagCheck_('MASTER_DB_CONNECT', function () {
    var ss = gwGetMasterSpreadsheet_();
    return { spreadsheetName: ss.getName(), spreadsheetId: ss.getId() };
  }));
  checks.push(gwDiagCheck_('CURRENT_USER_CONTEXT', function () { return gwGetUserContextSafe_(); }));
  checks.push(gwDiagCheck_('B12_PERMISSION_ASSERT', function () {
    var ctx = gwAssertPermission_('canAccessDevConsole');
    return { ok: true, employeeId: ctx.employeeId, roleCode: ctx.roleCode };
  }));
  checks.push(gwDiagCheck_('B12_BODY_SPECS', function () {
    var specs = gwGetB12BodySpecs();
    return {
      ok: true,
      buildStep: '12/20',
      bodySpecCount: specs.length,
      screenIds: specs.map(function (s) { return s.screenId; }),
      routeCount: specs.map(function (s) { return s.route; }).length,
      portalShellOnly: true
    };
  }));
  checks.push(gwDiagCheck_('B12_BODY_CONTRACT_VALIDATE', function () { return gwValidateB12BodyContracts(payload); }));
  checks.push(gwDiagCheck_('B12_USERS_BODY_RENDER', function () {
    var result = gwHandleUsersBody({ limit: payload.limit || 10, query: payload.query || '' });
    if (!result.ok) return result;
    return {
      ok: true,
      screenId: result.data.screenId,
      title: result.data.title,
      rowCount: result.data.list.totalReturned,
      actionCount: result.data.actions.length,
      apiCallCount: result.data.apiCalls.length,
      htmlLength: result.data.bodyHtml.length,
      bodyAudit: result.data.bodyAudit
    };
  }));
  checks.push(gwDiagCheck_('B12_PERMISSIONS_BODY_RENDER', function () {
    var result = gwHandlePermissionsBody({ limit: payload.limit || 10, query: payload.query || '' });
    if (!result.ok) return result;
    return {
      ok: true,
      screenId: result.data.screenId,
      title: result.data.title,
      rowCount: result.data.list.totalReturned,
      actionCount: result.data.actions.length,
      apiCallCount: result.data.apiCalls.length,
      permissionFieldCount: result.data.form.permissionFields.length,
      htmlLength: result.data.bodyHtml.length,
      bodyAudit: result.data.bodyAudit
    };
  }));
  checks.push(gwDiagCheck_('B12_API_HANDLER_MAP', function () {
    var users = gwApi('handleUsersBody', { limit: 5 });
    var permissions = gwApi('handlePermissionsBody', { limit: 5 });
    return {
      ok: users.ok === true && permissions.ok === true,
      usersHandlerOk: users.ok === true,
      permissionsHandlerOk: permissions.ok === true,
      usersMessage: users.message,
      permissionsMessage: permissions.message
    };
  }));
  if (payload.writeAudit === true) {
    checks.push(gwDiagCheck_('B12_AUDIT_LOG', function () {
      return gwWriteAuditLog_({
        moduleCode: 'GROUPWARE_PORTAL_BODY_UI',
        actionType: 'B12_USERS_PERMISSION_BODY_UI_DIAGNOSTIC',
        targetId: GW_BUILD_INFO.build,
        resultStatus: 'SUCCESS',
        detailMessage: 'B12 직원관리/권한관리 PORTAL 본문 UI 진단 실행',
        employeeId: gwGetUserContextSafe_().employeeId
      });
    }));
  }
  return gwBuildDiagnosticResult_('B12', checks, 'B12 직원관리/권한관리 PORTAL 본문 UI 진단 통과', 'B12_DIAGNOSTIC_FAILED', 'B12 진단 중 실패 항목이 있습니다.');
}


function gwRunB13Diagnostics(payload) {
  payload = payload || {};
  var checks = [];
  checks.push(gwDiagCheck_('BUILD_INFO', function () { return gwGetBuildInfo(); }));
  checks.push(gwDiagCheck_('MASTER_DB_CONNECT', function () {
    var ss = gwGetMasterSpreadsheet_();
    return { spreadsheetName: ss.getName(), spreadsheetId: ss.getId() };
  }));
  checks.push(gwDiagCheck_('CURRENT_USER_CONTEXT', function () { return gwGetUserContextSafe_(); }));
  checks.push(gwDiagCheck_('B13_PERMISSION_ASSERT', function () {
    var ctx = gwAssertPermission_('canAccessPortal');
    return { ok: true, employeeId: ctx.employeeId, roleCode: ctx.roleCode };
  }));
  checks.push(gwDiagCheck_('B13_BODY_SPECS', function () {
    var specs = gwGetB13BodySpecs();
    return {
      ok: true,
      buildStep: '13/20',
      bodySpecCount: specs.length,
      screenIds: specs.map(function (s) { return s.screenId; }),
      routeCount: specs.map(function (s) { return s.route; }).length,
      portalShellOnly: true
    };
  }));
  checks.push(gwDiagCheck_('B13_BODY_CONTRACT_VALIDATE', function () { return gwValidateB13BodyContracts(payload); }));
  checks.push(gwDiagCheck_('B13_NOTICE_BODY_RENDER', function () {
    var result = gwHandleNoticeBoardBody({ limit: payload.limit || 10, query: payload.query || '', includeAll: true });
    if (!result.ok) return result;
    return {
      ok: true,
      screenId: result.data.screenId,
      title: result.data.title,
      rowCount: result.data.list.totalReturned,
      actionCount: result.data.actions.length,
      apiCallCount: result.data.apiCalls.length,
      htmlLength: result.data.bodyHtml.length,
      bodyAudit: result.data.bodyAudit
    };
  }));
  checks.push(gwDiagCheck_('B13_API_HANDLER_MAP', function () {
    var notice = gwApi('handleNoticeBoardBody', { limit: 5, includeAll: true });
    return {
      ok: notice.ok === true,
      noticeHandlerOk: notice.ok === true,
      noticeMessage: notice.message
    };
  }));
  if (payload.writeAudit === true) {
    checks.push(gwDiagCheck_('B13_AUDIT_LOG', function () {
      return gwWriteAuditLog_({
        moduleCode: 'GROUPWARE_PORTAL_BODY_UI',
        actionType: 'B13_NOTICE_BOARD_BODY_UI_DIAGNOSTIC',
        targetId: GW_BUILD_INFO.build,
        resultStatus: 'SUCCESS',
        detailMessage: 'B13 공지/게시판 PORTAL 본문 UI 진단 실행',
        employeeId: gwGetUserContextSafe_().employeeId
      });
    }));
  }
  return gwBuildDiagnosticResult_('B13', checks, 'B13 공지/게시판 PORTAL 본문 UI 진단 통과', 'B13_DIAGNOSTIC_FAILED', 'B13 진단 중 실패 항목이 있습니다.');
}

function gwRunB14Diagnostics(payload) {
  payload = payload || {};
  var checks = [];
  checks.push(gwDiagCheck_('BUILD_INFO', function () { return gwGetBuildInfo(); }));
  checks.push(gwDiagCheck_('MASTER_DB_CONNECT', function () {
    var ss = gwGetMasterSpreadsheet_();
    return { spreadsheetName: ss.getName(), spreadsheetId: ss.getId() };
  }));
  checks.push(gwDiagCheck_('CURRENT_USER_CONTEXT', function () { return gwGetUserContextSafe_(); }));
  checks.push(gwDiagCheck_('B14_PERMISSION_ASSERT', function () {
    var ctx = gwAssertPermission_('canAccessPortal');
    return { ok: true, employeeId: ctx.employeeId, roleCode: ctx.roleCode };
  }));
  checks.push(gwDiagCheck_('B14_BODY_SPECS', function () {
    var specs = gwGetB14BodySpecs();
    return {
      ok: true,
      buildStep: '14/20',
      bodySpecCount: specs.length,
      screenIds: specs.map(function (s) { return s.screenId; }),
      routeCount: specs.map(function (s) { return s.route; }).length,
      portalShellOnly: true
    };
  }));
  checks.push(gwDiagCheck_('B14_BODY_CONTRACT_VALIDATE', function () { return gwValidateB14BodyContracts(payload); }));
  checks.push(gwDiagCheck_('B14_LIBRARY_BODY_RENDER', function () {
    var result = gwHandleDocLibraryBody({ limit: payload.limit || 10, query: payload.query || '', category: payload.category || 'ALL', includeAll: true });
    if (!result.ok) return result;
    return {
      ok: true,
      screenId: result.data.screenId,
      title: result.data.title,
      rowCount: result.data.list.totalReturned,
      actionCount: result.data.actions.length,
      apiCallCount: result.data.apiCalls.length,
      htmlLength: result.data.bodyHtml.length,
      bodyAudit: result.data.bodyAudit
    };
  }));
  checks.push(gwDiagCheck_('B14_API_HANDLER_MAP', function () {
    var library = gwApi('handleDocLibraryBody', { limit: 5, includeAll: true });
    return {
      ok: library.ok === true,
      libraryHandlerOk: library.ok === true,
      libraryMessage: library.message
    };
  }));
  if (payload.writeAudit === true) {
    checks.push(gwDiagCheck_('B14_AUDIT_LOG', function () {
      return gwWriteAuditLog_({
        moduleCode: 'GROUPWARE_PORTAL_BODY_UI',
        actionType: 'B14_DOC_LIBRARY_BODY_UI_DIAGNOSTIC',
        targetId: GW_BUILD_INFO.build,
        resultStatus: 'SUCCESS',
        detailMessage: 'B14 사내 자료실 PORTAL 본문 UI 진단 실행',
        employeeId: gwGetUserContextSafe_().employeeId
      });
    }));
  }
  return gwBuildDiagnosticResult_('B14', checks, 'B14 사내 자료실 PORTAL 본문 UI 진단 통과', 'B14_DIAGNOSTIC_FAILED', 'B14 진단 중 실패 항목이 있습니다.');
}

function gwRunB15Diagnostics(payload) {
  payload = payload || {};
  var checks = [];
  checks.push(gwDiagCheck_('BUILD_INFO', function () { return gwGetBuildInfo(); }));
  checks.push(gwDiagCheck_('MASTER_DB_CONNECT', function () {
    var ss = gwGetMasterSpreadsheet_();
    return { spreadsheetName: ss.getName(), spreadsheetId: ss.getId() };
  }));
  checks.push(gwDiagCheck_('CURRENT_USER_CONTEXT', function () { return gwGetUserContextSafe_(); }));
  checks.push(gwDiagCheck_('B15_PERMISSION_ASSERT', function () {
    var ctx = gwAssertPermission_('canAccessPortal');
    return { ok: true, employeeId: ctx.employeeId, roleCode: ctx.roleCode };
  }));
  checks.push(gwDiagCheck_('B15_BODY_SPECS', function () {
    var specs = gwGetB15BodySpecs();
    return {
      ok: true,
      buildStep: '15/20',
      bodySpecCount: specs.length,
      screenIds: specs.map(function (s) { return s.screenId; }),
      routeCount: specs.map(function (s) { return s.route; }).length,
      portalShellOnly: true
    };
  }));
  checks.push(gwDiagCheck_('B15_BODY_CONTRACT_VALIDATE', function () { return gwValidateB15BodyContracts(payload); }));
  checks.push(gwDiagCheck_('B15_REQUEST_BODY_RENDER', function () {
    var result = gwHandleRequestsBody({
      limit: payload.limit || 10,
      query: payload.query || '',
      requestStatus: payload.requestStatus || 'ALL',
      requestType: payload.requestType || 'ALL',
      includeAll: true
    });
    if (!result.ok) return result;
    return {
      ok: true,
      screenId: result.data.screenId,
      title: result.data.title,
      rowCount: result.data.list.totalReturned,
      approvalCount: result.data.approvals.totalReturned,
      actionCount: result.data.actions.length,
      apiCallCount: result.data.apiCalls.length,
      htmlLength: result.data.bodyHtml.length,
      bodyAudit: result.data.bodyAudit
    };
  }));
  checks.push(gwDiagCheck_('B15_API_HANDLER_MAP', function () {
    var requests = gwApi('handleRequestsBody', { limit: 5, includeAll: true, requestStatus: 'ALL', requestType: 'ALL' });
    return {
      ok: requests.ok === true,
      requestsHandlerOk: requests.ok === true,
      requestsMessage: requests.message
    };
  }));
  if (payload.writeAudit === true) {
    checks.push(gwDiagCheck_('B15_AUDIT_LOG', function () {
      return gwWriteAuditLog_({
        moduleCode: 'GROUPWARE_PORTAL_BODY_UI',
        actionType: 'B15_REQUEST_APPROVAL_BODY_UI_DIAGNOSTIC',
        targetId: GW_BUILD_INFO.build,
        resultStatus: 'SUCCESS',
        detailMessage: 'B15 업무요청/전자결재 PORTAL 본문 UI 진단 실행',
        employeeId: gwGetUserContextSafe_().employeeId
      });
    }));
  }
  return gwBuildDiagnosticResult_('B15', checks, 'B15 업무요청/전자결재 PORTAL 본문 UI 진단 통과', 'B15_DIAGNOSTIC_FAILED', 'B15 진단 중 실패 항목이 있습니다.');
}


function gwRunB16Diagnostics(payload) {
  payload = payload || {};
  var checks = [];
  checks.push(gwDiagCheck_('BUILD_INFO', function () { return gwGetBuildInfo(); }));
  checks.push(gwDiagCheck_('MASTER_DB_CONNECT', function () {
    var ss = gwGetMasterSpreadsheet_();
    return { spreadsheetName: ss.getName(), spreadsheetId: ss.getId() };
  }));
  checks.push(gwDiagCheck_('CURRENT_USER_CONTEXT', function () { return gwGetUserContextSafe_(); }));
  checks.push(gwDiagCheck_('B16_PERMISSION_ASSERT', function () {
    var ctx = gwAssertPermission_('canAccessPortal');
    return { ok: true, employeeId: ctx.employeeId, roleCode: ctx.roleCode };
  }));
  checks.push(gwDiagCheck_('B16_BODY_SPECS', function () {
    var specs = gwGetB16BodySpecs();
    return {
      ok: true,
      buildStep: '16/20',
      bodySpecCount: specs.length,
      screenIds: specs.map(function (s) { return s.screenId; }),
      routeCount: specs.map(function (s) { return s.route; }).length,
      portalShellOnly: true
    };
  }));
  checks.push(gwDiagCheck_('B16_BODY_CONTRACT_VALIDATE', function () { return gwValidateB16BodyContracts(payload); }));
  checks.push(gwDiagCheck_('B16_ATTENDANCE_CAPS_BODY_RENDER', function () {
    var result = gwHandleCapsAttendanceBody({ limit: payload.limit || 10, includeAll: true });
    if (!result.ok) return result;
    return gwBuildB16BodyRenderSummary_('caps', result.data);
  }));
  checks.push(gwDiagCheck_('B16_MY_ATTENDANCE_BODY_RENDER', function () {
    var result = gwHandleMyAttendanceBody({ limit: payload.limit || 10 });
    if (!result.ok) return result;
    return gwBuildB16BodyRenderSummary_('mine', result.data);
  }));
  checks.push(gwDiagCheck_('B16_ATTENDANCE_ADMIN_BODY_RENDER', function () {
    var result = gwHandleAttendanceAdminBody({ limit: payload.limit || 10, includeAll: true });
    if (!result.ok) return result;
    return gwBuildB16BodyRenderSummary_('admin', result.data);
  }));
  checks.push(gwDiagCheck_('B16_ATTENDANCE_EXCEPTIONS_BODY_RENDER', function () {
    var result = gwHandleAttendanceExceptionsBody({ limit: payload.limit || 10, includeAll: true });
    if (!result.ok) return result;
    return gwBuildB16BodyRenderSummary_('exceptions', result.data);
  }));
  checks.push(gwDiagCheck_('B16_API_HANDLER_MAP', function () {
    var caps = gwApi('handleCapsAttendanceBody', { limit: 5, includeAll: true });
    var mine = gwApi('handleMyAttendanceBody', { limit: 5 });
    var admin = gwApi('handleAttendanceAdminBody', { limit: 5, includeAll: true });
    var exceptions = gwApi('handleAttendanceExceptionsBody', { limit: 5, includeAll: true });
    return {
      ok: caps.ok === true && mine.ok === true && admin.ok === true && exceptions.ok === true,
      capsHandlerOk: caps.ok === true,
      myHandlerOk: mine.ok === true,
      adminHandlerOk: admin.ok === true,
      exceptionsHandlerOk: exceptions.ok === true,
      capsMessage: caps.message,
      myMessage: mine.message,
      adminMessage: admin.message,
      exceptionsMessage: exceptions.message
    };
  }));
  if (payload.writeAudit === true) {
    checks.push(gwDiagCheck_('B16_AUDIT_LOG', function () {
      return gwWriteAuditLog_({
        moduleCode: 'GROUPWARE_PORTAL_BODY_UI',
        actionType: 'B16_CAPS_ATTENDANCE_BODY_UI_DIAGNOSTIC',
        targetId: GW_BUILD_INFO.build,
        resultStatus: 'SUCCESS',
        detailMessage: 'B16 CAPS 근태 PORTAL 본문 UI 진단 실행',
        employeeId: gwGetUserContextSafe_().employeeId
      });
    }));
  }
  return gwBuildDiagnosticResult_('B16', checks, 'B16 CAPS 근태 PORTAL 본문 UI 진단 통과', 'B16_DIAGNOSTIC_FAILED', 'B16 진단 중 실패 항목이 있습니다.');
}

function gwBuildB16BodyRenderSummary_(kind, data) {
  return {
    ok: data.bodyAudit && data.bodyAudit.ok === true,
    kind: kind,
    screenId: data.screenId,
    title: data.title,
    attendanceCount: data.attendanceList ? data.attendanceList.totalReturned : 0,
    exceptionCount: data.exceptionList ? data.exceptionList.totalReturned : 0,
    rawCount: data.rawList ? data.rawList.totalReturned : 0,
    actionCount: data.actions ? data.actions.length : 0,
    apiCallCount: data.apiCalls ? data.apiCalls.length : 0,
    htmlLength: data.bodyHtml ? data.bodyHtml.length : 0,
    bodyAudit: data.bodyAudit
  };
}

function gwRunB17Diagnostics(payload) {
  payload = payload || {};
  var checks = [];
  checks.push(gwDiagCheck_('BUILD_INFO', function () { return gwGetBuildInfo(); }));
  checks.push(gwDiagCheck_('MASTER_DB_CONNECT', function () {
    var ss = gwGetMasterSpreadsheet_();
    return { spreadsheetName: ss.getName(), spreadsheetId: ss.getId() };
  }));
  checks.push(gwDiagCheck_('CURRENT_USER_CONTEXT', function () { return gwGetUserContextSafe_(); }));
  checks.push(gwDiagCheck_('B17_PERMISSION_ASSERT', function () {
    var ctx = gwAssertPermission_('canAccessPortal');
    return { ok: true, employeeId: ctx.employeeId, roleCode: ctx.roleCode };
  }));
  checks.push(gwDiagCheck_('B17_BODY_SPECS', function () {
    var specs = gwGetB17BodySpecs();
    return {
      ok: true,
      buildStep: '17/20',
      bodySpecCount: specs.length,
      screenIds: specs.map(function (s) { return s.screenId; }),
      routeCount: specs.map(function (s) { return s.route; }).length,
      portalShellOnly: true
    };
  }));
  checks.push(gwDiagCheck_('B17_BODY_CONTRACT_VALIDATE', function () { return gwValidateB17BodyContracts(payload); }));
  checks.push(gwDiagCheck_('B17_KPI_BODY_RENDER', function () {
    var result = gwHandleKpiBody({ limit: payload.limit || 10, includeAll: true, kpiStatus: 'ALL', kpiCategory: 'ALL' });
    if (!result.ok) return result;
    return gwBuildB17BodyRenderSummary_('kpi', result.data);
  }));
  checks.push(gwDiagCheck_('B17_ASSET_SUPPLY_BODY_RENDER', function () {
    var result = gwHandleAssetSupplyBody({ limit: payload.limit || 10, includeAll: true, assetStatus: 'ALL', supplyStatus: 'ALL' });
    if (!result.ok) return result;
    return gwBuildB17BodyRenderSummary_('assetSupply', result.data);
  }));
  checks.push(gwDiagCheck_('B17_SUPPLY_REQUEST_BODY_RENDER', function () {
    var result = gwHandleSupplyRequestBody({ limit: payload.limit || 10, includeAll: true, requestStatus: 'ALL' });
    if (!result.ok) return result;
    return gwBuildB17BodyRenderSummary_('supplyRequest', result.data);
  }));
  checks.push(gwDiagCheck_('B17_EXPENSE_BODY_RENDER', function () {
    var result = gwHandleExpenseBody({ limit: payload.limit || 10, includeAll: true, requestStatus: 'ALL' });
    if (!result.ok) return result;
    return gwBuildB17BodyRenderSummary_('expense', result.data);
  }));
  checks.push(gwDiagCheck_('B17_API_HANDLER_MAP', function () {
    var kpi = gwApi('handleKpiBody', { limit: 5, includeAll: true });
    var asset = gwApi('handleAssetSupplyBody', { limit: 5, includeAll: true });
    var supplyRequest = gwApi('handleSupplyRequestBody', { limit: 5, includeAll: true });
    var expense = gwApi('handleExpenseBody', { limit: 5, includeAll: true });
    return {
      ok: kpi.ok === true && asset.ok === true && supplyRequest.ok === true && expense.ok === true,
      kpiHandlerOk: kpi.ok === true,
      assetHandlerOk: asset.ok === true,
      supplyRequestHandlerOk: supplyRequest.ok === true,
      expenseHandlerOk: expense.ok === true,
      kpiMessage: kpi.message,
      assetMessage: asset.message,
      supplyRequestMessage: supplyRequest.message,
      expenseMessage: expense.message
    };
  }));
  if (payload.writeAudit === true) {
    checks.push(gwDiagCheck_('B17_AUDIT_LOG', function () {
      return gwWriteAuditLog_({
        moduleCode: 'GROUPWARE_PORTAL_BODY_UI',
        actionType: 'B17_MANAGEMENT_MODULES_BODY_UI_DIAGNOSTIC',
        targetId: GW_BUILD_INFO.build,
        resultStatus: 'SUCCESS',
        detailMessage: 'B17 KPI/자산/비품/비용 PORTAL 본문 UI 진단 실행',
        employeeId: gwGetUserContextSafe_().employeeId
      });
    }));
  }
  return gwBuildDiagnosticResult_('B17', checks, 'B17 KPI/자산/비품/비용 PORTAL 본문 UI 진단 통과', 'B17_DIAGNOSTIC_FAILED', 'B17 진단 중 실패 항목이 있습니다.');
}

function gwBuildB17BodyRenderSummary_(kind, data) {
  return {
    ok: data.bodyAudit && data.bodyAudit.ok === true,
    kind: kind,
    screenId: data.screenId,
    title: data.title,
    kpiCount: data.kpiList ? data.kpiList.totalReturned : 0,
    assetCount: data.assetList ? data.assetList.totalReturned : 0,
    supplyCount: data.supplyList ? data.supplyList.totalReturned : 0,
    supplyRequestCount: data.supplyRequestList ? data.supplyRequestList.totalReturned : 0,
    expenseCount: data.expenseList ? data.expenseList.totalReturned : 0,
    actionCount: data.actions ? data.actions.length : 0,
    apiCallCount: data.apiCalls ? data.apiCalls.length : 0,
    htmlLength: data.bodyHtml ? data.bodyHtml.length : 0,
    bodyAudit: data.bodyAudit
  };
}

function gwRunB18Diagnostics(payload) {
  payload = payload || {};
  var checks = [];
  checks.push(gwDiagCheck_('BUILD_INFO', function () { return gwGetBuildInfo(); }));
  checks.push(gwDiagCheck_('MASTER_DB_CONNECT', function () {
    var ss = gwGetMasterSpreadsheet_();
    return { spreadsheetName: ss.getName(), spreadsheetId: ss.getId() };
  }));
  checks.push(gwDiagCheck_('CURRENT_USER_CONTEXT', function () { return gwGetUserContextSafe_(); }));
  checks.push(gwDiagCheck_('B18_PERMISSION_ASSERT', function () {
    var ctx = gwAssertPermission_('canAccessDevConsole');
    return { ok: true, employeeId: ctx.employeeId, roleCode: ctx.roleCode };
  }));
  checks.push(gwDiagCheck_('B18_BODY_SPECS', function () {
    var specs = gwGetB18BodySpecs();
    return {
      ok: true,
      buildStep: '18/20',
      bodySpecCount: specs.length,
      screenIds: specs.map(function (s) { return s.screenId; }),
      routeCount: specs.map(function (s) { return s.route; }).length,
      portalShellOnly: true
    };
  }));
  checks.push(gwDiagCheck_('B18_BODY_CONTRACT_VALIDATE', function () { return gwValidateB18BodyContracts(payload); }));
  checks.push(gwDiagCheck_('B18_ADMIN_DIAGNOSTICS_BODY_RENDER', function () {
    var result = gwHandleAdminDiagnosticsBody({ limit: payload.limit || 10 });
    if (!result.ok) return result;
    return gwBuildB18BodyRenderSummary_('adminDiagnostics', result.data);
  }));
  checks.push(gwDiagCheck_('B18_AUDIT_LOG_BODY_RENDER', function () {
    var result = gwHandleAuditLogBody({ limit: payload.limit || 10 });
    if (!result.ok) return result;
    return gwBuildB18BodyRenderSummary_('auditLog', result.data);
  }));
  checks.push(gwDiagCheck_('B18_FEATURE_FLAG_BODY_RENDER', function () {
    var result = gwHandleFeatureFlagBody({ limit: payload.limit || 10 });
    if (!result.ok) return result;
    return gwBuildB18BodyRenderSummary_('featureFlag', result.data);
  }));
  checks.push(gwDiagCheck_('B18_LIMIT_GUARD_BODY_RENDER', function () {
    var result = gwHandleLimitGuardBody({ limit: payload.limit || 20 });
    if (!result.ok) return result;
    return gwBuildB18BodyRenderSummary_('limitGuard', result.data);
  }));
  checks.push(gwDiagCheck_('B18_API_HANDLER_MAP', function () {
    var admin = gwApi('handleAdminDiagnosticsBody', { limit: 5 });
    var audit = gwApi('handleAuditLogBody', { limit: 5 });
    var flags = gwApi('handleFeatureFlagBody', {});
    var limits = gwApi('handleLimitGuardBody', { limit: 5 });
    return {
      ok: admin.ok === true && audit.ok === true && flags.ok === true && limits.ok === true,
      adminHandlerOk: admin.ok === true,
      auditHandlerOk: audit.ok === true,
      featureFlagHandlerOk: flags.ok === true,
      limitGuardHandlerOk: limits.ok === true,
      adminMessage: admin.message,
      auditMessage: audit.message,
      featureFlagMessage: flags.message,
      limitGuardMessage: limits.message
    };
  }));
  if (payload.writeAudit === true) {
    checks.push(gwDiagCheck_('B18_AUDIT_LOG', function () {
      return gwWriteAuditLog_({
        moduleCode: 'GROUPWARE_PORTAL_BODY_UI',
        actionType: 'B18_ADMIN_DIAGNOSTIC_LIMIT_GUARD_BODY_UI_DIAGNOSTIC',
        targetId: GW_BUILD_INFO.build,
        resultStatus: 'SUCCESS',
        detailMessage: 'B18 관리자 진단/로그/FeatureFlag/셀 한도 보호 PORTAL 본문 UI 진단 실행',
        employeeId: gwGetUserContextSafe_().employeeId
      });
    }));
  }
  return gwBuildDiagnosticResult_('B18', checks, 'B18 관리자 진단/로그/셀 한도 보호 PORTAL 본문 UI 진단 통과', 'B18_DIAGNOSTIC_FAILED', 'B18 진단 중 실패 항목이 있습니다.');
}

function gwBuildB18BodyRenderSummary_(kind, data) {
  return {
    ok: data.bodyAudit && data.bodyAudit.ok === true,
    kind: kind,
    screenId: data.screenId,
    title: data.title,
    diagnosticMissingSheetCount: data.diagnostics && data.diagnostics.summary ? data.diagnostics.summary.missingSheetCount : 0,
    auditLogCount: data.auditLogList ? data.auditLogList.totalReturned : 0,
    featureFlagCount: data.featureFlagList ? data.featureFlagList.totalReturned : 0,
    cellRiskLevel: data.limitGuard ? data.limitGuard.riskLevel : '',
    cellUsagePercent: data.limitGuard ? data.limitGuard.usagePercent : 0,
    actionCount: data.actions ? data.actions.length : 0,
    apiCallCount: data.apiCalls ? data.apiCalls.length : 0,
    htmlLength: data.bodyHtml ? data.bodyHtml.length : 0,
    bodyAudit: data.bodyAudit
  };
}


function gwRunB19Diagnostics(payload) {
  payload = payload || {};
  var checks = [];
  checks.push(gwDiagCheck_('BUILD_INFO', function () { return gwGetBuildInfo(); }));
  checks.push(gwDiagCheck_('MASTER_DB_CONNECT', function () {
    var ss = gwGetMasterSpreadsheet_();
    return { spreadsheetName: ss.getName(), spreadsheetId: ss.getId() };
  }));
  checks.push(gwDiagCheck_('CURRENT_USER_CONTEXT', function () { return gwGetUserContextSafe_(); }));
  checks.push(gwDiagCheck_('B19_PERMISSION_ASSERT', function () {
    var ctx = gwAssertPermission_('canAccessDevConsole');
    return { ok: true, employeeId: ctx.employeeId, roleCode: ctx.roleCode };
  }));
  checks.push(gwDiagCheck_('B19_BODY_SPECS', function () {
    var specs = gwGetB19BodySpecs();
    return {
      ok: true,
      buildStep: '19/20',
      bodySpecCount: specs.length,
      screenIds: specs.map(function (s) { return s.screenId; }),
      routeCount: specs.map(function (s) { return s.route; }).length,
      portalShellOnly: true
    };
  }));
  checks.push(gwDiagCheck_('B19_BODY_CONTRACT_VALIDATE', function () { return gwValidateB19BodyContracts(payload); }));
  checks.push(gwDiagCheck_('B19_STABILITY_BODY_RENDER', function () {
    var result = gwHandleStabilityGuardBody({ limit: payload.limit || 10 });
    if (!result.ok) return result;
    return gwBuildB19BodyRenderSummary_('stability', result.data);
  }));
  checks.push(gwDiagCheck_('B19_PERMISSION_GUARD_BODY_RENDER', function () {
    var result = gwHandlePermissionGuardBody({ limit: payload.limit || 10 });
    if (!result.ok) return result;
    return gwBuildB19BodyRenderSummary_('permissionGuard', result.data);
  }));
  checks.push(gwDiagCheck_('B19_INPUT_VALIDATION_BODY_RENDER', function () {
    var result = gwHandleInputValidationBody({ limit: payload.limit || 10 });
    if (!result.ok) return result;
    return gwBuildB19BodyRenderSummary_('inputValidation', result.data);
  }));
  checks.push(gwDiagCheck_('B19_STATUS_GUARD_BODY_RENDER', function () {
    var result = gwHandleStatusGuardBody({ limit: payload.limit || 10 });
    if (!result.ok) return result;
    return gwBuildB19BodyRenderSummary_('statusGuard', result.data);
  }));
  checks.push(gwDiagCheck_('B19_GUARD_POLICY', function () {
    var guard = gwBuildB19GuardSnapshotForUi({ limit: payload.limit || 10 });
    if (!guard.ok) return guard;
    return {
      ok: true,
      cellRiskLevel: guard.data.stability.cellRiskLevel,
      cellUsagePercent: guard.data.stability.cellUsagePercent,
      newSheetGuard: guard.data.stability.newSheetGuard,
      permissionMissingCount: guard.data.permission.missingPermissionScreens.length,
      inputRuleCount: guard.data.input.ruleCount,
      statusGroupCount: guard.data.status.groupCount,
      freeTextStatusForbidden: guard.data.status.freeTextStatusForbidden
    };
  }));
  checks.push(gwDiagCheck_('B19_API_HANDLER_MAP', function () {
    var stability = gwApi('handleStabilityGuardBody', { limit: 5 });
    var permission = gwApi('handlePermissionGuardBody', { limit: 5 });
    var input = gwApi('handleInputValidationBody', { limit: 5 });
    var status = gwApi('handleStatusGuardBody', { limit: 5 });
    return {
      ok: stability.ok === true && permission.ok === true && input.ok === true && status.ok === true,
      stabilityHandlerOk: stability.ok === true,
      permissionHandlerOk: permission.ok === true,
      inputHandlerOk: input.ok === true,
      statusHandlerOk: status.ok === true,
      stabilityMessage: stability.message,
      permissionMessage: permission.message,
      inputMessage: input.message,
      statusMessage: status.message
    };
  }));
  if (payload.writeAudit === true) {
    checks.push(gwDiagCheck_('B19_AUDIT_LOG', function () {
      return gwWriteAuditLog_({
        moduleCode: 'GROUPWARE_PORTAL_BODY_UI',
        actionType: 'B19_STABILITY_HARDENING_BODY_UI_DIAGNOSTIC',
        targetId: GW_BUILD_INFO.build,
        resultStatus: 'SUCCESS',
        detailMessage: 'B19 PORTAL 본문 안정화/권한/입력값/상태값 보호 진단 실행',
        employeeId: gwGetUserContextSafe_().employeeId
      });
    }));
  }
  return gwBuildDiagnosticResult_('B19', checks, 'B19 PORTAL 본문 안정화 진단 통과', 'B19_DIAGNOSTIC_FAILED', 'B19 진단 중 실패 항목이 있습니다.');
}

function gwBuildB19BodyRenderSummary_(kind, data) {
  return {
    ok: data.bodyAudit && data.bodyAudit.ok === true,
    kind: kind,
    screenId: data.screenId,
    title: data.title,
    guardRowCount: data.list ? data.list.totalReturned : 0,
    cellRiskLevel: data.guardSnapshot && data.guardSnapshot.stability ? data.guardSnapshot.stability.cellRiskLevel : 'UNKNOWN',
    newSheetGuard: data.guardSnapshot && data.guardSnapshot.stability ? data.guardSnapshot.stability.newSheetGuard : '',
    inputRuleCount: data.guardSnapshot && data.guardSnapshot.input ? data.guardSnapshot.input.ruleCount : 0,
    statusGroupCount: data.guardSnapshot && data.guardSnapshot.status ? data.guardSnapshot.status.groupCount : 0,
    actionCount: data.actions ? data.actions.length : 0,
    apiCallCount: data.apiCalls ? data.apiCalls.length : 0,
    htmlLength: data.bodyHtml ? data.bodyHtml.length : 0,
    bodyAudit: data.bodyAudit
  };
}
