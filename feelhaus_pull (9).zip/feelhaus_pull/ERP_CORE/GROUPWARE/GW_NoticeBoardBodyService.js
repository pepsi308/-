/**
 * B13 PORTAL body-only UI service for Notice / Board.
 * This file returns body-only screen models and bodyHtml strings for PORTAL handlers.
 * It must not render module navigation, its own top bar, its own side bar, iframe, or preview route.
 */
const GW_B13_MODULE_CODE = 'GROUPWARE';
const GW_B13_BODY_IDS = Object.freeze(['GW_NoticeBoardBody']);
const GW_B13_FORBIDDEN_VISIBLE_TOKENS = Object.freeze(['<iframe', 'preview route', 'standalone shell', 'data-module-menu', 'gw-own-menu', 'gw-side-menu', 'gw-top-menu']);

const GW_B13_NOTICE_FORM_FIELDS = Object.freeze([
  'noticeId', 'title', 'content', 'noticeType', 'targetRoleCode', 'targetVendorId', 'targetEventId',
  'pinnedYn', 'displayStartAt', 'displayEndAt', 'attachmentFileIds', 'status', 'statusReason'
]);

function gwGetB13BodySpecs() {
  return [
    {
      moduleCode: GW_B13_MODULE_CODE,
      menuId: 'gw.notice',
      route: '/groupware/notice',
      handler: 'gwHandleNoticeBoardBody',
      viewFile: 'GW_NoticeBoardBody.html',
      screenId: 'GW_NoticeBoardBody',
      title: '공지 / 게시판',
      description: 'Portal_Notices 기준 공지 목록, 상세, 작성/수정, 게시기간, 상단고정, 대상 필터를 담당하는 PORTAL 본문 화면입니다.',
      permissionCode: 'canAccessPortal',
      adminPermissionCode: 'canAccessDevConsole',
      buttons: [
        { id: 'btnReloadNotices', label: '조회', call: 'listNotices', style: 'primary' },
        { id: 'btnNewNotice', label: '새 공지', call: 'prepareNewNotice', style: 'secondary' },
        { id: 'btnSaveNotice', label: '저장', call: 'saveNotice', style: 'primary' },
        { id: 'btnSetNoticeStatus', label: '상태변경', call: 'setNoticeStatus', style: 'warning' }
      ],
      calls: ['listNotices', 'getNoticeDetail', 'saveNotice', 'setNoticeStatus'],
      sheets: ['Portal_Notices', 'Portal_NoticeReads'],
      logSheet: 'Portal_AuditLog',
      screenStructure: ['화면 제목', '화면 설명', '주요 작업 버튼', '검색 / 필터', '목록 / 입력폼 / 상세', '성공 / 실패 안내문']
    }
  ];
}

function gwHandleNoticeBoardBody(payload) {
  payload = payload || {};
  gwAssertPermission_('canAccessPortal');
  var listResult = gwListNoticesForUi({ query: payload.query || '', limit: payload.limit || 50, includeAll: payload.includeAll === true });
  if (!listResult.ok) return listResult;
  var rows = (listResult.data && listResult.data.rows) || [];
  var selected = null;
  if (payload.noticeId) {
    var detailResult = gwGetNoticeDetailForUi({ noticeId: payload.noticeId, markRead: payload.markRead === true });
    if (detailResult.ok) selected = detailResult.data.notice;
  } else if (rows.length > 0) {
    selected = rows[0];
  }
  var model = gwBuildNoticeBoardBodyModel_(rows, selected, payload);
  return gwOk_(model, '공지/게시판 본문 구성 완료');
}

function gwBuildNoticeBoardBodyModel_(rows, selected, payload) {
  var spec = gwFindB13BodySpec_('GW_NoticeBoardBody');
  var model = {
    moduleCode: GW_B13_MODULE_CODE,
    screenId: spec.screenId,
    menuId: spec.menuId,
    route: spec.route,
    handler: spec.handler,
    title: spec.title,
    description: spec.description,
    permissionCode: spec.permissionCode,
    actions: spec.buttons,
    filters: [
      { id: 'noticeSearchKeyword', label: '검색어', field: 'query', value: gwToSafeText_(payload.query), placeholder: '제목, 내용, noticeType, 대상 role/vendor/event' },
      { id: 'noticeStatusFilter', label: '상태', field: 'status', value: gwToSafeText_(payload.status || ''), options: ['ALL', 'ACTIVE', 'DRAFT', 'INACTIVE', 'ARCHIVED'] }
    ],
    list: {
      title: '공지 목록',
      totalReturned: rows.length,
      columns: ['pinnedYn', 'noticeId', 'title', 'noticeType', 'targetRoleCode', 'displayStartAt', 'displayEndAt', 'status'],
      rows: rows
    },
    form: {
      title: selected ? '공지 상세 / 수정' : '새 공지 / 상세',
      fields: gwBuildB13NoticeFormFields_(selected)
    },
    messages: [
      { type: 'info', text: 'PORTAL 중앙 메뉴에서 열린 본문 화면입니다. 이 화면은 메뉴를 렌더링하지 않습니다.' },
      { type: 'success', text: '공지 저장 성공 시 목록을 다시 조회합니다.' },
      { type: 'error', text: '필수값, 기간, 권한 오류가 있으면 이 영역에 실패 안내문을 표시합니다.' }
    ],
    apiCalls: spec.calls,
    saveSheet: 'Portal_Notices',
    readSheet: 'Portal_NoticeReads',
    logSheet: 'Portal_AuditLog'
  };
  model.bodyHtml = gwRenderB13NoticeBoardBodyHtml_(model);
  model.bodyAudit = gwValidateB13BodyModel_(model);
  return model;
}

function gwFindB13BodySpec_(screenId) {
  var specs = gwGetB13BodySpecs();
  for (var i = 0; i < specs.length; i++) {
    if (specs[i].screenId === screenId) return specs[i];
  }
  throw new Error('B13 본문 책임표를 찾을 수 없습니다: ' + screenId);
}

function gwBuildB13NoticeFormFields_(notice) {
  notice = notice || {};
  return GW_B13_NOTICE_FORM_FIELDS.map(function (field) {
    return {
      field: field,
      label: gwGetB13NoticeFieldLabel_(field),
      value: gwToSafeText_(notice[field]),
      required: field === 'title' || field === 'content' || field === 'noticeType' || field === 'status',
      inputType: field === 'content' || field === 'statusReason' ? 'textarea' : (field === 'pinnedYn' ? 'checkbox' : 'text')
    };
  });
}

function gwGetB13NoticeFieldLabel_(field) {
  var labels = {
    noticeId: '공지 ID', title: '제목', content: '내용', noticeType: '공지 유형',
    targetRoleCode: '대상 역할', targetVendorId: '대상 업체', targetEventId: '대상 행사',
    pinnedYn: '상단 고정', displayStartAt: '게시 시작', displayEndAt: '게시 종료',
    attachmentFileIds: '첨부 fileId', status: '상태', statusReason: '상태 사유'
  };
  return labels[field] || field;
}

function gwRenderB13NoticeBoardBodyHtml_(model) {
  var rowsHtml = model.list.rows.map(function (row) {
    return '<tr data-notice-id="' + gwEscHtml_(row.noticeId) + '">' +
      '<td>' + gwEscHtml_(row.pinnedYn) + '</td>' +
      '<td>' + gwEscHtml_(row.noticeId) + '</td>' +
      '<td>' + gwEscHtml_(row.title) + '</td>' +
      '<td>' + gwEscHtml_(row.noticeType) + '</td>' +
      '<td>' + gwEscHtml_(row.targetRoleCode) + '</td>' +
      '<td>' + gwEscHtml_(row.displayStartAt) + '</td>' +
      '<td>' + gwEscHtml_(row.displayEndAt) + '</td>' +
      '<td>' + gwEscHtml_(row.status) + '</td>' +
    '</tr>';
  }).join('') || '<tr><td colspan="8">표시할 공지가 없습니다.</td></tr>';
  var fieldsHtml = model.form.fields.map(function (field) {
    if (field.inputType === 'textarea') {
      return '<label>' + gwEscHtml_(field.label) + '<textarea data-field="' + gwEscHtml_(field.field) + '">' + gwEscHtml_(field.value) + '</textarea></label>';
    }
    if (field.inputType === 'checkbox') {
      var checked = gwNormalizeYnText_(field.value) === 'Y' ? ' checked' : '';
      return '<label><input type="checkbox" data-field="' + gwEscHtml_(field.field) + '" value="Y"' + checked + ' /> ' + gwEscHtml_(field.label) + '</label>';
    }
    return '<label>' + gwEscHtml_(field.label) + '<input type="text" data-field="' + gwEscHtml_(field.field) + '" value="' + gwEscHtml_(field.value) + '" /></label>';
  }).join('');
  return '<section class="gw-body gw-notice-body" data-screen-id="GW_NoticeBoardBody">' +
    '<h2>' + gwEscHtml_(model.title) + '</h2>' +
    '<p>' + gwEscHtml_(model.description) + '</p>' +
    '<div class="gw-actions">' + gwRenderB13ActionButtons_(model.actions) + '</div>' +
    '<div class="gw-filter"><label>검색 / 필터<input type="text" data-field="query" value="' + gwEscHtml_(model.filters[0].value) + '" /></label></div>' +
    '<div class="gw-message-zone"><p data-message-type="info">공지를 선택하거나 새 공지를 입력한 뒤 저장합니다.</p></div>' +
    '<div class="gw-layout-two"><div class="gw-list"><h3>목록</h3><table><thead><tr><th>고정</th><th>공지 ID</th><th>제목</th><th>유형</th><th>대상</th><th>시작</th><th>종료</th><th>상태</th></tr></thead><tbody>' + rowsHtml + '</tbody></table></div>' +
    '<div class="gw-detail"><h3>입력폼 / 상세</h3>' + fieldsHtml + '</div></div>' +
  '</section>';
}

function gwRenderB13ActionButtons_(actions) {
  return actions.map(function (action) {
    return '<button type="button" data-gw-action="' + gwEscHtml_(action.call) + '" data-button-id="' + gwEscHtml_(action.id) + '">' + gwEscHtml_(action.label) + '</button>';
  }).join('');
}

function gwValidateB13BodyModel_(model) {
  var errors = [];
  var html = gwToSafeText_(model.bodyHtml);
  if (html.indexOf('<h2>') < 0) errors.push('화면 제목 누락: ' + model.screenId);
  if (html.indexOf('<p>') < 0) errors.push('화면 설명 누락: ' + model.screenId);
  if (html.indexOf('data-gw-action') < 0) errors.push('주요 작업 버튼 연결 누락: ' + model.screenId);
  if (html.indexOf('gw-filter') < 0) errors.push('검색 / 필터 영역 누락: ' + model.screenId);
  if (html.indexOf('gw-list') < 0 || html.indexOf('gw-detail') < 0) errors.push('목록 / 입력폼 / 상세 영역 누락: ' + model.screenId);
  if (html.indexOf('gw-message-zone') < 0) errors.push('성공 / 실패 안내문 영역 누락: ' + model.screenId);
  GW_B13_FORBIDDEN_VISIBLE_TOKENS.forEach(function (token) {
    if (html.toLowerCase().indexOf(token.toLowerCase()) >= 0) errors.push('금지 UI 토큰 포함: ' + token);
  });
  return { ok: errors.length === 0, errors: errors, htmlLength: html.length };
}

function gwValidateB13BodyContracts(payload) {
  var errors = [];
  var specs = gwGetB13BodySpecs();
  var expectedHandlers = { gwHandleNoticeBoardBody: true };
  var expectedRoutes = { '/groupware/notice': true };
  specs.forEach(function (spec) {
    if (spec.moduleCode !== GW_B13_MODULE_CODE) errors.push('moduleCode 오류: ' + spec.screenId);
    if (!expectedHandlers[spec.handler]) errors.push('handler 오류: ' + spec.handler);
    if (!expectedRoutes[spec.route]) errors.push('route 오류: ' + spec.route);
    if (spec.permissionCode !== 'canAccessPortal') errors.push('permissionCode 오류: ' + spec.screenId);
    if (!spec.buttons || spec.buttons.length === 0) errors.push('버튼 목록 누락: ' + spec.screenId);
    if (!spec.calls || spec.calls.length === 0) errors.push('호출 함수 누락: ' + spec.screenId);
    if (spec.sheets.indexOf('Portal_Notices') < 0) errors.push('저장 시트 누락: ' + spec.screenId);
    if (spec.logSheet !== 'Portal_AuditLog') errors.push('로그 시트 오류: ' + spec.screenId);
  });
  return gwOk_({ ok: errors.length === 0, errors: errors, specCount: specs.length, portalShellOnly: true }, errors.length === 0 ? 'B13_BODY_CONTRACT_OK' : 'B13_BODY_CONTRACT_ERROR');
}
