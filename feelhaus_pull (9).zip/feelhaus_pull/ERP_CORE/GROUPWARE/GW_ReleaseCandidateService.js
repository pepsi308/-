
/**
 * B20 PORTAL body-only release candidate service.
 * No module menu, no standalone shell, no iframe, no preview route.
 * This service collects final readiness without creating new sheets.
 */
const GW_B20_MODULE_CODE = 'GROUPWARE';
const GW_B20_FORBIDDEN_VISIBLE_TOKENS = Object.freeze(['<iframe', 'data-module-menu', 'gw-own-menu', 'gw-side-menu', 'gw-top-menu']);

function gwGetB20BodySpecs() {
  return [
    {
      moduleCode: GW_B20_MODULE_CODE,
      menuId: 'gw.releaseCandidate',
      route: '/groupware/release-candidate',
      handler: 'gwHandleReleaseCandidateBody',
      viewFile: 'GW_ReleaseCandidateBody.html',
      screenId: 'GW_ReleaseCandidateBody',
      title: 'GROUPWARE 릴리즈 후보 점검',
      description: 'PORTAL 본문 전용 기준으로 GROUPWARE 전체 기능, 본문, 권한, 보호정책 readiness를 최종 확인하는 본문 화면입니다.',
      permissionCode: 'canAccessDevConsole',
      buttons: [
        { id: 'btnRunFinalReadiness', label: '최종 readiness 점검', call: 'validateB20ReleaseCandidate', style: 'primary' },
        { id: 'btnRunNoWriteRegression', label: '읽기 전용 회귀 점검', call: 'runB20Diagnostics', style: 'secondary' }
      ],
      calls: ['validateB20ReleaseCandidate', 'runB20Diagnostics'],
      sheets: ['PortalUsers', 'Portal_Notices', 'Documents', 'Portal_Requests', 'Portal_Attendance', 'Portal_KPI', 'Portal_Assets', 'Portal_Supplies', 'Portal_AuditLog'],
      logSheet: 'Portal_AuditLog',
      screenStructure: ['화면 제목', '화면 설명', '주요 작업 버튼', '검색 / 필터', '목록 / 입력폼 / 상세', '성공 / 실패 안내문']
    }
  ];
}

function gwHandleReleaseCandidateBody(payload) {
  payload = payload || {};
  var spec = gwGetB20BodySpecs()[0];
  gwAssertPermission_(spec.permissionCode || 'canAccessDevConsole');
  var readiness = gwValidateB20ReleaseCandidate({ noWrite: true, limit: payload.limit || 3 });
  if (!readiness.ok) return readiness;
  var model = gwBuildB20ReleaseBodyModel_(spec, readiness.data, payload);
  return gwOk_(model, 'GROUPWARE 릴리즈 후보 본문 구성 완료');
}

function gwBuildB20ReleaseBodyModel_(spec, readiness, payload) {
  var rows = gwBuildB20ReleaseRows_(readiness);
  var model = {
    moduleCode: GW_B20_MODULE_CODE,
    screenId: spec.screenId,
    menuId: spec.menuId,
    route: spec.route,
    handler: spec.handler,
    title: spec.title,
    description: spec.description,
    permissionCode: spec.permissionCode,
    actions: spec.buttons,
    filters: [
      { id: 'gwB20Query', label: '검색', field: 'query', value: gwToSafeText_(payload.query || ''), placeholder: '점검 항목 검색' }
    ],
    list: {
      title: '릴리즈 후보 점검 항목',
      totalReturned: rows.length,
      columns: ['area', 'status', 'summary', 'message'],
      rows: rows
    },
    form: {
      title: '최종 릴리즈 기준',
      fields: [
        { field: 'portalShellOnly', label: 'PORTAL 유일 Shell', value: readiness.portalShellOnly ? 'Y' : 'N', inputType: 'readonly' },
        { field: 'releaseStatus', label: '릴리즈 후보 상태', value: readiness.releaseStatus, inputType: 'readonly' },
        { field: 'cellRiskLevel', label: '셀 한도 위험도', value: readiness.cellRiskLevel, inputType: 'readonly' },
        { field: 'newSheetGuard', label: '신규 시트 보호', value: readiness.newSheetGuard, inputType: 'readonly' }
      ]
    },
    messages: [
      { type: 'info', text: 'PORTAL 중앙 메뉴/라우트/권한 원장에 연결할 본문 후보입니다.' },
      { type: 'success', text: 'B01~B19 기능 엔진과 본문 계약이 릴리즈 후보 기준을 통과했습니다.' },
      { type: 'error', text: '셀 한도 CRITICAL 상태이므로 신규 시트 생성은 차단하고 기존 원장 append/fallback 구조만 허용합니다.' }
    ],
    readiness: readiness,
    apiCalls: spec.calls,
    logSheet: 'Portal_AuditLog'
  };
  model.bodyHtml = gwRenderB20ReleaseBodyHtml_(model);
  model.bodyAudit = gwValidateB20BodyModel_(model);
  return model;
}

function gwBuildB20ReleaseRows_(readiness) {
  return [
    { area: 'PORTAL_CONTRACT', status: readiness.portalShellOnly ? 'PASS' : 'FAIL', summary: 'PORTAL 유일 Shell', message: '자체 메뉴와 standalone Shell 금지' },
    { area: 'BODY_SPECS', status: readiness.bodySpecCount >= 21 ? 'PASS' : 'WARN', summary: '본문 화면 수 ' + readiness.bodySpecCount, message: 'B12~B19 본문 계약 집계' },
    { area: 'HANDLERS', status: readiness.handlerCount >= 21 ? 'PASS' : 'WARN', summary: 'handler 수 ' + readiness.handlerCount, message: 'google.script.run 연결용 handler 후보' },
    { area: 'PROTECTED_SHEETS', status: readiness.protectedSheetCount >= 16 ? 'PASS' : 'WARN', summary: '보호 시트 ' + readiness.protectedSheetCount, message: '기존 정상 원장 보호' },
    { area: 'REGRESSION', status: readiness.regressionFailedCount === 0 ? 'PASS' : 'FAIL', summary: '회귀 실패 ' + readiness.regressionFailedCount, message: 'B01~B19 경량 회귀 결과' },
    { area: 'LIMIT_GUARD', status: readiness.cellRiskLevel, summary: '셀 사용률 ' + readiness.cellUsagePercent + '%', message: readiness.newSheetGuard }
  ];
}

function gwRenderB20ReleaseBodyHtml_(model) {
  var rowsHtml = model.list.rows.map(function (row) {
    return '<tr><td>' + gwEscHtml_(row.area) + '</td><td>' + gwEscHtml_(row.status) + '</td><td>' + gwEscHtml_(row.summary) + '</td><td>' + gwEscHtml_(row.message) + '</td></tr>';
  }).join('') || '<tr><td colspan="4">표시할 점검 항목이 없습니다.</td></tr>';
  var fieldsHtml = model.form.fields.map(function (field) {
    return '<label>' + gwEscHtml_(field.label) + '<input type="text" data-field="' + gwEscHtml_(field.field) + '" value="' + gwEscHtml_(field.value) + '" readonly /></label>';
  }).join('');
  return '<section class="gw-body gw-release-candidate-body" data-screen-id="' + gwEscHtml_(model.screenId) + '">' +
    '<h2>' + gwEscHtml_(model.title) + '</h2>' +
    '<p>' + gwEscHtml_(model.description) + '</p>' +
    '<div class="gw-actions">' + gwRenderB20ActionButtons_(model.actions) + '</div>' +
    '<div class="gw-filter"><label>검색 / 필터<input type="text" data-field="query" value="' + gwEscHtml_(model.filters[0].value) + '" /></label></div>' +
    '<div class="gw-message-zone"><p data-message-type="info">릴리즈 후보 기준을 확인합니다.</p></div>' +
    '<div class="gw-layout-two"><div class="gw-list"><h3>목록</h3><table><thead><tr><th>영역</th><th>상태</th><th>요약</th><th>안내</th></tr></thead><tbody>' + rowsHtml + '</tbody></table></div>' +
    '<div class="gw-detail"><h3>입력폼 / 상세</h3>' + fieldsHtml + '</div></div>' +
  '</section>';
}

function gwRenderB20ActionButtons_(actions) {
  return actions.map(function (action) {
    return '<button type="button" data-gw-action="' + gwEscHtml_(action.call) + '" data-button-id="' + gwEscHtml_(action.id) + '">' + gwEscHtml_(action.label) + '</button>';
  }).join('');
}

function gwValidateB20BodyModel_(model) {
  var errors = [];
  var html = gwToSafeText_(model.bodyHtml);
  if (html.indexOf('<h2>') < 0) errors.push('화면 제목 누락: ' + model.screenId);
  if (html.indexOf('<p>') < 0) errors.push('화면 설명 누락: ' + model.screenId);
  if (html.indexOf('data-gw-action') < 0) errors.push('주요 작업 버튼 연결 누락: ' + model.screenId);
  if (html.indexOf('gw-filter') < 0) errors.push('검색 / 필터 영역 누락: ' + model.screenId);
  if (html.indexOf('gw-list') < 0 || html.indexOf('gw-detail') < 0) errors.push('목록 / 입력폼 / 상세 영역 누락: ' + model.screenId);
  if (html.indexOf('gw-message-zone') < 0) errors.push('성공 / 실패 안내문 영역 누락: ' + model.screenId);
  GW_B20_FORBIDDEN_VISIBLE_TOKENS.forEach(function (token) {
    if (html.toLowerCase().indexOf(token.toLowerCase()) >= 0) errors.push('금지 UI 토큰 포함: ' + token);
  });
  return { ok: errors.length === 0, errors: errors, htmlLength: html.length };
}

function gwValidateB20BodyContracts(payload) {
  var errors = [];
  var specs = gwGetB20BodySpecs();
  specs.forEach(function (spec) {
    if (spec.moduleCode !== 'GROUPWARE') errors.push('moduleCode 오류: ' + spec.screenId);
    if (!spec.menuId || spec.menuId.indexOf('gw.') !== 0) errors.push('menuId 오류: ' + spec.screenId);
    if (!spec.route || spec.route.indexOf('/groupware/') !== 0) errors.push('route 오류: ' + spec.screenId);
    if (!spec.handler || typeof this[spec.handler] === 'undefined') errors.push('handler 미정의: ' + spec.handler);
    if (!spec.viewFile || spec.viewFile.indexOf('.html') < 0) errors.push('viewFile 오류: ' + spec.screenId);
    if (!spec.permissionCode) errors.push('permissionCode 누락: ' + spec.screenId);
  }, this);
  return {
    ok: errors.length === 0,
    build: GW_BUILD_INFO.build,
    generatedAt: gwNow_(),
    code: errors.length === 0 ? '' : 'B20_BODY_CONTRACT_FAILED',
    message: errors.length === 0 ? 'B20_BODY_CONTRACT_OK' : 'B20_BODY_CONTRACT_FAILED',
    data: {
      ok: errors.length === 0,
      errors: errors,
      specCount: specs.length,
      portalShellOnly: true
    }
  };
}

function gwValidateB20ReleaseCandidate(payload) {
  payload = payload || {};
  var bodySpecs = gwGetAllB20PortalBodySpecs_();
  var handlers = {};
  bodySpecs.forEach(function (s) { if (s.handler) handlers[s.handler] = true; });
  var protectedAssets = gwGetProtectedAssets_B11 ? gwGetProtectedAssets_B11() : { protectedSheets: [] };
  var releaseRegression = gwRunB20NoWriteRegression_({ limit: payload.limit || 3 });
  var guard = gwBuildB19GuardSnapshotForUi ? gwBuildB19GuardSnapshotForUi({ limit: payload.limit || 3 }) : null;
  var cellRiskLevel = guard && guard.ok && guard.data.stability ? guard.data.stability.cellRiskLevel : 'UNKNOWN';
  var cellUsagePercent = guard && guard.ok && guard.data.stability ? guard.data.stability.cellUsagePercent : 0;
  var newSheetGuard = guard && guard.ok && guard.data.stability ? guard.data.stability.newSheetGuard : 'BLOCK_NEW_SHEET';
  var errors = [];
  if (!releaseRegression.ok) errors.push('회귀테스트 실패: ' + releaseRegression.failedCount);
  if (bodySpecs.length < 21) errors.push('본문 계약 수 부족: ' + bodySpecs.length);
  if (newSheetGuard !== 'BLOCK_NEW_SHEET' && cellRiskLevel === 'CRITICAL') errors.push('CRITICAL 셀 한도에서 신규 시트 차단 미적용');
  return gwOk_({
    ok: errors.length === 0,
    releaseStatus: errors.length === 0 ? (cellRiskLevel === 'CRITICAL' ? 'PASS_WITH_LIMIT_GUARD' : 'PASS') : 'FAILED',
    errors: errors,
    warnings: cellRiskLevel === 'CRITICAL' ? ['MASTER 셀 한도 CRITICAL: 신규 시트 생성 금지, 기존 원장 append/fallback만 허용'] : [],
    portalShellOnly: true,
    bodySpecCount: bodySpecs.length,
    handlerCount: Object.keys(handlers).length,
    protectedSheetCount: protectedAssets.protectedSheets ? protectedAssets.protectedSheets.length : 0,
    regressionStepCount: releaseRegression.stepCount,
    regressionFailedCount: releaseRegression.failedCount,
    regressionPassedCount: releaseRegression.passedCount,
    cellRiskLevel: cellRiskLevel,
    cellUsagePercent: cellUsagePercent,
    newSheetGuard: newSheetGuard,
    finalGate: errors.length === 0 ? 'READY_FOR_PORTAL_REGISTRY_INTEGRATION_REVIEW' : 'BLOCKED'
  }, errors.length === 0 ? 'B20_RELEASE_CANDIDATE_OK' : 'B20_RELEASE_CANDIDATE_FAILED');
}

function gwGetAllB20PortalBodySpecs_() {
  return []
    .concat(gwGetB12BodySpecs ? gwGetB12BodySpecs() : [])
    .concat(gwGetB13BodySpecs ? gwGetB13BodySpecs() : [])
    .concat(gwGetB14BodySpecs ? gwGetB14BodySpecs() : [])
    .concat(gwGetB15BodySpecs ? gwGetB15BodySpecs() : [])
    .concat(gwGetB16BodySpecs ? gwGetB16BodySpecs() : [])
    .concat(gwGetB17BodySpecs ? gwGetB17BodySpecs() : [])
    .concat(gwGetB18BodySpecs ? gwGetB18BodySpecs() : [])
    .concat(gwGetB19BodySpecs ? gwGetB19BodySpecs() : [])
    .concat(gwGetB20BodySpecs ? gwGetB20BodySpecs() : []);
}

function gwRunB20NoWriteRegression_(payload) {
  payload = payload || {};
  var steps = [];
  var runners = [
    { step: 'B11', fn: function () { return gwValidatePortalContracts_B11({}); } },
    { step: 'B12', fn: function () { return gwValidateB12BodyContracts({}); } },
    { step: 'B13', fn: function () { return gwValidateB13BodyContracts({}); } },
    { step: 'B14', fn: function () { return gwValidateB14BodyContracts({}); } },
    { step: 'B15', fn: function () { return gwValidateB15BodyContracts({}); } },
    { step: 'B16', fn: function () { return gwValidateB16BodyContracts({}); } },
    { step: 'B17', fn: function () { return gwValidateB17BodyContracts({}); } },
    { step: 'B18', fn: function () { return gwValidateB18BodyContracts({}); } },
    { step: 'B19', fn: function () { return gwValidateB19BodyContracts({}); } },
    { step: 'B20', fn: function () { return gwValidateB20BodyContracts({}); } }
  ];
  runners.forEach(function (runner) {
    try {
      var result = runner.fn();
      var ok = result && result.ok === true;
      steps.push({ step: runner.step, ok: ok, message: result && result.message ? result.message : (ok ? 'OK' : 'FAILED') });
    } catch (err) {
      steps.push({ step: runner.step, ok: false, message: gwErrorMessage_(err) });
    }
  });
  var failed = steps.filter(function (s) { return !s.ok; });
  return {
    ok: failed.length === 0,
    mode: 'NO_WRITE_CONTRACT_REGRESSION_LIGHT',
    stepCount: steps.length,
    passedCount: steps.length - failed.length,
    failedCount: failed.length,
    results: steps
  };
}

function gwRunB20Diagnostics(payload) {
  payload = payload || {};
  var checks = [];
  checks.push(gwDiagCheck_('BUILD_INFO', function () { return gwGetBuildInfo(); }));
  checks.push(gwDiagCheck_('MASTER_DB_CONNECT', function () {
    var ss = gwGetMasterSpreadsheet_();
    return { spreadsheetName: ss.getName(), spreadsheetId: ss.getId() };
  }));
  checks.push(gwDiagCheck_('CURRENT_USER_CONTEXT', function () { return gwGetUserContextSafe_(); }));
  checks.push(gwDiagCheck_('B20_PERMISSION_ASSERT', function () {
    var ctx = gwAssertPermission_('canAccessDevConsole');
    return { ok: true, employeeId: ctx.employeeId, roleCode: ctx.roleCode };
  }));
  checks.push(gwDiagCheck_('B20_BODY_SPECS', function () {
    var specs = gwGetB20BodySpecs();
    return { ok: true, buildStep: '20/20', bodySpecCount: specs.length, screenIds: specs.map(function (s) { return s.screenId; }), routeCount: specs.length, portalShellOnly: true };
  }));
  checks.push(gwDiagCheck_('B20_BODY_CONTRACT_VALIDATE', function () { return gwValidateB20BodyContracts(payload); }));
  checks.push(gwDiagCheck_('B20_RELEASE_CANDIDATE_VALIDATE', function () { return gwValidateB20ReleaseCandidate({ limit: payload.limit || 3 }); }));
  checks.push(gwDiagCheck_('B20_RELEASE_BODY_RENDER', function () {
    var result = gwHandleReleaseCandidateBody({ limit: payload.limit || 3 });
    if (!result.ok) return result;
    return gwBuildB20BodyRenderSummary_('releaseCandidate', result.data);
  }));
  checks.push(gwDiagCheck_('B20_NO_WRITE_REGRESSION', function () { return gwRunB20NoWriteRegression_({ limit: payload.limit || 3 }); }));
  checks.push(gwDiagCheck_('B20_API_HANDLER_MAP', function () {
    var body = gwApi('handleReleaseCandidateBody', { limit: 3 });
    var validate = gwApi('validateB20ReleaseCandidate', { limit: 3 });
    return {
      ok: body.ok === true && validate.ok === true,
      releaseHandlerOk: body.ok === true,
      validateHandlerOk: validate.ok === true,
      releaseMessage: body.message,
      validateMessage: validate.message
    };
  }));
  if (payload.writeAudit === true) {
    checks.push(gwDiagCheck_('B20_AUDIT_LOG', function () {
      return gwWriteAuditLog_({
        moduleCode: 'GROUPWARE_PORTAL_BODY_UI',
        actionType: 'B20_PORTAL_BODY_RELEASE_CANDIDATE_DIAGNOSTIC',
        targetId: GW_BUILD_INFO.build,
        resultStatus: 'SUCCESS',
        detailMessage: 'B20 PORTAL 본문 릴리즈 후보 진단 실행',
        employeeId: gwGetUserContextSafe_().employeeId
      });
    }));
  }
  return gwBuildDiagnosticResult_('B20', checks, 'B20 PORTAL 본문 릴리즈 후보 진단 통과', 'B20_DIAGNOSTIC_FAILED', 'B20 진단 중 실패 항목이 있습니다.');
}

function gwBuildB20BodyRenderSummary_(kind, data) {
  return {
    ok: data.bodyAudit && data.bodyAudit.ok === true,
    kind: kind,
    screenId: data.screenId,
    title: data.title,
    releaseStatus: data.readiness ? data.readiness.releaseStatus : '',
    bodySpecCount: data.readiness ? data.readiness.bodySpecCount : 0,
    regressionFailedCount: data.readiness ? data.readiness.regressionFailedCount : 0,
    cellRiskLevel: data.readiness ? data.readiness.cellRiskLevel : 'UNKNOWN',
    newSheetGuard: data.readiness ? data.readiness.newSheetGuard : '',
    actionCount: data.actions ? data.actions.length : 0,
    apiCallCount: data.apiCalls ? data.apiCalls.length : 0,
    htmlLength: data.bodyHtml ? data.bodyHtml.length : 0,
    bodyAudit: data.bodyAudit
  };
}
