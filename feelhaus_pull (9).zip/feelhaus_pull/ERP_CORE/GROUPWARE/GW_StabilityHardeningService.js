/**
 * B19 PORTAL body-only stability hardening service.
 * No module menu, no standalone shell, no iframe, no preview route.
 * This service exposes body-only guard screens and no-write policy validators.
 */
const GW_B19_MODULE_CODE = 'GROUPWARE';
var GW_B19_GUARD_SNAPSHOT_CACHE_ = null;
const GW_B19_FORBIDDEN_VISIBLE_TOKENS = Object.freeze(['<iframe', 'preview route', 'standalone shell', 'data-module-menu', 'gw-own-menu', 'gw-side-menu', 'gw-top-menu', 'fragment menu']);
const GW_B19_STATUS_RULES = Object.freeze({
  notice: ['DRAFT', 'ACTIVE', 'INACTIVE', 'ARCHIVED'],
  request: ['DRAFT', 'REQUESTED', 'IN_REVIEW', 'APPROVED', 'REJECTED', 'CANCELED', 'COMPLETED'],
  approval: ['PENDING', 'APPROVED', 'REJECTED', 'CANCELED', 'SKIPPED'],
  attendance: ['WORK', 'LATE', 'LEAVE', 'ABSENT', 'OUTSIDE', 'HALF_DAY', 'HOLIDAY', 'MISSING_CHECKOUT', 'MISSING_CHECKIN', 'NEEDS_REVIEW'],
  kpi: ['DRAFT', 'ACTIVE', 'EVALUATED', 'CLOSED', 'ARCHIVED'],
  asset: ['ACTIVE', 'ASSIGNED', 'RETURNED', 'REPAIR', 'LOST', 'DISPOSED', 'ARCHIVED'],
  supply: ['ACTIVE', 'LOW_STOCK', 'OUT_OF_STOCK', 'INACTIVE', 'ARCHIVED']
});

function gwGetB19BodySpecs() {
  return [
    {
      moduleCode: GW_B19_MODULE_CODE,
      menuId: 'gw.stabilityGuard',
      route: '/groupware/stability-guard',
      handler: 'gwHandleStabilityGuardBody',
      viewFile: 'GW_StabilityGuardBody.html',
      screenId: 'GW_StabilityGuardBody',
      title: '운영 안정화 점검',
      description: 'PORTAL 본문 화면의 오류 방어, 빈 화면 방지, 저장 전 보호 상태를 확인하는 본문 화면입니다.',
      permissionCode: 'canAccessDevConsole',
      buttons: [
        { id: 'btnValidateStability', label: '안정화 점검', call: 'validateStabilityGuards', style: 'primary' },
        { id: 'btnReloadLimitGuard', label: '셀 한도 재조회', call: 'getCellLimitSnapshot', style: 'secondary' }
      ],
      calls: ['validateStabilityGuards', 'getCellLimitSnapshot'],
      sheets: ['FEELHAUS_DB_MASTER', 'Portal_AuditLog'],
      logSheet: 'Portal_AuditLog',
      screenStructure: ['화면 제목', '화면 설명', '주요 작업 버튼', '검색 / 필터', '목록 / 입력폼 / 상세', '성공 / 실패 안내문']
    },
    {
      moduleCode: GW_B19_MODULE_CODE,
      menuId: 'gw.permissionGuard',
      route: '/groupware/permission-guard',
      handler: 'gwHandlePermissionGuardBody',
      viewFile: 'GW_PermissionGuardBody.html',
      screenId: 'GW_PermissionGuardBody',
      title: '권한 차단 점검',
      description: '메뉴 노출뿐 아니라 서버 handler/API에서 필요한 권한이 차단되는지 확인하는 본문 화면입니다.',
      permissionCode: 'canAccessDevConsole',
      buttons: [
        { id: 'btnValidatePermissionGuard', label: '권한 점검', call: 'validatePermissionGuards', style: 'primary' }
      ],
      calls: ['validatePermissionGuards'],
      sheets: ['PortalUsers'],
      logSheet: 'Portal_AuditLog',
      screenStructure: ['화면 제목', '화면 설명', '주요 작업 버튼', '검색 / 필터', '목록 / 입력폼 / 상세', '성공 / 실패 안내문']
    },
    {
      moduleCode: GW_B19_MODULE_CODE,
      menuId: 'gw.inputValidation',
      route: '/groupware/input-validation',
      handler: 'gwHandleInputValidationBody',
      viewFile: 'GW_InputValidationBody.html',
      screenId: 'GW_InputValidationBody',
      title: '입력값 검증',
      description: '저장 전 필수값, 형식, 금액, 이메일, fileId, 날짜 필드 검증 기준을 확인하는 본문 화면입니다.',
      permissionCode: 'canAccessDevConsole',
      buttons: [
        { id: 'btnValidateInputRules', label: '입력 규칙 점검', call: 'validateInputRules', style: 'primary' }
      ],
      calls: ['validateInputRules'],
      sheets: ['PortalUsers', 'Portal_Notices', 'Documents', 'Portal_Requests'],
      logSheet: 'Portal_AuditLog',
      screenStructure: ['화면 제목', '화면 설명', '주요 작업 버튼', '검색 / 필터', '목록 / 입력폼 / 상세', '성공 / 실패 안내문']
    },
    {
      moduleCode: GW_B19_MODULE_CODE,
      menuId: 'gw.statusGuard',
      route: '/groupware/status-guard',
      handler: 'gwHandleStatusGuardBody',
      viewFile: 'GW_StatusGuardBody.html',
      screenId: 'GW_StatusGuardBody',
      title: '상태값 보호',
      description: '상태값 자유입력 금지, 완료/종료 후 수정 제한, 승인 기반 예외 전이 원칙을 확인하는 본문 화면입니다.',
      permissionCode: 'canAccessDevConsole',
      buttons: [
        { id: 'btnValidateStatusRules', label: '상태값 점검', call: 'validateStatusRules', style: 'primary' }
      ],
      calls: ['validateStatusRules'],
      sheets: ['Portal_Requests', 'Portal_Approvals', 'Portal_Attendance', 'Portal_KPI', 'Portal_Assets'],
      logSheet: 'Portal_AuditLog',
      screenStructure: ['화면 제목', '화면 설명', '주요 작업 버튼', '검색 / 필터', '목록 / 입력폼 / 상세', '성공 / 실패 안내문']
    }
  ];
}

function gwHandleStabilityGuardBody(payload) { return gwBuildB19GuardBody_('GW_StabilityGuardBody', payload || {}); }
function gwHandlePermissionGuardBody(payload) { return gwBuildB19GuardBody_('GW_PermissionGuardBody', payload || {}); }
function gwHandleInputValidationBody(payload) { return gwBuildB19GuardBody_('GW_InputValidationBody', payload || {}); }
function gwHandleStatusGuardBody(payload) { return gwBuildB19GuardBody_('GW_StatusGuardBody', payload || {}); }

function gwBuildB19GuardBody_(screenId, payload) {
  payload = payload || {};
  var spec = gwFindB19BodySpec_(screenId);
  gwAssertPermission_(spec.permissionCode || 'canAccessDevConsole');
  var guardResult = gwBuildB19GuardSnapshotForUi({ screenId: screenId, limit: payload.limit || 10 });
  if (!guardResult.ok) return guardResult;
  var model = gwBuildB19GuardBodyModel_(spec, guardResult.data, payload);
  return gwOk_(model, spec.title + ' 본문 구성 완료');
}

function gwFindB19BodySpec_(screenId) {
  var specs = gwGetB19BodySpecs();
  for (var i = 0; i < specs.length; i++) {
    if (specs[i].screenId === screenId) return specs[i];
  }
  throw new Error('B19 본문 책임표를 찾을 수 없습니다: ' + screenId);
}

function gwBuildB19GuardSnapshotForUi(payload) {
  payload = payload || {};
  var forceRefresh = payload.forceRefresh === true;
  if (!forceRefresh && GW_B19_GUARD_SNAPSHOT_CACHE_) {
    return GW_B19_GUARD_SNAPSHOT_CACHE_;
  }
  var permission = gwValidatePermissionGuards(payload);
  var input = gwValidateInputRules(payload);
  var status = gwValidateStatusRules(payload);
  var stability = gwValidateStabilityGuards(payload);
  if (!permission.ok) return permission;
  if (!input.ok) return input;
  if (!status.ok) return status;
  if (!stability.ok) return stability;
  GW_B19_GUARD_SNAPSHOT_CACHE_ = gwOk_({
    permission: permission.data,
    input: input.data,
    status: status.data,
    stability: stability.data,
    generatedAt: gwNow_(),
    cacheMode: 'B19_SINGLE_EXECUTION_CACHE'
  }, 'B19_GUARD_SNAPSHOT_OK');
  return GW_B19_GUARD_SNAPSHOT_CACHE_;
}

function gwClearB19GuardSnapshotCache_() {
  GW_B19_GUARD_SNAPSHOT_CACHE_ = null;
}

function gwValidateStabilityGuards(payload) {
  payload = payload || {};
  var limit = gwGetCellLimitSnapshotForUi({ limit: payload.limit || 10 });
  if (!limit.ok) return limit;
  var risk = limit.data.riskLevel || 'UNKNOWN';
  return gwOk_({
    ok: true,
    guardName: 'STABILITY_GUARD',
    portalShellOnly: true,
    noStandaloneShell: true,
    noIframe: true,
    noPreviewRoute: true,
    noFragmentMenu: true,
    blankScreenPolicy: 'SHOW_MESSAGE_INSTEAD_OF_BLANK',
    errorPolicy: 'SHOW_FAILURE_MESSAGE_AND_KEEP_BODY',
    cellRiskLevel: risk,
    cellUsagePercent: limit.data.usagePercent,
    newSheetGuard: risk === 'CRITICAL' ? 'BLOCK_NEW_SHEET' : 'ALLOW_WITH_CAUTION',
    writeGuard: risk === 'CRITICAL' ? 'ALLOW_EXISTING_SHEET_APPEND_ONLY_WITH_PERMISSION' : 'NORMAL_PERMISSION_REQUIRED'
  }, 'B19_STABILITY_GUARD_OK');
}

function gwValidatePermissionGuards(payload) {
  var specs = []
    .concat(gwGetB12BodySpecs ? gwGetB12BodySpecs() : [])
    .concat(gwGetB13BodySpecs ? gwGetB13BodySpecs() : [])
    .concat(gwGetB14BodySpecs ? gwGetB14BodySpecs() : [])
    .concat(gwGetB15BodySpecs ? gwGetB15BodySpecs() : [])
    .concat(gwGetB16BodySpecs ? gwGetB16BodySpecs() : [])
    .concat(gwGetB17BodySpecs ? gwGetB17BodySpecs() : [])
    .concat(gwGetB18BodySpecs ? gwGetB18BodySpecs() : []);
  var missing = specs.filter(function (s) { return !s.permissionCode; }).map(function (s) { return s.screenId; });
  var uniquePermissions = {};
  specs.forEach(function (s) { if (s.permissionCode) uniquePermissions[s.permissionCode] = true; });
  return gwOk_({
    ok: missing.length === 0,
    guardName: 'PERMISSION_GUARD',
    bodySpecCount: specs.length,
    missingPermissionScreens: missing,
    permissionCodeCount: Object.keys(uniquePermissions).length,
    serverPermissionRequired: true,
    menuHideOnlyForbidden: true
  }, missing.length === 0 ? 'B19_PERMISSION_GUARD_OK' : 'B19_PERMISSION_GUARD_WARN');
}

function gwValidateInputRules(payload) {
  var rules = [
    { field: 'loginEmail', rule: 'EMAIL_FORMAT_AND_DUPLICATE_BLOCK', required: true },
    { field: 'employeeId', rule: 'AUTO_GENERATED_AND_NO_REUSE', required: true },
    { field: 'title', rule: 'REQUIRED_TEXT', required: true },
    { field: 'amount', rule: 'NUMBER_GREATER_THAN_ZERO', required: true },
    { field: 'driveFileId', rule: 'NON_EMPTY_FILE_ID_FOR_LIBRARY_OR_RECEIPT', required: false },
    { field: 'displayStartAt/displayEndAt', rule: 'DATE_RANGE_VALIDATION', required: false },
    { field: 'status', rule: 'ALLOWLIST_ONLY', required: true },
    { field: 'rejectedReason', rule: 'REQUIRED_ON_REJECT', required: false }
  ];
  return gwOk_({
    ok: true,
    guardName: 'INPUT_VALIDATION',
    ruleCount: rules.length,
    rules: rules,
    saveOrder: ['필수값 검사', '형식 검사', '권한 검사', '중복 검사', '셀 한도 검사', '저장', '로그 기록']
  }, 'B19_INPUT_RULES_OK');
}

function gwValidateStatusRules(payload) {
  var groups = Object.keys(GW_B19_STATUS_RULES).map(function (key) {
    return { group: key, allowedStatuses: GW_B19_STATUS_RULES[key], count: GW_B19_STATUS_RULES[key].length };
  });
  return gwOk_({
    ok: true,
    guardName: 'STATUS_GUARD',
    groupCount: groups.length,
    groups: groups,
    freeTextStatusForbidden: true,
    lockedAfterCompleted: true,
    reopenRequiresApproval: true,
    deletePreferStatusChange: true
  }, 'B19_STATUS_RULES_OK');
}

function gwBuildB19GuardBodyModel_(spec, snapshot, payload) {
  var rows = gwBuildB19GuardRows_(spec.screenId, snapshot);
  var model = {
    moduleCode: GW_B19_MODULE_CODE,
    screenId: spec.screenId,
    menuId: spec.menuId,
    route: spec.route,
    handler: spec.handler,
    title: spec.title,
    description: spec.description,
    permissionCode: spec.permissionCode,
    actions: spec.buttons,
    filters: [
      { id: 'gwB19Query', label: '검색', field: 'query', value: gwToSafeText_(payload.query || ''), placeholder: '점검 항목 검색' }
    ],
    list: {
      title: '안정화 점검 항목',
      totalReturned: rows.length,
      columns: ['guardType', 'item', 'status', 'message'],
      rows: rows
    },
    form: {
      title: '운영 보호 기준',
      fields: [
        { field: 'portalShellOnly', label: 'PORTAL 유일 Shell', value: 'Y', inputType: 'readonly' },
        { field: 'newSheetGuard', label: '신규 시트 보호', value: snapshot.stability.newSheetGuard || '', inputType: 'readonly' },
        { field: 'cellRiskLevel', label: '셀 한도 위험도', value: snapshot.stability.cellRiskLevel || 'UNKNOWN', inputType: 'readonly' },
        { field: 'errorPolicy', label: '오류 안내 정책', value: snapshot.stability.errorPolicy || '', inputType: 'readonly' }
      ]
    },
    messages: [
      { type: 'info', text: 'PORTAL 중앙 메뉴에서 열린 본문 화면입니다. 이 화면은 메뉴를 렌더링하지 않습니다.' },
      { type: 'success', text: '권한, 입력값, 상태값, 셀 한도 보호 기준을 통과한 handler만 운영 화면에 연결합니다.' },
      { type: 'error', text: '오류 발생 시 빈 화면 대신 실패 안내문을 표시하고 기존 본문을 유지합니다.' }
    ],
    guardSnapshot: snapshot,
    apiCalls: spec.calls,
    logSheet: 'Portal_AuditLog'
  };
  model.bodyHtml = gwRenderB19GuardBodyHtml_(model);
  model.bodyAudit = gwValidateB19BodyModel_(model);
  return model;
}

function gwBuildB19GuardRows_(screenId, snapshot) {
  var rows = [];
  rows.push({ guardType: 'STABILITY', item: 'PORTAL 유일 Shell', status: snapshot.stability.portalShellOnly ? 'PASS' : 'FAIL', message: '자체 메뉴/iframe/preview/standalone 금지' });
  rows.push({ guardType: 'STABILITY', item: '셀 한도', status: snapshot.stability.cellRiskLevel, message: '사용률 ' + snapshot.stability.cellUsagePercent + '%' });
  rows.push({ guardType: 'PERMISSION', item: '서버 권한검사', status: snapshot.permission.serverPermissionRequired ? 'PASS' : 'FAIL', message: '메뉴 숨김만으로 권한 처리 금지' });
  rows.push({ guardType: 'PERMISSION', item: '권한코드 누락 화면', status: snapshot.permission.missingPermissionScreens.length === 0 ? 'PASS' : 'WARN', message: snapshot.permission.missingPermissionScreens.join(', ') || '없음' });
  rows.push({ guardType: 'INPUT', item: '저장 순서', status: 'PASS', message: snapshot.input.saveOrder.join(' → ') });
  rows.push({ guardType: 'STATUS', item: '상태값 자유입력 금지', status: snapshot.status.freeTextStatusForbidden ? 'PASS' : 'FAIL', message: '허용 목록 기반' });
  rows.push({ guardType: 'STATUS', item: '완료 후 잠금', status: snapshot.status.lockedAfterCompleted ? 'PASS' : 'FAIL', message: '재오픈은 승인 기반' });
  return rows;
}

function gwRenderB19GuardBodyHtml_(model) {
  var rowsHtml = model.list.rows.map(function (row) {
    return '<tr><td>' + gwEscHtml_(row.guardType) + '</td><td>' + gwEscHtml_(row.item) + '</td><td>' + gwEscHtml_(row.status) + '</td><td>' + gwEscHtml_(row.message) + '</td></tr>';
  }).join('') || '<tr><td colspan="4">표시할 점검 항목이 없습니다.</td></tr>';
  var fieldsHtml = model.form.fields.map(function (field) {
    return '<label>' + gwEscHtml_(field.label) + '<input type="text" data-field="' + gwEscHtml_(field.field) + '" value="' + gwEscHtml_(field.value) + '" readonly /></label>';
  }).join('');
  return '<section class="gw-body gw-stability-body" data-screen-id="' + gwEscHtml_(model.screenId) + '">' +
    '<h2>' + gwEscHtml_(model.title) + '</h2>' +
    '<p>' + gwEscHtml_(model.description) + '</p>' +
    '<div class="gw-actions">' + gwRenderB19ActionButtons_(model.actions) + '</div>' +
    '<div class="gw-filter"><label>검색 / 필터<input type="text" data-field="query" value="' + gwEscHtml_(model.filters[0].value) + '" /></label></div>' +
    '<div class="gw-message-zone"><p data-message-type="info">운영 안정화 기준을 확인합니다.</p></div>' +
    '<div class="gw-layout-two"><div class="gw-list"><h3>목록</h3><table><thead><tr><th>구분</th><th>항목</th><th>상태</th><th>안내</th></tr></thead><tbody>' + rowsHtml + '</tbody></table></div>' +
    '<div class="gw-detail"><h3>입력폼 / 상세</h3>' + fieldsHtml + '</div></div>' +
  '</section>';
}

function gwRenderB19ActionButtons_(actions) {
  return actions.map(function (action) {
    return '<button type="button" data-gw-action="' + gwEscHtml_(action.call) + '" data-button-id="' + gwEscHtml_(action.id) + '">' + gwEscHtml_(action.label) + '</button>';
  }).join('');
}

function gwValidateB19BodyModel_(model) {
  var errors = [];
  var html = gwToSafeText_(model.bodyHtml);
  if (html.indexOf('<h2>') < 0) errors.push('화면 제목 누락: ' + model.screenId);
  if (html.indexOf('<p>') < 0) errors.push('화면 설명 누락: ' + model.screenId);
  if (html.indexOf('data-gw-action') < 0) errors.push('주요 작업 버튼 연결 누락: ' + model.screenId);
  if (html.indexOf('gw-filter') < 0) errors.push('검색 / 필터 영역 누락: ' + model.screenId);
  if (html.indexOf('gw-list') < 0 || html.indexOf('gw-detail') < 0) errors.push('목록 / 입력폼 / 상세 영역 누락: ' + model.screenId);
  if (html.indexOf('gw-message-zone') < 0) errors.push('성공 / 실패 안내문 영역 누락: ' + model.screenId);
  GW_B19_FORBIDDEN_VISIBLE_TOKENS.forEach(function (token) {
    if (html.toLowerCase().indexOf(token.toLowerCase()) >= 0) errors.push('금지 UI 토큰 포함: ' + token);
  });
  return { ok: errors.length === 0, errors: errors, htmlLength: html.length };
}

function gwValidateB19BodyContracts(payload) {
  var errors = [];
  var specs = gwGetB19BodySpecs();
  var expectedHandlers = {
    gwHandleStabilityGuardBody: true,
    gwHandlePermissionGuardBody: true,
    gwHandleInputValidationBody: true,
    gwHandleStatusGuardBody: true
  };
  var expectedRoutes = {
    '/groupware/stability-guard': true,
    '/groupware/permission-guard': true,
    '/groupware/input-validation': true,
    '/groupware/status-guard': true
  };
  specs.forEach(function (spec) {
    if (spec.moduleCode !== GW_B19_MODULE_CODE) errors.push('moduleCode 오류: ' + spec.screenId);
    if (!expectedHandlers[spec.handler]) errors.push('handler 오류: ' + spec.handler);
    if (!expectedRoutes[spec.route]) errors.push('route 오류: ' + spec.route);
    if (spec.permissionCode !== 'canAccessDevConsole') errors.push('permissionCode 오류: ' + spec.screenId);
    if (!spec.buttons || spec.buttons.length === 0) errors.push('버튼 목록 누락: ' + spec.screenId);
    if (!spec.calls || spec.calls.length === 0) errors.push('호출 함수 누락: ' + spec.screenId);
    if (spec.logSheet !== 'Portal_AuditLog') errors.push('로그 시트 오류: ' + spec.screenId);
  });
  return gwOk_({ ok: errors.length === 0, errors: errors, specCount: specs.length, portalShellOnly: true }, errors.length === 0 ? 'B19_BODY_CONTRACT_OK' : 'B19_BODY_CONTRACT_ERROR');
}
