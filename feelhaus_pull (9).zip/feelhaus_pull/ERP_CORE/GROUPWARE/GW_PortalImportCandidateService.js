/**
 * FEELHAUS GROUPWARE [10/10] B10 - PORTAL Body Import Candidate Service
 * No new sheet creation. This stage organizes import candidates and runs no-write regression checks.
 */
const GW_B10_IMPORT_STEP = '10/10';

const GW_B10_IMPORT_CANDIDATE_FILES = Object.freeze([
  { fileName: 'Code.js', type: 'ENTRY', importAction: 'REVIEW_AND_MERGE_API', note: 'doGet/gwApi 진입부. PORTAL 이관 시 moduleHost API 구조에 맞춰 일부만 병합합니다.' },
  { fileName: 'GW_UserService.js', type: 'SERVICE', importAction: 'IMPORT_CANDIDATE', note: 'PortalUsers 직원관리/권한 원본 서비스입니다.' },
  { fileName: 'GW_PermissionService.js', type: 'SERVICE', importAction: 'IMPORT_CANDIDATE', note: 'roleCode/권한 컬럼 기반 권한 판정 서비스입니다.' },
  { fileName: 'GW_NoticeService.js', type: 'SERVICE', importAction: 'IMPORT_CANDIDATE', note: '공지/게시판 서비스입니다.' },
  { fileName: 'GW_LibraryService.js', type: 'SERVICE', importAction: 'IMPORT_CANDIDATE', note: 'Drive fileId 기반 자료실 서비스입니다.' },
  { fileName: 'GW_RequestApprovalService.js', type: 'SERVICE', importAction: 'IMPORT_CANDIDATE', note: '업무요청/전자결재 및 fallback 요청 원장 서비스입니다.' },
  { fileName: 'GW_AttendanceCapsService.js', type: 'SERVICE', importAction: 'IMPORT_CANDIDATE', note: 'CAPS Raw/매칭/근태 원장/예외처리 서비스입니다.' },
  { fileName: 'GW_KpiService.js', type: 'SERVICE', importAction: 'IMPORT_CANDIDATE', note: '수기 KPI/평가 서비스입니다.' },
  { fileName: 'GW_AssetSupplyService.js', type: 'SERVICE', importAction: 'IMPORT_CANDIDATE', note: '자산/비품/Portal_Requests 비품요청 fallback 서비스입니다.' },
  { fileName: 'GW_ExpenseService.js', type: 'SERVICE', importAction: 'IMPORT_CANDIDATE', note: 'Portal_Requests 비용요청 fallback 서비스입니다.' },
  { fileName: 'GW_HeaderMap.js', type: 'COMMON', importAction: 'IMPORT_CANDIDATE', note: '헤더맵 기반 읽기/쓰기 공통 유틸입니다.' },
  { fileName: 'GW_Audit.js', type: 'COMMON', importAction: 'IMPORT_CANDIDATE', note: 'Portal_AuditLog 감사로그 공통 유틸입니다.' },
  { fileName: 'GW_Config.js', type: 'COMMON', importAction: 'IMPORT_CANDIDATE', note: 'SystemConfig/DB_MASTER_ID 연결 유틸입니다.' },
  { fileName: 'GW_Core.js', type: 'COMMON', importAction: 'IMPORT_CANDIDATE', note: '공통 시간/ID/응답/오류 유틸입니다.' },
  { fileName: 'GW_MenuService.js', type: 'MENU', importAction: 'REFERENCE_ONLY', note: '단독 엔진 메뉴 기준입니다. PORTAL 이관 시 PORTAL 메뉴 기준으로 재구성합니다.' },
  { fileName: 'GW_FeatureFlag.js', type: 'COMMON', importAction: 'REFERENCE_OR_IMPORT', note: 'GROUPWARE 기능 플래그 기본값입니다. PORTAL SystemConfig 기준과 병합 검토합니다.' },
  { fileName: 'GW_DevShell.html', type: 'UI_SHELL', importAction: 'DO_NOT_IMPORT_AS_IS', note: '단독 엔진 임시 Shell입니다. PORTAL 이관 시 본문 요소만 추출하고 Shell/좌측 메뉴는 폐기합니다.' },
  { fileName: 'GW_Test.js', type: 'TEST', importAction: 'KEEP_FOR_REGRESSION', note: '이관 전후 회귀테스트용으로 별도 보관합니다.' },
  { fileName: 'GW_DiagnosticService.js', type: 'TEST', importAction: 'KEEP_FOR_REGRESSION', note: 'B01~B10 진단 게이트입니다. 운영 본문에는 직접 병합하지 않습니다.' }
]);

const GW_B10_DO_NOT_IMPORT_FILES = Object.freeze([
  'GW_DevShell.html',
  'README_BUILD.md',
  'BUILD_TEST_REPORT.md',
  'appsscript.json'
]);

const GW_B10_PROTECTED_SHEETS = Object.freeze([
  'SystemConfig',
  'PortalUsers',
  'Portal_AuditLog',
  'Portal_Notices',
  'Portal_NoticeReads',
  'Documents',
  'Portal_FileDownloadLogs',
  'Portal_Requests',
  'Portal_Approvals',
  'Portal_AttendanceRaw_CAPS',
  'Portal_AttendanceCapsMap',
  'Portal_Attendance',
  'Portal_AttendanceExceptions',
  'Portal_KPI',
  'Portal_Assets',
  'Portal_Supplies'
]);

function gwGetB10PortalImportMeta_() {
  return {
    ok: true,
    buildStep: GW_B10_IMPORT_STEP,
    importMode: 'PORTAL_BODY_IMPORT_CANDIDATE',
    portalDirectMerge: 'FORBIDDEN_BEFORE_B10_PASS',
    candidateFileCount: GW_B10_IMPORT_CANDIDATE_FILES.length,
    doNotImportFileCount: GW_B10_DO_NOT_IMPORT_FILES.length,
    protectedSheetCount: GW_B10_PROTECTED_SHEETS.length,
    completedSteps: ['B01','B02','B03','B04','B05','B06','B07','B08','B09'],
    nextPhase: 'B11_PORTAL_BODY_IMPORT_AFTER_MAIN_DEVELOPER_REVIEW',
    rules: [
      'PORTAL 본체에 GROUPWARE 단독 Shell을 그대로 병합하지 않습니다.',
      '검증된 Body/Service/공통 유틸만 PORTAL 공통 디자인에 맞춰 이관합니다.',
      'SystemConfig 자동 읽기, FEELHAUS_DB_MASTER 연결, PortalUsers 계정 원본, HeaderMap, AuditLog 구조는 보호합니다.',
      'Portal_Requests fallback 구조는 셀 한도 보호 기준으로 유지합니다.',
      '정산 원장 직접 반영은 계속 금지합니다.'
    ]
  };
}

function gwGetPortalImportCandidateFilesForUi() {
  return gwOk_({
    candidateFiles: GW_B10_IMPORT_CANDIDATE_FILES.slice(),
    doNotImportFiles: GW_B10_DO_NOT_IMPORT_FILES.slice(),
    protectedSheets: GW_B10_PROTECTED_SHEETS.slice()
  }, 'B10 PORTAL 이관 후보 파일 목록 조회 완료');
}

function gwInspectB10ImportCandidates_() {
  var actionCounts = {};
  var typeCounts = {};
  GW_B10_IMPORT_CANDIDATE_FILES.forEach(function (item) {
    actionCounts[item.importAction] = (actionCounts[item.importAction] || 0) + 1;
    typeCounts[item.type] = (typeCounts[item.type] || 0) + 1;
  });
  return {
    ok: true,
    candidateFileCount: GW_B10_IMPORT_CANDIDATE_FILES.length,
    doNotImportFiles: GW_B10_DO_NOT_IMPORT_FILES.slice(),
    actionCounts: actionCounts,
    typeCounts: typeCounts,
    portalShellHandling: 'GW_DevShell.html은 그대로 이관하지 않고 본문 요소만 추출합니다.'
  };
}

function gwInspectB10SheetReadiness_() {
  var userHeaders = gwCheckPortalUsersHeaders_();
  var notice = gwInspectNoticeHeadersNoWrite_B03_();
  var library = gwInspectLibraryHeadersNoWrite_B04_();
  var request = gwInspectRequestHeadersNoWrite_B05_();
  var attendance = gwInspectAttendanceHeadersNoWrite_B06_();
  var kpi = gwInspectKpiHeadersNoWrite_B07_();
  var assetSupply = gwInspectAssetSupplyHeadersNoWrite_B08_();
  var expense = gwInspectExpenseHeadersNoWrite_B09_();
  var modules = [
    { moduleCode: 'USERS_PERMISSION', ok: !!userHeaders.ok, sheetName: userHeaders.sheetName || 'PortalUsers' },
    { moduleCode: 'NOTICE_BOARD', ok: !!notice.ok, sheetName: notice.noticeSheetName || '' },
    { moduleCode: 'DOC_LIBRARY', ok: !!library.ok, sheetName: library.librarySheetName || '' },
    { moduleCode: 'REQUEST_APPROVAL', ok: !!request.ok, sheetName: request.requestSheetName || '' },
    { moduleCode: 'CAPS_ATTENDANCE', ok: !!attendance.ok, sheetName: attendance.attendanceSheetName || '' },
    { moduleCode: 'KPI', ok: !!kpi.ok, sheetName: kpi.kpiSheetName || '' },
    { moduleCode: 'ASSET_SUPPLY', ok: !!assetSupply.ok, sheetName: assetSupply.assetSheetName || '' },
    { moduleCode: 'EXPENSE', ok: !!expense.ok, sheetName: expense.expenseSheetName || '' }
  ];
  var failed = modules.filter(function (m) { return !m.ok; });
  return {
    ok: failed.length === 0,
    moduleCount: modules.length,
    failedModuleCount: failed.length,
    modules: modules,
    fallbackModes: {
      supplyRequest: assetSupply.supplyRequestSheetName === 'Portal_Requests' ? 'Portal_Requests' : 'DEDICATED_OR_UNKNOWN',
      expenseRequest: expense.storageMode || 'REQUESTS_FALLBACK'
    }
  };
}

function gwRunB10NoWriteRegression_() {
  var steps = [
    { step: 'B01', fn: function () { return gwRunB01Diagnostics({ writeAudit: false }); } },
    { step: 'B02', fn: function () { return gwRunB02Diagnostics({ ensureHeaders: false, writeTestUser: false }); } },
    { step: 'B03', fn: function () { return gwRunB03Diagnostics({ ensureHeaders: false, writeTestNotice: false }); } },
    { step: 'B04', fn: function () { return gwRunB04Diagnostics({ ensureHeaders: false, writeTestFile: false }); } },
    { step: 'B05', fn: function () { return gwRunB05Diagnostics({ ensureHeaders: false, writeTestRequest: false }); } },
    { step: 'B06', fn: function () { return gwRunB06Diagnostics({ ensureHeaders: false, writeTestAttendance: false }); } },
    { step: 'B07', fn: function () { return gwRunB07Diagnostics({ ensureHeaders: false, writeTestKpi: false }); } },
    { step: 'B08', fn: function () { return gwRunB08Diagnostics({ ensureHeaders: false, writeTestAssetSupply: false }); } },
    { step: 'B09', fn: function () { return gwRunB09Diagnostics({ ensureHeaders: false, writeTestExpense: false }); } }
  ];
  var results = steps.map(function (item) {
    try {
      var result = item.fn();
      var body = result.data || result.detail || {};
      return {
        step: item.step,
        ok: !!result.ok,
        fatalCount: body.fatalCount || 0,
        message: result.message || ''
      };
    } catch (err) {
      return { step: item.step, ok: false, fatalCount: 1, message: gwErrorMessage_(err) };
    }
  });
  var failed = results.filter(function (r) { return !r.ok || r.fatalCount > 0; });
  return {
    ok: failed.length === 0,
    mode: 'NO_WRITE_REGRESSION',
    stepCount: results.length,
    passedCount: results.length - failed.length,
    failedCount: failed.length,
    results: results
  };
}

function gwInspectB10PortalImportPlan_() {
  return {
    ok: true,
    importOrder: [
      '1. PORTAL 공통 Shell/권한/FeatureFlag와 충돌 여부 점검',
      '2. GW_DevShell.html에서 본문 영역만 추출하고 단독 Shell/좌측 메뉴 제거',
      '3. HeaderMap/Config/Audit/Permission 공통 유틸 중 PORTAL 기존 함수와 중복되는 함수명 정리',
      '4. 직원관리, 공지, 자료실, 요청/결재, CAPS 근태, KPI, 자산/비품, 비용요청 본문을 순차 이관',
      '5. PORTAL 디자인 기준으로 본문 CSS 재정렬',
      '6. B01~B09 회귀테스트 후 PORTAL 통합 테스트 실행'
    ],
    blockedItems: [
      'PORTAL 본체에 GW_DevShell.html 전체 병합 금지',
      'PortalUsers 외 별도 계정 DB 생성 금지',
      '정산 원장 직접 수정 금지',
      '신규 대형 시트 무분별 생성 금지',
      '권한 없는 서버 함수 실행 허용 금지'
    ],
    mainDeveloperReviewRequired: true,
    portalImportReadyAfterB10Pass: true
  };
}

function gwWriteB10ImportCandidateAudit_(ctx) {
  return gwAuditSafe_({
    moduleCode: 'GROUPWARE_B10',
    actionType: 'PORTAL_BODY_IMPORT_CANDIDATE_READY',
    targetId: 'GROUPWARE_B10_PORTAL_BODY_IMPORT_CANDIDATE',
    employeeId: ctx && ctx.employeeId,
    resultStatus: 'SUCCESS',
    detailMessage: 'GROUPWARE B01~B09 단독 엔진 통과 후 PORTAL 본문 이관 후보 정리 완료'
  });
}
