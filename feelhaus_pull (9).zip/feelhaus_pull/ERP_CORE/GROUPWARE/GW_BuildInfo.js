const GW_BUILD_INFO = Object.freeze({
  build: '[21/60] GROUPWARE_B21_COMMON_ACTION_HANDLER_HARDENING_JS_ONLY',
  buildNo: 'B21',
  buildStep: '21/60',
  buildName: 'GROUPWARE 공통 액션 핸들러 고도화',
  buildDescription: 'B20 통과본 기반, PORTAL 유일 Shell 원칙 유지, 본문 버튼/action → handler → service → 성공/실패 메시지 → AuditLog 흐름 표준화. 신규 메뉴/시트 생성 없음.',
  createdAt: '2026-06-07T10:00:00+09:00',
  projectName: 'FEELHAUS_PORTAL_GROUPWARE',
  ownerCompany: '(주)필하우스',
  portalShellOnly: true,
  portalIntegrationMode: 'PORTAL_BODY_COMMON_ACTION_HANDLER_HARDENING'
});

function gwGetBuildInfo() {
  return Object.assign({}, GW_BUILD_INFO);
}
