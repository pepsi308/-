# [10/10] GROUPWARE_B10_PORTAL_BODY_IMPORT_CANDIDATE_JS_ONLY

## 목적
B09 통과본을 기준으로 GROUPWARE 단독 엔진을 PORTAL 본문 이관 후보로 정리합니다.

## 핵심 원칙
- ZIP 내부 `.gs` 파일 금지, `.js` 파일만 포함합니다.
- B10은 신규 업무 원장을 만들지 않습니다.
- `GW_DevShell.html`은 PORTAL에 그대로 이관하지 않습니다. 본문 요소만 추출합니다.
- `PortalUsers`, `SystemConfig`, `FEELHAUS_DB_MASTER`, `Portal_AuditLog`, HeaderMap, 권한검사 구조는 보호합니다.
- 셀 한도 보호를 위해 비품요청/비용요청은 `Portal_Requests` fallback 구조를 유지합니다.

## 실행 함수
1. `gwInternalTest_B10_Smoke_NoWrite()` - 위치 파일: `GW_Test.js`, 쓰기 없음
2. `gwInternalTest_B10_Regression_NoWrite()` - 위치 파일: `GW_Test.js`, B01~B09 no-write 회귀테스트
3. `gwInternalTest_B10_All()` - 위치 파일: `GW_Test.js`, B10 전체 진단 및 AuditLog 기록 가능

## 다음 단계
B10 통과 후 실제 PORTAL 이관은 B11 이후 별도 작업으로 진행합니다.
