function gwGetSheet_(ss, sheetName, createIfMissing) {
  var sheet = ss.getSheetByName(sheetName);
  if (!sheet && createIfMissing) sheet = ss.insertSheet(sheetName);
  if (!sheet) throw new Error(sheetName + ' 시트를 찾을 수 없습니다.');
  return sheet;
}

function gwGetHeaders_(sheet) {
  var lastCol = Math.max(sheet.getLastColumn(), 1);
  var values = sheet.getRange(1, 1, 1, lastCol).getValues()[0];
  return values.map(function (h) { return gwToSafeText_(h); });
}

function gwBuildHeaderMap_(headers) {
  var map = {};
  headers.forEach(function (h, idx) {
    if (h) map[h] = idx;
  });
  return map;
}

function gwCheckRequiredHeaders_(sheet, requiredHeaders) {
  var headers = gwGetHeaders_(sheet);
  var map = gwBuildHeaderMap_(headers);
  var missing = requiredHeaders.filter(function (h) { return typeof map[h] === 'undefined'; });
  return {
    ok: missing.length === 0,
    sheetName: sheet.getName(),
    headers: headers,
    missing: missing
  };
}

function gwEnsureHeaders_(sheet, requiredHeaders) {
  var result = gwCheckRequiredHeaders_(sheet, requiredHeaders);
  if (result.missing.length === 0) return result;

  var headers = result.headers.filter(function (h) { return h; });
  var merged = headers.concat(result.missing);
  sheet.getRange(1, 1, 1, merged.length).setValues([merged]);
  return gwCheckRequiredHeaders_(sheet, requiredHeaders);
}

function gwReadRowsAsObjects_(sheet) {
  var values = sheet.getDataRange().getValues();
  if (!values || values.length < 2) return [];
  var headers = values[0].map(function (h) { return gwToSafeText_(h); });
  return values.slice(1).filter(function (row) {
    return row.some(function (v) { return gwToSafeText_(v) !== ''; });
  }).map(function (row, rowIdx) {
    var obj = { _rowNumber: rowIdx + 2 };
    headers.forEach(function (h, idx) {
      if (h) obj[h] = row[idx];
    });
    return obj;
  });
}

function gwAppendObjectRow_(sheet, obj, requiredHeaders) {
  if (requiredHeaders && requiredHeaders.length) gwEnsureHeaders_(sheet, requiredHeaders);
  var headers = gwGetHeaders_(sheet).filter(function (h) { return h; });
  var row = headers.map(function (h) {
    return Object.prototype.hasOwnProperty.call(obj, h) ? obj[h] : '';
  });
  sheet.appendRow(row);
  return sheet.getLastRow();
}
