
const GW_CAPS_RAW_SHEET_CANDIDATES = Object.freeze(['Portal_AttendanceRaw_CAPS', 'PORTAL_AttendanceRaw_CAPS', 'GW_AttendanceRaw_CAPS', 'AttendanceRaw_CAPS', 'CapsAttendanceRaw']);
const GW_CAPS_RAW_PREFERRED_SHEET_NAME = 'Portal_AttendanceRaw_CAPS';
const GW_CAPS_MAP_SHEET_CANDIDATES = Object.freeze(['Portal_AttendanceCapsMap', 'PORTAL_AttendanceCapsMap', 'GW_AttendanceCapsMap', 'AttendanceCapsMap', 'CapsUserMap']);
const GW_CAPS_MAP_PREFERRED_SHEET_NAME = 'Portal_AttendanceCapsMap';
const GW_ATTENDANCE_SHEET_CANDIDATES = Object.freeze(['Portal_Attendance', 'PORTAL_Attendance', 'GW_Attendance', 'Attendance']);
const GW_ATTENDANCE_PREFERRED_SHEET_NAME = 'Portal_Attendance';
const GW_ATTENDANCE_EXCEPTION_SHEET_CANDIDATES = Object.freeze(['Portal_AttendanceExceptions', 'PORTAL_AttendanceExceptions', 'GW_AttendanceExceptions', 'AttendanceExceptions']);
const GW_ATTENDANCE_EXCEPTION_PREFERRED_SHEET_NAME = 'Portal_AttendanceExceptions';

const GW_CAPS_RAW_HEADERS = Object.freeze([
  'rawAttendanceId', 'sourceSystem', 'sourceRecordId', 'externalEmployeeKey', 'externalEmployeeName', 'externalDepartment',
  'externalDeviceId', 'externalDeviceName', 'rawEventType', 'rawEventAt', 'rawWorkDate', 'rawCheckInAt', 'rawCheckOutAt',
  'rawStatus', 'rawPayloadHash', 'rawPayloadJson', 'syncBatchId', 'syncStatus', 'syncMessage', 'createdAt', 'createdBy'
]);
const GW_CAPS_MAP_HEADERS = Object.freeze([
  'capsMapId', 'employeeId', 'employeeName', 'email', 'capsUserId', 'capsEmployeeNo', 'capsCardNo', 'capsDepartment',
  'matchStatus', 'matchConfidence', 'status', 'statusReason', 'createdAt', 'createdBy', 'updatedAt', 'updatedBy'
]);
const GW_ATTENDANCE_HEADERS = Object.freeze([
  'attendanceId', 'employeeId', 'workDate', 'checkInAt', 'checkOutAt', 'workStatus', 'workMemo', 'locationMemo',
  'sourceSystem', 'sourceRawIds', 'syncBatchId', 'capsMatchedYn', 'exceptionYn', 'exceptionType', 'approvedYn',
  'approvedBy', 'approvedAt', 'status', 'statusReason', 'createdAt', 'createdBy', 'updatedAt', 'updatedBy'
]);
const GW_ATTENDANCE_EXCEPTION_HEADERS = Object.freeze([
  'attendanceExceptionId', 'attendanceId', 'employeeId', 'workDate', 'exceptionType', 'exceptionReason', 'requestedBy',
  'requestStatus', 'approvedBy', 'approvedAt', 'rejectedReason', 'status', 'statusReason', 'createdAt', 'createdBy', 'updatedAt', 'updatedBy'
]);

const GW_CAPS_SYNC_STATUSES = Object.freeze(['PENDING', 'FETCHED', 'MAPPED', 'APPLIED', 'SKIPPED', 'FAILED', 'NEEDS_REVIEW']);
const GW_CAPS_MATCH_STATUSES = Object.freeze(['MATCHED', 'UNMATCHED', 'DUPLICATED', 'NEEDS_REVIEW', 'DISABLED']);
const GW_ATTENDANCE_WORK_STATUSES = Object.freeze(['WORK', 'LATE', 'LEAVE', 'ABSENT', 'OUTSIDE', 'HALF_DAY', 'HOLIDAY', 'MISSING_CHECKOUT', 'MISSING_CHECKIN', 'NEEDS_REVIEW']);
const GW_ATTENDANCE_EXCEPTION_TYPES = Object.freeze(['UNMATCHED_EMPLOYEE', 'MISSING_CHECKOUT', 'MISSING_CHECKIN', 'DUPLICATED_EVENT', 'HOLIDAY_EVENT', 'MANUAL_REVIEW']);

function gwGetB06AttendanceMeta_() {
  return {
    buildStep: '06/10',
    sourceSystem: 'CAPS',
    inputModes: ['API_ADAPTER_PENDING', 'MOCK', 'CSV_EXCEL_UPLOAD_READY', 'DRIVE_FILE_COLLECT_READY'],
    rawSheetCandidates: GW_CAPS_RAW_SHEET_CANDIDATES.slice(),
    mapSheetCandidates: GW_CAPS_MAP_SHEET_CANDIDATES.slice(),
    attendanceSheetCandidates: GW_ATTENDANCE_SHEET_CANDIDATES.slice(),
    exceptionSheetCandidates: GW_ATTENDANCE_EXCEPTION_SHEET_CANDIDATES.slice(),
    syncStatuses: GW_CAPS_SYNC_STATUSES.slice(),
    matchStatuses: GW_CAPS_MATCH_STATUSES.slice(),
    workStatuses: GW_ATTENDANCE_WORK_STATUSES.slice(),
    exceptionTypes: GW_ATTENDANCE_EXCEPTION_TYPES.slice(),
    requiredRawHeaderCount: GW_CAPS_RAW_HEADERS.length,
    requiredMapHeaderCount: GW_CAPS_MAP_HEADERS.length,
    requiredAttendanceHeaderCount: GW_ATTENDANCE_HEADERS.length,
    requiredExceptionHeaderCount: GW_ATTENDANCE_EXCEPTION_HEADERS.length
  };
}

function gwGetCapsRawSheet_(createIfMissing) { return gwFindOrCreateB06Sheet_(GW_CAPS_RAW_SHEET_CANDIDATES, GW_CAPS_RAW_PREFERRED_SHEET_NAME, GW_CAPS_RAW_HEADERS, createIfMissing, 'CAPS Raw'); }
function gwGetCapsMapSheet_(createIfMissing) { return gwFindOrCreateB06Sheet_(GW_CAPS_MAP_SHEET_CANDIDATES, GW_CAPS_MAP_PREFERRED_SHEET_NAME, GW_CAPS_MAP_HEADERS, createIfMissing, 'CAPS 직원 매칭'); }
function gwGetAttendanceSheet_(createIfMissing) { return gwFindOrCreateB06Sheet_(GW_ATTENDANCE_SHEET_CANDIDATES, GW_ATTENDANCE_PREFERRED_SHEET_NAME, GW_ATTENDANCE_HEADERS, createIfMissing, '근태 원장'); }
function gwGetAttendanceExceptionSheet_(createIfMissing) { return gwFindOrCreateB06Sheet_(GW_ATTENDANCE_EXCEPTION_SHEET_CANDIDATES, GW_ATTENDANCE_EXCEPTION_PREFERRED_SHEET_NAME, GW_ATTENDANCE_EXCEPTION_HEADERS, createIfMissing, '근태 예외'); }

function gwFindOrCreateB06Sheet_(candidates, preferredName, headers, createIfMissing, label) {
  var ss = gwGetMasterSpreadsheet_();
  for (var i = 0; i < candidates.length; i++) {
    var sheet = ss.getSheetByName(candidates[i]);
    if (sheet) return sheet;
  }
  if (createIfMissing) {
    var created = ss.insertSheet(preferredName);
    created.getRange(1, 1, 1, headers.length).setValues([headers]);
    return created;
  }
  throw new Error(label + ' 시트를 찾을 수 없습니다. 허용 시트명: ' + candidates.join(', '));
}

function gwEnsureCapsRawHeaders_() { return gwEnsureB06Headers_(gwGetCapsRawSheet_(true), GW_CAPS_RAW_HEADERS); }
function gwEnsureCapsMapHeaders_() { return gwEnsureB06Headers_(gwGetCapsMapSheet_(true), GW_CAPS_MAP_HEADERS); }
function gwEnsureAttendanceHeaders_() { return gwEnsureB06Headers_(gwGetAttendanceSheet_(true), GW_ATTENDANCE_HEADERS); }
function gwEnsureAttendanceExceptionHeaders_() { return gwEnsureB06Headers_(gwGetAttendanceExceptionSheet_(true), GW_ATTENDANCE_EXCEPTION_HEADERS); }

function gwEnsureB06Headers_(sheet, headers) {
  var before = gwGetHeaders_(sheet).filter(function (h) { return h; });
  var result = gwEnsureHeaders_(sheet, headers.slice());
  var after = gwGetHeaders_(sheet).filter(function (h) { return h; });
  return { ok: result.ok, sheetName: sheet.getName(), beforeCount: before.length, afterCount: after.length, addedHeaders: after.filter(function (h) { return before.indexOf(h) < 0; }), missing: result.missing || [] };
}

function gwInspectAttendanceHeadersNoWrite_B06_() {
  var ss = gwGetMasterSpreadsheet_();
  var rawSheet = gwFindExistingB06Sheet_(ss, GW_CAPS_RAW_SHEET_CANDIDATES);
  var mapSheet = gwFindExistingB06Sheet_(ss, GW_CAPS_MAP_SHEET_CANDIDATES);
  var attendanceSheet = gwFindExistingB06Sheet_(ss, GW_ATTENDANCE_SHEET_CANDIDATES);
  var exceptionSheet = gwFindExistingB06Sheet_(ss, GW_ATTENDANCE_EXCEPTION_SHEET_CANDIDATES);
  var result = {
    ok: true,
    mode: 'NO_WRITE_INSPECT',
    prepareRequired: false,
    rawSheetExists: !!rawSheet,
    mapSheetExists: !!mapSheet,
    attendanceSheetExists: !!attendanceSheet,
    exceptionSheetExists: !!exceptionSheet,
    rawSheetName: rawSheet ? rawSheet.getName() : '',
    mapSheetName: mapSheet ? mapSheet.getName() : '',
    attendanceSheetName: attendanceSheet ? attendanceSheet.getName() : '',
    exceptionSheetName: exceptionSheet ? exceptionSheet.getName() : '',
    missingRawHeaders: [],
    missingMapHeaders: [],
    missingAttendanceHeaders: [],
    missingExceptionHeaders: []
  };
  if (!rawSheet) result.prepareRequired = true; else { var c1 = gwCheckRequiredHeaders_(rawSheet, GW_CAPS_RAW_HEADERS.slice()); result.missingRawHeaders = c1.missing || []; if (!c1.ok) result.prepareRequired = true; }
  if (!mapSheet) result.prepareRequired = true; else { var c2 = gwCheckRequiredHeaders_(mapSheet, GW_CAPS_MAP_HEADERS.slice()); result.missingMapHeaders = c2.missing || []; if (!c2.ok) result.prepareRequired = true; }
  if (!attendanceSheet) result.prepareRequired = true; else { var c3 = gwCheckRequiredHeaders_(attendanceSheet, GW_ATTENDANCE_HEADERS.slice()); result.missingAttendanceHeaders = c3.missing || []; if (!c3.ok) result.prepareRequired = true; }
  if (!exceptionSheet) result.prepareRequired = true; else { var c4 = gwCheckRequiredHeaders_(exceptionSheet, GW_ATTENDANCE_EXCEPTION_HEADERS.slice()); result.missingExceptionHeaders = c4.missing || []; if (!c4.ok) result.prepareRequired = true; }
  return result;
}

function gwFindExistingB06Sheet_(ss, candidates) {
  for (var i = 0; i < candidates.length; i++) {
    var sheet = ss.getSheetByName(candidates[i]);
    if (sheet) return sheet;
  }
  return null;
}

function gwSyncCapsMockForUi(payload) {
  payload = payload || {};
  var ctx = gwAssertPermission_('canAccessPortal');
  gwEnsureCapsRawHeaders_();
  gwEnsureCapsMapHeaders_();
  gwEnsureAttendanceHeaders_();
  gwEnsureAttendanceExceptionHeaders_();
  var mapResult = gwEnsureCapsTestMap_(ctx);
  var records = gwBuildCapsMockRecords_(ctx, payload);
  var rawResult = gwSaveCapsRawRecords_(records, ctx, { mode: 'MOCK' });
  var applyResult = gwApplyCapsRawToAttendance_({ syncBatchId: rawResult.syncBatchId }, ctx);
  return gwOk_({ map: mapResult, raw: rawResult, apply: applyResult }, 'CAPS Mock 동기화 완료');
}

function gwEnsureCapsTestMap_(ctx) {
  ctx = ctx || gwGetUserContextSafe_();
  var sheet = gwGetCapsMapSheet_(true);
  gwEnsureHeaders_(sheet, GW_CAPS_MAP_HEADERS.slice());
  var capsUserId = 'CAPS-' + gwToSafeText_(ctx.employeeId || 'UNKNOWN');
  var rows = gwReadRowsAsObjects_(sheet);
  var found = null;
  for (var i = 0; i < rows.length; i++) {
    if (gwToSafeText_(rows[i].capsUserId) === capsUserId || gwToSafeText_(rows[i].capsEmployeeNo) === capsUserId) { found = rows[i]; break; }
  }
  var now = gwNow_();
  var obj = {
    capsMapId: found && found.capsMapId ? found.capsMapId : gwUuid_('CAPSMAP'),
    employeeId: ctx.employeeId,
    employeeName: ctx.employeeName,
    email: ctx.email,
    capsUserId: capsUserId,
    capsEmployeeNo: capsUserId,
    capsCardNo: 'TEST-CARD-' + ctx.employeeId,
    capsDepartment: 'GROUPWARE_TEST',
    matchStatus: 'MATCHED',
    matchConfidence: '100',
    status: 'ACTIVE',
    statusReason: 'B06 내부 테스트 매칭',
    createdAt: found && found.createdAt ? found.createdAt : now,
    createdBy: found && found.createdBy ? found.createdBy : ctx.employeeId,
    updatedAt: now,
    updatedBy: ctx.employeeId
  };
  if (found) {
    gwUpdateObjectRowByRowNumber_(sheet, found._rowNumber, obj);
    return { ok: true, action: 'UPDATE', sheetName: sheet.getName(), rowNumber: found._rowNumber, capsUserId: capsUserId, employeeId: ctx.employeeId };
  }
  var rowNumber = gwAppendObjectRow_(sheet, obj, GW_CAPS_MAP_HEADERS.slice());
  return { ok: true, action: 'CREATE', sheetName: sheet.getName(), rowNumber: rowNumber, capsUserId: capsUserId, employeeId: ctx.employeeId };
}

function gwBuildCapsMockRecords_(ctx, payload) {
  ctx = ctx || gwGetUserContextSafe_();
  payload = payload || {};
  var workDate = gwToSafeText_(payload.workDate) || Utilities.formatDate(new Date(), 'Asia/Seoul', 'yyyy-MM-dd');
  var batch = gwToSafeText_(payload.syncBatchId) || gwUuid_('CAPSBATCH');
  var capsUserId = 'CAPS-' + ctx.employeeId;
  return [
    { sourceRecordId: 'CAPS-B06-CHECKIN-' + ctx.employeeId + '-' + workDate, externalEmployeeKey: capsUserId, externalEmployeeName: ctx.employeeName, rawEventType: 'CHECK_IN', rawEventAt: workDate + ' 09:00:00', rawWorkDate: workDate, rawCheckInAt: workDate + ' 09:00:00', rawCheckOutAt: '', externalDeviceId: 'DEV-B06', externalDeviceName: 'B06 MOCK DEVICE', syncBatchId: batch },
    { sourceRecordId: 'CAPS-B06-CHECKOUT-' + ctx.employeeId + '-' + workDate, externalEmployeeKey: capsUserId, externalEmployeeName: ctx.employeeName, rawEventType: 'CHECK_OUT', rawEventAt: workDate + ' 18:00:00', rawWorkDate: workDate, rawCheckInAt: '', rawCheckOutAt: workDate + ' 18:00:00', externalDeviceId: 'DEV-B06', externalDeviceName: 'B06 MOCK DEVICE', syncBatchId: batch }
  ];
}

function gwSaveCapsRawRecords_(records, ctx, options) {
  ctx = ctx || gwGetUserContextSafe_();
  options = options || {};
  var sheet = gwGetCapsRawSheet_(true);
  gwEnsureHeaders_(sheet, GW_CAPS_RAW_HEADERS.slice());
  var existing = gwReadRowsAsObjects_(sheet);
  var bySource = {};
  existing.forEach(function (r) { bySource[gwToSafeText_(r.sourceRecordId)] = r; });
  var syncBatchId = '';
  var created = 0;
  var updated = 0;
  var now = gwNow_();
  (records || []).forEach(function (rec) {
    var sourceRecordId = gwToSafeText_(rec.sourceRecordId) || gwUuid_('CAPSREC');
    syncBatchId = gwToSafeText_(rec.syncBatchId) || syncBatchId || gwUuid_('CAPSBATCH');
    var old = bySource[sourceRecordId];
    var obj = {
      rawAttendanceId: old && old.rawAttendanceId ? old.rawAttendanceId : gwUuid_('CAPSRAW'),
      sourceSystem: 'CAPS',
      sourceRecordId: sourceRecordId,
      externalEmployeeKey: gwToSafeText_(rec.externalEmployeeKey),
      externalEmployeeName: gwToSafeText_(rec.externalEmployeeName),
      externalDepartment: gwToSafeText_(rec.externalDepartment || ''),
      externalDeviceId: gwToSafeText_(rec.externalDeviceId || ''),
      externalDeviceName: gwToSafeText_(rec.externalDeviceName || ''),
      rawEventType: gwToSafeText_(rec.rawEventType).toUpperCase(),
      rawEventAt: gwToSafeText_(rec.rawEventAt),
      rawWorkDate: gwToSafeText_(rec.rawWorkDate || gwDatePart_(rec.rawEventAt)),
      rawCheckInAt: gwToSafeText_(rec.rawCheckInAt),
      rawCheckOutAt: gwToSafeText_(rec.rawCheckOutAt),
      rawStatus: gwToSafeText_(rec.rawStatus || 'NORMAL'),
      rawPayloadHash: sourceRecordId,
      rawPayloadJson: JSON.stringify({ sourceRecordId: sourceRecordId, rawEventType: gwToSafeText_(rec.rawEventType), rawEventAt: gwToSafeText_(rec.rawEventAt) }),
      syncBatchId: syncBatchId,
      syncStatus: 'FETCHED',
      syncMessage: gwToSafeText_(options.mode || 'B06_SYNC'),
      createdAt: old && old.createdAt ? old.createdAt : now,
      createdBy: old && old.createdBy ? old.createdBy : ctx.employeeId
    };
    if (old) { gwUpdateObjectRowByRowNumber_(sheet, old._rowNumber, obj); updated++; }
    else { gwAppendObjectRow_(sheet, obj, GW_CAPS_RAW_HEADERS.slice()); created++; }
  });
  gwAuditSafe_({ moduleCode: 'GROUPWARE_ATTENDANCE_CAPS', actionType: 'CAPS_RAW_SYNC', targetId: syncBatchId, employeeId: ctx.employeeId, resultStatus: 'SUCCESS', detailMessage: 'CAPS Raw 저장 created=' + created + ', updated=' + updated });
  return { ok: true, syncBatchId: syncBatchId, sheetName: sheet.getName(), created: created, updated: updated, total: (records || []).length };
}

function gwApplyCapsRawToAttendance_(payload, ctx) {
  payload = payload || {};
  ctx = ctx || gwGetUserContextSafe_();
  var rawSheet = gwGetCapsRawSheet_(true);
  var attendanceSheet = gwGetAttendanceSheet_(true);
  var exceptionSheet = gwGetAttendanceExceptionSheet_(true);
  gwEnsureHeaders_(rawSheet, GW_CAPS_RAW_HEADERS.slice());
  gwEnsureHeaders_(attendanceSheet, GW_ATTENDANCE_HEADERS.slice());
  gwEnsureHeaders_(exceptionSheet, GW_ATTENDANCE_EXCEPTION_HEADERS.slice());
  var syncBatchId = gwToSafeText_(payload.syncBatchId);
  var rawRows = gwReadRowsAsObjects_(rawSheet).map(gwNormalizeCapsRawRow_).filter(function (r) {
    if (syncBatchId && r.syncBatchId !== syncBatchId) return false;
    return ['FETCHED', 'PENDING', 'MAPPED'].indexOf(r.syncStatus) >= 0;
  });
  var mapByExternal = gwBuildCapsMapByExternalKey_();
  var grouped = {};
  var unmatched = 0;
  rawRows.forEach(function (r) {
    var map = mapByExternal[r.externalEmployeeKey];
    if (!map) { unmatched++; gwCreateAttendanceException_('', 'UNKNOWN', r.rawWorkDate, 'UNMATCHED_EMPLOYEE', 'CAPS 직원 매칭 실패: ' + r.externalEmployeeKey, ctx, 'REQUESTED'); return; }
    var key = map.employeeId + '|' + r.rawWorkDate;
    if (!grouped[key]) grouped[key] = { employeeId: map.employeeId, workDate: r.rawWorkDate, checkIns: [], checkOuts: [], rawIds: [], syncBatchId: r.syncBatchId };
    if (r.rawCheckInAt || r.rawEventType === 'CHECK_IN') grouped[key].checkIns.push(r.rawCheckInAt || r.rawEventAt);
    if (r.rawCheckOutAt || r.rawEventType === 'CHECK_OUT') grouped[key].checkOuts.push(r.rawCheckOutAt || r.rawEventAt);
    grouped[key].rawIds.push(r.rawAttendanceId);
  });
  var applied = 0;
  var exceptions = unmatched;
  Object.keys(grouped).forEach(function (key) {
    var g = grouped[key];
    var checkInAt = gwMinDateText_(g.checkIns);
    var checkOutAt = gwMaxDateText_(g.checkOuts);
    var exceptionYn = checkInAt && !checkOutAt ? 'Y' : 'N';
    var exceptionType = exceptionYn === 'Y' ? 'MISSING_CHECKOUT' : '';
    var workStatus = exceptionYn === 'Y' ? 'MISSING_CHECKOUT' : 'WORK';
    var result = gwUpsertAttendanceLedger_(g.employeeId, g.workDate, {
      checkInAt: checkInAt,
      checkOutAt: checkOutAt,
      workStatus: workStatus,
      workMemo: 'CAPS 연동 반영',
      locationMemo: '',
      sourceSystem: 'CAPS',
      sourceRawIds: g.rawIds.join(','),
      syncBatchId: g.syncBatchId,
      capsMatchedYn: 'Y',
      exceptionYn: exceptionYn,
      exceptionType: exceptionType,
      approvedYn: 'N',
      status: 'ACTIVE',
      statusReason: 'B06 CAPS 동기화 반영'
    }, ctx);
    applied++;
    if (exceptionYn === 'Y') { exceptions++; gwCreateAttendanceException_(result.attendanceId, g.employeeId, g.workDate, exceptionType, '퇴근 기록 누락', ctx, 'REQUESTED'); }
  });
  gwAuditSafe_({ moduleCode: 'GROUPWARE_ATTENDANCE_CAPS', actionType: 'CAPS_APPLY_ATTENDANCE', targetId: syncBatchId, employeeId: ctx.employeeId, resultStatus: 'SUCCESS', detailMessage: 'CAPS Raw 근태 원장 반영 applied=' + applied + ', exceptions=' + exceptions });
  return { ok: true, syncBatchId: syncBatchId, rawCount: rawRows.length, applied: applied, exceptions: exceptions, unmatched: unmatched, attendanceSheetName: attendanceSheet.getName(), exceptionSheetName: exceptionSheet.getName() };
}

function gwUpsertAttendanceLedger_(employeeId, workDate, data, ctx) {
  var sheet = gwGetAttendanceSheet_(true);
  gwEnsureHeaders_(sheet, GW_ATTENDANCE_HEADERS.slice());
  var rows = gwReadRowsAsObjects_(sheet);
  var found = null;
  for (var i = 0; i < rows.length; i++) {
    if (gwToSafeText_(rows[i].employeeId) === employeeId && gwToSafeText_(rows[i].workDate) === workDate && gwToSafeText_(rows[i].sourceSystem) === 'CAPS') { found = rows[i]; break; }
  }
  var now = gwNow_();
  var obj = {
    attendanceId: found && found.attendanceId ? found.attendanceId : gwUuid_('ATT'),
    employeeId: employeeId,
    workDate: workDate,
    checkInAt: data.checkInAt || '',
    checkOutAt: data.checkOutAt || '',
    workStatus: data.workStatus || 'NEEDS_REVIEW',
    workMemo: data.workMemo || '',
    locationMemo: data.locationMemo || '',
    sourceSystem: data.sourceSystem || 'CAPS',
    sourceRawIds: data.sourceRawIds || '',
    syncBatchId: data.syncBatchId || '',
    capsMatchedYn: data.capsMatchedYn || 'Y',
    exceptionYn: data.exceptionYn || 'N',
    exceptionType: data.exceptionType || '',
    approvedYn: data.approvedYn || 'N',
    approvedBy: found && found.approvedBy ? found.approvedBy : '',
    approvedAt: found && found.approvedAt ? found.approvedAt : '',
    status: data.status || 'ACTIVE',
    statusReason: data.statusReason || '',
    createdAt: found && found.createdAt ? found.createdAt : now,
    createdBy: found && found.createdBy ? found.createdBy : ctx.employeeId,
    updatedAt: now,
    updatedBy: ctx.employeeId
  };
  if (found) gwUpdateObjectRowByRowNumber_(sheet, found._rowNumber, obj); else gwAppendObjectRow_(sheet, obj, GW_ATTENDANCE_HEADERS.slice());
  return { ok: true, attendanceId: obj.attendanceId, employeeId: employeeId, workDate: workDate, action: found ? 'UPDATE' : 'CREATE' };
}

function gwCreateAttendanceException_(attendanceId, employeeId, workDate, exceptionType, reason, ctx, requestStatus) {
  var sheet = gwGetAttendanceExceptionSheet_(true);
  gwEnsureHeaders_(sheet, GW_ATTENDANCE_EXCEPTION_HEADERS.slice());
  var rows = gwReadRowsAsObjects_(sheet);
  for (var i = 0; i < rows.length; i++) {
    if (gwToSafeText_(rows[i].attendanceId) === gwToSafeText_(attendanceId) && gwToSafeText_(rows[i].employeeId) === gwToSafeText_(employeeId) && gwToSafeText_(rows[i].workDate) === gwToSafeText_(workDate) && gwToSafeText_(rows[i].exceptionType) === gwToSafeText_(exceptionType) && gwToSafeText_(rows[i].status) !== 'COMPLETED') {
      return { ok: true, action: 'SKIP_DUPLICATE', attendanceExceptionId: rows[i].attendanceExceptionId };
    }
  }
  var now = gwNow_();
  var obj = {
    attendanceExceptionId: gwUuid_('ATEX'),
    attendanceId: gwToSafeText_(attendanceId),
    employeeId: gwToSafeText_(employeeId),
    workDate: gwToSafeText_(workDate),
    exceptionType: gwToSafeText_(exceptionType),
    exceptionReason: gwToSafeText_(reason),
    requestedBy: ctx.employeeId,
    requestStatus: requestStatus || 'REQUESTED',
    approvedBy: '',
    approvedAt: '',
    rejectedReason: '',
    status: 'ACTIVE',
    statusReason: 'B06 예외 자동 생성',
    createdAt: now,
    createdBy: ctx.employeeId,
    updatedAt: now,
    updatedBy: ctx.employeeId
  };
  var rowNumber = gwAppendObjectRow_(sheet, obj, GW_ATTENDANCE_EXCEPTION_HEADERS.slice());
  return { ok: true, action: 'CREATE', rowNumber: rowNumber, attendanceExceptionId: obj.attendanceExceptionId };
}

function gwListAttendanceForUi(payload) {
  payload = payload || {};
  var ctx = gwAssertPermission_('canAccessPortal');
  var sheet = gwGetAttendanceSheet_(true);
  gwEnsureHeaders_(sheet, GW_ATTENDANCE_HEADERS.slice());
  var rows = gwReadRowsAsObjects_(sheet).map(gwNormalizeAttendanceRow_);
  var includeAll = payload.includeAll === true && (gwCanSafe_(ctx, 'canViewLogs') || gwCanSafe_(ctx, 'canAccessDevConsole'));
  var employeeId = gwToSafeText_(payload.employeeId || (includeAll ? '' : ctx.employeeId));
  var workDate = gwToSafeText_(payload.workDate);
  rows = rows.filter(function (r) {
    if (employeeId && r.employeeId !== employeeId) return false;
    if (workDate && r.workDate !== workDate) return false;
    return true;
  });
  rows.sort(function (a, b) { return String(b.workDate).localeCompare(String(a.workDate)); });
  var limit = Math.min(Number(payload.limit || 100), 500);
  return gwOk_({ rows: rows.slice(0, limit), totalReturned: Math.min(rows.length, limit), sheetName: sheet.getName() }, '근태 목록 조회 완료');
}

function gwListAttendanceExceptionsForUi(payload) {
  payload = payload || {};
  var ctx = gwAssertPermission_('canAccessPortal');
  var sheet = gwGetAttendanceExceptionSheet_(true);
  gwEnsureHeaders_(sheet, GW_ATTENDANCE_EXCEPTION_HEADERS.slice());
  var rows = gwReadRowsAsObjects_(sheet).map(gwNormalizeAttendanceExceptionRow_);
  var includeAll = payload.includeAll === true && (gwCanSafe_(ctx, 'canApprove') || gwCanSafe_(ctx, 'canAccessDevConsole'));
  if (!includeAll) rows = rows.filter(function (r) { return r.employeeId === ctx.employeeId || r.requestedBy === ctx.employeeId; });
  var limit = Math.min(Number(payload.limit || 100), 500);
  return gwOk_({ rows: rows.slice(0, limit), totalReturned: Math.min(rows.length, limit), sheetName: sheet.getName() }, '근태 예외 목록 조회 완료');
}

function gwListCapsRawForUi(payload) {
  payload = payload || {};
  gwAssertPermission_('canViewLogs');
  var sheet = gwGetCapsRawSheet_(true);
  gwEnsureHeaders_(sheet, GW_CAPS_RAW_HEADERS.slice());
  var rows = gwReadRowsAsObjects_(sheet).map(gwNormalizeCapsRawRow_);
  var limit = Math.min(Number(payload.limit || 100), 500);
  return gwOk_({ rows: rows.slice(0, limit), totalReturned: Math.min(rows.length, limit), sheetName: sheet.getName() }, 'CAPS Raw 목록 조회 완료');
}

function gwBuildCapsMapByExternalKey_() {
  var sheet = gwGetCapsMapSheet_(true);
  gwEnsureHeaders_(sheet, GW_CAPS_MAP_HEADERS.slice());
  var rows = gwReadRowsAsObjects_(sheet);
  var map = {};
  rows.forEach(function (r) {
    var status = gwToSafeText_(r.matchStatus).toUpperCase();
    var active = gwToSafeText_(r.status).toUpperCase();
    if (status !== 'MATCHED' || active === 'DISABLED' || active === 'INACTIVE') return;
    [r.capsUserId, r.capsEmployeeNo, r.capsCardNo].forEach(function (key) { key = gwToSafeText_(key); if (key) map[key] = { employeeId: gwToSafeText_(r.employeeId), employeeName: gwToSafeText_(r.employeeName) }; });
  });
  return map;
}

function gwUpdateObjectRowByRowNumber_(sheet, rowNumber, obj) {
  var headers = gwGetHeaders_(sheet).filter(function (h) { return h; });
  var row = headers.map(function (h) { return Object.prototype.hasOwnProperty.call(obj, h) ? obj[h] : ''; });
  sheet.getRange(Number(rowNumber), 1, 1, row.length).setValues([row]);
}
function gwNormalizeCapsRawRow_(row) { return { rawAttendanceId: gwToSafeText_(row.rawAttendanceId), sourceSystem: gwToSafeText_(row.sourceSystem), sourceRecordId: gwToSafeText_(row.sourceRecordId), externalEmployeeKey: gwToSafeText_(row.externalEmployeeKey), externalEmployeeName: gwToSafeText_(row.externalEmployeeName), rawEventType: gwToSafeText_(row.rawEventType).toUpperCase(), rawEventAt: gwToSafeText_(row.rawEventAt), rawWorkDate: gwToSafeText_(row.rawWorkDate), rawCheckInAt: gwToSafeText_(row.rawCheckInAt), rawCheckOutAt: gwToSafeText_(row.rawCheckOutAt), syncBatchId: gwToSafeText_(row.syncBatchId), syncStatus: gwToSafeText_(row.syncStatus).toUpperCase(), _rowNumber: row._rowNumber }; }
function gwNormalizeAttendanceRow_(row) { return { attendanceId: gwToSafeText_(row.attendanceId), employeeId: gwToSafeText_(row.employeeId), workDate: gwToSafeText_(row.workDate), checkInAt: gwToSafeText_(row.checkInAt), checkOutAt: gwToSafeText_(row.checkOutAt), workStatus: gwToSafeText_(row.workStatus), sourceSystem: gwToSafeText_(row.sourceSystem), exceptionYn: gwToSafeText_(row.exceptionYn), exceptionType: gwToSafeText_(row.exceptionType), status: gwToSafeText_(row.status), _rowNumber: row._rowNumber }; }
function gwNormalizeAttendanceExceptionRow_(row) { return { attendanceExceptionId: gwToSafeText_(row.attendanceExceptionId), attendanceId: gwToSafeText_(row.attendanceId), employeeId: gwToSafeText_(row.employeeId), workDate: gwToSafeText_(row.workDate), exceptionType: gwToSafeText_(row.exceptionType), exceptionReason: gwToSafeText_(row.exceptionReason), requestStatus: gwToSafeText_(row.requestStatus), status: gwToSafeText_(row.status), _rowNumber: row._rowNumber }; }
function gwDatePart_(value) { var text = gwToSafeText_(value); return text.length >= 10 ? text.slice(0, 10) : text; }
function gwMinDateText_(values) { values = (values || []).filter(function (v) { return gwToSafeText_(v); }).sort(); return values.length ? values[0] : ''; }
function gwMaxDateText_(values) { values = (values || []).filter(function (v) { return gwToSafeText_(v); }).sort(); return values.length ? values[values.length - 1] : ''; }
