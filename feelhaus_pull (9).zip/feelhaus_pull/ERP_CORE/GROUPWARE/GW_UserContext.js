function gwGetActiveEmail_() {
  var email = '';
  try {
    email = Session.getActiveUser().getEmail();
  } catch (err) {
    email = '';
  }
  if (!email) {
    try {
      email = Session.getEffectiveUser().getEmail();
    } catch (err2) {
      email = '';
    }
  }
  return gwToSafeText_(email).toLowerCase();
}

function gwGetUserContextSafe_() {
  try {
    return gwGetUserContext_();
  } catch (err) {
    return {
      ok: false,
      email: gwGetActiveEmail_(),
      employeeId: 'UNKNOWN',
      employeeName: '미확인 사용자',
      roleCode: 'UNKNOWN',
      vendorId: '',
      eventId: '',
      status: 'UNKNOWN',
      permissions: {},
      message: gwErrorMessage_(err)
    };
  }
}

function gwGetUserContext_() {
  var email = gwGetActiveEmail_();
  var user = email ? gwFindPortalUserByEmail_(email) : null;
  if (!user) {
    return {
      ok: false,
      email: email,
      employeeId: 'UNKNOWN',
      employeeName: email || '미확인 사용자',
      roleCode: 'UNKNOWN',
      vendorId: '',
      eventId: '',
      status: 'UNKNOWN',
      permissions: {},
      message: 'PortalUsers에서 현재 이메일을 찾지 못했습니다. B01 기준 이메일 필드: loginEmail 또는 email.'
    };
  }

  return {
    ok: true,
    email: gwToSafeText_(user.email).toLowerCase(),
    employeeId: gwToSafeText_(user.employeeId),
    employeeName: gwToSafeText_(user.employeeName),
    roleCode: gwToSafeText_(user.roleCode),
    vendorId: gwToSafeText_(user.vendorId),
    eventId: gwToSafeText_(user.eventId),
    status: gwToSafeText_(user.status),
    permissions: user.permissions || {},
    sourceSheetName: gwGetPortalUsersSheet_().getName(),
    sourceRowNumber: user._rowNumber || '',
    message: 'PortalUsers 매칭 완료'
  };
}

function gwGetCurrentEmployeeIdSafe_() {
  var ctx = gwGetUserContextSafe_();
  return ctx.employeeId || 'UNKNOWN';
}
