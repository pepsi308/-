const GW_ASSET_SHEET_CANDIDATES = Object.freeze(['Portal_Assets', 'PORTAL_Assets', 'PORTAL_ASSETS', 'Assets', 'GW_Assets']);
const GW_SUPPLY_SHEET_CANDIDATES = Object.freeze(['Portal_Supplies', 'PORTAL_Supplies', 'PORTAL_SUPPLIES', 'Supplies', 'GW_Supplies']);
const GW_SUPPLY_REQUEST_SHEET_CANDIDATES = Object.freeze(['Portal_SupplyRequests', 'PORTAL_SupplyRequests', 'PORTAL_SUPPLY_REQUESTS', 'SupplyRequests', 'GW_SupplyRequests']);
const GW_ASSET_PREFERRED_SHEET_NAME = 'Portal_Assets';
const GW_SUPPLY_PREFERRED_SHEET_NAME = 'Portal_Supplies';
const GW_SUPPLY_REQUEST_PREFERRED_SHEET_NAME = 'Portal_SupplyRequests';
const GW_SUPPLY_REQUEST_FALLBACK_REQUEST_TYPE = 'SUPPLY_REQUEST';

const GW_ASSET_HEADERS = Object.freeze([
  'assetId', 'assetCategory', 'assetName', 'serialNo', 'assignedEmployeeId', 'assignedVendorId',
  'purchaseDate', 'assetStatus', 'location', 'memo',
  'status', 'statusReason', 'createdAt', 'createdBy', 'updatedAt', 'updatedBy'
]);

const GW_SUPPLY_HEADERS = Object.freeze([
  'supplyId', 'supplyName', 'category', 'stockQty', 'minQty', 'location',
  'status', 'statusReason', 'createdAt', 'createdBy', 'updatedAt', 'updatedBy'
]);

const GW_SUPPLY_REQUEST_HEADERS = Object.freeze([
  'supplyRequestId', 'employeeId', 'supplyId', 'requestQty', 'requestStatus',
  'approvedBy', 'approvedAt', 'rejectedReason',
  'status', 'statusReason', 'createdAt', 'createdBy', 'updatedAt', 'updatedBy'
]);

const GW_ASSET_STATUSES = Object.freeze(['ACTIVE', 'ASSIGNED', 'RETURNED', 'REPAIR', 'LOST', 'DISPOSED', 'ARCHIVED']);
const GW_ASSET_CATEGORIES = Object.freeze(['GENERAL', 'IT', 'MOBILE', 'OFFICE', 'EVENT', 'INSTALL', 'VEHICLE', 'SYSTEM']);
const GW_SUPPLY_STATUSES = Object.freeze(['ACTIVE', 'LOW_STOCK', 'OUT_OF_STOCK', 'INACTIVE', 'ARCHIVED']);
const GW_SUPPLY_CATEGORIES = Object.freeze(['GENERAL', 'OFFICE', 'EVENT', 'INSTALL', 'CLEANING', 'SAFETY', 'SYSTEM']);
const GW_SUPPLY_REQUEST_STATUSES = Object.freeze(['DRAFT', 'REQUESTED', 'APPROVED', 'REJECTED', 'CANCELED', 'COMPLETED']);

function gwFindFirstSheet_(candidates) {
  var ss = gwGetMasterSpreadsheet_();
  for (var i = 0; i < candidates.length; i++) {
    var sheet = ss.getSheetByName(candidates[i]);
    if (sheet) return sheet;
  }
  return null;
}

function gwGetAssetSheet_(createIfMissing) {
  var sheet = gwFindFirstSheet_(GW_ASSET_SHEET_CANDIDATES);
  if (sheet) return sheet;
  if (createIfMissing) {
    var ss = gwGetMasterSpreadsheet_();
    var created = ss.insertSheet(GW_ASSET_PREFERRED_SHEET_NAME);
    created.getRange(1, 1, 1, GW_ASSET_HEADERS.length).setValues([GW_ASSET_HEADERS]);
    return created;
  }
  throw new Error('자산 시트를 찾을 수 없습니다. 허용 시트명: ' + GW_ASSET_SHEET_CANDIDATES.join(', '));
}

function gwGetSupplySheet_(createIfMissing) {
  var sheet = gwFindFirstSheet_(GW_SUPPLY_SHEET_CANDIDATES);
  if (sheet) return sheet;
  if (createIfMissing) {
    var ss = gwGetMasterSpreadsheet_();
    var created = ss.insertSheet(GW_SUPPLY_PREFERRED_SHEET_NAME);
    created.getRange(1, 1, 1, GW_SUPPLY_HEADERS.length).setValues([GW_SUPPLY_HEADERS]);
    return created;
  }
  throw new Error('비품 시트를 찾을 수 없습니다. 허용 시트명: ' + GW_SUPPLY_SHEET_CANDIDATES.join(', '));
}

function gwGetSupplyRequestStore_(createIfMissing) {
  var sheet = gwFindFirstSheet_(GW_SUPPLY_REQUEST_SHEET_CANDIDATES);
  if (sheet) return { mode: 'DEDICATED', sheet: sheet, storageMode: 'DEDICATED' };

  var requestSheet = null;
  try { requestSheet = gwGetRequestSheet_(false); } catch (err) { requestSheet = null; }
  if (requestSheet) {
    return {
      mode: 'REQUESTS_FALLBACK',
      storageMode: 'REQUESTS_FALLBACK',
      sheet: requestSheet,
      requestType: GW_SUPPLY_REQUEST_FALLBACK_REQUEST_TYPE,
      note: '스프레드시트 셀 한도 보호를 위해 Portal_Requests를 비품요청 원장으로 재사용합니다.'
    };
  }

  if (createIfMissing) {
    var ss = gwGetMasterSpreadsheet_();
    try {
      var created = ss.insertSheet(GW_SUPPLY_REQUEST_PREFERRED_SHEET_NAME);
      created.getRange(1, 1, 1, GW_SUPPLY_REQUEST_HEADERS.length).setValues([GW_SUPPLY_REQUEST_HEADERS]);
      return { mode: 'DEDICATED', sheet: created, storageMode: 'DEDICATED' };
    } catch (createErr) {
      var fallbackSheet = gwGetRequestSheet_(true);
      return {
        mode: 'REQUESTS_FALLBACK',
        storageMode: 'REQUESTS_FALLBACK',
        sheet: fallbackSheet,
        requestType: GW_SUPPLY_REQUEST_FALLBACK_REQUEST_TYPE,
        fallbackReason: String(createErr && createErr.message ? createErr.message : createErr),
        note: 'Portal_SupplyRequests 신규 생성 실패로 Portal_Requests를 비품요청 원장으로 재사용합니다.'
      };
    }
  }
  throw new Error('비품요청 시트를 찾을 수 없습니다. 허용 시트명: ' + GW_SUPPLY_REQUEST_SHEET_CANDIDATES.join(', ') + ' 또는 Portal_Requests fallback');
}

function gwGetSupplyRequestSheet_(createIfMissing) {
  return gwGetSupplyRequestStore_(createIfMissing).sheet;
}

function gwIsSupplyRequestFallbackStore_(store) {
  return store && store.mode === 'REQUESTS_FALLBACK';
}

function gwEnsureAssetHeaders_() {
  return gwEnsureSheetHeadersB08_(gwGetAssetSheet_(true), GW_ASSET_HEADERS.slice());
}

function gwEnsureSupplyHeaders_() {
  return gwEnsureSheetHeadersB08_(gwGetSupplySheet_(true), GW_SUPPLY_HEADERS.slice());
}

function gwEnsureSupplyRequestHeaders_() {
  var store = gwGetSupplyRequestStore_(true);
  if (gwIsSupplyRequestFallbackStore_(store)) {
    var requestResult = gwEnsureRequestHeaders_();
    return {
      ok: true,
      sheetName: store.sheet.getName(),
      storageMode: 'REQUESTS_FALLBACK',
      requestType: GW_SUPPLY_REQUEST_FALLBACK_REQUEST_TYPE,
      beforeCount: requestResult.beforeCount,
      afterCount: requestResult.afterCount,
      addedHeaders: requestResult.addedHeaders || [],
      missing: requestResult.missing || [],
      note: store.note || 'Portal_Requests fallback 사용'
    };
  }
  var result = gwEnsureSheetHeadersB08_(store.sheet, GW_SUPPLY_REQUEST_HEADERS.slice());
  result.storageMode = 'DEDICATED';
  return result;
}

function gwEnsureSheetHeadersB08_(sheet, requiredHeaders) {
  var before = gwGetHeaders_(sheet).filter(function (h) { return h; });
  var result = gwEnsureHeaders_(sheet, requiredHeaders);
  var after = gwGetHeaders_(sheet).filter(function (h) { return h; });
  return {
    ok: result.ok,
    sheetName: sheet.getName(),
    beforeCount: before.length,
    afterCount: after.length,
    addedHeaders: after.filter(function (h) { return before.indexOf(h) < 0; }),
    missing: result.missing || []
  };
}

function gwInspectAssetSupplyHeadersNoWrite_B08_() {
  var assetSheet = gwFindFirstSheet_(GW_ASSET_SHEET_CANDIDATES);
  var supplySheet = gwFindFirstSheet_(GW_SUPPLY_SHEET_CANDIDATES);
  var dedicatedRequestSheet = gwFindFirstSheet_(GW_SUPPLY_REQUEST_SHEET_CANDIDATES);
  var fallbackRequestSheet = null;
  try { fallbackRequestSheet = gwGetRequestSheet_(false); } catch (err) { fallbackRequestSheet = null; }
  var requestSheet = dedicatedRequestSheet || fallbackRequestSheet;
  var storageMode = dedicatedRequestSheet ? 'DEDICATED' : (fallbackRequestSheet ? 'REQUESTS_FALLBACK' : 'MISSING');
  var result = {
    ok: true,
    mode: 'NO_WRITE_INSPECT',
    prepareRequired: false,
    assetSheetExists: !!assetSheet,
    supplySheetExists: !!supplySheet,
    supplyRequestSheetExists: !!requestSheet,
    supplyRequestStorageMode: storageMode,
    assetSheetName: assetSheet ? assetSheet.getName() : '',
    supplySheetName: supplySheet ? supplySheet.getName() : '',
    supplyRequestSheetName: requestSheet ? requestSheet.getName() : '',
    missingAssetHeaders: [],
    missingSupplyHeaders: [],
    missingSupplyRequestHeaders: []
  };
  if (!assetSheet || !supplySheet || !requestSheet) result.prepareRequired = true;
  if (assetSheet) {
    var assetCheck = gwCheckRequiredHeaders_(assetSheet, GW_ASSET_HEADERS.slice());
    result.missingAssetHeaders = assetCheck.missing || [];
    if (!assetCheck.ok) result.prepareRequired = true;
  }
  if (supplySheet) {
    var supplyCheck = gwCheckRequiredHeaders_(supplySheet, GW_SUPPLY_HEADERS.slice());
    result.missingSupplyHeaders = supplyCheck.missing || [];
    if (!supplyCheck.ok) result.prepareRequired = true;
  }
  if (dedicatedRequestSheet) {
    var requestCheck = gwCheckRequiredHeaders_(dedicatedRequestSheet, GW_SUPPLY_REQUEST_HEADERS.slice());
    result.missingSupplyRequestHeaders = requestCheck.missing || [];
    if (!requestCheck.ok) result.prepareRequired = true;
  } else if (fallbackRequestSheet) {
    var fallbackCheck = gwCheckRequiredHeaders_(fallbackRequestSheet, GW_REQUEST_HEADERS.slice());
    result.missingSupplyRequestHeaders = fallbackCheck.missing || [];
    if (!fallbackCheck.ok) result.prepareRequired = true;
    result.note = 'Portal_SupplyRequests 대신 Portal_Requests fallback을 사용합니다.';
  }
  if (result.prepareRequired) result.message = '총무/자산/비품 시트 준비가 필요합니다. gwInternalTest_B08_HeaderEnsure()에서 생성/보강됩니다.';
  return result;
}

function gwGetB08AssetSupplyMeta_() {
  return {
    buildStep: '08/10',
    assetStatuses: GW_ASSET_STATUSES.slice(),
    assetCategories: GW_ASSET_CATEGORIES.slice(),
    supplyStatuses: GW_SUPPLY_STATUSES.slice(),
    supplyCategories: GW_SUPPLY_CATEGORIES.slice(),
    supplyRequestStatuses: GW_SUPPLY_REQUEST_STATUSES.slice(),
    requiredAssetHeaders: GW_ASSET_HEADERS.slice(),
    requiredSupplyHeaders: GW_SUPPLY_HEADERS.slice(),
    requiredSupplyRequestHeaders: GW_SUPPLY_REQUEST_HEADERS.slice(),
    mode: 'ASSET_LEDGER_SUPPLY_REQUEST_FIRST_ACCOUNTING_LATER'
  };
}

function gwListAssetsForUi(payload) {
  payload = payload || {};
  var context = gwAssertPermission_('canAccessPortal');
  var sheet = gwGetAssetSheet_(true);
  gwEnsureHeaders_(sheet, GW_ASSET_HEADERS.slice());
  var rows = gwReadRowsAsObjects_(sheet).map(function (row) { return gwNormalizeAssetRow_(row); });
  var includeAll = payload.includeAll === true && (gwCanSafe_(context, 'canViewLogs') || gwCanSafe_(context, 'canAccessDevConsole'));
  var status = gwToSafeText_(payload.status || payload.assetStatus).toUpperCase();
  var category = gwToSafeText_(payload.assetCategory || payload.category).toUpperCase();
  var assignedEmployeeId = gwToSafeText_(payload.assignedEmployeeId);
  var query = gwToSafeText_(payload.query).toLowerCase();
  var limit = Math.min(Number(payload.limit || 100), 500);
  rows = rows.filter(function (asset) {
    if (!includeAll && asset.assignedEmployeeId && asset.assignedEmployeeId !== context.employeeId) return false;
    if (status && status !== 'ALL' && asset.assetStatus !== status && asset.status !== status) return false;
    if (category && category !== 'ALL' && asset.assetCategory !== category) return false;
    if (assignedEmployeeId && assignedEmployeeId !== 'ALL' && asset.assignedEmployeeId !== assignedEmployeeId) return false;
    if (query) {
      var hay = [asset.assetId, asset.assetCategory, asset.assetName, asset.serialNo, asset.assignedEmployeeId, asset.location, asset.memo, asset.status].join(' ').toLowerCase();
      if (hay.indexOf(query) < 0) return false;
    }
    return true;
  });
  rows.sort(function (a, b) { return gwB08DateToMillis_(b.updatedAt || b.createdAt) - gwB08DateToMillis_(a.updatedAt || a.createdAt); });
  rows = rows.slice(0, limit).map(function (asset) { return gwAssetToUiRow_(asset); });
  return gwOk_({ rows: rows, totalReturned: rows.length, sheetName: sheet.getName() }, '자산 목록 조회 완료');
}

function gwGetAssetDetailForUi(payload) {
  payload = payload || {};
  var context = gwAssertPermission_('canAccessPortal');
  var assetId = gwToSafeText_(payload.assetId);
  if (!assetId) return gwFail_('MISSING_ASSET_ID', 'assetId가 필요합니다.');
  var found = gwFindAssetById_(assetId);
  if (!found) return gwFail_('ASSET_NOT_FOUND', '자산을 찾을 수 없습니다.', { assetId: assetId });
  if (found.assignedEmployeeId && found.assignedEmployeeId !== context.employeeId && !gwCanSafe_(context, 'canViewLogs') && !gwCanSafe_(context, 'canAccessDevConsole')) {
    return gwFail_('ASSET_NO_PERMISSION', '해당 자산을 조회할 권한이 없습니다.', { assetId: assetId });
  }
  return gwOk_({ asset: gwAssetToUiRow_(found) }, '자산 상세 조회 완료');
}

function gwSaveAssetForUi(payload) {
  var context = gwAssertPermission_('canApprove');
  var result = gwSaveAsset_(payload || {}, context, { mode: 'UI' });
  return gwOk_(result, result.action === 'CREATE' ? '자산 등록 완료' : '자산 수정 완료');
}

function gwSaveAsset_(payload, context, options) {
  payload = payload || {};
  context = context || gwGetUserContextSafe_();
  options = options || {};
  var sheet = gwGetAssetSheet_(true);
  gwEnsureHeaders_(sheet, GW_ASSET_HEADERS.slice());
  var headers = gwGetHeaders_(sheet).filter(function (h) { return h; });
  var rows = gwReadRowsAsObjects_(sheet);
  var assetId = gwToSafeText_(payload.assetId);
  var existing = assetId ? gwFindAssetById_(assetId) : null;
  if (!assetId) assetId = existing ? existing.assetId : gwUuid_('AST');
  if (!gwToSafeText_(payload.assetName) && !existing) throw new Error('assetName은 필수입니다.');
  var now = gwNow_();
  var rowObj = existing ? Object.assign({}, existing._sourceRow) : {};
  var action = existing ? 'UPDATE' : 'CREATE';
  var nextStatus = gwNormalizeAssetStatus_(payload.assetStatus || payload.status || (existing ? existing.assetStatus : 'ACTIVE'));
  if (existing && gwAssetIsLocked_(existing) && options.mode !== 'B08_TEST') throw new Error('종료/폐기 자산은 일반 수정할 수 없습니다: ' + existing.assetStatus);
  rowObj.assetId = assetId;
  rowObj.assetCategory = gwNormalizeAssetCategory_(payload.assetCategory || rowObj.assetCategory || 'GENERAL');
  rowObj.assetName = gwToSafeText_(payload.assetName || rowObj.assetName);
  rowObj.serialNo = gwToSafeText_(payload.serialNo || rowObj.serialNo);
  rowObj.assignedEmployeeId = gwToSafeText_(payload.assignedEmployeeId || rowObj.assignedEmployeeId);
  rowObj.assignedVendorId = gwToSafeText_(payload.assignedVendorId || rowObj.assignedVendorId);
  rowObj.purchaseDate = gwToSafeText_(payload.purchaseDate || rowObj.purchaseDate);
  rowObj.assetStatus = nextStatus;
  rowObj.location = gwToSafeText_(payload.location || rowObj.location);
  rowObj.memo = gwToSafeText_(payload.memo || rowObj.memo);
  rowObj.status = nextStatus;
  rowObj.statusReason = gwToSafeText_(payload.statusReason || rowObj.statusReason);
  if (!existing) {
    rowObj.createdAt = now;
    rowObj.createdBy = context.employeeId || 'SYSTEM';
  }
  rowObj.updatedAt = now;
  rowObj.updatedBy = context.employeeId || 'SYSTEM';
  var rowNumber;
  if (existing) {
    rowNumber = existing._rowNumber;
    sheet.getRange(rowNumber, 1, 1, headers.length).setValues([headers.map(function (h) { return Object.prototype.hasOwnProperty.call(rowObj, h) ? rowObj[h] : ''; })]);
  } else {
    rowNumber = gwAppendObjectRow_(sheet, rowObj, GW_ASSET_HEADERS.slice());
  }
  gwAuditSafe_({ moduleCode: 'GROUPWARE_ASSET', actionType: action + '_ASSET', targetId: assetId, employeeId: context.employeeId, resultStatus: 'SUCCESS', detailMessage: 'B08 자산 ' + action + ' 완료: ' + assetId });
  return { ok: true, action: action, sheetName: sheet.getName(), rowNumber: rowNumber, asset: gwAssetToUiRow_(gwNormalizeAssetRow_(rowObj)) };
}

function gwListSuppliesForUi(payload) {
  payload = payload || {};
  gwAssertPermission_('canAccessPortal');
  var sheet = gwGetSupplySheet_(true);
  gwEnsureHeaders_(sheet, GW_SUPPLY_HEADERS.slice());
  var rows = gwReadRowsAsObjects_(sheet).map(function (row) { return gwNormalizeSupplyRow_(row); });
  var status = gwToSafeText_(payload.status).toUpperCase();
  var category = gwToSafeText_(payload.category).toUpperCase();
  var query = gwToSafeText_(payload.query).toLowerCase();
  var limit = Math.min(Number(payload.limit || 100), 500);
  rows = rows.filter(function (supply) {
    if (status && status !== 'ALL' && supply.status !== status) return false;
    if (category && category !== 'ALL' && supply.category !== category) return false;
    if (query) {
      var hay = [supply.supplyId, supply.supplyName, supply.category, supply.location, supply.status].join(' ').toLowerCase();
      if (hay.indexOf(query) < 0) return false;
    }
    return true;
  });
  rows.sort(function (a, b) { return gwB08DateToMillis_(b.updatedAt || b.createdAt) - gwB08DateToMillis_(a.updatedAt || a.createdAt); });
  rows = rows.slice(0, limit).map(function (supply) { return gwSupplyToUiRow_(supply); });
  return gwOk_({ rows: rows, totalReturned: rows.length, sheetName: sheet.getName() }, '비품 목록 조회 완료');
}

function gwGetSupplyDetailForUi(payload) {
  payload = payload || {};
  gwAssertPermission_('canAccessPortal');
  var supplyId = gwToSafeText_(payload.supplyId);
  if (!supplyId) return gwFail_('MISSING_SUPPLY_ID', 'supplyId가 필요합니다.');
  var found = gwFindSupplyById_(supplyId);
  if (!found) return gwFail_('SUPPLY_NOT_FOUND', '비품을 찾을 수 없습니다.', { supplyId: supplyId });
  return gwOk_({ supply: gwSupplyToUiRow_(found) }, '비품 상세 조회 완료');
}

function gwSaveSupplyForUi(payload) {
  var context = gwAssertPermission_('canApprove');
  var result = gwSaveSupply_(payload || {}, context, { mode: 'UI' });
  return gwOk_(result, result.action === 'CREATE' ? '비품 등록 완료' : '비품 수정 완료');
}

function gwSaveSupply_(payload, context, options) {
  payload = payload || {};
  context = context || gwGetUserContextSafe_();
  options = options || {};
  var sheet = gwGetSupplySheet_(true);
  gwEnsureHeaders_(sheet, GW_SUPPLY_HEADERS.slice());
  var headers = gwGetHeaders_(sheet).filter(function (h) { return h; });
  var supplyId = gwToSafeText_(payload.supplyId);
  var existing = supplyId ? gwFindSupplyById_(supplyId) : null;
  if (!supplyId) supplyId = existing ? existing.supplyId : gwUuid_('SUP');
  if (!gwToSafeText_(payload.supplyName) && !existing) throw new Error('supplyName은 필수입니다.');
  var now = gwNow_();
  var rowObj = existing ? Object.assign({}, existing._sourceRow) : {};
  var action = existing ? 'UPDATE' : 'CREATE';
  var stockQty = gwNormalizeNumberText_(payload.stockQty, rowObj.stockQty || '0');
  var minQty = gwNormalizeNumberText_(payload.minQty, rowObj.minQty || '0');
  var status = gwNormalizeSupplyStatus_(payload.status || rowObj.status || (Number(stockQty) <= Number(minQty) ? 'LOW_STOCK' : 'ACTIVE'));
  if (options.mode === 'AUTO_STOCK' && Number(stockQty) <= Number(minQty) && status === 'ACTIVE') status = 'LOW_STOCK';
  rowObj.supplyId = supplyId;
  rowObj.supplyName = gwToSafeText_(payload.supplyName || rowObj.supplyName);
  rowObj.category = gwNormalizeSupplyCategory_(payload.category || rowObj.category || 'GENERAL');
  rowObj.stockQty = stockQty;
  rowObj.minQty = minQty;
  rowObj.location = gwToSafeText_(payload.location || rowObj.location);
  rowObj.status = status;
  rowObj.statusReason = gwToSafeText_(payload.statusReason || rowObj.statusReason);
  if (!existing) {
    rowObj.createdAt = now;
    rowObj.createdBy = context.employeeId || 'SYSTEM';
  }
  rowObj.updatedAt = now;
  rowObj.updatedBy = context.employeeId || 'SYSTEM';
  var rowNumber;
  if (existing) {
    rowNumber = existing._rowNumber;
    sheet.getRange(rowNumber, 1, 1, headers.length).setValues([headers.map(function (h) { return Object.prototype.hasOwnProperty.call(rowObj, h) ? rowObj[h] : ''; })]);
  } else {
    rowNumber = gwAppendObjectRow_(sheet, rowObj, GW_SUPPLY_HEADERS.slice());
  }
  gwAuditSafe_({ moduleCode: 'GROUPWARE_SUPPLY', actionType: action + '_SUPPLY', targetId: supplyId, employeeId: context.employeeId, resultStatus: 'SUCCESS', detailMessage: 'B08 비품 ' + action + ' 완료: ' + supplyId });
  return { ok: true, action: action, sheetName: sheet.getName(), rowNumber: rowNumber, supply: gwSupplyToUiRow_(gwNormalizeSupplyRow_(rowObj)) };
}

function gwListSupplyRequestsForUi(payload) {
  payload = payload || {};
  var context = gwAssertPermission_('canAccessPortal');
  var store = gwGetSupplyRequestStore_(true);
  var sheet = store.sheet;
  var rows;
  if (gwIsSupplyRequestFallbackStore_(store)) {
    gwEnsureRequestHeaders_();
    rows = gwReadRowsAsObjects_(sheet).map(function (row) { return gwNormalizeSupplyRequestFromPortalRequestRow_(row); }).filter(function (row) { return row && row.supplyRequestId; });
  } else {
    gwEnsureHeaders_(sheet, GW_SUPPLY_REQUEST_HEADERS.slice());
    rows = gwReadRowsAsObjects_(sheet).map(function (row) { return gwNormalizeSupplyRequestRow_(row); });
  }
  var includeAll = payload.includeAll === true && (gwCanSafe_(context, 'canApprove') || gwCanSafe_(context, 'canAccessDevConsole'));
  var status = gwToSafeText_(payload.requestStatus || payload.status).toUpperCase();
  var employeeId = gwToSafeText_(payload.employeeId);
  var supplyId = gwToSafeText_(payload.supplyId);
  var limit = Math.min(Number(payload.limit || 100), 500);
  rows = rows.filter(function (request) {
    if (!includeAll && request.employeeId !== context.employeeId && request.approvedBy !== context.employeeId) return false;
    if (status && status !== 'ALL' && request.requestStatus !== status && request.status !== status) return false;
    if (employeeId && employeeId !== 'ALL' && request.employeeId !== employeeId) return false;
    if (supplyId && supplyId !== 'ALL' && request.supplyId !== supplyId) return false;
    return true;
  });
  rows.sort(function (a, b) { return gwB08DateToMillis_(b.updatedAt || b.createdAt) - gwB08DateToMillis_(a.updatedAt || a.createdAt); });
  rows = rows.slice(0, limit).map(function (request) { return gwSupplyRequestToUiRow_(request); });
  return gwOk_({ rows: rows, totalReturned: rows.length, sheetName: sheet.getName(), storageMode: store.storageMode }, '비품 요청 목록 조회 완료');
}

function gwGetSupplyRequestDetailForUi(payload) {
  payload = payload || {};
  var context = gwAssertPermission_('canAccessPortal');
  var supplyRequestId = gwToSafeText_(payload.supplyRequestId);
  if (!supplyRequestId) return gwFail_('MISSING_SUPPLY_REQUEST_ID', 'supplyRequestId가 필요합니다.');
  var found = gwFindSupplyRequestById_(supplyRequestId);
  if (!found) return gwFail_('SUPPLY_REQUEST_NOT_FOUND', '비품 요청을 찾을 수 없습니다.', { supplyRequestId: supplyRequestId });
  if (found.employeeId !== context.employeeId && found.approvedBy !== context.employeeId && !gwCanSafe_(context, 'canApprove') && !gwCanSafe_(context, 'canAccessDevConsole')) {
    return gwFail_('SUPPLY_REQUEST_NO_PERMISSION', '해당 비품 요청을 조회할 권한이 없습니다.', { supplyRequestId: supplyRequestId });
  }
  return gwOk_({ supplyRequest: gwSupplyRequestToUiRow_(found) }, '비품 요청 상세 조회 완료');
}

function gwSaveSupplyRequestForUi(payload) {
  var context = gwAssertPermission_('canAccessPortal');
  var result = gwSaveSupplyRequest_(payload || {}, context, { mode: 'UI' });
  return gwOk_(result, result.action === 'CREATE' ? '비품 요청 등록 완료' : '비품 요청 수정 완료');
}

function gwSaveSupplyRequest_(payload, context, options) {
  payload = payload || {};
  context = context || gwGetUserContextSafe_();
  options = options || {};
  var store = gwGetSupplyRequestStore_(true);
  if (gwIsSupplyRequestFallbackStore_(store)) {
    return gwSaveSupplyRequestToPortalRequests_(payload, context, options, store);
  }
  var sheet = store.sheet;
  gwEnsureHeaders_(sheet, GW_SUPPLY_REQUEST_HEADERS.slice());
  var headers = gwGetHeaders_(sheet).filter(function (h) { return h; });
  var supplyRequestId = gwToSafeText_(payload.supplyRequestId);
  var existing = supplyRequestId ? gwFindSupplyRequestById_(supplyRequestId) : null;
  if (!supplyRequestId) supplyRequestId = existing ? existing.supplyRequestId : gwUuid_('SUPREQ');
  var supplyId = gwToSafeText_(payload.supplyId || (existing && existing.supplyId));
  if (!supplyId) throw new Error('supplyId는 필수입니다.');
  var requestQty = gwNormalizeNumberText_(payload.requestQty, existing ? existing.requestQty : '1');
  if (Number(requestQty) <= 0) throw new Error('requestQty는 1 이상이어야 합니다.');
  var now = gwNow_();
  var rowObj = existing ? Object.assign({}, existing._sourceRow) : {};
  var action = existing ? 'UPDATE' : 'CREATE';
  var nextStatus = gwNormalizeSupplyRequestStatus_(payload.requestStatus || payload.status || (existing ? existing.requestStatus : 'REQUESTED'));
  if (existing && gwSupplyRequestIsLocked_(existing) && options.mode !== 'B08_TEST') throw new Error('완료/반려/취소된 비품 요청은 일반 수정할 수 없습니다: ' + existing.requestStatus);
  rowObj.supplyRequestId = supplyRequestId;
  rowObj.employeeId = gwToSafeText_(payload.employeeId || (existing && existing.employeeId) || context.employeeId);
  rowObj.supplyId = supplyId;
  rowObj.requestQty = requestQty;
  rowObj.requestStatus = nextStatus;
  rowObj.status = nextStatus;
  rowObj.statusReason = gwToSafeText_(payload.statusReason || rowObj.statusReason);
  rowObj.approvedBy = gwToSafeText_(payload.approvedBy || rowObj.approvedBy);
  rowObj.approvedAt = gwToSafeText_(payload.approvedAt || rowObj.approvedAt);
  rowObj.rejectedReason = gwToSafeText_(payload.rejectedReason || rowObj.rejectedReason);
  if (!existing) {
    rowObj.createdAt = now;
    rowObj.createdBy = context.employeeId || 'SYSTEM';
  }
  rowObj.updatedAt = now;
  rowObj.updatedBy = context.employeeId || 'SYSTEM';
  var rowNumber;
  if (existing) {
    rowNumber = existing._rowNumber;
    sheet.getRange(rowNumber, 1, 1, headers.length).setValues([headers.map(function (h) { return Object.prototype.hasOwnProperty.call(rowObj, h) ? rowObj[h] : ''; })]);
  } else {
    rowNumber = gwAppendObjectRow_(sheet, rowObj, GW_SUPPLY_REQUEST_HEADERS.slice());
  }
  gwAuditSafe_({ moduleCode: 'GROUPWARE_SUPPLY_REQUEST', actionType: action + '_SUPPLY_REQUEST', targetId: supplyRequestId, employeeId: context.employeeId, resultStatus: 'SUCCESS', detailMessage: 'B08 비품 요청 ' + action + ' 완료: ' + supplyRequestId });
  return { ok: true, action: action, sheetName: sheet.getName(), rowNumber: rowNumber, storageMode: store.storageMode, supplyRequest: gwSupplyRequestToUiRow_(gwNormalizeSupplyRequestRow_(rowObj)) };
}

function gwSaveSupplyRequestToPortalRequests_(payload, context, options, store) {
  var supplyRequestId = gwToSafeText_(payload.supplyRequestId);
  var existing = supplyRequestId ? gwFindSupplyRequestById_(supplyRequestId) : null;
  if (!supplyRequestId) supplyRequestId = existing ? existing.supplyRequestId : gwUuid_('SUPREQ');
  var supplyId = gwToSafeText_(payload.supplyId || (existing && existing.supplyId));
  if (!supplyId) throw new Error('supplyId는 필수입니다.');
  var requestQty = gwNormalizeNumberText_(payload.requestQty, existing ? existing.requestQty : '1');
  if (Number(requestQty) <= 0) throw new Error('requestQty는 1 이상이어야 합니다.');
  var nextStatus = gwNormalizeSupplyRequestStatus_(payload.requestStatus || payload.status || (existing ? existing.requestStatus : 'REQUESTED'));
  if (existing && gwSupplyRequestIsLocked_(existing) && options.mode !== 'B08_TEST') throw new Error('완료/반려/취소된 비품 요청은 일반 수정할 수 없습니다: ' + existing.requestStatus);
  var content = JSON.stringify({
    moduleCode: 'GROUPWARE_ASSET_SUPPLY',
    supplyRequestId: supplyRequestId,
    supplyId: supplyId,
    requestQty: requestQty,
    approvedBy: gwToSafeText_(payload.approvedBy || (existing && existing.approvedBy)),
    approvedAt: gwToSafeText_(payload.approvedAt || (existing && existing.approvedAt)),
    rejectedReason: gwToSafeText_(payload.rejectedReason || (existing && existing.rejectedReason))
  });
  var saved = gwSaveRequest_({
    requestId: supplyRequestId,
    requestType: GW_SUPPLY_REQUEST_FALLBACK_REQUEST_TYPE,
    title: gwToSafeText_(payload.title || ('비품 요청: ' + supplyId)).slice(0, 200),
    content: content,
    requesterEmployeeId: gwToSafeText_(payload.employeeId || (existing && existing.employeeId) || context.employeeId),
    targetEmployeeId: gwToSafeText_(payload.approvedBy || (existing && existing.approvedBy)),
    priority: 'NORMAL',
    requestStatus: nextStatus,
    statusReason: gwToSafeText_(payload.statusReason || payload.rejectedReason || (existing && existing.statusReason))
  }, context, { mode: options.mode || 'SUPPLY_REQUEST_FALLBACK' });
  var normalized = gwFindSupplyRequestById_(supplyRequestId) || gwNormalizeSupplyRequestFromPortalRequestRow_(gwFindRequestById_(supplyRequestId) || {});
  gwAuditSafe_({ moduleCode: 'GROUPWARE_SUPPLY_REQUEST', actionType: saved.action + '_SUPPLY_REQUEST_FALLBACK', targetId: supplyRequestId, employeeId: context.employeeId, resultStatus: 'SUCCESS', detailMessage: 'B08 비품 요청 Portal_Requests fallback 저장 완료: ' + supplyRequestId });
  return { ok: true, action: saved.action, sheetName: store.sheet.getName(), rowNumber: saved.rowNumber, storageMode: 'REQUESTS_FALLBACK', supplyRequest: gwSupplyRequestToUiRow_(normalized) };
}

function gwApproveSupplyRequestForUi(payload) {
  var context = gwAssertPermission_('canApprove');
  return gwOk_(gwApproveSupplyRequest_(payload || {}, context, { mode: 'UI' }), '비품 요청 승인 완료');
}

function gwRejectSupplyRequestForUi(payload) {
  var context = gwAssertPermission_('canApprove');
  return gwOk_(gwRejectSupplyRequest_(payload || {}, context, { mode: 'UI' }), '비품 요청 반려 완료');
}

function gwApproveSupplyRequest_(payload, context, options) {
  payload = payload || {};
  context = context || gwGetUserContextSafe_();
  options = options || {};
  var supplyRequestId = gwToSafeText_(payload.supplyRequestId);
  if (!supplyRequestId) throw new Error('supplyRequestId가 필요합니다.');
  var found = gwFindSupplyRequestById_(supplyRequestId);
  if (!found) throw new Error('비품 요청을 찾을 수 없습니다: ' + supplyRequestId);
  if (gwSupplyRequestIsLocked_(found) && options.mode !== 'B08_TEST') throw new Error('이미 종료된 비품 요청입니다: ' + found.requestStatus);
  var result = gwSaveSupplyRequest_(Object.assign({}, found._sourceRow, {
    supplyRequestId: supplyRequestId,
    requestStatus: 'APPROVED',
    status: 'APPROVED',
    approvedBy: context.employeeId,
    approvedAt: gwNow_(),
    statusReason: gwToSafeText_(payload.statusReason || 'B08 비품 요청 승인')
  }), context, { mode: options.mode || 'APPROVE' });
  result.approvalStatus = 'APPROVED';
  return result;
}

function gwRejectSupplyRequest_(payload, context, options) {
  payload = payload || {};
  context = context || gwGetUserContextSafe_();
  options = options || {};
  var supplyRequestId = gwToSafeText_(payload.supplyRequestId);
  var rejectedReason = gwToSafeText_(payload.rejectedReason || payload.reason);
  if (!supplyRequestId) throw new Error('supplyRequestId가 필요합니다.');
  if (!rejectedReason) throw new Error('반려 사유는 필수입니다.');
  var found = gwFindSupplyRequestById_(supplyRequestId);
  if (!found) throw new Error('비품 요청을 찾을 수 없습니다: ' + supplyRequestId);
  if (gwSupplyRequestIsLocked_(found) && options.mode !== 'B08_TEST') throw new Error('이미 종료된 비품 요청입니다: ' + found.requestStatus);
  var result = gwSaveSupplyRequest_(Object.assign({}, found._sourceRow, {
    supplyRequestId: supplyRequestId,
    requestStatus: 'REJECTED',
    status: 'REJECTED',
    approvedBy: context.employeeId,
    approvedAt: gwNow_(),
    rejectedReason: rejectedReason,
    statusReason: rejectedReason
  }), context, { mode: options.mode || 'REJECT' });
  result.approvalStatus = 'REJECTED';
  return result;
}

function gwFindAssetById_(assetId) {
  var sheet = gwGetAssetSheet_(true);
  gwEnsureHeaders_(sheet, GW_ASSET_HEADERS.slice());
  var rows = gwReadRowsAsObjects_(sheet).map(function (row) { return gwNormalizeAssetRow_(row); });
  for (var i = 0; i < rows.length; i++) if (rows[i].assetId === assetId) return rows[i];
  return null;
}

function gwFindSupplyById_(supplyId) {
  var sheet = gwGetSupplySheet_(true);
  gwEnsureHeaders_(sheet, GW_SUPPLY_HEADERS.slice());
  var rows = gwReadRowsAsObjects_(sheet).map(function (row) { return gwNormalizeSupplyRow_(row); });
  for (var i = 0; i < rows.length; i++) if (rows[i].supplyId === supplyId) return rows[i];
  return null;
}

function gwFindSupplyRequestById_(supplyRequestId) {
  var store = gwGetSupplyRequestStore_(true);
  if (gwIsSupplyRequestFallbackStore_(store)) {
    gwEnsureRequestHeaders_();
    var req = gwFindRequestById_(supplyRequestId);
    if (!req) return null;
    return gwNormalizeSupplyRequestFromPortalRequestRow_(req);
  }
  var sheet = store.sheet;
  gwEnsureHeaders_(sheet, GW_SUPPLY_REQUEST_HEADERS.slice());
  var rows = gwReadRowsAsObjects_(sheet).map(function (row) { return gwNormalizeSupplyRequestRow_(row); });
  for (var i = 0; i < rows.length; i++) if (rows[i].supplyRequestId === supplyRequestId) return rows[i];
  return null;
}

function gwNormalizeAssetRow_(row) {
  row = row || {};
  var normalized = Object.assign({}, row);
  normalized._sourceRow = row._sourceRow || Object.assign({}, row);
  normalized._rowNumber = row._rowNumber;
  normalized.assetId = gwToSafeText_(row.assetId);
  normalized.assetCategory = gwNormalizeAssetCategory_(row.assetCategory || 'GENERAL');
  normalized.assetName = gwToSafeText_(row.assetName);
  normalized.serialNo = gwToSafeText_(row.serialNo);
  normalized.assignedEmployeeId = gwToSafeText_(row.assignedEmployeeId);
  normalized.assignedVendorId = gwToSafeText_(row.assignedVendorId);
  normalized.purchaseDate = gwToSafeText_(row.purchaseDate);
  normalized.assetStatus = gwNormalizeAssetStatus_(row.assetStatus || row.status || 'ACTIVE');
  normalized.location = gwToSafeText_(row.location);
  normalized.memo = gwToSafeText_(row.memo);
  normalized.status = gwToSafeText_(row.status || normalized.assetStatus).toUpperCase();
  normalized.statusReason = gwToSafeText_(row.statusReason);
  normalized.createdAt = gwToSafeText_(row.createdAt);
  normalized.createdBy = gwToSafeText_(row.createdBy);
  normalized.updatedAt = gwToSafeText_(row.updatedAt);
  normalized.updatedBy = gwToSafeText_(row.updatedBy);
  return normalized;
}

function gwNormalizeSupplyRow_(row) {
  row = row || {};
  var normalized = Object.assign({}, row);
  normalized._sourceRow = row._sourceRow || Object.assign({}, row);
  normalized._rowNumber = row._rowNumber;
  normalized.supplyId = gwToSafeText_(row.supplyId);
  normalized.supplyName = gwToSafeText_(row.supplyName);
  normalized.category = gwNormalizeSupplyCategory_(row.category || 'GENERAL');
  normalized.stockQty = gwNormalizeNumberText_(row.stockQty, '0');
  normalized.minQty = gwNormalizeNumberText_(row.minQty, '0');
  normalized.location = gwToSafeText_(row.location);
  normalized.status = gwNormalizeSupplyStatus_(row.status || 'ACTIVE');
  normalized.statusReason = gwToSafeText_(row.statusReason);
  normalized.createdAt = gwToSafeText_(row.createdAt);
  normalized.createdBy = gwToSafeText_(row.createdBy);
  normalized.updatedAt = gwToSafeText_(row.updatedAt);
  normalized.updatedBy = gwToSafeText_(row.updatedBy);
  return normalized;
}

function gwNormalizeSupplyRequestFromPortalRequestRow_(row) {
  row = row || {};
  var requestType = gwToSafeText_(row.requestType).toUpperCase();
  if (requestType !== GW_SUPPLY_REQUEST_FALLBACK_REQUEST_TYPE) return null;
  var parsed = {};
  try { parsed = row.content ? JSON.parse(gwToSafeText_(row.content)) : {}; } catch (err) { parsed = {}; }
  var status = gwNormalizeSupplyRequestStatus_(row.requestStatus || row.status || 'REQUESTED');
  var normalized = {
    _sourceRow: row._sourceRow || Object.assign({}, row),
    _rowNumber: row._rowNumber,
    _storageMode: 'REQUESTS_FALLBACK',
    supplyRequestId: gwToSafeText_(row.requestId || parsed.supplyRequestId),
    employeeId: gwToSafeText_(row.requesterEmployeeId || parsed.employeeId),
    supplyId: gwToSafeText_(parsed.supplyId),
    requestQty: gwNormalizeNumberText_(parsed.requestQty, '1'),
    requestStatus: status,
    approvedBy: status === 'APPROVED' ? gwToSafeText_(row.updatedBy || parsed.approvedBy) : gwToSafeText_(parsed.approvedBy),
    approvedAt: status === 'APPROVED' ? gwToSafeText_(row.updatedAt || parsed.approvedAt) : gwToSafeText_(parsed.approvedAt),
    rejectedReason: status === 'REJECTED' ? gwToSafeText_(row.statusReason || parsed.rejectedReason) : gwToSafeText_(parsed.rejectedReason),
    status: status,
    statusReason: gwToSafeText_(row.statusReason),
    createdAt: gwToSafeText_(row.createdAt),
    createdBy: gwToSafeText_(row.createdBy),
    updatedAt: gwToSafeText_(row.updatedAt),
    updatedBy: gwToSafeText_(row.updatedBy)
  };
  return normalized;
}

function gwNormalizeSupplyRequestRow_(row) {
  row = row || {};
  var normalized = Object.assign({}, row);
  normalized._sourceRow = row._sourceRow || Object.assign({}, row);
  normalized._rowNumber = row._rowNumber;
  normalized.supplyRequestId = gwToSafeText_(row.supplyRequestId);
  normalized.employeeId = gwToSafeText_(row.employeeId);
  normalized.supplyId = gwToSafeText_(row.supplyId);
  normalized.requestQty = gwNormalizeNumberText_(row.requestQty, '1');
  normalized.requestStatus = gwNormalizeSupplyRequestStatus_(row.requestStatus || row.status || 'REQUESTED');
  normalized.approvedBy = gwToSafeText_(row.approvedBy);
  normalized.approvedAt = gwToSafeText_(row.approvedAt);
  normalized.rejectedReason = gwToSafeText_(row.rejectedReason);
  normalized.status = gwToSafeText_(row.status || normalized.requestStatus).toUpperCase();
  normalized.statusReason = gwToSafeText_(row.statusReason);
  normalized.createdAt = gwToSafeText_(row.createdAt);
  normalized.createdBy = gwToSafeText_(row.createdBy);
  normalized.updatedAt = gwToSafeText_(row.updatedAt);
  normalized.updatedBy = gwToSafeText_(row.updatedBy);
  return normalized;
}

function gwAssetToUiRow_(asset) {
  return {
    assetId: asset.assetId,
    assetCategory: asset.assetCategory,
    assetName: asset.assetName,
    serialNo: asset.serialNo,
    assignedEmployeeId: asset.assignedEmployeeId,
    assignedVendorId: asset.assignedVendorId,
    purchaseDate: asset.purchaseDate,
    assetStatus: asset.assetStatus,
    location: asset.location,
    memo: asset.memo,
    status: asset.status,
    statusReason: asset.statusReason,
    createdAt: asset.createdAt,
    createdBy: asset.createdBy,
    updatedAt: asset.updatedAt,
    updatedBy: asset.updatedBy
  };
}

function gwSupplyToUiRow_(supply) {
  return {
    supplyId: supply.supplyId,
    supplyName: supply.supplyName,
    category: supply.category,
    stockQty: supply.stockQty,
    minQty: supply.minQty,
    location: supply.location,
    status: supply.status,
    statusReason: supply.statusReason,
    createdAt: supply.createdAt,
    createdBy: supply.createdBy,
    updatedAt: supply.updatedAt,
    updatedBy: supply.updatedBy
  };
}

function gwSupplyRequestToUiRow_(request) {
  return {
    supplyRequestId: request.supplyRequestId,
    employeeId: request.employeeId,
    supplyId: request.supplyId,
    requestQty: request.requestQty,
    requestStatus: request.requestStatus,
    approvedBy: request.approvedBy,
    approvedAt: request.approvedAt,
    rejectedReason: request.rejectedReason,
    status: request.status,
    statusReason: request.statusReason,
    createdAt: request.createdAt,
    createdBy: request.createdBy,
    updatedAt: request.updatedAt,
    updatedBy: request.updatedBy
  };
}

function gwNormalizeAssetStatus_(value) {
  var status = gwToSafeText_(value).toUpperCase() || 'ACTIVE';
  return GW_ASSET_STATUSES.indexOf(status) >= 0 ? status : 'ACTIVE';
}

function gwNormalizeAssetCategory_(value) {
  var category = gwToSafeText_(value).toUpperCase() || 'GENERAL';
  return GW_ASSET_CATEGORIES.indexOf(category) >= 0 ? category : 'GENERAL';
}

function gwNormalizeSupplyStatus_(value) {
  var status = gwToSafeText_(value).toUpperCase() || 'ACTIVE';
  return GW_SUPPLY_STATUSES.indexOf(status) >= 0 ? status : 'ACTIVE';
}

function gwNormalizeSupplyCategory_(value) {
  var category = gwToSafeText_(value).toUpperCase() || 'GENERAL';
  return GW_SUPPLY_CATEGORIES.indexOf(category) >= 0 ? category : 'GENERAL';
}

function gwNormalizeSupplyRequestStatus_(value) {
  var status = gwToSafeText_(value).toUpperCase() || 'REQUESTED';
  return GW_SUPPLY_REQUEST_STATUSES.indexOf(status) >= 0 ? status : 'REQUESTED';
}

function gwNormalizeNumberText_(value, fallback) {
  var text = gwToSafeText_(value);
  if (text === '') text = gwToSafeText_(fallback);
  var numeric = Number(text);
  if (isNaN(numeric)) return gwToSafeText_(fallback || '0');
  return String(numeric);
}

function gwAssetIsLocked_(asset) {
  var status = gwNormalizeAssetStatus_(asset.assetStatus || asset.status);
  return status === 'DISPOSED' || status === 'ARCHIVED' || status === 'LOST';
}

function gwSupplyRequestIsLocked_(request) {
  var status = gwNormalizeSupplyRequestStatus_(request.requestStatus || request.status);
  return status === 'APPROVED' || status === 'REJECTED' || status === 'CANCELED' || status === 'COMPLETED';
}

function gwB08DateToMillis_(value) {
  var text = gwToSafeText_(value);
  if (!text) return 0;
  var date = new Date(text.replace(/-/g, '/'));
  var time = date.getTime();
  return isNaN(time) ? 0 : time;
}
