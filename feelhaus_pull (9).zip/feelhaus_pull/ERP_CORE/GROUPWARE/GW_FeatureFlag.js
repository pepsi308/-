const GW_FEATURE_DEFAULTS = Object.freeze({
  FEATURE_GW_HOME_ENABLED: 'Y',
  FEATURE_GW_ACCOUNT_ENABLED: 'Y',
  FEATURE_HR_ENABLED: 'Y',
  FEATURE_PERMISSION_ENABLED: 'Y',
  FEATURE_NOTICE_ENABLED: 'Y',
  FEATURE_BOARD_ENABLED: 'Y',
  FEATURE_DOC_LIBRARY_ENABLED: 'Y',
  FEATURE_REQUEST_ENABLED: 'Y',
  FEATURE_APPROVAL_ENABLED: 'Y',
  FEATURE_CALENDAR_ENABLED: 'N',
  FEATURE_ATTENDANCE_ENABLED: 'Y',
  FEATURE_CAPS_ATTENDANCE_SYNC_ENABLED: 'Y',
  FEATURE_KPI_ENABLED: 'Y',
  FEATURE_ASSET_ENABLED: 'Y',
  FEATURE_EXPENSE_ENABLED: 'Y',
  FEATURE_KNOWLEDGE_ENABLED: 'N',
  FEATURE_GW_DIAGNOSTIC_ENABLED: 'Y'
});

function gwGetFeatureFlag_(key) {
  var defaultValue = Object.prototype.hasOwnProperty.call(GW_FEATURE_DEFAULTS, key) ? GW_FEATURE_DEFAULTS[key] : 'N';
  var raw = gwGetConfigValue_([key], defaultValue);
  return gwNormalizeYn_(raw);
}

function gwGetFeatureFlagSnapshotSafe_() {
  var result = {};
  Object.keys(GW_FEATURE_DEFAULTS).forEach(function (key) {
    try {
      result[key] = gwGetFeatureFlag_(key) ? 'Y' : 'N';
    } catch (err) {
      result[key] = GW_FEATURE_DEFAULTS[key];
    }
  });
  return result;
}
