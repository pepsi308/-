/**
 * B15 PORTAL body-only UI service for Request / Approval.
 * This file returns body-only screen models and bodyHtml strings for PORTAL handlers.
 * It must not render module navigation, its own top bar, its own side bar, iframe, preview route, or standalone shell.
 */
const GW_B15_MODULE_CODE = 'GROUPWARE';
const GW_B15_BODY_IDS = Object.freeze(['GW_RequestsBody']);
const GW_B15_FORBIDDEN_VISIBLE_TOKENS = Object.freeze(['<iframe', 'preview route', 'standalone shell', 'data-module-menu', 'gw-own-menu', 'gw-side-menu', 'gw-top-menu', 'fragment menu']);

const GW_B15_REQUEST_FORM_FIELDS = Object.freeze([
  'requestId', 'requestType', 'title', 'content', 'requesterEmployeeId', 'targetEmployeeId',
  'targetVendorId', 'targetEventId', 'relatedCustomerId', 'relatedContractId', 'relatedDocumentId',
  'relatedSettlementId', 'priority', 'requestStatus', 'statusReason', 'approverEmployeeId', 'approvalComment'
]);

function gwGetB15BodySpecs() {
  return [
    {
      moduleCode: GW_B15_MODULE_CODE,
      menuId: 'gw.requests',
      route: '/groupware/requests',
      handler: 'gwHandleRequestsBody',
      viewFile: 'GW_RequestsBody.html',
      screenId: 'GW_RequestsBody',
      title: '전자결재 / 업무요청',
      description: 'Portal_Requests / Portal_Approvals 기준 업무요청 목록, 상세, 등록/수정, 승인/반려를 담당하는 PORTAL 본문 화면입니다.',
      permissionCode: 'canApprove',
      userPermissionCode: 'canAccessPortal',
      buttons: [
        { id: 'btnReloadRequests', label: '조회', call: 'listRequests', style: 'primary' },
        { id: 'btnNewRequest', label: '새 요청', call: 'prepareNewRequest', style: 'secondary' },
        { id: 'btnSaveRequest', label: '저장', call: 'saveRequest', style: 'primary' },
        { id: 'btnApproveRequest', label: '승인', call: 'approveRequest', style: 'success' },
        { id: 'btnRejectRequest', label: '반려', call: 'rejectRequest', style: 'warning' }
      ],
      calls: ['listRequests', 'getRequestDetail', 'saveRequest', 'approveRequest', 'rejectRequest'],
      sheets: ['Portal_Requests', 'Portal_Approvals'],
      logSheet: 'Portal_AuditLog',
      screenStructure: ['화면 제목', '화면 설명', '주요 작업 버튼', '검색 / 필터', '목록 / 입력폼 / 상세', '성공 / 실패 안내문']
    }
  ];
}

function gwHandleRequestsBody(payload) {
  payload = payload || {};
  gwAssertPermission_('canAccessPortal');
  var listResult = gwListRequestsForUi({
    query: payload.query || '',
    requestStatus: payload.requestStatus || payload.status || 'ALL',
    requestType: payload.requestType || 'ALL',
    limit: payload.limit || 50,
    includeAll: payload.includeAll === true
  });
  if (!listResult.ok) return listResult;
  var rows = (listResult.data && listResult.data.rows) || [];
  var selected = null;
  var approvals = [];
  if (payload.requestId) {
    var detailResult = gwGetRequestDetailForUi({ requestId: payload.requestId });
    if (detailResult.ok) {
      selected = detailResult.data.request;
      approvals = detailResult.data.approvals || [];
    }
  } else if (rows.length > 0) {
    selected = rows[0];
    var firstDetail = gwGetRequestDetailForUi({ requestId: rows[0].requestId });
    if (firstDetail.ok) approvals = firstDetail.data.approvals || [];
  }
  var model = gwBuildRequestsBodyModel_(rows, selected, approvals, payload);
  return gwOk_(model, '업무요청/전자결재 본문 구성 완료');
}

function gwBuildRequestsBodyModel_(rows, selected, approvals, payload) {
  var spec = gwFindB15BodySpec_('GW_RequestsBody');
  var model = {
    moduleCode: GW_B15_MODULE_CODE,
    screenId: spec.screenId,
    menuId: spec.menuId,
    route: spec.route,
    handler: spec.handler,
    title: spec.title,
    description: spec.description,
    permissionCode: spec.permissionCode,
    userPermissionCode: spec.userPermissionCode,
    actions: spec.buttons,
    filters: [
      { id: 'requestSearchKeyword', label: '검색어', field: 'query', value: gwToSafeText_(payload.query), placeholder: '제목, 내용, 요청유형, 관련 ID' },
      { id: 'requestTypeFilter', label: '요청 유형', field: 'requestType', value: gwToSafeText_(payload.requestType || 'ALL'), options: ['ALL'].concat(GW_REQUEST_TYPES || []) },
      { id: 'requestStatusFilter', label: '상태', field: 'requestStatus', value: gwToSafeText_(payload.requestStatus || payload.status || 'ALL'), options: ['ALL'].concat(GW_REQUEST_STATUSES || []) }
    ],
    list: {
      title: '업무요청 목록',
      totalReturned: rows.length,
      columns: ['requestId', 'requestType', 'title', 'requesterEmployeeId', 'targetEmployeeId', 'priority', 'requestStatus'],
      rows: rows
    },
    form: {
      title: selected ? '요청 상세 / 수정' : '새 요청 / 상세',
      fields: gwBuildB15RequestFormFields_(selected)
    },
    approvals: {
      title: '승인 이력',
      totalReturned: approvals.length,
      columns: ['approvalId', 'approverEmployeeId', 'approvalStep', 'approvalStatus', 'approvalComment', 'approvedAt', 'rejectedAt'],
      rows: approvals
    },
    messages: [
      { type: 'info', text: 'PORTAL 중앙 메뉴에서 열린 본문 화면입니다. 이 화면은 메뉴를 렌더링하지 않습니다.' },
      { type: 'success', text: '업무요청 저장, 승인, 반려 성공 시 목록과 상세를 다시 조회합니다.' },
      { type: 'error', text: '반려 사유, 상태전이, 권한 오류가 있으면 이 영역에 실패 안내문을 표시합니다.' }
    ],
    apiCalls: spec.calls,
    saveSheet: 'Portal_Requests',
    readSheet: 'Portal_Approvals',
    logSheet: 'Portal_AuditLog'
  };
  model.bodyHtml = gwRenderB15RequestsBodyHtml_(model);
  model.bodyAudit = gwValidateB15BodyModel_(model);
  return model;
}

function gwFindB15BodySpec_(screenId) {
  var specs = gwGetB15BodySpecs();
  for (var i = 0; i < specs.length; i++) {
    if (specs[i].screenId === screenId) return specs[i];
  }
  throw new Error('B15 본문 책임표를 찾을 수 없습니다: ' + screenId);
}

function gwBuildB15RequestFormFields_(request) {
  request = request || {};
  return GW_B15_REQUEST_FORM_FIELDS.map(function (field) {
    return {
      field: field,
      label: gwGetB15RequestFieldLabel_(field),
      value: gwToSafeText_(request[field]),
      required: field === 'title' || field === 'content' || field === 'requestType' || field === 'requestStatus',
      inputType: field === 'content' || field === 'statusReason' || field === 'approvalComment' ? 'textarea' : 'text'
    };
  });
}

function gwGetB15RequestFieldLabel_(field) {
  var labels = {
    requestId: '요청 ID', requestType: '요청 유형', title: '제목', content: '내용', requesterEmployeeId: '요청자',
    targetEmployeeId: '대상 직원', targetVendorId: '대상 업체', targetEventId: '대상 행사', relatedCustomerId: '관련 고객',
    relatedContractId: '관련 계약', relatedDocumentId: '관련 문서', relatedSettlementId: '관련 정산', priority: '우선순위',
    requestStatus: '요청 상태', statusReason: '상태 사유', approverEmployeeId: '승인자', approvalComment: '승인/반려 의견'
  };
  return labels[field] || field;
}

function gwRenderB15RequestsBodyHtml_(model) {
  var rowsHtml = model.list.rows.map(function (row) {
    return '<tr data-request-id="' + gwEscHtml_(row.requestId) + '">' +
      '<td>' + gwEscHtml_(row.requestId) + '</td>' +
      '<td>' + gwEscHtml_(row.requestType) + '</td>' +
      '<td>' + gwEscHtml_(row.title) + '</td>' +
      '<td>' + gwEscHtml_(row.requesterEmployeeId) + '</td>' +
      '<td>' + gwEscHtml_(row.targetEmployeeId) + '</td>' +
      '<td>' + gwEscHtml_(row.priority) + '</td>' +
      '<td>' + gwEscHtml_(row.requestStatus) + '</td>' +
    '</tr>';
  }).join('') || '<tr><td colspan="7">표시할 업무요청이 없습니다.</td></tr>';
  var fieldsHtml = model.form.fields.map(function (field) {
    if (field.inputType === 'textarea') {
      return '<label>' + gwEscHtml_(field.label) + '<textarea data-field="' + gwEscHtml_(field.field) + '">' + gwEscHtml_(field.value) + '</textarea></label>';
    }
    return '<label>' + gwEscHtml_(field.label) + '<input type="text" data-field="' + gwEscHtml_(field.field) + '" value="' + gwEscHtml_(field.value) + '" /></label>';
  }).join('');
  var approvalsHtml = model.approvals.rows.map(function (row) {
    return '<tr data-approval-id="' + gwEscHtml_(row.approvalId) + '">' +
      '<td>' + gwEscHtml_(row.approverEmployeeId) + '</td>' +
      '<td>' + gwEscHtml_(row.approvalStep) + '</td>' +
      '<td>' + gwEscHtml_(row.approvalStatus) + '</td>' +
      '<td>' + gwEscHtml_(row.approvalComment) + '</td>' +
      '<td>' + gwEscHtml_(row.approvedAt) + '</td>' +
      '<td>' + gwEscHtml_(row.rejectedAt) + '</td>' +
    '</tr>';
  }).join('') || '<tr><td colspan="6">승인 이력이 없습니다.</td></tr>';
  return '<section class="gw-body gw-requests-body" data-screen-id="GW_RequestsBody">' +
    '<h2>' + gwEscHtml_(model.title) + '</h2>' +
    '<p>' + gwEscHtml_(model.description) + '</p>' +
    '<div class="gw-actions">' + gwRenderB15ActionButtons_(model.actions) + '</div>' +
    '<div class="gw-filter"><label>검색 / 필터<input type="text" data-field="query" value="' + gwEscHtml_(model.filters[0].value) + '" /></label></div>' +
    '<div class="gw-message-zone"><p data-message-type="info">요청을 선택하거나 새 요청을 입력한 뒤 저장/승인/반려합니다.</p></div>' +
    '<div class="gw-layout-two"><div class="gw-list"><h3>목록</h3><table><thead><tr><th>요청 ID</th><th>유형</th><th>제목</th><th>요청자</th><th>대상</th><th>우선순위</th><th>상태</th></tr></thead><tbody>' + rowsHtml + '</tbody></table></div>' +
    '<div class="gw-detail"><h3>입력폼 / 상세</h3>' + fieldsHtml + '<h3>승인 이력</h3><table><thead><tr><th>승인자</th><th>단계</th><th>상태</th><th>의견</th><th>승인일</th><th>반려일</th></tr></thead><tbody>' + approvalsHtml + '</tbody></table></div></div>' +
  '</section>';
}

function gwRenderB15ActionButtons_(actions) {
  return actions.map(function (action) {
    return '<button type="button" data-gw-action="' + gwEscHtml_(action.call) + '" data-button-id="' + gwEscHtml_(action.id) + '">' + gwEscHtml_(action.label) + '</button>';
  }).join('');
}

function gwValidateB15BodyModel_(model) {
  var errors = [];
  var html = gwToSafeText_(model.bodyHtml);
  if (html.indexOf('<h2>') < 0) errors.push('화면 제목 누락: ' + model.screenId);
  if (html.indexOf('<p>') < 0) errors.push('화면 설명 누락: ' + model.screenId);
  if (html.indexOf('data-gw-action') < 0) errors.push('주요 작업 버튼 연결 누락: ' + model.screenId);
  if (html.indexOf('gw-filter') < 0) errors.push('검색 / 필터 영역 누락: ' + model.screenId);
  if (html.indexOf('gw-list') < 0 || html.indexOf('gw-detail') < 0) errors.push('목록 / 입력폼 / 상세 영역 누락: ' + model.screenId);
  if (html.indexOf('gw-message-zone') < 0) errors.push('성공 / 실패 안내문 영역 누락: ' + model.screenId);
  GW_B15_FORBIDDEN_VISIBLE_TOKENS.forEach(function (token) {
    if (html.toLowerCase().indexOf(token.toLowerCase()) >= 0) errors.push('금지 UI 토큰 포함: ' + token);
  });
  return { ok: errors.length === 0, errors: errors, htmlLength: html.length };
}

function gwValidateB15BodyContracts(payload) {
  var errors = [];
  var specs = gwGetB15BodySpecs();
  var expectedHandlers = { gwHandleRequestsBody: true };
  var expectedRoutes = { '/groupware/requests': true };
  specs.forEach(function (spec) {
    if (spec.moduleCode !== GW_B15_MODULE_CODE) errors.push('moduleCode 오류: ' + spec.screenId);
    if (!expectedHandlers[spec.handler]) errors.push('handler 오류: ' + spec.handler);
    if (!expectedRoutes[spec.route]) errors.push('route 오류: ' + spec.route);
    if (spec.permissionCode !== 'canApprove') errors.push('permissionCode 오류: ' + spec.screenId);
    if (!spec.buttons || spec.buttons.length < 5) errors.push('버튼 목록 부족: ' + spec.screenId);
    if (!spec.calls || spec.calls.length < 5) errors.push('호출 함수 부족: ' + spec.screenId);
    if (spec.sheets.indexOf('Portal_Requests') < 0 || spec.sheets.indexOf('Portal_Approvals') < 0) errors.push('저장/승인 시트 누락: ' + spec.screenId);
    if (spec.logSheet !== 'Portal_AuditLog') errors.push('로그 시트 오류: ' + spec.screenId);
  });
  return gwOk_({ ok: errors.length === 0, errors: errors, specCount: specs.length, portalShellOnly: true }, errors.length === 0 ? 'B15_BODY_CONTRACT_OK' : 'B15_BODY_CONTRACT_ERROR');
}
