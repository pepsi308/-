/**
 * PORTAL_CALENDAR_SAFE01B_R10K4H_ALL_TYPE_STACKED_DETAIL_20260604
 * READ_ONLY_RUNTIME_VERIFY_NO_SHEET_PROVIDER_WRITE
 * Purpose: verify all three business type detail sections are stacked and each has extra meeting ledger with recorder.
 */
function portalCalendarSafe01BR10K4HAllTypeStackedDetailVerify(){
  var build='PORTAL_CALENDAR_SAFE01B_R10K4H_ALL_TYPE_STACKED_DETAIL_20260604';
  var baseBuild='PORTAL_CALENDAR_SAFE01B_R10K4G6_MODAL_SCROLL_REPAIR_20260604';
  var html=''; var readError='';
  try{html=HtmlService.createTemplateFromFile('MC_CalendarViewV01').getRawContent();}catch(e){readError=(e&&e.message)?e.message:String(e);}
  function has(s){return html.indexOf(s)>=0;}
  var checks={
    viewReadable:!!html,
    buildMarkerPresent:has(build),
    allTypeStackReady:has('data-r10k4h-all-type-stacked="1"')&&has('fhCalendarR10K4HAllDetailHtml'),
    selectionSectionReady:has('⚑ 1. 박람회 선정 과정')&&has('fhCalendarR10K4HSelectionDetailHtml'),
    eventSectionReady:has('▣ 2. 행사관리 상세 카드 / ERP_행사관리 원장')&&has('fhCalendarR10K4HEventDetailHtml'),
    generalSectionReady:has('▤ 3. 일반/기타 일정')&&has('fhCalendarR10K4HGeneralDetailHtml'),
    meetingLedgerReady:has('r10k4h-meeting-ledger')&&has('＋ 추가 미팅 적재'),
    recorderReady:has('fhCalendarR10K4HRecorder')&&has('기록자'),
    freeGeneralReady:has('개인일정 / 자율일정 입력'),
    eventMasterKept:has('ERP_행사관리')&&has('eventId')&&has('fhCalendarR10K2ApplyEventMasterSelection'),
    scrollRepairKept:has('PORTAL_CALENDAR_SAFE01B_R10K4G6_MODAL_SCROLL_REPAIR_20260604')&&has('fhCalendarR10K4G6NormalizeModalScroll'),
    dataLoadKept:has('PORTAL_CALENDAR_SAFE01B_R10K4G4_DATA_LOAD_SPEED_REPAIR_20260604')&&has('fhCalendarR10K4G4StartInit'),
    detailFixKept:has('PORTAL_CALENDAR_SAFE01B_R10K4G5_RECORD_INITIAL_STATE_FIX_20260604')&&has('recordInitialState'),
    clickHardeningKept:has('R10K4G3_CLICK_BINDING_HARDEN')||has('fhCalendarR10K4G3'),
    r11AutoRefreshKept:has('fhCalendarStartAutoRefreshR11'),
    providerWriteNotAdded:!has('CalendarApp.getCalendarById')&&!has('createEventFromDescription'),
    noSheetProviderWriteInVerify:true
  };
  var fatal=[]; Object.keys(checks).forEach(function(k){if(!checks[k])fatal.push(k);});
  var result={ok:fatal.length===0,build:build,baseBuild:baseBuild,action:'portalCalendarSafe01BR10K4HAllTypeStackedDetailVerify',safety:'READ_ONLY_RUNTIME_VERIFY_NO_SHEET_PROVIDER_WRITE',checks:checks,diagnostics:{htmlLength:html.length,readError:readError,positions:{h:html.indexOf(build),all:html.indexOf('data-r10k4h-all-type-stacked="1"'),meeting:html.indexOf('r10k4h-meeting-ledger')}},warnings:[],fatal:fatal,summary:{mode:'all business type detail sections stacked with extra meeting ledger and recorder',preserved:'G4 data loading, G5 detail fix, G6 modal scroll, G3 click hardening, R10K2 event master, R11 auto refresh'},message:fatal.length?'R10K4H all-type stacked detail verification failed.':'R10K4H all-type stacked detail verification passed.'};
  Logger.log('JSON_COMPACT_RESULT: '+JSON.stringify(result));
  return result;
}
function portalCalendarSafe01BR10K4HStackedDetailVerify(){return portalCalendarSafe01BR10K4HAllTypeStackedDetailVerify();}
function portalCalendarSafe01BR10K4HVerify(){return portalCalendarSafe01BR10K4HAllTypeStackedDetailVerify();}
