/**
 * FEELHAUS MailCenter Template Manager Shell V01
 * Build: MC_TEMPLATE_SHELL_V01_20260519
 */

var MC_TEMPLATE_SHELL_V01_BUILD = 'MC_TEMPLATE_SHELL_V01_20260519';

function runMcTemplateShellV01() {
  var result = {
    ok: false,
    build: MC_TEMPLATE_SHELL_V01_BUILD,
    action: 'runMcTemplateShellV01',
    generatedAt: Utilities.formatDate(new Date(), Session.getScriptTimeZone() || 'Asia/Seoul', 'yyyy-MM-dd HH:mm:ss'),
    message: '',
    checks: []
  };

  try {
    result.checks.push({ key: 'CoreReady', ok: typeof mcTemplateCoreV01GetData === 'function', message: '템플릿 데이터 함수 확인' });
    result.checks.push({ key: 'SaveReady', ok: typeof mcTemplateCoreV01SaveTemplate === 'function', message: '템플릿 저장 함수 확인' });
    result.checks.push({ key: 'StatusReady', ok: typeof mcTemplateCoreV01SetTemplateStatus === 'function', message: '템플릿 상태 함수 확인' });
    result.checks.push({ key: 'HandleGetReady', ok: typeof mcTemplateShellV01HandleGet === 'function', message: '템플릿 화면 핸들러 확인' });

    result.ok = result.checks.every(function(c) { return !!c.ok; });
    result.message = result.ok ? 'MailCenter Template Shell V01 준비 완료' : 'MailCenter Template Shell V01 점검 필요';
  } catch (err) {
    result.ok = false;
    result.message = String(err && err.message ? err.message : err);
  }

  Logger.log('JSON_COMPACT_RESULT: ' + JSON.stringify(result));
  return result;
}

function mcTemplateShellV01HandleGet(e) {
  var data = typeof mcTemplateCoreV01GetData === 'function'
    ? mcTemplateCoreV01GetData({})
    : { ok: false, message: 'mcTemplateCoreV01GetData 함수가 없습니다.', templates: [], summary: {} };

  var t = HtmlService.createTemplateFromFile('MC_TemplateViewV01');
  t.build = MC_TEMPLATE_SHELL_V01_BUILD;
  t.initialJson = JSON.stringify(data);

  return t.evaluate()
    .setTitle('FEELHAUS MailCenter Template Manager')
    .setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL);
}
