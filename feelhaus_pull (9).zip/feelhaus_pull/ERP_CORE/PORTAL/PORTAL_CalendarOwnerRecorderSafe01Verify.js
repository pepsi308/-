
/** PORTAL_CALENDAR_OWNER_RECORDER_SAFE01_MARKER_REPACK_VERIFY_20260602 */
function portalCalendarOwnerRecorderOnlyVerify() {
  var result = {
    ok: false,
    build: 'PORTAL_CALENDAR_OWNER_RECORDER_SAFE01_MARKER_REPACK_20260602',
    action: 'portalCalendarOwnerRecorderOnlyVerify',
    safety: 'READ_ONLY_VERIFY_NO_DELETE_NO_IMPORT_NO_EXTERNAL_WRITE',
    scope: 'CALENDAR_OWNER_RECORDER_SPLIT_ONLY_GATE',
    checks: {},
    fatal: [],
    warnings: [],
    generatedAt: Utilities.formatDate(new Date(), 'Asia/Seoul', 'yyyy-MM-dd HH:mm:ss')
  };
  try {
    var html = HtmlService.createHtmlOutputFromFile('MC_CalendarViewV01').getContent();
    var c = result.checks;
    c.safe01MarkerExists = html.indexOf('PORTAL_CALENDAR_OWNER_RECORDER_SAFE01_MARKER_20260602') >= 0 || (html.indexOf('function fhCalendarBusinessOwnerSafe01') >= 0 && html.indexOf('function fhCalendarRecorderSafe01') >= 0 && html.indexOf('function fhCalendarUpdaterSafe01') >= 0);
    c.businessOwnerHelperExists = html.indexOf('function fhCalendarBusinessOwnerSafe01') >= 0;
    c.recorderHelperExists = html.indexOf('function fhCalendarRecorderSafe01') >= 0;
    c.updaterHelperExists = html.indexOf('function fhCalendarUpdaterSafe01') >= 0;
    c.nameEmailFormatterExists = html.indexOf('function fhCalendarPersonNameEmailSafe01') >= 0;
    c.currentUserNotUsedAsBusinessOwner = html.indexOf('e.manager,e.createdBy') < 0 && html.indexOf("detailVal(ev,'assignedEmployeeId'),detailVal(ev,'ownerEmployeeId'),e.assignedEmployeeId,e.ownerEmployeeId,'-'") < 0;
    c.listShowsOwnerLabel = html.indexOf('담당자 '+"'+esc(owner)+'") >= 0 || html.indexOf('담당자 미지정') >= 0;
    c.listShowsRecorderLabel = html.indexOf('기록자 '+"'+esc(recorder)+'") >= 0;
    c.detailRecordInfoSectionExists = html.indexOf('일정 기록 정보') >= 0;
    c.detailShowsRecorder = html.indexOf('<b>기록자</b>') >= 0;
    c.detailShowsUpdater = html.indexOf('<b>최종 수정자</b>') >= 0;
    c.icsOriginalOrganizerSeparated = html.indexOf('원본 주최자') >= 0;
    c.noSpanBarCodeAdded = html.indexOf('fhBuildMonthSpanSegmentsV06') < 0 && html.indexOf('month-span-bar') < 0;
    c.v05StillKept = html.indexOf('PORTAL_CALENDAR_CONTENT_NORMALIZE_NAV_YEAR_V05') >= 0 || html.indexOf('displayBody') >= 0;
    c.batchIdSyncStillKept = html.indexOf('__naverIcsLastDryRunBatchIdV04') >= 0 && html.indexOf('dryRunApprovalToken') >= 0 && html.indexOf('naverIcsRollbackBatchIdV03') >= 0;
    result.sample = {
      businessOwner: '담당자: 담당자 미지정 또는 실제 ownerName',
      recorder: '기록자: 이용필 <pepsi309@gmail.com>',
      updater: '최종 수정자: 이름 <email>',
      policy: 'createdBy/updatedBy는 기록자/수정자로만 표시하고, 담당자로 자동 사용하지 않음'
    };
    Object.keys(c).forEach(function(k){ if (!c[k]) result.fatal.push(k); });
    result.ok = result.fatal.length === 0;
    result.message = result.ok ? 'PORTAL calendar owner/recorder SAFE-01 verification passed.' : 'PORTAL calendar owner/recorder SAFE-01 verification failed.';
  } catch (err) {
    result.ok = false;
    result.fatal.push(err && err.stack ? String(err.stack) : String(err && err.message ? err.message : err));
    result.message = err && err.message ? err.message : String(err);
  }
  try { Logger.log('JSON_COMPACT_RESULT: ' + JSON.stringify(result)); } catch (ignore) {}
  return result;
}
