/**
 * FEELHAUS MailCenter Calendar Detail Stable Pack V01
 * Build: MAILCENTER_CALENDAR_DETAIL_STABLE_PACK_V01_20260521
 * Purpose:
 * - Lock/detail panel stable state after Detail Gate V01C passed
 * - Create actual backup spreadsheet for detail scope
 * - Append detail lock and summary records to FEELHAUS_DB_MASTER
 * - Do not modify router/menu/html/shell/view files
 */
var MC_CALENDAR_DETAIL_STABLE_PACK_V01_BUILD = 'MAILCENTER_CALENDAR_DETAIL_STABLE_PACK_V01_20260521';
var MC_CALENDAR_DETAIL_STABLE_PACK_V01_SETUP_DB_ID = '17VMSpgSZCvIrUlgcw8yCNcnl8WQWo2IcRf5tDCcuJGM';
var MC_CALENDAR_DETAIL_STABLE_PACK_V01_CONFIG_SHEET = 'SystemConfig';
var MC_CALENDAR_DETAIL_STABLE_PACK_V01_WEBAPP_URL = 'https://script.google.com/a/macros/feelhausfair.com/s/AKfycbxCyFE7zf4vE8nsfjOeWX0pC56SqU84gm8ie8Txa3qHQGEusJCZeljzCdYeOmZxUVYvjA/exec';

function runMcCalendarDetailStablePackV01Smoke() {
  var result = {
    ok: true,
    build: MC_CALENDAR_DETAIL_STABLE_PACK_V01_BUILD,
    action: 'runMcCalendarDetailStablePackV01Smoke',
    generatedAt: mcCalendarDetailStablePackV01Now_(),
    noWriteMode: true,
    checks: [],
    warnings: [],
    message: ''
  };
  function check(key, ok, message, detail) {
    result.checks.push({ key: key, ok: !!ok, message: message, detail: detail || '' });
    if (!ok) result.ok = false;
  }
  try {
    var master = mcCalendarDetailStablePackV01OpenMaster_();
    check('MasterOpenReady', !!master, 'SystemConfig -> FEELHAUS_DB_MASTER 연결 확인', master ? master.getId() : '');
    check('DetailGateFunctionReady', typeof runMcCalendarDetailGateV01C === 'function', '7-3 상세 게이트 V01C 함수 확인');
    check('DetailGetFunctionReady', typeof mcCalendarDetailCoreV01GetDetail === 'function' || typeof mcCalendarDetailCoreV01GetDetailById === 'function', '상세 조회 서버 함수 확인');
    check('LockFunctionReady', typeof runMcCalendarDetailStablePackV01CreateBackupAndLock === 'function', '상세 안정 잠금 함수 확인');
    check('SummaryFunctionReady', typeof runMcCalendarDetailStablePackV01Summary === 'function', '상세 요약 기록 함수 확인');
    check('WebAppUrlReady', !!MC_CALENDAR_DETAIL_STABLE_PACK_V01_WEBAPP_URL, 'WebApp 절대주소 확인', MC_CALENDAR_DETAIL_STABLE_PACK_V01_WEBAPP_URL);
    check('NoRouterMenuHtmlTouch', true, '본 파일은 라우터/메뉴/HTML/Shell/View 변경 없음');
    result.message = result.ok ? 'MailCenter Calendar Detail Stable Pack V01 Smoke 통과' : 'MailCenter Calendar Detail Stable Pack V01 점검 필요';
  } catch (err) {
    result.ok = false;
    result.message = mcCalendarDetailStablePackV01Err_(err);
  }
  Logger.log(JSON.stringify(result, null, 2));
  return result;
}

function runMcCalendarDetailStablePackV01CreateBackupAndLock() {
  var result = {
    ok: false,
    build: MC_CALENDAR_DETAIL_STABLE_PACK_V01_BUILD,
    action: 'runMcCalendarDetailStablePackV01CreateBackupAndLock',
    generatedAt: mcCalendarDetailStablePackV01Now_(),
    lockId: '',
    backupSpreadsheetId: '',
    backupName: '',
    copiedSheets: [],
    message: ''
  };
  var actor = mcCalendarDetailStablePackV01Actor_();
  try {
    var master = mcCalendarDetailStablePackV01OpenMaster_();
    var now = mcCalendarDetailStablePackV01Now_();
    var stamp = Utilities.formatDate(new Date(), Session.getScriptTimeZone() || 'Asia/Seoul', 'yyyyMMdd_HHmmss');
    var lockId = 'MCALDETAILLOCK-' + Utilities.formatDate(new Date(), Session.getScriptTimeZone() || 'Asia/Seoul', 'yyyyMMddHHmmss') + '-' + Utilities.getUuid().substring(0, 8).toUpperCase();
    var backupName = 'MAILCENTER_CALENDAR_DETAIL_STABLE_BACKUP_' + stamp;
    var backup = SpreadsheetApp.create(backupName);
    var backupId = backup.getId();

    var targetSheets = [
      'MAILCENTER_CalendarEvents',
      'MAILCENTER_CalendarMailLinks',
      'MAILCENTER_CalendarLogs',
      'MAILCENTER_CalendarStableLocks',
      'MAILCENTER_CalendarEventStatusLocks'
    ];
    var copied = [];
    targetSheets.forEach(function(sheetName) {
      var src = master.getSheetByName(sheetName);
      if (src) {
        var copy = src.copyTo(backup);
        copy.setName(sheetName);
        copied.push({ sheetName: sheetName, rows: src.getLastRow(), cols: src.getLastColumn() });
      } else {
        copied.push({ sheetName: sheetName, rows: 0, cols: 0, missing: true });
      }
    });

    var defaultSheet = backup.getSheetByName('Sheet1');
    if (defaultSheet && backup.getSheets().length > 1) backup.deleteSheet(defaultSheet);

    var info = backup.insertSheet('LOCK_INFO');
    var infoRows = [
      ['key', 'value'],
      ['lockId', lockId],
      ['build', MC_CALENDAR_DETAIL_STABLE_PACK_V01_BUILD],
      ['detailGateBuild', 'MAILCENTER_CALENDAR_DETAIL_GATE_V01C_FIX_20260521'],
      ['detailCoreBuild', 'MAILCENTER_CALENDAR_DETAIL_CORE_V01_20260521'],
      ['detailPanelBuild', 'MAILCENTER_CALENDAR_DETAIL_PANEL_V01_HTML_ONLY_20260521'],
      ['webAppUrl', MC_CALENDAR_DETAIL_STABLE_PACK_V01_WEBAPP_URL],
      ['sourceMasterId', master.getId()],
      ['backupSpreadsheetId', backupId],
      ['lockedAt', now],
      ['lockedBy', actor],
      ['status', 'DETAIL_STABLE_LOCKED'],
      ['scope', 'MailCenter calendar detail panel + mail link + logs + status data'],
      ['note', 'Router/menu/html/shell/view route structure not modified by this stable pack file']
    ];
    info.getRange(1, 1, infoRows.length, 2).setValues(infoRows);
    info.setFrozenRows(1);

    mcCalendarDetailStablePackV01AppendByHeaders_(master, 'MAILCENTER_CalendarDetailLocks', mcCalendarDetailStablePackV01LockHeaders_(), {
      lockId: lockId,
      build: MC_CALENDAR_DETAIL_STABLE_PACK_V01_BUILD,
      detailGateBuild: 'MAILCENTER_CALENDAR_DETAIL_GATE_V01C_FIX_20260521',
      backupName: backupName,
      backupSpreadsheetId: backupId,
      webAppUrl: MC_CALENDAR_DETAIL_STABLE_PACK_V01_WEBAPP_URL,
      status: 'DETAIL_STABLE_LOCKED',
      statusReason: 'MailCenter 캘린더 상세 패널 안정 게이트 및 백업 잠금 완료',
      copiedSheetsJson: JSON.stringify(copied),
      createdAt: now,
      createdBy: actor,
      updatedAt: now,
      updatedBy: actor
    });

    try {
      if (typeof mcCalendar19AppendAuditLog_ === 'function') {
        mcCalendar19AppendAuditLog_('MAILCENTER_CALENDAR_DETAIL_STABLE_LOCK', actor, lockId, 'SUCCESS', 'MailCenter 캘린더 상세 패널 안정 잠금 완료', { backupSpreadsheetId: backupId, backupName: backupName });
      }
    } catch (auditErr) {}

    result.ok = true;
    result.lockId = lockId;
    result.backupSpreadsheetId = backupId;
    result.backupName = backupName;
    result.copiedSheets = copied;
    result.message = 'MailCenter Calendar Detail Stable Pack V01 Lock 완료';
  } catch (err) {
    result.ok = false;
    result.message = mcCalendarDetailStablePackV01Err_(err);
  }
  Logger.log(JSON.stringify(result, null, 2));
  return result;
}

function runMcCalendarDetailStablePackV01Summary() {
  var result = {
    ok: false,
    build: MC_CALENDAR_DETAIL_STABLE_PACK_V01_BUILD,
    action: 'runMcCalendarDetailStablePackV01Summary',
    generatedAt: mcCalendarDetailStablePackV01Now_(),
    summaryId: '',
    message: ''
  };
  var actor = mcCalendarDetailStablePackV01Actor_();
  try {
    var master = mcCalendarDetailStablePackV01OpenMaster_();
    var now = mcCalendarDetailStablePackV01Now_();
    var summaryId = 'MCALDETAILSUM-' + Utilities.formatDate(new Date(), Session.getScriptTimeZone() || 'Asia/Seoul', 'yyyyMMddHHmmss') + '-' + Utilities.getUuid().substring(0, 8).toUpperCase();
    var counts = mcCalendarDetailStablePackV01CollectCounts_(master);
    mcCalendarDetailStablePackV01AppendByHeaders_(master, 'MAILCENTER_CalendarDetailSummaries', mcCalendarDetailStablePackV01SummaryHeaders_(), {
      summaryId: summaryId,
      build: MC_CALENDAR_DETAIL_STABLE_PACK_V01_BUILD,
      detailGateBuild: 'MAILCENTER_CALENDAR_DETAIL_GATE_V01C_FIX_20260521',
      webAppUrl: MC_CALENDAR_DETAIL_STABLE_PACK_V01_WEBAPP_URL,
      status: 'DETAIL_SUMMARY_RECORDED',
      statusReason: '상세 패널 서버/화면/게이트/잠금 요약 기록 완료',
      eventCount: counts.eventCount,
      mailLinkCount: counts.mailLinkCount,
      logCount: counts.logCount,
      lockCount: counts.lockCount,
      summaryJson: JSON.stringify(counts),
      createdAt: now,
      createdBy: actor,
      updatedAt: now,
      updatedBy: actor
    });
    result.ok = true;
    result.summaryId = summaryId;
    result.message = 'MailCenter Calendar Detail Stable Pack V01 Summary 기록 완료';
  } catch (err) {
    result.ok = false;
    result.message = mcCalendarDetailStablePackV01Err_(err);
  }
  Logger.log(JSON.stringify(result, null, 2));
  return result;
}

function mcCalendarDetailStablePackV01CollectCounts_(master) {
  function countRows(name) {
    var sh = master.getSheetByName(name);
    if (!sh) return 0;
    return Math.max(sh.getLastRow() - 1, 0);
  }
  return {
    eventCount: countRows('MAILCENTER_CalendarEvents'),
    mailLinkCount: countRows('MAILCENTER_CalendarMailLinks'),
    logCount: countRows('MAILCENTER_CalendarLogs'),
    lockCount: countRows('MAILCENTER_CalendarDetailLocks')
  };
}

function mcCalendarDetailStablePackV01LockHeaders_() {
  return ['lockId','build','detailGateBuild','backupName','backupSpreadsheetId','webAppUrl','status','statusReason','copiedSheetsJson','createdAt','createdBy','updatedAt','updatedBy'];
}

function mcCalendarDetailStablePackV01SummaryHeaders_() {
  return ['summaryId','build','detailGateBuild','webAppUrl','status','statusReason','eventCount','mailLinkCount','logCount','lockCount','summaryJson','createdAt','createdBy','updatedAt','updatedBy'];
}

function mcCalendarDetailStablePackV01AppendByHeaders_(ss, sheetName, baseHeaders, record) {
  var sheet = mcCalendarDetailStablePackV01GetSheetOrCreate_(ss, sheetName, baseHeaders);
  mcCalendarDetailStablePackV01EnsureHeaders_(sheet, Object.keys(record || {}));
  var headers = sheet.getRange(1, 1, 1, sheet.getLastColumn()).getValues()[0];
  var hm = mcCalendarDetailStablePackV01HeaderMap_(headers);
  var row = [];
  for (var i = 0; i < headers.length; i++) row.push('');
  Object.keys(record || {}).forEach(function(key) {
    if (hm.hasOwnProperty(key)) row[hm[key]] = record[key];
  });
  sheet.appendRow(row);
}

function mcCalendarDetailStablePackV01GetSheetOrCreate_(ss, name, headers) {
  var sheet = ss.getSheetByName(name);
  if (!sheet) {
    sheet = ss.insertSheet(name);
    sheet.getRange(1, 1, 1, headers.length).setValues([headers]);
    sheet.setFrozenRows(1);
    return sheet;
  }
  if (sheet.getLastRow() < 1 || sheet.getLastColumn() < 1) {
    sheet.getRange(1, 1, 1, headers.length).setValues([headers]);
    sheet.setFrozenRows(1);
    return sheet;
  }
  mcCalendarDetailStablePackV01EnsureHeaders_(sheet, headers);
  return sheet;
}

function mcCalendarDetailStablePackV01EnsureHeaders_(sheet, requiredHeaders) {
  var lastCol = Math.max(sheet.getLastColumn(), 1);
  var headers = sheet.getRange(1, 1, 1, lastCol).getValues()[0];
  var hm = mcCalendarDetailStablePackV01HeaderMap_(headers);
  var add = [];
  (requiredHeaders || []).forEach(function(h) { if (h && !hm.hasOwnProperty(h)) add.push(h); });
  if (add.length) sheet.getRange(1, headers.length + 1, 1, add.length).setValues([add]);
}

function mcCalendarDetailStablePackV01OpenMaster_() {
  var setup = SpreadsheetApp.openById(MC_CALENDAR_DETAIL_STABLE_PACK_V01_SETUP_DB_ID);
  var sheet = setup.getSheetByName(MC_CALENDAR_DETAIL_STABLE_PACK_V01_CONFIG_SHEET);
  if (!sheet) throw new Error('SystemConfig 시트를 찾지 못했습니다.');
  var values = sheet.getDataRange().getValues();
  if (!values || values.length < 2) throw new Error('SystemConfig 데이터가 비어 있습니다.');
  var hm = mcCalendarDetailStablePackV01HeaderMap_(values[0]);
  var keyCol = mcCalendarDetailStablePackV01PickIndex_(hm, ['CONFIG_KEY','configKey','key','name']);
  var valCol = mcCalendarDetailStablePackV01PickIndex_(hm, ['VALUE','configValue','value','spreadsheetId']);
  if (keyCol < 0 || valCol < 0) throw new Error('SystemConfig CONFIG_KEY/VALUE 헤더를 찾지 못했습니다.');
  var masterId = '';
  for (var r = 1; r < values.length; r++) {
    var key = String(values[r][keyCol] || '').trim();
    if (key === 'FEELHAUS_DB_MASTER' || key === 'FEELHAUS_DB_MASTER_ID' || key === 'MASTER_DB_ID') {
      masterId = String(values[r][valCol] || '').trim();
      break;
    }
  }
  if (!masterId) throw new Error('SystemConfig에서 FEELHAUS_DB_MASTER ID를 찾지 못했습니다.');
  return SpreadsheetApp.openById(masterId);
}

function mcCalendarDetailStablePackV01HeaderMap_(headers) {
  var out = {};
  (headers || []).forEach(function(h, i) {
    var key = String(h || '').trim();
    if (key) out[key] = i;
  });
  return out;
}

function mcCalendarDetailStablePackV01PickIndex_(hm, keys) {
  for (var i = 0; i < keys.length; i++) if (hm.hasOwnProperty(keys[i])) return hm[keys[i]];
  return -1;
}

function mcCalendarDetailStablePackV01Actor_() {
  return String(Session.getActiveUser().getEmail() || 'MAILCENTER_ADMIN').trim() || 'MAILCENTER_ADMIN';
}

function mcCalendarDetailStablePackV01Now_() {
  return Utilities.formatDate(new Date(), Session.getScriptTimeZone() || 'Asia/Seoul', 'yyyy-MM-dd HH:mm:ss');
}

function mcCalendarDetailStablePackV01Err_(err) {
  return err && err.message ? err.message : String(err);
}
