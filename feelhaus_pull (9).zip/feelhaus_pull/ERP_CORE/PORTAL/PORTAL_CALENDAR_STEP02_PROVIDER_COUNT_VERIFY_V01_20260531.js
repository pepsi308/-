/**
 * PORTAL_CALENDAR_STEP02_PROVIDER_COUNT_VERIFY_V01_20260531
 *
 * File:
 * - PORTAL_CALENDAR_STEP02_PROVIDER_COUNT_VERIFY_V01_20260531.js
 *
 * Function:
 * - portalCalendarStep02ProviderCountVerifyV01
 *
 * Scope:
 * - Step02 only: NAVER/GOOGLE summary cards count from current monthly rows.
 * - Keeps Step01 modal/full-list markers.
 * - Read-only, no external API, no sheet mutation.
 */
function portalCalendarStep02ProviderCountVerifyV01() {
  var out = {
    ok: false,
    build: 'PORTAL_CALENDAR_STEP02_PROVIDER_COUNT_VERIFY_V01_20260531',
    action: 'portalCalendarStep02ProviderCountVerifyV01',
    safety: 'READ_ONLY_NO_API_NO_SHEET_MUTATION',
    scope: 'UI_ONLY_PROVIDER_CARD_COUNTS_FROM_MONTH_ROWS',
    checks: {},
    fatal: [],
    warnings: [],
    generatedAt: Utilities.formatDate(new Date(), 'Asia/Seoul', 'yyyy-MM-dd HH:mm:ss')
  };

  try {
    var html = HtmlService.createHtmlOutputFromFile('MC_CalendarViewV01').getContent();
    function has(s){ return String(html || '').indexOf(s) >= 0; }

    out.checks.uiLoaded = html.length > 1000;
    out.checks.step01StillFixed = has("setTimeout(closeManualEventModal,60);") && has("reloadMonth({listMode:'all',message:state.pendingFocusMessage})");
    out.checks.providerCountHelper = has('function fhCalendarProviderCountsStep02(events)');
    out.checks.naverCountsSuccessOrProviderId = has("ns==='SUCCESS'||nId");
    out.checks.googleCountsSuccessOrProviderId = has("gs==='SUCCESS'||gId");
    out.checks.applyMonthUsesRowCounts = has('var pc=fhCalendarProviderCountsStep02(state.events);');
    out.checks.naverCardUsesRowCounts = has("id('naverSuccess').textContent=pc.naverSuccess");
    out.checks.googleCardUsesRowCounts = has("id('googleSuccess').textContent=pc.googleSuccess");
    out.checks.oldDashboardCountRemoved = !has("dashboard||{};id('naverSuccess').textContent=Number(d.naverSuccess||0)");
    out.checks.noActorAudit = !has('portalActorAuditLockV01') && !has('PORTAL_ACTOR_AUDIT');

    Object.keys(out.checks).forEach(function(k){
      if (!out.checks[k]) out.fatal.push(k);
    });
    out.ok = out.fatal.length === 0;
  } catch (err) {
    out.ok = false;
    out.fatal.push(err && err.stack ? String(err.stack) : String(err && err.message ? err.message : err));
  }

  Logger.log('JSON_COMPACT_RESULT: ' + JSON.stringify(out));
  return out;
}
