/**
 * PORTAL_CALENDAR_CONTENT_NORMALIZE_NAV_YEAR_V05
 * Save-hook external sync for a single calendarEventId.
 * - NAVER: create only through official createSchedule.json; NAVER modify is disabled after official min diag 409 result.
 * - GOOGLE_BACKUP: creates backup only when googleBackupStatus is not SUCCESS.
 * - Existing NAVER-linked rows are skipped for NAVER updates to avoid 409 Ical UID conflicts.
 */
var PORTAL_CALENDAR_SAFE01B_R7D_AUTOSYNC_ACTOR_PRESERVE_BUILD = 'PORTAL_CALENDAR_SAFE01B_R7D_AUTOSYNC_ACTOR_PRESERVE_20260602';
var PORTAL_CALENDAR_SAFE01B_R9A_RUNTIME_VERIFY_FIX_AUTOSYNC_BUILD = 'PORTAL_CALENDAR_SAFE01B_R9A_RUNTIME_VERIFY_FIX_20260602';
function portalCalendarExternalAutoSyncV01(request) {
  request = request || {};
  var result = {
    ok: false,
    build: 'PORTAL_STEP08_NAVER_CREATE_ONLY',
    forceReplace: 'FINAL_NAVER_CREATE_ONLY_NO_MODIFY_409_SAFE',
    action: 'portalCalendarExternalAutoSyncV01',
    calendarEventId: String(request.calendarEventId || '').trim(),
    realApplyExecuted: true,
    naverRealApplyExecuted: false,
    googleRealApplyExecuted: false,
    destructiveRepairExecuted: false,
    actualDeleteExecuted: false,
    finalInlineTraceMarkers: '[NAVER_CREATE_ONLY][REQUEST] [NAVER_CREATE_ONLY][RESPONSE] createSchedule.json NAVER_MODIFY_DISABLED_AFTER_OFFICIAL_409 portalCalendarStep08NaverFetchCreateScheduleWithRefreshRetryV07',
    details: [],
    fatal: [],
    warnings: [],
    generatedAt: Utilities.formatDate(new Date(), 'Asia/Seoul', 'yyyy-MM-dd HH:mm:ss')
  };
  var __r7dSs = null;
  var __r7dActorSnapshot = null;

  try {
    if (!result.calendarEventId) throw new Error('calendarEventId is required');
    var configBundle = mcCalendar19GetConfigBundle_();
    var profile = mcCalendar186ResolveCalendarActor_(request, configBundle, { allowFallback: true });
    var ss = mcCalendar19OpenMaster_(configBundle);
    __r7dSs = ss;
    var sheet = mcCalendar19GetSheetOrCreate_(ss, 'MAILCENTER_CalendarEvents', mcCalendar186CalendarEventHeaders_());
    var values = sheet.getDataRange().getValues();
    if (!values || values.length < 2) throw new Error('MAILCENTER_CalendarEvents has no rows');
    var hm = mcCalendar19HeaderMap_(values[0]);
    var rowNo = -1;
    var row = null;
    for (var r = values.length - 1; r >= 1; r--) {
      if (String(values[r][hm.calendarEventId] || '') === result.calendarEventId) { rowNo = r + 1; row = values[r]; break; }
    }
    if (rowNo < 0) throw new Error('calendar row not found: ' + result.calendarEventId);

    var obj = {};
    Object.keys(hm).forEach(function(k){ obj[k] = row[hm[k]]; });
    __r7dActorSnapshot = portalCalendarExternalAutoSyncV01ActorSnapshotR7D_(obj);
    result.r7dActorProtect = { enabled:true, updatedBy:__r7dActorSnapshot.updatedBy || '', updatedByEmail:__r7dActorSnapshot.updatedByEmail || '', source:__r7dActorSnapshot.updatedActorSource || __r7dActorSnapshot.actorSource || '' };
    obj.title = obj.eventTitle || obj.title || obj.displayTitle || 'FEELHAUS Calendar';
    obj.description = portalCalendarExternalAutoSyncV01BusinessDescriptionV05_(obj);
    obj.eventDescription = obj.description;
    obj.targetType = obj.eventType || obj.targetType || 'PORTAL_CALENDAR';
    obj.targetId = obj.calendarEventId || result.calendarEventId;

    var providerPolicy = portalCalendarExternalAutoSyncV06ResolvePolicy_(configBundle, profile, obj, request);
    result.calendarPolicy = { policyType: providerPolicy.policyType, vendorId: providerPolicy.vendorId || '', googleCalendarId: providerPolicy.googleCalendarId || '', naverAllowed: providerPolicy.naverAllowed === true };
    var providerConfigBundle = portalCalendarExternalAutoSyncV06ConfigBundleWithCalendar_(configBundle, providerPolicy.googleCalendarId);

    var start = portalCalendarExternalAutoSyncV01Date_(obj.startAt);
    var end = portalCalendarExternalAutoSyncV01Date_(obj.endAt || obj.startAt);
    if (!start || !end) throw new Error('startAt/endAt invalid');
    if (end.getTime() <= start.getTime()) end = new Date(start.getTime() + 30 * 60 * 1000);

    var naverStatus = String(obj.naverRegisterStatus || '').toUpperCase();
    var naverProviderEventId = portalCalendarExternalAutoSyncV01PickNaverProviderEventIdStep08_(obj);
    if (!providerPolicy.naverAllowed) {
      result.details.push({ provider:'NAVER', action:'SKIP_VENDOR_NAVER_BLOCKED_BY_POLICY_V06', calendarEventId:result.calendarEventId, vendorId:providerPolicy.vendorId || '' });
    } else if (naverProviderEventId || naverStatus === 'SUCCESS') {
      // PORTAL_STEP08_NAVER_CREATE_ONLY
      // OFFICIAL_MIN_DIAG confirmed: create succeeds, same UID modify returns 409 Ical Uid conflict.
      // Therefore NAVER is operated as create-only. Existing NAVER-linked events are not modified from PORTAL.
      result.details.push({
        provider:'NAVER',
        action:'SKIP_NAVER_MODIFY_DISABLED_CREATE_ONLY',
        ok:true,
        calendarEventId:result.calendarEventId,
        naverRegisterStatus:naverStatus || '',
        providerEventId:naverProviderEventId || '',
        message:'NAVER 신규등록 전용 모드: 기존 NAVER 일정 수정 자동반영은 비활성화됨'
      });
    } else if (naverStatus === 'FAIL') {
      // Avoid repeating known NAVER create failures on later edits. Manual reset/retry can be added later if needed.
      result.details.push({
        provider:'NAVER',
        action:'SKIP_NAVER_CREATE_FAILED_CREATE_ONLY_RETRY_BLOCKED',
        ok:true,
        calendarEventId:result.calendarEventId,
        naverRegisterStatus:naverStatus,
        message:'NAVER 신규등록 실패 이력이 있어 자동 재시도하지 않음'
      });
    } else {
      var naverResult = mcCalendar186TryProviderCreate_(function(){
        return portalCalendarExternalAutoSyncV01CreateOrModifyNaverScheduleStep08_(configBundle, obj, start, end, '', false);
      }, 'NAVER');
      mcCalendar186ApplyProviderResult_(ss, result.calendarEventId, 'NAVER', naverResult, profile);
      result.naverRealApplyExecuted = true;
      result.details.push({ provider:'NAVER', action:naverResult.ok?'CREATE_SUCCESS_OFFICIAL_UID_LOCK':'CREATE_FAIL', ok:naverResult.ok, message:naverResult.message || '', errorMessage:naverResult.errorMessage || '', providerEventId:naverResult.providerEventId || '' });
    }

    var googleStatus = String(obj.googleBackupStatus || '').toUpperCase();
    var googleProviderEventId = String(obj.googleProviderEventId || obj.googleEventId || obj.googleCalendarEventId || '').trim();
    if (googleStatus === 'SUCCESS' && googleProviderEventId) {
      var googleUpdateResult = mcCalendar186TryProviderCreate_(function(){
        return portalCalendarExternalAutoSyncV01UpdateGoogleCalendarEventStep06_(providerConfigBundle, obj, start, end, googleProviderEventId);
      }, 'GOOGLE_BACKUP');
      mcCalendar186ApplyProviderResult_(ss, result.calendarEventId, 'GOOGLE_BACKUP', googleUpdateResult, profile);
      result.googleRealApplyExecuted = true;
      result.details.push({ provider:'GOOGLE_BACKUP', action:googleUpdateResult.ok?'UPDATE_SUCCESS':'UPDATE_FAIL', ok:googleUpdateResult.ok, message:googleUpdateResult.message || '', errorMessage:googleUpdateResult.errorMessage || '', providerEventId:googleUpdateResult.providerEventId || googleProviderEventId });
    } else if (googleStatus === 'SUCCESS') {
      result.details.push({ provider:'GOOGLE_BACKUP', action:'SKIP_ALREADY_SUCCESS_NO_PROVIDER_EVENT_ID', calendarEventId:result.calendarEventId });
    } else if (typeof mcCalendar19CreateGoogleCalendarEvent_ === 'function') {
      var googleResult = mcCalendar186TryProviderCreate_(function(){
        return mcCalendar19CreateGoogleCalendarEvent_(providerConfigBundle, obj, start, end, null);
      }, 'GOOGLE_BACKUP');
      mcCalendar186ApplyProviderResult_(ss, result.calendarEventId, 'GOOGLE_BACKUP', googleResult, profile);
      result.googleRealApplyExecuted = true;
      result.details.push({ provider:'GOOGLE_BACKUP', action:googleResult.ok?'CREATE_OR_UPDATE_STATUS':'CREATE_FAIL', ok:googleResult.ok, message:googleResult.message || '', errorMessage:googleResult.errorMessage || '', providerEventId:googleResult.providerEventId || '' });
    } else {
      result.warnings.push('mcCalendar19CreateGoogleCalendarEvent_ not found');
    }

    portalCalendarExternalAutoSyncV01RestoreActorFieldsR7D_(__r7dSs, result.calendarEventId, __r7dActorSnapshot);
    result.ok = result.fatal.length === 0;
    result.message = 'External sync completed for ' + result.calendarEventId;
  } catch (err) {
    try { portalCalendarExternalAutoSyncV01RestoreActorFieldsR7D_(__r7dSs, result.calendarEventId, __r7dActorSnapshot); } catch (restoreErrR7D) { result.warnings.push('R7D actor restore skipped: ' + (restoreErrR7D && restoreErrR7D.message ? restoreErrR7D.message : String(restoreErrR7D))); }
    result.ok = false;
    result.fatal.push(err && err.stack ? String(err.stack) : String(err && err.message ? err.message : err));
    result.message = err && err.message ? err.message : String(err);
  }
  try { Logger.log('JSON_COMPACT_RESULT: ' + JSON.stringify(result)); } catch (ignore) {}
  return result;
}



function portalCalendarExternalAutoSyncV01R7DRuntimeVerifyMarker_() {
  return {
    ok: true,
    build: PORTAL_CALENDAR_SAFE01B_R7D_AUTOSYNC_ACTOR_PRESERVE_BUILD,
    verifyFixBuild: PORTAL_CALENDAR_SAFE01B_R9A_RUNTIME_VERIFY_FIX_AUTOSYNC_BUILD,
    snapshotReady: typeof portalCalendarExternalAutoSyncV01ActorSnapshotR7D_ === 'function',
    restoreReady: typeof portalCalendarExternalAutoSyncV01RestoreActorFieldsR7D_ === 'function'
  };
}



/**
 * R10A compatibility marker alias.
 * Keeps R7D autosync verification stable across R9C/R10 verifiers.
 */
function portalCalendarExternalAutoSyncV01R7DMarker_() {
  return portalCalendarExternalAutoSyncV01R7DRuntimeVerifyMarker_();
}

function portalCalendarExternalAutoSyncV01ActorSnapshotR7D_(obj) {
  // R7D_AUTOSYNC_ACTOR_SNAPSHOT: the save-hook autosync may run as an internal/admin actor.
  // Preserve the real Google-authenticated user actor already written by the manual save path.
  obj = obj || {};
  function pick(keys) {
    for (var i = 0; i < keys.length; i++) {
      var v = String(obj[keys[i]] === null || obj[keys[i]] === undefined ? '' : obj[keys[i]]).trim();
      if (v) return v;
    }
    return '';
  }
  function isSystemActor(v) {
    v = String(v || '').trim().toUpperCase();
    return !v || v === 'ADMIN-001' || v === 'MAILCENTER_ADMIN' || v === 'SYSTEM' || v.indexOf('AUTO') >= 0;
  }
  var createdByEmail = pick(['createdByEmail','organizerEmail','createdBy']);
  var updatedByEmail = pick(['updatedByEmail','createdByEmail','organizerEmail','createdBy']);
  var createdBy = pick(['createdBy']);
  var updatedBy = pick(['updatedBy']);
  if (isSystemActor(createdBy) && createdByEmail) createdBy = createdByEmail;
  if (isSystemActor(updatedBy) && updatedByEmail) updatedBy = updatedByEmail;
  return {
    createdBy: createdBy,
    createdByName: pick(['createdByName']),
    createdByEmail: createdByEmail,
    createdByEmployeeId: pick(['createdByEmployeeId']),
    actorSource: pick(['actorSource']),
    actorRoleCode: pick(['actorRoleCode']),
    actorVendorId: pick(['actorVendorId']),
    updatedBy: updatedBy,
    updatedByName: pick(['updatedByName','createdByName']),
    updatedByEmail: updatedByEmail,
    updatedByEmployeeId: pick(['updatedByEmployeeId','createdByEmployeeId']),
    updatedActorSource: pick(['updatedActorSource','actorSource'])
  };
}

function portalCalendarExternalAutoSyncV01RestoreActorFieldsR7D_(ss, calendarEventId, snapshot) {
  // R7D_AUTOSYNC_ACTOR_RESTORE: provider sync updates only provider/status fields.
  // It must not leave updatedBy as admin-001 when updatedByEmail identifies the real user.
  if (!ss || !calendarEventId || !snapshot) return false;
  var sheet = mcCalendar19GetSheetOrCreate_(ss, 'MAILCENTER_CalendarEvents', mcCalendar186CalendarEventHeaders_());
  var values = sheet.getDataRange().getValues();
  if (!values || values.length < 2) return false;
  var hm = mcCalendar19HeaderMap_(values[0]);
  if (hm.calendarEventId === undefined) return false;
  var targetRow = -1;
  for (var r = values.length - 1; r >= 1; r--) {
    if (String(values[r][hm.calendarEventId] || '').trim() === String(calendarEventId || '').trim()) { targetRow = r + 1; break; }
  }
  if (targetRow < 0) return false;
  var updates = {};
  ['createdBy','createdByName','createdByEmail','createdByEmployeeId','actorSource','actorRoleCode','actorVendorId','updatedBy','updatedByName','updatedByEmail','updatedByEmployeeId','updatedActorSource'].forEach(function(k) {
    var v = String(snapshot[k] === null || snapshot[k] === undefined ? '' : snapshot[k]).trim();
    if (v) updates[k] = v;
  });
  // If a previous sync path already left updatedBy as admin-001 but updatedByEmail is valid, normalize updatedBy to that email.
  if (!updates.updatedBy && updates.updatedByEmail) updates.updatedBy = updates.updatedByEmail;
  if (!updates.createdBy && updates.createdByEmail) updates.createdBy = updates.createdByEmail;
  mcCalendar186SetRowValuesByHeader_(sheet, targetRow, updates);
  return true;
}


function portalCalendarExternalAutoSyncV06ResolvePolicy_(configBundle, profile, obj, request) {
  var cfg = (configBundle && configBundle.config) || {};
  var vendorId = String((request && request.vendorId) || (obj && obj.vendorId) || (profile && profile.vendorId) || '').trim();
  var isHq = portalCalendarExternalAutoSyncV06IsHqActor_(profile, vendorId);
  var googleCalendarId = '';
  var policyType = '';
  if (isHq) {
    googleCalendarId = String((request && request.googleCalendarId) || mcCalendar19PickConfig_(cfg, ['HQ_GOOGLE_CALENDAR_ID','PORTAL_GOOGLE_CALENDAR_ID','GOOGLE_CALENDAR_ID']) || '').trim();
    policyType = 'HQ_FIXED_GOOGLE_CALENDAR';
  } else {
    googleCalendarId = portalCalendarExternalAutoSyncV06VendorCalendarId_(configBundle, vendorId, request);
    policyType = 'VENDOR_FIXED_GOOGLE_CALENDAR';
  }
  if (!googleCalendarId) throw new Error(isHq ? 'HQ_GOOGLE_CALENDAR_ID 설정이 필요합니다.' : '업체 대표 Google Calendar ID 설정이 필요합니다: ' + vendorId);
  return { policyType: policyType, googleCalendarId: googleCalendarId, vendorId: vendorId, naverAllowed: isHq };
}

function portalCalendarExternalAutoSyncV06IsHqActor_(profile, vendorId) {
  var role = String((profile && (profile.roleCode || profile.role || profile.userRole)) || '').toUpperCase();
  var vendor = String(vendorId || '').trim();
  if (!vendor) return true;
  if (role.indexOf('SUPER') >= 0 || role.indexOf('ADMIN') >= 0 || role.indexOf('HQ') >= 0 || role.indexOf('본사') >= 0) return true;
  return false;
}

function portalCalendarExternalAutoSyncV06VendorCalendarId_(configBundle, vendorId, request) {
  var cfg = (configBundle && configBundle.config) || {};
  vendorId = String(vendorId || '').trim();
  var direct = String((request && request.googleCalendarId) || '').trim();
  if (direct) return direct;
  var keys = [];
  if (vendorId) {
    keys.push('VENDOR_GOOGLE_CALENDAR_ID_' + vendorId);
    keys.push('GOOGLE_CALENDAR_ID_' + vendorId);
  }
  keys.push('VENDOR_GOOGLE_CALENDAR_ID');
  var byConfig = String(mcCalendar19PickConfig_(cfg, keys) || '').trim();
  if (byConfig) return byConfig;
  try {
    var ss = mcCalendar19OpenMaster_(configBundle);
    var names = ['VendorGoogleCalendarMap','VENDOR_GOOGLE_CALENDAR_MAP','ERP_VendorGoogleCalendarMap','ERP_Vendors','Vendors'];
    for (var i = 0; i < names.length; i++) {
      var sh = ss.getSheetByName(names[i]);
      if (!sh) continue;
      var values = sh.getDataRange().getValues();
      if (!values || values.length < 2) continue;
      var hm = mcCalendar19HeaderMap_(values[0]);
      var vendorCol = hm.vendorId !== undefined ? hm.vendorId : (hm.vendorID !== undefined ? hm.vendorID : -1);
      var calCol = hm.googleCalendarId !== undefined ? hm.googleCalendarId : (hm.googleCalendarID !== undefined ? hm.googleCalendarID : (hm.calendarId !== undefined ? hm.calendarId : -1));
      var enabledCol = hm.googleSyncEnabled !== undefined ? hm.googleSyncEnabled : (hm.syncEnabled !== undefined ? hm.syncEnabled : -1);
      if (vendorCol < 0 || calCol < 0) continue;
      for (var r = 1; r < values.length; r++) {
        if (String(values[r][vendorCol] || '').trim() !== vendorId) continue;
        if (enabledCol >= 0) {
          var enabled = String(values[r][enabledCol] || '').toUpperCase();
          if (enabled && enabled !== 'TRUE' && enabled !== 'Y' && enabled !== 'YES' && enabled !== '1') continue;
        }
        var found = String(values[r][calCol] || '').trim();
        if (found) return found;
      }
    }
  } catch (ignore) {}
  return '';
}

function portalCalendarExternalAutoSyncV06ConfigBundleWithCalendar_(configBundle, googleCalendarId) {
  var clone = {};
  for (var k in (configBundle || {})) clone[k] = configBundle[k];
  var cfg = {};
  var sourceCfg = (configBundle && configBundle.config) || {};
  for (var ck in sourceCfg) cfg[ck] = sourceCfg[ck];
  cfg.GOOGLE_CALENDAR_ID = String(googleCalendarId || '').trim();
  cfg.HQ_GOOGLE_CALENDAR_ID = cfg.HQ_GOOGLE_CALENDAR_ID || cfg.GOOGLE_CALENDAR_ID;
  cfg.PORTAL_GOOGLE_CALENDAR_ID = cfg.PORTAL_GOOGLE_CALENDAR_ID || cfg.GOOGLE_CALENDAR_ID;
  clone.config = cfg;
  return clone;
}

function portalCalendarExternalAutoSyncV01BusinessDescriptionV05_(request) {
  request = request || {};
  var body = String(request.displayBody || '').trim();
  if (!body) body = String(request.eventDescription || request.description || '').trim();
  function add(label, value) {
    value = String(value || '').trim();
    if (!value) return;
    if (body.indexOf('[' + label + ']') < 0 && body.indexOf(value) < 0) body += (body ? '\n\n' : '') + '[' + label + ']\n' + value;
  }
  add('장소', request.displayLocation || request.location || '');
  add('참석자', request.displayAttendees || request.attendees || request.attendeesText || '');
  add('원본', request.displaySource || request.sourceName || request.sourceType || 'PORTAL');
  add('안내', request.displayNotice || '');
  return body || 'FEELHAUS PORTAL Calendar';
}

function portalCalendarExternalAutoSyncV01Date_(v) {
  if (Object.prototype.toString.call(v) === '[object Date]' && !isNaN(v.getTime())) return v;
  var s = String(v || '').trim();
  if (!s) return null;
  var m = s.match(/^(\d{4})[-\/](\d{1,2})[-\/](\d{1,2})(?:[ T](\d{1,2}):(\d{2})(?::(\d{2}))?)?/);
  if (m) return new Date(Number(m[1]), Number(m[2])-1, Number(m[3]), Number(m[4]||0), Number(m[5]||0), Number(m[6]||0));
  var d = new Date(s);
  return isNaN(d.getTime()) ? null : d;
}


/**
 * PORTAL_CALENDAR_STEP06_GOOGLE_UPDATE_V01_20260601
 * Existing GOOGLE_BACKUP provider event update path.
 * - Updates only the already linked Google Calendar event.
 * - Does not create duplicate Google events when googleBackupStatus is SUCCESS.
 * - NAVER update remains out of scope for this step.
 */
function portalCalendarExternalAutoSyncV01UpdateGoogleCalendarEventStep06_(configBundle, request, startAt, endAt, googleProviderEventId) {
  var cfg = (configBundle && configBundle.config) || {};
  mcCalendar186FeatureGuard_(cfg, 'FEATURE_GOOGLE_CALENDAR_BACKUP_ENABLED', '구글 캘린더 백업');
  googleProviderEventId = String(googleProviderEventId || '').trim();
  if (!googleProviderEventId) throw new Error('googleProviderEventId is required for Google update');
  var googleCalendarId = mcCalendar19PickConfig_(cfg, ['GOOGLE_CALENDAR_ID','HQ_GOOGLE_CALENDAR_ID','PORTAL_GOOGLE_CALENDAR_ID','VENDOR_GOOGLE_CALENDAR_ID']);
  var cal = googleCalendarId ? CalendarApp.getCalendarById(String(googleCalendarId)) : CalendarApp.getDefaultCalendar();
  if (!cal) throw new Error('GOOGLE_CALENDAR_ID 캘린더를 찾을 수 없습니다.');
  var event = cal.getEventById(googleProviderEventId);
  if (!event) throw new Error('Google 기존 provider 일정을 찾을 수 없습니다: ' + googleProviderEventId);
  var title = String(request.title || request.eventTitle || 'FEELHAUS Calendar');
  var description = portalCalendarExternalAutoSyncV01BusinessDescriptionV05_(request);
  event.setTitle(title);
  event.setTime(startAt, endAt);
  event.setDescription(description);
  if (request.location && typeof event.setLocation === 'function') event.setLocation(String(request.location));
  return {
    provider: 'GOOGLE_BACKUP',
    eventId: googleProviderEventId,
    message: 'GOOGLE 기존 일정 변경 반영 완료'
  };
}


/**
 * PORTAL_STEP08_NAVER_CREATE_ONLY
 * Official NAVER create/modify path.
 * - NAVER official Calendar API uses createSchedule.json for both create and modify.
 * - Existing schedule modify must use the same UID and the same calendarId.
 * - Existing SUCCESS rows never fall back to a new UID create path.
 * - Response returnValue.processType is checked; update expects modify.
 */
function portalCalendarExternalAutoSyncV01PickNaverProviderEventIdStep08_(obj) {
  obj = obj || {};
  var keys = ['naverProviderEventId','naverIcalUid','naverUid','naverEventUid','naverEventId','naverScheduleId','providerEventId','scheduleId','icalUid','uid'];
  for (var i = 0; i < keys.length; i++) {
    var v = String(obj[keys[i]] || '').trim();
    if (!v) continue;
    var extracted = portalCalendarExternalAutoSyncV01ExtractNaverUidFromIcalStep08_(v) || portalCalendarExternalAutoSyncV01ExtractNaverUidFromLooseTextStep08_(v);
    return extracted || v;
  }
  var rawIcal = String(obj.naverIcal || obj.naverIcalInfo || obj.ical || obj.icalText || '');
  return portalCalendarExternalAutoSyncV01ExtractNaverUidFromIcalStep08_(rawIcal) || portalCalendarExternalAutoSyncV01ExtractNaverUidFromLooseTextStep08_(rawIcal);
}

function portalCalendarExternalAutoSyncV01MakeStableNaverUidStep08_(request) {
  request = request || {};
  var existing = portalCalendarExternalAutoSyncV01PickNaverProviderEventIdStep08_(request);
  if (existing) return existing;
  var base = String(request.calendarEventId || request.eventId || request.targetId || '').trim();
  if (!base) base = 'MCAL-' + Utilities.formatDate(new Date(), 'Asia/Seoul', 'yyyyMMddHHmmss') + '-' + Math.floor(Math.random() * 100000);
  base = base.replace(/[^A-Za-z0-9_-]/g, '-');
  return 'FH-' + base + '@feelhaus.portal';
}


function portalCalendarExternalAutoSyncV01HasNaverLinkLossConflictHintStep08_(obj) {
  obj = obj || {};
  var status = String(obj.naverRegisterStatus || obj.naverSyncStatus || '').toUpperCase();
  var code = String(obj.naverErrorCode || obj.lastErrorCode || '').toUpperCase();
  var msg = String(obj.naverErrorMessage || obj.lastErrorMessage || obj.statusReason || '').toLowerCase();
  if (status === 'SUCCESS') return true;
  if (code.indexOf('409') >= 0) return true;
  if (msg.indexOf('409') >= 0) return true;
  if (msg.indexOf('ical uid') >= 0 || msg.indexOf('icaluid') >= 0 || msg.indexOf('resourceconflict') >= 0 || msg.indexOf('conflict resource') >= 0) return true;
  return false;
}

function portalCalendarExternalAutoSyncV01IsNaverUidConflictProviderResultStep08_(providerResult) {
  providerResult = providerResult || {};
  var raw = providerResult.raw || {};
  var text = [providerResult.errorCode || '', providerResult.errorMessage || '', providerResult.message || '', raw.responseBody || '', raw.rawResponse || ''].join(' ').toLowerCase();
  return text.indexOf('409') >= 0 || text.indexOf('ical uid') >= 0 || text.indexOf('resourceconflict') >= 0 || text.indexOf('conflict resource') >= 0;
}

function portalCalendarExternalAutoSyncV01PickNaverCalendarIdStep08_(configBundle, obj, request) {
  // PORTAL_CALENDAR_STEP08_NAVER_CALENDAR_ID_PICKER_V05
  // NAVER 공식 createSchedule modify는 동일 UID + 동일 calendarId가 핵심입니다.
  // 우선순위: row 저장값 -> 요청값 -> iCal [CALENDAR-ID] -> SystemConfig NAVER_UPDATE_CALENDAR_ID.
  // Marker for verifier and maintenance: [CALENDAR-ID]
  obj = obj || {};
  request = request || {};
  var cfg = (configBundle && configBundle.config) || {};
  var directKeys = ['naverCalendarId','naverProviderCalendarId','naverNumericCalendarId','calendarId','providerCalendarId'];
  for (var i = 0; i < directKeys.length; i++) {
    var fromObj = String(obj[directKeys[i]] || '').trim();
    if (fromObj) return fromObj;
    var fromReq = String(request[directKeys[i]] || '').trim();
    if (fromReq) return fromReq;
  }
  var rawIcal = String(obj.naverIcal || obj.naverIcalInfo || obj.ical || obj.icalText || request.naverIcal || request.naverIcalInfo || request.ical || request.icalText || '');
  var fromIcal = portalCalendarExternalAutoSyncV01ExtractNaverCalendarIdFromIcalInfoStep08_(rawIcal);
  if (fromIcal) return fromIcal;
  var legacyProviderText = String(obj.naverProviderEventId || obj.providerEventId || request.naverProviderEventId || request.providerEventId || '');
  var fromLegacyProvider = portalCalendarExternalAutoSyncV01ExtractNaverCalendarIdFromIcalInfoStep08_(legacyProviderText);
  if (fromLegacyProvider) return fromLegacyProvider;
  return String(mcCalendar19PickConfig_(cfg, ['NAVER_UPDATE_CALENDAR_ID','NAVER_PROVIDER_CALENDAR_ID','NAVER_NUMERIC_CALENDAR_ID','NAVER_DEFAULT_CALENDAR_ID']) || '').trim();
}

function portalCalendarExternalAutoSyncV01ExtractNaverUidFromIcalStep08_(icalText) {
  var s = String(icalText || '');
  var m = s.match(/(?:^|\r?\n)UID:([^\r\n]+)/i);
  return m ? String(m[1] || '').trim() : '';
}

function portalCalendarExternalAutoSyncV01ExtractNaverUidFromLooseTextStep08_(text) {
  var s = String(text || '');
  var m = s.match(/(?:icalUid|uid|eventUid)\s*[:=]\s*["']?([^,}\s"']+)/i);
  return m ? String(m[1] || '').trim() : '';
}

function portalCalendarExternalAutoSyncV01ExtractNaverCalendarIdFromIcalInfoStep08_(icalText) {
  var naverCalendarIdIcalMarkerStep08V04 = '[CALENDAR-ID]';
  var s = String(icalText || '');
  var m = s.match(/\[CALENDAR-ID\]\s*:\s*([^\r\n]+)/i);
  if (m) return String(m[1] || '').trim();
  m = s.match(/(?:calendarId|providerCalendarId)\s*[:=]\s*["']?([^,}\s"']+)/i);
  return m ? String(m[1] || '').trim() : '';
}

function portalCalendarExternalAutoSyncV01UpdateNaverCalendarEventStep08_(configBundle, request, startAt, endAt, naverProviderEventId) {
  // PORTAL_STEP08_NAVER_CREATE_ONLY
  // NAVER official minimum diagnostic confirmed same-UID modify returns 409 Ical Uid conflict.
  // Keep this function as a hard guard for legacy callers; do not call NAVER API for modify.
  throw new Error('NAVER modify disabled by PORTAL_STEP08_NAVER_CREATE_ONLY. Use Google for automatic updates or edit NAVER manually.');
}

function portalCalendarExternalAutoSyncV01CreateOrModifyNaverScheduleStep08_(configBundle, request, startAt, endAt, forcedUid, expectModify) {
  if (expectModify === true) {
    throw new Error('NAVER modify disabled by PORTAL_STEP08_NAVER_CREATE_ONLY after official min diag 409 Ical UID conflict.');
  }
  var cfg = (configBundle && configBundle.config) || {};
  if (typeof mcCalendar186FeatureGuard_ === 'function') {
    mcCalendar186FeatureGuard_(cfg, 'FEATURE_NAVER_CALENDAR_ENABLED', '네이버 캘린더');
  }
  var accessToken = String(mcCalendar19PickConfig_(cfg, ['NAVER_CALENDAR_ACCESS_TOKEN','NAVER_ACCESS_TOKEN']) || '').trim();
  if (!accessToken) throw new Error('NAVER_CALENDAR_ACCESS_TOKEN 설정이 필요합니다.');

  var calendarId = portalCalendarExternalAutoSyncV01PickNaverCalendarIdStep08_(configBundle, request, request);
  if (!calendarId) throw new Error('NAVER create/modify requires calendarId. Set NAVER_UPDATE_CALENDAR_ID. Example from iCal [CALENDAR-ID]:2162375');

  var uid = String(forcedUid || '').trim() || portalCalendarExternalAutoSyncV01MakeStableNaverUidStep08_(request);
  if (expectModify && !uid) throw new Error('NAVER modify blocked: UID is empty.');

  var title = String(request.title || request.eventTitle || 'FEELHAUS Calendar');
  var description = portalCalendarExternalAutoSyncV01BusinessDescriptionV05_(request);
  var ical = portalCalendarExternalAutoSyncV01BuildNaverIcalStep08_(uid, title, description, startAt, endAt, request, { expectModify: expectModify });

  var createUrl = String(mcCalendar19PickConfig_(cfg, ['NAVER_CALENDAR_CREATE_URL']) || 'https://openapi.naver.com/calendar/createSchedule.json').trim();
  var payload = { calendarId: calendarId, scheduleIcalString: ical };
  var traceRequest = portalCalendarExternalAutoSyncV01BuildNaverActualPathTraceFinal_(request, {
    mode: expectModify ? 'MODIFY' : 'CREATE',
    createUrl: createUrl,
    calendarId: calendarId,
    uid: uid,
    title: title,
    startAt: startAt,
    endAt: endAt,
    sequence: portalCalendarExternalAutoSyncV01PickNaverSequenceStep08_(request, expectModify),
    scheduleIcalString: ical
  });
  portalCalendarExternalAutoSyncV01LogNaverActualPathTraceFinal_('REQUEST', traceRequest);

  var code = 0;
  var text = '';
  var parsed = {};
  var rv = {};
  var processType = '';
  var returnedUid = '';
  var returnedCalendarId = '';
  var retried = false;
  var usedV07RefreshWrapper = false;

  if (typeof portalCalendarStep08NaverFetchCreateScheduleWithRefreshRetryV07 === 'function') {
    usedV07RefreshWrapper = true;
    var wrapped = portalCalendarStep08NaverFetchCreateScheduleWithRefreshRetryV07(ical, calendarId, traceRequest);
    code = Number(wrapped.responseCode || 0);
    text = String(wrapped.responseBody || '');
    processType = String(wrapped.processType || '').toLowerCase();
    returnedUid = String(wrapped.icalUid || '').trim() || uid;
    returnedCalendarId = String(wrapped.calendarId || '').trim() || calendarId;
    retried = wrapped.retried === true;
    if (!wrapped.ok) {
      portalCalendarExternalAutoSyncV01LogNaverActualPathTraceFinal_('RESPONSE', {
        ok: false,
        usedV07RefreshWrapper: usedV07RefreshWrapper,
        retried: retried,
        httpCode: code,
        responseBody: text,
        processType: processType,
        icalUid: returnedUid,
        calendarId: returnedCalendarId,
        reason: wrapped.reason || '',
        token: wrapped.token || '',
        trace: traceRequest
      });
      throw new Error('NAVER createSchedule create/modify 실패 HTTP ' + code + ': ' + text.substring(0, 800));
    }
  } else {
    var response = UrlFetchApp.fetch(createUrl, {
      method: 'post',
      muteHttpExceptions: true,
      headers: { Authorization: 'Bearer ' + accessToken },
      payload: payload
    });
    code = response.getResponseCode();
    text = response.getContentText() || '';
    if (code < 200 || code >= 300) {
      portalCalendarExternalAutoSyncV01LogNaverActualPathTraceFinal_('RESPONSE', {
        ok: false,
        usedV07RefreshWrapper: usedV07RefreshWrapper,
        retried: retried,
        httpCode: code,
        responseBody: text.substring(0, 2000),
        processType: '',
        icalUid: '',
        calendarId: calendarId,
        trace: traceRequest
      });
      throw new Error('NAVER createSchedule create/modify 실패 HTTP ' + code + ': ' + text.substring(0, 800));
    }
    try { parsed = text ? JSON.parse(text) : {}; } catch (parseErr) { parsed = {}; }
    rv = parsed.returnValue || parsed.result || parsed || {};
    processType = String(rv.processType || parsed.processType || '').toLowerCase();
    returnedUid = String(rv.icalUid || rv.uid || rv.eventUid || '').trim() || uid;
    returnedCalendarId = String(rv.calendarId || parsed.calendarId || '').trim() || calendarId;
  }

  if (!parsed || Object.keys(parsed).length === 0) {
    try { parsed = text ? JSON.parse(text) : {}; } catch (parseErr2) { parsed = {}; }
    rv = parsed.returnValue || parsed.result || parsed || {};
    if (!processType) processType = String(rv.processType || parsed.processType || '').toLowerCase();
    if (!returnedUid) returnedUid = String(rv.icalUid || rv.uid || rv.eventUid || '').trim() || uid;
    if (!returnedCalendarId) returnedCalendarId = String(rv.calendarId || parsed.calendarId || '').trim() || calendarId;
  }

  var naverBodyResult = String(parsed.result || '').toLowerCase();
  var naverBodyCode = Number(parsed.code || 0);
  var naverFailMessage = String(parsed.message || parsed.error || '');
  if (naverBodyResult === 'fail' || naverBodyCode >= 400) {
    portalCalendarExternalAutoSyncV01LogNaverActualPathTraceFinal_('RESPONSE', {
      ok: false,
      usedV07RefreshWrapper: usedV07RefreshWrapper,
      retried: retried,
      httpCode: code,
      responseBody: text.substring(0, 2000),
      bodyResult: naverBodyResult,
      bodyCode: naverBodyCode,
      bodyMessage: naverFailMessage,
      processType: processType,
      icalUid: returnedUid,
      calendarId: returnedCalendarId,
      reason: 'NAVER_BODY_FAIL_OR_CODE_400',
      trace: traceRequest
    });
    throw new Error('NAVER createSchedule 실패 body result/code: result=' + naverBodyResult + ' code=' + naverBodyCode + ' message=' + naverFailMessage + ' response=' + text.substring(0, 800));
  }

  portalCalendarExternalAutoSyncV01LogNaverActualPathTraceFinal_('RESPONSE', {
    ok: true,
    usedV07RefreshWrapper: usedV07RefreshWrapper,
    retried: retried,
    httpCode: code,
    responseBody: text.substring(0, 2000),
    processType: processType,
    icalUid: returnedUid,
    calendarId: returnedCalendarId,
    judgement: {
      displayHint: 'Check NAVER calendarId=' + returnedCalendarId + ', UID=' + returnedUid + ', DTSTART=' + traceRequest.dtStart + ', SUMMARY=' + traceRequest.summary,
      expectedModify: expectModify === true
    },
    trace: traceRequest
  });

  var modifyRepairedByCreate = false;
  if (expectModify && processType && processType !== 'modify') {
    if (processType === 'create' && returnedUid === uid) {
      // NAVER returned create even though PORTAL had a stored UID. This means the external event was missing and was safely re-linked with the same UID.
      // Do not create a new UID. Keep the stable UID and mark the provider link as recovered.
      modifyRepairedByCreate = true;
    } else {
      throw new Error('NAVER modify expected but processType=' + processType + '. Duplicate risk detected. UID=' + uid + ' calendarId=' + calendarId + ' response=' + text.substring(0, 800));
    }
  }

  return {
    provider: 'NAVER',
    eventId: returnedUid,
    providerEventId: returnedUid,
    naverIcalUid: returnedUid,
    naverCalendarId: returnedCalendarId,
    providerCalendarId: returnedCalendarId,
    processType: modifyRepairedByCreate ? 'create_relinked_on_missing_external' : (processType || (expectModify ? 'modify_unconfirmed' : 'create_unconfirmed')),
    message: modifyRepairedByCreate ? 'NAVER 기존 UID 링크 복구 완료(createSchedule create relink)' : (expectModify ? 'NAVER 기존 일정 변경 반영 완료(createSchedule modify)' : 'NAVER 신규 일정 등록 완료(createSchedule)'),
    rawResponse: text.substring(0, 800)
  };
}

function portalCalendarExternalAutoSyncV01BuildNaverIcalStep08_(uid, title, description, startAt, endAt, request, options) {
  var tz = 'Asia/Seoul';
  request = request || {};
  options = options || {};
  var expectModify = options.expectModify === true;
  // PORTAL_STEP08_NAVER_CREATE_ONLY
  // NAVER createSchedule modify succeeded in V05 with the stable UID, same calendarId,
  // UTC Z DTSTAMP/LAST-MODIFIED, no CREATED line, and SEQUENCE left at the stored/raw value.
  // Do not auto-increment SEQUENCE here. NAVER returned 409 Ical Uid conflict with later high runtime sequences.
  var nowUtc = portalCalendarExternalAutoSyncV01FormatUtcZStep08_(new Date());
  var dtStart = Utilities.formatDate(startAt, tz, "yyyyMMdd'T'HHmmss");
  var dtEnd = Utilities.formatDate(endAt, tz, "yyyyMMdd'T'HHmmss");
  var safeTitle = portalCalendarExternalAutoSyncV01EscapeIcalTextStep08_(title);
  var safeDesc = portalCalendarExternalAutoSyncV01EscapeIcalTextStep08_(description);
  var location = portalCalendarExternalAutoSyncV01EscapeIcalTextStep08_(String((request && request.location) || ''));
  var sequence = portalCalendarExternalAutoSyncV01PickNaverSequenceStep08_(request, expectModify);
  var lines = [
    'BEGIN:VCALENDAR',
    'VERSION:2.0',
    'PRODID:Naver Calendar',
    'CALSCALE:GREGORIAN',
    'BEGIN:VTIMEZONE',
    'TZID:Asia/Seoul',
    'BEGIN:STANDARD',
    'DTSTART:19700101T000000',
    'TZNAME:GMT+09:00',
    'TZOFFSETFROM:+0900',
    'TZOFFSETTO:+0900',
    'END:STANDARD',
    'END:VTIMEZONE',
    'BEGIN:VEVENT',
    'SEQUENCE:' + String(sequence),
    'CLASS:PUBLIC',
    'TRANSP:OPAQUE',
    'UID:' + String(uid || '').replace(/[\r\n]/g, ''),
    'DTSTART;TZID=Asia/Seoul:' + dtStart,
    'DTEND;TZID=Asia/Seoul:' + dtEnd,
    'SUMMARY:' + safeTitle,
    'DESCRIPTION:' + safeDesc
  ];
  if (location) lines.push('LOCATION:' + location);
  lines.push('LAST-MODIFIED:' + nowUtc);
  lines.push('DTSTAMP:' + nowUtc);
  lines.push('PRIORITY:0');
  lines.push('END:VEVENT');
  lines.push('END:VCALENDAR');
  return lines.join('\r\n');
}

function portalCalendarExternalAutoSyncV01PickNaverSequenceStep08_(request, expectModify) {
  request = request || {};
  var keys = ['naverSequence','sequence','sequenceNo','nSequence'];
  for (var i = 0; i < keys.length; i++) {
    var raw = request[keys[i]];
    if (raw === '' || raw === null || typeof raw === 'undefined') continue;
    var n = Number(raw);
    if (isFinite(n) && n >= 0) return Math.floor(n);
  }
  var rawIcal = String(request.naverIcal || request.naverIcalInfo || request.ical || request.icalText || '');
  var m = rawIcal.match(/(?:^|\r?\n)SEQUENCE:(\d+)/i);
  if (m) {
    var found = Number(m[1]);
    if (isFinite(found) && found >= 0) return Math.floor(found);
  }
  // V05 compatibility: create and modify both default to zero when no existing sequence is stored.
  return 0;
}

function portalCalendarExternalAutoSyncV01RuntimeSequenceStep08_() {
  // Kept only for old verifier compatibility. Active NAVER V05 compatibility path does not call this.
  return Math.max(1, Math.floor(Date.now() / 1000));
}

function portalCalendarExternalAutoSyncV01FormatUtcZStep08_(date) {
  var d = date instanceof Date && !isNaN(date.getTime()) ? date : new Date();
  return Utilities.formatDate(d, 'UTC', "yyyyMMdd'T'HHmmss'Z'");
}

function portalCalendarExternalAutoSyncV01EscapeIcalTextStep08_(text) {
  return String(text || '')
    .replace(/\\/g, '\\\\')
    .replace(/\r?\n/g, '\\n')
    .replace(/,/g, '\\,')
    .replace(/;/g, '\\;');
}


/**
 * PORTAL_STEP08_NAVER_CREATE_ONLY
 * Real save-path NAVER request/response trace directly embedded in PORTAL_CalendarExternalAutoSyncV01.js.
 */
function portalCalendarExternalAutoSyncV01BuildNaverActualPathTraceFinal_(request, ctx) {
  ctx = ctx || {};
  var tz = 'Asia/Seoul';
  var startAt = ctx.startAt instanceof Date ? ctx.startAt : portalCalendarExternalAutoSyncV01Date_(ctx.startAt);
  var endAt = ctx.endAt instanceof Date ? ctx.endAt : portalCalendarExternalAutoSyncV01Date_(ctx.endAt);
  return {
    build: 'PORTAL_STEP08_NAVER_CREATE_ONLY',
    forceReplace: 'FINAL_NAVER_CREATE_ONLY_NO_MODIFY_409_SAFE',
    marker: 'NAVER_CREATE_ONLY',
    calendarEventId: String((request && (request.calendarEventId || request.eventId || request.targetId)) || ''),
    mode: String(ctx.mode || ''),
    createUrl: String(ctx.createUrl || ''),
    calendarId: String(ctx.calendarId || ''),
    uid: String(ctx.uid || ''),
    summary: String(ctx.title || ''),
    dtStart: startAt ? Utilities.formatDate(startAt, tz, "yyyy-MM-dd HH:mm:ss") : '',
    dtEnd: endAt ? Utilities.formatDate(endAt, tz, "yyyy-MM-dd HH:mm:ss") : '',
    sequence: String(ctx.sequence || ''),
    scheduleIcalString: String(ctx.scheduleIcalString || '').substring(0, 5000)
  };
}

function portalCalendarExternalAutoSyncV01LogNaverActualPathTraceFinal_(phase, payload) {
  try {
    Logger.log('[NAVER_CREATE_ONLY][' + String(phase || '').toUpperCase() + '] ' + JSON.stringify(payload || {}));
  } catch (err) {
    try { Logger.log('[NAVER_CREATE_ONLY][LOG_ERROR] ' + String(err && err.message ? err.message : err)); } catch (ignore) {}
  }
}
