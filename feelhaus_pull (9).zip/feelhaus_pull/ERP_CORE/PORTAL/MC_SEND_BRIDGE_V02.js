/**
 * MC_SEND_BRIDGE_V02_20260526
 * MailCenter 발송 UI 복구용 안전 브릿지.
 * - UI Shell은 건드리지 않고 화면 payload를 기존 발송 코어(mcSendTestCoreV01Send)로 직접 전달한다.
 * - mailAccountId 누락/별칭을 서버에서 한 번 더 보정한다.
 */
var MC_SEND_BRIDGE_V02_BUILD = 'MC_SEND_BRIDGE_V02_20260526';

function mcSendBridgeV02Send(payload) {
  return mcSendBridgeV02Dispatch_('COMPOSE', payload || {});
}

function mcSendBridgeV02Test(payload) {
  return mcSendBridgeV02Dispatch_('TEST', payload || {});
}

function mcSendBridgeV02Dispatch_(mode, payload) {
  var result = {
    ok: false,
    build: MC_SEND_BRIDGE_V02_BUILD,
    mode: mode,
    message: '',
    mailAccountId: '',
    toEmail: '',
    subject: '',
    sendResult: null,
    gmailMessageId: '',
    gmailThreadId: ''
  };
  try {
    if (typeof mcSendTestCoreV01Send !== 'function') {
      throw new Error('mcSendTestCoreV01Send 함수가 없습니다. MailCenter 발송 코어를 확인하세요.');
    }
    var p = payload || {};
    var mailAccountId = String(p.mailAccountId || p.mailAccountID || p.accountId || p.id || '').trim();
    var toEmail = String(p.toEmail || p.to || '').trim();
    var subject = String(p.subject || '').trim();
    var body = String(p.body || p.bodyHtml || p.htmlBody || p.textBody || '').trim();

    if (!mailAccountId) throw new Error('mailAccountId 값이 필요합니다. 발신 계정을 다시 선택하세요.');
    if (!toEmail) throw new Error('수신자 이메일이 필요합니다.');
    if (!subject) throw new Error('제목이 필요합니다.');
    if (!body) throw new Error('본문이 필요합니다.');

    if (p.signatureHtml && body.indexOf(String(p.signatureHtml).substring(0, 24)) < 0) {
      body += '<br><br>' + String(p.signatureHtml);
    }
    if (p.attachments && p.attachments.length) {
      body += mcSendBridgeV02AttachmentHtml_(p.attachments);
    }

    var sendPayload = {
      mailAccountId: mailAccountId,
      toEmail: toEmail,
      ccEmail: String(p.ccEmail || '').trim(),
      bccEmail: String(p.bccEmail || '').trim(),
      subject: subject,
      body: body,
      folderId: String(p.folderId || '').trim(),
      signatureId: String(p.signatureId || '').trim()
    };

    result.mailAccountId = mailAccountId;
    result.toEmail = toEmail;
    result.subject = subject;

    var sent = mcSendTestCoreV01Send('', sendPayload);
    result.sendResult = sent;
    if (!sent || !sent.ok) {
      throw new Error((sent && sent.message) ? sent.message : 'Gmail 발송 실패');
    }
    result.ok = true;
    result.message = sent.message || '메일 발송 완료';
    result.gmailMessageId = sent.gmailMessageId || (sent.sendResult && sent.sendResult.gmailMessageId) || '';
    result.gmailThreadId = sent.gmailThreadId || (sent.sendResult && sent.sendResult.gmailThreadId) || '';
    return result;
  } catch (err) {
    result.ok = false;
    result.message = String(err && err.message ? err.message : err);
    return result;
  }
}

function mcSendBridgeV02AttachmentHtml_(items) {
  var list = [];
  (items || []).forEach(function(a) {
    if (!a) return;
    var url = String(a.driveUrl || a.url || '').trim();
    var name = String(a.fileName || a.name || '첨부자료');
    if (url) list.push('<li><a href="' + mcSendBridgeV02Esc_(url) + '">' + mcSendBridgeV02Esc_(name) + '</a></li>');
  });
  return list.length ? '<br><br><p><strong>첨부/Drive 링크</strong></p><ul>' + list.join('') + '</ul>' : '';
}

function mcSendBridgeV02Esc_(v) {
  return String(v == null ? '' : v)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#039;');
}

function mcSend2Test() {
  var result = { ok: true, build: MC_SEND_BRIDGE_V02_BUILD, results: [] };
  function chk(name, ok, msg){ result.results.push({name:name, ok:!!ok, message:msg||''}); if(!ok) result.ok=false; }
  chk('bridge send exists', typeof mcSendBridgeV02Send === 'function');
  chk('bridge test exists', typeof mcSendBridgeV02Test === 'function');
  chk('core exists', typeof mcSendTestCoreV01Send === 'function');
  ['MC_DashboardViewV04','MC_ComposeViewV01','MC_DashboardSendViewV05'].forEach(function(name){
    var html = HtmlService.createTemplateFromFile(name).getRawContent();
    chk('load '+name, !!html && html.length > 1000, 'html load');
    chk('bridge call '+name, html.indexOf('mcSendBridgeV02') >= 0, 'client uses bridge');
    chk('mailAccountId payload '+name, html.indexOf('mailAccountId') >= 0, 'mailAccountId included');
    chk('no document.write '+name, html.indexOf('document.write') < 0, 'no document.write');
  });
  result.summary = { total: result.results.length, pass: result.results.filter(function(r){return r.ok;}).length, fail: result.results.filter(function(r){return !r.ok;}).length };
  Logger.log(JSON.stringify(result));
  return result;
}

function mcSend2Fail() {
  var r = mcSend2Test();
  return { ok: r.ok, build: 'MC_SEND2_FAIL', failedResults: (r.results||[]).filter(function(x){return !x.ok;}), summary: r.summary };
}
