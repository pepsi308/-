/* Build: PORTAL_187_CALENDAR_LOGINID_CLEAN_JS_REPLACE_20260518
 * File: Portal_Calendar.js
 * Rule: JS-only clean replace. No Google email matching. Actor identity uses PORTAL loginId / employeeId / sid.
 * Keep SystemConfig auto-read, FEELHAUS_DB_MASTER, header-map access, provider logs, retry queue, NAVER primary, GOOGLE_BACKUP fallback.
 */

function portal186ResolveCalendarActor_(request, configBundle, options) {
  request = request || {};
  options = options || {};
  var sid = String(request.sid || request.portalSid || request.sessionId || '').trim();
  if (sid && typeof portal103ValidateSession_ === 'function') {
    var valid = portal103ValidateSession_(sid);
    if (valid && valid.ok && valid.user) return portal186NormalizePortalActor_(valid.user, 'sid');
    if (options.requireSid) throw new Error(valid && valid.message ? valid.message : 'PORTAL 세션 확인에 실패했습니다.');
  }

  var loginId = String(request.loginId || request.createdBy || '').trim();
  var employeeId = String(request.employeeId || request.ownerEmployeeId || '').trim();
  if (loginId && typeof portal91LoadProfileByLoginId_ === 'function') {
    var byLogin = portal91LoadProfileByLoginId_(loginId);
    if (byLogin && byLogin.ok && byLogin.user) return portal186NormalizePortalActor_(byLogin.user, 'loginId');
  }

  var users = portal186ReadPortalUsersForCalendar_(configBundle);
  var found = null;
  for (var i = 0; i < users.length; i++) {
    if (loginId && String(users[i].loginId || '').toLowerCase() === loginId.toLowerCase()) { found = users[i]; break; }
  }
  if (!found && employeeId) {
    for (var j = 0; j < users.length; j++) {
      if (String(users[j].employeeId || '').toLowerCase() === employeeId.toLowerCase()) { found = users[j]; break; }
    }
  }
  if (!found && options.allowFallback) found = portal186PickCalendarFallbackUser_(users);
  if (!found) throw new Error('PORTAL 로그인 사용자 정보를 찾지 못했습니다. sid 또는 loginId/employeeId를 전달해 주세요.');
  return portal186NormalizePortalActor_(found, found._source || 'PortalUsers');
}

function portal186ReadPortalUsersForCalendar_(configBundle) {
  var ss = portal19OpenMaster_(configBundle || portal19GetConfigBundle_());
  var sheet = ss.getSheetByName('PortalUsers') || ss.getSheetByName('PORTAL_Users');
  if (!sheet) throw new Error('PortalUsers 시트를 찾지 못했습니다.');
  var values = sheet.getDataRange().getValues();
  if (!values || values.length < 1) throw new Error('PortalUsers 데이터가 비어 있습니다.');
  var headerRowIndex = portal186DetectCalendarUserHeaderRow_(values);
  if (headerRowIndex < 0) throw new Error('PortalUsers 헤더를 찾지 못했습니다.');
  var hm = portal19HeaderMap_(values[headerRowIndex]);
  var required = ['loginId', 'employeeId', 'roleCode', 'status'];
  var missing = [];
  for (var m = 0; m < required.length; m++) if (!hm.hasOwnProperty(required[m])) missing.push(required[m]);
  if (missing.length) throw new Error('PortalUsers 필수 헤더 누락: ' + missing.join(', '));
  var rows = [];
  for (var r = headerRowIndex + 1; r < values.length; r++) {
    var line = values[r] || [];
    var loginId = String(line[hm.loginId] || '').trim();
    var employeeId = String(line[hm.employeeId] || '').trim();
    if (!loginId && !employeeId) continue;
    rows.push({
      userId: hm.hasOwnProperty('userId') ? String(line[hm.userId] || '').trim() : '',
      loginId: loginId,
      employeeId: employeeId,
      employeeName: hm.hasOwnProperty('employeeName') ? String(line[hm.employeeName] || '').trim() : '',
      roleCode: hm.hasOwnProperty('roleCode') ? String(line[hm.roleCode] || '').trim() : '',
      vendorId: hm.hasOwnProperty('vendorId') ? String(line[hm.vendorId] || '').trim() : '',
      isActive: hm.hasOwnProperty('isActive') ? String(line[hm.isActive] || '').trim() : '',
      status: hm.hasOwnProperty('status') ? String(line[hm.status] || '').trim() : '',
      _source: 'PortalUsers'
    });
  }
  return rows;
}

function portal186DetectCalendarUserHeaderRow_(values) {
  for (var r = 0; r < Math.min(values.length, 10); r++) {
    var hm = portal19HeaderMap_(values[r] || []);
    if (hm.hasOwnProperty('loginId') && hm.hasOwnProperty('employeeId')) return r;
  }
  return -1;
}

function portal186PickCalendarFallbackUser_(users) {
  users = users || [];
  var preferred = ['pepsi308', 'admin'];
  for (var p = 0; p < preferred.length; p++) {
    for (var i = 0; i < users.length; i++) {
      if (portal186IsActiveCalendarUser_(users[i]) && String(users[i].loginId || '').toLowerCase() === preferred[p]) return users[i];
    }
  }
  var roles = { 'SUPER_ADMIN': true, 'HQ_ADMIN': true, 'DEV': true };
  for (var j = 0; j < users.length; j++) if (portal186IsActiveCalendarUser_(users[j]) && roles[String(users[j].roleCode || '').toUpperCase()]) return users[j];
  for (var k = 0; k < users.length; k++) if (portal186IsActiveCalendarUser_(users[k])) return users[k];
  return users.length ? users[0] : null;
}

function portal186IsActiveCalendarUser_(user) {
  var status = String(user && user.status || '').toUpperCase();
  var active = String(user && user.isActive || '').toUpperCase();
  if (status && status !== 'ACTIVE') return false;
  if (active && active !== 'TRUE' && active !== 'Y' && active !== '1') return false;
  return true;
}

function portal186NormalizePortalActor_(user, source) {
  user = user || {};
  var roleCode = String(user.roleCode || '').trim();
  var loginId = String(user.loginId || user.createdBy || '').trim();
  var employeeId = String(user.employeeId || '').trim();
  var permissions = portal186BuildCalendarPermissions_(roleCode);
  return {
    ok: true,
    source: source || '',
    userId: String(user.userId || '').trim(),
    loginId: loginId,
    email: loginId,
    employeeId: employeeId,
    employeeName: String(user.employeeName || '').trim(),
    roleCode: roleCode,
    vendorId: String(user.vendorId || '').trim(),
    permissions: permissions
  };
}

function portal186BuildCalendarPermissions_(roleCode) {
  var role = String(roleCode || '').toUpperCase();
  var map = {};
  if (role === 'SUPER_ADMIN' || role === 'HQ_ADMIN' || role === 'DEV') {
    map.ALL = true;
    map.DEV_CONSOLE = true;
    map.CALENDAR_CREATE = true;
    map.CALENDAR_RETRY = true;
    map.CALENDAR_VIEW = true;
    return map;
  }
  if (role === 'STAFF' || role === 'OPERATION' || role === 'VENDOR') {
    map.CALENDAR_CREATE = true;
    map.CALENDAR_VIEW = true;
    if (role === 'OPERATION') map.CALENDAR_RETRY = true;
    return map;
  }
  map.CALENDAR_VIEW = true;
  return map;
}

function portal186HasPermission_(profile, permissionKey) {
  if (!profile || !profile.permissions) return false;
  return !!(profile.permissions.ALL || profile.permissions[permissionKey]);
}

function portal186PermissionGuard_(profile, permissionKey) {
  if (!portal186HasPermission_(profile, permissionKey)) throw new Error('권한이 없습니다: ' + permissionKey + ' / roleCode=' + String(profile && profile.roleCode || ''));
}

function portal186ActorKey_(profile) {
  return String(profile && (profile.loginId || profile.employeeId || profile.userId) || 'SYSTEM_CALENDAR');
}

function portal186SafeActorSummary_(profile) {
  return {
    source: String(profile && profile.source || ''),
    loginId: String(profile && profile.loginId || ''),
    employeeId: String(profile && profile.employeeId || ''),
    employeeName: String(profile && profile.employeeName || ''),
    roleCode: String(profile && profile.roleCode || ''),
    vendorId: String(profile && profile.vendorId || '')
  };
}

function portal19CreateCalendarEvent(request) {
  var result = portal19SafeResult_('portal19CreateCalendarEvent');
  request = request || {};
  var actorKey = '';
  var config = null;
  var profile = null;
  var eventRecord = null;
  var providerResults = [];
  try {
    config = portal19GetConfigBundle_();
    profile = portal186ResolveCalendarActor_(request, config, { allowFallback: true });
    actorKey = portal186ActorKey_(profile);
    portal186PermissionGuard_(profile, 'CALENDAR_CREATE');
    portal186FeatureGuard_(config.config || {}, 'FEATURE_CALENDAR_ENABLED', '캘린더 기능');

    var normalized = portal186NormalizeCalendarRequest_(request, profile);
    portal186ValidateCalendarRequest_(normalized);
    var ss = portal19OpenMaster_(config);
    portal186EnsureCalendarModuleSheets_(ss);
    portal186AssertNoDuplicateCalendarEvent_(ss, normalized);

    eventRecord = portal186BuildCalendarEventRecord_(normalized, profile);
    portal186AppendCalendarEvent_(ss, eventRecord);
    portal186AppendProviderLog_(ss, eventRecord, 'INTERNAL', 'CREATE_EVENT', 'SUCCESS', '', '', '', 'PORTAL_CalendarEvents 내부 저장 완료', profile);

    var naverResult = portal186TryProviderCreate_(function(){
      return portal19CreateNaverCalendarEvent_(config, normalized, normalized._startDate, normalized._endDate);
    }, 'NAVER');
    providerResults.push(naverResult);
    portal186ApplyProviderResult_(ss, eventRecord.calendarEventId, 'NAVER', naverResult, profile);

    var googleResult = portal186TryProviderCreate_(function(){
      return portal19CreateGoogleCalendarEvent_(config, normalized, normalized._startDate, normalized._endDate, naverResult.ok ? null : new Error(naverResult.errorMessage));
    }, 'GOOGLE_BACKUP');
    providerResults.push(googleResult);
    portal186ApplyProviderResult_(ss, eventRecord.calendarEventId, 'GOOGLE_BACKUP', googleResult, profile);

    var overallStatus = portal186BuildOverallCalendarStatus_(providerResults);
    portal186FinalizeCalendarEventStatus_(ss, eventRecord.calendarEventId, overallStatus, profile);
    normalized.calendarProvider = 'INTERNAL,NAVER,GOOGLE_BACKUP';
    normalized.fallbackProvider = 'GOOGLE_BACKUP';
    normalized.calendarEventId = eventRecord.calendarEventId;
    normalized.result = overallStatus.result;
    normalized.statusReason = overallStatus.message;
    normalized.naverStatusReason = naverResult.ok ? '' : naverResult.errorMessage;
    portal19AppendCalendarLog_(profile, normalized);

    portal19AppendAuditLog_('CREATE_CALENDAR_EVENT', actorKey, eventRecord.calendarEventId, overallStatus.result, overallStatus.message, {
      calendarEventId: eventRecord.calendarEventId,
      eventTitle: normalized.eventTitle,
      eventId: normalized.eventId,
      customerId: normalized.customerId,
      contractId: normalized.contractId,
      installId: normalized.installId,
      asId: normalized.asId,
      requestId: normalized.requestId,
      providerResults: providerResults,
      actorLoginId: profile.loginId,
      actorEmployeeId: profile.employeeId,
      roleCode: profile.roleCode
    });

    result.ok = true;
    result.calendarEventId = eventRecord.calendarEventId;
    result.eventStatus = overallStatus.result === 'SUCCESS' ? 'REGISTERED' : 'PARTIAL';
    result.createdBy = actorKey;
    result.createdByEmployeeId = profile.employeeId;
    result.ownerEmployeeId = eventRecord.ownerEmployeeId;
    result.assignedEmployeeId = eventRecord.assignedEmployeeId;
    result.providerResults = providerResults;
    result.message = overallStatus.message;
  } catch (err) {
    result.ok = false;
    result.message = portal19ErrorMessage_(err);
    try {
      if (!config) config = portal19GetConfigBundle_();
      if (!profile) profile = portal186ResolveCalendarActor_(request, config, { allowFallback: true });
      actorKey = portal186ActorKey_(profile);
      request.result = 'FAIL';
      request.statusReason = result.message;
      request.calendarProvider = request.calendarProvider || 'INTERNAL,NAVER,GOOGLE_BACKUP';
      request.fallbackProvider = request.fallbackProvider || 'GOOGLE_BACKUP';
      portal19AppendCalendarLog_(profile, request);
      portal19AppendAuditLog_('CREATE_CALENDAR_EVENT', actorKey, eventRecord ? eventRecord.calendarEventId : '', 'FAIL', result.message, {
        title: request.eventTitle || request.title || '',
        actorLoginId: profile.loginId,
        actorEmployeeId: profile.employeeId,
        stage: eventRecord ? 'provider_or_log' : 'validation_or_internal_save'
      });
    } catch (ignore) {}
  }
  return portal19ClientSafeObject_(result);
}

function portal19CreateNaverCalendarEvent_(configBundle, request, startAt, endAt) {
  var cfg = configBundle.config || {};
  portal186FeatureGuard_(cfg, 'FEATURE_NAVER_CALENDAR_ENABLED', '네이버 캘린더');
  var freshToken = portal25EnsureFreshNaverAccessToken_(cfg, 'NAVER_CALENDAR_CREATE');
  if (freshToken.refreshed) {
    configBundle = portal19GetConfigBundle_();
    cfg = configBundle.config || {};
  }
  var settingCheck = portal21BuildNaverSettingCheck_(cfg);
  if (!settingCheck.ready) throw new Error('NAVER 캘린더 설정 미완료: ' + settingCheck.missingKeys.join(', '));

  var token = freshToken.accessToken || portal19PickConfig_(cfg, [
    'NAVER_CALENDAR_ACCESS_TOKEN',
    'NAVER_ACCESS_TOKEN',
    'NAVER_CALENDAR_TOKEN'
  ]);
  if (!token) throw new Error('NAVER 캘린더 토큰이 SystemConfig에 없습니다.');

  // 로그로 성공 확인된 PORTAL 31/35 방식: NAVER_CALENDAR_ID를 읽거나 보내지 않고 literal defaultCalendarId 사용.
  var calendarId = 'defaultCalendarId';
  var timezone = Session.getScriptTimeZone() || 'Asia/Seoul';
  var description = String(request.description || 'FEELHAUS PORTAL NAVER 실제등록');
  var endpoint = portal19PickConfig_(cfg, [
    'NAVER_CALENDAR_CREATE_URL',
    'NAVER_CALENDAR_API_URL'
  ]) || 'https://openapi.naver.com/calendar/createSchedule.json';
  var payload = {
    calendarId: calendarId,
    title: String(request.title || ''),
    description: description,
    start: Utilities.formatDate(startAt, timezone, "yyyy-MM-dd'T'HH:mm:ssXXX"),
    end: Utilities.formatDate(endAt, timezone, "yyyy-MM-dd'T'HH:mm:ssXXX"),
    targetType: request.targetType || '',
    targetId: request.targetId || ''
  };
  var ical = portal19BuildNaverIcal_(payload);
  var encodedBody = portal26BuildNaverFormBody_({
    calendarId: calendarId,
    scheduleIcalString: ical
  });
  var requestOptions = portal27BuildNaverCreateRequestOptions_(token, encodedBody);
  var response = UrlFetchApp.fetch(endpoint, requestOptions);
  var code = response.getResponseCode();
  var body = response.getContentText() || '';
  var authRetry = false;
  var retryTokenExpiresAt = freshToken.expiresAt || '';
  var retryMessage = '';

  if (code === 401 && portal27CanRefreshNaverToken_(cfg)) {
    try {
      var refreshed = portal25RefreshNaverAccessToken_(cfg, 'NAVER_CALENDAR_401_RETRY');
      authRetry = true;
      token = refreshed.accessToken;
      retryTokenExpiresAt = refreshed.expiresAt || '';
      requestOptions = portal27BuildNaverCreateRequestOptions_(token, encodedBody);
      response = UrlFetchApp.fetch(endpoint, requestOptions);
      code = response.getResponseCode();
      body = response.getContentText() || '';
      retryMessage = refreshed.message || 'NAVER access token 401 후 강제 갱신';
    } catch (refreshErr) {
      retryMessage = '401 후 token 갱신 실패: ' + portal19ErrorMessage_(refreshErr);
    }
  }

  if (code < 200 || code >= 300) {
    var debug = {
      endpoint: endpoint,
      calendarId: calendarId,
      calendarIdSource: 'fixed_defaultCalendarId',
      naverCalendarIdIgnored: true,
      authorizationScheme: 'Bearer',
      hasClientIdHeader: false,
      hasClientSecretHeader: false,
      contentType: requestOptions.contentType,
      payloadMode: 'raw_urlencoded_string',
      payloadKeys: ['calendarId', 'scheduleIcalString'],
      scheduleIcalLength: ical.length,
      encodedBodyLength: encodedBody.length,
      bodyPreview: portal26SafeBodyPreview_(encodedBody),
      tokenRefreshed: !!freshToken.refreshed,
      authRetryAfter401: authRetry,
      retryMessage: retryMessage,
      tokenExpiresAt: retryTokenExpiresAt || freshToken.expiresAt || ''
    };
    throw new Error('NAVER 캘린더 등록 실패: HTTP ' + code + ' ' + body.substring(0, 300) + ' / DEBUG=' + JSON.stringify(debug));
  }

  var parsedBody = null;
  var eventId = '';
  try {
    parsedBody = JSON.parse(body);
  } catch (ignore) {
    parsedBody = null;
  }

  var naverResult = parsedBody && parsedBody.result !== undefined ? String(parsedBody.result || '') : '';
  var naverMessage = parsedBody && parsedBody.message !== undefined ? String(parsedBody.message || '') : '';
  var naverErrorCode = parsedBody && parsedBody.errorCode !== undefined ? String(parsedBody.errorCode || '') : '';
  var naverErrorMessage = parsedBody && parsedBody.errorMessage !== undefined ? String(parsedBody.errorMessage || '') : '';
  var lowerBody = String(body || '').toLowerCase();
  var lowerResult = naverResult.toLowerCase();

  // PORTAL 35에서 정정한 기준: HTTP 200이어도 result=fail/errorMessage이면 실패로 처리.
  if (naverErrorCode || naverErrorMessage || lowerResult === 'fail' || lowerBody === 'fail') {
    var failDebug = {
      endpoint: endpoint,
      calendarId: calendarId,
      calendarIdSource: 'fixed_defaultCalendarId',
      naverCalendarIdIgnored: true,
      httpCode: code,
      naverResult: naverResult,
      naverMessage: naverMessage,
      naverErrorCode: naverErrorCode,
      naverErrorMessage: naverErrorMessage,
      bodyPreview: portal26SafeBodyPreview_(body),
      tokenRefreshed: !!freshToken.refreshed,
      authRetryAfter401: authRetry,
      retryMessage: retryMessage,
      tokenExpiresAt: retryTokenExpiresAt || freshToken.expiresAt || ''
    };
    throw new Error('NAVER 캘린더 등록 실패: HTTP ' + code + ' response=' + body.substring(0, 300) + ' / DEBUG=' + JSON.stringify(failDebug));
  }

  if (parsedBody) {
    var nested = parsedBody && typeof parsedBody.result === 'object' ? parsedBody.result : {};
    eventId = parsedBody.id || parsedBody.scheduleId || parsedBody.uid || parsedBody.eventId || parsedBody.calendarEventId || parsedBody.returnValue ||
      nested.id || nested.scheduleId || nested.uid || nested.eventId || nested.calendarEventId || nested.returnValue || '';
    // NAVER 일반 캘린더 API는 result=success만 반환할 수 있음. PORTAL 35 성공 로그 기준으로 성공 placeholder 허용.
    if (!eventId && lowerResult === 'success') eventId = 'NAVER_CALENDAR_EVENT_SUCCESS';
    if (!eventId && naverMessage && naverMessage.toLowerCase() !== 'fail') eventId = naverMessage;
  } else if (body) {
    eventId = 'NAVER_CALENDAR_EVENT';
  }

  if (String(eventId || '').toLowerCase() === 'fail') {
    throw new Error('NAVER 캘린더 등록 실패: HTTP ' + code + ' response=' + body.substring(0, 300));
  }

  return {
    provider: 'NAVER',
    eventId: eventId || 'NAVER_CALENDAR_EVENT',
    providerResponseCode: code,
    providerBodyStatus: String(naverResult || naverMessage || ''),
    message: authRetry ? 'NAVER access token 401 후 강제 갱신 등록 완료' : 'NAVER 기본 캘린더(defaultCalendarId) 등록 완료',
    calendarId: calendarId,
    tokenRefreshed: !!freshToken.refreshed || authRetry,
    tokenExpiresAt: retryTokenExpiresAt || freshToken.expiresAt || ''
  };
}

function portal27BuildNaverCreateRequestOptions_(token, encodedBody) {
  return {
    method: 'post',
    muteHttpExceptions: true,
    contentType: 'application/x-www-form-urlencoded',
    headers: {
      Authorization: 'Bearer ' + token
    },
    payload: encodedBody
  };
}

function portal27CanRefreshNaverToken_(cfg) {
  return !!portal19PickConfig_(cfg, ['NAVER_REFRESH_TOKEN', 'NAVER_CALENDAR_REFRESH_TOKEN'])
    && !!portal19PickConfig_(cfg, ['NAVER_CLIENT_ID', 'NAVER_CALENDAR_CLIENT_ID'])
    && !!portal19PickConfig_(cfg, ['NAVER_CLIENT_SECRET', 'NAVER_CALENDAR_CLIENT_SECRET']);
}

function portal19CreateGoogleCalendarEvent_(configBundle, request, startAt, endAt, naverErr) {
  var cfg = configBundle.config || {};
  portal186FeatureGuard_(cfg, 'FEATURE_GOOGLE_CALENDAR_BACKUP_ENABLED', '구글 캘린더 백업');
  var googleCalendarId = portal19PickConfig_(cfg, ['GOOGLE_CALENDAR_ID']);
  var cal = googleCalendarId ? CalendarApp.getCalendarById(String(googleCalendarId)) : CalendarApp.getDefaultCalendar();
  if (!cal) throw new Error('GOOGLE_CALENDAR_ID 캘린더를 찾을 수 없습니다.');
  var description = String(request.eventDescription || request.description || 'FEELHAUS PORTAL 캘린더 백업 등록');
  if (naverErr) description += '\nNAVER 기본 캘린더 실패 후 GOOGLE 보조 캘린더로 등록: ' + portal19ErrorMessage_(naverErr);
  var event = cal.createEvent(String(request.title || ''), startAt, endAt, { description: description });
  return {
    provider: 'GOOGLE_BACKUP',
    eventId: event.getId(),
    message: naverErr ? 'NAVER 실패 후 GOOGLE 보조 백업 등록 완료' : 'GOOGLE 보조 백업 등록 완료'
  };
}


function portal26BuildNaverFormBody_(params) {
  var parts = [];
  var keys = Object.keys(params || {});
  for (var i = 0; i < keys.length; i++) {
    var key = keys[i];
    var value = params[key] == null ? '' : String(params[key]);
    parts.push(encodeURIComponent(key) + '=' + encodeURIComponent(value));
  }
  return parts.join('&');
}

function portal26SafeBodyPreview_(body) {
  body = String(body || '');
  if (!body) return '';
  var preview = body.substring(0, 160);
  preview = preview.replace(/scheduleIcalString=[^&]*/g, 'scheduleIcalString=[ICAL_ENCODED_OMITTED]');
  return preview;
}

function portal19BuildNaverIcal_(payload) {
  var uid = Utilities.getUuid() + '@feelhaus.portal35';
  function esc(v) {
    return String(v || '').replace(/\\/g, '\\\\').replace(/;/g, '\\;').replace(/,/g, '\\,').replace(/\n/g, '\\n');
  }
  function dtLocal(v) {
    var d = v instanceof Date ? v : new Date(v);
    if (!d || isNaN(d.getTime())) d = new Date();
    return Utilities.formatDate(d, 'Asia/Seoul', "yyyyMMdd'T'HHmmss");
  }
  function dtUtc(v) {
    var d = v instanceof Date ? v : new Date(v);
    if (!d || isNaN(d.getTime())) d = new Date();
    return Utilities.formatDate(d, 'UTC', "yyyyMMdd'T'HHmmss'Z'");
  }
  var now = new Date();
  return [
    'BEGIN:VCALENDAR',
    'VERSION:2.0',
    'PRODID:-//FEELHAUS//PORTAL35//KO',
    'CALSCALE:GREGORIAN',
    'BEGIN:VTIMEZONE',
    'TZID:Asia/Seoul',
    'X-LIC-LOCATION:Asia/Seoul',
    'BEGIN:STANDARD',
    'TZOFFSETFROM:+0900',
    'TZOFFSETTO:+0900',
    'TZNAME:KST',
    'DTSTART:19700101T000000',
    'END:STANDARD',
    'END:VTIMEZONE',
    'BEGIN:VEVENT',
    'SEQUENCE:0',
    'CLASS:PUBLIC',
    'TRANSP:OPAQUE',
    'UID:' + uid,
    'SUMMARY:' + esc(payload.title),
    'DESCRIPTION:' + esc(payload.description + '\n' + payload.targetType + ':' + payload.targetId),
    'DTSTART;TZID=Asia/Seoul:' + dtLocal(payload.start),
    'DTEND;TZID=Asia/Seoul:' + dtLocal(payload.end),
    'CREATED:' + dtUtc(now),
    'DTSTAMP:' + dtUtc(now),
    'LAST-MODIFIED:' + dtUtc(now),
    'PRIORITY:0',
    'END:VEVENT',
    'END:VCALENDAR'
  ].join('\r\n');
}

function portal19FormatCalendarDateTime_(dateObj) {
  return Utilities.formatDate(dateObj, Session.getScriptTimeZone() || 'Asia/Seoul', 'yyyy-MM-dd HH:mm');
}

function portal19CreateSelfTestCalendarEvent() {
  var start = new Date(new Date().getTime() + 30 * 60000);
  var end = new Date(start.getTime() + 30 * 60000);
  return portal19CreateCalendarEvent({
    targetType: 'SELF_TEST',
    targetId: 'PORTAL19_CALENDAR_TEST',
    title: 'FEELHAUS PORTAL 19 테스트 일정',
    startAt: start.toISOString(),
    endAt: end.toISOString()
  });
}


function portal21CheckNaverCalendarSettings(request) {
  var result = portal19SafeResult_('portal21CheckNaverCalendarSettings');
  request = request || {};
  try {
    var config = portal19GetConfigBundle_();
    var profile = portal186ResolveCalendarActor_(request, config, { allowFallback: true });
    var actorKey = portal186ActorKey_(profile);
    portal186PermissionGuard_(profile, 'CALENDAR_CREATE');
    var check = portal21BuildNaverSettingCheck_(config.config || {});
    result.ok = true;
    result.ready = check.ready;
    result.provider = 'NAVER_PRIMARY';
    result.fallbackProvider = 'GOOGLE_BACKUP';
    result.actor = portal186SafeActorSummary_(profile);
    result.message = check.ready ? 'NAVER 캘린더 설정 준비 완료' : 'NAVER 캘린더 설정 미완료: ' + check.missingKeys.join(', ');
    result.check = check;
    portal19AppendAuditLog_('NAVER_CALENDAR_SETTING_CHECK', actorKey, '', check.ready ? 'SUCCESS' : 'FAIL', result.message, check.safeSummary);
  } catch (err) {
    result.ok = false;
    result.ready = false;
    result.message = portal19ErrorMessage_(err);
  }
  return portal19ClientSafeObject_(result);
}

function portal21BuildNaverSettingCheck_(cfg) {
  var requiredAny = [
    { name: 'NAVER access token', keys: ['NAVER_CALENDAR_ACCESS_TOKEN', 'NAVER_ACCESS_TOKEN', 'NAVER_CALENDAR_TOKEN'] }
  ];
  var optional = [
    { name: 'NAVER_CALENDAR_ENABLED', keys: ['NAVER_CALENDAR_ENABLED'] },
    { name: 'NAVER_CLIENT_ID', keys: ['NAVER_CLIENT_ID', 'NAVER_CALENDAR_CLIENT_ID'] },
    { name: 'NAVER_CLIENT_SECRET', keys: ['NAVER_CLIENT_SECRET', 'NAVER_CALENDAR_CLIENT_SECRET'] },
    { name: 'NAVER_REFRESH_TOKEN', keys: ['NAVER_REFRESH_TOKEN', 'NAVER_CALENDAR_REFRESH_TOKEN'] },
    { name: 'NAVER_TOKEN_EXPIRES_AT', keys: ['NAVER_TOKEN_EXPIRES_AT', 'NAVER_CALENDAR_TOKEN_EXPIRES_AT'] },
    { name: 'NAVER_CALENDAR_CREATE_URL', keys: ['NAVER_CALENDAR_CREATE_URL', 'NAVER_CALENDAR_API_URL'] }
  ];
  var missing = [];
  var present = [];
  for (var i = 0; i < requiredAny.length; i++) {
    var value = portal19PickConfig_(cfg, requiredAny[i].keys);
    if (value) present.push(requiredAny[i].name); else missing.push(requiredAny[i].name + ' (' + requiredAny[i].keys.join(' 또는 ') + ')');
  }
  var optionalStatus = [];
  for (var j = 0; j < optional.length; j++) {
    optionalStatus.push({ name: optional[j].name, exists: !!portal19PickConfig_(cfg, optional[j].keys) });
  }
  var enabled = portal19PickConfig_(cfg, ['NAVER_CALENDAR_ENABLED']);
  var disabled = String(enabled || '').toUpperCase() === 'N' || String(enabled || '').toUpperCase() === 'FALSE' || String(enabled || '').toUpperCase() === 'OFF';
  if (disabled) missing.push('NAVER_CALENDAR_ENABLED 값이 OFF/FALSE/N 입니다.');
  return {
    ready: missing.length === 0,
    missingKeys: missing,
    presentRequired: present,
    optionalStatus: optionalStatus,
    safeSummary: {
      ready: missing.length === 0,
      missingCount: missing.length,
      calendarIdRequired: false,
      calendarIdConfigured: false,
      calendarIdMode: 'defaultCalendarId',
      accessTokenConfigured: !!portal19PickConfig_(cfg, ['NAVER_CALENDAR_ACCESS_TOKEN', 'NAVER_ACCESS_TOKEN', 'NAVER_CALENDAR_TOKEN']),
      createUrlConfigured: !!portal19PickConfig_(cfg, ['NAVER_CALENDAR_CREATE_URL', 'NAVER_CALENDAR_API_URL']),
      fallbackProvider: 'GOOGLE_BACKUP'
    }
  };
}


function portal22EnsureNaverSystemConfigRows() {
  var result = portal19SafeResult_('portal22EnsureNaverSystemConfigRows');
  try {
    var cfgBundle = portal19GetConfigBundle_();
    var profile = portal186ResolveCalendarActor_({}, cfgBundle, { allowFallback: true });
    var actorKey = portal186ActorKey_(profile);
    portal186PermissionGuard_(profile, 'DEV_CONSOLE');

    var setup = SpreadsheetApp.openById(PORTAL19_SETUP_DB_ID);
    var sheet = setup.getSheetByName(PORTAL19_CONFIG_SHEET);
    if (!sheet) throw new Error('SystemConfig 시트를 찾을 수 없습니다.');
    var values = sheet.getDataRange().getValues();
    if (!values || values.length < 1) throw new Error('SystemConfig 헤더가 없습니다.');
    var headers = portal19HeaderMap_(values[0]);
    var keyCol = portal19FindHeader_(headers, ['CONFIG_KEY']);
    var valueCol = portal19FindHeader_(headers, ['VALUE']);
    if (keyCol < 0 || valueCol < 0) throw new Error('SystemConfig 필수 헤더(CONFIG_KEY/VALUE)를 찾을 수 없습니다.');

    var existing = {};
    for (var r = 1; r < values.length; r++) {
      var key = String(values[r][keyCol] || '').trim();
      if (key) existing[key] = true;
    }
    var requiredRows = [
      { key: 'NAVER_CALENDAR_ENABLED', value: 'N', category: 'CALENDAR', subCategory: 'NAVER', projectScope: 'PORTAL', description: 'NAVER 기본 캘린더 사용 여부. 실등록 검증 전 Y로 변경', isRequired: 'Y', isSensitive: 'N', status: 'ACTIVE' },
      { key: 'NAVER_CLIENT_ID', value: '', category: 'CALENDAR', subCategory: 'NAVER', projectScope: 'PORTAL', description: 'NAVER Developers Client ID', isRequired: 'Y', isSensitive: 'N', status: 'ACTIVE' },
      { key: 'NAVER_CLIENT_SECRET', value: '', category: 'CALENDAR', subCategory: 'NAVER', projectScope: 'PORTAL', description: 'NAVER Developers Client Secret. 민감값', isRequired: 'Y', isSensitive: 'Y', status: 'ACTIVE' },
      { key: 'NAVER_CALENDAR_ID', value: '', category: 'CALENDAR', subCategory: 'NAVER', projectScope: 'PORTAL', description: '사용중지. 일반 네이버 캘린더 API 기준 필수값 아님. 입력 금지.', isRequired: 'N', isSensitive: 'N', status: 'INACTIVE' },
      { key: 'NAVER_CALENDAR_ACCESS_TOKEN', value: '', category: 'CALENDAR', subCategory: 'NAVER', projectScope: 'PORTAL', description: 'NAVER 캘린더 API access token. 민감값', isRequired: 'Y', isSensitive: 'Y', status: 'ACTIVE' },
      { key: 'NAVER_REFRESH_TOKEN', value: '', category: 'CALENDAR', subCategory: 'NAVER', projectScope: 'PORTAL', description: 'NAVER refresh token. 민감값', isRequired: 'N', isSensitive: 'Y', status: 'ACTIVE' },
      { key: 'NAVER_TOKEN_EXPIRES_AT', value: '', category: 'CALENDAR', subCategory: 'NAVER', projectScope: 'PORTAL', description: 'NAVER access token 만료 예정 시간', isRequired: 'N', isSensitive: 'N', status: 'ACTIVE' },
      { key: 'NAVER_TOKEN_TYPE', value: 'bearer', category: 'CALENDAR', subCategory: 'NAVER', projectScope: 'PORTAL', description: 'NAVER OAuth token type', isRequired: 'N', isSensitive: 'N', status: 'ACTIVE' },
      { key: 'NAVER_CALENDAR_CREATE_URL', value: 'https://openapi.naver.com/calendar/createSchedule.json', category: 'CALENDAR', subCategory: 'NAVER', projectScope: 'PORTAL', description: 'NAVER 일정 생성 API URL', isRequired: 'N', isSensitive: 'N', status: 'ACTIVE' }
    ];
    var created = [];
    var present = [];
    for (var i = 0; i < requiredRows.length; i++) {
      var spec = requiredRows[i];
      if (existing[spec.key]) {
        present.push(spec.key);
        portal28SyncNaverConfigMetadata_(sheet, headers, values, keyCol, valueCol, spec, actorKey);
        continue;
      }
      var row = [];
      for (var c = 0; c < values[0].length; c++) row.push('');
      row[keyCol] = spec.key;
      row[valueCol] = spec.value;
      portal22SetIfHeader_(headers, row, 'category', spec.category);
      portal22SetIfHeader_(headers, row, 'subCategory', spec.subCategory);
      portal22SetIfHeader_(headers, row, 'projectScope', spec.projectScope);
      portal22SetIfHeader_(headers, row, 'description', spec.description);
      portal22SetIfHeader_(headers, row, 'DESCRIPTION', spec.description);
      portal22SetIfHeader_(headers, row, 'isRequired', spec.isRequired);
      portal22SetIfHeader_(headers, row, 'isSensitive', spec.isSensitive);
      portal22SetIfHeader_(headers, row, 'status', spec.status);
      portal22SetIfHeader_(headers, row, 'updatedAt', portal19Now_());
      portal22SetIfHeader_(headers, row, 'UPDATED_AT', portal19Now_());
      portal22SetIfHeader_(headers, row, 'updatedBy', actorKey);
      sheet.appendRow(row);
      created.push(spec.key);
    }
    result.ok = true;
    result.createdKeys = created;
    result.existingKeys = present;
    result.message = created.length ? 'NAVER SystemConfig 설정 행 생성 완료: ' + created.join(', ') : 'NAVER SystemConfig 설정 행이 이미 있습니다.';
    portal19AppendAuditLog_('NAVER_CONFIG_ROWS', actorKey, '', 'SUCCESS', result.message, { createdKeys: created, existingKeys: present });
  } catch (err) {
    result.ok = false;
    result.message = portal19ErrorMessage_(err);
  }
  return result;
}

function portal22SetIfHeader_(headers, row, headerName, value) {
  var idx = portal19FindHeader_(headers, [headerName]);
  if (idx >= 0) row[idx] = value;
}

function portal28SyncNaverConfigMetadata_(sheet, headers, values, keyCol, valueCol, spec, updatedBy) {
  var targetRow = -1;
  for (var r = 1; r < values.length; r++) {
    if (String(values[r][keyCol] || '').trim() === spec.key) {
      targetRow = r + 1;
      break;
    }
  }
  if (targetRow < 0) return;
  if (spec.key === 'NAVER_CALENDAR_ID') sheet.getRange(targetRow, valueCol + 1).setValue('');
  portal28SetCellIfHeader_(sheet, headers, targetRow, 'description', spec.description);
  portal28SetCellIfHeader_(sheet, headers, targetRow, 'DESCRIPTION', spec.description);
  portal28SetCellIfHeader_(sheet, headers, targetRow, 'isRequired', spec.isRequired);
  portal28SetCellIfHeader_(sheet, headers, targetRow, 'isSensitive', spec.isSensitive);
  portal28SetCellIfHeader_(sheet, headers, targetRow, 'status', spec.status);
  portal28SetCellIfHeader_(sheet, headers, targetRow, 'updatedAt', portal19Now_());
  portal28SetCellIfHeader_(sheet, headers, targetRow, 'UPDATED_AT', portal19Now_());
  portal28SetCellIfHeader_(sheet, headers, targetRow, 'updatedBy', updatedBy || '');
}

function portal28SetCellIfHeader_(sheet, headers, rowIndex, headerName, value) {
  var idx = portal19FindHeader_(headers, [headerName]);
  if (idx >= 0) sheet.getRange(rowIndex, idx + 1).setValue(value);
}

function portal22CreateNaverOnlySelfTestCalendarEvent() {
  var result = portal19SafeResult_('portal22CreateNaverOnlySelfTestCalendarEvent');
  var request = {};
  try {
    var config = portal19GetConfigBundle_();
    var profile = portal186ResolveCalendarActor_(request, config, { allowFallback: true });
    var actorKey = portal186ActorKey_(profile);
    portal186PermissionGuard_(profile, 'CALENDAR_CREATE');
    var start = new Date(new Date().getTime() + 30 * 60000);
    var end = new Date(start.getTime() + 30 * 60000);
    request = {
      targetType: 'SELF_TEST',
      targetId: 'PORTAL24_NAVER_REAL_TEST',
      title: 'FEELHAUS PORTAL 29 NAVER no-calendar-id 실제등록 테스트',
      startAt: portal19FormatCalendarDateTime_(start),
      endAt: portal19FormatCalendarDateTime_(end),
      fallbackProvider: '',
      calendarProvider: 'NAVER',
      calendarEventId: '',
      naverStatusReason: ''
    };
    var settingCheck = portal21BuildNaverSettingCheck_(config.config || {});
    if (!settingCheck.ready) throw new Error('NAVER 실제등록 차단: ' + settingCheck.missingKeys.join(', '));
    var providerResult = portal19CreateNaverCalendarEvent_(config, request, start, end);
    request.calendarProvider = 'NAVER';
    request.calendarEventId = providerResult.eventId || '';
    request.result = 'SUCCESS';
    request.statusReason = providerResult.message || 'NAVER 기본 캘린더(defaultCalendarId) 실제등록 완료';
    request.naverStatusReason = providerResult.tokenRefreshed ? 'NAVER access token 자동 갱신 후 등록 성공' : 'NAVER access token 유효 상태로 등록 성공';
    portal19AppendCalendarLog_(profile, request);
    portal19AppendAuditLog_('NAVER_REAL_CREATE', actorKey, request.targetId, 'SUCCESS', request.statusReason, { calendarEventId: request.calendarEventId });
    result.ok = true;
    result.calendarProvider = 'NAVER';
    result.calendarEventId = request.calendarEventId;
    result.calendarId = providerResult.calendarId || '';
    result.message = 'NAVER 기본 캘린더(defaultCalendarId) 실제등록 및 CalendarLog 저장 완료';
  } catch (err) {
    result.ok = false;
    result.message = portal19ErrorMessage_(err);
    try {
      var failConfig = portal19GetConfigBundle_();
      var failProfile = portal186ResolveCalendarActor_(request, failConfig, { allowFallback: true });
      var failActorKey = portal186ActorKey_(failProfile);
      request.targetType = request.targetType || 'SELF_TEST';
      request.targetId = request.targetId || 'PORTAL24_NAVER_REAL_TEST';
      request.title = request.title || 'FEELHAUS PORTAL 29 NAVER no-calendar-id 실제등록 테스트';
      request.calendarProvider = 'NAVER';
      request.result = 'FAIL';
      request.statusReason = result.message;
      request.naverStatusReason = result.message;
      portal19AppendCalendarLog_(failProfile, request);
      portal19AppendAuditLog_('NAVER_REAL_CREATE', failActorKey, request.targetId, 'FAIL', result.message, {});
    } catch (ignore) {}
  }
  return result;
}


/* Build: PORTAL_186_CALENDAR_MODULE_STAFF_AUDIT_20260518
 * Calendar module add-on. PORTAL body remains light; external providers never run on PortalHome boot.
 */
function portal186CalendarEventHeaders_() {
  return ['calendarEventId','eventId','customerId','contractId','installId','asId','requestId','provider','providerEventId','eventType','eventTitle','eventDescription','startAt','endAt','allDayYn','location','attendees','ownerEmployeeId','assignedEmployeeId','eventStatus','naverRegisterStatus','naverProviderEventId','naverErrorCode','naverErrorMessage','googleBackupStatus','googleProviderEventId','googleErrorCode','googleErrorMessage','retryCount','lastRetryAt','createdAt','createdBy','updatedAt','updatedBy'];
}

function portal186CalendarLogHeaders_() {
  return ['calendarLogId','calendarEventId','provider','actionType','resultStatus','providerEventId','errorCode','errorMessage','requestPayloadSummary','responseSummary','createdAt','createdBy'];
}

function portal186CalendarRetryHeaders_() {
  return ['retryId','calendarEventId','provider','retryStatus','retryCount','lastErrorCode','lastErrorMessage','nextRetryAt','createdAt','updatedAt'];
}

function portal186FeatureGuard_(cfg, key, label) {
  var value = String(cfg && cfg.hasOwnProperty(key) ? cfg[key] : 'Y').toUpperCase();
  if (value === 'N' || value === 'FALSE' || value === 'OFF' || value === '0') throw new Error(label + '이 SystemConfig에서 비활성화되어 있습니다: ' + key);
}

function portal186EnsureCalendarModuleSheets_(ss) {
  portal19GetSheetOrCreate_(ss, 'PORTAL_CalendarEvents', portal186CalendarEventHeaders_());
  portal19GetSheetOrCreate_(ss, 'PORTAL_CalendarLogs', portal186CalendarLogHeaders_());
  portal19GetSheetOrCreate_(ss, 'PORTAL_CalendarRetryQueue', portal186CalendarRetryHeaders_());
}

function portal186NormalizeCalendarRequest_(request, profile) {
  var title = String(request.eventTitle || request.title || '').trim();
  var startAt = request.startAt ? new Date(request.startAt) : null;
  var endAt = request.endAt ? new Date(request.endAt) : null;
  var normalized = {
    eventTitle: title,
    title: title,
    eventType: String(request.eventType || request.targetType || 'INTERNAL').trim() || 'INTERNAL',
    eventDescription: String(request.eventDescription || request.description || '').trim(),
    description: String(request.eventDescription || request.description || '').trim(),
    startAt: startAt && !isNaN(startAt.getTime()) ? portal19FormatCalendarDateTime_(startAt) : String(request.startAt || ''),
    endAt: endAt && !isNaN(endAt.getTime()) ? portal19FormatCalendarDateTime_(endAt) : String(request.endAt || ''),
    allDayYn: String(request.allDayYn || 'N').toUpperCase() === 'Y' ? 'Y' : 'N',
    location: String(request.location || '').trim(),
    attendees: String(request.attendees || '').trim(),
    ownerEmployeeId: String(request.ownerEmployeeId || profile.employeeId || '').trim(),
    assignedEmployeeId: String(request.assignedEmployeeId || request.ownerEmployeeId || profile.employeeId || '').trim(),
    eventId: String(request.eventId || '').trim(),
    customerId: String(request.customerId || '').trim(),
    contractId: String(request.contractId || '').trim(),
    installId: String(request.installId || '').trim(),
    asId: String(request.asId || '').trim(),
    requestId: String(request.requestId || '').trim(),
    targetType: String(request.targetType || request.eventType || 'INTERNAL').trim() || 'INTERNAL',
    targetId: String(request.targetId || request.eventId || request.customerId || request.installId || request.asId || request.requestId || request.contractId || '').trim(),
    _startDate: startAt,
    _endDate: endAt
  };
  return normalized;
}

function portal186ValidateCalendarRequest_(request) {
  if (!request.eventTitle) throw new Error('일정 제목을 입력하세요.');
  if (!request._startDate || isNaN(request._startDate.getTime())) throw new Error('시작 일시 형식이 올바르지 않습니다.');
  if (!request._endDate || isNaN(request._endDate.getTime())) throw new Error('종료 일시 형식이 올바르지 않습니다.');
  if (request.allDayYn !== 'Y' && request._endDate.getTime() <= request._startDate.getTime()) throw new Error('종료 일시는 시작 일시보다 뒤여야 합니다.');
}

function portal186BuildCalendarEventRecord_(request, profile) {
  var id = 'CAL-' + Utilities.formatDate(new Date(), Session.getScriptTimeZone() || 'Asia/Seoul', 'yyyyMMddHHmmss') + '-' + Utilities.getUuid().substring(0, 8).toUpperCase();
  var now = portal19Now_();
  return {
    calendarEventId: id,
    eventId: request.eventId,
    customerId: request.customerId,
    contractId: request.contractId,
    installId: request.installId,
    asId: request.asId,
    requestId: request.requestId,
    provider: 'INTERNAL',
    providerEventId: '',
    eventType: request.eventType,
    eventTitle: request.eventTitle,
    eventDescription: request.eventDescription,
    startAt: request.startAt,
    endAt: request.endAt,
    allDayYn: request.allDayYn,
    location: request.location,
    attendees: request.attendees,
    ownerEmployeeId: request.ownerEmployeeId,
    assignedEmployeeId: request.assignedEmployeeId,
    eventStatus: 'INTERNAL_SAVED',
    naverRegisterStatus: 'PENDING',
    naverProviderEventId: '',
    naverErrorCode: '',
    naverErrorMessage: '',
    googleBackupStatus: 'PENDING',
    googleProviderEventId: '',
    googleErrorCode: '',
    googleErrorMessage: '',
    retryCount: 0,
    lastRetryAt: '',
    createdAt: now,
    createdBy: profile.employeeId || profile.loginId,
    updatedAt: now,
    updatedBy: profile.employeeId || profile.loginId
  };
}

function portal186AppendCalendarEvent_(ss, record) {
  var headers = portal186CalendarEventHeaders_();
  var sheet = portal19GetSheetOrCreate_(ss, 'PORTAL_CalendarEvents', headers);
  portal19AppendByHeader_(sheet, record, headers);
}

function portal186AssertNoDuplicateCalendarEvent_(ss, request) {
  var sheet = portal19GetSheetOrCreate_(ss, 'PORTAL_CalendarEvents', portal186CalendarEventHeaders_());
  var data = portal19ReadRowsByHeader_(sheet);
  var key = [request.eventTitle, request.startAt, request.endAt, request.ownerEmployeeId, request.customerId, request.installId, request.asId].join('|').toLowerCase();
  for (var i = data.rows.length - 1; i >= 0 && i >= data.rows.length - 200; i--) {
    var row = data.rows[i];
    var rowKey = [row.eventTitle, row.startAt, row.endAt, row.ownerEmployeeId, row.customerId, row.installId, row.asId].join('|').toLowerCase();
    var status = String(row.eventStatus || '').toUpperCase();
    if (key === rowKey && status !== 'CANCELLED' && status !== 'DELETED') throw new Error('중복 의심 일정이 있습니다. 기존 calendarEventId: ' + row.calendarEventId);
  }
}

function portal186TryProviderCreate_(callback, provider) {
  try {
    var created = callback();
    return { ok: true, provider: provider, resultStatus: 'SUCCESS', providerEventId: created.eventId || '', errorCode: '', errorMessage: '', message: created.message || provider + ' 등록 성공', raw: created };
  } catch (err) {
    return { ok: false, provider: provider, resultStatus: 'FAIL', providerEventId: '', errorCode: portal186GuessErrorCode_(err), errorMessage: portal19ErrorMessage_(err), message: provider + ' 등록 실패' };
  }
}

function portal186GuessErrorCode_(err) {
  var msg = portal19ErrorMessage_(err);
  var m = msg.match(/HTTP\s+(\d+)/i);
  if (m) return 'HTTP_' + m[1];
  if (msg.indexOf('권한') >= 0) return 'PERMISSION';
  if (msg.indexOf('토큰') >= 0 || msg.toLowerCase().indexOf('token') >= 0) return 'TOKEN';
  return 'PROVIDER_ERROR';
}

function portal186ApplyProviderResult_(ss, calendarEventId, provider, providerResult, profile) {
  var eventHeaders = portal186CalendarEventHeaders_();
  var sheet = portal19GetSheetOrCreate_(ss, 'PORTAL_CalendarEvents', eventHeaders);
  var data = sheet.getDataRange().getValues();
  if (!data || data.length < 2) return;
  var headers = portal19HeaderMap_(data[0]);
  var targetRow = -1;
  for (var r = data.length - 1; r >= 1; r--) {
    if (String(data[r][headers.calendarEventId] || '') === String(calendarEventId)) { targetRow = r + 1; break; }
  }
  if (targetRow < 0) return;
  var now = portal19Now_();
  var status = providerResult.ok ? 'SUCCESS' : 'FAIL';
  var updates = { updatedAt: now, updatedBy: profile.employeeId || profile.loginId };
  if (provider === 'NAVER') {
    updates.naverRegisterStatus = status;
    updates.naverProviderEventId = providerResult.providerEventId || '';
    updates.naverErrorCode = providerResult.errorCode || '';
    updates.naverErrorMessage = providerResult.errorMessage || '';
  }
  if (provider === 'GOOGLE_BACKUP') {
    updates.googleBackupStatus = status;
    updates.googleProviderEventId = providerResult.providerEventId || '';
    updates.googleErrorCode = providerResult.errorCode || '';
    updates.googleErrorMessage = providerResult.errorMessage || '';
  }
  if (!providerResult.ok) updates.eventStatus = 'PROVIDER_PARTIAL_FAIL';
  portal186SetRowValuesByHeader_(sheet, targetRow, updates);
  portal186AppendProviderLog_(ss, { calendarEventId: calendarEventId }, provider, 'CREATE_EVENT', status, providerResult.providerEventId || '', providerResult.errorCode || '', providerResult.errorMessage || '', providerResult.message || '', profile);
  if (!providerResult.ok) portal186UpsertRetryQueue_(ss, calendarEventId, provider, providerResult, profile);
}


function portal186FinalizeCalendarEventStatus_(ss, calendarEventId, overallStatus, profile) {
  var sheet = portal19GetSheetOrCreate_(ss, 'PORTAL_CalendarEvents', portal186CalendarEventHeaders_());
  var data = sheet.getDataRange().getValues();
  if (!data || data.length < 2) return;
  var headers = portal19HeaderMap_(data[0]);
  for (var r = data.length - 1; r >= 1; r--) {
    if (String(data[r][headers.calendarEventId] || '') === String(calendarEventId)) {
      portal186SetRowValuesByHeader_(sheet, r + 1, {
        eventStatus: overallStatus.result === 'SUCCESS' ? 'REGISTERED' : 'PROVIDER_PARTIAL_FAIL',
        updatedAt: portal19Now_(),
        updatedBy: profile.employeeId || profile.loginId || ''
      });
      return;
    }
  }
}

function portal186SetRowValuesByHeader_(sheet, rowNumber, updates) {
  var values = sheet.getDataRange().getValues();
  var headers = portal19HeaderMap_(values[0]);
  var keys = Object.keys(updates || {});
  for (var i = 0; i < keys.length; i++) {
    var k = keys[i];
    if (headers.hasOwnProperty(k)) sheet.getRange(rowNumber, headers[k] + 1).setValue(updates[k]);
  }
}

function portal186AppendProviderLog_(ss, eventRecord, provider, actionType, resultStatus, providerEventId, errorCode, errorMessage, responseSummary, profile) {
  var headers = portal186CalendarLogHeaders_();
  var sheet = portal19GetSheetOrCreate_(ss, 'PORTAL_CalendarLogs', headers);
  portal19AppendByHeader_(sheet, {
    calendarLogId: 'CLOG-' + Utilities.getUuid(),
    calendarEventId: eventRecord.calendarEventId || '',
    provider: provider || '',
    actionType: actionType || '',
    resultStatus: resultStatus || '',
    providerEventId: providerEventId || '',
    errorCode: errorCode || '',
    errorMessage: errorMessage || '',
    requestPayloadSummary: JSON.stringify(portal28SanitizePayload_({ calendarEventId: eventRecord.calendarEventId || '', provider: provider || '' })),
    responseSummary: responseSummary || '',
    createdAt: portal19Now_(),
    createdBy: profile.employeeId || profile.loginId || ''
  }, headers);
}

function portal186UpsertRetryQueue_(ss, calendarEventId, provider, providerResult, profile) {
  var headers = portal186CalendarRetryHeaders_();
  var sheet = portal19GetSheetOrCreate_(ss, 'PORTAL_CalendarRetryQueue', headers);
  var next = new Date(new Date().getTime() + 10 * 60000);
  portal19AppendByHeader_(sheet, {
    retryId: 'RETRY-' + Utilities.getUuid(),
    calendarEventId: calendarEventId,
    provider: provider,
    retryStatus: 'PENDING',
    retryCount: 0,
    lastErrorCode: providerResult.errorCode || '',
    lastErrorMessage: providerResult.errorMessage || '',
    nextRetryAt: Utilities.formatDate(next, Session.getScriptTimeZone() || 'Asia/Seoul', 'yyyy-MM-dd HH:mm:ss'),
    createdAt: portal19Now_(),
    updatedAt: portal19Now_()
  }, headers);
}

function portal186BuildOverallCalendarStatus_(providerResults) {
  var fail = [];
  for (var i = 0; i < providerResults.length; i++) if (!providerResults[i].ok) fail.push(providerResults[i].provider);
  if (!fail.length) return { result: 'SUCCESS', message: '내부 저장, NAVER 등록, GOOGLE 백업이 모두 완료되었습니다.' };
  return { result: 'PARTIAL', message: '내부 저장은 완료되었습니다. 실패 provider: ' + fail.join(', ') + ' / 재전송 대기열에 저장했습니다.' };
}

function portal186GetCalendarDashboard(request) {
  var result = portal19SafeResult_('portal186GetCalendarDashboard');
  request = request || {};
  try {
    var config = portal19GetConfigBundle_();
    var profile = portal186ResolveCalendarActor_(request, config, { allowFallback: true });
    portal186PermissionGuard_(profile, 'CALENDAR_CREATE');
    var ss = portal19OpenMaster_(config);
    portal186EnsureCalendarModuleSheets_(ss);
    var events = portal19ReadRowsByHeader_(ss.getSheetByName('PORTAL_CalendarEvents')).rows;
    var retryRows = portal19ReadRowsByHeader_(ss.getSheetByName('PORTAL_CalendarRetryQueue')).rows;
    var today = Utilities.formatDate(new Date(), Session.getScriptTimeZone() || 'Asia/Seoul', 'yyyy-MM-dd');
    var summary = { total: events.length, today: 0, naverSuccess: 0, naverFail: 0, googleSuccess: 0, googleFail: 0, retryPending: 0 };
    var recent = [];
    for (var i = events.length - 1; i >= 0; i--) {
      var row = events[i];
      if (String(row.startAt || '').indexOf(today) === 0) summary.today++;
      if (String(row.naverRegisterStatus || '') === 'SUCCESS') summary.naverSuccess++;
      if (String(row.naverRegisterStatus || '') === 'FAIL') summary.naverFail++;
      if (String(row.googleBackupStatus || '') === 'SUCCESS') summary.googleSuccess++;
      if (String(row.googleBackupStatus || '') === 'FAIL') summary.googleFail++;
      if ((String(row.ownerEmployeeId || '') === String(profile.employeeId || '') || String(row.assignedEmployeeId || '') === String(profile.employeeId || '') || portal186HasPermission_(profile, 'ALL')) && recent.length < 20) {
        recent.push(portal186CalendarEventClientRow_(row));
      }
    }
    for (var r = 0; r < retryRows.length; r++) if (String(retryRows[r].retryStatus || '') === 'PENDING') summary.retryPending++;
    result.ok = true;
    result.summary = summary;
    result.recentEvents = recent;
    result.profile = portal186SafeActorSummary_(profile);
    result.message = '캘린더 요약 조회 완료';
  } catch (err) {
    result.ok = false;
    result.message = portal19ErrorMessage_(err);
    result.summary = { total: 0, today: 0, naverSuccess: 0, naverFail: 0, googleSuccess: 0, googleFail: 0, retryPending: 0 };
    result.recentEvents = [];
  }
  return portal19ClientSafeObject_(result);
}

function portal186CalendarEventClientRow_(row) {
  return {
    calendarEventId: portal19ClientSafeValue_(row.calendarEventId),
    eventTitle: portal19ClientSafeValue_(row.eventTitle),
    startAt: portal19ClientSafeValue_(row.startAt),
    endAt: portal19ClientSafeValue_(row.endAt),
    ownerEmployeeId: portal19ClientSafeValue_(row.ownerEmployeeId),
    assignedEmployeeId: portal19ClientSafeValue_(row.assignedEmployeeId),
    eventStatus: portal19ClientSafeValue_(row.eventStatus),
    naverRegisterStatus: portal19ClientSafeValue_(row.naverRegisterStatus),
    googleBackupStatus: portal19ClientSafeValue_(row.googleBackupStatus),
    createdBy: portal19ClientSafeValue_(row.createdBy),
    updatedBy: portal19ClientSafeValue_(row.updatedBy)
  };
}

function portal186RetryPendingCalendarProviders(request) {
  var result = portal19SafeResult_('portal186RetryPendingCalendarProviders');
  request = request || {};
  try {
    var config = portal19GetConfigBundle_();
    var profile = portal186ResolveCalendarActor_(request, config, { allowFallback: true });
    portal186PermissionGuard_(profile, 'CALENDAR_CREATE');
    portal186PermissionGuard_(profile, 'CALENDAR_RETRY');
    result.ok = true;
    result.actor = portal186SafeActorSummary_(profile);
    result.message = '재전송 실행 게이트 통과. 실제 provider 재전송은 다음 빌드에서 개별 Adapter 단위로 확장합니다.';
    result.note = '현재 빌드는 실패 provider를 PORTAL_CalendarRetryQueue에 안전 저장하는 1차 안정화입니다.';
  } catch (err) {
    result.ok = false;
    result.message = portal19ErrorMessage_(err);
  }
  return portal19ClientSafeObject_(result);
}

/*******************************************************
 * PORTAL 186 Calendar Clean Debug Runners
 * 목적:
 * - Apps Script 실행 로그에 결과 JSON을 강제로 출력
 * - 함수 인식 여부, 대시보드 조회, 테스트 일정 생성, 네이버 설정 점검을 순서대로 확인
 * 실행 순서:
 * 1) portal186PingDebug
 * 2) portal186RunCalendarDashboardDebug
 * 3) portal186RunCalendarSelfTestDebug
 * 4) portal186RunNaverSettingsDebug
 *******************************************************/
function portal186DebugStringify_(value) {
  try {
    return JSON.stringify(value, null, 2);
  } catch (e) {
    return String(value);
  }
}

function portal186PingDebug() {
  var fn = 'portal186PingDebug';
  var result = {
    ok: true,
    build: 'PORTAL_187_CALENDAR_LOGINID_CLEAN_DEBUG_20260518',
    action: fn,
    message: 'Portal_Calendar.js 함수 인식 성공 - loginId/employeeId 기준 클린빌드',
    generatedAt: Utilities.formatDate(new Date(), Session.getScriptTimeZone() || 'Asia/Seoul', 'yyyy-MM-dd HH:mm:ss')
  };
  Logger.log('[' + fn + '] 실행 결과');
  Logger.log(portal186DebugStringify_(result));
  return result;
}

function portal186RunCalendarDashboardDebug() {
  var fn = 'portal186RunCalendarDashboardDebug';
  Logger.log('[' + fn + '] 실행 시작');

  try {
    var result = portal186GetCalendarDashboard();
    Logger.log('[' + fn + '] 실행 결과');
    Logger.log(portal186DebugStringify_(result));
    Logger.log('[' + fn + '] 실행 완료');
    return result;
  } catch (e) {
    Logger.log('[' + fn + '] 오류 발생');
    Logger.log('message: ' + (e && e.message ? e.message : e));
    Logger.log('stack: ' + (e && e.stack ? e.stack : 'no stack'));
    throw e;
  }
}

function portal186RunCalendarSelfTestDebug() {
  var fn = 'portal186RunCalendarSelfTestDebug';
  Logger.log('[' + fn + '] 실행 시작');

  try {
    var result = portal19CreateSelfTestCalendarEvent();
    Logger.log('[' + fn + '] 실행 결과');
    Logger.log(portal186DebugStringify_(result));
    Logger.log('[' + fn + '] 실행 완료');
    return result;
  } catch (e) {
    Logger.log('[' + fn + '] 오류 발생');
    Logger.log('message: ' + (e && e.message ? e.message : e));
    Logger.log('stack: ' + (e && e.stack ? e.stack : 'no stack'));
    throw e;
  }
}

function portal186RunNaverSettingsDebug() {
  var fn = 'portal186RunNaverSettingsDebug';
  Logger.log('[' + fn + '] 실행 시작');

  try {
    var result = portal21CheckNaverCalendarSettings({});
    Logger.log('[' + fn + '] 실행 결과');
    Logger.log(portal186DebugStringify_(result));
    Logger.log('[' + fn + '] 실행 완료');
    return result;
  } catch (e) {
    Logger.log('[' + fn + '] 오류 발생');
    Logger.log('message: ' + (e && e.message ? e.message : e));
    Logger.log('stack: ' + (e && e.stack ? e.stack : 'no stack'));
    throw e;
  }
}


/*******************************************************
 * PORTAL 189 Calendar Advanced Field Helpers
 * Build: PORTAL_190_CALENDAR_DETAIL_RETRY_ACTION_LOCK_20260518
 * Scope: assignee picker, event detail, retry list. JS only.
 *******************************************************/
function portal189ListCalendarAssignees(request) {
  var result = portal19SafeResult_('portal189ListCalendarAssignees');
  request = request || {};
  try {
    var config = portal19GetConfigBundle_();
    var profile = portal186ResolveCalendarActor_(request, config, { allowFallback: true });
    portal186PermissionGuard_(profile, 'CALENDAR_VIEW');
    var users = portal186ReadPortalUsersForCalendar_(config);
    var list = [];
    for (var i = 0; i < users.length; i++) {
      if (!portal186IsActiveCalendarUser_(users[i])) continue;
      list.push({
        userId: portal19ClientSafeValue_(users[i].userId || ''),
        loginId: portal19ClientSafeValue_(users[i].loginId || ''),
        employeeId: portal19ClientSafeValue_(users[i].employeeId || ''),
        employeeName: portal19ClientSafeValue_(users[i].employeeName || ''),
        roleCode: portal19ClientSafeValue_(users[i].roleCode || ''),
        vendorId: portal19ClientSafeValue_(users[i].vendorId || '')
      });
    }
    list.sort(function(a, b) {
      var ak = String(a.employeeName || a.loginId || a.employeeId || '');
      var bk = String(b.employeeName || b.loginId || b.employeeId || '');
      return ak.localeCompare(bk, 'ko');
    });
    result.ok = true;
    result.message = '담당자 목록 조회 완료';
    result.actor = portal186SafeActorSummary_(profile);
    result.assignees = list;
  } catch (err) {
    result.ok = false;
    result.message = portal19ErrorMessage_(err);
    result.assignees = [];
  }
  return portal19ClientSafeObject_(result);
}

function portal189FindCalendarEventRow_(events, calendarEventId) {
  calendarEventId = String(calendarEventId || '').trim();
  for (var i = events.length - 1; i >= 0; i--) {
    if (String(events[i].calendarEventId || '') === calendarEventId) return events[i];
  }
  return null;
}

function portal189CanViewCalendarEvent_(profile, row) {
  if (portal186HasPermission_(profile, 'ALL')) return true;
  var emp = String(profile && profile.employeeId || '');
  return String(row.ownerEmployeeId || '') === emp || String(row.assignedEmployeeId || '') === emp || String(row.createdBy || '') === emp || String(row.updatedBy || '') === emp;
}

function portal189GetCalendarEventDetail(request) {
  var result = portal19SafeResult_('portal189GetCalendarEventDetail');
  request = request || {};
  try {
    var calendarEventId = String(request.calendarEventId || '').trim();
    if (!calendarEventId) throw new Error('calendarEventId가 필요합니다.');
    var config = portal19GetConfigBundle_();
    var profile = portal186ResolveCalendarActor_(request, config, { allowFallback: true });
    portal186PermissionGuard_(profile, 'CALENDAR_VIEW');
    var ss = portal19OpenMaster_(config);
    portal186EnsureCalendarModuleSheets_(ss);
    var events = portal19ReadRowsByHeader_(ss.getSheetByName('PORTAL_CalendarEvents')).rows;
    var row = portal189FindCalendarEventRow_(events, calendarEventId);
    if (!row) throw new Error('일정을 찾지 못했습니다: ' + calendarEventId);
    if (!portal189CanViewCalendarEvent_(profile, row)) throw new Error('해당 일정 조회 권한이 없습니다.');
    var logs = portal19ReadRowsByHeader_(ss.getSheetByName('PORTAL_CalendarLogs')).rows;
    var retries = portal19ReadRowsByHeader_(ss.getSheetByName('PORTAL_CalendarRetryQueue')).rows;
    var eventLogs = [];
    var retryRows = [];
    for (var i = logs.length - 1; i >= 0 && eventLogs.length < 30; i--) {
      if (String(logs[i].calendarEventId || '') === calendarEventId) eventLogs.push(portal19ClientSafeObject_(logs[i]));
    }
    for (var r = retries.length - 1; r >= 0 && retryRows.length < 20; r--) {
      if (String(retries[r].calendarEventId || '') === calendarEventId) retryRows.push(portal19ClientSafeObject_(retries[r]));
    }
    result.ok = true;
    result.message = '일정 상세 조회 완료';
    result.actor = portal186SafeActorSummary_(profile);
    result.event = portal19ClientSafeObject_(row);
    result.logs = eventLogs;
    result.retryRows = retryRows;
  } catch (err) {
    result.ok = false;
    result.message = portal19ErrorMessage_(err);
    result.event = null;
    result.logs = [];
    result.retryRows = [];
  }
  return portal19ClientSafeObject_(result);
}

function portal189ListCalendarRetryQueue(request) {
  var result = portal19SafeResult_('portal189ListCalendarRetryQueue');
  request = request || {};
  try {
    var config = portal19GetConfigBundle_();
    var profile = portal186ResolveCalendarActor_(request, config, { allowFallback: true });
    portal186PermissionGuard_(profile, 'CALENDAR_VIEW');
    var ss = portal19OpenMaster_(config);
    portal186EnsureCalendarModuleSheets_(ss);
    var events = portal19ReadRowsByHeader_(ss.getSheetByName('PORTAL_CalendarEvents')).rows;
    var retryRowsRaw = portal19ReadRowsByHeader_(ss.getSheetByName('PORTAL_CalendarRetryQueue')).rows;
    var byId = {};
    for (var i = 0; i < events.length; i++) byId[String(events[i].calendarEventId || '')] = events[i];
    var retryRows = [];
    for (var r = retryRowsRaw.length - 1; r >= 0 && retryRows.length < 50; r--) {
      var q = retryRowsRaw[r];
      var ev = byId[String(q.calendarEventId || '')] || {};
      if (!portal189CanViewCalendarEvent_(profile, ev || {})) continue;
      retryRows.push({
        retryId: portal19ClientSafeValue_(q.retryId || ''),
        calendarEventId: portal19ClientSafeValue_(q.calendarEventId || ''),
        eventTitle: portal19ClientSafeValue_(ev.eventTitle || ''),
        startAt: portal19ClientSafeValue_(ev.startAt || ''),
        provider: portal19ClientSafeValue_(q.provider || ''),
        retryStatus: portal19ClientSafeValue_(q.retryStatus || ''),
        retryCount: portal19ClientSafeValue_(q.retryCount || ''),
        lastErrorCode: portal19ClientSafeValue_(q.lastErrorCode || ''),
        lastErrorMessage: portal19ClientSafeValue_(q.lastErrorMessage || ''),
        nextRetryAt: portal19ClientSafeValue_(q.nextRetryAt || ''),
        updatedAt: portal19ClientSafeValue_(q.updatedAt || '')
      });
    }
    result.ok = true;
    result.message = '재전송 대기열 조회 완료';
    result.actor = portal186SafeActorSummary_(profile);
    result.retryRows = retryRows;
  } catch (err) {
    result.ok = false;
    result.message = portal19ErrorMessage_(err);
    result.retryRows = [];
  }
  return portal19ClientSafeObject_(result);
}

function portal189CalendarAdvancedDebug() {
  var result = {
    ok: true,
    build: 'PORTAL_189_CALENDAR_FIELD_ADVANCED_20260518',
    action: 'portal189CalendarAdvancedDebug',
    message: '캘린더 후속 기능 파일 인식 성공: 담당자 선택, 상세 보기, 재전송 목록',
    checks: {
      assigneeListReady: typeof portal189ListCalendarAssignees === 'function',
      detailReady: typeof portal189GetCalendarEventDetail === 'function',
      retryListReady: typeof portal189ListCalendarRetryQueue === 'function',
      calendarCreateReady: typeof portal19CreateCalendarEvent === 'function',
      dashboardReady: typeof portal186GetCalendarDashboard === 'function'
    },
    generatedAt: Utilities.formatDate(new Date(), Session.getScriptTimeZone() || 'Asia/Seoul', 'yyyy-MM-dd HH:mm:ss')
  };
  Logger.log(JSON.stringify(result, null, 2));
  return result;
}


/*******************************************************
 * PORTAL 190 Calendar Detail/Retry Action Lock
 * Build: PORTAL_190_CALENDAR_DETAIL_RETRY_ACTION_LOCK_20260518
 * Scope: verify detail button, retry list and action functions.
 *******************************************************/
function portal190CalendarActionDebug() {
  var result = {
    ok: true,
    build: 'PORTAL_190_CALENDAR_DETAIL_RETRY_ACTION_LOCK_20260518',
    action: 'portal190CalendarActionDebug',
    message: '캘린더 상세/재전송 액션 서버 함수 인식 성공',
    checks: {
      dashboardReady: typeof portal186GetCalendarDashboard === 'function',
      detailReady: typeof portal189GetCalendarEventDetail === 'function',
      retryListReady: typeof portal189ListCalendarRetryQueue === 'function',
      retryActionReady: typeof portal186RetryPendingCalendarProviders === 'function',
      assigneeListReady: typeof portal189ListCalendarAssignees === 'function'
    },
    generatedAt: Utilities.formatDate(new Date(), Session.getScriptTimeZone() || 'Asia/Seoul', 'yyyy-MM-dd HH:mm:ss')
  };
  Logger.log(JSON.stringify(result, null, 2));
  return result;
}

function portal190CalendarLatestDetailSelfCheck(request) {
  var result = portal19SafeResult_('portal190CalendarLatestDetailSelfCheck');
  request = request || {};
  try {
    var dashboard = portal186GetCalendarDashboard(request);
    var latest = dashboard && dashboard.recentEvents && dashboard.recentEvents.length ? dashboard.recentEvents[0] : null;
    var detail = null;
    if (latest && latest.calendarEventId) {
      detail = portal189GetCalendarEventDetail({
        sid: request.sid || '',
        loginId: request.loginId || '',
        employeeId: request.employeeId || '',
        calendarEventId: latest.calendarEventId
      });
    }
    var retry = portal189ListCalendarRetryQueue(request);
    result.ok = !!(dashboard && dashboard.ok) && (!latest || !!(detail && detail.ok)) && !!(retry && retry.ok);
    result.build = 'PORTAL_190_CALENDAR_DETAIL_RETRY_ACTION_LOCK_20260518';
    result.message = result.ok ? '최근 일정 상세/재전송 목록 자체점검 통과' : '최근 일정 상세/재전송 목록 자체점검 확인 필요';
    result.dashboardOk = !!(dashboard && dashboard.ok);
    result.latestCalendarEventId = latest ? latest.calendarEventId : '';
    result.detailOk = latest ? !!(detail && detail.ok) : true;
    result.retryListOk = !!(retry && retry.ok);
    result.retryCount = retry && retry.retryRows ? retry.retryRows.length : 0;
  } catch (err) {
    result.ok = false;
    result.build = 'PORTAL_190_CALENDAR_DETAIL_RETRY_ACTION_LOCK_20260518';
    result.message = portal19ErrorMessage_(err);
  }
  Logger.log(JSON.stringify(result, null, 2));
  return portal19ClientSafeObject_(result);
}


/*******************************************************
 * PORTAL 192 Calendar Range/List View
 * Build: PORTAL_192_CALENDAR_RANGE_LIST_VIEW_20260518
 * Scope: read-only range search/list for field calendar. No mail/common files touched.
 *******************************************************/
function portal192ListCalendarEvents(request) {
  var result = portal19SafeResult_('portal192ListCalendarEvents');
  request = request || {};
  try {
    var config = portal19GetConfigBundle_();
    var profile = portal186ResolveCalendarActor_(request, config, { allowFallback: true });
    portal186PermissionGuard_(profile, 'CALENDAR_VIEW');
    var ss = portal19OpenMaster_(config);
    portal186EnsureCalendarModuleSheets_(ss);
    var events = portal19ReadRowsByHeader_(ss.getSheetByName('PORTAL_CalendarEvents')).rows;
    var rangeStart = portal192ParseDateLoose_(request.rangeStart || request.startAt || '');
    var rangeEnd = portal192ParseDateLoose_(request.rangeEnd || request.endAt || '');
    if (rangeEnd) rangeEnd = new Date(rangeEnd.getFullYear(), rangeEnd.getMonth(), rangeEnd.getDate(), 23, 59, 59, 999);
    var keyword = String(request.keyword || '').trim().toLowerCase();
    var assignee = String(request.assignedEmployeeId || '').trim();
    var status = String(request.eventStatus || '').trim();
    var rows = [];
    var totalVisible = 0;
    for (var i = 0; i < events.length; i++) {
      var row = events[i];
      if (!portal189CanViewCalendarEvent_(profile, row)) continue;
      totalVisible++;
      var start = portal192ParseDateLoose_(row.startAt || '');
      if (rangeStart && start && start < rangeStart) continue;
      if (rangeEnd && start && start > rangeEnd) continue;
      if (assignee && String(row.assignedEmployeeId || '') !== assignee) continue;
      if (status && String(row.eventStatus || '') !== status) continue;
      if (keyword) {
        var hay = [row.calendarEventId, row.eventTitle, row.eventDescription, row.location, row.eventId, row.customerId, row.contractId, row.installId, row.asId, row.requestId, row.ownerEmployeeId, row.assignedEmployeeId].join(' ').toLowerCase();
        if (hay.indexOf(keyword) < 0) continue;
      }
      rows.push(portal186CalendarEventClientRow_(row));
    }
    rows.sort(function(a,b){
      var da = portal192ParseDateLoose_(a.startAt || '') || new Date(0);
      var db = portal192ParseDateLoose_(b.startAt || '') || new Date(0);
      return da.getTime() - db.getTime();
    });
    result.ok = true;
    result.build = 'PORTAL_192_CALENDAR_RANGE_LIST_VIEW_20260518';
    result.message = '캘린더 기간/검색 목록 조회 완료';
    result.totalVisible = totalVisible;
    result.filteredCount = rows.length;
    result.rows = rows.slice(0, 100);
    result.profile = portal186SafeActorSummary_(profile);
    result.filters = {
      rangeStart: request.rangeStart || '',
      rangeEnd: request.rangeEnd || '',
      keyword: request.keyword || '',
      assignedEmployeeId: assignee,
      eventStatus: status
    };
  } catch (err) {
    result.ok = false;
    result.build = 'PORTAL_192_CALENDAR_RANGE_LIST_VIEW_20260518';
    result.message = portal19ErrorMessage_(err);
    result.rows = [];
    result.filteredCount = 0;
  }
  return portal19ClientSafeObject_(result);
}

function portal192ParseDateLoose_(value) {
  if (value instanceof Date && !isNaN(value.getTime())) return value;
  value = String(value || '').trim();
  if (!value) return null;
  var normalized = value.replace(/\./g, '-').replace(/T/g, ' ');
  var m = normalized.match(/^(\d{4})-(\d{1,2})-(\d{1,2})(?:\s+(\d{1,2}):(\d{1,2})(?::(\d{1,2}))?)?/);
  if (m) return new Date(Number(m[1]), Number(m[2]) - 1, Number(m[3]), Number(m[4] || 0), Number(m[5] || 0), Number(m[6] || 0));
  var d = new Date(value);
  return isNaN(d.getTime()) ? null : d;
}

function portal192CalendarRangeListDebug() {
  var result = {
    ok: true,
    build: 'PORTAL_192_CALENDAR_RANGE_LIST_VIEW_20260518',
    action: 'portal192CalendarRangeListDebug',
    message: '캘린더 기간/검색 목록 서버 함수 인식 성공',
    checks: {
      rangeListReady: typeof portal192ListCalendarEvents === 'function',
      dashboardReady: typeof portal186GetCalendarDashboard === 'function',
      detailReady: typeof portal189GetCalendarEventDetail === 'function',
      assigneeListReady: typeof portal189ListCalendarAssignees === 'function'
    },
    generatedAt: Utilities.formatDate(new Date(), Session.getScriptTimeZone() || 'Asia/Seoul', 'yyyy-MM-dd HH:mm:ss')
  };
  try {
    var list = portal192ListCalendarEvents({});
    result.selfCheckOk = !!(list && list.ok);
    result.filteredCount = list && list.filteredCount ? list.filteredCount : 0;
  } catch (e) {
    result.selfCheckOk = false;
    result.selfCheckMessage = e && e.message ? e.message : String(e);
  }
  Logger.log(JSON.stringify(result, null, 2));
  return result;
}

/*
 * PORTAL 193 Calendar Edit Event Lock
 * Scope: internal calendar event edit with audit/provider log. External provider update is deferred.
 */
function portal193FindCalendarEventRowNumber_(sheet, calendarEventId) {
  var values = sheet.getDataRange().getValues();
  if (!values || values.length < 2) return { rowNumber: -1, headers: values && values[0] ? portal19HeaderMap_(values[0]) : {}, row: null };
  var headers = portal19HeaderMap_(values[0]);
  for (var r = values.length - 1; r >= 1; r--) {
    if (String(values[r][headers.calendarEventId] || '') === String(calendarEventId)) {
      var rowObj = {};
      Object.keys(headers).forEach(function(k){ rowObj[k] = values[r][headers[k]]; });
      return { rowNumber: r + 1, headers: headers, row: rowObj };
    }
  }
  return { rowNumber: -1, headers: headers, row: null };
}

function portal193NormalizeEditDate_(value, fallback) {
  var raw = String(value || '').trim();
  if (!raw) raw = String(fallback || '').trim();
  if (!raw) return '';
  var d = new Date(raw);
  if (!isNaN(d.getTime())) return portal19FormatCalendarDateTime_(d);
  return raw;
}

function portal193UpdateCalendarEvent(request) {
  var result = portal19SafeResult_('portal193UpdateCalendarEvent');
  request = request || {};
  try {
    var calendarEventId = String(request.calendarEventId || '').trim();
    if (!calendarEventId) throw new Error('calendarEventId가 필요합니다.');

    var config = portal19GetConfigBundle_();
    var profile = portal186ResolveCalendarActor_(request, config, { allowFallback: true });
    // CALENDAR_EDIT 권한이 별도 없으면 기존 운영 권한인 CALENDAR_CREATE 기준으로 수정 권한을 인정합니다.
    if (!portal186HasPermission_(profile, 'CALENDAR_EDIT')) portal186PermissionGuard_(profile, 'CALENDAR_CREATE');

    var ss = portal19OpenMaster_(config);
    portal186EnsureCalendarModuleSheets_(ss);
    var sheet = portal19GetSheetOrCreate_(ss, 'PORTAL_CalendarEvents', portal186CalendarEventHeaders_());
    var found = portal193FindCalendarEventRowNumber_(sheet, calendarEventId);
    if (found.rowNumber < 0 || !found.row) throw new Error('수정할 일정을 찾지 못했습니다: ' + calendarEventId);
    var existing = found.row;
    if (!portal189CanViewCalendarEvent_(profile, existing)) throw new Error('해당 일정 수정 권한이 없습니다.');

    var currentStatus = String(existing.eventStatus || '').toUpperCase();
    if (currentStatus === 'LOCKED' || currentStatus === 'COMPLETED' || currentStatus === 'CANCELED' || currentStatus === 'CANCELLED') {
      throw new Error('완료/잠금/취소된 일정은 일반 수정할 수 없습니다: ' + currentStatus);
    }

    var newStart = portal193NormalizeEditDate_(request.startAt, existing.startAt);
    var newEnd = portal193NormalizeEditDate_(request.endAt, existing.endAt);
    var ds = new Date(newStart);
    var de = new Date(newEnd);
    if (newStart && newEnd && !isNaN(ds.getTime()) && !isNaN(de.getTime()) && de.getTime() <= ds.getTime()) {
      throw new Error('종료 일시는 시작 일시보다 뒤여야 합니다.');
    }

    var updates = {
      eventTitle: String(request.eventTitle || existing.eventTitle || '').trim(),
      eventType: String(request.eventType || existing.eventType || 'INTERNAL').trim() || 'INTERNAL',
      eventDescription: String(request.eventDescription || request.description || existing.eventDescription || '').trim(),
      startAt: newStart,
      endAt: newEnd,
      location: String(request.location || existing.location || '').trim(),
      assignedEmployeeId: String(request.assignedEmployeeId || existing.assignedEmployeeId || existing.ownerEmployeeId || profile.employeeId || '').trim(),
      eventId: String(request.eventId || existing.eventId || '').trim(),
      customerId: String(request.customerId || existing.customerId || '').trim(),
      contractId: String(request.contractId || existing.contractId || '').trim(),
      installId: String(request.installId || existing.installId || '').trim(),
      asId: String(request.asId || existing.asId || '').trim(),
      requestId: String(request.requestId || existing.requestId || '').trim(),
      eventStatus: 'UPDATED',
      updatedAt: portal19Now_(),
      updatedBy: profile.employeeId || profile.loginId
    };
    if (!updates.eventTitle) throw new Error('일정 제목을 입력하세요.');
    if (!updates.startAt) throw new Error('시작 일시를 입력하세요.');
    if (!updates.endAt) throw new Error('종료 일시를 입력하세요.');

    portal186SetRowValuesByHeader_(sheet, found.rowNumber, updates);
    portal186AppendProviderLog_(ss, { calendarEventId: calendarEventId }, 'INTERNAL', 'UPDATE_EVENT', 'SUCCESS', '', '', '', 'PORTAL_CalendarEvents 내부 일정 수정 완료', profile);
    try {
      if (typeof portal19AppendAuditLog_ === 'function') {
        portal19AppendAuditLog_('CALENDAR_UPDATE_EVENT', profile.loginId || profile.employeeId || '', calendarEventId, 'SUCCESS', '캘린더 일정 수정 완료', {
          calendarEventId: calendarEventId,
          employeeId: profile.employeeId,
          updatedFields: Object.keys(updates).join(',')
        });
      }
    } catch (auditErr) {}

    result.ok = true;
    result.message = '일정 수정이 완료되었습니다. NAVER/GOOGLE 수정 동기화는 후속 provider update 단계에서 처리합니다.';
    result.calendarEventId = calendarEventId;
    result.eventStatus = 'UPDATED';
    result.updatedBy = updates.updatedBy;
    result.updatedAt = updates.updatedAt;
    result.providerSyncDeferred = true;
    result.event = portal19ClientSafeObject_(Object.assign({}, existing, updates));
  } catch (err) {
    result.ok = false;
    result.message = portal19ErrorMessage_(err);
  }
  return portal19ClientSafeObject_(result);
}

function portal193CalendarEditDebug() {
  var result = {
    ok: true,
    build: 'PORTAL_193_CALENDAR_EDIT_EVENT_LOCK_20260518',
    action: 'portal193CalendarEditDebug',
    message: '캘린더 193 일정 수정 서버 기능 인식 성공',
    checks: {
      updateReady: typeof portal193UpdateCalendarEvent === 'function',
      detailReady: typeof portal189GetCalendarEventDetail === 'function',
      dashboardReady: typeof portal186GetCalendarDashboard === 'function',
      rangeListReady: typeof portal192ListCalendarEvents === 'function',
      logReady: typeof portal186AppendProviderLog_ === 'function'
    },
    generatedAt: Utilities.formatDate(new Date(), Session.getScriptTimeZone() || 'Asia/Seoul', 'yyyy-MM-dd HH:mm:ss')
  };
  Logger.log(JSON.stringify(result, null, 2));
  return result;
}

/*******************************************************
 * PORTAL 199 Calendar Complete Status Engine
 * Build: PORTAL_199_CALENDAR_COMPLETE_CLEAN_FULL_20260518
 * Scope: clean final calendar status transition server functions.
 *******************************************************/
function portal199CalendarStatusLabelMap_() {
  return { REGISTERED:'등록', IN_PROGRESS:'진행중', UPDATED:'수정됨', COMPLETED:'완료', CANCELED:'취소', CANCELLED:'취소', LOCKED:'잠금', PROVIDER_PARTIAL_FAIL:'연동 일부 실패', PROVIDER_FAIL:'연동 실패', INTERNAL_SAVED:'내부 저장' };
}
function portal199NormalizeCalendarStatus_(value) {
  var status = String(value || '').trim().toUpperCase();
  if (status === 'CANCELLED') return 'CANCELED';
  return status;
}
function portal199CalendarAllowedTransitions_() {
  return {
    INTERNAL_SAVED:{REGISTERED:true,PROVIDER_PARTIAL_FAIL:true,PROVIDER_FAIL:true,CANCELED:true},
    PROVIDER_PARTIAL_FAIL:{REGISTERED:true,PROVIDER_FAIL:true,CANCELED:true},
    PROVIDER_FAIL:{REGISTERED:true,PROVIDER_PARTIAL_FAIL:true,CANCELED:true},
    REGISTERED:{IN_PROGRESS:true,UPDATED:true,COMPLETED:true,CANCELED:true,LOCKED:true},
    UPDATED:{IN_PROGRESS:true,COMPLETED:true,CANCELED:true,LOCKED:true},
    IN_PROGRESS:{UPDATED:true,COMPLETED:true,CANCELED:true,LOCKED:true},
    COMPLETED:{}, CANCELED:{}, LOCKED:{}
  };
}
function portal199GetCalendarStatusOptions(request) {
  var result = portal19SafeResult_('portal199GetCalendarStatusOptions');
  try {
    request = request || {};
    var fromStatus = portal199NormalizeCalendarStatus_(request.eventStatus || request.fromStatus || 'REGISTERED') || 'REGISTERED';
    var transitions = portal199CalendarAllowedTransitions_();
    var labels = portal199CalendarStatusLabelMap_();
    var allowed = transitions[fromStatus] || {};
    result.ok = true;
    result.fromStatus = fromStatus;
    result.options = Object.keys(allowed).map(function(status){ return { value: status, label: labels[status] || status }; });
    result.terminal = result.options.length === 0;
    result.message = result.terminal ? '현재 상태에서는 추가 상태변경이 제한됩니다.' : '상태변경 가능 목록 조회 완료';
  } catch (err) {
    result.ok = false;
    result.message = portal19ErrorMessage_(err);
  }
  return portal19ClientSafeObject_(result);
}
function portal199ChangeCalendarEventStatus(request) {
  var result = portal19SafeResult_('portal199ChangeCalendarEventStatus');
  request = request || {};
  try {
    var calendarEventId = String(request.calendarEventId || '').trim();
    var toStatus = portal199NormalizeCalendarStatus_(request.toStatus || request.eventStatus || '');
    var reason = String(request.reason || request.statusReason || '').trim();
    if (!calendarEventId) throw new Error('calendarEventId가 필요합니다.');
    if (!toStatus) throw new Error('변경할 상태값이 필요합니다.');
    var config = portal19GetConfigBundle_();
    var profile = portal186ResolveCalendarActor_(request, config, { allowFallback: true });
    if (!portal186HasPermission_(profile, 'CALENDAR_STATUS')) portal186PermissionGuard_(profile, 'CALENDAR_CREATE');
    var ss = portal19OpenMaster_(config);
    portal186EnsureCalendarModuleSheets_(ss);
    var sheet = portal19GetSheetOrCreate_(ss, 'PORTAL_CalendarEvents', portal186CalendarEventHeaders_());
    var found = portal193FindCalendarEventRowNumber_(sheet, calendarEventId);
    if (found.rowNumber < 0 || !found.row) throw new Error('상태를 변경할 일정을 찾지 못했습니다: ' + calendarEventId);
    var existing = found.row;
    if (!portal189CanViewCalendarEvent_(profile, existing)) throw new Error('해당 일정 상태변경 권한이 없습니다.');
    var fromStatus = portal199NormalizeCalendarStatus_(existing.eventStatus || 'REGISTERED') || 'REGISTERED';
    if (fromStatus === toStatus) throw new Error('이미 같은 상태입니다: ' + toStatus);
    var transitions = portal199CalendarAllowedTransitions_();
    if (!transitions[fromStatus] || !transitions[fromStatus][toStatus]) throw new Error('허용되지 않은 상태전이입니다: ' + fromStatus + ' → ' + toStatus);
    if ((toStatus === 'CANCELED' || toStatus === 'LOCKED') && !reason) throw new Error('취소/잠금 처리에는 사유가 필요합니다.');
    var now = portal19Now_();
    var actor = profile.employeeId || profile.loginId || '';
    portal186SetRowValuesByHeader_(sheet, found.rowNumber, { eventStatus: toStatus, statusReason: reason || ('캘린더 상태 변경: ' + fromStatus + ' → ' + toStatus), updatedAt: now, updatedBy: actor });
    portal186AppendProviderLog_(ss, { calendarEventId: calendarEventId }, 'INTERNAL', 'STATUS_TRANSITION', 'SUCCESS', '', '', '', '캘린더 상태 변경 완료: ' + fromStatus + ' → ' + toStatus + (reason ? ' / 사유: ' + reason : ''), profile);
    try { if (typeof portal19AppendAuditLog_ === 'function') portal19AppendAuditLog_('CALENDAR_STATUS_TRANSITION', profile.loginId || actor, calendarEventId, 'SUCCESS', '캘린더 상태 변경 완료', { calendarEventId: calendarEventId, fromStatus: fromStatus, toStatus: toStatus, reason: reason, employeeId: profile.employeeId }); } catch (auditErr) {}
    result.ok = true;
    result.message = '상태변경이 완료되었습니다.';
    result.calendarEventId = calendarEventId;
    result.fromStatus = fromStatus;
    result.toStatus = toStatus;
    result.eventStatus = toStatus;
    result.updatedAt = now;
    result.updatedBy = actor;
  } catch (err) {
    result.ok = false;
    result.message = portal19ErrorMessage_(err);
  }
  return portal19ClientSafeObject_(result);
}
function portal199CalendarCompleteSelfTest() {
  var result = { ok:true, build:'PORTAL_199_CALENDAR_COMPLETE_CLEAN_FULL_20260518', action:'portal199CalendarCompleteSelfTest', message:'캘린더 완성형 클린 통합 빌드 서버 함수 인식 성공', checks:{ dashboardReady:typeof portal186GetCalendarDashboard === 'function', detailReady:typeof portal189GetCalendarEventDetail === 'function', updateReady:typeof portal193UpdateCalendarEvent === 'function', statusChangeReady:typeof portal199ChangeCalendarEventStatus === 'function', statusOptionsReady:typeof portal199GetCalendarStatusOptions === 'function', providerLogReady:typeof portal186AppendProviderLog_ === 'function', transitionRuleReady:typeof portal199CalendarAllowedTransitions_ === 'function' }, generatedAt:Utilities.formatDate(new Date(), Session.getScriptTimeZone() || 'Asia/Seoul', 'yyyy-MM-dd HH:mm:ss') };
  result.ok = !!(result.checks.dashboardReady && result.checks.detailReady && result.checks.updateReady && result.checks.statusChangeReady && result.checks.statusOptionsReady && result.checks.providerLogReady && result.checks.transitionRuleReady);
  try { var options = portal199GetCalendarStatusOptions({ eventStatus:'REGISTERED' }); result.optionCheckOk = !!(options && options.ok && options.options && options.options.length); } catch (e) { result.optionCheckOk = false; result.optionCheckMessage = e && e.message ? e.message : String(e); }
  Logger.log(JSON.stringify(result, null, 2));
  return portal19ClientSafeObject_(result);
}
