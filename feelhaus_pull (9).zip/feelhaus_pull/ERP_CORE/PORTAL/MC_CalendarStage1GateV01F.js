
/**
 * MAILCENTER_CALENDAR_STAGE1_GATE_V01F_LOG_FIX_20260521
 * Purpose:
 * - Avoid duplicated mcCalendar206CalendarDiagFixOnlyDebug collisions.
 * - Judge stage 1 clone readiness only.
 * - Do not require MailCenter calendar menu/data binding yet.
 * - JS only.
 */

function runMcCalendarStage1GateV01F() {
  var required = [
    'mcCalendar186GetCalendarDashboard',
    'mcCalendar186RunCalendarDashboardDebug',
    'mcCalendar193UpdateCalendarEvent',
    'mcCalendar199ChangeCalendarEventStatus',
    'mcCalendar199GetCalendarStatusOptions',
    'mcCalendar199CalendarCompleteSelfTest',
    'mcCalendar187GetCalendarEventDetail'
  ];

  var checks = {};
  var missing = [];

  required.forEach(function(name) {
    var ready = false;
    try { ready = typeof this[name] === 'function'; } catch (ignoreThis) {}
    try { ready = ready || typeof globalThis[name] === 'function'; } catch (ignoreGlobal) {}
    checks[name] = ready;
    if (!ready) missing.push(name);
  });

  var selfTest = {};
  try {
    if (checks.mcCalendar199CalendarCompleteSelfTest) {
      selfTest = mcCalendar199CalendarCompleteSelfTest({ noWriteMode: true, dryRun: true }) || {};
    } else {
      selfTest = { ok: false, message: 'selfTest function missing' };
    }
  } catch (err) {
    selfTest = { ok: false, error: String(err && err.message ? err.message : err) };
  }

  var dashboardProbe = {};
  try {
    if (checks.mcCalendar186GetCalendarDashboard) {
      dashboardProbe = mcCalendar186GetCalendarDashboard({ noWriteMode: true, limit: 2 }) || {};
    } else {
      dashboardProbe = { ok: false, message: 'dashboard function missing' };
    }
  } catch (errDash) {
    dashboardProbe = { ok: false, error: String(errDash && errDash.message ? errDash.message : errDash) };
  }

  var statusProbe = {};
  try {
    if (checks.mcCalendar199GetCalendarStatusOptions) {
      statusProbe = mcCalendar199GetCalendarStatusOptions({ noWriteMode: true }) || {};
    } else {
      statusProbe = { optionsOk: false, message: 'status option function missing' };
    }
  } catch (errStatus) {
    statusProbe = { optionsOk: false, error: String(errStatus && errStatus.message ? errStatus.message : errStatus) };
  }

  var stage1Checks = {
    coreFunctionReady: missing.length === 0,
    selfTestReady: !!(selfTest && (
      selfTest.ok === true ||
      (
        selfTest.dashboardReady === true &&
        selfTest.detailReady === true &&
        selfTest.updateReady === true &&
        selfTest.statusChangeReady === true &&
        selfTest.statusOptionsReady === true
      )
    )),
    dashboardCallable: checks.mcCalendar186GetCalendarDashboard === true,
    statusOptionsCallable: checks.mcCalendar199GetCalendarStatusOptions === true,
    detailReadyCorrected: checks.mcCalendar187GetCalendarEventDetail === true,
    noWriteMode: true,
    uiChangedByThisBuild: false,
    writeChangedByThisBuild: false,
    mailCenterMenuBindingRequired: false,
    calendarDataRequiredAtStage1: false
  };

  var warnings = [];
  if (dashboardProbe && dashboardProbe.ok === false) {
    warnings.push('dashboard returned empty/not-ready. Accepted in stage 1; MailCenter menu/data binding is stage 2.');
  }
  if (statusProbe && statusProbe.optionsOk === false) {
    warnings.push('status options returned empty/not-ready. Accepted in stage 1; MailCenter calendar status mapping is stage 2.');
  }
  if (selfTest && selfTest.optionCheckOk === false) {
    warnings.push('selfTest optionCheckOk=false. Accepted in stage 1 because server function recognition passed.');
  }

  var ok = (
    stage1Checks.coreFunctionReady &&
    stage1Checks.selfTestReady &&
    stage1Checks.dashboardCallable &&
    stage1Checks.statusOptionsCallable &&
    stage1Checks.detailReadyCorrected
  );

  var result = {
    ok: ok,
    build: 'MAILCENTER_CALENDAR_STAGE1_GATE_V01F_LOG_FIX_20260521',
    action: 'runMcCalendarStage1GateV01F',
    message: ok
      ? 'MailCenter 캘린더 1단계 Core Clone Gate 통과'
      : 'MailCenter 캘린더 1단계 Core Clone Gate 확인 필요',
    generatedAt: Utilities.formatDate(new Date(), Session.getScriptTimeZone(), 'yyyy-MM-dd HH:mm:ss'),
    stage: '1_CORE_CLONE_GATE',
    checks: checks,
    stage1Checks: stage1Checks,
    selfTest: selfTest,
    dashboardProbe: dashboardProbe,
    statusProbe: statusProbe,
    warnings: warnings,
    missing: missing,
    nextStage: ok ? 'MAILCENTER_CALENDAR_LINK_V01' : ''
  };

  Logger.log(JSON.stringify(result, null, 2));
  return result;
}
