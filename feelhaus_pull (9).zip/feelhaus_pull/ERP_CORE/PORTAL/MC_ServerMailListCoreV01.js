/**
 * FEELHAUS MailCenter Server Mail List Core V01
 * Build: MAILCENTER_SERVER_MAIL_LIST_FAST_LINK_V01_20260521
 * Purpose:
 * - Gmail 서버 메일 목록 빠른 로딩
 * - 받은메일/보낸메일/별표/읽지않음/검색 필터
 * - 작성/로그/자료함/템플릿 화면 연결용 메타데이터 제공
 * Guard:
 * - 발송 Core / 첨부 Core / Backup Core 미수정
 */

var MC_SERVER_MAIL_LIST_CORE_V01_BUILD = 'MC_MAIL_LIST_FAST_ROW_NO_BODY_CACHE_V01_20260527';
var MC_SERVER_MAIL_LIST_CORE_V01_SETUP_DB_ID = '17VMSpgSZCvIrUlgcw8yCNcnl8WQWo2IcRf5tDCcuJGM';
var MC_SERVER_MAIL_LIST_CORE_V01_CONFIG_SHEET = 'SystemConfig';
var MC_SERVER_MAIL_LIST_CORE_V01_DEFAULT_LIMIT = 20;
var MC_SERVER_MAIL_LIST_CORE_V01_MAX_LIMIT = 50;
var MC_SERVER_MAIL_LIST_CORE_V01_LIST_CACHE_SECONDS = 600;
var MC_SERVER_MAIL_LIST_CORE_V01_DETAIL_CACHE_SECONDS = 180;
var MC_SERVER_MAIL_LIST_CORE_V01_ACCOUNTS_CACHE_SECONDS = 300;

function runMcServerMailListV01Smoke() {
  var result = {
    ok: false,
    build: MC_SERVER_MAIL_LIST_CORE_V01_BUILD,
    action: 'runMcServerMailListV01Smoke',
    generatedAt: mcServerMailListV01Now_(),
    message: '',
    checks: []
  };

  try {
    result.checks.push({ key: 'HandleGetReady', ok: typeof mcServerMailListShellV01HandleGet === 'function', message: '서버 메일 목록 화면 핸들러 확인' });
    result.checks.push({ key: 'InitialDataReady', ok: typeof mcServerMailListV01GetInitialData === 'function', message: '초기 데이터 함수 확인' });
    result.checks.push({ key: 'ListDataReady', ok: typeof mcServerMailListV01List === 'function', message: 'Gmail 서버 목록 조회 함수 확인' });
    result.checks.push({ key: 'ThreadDetailReady', ok: typeof mcServerMailListV01GetThreadDetail === 'function', message: '스레드 상세 조회 함수 확인' });
    result.checks.push({ key: 'MasterHelperReady', ok: typeof mcServerMailListV01OpenMaster_ === 'function', message: 'SystemConfig/MASTER 연결 헬퍼 확인' });
    result.checks.push({ key: 'GmailAppReady', ok: typeof GmailApp !== 'undefined', message: 'GmailApp 서비스 접근 확인' });
    result.ok = result.checks.every(function(c) { return !!c.ok; });
    result.message = result.ok ? 'MailCenter Server Mail List Fast Link V01 준비 완료' : 'MailCenter Server Mail List Fast Link V01 점검 필요';
  } catch (err) {
    result.ok = false;
    result.message = String(err && err.message ? err.message : err);
  }

  Logger.log('JSON_COMPACT_RESULT: ' + JSON.stringify(result));
  return result;
}

function mcServerMailListV01GetInitialData() {
  var result = {
    ok: false,
    build: MC_SERVER_MAIL_LIST_CORE_V01_BUILD,
    action: 'mcServerMailListV01GetInitialData',
    generatedAt: mcServerMailListV01Now_(),
    message: '',
    userEmail: '',
    accounts: [],
    quickFilters: mcServerMailListV01QuickFilters_(),
    links: mcServerMailListV01BuildLinks_(),
    performance: {
      mode: 'initial-shell-first',
      accountsCacheSeconds: MC_SERVER_MAIL_LIST_CORE_V01_ACCOUNTS_CACHE_SECONDS
    }
  };

  try {
    result.userEmail = Session.getActiveUser().getEmail() || '';
    result.accounts = mcServerMailListV01GetAccountsCached_();
    result.ok = true;
    result.message = '서버 메일 목록 초기 화면 준비 완료';
  } catch (err) {
    result.ok = false;
    result.message = String(err && err.message ? err.message : err);
  }

  return result;
}

function mcServerMailListV01List(payload) {
  var started = new Date().getTime();
  var result = {
    ok: false,
    build: MC_SERVER_MAIL_LIST_CORE_V01_BUILD,
    action: 'mcServerMailListV01List',
    generatedAt: mcServerMailListV01Now_(),
    message: '',
    query: '',
    start: 0,
    limit: MC_SERVER_MAIL_LIST_CORE_V01_DEFAULT_LIMIT,
    count: 0,
    elapsedMs: 0,
    cacheHit: false,
    engine: 'FAST_ENGINE_V02_BATCH_MESSAGES',
    cacheSeconds: MC_SERVER_MAIL_LIST_CORE_V01_LIST_CACHE_SECONDS,
    threads: []
  };

  try {
    payload = payload || {};
    var start = Math.max(0, parseInt(payload.start || 0, 10) || 0);
    var limit = Math.min(MC_SERVER_MAIL_LIST_CORE_V01_MAX_LIMIT, Math.max(1, parseInt(payload.limit || 10, 10) || 10));
    var query = mcServerMailListV01BuildQuery_(payload);
    var cacheKey = mcServerMailListV01CacheKey_('listV02', { query: query, start: start, limit: limit });

    if (!payload.forceRefresh) {
      var cached = mcServerMailListV01CacheGet_(cacheKey);
      if (cached && cached.ok) {
        cached.generatedAt = mcServerMailListV01Now_();
        cached.elapsedMs = new Date().getTime() - started;
        cached.cacheHit = true;
        cached.engine = 'FAST_ENGINE_V02_CACHE';
        cached.message = '캐시된 메일 목록을 빠르게 표시했습니다.';
        return cached;
      }
    }

    var threads = GmailApp.search(query, start, limit);
    var messageMatrix = [];
    try {
      messageMatrix = threads.length ? GmailApp.getMessagesForThreads(threads) : [];
    } catch (batchErr) {
      messageMatrix = [];
    }

    result.query = query;
    result.start = start;
    result.limit = limit;
    result.threads = threads.map(function(thread, idx) {
      return mcServerMailListV01ThreadToRowFast_(thread, messageMatrix[idx] || []);
    });
    result.count = result.threads.length;
    result.elapsedMs = new Date().getTime() - started;
    result.ok = true;
    result.message = result.count ? '서버 메일 목록 V02 빠른 조회 완료' : '조건에 맞는 메일이 없습니다.';
    mcServerMailListV01CachePut_(cacheKey, result, MC_SERVER_MAIL_LIST_CORE_V01_LIST_CACHE_SECONDS);
  } catch (err) {
    result.ok = false;
    result.elapsedMs = new Date().getTime() - started;
    result.message = String(err && err.message ? err.message : err);
  }

  return result;
}

function mcServerMailListV01GetThreadDetail(payload) {
  var started = new Date().getTime();
  var result = {
    ok: false,
    build: MC_SERVER_MAIL_LIST_CORE_V01_BUILD,
    action: 'mcServerMailListV01GetThreadDetail',
    generatedAt: mcServerMailListV01Now_(),
    message: '',
    threadId: '',
    threadUrl: '',
    subject: '',
    elapsedMs: 0,
    cacheHit: false,
    messages: []
  };

  try {
    payload = payload || {};
    var threadId = String(payload.threadId || '').trim();
    if (!threadId) throw new Error('threadId 값이 필요합니다.');

    var cacheKey = mcServerMailListV01CacheKey_('detail', { threadId: threadId });
    if (!payload.forceRefresh) {
      var cached = mcServerMailListV01CacheGet_(cacheKey);
      if (cached && cached.ok) {
        cached.generatedAt = mcServerMailListV01Now_();
        cached.elapsedMs = new Date().getTime() - started;
        cached.cacheHit = true;
        cached.message = '캐시된 메일 상세를 빠르게 표시했습니다.';
        return cached;
      }
    }

    var thread = GmailApp.getThreadById(threadId);
    if (!thread) throw new Error('Gmail 스레드를 찾지 못했습니다: ' + threadId);

    var messages = thread.getMessages();
    result.threadId = threadId;
    result.threadUrl = 'https://mail.google.com/mail/u/0/#inbox/' + encodeURIComponent(threadId);
    result.subject = thread.getFirstMessageSubject ? thread.getFirstMessageSubject() : '';
    result.messages = messages.slice(Math.max(0, messages.length - 10)).map(function(m) {
      var plain = '';
      var html = '';
      var attachments = [];
      try { plain = String(m.getPlainBody ? (m.getPlainBody() || '') : ''); } catch (ignore) { plain = ''; }
      try { html = String(m.getBody ? (m.getBody() || '') : ''); } catch (ignore2) { html = ''; }
      try {
        attachments = (m.getAttachments ? m.getAttachments({ includeInlineImages: false, includeAttachments: true }) : []).map(function(a, idx) {
          return {
            index: idx + 1,
            name: a.getName ? (a.getName() || ('attachment-' + (idx + 1))) : ('attachment-' + (idx + 1)),
            contentType: a.getContentType ? (a.getContentType() || '') : '',
            sizeBytes: 0,
            sizeLabel: ''
          };
        });
      } catch (ignore4) {
        attachments = [];
      }

      if (plain.length > 20000) plain = plain.substring(0, 20000) + '\n\n...';
      if (html.length > 80000) html = html.substring(0, 80000) + '<p>...</p>';

      return {
        messageId: m.getId ? m.getId() : '',
        from: m.getFrom ? m.getFrom() : '',
        to: m.getTo ? m.getTo() : '',
        cc: m.getCc ? m.getCc() : '',
        bcc: m.getBcc ? m.getBcc() : '',
        date: m.getDate ? mcServerMailListV01FormatDate_(m.getDate()) : '',
        subject: m.getSubject ? m.getSubject() : '',
        plainBody: plain,
        htmlBody: mcServerMailListV01SanitizeHtml_(html),
        snippet: plain.replace(/\s+/g, ' ').trim().substring(0, 700),
        attachmentCount: attachments.length,
        attachments: attachments
      };
    });
    result.elapsedMs = new Date().getTime() - started;
    result.ok = true;
    result.message = '스레드 상세 HTML/첨부 조회 완료';
    mcServerMailListV01CachePut_(cacheKey, result, MC_SERVER_MAIL_LIST_CORE_V01_DETAIL_CACHE_SECONDS);
  } catch (err) {
    result.ok = false;
    result.elapsedMs = new Date().getTime() - started;
    result.message = String(err && err.message ? err.message : err);
  }

  return result;
}


function mcServerMailListV01ApplyAction(payload) {
  var result = {
    ok: false,
    build: MC_SERVER_MAIL_LIST_CORE_V01_BUILD,
    action: 'mcServerMailListV01ApplyAction',
    generatedAt: mcServerMailListV01Now_(),
    message: '',
    actionType: '',
    threadId: '',
    updated: {}
  };

  try {
    payload = payload || {};
    var threadId = String(payload.threadId || '').trim();
    var messageId = String(payload.messageId || '').trim();
    var actionType = String(payload.actionType || '').trim();
    if (!threadId) throw new Error('threadId 값이 필요합니다.');
    if (!actionType) throw new Error('actionType 값이 필요합니다.');

    var thread = GmailApp.getThreadById(threadId);
    if (!thread) throw new Error('Gmail 스레드를 찾지 못했습니다: ' + threadId);

    result.threadId = threadId;
    result.messageId = messageId;
    result.actionType = actionType;

    if (actionType === 'markRead') {
      mcServerMailListV01SetReadFast_(thread, messageId, true);
      result.updated.unread = false;
      result.message = '읽음 처리 완료';
    } else if (actionType === 'markUnread') {
      mcServerMailListV01SetReadFast_(thread, messageId, false);
      result.updated.unread = true;
      result.message = '안읽음 처리 완료';
    } else if (actionType === 'star') {
      mcServerMailListV01SetStarFast_(thread, messageId, true);
      result.updated.starred = true;
      result.message = '별표 처리 완료';
    } else if (actionType === 'unstar') {
      mcServerMailListV01SetStarFast_(thread, messageId, false);
      result.updated.starred = false;
      result.message = '별표 해제 완료';
    } else {
      throw new Error('허용되지 않은 actionType 입니다: ' + actionType);
    }

    result.ok = true;
  } catch (err) {
    result.ok = false;
    result.message = String(err && err.message ? err.message : err);
  }

  return result;
}



function mcServerMailListV01GetTargetMessageFast_(thread, messageId) {
  var target = null;

  if (messageId) {
    try { target = GmailApp.getMessageById(messageId); } catch (ignore) { target = null; }
  }

  if (!target) {
    var messages = [];
    try { messages = thread.getMessages(); } catch (err) { messages = []; }
    if (messages.length) target = messages[messages.length - 1];
  }

  if (!target) throw new Error('처리할 Gmail 메시지를 찾지 못했습니다.');
  return target;
}

function mcServerMailListV01SetReadFast_(thread, messageId, markRead) {
  var target = mcServerMailListV01GetTargetMessageFast_(thread, messageId);
  if (markRead) {
    if (target.markRead) target.markRead();
    else throw new Error('현재 Apps Script GmailMessage.markRead()를 사용할 수 없습니다.');
  } else {
    if (target.markUnread) target.markUnread();
    else throw new Error('현재 Apps Script GmailMessage.markUnread()를 사용할 수 없습니다.');
  }
  return true;
}

function mcServerMailListV01SetStarFast_(thread, messageId, enabled) {
  var target = mcServerMailListV01GetTargetMessageFast_(thread, messageId);
  if (enabled) {
    if (target.star) target.star();
    else throw new Error('현재 Apps Script GmailMessage.star()를 사용할 수 없습니다.');
  } else {
    if (target.unstar) target.unstar();
    else throw new Error('현재 Apps Script GmailMessage.unstar()를 사용할 수 없습니다.');
  }
  return true;
}


function mcServerMailListV01SetThreadStar_(thread, enabled) {
  var messages = [];
  try { messages = thread.getMessages(); } catch (err) { messages = []; }
  if (!messages.length) return false;

  var target = messages[messages.length - 1];
  if (enabled) {
    if (target.star) target.star();
    else throw new Error('현재 Apps Script GmailMessage.star()를 사용할 수 없습니다.');
  } else {
    if (target.unstar) target.unstar();
    else throw new Error('현재 Apps Script GmailMessage.unstar()를 사용할 수 없습니다.');
  }
  return true;
}



function mcServerMailListV01SaveRecord(payload) {
  var result = {
    ok: false,
    build: MC_SERVER_MAIL_LIST_CORE_V01_BUILD,
    action: 'mcServerMailListV01SaveRecord',
    generatedAt: mcServerMailListV01Now_(),
    message: '',
    recordType: '',
    recordId: '',
    threadId: '',
    messageId: '',
    rfcMessageId: ''
  };

  try {
    payload = payload || {};
    var recordType = String(payload.recordType || '').trim();
    var threadId = String(payload.threadId || '').trim();
    var messageId = String(payload.messageId || '').trim();

    if (!recordType) throw new Error('recordType 값이 필요합니다.');
    if (['CONSULT', 'SALES'].indexOf(recordType) < 0) throw new Error('허용되지 않은 recordType 입니다: ' + recordType);

    var thread = null;
    var message = null;

    if (messageId) {
      try { message = GmailApp.getMessageById(messageId); } catch (ignoreMsg) { message = null; }
      if (message) {
        try { thread = message.getThread(); } catch (ignoreThreadFromMsg) {}
        try { if (!threadId && thread) threadId = thread.getId(); } catch (ignoreThreadId) {}
      }
    }

    if (!thread && threadId) {
      try { thread = GmailApp.getThreadById(threadId); } catch (ignoreThread) { thread = null; }
    }

    if (!thread && !message) throw new Error('저장할 Gmail 원문 정보를 찾지 못했습니다. threadId/messageId를 확인하세요.');

    if (!message && thread) {
      var messages = [];
      try { messages = thread.getMessages(); } catch (ignoreMessages) { messages = []; }
      if (messages.length) message = messages[messages.length - 1];
    }

    if (thread && !threadId) {
      try { threadId = thread.getId(); } catch (ignoreThreadId2) {}
    }
    if (message && !messageId) {
      try { messageId = message.getId(); } catch (ignoreMsgId2) {}
    }

    var now = mcServerMailListV01Now_();
    var actor = '';
    try { actor = Session.getActiveUser().getEmail() || ''; } catch (ignoreActor) {}

    var recordId = 'MAILREC-' + Utilities.formatDate(new Date(), Session.getScriptTimeZone(), 'yyyyMMddHHmmss') + '-' + Math.floor(Math.random() * 9000 + 1000);

    var subject = String(payload.subject || '').trim();
    var fromEmail = String(payload.from || payload.fromEmail || '').trim();
    var toEmail = String(payload.to || payload.toEmail || '').trim();
    var mailDate = String(payload.date || payload.lastDate || '').trim();
    var memo = String(payload.memo || '').trim();
    var snippet = String(payload.snippet || '').trim();
    var rfcMessageId = '';

    if (message) {
      try { subject = message.getSubject() || subject; } catch (ignoreSubj) {}
      try { fromEmail = message.getFrom() || fromEmail; } catch (ignoreFrom) {}
      try { toEmail = message.getTo() || toEmail; } catch (ignoreTo) {}
      try { mailDate = mcServerMailListV01FormatDate_(message.getDate()) || mailDate; } catch (ignoreDate) {}
      try { snippet = String(message.getPlainBody() || '').replace(/\s+/g, ' ').trim().substring(0, 180) || snippet; } catch (ignoreSnippet) {}
      try { rfcMessageId = String(message.getHeader('Message-ID') || '').trim(); } catch (ignoreHeader1) {}
      if (!rfcMessageId) {
        try { rfcMessageId = String(message.getHeader('Message-Id') || '').trim(); } catch (ignoreHeader2) {}
      }
    }

    var detail = {
      recordId: recordId,
      recordType: recordType,
      source: 'MailCenterServerMailListV01',
      threadId: threadId,
      messageId: messageId,
      rfcMessageId: rfcMessageId,
      fromEmail: fromEmail,
      toEmail: toEmail,
      subject: subject,
      mailDate: mailDate,
      memo: memo,
      snippet: snippet,
      savedAt: now,
      savedAtMs: new Date().getTime(),
      savedBy: actor
    };

    mcServerMailListV01AppendAuditRecord_(detail);

    result.ok = true;
    result.recordType = recordType;
    result.recordId = recordId;
    result.threadId = threadId;
    result.messageId = messageId;
    result.rfcMessageId = rfcMessageId;
    result.message = (recordType === 'CONSULT' ? '상담기록' : '영업기록') + ' 저장 완료';
  } catch (err) {
    result.ok = false;
    result.message = String(err && err.message ? err.message : err);
  }

  return result;
}

function mcServerMailListV01AppendAuditRecord_(detail) {
  var ss = mcServerMailListV01OpenMaster_();
  var sh = ss.getSheetByName('MailCenter_AuditLogs');
  if (!sh) throw new Error('MailCenter_AuditLogs 시트를 찾지 못했습니다.');

  var lastCol = Math.max(1, sh.getLastColumn());
  var headers = sh.getRange(1, 1, 1, lastCol).getValues()[0].map(function(h) { return String(h || '').trim(); });
  var row = new Array(headers.length);
  for (var i = 0; i < row.length; i++) row[i] = '';

  function put(names, value) {
    var done = false;
    for (var n = 0; n < names.length; n++) {
      var idx = headers.indexOf(names[n]);
      if (idx >= 0) {
        row[idx] = value;
        done = true;
      }
    }
    return done;
  }

  function firstEmptyIndex(preferredStart) {
    preferredStart = preferredStart || 0;
    for (var i = preferredStart; i < row.length; i++) {
      if (row[i] === '') return i;
    }
    return -1;
  }

  var typeLabel = detail.recordType === 'SALES' ? '영업기록' : '상담기록';
  var json = JSON.stringify(detail);

  put(['logId', 'auditLogId', 'recordId'], detail.recordId);
  put(['createdAt', 'loggedAt', 'timestamp'], detail.savedAt);
  put(['createdBy', 'actorEmail', 'userEmail', 'updatedBy'], detail.savedBy);
  put(['logType', 'actionType', 'action', 'eventType'], 'MAIL_RECORD_SAVE');
  put(['targetType', 'entityType', 'sourceType'], 'MAIL_THREAD');
  put(['targetId', 'threadId'], detail.threadId);
  put(['messageId'], detail.messageId);
  put(['status'], 'SAVED');
  put(['statusReason', 'message', 'description', 'detail'], typeLabel + ' 저장: ' + (detail.subject || '(제목 없음)'));
  put(['memo', 'note'], detail.memo);
  put(['fromEmail'], detail.fromEmail);
  put(['toEmail'], detail.toEmail);
  put(['subject'], detail.subject);
  put(['mailDate'], detail.mailDate);
  var payloadWritten = put(['payload', 'json', 'afterJson'], json);

  // Existing AuditLogs schema may not have mail-specific columns.
  // Fill still-empty generic columns in a deterministic order without changing headers.
  var fallbackValues = [
    detail.recordId,
    detail.savedAt,
    detail.savedBy,
    'MAIL_RECORD_SAVE',
    typeLabel,
    detail.threadId,
    detail.messageId,
    detail.fromEmail,
    detail.toEmail,
    detail.subject,
    detail.mailDate,
    detail.memo,
    detail.snippet,
    json
  ];

  for (var f = 0; f < fallbackValues.length; f++) {
    var idx = firstEmptyIndex(0);
    if (idx < 0) break;
    row[idx] = fallbackValues[f];
  }

  sh.appendRow(row);

  // Store the full JSON in a note on the first cell.
  // This keeps lookup recoverable even when AuditLogs headers are generic.
  try {
    var newRow = sh.getLastRow();
    sh.getRange(newRow, 1).setNote('MAIL_RECORD_JSON:' + json);
  } catch (noteErr) {}

  return true;
}



function mcServerMailListV01GetSavedRecords(payload) {
  var started = new Date().getTime();
  var result = {
    ok: false,
    build: MC_SERVER_MAIL_LIST_CORE_V01_BUILD,
    action: 'mcServerMailListV01GetSavedRecords',
    generatedAt: mcServerMailListV01Now_(),
    message: '',
    elapsedMs: 0,
    count: 0,
    records: []
  };

  try {
    payload = payload || {};
    var limit = Math.min(100, Math.max(1, parseInt(payload.limit || 30, 10) || 30));
    var keyword = String(payload.keyword || '').trim().toLowerCase();
    var recordType = String(payload.recordType || '').trim();
    // Exact linkage filters for Calendar detail.
    // threadId is the mail-level parent key. recordId is only one child row key.
    var filterThreadId = String(payload.threadId || payload.mailGroupId || '').trim();
    var filterMessageId = String(payload.messageId || '').trim();
    var filterRecordId = String(payload.recordId || payload.requestId || '').trim();
    var filterRfcMessageId = String(payload.rfcMessageId || '').trim();

    var ss = mcServerMailListV01OpenMaster_();
    var sh = ss.getSheetByName('MailCenter_AuditLogs');
    if (!sh) throw new Error('MailCenter_AuditLogs 시트를 찾지 못했습니다.');

    var lastRow = sh.getLastRow();
    var lastCol = sh.getLastColumn();
    if (lastRow < 2 || lastCol < 1) {
      result.ok = true;
      result.message = '저장된 메일 기록이 없습니다.';
      return result;
    }

    var headers = sh.getRange(1, 1, 1, lastCol).getValues()[0].map(function(h) { return String(h || '').trim(); });
    var values = sh.getRange(2, 1, lastRow - 1, lastCol).getValues();
    var notes = [];
    try { notes = sh.getRange(2, 1, lastRow - 1, 1).getNotes(); } catch (ignoreNotes) { notes = []; }

    function getCell(row, names) {
      for (var i = 0; i < names.length; i++) {
        var idx = headers.indexOf(names[i]);
        if (idx >= 0) return row[idx];
      }
      return '';
    }

    function safeString(v) {
      if (v instanceof Date) {
        try { return Utilities.formatDate(v, Session.getScriptTimeZone(), 'yyyy-MM-dd HH:mm:ss'); } catch (ignoreDate) {}
      }
      return String(v || '');
    }

    function parseJsonText(raw) {
      if (!raw) return {};
      raw = String(raw);
      if (raw.indexOf('MAIL_RECORD_JSON:') === 0) raw = raw.substring('MAIL_RECORD_JSON:'.length);
      try { return JSON.parse(raw); } catch (err) { return {}; }
    }

    function parsePayload(row, rowIndex) {
      var raw = getCell(row, ['payload', 'json', 'afterJson']);
      var parsed = parseJsonText(raw);
      if (parsed && parsed.recordId) return parsed;

      var note = notes[rowIndex] && notes[rowIndex][0] ? notes[rowIndex][0] : '';
      parsed = parseJsonText(note);
      if (parsed && parsed.recordId) return parsed;

      return {};
    }

    var out = [];
    for (var r = values.length - 1; r >= 0; r--) {
      var row = values[r];
      var payloadJson = parsePayload(row, r);
      var rowText = row.map(safeString).join(' ');
      var actionType = String(getCell(row, ['logType', 'actionType', 'action', 'eventType']) || '').trim();
      var rowHasMailRecord = rowText.indexOf('MAIL_RECORD_SAVE') >= 0 || rowText.indexOf('상담기록') >= 0 || rowText.indexOf('영업기록') >= 0;
      var fromPayload = payloadJson && payloadJson.source === 'MailCenterServerMailListV01';
      var isMailRecord = actionType === 'MAIL_RECORD_SAVE' || fromPayload || !!payloadJson.recordId || rowHasMailRecord;
      if (!isMailRecord) continue;

      var c = row.map(safeString);
      var fallbackType = c[4] === '영업기록' ? 'SALES' : 'CONSULT';

      var item = {
        recordId: String(payloadJson.recordId || getCell(row, ['logId', 'auditLogId', 'recordId']) || c[0] || ''),
        recordType: String(payloadJson.recordType || fallbackType || ''),
        recordTypeLabel: (payloadJson.recordType || fallbackType) === 'SALES' ? '영업기록' : '상담기록',
        threadId: String(payloadJson.threadId || getCell(row, ['targetId', 'threadId']) || c[5] || ''),
        messageId: String(payloadJson.messageId || getCell(row, ['messageId']) || c[6] || ''),
        rfcMessageId: String(payloadJson.rfcMessageId || getCell(row, ['rfcMessageId']) || ''),
        fromEmail: String(payloadJson.fromEmail || getCell(row, ['fromEmail']) || c[7] || ''),
        toEmail: String(payloadJson.toEmail || getCell(row, ['toEmail']) || c[8] || ''),
        subject: String(payloadJson.subject || getCell(row, ['subject']) || c[9] || ''),
        mailDate: String(payloadJson.mailDate || getCell(row, ['mailDate']) || c[10] || ''),
        memo: String(payloadJson.memo || getCell(row, ['memo', 'note']) || c[11] || ''),
        savedAt: String(payloadJson.savedAt || getCell(row, ['createdAt', 'loggedAt', 'timestamp']) || c[1] || ''),
        savedAtMs: Number(payloadJson.savedAtMs || 0),
        savedBy: String(payloadJson.savedBy || getCell(row, ['createdBy', 'actorEmail', 'userEmail', 'updatedBy']) || c[2] || ''),
        snippet: String(payloadJson.snippet || c[12] || ''),
        rowNo: r + 2
      };

      if (!item.subject) item.subject = '(제목 없음)';
      if (recordType && item.recordType !== recordType) continue;

      // Calendar must never use loose keyword matching as the primary key.
      // Apply exact parent/child filters before optional keyword filtering.
      if (filterThreadId && item.threadId !== filterThreadId) continue;
      if (filterMessageId && item.messageId !== filterMessageId) continue;
      if (filterRecordId && item.recordId !== filterRecordId) continue;
      if (filterRfcMessageId && item.rfcMessageId !== filterRfcMessageId) continue;

      if (keyword) {
        var bag = [
          item.recordId, item.recordType, item.recordTypeLabel, item.threadId, item.messageId, item.rfcMessageId,
          item.fromEmail, item.toEmail, item.subject, item.memo, item.savedBy, item.snippet
        ].join(' ').toLowerCase();
        if (bag.indexOf(keyword) < 0) continue;
      }

      out.push(item);
    }

    out.sort(function(a, b) {
      var am = Number(a.savedAtMs || 0);
      var bm = Number(b.savedAtMs || 0);
      if (am && bm && am !== bm) return bm - am;
      return Number(b.rowNo || 0) - Number(a.rowNo || 0);
    });

    out = out.slice(0, limit);

    result.records = out;
    result.count = out.length;
    result.query = {
      threadId: filterThreadId,
      messageId: filterMessageId,
      recordId: filterRecordId,
      rfcMessageId: filterRfcMessageId,
      recordType: recordType,
      keyword: keyword
    };
    result.elapsedMs = new Date().getTime() - started;
    result.ok = true;
    result.message = out.length ? '메일 저장기록 조회 완료' : '조건에 맞는 저장기록이 없습니다.';
  } catch (err) {
    result.ok = false;
    result.elapsedMs = new Date().getTime() - started;
    result.message = String(err && err.message ? err.message : err);
  }

  return result;
}

function mcServerMailListV01BuildQuery_(payload) {
  payload = payload || {};
  var box = String(payload.box || 'inbox').trim();
  var keyword = String(payload.keyword || '').trim();
  var unreadOnly = String(payload.unreadOnly || '') === 'true' || payload.unreadOnly === true;
  var hasAttachment = String(payload.hasAttachment || '') === 'true' || payload.hasAttachment === true;
  var days = parseInt(payload.days || 30, 10) || 30;
  if (days < 1) days = 30;
  if (days > 365) days = 365;

  var parts = [];
  if (box === 'sent') parts.push('in:sent');
  else if (box === 'starred') parts.push('is:starred');
  else if (box === 'all') parts.push('in:anywhere');
  else if (box === 'important') parts.push('is:important');
  else parts.push('in:inbox');

  parts.push('newer_than:' + days + 'd');
  if (unreadOnly) parts.push('is:unread');
  if (hasAttachment) parts.push('has:attachment');
  if (keyword) parts.push(mcServerMailListV01SanitizeQuery_(keyword));
  return parts.join(' ');
}

function mcServerMailListV01ThreadToRow_(thread) {
  var messages = [];
  try { messages = thread.getMessages(); } catch (ignore) { messages = []; }
  return mcServerMailListV01ThreadToRowFast_(thread, messages);
}

function mcServerMailListV01ThreadToRowFast_(thread, messages) {
  messages = messages || [];
  var last = messages.length ? messages[messages.length - 1] : null;
  var first = messages.length ? messages[0] : null;

  var from = '';
  var to = '';
  var subject = '';
  try { subject = thread.getFirstMessageSubject ? thread.getFirstMessageSubject() : ''; } catch (ignoreSubject) { subject = ''; }
  try { if (!subject && last && last.getSubject) subject = last.getSubject() || ''; } catch (ignoreLastSubject) {}
  try { from = last && last.getFrom ? last.getFrom() : ''; } catch (ignoreFrom) { from = ''; }
  try { to = last && last.getTo ? last.getTo() : ''; } catch (ignoreTo) { to = ''; }

  var threadId = thread.getId();
  var messageCount = messages.length;
  var lastDate = '';
  try { lastDate = thread.getLastMessageDate ? mcServerMailListV01FormatDate_(thread.getLastMessageDate()) : ''; } catch (ignoreDate) { lastDate = ''; }
  try { if (!lastDate && last && last.getDate) lastDate = mcServerMailListV01FormatDate_(last.getDate()); } catch (ignoreLastDate) {}

  var hasAttachmentHint = false;
  try { hasAttachmentHint = /첨부|attached|attachment/i.test(subject || ''); } catch (ignoreAttach) { hasAttachmentHint = false; }

  var unread = false;
  var starred = false;
  try { unread = thread.hasUnreadMessages ? thread.hasUnreadMessages() : false; } catch (ignoreUnread) {}
  try { starred = thread.hasStarredMessages ? thread.hasStarredMessages() : false; } catch (ignoreStar) {}

  return {
    threadId: threadId,
    messageId: last && last.getId ? last.getId() : '',
    subject: subject || '(제목 없음)',
    from: from,
    to: to,
    lastDate: lastDate,
    firstDate: first && first.getDate ? mcServerMailListV01FormatDate_(first.getDate()) : '',
    messageCount: messageCount,
    attachmentCount: 0,
    hasAttachmentHint: hasAttachmentHint,
    unread: unread,
    starred: starred,
    important: false,
    labels: [],
    snippet: subject || '',
    gmailUrl: 'https://mail.google.com/mail/u/0/#inbox/' + encodeURIComponent(threadId),
    replyTo: mcServerMailListV01ExtractEmail_(from),
    forwardTo: '',
    composeSubject: subject ? (String(subject).indexOf('Re:') === 0 ? subject : 'Re: ' + subject) : 'Re: ',
    forwardSubject: subject ? (String(subject).indexOf('Fwd:') === 0 ? subject : 'Fwd: ' + subject) : 'Fwd: '
  };
}

function mcServerMailListV01GetAccountsCached_() {
  var key = mcServerMailListV01CacheKey_('accounts', { user: Session.getActiveUser().getEmail() || '' });
  var cached = mcServerMailListV01CacheGet_(key);
  if (cached && cached.rows) return cached.rows;
  var rows = mcServerMailListV01GetAccounts_();
  mcServerMailListV01CachePut_(key, { rows: rows }, MC_SERVER_MAIL_LIST_CORE_V01_ACCOUNTS_CACHE_SECONDS);
  return rows;
}

function mcServerMailListV01GetAccounts_() {
  var rows = [];
  try {
    var ss = mcServerMailListV01OpenMaster_();
    var sh = ss.getSheetByName('MailCenter_Accounts');
    if (!sh) return [];
    var values = sh.getDataRange().getValues();
    if (!values || values.length < 2) return [];
    var headers = values[0].map(function(h) { return String(h || '').trim(); });
    var h = mcServerMailListV01HeaderMap_(headers);
    for (var r = 1; r < values.length; r++) {
      var row = values[r];
      var status = mcServerMailListV01Cell_(row, h, 'accountStatus');
      if (status && String(status).toUpperCase() !== 'ACTIVE') continue;
      rows.push({
        mailAccountId: mcServerMailListV01Cell_(row, h, 'mailAccountId'),
        emailAddress: mcServerMailListV01Cell_(row, h, 'emailAddress'),
        ownerName: mcServerMailListV01Cell_(row, h, 'ownerName'),
        ownerType: mcServerMailListV01Cell_(row, h, 'ownerType'),
        roleCode: mcServerMailListV01Cell_(row, h, 'roleCode'),
        accountStatus: status,
        isDefault: mcServerMailListV01Cell_(row, h, 'isDefault')
      });
    }
  } catch (err) {
    rows = [];
  }
  return rows;
}

function mcServerMailListV01QuickFilters_() {
  return [
    { key: 'inbox', label: '받은메일', box: 'inbox' },
    { key: 'unread', label: '읽지않음', box: 'inbox', unreadOnly: true },
    { key: 'sent', label: '보낸메일', box: 'sent' },
    { key: 'starred', label: '별표', box: 'starred' },
    { key: 'attach', label: '첨부있음', box: 'all', hasAttachment: true },
    { key: 'all', label: '전체검색', box: 'all' }
  ];
}

function mcServerMailListV01BuildLinks_() {
  return {
    compose: '?page=MailCenterComposeV01',
    logAudit: '?page=MailCenterLogAuditV01',
    attachments: '?page=MailCenterAttachmentLibraryV01',
    templates: '?page=MailCenterTemplateV01',
    settings: '?page=MailCenterSettingsV01',
    accountAdmin: '?page=MailCenterAccountAdminV01'
  };
}

function mcServerMailListV01OpenMaster_() {
  var setup = SpreadsheetApp.openById(MC_SERVER_MAIL_LIST_CORE_V01_SETUP_DB_ID);
  var configSheet = setup.getSheetByName(MC_SERVER_MAIL_LIST_CORE_V01_CONFIG_SHEET);
  if (!configSheet) throw new Error('SystemConfig 시트를 찾지 못했습니다.');
  var values = configSheet.getDataRange().getValues();
  if (!values || values.length < 2) throw new Error('SystemConfig 데이터가 비어 있습니다.');
  var headers = values[0].map(function(h) { return String(h || '').trim(); });
  var keyCol = headers.indexOf('CONFIG_KEY');
  var valCol = headers.indexOf('VALUE');
  if (keyCol < 0 || valCol < 0) throw new Error('SystemConfig CONFIG_KEY/VALUE 헤더를 찾지 못했습니다.');
  var masterId = '';
  for (var i = 1; i < values.length; i++) {
    var key = String(values[i][keyCol] || '').trim();
    if (key === 'FEELHAUS_DB_MASTER' || key === 'FEELHAUS_DB_MASTER_ID' || key === 'MASTER_DB_ID') {
      masterId = String(values[i][valCol] || '').trim();
      break;
    }
  }
  if (!masterId) throw new Error('SystemConfig에서 FEELHAUS_DB_MASTER ID를 찾지 못했습니다.');
  return SpreadsheetApp.openById(masterId);
}

function mcServerMailListV01HeaderMap_(headers) {
  var map = {};
  for (var i = 0; i < headers.length; i++) map[String(headers[i] || '').trim()] = i;
  return map;
}

function mcServerMailListV01Cell_(row, map, key) {
  var idx = map[key];
  return idx === undefined || idx < 0 ? '' : String(row[idx] || '').trim();
}

function mcServerMailListV01ExtractEmail_(value) {
  value = String(value || '').trim();
  var m = value.match(/<([^>]+)>/);
  if (m && m[1]) return m[1].trim();
  var e = value.match(/[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}/i);
  return e ? e[0] : value;
}

function mcServerMailListV01SanitizeQuery_(q) {
  q = String(q || '').replace(/[\r\n]+/g, ' ').replace(/[{}]/g, ' ').trim();
  if (!q) return '';
  if (q.length > 120) q = q.substring(0, 120);
  return q;
}

function mcServerMailListV01FormatDate_(d) {
  try {
    return Utilities.formatDate(d, Session.getScriptTimeZone() || 'Asia/Seoul', 'yyyy-MM-dd HH:mm:ss');
  } catch (err) {
    return '';
  }
}

function mcServerMailListV01SanitizeHtml_(html) {
  html = String(html || '');
  if (!html) return '';
  html = html.replace(/<\s*(script|style|iframe|object|embed|form|input|button|select|textarea|meta|base|link)[\s\S]*?<\s*\/\s*\1\s*>/gi, '');
  html = html.replace(/<\s*(script|style|iframe|object|embed|form|input|button|select|textarea|meta|base|link)[^>]*>/gi, '');
  html = html.replace(/\s+on[a-z]+\s*=\s*("[^"]*"|'[^']*'|[^\s>]+)/gi, '');
  html = html.replace(/(href|src)\s*=\s*("|')\s*javascript:[\s\S]*?\2/gi, '$1="#"');
  html = html.replace(/<a\b(?![^>]*\btarget=)/gi, '<a target="_blank"');
  html = html.replace(/<a\b(?![^>]*\brel=)/gi, '<a rel="noopener noreferrer"');
  return html;
}

function mcServerMailListV01FormatBytes_(bytes) {
  bytes = Number(bytes || 0);
  if (!bytes) return '-';
  if (bytes < 1024) return bytes + ' B';
  if (bytes < 1024 * 1024) return Math.round(bytes / 1024) + ' KB';
  return (Math.round((bytes / 1024 / 1024) * 10) / 10) + ' MB';
}

function mcServerMailListV01Cache_() {
  try { return CacheService.getUserCache(); } catch (err) { return null; }
}

function mcServerMailListV01CacheKey_(prefix, obj) {
  var raw = prefix + ':' + JSON.stringify(obj || {});
  var digest = Utilities.computeDigest(Utilities.DigestAlgorithm.MD5, raw, Utilities.Charset.UTF_8);
  return 'MC_SML_V01_' + prefix + '_' + digest.map(function(b) {
    var v = (b < 0 ? b + 256 : b).toString(16);
    return v.length === 1 ? '0' + v : v;
  }).join('');
}

function mcServerMailListV01CacheGet_(key) {
  try {
    var cache = mcServerMailListV01Cache_();
    if (!cache) return null;
    var text = cache.get(key);
    return text ? JSON.parse(text) : null;
  } catch (err) {
    return null;
  }
}

function mcServerMailListV01CachePut_(key, value, seconds) {
  try {
    var cache = mcServerMailListV01Cache_();
    if (!cache) return false;
    var text = JSON.stringify(value || {});
    if (text.length > 95000) return false;
    cache.put(key, text, seconds || 60);
    return true;
  } catch (err) {
    return false;
  }
}

function mcServerMailListV01Now_() {
  return Utilities.formatDate(new Date(), Session.getScriptTimeZone() || 'Asia/Seoul', 'yyyy-MM-dd HH:mm:ss');
}


/**
 * PORTAL HQ Mail Fetch Addon V01C
 * Purpose: keep existing personal/active Gmail engine untouched and add HQ-mail-only fetch path.
 * Guard: no menu/router/address/ui layout changes.
 */
var PORTAL_HQ_MAIL_FETCH_ADDON_V01C_BUILD = 'PORTAL_HQ_MAIL_FETCH_ADDON_V01D_20260531';
var PORTAL_HQ_MAIL_FETCH_ADDON_V01C_EMAIL = 'feelhaus@feelhausfair.com';

function mcServerHqMailFetchAddonV01List(payload) {
  var started = new Date().getTime();
  var result = {
    ok: false,
    build: PORTAL_HQ_MAIL_FETCH_ADDON_V01C_BUILD,
    action: 'mcServerHqMailFetchAddonV01List',
    generatedAt: mcServerMailListV01Now_(),
    message: '',
    source: '',
    query: '',
    start: 0,
    limit: MC_SERVER_MAIL_LIST_CORE_V01_DEFAULT_LIMIT,
    count: 0,
    elapsedMs: 0,
    mailboxEmail: PORTAL_HQ_MAIL_FETCH_ADDON_V01C_EMAIL,
    mailAccountId: '',
    viewerEmail: '',
    threads: []
  };

  try {
    payload = payload || {};
    var start = Math.max(0, parseInt(payload.start || 0, 10) || 0);
    var limit = Math.min(MC_SERVER_MAIL_LIST_CORE_V01_MAX_LIMIT, Math.max(1, parseInt(payload.limit || 10, 10) || 10));
    var query = mcServerMailListV01BuildQuery_(payload) || 'in:inbox newer_than:30d';
    result.start = start;
    result.limit = limit;
    result.query = query;
    result.viewerEmail = mcServerHqMailFetchAddonV01ViewerEmail_();

    if (typeof portal169ListMailThreadsLock !== 'function') {
      throw new Error('본사메일 커넥터 함수가 없습니다: portal169ListMailThreadsLock');
    }

    var account = mcServerHqMailFetchAddonV01ResolveAccount_();
    result.mailAccountId = account.mailAccountId || '';
    result.mailboxEmail = account.emailAddress || PORTAL_HQ_MAIL_FETCH_ADDON_V01C_EMAIL;

    var connector = portal169ListMailThreadsLock(result.viewerEmail || 'PORTAL_HQ_MAIL_FETCH_ADDON', {
      mailAccountId: account.mailAccountId,
      emailAddress: account.emailAddress,
      query: query,
      max: limit
    });

    if (!connector || !connector.ok) {
      var connectorMsg = connector && connector.message ? connector.message : '본사메일 실시간 커넥터 조회 실패';
      var metadataNoQuery = [];
      if (mcServerHqMailFetchAddonV01IsMetadataScopeQueryError_(connectorMsg)) {
        metadataNoQuery = mcServerHqMailFetchAddonV01MetadataNoQueryList_(account, limit, start);
        if (metadataNoQuery && metadataNoQuery.length) {
          result.source = 'connector_metadata_no_query';
          result.threads = metadataNoQuery;
          result.count = metadataNoQuery.length;
          result.ok = true;
          result.elapsedMs = new Date().getTime() - started;
          result.message = '본사메일 실시간 목록 조회 완료. 현재 토큰이 metadata scope라 검색(q) 없이 최신 메일 기준으로 표시합니다.';
          return result;
        }
      }
      var cached = mcServerHqMailFetchAddonV01CacheFallback_(account, query, limit, start);
      if (cached && cached.length) {
        result.source = 'cache';
        result.threads = cached;
        result.count = cached.length;
        result.ok = true;
        result.elapsedMs = new Date().getTime() - started;
        result.message = '실시간 커넥터 실패, PORTAL_MailInbox 캐시로 본사메일 표시: ' + connectorMsg;
        return result;
      }
      throw new Error(connectorMsg);
    }

    var items = connector.items || connector.threads || [];
    result.source = 'connector';
    result.threads = items.map(function(item) {
      return mcServerHqMailFetchAddonV01ItemToRow_(item, account);
    });
    result.count = result.threads.length;
    result.elapsedMs = new Date().getTime() - started;
    result.ok = true;
    result.message = result.count ? '본사메일 커넥터 조회 완료' : '본사메일 조건에 맞는 메일이 없습니다.';
    return result;
  } catch (err) {
    result.ok = false;
    result.elapsedMs = new Date().getTime() - started;
    result.message = String(err && err.message ? err.message : err);
    return result;
  }
}

function mcServerHqMailFetchAddonV01GetMessageDetail(payload) {
  var started = new Date().getTime();
  var result = {
    ok: false,
    build: PORTAL_HQ_MAIL_FETCH_ADDON_V01C_BUILD,
    action: 'mcServerHqMailFetchAddonV01GetMessageDetail',
    generatedAt: mcServerMailListV01Now_(),
    message: '',
    threadId: '',
    threadUrl: '',
    subject: '',
    elapsedMs: 0,
    messages: []
  };
  try {
    payload = payload || {};
    var messageId = String(payload.messageId || '').trim();
    if (!messageId) throw new Error('messageId 값이 필요합니다.');
    if (typeof portal169GetMailMessageLock !== 'function') throw new Error('본사메일 상세 커넥터 함수가 없습니다: portal169GetMailMessageLock');
    var account = mcServerHqMailFetchAddonV01ResolveAccount_();
    var detail = portal169GetMailMessageLock(mcServerHqMailFetchAddonV01ViewerEmail_() || 'PORTAL_HQ_MAIL_FETCH_ADDON', {
      mailAccountId: account.mailAccountId,
      emailAddress: account.emailAddress,
      messageId: messageId
    });
    var item = null;
    var detailMsg = detail && detail.message ? detail.message : '';
    if (!detail || !detail.ok) {
      if (mcServerHqMailFetchAddonV01IsMetadataScopeFullError_(detailMsg)) {
        item = mcServerHqMailFetchAddonV01MetadataDetailFallback_(account, messageId) || mcServerHqMailFetchAddonV01CacheDetailFallback_(account, messageId);
        if (!item) throw new Error('본문 전문 권한이 부족하여 상세 본문을 가져오지 못했습니다. Gmail 원문 열기를 사용하세요. 원인: ' + detailMsg);
        result.message = '현재 토큰이 metadata scope라 본문 전문 대신 메타데이터/미리보기 기준으로 표시합니다.';
      } else {
        throw new Error(detailMsg || '본사메일 상세 조회 실패');
      }
    } else {
      item = detail.item || {};
      result.message = '본사메일 상세 조회 완료';
    }
    result.threadId = item.threadId || payload.threadId || '';
    result.threadUrl = 'https://mail.google.com/mail/u/0/#inbox/' + encodeURIComponent(result.threadId || messageId);
    result.subject = item.subject || '';
    result.messages = [{
      messageId: item.messageId || messageId,
      from: item.fromEmail || item.from || '',
      to: item.toEmail || item.to || '',
      cc: item.ccEmail || item.cc || '',
      bcc: '',
      date: item.date || item.receivedAt || '',
      subject: item.subject || '',
      plainBody: item.textBody || item.plainBody || item.snippet || '본문 전문 권한이 없어 미리보기만 표시합니다. 원문은 Gmail 원문 열기로 확인하세요.',
      htmlBody: mcServerMailListV01SanitizeHtml_(item.htmlBody || ''),
      snippet: item.snippet || '',
      attachmentCount: item.attachments ? item.attachments.length : (item.attachmentCount || 0),
      attachments: (item.attachments || []).map(function(a, idx) {
        return { index: idx + 1, name: a.filename || a.name || ('attachment-' + (idx + 1)), contentType: a.mimeType || a.contentType || '', sizeBytes: a.size || 0, sizeLabel: '' };
      })
    }];
    result.elapsedMs = new Date().getTime() - started;
    result.ok = true;
    if (!result.message) result.message = '본사메일 상세 조회 완료';
    return result;
  } catch (err) {
    result.ok = false;
    result.elapsedMs = new Date().getTime() - started;
    result.message = String(err && err.message ? err.message : err);
    return result;
  }
}


function mcServerHqMailFetchAddonV01IsMetadataScopeQueryError_(message) {
  var text = String(message || '');
  return text.indexOf('Metadata scope does not support') >= 0 || text.indexOf('PERMISSION_DENIED') >= 0 && text.indexOf("'q' parameter") >= 0;
}

function mcServerHqMailFetchAddonV01IsMetadataScopeFullError_(message) {
  var text = String(message || '');
  return text.indexOf('Metadata scope does not allow format FULL') >= 0 || text.indexOf('format FULL') >= 0 && text.indexOf('PERMISSION_DENIED') >= 0;
}

function mcServerHqMailFetchAddonV01MetadataDetailFallback_(account, messageId) {
  try {
    var accountId = String(account && account.mailAccountId || '');
    if (!accountId || !messageId || typeof portal169GetMessageMeta_ !== 'function') return null;
    var acc = account;
    try { if (typeof portal169GetAccount_ === 'function') acc = portal169GetAccount_(accountId) || account; } catch (ignoreAcc) {}
    var meta = portal169GetMessageMeta_(accountId, messageId, acc);
    if (meta && typeof portal169UpsertInbox_ === 'function') {
      try { portal169UpsertInbox_(meta, mcServerHqMailFetchAddonV01ViewerEmail_() || 'PORTAL_HQ_MAIL_FETCH_ADDON'); } catch (ignoreUpsert) {}
    }
    return meta || null;
  } catch (ignore) {
    return null;
  }
}

function mcServerHqMailFetchAddonV01CacheMapByMessageId_(accountId) {
  var map = {};
  try {
    var ss = mcServerMailListV01OpenMaster_();
    var sh = ss.getSheetByName('PORTAL_MailInbox');
    if (!sh) return map;
    var values = sh.getDataRange().getValues();
    if (!values || values.length < 2) return map;
    var headers = values[0].map(function(h) { return String(h || '').trim(); });
    var h = mcServerMailListV01HeaderMap_(headers);
    for (var r = 1; r < values.length; r++) {
      var row = values[r];
      if (accountId && String(mcServerMailListV01Cell_(row, h, 'mailAccountId') || '') !== String(accountId)) continue;
      var mid = String(mcServerMailListV01Cell_(row, h, 'messageId') || '');
      if (!mid) continue;
      map[mid] = {
        messageId: mid,
        threadId: mcServerMailListV01Cell_(row, h, 'threadId'),
        mailAccountId: mcServerMailListV01Cell_(row, h, 'mailAccountId'),
        gmailLabel: mcServerMailListV01Cell_(row, h, 'gmailLabel'),
        mailStatus: mcServerMailListV01Cell_(row, h, 'mailStatus'),
        fromEmail: mcServerMailListV01Cell_(row, h, 'fromEmail'),
        toEmail: mcServerMailListV01Cell_(row, h, 'toEmail'),
        subject: mcServerMailListV01Cell_(row, h, 'subject'),
        snippet: mcServerMailListV01Cell_(row, h, 'snippet'),
        receivedAt: mcServerMailListV01Cell_(row, h, 'receivedAt') || mcServerMailListV01Cell_(row, h, 'updatedAt')
      };
    }
  } catch (ignore) {}
  return map;
}

function mcServerHqMailFetchAddonV01CacheDetailFallback_(account, messageId) {
  var map = mcServerHqMailFetchAddonV01CacheMapByMessageId_(String(account && account.mailAccountId || ''));
  return map[String(messageId || '')] || null;
}

function mcServerHqMailFetchAddonV01MetadataNoQueryList_(account, limit, start) {
  var rows = [];
  var accountId = String(account && account.mailAccountId || '');
  if (!accountId) return rows;
  if (typeof portal169GmailApi_ !== 'function' || typeof portal169GetMessageMeta_ !== 'function') return rows;
  var offset = Math.max(0, Number(start || 0));
  var want = Math.max(1, Number(limit || 10));
  var max = Math.max(1, Math.min(want + offset, 50));
  var list = portal169GmailApi_(accountId, 'get', '/gmail/v1/users/me/messages?maxResults=' + max, null);
  var acc = account;
  try { if (typeof portal169GetAccount_ === 'function') acc = portal169GetAccount_(accountId) || account; } catch (ignoreAcc) {}
  var messages = list && list.messages ? list.messages : [];
  var cacheMap = mcServerHqMailFetchAddonV01CacheMapByMessageId_(accountId);
  var actor = mcServerHqMailFetchAddonV01ViewerEmail_() || 'PORTAL_HQ_MAIL_FETCH_ADDON';
  for (var i = 0; i < messages.length; i++) {
    var mid = String(messages[i] && messages[i].id || '');
    if (!mid) continue;
    try {
      if (cacheMap[mid]) {
        rows.push(mcServerHqMailFetchAddonV01ItemToRow_(cacheMap[mid], acc));
        continue;
      }
      var meta = portal169GetMessageMeta_(accountId, mid, acc);
      if (typeof portal169UpsertInbox_ === 'function') {
        try { portal169UpsertInbox_(meta, actor); } catch (ignoreUpsert) {}
      }
      rows.push(mcServerHqMailFetchAddonV01ItemToRow_(meta, acc));
    } catch (ignoreMeta) {}
  }
  return rows.slice(offset, offset + want);
}

function mcServerHqMailFetchAddonV01ResolveAccount_() {
  if (typeof portal169FindAccountByEmail_ === 'function') {
    var acc = portal169FindAccountByEmail_(PORTAL_HQ_MAIL_FETCH_ADDON_V01C_EMAIL, '');
    if (acc && acc.mailAccountId) return acc;
  }
  if (typeof portal169ResolveAccountId_ === 'function' && typeof portal169GetAccount_ === 'function') {
    var accountId = portal169ResolveAccountId_({ emailAddress: PORTAL_HQ_MAIL_FETCH_ADDON_V01C_EMAIL, vendorId: '' });
    return portal169GetAccount_(accountId);
  }
  throw new Error('본사메일 계정을 찾을 수 없습니다: ' + PORTAL_HQ_MAIL_FETCH_ADDON_V01C_EMAIL);
}

function mcServerHqMailFetchAddonV01ItemToRow_(item, account) {
  item = item || {};
  var labels = String(item.gmailLabel || item.labelIds || '').split(',');
  var unread = String(item.mailStatus || '').toUpperCase() === 'UNREAD' || labels.indexOf('UNREAD') >= 0;
  var starred = labels.indexOf('STARRED') >= 0;
  var subject = item.subject || '(제목 없음)';
  var threadId = item.threadId || item.messageId || '';
  var messageId = item.messageId || '';
  return {
    threadId: threadId,
    messageId: messageId,
    mailAccountId: item.mailAccountId || (account && account.mailAccountId) || '',
    mailboxEmail: (account && account.emailAddress) || PORTAL_HQ_MAIL_FETCH_ADDON_V01C_EMAIL,
    source: 'hq_connector',
    subject: subject,
    from: item.fromEmail || item.from || '',
    to: item.toEmail || item.to || '',
    lastDate: item.receivedAt || item.date || item.updatedAt || '',
    firstDate: item.receivedAt || item.date || '',
    messageCount: 1,
    attachmentCount: item.attachmentCount || 0,
    hasAttachmentHint: /첨부|attached|attachment/i.test(subject || '') || !!item.attachmentCount,
    unread: unread,
    starred: starred,
    important: labels.indexOf('IMPORTANT') >= 0,
    labels: labels.filter(function(x) { return !!x; }),
    snippet: item.snippet || subject,
    gmailUrl: 'https://mail.google.com/mail/u/0/#inbox/' + encodeURIComponent(threadId),
    replyTo: mcServerMailListV01ExtractEmail_(item.fromEmail || item.from || ''),
    forwardTo: '',
    composeSubject: subject ? (String(subject).indexOf('Re:') === 0 ? subject : 'Re: ' + subject) : 'Re: ',
    forwardSubject: subject ? (String(subject).indexOf('Fwd:') === 0 ? subject : 'Fwd: ' + subject) : 'Fwd: '
  };
}

function mcServerHqMailFetchAddonV01CacheFallback_(account, query, limit, start) {
  var rows = [];
  try {
    var ss = mcServerMailListV01OpenMaster_();
    var sh = ss.getSheetByName('PORTAL_MailInbox');
    if (!sh) return [];
    var values = sh.getDataRange().getValues();
    if (!values || values.length < 2) return [];
    var headers = values[0].map(function(h) { return String(h || '').trim(); });
    var h = mcServerMailListV01HeaderMap_(headers);
    var accountId = String(account && account.mailAccountId || '');
    for (var r = 1; r < values.length; r++) {
      var row = values[r];
      if (accountId && String(mcServerMailListV01Cell_(row, h, 'mailAccountId') || '') !== accountId) continue;
      rows.push(mcServerHqMailFetchAddonV01ItemToRow_({
        messageId: mcServerMailListV01Cell_(row, h, 'messageId'),
        threadId: mcServerMailListV01Cell_(row, h, 'threadId'),
        mailAccountId: mcServerMailListV01Cell_(row, h, 'mailAccountId'),
        gmailLabel: mcServerMailListV01Cell_(row, h, 'gmailLabel'),
        mailStatus: mcServerMailListV01Cell_(row, h, 'mailStatus'),
        fromEmail: mcServerMailListV01Cell_(row, h, 'fromEmail'),
        toEmail: mcServerMailListV01Cell_(row, h, 'toEmail'),
        subject: mcServerMailListV01Cell_(row, h, 'subject'),
        snippet: mcServerMailListV01Cell_(row, h, 'snippet'),
        receivedAt: mcServerMailListV01Cell_(row, h, 'receivedAt') || mcServerMailListV01Cell_(row, h, 'updatedAt')
      }, account));
    }
  } catch (ignore) {
    rows = [];
  }
  return rows.slice(Math.max(0, start || 0), Math.max(0, start || 0) + Math.max(1, limit || 10));
}

function mcServerHqMailFetchAddonV01ViewerEmail_() {
  try {
    if (typeof portal19GetCurrentEmail_ === 'function') return portal19GetCurrentEmail_() || '';
  } catch (ignore) {}
  try { return Session.getActiveUser().getEmail() || ''; } catch (ignore2) { return ''; }
}
