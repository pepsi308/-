/**
 * FEELHAUS PORTAL / Calendar SAFE-01B R11 Page Auto Refresh Reentry Verify
 * Build: PORTAL_CALENDAR_SAFE01B_R11_PAGE_AUTO_REFRESH_REENTRY_20260604
 * Safety: READ_ONLY_RUNTIME_VERIFY_NO_SHEET_PROVIDER_WRITE
 * Purpose:
 *  - Verify R11 page-level auto refresh is present after R10K2 event-master link work.
 *  - Verify open detail modal refreshes from server ledger rows without sheet/provider writes.
 *  - Verify R10K2 ERP_행사관리 eventId-based detail link remains available.
 */
var PORTAL_CALENDAR_SAFE01B_R11_PAGE_AUTO_REFRESH_REENTRY_BUILD = 'PORTAL_CALENDAR_SAFE01B_R11_PAGE_AUTO_REFRESH_REENTRY_20260604';

function portalCalendarSafe01BR11PageAutoRefreshReentryVerify() {
  return portalCalendarSafe01BR11PageAutoRefreshVerify();
}

function portalCalendarSafe01BR11PageAutoRefreshKstVerify() {
  return portalCalendarSafe01BR11PageAutoRefreshVerify();
}

function portalCalendarSafe01BR11PageAutoRefreshVerify() {
  var BUILD = PORTAL_CALENDAR_SAFE01B_R11_PAGE_AUTO_REFRESH_REENTRY_BUILD;
  var BASE_BUILD = 'PORTAL_CALENDAR_SAFE01B_R10K2_EVENT_MASTER_LINK_DETAIL_20260604';
  var ACTION = 'portalCalendarSafe01BR11PageAutoRefreshVerify';
  var html = '';
  var readError = '';
  var detailSource = '';
  var marker = null;

  try {
    html = HtmlService.createTemplateFromFile('MC_CalendarViewV01').getRawContent();
  } catch (e1) {
    try {
      html = HtmlService.createHtmlOutputFromFile('MC_CalendarViewV01').getContent();
    } catch (e2) {
      readError = String(e2 && e2.message ? e2.message : e2);
      html = '';
    }
  }

  try {
    if (typeof mcCalendarDetailCoreV01GetDetail === 'function') detailSource = String(mcCalendarDetailCoreV01GetDetail);
  } catch (e3) {
    detailSource = '';
  }

  try {
    if (typeof mcCalendarDetailCoreV01R11PageRefreshMarker_ === 'function') marker = mcCalendarDetailCoreV01R11PageRefreshMarker_();
  } catch (e4) {
    marker = { ok:false, message:String(e4 && e4.message ? e4.message : e4) };
  }

  function has(s) { return html.indexOf(s) !== -1; }
  function hasDetail(s) { return detailSource.indexOf(s) !== -1; }
  function re(r) { return r.test(html); }
  function lineNumberAt(text, index) {
    if (index < 0) return -1;
    return String(text || '').substring(0, index).split('\n').length;
  }
  function contextAt(text, index, needle) {
    if (index < 0) return '';
    var size = 220;
    var end = index + String(needle || '').length;
    return String(text || '').substring(Math.max(0, index - size), Math.min(String(text || '').length, end + size));
  }
  function matchInfo(text, needle) {
    var idx = String(text || '').indexOf(needle);
    return {
      found: idx !== -1,
      needle: idx !== -1 ? needle : '',
      matchIndex: idx,
      lineNumber: lineNumberAt(text, idx),
      context: contextAt(text, idx, needle)
    };
  }

  var checks = {
    viewReadable: !!html && !readError,
    r11BuildMarkerPresent: has('PORTAL_CALENDAR_SAFE01B_R11_PAGE_AUTO_REFRESH_KST_20260603') || has('R11_PAGE_AUTO_REFRESH'),
    initStartsAutoRefresh: re(/function\s+init\s*\([^)]*\)\s*\{[\s\S]*fhCalendarStartAutoRefreshR11\s*\(/),
    pollTimerReady: has('__fhCalendarR11PollTimer') && has('setInterval(fhCalendarCheckPageRefreshR11,30000)'),
    revisionSignatureReady: has('fhCalendarRevisionSignatureR11') && has('fhCalendarSetRevisionBaselineR11'),
    monthRefreshUsesShellRead: has('fhCalendarCheckPageRefreshR11') && has('mcCalendarShellV01GetMonthData({year:state.year,month:state.month,changePoll') && has('R11_PAGE_AUTO_REFRESH'),
    autoRefreshSkipsEditModal: has('if(__fhCalendarEditModalActive)return;'),
    autoRefreshSkipsHiddenTab: has('if(document.hidden)return;'),
    pageRefreshRerendersCalendarAndList: has('renderCalendar();renderList();'),
    activeDetailIdTracked: has('__fhCalendarR11ActiveDetailId') && has('__fhCalendarR11ActiveDetailId=firstText'),
    closeClearsActiveDetailId: has('closeCalendarDetailPopup') && has('__fhCalendarR11ActiveDetailId=\'\''),
    openDetailRefreshReady: has('fhCalendarRefreshOpenDetailR11') && has('mcCalendarDetailCoreV01GetDetail({calendarEventId:calendarEventId,forceFresh'),
    detailRefreshRendersPopup: has('renderCalendarDetailPopup(e,res,\'\')') && has('renderBasicDetailSummary(e,notice'),
    r10k1DetailFaceKept: has('fhCalendarDetailFaceR10K') && has('오늘 업무 브리핑') && has('cal-k1-hero'),
    r10k2EventMasterUiKept: has('행사관리 원장 연결 / 담당·참여자 정보') && has('me_eventMasterPicker') && has('portalCalendarR10K2ListEventMasterOptions') && has('portalCalendarR10K2GetEventMasterDetail'),
    r10k2EventMasterSummaryKept: has('fhCalendarR10K2EventOperationInfoHtml') && has('ERP_행사관리 조회형') && has('eventId 기준'),
    detailCoreFunctionReady: typeof mcCalendarDetailCoreV01GetDetail === 'function',
    detailCoreR11MarkerReady: marker && marker.ok === true,
    detailCoreForceFreshAccepted: marker && marker.forceFreshPayloadAccepted === true,
    detailCoreR10K2EventMasterLookupKept: hasDetail('mcCalendarDetailCoreV01FindEventMasterR10K2_') && hasDetail('__eventMasterR10K2') && hasDetail('eventId') && hasDetail('relatedEventId'),
    providerWriteNotAddedInR11: !has('CalendarApp.') && !has('UrlFetchApp.fetch') && !has('appendRow(') && !has('.setValue('),
    noSheetProviderWriteInVerify: true
  };

  var fatal = [];
  Object.keys(checks).forEach(function(k) { if (!checks[k]) fatal.push(k); });
  if (readError) fatal.push('viewHtmlReadError');

  var diagnostics = {
    htmlLength: html.length,
    readError: readError,
    r11Marker: matchInfo(html, 'PORTAL_CALENDAR_SAFE01B_R11_PAGE_AUTO_REFRESH_KST_20260603'),
    startAutoRefresh: matchInfo(html, 'fhCalendarStartAutoRefreshR11'),
    pollInterval: matchInfo(html, 'setInterval(fhCalendarCheckPageRefreshR11,30000)'),
    shellMonthRead: matchInfo(html, 'mcCalendarShellV01GetMonthData({year:state.year,month:state.month,changePoll'),
    detailRefresh: matchInfo(html, 'fhCalendarRefreshOpenDetailR11'),
    detailForceFresh: matchInfo(html, 'forceFresh:\'R11_PAGE_AUTO_REFRESH\''),
    r10k2Picker: matchInfo(html, 'me_eventMasterPicker'),
    r10k2EventSummary: matchInfo(html, '행사관리 원장 연결 / 담당·참여자 정보'),
    detailCoreSourceLength: detailSource.length,
    detailCoreMarker: marker || {},
    detailCoreEventMasterLookup: {
      findFunction: hasDetail('mcCalendarDetailCoreV01FindEventMasterR10K2_'),
      eventMasterReturn: hasDetail('__eventMasterR10K2'),
      preferredSheet: hasDetail('ERP_행사관리')
    }
  };

  var result = {
    ok: fatal.length === 0,
    build: BUILD,
    baseBuild: BASE_BUILD,
    action: ACTION,
    safety: 'READ_ONLY_RUNTIME_VERIFY_NO_SHEET_PROVIDER_WRITE',
    checks: checks,
    diagnostics: diagnostics,
    warnings: [],
    fatal: fatal,
    summary: {
      mode: 'R11 page auto refresh reentry after R10K2 event master link',
      refreshIntervalMs: 30000,
      openDetailRefresh: true,
      eventMasterLinkPreserved: checks.r10k2EventMasterUiKept && checks.detailCoreR10K2EventMasterLookupKept,
      providerPolicy: 'No Google/NAVER/ICS/provider write logic added by this verify build',
      expectedNext: '실서버 통과 후 업무 중 사용하면서 R11 자동갱신 안정성 관찰'
    },
    message: fatal.length === 0
      ? 'SAFE-01B R11 page auto-refresh reentry verification passed.'
      : 'SAFE-01B R11 page auto-refresh reentry verification failed. Check fatal items and diagnostics.'
  };

  try { Logger.log('JSON_COMPACT_RESULT: ' + JSON.stringify(result)); } catch (ignore) {}
  return result;
}
