/**
 * FEELHAUS Google Calendar Sync Patch 03
 * Build: MC_GOOGLE_CALENDAR_SYNC_PATCH_SANITIZE_PAYLOAD_V01_20260527
 *
 * 현재 해결할 오류:
 *   PREP_DRY_RUN / APPLY_DRY_RUN
 *   message: "mcCalendar28SanitizePayload_ is not defined"
 *
 * 적용 방법:
 * 1. Apps Script에 새 파일을 만듭니다.
 *    파일명 예: MC_GoogleCalendarSync_Patch03
 * 2. 이 파일 전체를 붙여넣습니다.
 * 3. 저장합니다.
 * 4. mcGoogleCalendarSyncPatch03VerifyAndRunGateV01 실행
 */


/**
 * 누락된 payload sanitize 헬퍼 복구
 *
 * 목적:
 * - 로그/시트에 넣기 전에 payload를 JSON 직렬화 가능한 안전한 객체로 변환
 * - Date, 함수, 순환참조, Error, CalendarEvent 같은 객체를 안전하게 문자열/객체화
 */
function mcCalendar28SanitizePayload_(payload, options) {
  options = options || {};

  var maxDepth = Number(options.maxDepth || 8);
  var maxStringLength = Number(options.maxStringLength || 5000);
  var seen = [];

  function trimString(s) {
    s = String(s);
    if (s.length > maxStringLength) {
      return s.slice(0, maxStringLength) + '... [TRUNCATED ' + s.length + ']';
    }
    return s;
  }

  function sanitize(value, depth) {
    if (value === null || value === undefined) {
      return value;
    }

    var t = typeof value;

    if (t === 'string') {
      return trimString(value);
    }

    if (t === 'number' || t === 'boolean') {
      return value;
    }

    if (t === 'function') {
      return '[Function]';
    }

    if (value instanceof Date) {
      try {
        return Utilities.formatDate(
          value,
          Session.getScriptTimeZone() || 'Asia/Seoul',
          'yyyy-MM-dd HH:mm:ss'
        );
      } catch (errDate) {
        return value.toISOString ? value.toISOString() : String(value);
      }
    }

    if (value instanceof Error) {
      return {
        name: value.name || 'Error',
        message: value.message || String(value),
        stack: value.stack ? trimString(value.stack) : ''
      };
    }

    if (depth >= maxDepth) {
      return '[MaxDepth]';
    }

    // Apps Script 객체 대응: getId/getTitle/getName 등이 있으면 요약만 남김
    try {
      if (
        typeof value.getId === 'function' ||
        typeof value.getTitle === 'function' ||
        typeof value.getName === 'function'
      ) {
        var summary = {
          _type: Object.prototype.toString.call(value)
        };

        try { if (typeof value.getId === 'function') summary.id = value.getId(); } catch (ignoreId) {}
        try { if (typeof value.getTitle === 'function') summary.title = value.getTitle(); } catch (ignoreTitle) {}
        try { if (typeof value.getName === 'function') summary.name = value.getName(); } catch (ignoreName) {}
        try { if (typeof value.getEmail === 'function') summary.email = value.getEmail(); } catch (ignoreEmail) {}

        return sanitize(summary, depth + 1);
      }
    } catch (ignoreAppsObject) {}

    if (seen.indexOf(value) >= 0) {
      return '[Circular]';
    }

    seen.push(value);

    try {
      if (Array.isArray(value)) {
        return value.map(function(item) {
          return sanitize(item, depth + 1);
        });
      }

      var out = {};
      Object.keys(value).forEach(function(k) {
        var safeKey = trimString(k);
        out[safeKey] = sanitize(value[k], depth + 1);
      });
      return out;
    } catch (errObj) {
      return trimString(value);
    } finally {
      seen.pop();
    }
  }

  return sanitize(payload, 0);
}


/**
 * 일부 코드가 다른 이름을 참조할 가능성에 대비한 별칭
 */
function mcCalendar28SafePayload_(payload, options) {
  return mcCalendar28SanitizePayload_(payload, options);
}


/**
 * 객체를 안전한 JSON 문자열로 변환하는 보조 함수
 */
function mcCalendar28SafeJsonStringify_(payload, options) {
  try {
    return JSON.stringify(mcCalendar28SanitizePayload_(payload, options || {}));
  } catch (err) {
    return JSON.stringify({
      ok: false,
      message: String(err && err.message ? err.message : err)
    });
  }
}


/**
 * 패치 03 검증
 */
function mcGoogleCalendarSyncPatch03VerifyV01() {
  var result = {
    ok: true,
    build: 'MC_GOOGLE_CALENDAR_SYNC_PATCH03_VERIFY_V01_20260527',
    action: 'mcGoogleCalendarSyncPatch03VerifyV01',
    checks: {},
    generatedAt: Utilities.formatDate(
      new Date(),
      Session.getScriptTimeZone() || 'Asia/Seoul',
      'yyyy-MM-dd HH:mm:ss'
    )
  };

  try {
    result.checks.sanitizeExists = {
      ok: typeof mcCalendar28SanitizePayload_ === 'function',
      type: typeof mcCalendar28SanitizePayload_
    };
    if (!result.checks.sanitizeExists.ok) result.ok = false;
  } catch (errExists) {
    result.ok = false;
    result.checks.sanitizeExists = {
      ok: false,
      error: String(errExists && errExists.message ? errExists.message : errExists)
    };
  }

  try {
    var circular = { name: 'root' };
    circular.self = circular;

    var sanitized = mcCalendar28SanitizePayload_({
      action: 'PATCH03_TEST',
      now: new Date(),
      fn: function testFn() {},
      circular: circular,
      nested: {
        a: 1,
        b: true
      }
    });

    result.checks.sanitizeWorks = {
      ok: !!sanitized &&
          sanitized.action === 'PATCH03_TEST' &&
          sanitized.circular &&
          sanitized.circular.self === '[Circular]',
      value: sanitized
    };

    if (!result.checks.sanitizeWorks.ok) result.ok = false;
  } catch (errWorks) {
    result.ok = false;
    result.checks.sanitizeWorks = {
      ok: false,
      error: String(errWorks && errWorks.message ? errWorks.message : errWorks)
    };
  }

  Logger.log('JSON_COMPACT_RESULT: ' + JSON.stringify(result));
  return result;
}


/**
 * 패치 03 검증 후 테스트 게이트 실행
 */
function mcGoogleCalendarSyncPatch03VerifyAndRunGateV01() {
  var verifyResult = mcGoogleCalendarSyncPatch03VerifyV01();

  var gateResult = null;
  var gateError = '';

  try {
    gateResult = mcGoogleCalendarSyncTestGateV03All();
  } catch (errGate) {
    gateError = String(errGate && errGate.message ? errGate.message : errGate);
  }

  var result = {
    ok: !!verifyResult.ok && !!gateResult && !!gateResult.ok,
    build: 'MC_GOOGLE_CALENDAR_SYNC_PATCH03_VERIFY_AND_RUN_GATE_V01_20260527',
    action: 'mcGoogleCalendarSyncPatch03VerifyAndRunGateV01',
    verifyResult: verifyResult,
    gateResult: gateResult,
    gateError: gateError,
    generatedAt: Utilities.formatDate(
      new Date(),
      Session.getScriptTimeZone() || 'Asia/Seoul',
      'yyyy-MM-dd HH:mm:ss'
    )
  };

  Logger.log('JSON_COMPACT_RESULT: ' + JSON.stringify(result));
  return result;
}
