/**
 * FEELHAUS PORTAL / MailCenter Calendar ERP Event Link V01
 * Build: PORTAL_MC_CALENDAR_ERP_EVENT_LINK_V01_20260528
 * Purpose:
 * - 운영 캘린더와 ERP 행사/업체/고객/설치/A/S 원장을 ID 기준으로 연결한다.
 * - ERP 원본은 직접 덮어쓰지 않고 sourceWritePolicy/sourceUpdateStatus로 반영 정책만 추적한다.
 * - 화면/캘린더에서 수정된 연결 일정은 캘린더 원장에 기록하고, 원본 반영은 승인/대기 상태로 남긴다.
 */
var MC_CALENDAR_ERP_EVENT_LINK_V01_BUILD = 'PORTAL_MC_CALENDAR_ERP_EVENT_LINK_V01_20260528';

function calErpHelp() {
  var result = mcCalendarErpEventLinkV01BaseResult_('calErpHelp');
  result.ok = true;
  result.message = 'ERP 행사연동 캘린더 짧은 실행 함수 안내';
  result.runners = [
    { fn: 'calErpTest()', desc: '사전점검: Calendar/ChangeLog/ERP 후보 시트/필수 함수 확인' },
    { fn: 'calErpDry()', desc: 'ERP 행사연동 캘린더 샘플 DryRun. 저장 없음' },
    { fn: 'calErpSave()', desc: 'ERP 행사연동 캘린더 샘플 실제 저장. ERP 원본 수정 없음' },
    { fn: 'calErpCheck()', desc: '최근 ERP_EVENT 연동 일정 검증' },
    { fn: 'calErpEdit()', desc: '최근 ERP_EVENT 일정 표시정보 수정 테스트. ERP 원본 직접 수정 없음' },
    { fn: 'calErpList()', desc: '최근 ERP/운영 캘린더 연동 일정 목록' }
  ];
  result.nextAction = 'calErpTest() 실행 후 calErpDry()를 실행하세요.';
  return mcCalendarErpEventLinkV01Print_(result);
}

function calErpTest() { return mcCalendarErpEventLinkV01SelfTest(); }
function calErpDry() { return mcCalendarErpEventLinkV01CreateSampleDryRun(); }
function calErpSave() { return mcCalendarErpEventLinkV01CreateSampleReal(); }
function calErpCheck() { return mcCalendarErpEventLinkV01VerifyRecent(); }
function calErpEdit() { return mcCalendarErpEventLinkV01UpdateRecentSample(); }
function calErpList() { return mcCalendarErpEventLinkV01ListRecent5(); }

function mcCalendarErpEventLinkV01SelfTest() {
  var result = mcCalendarErpEventLinkV01BaseResult_('mcCalendarErpEventLinkV01SelfTest');
  try {
    var ss = mcCalendarUnifiedManualInputV01OpenMaster_();
    var calendarSheet = mcCalendarUnifiedManualInputV01GetSheetOrCreate_(ss, 'MAILCENTER_CalendarEvents', mcCalendarOperationHubV01CalendarHeaders_());
    var changeLogSheet = mcCalendarUnifiedManualInputV01GetSheetOrCreate_(ss, 'MAILCENTER_CalendarChangeLogs', mcCalendarOperationHubV01ChangeLogHeaders_());
    var hm = mcCalendarUnifiedManualInputV01HeaderMap_(calendarSheet.getRange(1, 1, 1, Math.max(calendarSheet.getLastColumn(), 1)).getValues()[0]);
    var required = mcCalendarErpEventLinkV01RequiredHeaders_();
    var missing = required.filter(function(h) { return hm[h] === undefined; });
    var erpSheets = mcCalendarErpEventLinkV01DiscoverErpSheets_(ss);
    result.ok = missing.length === 0 && !!calendarSheet && !!changeLogSheet && typeof mcCalendarUnifiedManualInputV01Create === 'function' && typeof mcCalendarOperationHubV01UpdateEvent === 'function';
    result.checks = {
      masterDbOk: !!ss,
      calendarSheetOk: !!calendarSheet,
      changeLogSheetOk: !!changeLogSheet,
      missingHeaderCount: missing.length,
      createReady: typeof mcCalendarUnifiedManualInputV01Create === 'function',
      updateReady: typeof mcCalendarOperationHubV01UpdateEvent === 'function',
      detailReady: typeof mcCalendarOperationHubV01GetDetail === 'function',
      erpEventSheetFound: erpSheets.eventSheets.length > 0,
      erpVendorSheetFound: erpSheets.vendorSheets.length > 0,
      erpCustomerSheetFound: erpSheets.customerSheets.length > 0,
      realApplyExecuted: false,
      destructiveRepairExecuted: false
    };
    result.targetSheets = [
      { sheetName: calendarSheet.getName(), lastRow: calendarSheet.getLastRow(), lastColumn: calendarSheet.getLastColumn() },
      { sheetName: changeLogSheet.getName(), lastRow: changeLogSheet.getLastRow(), lastColumn: changeLogSheet.getLastColumn() }
    ];
    result.erpSheetDiscovery = erpSheets;
    result.missingHeaders = missing;
    result.message = result.ok ? 'ERP 행사연동 캘린더 V01 준비 완료' : 'ERP 행사연동 캘린더 V01 사전점검에서 누락 항목이 있습니다.';
    result.nextAction = result.ok ? 'calErpDry() 실행 후 결과를 확인하세요.' : 'missingHeaders 또는 필수 함수 상태를 먼저 확인하세요.';
  } catch (err) {
    mcCalendarErpEventLinkV01Catch_(result, err);
  }
  return mcCalendarErpEventLinkV01Print_(result);
}

function mcCalendarErpEventLinkV01CreateSampleDryRun() {
  var result = mcCalendarErpEventLinkV01BaseResult_('mcCalendarErpEventLinkV01CreateSampleDryRun');
  try {
    var before = mcCalendarErpEventLinkV01CalendarSheetStatus_();
    var inner = mcCalendarUnifiedManualInputV01Create(mcCalendarErpEventLinkV01SamplePayload_('Y'));
    var after = mcCalendarErpEventLinkV01CalendarSheetStatus_();
    result.ok = !!inner.ok;
    result.innerBuild = inner.build;
    result.innerAction = inner.action;
    result.innerMessage = inner.message;
    result.validation = inner.validation || {};
    result.dryRun = true;
    result.saved = false;
    result.calendarEventId = inner.record && inner.record.calendarEventId ? inner.record.calendarEventId : '';
    result.record = mcCalendarErpEventLinkV01CompactRecord_(inner.record || {});
    result.before = before;
    result.after = after;
    result.rowDelta = (after.lastRow || 0) - (before.lastRow || 0);
    result.message = 'ERP 행사연동 일정 DryRun 완료. Calendar 저장과 ERP 원본 수정은 하지 않았습니다.';
    result.nextAction = '결과 확인 후 실제 저장이 필요하면 calErpSave()를 실행하세요.';
  } catch (err) {
    mcCalendarErpEventLinkV01Catch_(result, err);
  }
  return mcCalendarErpEventLinkV01Print_(result);
}

function mcCalendarErpEventLinkV01CreateSampleReal() {
  var result = mcCalendarErpEventLinkV01BaseResult_('mcCalendarErpEventLinkV01CreateSampleReal');
  try {
    var before = mcCalendarErpEventLinkV01CalendarSheetStatus_();
    var inner = mcCalendarUnifiedManualInputV01Create(mcCalendarErpEventLinkV01SamplePayload_('N'));
    var after = mcCalendarErpEventLinkV01CalendarSheetStatus_();
    result.ok = !!inner.ok && !!inner.saved;
    result.innerBuild = inner.build;
    result.innerAction = inner.action;
    result.innerMessage = inner.message;
    result.validation = inner.validation || {};
    result.duplicateCheck = inner.duplicateCheck || {};
    result.dryRun = false;
    result.saved = !!inner.saved;
    result.calendarEventId = inner.calendarEventId || (inner.record && inner.record.calendarEventId) || '';
    result.record = mcCalendarErpEventLinkV01CompactRecord_(inner.record || {});
    result.before = before;
    result.after = after;
    result.rowDelta = (after.lastRow || 0) - (before.lastRow || 0);
    result.erpSourceMutated = false;
    result.message = result.ok ? 'ERP 행사연동 일정이 캘린더 원장에 저장되었습니다. ERP 원본은 수정하지 않았습니다.' : 'ERP 행사연동 일정 저장 실패';
    result.nextAction = 'calErpCheck() 실행 후 캘린더 화면에서 표시를 확인하세요.';
  } catch (err) {
    mcCalendarErpEventLinkV01Catch_(result, err);
  }
  return mcCalendarErpEventLinkV01Print_(result);
}

function mcCalendarErpEventLinkV01VerifyRecent() {
  var result = mcCalendarErpEventLinkV01BaseResult_('mcCalendarErpEventLinkV01VerifyRecent');
  try {
    var recent = mcCalendarErpEventLinkV01ListRecentLinkedEvents_(10, 'ERP_EVENT');
    var target = recent.length ? recent[0] : null;
    if (!target) throw new Error('최근 ERP_EVENT 연동 일정이 없습니다. 먼저 calErpSave()를 실행하세요.');
    var detail = mcCalendarOperationHubV01GetDetail({ calendarEventId: target.calendarEventId });
    var ev = detail.event || {};
    var checks = {
      sourceTypeOk: String(ev.sourceType || '').toUpperCase() === 'ERP_EVENT',
      eventIdOk: !!ev.eventId,
      relatedEventIdOk: !!ev.relatedEventId,
      sourcePolicyOk: ['READONLY_SOURCE','SYNC_TO_SOURCE','CALENDAR_ONLY'].indexOf(String(ev.sourceWritePolicy || '').toUpperCase()) >= 0,
      sourceUpdateStatusOk: !!ev.sourceUpdateStatus,
      ownerOk: !!ev.ownerName,
      participantOk: !!ev.participantJson,
      noGoogleApply: true,
      noDestructiveRepair: true
    };
    result.ok = Object.keys(checks).every(function(k) { return checks[k] === true; });
    result.checks = checks;
    result.calendarEventId = target.calendarEventId;
    result.compactDetail = mcCalendarErpEventLinkV01CompactRecord_(ev);
    result.message = result.ok ? '최근 ERP_EVENT 연동 일정 검증 완료' : '최근 ERP_EVENT 연동 일정 검증에서 누락 항목이 있습니다.';
    result.nextAction = result.ok ? '필요하면 calErpEdit()로 원본 미수정 정책을 확인하세요.' : 'compactDetail의 eventId/sourceWritePolicy/sourceUpdateStatus를 확인하세요.';
  } catch (err) {
    mcCalendarErpEventLinkV01Catch_(result, err);
  }
  return mcCalendarErpEventLinkV01Print_(result);
}

function mcCalendarErpEventLinkV01UpdateRecentSample() {
  var result = mcCalendarErpEventLinkV01BaseResult_('mcCalendarErpEventLinkV01UpdateRecentSample');
  try {
    var recent = mcCalendarErpEventLinkV01ListRecentLinkedEvents_(10, 'ERP_EVENT');
    if (!recent.length) throw new Error('최근 ERP_EVENT 연동 일정이 없습니다. 먼저 calErpSave()를 실행하세요.');
    var target = recent[0];
    var beforeLog = mcCalendarErpEventLinkV01ChangeLogStatus_();
    var inner = mcCalendarOperationHubV01UpdateEvent({
      calendarEventId: target.calendarEventId,
      title: '[ERP연동수정] 입주박람회 협의회 운영 일정',
      ownerName: '이용필 총괄',
      ownerUserId: 'USER-YONGPIL-001',
      departmentCode: 'OPERATION',
      participantText: '이용필, 최유라, 협의회 담당자, 행사 운영 담당자',
      agendaText: 'ERP 행사 원장 기준 일정 변경 요청 사항 확인\n업체/고객/설치 일정 캘린더 표시 기준 점검',
      decisionMemo: '캘린더 표시정보는 수정하되 ERP 원본 직접 덮어쓰기는 하지 않는다.',
      todoText: 'ERP_EVENT_LINK 승인 반영 정책 설계\n행사관리 화면에서 eventId 기준 역조회 확인',
      sourceWritePolicy: 'SYNC_TO_SOURCE',
      changeReason: 'ERP_EVENT_LINK_V01 수정 검증: 캘린더 표시정보 변경 및 원본 반영 승인대기 처리'
    });
    var afterLog = mcCalendarErpEventLinkV01ChangeLogStatus_();
    result.ok = !!inner.ok;
    result.inner = mcCalendarErpEventLinkV01CompactUpdate_(inner);
    result.changeLogBefore = beforeLog;
    result.changeLogAfter = afterLog;
    result.changeLogDelta = (afterLog.lastRow || 0) - (beforeLog.lastRow || 0);
    result.erpSourceMutated = false;
    result.message = result.ok ? 'ERP_EVENT 연동 일정 수정 테스트 완료. ERP 원본 직접 수정은 하지 않았습니다.' : 'ERP_EVENT 연동 일정 수정 테스트 실패';
    result.nextAction = 'calErpCheck()로 sourceUpdateStatus가 PENDING/APPROVAL_REQUIRED로 남는지 확인하세요.';
  } catch (err) {
    mcCalendarErpEventLinkV01Catch_(result, err);
  }
  return mcCalendarErpEventLinkV01Print_(result);
}

function mcCalendarErpEventLinkV01ListRecent5() {
  var result = mcCalendarErpEventLinkV01BaseResult_('mcCalendarErpEventLinkV01ListRecent5');
  try {
    var list = mcCalendarErpEventLinkV01ListRecentLinkedEvents_(5, '');
    result.ok = true;
    result.summary = { displayed: list.length, output: 'ERP_AND_OPERATION_LINKS' };
    result.recentEvents = list;
    result.message = '최근 ERP/운영 캘린더 연동 일정 5건 조회 완료';
    result.nextAction = '캘린더 화면에서 eventId/vendorId/customerId 표시를 확인하세요.';
  } catch (err) {
    mcCalendarErpEventLinkV01Catch_(result, err);
  }
  return mcCalendarErpEventLinkV01Print_(result);
}

function mcCalendarErpEventLinkV01DiscoverErpSheets() {
  var result = mcCalendarErpEventLinkV01BaseResult_('mcCalendarErpEventLinkV01DiscoverErpSheets');
  try {
    var ss = mcCalendarUnifiedManualInputV01OpenMaster_();
    result.ok = true;
    result.discovery = mcCalendarErpEventLinkV01DiscoverErpSheets_(ss);
    result.message = 'ERP 연동 후보 시트 조회 완료. 시트 생성/수정은 하지 않았습니다.';
    result.nextAction = 'eventSheets/vendorSheets/customerSheets 후보를 확인하세요.';
  } catch (err) {
    mcCalendarErpEventLinkV01Catch_(result, err);
  }
  return mcCalendarErpEventLinkV01Print_(result);
}

function mcCalendarErpEventLinkV01SamplePayload_(dryRun) {
  var nowKey = mcCalendarErpEventLinkV01NowKey_();
  return {
    dryRun: dryRun,
    title: '[ERP연동] 입주박람회 협의회 운영 일정',
    sourceType: 'ERP_EVENT',
    sourceModule: 'ERP_EVENT_CENTER',
    sourceId: 'EVENT-SAMPLE-' + nowKey,
    eventId: 'EVENT-SAMPLE-' + nowKey,
    vendorId: 'VENDOR-SAMPLE-001',
    customerId: '',
    relatedEventId: 'EVENT-SAMPLE-' + nowKey,
    relatedVendorId: 'VENDOR-SAMPLE-001',
    relatedCustomerId: '',
    description: 'ERP 행사관리 원장과 연결되는 운영 캘린더 샘플입니다. ERP 원본은 직접 수정하지 않습니다.',
    startAt: mcCalendarErpEventLinkV01TodayAt_('15:00:00'),
    endAt: mcCalendarErpEventLinkV01TodayAt_('16:00:00'),
    location: 'FEELHAUS 회의실 / 행사 운영센터',
    attendeesText: 'pepsi309@gmail.com, feelhaus@feelhausfair.com',
    organizerEmail: 'feelhaus@feelhausfair.com',
    ownerName: '이용필 총괄',
    ownerUserId: 'USER-YONGPIL-001',
    departmentCode: 'OPERATION',
    eventGroupType: 'FAIR_EVENT',
    operationType: 'ERP_EVENT_LINK',
    participantText: '이용필, 최유라, 행사 운영 담당자',
    externalPartyText: '입주예정자 협의회, 참여업체 담당자',
    agendaText: '행사 일정 기준 확인\n업체 참여 일정 연결\n고객 상담 동선 일정 확인',
    decisionMemo: '캘린더는 ERP eventId를 참조하고 원본 직접 덮어쓰기는 하지 않는다.',
    todoText: '행사관리 화면에서 eventId 역조회\n업체/고객 일정 필터 연결\n승인 기반 원본 반영 정책 추가',
    councilName: '입주예정자 협의회',
    fairName: '필하우스 입주박람회',
    meetingPurpose: 'ERP 행사관리 일정 캘린더 연결 검증',
    meetingMethod: 'OFFLINE',
    presentationType: 'COUNCIL',
    categoryCode: 'EVENT',
    customTypeName: 'ERP 행사연동',
    priority: 'HIGH',
    privacyLevel: 'DEFAULT',
    busyStatus: 'BUSY',
    repeatType: 'NONE',
    reminderMinutesText: '30,1440',
    eventStatus: 'SCHEDULED',
    syncTarget: 'NONE',
    sourceWritePolicy: 'READONLY_SOURCE',
    sourceUpdateStatus: 'NOT_REQUIRED',
    changeReason: 'ERP_EVENT_LINK_V01 샘플 등록: 캘린더 원장 연결 검증'
  };
}

function mcCalendarErpEventLinkV01RequiredHeaders_() {
  return ['calendarEventId','sourceType','sourceModule','sourceId','eventId','vendorId','customerId','relatedEventId','relatedVendorId','relatedCustomerId','title','eventTitle','startAt','endAt','ownerName','ownerUserId','departmentCode','eventGroupType','operationType','participantJson','externalPartyJson','agendaJson','todoJson','decisionMemo','sourceWritePolicy','sourceUpdateStatus','changeReason','lastChangedFields','eventStatus','status','createdAt','createdBy','updatedAt','updatedBy'];
}

function mcCalendarErpEventLinkV01DiscoverErpSheets_(ss) {
  var aliases = {
    eventSheets: ['ERP_행사관리','ERP_행사','ERP_Events','ERP_Event','ERP_EventMaster','Events','EventMaster','EventList','EventCenterEvents','EventVendor','EventVendorMaster'],
    vendorSheets: ['ERP_업체관리','ERP_업체','ERP_Vendors','ERP_VendorMaster','Vendors','VendorMaster','업체관리','업체','협력업체'],
    customerSheets: ['ERP_고객관리','ERP_고객','ERP_Customers','Customers','CustomerMaster','고객관리','고객'],
    installSheets: ['ERP_설치관리','ERP_설치','Installations','Installation','설치관리'],
    asSheets: ['ERP_AS관리','ERP_A/S관리','AS_Requests','ASRequests','A/S관리','AS관리']
  };
  var out = {};
  Object.keys(aliases).forEach(function(group) {
    out[group] = aliases[group].map(function(name) {
      var sh = ss.getSheetByName(name);
      return sh ? { sheetName: name, exists: true, lastRow: sh.getLastRow(), lastColumn: sh.getLastColumn() } : null;
    }).filter(function(x) { return !!x; });
  });
  out.note = '조회 전용입니다. ERP 후보 시트를 생성하거나 수정하지 않습니다.';
  return out;
}

function mcCalendarErpEventLinkV01ListRecentLinkedEvents_(limit, sourceTypeFilter) {
  limit = Math.max(1, Math.min(Number(limit || 5), 20));
  sourceTypeFilter = String(sourceTypeFilter || '').toUpperCase();
  var ss = mcCalendarUnifiedManualInputV01OpenMaster_();
  var sheet = mcCalendarUnifiedManualInputV01GetSheetOrCreate_(ss, 'MAILCENTER_CalendarEvents', mcCalendarOperationHubV01CalendarHeaders_());
  var values = sheet.getDataRange().getValues();
  if (values.length < 2) return [];
  var headers = values[0];
  var hm = mcCalendarUnifiedManualInputV01HeaderMap_(headers);
  var out = [];
  for (var r = values.length - 1; r >= 1 && out.length < limit; r--) {
    var rec = {};
    headers.forEach(function(h, i) { rec[h] = values[r][i]; });
    var st = String(rec.sourceType || rec.calendarType || '').toUpperCase();
    if (sourceTypeFilter && st !== sourceTypeFilter) continue;
    if (!sourceTypeFilter && ['ERP_EVENT','ERP_INSTALL','ERP_AS','ERP_CUSTOMER','MANUAL'].indexOf(st) < 0) continue;
    out.push({
      rowNumber: r + 1,
      calendarEventId: rec.calendarEventId || '',
      sourceType: rec.sourceType || '',
      eventId: rec.eventId || rec.relatedEventId || '',
      vendorId: rec.vendorId || rec.relatedVendorId || '',
      customerId: rec.customerId || rec.relatedCustomerId || '',
      title: rec.title || rec.eventTitle || '',
      startAt: rec.startAt || '',
      endAt: rec.endAt || '',
      eventGroupType: rec.eventGroupType || '',
      operationType: rec.operationType || '',
      ownerName: rec.ownerName || '',
      sourceWritePolicy: rec.sourceWritePolicy || '',
      sourceUpdateStatus: rec.sourceUpdateStatus || '',
      status: rec.eventStatus || rec.status || ''
    });
  }
  return out;
}

function mcCalendarErpEventLinkV01CalendarSheetStatus_() {
  try {
    var ss = mcCalendarUnifiedManualInputV01OpenMaster_();
    var sh = ss.getSheetByName('MAILCENTER_CalendarEvents');
    return sh ? { sheetName: sh.getName(), exists: true, lastRow: sh.getLastRow(), lastColumn: sh.getLastColumn() } : { sheetName: 'MAILCENTER_CalendarEvents', exists: false, lastRow: 0, lastColumn: 0 };
  } catch (err) {
    return { sheetName: 'MAILCENTER_CalendarEvents', exists: false, error: String(err && err.message ? err.message : err) };
  }
}

function mcCalendarErpEventLinkV01ChangeLogStatus_() {
  try {
    var ss = mcCalendarUnifiedManualInputV01OpenMaster_();
    var sh = ss.getSheetByName('MAILCENTER_CalendarChangeLogs');
    return sh ? { sheetName: sh.getName(), exists: true, lastRow: sh.getLastRow(), lastColumn: sh.getLastColumn() } : { sheetName: 'MAILCENTER_CalendarChangeLogs', exists: false, lastRow: 0, lastColumn: 0 };
  } catch (err) {
    return { sheetName: 'MAILCENTER_CalendarChangeLogs', exists: false, error: String(err && err.message ? err.message : err) };
  }
}

function mcCalendarErpEventLinkV01CompactRecord_(rec) {
  rec = rec || {};
  return {
    calendarEventId: rec.calendarEventId || '',
    sourceType: rec.sourceType || '',
    sourceModule: rec.sourceModule || '',
    sourceId: rec.sourceId || '',
    eventId: rec.eventId || '',
    vendorId: rec.vendorId || '',
    customerId: rec.customerId || '',
    relatedEventId: rec.relatedEventId || '',
    relatedVendorId: rec.relatedVendorId || '',
    relatedCustomerId: rec.relatedCustomerId || '',
    title: rec.title || rec.eventTitle || '',
    startAt: rec.startAt || '',
    endAt: rec.endAt || '',
    eventGroupType: rec.eventGroupType || '',
    operationType: rec.operationType || '',
    ownerName: rec.ownerName || '',
    ownerUserId: rec.ownerUserId || '',
    departmentCode: rec.departmentCode || '',
    councilName: rec.councilName || '',
    fairName: rec.fairName || '',
    sourceWritePolicy: rec.sourceWritePolicy || '',
    sourceUpdateStatus: rec.sourceUpdateStatus || '',
    eventStatus: rec.eventStatus || rec.status || '',
    googleSyncStatus: rec.googleSyncStatus || '',
    naverSyncStatus: rec.naverSyncStatus || '',
    createdAt: rec.createdAt || '',
    updatedAt: rec.updatedAt || ''
  };
}

function mcCalendarErpEventLinkV01CompactUpdate_(inner) {
  inner = inner || {};
  return {
    ok: !!inner.ok,
    calendarEventId: inner.calendarEventId || '',
    message: inner.message || '',
    changedFields: inner.changedFields || [],
    policy: inner.policy || {},
    sourceType: inner.sourceType || '',
    record: mcCalendarErpEventLinkV01CompactRecord_(inner.record || {})
  };
}

function mcCalendarErpEventLinkV01TodayAt_(timeText) {
  var d = new Date();
  var yyyy = d.getFullYear();
  var mm = String(d.getMonth() + 1); if (mm.length < 2) mm = '0' + mm;
  var dd = String(d.getDate()); if (dd.length < 2) dd = '0' + dd;
  return yyyy + '-' + mm + '-' + dd + ' ' + timeText;
}

function mcCalendarErpEventLinkV01NowKey_() {
  var d = new Date();
  function pad(n) { n = String(n); return n.length < 2 ? '0' + n : n; }
  return String(d.getFullYear()) + pad(d.getMonth() + 1) + pad(d.getDate()) + pad(d.getHours()) + pad(d.getMinutes()) + pad(d.getSeconds());
}

function mcCalendarErpEventLinkV01BaseResult_(action) {
  return {
    ok: false,
    build: MC_CALENDAR_ERP_EVENT_LINK_V01_BUILD,
    action: action,
    generatedAt: mcCalendarErpEventLinkV01Now_(),
    realApplyExecuted: false,
    destructiveRepairExecuted: false,
    warnings: [],
    errors: []
  };
}

function mcCalendarErpEventLinkV01Now_() {
  try {
    return Utilities.formatDate(new Date(), 'Asia/Seoul', 'yyyy-MM-dd HH:mm:ss');
  } catch (err) {
    return new Date().toISOString();
  }
}

function mcCalendarErpEventLinkV01Catch_(result, err) {
  result.ok = false;
  result.message = String(err && err.message ? err.message : err);
  result.errors = result.errors || [];
  result.errors.push({ message: String(err && err.message ? err.message : err), stack: String(err && err.stack ? err.stack : '') });
  result.nextAction = '오류 메시지와 missingHeaders/필수 함수 상태를 확인하세요.';
}

function mcCalendarErpEventLinkV01Print_(result) {
  result.endedAt = mcCalendarErpEventLinkV01Now_();
  result.realApplyExecuted = false;
  result.destructiveRepairExecuted = false;
  try {
    Logger.log('JSON_COMPACT_RESULT: ' + JSON.stringify(result));
  } catch (err) {}
  return result;
}
