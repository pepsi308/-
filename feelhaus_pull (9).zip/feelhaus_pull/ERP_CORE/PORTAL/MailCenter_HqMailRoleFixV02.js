/**
 * FEELHAUS MailCenter HQ Mail Role Fix V02
 * Build: MAILCENTER_HQ_MAIL_ROLE_FIX_V02_20260519
 *
 * Fix:
 * - V01 error: Cannot read properties of null (reading 'getSheetByName')
 * - V02 opens FEELHAUS_SETUP_DB > SystemConfig > FEELHAUS_DB_MASTER directly.
 *
 * Role:
 * - feelhaus@feelhausfair.com = HQ_OFFICIAL / 본사 공식 대표메일
 * - pepsi309@gmail.com = HQ_STAFF / 본사 직원용 메일
 */

var MAILCENTER_HQ_MAIL_ROLE_FIX_V02_BUILD = 'MAILCENTER_HQ_MAIL_ROLE_FIX_V02_20260519';
var MAILCENTER_HQ_MAIL_ROLE_FIX_V02_SETUP_DB_ID = '17VMSpgSZCvIrUlgcw8yCNcnl8WQWo2IcRf5tDCcuJGM';
var MAILCENTER_HQ_MAIL_ROLE_FIX_V02_CONFIG_SHEET = 'SystemConfig';

function runMailCenterHqMailRoleFixV02() {
  var result = {
    ok: false,
    build: MAILCENTER_HQ_MAIL_ROLE_FIX_V02_BUILD,
    action: 'runMailCenterHqMailRoleFixV02',
    generatedAt: mailCenterHqMailRoleFixV02Now_(),
    message: '',
    officialEmail: 'feelhaus@feelhausfair.com',
    staffEmail: 'pepsi309@gmail.com',
    masterDbId: '',
    spreadsheetName: '',
    officialAccount: null,
    staffAccount: null,
    officialOAuth: null,
    warnings: []
  };

  try {
    if (typeof mailCenterSetupStandaloneGateOnce === 'function') {
      mailCenterSetupStandaloneGateOnce();
    }

    var masterInfo = mailCenterHqMailRoleFixV02OpenMaster_();
    var ss = masterInfo.ss;
    result.masterDbId = masterInfo.masterDbId;
    result.spreadsheetName = ss.getName();

    var accountSheet = mailCenterHqMailRoleFixV02GetSheetOrCreate_(ss, 'MailCenter_Accounts', [
      'mailAccountId','vendorId','eventId','ownerType','ownerName','emailAddress','provider',
      'mailAccountStatus','statusReason','approvalStatus','requestedBy','requestedAt',
      'approvedBy','approvedAt','lastConnectedAt','lastSyncAt','createdAt','createdBy',
      'updatedAt','updatedBy','accountPurpose','isPrimary','displayName','roleMemo'
    ]);

    var official = mailCenterHqMailRoleFixV02UpsertAccount_(accountSheet, {
      emailAddress: 'feelhaus@feelhausfair.com',
      vendorId: '',
      ownerType: 'HQ',
      ownerName: '(주)필하우스 본사 대표메일',
      provider: 'Google Workspace',
      mailAccountStatus: 'ACTIVE',
      approvalStatus: 'APPROVED',
      accountPurpose: 'HQ_OFFICIAL',
      isPrimary: 'TRUE',
      displayName: '(주)필하우스 본사 대표메일',
      roleMemo: '본사용 공식 대표메일. 대외/본사 공지/본사 발송 기본 계정.',
      statusReason: '본사 공식 대표메일로 세팅',
      actor: 'MailCenterHqRoleFixV02'
    });

    var staff = mailCenterHqMailRoleFixV02UpsertAccount_(accountSheet, {
      emailAddress: 'pepsi309@gmail.com',
      vendorId: '',
      ownerType: 'HQ_STAFF',
      ownerName: '이용필 본사 직원메일',
      provider: 'Gmail',
      mailAccountStatus: 'ACTIVE',
      approvalStatus: 'APPROVED',
      accountPurpose: 'HQ_STAFF',
      isPrimary: 'FALSE',
      displayName: '이용필 본사 직원메일',
      roleMemo: '본사 대표메일 아님. 본사 직원/개발/테스트용 계정.',
      statusReason: '본사 직원용 메일로 전환',
      actor: 'MailCenterHqRoleFixV02'
    });

    result.officialAccount = official;
    result.staffAccount = staff;

    if (typeof mailCenterBuildOAuthConnectUrl === 'function') {
      result.officialOAuth = mailCenterBuildOAuthConnectUrl('', {
        mailAccountId: official.mailAccountId,
        vendorId: '',
        ownerType: 'HQ',
        ownerName: '(주)필하우스 본사 대표메일',
        emailAddress: 'feelhaus@feelhausfair.com',
        provider: 'Google Workspace'
      });
    } else {
      result.warnings.push('mailCenterBuildOAuthConnectUrl 함수가 없어 본사 공식 대표메일 OAuth URL은 생성하지 못했습니다.');
    }

    mailCenterHqMailRoleFixV02AppendAudit_(ss, {
      actionType: 'HQ_MAIL_ROLE_FIX',
      targetType: 'MailCenter_Accounts',
      targetId: official.mailAccountId + ',' + staff.mailAccountId,
      vendorId: '',
      beforeValue: 'pepsi309@gmail.com treated as HQ representative in previous test context',
      afterValue: 'feelhaus@feelhausfair.com=HQ_OFFICIAL, pepsi309@gmail.com=HQ_STAFF',
      reason: '본사 대표메일/본사 직원메일 역할 정정',
      createdBy: 'MailCenterHqRoleFixV02'
    });

    result.ok = true;
    result.message = '본사 공식 대표메일과 본사 직원메일 역할 정정 완료';
  } catch (err) {
    result.ok = false;
    result.message = String(err && err.message ? err.message : err);
  }

  mailCenterHqMailRoleFixV02Log_(result);
  return result;
}

function mailCenterHqMailRoleFixV02OpenMaster_() {
  if (typeof portal19GetConfigBundle_ === 'function' && typeof portal19OpenMaster_ === 'function') {
    var bundle = portal19GetConfigBundle_();
    var ssByPortal = portal19OpenMaster_(bundle);
    if (ssByPortal) {
      return { ss: ssByPortal, masterDbId: bundle.masterDbId || '' };
    }
  }

  var setup = SpreadsheetApp.openById(MAILCENTER_HQ_MAIL_ROLE_FIX_V02_SETUP_DB_ID);
  var configSheet = setup.getSheetByName(MAILCENTER_HQ_MAIL_ROLE_FIX_V02_CONFIG_SHEET);
  if (!configSheet) throw new Error('SystemConfig 시트를 찾지 못했습니다.');

  var values = configSheet.getDataRange().getValues();
  if (!values || values.length < 2) throw new Error('SystemConfig 데이터가 비어 있습니다.');

  var hm = mailCenterHqMailRoleFixV02HeaderMap_(values[0]);
  var keyCol = mailCenterHqMailRoleFixV02FindHeader_(hm, ['CONFIG_KEY','configKey','KEY','key']);
  var valCol = mailCenterHqMailRoleFixV02FindHeader_(hm, ['VALUE','CONFIG_VALUE','configValue','value']);
  if (keyCol < 0 || valCol < 0) {
    throw new Error('SystemConfig 필수 헤더(CONFIG_KEY/VALUE)를 찾지 못했습니다.');
  }

  var map = {};
  for (var r = 1; r < values.length; r++) {
    var key = String(values[r][keyCol] || '').trim();
    if (key) map[key] = values[r][valCol];
  }

  var masterDbId = '';
  var keys = ['FEELHAUS_DB_MASTER','FEELHAUS_DB_MASTER_ID','MASTER_DB_ID','DB_MASTER_ID'];
  for (var i = 0; i < keys.length; i++) {
    if (map[keys[i]]) {
      masterDbId = String(map[keys[i]]).trim();
      break;
    }
  }
  if (!masterDbId) throw new Error('SystemConfig에서 FEELHAUS_DB_MASTER ID를 찾지 못했습니다.');

  return { ss: SpreadsheetApp.openById(masterDbId), masterDbId: masterDbId };
}

function mailCenterHqMailRoleFixV02UpsertAccount_(sh, spec) {
  var now = mailCenterHqMailRoleFixV02Now_();
  var data = sh.getDataRange().getValues();
  var hm = mailCenterHqMailRoleFixV02HeaderMap_(data[0]);
  var email = String(spec.emailAddress || '').trim();
  if (!email) throw new Error('emailAddress 값이 없습니다.');

  var foundRow = -1;
  for (var r = 1; r < data.length; r++) {
    if (String(data[r][hm.emailAddress] || '').trim().toLowerCase() === email.toLowerCase()) {
      foundRow = r + 1;
      break;
    }
  }

  var mailAccountId = '';
  if (foundRow > 0) {
    mailAccountId = String(sh.getRange(foundRow, hm.mailAccountId + 1).getValue() || '').trim();
  }
  if (!mailAccountId) {
    mailAccountId = 'MAILACC-' + Utilities.formatDate(new Date(), Session.getScriptTimeZone() || 'Asia/Seoul', 'yyyyMMddHHmmss') + '-' + Math.floor(Math.random() * 9000 + 1000);
  }

  var obj = {
    mailAccountId: mailAccountId,
    vendorId: spec.vendorId,
    eventId: '',
    ownerType: spec.ownerType,
    ownerName: spec.ownerName,
    emailAddress: email,
    provider: spec.provider,
    mailAccountStatus: spec.mailAccountStatus,
    statusReason: spec.statusReason,
    approvalStatus: spec.approvalStatus,
    requestedBy: spec.actor,
    requestedAt: now,
    approvedBy: spec.actor,
    approvedAt: now,
    updatedAt: now,
    updatedBy: spec.actor,
    accountPurpose: spec.accountPurpose,
    isPrimary: spec.isPrimary,
    displayName: spec.displayName,
    roleMemo: spec.roleMemo
  };

  if (foundRow < 0) {
    obj.createdAt = now;
    obj.createdBy = spec.actor;
    var row = new Array(data[0].length).fill('');
    Object.keys(obj).forEach(function(k) {
      if (hm[k] != null) row[hm[k]] = obj[k];
    });
    sh.appendRow(row);
  } else {
    Object.keys(obj).forEach(function(k) {
      if (hm[k] != null) sh.getRange(foundRow, hm[k] + 1).setValue(obj[k]);
    });
  }

  return {
    mailAccountId: mailAccountId,
    emailAddress: email,
    ownerType: spec.ownerType,
    accountPurpose: spec.accountPurpose,
    isPrimary: spec.isPrimary,
    mailAccountStatus: spec.mailAccountStatus,
    approvalStatus: spec.approvalStatus
  };
}

function mailCenterHqMailRoleFixV02GetSheetOrCreate_(ss, sheetName, headers) {
  var sh = ss.getSheetByName(sheetName);
  if (!sh) sh = ss.insertSheet(sheetName);

  var lastRow = sh.getLastRow();
  var lastCol = sh.getLastColumn();
  if (lastRow < 1 || lastCol < 1) {
    sh.getRange(1, 1, 1, headers.length).setValues([headers]);
    return sh;
  }

  var existing = sh.getRange(1, 1, 1, lastCol).getValues()[0].map(function(v) {
    return String(v || '').trim();
  });
  var append = [];
  headers.forEach(function(h) {
    if (existing.indexOf(h) < 0) append.push(h);
  });
  if (append.length) {
    sh.getRange(1, existing.length + 1, 1, append.length).setValues([append]);
  }
  return sh;
}

function mailCenterHqMailRoleFixV02AppendAudit_(ss, spec) {
  var sh = mailCenterHqMailRoleFixV02GetSheetOrCreate_(ss, 'MailCenter_AuditLogs', [
    'mailAuditLogId','targetType','targetId','vendorId','eventId','actionType',
    'beforeValue','afterValue','reason','createdAt','createdBy'
  ]);

  var data = sh.getDataRange().getValues();
  var hm = mailCenterHqMailRoleFixV02HeaderMap_(data[0]);
  var row = new Array(data[0].length).fill('');
  var now = mailCenterHqMailRoleFixV02Now_();
  var obj = {
    mailAuditLogId: 'MAILAUD-' + Utilities.formatDate(new Date(), Session.getScriptTimeZone() || 'Asia/Seoul', 'yyyyMMddHHmmss') + '-' + Math.floor(Math.random() * 9000 + 1000),
    targetType: spec.targetType,
    targetId: spec.targetId,
    vendorId: spec.vendorId,
    eventId: '',
    actionType: spec.actionType,
    beforeValue: spec.beforeValue,
    afterValue: spec.afterValue,
    reason: spec.reason,
    createdAt: now,
    createdBy: spec.createdBy
  };
  Object.keys(obj).forEach(function(k) {
    if (hm[k] != null) row[hm[k]] = obj[k];
  });
  sh.appendRow(row);
}

function mailCenterHqMailRoleFixV02HeaderMap_(header) {
  var hm = {};
  for (var i = 0; i < header.length; i++) {
    var raw = String(header[i] || '').trim();
    if (!raw) continue;
    hm[raw] = i;
    var norm = mailCenterHqMailRoleFixV02Normalize_(raw);
    if (norm && hm[norm] == null) hm[norm] = i;
  }
  return hm;
}

function mailCenterHqMailRoleFixV02FindHeader_(hm, names) {
  for (var i = 0; i < names.length; i++) {
    if (hm[names[i]] != null) return hm[names[i]];
    var norm = mailCenterHqMailRoleFixV02Normalize_(names[i]);
    if (hm[norm] != null) return hm[norm];
  }
  return -1;
}

function mailCenterHqMailRoleFixV02Normalize_(v) {
  return String(v || '').trim().toUpperCase().replace(/[^A-Z0-9]/g, '');
}

function mailCenterHqMailRoleFixV02Now_() {
  return Utilities.formatDate(new Date(), Session.getScriptTimeZone() || 'Asia/Seoul', 'yyyy-MM-dd HH:mm:ss');
}

function mailCenterHqMailRoleFixV02Log_(obj) {
  try {
    Logger.log('JSON_COMPACT_RESULT: ' + JSON.stringify(obj));
  } catch (e) {
    Logger.log(obj);
  }
}
