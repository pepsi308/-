var PORTAL_CALENDAR_SAFE01B_R10J1_HEADER_MODAL_SAFE_OPEN_BUILD = 'PORTAL_CALENDAR_SAFE01B_R10J1_HEADER_MODAL_SAFE_OPEN_20260603';
var PORTAL_CALENDAR_SAFE01B_R10J4_BASIC_INFO_BUILD = 'PORTAL_CALENDAR_SAFE01B_R10J4_BASIC_INFO_EXPANSION_20260603';
/**
 * FEELHAUS PORTAL / MailCenter Calendar Unified Manual Input V01
 * Build: PORTAL_MC_CALENDAR_UNIFIED_MANUAL_INPUT_V01_20260528
 * Purpose:
 * - MailCenter Calendar에 고급 수동일정 등록 기능을 추가한다.
 * - 메일연동/행사연동/수동입력/Google Sync 후보를 하나의 MAILCENTER_CalendarEvents 원장 기준으로 관리한다.
 * - 실제 Google Calendar 생성은 하지 않는다. syncTarget=GOOGLE 또는 BOTH인 경우 DryRun 후보 상태만 저장한다.
 */
var MC_CALENDAR_UNIFIED_MANUAL_INPUT_V01_BUILD = 'PORTAL_MC_CALENDAR_UNIFIED_MANUAL_INPUT_V01_20260528';
var PORTAL_CALENDAR_SAFE01B_R5_ACTOR_ONLY_BUILD = 'PORTAL_CALENDAR_SAFE01B_R5_ACTOR_ONLY_20260602';
var PORTAL_CALENDAR_SAFE01B_R7_GOOGLE_EMAIL_ACTOR_MAP_BUILD = 'PORTAL_CALENDAR_SAFE01B_R7_GOOGLE_EMAIL_ACTOR_MAP_20260602';
var PORTAL_CALENDAR_SAFE01B_R7C_UPDATEDBY_USER_LOCK_BUILD = 'PORTAL_CALENDAR_SAFE01B_R7C_UPDATEDBY_USER_LOCK_20260602';
var PORTAL_CALENDAR_SAFE01B_R10F_BUSINESS_TYPE_MODAL_BUILD = 'PORTAL_CALENDAR_SAFE01B_R10F2_BUSINESS_TYPE_MODAL_APPLY_FIX_20260603';

function mcCalendarUnifiedManualInputV01SelfTest() {
  var result = mcCalendarUnifiedManualInputV01BaseResult_('mcCalendarUnifiedManualInputV01SelfTest');
  try {
    var ss = mcCalendarUnifiedManualInputV01OpenMaster_();
    var sheet = mcCalendarUnifiedManualInputV01GetSheetOrCreate_(ss, 'MAILCENTER_CalendarEvents', mcCalendarUnifiedManualInputV01CalendarHeaders_());
    var hm = mcCalendarUnifiedManualInputV01HeaderMap_(sheet.getRange(1, 1, 1, Math.max(sheet.getLastColumn(), 1)).getValues()[0]);
    var missing = mcCalendarUnifiedManualInputV01CalendarHeaders_().filter(function(h) { return hm[h] === undefined; });
    result.checks = {
      masterDbOk: !!ss,
      calendarSheetOk: !!sheet,
      missingHeaderCount: missing.length,
      createFunctionReady: typeof mcCalendarUnifiedManualInputV01Create === 'function',
      optionsFunctionReady: typeof mcCalendarUnifiedManualInputV01GetOptions === 'function',
      googleRealApplyExecuted: false,
      destructiveRepairExecuted: false
    };
    result.targetSheets = [{ sheetName: sheet.getName(), lastRow: sheet.getLastRow(), lastColumn: sheet.getLastColumn() }];
    result.missingHeaders = missing;
    result.ok = missing.length === 0;
    result.message = result.ok ? '고급 수동일정 등록 V01 준비 완료' : '필수 헤더 보강 필요';
    result.nextAction = '캘린더 화면에서 수동일정 등록 또는 mcCalendarUnifiedManualInputV01CreateSampleDryRun 실행';
  } catch (err) {
    mcCalendarUnifiedManualInputV01Catch_(result, err);
  }
  return mcCalendarUnifiedManualInputV01Print_(result);
}

function mcCalendarUnifiedManualInputV01GetOptions() {
  var result = mcCalendarUnifiedManualInputV01BaseResult_('mcCalendarUnifiedManualInputV01GetOptions');
  result.ok = true;
  result.options = {
    sourceTypes: [
      { value: 'MANUAL', label: '수동 입력' },
      { value: 'MAIL_RECEIVED', label: '수신메일 연동' },
      { value: 'MAIL_SENT', label: '발신메일 연동' },
      { value: 'MAIL_SCHEDULED', label: '예약발송' },
      { value: 'ERP_EVENT', label: '행사' },
      { value: 'ERP_INSTALL', label: '설치' },
      { value: 'ERP_AS', label: 'A/S' },
      { value: 'ERP_CUSTOMER', label: '고객상담' },
      { value: 'GOOGLE_IMPORTED', label: 'Google 수신' }
    ],
    categories: [
      { value: 'INTERNAL', label: '내부업무' },
      { value: 'MEETING', label: '회의' },
      { value: 'EVENT', label: '행사' },
      { value: 'VENDOR', label: '업체미팅' },
      { value: 'CUSTOMER', label: '고객상담' },
      { value: 'INSTALL', label: '설치' },
      { value: 'AS', label: 'A/S' },
      { value: 'SETTLEMENT', label: '정산' },
      { value: 'REMINDER', label: '알림/할일' },
      { value: 'ETC', label: '기타' }
    ],
    statuses: [
      { value: 'SCHEDULED', label: '예정' },
      { value: 'REQUESTED', label: '요청' },
      { value: 'IN_PROGRESS', label: '진행중' },
      { value: 'DONE', label: '완료' },
      { value: 'CANCELLED', label: '취소' }
    ],
    repeatTypes: [
      { value: 'NONE', label: '반복 없음' },
      { value: 'DAILY', label: '매일' },
      { value: 'WEEKLY', label: '매주' },
      { value: 'MONTHLY', label: '매월' },
      { value: 'YEARLY', label: '매년' },
      { value: 'CUSTOM', label: '사용자 지정' }
    ],
    syncTargets: [
      { value: 'NONE', label: '외부 동기화 안 함' },
      { value: 'GOOGLE', label: 'Google Sync 후보' },
      { value: 'NAVER_EXPORT', label: 'Naver export 후보' },
      { value: 'BOTH', label: 'Google/Naver 후보' }
    ],
    privacyLevels: [
      { value: 'DEFAULT', label: '기본' },
      { value: 'PUBLIC', label: '공개' },
      { value: 'PRIVATE', label: '비공개' },
      { value: 'CONFIDENTIAL', label: '민감/제한' }
    ],
    busyStatuses: [
      { value: 'BUSY', label: '바쁨' },
      { value: 'FREE', label: '가능' },
      { value: 'TENTATIVE', label: '미정' },
      { value: 'OOO', label: '부재' }
    ],
    reminderMinutes: [0, 5, 10, 15, 30, 60, 120, 1440]
  };
  result.message = '고급 수동일정 옵션 조회 완료';
  result.nextAction = '수동일정 등록 화면에서 옵션을 사용하세요.';
  return mcCalendarUnifiedManualInputV01Print_(result);
}

function mcCalendarUnifiedManualInputV01Create(payload) {
  payload = payload || {};
  var result = mcCalendarUnifiedManualInputV01BaseResult_('mcCalendarUnifiedManualInputV01Create');
  result.realApplyExecuted = false;
  result.destructiveRepairExecuted = false;
  try {
    var actorProfile = mcCalendarUnifiedManualInputV01ResolveActorProfile_(payload);
    var actor = actorProfile.actorKey;
    var now = mcCalendarUnifiedManualInputV01Now_();
    var normalized = mcCalendarUnifiedManualInputV01NormalizePayload_(payload, actor, now, actorProfile);
    var validation = mcCalendarUnifiedManualInputV01Validate_(normalized);
    result.validation = validation;
    if (!validation.ok) {
      result.ok = false;
      result.message = '수동일정 저장 차단: 필수값 또는 형식 오류가 있습니다.';
      result.errors = validation.errors;
      result.nextAction = '제목/시작일시/종료일시/일정구분을 확인하세요.';
      return mcCalendarUnifiedManualInputV01Print_(result);
    }

    if (String(payload.dryRun || '').toUpperCase() === 'Y') {
      result.ok = true;
      result.dryRun = true;
      result.record = mcCalendarUnifiedManualInputV01PublicRecord_(normalized);
      result.message = 'DRY RUN: 실제 저장 없이 수동일정 등록 계획만 반환했습니다.';
      result.nextAction = '실제 저장은 dryRun 없이 실행하세요.';
      return mcCalendarUnifiedManualInputV01Print_(result);
    }

    var ss = mcCalendarUnifiedManualInputV01OpenMaster_();
    var sheet = mcCalendarUnifiedManualInputV01GetSheetOrCreate_(ss, 'MAILCENTER_CalendarEvents', mcCalendarUnifiedManualInputV01CalendarHeaders_());
    var duplicate = mcCalendarUnifiedManualInputV01FindDuplicate_(sheet, normalized);
    result.duplicateCheck = duplicate;
    if (duplicate.found) {
      result.ok = false;
      result.message = '수동일정 저장 차단: 같은 시간대/제목의 중복 의심 일정이 있습니다.';
      result.errors.push({ code: 'DUPLICATE_SUSPECTED', message: duplicate.message, calendarEventId: duplicate.calendarEventId });
      result.nextAction = '기존 일정을 확인하거나 제목/시간을 조정하세요.';
      return mcCalendarUnifiedManualInputV01Print_(result);
    }

    mcCalendarUnifiedManualInputV01AppendByHeaders_(sheet, normalized);
    mcCalendarUnifiedManualInputV01AppendAudit_(ss, {
      actionType: 'CREATE_MANUAL_CALENDAR_EVENT',
      resultStatus: 'SUCCESS',
      calendarEventId: normalized.calendarEventId,
      message: '고급 수동일정 등록 완료',
      payloadSummary: JSON.stringify(mcCalendarUnifiedManualInputV01PublicRecord_(normalized)).slice(0, 900),
      createdAt: now,
      createdBy: actor,
      createdByName: actorProfile.employeeName || '',
      createdByEmail: actorProfile.email || '',
      actorSource: actorProfile.source || ''
    });

    result.ok = true;
    result.saved = true;
    result.calendarEventId = normalized.calendarEventId;
    result.record = mcCalendarUnifiedManualInputV01PublicRecord_(normalized);
    result.googleSyncCandidate = normalized.syncTarget === 'GOOGLE' || normalized.syncTarget === 'BOTH';
    result.naverExportCandidate = normalized.syncTarget === 'NAVER_EXPORT' || normalized.syncTarget === 'BOTH';
    result.message = '고급 수동일정이 MAILCENTER_CalendarEvents에 저장되었습니다.';
    result.nextAction = result.googleSyncCandidate ? 'Google 실반영 전 Preview/DryRun에서 후보로 확인하세요.' : '캘린더 화면을 새로고침해 표시를 확인하세요.';
  } catch (err) {
    mcCalendarUnifiedManualInputV01Catch_(result, err);
  }
  return mcCalendarUnifiedManualInputV01Print_(result);
}

function mcCalendarUnifiedManualInputV01CreateSampleDryRun() {
  return mcCalendarUnifiedManualInputV01Create({
    dryRun: 'Y',
    title: '[샘플] 수동입력 고급 일정',
    sourceType: 'MANUAL',
    categoryCode: 'MEETING',
    startAt: mcCalendarUnifiedManualInputV01TodayAt_('10:00'),
    endAt: mcCalendarUnifiedManualInputV01TodayAt_('10:30'),
    location: 'FEELHAUS 회의실',
    description: '수동입력 고급 일정 저장 구조 점검용 DryRun입니다.',
    attendeesText: 'pepsi309@gmail.com',
    reminderMinutesText: '10,30',
    repeatType: 'NONE',
    syncTarget: 'NONE',
    privacyLevel: 'DEFAULT',
    busyStatus: 'BUSY',
    eventStatus: 'SCHEDULED'
  });
}

function mcCalendarUnifiedManualInputV01NormalizePayload_(payload, actor, now, actorProfile) {
  actorProfile = actorProfile || { actorKey: actor || '', employeeName: '', email: actor || '', source: 'legacy' };
  var startAt = mcCalendarUnifiedManualInputV01NormalizeDateTime_(payload.startAt || payload.startDateTime || '');
  var endAt = mcCalendarUnifiedManualInputV01NormalizeDateTime_(payload.endAt || payload.endDateTime || '');
  var calendarEventId = String(payload.calendarEventId || '').trim() || mcCalendarUnifiedManualInputV01NewId_('MCAL-MANUAL');
  var sourceType = mcCalendarUnifiedManualInputV01Enum_(payload.sourceType, ['MANUAL','MAIL_RECEIVED','MAIL_SENT','MAIL_SCHEDULED','ERP_EVENT','ERP_INSTALL','ERP_AS','ERP_CUSTOMER','GOOGLE_IMPORTED'], 'MANUAL');
  var syncTarget = mcCalendarUnifiedManualInputV01Enum_(payload.syncTarget, ['NONE','GOOGLE','NAVER_EXPORT','BOTH'], 'NONE');
  var googleSyncStatus = (syncTarget === 'GOOGLE' || syncTarget === 'BOTH') ? 'READY_DRY_RUN_REQUIRED' : 'NOT_TARGET';
  var attendees = mcCalendarUnifiedManualInputV01ParsePeople_(payload.attendees || payload.attendeesText || '');
  var reminders = mcCalendarUnifiedManualInputV01ParseReminderMinutes_(payload.reminders || payload.reminderMinutesText || payload.reminderMinutes || '');
  var record = {
    calendarEventId: calendarEventId,
    sourceType: sourceType,
    sourceModule: 'MAILCENTER_CALENDAR',
    sourceId: String(payload.sourceId || calendarEventId).trim(),
    calendarBusinessType: mcCalendarUnifiedManualInputV01Enum_(payload.calendarBusinessType || payload.businessType, ['SELECTION_PROCESS','EVENT_MANAGEMENT','GENERAL_SCHEDULE'], (payload.eventId || payload.relatedEventId) ? 'EVENT_MANAGEMENT' : (payload.selectionId ? 'SELECTION_PROCESS' : 'GENERAL_SCHEDULE')),
    businessStage: String(payload.businessStage || payload.selectionStage || payload.eventStage || '').trim(),
    scheduleSubType: String(payload.scheduleSubType || '').trim(),
    selectionId: String(payload.selectionId || payload.leadId || payload.prospectId || '').trim(),
    complexName: String(payload.complexName || payload.apartmentName || '').trim(),
    complexRegion: String(payload.complexRegion || payload.region || '').trim(),
    householdCount: String(payload.householdCount || payload.households || '').trim(),
    moveInExpectedAt: String(payload.moveInExpectedAt || payload.moveInDate || '').trim(),
    selectionPossibility: String(payload.selectionPossibility || payload.winProbability || '').trim(),
    contactTargetType: String(payload.contactTargetType || '').trim(),
    contactName: String(payload.contactName || '').trim(),
    contactPhone: String(payload.contactPhone || '').trim(),
    contactResponseStatus: String(payload.contactResponseStatus || '').trim(),
    proposalStatus: String(payload.proposalStatus || '').trim(),
    conditionStatus: String(payload.conditionStatus || '').trim(),
    competitionStatus: String(payload.competitionStatus || '').trim(),
    nextAction: String(payload.nextAction || '').trim(),
    nextCheckAt: String(payload.nextCheckAt || '').trim(),
    meetingTimelineJson: mcCalendarOperationHubV01SafeTextJson_(payload.meetingTimelineJson || payload.meetingTimelineText || ''),
    infoSource: String(payload.infoSource || '').trim(),
    expectedFairPeriod: String(payload.expectedFairPeriod || '').trim(),
    previousFairHistory: String(payload.previousFairHistory || '').trim(),
    competitorContactYn: String(payload.competitorContactYn || '').trim(),
    internalOwnerName: String(payload.internalOwnerName || '').trim(),
    internalOwnerEmployeeId: String(payload.internalOwnerEmployeeId || '').trim(),
    internalDepartmentCode: String(payload.internalDepartmentCode || '').trim(),
    internalOrganizerRole: String(payload.internalOrganizerRole || '').trim(),
    followUpOwnerName: String(payload.followUpOwnerName || '').trim(),
    externalContactRole: String(payload.externalContactRole || '').trim(),
    externalContactEmail: String(payload.externalContactEmail || '').trim(),
    externalOrganization: String(payload.externalOrganization || '').trim(),
    decisionInfluenceLevel: String(payload.decisionInfluenceLevel || '').trim(),
    lastContactAt: String(payload.lastContactAt || '').trim(),
    presentationEnabled: String(payload.presentationEnabled || '').trim(),
    presentationAt: String(payload.presentationAt || '').trim(),
    presentationPlace: String(payload.presentationPlace || '').trim(),
    presentationMethod: String(payload.presentationMethod || '').trim(),
    presentationMainSpeaker: String(payload.presentationMainSpeaker || '').trim(),
    presentationSubSpeaker: String(payload.presentationSubSpeaker || '').trim(),
    presentationMaterialOwner: String(payload.presentationMaterialOwner || '').trim(),
    presentationConditionOwner: String(payload.presentationConditionOwner || '').trim(),
    presentationOperationOwner: String(payload.presentationOperationOwner || '').trim(),
    presentationSettlementOwner: String(payload.presentationSettlementOwner || '').trim(),
    presentationParticipantsJson: String(payload.presentationParticipantsJson || '').trim(),
    externalPresentationAttendeesJson: String(payload.externalPresentationAttendeesJson || '').trim(),
    presentationTarget: String(payload.presentationTarget || '').trim(),
    presentationMaterials: String(payload.presentationMaterials || '').trim(),
    presentationRequestItems: String(payload.presentationRequestItems || '').trim(),
    presentationResult: String(payload.presentationResult || '').trim(),
    expectedFairAt: String(payload.expectedFairAt || '').trim(),
    venueNegotiationStatus: String(payload.venueNegotiationStatus || '').trim(),
    operationCondition: String(payload.operationCondition || '').trim(),
    promotionCondition: String(payload.promotionCondition || '').trim(),
    vendorCondition: String(payload.vendorCondition || '').trim(),
    residentBenefitCondition: String(payload.residentBenefitCondition || '').trim(),
    managementRequest: String(payload.managementRequest || '').trim(),
    preCouncilRequest: String(payload.preCouncilRequest || '').trim(),
    feelhausProposalCondition: String(payload.feelhausProposalCondition || '').trim(),
    negotiationRisk: String(payload.negotiationRisk || '').trim(),
    competitorNames: String(payload.competitorNames || '').trim(),
    competitorCondition: String(payload.competitorCondition || '').trim(),
    feelhausStrength: String(payload.feelhausStrength || '').trim(),
    concernItems: String(payload.concernItems || '').trim(),
    decisionMaker: String(payload.decisionMaker || '').trim(),
    decisionDueAt: String(payload.decisionDueAt || '').trim(),
    actionType: String(payload.actionType || '').trim(),
    actionOwner: String(payload.actionOwner || '').trim(),
    actionDueAt: String(payload.actionDueAt || '').trim(),
    actionPriority: String(payload.actionPriority || '').trim(),
    actionDoneYn: String(payload.actionDoneYn || '').trim(),
    selectionStatus: String(payload.selectionStatus || '').trim(),
    selectedAt: String(payload.selectedAt || '').trim(),
    rejectionReason: String(payload.rejectionReason || '').trim(),
    holdReason: String(payload.holdReason || '').trim(),
    reconnectAt: String(payload.reconnectAt || '').trim(),
    agreementRequired: String(payload.agreementRequired || '').trim(),
    agreementAt: String(payload.agreementAt || '').trim(),
    agreementPlace: String(payload.agreementPlace || '').trim(),
    agreementMethod: String(payload.agreementMethod || '').trim(),
    agreementAgenda: String(payload.agreementAgenda || '').trim(),
    agreementCondition: String(payload.agreementCondition || '').trim(),
    agreementResult: String(payload.agreementResult || '').trim(),
    agreementDocumentRequired: String(payload.agreementDocumentRequired || '').trim(),
    agreementSignRequired: String(payload.agreementSignRequired || '').trim(),
    agreementFeelhausAttendeesJson: String(payload.agreementFeelhausAttendeesJson || '').trim(),
    agreementExternalAttendeesJson: String(payload.agreementExternalAttendeesJson || '').trim(),
    agreementStatus: String(payload.agreementStatus || '').trim(),
    attachmentMemo: String(payload.attachmentMemo || '').trim(),
    scheduleSummary: String(payload.scheduleSummary || payload.summary || '').trim(),
    processStatus: String(payload.processStatus || '').trim(),
    primaryOwnerName: String(payload.primaryOwnerName || payload.primaryOwner || payload.ownerName || '').trim(),
    assistantOwnerName: String(payload.assistantOwnerName || payload.assistantOwner || '').trim(),
    shareTargetsJson: String(payload.shareTargetsJson || payload.shareTargetsText || '').trim(),
    reportTargetsJson: String(payload.reportTargetsJson || payload.reportTargetsText || '').trim(),
    nextActionOwner: String(payload.nextActionOwner || payload.actionOwner || '').trim(),
    followUpRequiredYn: String(payload.followUpRequiredYn || '').trim(),
    followUpCreatedYn: String(payload.followUpCreatedYn || '').trim(),
    sensitiveInfoLevel: String(payload.sensitiveInfoLevel || '일반').trim(),
    relatedLinks: String(payload.relatedLinks || '').trim(),
    relatedDocumentIds: String(payload.relatedDocumentIds || '').trim(),
    scheduleWorkType: String(payload.scheduleWorkType || '').trim(),
    scheduleTargetType: String(payload.scheduleTargetType || '').trim(),
    calendarSourceType: String(payload.calendarSourceType || '').trim(),
    approvalRequired: String(payload.approvalRequired || '').trim(),
    approvalId: String(payload.approvalId || '').trim(),
    approvalStatus: String(payload.approvalStatus || '').trim(),
    approvalRequester: String(payload.approvalRequester || '').trim(),
    approvalApprover: String(payload.approvalApprover || '').trim(),
    approvalApprovedAt: String(payload.approvalApprovedAt || '').trim(),
    calendarVisibilityMode: String(payload.calendarVisibilityMode || '').trim(),
    displayPrivacyMode: String(payload.displayPrivacyMode || '').trim(),
    connectionStatus: String(payload.connectionStatus || '').trim(),
    connectionTargetType: String(payload.connectionTargetType || '').trim(),
    personalScheduleType: String(payload.personalScheduleType || '').trim(),
    eventId: String(payload.eventId || '').trim(),
    vendorId: String(payload.vendorId || '').trim(),
    customerId: String(payload.customerId || '').trim(),
    saleId: String(payload.saleId || '').trim(),
    contractId: String(payload.contractId || '').trim(),
    installId: String(payload.installId || '').trim(),
    asId: String(payload.asId || '').trim(),
    documentId: String(payload.documentId || '').trim(),
    mailRecordId: String(payload.mailRecordId || payload.recordId || '').trim(),
    scheduleId: String(payload.scheduleId || '').trim(),
    googleEventId: String(payload.googleEventId || '').trim(),
    naverEventId: String(payload.naverEventId || '').trim(),
    title: String(payload.title || payload.eventTitle || '').trim(),
    description: String(payload.description || payload.memo || payload.eventDescription || '').trim(),
    startAt: startAt,
    endAt: endAt,
    allDay: mcCalendarUnifiedManualInputV01BoolText_(payload.allDay),
    timezone: String(payload.timezone || 'Asia/Seoul').trim(),
    location: String(payload.location || '').trim(),
    meetingUrl: String(payload.meetingUrl || '').trim(),
    attendeesJson: JSON.stringify(attendees),
    organizerEmail: String(payload.organizerEmail || actor || '').trim(),
    ownerName: String(payload.ownerName || payload.owner || '').trim(),
    ownerUserId: String(payload.ownerUserId || '').trim(),
    departmentCode: String(payload.departmentCode || '').trim(),
    organizerRole: String(payload.organizerRole || '').trim(),
    eventGroupType: String(payload.eventGroupType || '').trim(),
    operationType: String(payload.operationType || payload.eventGroupType || '').trim(),
    participantJson: mcCalendarOperationHubV01SafeTextJson_(payload.participantJson || payload.participantText || ''),
    externalPartyJson: mcCalendarOperationHubV01SafeTextJson_(payload.externalPartyJson || payload.externalPartyText || ''),
    agendaJson: mcCalendarOperationHubV01SafeTextJson_(payload.agendaJson || payload.agendaText || ''),
    todoJson: mcCalendarOperationHubV01SafeTextJson_(payload.todoJson || payload.todoText || ''),
    decisionMemo: String(payload.decisionMemo || '').trim(),
    presentationType: String(payload.presentationType || '').trim(),
    meetingMethod: String(payload.meetingMethod || '').trim(),
    councilName: String(payload.councilName || '').trim(),
    fairName: String(payload.fairName || '').trim(),
    boothZone: String(payload.boothZone || '').trim(),
    meetingPurpose: String(payload.meetingPurpose || '').trim(),
    preparationItems: String(payload.preparationItems || '').trim(),
    resultSummary: String(payload.resultSummary || '').trim(),
    nextFollowUpAt: String(payload.nextFollowUpAt || '').trim(),
    sourceWritePolicy: String(payload.sourceWritePolicy || (sourceType === 'MANUAL' ? 'CALENDAR_ONLY' : 'READONLY_SOURCE')).trim(),
    sourceUpdateStatus: String(payload.sourceUpdateStatus || 'NOT_REQUIRED').trim(),
    changeReason: String(payload.changeReason || '수동일정 등록').trim(),
    lastChangedFields: '',
    relatedEventId: String(payload.relatedEventId || payload.eventId || '').trim(),
    relatedVendorId: String(payload.relatedVendorId || payload.vendorId || '').trim(),
    relatedCustomerId: String(payload.relatedCustomerId || payload.customerId || '').trim(),
    relatedSaleId: String(payload.relatedSaleId || payload.saleId || '').trim(),
    relatedContractId: String(payload.relatedContractId || payload.contractId || '').trim(),
    relatedInstallId: String(payload.relatedInstallId || payload.installId || '').trim(),
    relatedAsId: String(payload.relatedAsId || payload.asId || '').trim(),
    categoryCode: mcCalendarUnifiedManualInputV01Enum_(payload.categoryCode || payload.calendarType, ['INTERNAL','MEETING','EVENT','VENDOR','CUSTOMER','INSTALL','AS','SETTLEMENT','REMINDER','ETC'], 'ETC'),
    customTypeName: String(payload.customTypeName || '').trim(),
    colorTag: String(payload.colorTag || '').trim(),
    priority: mcCalendarUnifiedManualInputV01Enum_(payload.priority, ['LOW','NORMAL','HIGH','URGENT'], 'NORMAL'),
    visibility: mcCalendarUnifiedManualInputV01Enum_(payload.visibility || payload.privacyLevel, ['DEFAULT','PUBLIC','PRIVATE','CONFIDENTIAL'], 'DEFAULT'),
    privacyLevel: mcCalendarUnifiedManualInputV01Enum_(payload.privacyLevel || payload.visibility, ['DEFAULT','PUBLIC','PRIVATE','CONFIDENTIAL'], 'DEFAULT'),
    busyStatus: mcCalendarUnifiedManualInputV01Enum_(payload.busyStatus, ['BUSY','FREE','TENTATIVE','OOO'], 'BUSY'),
    repeatType: mcCalendarUnifiedManualInputV01Enum_(payload.repeatType, ['NONE','DAILY','WEEKLY','MONTHLY','YEARLY','CUSTOM'], 'NONE'),
    repeatRule: String(payload.repeatRule || '').trim(),
    repeatUntil: String(payload.repeatUntil || '').trim(),
    repeatCount: String(payload.repeatCount || '').trim(),
    reminderEnabled: reminders.length ? 'Y' : mcCalendarUnifiedManualInputV01BoolText_(payload.reminderEnabled),
    remindersJson: JSON.stringify(reminders),
    attachmentIds: String(payload.attachmentIds || '').trim(),
    eventStatus: mcCalendarUnifiedManualInputV01Enum_(payload.eventStatus || payload.status, ['REQUESTED','SCHEDULED','IN_PROGRESS','DONE','CANCELLED'], 'SCHEDULED'),
    status: mcCalendarUnifiedManualInputV01Enum_(payload.status || payload.eventStatus, ['REQUESTED','SCHEDULED','IN_PROGRESS','DONE','CANCELLED'], 'SCHEDULED'),
    statusReason: String(payload.statusReason || '수동일정 등록').trim(),
    syncTarget: syncTarget,
    googleSyncStatus: googleSyncStatus,
    naverSyncStatus: (syncTarget === 'NAVER_EXPORT' || syncTarget === 'BOTH') ? 'EXPORT_READY' : 'NOT_TARGET',
    lastSyncAt: '',
    locked: 'N',
    createdAt: now,
    createdBy: actor,
    createdByName: String(actorProfile.employeeName || '').trim(),
    createdByEmail: String(actorProfile.email || '').trim(),
    createdByEmployeeId: String(actorProfile.employeeId || '').trim(),
    actorSource: String(actorProfile.source || '').trim(),
    actorRoleCode: String(actorProfile.roleCode || '').trim(),
    actorVendorId: String(actorProfile.vendorId || '').trim(),
    updatedAt: now,
    updatedBy: actor,
    updatedByName: String(actorProfile.employeeName || '').trim(),
    updatedByEmail: String(actorProfile.email || '').trim(),
    updatedByEmployeeId: String(actorProfile.employeeId || '').trim(),
    updatedActorSource: String(actorProfile.source || '').trim()
  };
  record.calendarType = sourceType === 'MANUAL' ? 'MANUAL' : sourceType;
  record.eventTitle = record.title;
  record.eventDescription = record.description;
  return record;
}

function mcCalendarUnifiedManualInputV01Validate_(record) {
  var errors = [];
  if (!record.title) errors.push({ code: 'TITLE_REQUIRED', message: '일정 제목은 필수입니다.' });
  if (!record.startAt) errors.push({ code: 'START_REQUIRED', message: '시작일시는 필수입니다.' });
  if (!record.endAt) errors.push({ code: 'END_REQUIRED', message: '종료일시는 필수입니다.' });
  if (record.startAt && record.endAt) {
    var s = new Date(String(record.startAt).replace(' ', 'T'));
    var e = new Date(String(record.endAt).replace(' ', 'T'));
    if (!isNaN(s.getTime()) && !isNaN(e.getTime()) && e.getTime() < s.getTime()) errors.push({ code: 'END_BEFORE_START', message: '종료일시는 시작일시 이후여야 합니다.' });
  }
  if (record.syncTarget === 'GOOGLE' || record.syncTarget === 'BOTH') {
    if (record.privacyLevel === 'CONFIDENTIAL') errors.push({ code: 'CONFIDENTIAL_GOOGLE_SYNC_BLOCKED', message: '민감/제한 일정은 Google Sync 후보로 저장할 수 없습니다.' });
  }
  return { ok: errors.length === 0, errors: errors };
}

function mcCalendarUnifiedManualInputV01FindDuplicate_(sheet, record) {
  var out = { found: false, message: '', calendarEventId: '' };
  if (!sheet || sheet.getLastRow() < 2) return out;
  var values = sheet.getDataRange().getValues();
  var headers = values[0] || [];
  var hm = mcCalendarUnifiedManualInputV01HeaderMap_(headers);
  for (var r = 1; r < values.length; r++) {
    var row = values[r];
    var title = String(mcCalendarUnifiedManualInputV01Cell_(row, hm, ['title','eventTitle']) || '').trim();
    var startAt = String(mcCalendarUnifiedManualInputV01Cell_(row, hm, ['startAt']) || '').trim();
    var endAt = String(mcCalendarUnifiedManualInputV01Cell_(row, hm, ['endAt']) || '').trim();
    var status = String(mcCalendarUnifiedManualInputV01Cell_(row, hm, ['eventStatus','status']) || '').trim().toUpperCase();
    if (status === 'CANCELLED') continue;
    if (title === record.title && startAt === record.startAt && endAt === record.endAt) {
      out.found = true;
      out.calendarEventId = String(mcCalendarUnifiedManualInputV01Cell_(row, hm, ['calendarEventId']) || '').trim();
      out.message = '동일 제목/시작/종료 일정이 이미 존재합니다.';
      return out;
    }
  }
  return out;
}

function mcCalendarUnifiedManualInputV01PublicRecord_(record) {
  var keys = ['calendarEventId','sourceType','calendarType','calendarBusinessType','businessStage','scheduleSubType','selectionId','complexName','complexRegion','householdCount','moveInExpectedAt','selectionPossibility','contactTargetType','contactName','contactPhone','contactResponseStatus','proposalStatus','conditionStatus','competitionStatus','nextAction','nextCheckAt','meetingTimelineJson','infoSource','expectedFairPeriod','previousFairHistory','competitorContactYn','internalOwnerName','internalOwnerEmployeeId','internalDepartmentCode','internalOrganizerRole','followUpOwnerName','externalContactRole','externalContactEmail','externalOrganization','decisionInfluenceLevel','lastContactAt','presentationEnabled','presentationAt','presentationPlace','presentationMethod','presentationMainSpeaker','presentationSubSpeaker','presentationMaterialOwner','presentationConditionOwner','presentationOperationOwner','presentationSettlementOwner','presentationParticipantsJson','externalPresentationAttendeesJson','presentationTarget','presentationMaterials','presentationRequestItems','presentationResult','expectedFairAt','venueNegotiationStatus','operationCondition','promotionCondition','vendorCondition','residentBenefitCondition','managementRequest','preCouncilRequest','feelhausProposalCondition','negotiationRisk','competitorNames','competitorCondition','feelhausStrength','concernItems','decisionMaker','decisionDueAt','actionType','actionOwner','actionDueAt','actionPriority','actionDoneYn','selectionStatus','selectedAt','rejectionReason','holdReason','reconnectAt','agreementRequired','agreementAt','agreementPlace','agreementMethod','agreementAgenda','agreementCondition','agreementResult','agreementDocumentRequired','agreementSignRequired','agreementFeelhausAttendeesJson','agreementExternalAttendeesJson','agreementStatus','attachmentMemo','scheduleSummary','processStatus','primaryOwnerName','assistantOwnerName','shareTargetsJson','reportTargetsJson','nextActionOwner','followUpRequiredYn','followUpCreatedYn','sensitiveInfoLevel','relatedLinks','relatedDocumentIds','scheduleWorkType','scheduleTargetType','calendarSourceType','approvalRequired','approvalId','approvalStatus','approvalRequester','approvalApprover','approvalApprovedAt','calendarVisibilityMode','displayPrivacyMode','connectionStatus','connectionTargetType','personalScheduleType','eventId','vendorId','customerId','mailRecordId','scheduleId','googleEventId','title','description','startAt','endAt','allDay','timezone','location','meetingUrl','attendeesJson','organizerEmail','ownerUserId','ownerName','departmentCode','organizerRole','eventGroupType','operationType','participantJson','externalPartyJson','agendaJson','todoJson','decisionMemo','presentationType','meetingMethod','councilName','fairName','boothZone','meetingPurpose','preparationItems','resultSummary','nextFollowUpAt','sourceWritePolicy','sourceUpdateStatus','changeReason','categoryCode','customTypeName','colorTag','priority','privacyLevel','busyStatus','repeatType','repeatRule','repeatUntil','repeatCount','reminderEnabled','remindersJson','eventStatus','syncTarget','googleSyncStatus','naverSyncStatus','createdAt','createdBy','createdByName','createdByEmail','createdByEmployeeId','actorSource','actorRoleCode','actorVendorId','updatedAt','updatedBy','updatedByName','updatedByEmail','updatedByEmployeeId','updatedActorSource'];
  var out = {};
  keys.forEach(function(k) { out[k] = record[k] || ''; });
  return out;
}

function mcCalendarUnifiedManualInputV01CalendarHeaders_() {
  return ['calendarEventId','sourceType','sourceModule','sourceId','calendarType','calendarBusinessType','businessStage','scheduleSubType','selectionId','complexName','complexRegion','householdCount','moveInExpectedAt','selectionPossibility','contactTargetType','contactName','contactPhone','contactResponseStatus','proposalStatus','conditionStatus','competitionStatus','nextAction','nextCheckAt','meetingTimelineJson','infoSource','expectedFairPeriod','previousFairHistory','competitorContactYn','internalOwnerName','internalOwnerEmployeeId','internalDepartmentCode','internalOrganizerRole','followUpOwnerName','externalContactRole','externalContactEmail','externalOrganization','decisionInfluenceLevel','lastContactAt','presentationEnabled','presentationAt','presentationPlace','presentationMethod','presentationMainSpeaker','presentationSubSpeaker','presentationMaterialOwner','presentationConditionOwner','presentationOperationOwner','presentationSettlementOwner','presentationParticipantsJson','externalPresentationAttendeesJson','presentationTarget','presentationMaterials','presentationRequestItems','presentationResult','expectedFairAt','venueNegotiationStatus','operationCondition','promotionCondition','vendorCondition','residentBenefitCondition','managementRequest','preCouncilRequest','feelhausProposalCondition','negotiationRisk','competitorNames','competitorCondition','feelhausStrength','concernItems','decisionMaker','decisionDueAt','actionType','actionOwner','actionDueAt','actionPriority','actionDoneYn','selectionStatus','selectedAt','rejectionReason','holdReason','reconnectAt','agreementRequired','agreementAt','agreementPlace','agreementMethod','agreementAgenda','agreementCondition','agreementResult','agreementDocumentRequired','agreementSignRequired','agreementFeelhausAttendeesJson','agreementExternalAttendeesJson','agreementStatus','attachmentMemo','scheduleSummary','processStatus','primaryOwnerName','assistantOwnerName','shareTargetsJson','reportTargetsJson','nextActionOwner','followUpRequiredYn','followUpCreatedYn','sensitiveInfoLevel','relatedLinks','relatedDocumentIds','scheduleWorkType','scheduleTargetType','calendarSourceType','approvalRequired','approvalId','approvalStatus','approvalRequester','approvalApprover','approvalApprovedAt','calendarVisibilityMode','displayPrivacyMode','connectionStatus','connectionTargetType','personalScheduleType','eventId','vendorId','customerId','saleId','contractId','installId','asId','documentId','mailRecordId','scheduleId','googleEventId','naverEventId','title','eventTitle','description','eventDescription','startAt','endAt','allDay','timezone','location','meetingUrl','attendeesJson','organizerEmail','ownerName','ownerUserId','departmentCode','organizerRole','eventGroupType','operationType','participantJson','externalPartyJson','decisionMemo','todoJson','agendaJson','presentationType','meetingMethod','relatedEventId','relatedVendorId','relatedCustomerId','relatedSaleId','relatedContractId','relatedInstallId','relatedAsId','sourceWritePolicy','sourceUpdateStatus','changeReason','lastChangedFields','councilName','fairName','boothZone','meetingPurpose','preparationItems','resultSummary','nextFollowUpAt','categoryCode','customTypeName','colorTag','priority','visibility','privacyLevel','busyStatus','repeatType','repeatRule','repeatUntil','repeatCount','reminderEnabled','remindersJson','attachmentIds','eventStatus','status','statusReason','syncTarget','googleSyncStatus','naverSyncStatus','lastSyncAt','locked','createdAt','createdBy','createdByName','createdByEmail','createdByEmployeeId','actorSource','actorRoleCode','actorVendorId','updatedAt','updatedBy','updatedByName','updatedByEmail','updatedByEmployeeId','updatedActorSource'];
}

function mcCalendarUnifiedManualInputV01AuditHeaders_() {
  return ['auditId','build','module','actionType','resultStatus','calendarEventId','message','payloadSummary','createdAt','createdBy','createdByName','createdByEmail','actorSource'];
}

function mcCalendarUnifiedManualInputV01AppendAudit_(ss, audit) {
  try {
    var sheet = mcCalendarUnifiedManualInputV01GetSheetOrCreate_(ss, 'MAILCENTER_AuditLogs', mcCalendarUnifiedManualInputV01AuditHeaders_());
    audit.auditId = 'AUD-' + Utilities.getUuid();
    audit.build = MC_CALENDAR_UNIFIED_MANUAL_INPUT_V01_BUILD;
    audit.module = 'MAILCENTER_CALENDAR';
    mcCalendarUnifiedManualInputV01AppendByHeaders_(sheet, audit);
  } catch (err) {
    // 감사로그 실패가 원장 저장 성공을 되돌리지는 않는다. 결과 로그에는 message로만 남긴다.
  }
}

function mcCalendarUnifiedManualInputV01GetSheetOrCreate_(ss, name, headers) {
  var sheet = ss.getSheetByName(name);
  if (!sheet) sheet = ss.insertSheet(name);
  mcCalendarUnifiedManualInputV01EnsureHeaders_(sheet, headers);
  return sheet;
}

function mcCalendarUnifiedManualInputV01EnsureHeaders_(sheet, headers) {
  var lastCol = Math.max(sheet.getLastColumn(), 1);
  var current = sheet.getRange(1, 1, 1, lastCol).getValues()[0] || [];
  var hm = mcCalendarUnifiedManualInputV01HeaderMap_(current);
  var changed = false;
  headers.forEach(function(h) {
    if (hm[h] === undefined) {
      current.push(h);
      hm[h] = current.length - 1;
      changed = true;
    }
  });
  if (changed || sheet.getLastRow() === 0) sheet.getRange(1, 1, 1, current.length).setValues([current]);
}

function mcCalendarUnifiedManualInputV01AppendByHeaders_(sheet, record) {
  var headers = sheet.getRange(1, 1, 1, Math.max(sheet.getLastColumn(), 1)).getValues()[0] || [];
  var row = headers.map(function(h) { return record[String(h || '').trim()] || ''; });
  sheet.appendRow(row);
}

function mcCalendarUnifiedManualInputV01OpenMaster_() {
  var setupId = '17VMSpgSZCvIrUlgcw8yCNcnl8WQWo2IcRf5tDCcuJGM';
  var setup = SpreadsheetApp.openById(setupId);
  var sheet = setup.getSheetByName('SystemConfig');
  if (!sheet) throw new Error('SystemConfig 시트를 찾지 못했습니다.');
  var values = sheet.getDataRange().getValues();
  var hm = mcCalendarUnifiedManualInputV01HeaderMap_(values[0] || []);
  var keyCol = mcCalendarUnifiedManualInputV01PickIndex_(hm, ['CONFIG_KEY','configKey','key','name']);
  var valCol = mcCalendarUnifiedManualInputV01PickIndex_(hm, ['VALUE','configValue','value','spreadsheetId']);
  if (keyCol < 0 || valCol < 0) throw new Error('SystemConfig CONFIG_KEY/VALUE 헤더를 찾지 못했습니다.');
  var masterId = '';
  for (var r = 1; r < values.length; r++) {
    var key = String(values[r][keyCol] || '').trim();
    if (key === 'FEELHAUS_DB_MASTER' || key === 'FEELHAUS_DB_MASTER_ID' || key === 'MASTER_DB_ID') {
      masterId = String(values[r][valCol] || '').trim();
      break;
    }
  }
  if (!masterId) throw new Error('SystemConfig에서 FEELHAUS_DB_MASTER ID를 찾지 못했습니다.');
  return SpreadsheetApp.openById(masterId);
}

function mcCalendarUnifiedManualInputV01NormalizeDateTime_(value) {
  if (!value && value !== 0) return '';
  if (Object.prototype.toString.call(value) === '[object Date]' && !isNaN(value.getTime())) return Utilities.formatDate(value, Session.getScriptTimeZone() || 'Asia/Seoul', 'yyyy-MM-dd HH:mm:ss');
  var s = String(value || '').trim();
  if (!s) return '';
  s = s.replace('T', ' ');
  if (/^\d{4}-\d{2}-\d{2} \d{2}:\d{2}$/.test(s)) return s + ':00';
  if (/^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}$/.test(s)) return s;
  var d = new Date(s);
  if (!isNaN(d.getTime())) return Utilities.formatDate(d, Session.getScriptTimeZone() || 'Asia/Seoul', 'yyyy-MM-dd HH:mm:ss');
  return s;
}

function mcCalendarUnifiedManualInputV01ParsePeople_(value) {
  if (Array.isArray(value)) return value.filter(function(x) { return !!String(x || '').trim(); }).map(function(x) { return { email: String(x).trim(), name: '' }; });
  var text = String(value || '').trim();
  if (!text) return [];
  return text.split(/[;,\n]+/).map(function(x) { return String(x || '').trim(); }).filter(Boolean).map(function(x) { return { email: x, name: '' }; });
}

function mcCalendarUnifiedManualInputV01ParseReminderMinutes_(value) {
  if (Array.isArray(value)) return value.map(Number).filter(function(n) { return !isNaN(n) && n >= 0; });
  var text = String(value || '').trim();
  if (!text) return [];
  return text.split(/[;,\s]+/).map(Number).filter(function(n) { return !isNaN(n) && n >= 0; });
}

function mcCalendarUnifiedManualInputV01Enum_(value, allowed, fallback) {
  var v = String(value || '').trim().toUpperCase();
  return allowed.indexOf(v) >= 0 ? v : fallback;
}

function mcCalendarUnifiedManualInputV01BoolText_(value) {
  var v = String(value || '').trim().toUpperCase();
  return (v === 'Y' || v === 'YES' || v === 'TRUE' || v === '1' || v === 'ON') ? 'Y' : 'N';
}

function mcCalendarUnifiedManualInputV01HeaderMap_(headers) {
  var out = {};
  (headers || []).forEach(function(h, i) { var k = String(h || '').trim(); if (k) out[k] = i; });
  return out;
}
function mcCalendarUnifiedManualInputV01PickIndex_(hm, keys) { for (var i = 0; i < keys.length; i++) if (hm[keys[i]] !== undefined) return hm[keys[i]]; return -1; }
function mcCalendarUnifiedManualInputV01Cell_(row, hm, keys) { for (var i = 0; i < keys.length; i++) if (hm[keys[i]] !== undefined) return row[hm[keys[i]]]; return ''; }
function mcCalendarUnifiedManualInputV01Actor_() { return mcCalendarUnifiedManualInputV01ResolveActorProfile_({}).actorKey; }
function mcCalendarUnifiedManualInputV01LegacySessionActor_() { try { return String(Session.getActiveUser().getEmail() || Session.getEffectiveUser().getEmail() || 'MAILCENTER_ADMIN').trim() || 'MAILCENTER_ADMIN'; } catch (err) { return 'MAILCENTER_ADMIN'; } }
function mcCalendarUnifiedManualInputV01SessionEmail_() {
  try {
    var active = String(Session.getActiveUser().getEmail() || '').trim();
    if (active && active.indexOf('@') > 0) return active;
  } catch (ignoreActive) {}
  try {
    var effective = String(Session.getEffectiveUser().getEmail() || '').trim();
    if (effective && effective.indexOf('@') > 0) return effective;
  } catch (ignoreEffective) {}
  return '';
}
function mcCalendarUnifiedManualInputV01NormalizeEmail_(value) {
  return String(value || '').trim().toLowerCase();
}
function mcCalendarUnifiedManualInputV01HasActorHint_(request) {
  request = request || {};
  var keys = ['sid','portalSid','mcCalendarSid','sessionId','loginId','employeeId','actorLoginId','actorEmployeeId','actorEmail','googleEmail','sessionEmail','email'];
  for (var i = 0; i < keys.length; i++) if (String(request[keys[i]] || '').trim()) return true;
  return false;
}
function mcCalendarUnifiedManualInputV01ActorRequest_(payload) {
  payload = payload || {};
  return {
    sid: String(payload.sid || payload.portalSid || payload.mcCalendarSid || payload.sessionId || '').trim(),
    portalSid: String(payload.portalSid || payload.sid || payload.sessionId || '').trim(),
    mcCalendarSid: String(payload.mcCalendarSid || payload.sid || payload.sessionId || '').trim(),
    sessionId: String(payload.sessionId || payload.sid || payload.portalSid || payload.mcCalendarSid || '').trim(),
    loginId: String(payload.loginId || payload.actorLoginId || '').trim(),
    employeeId: String(payload.employeeId || payload.actorEmployeeId || '').trim(),
    actorEmail: String(payload.actorEmail || payload.googleEmail || payload.sessionEmail || payload.email || '').trim(),
    googleEmail: String(payload.googleEmail || payload.actorEmail || payload.sessionEmail || payload.email || '').trim(),
    sessionEmail: String(payload.sessionEmail || payload.googleEmail || payload.actorEmail || payload.email || '').trim(),
    email: String(payload.email || payload.actorEmail || payload.googleEmail || payload.sessionEmail || '').trim()
  };
}
function mcCalendarUnifiedManualInputV01ResolveActorProfile_(payload) {
  payload = payload || {};
  var req = mcCalendarUnifiedManualInputV01ActorRequest_(payload);
  var hasHint = mcCalendarUnifiedManualInputV01HasActorHint_(req);
  var profile = null;
  var source = '';

  // Future-ready path: when a completed PORTAL/HR login context is explicitly supplied later,
  // use it. It is optional and never required in the current Google-email phase.
  if (hasHint && (req.sid || req.loginId || req.employeeId) && typeof mcCalendar186ResolveCalendarActor_ === 'function') {
    try { profile = mcCalendar186ResolveCalendarActor_(req, null, { allowFallback: false }); source = 'MailCenterActorFutureContext'; } catch (ignoreMcActor) {}
  }
  if (!profile && hasHint && (req.sid || req.loginId || req.employeeId) && typeof portal186ResolveCalendarActor_ === 'function') {
    try { profile = portal186ResolveCalendarActor_(req, null, { allowFallback: false }); source = 'PortalActorFutureContext'; } catch (ignorePortalActor) {}
  }
  if (profile) return mcCalendarUnifiedManualInputV01NormalizeActorProfile_(profile, source || String(profile.source || 'FutureLoginContext').trim(), false);

  var explicitEmail = String(req.actorEmail || req.googleEmail || req.sessionEmail || req.email || '').trim();
  var sessionEmail = mcCalendarUnifiedManualInputV01SessionEmail_();
  var email = explicitEmail || sessionEmail || mcCalendarUnifiedManualInputV01LegacySessionActor_();
  var byEmail = null;
  if (email && email.indexOf('@') > 0) byEmail = mcCalendarUnifiedManualInputV01ResolveActorByEmail_(email);
  if (byEmail && byEmail.ok) return mcCalendarUnifiedManualInputV01NormalizeActorProfile_(byEmail, byEmail.source || 'GoogleSessionEmailUserMap', false);

  // Current safe fallback: keep saving possible with Google email even when user master mapping is incomplete.
  var legacy = email || mcCalendarUnifiedManualInputV01LegacySessionActor_();
  return { ok: true, source: 'LegacySessionFallback', actorKey: legacy, email: legacy, employeeId: '', employeeName: '', roleCode: '', vendorId: '', fallback: true };
}
function mcCalendarUnifiedManualInputV01NormalizeActorProfile_(profile, source, fallback) {
  profile = profile || {};
  var email = String(profile.email || profile.loginEmail || profile.userEmail || profile.loginId || '').trim();
  var employeeId = String(profile.employeeId || '').trim();
  var employeeName = String(profile.employeeName || profile.displayName || profile.name || '').trim();
  return {
    ok: true,
    source: String(source || profile.source || '').trim(),
    actorKey: email || String(profile.loginId || '').trim() || employeeId || employeeName || 'MAILCENTER_ACTOR',
    email: email,
    employeeId: employeeId,
    employeeName: employeeName,
    roleCode: String(profile.roleCode || '').trim(),
    vendorId: String(profile.vendorId || '').trim(),
    fallback: !!fallback
  };
}
function mcCalendarUnifiedManualInputV01ResolveActorByEmail_(email) {
  var target = mcCalendarUnifiedManualInputV01NormalizeEmail_(email);
  if (!target || target.indexOf('@') < 1) return null;
  try {
    var ss = mcCalendarUnifiedManualInputV01OpenMaster_();
    var sheets = ['MailCenterUsers','MAILCENTER_Users','PortalUsers','PORTAL_Users','MailCenter_Accounts','MAILCENTER_Accounts','MailAccounts','MAILCENTER_MailAccounts','ERP_Employees','HR_Employees','Employees','Users'];
    for (var s = 0; s < sheets.length; s++) {
      var sheet = ss.getSheetByName(sheets[s]);
      if (!sheet || sheet.getLastRow() < 2) continue;
      var values = sheet.getDataRange().getValues();
      var headerRowIndex = mcCalendarUnifiedManualInputV01DetectActorHeaderRow_(values);
      if (headerRowIndex < 0) continue;
      var headers = values[headerRowIndex] || [];
      var hm = mcCalendarUnifiedManualInputV01HeaderMap_(headers);
      var emailIndexes = mcCalendarUnifiedManualInputV01ActorEmailIndexes_(hm);
      if (!emailIndexes.length) continue;
      for (var r = headerRowIndex + 1; r < values.length; r++) {
        var row = values[r] || [];
        if (!mcCalendarUnifiedManualInputV01ActorRowActive_(row, hm)) continue;
        for (var e = 0; e < emailIndexes.length; e++) {
          var candidate = mcCalendarUnifiedManualInputV01NormalizeEmail_(row[emailIndexes[e]]);
          if (candidate && candidate === target) {
            return {
              ok: true,
              source: 'GoogleSessionEmailUserMap:' + sheets[s],
              email: target,
              loginId: target,
              employeeId: mcCalendarUnifiedManualInputV01FirstByHeaders_(row, hm, ['employeeId','ownerEmployeeId','empId','staffId','userId']),
              employeeName: mcCalendarUnifiedManualInputV01FirstByHeaders_(row, hm, ['employeeName','ownerName','empName','staffName','userName','displayName','name','fullName']),
              roleCode: mcCalendarUnifiedManualInputV01FirstByHeaders_(row, hm, ['roleCode','role','permissionRole','userRole','ownerType']),
              vendorId: mcCalendarUnifiedManualInputV01FirstByHeaders_(row, hm, ['vendorId','companyId','partnerId']),
              userId: mcCalendarUnifiedManualInputV01FirstByHeaders_(row, hm, ['userId','ownerUserId','accountId','mailAccountId'])
            };
          }
        }
      }
    }
  } catch (err) {
    Logger.log('R7_EMAIL_ACTOR_MAP_SKIPPED: ' + String(err && err.message ? err.message : err));
  }
  return null;
}
function mcCalendarUnifiedManualInputV01DetectActorHeaderRow_(values) {
  for (var r = 0; r < Math.min(values.length, 10); r++) {
    var hm = mcCalendarUnifiedManualInputV01HeaderMap_(values[r] || []);
    if (mcCalendarUnifiedManualInputV01ActorEmailIndexes_(hm).length) return r;
  }
  return -1;
}
function mcCalendarUnifiedManualInputV01ActorEmailIndexes_(hm) {
  var keys = ['email','userEmail','loginEmail','googleEmail','gmail','accountEmail','emailAddress','mail','loginId'];
  var out = [];
  for (var i = 0; i < keys.length; i++) if (hm[keys[i]] !== undefined) out.push(hm[keys[i]]);
  return out;
}
function mcCalendarUnifiedManualInputV01ActorRowActive_(row, hm) {
  var status = String(mcCalendarUnifiedManualInputV01FirstByHeaders_(row, hm, ['status','useStatus','accountStatus','mailAccountStatus']) || '').trim().toUpperCase();
  var active = String(mcCalendarUnifiedManualInputV01FirstByHeaders_(row, hm, ['isActive','activeYn','useYn','enabled']) || '').trim().toUpperCase();
  if (status && ['ACTIVE','USE','ENABLED','Y','TRUE','1','정상','사용'].indexOf(status) < 0) return false;
  if (active && ['Y','TRUE','1','ACTIVE','USE','ENABLED','정상','사용'].indexOf(active) < 0) return false;
  return true;
}
function mcCalendarUnifiedManualInputV01FirstByHeaders_(row, hm, keys) {
  for (var i = 0; i < keys.length; i++) {
    if (hm[keys[i]] !== undefined) {
      var v = String(row[hm[keys[i]]] || '').trim();
      if (v) return v;
    }
  }
  return '';
}
function mcCalendarUnifiedManualInputV01Now_() { return Utilities.formatDate(new Date(), Session.getScriptTimeZone() || 'Asia/Seoul', 'yyyy-MM-dd HH:mm:ss'); }
function mcCalendarUnifiedManualInputV01TodayAt_(hhmm) { return Utilities.formatDate(new Date(), Session.getScriptTimeZone() || 'Asia/Seoul', 'yyyy-MM-dd') + ' ' + hhmm + ':00'; }
function mcCalendarUnifiedManualInputV01NewId_(prefix) { return prefix + '-' + Utilities.formatDate(new Date(), Session.getScriptTimeZone() || 'Asia/Seoul', 'yyyyMMddHHmmss') + '-' + Utilities.getUuid().slice(0, 8).toUpperCase(); }
function mcCalendarUnifiedManualInputV01BaseResult_(action) { return { ok: false, build: MC_CALENDAR_UNIFIED_MANUAL_INPUT_V01_BUILD, action: action, generatedAt: mcCalendarUnifiedManualInputV01Now_(), realApplyExecuted: false, destructiveRepairExecuted: false, checks: {}, warnings: [], errors: [], message: '', nextAction: '' }; }
function mcCalendarUnifiedManualInputV01Catch_(result, err) { result.ok = false; result.message = String(err && err.message ? err.message : err); result.errors.push({ message: result.message, stack: err && err.stack ? err.stack : '' }); result.nextAction = '필수값, 시트 헤더, SystemConfig, 권한을 확인하세요.'; }
function mcCalendarUnifiedManualInputV01Print_(result) { result.endedAt = mcCalendarUnifiedManualInputV01Now_(); Logger.log('JSON_COMPACT_RESULT: ' + JSON.stringify(result)); return result; }


function mcCalendarOperationHubV01SafeTextJson_(value) {
  try {
    var text = String(value || '').trim();
    if (!text) return '';
    if ((text.charAt(0) === '[' || text.charAt(0) === '{')) return text;
    return JSON.stringify(text.split(/[\n|;]+/).map(function(x) { return String(x || '').trim(); }).filter(Boolean).map(function(x, i) { return { index: i + 1, text: x }; }));
  } catch (err) {
    return '';
  }
}
