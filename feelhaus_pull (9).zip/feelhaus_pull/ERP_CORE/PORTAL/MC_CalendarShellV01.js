/**
 * FEELHAUS MailCenter Calendar Link V01
 * Build: MAILCENTER_CALENDAR_LINK_V01_20260521
 * Purpose:
 * - MailCenter 메뉴에 메일 일정 관리 화면을 연결한다.
 * - PORTAL 캘린더 원본은 수정하지 않는다.
 * - 2단계: 라우터/메뉴/업무형 화면 진입까지만 처리한다.
 */

var MC_CALENDAR_LINK_V01_BUILD = 'MAILCENTER_CALENDAR_MONTH_UI_V01_20260521';
var PORTAL_CALENDAR_SAFE01B_R5_ACTOR_ONLY_SHELL_BUILD = 'PORTAL_CALENDAR_SAFE01B_R5_ACTOR_ONLY_20260602';
var PORTAL_CALENDAR_SAFE01B_R7_GOOGLE_EMAIL_ACTOR_MAP_SHELL_BUILD = 'PORTAL_CALENDAR_SAFE01B_R7_GOOGLE_EMAIL_ACTOR_MAP_20260602';
var PORTAL_CALENDAR_SAFE01B_R7C_UPDATEDBY_USER_LOCK_SHELL_BUILD = 'PORTAL_CALENDAR_SAFE01B_R7C_UPDATEDBY_USER_LOCK_20260602';
var PORTAL_CALENDAR_SAFE01B_R9_UPDATE_ACTOR_CHANGELOG_SHELL_BUILD = 'PORTAL_CALENDAR_SAFE01B_R9_UPDATE_ACTOR_CHANGELOG_20260602';
var PORTAL_CALENDAR_SAFE01B_R9A_RUNTIME_VERIFY_FIX_SHELL_BUILD = 'PORTAL_CALENDAR_SAFE01B_R9A_RUNTIME_VERIFY_FIX_20260602';
var PORTAL_CALENDAR_SAFE01B_R9C_STRICT_UPDATE_GATE_SHELL_BUILD = 'PORTAL_CALENDAR_SAFE01B_R9C_STRICT_UPDATE_GATE_20260602';

function mcCalendarShellV01HandleGet(e) {
  var tpl = HtmlService.createTemplateFromFile('MC_CalendarViewV01');
  tpl.build = (typeof MC_CALENDAR_LINK_V01_BUILD !== 'undefined' ? MC_CALENDAR_LINK_V01_BUILD : 'PORTAL_MC_CALENDAR_PARTICIPANT_FILTER_UI_V03_HARD_ROUTE_PATCH_20260528');
  tpl.webAppUrl = (typeof mcCalendarShellV01GetWebAppUrl_ === 'function') ? mcCalendarShellV01GetWebAppUrl_() : '';
  tpl.initialJson = JSON.stringify((typeof mcCalendarShellV01GetInitialData === 'function') ? mcCalendarShellV01GetInitialData(e || {}) : { ok: true });

  var out = tpl.evaluate()
    .setTitle('FEELHAUS MailCenter 메일 일정 관리')
    .setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL);

  try {
    var content = String(out && out.getContent ? out.getContent() : '');

    if (typeof mcCalendarOperationHubUiBindingV04ForceMarkers_ === 'function') {
      content = mcCalendarOperationHubUiBindingV04ForceMarkers_(content);
    }
    if (typeof feelhausCommonUiColorRefreshV02ForceRouteColors_ === 'function') {
      content = feelhausCommonUiColorRefreshV02ForceRouteColors_(content);
    }
    if (typeof mcCalendarParticipantFilterUiV03Force_ === 'function') {
      content = mcCalendarParticipantFilterUiV03Force_(content);
    }

    return HtmlService.createHtmlOutput(content)
      .setTitle('FEELHAUS MailCenter 메일 일정 관리')
      .setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL);
  } catch (err) {
    return out;
  }
}

function mcCalendarShellV01GetWebAppUrl_() {
  var fallbackUrl = 'https://script.google.com/macros/s/AKfycbxCyFE7zf4vE8nsfjOeWX0pC56SqU84gm8ie8Txa3qHQGEusJCZeljzCdYeOmZxUVYvjA/exec';
  try {
    var serviceUrl = ScriptApp.getService().getUrl();
    return serviceUrl || fallbackUrl;
  } catch (err) {
    return fallbackUrl;
  }
}

function mcCalendarShellV01GetInitialData(e) {
  var result = {
    ok: true,
    build: MC_CALENDAR_LINK_V01_BUILD,
    action: 'mcCalendarShellV01GetInitialData',
    generatedAt: mcCalendarShellV01Now_(),
    userEmail: '',
    dashboard: {},
    status: {},
    stage: 'MAILCENTER_CALENDAR_MONTH_UI_V01',
    message: 'MailCenter 캘린더 화면 초기 데이터 준비 완료',
    routeParams: {},
    actorContext: {},
    actorPatchBuild: PORTAL_CALENDAR_SAFE01B_R7C_UPDATEDBY_USER_LOCK_SHELL_BUILD,
    updateActorChangeLogBuild: PORTAL_CALENDAR_SAFE01B_R9_UPDATE_ACTOR_CHANGELOG_SHELL_BUILD
  };

  try {
    try { result.userEmail = Session.getActiveUser().getEmail() || Session.getEffectiveUser().getEmail() || ''; } catch (ignoreUser) {}
    try { result.routeParams = mcCalendarShellV01SafeRouteParamsR5_(e && e.parameter ? e.parameter : {}); } catch (ignoreParams) { result.routeParams = {}; }
    try { result.actorContext = mcCalendarShellV01ActorContextR9_(e || {}); } catch (ignoreActorR9) { result.actorContext = {}; }

    result.dashboard = mcCalendarShellV01SafeDashboard_();
    result.status = mcCalendarShellV01SafeStatus_();
  } catch (err) {
    result.ok = false;
    result.message = String(err && err.message ? err.message : err);
  }

  return mcCalendarShellV01Safe_(result);
}

function mcCalendarShellV01SafeRouteParamsR5_(params) {
  params = params || {};
  var keys = ['sid','portalSid','mcCalendarSid','sessionId','loginId','employeeId','actorLoginId','actorEmployeeId','actorEmail','googleEmail','sessionEmail','email','actorName','actorRoleCode','actorVendorId'];
  var out = {};
  keys.forEach(function(k) {
    var v = String(params[k] || '').trim();
    if (v) out[k] = v;
  });
  return out;
}




function mcCalendarShellV01R9RuntimeVerifyMarker_() {
  return {
    ok: true,
    build: PORTAL_CALENDAR_SAFE01B_R9_UPDATE_ACTOR_CHANGELOG_SHELL_BUILD,
    verifyFixBuild: PORTAL_CALENDAR_SAFE01B_R9A_RUNTIME_VERIFY_FIX_SHELL_BUILD,
    strictUpdateGateBuild: PORTAL_CALENDAR_SAFE01B_R9C_STRICT_UPDATE_GATE_SHELL_BUILD,
    actorContextReady: typeof mcCalendarShellV01ActorContextR9_ === 'function',
    handleGetReady: typeof mcCalendarShellV01HandleGet === 'function'
  };
}

function mcCalendarShellV01ActorContextR9_(e) {
  var out = {};
  var params = (e && e.parameter) ? e.parameter : {};
  function put(k, v) {
    v = String(v || '').trim();
    if (v && !out[k]) out[k] = v;
  }
  ['actorEmail','googleEmail','sessionEmail','email','actorLoginId','actorEmployeeId','actorName','actorRoleCode','actorVendorId','loginId','employeeId'].forEach(function(k) { put(k, params[k]); });
  try {
    var active = String(Session.getActiveUser().getEmail() || '').trim();
    if (active && active.indexOf('@') > 0) {
      put('actorEmail', active);
      put('googleEmail', active);
      put('sessionEmail', active);
      put('email', active);
    }
  } catch (ignoreActiveR9) {}
  try {
    var effective = String(Session.getEffectiveUser().getEmail() || '').trim();
    if (effective && effective.indexOf('@') > 0) {
      put('sessionEmail', effective);
      put('email', effective);
    }
  } catch (ignoreEffectiveR9) {}
  try {
    if (typeof portal19GetPermissionLoadReport === 'function') {
      var r = portal19GetPermissionLoadReport();
      var p = (r && r.profile) ? r.profile : {};
      put('actorEmail', r && (r.email || p.email || p.loginEmail));
      put('googleEmail', r && (r.email || p.email || p.loginEmail));
      put('sessionEmail', r && (r.email || p.email || p.loginEmail));
      put('email', r && (r.email || p.email || p.loginEmail));
      put('actorLoginId', p.loginId || p.loginEmail || r.email);
      put('actorEmployeeId', p.employeeId);
      put('actorName', p.employeeName || p.displayName);
      put('actorRoleCode', p.roleCode);
      put('actorVendorId', p.vendorId);
    }
  } catch (ignorePortalProfileR9) {}
  return out;
}

function runMcCalendarLinkV01Smoke() {
  var result = {
    ok: false,
    build: MC_CALENDAR_LINK_V01_BUILD,
    action: 'runMcCalendarLinkV01Smoke',
    generatedAt: mcCalendarShellV01Now_(),
    checks: [],
    message: ''
  };

  result.checks.push({
    key: 'ShellReady',
    ok: typeof mcCalendarShellV01HandleGet === 'function',
    message: 'MailCenterCalendarV01 화면 핸들러 확인'
  });
  result.checks.push({
    key: 'WebAppUrlReady',
    ok: !!mcCalendarShellV01GetWebAppUrl_(),
    message: '캘린더 메뉴 이동용 WebApp 절대주소 확인'
  });
  result.checks.push({
    key: 'InitialDataReady',
    ok: typeof mcCalendarShellV01GetInitialData === 'function',
    message: 'MailCenter 캘린더 초기 데이터 함수 확인'
  });
  result.checks.push({
    key: 'CoreCloneStage1GateReady',
    ok: typeof runMcCalendarStage1GateV01F === 'function',
    message: '1단계 Core Clone Gate 함수 확인'
  });
  result.checks.push({
    key: 'CalendarDashboardCallable',
    ok: typeof mcCalendar186GetCalendarDashboard === 'function',
    message: '복제 캘린더 dashboard 함수 확인'
  });
  result.checks.push({
    key: 'CalendarStatusCallable',
    ok: typeof mcCalendar199GetCalendarStatusOptions === 'function',
    message: '복제 캘린더 상태 옵션 함수 확인'
  });

  result.ok = result.checks.every(function(c) { return !!c.ok; });
  result.message = result.ok
    ? 'MailCenter Calendar Link V01 준비 완료'
    : 'MailCenter Calendar Link V01 점검 필요';

  Logger.log(JSON.stringify(result, null, 2));
  return result;
}

function mcCalendarShellV01SafeDashboard_() {
  try {
    if (typeof mcCalendar186GetCalendarDashboard === 'function') {
      var d = mcCalendar186GetCalendarDashboard({ noWriteMode: true, limit: 10 }) || {};
      if (d && d.ok !== false) return d;
      return {
        ok: true,
        fallback: true,
        total: Number(d.total || 0),
        today: Number(d.today || 0),
        recentCount: Number(d.recentCount || 0),
        naverSuccess: Number(d.naverSuccess || 0),
        googleSuccess: Number(d.googleSuccess || 0),
        retryPending: Number(d.retryPending || 0),
        message: '캘린더 데이터 연결 전 안전 표시'
      };
    }
  } catch (err) {
    return {
      ok: true,
      fallback: true,
      total: 0,
      today: 0,
      recentCount: 0,
      naverSuccess: 0,
      googleSuccess: 0,
      retryPending: 0,
      message: '캘린더 데이터 연결 전 안전 표시: ' + String(err && err.message ? err.message : err)
    };
  }

  return {
    ok: true,
    fallback: true,
    total: 0,
    today: 0,
    recentCount: 0,
    naverSuccess: 0,
    googleSuccess: 0,
    retryPending: 0,
    message: '캘린더 dashboard 함수 연결 대기'
  };
}

function mcCalendarShellV01SafeStatus_() {
  try {
    if (typeof mcCalendar199GetCalendarStatusOptions === 'function') {
      var s = mcCalendar199GetCalendarStatusOptions({ noWriteMode: true }) || {};
      if ((s.options && s.options.length) || s.optionCount) return s;
    }
  } catch (err) {}

  return {
    ok: true,
    optionsOk: true,
    optionCount: 5,
    currentBuild: MC_CALENDAR_LINK_V01_BUILD,
    options: [
      { value: 'REQUESTED', label: '요청' },
      { value: 'SCHEDULED', label: '예정' },
      { value: 'IN_PROGRESS', label: '진행중' },
      { value: 'DONE', label: '완료' },
      { value: 'CANCELLED', label: '취소' }
    ]
  };
}


function runMcCalendarMonthUiV01Smoke() {
  var result = {
    ok: false,
    build: MC_CALENDAR_LINK_V01_BUILD,
    action: 'runMcCalendarMonthUiV01Smoke',
    generatedAt: mcCalendarShellV01Now_(),
    noWriteMode: true,
    checks: [],
    message: ''
  };
  function check(key, ok, message) {
    result.checks.push({ key: key, ok: !!ok, message: message });
    if (!ok) result.ok = false;
  }
  result.ok = true;
  try {
    check('ShellReady', typeof mcCalendarShellV01HandleGet === 'function', '캘린더 화면 핸들러 확인');
    check('MonthDataReady', typeof mcCalendarShellV01GetMonthData === 'function', '월간 일정 데이터 함수 확인');
    check('WebAppUrlReady', !!mcCalendarShellV01GetWebAppUrl_(), 'WebApp 절대주소 확인');
    check('MasterOpenFunctionReady', typeof mcCalendarShellV01OpenMaster_ === 'function', 'SystemConfig -> FEELHAUS_DB_MASTER 연결 함수 확인');
    result.message = result.ok ? 'MailCenter Calendar Month UI V01 준비 완료' : 'MailCenter Calendar Month UI V01 점검 필요';
  } catch (err) {
    result.ok = false;
    result.message = String(err && err.message ? err.message : err);
  }
  Logger.log(JSON.stringify(result, null, 2));
  return result;
}

function mcCalendarShellV01GetMonthData(request) {
  request = request || {};
  var nowDate = new Date();
  var year = parseInt(request.year || nowDate.getFullYear(), 10);
  var month = parseInt(request.month || (nowDate.getMonth() + 1), 10);
  if (!year || year < 2000 || year > 2100) year = nowDate.getFullYear();
  if (!month || month < 1 || month > 12) month = nowDate.getMonth() + 1;

  var result = {
    ok: true,
    build: MC_CALENDAR_LINK_V01_BUILD,
    action: 'mcCalendarShellV01GetMonthData',
    generatedAt: mcCalendarShellV01Now_(),
    year: year,
    month: month,
    events: [],
    total: 0,
    today: 0,
    message: '월간 일정 데이터 조회 완료'
  };

  try {
    var ss = mcCalendarShellV01OpenMaster_();
    var tz = Session.getScriptTimeZone() || 'Asia/Seoul';
    var todayKey = Utilities.formatDate(new Date(), tz, 'yyyy-MM-dd');
    var sheetNames = ['MAILCENTER_CalendarEvents', 'CalendarEvents'];
    var foundAnySheet = false;
    var seenIds = {};
    for (var sn = 0; sn < sheetNames.length; sn++) {
      var sheet = ss.getSheetByName(sheetNames[sn]);
      if (!sheet || sheet.getLastRow() < 2) continue;
      foundAnySheet = true;
      var values = sheet.getDataRange().getValues();
      var headers = values[0] || [];
      var hm = mcCalendarShellV01HeaderMap_(headers);
      for (var r = 1; r < values.length; r++) {
        var row = values[r];
        var startAtRaw = mcCalendarShellV01Cell_(row, hm, ['startAt', 'scheduleDate', 'createdAt']);
        var dateKey = mcCalendarShellV01DateKey_(startAtRaw, tz);
        if (!dateKey) continue;
        var parts = dateKey.split('-');
        if (parseInt(parts[0], 10) !== year || parseInt(parts[1], 10) !== month) continue;
        var status = mcCalendarShellV01Cell_(row, hm, ['eventStatus', 'status']) || '';
        var calendarId = mcCalendarShellV01Cell_(row, hm, ['calendarEventId', 'calendarId']) || '';
        var uniqueKey = String(sheetNames[sn] + '::' + calendarId + '::' + r);
        if (calendarId && seenIds[String(sheetNames[sn] + '::' + calendarId)]) continue;
        if (calendarId) seenIds[String(sheetNames[sn] + '::' + calendarId)] = true;
        var item = {
          calendarEventId: calendarId,
          calendarId: calendarId,
          dateKey: dateKey,
          startAt: String(startAtRaw || ''),
          endAt: String(mcCalendarShellV01Cell_(row, hm, ['endAt']) || ''),
          title: mcCalendarShellV01Cell_(row, hm, ['title', 'eventTitle', 'subject']) || '제목 없음',
          description: mcCalendarShellV01Cell_(row, hm, ['description', 'eventDescription', 'memo']) || '',
          displayTitle: mcCalendarShellV01Cell_(row, hm, ['displayTitle','eventTitle','title']) || '',
          displayDateTime: mcCalendarShellV01Cell_(row, hm, ['displayDateTime']) || '',
          displayLocation: mcCalendarShellV01Cell_(row, hm, ['displayLocation','location']) || '',
          displayBody: mcCalendarShellV01Cell_(row, hm, ['displayBody','eventDescription','description','memo']) || '',
          displaySource: mcCalendarShellV01Cell_(row, hm, ['displaySource','sourceName','sourceType','provider']) || '',
          displayAttendees: mcCalendarShellV01Cell_(row, hm, ['displayAttendees','attendees','attendeesText','attendeesJson']) || '',
          displayOriginalContent: mcCalendarShellV01Cell_(row, hm, ['displayOriginalContent']) || '',
          displayNotice: mcCalendarShellV01Cell_(row, hm, ['displayNotice']) || '',
          originalDescription: mcCalendarShellV01Cell_(row, hm, ['originalDescription']) || '',
          originalLocation: mcCalendarShellV01Cell_(row, hm, ['originalLocation']) || '',
          originalAttendees: mcCalendarShellV01Cell_(row, hm, ['originalAttendees']) || '',
          originalOrganizer: mcCalendarShellV01Cell_(row, hm, ['originalOrganizer']) || '',
          originalCategories: mcCalendarShellV01Cell_(row, hm, ['originalCategories']) || '',
          originalStatus: mcCalendarShellV01Cell_(row, hm, ['originalStatus']) || '',
          externalCreatedAt: mcCalendarShellV01Cell_(row, hm, ['externalCreatedAt']) || '',
          externalLastModifiedAt: mcCalendarShellV01Cell_(row, hm, ['externalLastModifiedAt']) || '',
          provider: mcCalendarShellV01Cell_(row, hm, ['provider']) || '',
          calendarType: mcCalendarShellV01Cell_(row, hm, ['calendarType', 'eventType', 'sourceType']) || (sheetNames[sn] === 'MAILCENTER_CalendarEvents' ? '메일일정' : ''),
          sourceType: mcCalendarShellV01Cell_(row, hm, ['sourceType']) || '',
          customTypeName: mcCalendarShellV01Cell_(row, hm, ['customTypeName']) || '',
          sourceModule: mcCalendarShellV01Cell_(row, hm, ['sourceModule']) || (sheetNames[sn] === 'MAILCENTER_CalendarEvents' ? 'MAILCENTER' : ''),
          sourceId: mcCalendarShellV01Cell_(row, hm, ['sourceId']) || '',
          eventId: mcCalendarShellV01Cell_(row, hm, ['eventId']) || '',
          rentalId: mcCalendarShellV01Cell_(row, hm, ['rentalId']) || '',
          setupItemId: mcCalendarShellV01Cell_(row, hm, ['setupItemId']) || '',
          ownerName: mcCalendarShellV01Cell_(row, hm, ['ownerName']) || '',
          categoryCode: mcCalendarShellV01Cell_(row, hm, ['categoryCode']) || '',
          priority: mcCalendarShellV01Cell_(row, hm, ['priority']) || '',
          privacyLevel: mcCalendarShellV01Cell_(row, hm, ['privacyLevel', 'visibility']) || '',
          busyStatus: mcCalendarShellV01Cell_(row, hm, ['busyStatus']) || '',
          repeatType: mcCalendarShellV01Cell_(row, hm, ['repeatType']) || '',
          syncTarget: mcCalendarShellV01Cell_(row, hm, ['syncTarget']) || '',
          googleSyncStatus: mcCalendarShellV01Cell_(row, hm, ['googleSyncStatus']) || '',
          naverRegisterStatus: mcCalendarShellV01Cell_(row, hm, ['naverRegisterStatus']) || '',
          naverProviderEventId: mcCalendarShellV01Cell_(row, hm, ['naverProviderEventId']) || '',
          naverErrorCode: mcCalendarShellV01Cell_(row, hm, ['naverErrorCode']) || '',
          naverErrorMessage: mcCalendarShellV01Cell_(row, hm, ['naverErrorMessage']) || '',
          googleBackupStatus: mcCalendarShellV01Cell_(row, hm, ['googleBackupStatus']) || '',
          googleProviderEventId: mcCalendarShellV01Cell_(row, hm, ['googleProviderEventId']) || '',
          googleErrorCode: mcCalendarShellV01Cell_(row, hm, ['googleErrorCode']) || '',
          googleErrorMessage: mcCalendarShellV01Cell_(row, hm, ['googleErrorMessage']) || '',
          attendeesJson: mcCalendarShellV01Cell_(row, hm, ['attendeesJson']) || '',
          meetingUrl: mcCalendarShellV01Cell_(row, hm, ['meetingUrl']) || '',
          eventGroupType: mcCalendarShellV01Cell_(row, hm, ['eventGroupType']) || '',
          operationType: mcCalendarShellV01Cell_(row, hm, ['operationType']) || '',
          ownerUserId: mcCalendarShellV01Cell_(row, hm, ['ownerUserId']) || '',
          departmentCode: mcCalendarShellV01Cell_(row, hm, ['departmentCode']) || '',
          organizerRole: mcCalendarShellV01Cell_(row, hm, ['organizerRole']) || '',
          participantJson: mcCalendarShellV01Cell_(row, hm, ['participantJson']) || '',
          externalPartyJson: mcCalendarShellV01Cell_(row, hm, ['externalPartyJson']) || '',
          agendaJson: mcCalendarShellV01Cell_(row, hm, ['agendaJson']) || '',
          decisionMemo: mcCalendarShellV01Cell_(row, hm, ['decisionMemo']) || '',
          todoJson: mcCalendarShellV01Cell_(row, hm, ['todoJson']) || '',
          councilName: mcCalendarShellV01Cell_(row, hm, ['councilName']) || '',
          fairName: mcCalendarShellV01Cell_(row, hm, ['fairName']) || '',
          meetingMethod: mcCalendarShellV01Cell_(row, hm, ['meetingMethod']) || '',
          presentationType: mcCalendarShellV01Cell_(row, hm, ['presentationType']) || '',
          sourceWritePolicy: mcCalendarShellV01Cell_(row, hm, ['sourceWritePolicy']) || '',
          sourceUpdateStatus: mcCalendarShellV01Cell_(row, hm, ['sourceUpdateStatus']) || '',
          nextFollowUpAt: mcCalendarShellV01Cell_(row, hm, ['nextFollowUpAt']) || '',
          boothZone: mcCalendarShellV01Cell_(row, hm, ['boothZone']) || '',
          organizerEmail: mcCalendarShellV01Cell_(row, hm, ['organizerEmail']) || '',
          createdBy: mcCalendarShellV01Cell_(row, hm, ['createdBy']) || '',
          createdByName: mcCalendarShellV01Cell_(row, hm, ['createdByName']) || '',
          createdByEmail: mcCalendarShellV01Cell_(row, hm, ['createdByEmail']) || '',
          createdByEmployeeId: mcCalendarShellV01Cell_(row, hm, ['createdByEmployeeId']) || '',
          actorSource: mcCalendarShellV01Cell_(row, hm, ['actorSource']) || '',
          updatedAt: mcCalendarShellV01Cell_(row, hm, ['updatedAt']) || '',
          updatedBy: mcCalendarShellV01Cell_(row, hm, ['updatedBy']) || '',
          updatedByName: mcCalendarShellV01Cell_(row, hm, ['updatedByName']) || '',
          updatedByEmail: mcCalendarShellV01Cell_(row, hm, ['updatedByEmail']) || '',
          updatedByEmployeeId: mcCalendarShellV01Cell_(row, hm, ['updatedByEmployeeId']) || '',
          updatedActorSource: mcCalendarShellV01Cell_(row, hm, ['updatedActorSource']) || '',
          status: status,
          statusLabel: mcCalendarShellV01StatusLabel_(status),
          createdAt: String(mcCalendarShellV01Cell_(row, hm, ['createdAt']) || ''),
          sourceSheet: sheetNames[sn]
        };
        result.events.push(item);
        if (dateKey === todayKey) result.today++;
      }
    }
    if (!foundAnySheet) {
      result.message = '등록된 일정이 없습니다.';
      return mcCalendarShellV01Safe_(result);
    }
    result.total = result.events.length;
    result.dashboard = mcCalendarShellV01ProviderSummary_(result.events);
    result.events.sort(function(a, b) {
      return String(a.startAt || '').localeCompare(String(b.startAt || '')) || String(a.createdAt || '').localeCompare(String(b.createdAt || ''));
    });
  } catch (err) {
    result.ok = false;
    result.message = String(err && err.message ? err.message : err);
  }
  return mcCalendarShellV01Safe_(result);
}

/* PORTAL_CALENDAR_SAFE01B_R10K4G4_DATA_LOAD_SPEED_REPAIR_20260604
 * SystemConfig -> FEELHAUS_DB_MASTER lookup cache.
 * Reads SystemConfig automatically on cache miss, never changes the DB connection policy.
 */
function mcCalendarShellV01GetMasterIdCached_() {
  var setupId = '17VMSpgSZCvIrUlgcw8yCNcnl8WQWo2IcRf5tDCcuJGM';
  var cacheKey = 'MC_CALENDAR_MASTER_ID_R10K4G4';
  var cached = '';
  try { cached = CacheService.getScriptCache().get(cacheKey) || ''; } catch (cacheReadErr) {}
  if (cached) return cached;

  var setup = SpreadsheetApp.openById(setupId);
  var sheet = setup.getSheetByName('SystemConfig');
  if (!sheet) throw new Error('SystemConfig 시트를 찾지 못했습니다.');
  var values = sheet.getDataRange().getValues();
  if (!values || values.length < 2) throw new Error('SystemConfig 데이터가 비어 있습니다.');
  var hm = mcCalendarShellV01HeaderMap_(values[0]);
  var keyCol = mcCalendarShellV01PickIndex_(hm, ['CONFIG_KEY','configKey','key','name']);
  var valCol = mcCalendarShellV01PickIndex_(hm, ['VALUE','configValue','value','spreadsheetId']);
  if (keyCol < 0 || valCol < 0) throw new Error('SystemConfig CONFIG_KEY/VALUE 헤더를 찾지 못했습니다.');
  var masterId = '';
  for (var r = 1; r < values.length; r++) {
    var key = String(values[r][keyCol] || '').trim();
    if (key === 'FEELHAUS_DB_MASTER' || key === 'FEELHAUS_DB_MASTER_ID' || key === 'MASTER_DB_ID') {
      masterId = String(values[r][valCol] || '').trim();
      break;
    }
  }
  if (!masterId) throw new Error('SystemConfig에서 FEELHAUS_DB_MASTER ID를 찾지 못했습니다.');
  try { CacheService.getScriptCache().put(cacheKey, masterId, 300); } catch (cacheWriteErr) {}
  return masterId;
}

function mcCalendarShellV01OpenMaster_() {
  return SpreadsheetApp.openById(mcCalendarShellV01GetMasterIdCached_());
}

function mcCalendarShellV01HeaderMap_(headers) {
  var out = {};
  (headers || []).forEach(function(h, i) {
    var key = String(h || '').trim();
    if (key) out[key] = i;
  });
  return out;
}

function mcCalendarShellV01PickIndex_(hm, keys) {
  for (var i = 0; i < keys.length; i++) if (hm.hasOwnProperty(keys[i])) return hm[keys[i]];
  return -1;
}

function mcCalendarShellV01Cell_(row, hm, keys) {
  for (var i = 0; i < keys.length; i++) {
    if (hm.hasOwnProperty(keys[i])) return row[hm[keys[i]]];
  }
  return '';
}

function mcCalendarShellV01DateKey_(value, tz) {
  if (!value && value !== 0) return '';
  if (Object.prototype.toString.call(value) === '[object Date]' && !isNaN(value.getTime())) {
    return Utilities.formatDate(value, tz || 'Asia/Seoul', 'yyyy-MM-dd');
  }
  var s = String(value || '').trim();
  var m = s.match(/^(\d{4})-(\d{2})-(\d{2})/);
  if (m) return m[1] + '-' + m[2] + '-' + m[3];
  var d = new Date(s);
  if (!isNaN(d.getTime())) return Utilities.formatDate(d, tz || 'Asia/Seoul', 'yyyy-MM-dd');
  return '';
}

function mcCalendarShellV01ProviderSummary_(events) {
  var summary = {
    naverSuccess: 0,
    googleSuccess: 0,
    naverPending: 0,
    googlePending: 0
  };
  (events || []).forEach(function(e) {
    e = e || {};
    var ns = String(e.naverRegisterStatus || '').toUpperCase();
    var gs = String(e.googleBackupStatus || '').toUpperCase();
    var nId = String(e.naverProviderEventId || '').trim();
    var gId = String(e.googleProviderEventId || '').trim();

    if (ns === 'SUCCESS' || nId) summary.naverSuccess++;
    else if (ns === 'PENDING' || ns === '') summary.naverPending++;

    if (gs === 'SUCCESS' || gId) summary.googleSuccess++;
    else if (gs === 'PENDING' || gs === '') summary.googlePending++;
  });
  return summary;
}

function mcCalendarShellV01StatusLabel_(status) {
  var map = {
    MAIL_LINK_SAVED: '메일등록',
    REQUESTED: '요청',
    SCHEDULED: '예정',
    IN_PROGRESS: '진행중',
    DONE: '완료',
    CANCELLED: '취소'
  };
  return map[String(status || '').trim()] || String(status || '').trim() || '상태없음';
}

function mcCalendarShellV01Now_() {
  return Utilities.formatDate(new Date(), Session.getScriptTimeZone(), 'yyyy-MM-dd HH:mm:ss');
}

function mcCalendarShellV01Safe_(obj) {
  try {
    return JSON.parse(JSON.stringify(obj || {}));
  } catch (err) {
    return {
      ok: false,
      build: MC_CALENDAR_LINK_V01_BUILD,
      message: String(err && err.message ? err.message : err)
    };
  }
}
