/**
 * FEELHAUS MailCenter Navigation Links V01
 * Build: MC_MENU_NAV_LINKS_V01_20260519
 *
 * Purpose:
 * - MailCenter 내부 화면 공통 이동 링크 제공
 * - Dashboard / Compose / SendTest / AccountAdmin / Settings
 * - Portal_Main.js 수정 없음
 */

var MC_MENU_NAV_LINKS_V01_BUILD = 'MC_MENU_NAV_LINKS_V01_20260519';

function runMcMenuNavLinksV01Smoke() {
  var result = {
    ok: false,
    build: MC_MENU_NAV_LINKS_V01_BUILD,
    action: 'runMcMenuNavLinksV01Smoke',
    generatedAt: mcMenuNavLinksV01Now_(),
    message: '',
    checks: []
  };

  try {
    result.checks.push({
      key: 'NavDataReady',
      ok: typeof mcMenuNavLinksV01GetLinks === 'function',
      message: 'MailCenter 메뉴 링크 함수 확인'
    });
    result.checks.push({
      key: 'DashboardRouteExpected',
      ok: true,
      message: 'MailCenterDashboardV04 route 사용'
    });
    result.checks.push({
      key: 'ComposeRouteExpected',
      ok: true,
      message: 'MailCenterComposeV01 route 사용'
    });
    result.checks.push({
      key: 'SendTestRouteExpected',
      ok: true,
      message: 'MailCenterSendTestV05 route 사용'
    });
    result.checks.push({
      key: 'AccountAdminRouteExpected',
      ok: true,
      message: 'MailCenterAccountAdminV01 route 사용'
    });
    result.checks.push({
      key: 'SettingsRouteExpected',
      ok: true,
      message: 'MailCenterSettingsV01 route 사용'
    });

    result.ok = result.checks.every(function(c) { return !!c.ok; });
    result.message = result.ok ? 'MailCenter Menu Nav Links V01 준비 완료' : 'MailCenter Menu Nav Links V01 점검 실패';
  } catch (err) {
    result.ok = false;
    result.message = String(err && err.message ? err.message : err);
  }

  mcMenuNavLinksV01Log_(result);
  return result;
}

function mcMenuNavLinksV01GetLinks() {
  return [
    {
      page: 'MailCenterDashboardV04',
      label: '대시보드',
      icon: '⌂',
      desc: '메일센터 현황',
      group: 'MAILCENTER'
    },
    {
      page: 'MailCenterComposeV01',
      label: '메일 작성/발송',
      icon: '✎',
      desc: '기본 계정/서명 적용 발송',
      group: 'MAILCENTER'
    },
    {
      page: 'MailCenterCalendarV01',
      label: '메일 일정 관리',
      icon: '▣',
      desc: '메일과 연결되는 일정 관리',
      group: 'MAILCENTER'
    },
    {
      page: 'eventVendor',
      label: '행사관리',
      icon: '★',
      desc: '기존 ERP 행사관리 엔진 연결',
      group: 'ERP'
    },
    {
      page: 'MailCenterSendTestV05',
      label: '테스트 발송',
      icon: '✉',
      desc: '계정별 발송 테스트',
      group: 'MAILCENTER'
    },
    {
      page: 'MailCenterAccountAdminV01',
      label: '계정 등록/승인',
      icon: '☑',
      desc: '직원/업체 원본 연결',
      group: 'MAILCENTER'
    },
    {
      page: 'MailCenterSettingsV01',
      label: '서명/폴더/설정',
      icon: '⚙',
      desc: '서명, 폴더, 기본 발신계정',
      group: 'MAILCENTER'
    }
  ];
}

function mcMenuNavLinksV01Now_() {
  return Utilities.formatDate(new Date(), Session.getScriptTimeZone() || 'Asia/Seoul', 'yyyy-MM-dd HH:mm:ss');
}

function mcMenuNavLinksV01Log_(obj) {
  try {
    Logger.log('JSON_COMPACT_RESULT: ' + JSON.stringify(obj));
  } catch (e) {
    Logger.log(obj);
  }
}
