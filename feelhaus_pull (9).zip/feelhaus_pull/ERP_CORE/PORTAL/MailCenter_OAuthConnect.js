/**
 * FEELHAUS MailCenter OAuth Connect FAST V03
 * Build: MAILCENTER_OAUTH_CONNECT_FAST_V03_20260519
 * Purpose:
 * - 독립형 MailCenter가 기존 PORTAL 169/171 Gmail OAuth 커넥터를 안전하게 호출한다.
 * - PORTAL 본체/캘린더/직원관리 비침범. 신규 파일 1개만 추가.
 * - 토큰/refresh token/access token은 노출하거나 MailCenter 시트에 저장하지 않는다.
 */
var MAILCENTER_OAUTH_BUILD = 'MAILCENTER_OAUTH_CONNECT_FAST_V03_20260519';
var MAILCENTER_OAUTH_DESC = '독립형 MailCenter Gmail OAuth 승인 URL 생성 / pepsi309 실계정 연결 / 기존 169 OAuth 커넥터 유지 / FAST 기준';
var MAILCENTER_OAUTH_SHEET = 'MailCenter_OAuthConnections';
var MAILCENTER_OAUTH_HEADERS = [
  'oauthConnectionId','mailAccountId','connectorMailAccountId','vendorId','emailAddress','provider',
  'oauthStatus','authUrl','redirectUri','lastConnectedAt','lastCheckedAt','lastError',
  'createdAt','createdBy','updatedAt','updatedBy'
];
var MAILCENTER_OAUTH_STATUSES = ['READY','PENDING_AUTH','CONNECTED','FAILED','DISCONNECTED','REVOKED'];

function runMailCenterOAuthConnectFastV01() {
  var r = mailCenterOAuthResult_('runMailCenterOAuthConnectFastV01');
  var checks = [];
  try {
    mailCenterOAuthEnsureSheet_();
    checks.push(mailCenterOAuthCheck_('OAuthSheetReady', true, 'MailCenter_OAuthConnections 시트/헤더 준비'));
    checks.push(mailCenterOAuthCheck_('StandaloneGateReady', typeof mailCenterSetupStandaloneGateOnce === 'function', 'MailCenter 1차 게이트 함수 유지'));
    checks.push(mailCenterOAuthCheck_('Connector169RegisterReady', typeof portal169RegisterMailAccountLock === 'function', '기존 169 계정등록/OAuth URL 함수 존재'));
    checks.push(mailCenterOAuthCheck_('Connector169ListReady', typeof portal169ListMailAccountsLock === 'function', '기존 169 계정목록 함수 존재'));
    checks.push(mailCenterOAuthCheck_('Connector169GateReady', typeof portal169MailConnectorGateLock === 'function', '기존 169 Gmail 연결점검 함수 존재'));
    checks.push(mailCenterOAuthCheck_('CallbackRouteReady', typeof portal171CheckMailOAuthRouteLock === 'function' || typeof portal169HandleGet === 'function', 'OAuth callback route 유지'));
    checks.push(mailCenterOAuthCheck_('NoTokenColumns', MAILCENTER_OAUTH_HEADERS.indexOf('accessToken') < 0 && MAILCENTER_OAUTH_HEADERS.indexOf('refreshToken') < 0, '토큰 컬럼 없음'));
    var config = mailCenterOAuthConfigCheck_();
    checks.push(mailCenterOAuthCheck_('OAuthClientIdConfigured', !!config.clientId, config.clientId ? 'GMAIL_OAUTH_CLIENT_ID 확인' : 'GMAIL_OAUTH_CLIENT_ID 미설정'));
    checks.push(mailCenterOAuthCheck_('OAuthClientSecretConfigured', !!config.clientSecret, config.clientSecret ? 'GMAIL_OAUTH_CLIENT_SECRET 확인' : 'GMAIL_OAUTH_CLIENT_SECRET 미설정'));
    r.ok = mailCenterOAuthAllRequiredOk_(checks);
    r.message = r.ok ? 'MailCenter OAuth Connect FAST V01 준비 완료' : 'MailCenter OAuth Connect FAST V01 준비 완료 - Google OAuth 설정값 확인 필요';
    r.checks = checks;
    r.requiredNext = '대표메일 ACTIVE 계정에서 mailCenterBuildOAuthConnectUrl(sid,payload)를 호출하면 authUrl이 생성됩니다.';
    r.executeOnlyWhenNeeded = ['mailCenterBuildOAuthConnectUrl','mailCenterSyncOAuthConnectionStatus','mailCenterCheckOAuthConnection'];
    r.changedFile = 'MailCenter_OAuthConnect.js';
  } catch (err) {
    r.ok = false;
    r.message = mailCenterOAuthErr_(err);
    r.checks = checks;
  }
  Logger.log('JSON_COMPACT_RESULT: ' + JSON.stringify(r));
  return r;
}

function mailCenterOAuthSetupFastOnce(sid) {
  var r = mailCenterOAuthResult_('mailCenterOAuthSetupFastOnce');
  try {
    mailCenterOAuthEnsureSheet_();
    r.ok = true;
    r.message = 'MailCenter OAuth 연결 시트/헤더 점검 완료';
    r.sheet = MAILCENTER_OAUTH_SHEET;
    r.headers = MAILCENTER_OAUTH_HEADERS;
    mailCenterOAuthAuditSafe_('MAIL_OAUTH','MailCenterOAuth','SETUP','','','SUCCESS',r.message,mailCenterOAuthActor_(sid));
  } catch (err) {
    r.ok = false;
    r.message = mailCenterOAuthErr_(err);
  }
  Logger.log('JSON_COMPACT_RESULT: ' + JSON.stringify(r));
  return r;
}

function getMailCenterOAuthConnectFunctionList() {
  var r = mailCenterOAuthResult_('getMailCenterOAuthConnectFunctionList');
  r.ok = true;
  r.message = 'MailCenter OAuth Connect FAST V01 실제 함수 목록';
  r.changedFile = 'MailCenter_OAuthConnect.js';
  r.noArgFunctions = [
    {name:'runMailCenterOAuthConnectFastV01', file:'MailCenter_OAuthConnect.js', purpose:'OAuth 시트 생성 및 169/171 브리지 준비상태 점검'},
    {name:'mailCenterOAuthSetupFastOnce', file:'MailCenter_OAuthConnect.js', purpose:'OAuth 연결 시트/헤더만 점검'},
    {name:'getMailCenterOAuthConnectFunctionList', file:'MailCenter_OAuthConnect.js', purpose:'실제 함수 목록 확인'}
  ];
  r.parameterFunctions = [
    {name:'mailCenterBuildOAuthConnectUrl', file:'MailCenter_OAuthConnect.js', args:'sid, payload{mailAccountId}', purpose:'ACTIVE 대표메일의 Gmail OAuth 승인 URL 생성'},
    {name:'mailCenterSyncOAuthConnectionStatus', file:'MailCenter_OAuthConnect.js', args:'sid, payload{mailAccountId}', purpose:'169 커넥터 상태를 MailCenter OAuth 상태로 동기화'},
    {name:'mailCenterCheckOAuthConnection', file:'MailCenter_OAuthConnect.js', args:'sid, payload{mailAccountId}', purpose:'Gmail API 연결 점검 후 상태 반영'},
    {name:'mailCenterListOAuthConnections', file:'MailCenter_OAuthConnect.js', args:'sid, payload{vendorId}', purpose:'OAuth 연결 목록 조회'}
  ];
  Logger.log('JSON_COMPACT_RESULT: ' + JSON.stringify(r));
  return r;
}

function mailCenterBuildOAuthConnectUrl(sid, payload) {
  var r = mailCenterOAuthResult_('mailCenterBuildOAuthConnectUrl');
  try {
    mailCenterOAuthEnsureSheet_();
    var p = payload || {};
    var actor = mailCenterOAuthActor_(sid);
    var mailAccountId = mailCenterOAuthRequire_(p.mailAccountId, 'mailAccountId');
    var acc = mailCenterOAuthGetMailAccount_(mailAccountId);
    if (!acc) throw new Error('MailCenter_Accounts에서 mailAccountId를 찾을 수 없습니다: ' + mailAccountId);
    if (String(acc.mailAccountStatus || '') !== 'ACTIVE') throw new Error('ACTIVE 승인된 대표메일만 OAuth 연결할 수 있습니다. 현재 상태: ' + String(acc.mailAccountStatus || ''));
    if (typeof portal169RegisterMailAccountLock !== 'function') throw new Error('Portal_Run169_MailConnectorMultiAccount.js의 portal169RegisterMailAccountLock 함수가 없습니다.');
    var bridge = portal169RegisterMailAccountLock(sid || '', {
      ownerType: acc.ownerType || (acc.vendorId ? 'VENDOR' : 'HQ'),
      ownerId: acc.vendorId || 'HQ',
      vendorId: acc.vendorId || '',
      emailAddress: acc.emailAddress,
      displayName: acc.ownerName || acc.emailAddress
    });
    if (!bridge || !bridge.ok) throw new Error(bridge && bridge.message ? bridge.message : '169 OAuth URL 생성 실패');
    var now = mailCenterOAuthNow_();
    var row = {
      oauthConnectionId: mailCenterOAuthId_('OAUTH'),
      mailAccountId: mailAccountId,
      connectorMailAccountId: bridge.mailAccountId || '',
      vendorId: acc.vendorId || '',
      emailAddress: acc.emailAddress || '',
      provider: acc.provider || 'GOOGLE_WORKSPACE',
      oauthStatus: bridge.authUrl ? 'PENDING_AUTH' : 'READY',
      authUrl: bridge.authUrl || '',
      redirectUri: bridge.redirectUri || '',
      lastConnectedAt: '',
      lastCheckedAt: now,
      lastError: '',
      createdAt: now,
      createdBy: actor,
      updatedAt: now,
      updatedBy: actor
    };
    var existing = mailCenterOAuthFindConnection_(mailAccountId);
    if (existing && existing.oauthConnectionId) {
      row.oauthConnectionId = existing.oauthConnectionId;
      row.createdAt = existing.createdAt || now;
      row.createdBy = existing.createdBy || actor;
      row.lastConnectedAt = existing.lastConnectedAt || '';
    }
    mailCenterOAuthUpsert_(MAILCENTER_OAUTH_SHEET, MAILCENTER_OAUTH_HEADERS, 'oauthConnectionId', row);
    mailCenterOAuthAuditSafe_('MAIL_OAUTH', mailAccountId, 'BUILD_AUTH_URL', '', row.oauthStatus, 'SUCCESS', 'Gmail OAuth 승인 URL 생성', actor);
    r.ok = true;
    r.message = 'Gmail OAuth 승인 URL 생성 완료';
    r.mailAccountId = mailAccountId;
    r.connectorMailAccountId = row.connectorMailAccountId;
    r.emailAddress = row.emailAddress;
    r.oauthStatus = row.oauthStatus;
    r.authUrl = row.authUrl;
    r.redirectUri = row.redirectUri;
  } catch (err) {
    r.ok = false;
    r.message = mailCenterOAuthErr_(err);
  }
  Logger.log('JSON_COMPACT_RESULT: ' + JSON.stringify(r));
  return r;
}

function mailCenterSyncOAuthConnectionStatus(sid, payload) {
  var r = mailCenterOAuthResult_('mailCenterSyncOAuthConnectionStatus');
  try {
    mailCenterOAuthEnsureSheet_();
    var p = payload || {};
    var actor = mailCenterOAuthActor_(sid);
    var mailAccountId = mailCenterOAuthRequire_(p.mailAccountId, 'mailAccountId');
    var acc = mailCenterOAuthGetMailAccount_(mailAccountId);
    if (!acc) throw new Error('MailCenter_Accounts에서 mailAccountId를 찾을 수 없습니다: ' + mailAccountId);
    if (typeof portal169ListMailAccountsLock !== 'function') throw new Error('portal169ListMailAccountsLock 함수가 없습니다.');
    var list = portal169ListMailAccountsLock(sid || '', {vendorId: acc.vendorId || ''});
    if (!list || !list.ok) throw new Error(list && list.message ? list.message : '169 계정 목록 조회 실패');
    var connector = null;
    var items = list.items || [];
    for (var i = 0; i < items.length; i++) {
      if (String(items[i].emailAddress || '').toLowerCase() === String(acc.emailAddress || '').toLowerCase()) {
        connector = items[i];
        break;
      }
    }
    if (!connector) throw new Error('169 커넥터에서 동일 이메일 계정을 찾지 못했습니다: ' + acc.emailAddress);
    var now = mailCenterOAuthNow_();
    var status = String(connector.authStatus || '') === 'CONNECTED' ? 'CONNECTED' : 'PENDING_AUTH';
    var row = mailCenterOAuthFindConnection_(mailAccountId) || {};
    row.oauthConnectionId = row.oauthConnectionId || mailCenterOAuthId_('OAUTH');
    row.mailAccountId = mailAccountId;
    row.connectorMailAccountId = connector.mailAccountId || row.connectorMailAccountId || '';
    row.vendorId = acc.vendorId || '';
    row.emailAddress = acc.emailAddress || '';
    row.provider = acc.provider || 'GOOGLE_WORKSPACE';
    row.oauthStatus = status;
    row.lastConnectedAt = connector.lastConnectedAt || row.lastConnectedAt || '';
    row.lastCheckedAt = now;
    row.lastError = connector.lastError || '';
    row.createdAt = row.createdAt || now;
    row.createdBy = row.createdBy || actor;
    row.updatedAt = now;
    row.updatedBy = actor;
    mailCenterOAuthUpsert_(MAILCENTER_OAUTH_SHEET, MAILCENTER_OAUTH_HEADERS, 'oauthConnectionId', row);
    if (status === 'CONNECTED') mailCenterOAuthUpdateMailAccountConnection_(mailAccountId, row.lastConnectedAt || now, actor);
    r.ok = true;
    r.message = 'OAuth 연결 상태 동기화 완료';
    r.mailAccountId = mailAccountId;
    r.connectorMailAccountId = row.connectorMailAccountId;
    r.oauthStatus = status;
    r.lastConnectedAt = row.lastConnectedAt;
  } catch (err) {
    r.ok = false;
    r.message = mailCenterOAuthErr_(err);
  }
  Logger.log('JSON_COMPACT_RESULT: ' + JSON.stringify(r));
  return r;
}

function mailCenterCheckOAuthConnection(sid, payload) {
  var r = mailCenterOAuthResult_('mailCenterCheckOAuthConnection');
  try {
    mailCenterOAuthEnsureSheet_();
    var p = payload || {};
    var mailAccountId = mailCenterOAuthRequire_(p.mailAccountId, 'mailAccountId');
    var row = mailCenterOAuthFindConnection_(mailAccountId);
    if (!row || !row.connectorMailAccountId) throw new Error('먼저 mailCenterBuildOAuthConnectUrl로 OAuth 연결행을 생성하세요.');
    if (typeof portal169MailConnectorGateLock !== 'function') throw new Error('portal169MailConnectorGateLock 함수가 없습니다.');
    var gate = portal169MailConnectorGateLock(sid || '', {mailAccountId: row.connectorMailAccountId});
    if (!gate || !gate.ok) throw new Error(gate && gate.message ? gate.message : 'Gmail 연결 점검 실패');
    row.oauthStatus = 'CONNECTED';
    row.lastConnectedAt = mailCenterOAuthNow_();
    row.lastCheckedAt = row.lastConnectedAt;
    row.lastError = '';
    row.updatedAt = row.lastConnectedAt;
    row.updatedBy = mailCenterOAuthActor_(sid);
    mailCenterOAuthUpsert_(MAILCENTER_OAUTH_SHEET, MAILCENTER_OAUTH_HEADERS, 'oauthConnectionId', row);
    mailCenterOAuthUpdateMailAccountConnection_(mailAccountId, row.lastConnectedAt, mailCenterOAuthActor_(sid));
    r.ok = true;
    r.message = 'Gmail OAuth 연결 점검 완료';
    r.mailAccountId = mailAccountId;
    r.connectorMailAccountId = row.connectorMailAccountId;
    r.oauthStatus = 'CONNECTED';
  } catch (err) {
    r.ok = false;
    r.message = mailCenterOAuthErr_(err);
  }
  Logger.log('JSON_COMPACT_RESULT: ' + JSON.stringify(r));
  return r;
}

function mailCenterListOAuthConnections(sid, payload) {
  var r = mailCenterOAuthResult_('mailCenterListOAuthConnections');
  try {
    mailCenterOAuthEnsureSheet_();
    var p = payload || {};
    var vendorId = String(p.vendorId || '').trim();
    var rows = mailCenterOAuthReadObjects_(MAILCENTER_OAUTH_SHEET, MAILCENTER_OAUTH_HEADERS).filter(function(x){
      return !vendorId || String(x.vendorId || '') === vendorId;
    });
    r.ok = true;
    r.message = 'OAuth 연결 목록 조회 완료';
    r.count = rows.length;
    r.items = rows.slice(0, 50).map(function(x){
      return {
        oauthConnectionId: x.oauthConnectionId,
        mailAccountId: x.mailAccountId,
        connectorMailAccountId: x.connectorMailAccountId,
        vendorId: x.vendorId,
        emailAddress: x.emailAddress,
        provider: x.provider,
        oauthStatus: x.oauthStatus,
        redirectUri: x.redirectUri,
        lastConnectedAt: x.lastConnectedAt,
        lastCheckedAt: x.lastCheckedAt,
        lastError: x.lastError
      };
    });
  } catch (err) {
    r.ok = false;
    r.message = mailCenterOAuthErr_(err);
  }
  return r;
}

function mailCenterOAuthEnsureSheet_() {
  var ss = mailCenterOAuthOpenMasterDb_();
  var sh = ss.getSheetByName(MAILCENTER_OAUTH_SHEET);
  if (!sh) sh = ss.insertSheet(MAILCENTER_OAUTH_SHEET);
  var range = sh.getRange(1, 1, 1, MAILCENTER_OAUTH_HEADERS.length);
  var current = range.getValues()[0].map(function(h){ return String(h || '').trim(); });
  var needs = false;
  for (var i = 0; i < MAILCENTER_OAUTH_HEADERS.length; i++) {
    if (current[i] !== MAILCENTER_OAUTH_HEADERS[i]) { needs = true; break; }
  }
  if (needs) range.setValues([MAILCENTER_OAUTH_HEADERS]);
  sh.setFrozenRows(1);
  return sh;
}

function mailCenterOAuthOpenMasterDb_() {
  if (typeof mailCenterOpenMasterDb_ === 'function') return mailCenterOpenMasterDb_();
  var active = SpreadsheetApp.getActiveSpreadsheet();
  if (active) return active;
  throw new Error('FEELHAUS_DB_MASTER 연결 실패: mailCenterOpenMasterDb_ 함수가 없습니다.');
}

function mailCenterOAuthGetMailAccount_(mailAccountId) {
  if (typeof mailCenterGetById_ === 'function' && typeof MAILCENTER_SHEETS !== 'undefined' && typeof MAILCENTER_HEADERS !== 'undefined') {
    return mailCenterGetById_(MAILCENTER_SHEETS.accounts, MAILCENTER_HEADERS.accounts, 'mailAccountId', mailAccountId);
  }
  return mailCenterOAuthGetById_('MailCenter_Accounts', ['mailAccountId','vendorId','eventId','ownerType','ownerName','emailAddress','provider','mailAccountStatus','statusReason','approvalStatus','requestedBy','requestedAt','approvedBy','approvedAt','lastConnectedAt','lastSyncAt','createdAt','createdBy','updatedAt','updatedBy'], 'mailAccountId', mailAccountId);
}

function mailCenterOAuthUpdateMailAccountConnection_(mailAccountId, connectedAt, actor) {
  if (typeof MAILCENTER_SHEETS === 'undefined' || typeof MAILCENTER_HEADERS === 'undefined') return;
  var acc = mailCenterOAuthGetMailAccount_(mailAccountId);
  if (!acc) return;
  acc.lastConnectedAt = connectedAt;
  acc.lastSyncAt = mailCenterOAuthNow_();
  acc.updatedAt = mailCenterOAuthNow_();
  acc.updatedBy = actor || '';
  if (typeof mailCenterUpsert_ === 'function') mailCenterUpsert_(MAILCENTER_SHEETS.accounts, MAILCENTER_HEADERS.accounts, 'mailAccountId', acc);
}

function mailCenterOAuthFindConnection_(mailAccountId) {
  var rows = mailCenterOAuthReadObjects_(MAILCENTER_OAUTH_SHEET, MAILCENTER_OAUTH_HEADERS);
  for (var i = rows.length - 1; i >= 0; i--) {
    if (String(rows[i].mailAccountId || '') === String(mailAccountId || '')) return rows[i];
  }
  return null;
}

function mailCenterOAuthReadObjects_(sheetName, headers) {
  var ss = mailCenterOAuthOpenMasterDb_();
  var sh = ss.getSheetByName(sheetName);
  if (!sh) return [];
  var values = sh.getDataRange().getValues();
  if (values.length < 2) return [];
  var heads = values[0].map(function(h){ return String(h || '').trim(); });
  var map = {};
  for (var h = 0; h < heads.length; h++) map[heads[h]] = h;
  var out = [];
  for (var r = 1; r < values.length; r++) {
    var blank = true;
    var obj = {};
    for (var c = 0; c < headers.length; c++) {
      var name = headers[c];
      var idx = map[name];
      var val = idx === undefined ? '' : values[r][idx];
      if (val !== '' && val !== null) blank = false;
      obj[name] = val;
    }
    if (!blank) out.push(obj);
  }
  return out;
}

function mailCenterOAuthGetById_(sheetName, headers, keyName, keyValue) {
  var rows = mailCenterOAuthReadObjects_(sheetName, headers);
  for (var i = 0; i < rows.length; i++) {
    if (String(rows[i][keyName] || '') === String(keyValue || '')) return rows[i];
  }
  return null;
}

function mailCenterOAuthUpsert_(sheetName, headers, keyName, obj) {
  var ss = mailCenterOAuthOpenMasterDb_();
  var sh = ss.getSheetByName(sheetName) || ss.insertSheet(sheetName);
  var lastCol = Math.max(sh.getLastColumn(), headers.length);
  if (sh.getLastRow() < 1) sh.getRange(1, 1, 1, headers.length).setValues([headers]);
  var values = sh.getDataRange().getValues();
  var heads = values[0].map(function(h){ return String(h || '').trim(); });
  var map = {};
  for (var h = 0; h < heads.length; h++) map[heads[h]] = h;
  var rowIndex = -1;
  for (var r = 1; r < values.length; r++) {
    if (String(values[r][map[keyName]] || '') === String(obj[keyName] || '')) { rowIndex = r + 1; break; }
  }
  var row = [];
  for (var c = 0; c < headers.length; c++) row.push(obj[headers[c]] === undefined ? '' : obj[headers[c]]);
  if (rowIndex > 0) sh.getRange(rowIndex, 1, 1, headers.length).setValues([row]);
  else sh.appendRow(row);
}

function mailCenterOAuthConfigCheck_() {
  var clientId = '';
  var clientSecret = '';
  var redirectUri = '';
  try {
    if (typeof portal169GetSetting_ === 'function') {
      clientId = portal169GetSetting_('GMAIL_OAUTH_CLIENT_ID') || '';
      clientSecret = portal169GetSetting_('GMAIL_OAUTH_CLIENT_SECRET') || '';
      redirectUri = typeof portal169GetRedirectUri_ === 'function' ? portal169GetRedirectUri_() : '';
    }
  } catch (ignore) {}
  return {clientId: clientId, clientSecret: clientSecret, redirectUri: redirectUri};
}

function mailCenterOAuthAuditSafe_(targetType, targetId, actionType, beforeValue, afterValue, result, reason, actor) {
  try {
    if (typeof mailCenterAudit_ === 'function') mailCenterAudit_(targetType, targetId, actionType, beforeValue, afterValue, result, '', reason, actor);
  } catch (ignore) {}
}

function mailCenterOAuthResult_(action) {
  return {ok:false, build:MAILCENTER_OAUTH_BUILD, action:action, message:'', generatedAt:mailCenterOAuthNow_()};
}

function mailCenterOAuthCheck_(key, ok, message) {
  return {key:key, ok:!!ok, message:message};
}

function mailCenterOAuthAllRequiredOk_(checks) {
  for (var i = 0; i < checks.length; i++) {
    if ((checks[i].key === 'OAuthClientIdConfigured' || checks[i].key === 'OAuthClientSecretConfigured') && !checks[i].ok) continue;
    if (!checks[i].ok) return false;
  }
  return true;
}

function mailCenterOAuthRequire_(value, name) {
  if (value === undefined || value === null || String(value).trim() === '') throw new Error(name + ' 값이 필요합니다.');
  return String(value).trim();
}

function mailCenterOAuthActor_(sid) {
  return String(sid || 'MAILCENTER_OAUTH_SYSTEM').trim();
}

function mailCenterOAuthNow_() {
  return Utilities.formatDate(new Date(), Session.getScriptTimeZone() || 'Asia/Seoul', 'yyyy-MM-dd HH:mm:ss');
}

function mailCenterOAuthId_(prefix) {
  return prefix + '-' + Utilities.formatDate(new Date(), Session.getScriptTimeZone() || 'Asia/Seoul', 'yyyyMMddHHmmss') + '-' + Math.floor(Math.random() * 9000 + 1000);
}

function mailCenterOAuthErr_(err) {
  return err && err.message ? err.message : String(err);
}


/**
 * V02 one-click OAuth URL build.
 * Apps Script 실행창에서 매개변수 없이 실행한다.
 * - MailCenter_Accounts에서 ACTIVE 계정 1개를 자동 선택
 * - 기존 mailCenterBuildOAuthConnectUrl(sid,payload)를 호출
 * - authUrl을 Logger와 return JSON에 포함
 */
function runMailCenterOAuthBuildUrlFastV02() {
  var r = mailCenterOAuthResult_('runMailCenterOAuthBuildUrlFastV02');
  try {
    mailCenterOAuthEnsureSheet_();
    var acc = mailCenterOAuthPickActiveAccount_();
    if (!acc || !acc.mailAccountId) {
      r.ok = false;
      r.message = 'ACTIVE 상태의 MailCenter 대표메일 계정이 없습니다. 먼저 대표메일 승인까지 완료해야 OAuth URL을 만들 수 있습니다.';
      r.required = 'MailCenter_Accounts.mailAccountStatus = ACTIVE';
      Logger.log('JSON_COMPACT_RESULT: ' + JSON.stringify(r));
      return r;
    }
    var built = mailCenterBuildOAuthConnectUrl('MAILCENTER_OAUTH_V02_RUNNER', {mailAccountId: acc.mailAccountId});
    r.ok = !!(built && built.ok);
    r.message = r.ok ? 'OAuth 승인 URL 생성 완료' : (built && built.message ? built.message : 'OAuth 승인 URL 생성 실패');
    r.mailAccountId = acc.mailAccountId;
    r.vendorId = acc.vendorId || '';
    r.emailAddress = acc.emailAddress || '';
    r.oauthStatus = built && built.oauthStatus ? built.oauthStatus : '';
    r.authUrl = built && built.authUrl ? built.authUrl : '';
    r.redirectUri = built && built.redirectUri ? built.redirectUri : '';
    r.next = r.authUrl ? 'authUrl을 브라우저에 열어서 Google 승인 진행' : 'authUrl 없음 - message 확인';
  } catch (err) {
    r.ok = false;
    r.message = mailCenterOAuthErr_(err);
  }
  Logger.log('JSON_COMPACT_RESULT: ' + JSON.stringify(r));
  return r;
}

function getMailCenterOAuthNextStepFastV02() {
  var r = mailCenterOAuthResult_('getMailCenterOAuthNextStepFastV02');
  r.ok = true;
  r.message = 'OAuth V02 다음 실행 함수 안내';
  r.changedFile = 'MailCenter_OAuthConnect.js';
  r.runOnlyThis = {
    name: 'runMailCenterOAuthBuildUrlFastV02',
    file: 'MailCenter_OAuthConnect.js',
    purpose: 'ACTIVE 대표메일 1개를 자동 선택해서 Google OAuth 승인 URL 생성'
  };
  Logger.log('JSON_COMPACT_RESULT: ' + JSON.stringify(r));
  return r;
}

function mailCenterOAuthPickActiveAccount_() {
  var rows = mailCenterOAuthReadObjects_('MailCenter_Accounts', [
    'mailAccountId','vendorId','eventId','ownerType','ownerName','emailAddress','provider','mailAccountStatus','statusReason','approvalStatus','requestedBy','requestedAt','approvedBy','approvedAt','lastConnectedAt','lastSyncAt','createdAt','createdBy','updatedAt','updatedBy'
  ]);
  for (var i = 0; i < rows.length; i++) {
    var status = String(rows[i].mailAccountStatus || '').trim();
    var email = String(rows[i].emailAddress || '').trim();
    if (status === 'ACTIVE' && email) return rows[i];
  }
  return null;
}


/**
 * V03 one-click OAuth URL build for pepsi309@gmail.com.
 * Apps Script 실행창에서 이 함수 1개만 실행한다.
 * - pepsi309@gmail.com MailCenter 대표메일 계정을 준비/ACTIVE 처리
 * - 기존 169 OAuth 커넥터를 호출해서 Google OAuth 승인 URL 생성
 * - 토큰은 MailCenter 시트에 저장하지 않는다.
 */
function runMailCenterOAuthBuildUrlPepsi309FastV03() {
  var r = mailCenterOAuthResult_('runMailCenterOAuthBuildUrlPepsi309FastV03');
  try {
    mailCenterOAuthEnsureSheet_();
    var acc = mailCenterOAuthEnsurePepsi309Account_();
    var built = mailCenterBuildOAuthConnectUrl('MAILCENTER_OAUTH_V03_PEPSI309', {mailAccountId: acc.mailAccountId});
    r.ok = !!(built && built.ok);
    r.message = r.ok ? 'pepsi309@gmail.com OAuth 승인 URL 생성 완료' : (built && built.message ? built.message : 'pepsi309@gmail.com OAuth 승인 URL 생성 실패');
    r.mailAccountId = acc.mailAccountId;
    r.vendorId = acc.vendorId || '';
    r.ownerType = acc.ownerType || 'HQ';
    r.emailAddress = acc.emailAddress || 'pepsi309@gmail.com';
    r.oauthStatus = built && built.oauthStatus ? built.oauthStatus : '';
    r.authUrl = built && built.authUrl ? built.authUrl : '';
    r.redirectUri = built && built.redirectUri ? built.redirectUri : '';
    r.next = r.authUrl ? 'authUrl을 브라우저에 열어서 pepsi309@gmail.com Google 승인 진행' : 'authUrl 없음 - message 확인';
    r.changedFile = 'MailCenter_OAuthConnect.js';
  } catch (err) {
    r.ok = false;
    r.message = mailCenterOAuthErr_(err);
  }
  Logger.log('JSON_COMPACT_RESULT: ' + JSON.stringify(r));
  return r;
}

function getMailCenterOAuthNextStepFastV03() {
  var r = mailCenterOAuthResult_('getMailCenterOAuthNextStepFastV03');
  r.ok = true;
  r.message = 'OAuth V03 다음 실행 함수 안내';
  r.changedFile = 'MailCenter_OAuthConnect.js';
  r.runOnlyThis = {
    name: 'runMailCenterOAuthBuildUrlPepsi309FastV03',
    file: 'MailCenter_OAuthConnect.js',
    purpose: 'pepsi309@gmail.com 대표메일 계정을 준비하고 Google OAuth 승인 URL 생성'
  };
  Logger.log('JSON_COMPACT_RESULT: ' + JSON.stringify(r));
  return r;
}

function mailCenterOAuthEnsurePepsi309Account_() {
  var email = 'pepsi309@gmail.com';
  var now = mailCenterOAuthNow_();
  var actor = 'MAILCENTER_OAUTH_V03_PEPSI309';
  var headers = [
    'mailAccountId','vendorId','eventId','ownerType','ownerName','emailAddress','provider','mailAccountStatus','statusReason','approvalStatus','requestedBy','requestedAt','approvedBy','approvedAt','lastConnectedAt','lastSyncAt','createdAt','createdBy','updatedAt','updatedBy'
  ];
  var existing = mailCenterOAuthFindAccountByEmail_(email);
  var acc = existing || {};
  acc.mailAccountId = acc.mailAccountId || mailCenterOAuthId_('MAILACC');
  acc.vendorId = acc.vendorId || '';
  acc.eventId = acc.eventId || '';
  acc.ownerType = acc.ownerType || 'HQ';
  acc.ownerName = acc.ownerName || '이용필 개발자';
  acc.emailAddress = email;
  acc.provider = acc.provider || 'GMAIL';
  acc.mailAccountStatus = 'ACTIVE';
  acc.statusReason = 'pepsi309 Gmail OAuth 연결 진행';
  acc.approvalStatus = 'APPROVED';
  acc.requestedBy = acc.requestedBy || actor;
  acc.requestedAt = acc.requestedAt || now;
  acc.approvedBy = acc.approvedBy || actor;
  acc.approvedAt = acc.approvedAt || now;
  acc.lastConnectedAt = acc.lastConnectedAt || '';
  acc.lastSyncAt = acc.lastSyncAt || '';
  acc.createdAt = acc.createdAt || now;
  acc.createdBy = acc.createdBy || actor;
  acc.updatedAt = now;
  acc.updatedBy = actor;
  mailCenterOAuthUpsert_('MailCenter_Accounts', headers, 'mailAccountId', acc);
  mailCenterOAuthAuditSafe_('MAIL_ACCOUNT', acc.mailAccountId, existing ? 'ENSURE_PEPSI309_ACTIVE' : 'CREATE_PEPSI309_ACTIVE', '', 'ACTIVE', 'SUCCESS', 'pepsi309 Gmail OAuth 연결용 대표메일 준비', actor);
  return acc;
}

function mailCenterOAuthFindAccountByEmail_(emailAddress) {
  var headers = [
    'mailAccountId','vendorId','eventId','ownerType','ownerName','emailAddress','provider','mailAccountStatus','statusReason','approvalStatus','requestedBy','requestedAt','approvedBy','approvedAt','lastConnectedAt','lastSyncAt','createdAt','createdBy','updatedAt','updatedBy'
  ];
  var rows = mailCenterOAuthReadObjects_('MailCenter_Accounts', headers);
  var email = String(emailAddress || '').toLowerCase();
  for (var i = rows.length - 1; i >= 0; i--) {
    if (String(rows[i].emailAddress || '').toLowerCase() === email) return rows[i];
  }
  return null;
}
