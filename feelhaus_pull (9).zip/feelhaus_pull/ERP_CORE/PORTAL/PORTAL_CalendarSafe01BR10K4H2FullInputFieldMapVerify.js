function portalCalendarSafe01BR10K4H2FullInputFieldMapVerify() {
  var build = 'PORTAL_CALENDAR_SAFE01B_R10K4H2A_VERIFY_TEMPLATE_CONTEXT_FIX_20260604';
  var out = {ok:false, build:build, baseBuild:'PORTAL_CALENDAR_SAFE01B_R10K4H2_FULL_INPUT_FIELD_MAP_20260604', action:'portalCalendarSafe01BR10K4H2FullInputFieldMapVerify', safety:'READ_ONLY_RUNTIME_VERIFY_NO_SHEET_PROVIDER_WRITE', checks:{}, diagnostics:{}, warnings:[], fatal:[]};
  try {
    var tpl = HtmlService.createTemplateFromFile('MC_CalendarViewV01');
    tpl.initialJson = JSON.stringify({ok:true, status:{}, events:[], items:[], monthItems:[], user:{displayName:'verify', userId:'verify'}});
    tpl.webAppUrl = '';
    var html = tpl.evaluate().getContent();
    out.diagnostics.htmlLength = html.length;
    function has(s){ return html.indexOf(s) >= 0; }
    out.checks.viewReadable = html.length > 1000;
    out.checks.buildMarkerPresent = has(build) || has('PORTAL_CALENDAR_SAFE01B_R10K4H2_FULL_INPUT_FIELD_MAP_20260604');
    out.checks.fullInputMapReady = has('data-r10k4h2-full-input-map="1"');
    out.checks.basicSectionReady = has('id="h2-basic"') && has('제목 <span class="req">*</span>') && has('id="me_startAt"');
    out.checks.typeActivationReady = has('fhCalendarR10K4H2PickBusinessType') && has('data-h2-type-card="SELECTION_PROCESS"') && has('data-h2-type-card="EVENT_MANAGEMENT"') && has('data-h2-type-card="GENERAL_SCHEDULE"');
    out.checks.selectionFieldsReady = has('id="h2-selection"') && has('id="me_selectionComplexName"') && has('id="me_councilRepPhone"') && has('id="me_selectionProbability"') && has('id="me_conversionMemo"');
    out.checks.eventFieldsReady = has('id="h2-event"') && has('id="me_eventMasterPicker"') && has('id="me_vendorAssignStatus"') && has('id="me_boothLayoutStatus"') && has('id="me_contractCount"') && has('id="me_cancelSettlementYn"');
    out.checks.generalFieldsReady = has('id="h2-general"') && has('id="me_generalScheduleType"') && has('개인일정') && has('자율일정 입력') && has('id="me_freeScheduleMemo"');
    out.checks.meetingLedgerInputReady = has('id="h2-meeting"') && has('id="me_meetingBusinessType"') && has('id="me_meetingRecorderName"') && has('logId 기준으로 누적');
    out.checks.meetingTargetRuntimeReady = has('r10k4h2MeetingTargetText') && has('fhCalendarR10K4H2SyncBusinessPanels');
    out.checks.ownerFollowLinkReady = has('id="h2-owner"') && has('id="h2-follow"') && has('id="h2-link"');
    out.checks.signFormVendorSettlementReady = has('id="h2-ext"') && has('id="me_requestId"') && has('id="me_vendorId"') && has('id="me_settlementId"');
    out.checks.alarmRepeatAttachReady = has('id="h2-alarm"') && has('id="me_repeatType"') && has('id="me_attachmentPermission"');
    out.checks.policySaveReady = has('id="h2-policy"') && has('id="h2-sync"') && has('id="h2-save"') && has('필수값 → 형식 → 권한 → 중복 → 저장 → 로그 기록');
    out.checks.eventMasterKept = has('fhCalendarR10K2ApplyEventMasterSelection') && has('cal-r10k2-event-master-select');
    out.checks.scrollRepairKept = has('PORTAL_CALENDAR_SAFE01B_R10K4G6_MODAL_SCROLL_REPAIR_20260604') || has('#manualEventModal .manual-modal');
    out.checks.h1StackKept = has('PORTAL_CALENDAR_SAFE01B_R10K4H1_ALL_TYPE_STACK_RUNTIME_APPLY_20260604') || has('fhCalendarR10K4H1');
    out.checks.providerWriteNotAdded = html.indexOf('CalendarApp.getCalendarById') < 0 && html.indexOf('Calendar.Events.insert') < 0;
    out.checks.noSheetProviderWriteInVerify = true;
    Object.keys(out.checks).forEach(function(k){ if(!out.checks[k]) out.fatal.push(k); });
    out.ok = out.fatal.length === 0;
  } catch(e) { out.fatal.push('verifyException'); out.diagnostics.error = String(e && e.stack || e); }
  out.message = out.ok ? 'R10K4H2A full input field map verification passed.' : 'R10K4H2A full input field map verification failed.';
  Logger.log('JSON_COMPACT_RESULT: ' + JSON.stringify(out));
  return out;
}
function portalCalendarSafe01BR10K4H2InputMapVerify(){return portalCalendarSafe01BR10K4H2FullInputFieldMapVerify();}
function portalCalendarSafe01BR10K4H2Verify(){return portalCalendarSafe01BR10K4H2FullInputFieldMapVerify();}
