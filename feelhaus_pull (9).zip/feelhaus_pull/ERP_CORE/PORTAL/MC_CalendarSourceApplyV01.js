/**
 * FEELHAUS PORTAL / MailCenter Calendar Source Apply V01
 * Build: PORTAL_MC_CALENDAR_SOURCE_APPLY_V02_KO_SOURCE_20260528
 * Purpose:
 * - 승인큐에서 APPROVED 처리된 캘린더 변경건 중 APPROVED_PENDING_SOURCE_APPLY 상태를 원본 반영 후보로 조회한다.
 * - V01은 ERP_EVENT 원본 반영을 우선 지원한다.
 * - 승인된 건만 대상으로 하며, 허용 필드만 원본 시트에 반영한다.
 * - Google/Naver 실반영, 삭제/복구/clear는 수행하지 않는다.
 */
var MC_CALENDAR_SOURCE_APPLY_V01_BUILD = 'PORTAL_MC_CALENDAR_SOURCE_APPLY_V02_KO_SOURCE_20260528';

function calSrcHelp() {
  var r = mcCalSrcV01Base_('calSrcHelp');
  r.ok = true;
  r.message = '캘린더 승인건 원본반영 짧은 실행 함수 안내';
  r.runners = [
    { fn:'calSrcTest()', desc:'사전점검: 캘린더 원장/승인큐/변경로그/원본 후보 시트 확인' },
    { fn:'calSrcScan()', desc:'APPROVED_PENDING_SOURCE_APPLY 원본반영 후보 조회. 저장 없음' },
    { fn:'calSrcList()', desc:'최근 원본반영 후보 compact 목록' },
    { fn:'calSrcDry()', desc:'최근 승인 후보 1건 원본반영 DryRun. ERP 원본 수정 없음' },
    { fn:'calSrcApply()', desc:'최근 승인 후보 1건 원본반영 실행. 승인/원본행/허용필드 모두 통과 시에만 반영' }
  ];
  r.nextAction = 'calSrcTest() 실행 후 calSrcScan()을 실행하세요.';
  return mcCalSrcV01Print_(r);
}

function calSrcTest() { return mcCalendarSourceApplyV01SelfTest(); }
function calSrcScan() { return mcCalendarSourceApplyV01Scan(); }
function calSrcList() { return mcCalendarSourceApplyV01ListRecent(); }
function calSrcDry() { return mcCalendarSourceApplyV01ApplyRecentDryRun(); }
function calSrcApply() { return mcCalendarSourceApplyV01ApplyRecent(); }

function mcCalendarSourceApplyV01SelfTest() {
  var r = mcCalSrcV01Base_('mcCalendarSourceApplyV01SelfTest');
  try {
    var ss = mcCalSrcV01OpenMaster_();
    var calendar = mcCalSrcV01GetSheetOrCreate_(ss, 'MAILCENTER_CalendarEvents', mcCalSrcV01CalendarHeaders_());
    var queue = mcCalSrcV01GetSheetOrCreate_(ss, 'MAILCENTER_CalendarApprovalQueue', mcCalSrcV01QueueHeaders_());
    var logs = mcCalSrcV01GetSheetOrCreate_(ss, 'MAILCENTER_CalendarChangeLogs', mcCalSrcV01ChangeLogHeaders_());
    var ch = mcCalSrcV01HeaderMap_(calendar);
    var qh = mcCalSrcV01HeaderMap_(queue);
    var requiredCalendar = ['calendarEventId','sourceType','eventId','vendorId','customerId','title','eventTitle','startAt','endAt','sourceWritePolicy','sourceUpdateStatus','updatedAt','updatedBy'];
    var requiredQueue = ['approvalId','calendarEventId','sourceType','eventId','vendorId','customerId','approvalStatus','sourceUpdateStatus'];
    var missingCalendar = requiredCalendar.filter(function(h){ return ch[h] === undefined; });
    var missingQueue = requiredQueue.filter(function(h){ return qh[h] === undefined; });
    var sourceProbe = mcCalSrcV01FindSourceSheet_(ss, 'ERP_EVENT');
    r.ok = missingCalendar.length === 0 && missingQueue.length === 0;
    r.checks = {
      masterDbOk: !!ss,
      calendarSheetOk: !!calendar,
      approvalQueueSheetOk: !!queue,
      changeLogSheetOk: !!logs,
      missingCalendarHeaderCount: missingCalendar.length,
      missingQueueHeaderCount: missingQueue.length,
      erpEventSourceSheetFound: !!sourceProbe.sheet,
      erpEventSourceSheetName: sourceProbe.sheet ? sourceProbe.sheet.getName() : '',
      realApplyExecuted: false,
      destructiveRepairExecuted: false
    };
    r.targetSheets = [
      { sheetName: calendar.getName(), lastRow: calendar.getLastRow(), lastColumn: calendar.getLastColumn() },
      { sheetName: queue.getName(), lastRow: queue.getLastRow(), lastColumn: queue.getLastColumn() },
      { sheetName: logs.getName(), lastRow: logs.getLastRow(), lastColumn: logs.getLastColumn() }
    ];
    r.sourceSheetCandidates = mcCalSrcV01SourceSheetCandidates_('ERP_EVENT');
    r.missingCalendarHeaders = missingCalendar;
    r.missingQueueHeaders = missingQueue;
    r.message = r.ok ? '캘린더 원본반영 V01 준비 완료' : '원본반영 사전점검에서 누락 헤더가 있습니다.';
    r.nextAction = r.ok ? 'calSrcScan()으로 승인된 원본반영 후보를 조회하세요.' : 'missingHeaders를 먼저 확인하세요.';
  } catch (err) { mcCalSrcV01Catch_(r, err); }
  return mcCalSrcV01Print_(r);
}

function mcCalendarSourceApplyV01Scan() {
  var r = mcCalSrcV01Base_('mcCalendarSourceApplyV01Scan');
  try {
    var candidates = mcCalSrcV01FindApprovedCandidates_();
    r.ok = true;
    r.summary = {
      found: candidates.length,
      ready: candidates.filter(function(x){ return x.sourceReady; }).length,
      sourceMissing: candidates.filter(function(x){ return !x.sourceReady; }).length,
      realApplyExecuted: false,
      destructiveRepairExecuted: false
    };
    r.items = candidates.map(mcCalSrcV01CompactCandidate_).slice(0, 10);
    r.message = '승인된 원본반영 후보 조회 완료. 저장/원본수정은 하지 않았습니다.';
    r.nextAction = candidates.length ? 'calSrcDry()로 최근 후보 1건 적용 계획을 확인하세요.' : '승인큐에서 APPROVED_PENDING_SOURCE_APPLY 건을 먼저 생성하세요.';
  } catch (err) { mcCalSrcV01Catch_(r, err); }
  return mcCalSrcV01Print_(r);
}

function mcCalendarSourceApplyV01ListRecent() { return mcCalendarSourceApplyV01Scan(); }
function mcCalendarSourceApplyV01ApplyRecentDryRun() { return mcCalSrcV01ApplyRecent_(true); }
function mcCalendarSourceApplyV01ApplyRecent() { return mcCalSrcV01ApplyRecent_(false); }

function mcCalSrcV01ApplyRecent_(dryRun) {
  var r = mcCalSrcV01Base_(dryRun ? 'mcCalendarSourceApplyV01ApplyRecentDryRun' : 'mcCalendarSourceApplyV01ApplyRecent');
  try {
    var candidates = mcCalSrcV01FindApprovedCandidates_();
    if (!candidates.length) throw new Error('원본반영 대상이 없습니다. calSrcScan() 결과를 확인하세요.');
    var target = candidates[0];
    var plan = mcCalSrcV01BuildApplyPlan_(target);
    r.ok = plan.ok;
    r.dryRun = !!dryRun;
    r.target = mcCalSrcV01CompactCandidate_(target);
    r.plan = plan;
    r.realApplyExecuted = !dryRun && plan.ok;
    r.destructiveRepairExecuted = false;
    if (!plan.ok) {
      r.saved = false;
      r.message = '원본반영 차단: ' + plan.blockedReason;
      r.nextAction = 'sourceSheet/sourceRow/allowedFields를 확인하세요. ERP 원본은 수정되지 않았습니다.';
      return mcCalSrcV01Print_(r);
    }
    if (dryRun) {
      r.saved = false;
      r.message = 'DRY RUN: 승인된 캘린더 변경건의 ERP 원본 반영 계획만 반환했습니다.';
      r.nextAction = '계획이 맞으면 calSrcApply()를 실행하세요.';
      return mcCalSrcV01Print_(r);
    }
    mcCalSrcV01ExecuteApply_(target, plan);
    r.saved = true;
    r.message = '승인된 캘린더 변경건을 ERP 원본 허용 필드에 반영했습니다.';
    r.nextAction = 'calSrcScan() 또는 calSrcList()로 남은 후보를 확인하세요.';
  } catch (err) { mcCalSrcV01Catch_(r, err); }
  return mcCalSrcV01Print_(r);
}

function mcCalSrcV01FindApprovedCandidates_() {
  var ss = mcCalSrcV01OpenMaster_();
  var calendar = ss.getSheetByName('MAILCENTER_CalendarEvents');
  var queue = ss.getSheetByName('MAILCENTER_CalendarApprovalQueue');
  if (!calendar || !queue) return [];
  var ch = mcCalSrcV01HeaderMap_(calendar);
  var qh = mcCalSrcV01HeaderMap_(queue);
  var cRows = calendar.getDataRange().getValues();
  var qRows = queue.getDataRange().getValues();
  var queueByCalendarId = {};
  for (var q = 1; q < qRows.length; q++) {
    var qObj = mcCalSrcV01RowToObj_(qRows[q], qh, q + 1);
    var qStatus = String(qObj.approvalStatus || '').toUpperCase();
    if (qStatus !== 'APPROVED') continue;
    if (qObj.calendarEventId) queueByCalendarId[String(qObj.calendarEventId)] = qObj;
  }
  var out = [];
  for (var i = cRows.length - 1; i >= 1; i--) {
    var cObj = mcCalSrcV01RowToObj_(cRows[i], ch, i + 1);
    var calendarEventId = String(cObj.calendarEventId || '');
    if (!calendarEventId || !queueByCalendarId[calendarEventId]) continue;
    var st = String(cObj.sourceUpdateStatus || '').toUpperCase();
    var policy = String(cObj.sourceWritePolicy || '').toUpperCase();
    if (st !== 'APPROVED_PENDING_SOURCE_APPLY') continue;
    if (policy !== 'SYNC_TO_SOURCE') continue;
    var source = mcCalSrcV01ResolveSource_(cObj.sourceType, cObj.eventId, cObj);
    out.push({ calendarRow: i + 1, queueRow: queueByCalendarId[calendarEventId].rowNumber, calendar: cObj, queue: queueByCalendarId[calendarEventId], source: source, sourceReady: !!(source.sheet && source.rowNumber > 1) });
  }
  return out;
}

function mcCalSrcV01ResolveSource_(sourceType, sourceId, calendarObj) {
  var ss = mcCalSrcV01OpenMaster_();
  var type = String(sourceType || '').toUpperCase();
  var probe = mcCalSrcV01FindSourceSheet_(ss, type);
  var result = { sourceType: type, sourceSheetName: probe.sheet ? probe.sheet.getName() : '', sourceRowNumber: -1, keyField: '', keyValue: sourceId || '', sheet: probe.sheet, headerMap: probe.headerMap || {}, rowNumber: -1 };
  if (!probe.sheet) return result;
  var keyFields = type === 'ERP_EVENT' ? ['eventId','행사ID','행사Id','행사id'] : ['eventId','installId','asId','customerId','vendorId'];
  var rows = probe.sheet.getDataRange().getValues();
  for (var k = 0; k < keyFields.length; k++) {
    var key = keyFields[k];
    var val = calendarObj[key] || sourceId || '';
    if (!val || probe.headerMap[key] === undefined) continue;
    for (var i = 1; i < rows.length; i++) {
      if (String(rows[i][probe.headerMap[key]] || '') === String(val)) {
        result.sourceRowNumber = i + 1;
        result.rowNumber = i + 1;
        result.keyField = key;
        result.keyValue = val;
        return result;
      }
    }
  }
  return result;
}

function mcCalSrcV01BuildApplyPlan_(target) {
  var source = target.source;
  if (String(target.calendar.sourceType || '').toUpperCase() !== 'ERP_EVENT') {
    return { ok:false, blockedReason:'V01은 ERP_EVENT 원본반영만 허용합니다.', allowedSourceType:'ERP_EVENT', actualSourceType:target.calendar.sourceType || '' };
  }
  if (!source.sheet) {
    return { ok:false, blockedReason:'ERP_EVENT 원본 시트를 찾지 못했습니다.', sourceSheetCandidates:mcCalSrcV01SourceSheetCandidates_('ERP_EVENT') };
  }
  if (!(source.rowNumber > 1)) {
    return { ok:false, blockedReason:'ERP_EVENT 원본 행을 찾지 못했습니다.', sourceSheetName:source.sourceSheetName, keyField:source.keyField || 'eventId', keyValue:source.keyValue || target.calendar.eventId || '' };
  }
  var hm = source.headerMap;
  var maps = mcCalSrcV01AllowedFieldMappings_();
  var updates = [];
  maps.forEach(function(m){
    var val = mcCalSrcV01PickCalendarValue_(target.calendar, m.calendarFields);
    if (val === '') return;
    var targetHeader = mcCalSrcV01PickExistingHeader_(hm, m.sourceHeaders);
    if (!targetHeader) return;
    updates.push({ calendarFields:m.calendarFields, sourceHeader:targetHeader, value:val });
  });
  if (!updates.length) return { ok:false, blockedReason:'ERP 원본에 반영 가능한 허용 필드가 없습니다.', sourceSheetName:source.sourceSheetName, sourceRowNumber:source.rowNumber };
  return { ok:true, sourceType:'ERP_EVENT', sourceSheetName:source.sourceSheetName, sourceRowNumber:source.rowNumber, keyField:source.keyField, keyValue:source.keyValue, allowedUpdateCount:updates.length, updates:updates, erpSourceMutated:true, googleRealApplyExecuted:false, naverAutoApplyExecuted:false };
}

function mcCalSrcV01ExecuteApply_(target, plan) {
  var ss = mcCalSrcV01OpenMaster_();
  var calendar = ss.getSheetByName('MAILCENTER_CalendarEvents');
  var queue = ss.getSheetByName('MAILCENTER_CalendarApprovalQueue');
  var logs = mcCalSrcV01GetSheetOrCreate_(ss, 'MAILCENTER_CalendarChangeLogs', mcCalSrcV01ChangeLogHeaders_());
  var ch = mcCalSrcV01HeaderMap_(calendar);
  var qh = mcCalSrcV01HeaderMap_(queue);
  var lh = mcCalSrcV01HeaderMap_(logs);
  var sourceSheet = plan.sourceSheetName ? ss.getSheetByName(plan.sourceSheetName) : null;
  if (!sourceSheet) throw new Error('실행 직전 ERP 원본 시트를 찾지 못했습니다: ' + plan.sourceSheetName);
  var sh = mcCalSrcV01HeaderMap_(sourceSheet);
  var before = {};
  var after = {};
  plan.updates.forEach(function(u){
    var col = sh[u.sourceHeader];
    if (col === undefined) return;
    before[u.sourceHeader] = sourceSheet.getRange(plan.sourceRowNumber, col + 1).getValue();
    sourceSheet.getRange(plan.sourceRowNumber, col + 1).setValue(u.value);
    after[u.sourceHeader] = u.value;
  });
  var now = mcCalSrcV01Now_();
  var actor = mcCalSrcV01Actor_();
  ['updatedAt','updatedBy'].forEach(function(h){ if (sh[h] !== undefined) sourceSheet.getRange(plan.sourceRowNumber, sh[h] + 1).setValue(h === 'updatedAt' ? now : actor); });
  mcCalSrcV01SetCell_(calendar, ch, target.calendarRow, 'sourceUpdateStatus', 'SOURCE_APPLIED');
  mcCalSrcV01SetCell_(calendar, ch, target.calendarRow, 'statusReason', '승인된 캘린더 변경을 ERP 원본에 반영 완료');
  mcCalSrcV01SetCell_(calendar, ch, target.calendarRow, 'updatedAt', now);
  mcCalSrcV01SetCell_(calendar, ch, target.calendarRow, 'updatedBy', actor);
  mcCalSrcV01SetCell_(queue, qh, target.queueRow, 'sourceUpdateStatus', 'SOURCE_APPLIED');
  mcCalSrcV01SetCell_(queue, qh, target.queueRow, 'decisionReason', '원본 반영 완료: ' + plan.sourceSheetName + ' row ' + plan.sourceRowNumber);
  mcCalSrcV01SetCell_(queue, qh, target.queueRow, 'updatedAt', now);
  mcCalSrcV01SetCell_(queue, qh, target.queueRow, 'updatedBy', actor);
  mcCalSrcV01AppendByHeader_(logs, lh, {
    changeLogId:'MCALCHG-' + mcCalSrcV01Uuid_(),
    calendarEventId:target.calendar.calendarEventId,
    changeType:'SOURCE_APPLIED',
    changedFields:plan.updates.map(function(u){ return u.sourceHeader; }).join(','),
    beforeJson:JSON.stringify(before),
    afterJson:JSON.stringify(after),
    changeReason:'승인된 캘린더 변경을 ERP 원본에 반영',
    changedAt:now,
    changedBy:actor,
    sourceType:target.calendar.sourceType,
    sourceWritePolicy:target.calendar.sourceWritePolicy,
    sourceUpdateStatus:'SOURCE_APPLIED',
    realApplyExecuted:'N',
    destructiveRepairExecuted:'N'
  });
}

function mcCalSrcV01FindSourceSheet_(ss, sourceType) {
  var names = mcCalSrcV01SourceSheetCandidates_(sourceType);
  for (var i = 0; i < names.length; i++) {
    var sh = ss.getSheetByName(names[i]);
    if (sh) return { sheet:sh, headerMap:mcCalSrcV01HeaderMap_(sh) };
  }
  return { sheet:null, headerMap:{} };
}

function mcCalSrcV01SourceSheetCandidates_(sourceType) {
  var type = String(sourceType || '').toUpperCase();
  if (type === 'ERP_EVENT') return ['ERP_행사관리','행사관리','ERP_Events','ERP_EventMaster','ERP_Event','ERP_행사','EVENT_MASTER','EVENTS','행사'];
  if (type === 'ERP_INSTALL') return ['ERP_InstallMaster','ERP_Installs','ERP_설치관리','설치관리'];
  if (type === 'ERP_AS') return ['ERP_AsMaster','ERP_AS','ERP_AS관리','AS관리'];
  return [];
}

function mcCalSrcV01AllowedFieldMappings_() {
  return [
    { calendarFields:['eventTitle','title'], sourceHeaders:['eventTitle','title','eventName','name','행사명','행사명칭'] },
    { calendarFields:['startAt'], sourceHeaders:['startAt','eventStartAt','startDate','scheduledAt','행사시작일','시작일','시작일자'] },
    { calendarFields:['endAt'], sourceHeaders:['endAt','eventEndAt','endDate','행사종료일','종료일','종료일자'] },
    { calendarFields:['location'], sourceHeaders:['location','eventLocation','venue','eventPlace','place','장소','행사장소','행사장'] },
    { calendarFields:['ownerName'], sourceHeaders:['ownerName','managerName','manager','owner','담당자','담당','담당자명'] },
    { calendarFields:['departmentCode'], sourceHeaders:['departmentCode','department','부서','담당부서'] },
    { calendarFields:['decisionMemo'], sourceHeaders:['decisionMemo','memo','note','메모','비고'] },
    { calendarFields:['statusReason','changeReason'], sourceHeaders:['calendarStatusReason','statusReason','상태사유','메모','비고'] }
  ];
}

function mcCalSrcV01PickCalendarValue_(obj, fields) {
  for (var i = 0; i < fields.length; i++) {
    var v = obj[fields[i]];
    if (v !== undefined && v !== null && String(v) !== '') return v;
  }
  return '';
}
function mcCalSrcV01PickExistingHeader_(hm, candidates) {
  for (var i = 0; i < candidates.length; i++) if (hm[candidates[i]] !== undefined) return candidates[i];
  return '';
}
function mcCalSrcV01CompactCandidate_(x) {
  return { calendarRow:x.calendarRow, queueRow:x.queueRow, calendarEventId:x.calendar.calendarEventId || '', sourceType:x.calendar.sourceType || '', eventId:x.calendar.eventId || '', vendorId:x.calendar.vendorId || '', title:x.calendar.title || x.calendar.eventTitle || '', sourceWritePolicy:x.calendar.sourceWritePolicy || '', sourceUpdateStatus:x.calendar.sourceUpdateStatus || '', approvalStatus:x.queue.approvalStatus || '', sourceReady:x.sourceReady, sourceSheetName:x.source.sourceSheetName || '', sourceRowNumber:x.source.rowNumber || -1 };
}

function mcCalSrcV01CalendarHeaders_() { if (typeof mcCalendarOperationHubV01CalendarHeaders_ === 'function') return mcCalendarOperationHubV01CalendarHeaders_(); return ['calendarEventId','sourceType','sourceId','eventId','vendorId','customerId','title','eventTitle','startAt','endAt','location','ownerName','departmentCode','sourceWritePolicy','sourceUpdateStatus','statusReason','updatedAt','updatedBy','createdAt','createdBy']; }
function mcCalSrcV01QueueHeaders_() { return ['approvalId','calendarEventId','sourceType','sourceId','eventId','vendorId','customerId','title','requestedChangeSummary','sourceWritePolicy','sourceUpdateStatus','approvalStatus','requestedAt','requestedBy','approvedAt','approvedBy','decisionReason','createdAt','createdBy','updatedAt','updatedBy','calendarRowNumber']; }
function mcCalSrcV01ChangeLogHeaders_() { if (typeof mcCalendarOperationHubV01ChangeLogHeaders_ === 'function') return mcCalendarOperationHubV01ChangeLogHeaders_(); return ['changeLogId','calendarEventId','changeType','changedFields','beforeJson','afterJson','changeReason','changedAt','changedBy','sourceType','sourceWritePolicy','sourceUpdateStatus','realApplyExecuted','destructiveRepairExecuted']; }
function mcCalSrcV01OpenMaster_() { if (typeof mcCalendarUnifiedManualInputV01OpenMaster_ === 'function') return mcCalendarUnifiedManualInputV01OpenMaster_(); return SpreadsheetApp.getActiveSpreadsheet(); }
function mcCalSrcV01GetSheetOrCreate_(ss, name, headers) { if (typeof mcCalendarUnifiedManualInputV01GetSheetOrCreate_ === 'function') return mcCalendarUnifiedManualInputV01GetSheetOrCreate_(ss, name, headers); var sh = ss.getSheetByName(name) || ss.insertSheet(name); if (sh.getLastRow() < 1) sh.getRange(1,1,1,headers.length).setValues([headers]); return sh; }
function mcCalSrcV01HeaderMap_(sheet) { var vals = sheet.getRange(1,1,1,Math.max(sheet.getLastColumn(),1)).getValues()[0]; var m = {}; vals.forEach(function(h,i){ if (h !== '') m[String(h).trim()] = i; }); return m; }
function mcCalSrcV01RowToObj_(row, hm, rowNumber) { var o = { rowNumber:rowNumber }; Object.keys(hm).forEach(function(k){ o[k] = row[hm[k]]; }); return o; }
function mcCalSrcV01Get_(row, hm, key) { return hm[key] === undefined ? '' : row[hm[key]]; }
function mcCalSrcV01SetCell_(sheet, hm, row, key, value) { if (hm[key] !== undefined) sheet.getRange(row, hm[key] + 1).setValue(value); }
function mcCalSrcV01AppendByHeader_(sheet, hm, obj) { var width = sheet.getLastColumn(); var row = new Array(width).fill(''); Object.keys(obj).forEach(function(k){ if (hm[k] !== undefined) row[hm[k]] = obj[k]; }); sheet.appendRow(row); }
function mcCalSrcV01Actor_() { try { return Session.getActiveUser().getEmail() || 'unknown'; } catch (e) { return 'unknown'; } }
function mcCalSrcV01Now_() { return Utilities.formatDate(new Date(), 'Asia/Seoul', 'yyyy-MM-dd HH:mm:ss'); }
function mcCalSrcV01Uuid_() { return Utilities.getUuid ? Utilities.getUuid() : String(new Date().getTime()); }
function mcCalSrcV01Base_(action) { return { ok:false, build:MC_CALENDAR_SOURCE_APPLY_V01_BUILD, action:action, generatedAt:mcCalSrcV01Now_(), realApplyExecuted:false, destructiveRepairExecuted:false, warnings:[], errors:[] }; }
function mcCalSrcV01Catch_(r, err) { r.ok = false; r.message = String(err && err.message ? err.message : err); r.errors.push({ message:r.message, stack:err && err.stack ? err.stack : '' }); r.nextAction = '오류 메시지와 sourceSheet/sourceRow/approval 상태를 확인하세요.'; }
function mcCalSrcV01Print_(r) { r.endedAt = mcCalSrcV01Now_(); Logger.log('JSON_COMPACT_RESULT: ' + JSON.stringify(r)); return r; }
