/**
 * FEELHAUS PORTAL / MailCenter
 * Build: PORTAL_MC_FINAL_DEPLOY_SCREEN_CHECK_V01_20260527
 * Purpose: Final deploy screen smoke check. Read-only, no Google real apply, no repair, no clear.
 * Scope: PORTAL V06 shell, MailCenter route, Calendar route, log runners, Google real apply locked state.
 */

var MC_PORTAL_FINAL_DEPLOY_SCREEN_CHECK_V01_BUILD = 'PORTAL_MC_FINAL_DEPLOY_SCREEN_CHECK_V01_20260527';

function mcPortalFinalDeployScreenCheckV01SelfTest() {
  var result = mcPortalFinalDeployScreenCheckV01Base_('mcPortalFinalDeployScreenCheckV01SelfTest');
  result.message = 'FINAL_DEPLOY_SCREEN_CHECK V01 준비 완료';
  result.checks = {
    doGetReady: typeof doGet === 'function',
    portalRendererReady: typeof portalMenuUiRendererV06HandleGet === 'function',
    mailRouterReady: typeof mcRouterHandleGet === 'function',
    v04SelfTestReady: typeof mcGoogleCalendarApprovalLogVerboseV04SelfTest === 'function',
    v04ListRecent5Ready: typeof mcGoogleCalendarApprovalLogVerboseV04ListRecent5 === 'function',
    v04PreviewDefaultReady: typeof mcGoogleCalendarApprovalLogVerboseV04PreviewDefaultMax5 === 'function',
    v04RealApplyLockedReady: typeof mcGoogleCalendarApprovalLogVerboseV04RealApplyMax5_LOCKED === 'function'
  };
  result.ok = mcPortalFinalDeployScreenCheckV01AllTrue_(result.checks);
  result.nextAction = result.ok ? 'mcPortalFinalDeployScreenCheckV01Run() 실행' : '누락된 함수 파일을 먼저 확인하세요.';
  return mcPortalFinalDeployScreenCheckV01Finish_(result);
}

function mcPortalFinalDeployScreenCheckV01Run() {
  var result = mcPortalFinalDeployScreenCheckV01Base_('mcPortalFinalDeployScreenCheckV01Run');
  result.message = 'PORTAL / MailCenter 배포화면 최종 점검을 실행했습니다. 실제 Google 생성은 하지 않습니다.';
  result.mode = 'READONLY_SCREEN_SMOKE_NO_REAL_APPLY';
  result.routeChecks = [];
  result.functionChecks = [];
  result.policyChecks = [];

  mcPortalFinalDeployScreenCheckV01AddFunction_(result, 'doGet', typeof doGet === 'function');
  mcPortalFinalDeployScreenCheckV01AddFunction_(result, 'portalMenuUiRendererV06HandleGet', typeof portalMenuUiRendererV06HandleGet === 'function');
  mcPortalFinalDeployScreenCheckV01AddFunction_(result, 'mcRouterHandleGet', typeof mcRouterHandleGet === 'function');
  mcPortalFinalDeployScreenCheckV01AddFunction_(result, 'mcGoogleCalendarApprovalLogVerboseV04ListRecent5', typeof mcGoogleCalendarApprovalLogVerboseV04ListRecent5 === 'function');
  mcPortalFinalDeployScreenCheckV01AddFunction_(result, 'mcGoogleCalendarApprovalLogVerboseV04PreviewDefaultMax5', typeof mcGoogleCalendarApprovalLogVerboseV04PreviewDefaultMax5 === 'function');
  mcPortalFinalDeployScreenCheckV01AddFunction_(result, 'mcGoogleCalendarApprovalLogVerboseV04RealApplyMax5_LOCKED', typeof mcGoogleCalendarApprovalLogVerboseV04RealApplyMax5_LOCKED === 'function');

  if (typeof doGet === 'function') {
    mcPortalFinalDeployScreenCheckV01RouteSmoke_(result, 'portalHome', {});
    mcPortalFinalDeployScreenCheckV01RouteSmoke_(result, 'MailCenterDashboardV04', { page: 'MailCenterDashboardV04' });
    mcPortalFinalDeployScreenCheckV01RouteSmoke_(result, 'MailCenterCalendarV01', { page: 'MailCenterCalendarV01' });
    mcPortalFinalDeployScreenCheckV01RouteSmoke_(result, 'controlSettings', { page: 'controlSettings' });
  } else {
    result.errors.push({ step: 'ROUTE_SMOKE', message: 'doGet 함수가 없어 화면 라우트 점검을 생략했습니다.' });
  }

  var propValue = '';
  try {
    propValue = PropertiesService.getScriptProperties().getProperty('MC_GOOGLE_REAL_APPLY_NO_ARG_APPROVED') || '';
  } catch (propErr) {
    result.warnings.push({ step: 'SCRIPT_PROPERTIES', message: String(propErr && propErr.message ? propErr.message : propErr) });
  }
  result.policyChecks.push({
    name: 'REAL_APPLY_NO_ARG_APPROVED_PROPERTY',
    ok: propValue !== 'YES',
    expected: 'NOT YES for safe close',
    actual: propValue || '(empty)',
    message: propValue === 'YES' ? '주의: 실반영 잠금 해제 속성이 YES입니다.' : '정상: 실반영 잠금 해제 속성이 비어있거나 YES가 아닙니다.'
  });

  result.summary = mcPortalFinalDeployScreenCheckV01Summary_(result);
  result.ok = result.summary.failed === 0;
  result.nextAction = result.ok
    ? '배포화면 점검 통과. 화면에서 PORTAL 홈, 메일센터, 캘린더 진입만 확인하고 실반영은 보류하세요.'
    : 'failed 항목을 먼저 확인하세요. Google 실반영 함수는 실행하지 마세요.';
  return mcPortalFinalDeployScreenCheckV01Finish_(result);
}

function mcPortalFinalDeployScreenCheckV01RunMinimal() {
  var result = mcPortalFinalDeployScreenCheckV01Base_('mcPortalFinalDeployScreenCheckV01RunMinimal');
  result.message = '최소 배포 점검: 함수 존재와 실반영 잠금 상태만 확인했습니다.';
  result.functionChecks = [];
  result.policyChecks = [];
  mcPortalFinalDeployScreenCheckV01AddFunction_(result, 'doGet', typeof doGet === 'function');
  mcPortalFinalDeployScreenCheckV01AddFunction_(result, 'mcRouterHandleGet', typeof mcRouterHandleGet === 'function');
  mcPortalFinalDeployScreenCheckV01AddFunction_(result, 'mcGoogleCalendarApprovalLogVerboseV04RealApplyMax5_LOCKED', typeof mcGoogleCalendarApprovalLogVerboseV04RealApplyMax5_LOCKED === 'function');
  var propValue = '';
  try { propValue = PropertiesService.getScriptProperties().getProperty('MC_GOOGLE_REAL_APPLY_NO_ARG_APPROVED') || ''; } catch (e) { propValue = 'PROPERTY_READ_ERROR'; }
  result.policyChecks.push({ name: 'REAL_APPLY_UNLOCK', ok: propValue !== 'YES', actual: propValue || '(empty)' });
  result.summary = mcPortalFinalDeployScreenCheckV01Summary_(result);
  result.ok = result.summary.failed === 0;
  result.nextAction = result.ok ? 'mcPortalFinalDeployScreenCheckV01Run() 실행 가능' : 'failed 항목 확인';
  return mcPortalFinalDeployScreenCheckV01Finish_(result);
}

function mcPortalFinalDeployScreenCheckV01Guide() {
  var result = mcPortalFinalDeployScreenCheckV01Base_('mcPortalFinalDeployScreenCheckV01Guide');
  result.ok = true;
  result.message = '배포화면 수동 확인 가이드';
  result.manualChecklist = [
    'PORTAL 홈 접속: 빈페이지가 아니라 FEELHAUS 통합 운영센터가 보여야 합니다.',
    '좌측 메뉴: 커뮤니케이션 / 알림 > 메일 / 알림센터가 보여야 합니다.',
    '메일센터 진입: MailCenterDashboardV04 화면이 열려야 합니다.',
    '캘린더 진입: MailCenterCalendarV01 화면이 열려야 합니다.',
    'Google 실반영 버튼/함수는 일반 사용자가 바로 실행하지 않는 상태여야 합니다.',
    '오늘은 SystemConfig Google Sync OFF 유지 상태로 마감합니다.'
  ];
  result.nextAction = 'mcPortalFinalDeployScreenCheckV01Run() 실행';
  return mcPortalFinalDeployScreenCheckV01Finish_(result);
}

function mcPortalFinalDeployScreenCheckV01RouteSmoke_(result, name, parameter) {
  var item = { name: name, ok: false, title: '', contentLength: 0, hasFeelhaus: false, hasMailCenter: false, hasCalendar: false, error: '' };
  try {
    var out = doGet({ parameter: parameter || {} });
    if (out && typeof out.getTitle === 'function') item.title = String(out.getTitle() || '');
    var html = '';
    if (out && typeof out.getContent === 'function') html = String(out.getContent() || '');
    item.contentLength = html.length;
    item.hasFeelhaus = html.indexOf('FEELHAUS') >= 0 || html.indexOf('필하우스') >= 0;
    item.hasMailCenter = html.indexOf('MailCenter') >= 0 || html.indexOf('메일') >= 0;
    item.hasCalendar = html.indexOf('Calendar') >= 0 || html.indexOf('캘린더') >= 0;
    item.ok = item.contentLength > 200 && (item.hasFeelhaus || item.hasMailCenter || item.hasCalendar);
    if (!item.ok) item.error = 'HTML 내용이 너무 짧거나 FEELHAUS/MailCenter/Calendar 표식이 부족합니다.';
  } catch (err) {
    item.ok = false;
    item.error = String(err && err.message ? err.message : err);
  }
  result.routeChecks.push(item);
}

function mcPortalFinalDeployScreenCheckV01AddFunction_(result, name, ok) {
  result.functionChecks.push({ name: name, ok: !!ok, status: ok ? 'READY' : 'MISSING' });
}

function mcPortalFinalDeployScreenCheckV01Summary_(result) {
  var total = 0;
  var failed = 0;
  function count(list) {
    for (var i = 0; i < (list || []).length; i++) {
      total++;
      if (!list[i].ok) failed++;
    }
  }
  count(result.functionChecks);
  count(result.routeChecks);
  count(result.policyChecks);
  return {
    total: total,
    ok: total - failed,
    failed: failed,
    routeFailed: mcPortalFinalDeployScreenCheckV01FailedNames_(result.routeChecks),
    functionFailed: mcPortalFinalDeployScreenCheckV01FailedNames_(result.functionChecks),
    policyFailed: mcPortalFinalDeployScreenCheckV01FailedNames_(result.policyChecks),
    realApplyExecuted: false,
    destructiveRepairExecuted: false
  };
}

function mcPortalFinalDeployScreenCheckV01FailedNames_(list) {
  var out = [];
  for (var i = 0; i < (list || []).length; i++) if (!list[i].ok) out.push(list[i].name || list[i].step || ('index' + i));
  return out;
}

function mcPortalFinalDeployScreenCheckV01Base_(action) {
  return {
    ok: false,
    build: MC_PORTAL_FINAL_DEPLOY_SCREEN_CHECK_V01_BUILD,
    action: action,
    generatedAt: mcPortalFinalDeployScreenCheckV01Now_(),
    realApplyExecuted: false,
    destructiveRepairExecuted: false,
    warnings: [],
    errors: []
  };
}

function mcPortalFinalDeployScreenCheckV01Finish_(result) {
  result.endedAt = mcPortalFinalDeployScreenCheckV01Now_();
  Logger.log('JSON_COMPACT_RESULT: ' + JSON.stringify(result));
  return result;
}

function mcPortalFinalDeployScreenCheckV01AllTrue_(obj) {
  for (var k in obj) if (obj.hasOwnProperty(k) && !obj[k]) return false;
  return true;
}

function mcPortalFinalDeployScreenCheckV01Now_() {
  try { return Utilities.formatDate(new Date(), Session.getScriptTimeZone() || 'Asia/Seoul', 'yyyy-MM-dd HH:mm:ss'); }
  catch (e) { return new Date().toISOString(); }
}
