/**
 * PORTAL_CALENDAR_STEP08_NAVER_AUTO_REFRESH_RETRY_V07_20260601
 * NAVER Calendar token auto-refresh + one-shot retry helper.
 * Safety: no standalone execution writes NAVER calendar unless called by save/update path.
 */
var PORTAL_CALENDAR_STEP08_NAVER_AUTO_REFRESH_RETRY_V07_20260601 = 'PORTAL_CALENDAR_STEP08_NAVER_AUTO_REFRESH_RETRY_V07_20260601';

function portalCalendarStep08NaverGetSystemConfigSheetV07_() {
  var setupDbId = '17VMSpgSZCvIrUlgcw8yCNcnl8WQWo2IcRf5tDCcuJGM';
  var ss = SpreadsheetApp.openById(setupDbId);
  var sh = ss.getSheetByName('SystemConfig');
  if (!sh) throw new Error('SystemConfig sheet not found');
  return sh;
}

function portalCalendarStep08NaverReadSystemConfigV07_() {
  var sh = portalCalendarStep08NaverGetSystemConfigSheetV07_();
  var values = sh.getDataRange().getValues();
  if (!values || values.length < 2) return {};
  var headers = values[0].map(function(h){ return String(h || '').trim(); });
  var keyIdx = headers.indexOf('CONFIG_KEY');
  var valueIdx = headers.indexOf('VALUE');
  var statusIdx = headers.indexOf('status');
  if (keyIdx < 0 || valueIdx < 0) throw new Error('SystemConfig headers missing CONFIG_KEY/VALUE');
  var map = {};
  for (var r = 1; r < values.length; r++) {
    var key = String(values[r][keyIdx] || '').trim();
    if (!key) continue;
    var status = statusIdx >= 0 ? String(values[r][statusIdx] || '').trim() : 'ACTIVE';
    if (status && status !== 'ACTIVE') continue;
    map[key] = values[r][valueIdx];
  }
  return map;
}

function portalCalendarStep08NaverUpdateSystemConfigV07_(updates) {
  var sh = portalCalendarStep08NaverGetSystemConfigSheetV07_();
  var range = sh.getDataRange();
  var values = range.getValues();
  var headers = values[0].map(function(h){ return String(h || '').trim(); });
  var keyIdx = headers.indexOf('CONFIG_KEY');
  var valueIdx = headers.indexOf('VALUE');
  var updatedAtIdx = headers.indexOf('updatedAt');
  var updatedByIdx = headers.indexOf('updatedBy');
  if (keyIdx < 0 || valueIdx < 0) throw new Error('SystemConfig headers missing CONFIG_KEY/VALUE');
  var now = Utilities.formatDate(new Date(), 'Asia/Seoul', "yyyy-MM-dd HH:mm:ss");
  var found = {};
  for (var r = 1; r < values.length; r++) {
    var key = String(values[r][keyIdx] || '').trim();
    if (Object.prototype.hasOwnProperty.call(updates, key)) {
      sh.getRange(r + 1, valueIdx + 1).setValue(updates[key]);
      if (updatedAtIdx >= 0) sh.getRange(r + 1, updatedAtIdx + 1).setValue(now);
      if (updatedByIdx >= 0) sh.getRange(r + 1, updatedByIdx + 1).setValue('PORTAL_NAVER_AUTO_REFRESH_V07');
      found[key] = true;
    }
  }
  Object.keys(updates).forEach(function(key){
    if (found[key]) return;
    var row = new Array(headers.length).fill('');
    row[keyIdx] = key;
    row[valueIdx] = updates[key];
    var categoryIdx = headers.indexOf('category');
    var subIdx = headers.indexOf('subCategory');
    var scopeIdx = headers.indexOf('projectScope');
    var statusIdx = headers.indexOf('status');
    if (categoryIdx >= 0) row[categoryIdx] = 'CALENDAR';
    if (subIdx >= 0) row[subIdx] = 'NAVER';
    if (scopeIdx >= 0) row[scopeIdx] = 'PORTAL';
    if (statusIdx >= 0) row[statusIdx] = 'ACTIVE';
    if (updatedAtIdx >= 0) row[updatedAtIdx] = now;
    if (updatedByIdx >= 0) row[updatedByIdx] = 'PORTAL_NAVER_AUTO_REFRESH_V07';
    sh.appendRow(row);
  });
}

function portalCalendarStep08NaverIsExpiredOrNearV07_(expiresAt, safetySeconds) {
  if (!expiresAt) return true;
  var dt = new Date(String(expiresAt));
  if (isNaN(dt.getTime())) return true;
  return dt.getTime() <= (Date.now() + (safetySeconds || 300) * 1000);
}

function portalCalendarStep08NaverRefreshAccessTokenV07() {
  var cfg = portalCalendarStep08NaverReadSystemConfigV07_();
  var clientId = String(cfg.NAVER_CLIENT_ID || '').trim();
  var clientSecret = String(cfg.NAVER_CLIENT_SECRET || '').trim();
  var refreshToken = String(cfg.NAVER_REFRESH_TOKEN || '').trim();
  if (!clientId || !clientSecret || !refreshToken) {
    return { ok:false, refreshed:false, reason:'NAVER_REFRESH_CONFIG_MISSING', hasClientId:!!clientId, hasClientSecret:!!clientSecret, hasRefreshToken:!!refreshToken };
  }
  var url = 'https://nid.naver.com/oauth2.0/token';
  var payload = {
    grant_type: 'refresh_token',
    client_id: clientId,
    client_secret: clientSecret,
    refresh_token: refreshToken
  };
  var res = UrlFetchApp.fetch(url, { method:'post', payload: payload, muteHttpExceptions:true });
  var code = res.getResponseCode();
  var body = res.getContentText() || '';
  var json = {};
  try { json = JSON.parse(body); } catch (e) {}
  if (code < 200 || code >= 300 || !json.access_token) {
    return { ok:false, refreshed:false, reason:'NAVER_REFRESH_FAILED', responseCode:code, responseBody:body.substring(0, 1000) };
  }
  var expiresIn = Number(json.expires_in || 3600);
  var expiresAtDate = new Date(Date.now() + Math.max(60, expiresIn - 60) * 1000);
  var expiresAt = Utilities.formatDate(expiresAtDate, 'Asia/Seoul', "yyyy-MM-dd'T'HH:mm:ssXXX");
  var updates = {
    NAVER_CALENDAR_ACCESS_TOKEN: json.access_token,
    NAVER_TOKEN_EXPIRES_AT: expiresAt,
    NAVER_TOKEN_TYPE: json.token_type || 'bearer'
  };
  if (json.refresh_token) updates.NAVER_REFRESH_TOKEN = json.refresh_token;
  portalCalendarStep08NaverUpdateSystemConfigV07_(updates);
  return { ok:true, refreshed:true, responseCode:code, expiresAt:expiresAt, tokenType:updates.NAVER_TOKEN_TYPE };
}

function portalCalendarStep08NaverEnsureFreshAccessTokenV07() {
  var cfg = portalCalendarStep08NaverReadSystemConfigV07_();
  var accessToken = String(cfg.NAVER_CALENDAR_ACCESS_TOKEN || '').trim();
  var expiresAt = String(cfg.NAVER_TOKEN_EXPIRES_AT || '').trim();
  var expired = !accessToken || portalCalendarStep08NaverIsExpiredOrNearV07_(expiresAt, 300);
  if (!expired) {
    return { ok:true, refreshed:false, accessToken:accessToken, expiresAt:expiresAt };
  }
  var refresh = portalCalendarStep08NaverRefreshAccessTokenV07();
  if (!refresh.ok) return refresh;
  cfg = portalCalendarStep08NaverReadSystemConfigV07_();
  accessToken = String(cfg.NAVER_CALENDAR_ACCESS_TOKEN || '').trim();
  return { ok:!!accessToken, refreshed:true, accessToken:accessToken, expiresAt:String(cfg.NAVER_TOKEN_EXPIRES_AT || '') };
}

function portalCalendarStep08NaverFetchCreateScheduleWithRefreshRetryV07(scheduleIcalString, calendarId, trace) {
  var cfg = portalCalendarStep08NaverReadSystemConfigV07_();
  var url = String(cfg.NAVER_CALENDAR_CREATE_URL || 'https://openapi.naver.com/calendar/createSchedule.json').trim();
  var effectiveCalendarId = String(calendarId || cfg.NAVER_UPDATE_CALENDAR_ID || cfg.NAVER_NUMERIC_CALENDAR_ID || '').trim();
  if (!effectiveCalendarId) return { ok:false, reason:'NAVER_CALENDAR_ID_MISSING', trace:trace || {} };
  if (!scheduleIcalString) return { ok:false, reason:'NAVER_ICAL_STRING_MISSING', trace:trace || {} };
  var token = portalCalendarStep08NaverEnsureFreshAccessTokenV07();
  if (!token.ok) return { ok:false, reason:'NAVER_TOKEN_REFRESH_FAILED', token:token, trace:trace || {} };
  var options = {
    method:'post',
    muteHttpExceptions:true,
    headers:{ Authorization:'Bearer ' + token.accessToken },
    payload:{ calendarId: effectiveCalendarId, scheduleIcalString: scheduleIcalString }
  };
  var res = UrlFetchApp.fetch(url, options);
  var code = res.getResponseCode();
  var body = res.getContentText() || '';
  var retried = false;
  if (code === 401 || code === 403) {
    var refresh = portalCalendarStep08NaverRefreshAccessTokenV07();
    if (!refresh.ok) return { ok:false, reason:'NAVER_AUTH_FAILED_REFRESH_RETRY_BLOCKED', responseCode:code, responseBody:body.substring(0, 1500), refresh:refresh, trace:trace || {} };
    var cfg2 = portalCalendarStep08NaverReadSystemConfigV07_();
    options.headers.Authorization = 'Bearer ' + String(cfg2.NAVER_CALENDAR_ACCESS_TOKEN || '').trim();
    res = UrlFetchApp.fetch(url, options);
    code = res.getResponseCode();
    body = res.getContentText() || '';
    retried = true;
  }
  var json = {};
  try { json = JSON.parse(body); } catch (e) {}
  var rv = json.returnValue || json;
  var processType = String(rv.processType || '').toLowerCase();
  return {
    ok: code >= 200 && code < 300,
    responseCode: code,
    retried: retried,
    processType: processType,
    icalUid: rv.icalUid || rv.uid || '',
    calendarId: rv.calendarId || effectiveCalendarId,
    responseBody: body.substring(0, 2000),
    officialCreateScheduleMode: true,
    trace: trace || {}
  };
}

function portalCalendarStep08NaverRuntimeDiagnoseRefreshV07() {
  var before = portalCalendarStep08NaverReadSystemConfigV07_();
  var ensured = portalCalendarStep08NaverEnsureFreshAccessTokenV07();
  var after = portalCalendarStep08NaverReadSystemConfigV07_();
  var result = {
    ok: !!ensured.ok,
    build: PORTAL_CALENDAR_STEP08_NAVER_AUTO_REFRESH_RETRY_V07_20260601,
    action: 'portalCalendarStep08NaverRuntimeDiagnoseRefreshV07',
    safety: 'TOKEN_REFRESH_ONLY_NO_NAVER_CALENDAR_WRITE',
    before: { expiresAt: before.NAVER_TOKEN_EXPIRES_AT || '', accessTokenExists: !!before.NAVER_CALENDAR_ACCESS_TOKEN, refreshTokenExists: !!before.NAVER_REFRESH_TOKEN },
    ensured: ensured,
    after: { expiresAt: after.NAVER_TOKEN_EXPIRES_AT || '', accessTokenExists: !!after.NAVER_CALENDAR_ACCESS_TOKEN, refreshTokenExists: !!after.NAVER_REFRESH_TOKEN }
  };
  Logger.log('JSON_COMPACT_RESULT: ' + JSON.stringify(result));
  return result;
}
