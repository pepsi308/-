/**
 * FEELHAUS PORTAL / MailCenter Calendar Participant Manager V01
 * Build: PORTAL_MC_CALENDAR_PARTICIPANT_MANAGER_V01_20260528
 * Purpose: 담당자/참여자/외부 참석자 관리, 변경 이력 기록, 담당자/부서별 조회
 * Safety: No ERP source mutation, no Google/Naver real apply, no delete/clear/repair.
 */
var MC_CAL_PART_V01_BUILD = 'PORTAL_MC_CALENDAR_PARTICIPANT_MANAGER_V01_20260528';
var MC_CAL_PART_V01_SETUP_DB_ID = '17VMSpgSZCvIrUlgcw8yCNcnl8WQWo2IcRf5tDCcuJGM';
var MC_CAL_PART_V01_CONFIG_SHEET = 'SystemConfig';
var MC_CAL_PART_V01_CALENDAR_SHEET = 'MAILCENTER_CalendarEvents';
var MC_CAL_PART_V01_CHANGE_LOG_SHEET = 'MAILCENTER_CalendarChangeLogs';

function calPartHelp() {
  return mcCalPartV01Print_({
    ok: true,
    build: MC_CAL_PART_V01_BUILD,
    action: 'calPartHelp',
    generatedAt: mcCalPartV01Now_(),
    realApplyExecuted: false,
    destructiveRepairExecuted: false,
    message: '캘린더 담당자/참여자 관리 V01 짧은 실행 함수 안내',
    fileName: 'PORTAL/MC_CalendarParticipantManagerV01.js',
    runners: [
      { fn: 'calPartTest()', desc: '사전점검: 시트/헤더/최근 일정 확인' },
      { fn: 'calPartList()', desc: '최근 담당자/참여자 일정 5건 조회' },
      { fn: 'calPartCheck()', desc: '최근 일정의 담당자/참여자 상세 확인' },
      { fn: 'calPartOwner()', desc: '최근 일정 담당자/부서 샘플 변경' },
      { fn: 'calPartAdd()', desc: '최근 일정에 참여 담당자 샘플 추가' },
      { fn: 'calPartRemove()', desc: '최근 일정에서 참여 담당자 샘플 제거' },
      { fn: 'calPartDept()', desc: '부서별 일정 요약 조회' }
    ],
    safety: ['ERP 원본 수정 없음', 'Google/Naver 실반영 없음', '행 삭제 없음', 'ChangeLogs 기록']
  });
}

function calPartTest() { return mcCalPartV01SelfTest_(); }
function calPartList() { return mcCalPartV01ListRecent_(5); }
function calPartCheck() { return mcCalPartV01CheckRecent_(); }
function calPartOwner() { return mcCalPartV01UpdateOwnerSample_(); }
function calPartAdd() { return mcCalPartV01AddParticipantSample_(); }
function calPartRemove() { return mcCalPartV01RemoveParticipantSample_(); }
function calPartDept() { return mcCalPartV01ListByDepartment_('OPERATION', 10); }

function mcCalPartV01SelfTest_() {
  var startedAt = mcCalPartV01Now_();
  var warnings = [];
  var errors = [];
  try {
    var ss = mcCalPartV01OpenMaster_();
    var cal = mcCalPartV01EnsureSheet_(ss, MC_CAL_PART_V01_CALENDAR_SHEET, mcCalPartV01CalendarHeaders_());
    var log = mcCalPartV01EnsureSheet_(ss, MC_CAL_PART_V01_CHANGE_LOG_SHEET, mcCalPartV01ChangeLogHeaders_());
    var calMap = mcCalPartV01HeaderMap_(cal);
    var logMap = mcCalPartV01HeaderMap_(log);
    var missingCal = mcCalPartV01MissingHeaders_(calMap, mcCalPartV01CalendarHeaders_());
    var missingLog = mcCalPartV01MissingHeaders_(logMap, mcCalPartV01ChangeLogHeaders_());
    var recent = mcCalPartV01FindRecentTarget_(cal, calMap);
    return mcCalPartV01Print_({
      ok: missingCal.length === 0 && missingLog.length === 0,
      build: MC_CAL_PART_V01_BUILD,
      action: 'calPartTest',
      generatedAt: startedAt,
      endedAt: mcCalPartV01Now_(),
      realApplyExecuted: false,
      destructiveRepairExecuted: false,
      warnings: warnings,
      errors: errors,
      message: '담당자/참여자 관리 V01 사전점검 완료',
      targetSheets: [
        { sheetName: cal.getName(), lastRow: cal.getLastRow(), lastColumn: cal.getLastColumn() },
        { sheetName: log.getName(), lastRow: log.getLastRow(), lastColumn: log.getLastColumn() }
      ],
      missingCalendarHeaders: missingCal,
      missingChangeLogHeaders: missingLog,
      recentTarget: recent ? mcCalPartV01Compact_(recent.record) : null,
      nextAction: 'calPartList() 실행 후 calPartOwner()/calPartAdd()/calPartRemove()를 순서대로 확인하세요.'
    });
  } catch (err) {
    return mcCalPartV01Error_('calPartTest', startedAt, err);
  }
}

function mcCalPartV01ListRecent_(limit) {
  var startedAt = mcCalPartV01Now_();
  try {
    var ss = mcCalPartV01OpenMaster_();
    var cal = mcCalPartV01EnsureSheet_(ss, MC_CAL_PART_V01_CALENDAR_SHEET, mcCalPartV01CalendarHeaders_());
    var map = mcCalPartV01HeaderMap_(cal);
    var rows = mcCalPartV01Rows_(cal, map);
    rows.sort(function(a, b) { return b.rowNumber - a.rowNumber; });
    var out = [];
    for (var i = 0; i < rows.length && out.length < (limit || 5); i++) {
      if (!rows[i].record.calendarEventId) continue;
      out.push(mcCalPartV01Compact_(rows[i].record, rows[i].rowNumber));
    }
    return mcCalPartV01Print_({
      ok: true,
      build: MC_CAL_PART_V01_BUILD,
      action: 'calPartList',
      generatedAt: startedAt,
      endedAt: mcCalPartV01Now_(),
      realApplyExecuted: false,
      destructiveRepairExecuted: false,
      message: '최근 담당자/참여자 일정 조회 완료',
      summary: { displayed: out.length, sheetLastRow: cal.getLastRow() },
      recentEvents: out,
      nextAction: '상세 확인은 calPartCheck(), 담당자 변경은 calPartOwner() 실행'
    });
  } catch (err) {
    return mcCalPartV01Error_('calPartList', startedAt, err);
  }
}

function mcCalPartV01CheckRecent_() {
  var startedAt = mcCalPartV01Now_();
  try {
    var ctx = mcCalPartV01GetRecentContext_();
    var rec = ctx.target.record;
    return mcCalPartV01Print_({
      ok: true,
      build: MC_CAL_PART_V01_BUILD,
      action: 'calPartCheck',
      generatedAt: startedAt,
      endedAt: mcCalPartV01Now_(),
      realApplyExecuted: false,
      destructiveRepairExecuted: false,
      message: '최근 일정 담당자/참여자 상세 확인 완료',
      rowNumber: ctx.target.rowNumber,
      detail: {
        calendarEventId: rec.calendarEventId || '',
        sourceType: rec.sourceType || '',
        title: rec.title || rec.eventTitle || '',
        ownerUserId: rec.ownerUserId || '',
        ownerName: rec.ownerName || rec.createdBy || '',
        departmentCode: rec.departmentCode || '',
        organizerRole: rec.organizerRole || '',
        participantJson: rec.participantJson || '',
        participants: mcCalPartV01ParseList_(rec.participantJson),
        externalPartyJson: rec.externalPartyJson || '',
        externalParties: mcCalPartV01ParseList_(rec.externalPartyJson),
        councilName: rec.councilName || '',
        fairName: rec.fairName || '',
        sourceWritePolicy: rec.sourceWritePolicy || '',
        sourceUpdateStatus: rec.sourceUpdateStatus || '',
        updatedAt: rec.updatedAt || ''
      },
      nextAction: '담당자 변경은 calPartOwner(), 참여자 추가는 calPartAdd() 실행'
    });
  } catch (err) {
    return mcCalPartV01Error_('calPartCheck', startedAt, err);
  }
}

function mcCalPartV01UpdateOwnerSample_() {
  var startedAt = mcCalPartV01Now_();
  try {
    var ctx = mcCalPartV01GetRecentContext_();
    var before = mcCalPartV01Clone_(ctx.target.record);
    var updates = {
      ownerUserId: 'USER-OPS-001',
      ownerName: '이용필 총괄',
      departmentCode: 'OPERATION',
      organizerRole: '총괄/운영책임',
      statusReason: '담당자 관리 V01: 담당자/부서 표준화 테스트',
      changeReason: '담당자 관리 V01 담당자 변경 테스트',
      updatedAt: mcCalPartV01Now_(),
      updatedBy: mcCalPartV01Actor_()
    };
    var changed = mcCalPartV01ApplyUpdates_(ctx.sheet, ctx.map, ctx.target.rowNumber, updates);
    mcCalPartV01AppendChangeLog_(ctx.ss, before, mcCalPartV01ReadRow_(ctx.sheet, ctx.map, ctx.target.rowNumber), changed, 'OWNER_UPDATE', updates.changeReason);
    return mcCalPartV01Print_({
      ok: true,
      build: MC_CAL_PART_V01_BUILD,
      action: 'calPartOwner',
      generatedAt: startedAt,
      endedAt: mcCalPartV01Now_(),
      realApplyExecuted: false,
      destructiveRepairExecuted: false,
      saved: true,
      message: '최근 일정 담당자/부서 정보를 수정하고 변경 이력을 기록했습니다.',
      calendarEventId: before.calendarEventId || '',
      changedFields: changed,
      owner: { ownerUserId: updates.ownerUserId, ownerName: updates.ownerName, departmentCode: updates.departmentCode, organizerRole: updates.organizerRole },
      nextAction: '참여자 추가는 calPartAdd(), 상세 확인은 calPartCheck()'
    });
  } catch (err) {
    return mcCalPartV01Error_('calPartOwner', startedAt, err);
  }
}

function mcCalPartV01AddParticipantSample_() {
  var startedAt = mcCalPartV01Now_();
  try {
    var ctx = mcCalPartV01GetRecentContext_();
    var before = mcCalPartV01Clone_(ctx.target.record);
    var participants = mcCalPartV01ParseList_(before.participantJson);
    var sample = { userId: 'USER-YURA-001', name: '최유라', role: '운영지원', departmentCode: 'OPERATION', email: '', phone: '', source: 'CAL_PART_V01_SAMPLE' };
    participants = mcCalPartV01UpsertByKey_(participants, sample, 'userId');
    var updates = {
      participantJson: JSON.stringify(participants),
      statusReason: '담당자 관리 V01: 참여 담당자 추가 테스트',
      changeReason: '참여 담당자 추가',
      updatedAt: mcCalPartV01Now_(),
      updatedBy: mcCalPartV01Actor_()
    };
    var changed = mcCalPartV01ApplyUpdates_(ctx.sheet, ctx.map, ctx.target.rowNumber, updates);
    mcCalPartV01AppendChangeLog_(ctx.ss, before, mcCalPartV01ReadRow_(ctx.sheet, ctx.map, ctx.target.rowNumber), changed, 'PARTICIPANT_ADD', updates.changeReason);
    return mcCalPartV01Print_({
      ok: true,
      build: MC_CAL_PART_V01_BUILD,
      action: 'calPartAdd',
      generatedAt: startedAt,
      endedAt: mcCalPartV01Now_(),
      realApplyExecuted: false,
      destructiveRepairExecuted: false,
      saved: true,
      message: '최근 일정에 참여 담당자 샘플을 추가했습니다.',
      calendarEventId: before.calendarEventId || '',
      participantCount: participants.length,
      participants: participants,
      changedFields: changed,
      nextAction: '참여자 제거 테스트는 calPartRemove(), 상세 확인은 calPartCheck()'
    });
  } catch (err) {
    return mcCalPartV01Error_('calPartAdd', startedAt, err);
  }
}

function mcCalPartV01RemoveParticipantSample_() {
  var startedAt = mcCalPartV01Now_();
  try {
    var ctx = mcCalPartV01GetRecentContext_();
    var before = mcCalPartV01Clone_(ctx.target.record);
    var participants = mcCalPartV01ParseList_(before.participantJson);
    var afterList = [];
    for (var i = 0; i < participants.length; i++) {
      if (String(participants[i].userId || '') !== 'USER-YURA-001') afterList.push(participants[i]);
    }
    var updates = {
      participantJson: JSON.stringify(afterList),
      statusReason: '담당자 관리 V01: 참여 담당자 제거 테스트',
      changeReason: '참여 담당자 제거',
      updatedAt: mcCalPartV01Now_(),
      updatedBy: mcCalPartV01Actor_()
    };
    var changed = mcCalPartV01ApplyUpdates_(ctx.sheet, ctx.map, ctx.target.rowNumber, updates);
    mcCalPartV01AppendChangeLog_(ctx.ss, before, mcCalPartV01ReadRow_(ctx.sheet, ctx.map, ctx.target.rowNumber), changed, 'PARTICIPANT_REMOVE', updates.changeReason);
    return mcCalPartV01Print_({
      ok: true,
      build: MC_CAL_PART_V01_BUILD,
      action: 'calPartRemove',
      generatedAt: startedAt,
      endedAt: mcCalPartV01Now_(),
      realApplyExecuted: false,
      destructiveRepairExecuted: false,
      saved: true,
      message: '최근 일정에서 참여 담당자 샘플을 제거했습니다.',
      calendarEventId: before.calendarEventId || '',
      beforeCount: participants.length,
      afterCount: afterList.length,
      participants: afterList,
      changedFields: changed,
      nextAction: '상세 확인은 calPartCheck()'
    });
  } catch (err) {
    return mcCalPartV01Error_('calPartRemove', startedAt, err);
  }
}

function mcCalPartV01ListByDepartment_(departmentCode, limit) {
  var startedAt = mcCalPartV01Now_();
  try {
    var ss = mcCalPartV01OpenMaster_();
    var cal = mcCalPartV01EnsureSheet_(ss, MC_CAL_PART_V01_CALENDAR_SHEET, mcCalPartV01CalendarHeaders_());
    var map = mcCalPartV01HeaderMap_(cal);
    var rows = mcCalPartV01Rows_(cal, map);
    rows.sort(function(a, b) { return b.rowNumber - a.rowNumber; });
    var out = [];
    for (var i = 0; i < rows.length && out.length < (limit || 10); i++) {
      var rec = rows[i].record;
      if (String(rec.departmentCode || '') === String(departmentCode || '')) out.push(mcCalPartV01Compact_(rec, rows[i].rowNumber));
    }
    return mcCalPartV01Print_({
      ok: true,
      build: MC_CAL_PART_V01_BUILD,
      action: 'calPartDept',
      generatedAt: startedAt,
      endedAt: mcCalPartV01Now_(),
      realApplyExecuted: false,
      destructiveRepairExecuted: false,
      message: '부서별 운영 일정 조회 완료',
      filters: { departmentCode: departmentCode || '', limit: limit || 10 },
      summary: { displayed: out.length },
      events: out,
      nextAction: '담당자별/부서별 필터 UI는 다음 화면 고도화 단계에서 연결'
    });
  } catch (err) {
    return mcCalPartV01Error_('calPartDept', startedAt, err);
  }
}

function mcCalPartV01GetRecentContext_() {
  var ss = mcCalPartV01OpenMaster_();
  var cal = mcCalPartV01EnsureSheet_(ss, MC_CAL_PART_V01_CALENDAR_SHEET, mcCalPartV01CalendarHeaders_());
  var map = mcCalPartV01HeaderMap_(cal);
  var target = mcCalPartV01FindRecentTarget_(cal, map);
  if (!target) throw new Error('담당자/참여자 테스트 대상 일정이 없습니다. 먼저 운영 캘린더 일정을 저장하세요.');
  return { ss: ss, sheet: cal, map: map, target: target };
}

function mcCalPartV01FindRecentTarget_(sheet, map) {
  var rows = mcCalPartV01Rows_(sheet, map);
  for (var i = rows.length - 1; i >= 0; i--) {
    var rec = rows[i].record;
    if (!rec.calendarEventId) continue;
    if (String(rec.sourceUpdateStatus || '') === 'SOURCE_MISSING_CLOSED') continue;
    return rows[i];
  }
  return null;
}

function mcCalPartV01CalendarHeaders_() {
  return ['calendarEventId','sourceType','sourceModule','sourceId','calendarType','eventId','vendorId','customerId','saleId','contractId','installId','asId','documentId','mailRecordId','scheduleId','googleEventId','naverEventId','title','eventTitle','description','eventDescription','startAt','endAt','allDay','timezone','location','meetingUrl','attendeesJson','organizerEmail','ownerName','categoryCode','customTypeName','colorTag','priority','visibility','privacyLevel','busyStatus','repeatType','repeatRule','repeatUntil','repeatCount','reminderEnabled','remindersJson','attachmentIds','eventStatus','status','statusReason','syncTarget','googleSyncStatus','naverSyncStatus','lastSyncAt','locked','createdAt','createdBy','updatedAt','updatedBy','eventGroupType','operationType','ownerUserId','departmentCode','participantJson','externalPartyJson','decisionMemo','todoJson','agendaJson','presentationType','meetingMethod','relatedEventId','relatedVendorId','relatedCustomerId','relatedSaleId','relatedContractId','relatedInstallId','relatedAsId','sourceWritePolicy','sourceUpdateStatus','changeReason','lastChangedFields','organizerRole','councilName','fairName','boothZone','meetingPurpose','preparationItems','resultSummary','nextFollowUpAt'];
}

function mcCalPartV01ChangeLogHeaders_() {
  return ['changeLogId','calendarEventId','sourceType','sourceId','changeType','changedFields','beforeJson','afterJson','changeReason','changedAt','changedBy','approvalId','realApplyExecuted','destructiveRepairExecuted'];
}

function mcCalPartV01OpenMaster_() {
  var masterId = '';
  try {
    var setup = SpreadsheetApp.openById(MC_CAL_PART_V01_SETUP_DB_ID);
    var cfg = setup.getSheetByName(MC_CAL_PART_V01_CONFIG_SHEET);
    if (cfg) {
      var vals = cfg.getDataRange().getValues();
      for (var i = 0; i < vals.length; i++) {
        var k = String(vals[i][0] || '').trim();
        var v = String(vals[i][1] || '').trim();
        if (['FEELHAUS_DB_MASTER','FEELHAUS_DB_MASTER_ID','MASTER_DB_ID','MASTER_DB'].indexOf(k) >= 0 && v) {
          masterId = v;
          break;
        }
      }
    }
  } catch (ignore) {}
  if (masterId) {
    try { return SpreadsheetApp.openById(masterId); } catch (ignore2) {}
  }
  return SpreadsheetApp.getActiveSpreadsheet();
}

function mcCalPartV01EnsureSheet_(ss, name, headers) {
  var sh = ss.getSheetByName(name);
  if (!sh) sh = ss.insertSheet(name);
  if (sh.getLastRow() < 1) sh.getRange(1, 1, 1, headers.length).setValues([headers]);
  var map = mcCalPartV01HeaderMap_(sh);
  var missing = mcCalPartV01MissingHeaders_(map, headers);
  if (missing.length) {
    var startCol = sh.getLastColumn() + 1;
    sh.getRange(1, startCol, 1, missing.length).setValues([missing]);
  }
  return sh;
}

function mcCalPartV01HeaderMap_(sheet) {
  var lastCol = Math.max(sheet.getLastColumn(), 1);
  var headers = sheet.getRange(1, 1, 1, lastCol).getValues()[0];
  var map = {};
  for (var i = 0; i < headers.length; i++) {
    var h = String(headers[i] || '').trim();
    if (h) map[h] = i + 1;
  }
  return map;
}

function mcCalPartV01MissingHeaders_(map, headers) {
  var out = [];
  for (var i = 0; i < headers.length; i++) if (!map[headers[i]]) out.push(headers[i]);
  return out;
}

function mcCalPartV01Rows_(sheet, map) {
  var lastRow = sheet.getLastRow();
  var lastCol = sheet.getLastColumn();
  if (lastRow < 2) return [];
  var values = sheet.getRange(2, 1, lastRow - 1, lastCol).getValues();
  var headers = sheet.getRange(1, 1, 1, lastCol).getValues()[0];
  var out = [];
  for (var r = 0; r < values.length; r++) {
    var rec = {};
    for (var c = 0; c < headers.length; c++) {
      var h = String(headers[c] || '').trim();
      if (h) rec[h] = values[r][c];
    }
    out.push({ rowNumber: r + 2, record: rec });
  }
  return out;
}

function mcCalPartV01ReadRow_(sheet, map, rowNumber) {
  var lastCol = sheet.getLastColumn();
  var vals = sheet.getRange(rowNumber, 1, 1, lastCol).getValues()[0];
  var headers = sheet.getRange(1, 1, 1, lastCol).getValues()[0];
  var rec = {};
  for (var i = 0; i < headers.length; i++) {
    var h = String(headers[i] || '').trim();
    if (h) rec[h] = vals[i];
  }
  return rec;
}

function mcCalPartV01ApplyUpdates_(sheet, map, rowNumber, updates) {
  var changed = [];
  for (var key in updates) {
    if (!updates.hasOwnProperty(key)) continue;
    if (!map[key]) continue;
    sheet.getRange(rowNumber, map[key]).setValue(updates[key]);
    changed.push(key);
  }
  if (map.lastChangedFields) sheet.getRange(rowNumber, map.lastChangedFields).setValue(changed.join(','));
  return changed;
}

function mcCalPartV01AppendChangeLog_(ss, before, after, changedFields, changeType, reason) {
  var sh = mcCalPartV01EnsureSheet_(ss, MC_CAL_PART_V01_CHANGE_LOG_SHEET, mcCalPartV01ChangeLogHeaders_());
  var map = mcCalPartV01HeaderMap_(sh);
  var row = [];
  var headers = sh.getRange(1, 1, 1, sh.getLastColumn()).getValues()[0];
  var rec = {
    changeLogId: 'MCALPART-' + Utilities.getUuid(),
    calendarEventId: after.calendarEventId || before.calendarEventId || '',
    sourceType: after.sourceType || before.sourceType || '',
    sourceId: after.sourceId || before.sourceId || '',
    changeType: changeType || 'PARTICIPANT_CHANGE',
    changedFields: (changedFields || []).join(','),
    beforeJson: JSON.stringify(mcCalPartV01CompactForLog_(before)),
    afterJson: JSON.stringify(mcCalPartV01CompactForLog_(after)),
    changeReason: reason || '',
    changedAt: mcCalPartV01Now_(),
    changedBy: mcCalPartV01Actor_(),
    approvalId: '',
    realApplyExecuted: false,
    destructiveRepairExecuted: false
  };
  for (var i = 0; i < headers.length; i++) row.push(rec[String(headers[i] || '').trim()] || '');
  sh.appendRow(row);
}

function mcCalPartV01Compact_(rec, rowNumber) {
  return {
    rowNumber: rowNumber || '',
    calendarEventId: rec.calendarEventId || '',
    sourceType: rec.sourceType || '',
    title: rec.title || rec.eventTitle || '',
    startAt: rec.startAt || '',
    endAt: rec.endAt || '',
    ownerUserId: rec.ownerUserId || '',
    ownerName: rec.ownerName || rec.createdBy || '',
    departmentCode: rec.departmentCode || '',
    participantCount: mcCalPartV01ParseList_(rec.participantJson).length,
    externalPartyCount: mcCalPartV01ParseList_(rec.externalPartyJson).length,
    sourceWritePolicy: rec.sourceWritePolicy || '',
    sourceUpdateStatus: rec.sourceUpdateStatus || ''
  };
}

function mcCalPartV01CompactForLog_(rec) {
  return {
    calendarEventId: rec.calendarEventId || '',
    title: rec.title || rec.eventTitle || '',
    ownerUserId: rec.ownerUserId || '',
    ownerName: rec.ownerName || '',
    departmentCode: rec.departmentCode || '',
    participantJson: rec.participantJson || '',
    externalPartyJson: rec.externalPartyJson || '',
    updatedAt: rec.updatedAt || '',
    updatedBy: rec.updatedBy || ''
  };
}

function mcCalPartV01ParseList_(value) {
  if (!value) return [];
  if (Object.prototype.toString.call(value) === '[object Array]') return value;
  try {
    var parsed = JSON.parse(String(value));
    if (Object.prototype.toString.call(parsed) === '[object Array]') return parsed;
    return [parsed];
  } catch (e) {
    return String(value).split(',').map(function(t, idx) { return { index: idx + 1, text: String(t || '').trim() }; }).filter(function(x) { return x.text; });
  }
}

function mcCalPartV01UpsertByKey_(arr, item, key) {
  var out = [];
  var found = false;
  for (var i = 0; i < arr.length; i++) {
    if (String(arr[i][key] || '') === String(item[key] || '')) {
      out.push(item);
      found = true;
    } else out.push(arr[i]);
  }
  if (!found) out.push(item);
  return out;
}

function mcCalPartV01Clone_(obj) {
  return JSON.parse(JSON.stringify(obj || {}));
}

function mcCalPartV01Actor_() {
  try { return Session.getActiveUser().getEmail() || 'system'; } catch (e) { return 'system'; }
}

function mcCalPartV01Now_() {
  return Utilities.formatDate(new Date(), 'Asia/Seoul', 'yyyy-MM-dd HH:mm:ss');
}

function mcCalPartV01Print_(result) {
  Logger.log('JSON_COMPACT_RESULT: ' + JSON.stringify(result));
  return result;
}

function mcCalPartV01Error_(action, startedAt, err) {
  var result = {
    ok: false,
    build: MC_CAL_PART_V01_BUILD,
    action: action,
    generatedAt: startedAt || mcCalPartV01Now_(),
    endedAt: mcCalPartV01Now_(),
    realApplyExecuted: false,
    destructiveRepairExecuted: false,
    warnings: [],
    errors: [{ message: err && err.message ? err.message : String(err), stack: err && err.stack ? err.stack : '' }],
    message: String(err && err.message ? err.message : err),
    nextAction: '오류 메시지와 대상 시트/헤더를 확인하세요.'
  };
  Logger.log('JSON_COMPACT_RESULT: ' + JSON.stringify(result));
  return result;
}
