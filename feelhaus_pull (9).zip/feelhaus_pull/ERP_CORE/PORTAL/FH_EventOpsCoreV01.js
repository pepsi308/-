/**
 * FEELHAUS Event Ops Core V01
 * Build: EVENT_CENTER_FAST_STABILIZE_V01_READONLY_LOCK_20260523
 * Purpose:
 * - Legacy FH_EventOpsV01 write/schema auto-create route is locked.
 * - No ERP_Events / CalendarEvents / EventRentalRequests sheet creation.
 * - EVENT_CENTER must use ERP_행사관리 / ERP_업체관리 / ERP_행사업체연결 after mapping.
 */

var FH_EVENT_OPS_CORE_V01_BUILD = 'EVENT_CENTER_FAST_STABILIZE_V01_READONLY_LOCK_20260523';

var FH_EVENT_OPS_V01_SHEETS = {
  events: {
    name: 'ERP_Events',
    headers: ['eventId','eventName','eventType','eventStatus','eventStartDate','eventEndDate','eventLocation','eventAddress','operationStartTime','operationEndTime','primaryManagerId','primaryManagerName','siteManagerId','siteManagerName','memo','createdAt','createdBy','updatedAt','updatedBy']
  },
  calendar: {
    name: 'CalendarEvents',
    headers: ['calendarId','calendarType','customTypeName','sourceModule','sourceId','title','description','startAt','endAt','allDay','location','status','priority','visibility','ownerId','ownerName','attendees','eventId','vendorId','customerId','saleId','contractId','installId','asId','settlementId','documentId','requestId','approvalId','reportId','rentalId','setupItemId','mailGroupId','threadId','messageId','recordId','createdAt','createdBy','updatedAt','updatedBy']
  },
  rentals: {
    name: 'EventRentalRequests',
    headers: ['rentalId','eventId','rentalName','rentalStatus','approvalStatus','venueName','venueAddress','requestStartDate','requestEndDate','useStartAt','useEndAt','setupStartAt','dismantleEndAt','totalFee','paymentDueDate','paymentStatus','paidAt','refundAmount','refundStatus','postStartAt','postEndAt','restoreCheckAt','memo','createdAt','createdBy','updatedAt','updatedBy']
  },
  staff: {
    name: 'EventStaffAssignments',
    headers: ['assignmentId','eventId','calendarId','staffId','staffName','staffRole','staffType','workDate','startAt','endAt','location','taskMemo','status','isPrimary','isRequired','createdAt','createdBy','updatedAt','updatedBy']
  },
  setup: {
    name: 'EventSetupItems',
    headers: ['setupItemId','eventId','category','itemName','itemType','requiredQty','confirmedQty','unit','vendorId','vendorName','ownerId','ownerName','dueDate','setupAt','removeAt','status','cost','isRequired','riskLevel','memo','createdAt','createdBy','updatedAt','updatedBy']
  },
  setupVendors: {
    name: 'EventSetupVendors',
    headers: ['setupVendorId','eventId','vendorId','vendorName','vendorType','serviceType','contactName','contactPhone','contractStatus','workStartAt','workEndAt','cost','paymentStatus','documentId','status','memo','createdAt','createdBy','updatedAt','updatedBy']
  },
  logs: {
    name: 'AuditLogs',
    headers: ['logId','eventId','calendarId','rentalId','assignmentId','setupItemId','actionType','beforeValue','afterValue','reason','createdAt','createdBy']
  }
};

function fhEventOpsV01EnsureSchema(payload) {
  var result = {
    ok: true,
    locked: true,
    build: FH_EVENT_OPS_CORE_V01_BUILD,
    action: 'fhEventOpsV01EnsureSchema',
    generatedAt: fhEventOpsV01Now_(),
    sheets: [],
    message: 'EVENT_CENTER_FAST_STABILIZE_V01 기준: FH_EventOpsV01 신규 시트 자동 생성은 차단되었습니다.'
  };
  try {
    var ss = fhEventOpsV01OpenMaster_();
    var keys = ['events','calendar','rentals','staff','setup','setupVendors','logs'];
    for (var i = 0; i < keys.length; i++) {
      var spec = FH_EVENT_OPS_V01_SHEETS[keys[i]];
      var sh = ss.getSheetByName(spec.name);
      result.sheets.push({ name: spec.name, exists: !!sh, created: false, addedHeaders: [], ok: true, locked: true });
    }
  } catch (err) {
    result.ok = false;
    result.message = String(err && err.message ? err.message : err);
  }
  return fhEventOpsV01Safe_(result);
}

function fhEventOpsV01GetDashboard(payload) {
  var result = { ok: true, build: FH_EVENT_OPS_CORE_V01_BUILD, action: 'fhEventOpsV01GetDashboard', generatedAt: fhEventOpsV01Now_(), counts: {}, message: '행사관리 대시보드 조회 완료' };
  try {
    fhEventOpsV01EnsureSchema({ silent: true });
    var ss = fhEventOpsV01OpenMaster_();
    result.counts.events = fhEventOpsV01CountRows_(ss, 'ERP_Events');
    result.counts.calendar = fhEventOpsV01CountRows_(ss, 'CalendarEvents');
    result.counts.rentals = fhEventOpsV01CountRows_(ss, 'EventRentalRequests');
    result.counts.staff = fhEventOpsV01CountRows_(ss, 'EventStaffAssignments');
    result.counts.setup = fhEventOpsV01CountRows_(ss, 'EventSetupItems');
    result.counts.setupVendors = fhEventOpsV01CountRows_(ss, 'EventSetupVendors');
  } catch (err) {
    result.ok = false;
    result.message = String(err && err.message ? err.message : err);
  }
  return fhEventOpsV01Safe_(result);
}

function fhEventOpsV01ListEvents(payload) {
  payload = payload || {};
  var result = { ok: true, build: FH_EVENT_OPS_CORE_V01_BUILD, action: 'fhEventOpsV01ListEvents', generatedAt: fhEventOpsV01Now_(), count: 0, events: [], message: '행사 목록 조회 완료' };
  try {
    fhEventOpsV01EnsureSchema({ silent: true });
    var ss = fhEventOpsV01OpenMaster_();
    var sh = ss.getSheetByName('ERP_Events');
    var rows = fhEventOpsV01ReadObjects_(sh);
    rows.sort(function(a, b) { return String(b.createdAt || '').localeCompare(String(a.createdAt || '')); });
    var limit = Math.min(200, Math.max(1, parseInt(payload.limit || 100, 10) || 100));
    result.events = rows.slice(0, limit);
    result.count = result.events.length;
  } catch (err) {
    result.ok = false;
    result.message = String(err && err.message ? err.message : err);
  }
  return fhEventOpsV01Safe_(result);
}

function fhEventOpsV01GetEventDetail(payload) {
  payload = payload || {};
  var eventId = String(payload.eventId || '').trim();
  var result = { ok: false, build: FH_EVENT_OPS_CORE_V01_BUILD, action: 'fhEventOpsV01GetEventDetail', generatedAt: fhEventOpsV01Now_(), eventId: eventId, event: null, calendars: [], rentals: [], staff: [], setupItems: [], setupVendors: [], logs: [], message: '' };
  try {
    if (!eventId) throw new Error('eventId가 없습니다.');
    fhEventOpsV01EnsureSchema({ silent: true });
    var ss = fhEventOpsV01OpenMaster_();
    result.event = fhEventOpsV01FindByKey_(ss.getSheetByName('ERP_Events'), 'eventId', eventId);
    if (!result.event) throw new Error('행사를 찾지 못했습니다: ' + eventId);
    result.calendars = fhEventOpsV01FilterByKey_(ss.getSheetByName('CalendarEvents'), 'eventId', eventId);
    result.rentals = fhEventOpsV01FilterByKey_(ss.getSheetByName('EventRentalRequests'), 'eventId', eventId);
    result.staff = fhEventOpsV01FilterByKey_(ss.getSheetByName('EventStaffAssignments'), 'eventId', eventId);
    result.setupItems = fhEventOpsV01FilterByKey_(ss.getSheetByName('EventSetupItems'), 'eventId', eventId);
    result.setupVendors = fhEventOpsV01FilterByKey_(ss.getSheetByName('EventSetupVendors'), 'eventId', eventId);
    result.logs = fhEventOpsV01FilterByKey_(ss.getSheetByName('AuditLogs'), 'eventId', eventId).slice(-20).reverse();
    result.ok = true;
    result.message = '행사 상세 조회 완료';
  } catch (err) {
    result.ok = false;
    result.message = String(err && err.message ? err.message : err);
  }
  return fhEventOpsV01Safe_(result);
}


function fhEventOpsV01BlockedWrite_(action) {
  return fhEventOpsV01Safe_({
    ok: false,
    locked: true,
    build: FH_EVENT_OPS_CORE_V01_BUILD,
    action: action || 'FH_EVENT_OPS_WRITE',
    generatedAt: fhEventOpsV01Now_(),
    message: 'EVENT_CENTER_FAST_STABILIZE_V01 기준: 이 V01 저장 함수는 잠금 상태입니다. ERP_행사관리/ERP_업체관리/ERP_행사업체연결 기준 정렬 후 새 센터에서 저장을 활성화해야 합니다.'
  });
}

function fhEventOpsV01SaveEvent(payload) {
  return fhEventOpsV01BlockedWrite_('fhEventOpsV01SaveEvent');
}

function fhEventOpsV01SaveRental(payload) {
  return fhEventOpsV01BlockedWrite_('fhEventOpsV01SaveRental');
}

function fhEventOpsV01SaveCalendarEvent(payload) {
  return fhEventOpsV01BlockedWrite_('fhEventOpsV01SaveCalendarEvent');
}

function fhEventOpsV01SaveStaffAssignment(payload) {
  return fhEventOpsV01BlockedWrite_('fhEventOpsV01SaveStaffAssignment');
}

function fhEventOpsV01SaveSetupItem(payload) {
  return fhEventOpsV01BlockedWrite_('fhEventOpsV01SaveSetupItem');
}

function fhEventOpsV01OpenMaster_() {
  var setupId = '17VMSpgSZCvIrUlgcw8yCNcnl8WQWo2IcRf5tDCcuJGM';
  var setup = SpreadsheetApp.openById(setupId);
  var sheet = setup.getSheetByName('SystemConfig');
  if (!sheet) throw new Error('SystemConfig 시트를 찾지 못했습니다.');
  var values = sheet.getDataRange().getValues();
  if (!values || values.length < 2) throw new Error('SystemConfig 데이터가 비어 있습니다.');
  var hm = fhEventOpsV01HeaderMap_(values[0]);
  var keyCol = fhEventOpsV01PickIndex_(hm, ['CONFIG_KEY','configKey','key','name']);
  var valCol = fhEventOpsV01PickIndex_(hm, ['VALUE','configValue','value','spreadsheetId']);
  if (keyCol < 0 || valCol < 0) throw new Error('SystemConfig CONFIG_KEY/VALUE 헤더를 찾지 못했습니다.');
  var masterId = '';
  for (var r = 1; r < values.length; r++) {
    var key = String(values[r][keyCol] || '').trim();
    if (key === 'FEELHAUS_DB_MASTER' || key === 'FEELHAUS_DB_MASTER_ID' || key === 'MASTER_DB_ID') {
      masterId = String(values[r][valCol] || '').trim();
      break;
    }
  }
  if (!masterId) throw new Error('SystemConfig에서 FEELHAUS_DB_MASTER ID를 찾지 못했습니다.');
  return SpreadsheetApp.openById(masterId);
}

function fhEventOpsV01EnsureSheet_(ss, name, headers) {
  var sh = ss.getSheetByName(name);
  if (!sh) {
    return { name: name, exists: false, created: false, addedHeaders: [], ok: true, locked: true, message: '자동 시트 생성 차단' };
  }
  var existing = [];
  if (sh.getLastRow() >= 1 && sh.getLastColumn() >= 1) {
    existing = sh.getRange(1, 1, 1, sh.getLastColumn()).getValues()[0].map(function(h) { return String(h || '').trim(); });
  }
  var missing = [];
  for (var i = 0; i < headers.length; i++) {
    if (existing.indexOf(headers[i]) < 0) missing.push(headers[i]);
  }
  return { name: name, exists: true, created: false, addedHeaders: [], missingHeaders: missing, ok: true, locked: true };
}

function fhEventOpsV01AppendObject_(sh, obj) {
  throw new Error('EVENT_CENTER_FAST_STABILIZE_V01: append write is locked.');
}

function fhEventOpsV01UpdateObjectAtRow_(sh, rowNo, obj) {
  throw new Error('EVENT_CENTER_FAST_STABILIZE_V01: update write is locked.');
}

function fhEventOpsV01ReadObjects_(sh) {
  if (!sh || sh.getLastRow() < 2 || sh.getLastColumn() < 1) return [];
  var values = sh.getDataRange().getValues();
  var headers = values[0].map(function(h) { return String(h || '').trim(); });
  var out = [];
  for (var r = 1; r < values.length; r++) {
    var obj = {};
    var empty = true;
    for (var c = 0; c < headers.length; c++) {
      var key = headers[c];
      if (!key) continue;
      var value = values[r][c];
      if (value instanceof Date) value = Utilities.formatDate(value, Session.getScriptTimeZone() || 'Asia/Seoul', 'yyyy-MM-dd HH:mm:ss');
      if (String(value || '').trim()) empty = false;
      obj[key] = value == null ? '' : String(value);
    }
    if (!empty) out.push(obj);
  }
  return out;
}

function fhEventOpsV01FindByKey_(sh, key, value) {
  var rows = fhEventOpsV01ReadObjects_(sh);
  for (var i = 0; i < rows.length; i++) if (String(rows[i][key] || '') === String(value || '')) return rows[i];
  return null;
}

function fhEventOpsV01FilterByKey_(sh, key, value) {
  var rows = fhEventOpsV01ReadObjects_(sh);
  var out = [];
  for (var i = 0; i < rows.length; i++) if (String(rows[i][key] || '') === String(value || '')) out.push(rows[i]);
  return out;
}

function fhEventOpsV01FindRowByKey_(sh, key, value) {
  if (!sh || sh.getLastRow() < 2) return { rowNo: -1, object: null };
  var values = sh.getDataRange().getValues();
  var headers = values[0].map(function(h) { return String(h || '').trim(); });
  var idx = headers.indexOf(key);
  if (idx < 0) return { rowNo: -1, object: null };
  for (var r = 1; r < values.length; r++) {
    if (String(values[r][idx] || '') === String(value || '')) {
      var obj = {};
      for (var c = 0; c < headers.length; c++) obj[headers[c]] = values[r][c] == null ? '' : String(values[r][c]);
      return { rowNo: r + 1, object: obj };
    }
  }
  return { rowNo: -1, object: null };
}

function fhEventOpsV01FindStaffConflict_(ss, obj) {
  var staffName = String(obj.staffName || '').trim();
  var staffId = String(obj.staffId || '').trim();
  var startAt = String(obj.startAt || '').trim();
  var endAt = String(obj.endAt || '').trim();
  if ((!staffId && !staffName) || !startAt || !endAt) return null;
  var rows = fhEventOpsV01ReadObjects_(ss.getSheetByName('EventStaffAssignments'));
  var startMs = new Date(startAt.replace(' ', 'T')).getTime();
  var endMs = new Date(endAt.replace(' ', 'T')).getTime();
  if (!startMs || !endMs) return null;
  for (var i = 0; i < rows.length; i++) {
    var r = rows[i];
    if (String(r.assignmentId || '') === String(obj.assignmentId || '')) continue;
    var sameStaff = staffId ? String(r.staffId || '') === staffId : String(r.staffName || '') === staffName;
    if (!sameStaff) continue;
    var rs = new Date(String(r.startAt || '').replace(' ', 'T')).getTime();
    var re = new Date(String(r.endAt || '').replace(' ', 'T')).getTime();
    if (!rs || !re) continue;
    var overlap = startMs < re && endMs > rs;
    if (overlap && String(r.status || '') !== '취소') return r;
  }
  return null;
}

function fhEventOpsV01Log_(payload) {
  try {
    var ss = fhEventOpsV01OpenMaster_();
    var sh = ss.getSheetByName('AuditLogs');
    if (!sh) return false;
    var obj = {
      logId: fhEventOpsV01NewId_('LOG'),
      eventId: payload.eventId || '',
      calendarId: payload.calendarId || '',
      rentalId: payload.rentalId || '',
      assignmentId: payload.assignmentId || '',
      setupItemId: payload.setupItemId || '',
      actionType: payload.actionType || '',
      beforeValue: payload.beforeValue || '',
      afterValue: payload.afterValue || '',
      reason: payload.reason || '',
      createdAt: fhEventOpsV01Now_(),
      createdBy: fhEventOpsV01User_()
    };
    fhEventOpsV01AppendObject_(sh, obj);
    return true;
  } catch (err) {
    try { Logger.log('fhEventOpsV01Log_ failed: ' + err); } catch (ignoreLog) {}
    return false;
  }
}

function fhEventOpsV01GetHeaders_(sh) {
  if (!sh || sh.getLastColumn() < 1) return [];
  return sh.getRange(1, 1, 1, sh.getLastColumn()).getValues()[0].map(function(h) { return String(h || '').trim(); });
}

function fhEventOpsV01CountRows_(ss, sheetName) {
  var sh = ss.getSheetByName(sheetName);
  if (!sh) return 0;
  return Math.max(0, sh.getLastRow() - 1);
}

function fhEventOpsV01HeaderMap_(headers) {
  var out = {};
  (headers || []).forEach(function(h, i) { var key = String(h || '').trim(); if (key) out[key] = i; });
  return out;
}

function fhEventOpsV01PickIndex_(hm, names) {
  for (var i = 0; i < names.length; i++) if (hm.hasOwnProperty(names[i])) return hm[names[i]];
  return -1;
}

function fhEventOpsV01NewId_(prefix) {
  var tz = Session.getScriptTimeZone() || 'Asia/Seoul';
  var stamp = Utilities.formatDate(new Date(), tz, 'yyyyMMddHHmmss');
  var rand = Math.floor(Math.random() * 9000) + 1000;
  return prefix + '-' + stamp + '-' + rand;
}

function fhEventOpsV01User_() {
  try { return Session.getActiveUser().getEmail() || Session.getEffectiveUser().getEmail() || ''; } catch (err) { return ''; }
}
