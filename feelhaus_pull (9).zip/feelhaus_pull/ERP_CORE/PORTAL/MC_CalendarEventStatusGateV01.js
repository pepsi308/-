/**
 * FEELHAUS MailCenter Calendar Event Status Gate V01
 * Build: MAILCENTER_CALENDAR_EVENT_STATUS_GATE_V01_20260521
 * Purpose:
 * - Read-only stability gate for 6단계 일정 상태변경 기능
 * - Verify server status function, transition helpers, required sheets/headers, and status logs
 * - Do not modify router/menu/html/shell/view files
 */
var MC_CALENDAR_EVENT_STATUS_GATE_V01_BUILD = 'MAILCENTER_CALENDAR_EVENT_STATUS_GATE_V01_20260521';
var MC_CALENDAR_EVENT_STATUS_GATE_V01_SETUP_DB_ID = '17VMSpgSZCvIrUlgcw8yCNcnl8WQWo2IcRf5tDCcuJGM';
var MC_CALENDAR_EVENT_STATUS_GATE_V01_CONFIG_SHEET = 'SystemConfig';
var MC_CALENDAR_EVENT_STATUS_GATE_V01_WEBAPP_URL = 'https://script.google.com/a/macros/feelhausfair.com/s/AKfycbxCyFE7zf4vE8nsfjOeWX0pC56SqU84gm8ie8Txa3qHQGEusJCZeljzCdYeOmZxUVYvjA/exec';

function runMcCalendarEventStatusGateV01() {
  var result = {
    ok: true,
    build: MC_CALENDAR_EVENT_STATUS_GATE_V01_BUILD,
    action: 'runMcCalendarEventStatusGateV01',
    generatedAt: mcCalendarEventStatusGateV01Now_(),
    noWriteMode: true,
    checks: [],
    warnings: [],
    message: '',
    nextStage: ''
  };
  function check(key, ok, message, detail) {
    result.checks.push({ key: key, ok: !!ok, message: message, detail: detail || '' });
    if (!ok) result.ok = false;
  }
  function warn(message, detail) {
    result.warnings.push({ message: message, detail: detail || '' });
  }

  try {
    check('StatusSmokeReady', typeof runMcCalendarEventStatusV01Smoke === 'function', '6-1 상태변경 Smoke 함수 확인');
    check('StatusDryRunReady', typeof runMcCalendarEventStatusV01DryRun === 'function', '6-1 상태변경 Dry Run 함수 확인');
    check('StatusChangeReady', typeof mcCalendarEventStatusV01ChangeStatus === 'function', '상태변경 실행 함수 확인');
    check('TransitionRuleReady', typeof mcCalendarEventStatusV01CanTransition_ === 'function', '상태 전이 규칙 함수 확인');
    check('WebAppUrlReady', !!MC_CALENDAR_EVENT_STATUS_GATE_V01_WEBAPP_URL, 'WebApp 절대주소 확인', MC_CALENDAR_EVENT_STATUS_GATE_V01_WEBAPP_URL);

    var master = mcCalendarEventStatusGateV01OpenMaster_();
    check('MasterOpenReady', !!master, 'SystemConfig -> FEELHAUS_DB_MASTER 연결 확인', master.getId());

    var eventSheet = master.getSheetByName('MAILCENTER_CalendarEvents');
    check('CalendarEventsSheetReady', !!eventSheet, 'MAILCENTER_CalendarEvents 시트 확인');
    if (eventSheet) {
      var eventData = eventSheet.getDataRange().getValues();
      var eventHeaders = eventData.length ? eventData[0] : [];
      var eventHm = mcCalendarEventStatusGateV01HeaderMap_(eventHeaders);
      var missingEventHeaders = mcCalendarEventStatusGateV01Missing_(eventHm, ['calendarEventId','eventTitle','eventStatus','statusReason','updatedAt','updatedBy']);
      check('CalendarEventsHeadersReady', missingEventHeaders.length === 0, '상태변경 핵심 헤더 확인', 'rows=' + eventSheet.getLastRow() + ', missing=' + JSON.stringify(missingEventHeaders));

      var statusCol = eventHm.hasOwnProperty('eventStatus') ? eventHm.eventStatus : -1;
      var idCol = eventHm.hasOwnProperty('calendarEventId') ? eventHm.calendarEventId : -1;
      var totalEvents = Math.max(eventData.length - 1, 0);
      var statusCounts = {};
      var sampleIds = [];
      if (statusCol >= 0 && idCol >= 0) {
        for (var r = 1; r < eventData.length; r++) {
          var st = String(eventData[r][statusCol] || '').trim() || '(blank)';
          statusCounts[st] = (statusCounts[st] || 0) + 1;
          if (sampleIds.length < 3) sampleIds.push(String(eventData[r][idCol] || '').trim());
        }
      }
      check('CalendarEventsRowsReady', totalEvents > 0, '상태변경 대상 일정 데이터 확인', 'total=' + totalEvents + ', statusCounts=' + JSON.stringify(statusCounts) + ', sampleIds=' + JSON.stringify(sampleIds));
    }

    var logSheet = master.getSheetByName('MAILCENTER_CalendarLogs');
    check('CalendarLogsSheetReady', !!logSheet, 'MAILCENTER_CalendarLogs 시트 확인');
    if (logSheet) {
      var logData = logSheet.getDataRange().getValues();
      var logHeaders = logData.length ? logData[0] : [];
      var logHm = mcCalendarEventStatusGateV01HeaderMap_(logHeaders);
      var missingLogHeaders = mcCalendarEventStatusGateV01Missing_(logHm, ['calendarLogId','calendarEventId','actionType','resultStatus','requestPayloadSummary','responseSummary','createdAt','createdBy']);
      check('CalendarLogsHeadersReady', missingLogHeaders.length === 0, '상태변경 로그 핵심 헤더 확인', 'rows=' + logSheet.getLastRow() + ', missing=' + JSON.stringify(missingLogHeaders));

      var actionCol = logHm.hasOwnProperty('actionType') ? logHm.actionType : -1;
      var resultCol = logHm.hasOwnProperty('resultStatus') ? logHm.resultStatus : -1;
      var statusChangeLogs = 0;
      var successLogs = 0;
      if (actionCol >= 0) {
        for (var i = 1; i < logData.length; i++) {
          if (String(logData[i][actionCol] || '').trim() === 'STATUS_CHANGE') {
            statusChangeLogs++;
            if (resultCol < 0 || String(logData[i][resultCol] || '').trim() === 'SUCCESS') successLogs++;
          }
        }
      }
      check('StatusChangeLogReady', statusChangeLogs > 0, '상태변경 로그 기록 확인', 'statusChangeLogs=' + statusChangeLogs + ', successLogs=' + successLogs);
      if (statusChangeLogs === 0) warn('상태변경 로그가 아직 없습니다.', '화면에서 상태변경 1회 성공 후 다시 게이트 실행 필요');
    }

    if (typeof mcCalendarEventStatusV01CanTransition_ === 'function') {
      var rules = [
        { from: '요청', to: '예정', expected: true },
        { from: '예정', to: '진행중', expected: true },
        { from: '진행중', to: '완료', expected: true },
        { from: '완료', to: '예정', expected: false },
        { from: '취소', to: '예정', expected: false }
      ];
      var ruleOk = true;
      var details = [];
      rules.forEach(function(t) {
        var got = mcCalendarEventStatusV01CanTransition_(t.from, t.to);
        var ok = !!got.ok === t.expected;
        if (!ok) ruleOk = false;
        details.push(t.from + '->' + t.to + '=' + got.ok);
      });
      check('TransitionRuleMatrixReady', ruleOk, '상태 전이 규칙 기본 매트릭스 확인', details.join(', '));
    }

    check('NoWriteModeConfirmed', true, '본 게이트는 읽기 점검 전용, 시트 쓰기 없음');
    check('NoRouterMenuHtmlTouchByGate', true, '게이트 파일은 라우터/메뉴/HTML/Shell/View 변경 없음');

    result.message = result.ok ? 'MailCenter Calendar Event Status Gate V01 통과' : 'MailCenter Calendar Event Status Gate V01 점검 필요';
    result.nextStage = result.ok ? 'MAILCENTER_CALENDAR_EVENT_STATUS_LOCK_READY' : 'FIX_REQUIRED';
  } catch (err) {
    result.ok = false;
    result.message = mcCalendarEventStatusGateV01Err_(err);
    result.nextStage = 'FIX_REQUIRED';
  }

  Logger.log(JSON.stringify(result, null, 2));
  return result;
}

function mcCalendarEventStatusGateV01OpenMaster_() {
  var setup = SpreadsheetApp.openById(MC_CALENDAR_EVENT_STATUS_GATE_V01_SETUP_DB_ID);
  var sheet = setup.getSheetByName(MC_CALENDAR_EVENT_STATUS_GATE_V01_CONFIG_SHEET);
  if (!sheet) throw new Error('SystemConfig 시트를 찾지 못했습니다.');
  var values = sheet.getDataRange().getValues();
  if (!values || values.length < 2) throw new Error('SystemConfig 데이터가 비어 있습니다.');
  var hm = mcCalendarEventStatusGateV01HeaderMap_(values[0]);
  var keyCol = mcCalendarEventStatusGateV01PickIndex_(hm, ['CONFIG_KEY','configKey','key','name']);
  var valCol = mcCalendarEventStatusGateV01PickIndex_(hm, ['VALUE','configValue','value','spreadsheetId']);
  if (keyCol < 0 || valCol < 0) throw new Error('SystemConfig CONFIG_KEY/VALUE 헤더를 찾지 못했습니다.');
  var masterId = '';
  for (var r = 1; r < values.length; r++) {
    var key = String(values[r][keyCol] || '').trim();
    if (key === 'FEELHAUS_DB_MASTER' || key === 'FEELHAUS_DB_MASTER_ID' || key === 'MASTER_DB_ID') {
      masterId = String(values[r][valCol] || '').trim();
      break;
    }
  }
  if (!masterId) throw new Error('SystemConfig에서 FEELHAUS_DB_MASTER ID를 찾지 못했습니다.');
  return SpreadsheetApp.openById(masterId);
}

function mcCalendarEventStatusGateV01HeaderMap_(headers) {
  var out = {};
  (headers || []).forEach(function(h, i) {
    var key = String(h || '').trim();
    if (key) out[key] = i;
  });
  return out;
}

function mcCalendarEventStatusGateV01Missing_(hm, required) {
  var missing = [];
  (required || []).forEach(function(h) {
    if (!hm.hasOwnProperty(h)) missing.push(h);
  });
  return missing;
}

function mcCalendarEventStatusGateV01PickIndex_(hm, keys) {
  for (var i = 0; i < keys.length; i++) if (hm.hasOwnProperty(keys[i])) return hm[keys[i]];
  return -1;
}

function mcCalendarEventStatusGateV01Now_() {
  return Utilities.formatDate(new Date(), Session.getScriptTimeZone() || 'Asia/Seoul', 'yyyy-MM-dd HH:mm:ss');
}

function mcCalendarEventStatusGateV01Err_(err) {
  return err && err.message ? err.message : String(err);
}
