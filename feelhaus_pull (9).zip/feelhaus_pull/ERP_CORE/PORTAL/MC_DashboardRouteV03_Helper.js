/**
 * FEELHAUS MailCenter Dashboard Route V03 Helper
 * Build: MC_DASHBOARD_ROUTE_V03_20260519
 *
 * This file does NOT replace Portal_Main.js.
 * It only provides helper functions for safe route checking.
 */

var MC_DASHBOARD_ROUTE_V03_BUILD = 'MC_DASHBOARD_ROUTE_V03_20260519';

function runMcDashboardRouteV03Check() {
  var result = {
    ok: false,
    build: MC_DASHBOARD_ROUTE_V03_BUILD,
    action: 'runMcDashboardRouteV03Check',
    generatedAt: mcDashboardRouteV03Now_(),
    message: '',
    checks: []
  };

  try {
    result.checks.push({
      key: 'DashboardHandlerReady',
      ok: typeof mcDashboardShellV03HandleGet === 'function',
      message: 'mcDashboardShellV03HandleGet 함수 존재 확인'
    });
    result.checks.push({
      key: 'DashboardDataReady',
      ok: typeof mcDashboardShellV03GetInitialData === 'function',
      message: 'mcDashboardShellV03GetInitialData 함수 존재 확인'
    });
    result.checks.push({
      key: 'NoDoGetInThisFile',
      ok: true,
      message: '이 파일은 doGet을 만들지 않음. Portal_Main 기존 doGet 보호'
    });
    result.ok = result.checks.every(function(c) { return c.ok; });
    result.message = result.ok
      ? 'MailCenter Dashboard V03 route 연결 준비 완료'
      : 'MailCenter Dashboard V03 route 연결 전 필수 함수 확인 필요';
  } catch (err) {
    result.ok = false;
    result.message = String(err && err.message ? err.message : err);
  }

  Logger.log('JSON_COMPACT_RESULT: ' + JSON.stringify(result));
  return result;
}

function mcDashboardRouteV03CanHandlePage(e) {
  var page = '';
  try {
    page = String((e && e.parameter && e.parameter.page) || '').trim();
  } catch (err) {
    page = '';
  }
  return page === 'MailCenterDashboardV03';
}

function mcDashboardRouteV03HandleGet(e) {
  if (typeof mcDashboardShellV03HandleGet !== 'function') {
    throw new Error('mcDashboardShellV03HandleGet 함수가 없습니다. MC_DashboardShellV03.js 적용 상태를 확인하세요.');
  }
  return mcDashboardShellV03HandleGet(e);
}

function mcDashboardRouteV03Now_() {
  return Utilities.formatDate(new Date(), Session.getScriptTimeZone() || 'Asia/Seoul', 'yyyy-MM-dd HH:mm:ss');
}
