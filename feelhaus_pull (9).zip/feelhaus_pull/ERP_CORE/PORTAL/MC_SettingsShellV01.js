/**
 * FEELHAUS MailCenter Settings Shell V01
 * Build: MC_SETTINGS_SHELL_V01_20260519
 */

var MC_SETTINGS_SHELL_V01_BUILD = 'MAILCENTER_DEFAULT_POLICY_SETTINGS_V01_20260520';

function runMcSettingsShellV01() {
  var result = {
    ok: false,
    build: MC_SETTINGS_SHELL_V01_BUILD,
    action: 'runMcSettingsShellV01',
    generatedAt: Utilities.formatDate(new Date(), Session.getScriptTimeZone() || 'Asia/Seoul', 'yyyy-MM-dd HH:mm:ss'),
    message: '',
    checks: []
  };

  try {
    result.checks.push({ key: 'CoreReady', ok: typeof mcSettingsCoreV01GetData === 'function', message: 'Settings Core 데이터 함수 확인' });
    result.checks.push({ key: 'SaveSignatureReady', ok: typeof mcSettingsCoreV01SaveSignature === 'function', message: '서명 저장 함수 확인' });
    result.checks.push({ key: 'SaveFolderReady', ok: typeof mcSettingsCoreV01SaveFolder === 'function', message: '폴더 저장 함수 확인' });
    result.checks.push({ key: 'DefaultAccountReady', ok: typeof mcSettingsCoreV01SetDefaultAccount === 'function', message: '기본 발신계정 함수 확인' });
    result.checks.push({ key: 'DefaultSignatureReady', ok: typeof mcSettingsCoreV01SetDefaultSignature === 'function', message: '기본 서명 지정 함수 확인' });
    result.checks.push({ key: 'DisableSignatureReady', ok: typeof mcSettingsCoreV01DisableSignature === 'function', message: '서명 사용중지 함수 확인' });
    result.checks.push({ key: 'DisableFolderReady', ok: typeof mcSettingsCoreV01DisableFolder === 'function', message: '폴더 사용중지 함수 확인' });
    result.checks.push({ key: 'DefaultFolderReady', ok: typeof mcSettingsCoreV01SetDefaultFolder === 'function', message: '기본 폴더 지정 함수 확인' });
    result.checks.push({ key: 'PolicySettingsReady', ok: typeof mcSettingsCoreV01SavePolicySettings === 'function', message: '기본 발송/첨부 정책 저장 함수 확인' });
    result.ok = result.checks.every(function(c) { return !!c.ok; });
    result.message = result.ok ? 'MailCenter Settings Shell V01 준비 완료' : 'Settings Shell V01 필수 함수 확인 필요';
  } catch (err) {
    result.ok = false;
    result.message = String(err && err.message ? err.message : err);
  }

  Logger.log('JSON_COMPACT_RESULT: ' + JSON.stringify(result));
  return result;
}

function mcSettingsShellV01HandleGet(e) {
  var data = typeof mcSettingsCoreV01GetData === 'function'
    ? mcSettingsCoreV01GetData()
    : { ok: false, message: 'mcSettingsCoreV01GetData 함수가 없습니다.', accounts: [], signatures: [], folders: [], preferences: [] };

  var t = HtmlService.createTemplateFromFile('MC_SettingsViewV01');
  t.build = MC_SETTINGS_SHELL_V01_BUILD;
  t.initialJson = JSON.stringify(data);

  return t.evaluate()
    .setTitle('FEELHAUS MailCenter Settings')
    .setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL);
}
