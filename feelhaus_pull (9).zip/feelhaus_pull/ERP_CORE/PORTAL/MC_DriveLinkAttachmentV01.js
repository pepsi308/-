/**
 * FEELHAUS MailCenter Drive Link Attachment V01
 * Build: MAILCENTER_ATTACHMENT_FLOW_V01_20260520
 *
 * Purpose:
 * - Gmail 실제 첨부 전 안전 단계
 * - Drive URL / 파일명 / 설명을 본문 하단에 자동 삽입
 * - MailCenter_Attachments 기록
 * - 기존 Compose Core / Send Core 수정 없음
 */

var MC_DRIVE_LINK_ATTACHMENT_V01_BUILD = 'MAILCENTER_ATTACHMENT_FLOW_V01_20260520';
var MC_DRIVE_LINK_ATTACHMENT_V01_SETUP_DB_ID = '17VMSpgSZCvIrUlgcw8yCNcnl8WQWo2IcRf5tDCcuJGM';
var MC_DRIVE_LINK_ATTACHMENT_V01_CONFIG_SHEET = 'SystemConfig';

function runMcDriveLinkAttachmentV01Smoke() {
  var result = {
    ok: false,
    build: MC_DRIVE_LINK_ATTACHMENT_V01_BUILD,
    action: 'runMcDriveLinkAttachmentV01Smoke',
    generatedAt: mcDriveLinkAttachmentV01Now_(),
    message: '',
    checks: []
  };

  try {
    var ss = mcDriveLinkAttachmentV01OpenMaster_().ss;
    mcDriveLinkAttachmentV01EnsureSheets_(ss);

    result.checks.push({
      key: 'MasterConnected',
      ok: !!ss,
      message: 'FEELHAUS_DB_MASTER 연결 확인'
    });
    result.checks.push({
      key: 'AttachmentsSheetReady',
      ok: !!ss.getSheetByName('MailCenter_Attachments'),
      message: 'MailCenter_Attachments 시트 확인'
    });
    result.checks.push({
      key: 'ComposeCoreReady',
      ok: typeof mcComposeCoreV01Send === 'function',
      message: '기존 Compose 발송 함수 확인'
    });
    result.checks.push({
      key: 'PrepareFunctionReady',
      ok: typeof mcDriveLinkAttachmentV01Prepare === 'function',
      message: 'Drive 링크 준비 함수 확인'
    });
    result.checks.push({
      key: 'SendWrapperReady',
      ok: typeof mcDriveLinkAttachmentV01SendWithLinks === 'function',
      message: 'Drive 링크 포함 발송 래퍼 확인'
    });

    result.ok = result.checks.every(function(c) { return !!c.ok; });
    result.message = result.ok ? 'Drive Link Attachment V01 준비 완료' : 'Drive Link Attachment V01 점검 필요';
  } catch (err) {
    result.ok = false;
    result.message = String(err && err.message ? err.message : err);
  }

  mcDriveLinkAttachmentV01Log_(result);
  return mcDriveLinkAttachmentV01Safe_(result);
}

function mcDriveLinkAttachmentV01Prepare(payload) {
  var result = {
    ok: false,
    build: MC_DRIVE_LINK_ATTACHMENT_V01_BUILD,
    action: 'mcDriveLinkAttachmentV01Prepare',
    generatedAt: mcDriveLinkAttachmentV01Now_(),
    message: '',
    attachments: [],
    attachmentText: '',
    attachmentHtml: ''
  };

  try {
    var p = payload || {};
    var links = p.attachments || p.driveLinks || [];
    if (!Array.isArray(links)) links = [];

    var clean = [];
    for (var i = 0; i < links.length; i++) {
      var item = links[i] || {};
      var url = String(item.driveUrl || item.url || '').trim();
      var fileName = String(item.fileName || item.name || '').trim();
      var desc = String(item.description || item.desc || '').trim();

      if (!url && !fileName && !desc) continue;
      if (!url) throw new Error('Drive URL 값이 필요합니다.');
      if (!/^https?:\/\//i.test(url)) throw new Error('Drive URL 형식이 올바르지 않습니다: ' + url);
      if (!fileName) fileName = '첨부자료';

      clean.push({
        attachmentId: mcDriveLinkAttachmentV01NewId_('MCATT'),
        fileName: fileName,
        driveUrl: url,
        description: desc,
        attachmentType: 'DRIVE_LINK',
        attachmentStatus: 'READY'
      });
    }

    result.attachments = clean;
    result.attachmentText = mcDriveLinkAttachmentV01BuildText_(clean);
    result.attachmentHtml = mcDriveLinkAttachmentV01BuildHtml_(clean);
    result.ok = true;
    result.message = 'Drive 링크 준비 완료';
  } catch (err) {
    result.ok = false;
    result.message = String(err && err.message ? err.message : err);
  }

  return mcDriveLinkAttachmentV01Safe_(result);
}

function mcDriveLinkAttachmentV01SendWithLinks(payload) {
  var result = {
    ok: false,
    build: MC_DRIVE_LINK_ATTACHMENT_V01_BUILD,
    action: 'mcDriveLinkAttachmentV01SendWithLinks',
    generatedAt: mcDriveLinkAttachmentV01Now_(),
    message: '',
    attachmentIds: [],
    sendResult: null
  };

  try {
    if (typeof mcComposeCoreV01Send !== 'function') {
      throw new Error('mcComposeCoreV01Send 함수가 없습니다.');
    }

    var p = payload || {};
    var prepared = mcDriveLinkAttachmentV01Prepare(p);
    if (!prepared.ok) throw new Error(prepared.message || 'Drive 링크 준비 실패');

    var body = String(p.body || '');
    var finalBody = body;
    if (prepared.attachmentHtml) {
      finalBody += '<br><br>' + prepared.attachmentHtml;
    } else if (prepared.attachmentText) {
      finalBody += '<br><br>' + mcDriveLinkAttachmentV01Escape_(prepared.attachmentText).replace(/\r?\n/g, '<br>');
    }

    var sendPayload = {
      mailAccountId: p.mailAccountId || '',
      folderId: p.folderId || '',
      signatureId: p.signatureId || '',
      toEmail: p.toEmail || '',
      ccEmail: p.ccEmail || '',
      bccEmail: p.bccEmail || '',
      subject: p.subject || '',
      body: finalBody
    };

    var sent = mcComposeCoreV01Send(sendPayload);
    result.sendResult = mcDriveLinkAttachmentV01Safe_(sent);

    var ss = mcDriveLinkAttachmentV01OpenMaster_().ss;
    mcDriveLinkAttachmentV01EnsureSheets_(ss);

    var sendOk = !!(sent && sent.ok);
    var messageId = sent && sent.sendResult && sent.sendResult.gmailMessageId ? sent.sendResult.gmailMessageId : '';
    if (!messageId && sent && sent.gmailMessageId) messageId = sent.gmailMessageId;

    for (var i = 0; i < prepared.attachments.length; i++) {
      mcDriveLinkAttachmentV01AppendAttachment_(ss, prepared.attachments[i], {
        mailAccountId: p.mailAccountId || '',
        toEmail: p.toEmail || '',
        subject: p.subject || '',
        composeStatus: sendOk ? 'SENT' : 'FAILED',
        gmailMessageId: messageId
      });
      result.attachmentIds.push(prepared.attachments[i].attachmentId);
    }

    if (!sendOk) {
      throw new Error((sent && sent.message) ? sent.message : '발송 실패');
    }

    result.ok = true;
    result.message = 'Drive 링크 포함 메일 발송 완료';
  } catch (err) {
    result.ok = false;
    result.message = String(err && err.message ? err.message : err);
  }

  mcDriveLinkAttachmentV01Log_(result);
  return mcDriveLinkAttachmentV01Safe_(result);
}

function mcDriveLinkAttachmentV01ListRecent(limit) {
  var result = {
    ok: false,
    build: MC_DRIVE_LINK_ATTACHMENT_V01_BUILD,
    action: 'mcDriveLinkAttachmentV01ListRecent',
    generatedAt: mcDriveLinkAttachmentV01Now_(),
    message: '',
    attachments: []
  };

  try {
    var ss = mcDriveLinkAttachmentV01OpenMaster_().ss;
    mcDriveLinkAttachmentV01EnsureSheets_(ss);

    var rows = mcDriveLinkAttachmentV01ReadRecent_(ss, 'MailCenter_Attachments', Number(limit || 20));
    result.attachments = rows;
    result.ok = true;
    result.message = '최근 Drive 링크 첨부 기록 조회 완료';
  } catch (err) {
    result.ok = false;
    result.message = String(err && err.message ? err.message : err);
  }

  return mcDriveLinkAttachmentV01Safe_(result);
}

function runMcDriveLinkAttachmentV01ListRecent() {
  var result = mcDriveLinkAttachmentV01ListRecent(20);
  mcDriveLinkAttachmentV01Log_(result);
  return result;
}

function mcDriveLinkAttachmentV01BuildText_(items) {
  if (!items || !items.length) return '';
  var lines = ['[첨부/자료 링크]'];
  for (var i = 0; i < items.length; i++) {
    lines.push('- ' + items[i].fileName + ': ' + items[i].driveUrl + (items[i].description ? ' (' + items[i].description + ')' : ''));
  }
  return lines.join('\n');
}

function mcDriveLinkAttachmentV01BuildHtml_(items) {
  if (!items || !items.length) return '';
  var html = '<div style="margin-top:14px;padding:12px;border:1px solid #e5e7eb;border-radius:12px;background:#fafafa"><strong>[첨부파일 다운로드]</strong><ul style="margin:8px 0 0;padding-left:18px">';
  for (var i = 0; i < items.length; i++) {
    html += '<li><a style="font-weight:700;color:#1a73e8;text-decoration:none" href="' + mcDriveLinkAttachmentV01Escape_(items[i].driveUrl) + '" target="_blank" rel="noopener">' + mcDriveLinkAttachmentV01Escape_(items[i].fileName) + '</a>';
    if (items[i].description) html += ' - ' + mcDriveLinkAttachmentV01Escape_(items[i].description);
    html += '</li>';
  }
  html += '</ul></div>';
  return html;
}

function mcDriveLinkAttachmentV01AppendAttachment_(ss, item, meta) {
  var sh = ss.getSheetByName('MailCenter_Attachments');
  var headers = mcDriveLinkAttachmentV01Headers_(sh);
  var obj = {
    attachmentId: item.attachmentId || mcDriveLinkAttachmentV01NewId_('MCATT'),
    mailAccountId: meta.mailAccountId || '',
    toEmail: meta.toEmail || '',
    subject: meta.subject || '',
    fileName: item.fileName || '',
    driveUrl: item.driveUrl || '',
    description: item.description || '',
    attachmentType: item.attachmentType || 'DRIVE_LINK',
    attachmentStatus: meta.composeStatus || item.attachmentStatus || 'READY',
    gmailMessageId: meta.gmailMessageId || '',
    createdAt: mcDriveLinkAttachmentV01Now_(),
    createdBy: mcDriveLinkAttachmentV01User_()
  };
  sh.appendRow(headers.map(function(h) { return obj[h] !== undefined ? obj[h] : ''; }));
}

function mcDriveLinkAttachmentV01EnsureSheets_(ss) {
  mcDriveLinkAttachmentV01GetSheetOrCreate_(ss, 'MailCenter_Attachments', [
    'attachmentId','mailAccountId','toEmail','subject','fileName','driveUrl','description',
    'attachmentType','attachmentStatus','gmailMessageId','createdAt','createdBy'
  ]);
}

function mcDriveLinkAttachmentV01ReadRecent_(ss, sheetName, limit) {
  var sh = ss.getSheetByName(sheetName);
  if (!sh) return [];
  var values = sh.getDataRange().getValues();
  if (!values || values.length < 2) return [];
  var hm = mcDriveLinkAttachmentV01HeaderMap_(values[0]);
  var rows = [];
  var start = Math.max(1, values.length - Math.max(1, limit));
  for (var r = values.length - 1; r >= start; r--) {
    rows.push(mcDriveLinkAttachmentV01RowObject_(values[r], hm));
  }
  return rows;
}

function mcDriveLinkAttachmentV01GetSheetOrCreate_(ss, sheetName, headers) {
  var sh = ss.getSheetByName(sheetName);
  if (!sh) sh = ss.insertSheet(sheetName);
  var lastCol = sh.getLastColumn();
  if (lastCol < 1) {
    sh.getRange(1, 1, 1, headers.length).setValues([headers]);
    return sh;
  }
  var existing = sh.getRange(1, 1, 1, lastCol).getValues()[0].map(function(v) { return String(v || '').trim(); });
  var append = [];
  headers.forEach(function(h) { if (existing.indexOf(h) < 0) append.push(h); });
  if (append.length) sh.getRange(1, existing.length + 1, 1, append.length).setValues([append]);
  return sh;
}

function mcDriveLinkAttachmentV01OpenMaster_() {
  if (typeof portal19GetConfigBundle_ === 'function' && typeof portal19OpenMaster_ === 'function') {
    var bundle = portal19GetConfigBundle_();
    var ssByPortal = portal19OpenMaster_(bundle);
    if (ssByPortal) return { ss: ssByPortal, masterDbId: bundle.masterDbId || '' };
  }

  var setup = SpreadsheetApp.openById(MC_DRIVE_LINK_ATTACHMENT_V01_SETUP_DB_ID);
  var configSheet = setup.getSheetByName(MC_DRIVE_LINK_ATTACHMENT_V01_CONFIG_SHEET);
  if (!configSheet) throw new Error('SystemConfig 시트를 찾지 못했습니다.');

  var values = configSheet.getDataRange().getValues();
  var hm = mcDriveLinkAttachmentV01HeaderMap_(values[0]);
  var keyCol = mcDriveLinkAttachmentV01FindHeader_(hm, ['CONFIG_KEY','configKey','KEY','key']);
  var valCol = mcDriveLinkAttachmentV01FindHeader_(hm, ['VALUE','CONFIG_VALUE','configValue','value']);

  var masterId = '';
  for (var r = 1; r < values.length; r++) {
    var key = String(values[r][keyCol] || '').trim();
    if (key === 'FEELHAUS_DB_MASTER' || key === 'FEELHAUS_DB_MASTER_ID' || key === 'MASTER_DB_ID') {
      masterId = String(values[r][valCol] || '').trim();
      break;
    }
  }
  if (!masterId) throw new Error('SystemConfig에서 FEELHAUS_DB_MASTER ID를 찾지 못했습니다.');
  return { ss: SpreadsheetApp.openById(masterId), masterDbId: masterId };
}

function mcDriveLinkAttachmentV01Headers_(sh) {
  return sh.getRange(1, 1, 1, sh.getLastColumn()).getValues()[0].map(function(h) { return String(h || '').trim(); });
}

function mcDriveLinkAttachmentV01HeaderMap_(header) {
  var hm = {};
  for (var i = 0; i < header.length; i++) {
    var raw = String(header[i] || '').trim();
    if (!raw) continue;
    hm[raw] = i;
    var norm = mcDriveLinkAttachmentV01Normalize_(raw);
    if (hm[norm] == null) hm[norm] = i;
  }
  return hm;
}

function mcDriveLinkAttachmentV01FindHeader_(hm, names) {
  for (var i = 0; i < names.length; i++) {
    if (hm[names[i]] != null) return hm[names[i]];
    var norm = mcDriveLinkAttachmentV01Normalize_(names[i]);
    if (hm[norm] != null) return hm[norm];
  }
  return -1;
}

function mcDriveLinkAttachmentV01RowObject_(row, hm) {
  var obj = {};
  Object.keys(hm).forEach(function(k) {
    if (k === mcDriveLinkAttachmentV01Normalize_(k)) return;
    var val = row[hm[k]];
    obj[k] = val instanceof Date
      ? Utilities.formatDate(val, Session.getScriptTimeZone() || 'Asia/Seoul', 'yyyy-MM-dd HH:mm:ss')
      : val;
  });
  return obj;
}

function mcDriveLinkAttachmentV01Normalize_(v) {
  return String(v || '').trim().toUpperCase().replace(/[^A-Z0-9]/g, '');
}

function mcDriveLinkAttachmentV01Escape_(v) {
  return String(v || '').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/'/g,'&#039;');
}

function mcDriveLinkAttachmentV01NewId_(prefix) {
  return prefix + '-' + Utilities.formatDate(new Date(), Session.getScriptTimeZone() || 'Asia/Seoul', 'yyyyMMddHHmmss') + '-' + Math.floor(Math.random() * 9000 + 1000);
}

function mcDriveLinkAttachmentV01User_() {
  try { return Session.getActiveUser().getEmail() || ''; } catch (e) { return ''; }
}

function mcDriveLinkAttachmentV01Now_() {
  return Utilities.formatDate(new Date(), Session.getScriptTimeZone() || 'Asia/Seoul', 'yyyy-MM-dd HH:mm:ss');
}

function mcDriveLinkAttachmentV01Safe_(obj) {
  try {
    return JSON.parse(JSON.stringify(obj));
  } catch (e) {
    return {
      ok: false,
      build: MC_DRIVE_LINK_ATTACHMENT_V01_BUILD,
      action: 'mcDriveLinkAttachmentV01Safe_',
      generatedAt: mcDriveLinkAttachmentV01Now_(),
      message: String(e && e.message ? e.message : e)
    };
  }
}

function mcDriveLinkAttachmentV01Log_(obj) {
  try {
    Logger.log('JSON_COMPACT_RESULT: ' + JSON.stringify(obj));
  } catch (e) {
    Logger.log(obj);
  }
}
