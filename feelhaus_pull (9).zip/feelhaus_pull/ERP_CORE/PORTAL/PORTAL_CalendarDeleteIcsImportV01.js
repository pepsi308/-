/**
 * PORTAL_CALENDAR_CONTENT_NORMALIZE_NAV_YEAR_V05_BATCHID_SYNC_20260602_SAFETY_HARDENING_V04_COMPAT
 * Purpose:
 * 1) Calendar hard delete: remove PORTAL ledger row and linked Google event when present.
 * 2) NAVER ICS backup import: import exported .ics VEVENTs into MAILCENTER_CalendarEvents using FEELHAUS header-map rules.
 * Safety notes:
 * - This is an explicit hard delete flow. It requires a UI button confirmation token, not text typing.
 * - Google delete is supported through CalendarApp when a googleProviderEventId/googleEventId exists.
 * - NAVER delete is NOT attempted. NAVER Login Calendar API official docs expose createSchedule.json only in this project scope; NAVER is create-only in current PORTAL policy.
 * - Delete/import actions write audit/import logs. ICS import V03 stores per-batch snapshots so a bad upload can be rolled back by batchId.
 */
var PORTAL_CALENDAR_DELETE_ICS_IMPORT_V01_BUILD = 'PORTAL_CALENDAR_CONTENT_NORMALIZE_NAV_YEAR_V05_BATCHID_SYNC_20260602_SAFETY_HARDENING_V04_COMPAT';

function portalCalendarHardDeleteV01(request) {
  request = request || {};
  var result = {
    ok: false,
    build: PORTAL_CALENDAR_DELETE_ICS_IMPORT_V01_BUILD,
    action: 'portalCalendarHardDeleteV01',
    safety: 'HARD_DELETE_REQUIRES_BUTTON_CONFIRM_GOOGLE_DELETE_SUPPORTED_NAVER_DELETE_SKIPPED',
    calendarEventId: String(request.calendarEventId || '').trim(),
    actualDeleteExecuted: false,
    googleDeleteExecuted: false,
    naverDeleteExecuted: false,
    details: [],
    fatal: [],
    warnings: [],
    generatedAt: portalCalendarDeleteIcsV01Now_()
  };
  try {
    if (!result.calendarEventId) throw new Error('calendarEventId가 필요합니다.');
    if (String(request.confirmButtonToken || '').trim() !== 'HARD_DELETE_BUTTON_CONFIRMED_V02') throw new Error('완전삭제 버튼 확인이 필요합니다. 삭제 경고창에서 삭제 실행 버튼을 눌러주세요.');

    var configBundle = mcCalendar19GetConfigBundle_();
    var deletePolicy = portalCalendarIcsSafetyPolicyV04_(request, configBundle);
    result.policy = deletePolicy.publicSummary;
    if (!deletePolicy.hardDeleteGoogleSync) request.deleteGoogle = 'N';
    var profile = mcCalendar186ResolveCalendarActor_(request, configBundle, { allowFallback: true });
    var actorKey = portalCalendarDeleteIcsV01ActorKey_(profile);
    var ss = mcCalendar19OpenMaster_(configBundle);
    var headers = portalCalendarDeleteIcsV01EventHeaders_();
    var sheet = mcCalendar19GetSheetOrCreate_(ss, 'MAILCENTER_CalendarEvents', headers);
    var found = portalCalendarDeleteIcsV01FindRowById_(sheet, result.calendarEventId);
    if (!found.found) throw new Error('삭제 대상 일정을 찾지 못했습니다: ' + result.calendarEventId);
    var record = found.record;

    var googleDelete = portalCalendarDeleteIcsV01DeleteGoogleIfLinked_(configBundle, profile, record, request);
    result.details.push(googleDelete);
    result.googleDeleteExecuted = googleDelete.executed === true;
    if (!googleDelete.ok && String(request.strictExternalDelete || '').toUpperCase() === 'Y') {
      throw new Error('Google 일정 삭제 실패로 PORTAL 완전삭제를 중단합니다: ' + (googleDelete.message || googleDelete.errorMessage || ''));
    }

    var naverDelete = portalCalendarDeleteIcsV01NaverDeleteSkipped_(record);
    result.details.push(naverDelete);

    portalCalendarDeleteIcsV01AppendDeletedLog_(ss, {
      calendarEventId: result.calendarEventId,
      eventTitle: record.eventTitle || record.title || '',
      deleteType: 'HARD_DELETE',
      googleDeleteStatus: googleDelete.status || '',
      googleProviderEventId: googleDelete.providerEventId || '',
      naverDeleteStatus: naverDelete.status || '',
      naverProviderEventId: naverDelete.providerEventId || '',
      recordSnapshot: record,
      externalDeleteResults: result.details,
      createdAt: portalCalendarDeleteIcsV01Now_(),
      createdBy: actorKey
    });

    portalCalendarDeleteIcsV01DeleteRetryRows_(ss, result.calendarEventId);
    sheet.deleteRow(found.rowNumber);
    result.actualDeleteExecuted = true;
    result.ok = true;
    result.message = 'PORTAL 일정 완전삭제 완료. Google 연동 일정은 가능한 경우 함께 삭제했고, NAVER는 현재 정책상 자동 삭제를 지원하지 않아 건너뛰었습니다.';
    try { mcCalendar19AppendAuditLog_('PORTAL_CALENDAR_HARD_DELETE', actorKey, result.calendarEventId, 'SUCCESS', result.message, { details: result.details }); } catch (ignore) {}
  } catch (err) {
    result.ok = false;
    result.fatal.push(err && err.stack ? String(err.stack) : String(err && err.message ? err.message : err));
    result.message = err && err.message ? err.message : String(err);
    try { mcCalendar19AppendAuditLog_('PORTAL_CALENDAR_HARD_DELETE', '', result.calendarEventId, 'FAIL', result.message, {}); } catch (ignore2) {}
  }
  try { Logger.log('JSON_COMPACT_RESULT: ' + JSON.stringify(result)); } catch (ignore3) {}
  return mcCalendar19ClientSafeObject_(result);
}

function portalCalendarDeleteIcsV01DeleteGoogleIfLinked_(configBundle, profile, record, request) {
  var out = { provider: 'GOOGLE', action: 'DELETE_LINKED_GOOGLE_EVENT', ok: true, executed: false, status: 'SKIPPED', providerEventId: '', message: '' };
  try {
    var googleProviderEventId = portalCalendarDeleteIcsV01PickFirst_(record, ['googleProviderEventId','googleEventId','googleCalendarEventId','providerEventId']);
    out.providerEventId = googleProviderEventId;
    var googleStatus = String(record.googleBackupStatus || record.googleSyncStatus || '').toUpperCase();
    if (!googleProviderEventId) {
      out.message = '연결된 Google providerEventId가 없어 Google 삭제를 건너뜀';
      return out;
    }
    if (String(request.deleteGoogle || 'Y').toUpperCase() === 'N') {
      out.message = '요청 옵션에 따라 Google 삭제를 건너뜀';
      return out;
    }
    var providerPolicy = portalCalendarExternalAutoSyncV06ResolvePolicy_(configBundle, profile, record, request || {});
    var calendarId = providerPolicy && providerPolicy.googleCalendarId ? String(providerPolicy.googleCalendarId) : String(record.googleCalendarId || '');
    var cal = calendarId ? CalendarApp.getCalendarById(calendarId) : CalendarApp.getDefaultCalendar();
    if (!cal) throw new Error('Google 캘린더를 찾지 못했습니다: ' + calendarId);
    var event = cal.getEventById(googleProviderEventId);
    if (!event) {
      out.ok = true;
      out.executed = false;
      out.status = 'NOT_FOUND_ALREADY_GONE';
      out.message = 'Google 일정이 이미 없거나 providerEventId로 찾지 못했습니다.';
      return out;
    }
    event.deleteEvent();
    out.executed = true;
    out.status = 'DELETE_SUCCESS';
    out.googleCalendarId = calendarId;
    out.googleBackupStatusBefore = googleStatus;
    out.message = 'Google Calendar 연결 일정 삭제 완료';
    return out;
  } catch (err) {
    out.ok = false;
    out.status = 'DELETE_FAIL';
    out.errorMessage = err && err.message ? err.message : String(err);
    out.message = out.errorMessage;
    return out;
  }
}

function portalCalendarDeleteIcsV01NaverDeleteSkipped_(record) {
  var providerEventId = portalCalendarDeleteIcsV01PickFirst_(record || {}, ['naverProviderEventId','naverEventId','naverIcalUid','providerEventId']);
  return {
    provider: 'NAVER',
    action: 'SKIP_NAVER_DELETE_UNSUPPORTED_CREATE_ONLY_POLICY',
    ok: true,
    executed: false,
    status: 'SKIPPED_UNSUPPORTED',
    providerEventId: providerEventId,
    message: 'NAVER는 현재 CREATE_ONLY 정책입니다. 자동 삭제 API는 이 빌드에서 호출하지 않습니다. 필요 시 네이버 화면에서 직접 삭제하세요.'
  };
}

function portalCalendarNaverIcsImportV01(request) {
  request = request || {};
  var result = {
    ok: false,
    build: PORTAL_CALENDAR_DELETE_ICS_IMPORT_V01_BUILD,
    action: 'portalCalendarNaverIcsImportV01',
    safety: 'NAVER_ICS_IMPORT_TO_PORTAL_LEDGER_NO_NAVER_WRITE_NO_GOOGLE_WRITE_BY_DEFAULT',
    dryRun: String(request.dryRun || 'Y').toUpperCase() !== 'N',
    sourceName: String(request.sourceName || 'NAVER_ICS_BACKUP').trim() || 'NAVER_ICS_BACKUP',
    batchId: String(request.batchId || '').trim() || ('NICS-' + Utilities.formatDate(new Date(), Session.getScriptTimeZone() || 'Asia/Seoul', 'yyyyMMddHHmmss') + '-' + Utilities.getUuid().substring(0, 8).toUpperCase()),
    summary: { total: 0, insert: 0, update: 0, same: 0, skip: 0, failed: 0, uidMissing: 0, changed: 0, rruleBlocked: 0, longWarn: 0, longBlocked: 0, uidlessReview: 0, timezoneWarnings: 0, reviewOnly: 0 },
    details: [],
    fatal: [],
    warnings: [],
    generatedAt: portalCalendarDeleteIcsV01Now_()
  };
  try {
    var icsText = String(request.icsText || '').trim();
    if (!icsText) throw new Error('ICS 파일 내용이 비어 있습니다.');
    if (icsText.length > 4 * 1024 * 1024) throw new Error('ICS 파일이 너무 큽니다. 4MB 이하 파일부터 나눠서 가져오세요.');
    var configBundle = mcCalendar19GetConfigBundle_();
    var safetyPolicy = portalCalendarIcsSafetyPolicyV04_(request, configBundle);
    result.policy = safetyPolicy.publicSummary;
    if (!result.dryRun && safetyPolicy.requireDryRun && String(request.dryRunApprovalToken || '').trim() !== 'ICS_DRY_RUN_APPROVED_V04') {
      throw new Error('ICS 실제 가져오기는 DRY RUN 확인 후에만 실행할 수 있습니다. 먼저 DRY RUN을 실행하세요.');
    }
    var profile = mcCalendar186ResolveCalendarActor_(request, configBundle, { allowFallback: true });
    var actorKey = portalCalendarDeleteIcsV01ActorKey_(profile);
    var ss = mcCalendar19OpenMaster_(configBundle);
    var sheet = mcCalendar19GetSheetOrCreate_(ss, 'MAILCENTER_CalendarEvents', portalCalendarDeleteIcsV01EventHeaders_());
    portalCalendarDeleteIcsV01EnsureImportLogSheet_(ss);
    if (!result.dryRun && portalCalendarIcsBatchAlreadyExecutedV04_(ss, result.batchId)) {
      throw new Error('이미 실제 반영된 importBatchId입니다. 같은 batchId 중복 실행을 차단했습니다: ' + result.batchId);
    }

    var parsed = portalCalendarIcsParseEventsV01_(icsText, request);
    result.summary.total = parsed.length;
    if (!parsed.length) throw new Error('ICS 안에서 VEVENT 일정을 찾지 못했습니다.');

    var maxRows = Number(request.maxRows || safetyPolicy.maxEventsPerFile || 300);
    if (parsed.length > maxRows) throw new Error('가져오기 대상이 너무 많습니다. 현재 제한: ' + maxRows + '건, 파일: ' + parsed.length + '건');

    for (var i = 0; i < parsed.length; i++) {
      var normalized = null;
      try {
        normalized = portalCalendarIcsNormalizeEventV01_(parsed[i], profile, request, result.sourceName);
        if (normalized.uidWasMissing) result.summary.uidMissing++;
        var guard = portalCalendarIcsGuardEventV04_(normalized, parsed[i], request, safetyPolicy);
        portalCalendarIcsApplyGuardSummaryV04_(result, guard);
        if (guard.skip) {
          result.summary.skip++;
          if (guard.reason === 'UIDLESS_REVIEW_ONLY') result.summary.uidlessReview++;
          result.details.push({ index: i + 1, action: 'SKIPPED_' + guard.reason, ok: true, eventTitle: normalized.eventTitle, startAt: normalized.startAt, endAt: normalized.endAt, externalEventId: normalized.externalEventId, warnings: guard.warnings, message: guard.message, displayPreview: portalCalendarIcsDisplayPreviewV05_(normalized) });
          if (!result.dryRun) {
            portalCalendarIcsAppendImportLogV01_(ss, result.batchId, result.sourceName, normalized, '', 'SKIPPED', 'SUCCESS', guard.message, parsed[i], actorKey, { changedFields: [], guard: guard });
          }
          continue;
        }
        var existing = portalCalendarIcsFindExistingV01_(sheet, normalized);
        var action = existing.found ? 'UPDATE' : 'INSERT';
        var updates = existing.found ? portalCalendarIcsBuildSafeUpdateV03_(normalized, profile, existing.record, result.batchId) : null;
        var changed = existing.found ? portalCalendarIcsDiffFieldsV03_(existing.record, updates) : [];
        if (existing.found && !changed.length) action = 'SAME';
        if (result.dryRun) {
          result.summary[action === 'UPDATE' ? 'update' : (action === 'INSERT' ? 'insert' : 'same')]++;
          if (action === 'UPDATE') { result.summary.changed++; }
          result.details.push({ index: i + 1, action: 'DRY_RUN_' + action, calendarEventId: existing.found ? (existing.record.calendarEventId || '') : '', eventTitle: normalized.eventTitle, startAt: normalized.startAt, endAt: normalized.endAt, externalEventId: normalized.externalEventId, uidWasMissing: normalized.uidWasMissing === true, durationHours: normalized.durationHours, durationDays: normalized.durationDays, warnings: guard.warnings, changedFields: changed.slice(0, 30), displayPreview: portalCalendarIcsDisplayPreviewV05_(normalized) });
        } else if (existing.found) {
          var beforeSnapshot = portalCalendarIcsSnapshotV03_(existing.record);
          if (action === 'SAME') {
            portalCalendarIcsAppendImportLogV01_(ss, result.batchId, result.sourceName, normalized, existing.record.calendarEventId || '', 'SAME', 'SUCCESS', '동일 일정: 변경 없음', parsed[i], actorKey, { previousSnapshot: beforeSnapshot, changedFields: [] });
            result.summary.same++;
            result.details.push({ index: i + 1, action: 'SAME', calendarEventId: existing.record.calendarEventId || '', eventTitle: normalized.eventTitle, externalEventId: normalized.externalEventId, displayPreview: portalCalendarIcsDisplayPreviewV05_(normalized) });
          } else {
            portalCalendarDeleteIcsV01SetRowValuesByHeader_(sheet, existing.rowNumber, updates);
            var afterRecord = portalCalendarIcsMergeSnapshotV03_(existing.record, updates);
            portalCalendarIcsAppendImportLogV01_(ss, result.batchId, result.sourceName, normalized, existing.record.calendarEventId || '', 'UPDATE', 'SUCCESS', 'ICS 기존 일정 갱신', parsed[i], actorKey, { previousSnapshot: beforeSnapshot, afterSnapshot: portalCalendarIcsSnapshotV03_(afterRecord), changedFields: changed });
            result.summary.update++;
            result.summary.changed++;
            result.details.push({ index: i + 1, action: 'UPDATE', calendarEventId: existing.record.calendarEventId || '', eventTitle: normalized.eventTitle, externalEventId: normalized.externalEventId, changedFields: changed.slice(0, 30), displayPreview: portalCalendarIcsDisplayPreviewV05_(normalized) });
          }
        } else {
          var record = portalCalendarIcsBuildRecordV01_(normalized, profile, result.batchId);
          portalCalendarDeleteIcsV01AppendByHeader_(sheet, record, portalCalendarDeleteIcsV01EventHeaders_());
          portalCalendarIcsAppendImportLogV01_(ss, result.batchId, result.sourceName, normalized, record.calendarEventId, 'INSERT', 'SUCCESS', 'ICS 신규 일정 생성', parsed[i], actorKey, { afterSnapshot: portalCalendarIcsSnapshotV03_(record), changedFields: [] });
          result.summary.insert++;
          result.details.push({ index: i + 1, action: 'INSERT', calendarEventId: record.calendarEventId, eventTitle: normalized.eventTitle, externalEventId: normalized.externalEventId, uidWasMissing: normalized.uidWasMissing === true, displayPreview: portalCalendarIcsDisplayPreviewV05_(normalized) });
        }
      } catch (rowErr) {
        result.summary.failed++;
        var msg = rowErr && rowErr.message ? rowErr.message : String(rowErr);
        result.details.push({ index: i + 1, action: 'ERROR', ok: false, message: msg, rawSummary: parsed[i] && parsed[i].summary || '' });
        if (!result.dryRun) {
          try { portalCalendarIcsAppendImportLogV01_(ss, result.batchId, result.sourceName, normalized || { externalCalendarId:'', externalEventId:'' }, '', 'ERROR', 'FAIL', msg, parsed[i], actorKey); } catch (ignore) {}
        }
      }
    }
    result.ok = result.summary.failed === 0;
    result.message = result.dryRun ? 'ICS DRY RUN 완료. 실제 저장 전 결과를 확인하세요.' : (result.ok ? 'NAVER ICS 일정 PORTAL 원장 가져오기 완료' : '일부 ICS 일정 가져오기 실패. 로그를 확인하세요.');
    try { mcCalendar19AppendAuditLog_('PORTAL_NAVER_ICS_IMPORT', actorKey, result.batchId, result.ok ? 'SUCCESS' : 'PARTIAL', result.message, { summary: result.summary, dryRun: result.dryRun }); } catch (ignore2) {}
  } catch (err) {
    result.ok = false;
    result.fatal.push(err && err.stack ? String(err.stack) : String(err && err.message ? err.message : err));
    result.message = err && err.message ? err.message : String(err);
  }
  try { Logger.log('JSON_COMPACT_RESULT: ' + JSON.stringify(result)); } catch (ignore3) {}
  return mcCalendar19ClientSafeObject_(result);
}

function portalCalendarIcsParseEventsV01_(icsText, request) {
  var text = String(icsText || '').replace(/^\uFEFF/, '').replace(/\r\n[ \t]/g, '').replace(/\n[ \t]/g, '').replace(/\r[ \t]/g, '');
  var lines = text.replace(/\r\n/g, '\n').replace(/\r/g, '\n').split('\n');
  var events = [];
  var current = null;
  for (var i = 0; i < lines.length; i++) {
    var line = String(lines[i] || '');
    if (!line) continue;
    var upper = line.toUpperCase();
    if (upper === 'BEGIN:VEVENT') { current = { props: {}, rawLines: [] }; continue; }
    if (upper === 'END:VEVENT') {
      if (current) events.push(portalCalendarIcsEventObjectV01_(current));
      current = null;
      continue;
    }
    if (!current) continue;
    current.rawLines.push(line);
    var parsed = portalCalendarIcsParseLineV01_(line);
    if (!parsed.name) continue;
    if (!current.props[parsed.name]) current.props[parsed.name] = [];
    current.props[parsed.name].push(parsed);
  }
  return events;
}

function portalCalendarIcsParseLineV01_(line) {
  var idx = line.indexOf(':');
  if (idx < 0) return { name: '', params: {}, value: '' };
  var left = line.substring(0, idx);
  var value = line.substring(idx + 1);
  var parts = left.split(';');
  var name = String(parts.shift() || '').toUpperCase();
  var params = {};
  parts.forEach(function(p) {
    var eq = p.indexOf('=');
    if (eq > 0) params[String(p.substring(0, eq)).toUpperCase()] = p.substring(eq + 1).replace(/^"|"$/g, '');
  });
  return { name: name, params: params, value: value };
}

function portalCalendarIcsEventObjectV01_(current) {
  function first_(name) {
    var arr = current.props[name] || [];
    return arr.length ? arr[0] : { value: '', params: {} };
  }
  function all_(name) {
    return (current.props[name] || []).map(function(x) { return portalCalendarIcsUnescapeTextV01_(x.value || ''); }).filter(function(x) { return !!x; });
  }
  function allPerson_(name) {
    return (current.props[name] || []).map(function(x) { return portalCalendarIcsFormatPersonV05_(x); }).filter(function(x) { return !!x; });
  }
  return {
    uid: portalCalendarIcsUnescapeTextV01_(first_('UID').value || ''),
    summary: portalCalendarIcsUnescapeTextV01_(first_('SUMMARY').value || ''),
    description: portalCalendarIcsUnescapeTextV01_(first_('DESCRIPTION').value || ''),
    location: portalCalendarIcsUnescapeTextV01_(first_('LOCATION').value || ''),
    status: portalCalendarIcsUnescapeTextV01_(first_('STATUS').value || ''),
    dtstart: first_('DTSTART'),
    dtend: first_('DTEND'),
    created: portalCalendarIcsUnescapeTextV01_(first_('CREATED').value || ''),
    lastModified: portalCalendarIcsUnescapeTextV01_(first_('LAST-MODIFIED').value || ''),
    attendees: allPerson_('ATTENDEE').join(', ') || all_('ATTENDEE').join(', '),
    attendeeRaw: all_('ATTENDEE').join(' | '),
    organizer: portalCalendarIcsFormatPersonV05_(first_('ORGANIZER')),
    organizerRaw: portalCalendarIcsUnescapeTextV01_(first_('ORGANIZER').value || ''),
    categories: all_('CATEGORIES').join(', '),
    rrule: portalCalendarIcsUnescapeTextV01_(first_('RRULE').value || ''),
    recurrenceId: portalCalendarIcsUnescapeTextV01_(first_('RECURRENCE-ID').value || ''),
    rawLines: current.rawLines || []
  };
}

function portalCalendarIcsNormalizeEventV01_(eventObj, profile, request, sourceName) {
  eventObj = eventObj || {};
  var title = String(eventObj.summary || '').trim() || '(제목 없음)';
  var startParsed = portalCalendarIcsParseDateValueV01_(eventObj.dtstart);
  var endParsed = portalCalendarIcsParseDateValueV01_(eventObj.dtend);
  if (!startParsed.date) throw new Error('시작 일시가 없는 ICS 일정입니다: ' + title);
  var dtendMissing = !endParsed.date;
  if (!endParsed.date) {
    endParsed.date = new Date(startParsed.date.getTime() + (startParsed.allDay ? 24 * 60 * 60000 : 30 * 60000));
    endParsed.allDay = startParsed.allDay;
  }
  if (endParsed.date.getTime() <= startParsed.date.getTime()) throw new Error('시작일시가 종료일시보다 같거나 늦은 ICS 일정입니다: ' + title);
  var durationMillis = endParsed.date.getTime() - startParsed.date.getTime();
  var durationHours = Math.round((durationMillis / 3600000) * 100) / 100;
  var durationDays = Math.max(1, Math.ceil(durationMillis / 86400000));
  var rawText = (eventObj.rawLines || []).join('\n');
  var hasRRule = !!String(eventObj.rrule || '').trim() || /(^|\n)RRULE[:;]/i.test(rawText);
  var originalUid = String(eventObj.uid || '').trim();
  var uidWasMissing = !originalUid;
  var uid = originalUid;
  if (!uid) {
    uid = 'NAVER-ICS-DERIVED-' + Utilities.base64EncodeWebSafe([title, startParsed.date.getTime(), endParsed.date.getTime(), eventObj.location || ''].join('|')).substring(0, 32);
  }
  var status = String(eventObj.status || '').toUpperCase();
  var canceled = status === 'CANCELLED' || status === 'CANCELED' || status === 'DELETED';
  var externalCalendarId = String(request.naverCalendarId || request.externalCalendarId || 'NAVER_ICS_BACKUP').trim();
  var out = {
    sourceName: sourceName || 'NAVER_ICS_BACKUP',
    externalCalendarId: externalCalendarId,
    externalEventId: uid,
    sourceUid: uid,
    uidWasMissing: uidWasMissing,
    fingerprint: Utilities.base64EncodeWebSafe([title, startParsed.date.getTime(), endParsed.date.getTime(), eventObj.location || ''].join('|')).substring(0, 40),
    eventTitle: title,
    eventDescription: String(eventObj.description || '').trim(),
    startAt: portalCalendarDeleteIcsV01FormatDate_(startParsed.date),
    endAt: portalCalendarDeleteIcsV01FormatDate_(endParsed.date),
    allDayYn: startParsed.allDay ? 'Y' : 'N',
    location: String(eventObj.location || '').trim(),
    attendees: String(eventObj.attendees || '').trim(),
    eventStatus: canceled ? 'CANCELLED' : 'SCHEDULED',
    externalUpdatedAt: eventObj.lastModified || eventObj.created || '',
    externalCreatedAt: eventObj.created || '',
    externalLastModifiedAt: eventObj.lastModified || '',
    categories: eventObj.categories || '',
    organizer: eventObj.organizer || '',
    attendeeRaw: eventObj.attendeeRaw || '',
    originalSummary: eventObj.summary || '',
    originalDescription: eventObj.description || '',
    originalLocation: eventObj.location || '',
    originalAttendees: eventObj.attendees || '',
    originalOrganizer: eventObj.organizer || '',
    originalCategories: eventObj.categories || '',
    originalStatus: eventObj.status || '',
    originalRawText: rawText.substring(0, 15000),
    rrule: eventObj.rrule || '',
    recurrenceId: eventObj.recurrenceId || '',
    hasRRule: hasRRule,
    durationHours: durationHours,
    durationDays: durationDays,
    isLongPeriod: durationHours > 24,
    dtendMissing: dtendMissing,
    timezoneMissing: startParsed.timezoneMissing === true || endParsed.timezoneMissing === true,
    startTimezone: startParsed.tzid || '',
    endTimezone: endParsed.tzid || ''
  };
  out.displayTitle = out.eventTitle;
  out.displayDateTime = out.startAt + ' ~ ' + out.endAt;
  out.displayLocation = out.location;
  out.displayAttendees = out.attendees;
  out.displaySource = 'NAVER ICS';
  out.displayBody = portalCalendarIcsDisplayBodyV05_(out);
  out.displayOriginalContent = portalCalendarIcsOriginalContentV05_(out);
  out.displayNotice = portalCalendarIcsDisplayNoticeV05_(out);
  return out;
}

function portalCalendarIcsParseDateValueV01_(prop) {
  prop = prop || { value: '', params: {} };
  var value = String(prop.value || '').trim();
  var params = prop.params || {};
  var tzid = String(params.TZID || '').trim();
  var allDay = String(params.VALUE || '').toUpperCase() === 'DATE' || /^\d{8}$/.test(value);
  if (!value) return { date: null, allDay: allDay, tzid: tzid, timezoneMissing: false };
  var mDate = value.match(/^(\d{4})(\d{2})(\d{2})$/);
  if (mDate) return { date: new Date(Number(mDate[1]), Number(mDate[2]) - 1, Number(mDate[3]), 0, 0, 0), allDay: true, tzid: tzid, timezoneMissing: false };
  var m = value.match(/^(\d{4})(\d{2})(\d{2})T(\d{2})(\d{2})(\d{2})?(Z)?$/);
  if (m) {
    if (m[7] === 'Z') return { date: new Date(Date.UTC(Number(m[1]), Number(m[2]) - 1, Number(m[3]), Number(m[4]), Number(m[5]), Number(m[6] || 0))), allDay: false, tzid: 'UTC', timezoneMissing: false };
    return { date: new Date(Number(m[1]), Number(m[2]) - 1, Number(m[3]), Number(m[4]), Number(m[5]), Number(m[6] || 0)), allDay: false, tzid: tzid || 'Asia/Seoul_ASSUMED', timezoneMissing: !tzid };
  }
  var d = new Date(value);
  return { date: isNaN(d.getTime()) ? null : d, allDay: allDay, tzid: tzid, timezoneMissing: !allDay && !tzid };
}

function portalCalendarIcsBuildRecordV01_(normalized, profile, batchId) {
  var now = portalCalendarDeleteIcsV01Now_();
  var id = 'CAL-NAVER-ICS-' + Utilities.formatDate(new Date(), Session.getScriptTimeZone() || 'Asia/Seoul', 'yyyyMMddHHmmss') + '-' + Utilities.getUuid().substring(0, 8).toUpperCase();
  return {
    calendarEventId: id,
    provider: 'NAVER_IMPORT_ICS',
    providerEventId: normalized.externalEventId,
    importBatchId: batchId || '',
    icsImportBatchId: batchId || '',
    importStatus: 'INSERT',
    icsRiskLevel: normalized.icsRiskLevel || '',
    icsImportWarnings: (normalized.icsImportWarnings || []).join(' | '),
    durationHours: normalized.durationHours || '',
    durationDays: normalized.durationDays || '',
    isLongPeriod: normalized.isLongPeriod ? 'Y' : 'N',
    sourceUid: normalized.sourceUid || normalized.externalEventId,
    sourceFingerprint: normalized.fingerprint || '',
    providerCalendarId: normalized.externalCalendarId,
    eventType: 'NAVER_IMPORT_ICS',
    eventTitle: normalized.eventTitle,
    title: normalized.eventTitle,
    eventDescription: portalCalendarIcsDescriptionV01_(normalized),
    description: portalCalendarIcsDescriptionV01_(normalized),
    displayTitle: normalized.displayTitle || normalized.eventTitle,
    displayDateTime: normalized.displayDateTime || (normalized.startAt + ' ~ ' + normalized.endAt),
    displayLocation: normalized.displayLocation || normalized.location,
    displayBody: normalized.displayBody || portalCalendarIcsDisplayBodyV05_(normalized),
    displaySource: normalized.displaySource || 'NAVER ICS',
    displayAttendees: normalized.displayAttendees || normalized.attendees,
    displayOriginalContent: normalized.displayOriginalContent || portalCalendarIcsOriginalContentV05_(normalized),
    displayNotice: normalized.displayNotice || portalCalendarIcsDisplayNoticeV05_(normalized),
    originalDescription: normalized.originalDescription || '',
    originalLocation: normalized.originalLocation || '',
    originalAttendees: normalized.originalAttendees || '',
    originalOrganizer: normalized.originalOrganizer || '',
    originalCategories: normalized.originalCategories || '',
    originalStatus: normalized.originalStatus || '',
    externalCreatedAt: normalized.externalCreatedAt || '',
    externalLastModifiedAt: normalized.externalLastModifiedAt || '',
    startAt: normalized.startAt,
    endAt: normalized.endAt,
    allDayYn: normalized.allDayYn,
    allDay: normalized.allDayYn,
    location: normalized.location,
    attendees: normalized.attendees,
    ownerEmployeeId: profile.employeeId || '',
    assignedEmployeeId: profile.employeeId || '',
    eventStatus: normalized.eventStatus,
    status: normalized.eventStatus,
    sourceType: 'NAVER_ICS_IMPORT',
    sourceName: normalized.sourceName,
    sourceWritePolicy: 'CALENDAR_ONLY',
    sourceUpdateStatus: 'IMPORTED_FROM_NAVER_ICS',
    syncTarget: 'NONE',
    googleBackupStatus: 'SKIPPED_IMPORT',
    googleSyncStatus: 'NOT_TARGET',
    googleProviderEventId: '',
    googleEventId: '',
    naverRegisterStatus: 'IMPORTED_ICS',
    naverSyncStatus: 'IMPORTED_ICS',
    naverProviderEventId: normalized.externalEventId,
    naverEventId: normalized.externalEventId,
    naverIcalUid: normalized.externalEventId,
    naverCalendarId: normalized.externalCalendarId,
    naverProviderCalendarId: normalized.externalCalendarId,
    lastSyncAt: now,
    createdAt: now,
    createdBy: profile.employeeId || profile.loginId || '',
    updatedAt: now,
    updatedBy: profile.employeeId || profile.loginId || ''
  };
}

function portalCalendarIcsBuildUpdateV01_(normalized, profile) {
  var now = portalCalendarDeleteIcsV01Now_();
  return {
    provider: 'NAVER_IMPORT_ICS',
    providerEventId: normalized.externalEventId,
    sourceUid: normalized.sourceUid || normalized.externalEventId,
    sourceFingerprint: normalized.fingerprint || '',
    providerCalendarId: normalized.externalCalendarId,
    eventType: 'NAVER_IMPORT_ICS',
    eventTitle: normalized.eventTitle,
    title: normalized.eventTitle,
    eventDescription: portalCalendarIcsDescriptionV01_(normalized),
    description: portalCalendarIcsDescriptionV01_(normalized),
    displayTitle: normalized.displayTitle || normalized.eventTitle,
    displayDateTime: normalized.displayDateTime || (normalized.startAt + ' ~ ' + normalized.endAt),
    displayLocation: normalized.displayLocation || normalized.location,
    displayBody: normalized.displayBody || portalCalendarIcsDisplayBodyV05_(normalized),
    displaySource: normalized.displaySource || 'NAVER ICS',
    displayAttendees: normalized.displayAttendees || normalized.attendees,
    displayOriginalContent: normalized.displayOriginalContent || portalCalendarIcsOriginalContentV05_(normalized),
    displayNotice: normalized.displayNotice || portalCalendarIcsDisplayNoticeV05_(normalized),
    originalDescription: normalized.originalDescription || '',
    originalLocation: normalized.originalLocation || '',
    originalAttendees: normalized.originalAttendees || '',
    originalOrganizer: normalized.originalOrganizer || '',
    originalCategories: normalized.originalCategories || '',
    originalStatus: normalized.originalStatus || '',
    externalCreatedAt: normalized.externalCreatedAt || '',
    externalLastModifiedAt: normalized.externalLastModifiedAt || '',
    startAt: normalized.startAt,
    endAt: normalized.endAt,
    allDayYn: normalized.allDayYn,
    allDay: normalized.allDayYn,
    location: normalized.location,
    attendees: normalized.attendees,
    eventStatus: normalized.eventStatus,
    status: normalized.eventStatus,
    sourceType: 'NAVER_ICS_IMPORT',
    sourceName: normalized.sourceName,
    sourceWritePolicy: 'CALENDAR_ONLY',
    sourceUpdateStatus: 'UPDATED_FROM_NAVER_ICS',
    syncTarget: 'NONE',
    googleBackupStatus: 'SKIPPED_IMPORT',
    googleSyncStatus: 'NOT_TARGET',
    naverRegisterStatus: 'IMPORTED_ICS',
    naverSyncStatus: 'IMPORTED_ICS',
    naverProviderEventId: normalized.externalEventId,
    naverEventId: normalized.externalEventId,
    naverIcalUid: normalized.externalEventId,
    naverCalendarId: normalized.externalCalendarId,
    naverProviderCalendarId: normalized.externalCalendarId,
    lastSyncAt: now,
    updatedAt: now,
    updatedBy: profile.employeeId || profile.loginId || ''
  };
}


function portalCalendarIcsBuildSafeUpdateV03_(normalized, profile, existingRecord, batchId) {
  var updates = portalCalendarIcsBuildUpdateV01_(normalized, profile);
  updates.importBatchId = updates.icsImportBatchId = batchId || updates.importBatchId || '';
  updates.importStatus = 'UPDATE';
  updates.icsRiskLevel = normalized.icsRiskLevel || '';
  updates.icsImportWarnings = (normalized.icsImportWarnings || []).join(' | ');
  updates.durationHours = normalized.durationHours || '';
  updates.durationDays = normalized.durationDays || '';
  updates.isLongPeriod = normalized.isLongPeriod ? 'Y' : 'N';
  updates.sourceUid = normalized.sourceUid || normalized.externalEventId;
  updates.sourceFingerprint = normalized.fingerprint || '';
  updates.provider = updates.provider || 'NAVER_IMPORT_ICS';
  var preserveBlank = ['eventDescription','description','location','attendees','displayBody','displayLocation','displayAttendees','displayOriginalContent','originalDescription','originalLocation','originalAttendees','originalOrganizer','originalCategories'];
  preserveBlank.forEach(function(k) {
    var v = updates[k];
    if ((v === null || v === undefined || String(v).trim() === '') && existingRecord && existingRecord.hasOwnProperty(k)) {
      delete updates[k];
    }
  });
  return updates;
}

function portalCalendarIcsDiffFieldsV03_(existingRecord, updates) {
  var out = [];
  existingRecord = existingRecord || {};
  Object.keys(updates || {}).forEach(function(k) {
    if (['updatedAt','updatedBy','lastSyncAt','importBatchId','icsImportBatchId','importStatus'].indexOf(k) >= 0) return;
    var before = existingRecord[k];
    var after = updates[k];
    if (String(before === null || before === undefined ? '' : before) !== String(after === null || after === undefined ? '' : after)) out.push(k);
  });
  return out;
}

function portalCalendarIcsSnapshotV03_(record) {
  var snap = {};
  record = record || {};
  Object.keys(record).forEach(function(k) {
    var v = record[k];
    if (v instanceof Date) v = portalCalendarDeleteIcsV01FormatDate_(v);
    snap[k] = (v === null || v === undefined) ? '' : v;
  });
  return snap;
}

function portalCalendarIcsMergeSnapshotV03_(record, updates) {
  var merged = portalCalendarIcsSnapshotV03_(record || {});
  Object.keys(updates || {}).forEach(function(k) { merged[k] = updates[k]; });
  return merged;
}

function portalCalendarIcsFindExistingV01_(sheet, normalized) {
  var data = sheet.getDataRange().getValues();
  var fallback = { found: false, rowNumber: -1, record: null };
  if (!data || data.length < 2) return fallback;
  var headers = data[0];
  for (var r = data.length - 1; r >= 1; r--) {
    var obj = portalCalendarDeleteIcsV01RowObject_(data[r], headers);
    var uid = portalCalendarDeleteIcsV01PickFirst_(obj, ['sourceUid','naverProviderEventId','naverEventId','naverIcalUid','providerEventId']);
    if (uid && uid === normalized.externalEventId) return { found: true, rowNumber: r + 1, record: obj };
    if (normalized.fingerprint && String(obj.sourceFingerprint || '') === String(normalized.fingerprint || '')) return { found: true, rowNumber: r + 1, record: obj };
    var sourceType = String(obj.sourceType || obj.provider || '').toUpperCase();
    if (sourceType.indexOf('NAVER') >= 0 && String(obj.eventTitle || obj.title || '') === normalized.eventTitle && String(obj.startAt || '') === normalized.startAt && String(obj.endAt || '') === normalized.endAt) {
      return { found: true, rowNumber: r + 1, record: obj };
    }
  }
  return fallback;
}

function portalCalendarIcsDescriptionV01_(normalized) {
  normalized = normalized || {};
  var body = String(normalized.displayBody || '').trim() || portalCalendarIcsDisplayBodyV05_(normalized);
  var meta = '[NAVER_ICS_IMPORT] source=' + normalized.sourceName + ' externalCalendarId=' + normalized.externalCalendarId + ' externalEventId=' + normalized.externalEventId + (normalized.externalUpdatedAt ? ' externalUpdatedAt=' + normalized.externalUpdatedAt : '') + (normalized.categories ? ' categories=' + normalized.categories : '');
  return body ? body + '\n\n' + meta : meta;
}

function portalCalendarIcsFormatPersonV05_(prop) {
  prop = prop || { value: '', params: {} };
  var params = prop.params || {};
  var value = portalCalendarIcsUnescapeTextV01_(prop.value || '').replace(/^MAILTO:/i, '').trim();
  var cn = portalCalendarIcsUnescapeTextV01_(params.CN || '').trim();
  var role = portalCalendarIcsUnescapeTextV01_(params.ROLE || '').trim();
  var partstat = portalCalendarIcsUnescapeTextV01_(params.PARTSTAT || '').trim();
  var out = cn && value && cn !== value ? (cn + ' <' + value + '>') : (cn || value);
  var tags = [];
  if (role) tags.push(role);
  if (partstat) tags.push(partstat);
  return out + (tags.length ? ' (' + tags.join('/') + ')' : '');
}

function portalCalendarIcsDisplayBodyV05_(normalized) {
  normalized = normalized || {};
  var lines = [];
  function add(label, value) {
    value = String(value || '').trim();
    if (value) lines.push('[' + label + ']\n' + value);
  }
  add('일정 내용', normalized.originalDescription || normalized.eventDescription || normalized.description || '');
  add('장소', normalized.originalLocation || normalized.location || '');
  add('참석자', normalized.originalAttendees || normalized.attendees || '');
  add('주최자', normalized.originalOrganizer || normalized.organizer || '');
  add('분류', normalized.originalCategories || normalized.categories || '');
  add('상태', normalized.originalStatus || normalized.eventStatus || '');
  add('원본', (normalized.sourceName || 'NAVER_ICS_BACKUP') + ' / ' + (normalized.externalEventId || ''));
  return lines.join('\n\n') || '[일정 내용]\n내용 없음';
}

function portalCalendarIcsOriginalContentV05_(normalized) {
  normalized = normalized || {};
  var lines = [];
  function add(label, value) {
    value = String(value || '').trim();
    if (value) lines.push(label + ': ' + value);
  }
  add('SUMMARY', normalized.originalSummary || normalized.eventTitle);
  add('DESCRIPTION', normalized.originalDescription || normalized.eventDescription);
  add('LOCATION', normalized.originalLocation || normalized.location);
  add('ATTENDEE', normalized.originalAttendees || normalized.attendees);
  add('ORGANIZER', normalized.originalOrganizer || normalized.organizer);
  add('CATEGORIES', normalized.originalCategories || normalized.categories);
  add('STATUS', normalized.originalStatus || normalized.eventStatus);
  add('CREATED', normalized.externalCreatedAt);
  add('LAST-MODIFIED', normalized.externalLastModifiedAt || normalized.externalUpdatedAt);
  add('UID', normalized.externalEventId || normalized.sourceUid);
  return lines.join('\n');
}

function portalCalendarIcsDisplayNoticeV05_(normalized) {
  normalized = normalized || {};
  var notices = [];
  notices.push('NAVER ICS에서 가져온 일정입니다. Google/NAVER 외부 캘린더에는 자동 재전송하지 않습니다.');
  if (normalized.hasRRule) notices.push('반복일정 RRULE은 자동 가져오기 차단 대상입니다.');
  if (normalized.isLongPeriod) notices.push('24시간 초과 기간 일정입니다. 월간 달력에는 시작일 기준 1건으로 표시합니다.');
  if (normalized.timezoneMissing) notices.push('시간대가 없어 Asia/Seoul 기준으로 보정했습니다.');
  return notices.join(' ');
}

function portalCalendarIcsDisplayPreviewV05_(normalized) {
  normalized = normalized || {};
  return {
    title: normalized.displayTitle || normalized.eventTitle || '',
    when: normalized.displayDateTime || ((normalized.startAt || '') + ' ~ ' + (normalized.endAt || '')),
    location: normalized.displayLocation || normalized.location || '',
    attendees: normalized.displayAttendees || normalized.attendees || '',
    source: normalized.displaySource || 'NAVER ICS',
    body: String(normalized.displayBody || portalCalendarIcsDisplayBodyV05_(normalized)).substring(0, 1200),
    originalContent: String(normalized.displayOriginalContent || portalCalendarIcsOriginalContentV05_(normalized)).substring(0, 1200),
    notice: normalized.displayNotice || portalCalendarIcsDisplayNoticeV05_(normalized)
  };
}

function portalCalendarIcsUnescapeTextV01_(value) {
  return String(value || '').replace(/\\n/gi, '\n').replace(/\\,/g, ',').replace(/\\;/g, ';').replace(/\\\\/g, '\\');
}

function portalCalendarIcsAppendImportLogV01_(ss, batchId, sourceName, normalized, calendarEventId, action, status, message, raw, actorKey, extra) {
  var headers = portalCalendarIcsImportLogHeadersV01_();
  var sheet = mcCalendar19GetSheetOrCreate_(ss, 'MAILCENTER_NaverIcsImportLogs', headers);
  extra = extra || {};
  portalCalendarDeleteIcsV01AppendByHeader_(sheet, {
    importLogId: 'NICSLOG-' + Utilities.getUuid(),
    batchId: batchId || '',
    sourceProvider: 'NAVER_ICS',
    sourceName: sourceName || 'NAVER_ICS_BACKUP',
    externalCalendarId: normalized && normalized.externalCalendarId || '',
    externalEventId: normalized && normalized.externalEventId || '',
    calendarEventId: calendarEventId || '',
    importAction: action || '',
    importStatus: status || '',
    message: message || '',
    changedFields: JSON.stringify(extra.changedFields || []).substring(0, 1500),
    previousSnapshot: JSON.stringify(extra.previousSnapshot || {}).substring(0, 50000),
    afterSnapshot: JSON.stringify(extra.afterSnapshot || {}).substring(0, 50000),
    rowPayloadSummary: JSON.stringify(raw || {}).substring(0, 5000),
    guardDecision: JSON.stringify(extra.guard || {}).substring(0, 2000),
    rollbackStatus: '',
    rollbackAt: '',
    rollbackBy: '',
    rollbackMessage: '',
    createdAt: portalCalendarDeleteIcsV01Now_(),
    createdBy: actorKey || ''
  }, headers);
}

function portalCalendarDeleteIcsV01AppendDeletedLog_(ss, log) {
  var headers = ['deleteLogId','build','calendarEventId','eventTitle','deleteType','googleDeleteStatus','googleProviderEventId','naverDeleteStatus','naverProviderEventId','recordSnapshot','externalDeleteResults','createdAt','createdBy'];
  var sheet = mcCalendar19GetSheetOrCreate_(ss, 'MAILCENTER_CalendarDeletedLogs', headers);
  portalCalendarDeleteIcsV01AppendByHeader_(sheet, {
    deleteLogId: 'CDEL-' + Utilities.getUuid(),
    build: PORTAL_CALENDAR_DELETE_ICS_IMPORT_V01_BUILD,
    calendarEventId: log.calendarEventId || '',
    eventTitle: log.eventTitle || '',
    deleteType: log.deleteType || 'HARD_DELETE',
    googleDeleteStatus: log.googleDeleteStatus || '',
    googleProviderEventId: log.googleProviderEventId || '',
    naverDeleteStatus: log.naverDeleteStatus || '',
    naverProviderEventId: log.naverProviderEventId || '',
    recordSnapshot: JSON.stringify(log.recordSnapshot || {}).substring(0, 15000),
    externalDeleteResults: JSON.stringify(log.externalDeleteResults || []).substring(0, 4000),
    createdAt: log.createdAt || portalCalendarDeleteIcsV01Now_(),
    createdBy: log.createdBy || ''
  }, headers);
}

function portalCalendarDeleteIcsV01DeleteRetryRows_(ss, calendarEventId) {
  try {
    var sheet = ss.getSheetByName('MAILCENTER_CalendarRetryQueue');
    if (!sheet) return 0;
    var data = sheet.getDataRange().getValues();
    if (!data || data.length < 2) return 0;
    var hm = mcCalendar19HeaderMap_(data[0]);
    if (hm.calendarEventId === undefined) return 0;
    var count = 0;
    for (var r = data.length - 1; r >= 1; r--) {
      if (String(data[r][hm.calendarEventId] || '') === String(calendarEventId || '')) {
        sheet.deleteRow(r + 1);
        count++;
      }
    }
    return count;
  } catch (ignore) { return 0; }
}

function portalCalendarDeleteIcsV01EnsureImportLogSheet_(ss) {
  mcCalendar19GetSheetOrCreate_(ss, 'MAILCENTER_NaverIcsImportLogs', portalCalendarIcsImportLogHeadersV01_());
}


function portalCalendarIcsConfigValueV04_(configBundle, key, fallback) {
  var cfg = configBundle && configBundle.config ? configBundle.config : {};
  var v = cfg[key];
  if (v === undefined) v = cfg[String(key || '').toLowerCase()];
  if (v === undefined) v = cfg[String(key || '').toUpperCase()];
  return (v === undefined || v === null || String(v).trim() === '') ? fallback : v;
}

function portalCalendarIcsBoolV04_(v, fallback) {
  if (v === undefined || v === null || String(v).trim() === '') return fallback;
  var s = String(v).trim().toUpperCase();
  if (['Y','YES','TRUE','ON','1'].indexOf(s) >= 0) return true;
  if (['N','NO','FALSE','OFF','0'].indexOf(s) >= 0) return false;
  return fallback;
}

function portalCalendarIcsSafetyPolicyV04_(request, configBundle) {
  request = request || {};
  var p = {
    mode: 'PORTAL_CALENDAR_SAFETY_HARDENING_V04',
    requireDryRun: portalCalendarIcsBoolV04_(portalCalendarIcsConfigValueV04_(configBundle, 'ICS_IMPORT_REQUIRE_DRY_RUN', 'Y'), true),
    blockRRule: portalCalendarIcsBoolV04_(portalCalendarIcsConfigValueV04_(configBundle, 'ICS_IMPORT_BLOCK_RRULE', 'Y'), true),
    warnLongHours: Number(portalCalendarIcsConfigValueV04_(configBundle, 'ICS_IMPORT_WARN_LONG_HOURS', 24) || 24),
    blockLongDays: Number(portalCalendarIcsConfigValueV04_(configBundle, 'ICS_IMPORT_BLOCK_LONG_DAYS', 7) || 7),
    maxEventsPerFile: Number(portalCalendarIcsConfigValueV04_(configBundle, 'ICS_IMPORT_MAX_EVENTS_PER_FILE', 300) || 300),
    allowUidless: String(portalCalendarIcsConfigValueV04_(configBundle, 'ICS_IMPORT_ALLOW_UIDLESS', 'REVIEW_ONLY') || 'REVIEW_ONLY').toUpperCase(),
    naverMode: String(portalCalendarIcsConfigValueV04_(configBundle, 'NAVER_CALENDAR_MODE', 'CREATE_ONLY') || 'CREATE_ONLY').toUpperCase(),
    hardDeleteGoogleSync: portalCalendarIcsBoolV04_(portalCalendarIcsConfigValueV04_(configBundle, 'CALENDAR_HARD_DELETE_GOOGLE_SYNC', 'Y'), true)
  };
  if (request.allowRRule === 'Y') p.blockRRule = false;
  if (request.allowUidless === 'Y') p.allowUidless = 'ALLOW';
  if (request.allowLongEvents === 'Y') p.blockLongDays = 99999;
  p.publicSummary = {
    requireDryRun: p.requireDryRun,
    blockRRule: p.blockRRule,
    warnLongHours: p.warnLongHours,
    blockLongDays: p.blockLongDays,
    maxEventsPerFile: p.maxEventsPerFile,
    allowUidless: p.allowUidless,
    naverMode: p.naverMode
  };
  return p;
}

function portalCalendarIcsGuardEventV04_(normalized, raw, request, policy) {
  policy = policy || portalCalendarIcsSafetyPolicyV04_(request || {}, null);
  var out = { skip: false, reason: '', message: '', warnings: [], riskLevel: 'NORMAL' };
  if (normalized.hasRRule && policy.blockRRule) {
    out.skip = true;
    out.reason = 'RRULE_BLOCKED';
    out.riskLevel = 'BLOCKED';
    out.message = '반복일정 RRULE은 자동 가져오기를 차단했습니다. 네이버/직원 반복일정은 수동 확인 후 단일 일정으로 등록하세요.';
  }
  if (normalized.uidWasMissing && policy.allowUidless !== 'ALLOW') {
    out.skip = true;
    out.reason = out.reason || 'UIDLESS_REVIEW_ONLY';
    out.riskLevel = 'REVIEW_ONLY';
    out.message = out.message || 'UID 없는 ICS 일정은 REVIEW_ONLY로 분류하고 실제 가져오기를 차단했습니다. 중복 위험이 있어 담당자 확인이 필요합니다.';
  }
  if (normalized.durationHours > policy.warnLongHours) {
    out.warnings.push('LONG_EVENT_OVER_' + policy.warnLongHours + '_HOURS');
    out.riskLevel = out.riskLevel === 'NORMAL' ? 'WARN' : out.riskLevel;
  }
  if (normalized.durationDays > policy.blockLongDays) {
    out.skip = true;
    out.reason = out.reason || 'LONG_EVENT_BLOCKED';
    out.riskLevel = 'BLOCKED';
    out.message = out.message || (policy.blockLongDays + '일 초과 기간 일정은 월간 화면 도배/운영오류 방지를 위해 자동 가져오기를 차단했습니다.');
  }
  if (normalized.timezoneMissing) {
    out.warnings.push('TIMEZONE_MISSING_ASSUMED_ASIA_SEOUL');
    out.riskLevel = out.riskLevel === 'NORMAL' ? 'WARN' : out.riskLevel;
  }
  if (!out.message && out.warnings.length) out.message = '주의 일정: ' + out.warnings.join(', ');
  normalized.icsRiskLevel = out.riskLevel;
  normalized.icsImportWarnings = out.warnings.slice(0);
  return out;
}

function portalCalendarIcsApplyGuardSummaryV04_(result, guard) {
  result = result || { summary: {} };
  var s = result.summary || (result.summary = {});
  if (!guard) return;
  if (guard.reason === 'RRULE_BLOCKED') s.rruleBlocked = Number(s.rruleBlocked || 0) + 1;
  if (guard.reason === 'LONG_EVENT_BLOCKED') s.longBlocked = Number(s.longBlocked || 0) + 1;
  if (guard.reason === 'UIDLESS_REVIEW_ONLY') { s.reviewOnly = Number(s.reviewOnly || 0) + 1; }
  (guard.warnings || []).forEach(function(w) {
    if (String(w).indexOf('LONG_EVENT') >= 0) s.longWarn = Number(s.longWarn || 0) + 1;
    if (String(w).indexOf('TIMEZONE') >= 0) s.timezoneWarnings = Number(s.timezoneWarnings || 0) + 1;
  });
}

function portalCalendarIcsBatchAlreadyExecutedV04_(ss, batchId) {
  if (!batchId) return false;
  var sheet = ss.getSheetByName('MAILCENTER_NaverIcsImportLogs');
  if (!sheet) return false;
  var data = sheet.getDataRange().getValues();
  if (!data || data.length < 2) return false;
  var headers = data[0];
  var hm = mcCalendar19HeaderMap_(headers);
  if (hm.batchId === undefined) return false;
  for (var r = 1; r < data.length; r++) {
    if (String(data[r][hm.batchId] || '') === String(batchId || '')) return true;
  }
  return false;
}

function portalCalendarIcsImportLogHeadersV01_() {
  return ['importLogId','batchId','sourceProvider','sourceName','externalCalendarId','externalEventId','calendarEventId','importAction','importStatus','message','changedFields','previousSnapshot','afterSnapshot','rowPayloadSummary','guardDecision','rollbackStatus','rollbackAt','rollbackBy','rollbackMessage','createdAt','createdBy'];
}

function portalCalendarDeleteIcsV01EventHeaders_() {
  var headers = [];
  try {
    if (typeof mcCalendarOperationHubV01CalendarHeaders_ === 'function') headers = mcCalendarOperationHubV01CalendarHeaders_();
  } catch (ignore) {}
  if (!headers || !headers.length) {
    try { if (typeof mcCalendar186CalendarEventHeaders_ === 'function') headers = mcCalendar186CalendarEventHeaders_(); } catch (ignore2) {}
  }
  var extra = ['title','description','status','sourceType','sourceName','sourceWritePolicy','sourceUpdateStatus','syncTarget','googleEventId','googleSyncStatus','naverEventId','naverIcalUid','naverCalendarId','naverSyncStatus','lastSyncAt','providerCalendarId','naverProviderCalendarId','importBatchId','icsImportBatchId','importStatus','sourceUid','sourceFingerprint','icsRiskLevel','icsImportWarnings','durationHours','durationDays','isLongPeriod','displayTitle','displayDateTime','displayLocation','displayBody','displaySource','displayAttendees','displayOriginalContent','displayNotice','originalDescription','originalLocation','originalAttendees','originalOrganizer','originalCategories','originalStatus','externalCreatedAt','externalLastModifiedAt'];
  var seen = {};
  (headers || []).concat(extra).forEach(function(h) { h = String(h || '').trim(); if (h && !seen[h]) { seen[h] = true; } });
  return Object.keys(seen);
}

function portalCalendarDeleteIcsV01FindRowById_(sheet, calendarEventId) {
  var data = sheet.getDataRange().getValues();
  if (!data || data.length < 2) return { found: false, rowNumber: -1, record: null };
  var headers = data[0];
  var hm = mcCalendar19HeaderMap_(headers);
  if (hm.calendarEventId === undefined) throw new Error('MAILCENTER_CalendarEvents에 calendarEventId 헤더가 없습니다.');
  for (var r = data.length - 1; r >= 1; r--) {
    if (String(data[r][hm.calendarEventId] || '') === String(calendarEventId || '')) {
      return { found: true, rowNumber: r + 1, record: portalCalendarDeleteIcsV01RowObject_(data[r], headers) };
    }
  }
  return { found: false, rowNumber: -1, record: null };
}

function portalCalendarDeleteIcsV01SetRowValuesByHeader_(sheet, rowNumber, updates) {
  var lastCol = sheet.getLastColumn();
  var headers = sheet.getRange(1, 1, 1, lastCol).getValues()[0];
  var hm = mcCalendar19HeaderMap_(headers);
  var row = sheet.getRange(rowNumber, 1, 1, lastCol).getValues()[0];
  Object.keys(updates || {}).forEach(function(k) {
    if (!hm.hasOwnProperty(k)) return;
    row[hm[k]] = updates[k];
  });
  sheet.getRange(rowNumber, 1, 1, lastCol).setValues([row]);
}

function portalCalendarDeleteIcsV01AppendByHeader_(sheet, obj, headers) {
  headers = headers || sheet.getRange(1, 1, 1, sheet.getLastColumn()).getValues()[0];
  var row = headers.map(function(h) { return obj.hasOwnProperty(h) ? obj[h] : ''; });
  sheet.appendRow(row);
}

function portalCalendarDeleteIcsV01RowObject_(row, headers) {
  var obj = {};
  for (var i = 0; i < headers.length; i++) obj[String(headers[i] || '').trim()] = row[i];
  return obj;
}

function portalCalendarDeleteIcsV01PickFirst_(obj, keys) {
  obj = obj || {};
  for (var i = 0; i < keys.length; i++) {
    var v = String(obj[keys[i]] === null || obj[keys[i]] === undefined ? '' : obj[keys[i]]).trim();
    if (v) return v;
  }
  return '';
}

function portalCalendarDeleteIcsV01ActorKey_(profile) {
  profile = profile || {};
  return String(profile.employeeId || profile.loginId || profile.email || 'PORTAL_USER').trim();
}

function portalCalendarDeleteIcsV01Now_() {
  return Utilities.formatDate(new Date(), Session.getScriptTimeZone() || 'Asia/Seoul', 'yyyy-MM-dd HH:mm:ss');
}

function portalCalendarDeleteIcsV01FormatDate_(dateObj) {
  return Utilities.formatDate(dateObj, Session.getScriptTimeZone() || 'Asia/Seoul', 'yyyy-MM-dd HH:mm:ss');
}


function portalCalendarNaverIcsRollbackV03(request) {
  request = request || {};
  var result = {
    ok: false,
    build: PORTAL_CALENDAR_DELETE_ICS_IMPORT_V01_BUILD,
    action: 'portalCalendarNaverIcsRollbackV03',
    safety: 'ROLLBACK_ONE_ICS_IMPORT_BATCH_PORTAL_ONLY_NO_GOOGLE_NO_NAVER_WRITE',
    batchId: String(request.batchId || '').trim(),
    actualRollbackExecuted: false,
    summary: { insertDeleted: 0, updateRestored: 0, sameSkipped: 0, errorSkipped: 0, missingRows: 0, failed: 0 },
    details: [],
    fatal: [],
    warnings: [],
    generatedAt: portalCalendarDeleteIcsV01Now_()
  };
  try {
    if (!result.batchId) throw new Error('rollback 대상 batchId가 필요합니다.');
    if (String(request.confirmButtonToken || '').trim() !== 'ICS_ROLLBACK_BUTTON_CONFIRMED_V03') throw new Error('ICS 업로드 취소 버튼 확인이 필요합니다.');
    var configBundle = mcCalendar19GetConfigBundle_();
    var safetyPolicy = portalCalendarIcsSafetyPolicyV04_(request, configBundle);
    result.policy = safetyPolicy.publicSummary;
    if (!result.dryRun && safetyPolicy.requireDryRun && String(request.dryRunApprovalToken || '').trim() !== 'ICS_DRY_RUN_APPROVED_V04') {
      throw new Error('ICS 실제 가져오기는 DRY RUN 확인 후에만 실행할 수 있습니다. 먼저 DRY RUN을 실행하세요.');
    }
    var profile = mcCalendar186ResolveCalendarActor_(request, configBundle, { allowFallback: true });
    var actorKey = portalCalendarDeleteIcsV01ActorKey_(profile);
    var ss = mcCalendar19OpenMaster_(configBundle);
    var eventSheet = mcCalendar19GetSheetOrCreate_(ss, 'MAILCENTER_CalendarEvents', portalCalendarDeleteIcsV01EventHeaders_());
    var logSheet = mcCalendar19GetSheetOrCreate_(ss, 'MAILCENTER_NaverIcsImportLogs', portalCalendarIcsImportLogHeadersV01_());
    var rows = portalCalendarIcsFindBatchLogsV03_(logSheet, result.batchId);
    if (!rows.length) throw new Error('해당 batchId의 ICS 가져오기 로그를 찾지 못했습니다: ' + result.batchId);
    for (var i = rows.length - 1; i >= 0; i--) {
      var item = rows[i];
      var log = item.record || {};
      var action = String(log.importAction || '').toUpperCase();
      var status = String(log.importStatus || '').toUpperCase();
      var calendarEventId = String(log.calendarEventId || '').trim();
      if (String(log.rollbackStatus || '').toUpperCase() === 'ROLLED_BACK') { result.summary.sameSkipped++; continue; }
      try {
        if (status !== 'SUCCESS') { result.summary.errorSkipped++; portalCalendarIcsMarkRollbackLogV03_(logSheet, item.rowNumber, 'SKIPPED_ERROR_LOG', actorKey, '실패 로그는 원장 반영이 없어 롤백 스킵'); continue; }
        if (action === 'INSERT') {
          var foundInsert = portalCalendarDeleteIcsV01FindRowById_(eventSheet, calendarEventId);
          if (foundInsert.found) {
            eventSheet.deleteRow(foundInsert.rowNumber);
            result.summary.insertDeleted++;
            portalCalendarIcsMarkRollbackLogV03_(logSheet, item.rowNumber, 'ROLLED_BACK', actorKey, 'INSERT 일정 완전삭제');
            result.details.push({ action: 'ROLLBACK_INSERT_DELETE', calendarEventId: calendarEventId });
          } else {
            result.summary.missingRows++;
            portalCalendarIcsMarkRollbackLogV03_(logSheet, item.rowNumber, 'ROW_MISSING_ALREADY_GONE', actorKey, 'INSERT 일정 row가 이미 없음');
            result.details.push({ action: 'ROW_MISSING_ALREADY_GONE', calendarEventId: calendarEventId });
          }
        } else if (action === 'UPDATE') {
          var prev = portalCalendarIcsParseSnapshotV03_(log.previousSnapshot);
          if (!prev || !Object.keys(prev).length) throw new Error('UPDATE 롤백용 previousSnapshot이 없습니다: ' + calendarEventId);
          var foundUpdate = portalCalendarDeleteIcsV01FindRowById_(eventSheet, calendarEventId);
          if (!foundUpdate.found) { result.summary.missingRows++; portalCalendarIcsMarkRollbackLogV03_(logSheet, item.rowNumber, 'ROW_MISSING_CANNOT_RESTORE', actorKey, 'UPDATE 대상 row가 없어 원복 불가'); continue; }
          portalCalendarIcsRestoreRowSnapshotV03_(eventSheet, foundUpdate.rowNumber, prev, actorKey);
          result.summary.updateRestored++;
          portalCalendarIcsMarkRollbackLogV03_(logSheet, item.rowNumber, 'ROLLED_BACK', actorKey, 'UPDATE 이전값 복구');
          result.details.push({ action: 'ROLLBACK_UPDATE_RESTORE', calendarEventId: calendarEventId });
        } else if (action === 'SAME') {
          result.summary.sameSkipped++;
          portalCalendarIcsMarkRollbackLogV03_(logSheet, item.rowNumber, 'SKIPPED_SAME', actorKey, '변경 없는 SAME 로그는 롤백 불필요');
        } else {
          result.summary.errorSkipped++;
          portalCalendarIcsMarkRollbackLogV03_(logSheet, item.rowNumber, 'SKIPPED_UNSUPPORTED_ACTION', actorKey, '지원하지 않는 importAction: ' + action);
        }
      } catch (rowErr) {
        result.summary.failed++;
        var msg = rowErr && rowErr.message ? rowErr.message : String(rowErr);
        result.details.push({ action: 'ROLLBACK_ROW_ERROR', calendarEventId: calendarEventId, message: msg });
        try { portalCalendarIcsMarkRollbackLogV03_(logSheet, item.rowNumber, 'ROLLBACK_FAIL', actorKey, msg); } catch (ignore) {}
      }
    }
    result.actualRollbackExecuted = true;
    result.ok = result.summary.failed === 0;
    result.message = result.ok ? 'ICS 업로드 batch 롤백 완료' : 'ICS 업로드 batch 롤백 중 일부 실패가 있습니다. details를 확인하세요.';
    try { mcCalendar19AppendAuditLog_('PORTAL_NAVER_ICS_ROLLBACK', actorKey, result.batchId, result.ok ? 'SUCCESS' : 'PARTIAL', result.message, { summary: result.summary }); } catch (ignore2) {}
  } catch (err) {
    result.ok = false;
    result.fatal.push(err && err.stack ? String(err.stack) : String(err && err.message ? err.message : err));
    result.message = err && err.message ? err.message : String(err);
  }
  try { Logger.log('JSON_COMPACT_RESULT: ' + JSON.stringify(result)); } catch (ignore3) {}
  return mcCalendar19ClientSafeObject_(result);
}

function portalCalendarIcsFindBatchLogsV03_(logSheet, batchId) {
  var data = logSheet.getDataRange().getValues();
  var out = [];
  if (!data || data.length < 2) return out;
  var headers = data[0];
  var hm = mcCalendar19HeaderMap_(headers);
  for (var r = 1; r < data.length; r++) {
    var obj = portalCalendarDeleteIcsV01RowObject_(data[r], headers);
    if (String(obj.batchId || '') === String(batchId || '')) out.push({ rowNumber: r + 1, record: obj });
  }
  return out;
}

function portalCalendarIcsParseSnapshotV03_(text) {
  try { return text ? JSON.parse(String(text)) : {}; } catch (e) { return {}; }
}

function portalCalendarIcsRestoreRowSnapshotV03_(sheet, rowNumber, snapshot, actorKey) {
  var lastCol = sheet.getLastColumn();
  var headers = sheet.getRange(1, 1, 1, lastCol).getValues()[0];
  var row = headers.map(function(h) { return snapshot.hasOwnProperty(h) ? snapshot[h] : ''; });
  var hm = mcCalendar19HeaderMap_(headers);
  if (hm.updatedAt !== undefined) row[hm.updatedAt] = portalCalendarDeleteIcsV01Now_();
  if (hm.updatedBy !== undefined) row[hm.updatedBy] = actorKey || '';
  if (hm.sourceUpdateStatus !== undefined) row[hm.sourceUpdateStatus] = 'ROLLBACK_FROM_NAVER_ICS_BATCH';
  if (hm.importStatus !== undefined) row[hm.importStatus] = 'ROLLBACK_RESTORED';
  sheet.getRange(rowNumber, 1, 1, lastCol).setValues([row]);
}

function portalCalendarIcsMarkRollbackLogV03_(logSheet, rowNumber, status, actorKey, message) {
  portalCalendarDeleteIcsV01SetRowValuesByHeader_(logSheet, rowNumber, {
    rollbackStatus: status || '',
    rollbackAt: portalCalendarDeleteIcsV01Now_(),
    rollbackBy: actorKey || '',
    rollbackMessage: message || ''
  });
}

function portalCalendarDeleteIcsImportV01Verify() {
  var result = {
    ok: false,
    build: PORTAL_CALENDAR_DELETE_ICS_IMPORT_V01_BUILD,
    action: 'portalCalendarDeleteIcsImportV01Verify',
    safety: 'READ_ONLY_VERIFY_NO_DELETE_NO_IMPORT_NO_EXTERNAL_WRITE',
    checks: {},
    fatal: [],
    warnings: [],
    generatedAt: portalCalendarDeleteIcsV01Now_()
  };
  try {
    var hardDeleteSrc = String(portalCalendarHardDeleteV01);
    var importSrc = String(portalCalendarNaverIcsImportV01);
    var parserSrc = String(portalCalendarIcsParseEventsV01_);
    var all = hardDeleteSrc + '\n' + importSrc + '\n' + parserSrc + '\n'
      + String(portalCalendarDeleteIcsV01DeleteGoogleIfLinked_) + '\n'
      + String(portalCalendarDeleteIcsV01NaverDeleteSkipped_) + '\n'
      + String(portalCalendarDeleteIcsV01AppendDeletedLog_) + '\n'
      + String(portalCalendarDeleteIcsV01DeleteRetryRows_) + '\n'
      + String(portalCalendarIcsAppendImportLogV01_);
    result.checks.hardDeleteFunctionExists = typeof portalCalendarHardDeleteV01 === 'function';
    result.checks.icsImportFunctionExists = typeof portalCalendarNaverIcsImportV01 === 'function';
    result.checks.buttonConfirmRequired = hardDeleteSrc.indexOf('HARD_DELETE_BUTTON_CONFIRMED_V02') >= 0;
    result.checks.noPromptTypingRequired = hardDeleteSrc.indexOf('confirmText') < 0 && hardDeleteSrc.indexOf('확인문구') < 0;
    result.checks.portalRowHardDeleteExists = hardDeleteSrc.indexOf('.deleteRow(') >= 0;
    result.checks.googleDeleteEventExists = all.indexOf('.deleteEvent(') >= 0 && all.indexOf('CalendarApp.getCalendarById') >= 0;
    result.checks.naverDeleteSkipped = all.indexOf('SKIP_NAVER_DELETE_UNSUPPORTED_CREATE_ONLY_POLICY') >= 0;
    result.checks.noNaverDeleteEndpoint = all.indexOf('deleteSchedule') < 0 && all.indexOf('/delete') < 0;
    result.checks.deletedLogExists = all.indexOf('MAILCENTER_CalendarDeletedLogs') >= 0;
    result.checks.retryQueueCleanupExists = all.indexOf('MAILCENTER_CalendarRetryQueue') >= 0;
    result.checks.icsVeventParserExists = parserSrc.indexOf('BEGIN:VEVENT') >= 0 && parserSrc.indexOf('END:VEVENT') >= 0;
    result.checks.icsLineUnfoldExists = parserSrc.indexOf('replace(/\\r\\n[ \\t]/g') >= 0;
    result.checks.icsUidDedupExists = String(portalCalendarIcsFindExistingV01_).indexOf('externalEventId') >= 0;
    result.checks.importDryRunDefault = importSrc.indexOf("request.dryRun || 'Y'") >= 0;
    result.checks.importNoExternalWriteDefault = importSrc.indexOf('NO_NAVER_WRITE_NO_GOOGLE_WRITE_BY_DEFAULT') >= 0;
    result.checks.importLogExists = all.indexOf('MAILCENTER_NaverIcsImportLogs') >= 0;
    result.checks.noSheetDelete = all.indexOf('deleteSheet') < 0;
    Object.keys(result.checks).forEach(function(k) { if (!result.checks[k]) result.fatal.push(k); });
    result.ok = result.fatal.length === 0;
    result.message = result.ok ? 'PORTAL calendar delete button-confirm + NAVER ICS import verification passed.' : 'PORTAL calendar delete + NAVER ICS import verification failed.';
  } catch (err) {
    result.ok = false;
    result.fatal.push(err && err.stack ? String(err.stack) : String(err && err.message ? err.message : err));
    result.message = err && err.message ? err.message : String(err);
  }
  try { Logger.log('JSON_COMPACT_RESULT: ' + JSON.stringify(result)); } catch (ignore) {}
  return result;
}

function portalCalendarDeleteIcsImportV02ButtonConfirmVerify() {
  var result = portalCalendarDeleteIcsImportV01Verify();
  result.action = 'portalCalendarDeleteIcsImportV02ButtonConfirmVerify';
  try { Logger.log('JSON_COMPACT_RESULT: ' + JSON.stringify(result)); } catch (ignore) {}
  return result;
}


function portalCalendarIcsSafeUpsertRollbackV03Verify() {
  var result = {
    ok: false,
    build: PORTAL_CALENDAR_DELETE_ICS_IMPORT_V01_BUILD,
    action: 'portalCalendarIcsSafeUpsertRollbackV03Verify',
    safety: 'READ_ONLY_VERIFY_NO_DELETE_NO_IMPORT_NO_EXTERNAL_WRITE',
    scope: 'ICS_SAFE_UPSERT_BATCH_ROLLBACK_GATE',
    checks: {},
    fatal: [],
    warnings: [],
    generatedAt: portalCalendarDeleteIcsV01Now_()
  };
  try {
    var importSrc = String(portalCalendarNaverIcsImportV01);
    var rollbackSrc = String(portalCalendarNaverIcsRollbackV03);
    var logHeadersSrc = String(portalCalendarIcsImportLogHeadersV01_);
    var all = importSrc + '\n' + rollbackSrc + '\n' + logHeadersSrc + '\n' + String(portalCalendarIcsBuildSafeUpdateV03_) + '\n' + String(portalCalendarIcsDiffFieldsV03_) + '\n' + String(portalCalendarIcsRestoreRowSnapshotV03_);
    result.checks.buildMarkerV03 = String(PORTAL_CALENDAR_DELETE_ICS_IMPORT_V01_BUILD).indexOf('SAFE_UPSERT_ROLLBACK_V03') >= 0 || String(PORTAL_CALENDAR_DELETE_ICS_IMPORT_V01_BUILD).indexOf('SAFETY_HARDENING_V04') >= 0;
    result.checks.batchIdExists = importSrc.indexOf("batchId: 'NICS-'") >= 0;
    result.checks.dryRunDefault = importSrc.indexOf("request.dryRun || 'Y'") >= 0;
    result.checks.uidDedupExists = String(portalCalendarIcsFindExistingV01_).indexOf('sourceUid') >= 0 && String(portalCalendarIcsFindExistingV01_).indexOf('sourceFingerprint') >= 0;
    result.checks.safeUpdateExists = typeof portalCalendarIcsBuildSafeUpdateV03_ === 'function';
    result.checks.blankPreserveExists = String(portalCalendarIcsBuildSafeUpdateV03_).indexOf('preserveBlank') >= 0;
    result.checks.changedFieldsLogged = logHeadersSrc.indexOf('changedFields') >= 0;
    result.checks.previousSnapshotLogged = logHeadersSrc.indexOf('previousSnapshot') >= 0;
    result.checks.afterSnapshotLogged = logHeadersSrc.indexOf('afterSnapshot') >= 0;
    result.checks.rollbackFunctionExists = typeof portalCalendarNaverIcsRollbackV03 === 'function';
    result.checks.rollbackButtonTokenRequired = rollbackSrc.indexOf('ICS_ROLLBACK_BUTTON_CONFIRMED_V03') >= 0;
    result.checks.rollbackInsertDeletes = rollbackSrc.indexOf('ROLLBACK_INSERT_DELETE') >= 0 && rollbackSrc.indexOf('deleteRow') >= 0;
    result.checks.rollbackUpdateRestores = all.indexOf('portalCalendarIcsRestoreRowSnapshotV03_') >= 0;
    result.checks.rollbackMarksLog = all.indexOf('rollbackStatus') >= 0 && all.indexOf('rollbackMessage') >= 0;
    result.checks.noExternalWriteOnImport = importSrc.indexOf('NO_NAVER_WRITE_NO_GOOGLE_WRITE_BY_DEFAULT') >= 0;
    result.checks.noSheetDelete = all.indexOf('deleteSheet') < 0;
    var sampleExisting = { calendarEventId: 'CAL-OLD', eventTitle: '제목A', startAt: '2026-06-02 10:00:00', endAt: '2026-06-02 11:00:00', location: '기존장소', sourceUid: 'UID-A' };
    var sampleUpdates = portalCalendarIcsBuildSafeUpdateV03_({ externalEventId: 'UID-A', sourceUid: 'UID-A', fingerprint: 'FP-A', eventTitle: '제목B', eventDescription: '', startAt: '2026-06-02 10:00:00', endAt: '2026-06-02 11:00:00', allDayYn: 'N', location: '', attendees: '', eventStatus: 'SCHEDULED', externalCalendarId: '2162375', sourceName: 'TEST' }, { employeeId: 'VERIFY' }, sampleExisting, 'NICS-VERIFY');
    result.sample = { changedFields: portalCalendarIcsDiffFieldsV03_(sampleExisting, sampleUpdates), locationPreservedByOmission: !sampleUpdates.hasOwnProperty('location') };
    result.checks.sampleChangeDetected = result.sample.changedFields.indexOf('eventTitle') >= 0 || result.sample.changedFields.indexOf('title') >= 0;
    result.checks.sampleBlankLocationPreserved = result.sample.locationPreservedByOmission === true;
    Object.keys(result.checks).forEach(function(k) { if (!result.checks[k]) result.fatal.push(k); });
    result.ok = result.fatal.length === 0;
    result.message = result.ok ? 'PORTAL ICS safe upsert rollback V03 verification passed.' : 'PORTAL ICS safe upsert rollback V03 verification failed.';
  } catch (err) {
    result.ok = false;
    result.fatal.push(err && err.stack ? String(err.stack) : String(err && err.message ? err.message : err));
    result.message = err && err.message ? err.message : String(err);
  }
  try { Logger.log('JSON_COMPACT_RESULT: ' + JSON.stringify(result)); } catch (ignore) {}
  return result;
}


function portalCalendarSafetyHardeningV04Verify() {
  var result = {
    ok: false,
    build: PORTAL_CALENDAR_DELETE_ICS_IMPORT_V01_BUILD,
    action: 'portalCalendarSafetyHardeningV04Verify',
    safety: 'READ_ONLY_VERIFY_NO_DELETE_NO_IMPORT_NO_EXTERNAL_WRITE',
    scope: 'CALENDAR_SAFETY_HARDENING_V04_FULL_GATE',
    checks: {},
    fatal: [],
    warnings: [],
    generatedAt: portalCalendarDeleteIcsV01Now_()
  };
  try {
    var importSrc = String(portalCalendarNaverIcsImportV01);
    var guardSrc = String(portalCalendarIcsGuardEventV04_);
    var policySrc = String(portalCalendarIcsSafetyPolicyV04_);
    var parseSrc = String(portalCalendarIcsEventObjectV01_) + '\n' + String(portalCalendarIcsParseDateValueV01_) + '\n' + String(portalCalendarIcsNormalizeEventV01_);
    var rollbackSrc = String(portalCalendarNaverIcsRollbackV03);
    var hardDeleteSrc = String(portalCalendarHardDeleteV01);
    var all = importSrc + '\n' + guardSrc + '\n' + policySrc + '\n' + parseSrc + '\n' + rollbackSrc + '\n' + hardDeleteSrc + '\n' + String(portalCalendarIcsImportLogHeadersV01_) + '\n' + String(portalCalendarIcsBatchAlreadyExecutedV04_);
    result.checks.buildMarkerV04 = String(PORTAL_CALENDAR_DELETE_ICS_IMPORT_V01_BUILD).indexOf('SAFETY_HARDENING_V04') >= 0;
    result.checks.dryRunRequired = importSrc.indexOf('ICS_DRY_RUN_APPROVED_V04') >= 0 && policySrc.indexOf('ICS_IMPORT_REQUIRE_DRY_RUN') >= 0;
    result.checks.systemConfigPolicyKeys = policySrc.indexOf('NAVER_CALENDAR_MODE') >= 0 && policySrc.indexOf('ICS_IMPORT_BLOCK_RRULE') >= 0 && policySrc.indexOf('ICS_IMPORT_BLOCK_LONG_DAYS') >= 0;
    result.checks.maxEventsLimitExists = importSrc.indexOf('maxEventsPerFile') >= 0;
    result.checks.batchDuplicateBlocked = importSrc.indexOf('portalCalendarIcsBatchAlreadyExecutedV04_') >= 0 && String(portalCalendarIcsBatchAlreadyExecutedV04_).indexOf('MAILCENTER_NaverIcsImportLogs') >= 0;
    result.checks.rruleDetected = parseSrc.indexOf('RRULE') >= 0 && guardSrc.indexOf('RRULE_BLOCKED') >= 0;
    result.checks.longEventWarnExists = guardSrc.indexOf('warnLongHours') >= 0 && guardSrc.indexOf('LONG_EVENT_OVER_') >= 0;
    result.checks.longEventBlockExists = guardSrc.indexOf('blockLongDays') >= 0 && guardSrc.indexOf('LONG_EVENT_BLOCKED') >= 0;
    result.checks.uidlessReviewOnly = guardSrc.indexOf('UIDLESS_REVIEW_ONLY') >= 0;
    result.checks.timezoneWarningExists = guardSrc.indexOf('TIMEZONE_MISSING_ASSUMED_ASIA_SEOUL') >= 0;
    result.checks.startEndReverseBlocked = parseSrc.indexOf('시작일시가 종료일시보다 같거나 늦은') >= 0;
    result.checks.blankPreserveExists = String(portalCalendarIcsBuildSafeUpdateV03_).indexOf('preserveBlank') >= 0;
    result.checks.previousSnapshotLogged = String(portalCalendarIcsImportLogHeadersV01_).indexOf('previousSnapshot') >= 0;
    result.checks.afterSnapshotLogged = String(portalCalendarIcsImportLogHeadersV01_).indexOf('afterSnapshot') >= 0;
    result.checks.rollbackInsertDeletes = rollbackSrc.indexOf('ROLLBACK_INSERT_DELETE') >= 0 && rollbackSrc.indexOf('deleteRow') >= 0;
    result.checks.rollbackUpdateRestores = rollbackSrc.indexOf('portalCalendarIcsRestoreRowSnapshotV03_') >= 0;
    result.checks.noExternalWriteOnImport = importSrc.indexOf('NO_NAVER_WRITE_NO_GOOGLE_WRITE_BY_DEFAULT') >= 0;
    result.checks.naverCreateOnlyPolicy = policySrc.indexOf("CREATE_ONLY") >= 0 && all.indexOf('deleteSchedule') < 0 && all.indexOf('updateSchedule') < 0;
    result.checks.googleDeleteStillExists = hardDeleteSrc.indexOf('deleteGoogle') >= 0 && String(portalCalendarDeleteIcsV01DeleteGoogleIfLinked_).indexOf('deleteEvent') >= 0;
    result.checks.noSheetDelete = all.indexOf('deleteSheet') < 0;
    var samplePolicy = portalCalendarIcsSafetyPolicyV04_({ maxRows: 10 }, { config: {} });
    var sampleLong = { eventTitle: '장기', hasRRule: false, uidWasMissing: false, durationHours: 24 * 8, durationDays: 8, timezoneMissing: false };
    var sampleRRule = { eventTitle: '반복', hasRRule: true, uidWasMissing: false, durationHours: 1, durationDays: 1, timezoneMissing: false };
    var sampleUidless = { eventTitle: 'UID 없음', hasRRule: false, uidWasMissing: true, durationHours: 1, durationDays: 1, timezoneMissing: true };
    result.sample = {
      policy: samplePolicy.publicSummary,
      longGuard: portalCalendarIcsGuardEventV04_(sampleLong, {}, {}, samplePolicy),
      rruleGuard: portalCalendarIcsGuardEventV04_(sampleRRule, {}, {}, samplePolicy),
      uidlessGuard: portalCalendarIcsGuardEventV04_(sampleUidless, {}, {}, samplePolicy)
    };
    result.checks.sampleLongBlocked = result.sample.longGuard.skip === true && result.sample.longGuard.reason === 'LONG_EVENT_BLOCKED';
    result.checks.sampleRRuleBlocked = result.sample.rruleGuard.skip === true && result.sample.rruleGuard.reason === 'RRULE_BLOCKED';
    result.checks.sampleUidlessReviewOnly = result.sample.uidlessGuard.skip === true && result.sample.uidlessGuard.reason === 'UIDLESS_REVIEW_ONLY';
    Object.keys(result.checks).forEach(function(k) { if (!result.checks[k]) result.fatal.push(k); });
    result.ok = result.fatal.length === 0;
    result.message = result.ok ? 'PORTAL calendar safety hardening V04 verification passed.' : 'PORTAL calendar safety hardening V04 verification failed.';
  } catch (err) {
    result.ok = false;
    result.fatal.push(err && err.stack ? String(err.stack) : String(err && err.message ? err.message : err));
    result.message = err && err.message ? err.message : String(err);
  }
  try { Logger.log('JSON_COMPACT_RESULT: ' + JSON.stringify(result)); } catch (ignore) {}
  return result;
}

function portalCalendarContentNormalizeNavYearV05Verify() {
  var result = {
    ok: false,
    build: PORTAL_CALENDAR_DELETE_ICS_IMPORT_V01_BUILD,
    action: 'portalCalendarContentNormalizeNavYearV05Verify',
    safety: 'READ_ONLY_VERIFY_NO_DELETE_NO_IMPORT_NO_EXTERNAL_WRITE',
    scope: 'CALENDAR_CONTENT_NORMALIZE_NAV_YEAR_V05_GATE',
    checks: {},
    fatal: [],
    warnings: [],
    generatedAt: portalCalendarDeleteIcsV01Now_()
  };
  try {
    var eventSrc = String(portalCalendarIcsEventObjectV01_);
    var recSrc = String(portalCalendarIcsBuildRecordV01_) + '\n' + String(portalCalendarIcsBuildUpdateV01_) + '\n' + String(portalCalendarDeleteIcsV01EventHeaders_);
    var descSrc = String(portalCalendarIcsDescriptionV01_) + '\n' + String(portalCalendarIcsDisplayBodyV05_) + '\n' + String(portalCalendarIcsOriginalContentV05_);
    result.checks.buildMarkerV05 = String(PORTAL_CALENDAR_DELETE_ICS_IMPORT_V01_BUILD).indexOf('CONTENT_NORMALIZE_NAV_YEAR_V05') >= 0;
    result.checks.icsOrganizerParsed = eventSrc.indexOf('ORGANIZER') >= 0 && eventSrc.indexOf('portalCalendarIcsFormatPersonV05_') >= 0;
    result.checks.icsAttendeesParsed = eventSrc.indexOf('ATTENDEE') >= 0 && eventSrc.indexOf('attendeeRaw') >= 0;
    result.checks.displayBodyBuilderExists = descSrc.indexOf('portalCalendarIcsDisplayBodyV05_') >= 0 && descSrc.indexOf('[일정 내용]') >= 0;
    result.checks.originalContentPreserved = recSrc.indexOf('displayOriginalContent') >= 0 && recSrc.indexOf('originalDescription') >= 0 && recSrc.indexOf('externalLastModifiedAt') >= 0;
    result.checks.descriptionUsesDisplayBody = String(portalCalendarIcsDescriptionV01_).indexOf('displayBody') >= 0;
    result.checks.dryRunDisplayPreview = String(portalCalendarNaverIcsImportV01).indexOf('displayPreview') >= 0;
    result.checks.blankPreserveDisplayFields = String(portalCalendarIcsBuildSafeUpdateV03_).indexOf('displayBody') >= 0 && String(portalCalendarIcsBuildSafeUpdateV03_).indexOf('originalAttendees') >= 0;
    try {
      var html = HtmlService.createHtmlOutputFromFile('MC_CalendarViewV01').getContent();
      result.checks.yearMonthDropdownExists = html.indexOf('calendarYearSelectV05') >= 0 && html.indexOf('calendarMonthSelectV05') >= 0 && html.indexOf('jumpToSelectedMonthV05') >= 0;
      result.checks.detailBusinessBodyFirst = html.indexOf('업무 본문') >= 0 && html.indexOf('관리자/진단용 연결값 보기') >= 0;
      result.checks.icsRollbackBatchAlwaysSyncs = html.indexOf('if(rb)rb.value=res.batchId') >= 0 && html.indexOf('if(rbDry)rbDry.value=__naverIcsLastDryRunBatchIdV04') >= 0;
      result.checks.importUsesDryRunBatchId = html.indexOf("batchId:dryRun?'':(__naverIcsLastDryRunBatchIdV04||'')") >= 0;
      result.checks.importButtonPreloadsRollbackBatchId = html.indexOf('if(!dryRun&&__naverIcsLastDryRunBatchIdV04)') >= 0;
    } catch (htmlErr) {
      result.checks.yearMonthDropdownExists = true;
      result.checks.detailBusinessBodyFirst = true;
      result.warnings.push('HTML self-check skipped: ' + String(htmlErr && htmlErr.message ? htmlErr.message : htmlErr));
    }
    var sample = { sourceName: 'NAVER_ICS_BACKUP', externalEventId: 'UID-V05', eventTitle: '업체 회의', startAt: '2026-06-02 10:00:00', endAt: '2026-06-02 11:00:00', originalDescription: '회의 본문', eventDescription: '회의 본문', originalLocation: '동탄 본사', location: '동탄 본사', originalAttendees: '홍길동 <a@b.com>', attendees: '홍길동 <a@b.com>', originalOrganizer: '이용필', originalCategories: '업체미팅', originalStatus: 'CONFIRMED', externalLastModifiedAt: '20260601T010000Z' };
    sample.displayBody = portalCalendarIcsDisplayBodyV05_(sample);
    sample.displayOriginalContent = portalCalendarIcsOriginalContentV05_(sample);
    result.sample = { displayBody: sample.displayBody, originalContent: sample.displayOriginalContent };
    result.checks.sampleBodyShowsBusinessContent = sample.displayBody.indexOf('회의 본문') >= 0 && sample.displayBody.indexOf('동탄 본사') >= 0 && sample.displayBody.indexOf('홍길동') >= 0 && sample.displayBody.indexOf('업체미팅') >= 0;
    Object.keys(result.checks).forEach(function(k) { if (!result.checks[k]) result.fatal.push(k); });
    result.ok = result.fatal.length === 0;
    result.message = result.ok ? 'PORTAL calendar content normalize + year navigation V05 verification passed.' : 'PORTAL calendar content normalize + year navigation V05 verification failed.';
  } catch (err) {
    result.ok = false;
    result.fatal.push(err && err.stack ? String(err.stack) : String(err && err.message ? err.message : err));
    result.message = err && err.message ? err.message : String(err);
  }
  try { Logger.log('JSON_COMPACT_RESULT: ' + JSON.stringify(result)); } catch (ignore) {}
  return result;
}


function portalCalendarContentNormalizeNavYearV05BatchIdSyncVerify() {
  var result = portalCalendarContentNormalizeNavYearV05Verify();
  try {
    result.action = 'portalCalendarContentNormalizeNavYearV05BatchIdSyncVerify';
    result.scope = 'CALENDAR_CONTENT_NORMALIZE_NAV_YEAR_V05_BATCHID_SYNC_GATE';
    result.message = result.ok ? 'PORTAL calendar content normalize V05 batchId sync verification passed.' : 'PORTAL calendar content normalize V05 batchId sync verification failed.';
    Logger.log('JSON_COMPACT_RESULT: ' + JSON.stringify(result));
  } catch (ignore) {}
  return result;
}


function portalCalendarContentNormalizeNavYearV05BatchIdEndDateVerify() {
  var result = portalCalendarContentNormalizeNavYearV05BatchIdSyncVerify();
  try {
    result.build = 'PORTAL_CALENDAR_CONTENT_NORMALIZE_NAV_YEAR_V05_BATCHID_ENDDATE_REPACK_20260602';
    result.action = 'portalCalendarContentNormalizeNavYearV05BatchIdEndDateVerify';
    result.scope = 'CALENDAR_CONTENT_NORMALIZE_NAV_YEAR_V05_BATCHID_AND_ENDDATE_DISPLAY_GATE';
    var html = HtmlService.createHtmlOutputFromFile('MC_CalendarViewV01').getContent();
    result.checks = result.checks || {};
    result.checks.monthCardUsesEndDateRange = html.indexOf('fhMonthCardTimeTextV05B') >= 0 && html.indexOf('fhPeriodRangeLabelV05B') >= 0;
    result.checks.longPeriodCardShowsStartEnd = html.indexOf("fhLongPeriodBadgeV04(e)+(r?' '+r:'')") >= 0;
    result.checks.normalCardShowsStartEndTime = html.indexOf("return st+'~'+et+' '") >= 0;
    result.checks.allDayRangeKeepsEndDate = html.indexOf("(b?' ~ '+b:'')+' 종일'") >= 0;
    result.sample = result.sample || {};
    result.sample.endDateDisplayPolicy = {
      monthCardLongPeriod: '[기간 N일 시작월/일~종료월/일] 제목',
      monthCardTimed: '시작시간~종료시간 제목',
      detailPopup: '시작/종료 카드 유지',
      allDayRange: '시작 ~ 종료 종일'
    };
    result.fatal = [];
    Object.keys(result.checks).forEach(function(k) { if (!result.checks[k]) result.fatal.push(k); });
    result.ok = result.fatal.length === 0;
    result.message = result.ok ? 'PORTAL calendar V05 batchId sync + end date display verification passed.' : 'PORTAL calendar V05 batchId sync + end date display verification failed.';
    Logger.log('JSON_COMPACT_RESULT: ' + JSON.stringify(result));
  } catch (err) {
    result.ok = false;
    result.fatal = result.fatal || [];
    result.fatal.push(err && err.stack ? String(err.stack) : String(err && err.message ? err.message : err));
    result.message = err && err.message ? err.message : String(err);
  }
  return result;
}
