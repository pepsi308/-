/**
 * FEELHAUS MailCenter Calendar Event Status Lock V01
 * Build: MAILCENTER_CALENDAR_EVENT_STATUS_LOCK_V01_20260521
 * Purpose:
 * - Create actual backup spreadsheet for MailCenter calendar event status scope
 * - Append event status stable lock record to FEELHAUS_DB_MASTER
 * - Do not modify router/menu/html/shell/view files
 */
var MC_CALENDAR_EVENT_STATUS_LOCK_V01_BUILD = 'MAILCENTER_CALENDAR_EVENT_STATUS_LOCK_V01_20260521';
var MC_CALENDAR_EVENT_STATUS_LOCK_V01_SETUP_DB_ID = '17VMSpgSZCvIrUlgcw8yCNcnl8WQWo2IcRf5tDCcuJGM';
var MC_CALENDAR_EVENT_STATUS_LOCK_V01_CONFIG_SHEET = 'SystemConfig';
var MC_CALENDAR_EVENT_STATUS_LOCK_V01_WEBAPP_URL = 'https://script.google.com/a/macros/feelhausfair.com/s/AKfycbxCyFE7zf4vE8nsfjOeWX0pC56SqU84gm8ie8Txa3qHQGEusJCZeljzCdYeOmZxUVYvjA/exec';

function runMcCalendarEventStatusLockV01Smoke() {
  var result = {
    ok: true,
    build: MC_CALENDAR_EVENT_STATUS_LOCK_V01_BUILD,
    action: 'runMcCalendarEventStatusLockV01Smoke',
    generatedAt: mcCalendarEventStatusLockV01Now_(),
    noWriteMode: true,
    checks: [],
    warnings: [],
    message: ''
  };
  function check(key, ok, message, detail) {
    result.checks.push({ key: key, ok: !!ok, message: message, detail: detail || '' });
    if (!ok) result.ok = false;
  }
  try {
    var master = mcCalendarEventStatusLockV01OpenMaster_();
    check('MasterOpenReady', !!master, 'SystemConfig -> FEELHAUS_DB_MASTER 연결 확인', master ? master.getId() : '');
    check('CreateLockFunctionReady', typeof runMcCalendarEventStatusLockV01CreateBackupAndLock === 'function', '상태변경 실제 백업/잠금 함수 확인');
    check('EventStatusGatePassedFunctionReady', typeof runMcCalendarEventStatusGateV01 === 'function', '6-3 상태변경 게이트 함수 확인');
    check('StatusChangeFunctionReady', typeof mcCalendarEventStatusV01ChangeStatus === 'function', '상태변경 실행 함수 확인');
    check('WebAppUrlReady', !!MC_CALENDAR_EVENT_STATUS_LOCK_V01_WEBAPP_URL, 'WebApp 절대주소 확인', MC_CALENDAR_EVENT_STATUS_LOCK_V01_WEBAPP_URL);
    check('NoRouterMenuHtmlTouch', true, '본 파일은 라우터/메뉴/HTML/Shell/View 변경 없음');

    var events = master.getSheetByName('MAILCENTER_CalendarEvents');
    var logs = master.getSheetByName('MAILCENTER_CalendarLogs');
    check('CalendarEventsSheetReady', !!events, 'MAILCENTER_CalendarEvents 시트 확인', events ? 'rows=' + events.getLastRow() : 'missing');
    check('CalendarLogsSheetReady', !!logs, 'MAILCENTER_CalendarLogs 시트 확인', logs ? 'rows=' + logs.getLastRow() : 'missing');

    result.message = result.ok ? 'MailCenter Calendar Event Status Lock V01 Smoke 통과' : 'MailCenter Calendar Event Status Lock V01 점검 필요';
  } catch (err) {
    result.ok = false;
    result.message = mcCalendarEventStatusLockV01Err_(err);
  }
  Logger.log(JSON.stringify(result, null, 2));
  return result;
}

function runMcCalendarEventStatusLockV01CreateBackupAndLock() {
  var result = {
    ok: false,
    build: MC_CALENDAR_EVENT_STATUS_LOCK_V01_BUILD,
    action: 'runMcCalendarEventStatusLockV01CreateBackupAndLock',
    generatedAt: mcCalendarEventStatusLockV01Now_(),
    lockId: '',
    backupSpreadsheetId: '',
    backupName: '',
    copiedSheets: [],
    message: ''
  };
  var actor = mcCalendarEventStatusLockV01Actor_();
  try {
    var master = mcCalendarEventStatusLockV01OpenMaster_();
    var now = mcCalendarEventStatusLockV01Now_();
    var stamp = Utilities.formatDate(new Date(), Session.getScriptTimeZone() || 'Asia/Seoul', 'yyyyMMdd_HHmmss');
    var lockId = 'MCALSTLOCK-' + Utilities.formatDate(new Date(), Session.getScriptTimeZone() || 'Asia/Seoul', 'yyyyMMddHHmmss') + '-' + Utilities.getUuid().substring(0, 8).toUpperCase();
    var backupName = 'MAILCENTER_CALENDAR_EVENT_STATUS_BACKUP_' + stamp;
    var backup = SpreadsheetApp.create(backupName);
    var backupId = backup.getId();

    var targetSheets = [
      'MAILCENTER_CalendarEvents',
      'MAILCENTER_CalendarLogs',
      'MAILCENTER_CalendarMailLinks',
      'MAILCENTER_CalendarStableLocks'
    ];
    var copied = [];
    targetSheets.forEach(function(sheetName) {
      var src = master.getSheetByName(sheetName);
      if (src) {
        var copy = src.copyTo(backup);
        copy.setName(sheetName);
        copied.push({ sheetName: sheetName, rows: src.getLastRow(), cols: src.getLastColumn() });
      } else {
        copied.push({ sheetName: sheetName, rows: 0, cols: 0, missing: true });
      }
    });

    var defaultSheet = backup.getSheetByName('Sheet1');
    if (defaultSheet && backup.getSheets().length > 1) backup.deleteSheet(defaultSheet);

    var info = backup.insertSheet('LOCK_INFO');
    var infoRows = [
      ['key', 'value'],
      ['lockId', lockId],
      ['build', MC_CALENDAR_EVENT_STATUS_LOCK_V01_BUILD],
      ['eventStatusGateBuild', 'MAILCENTER_CALENDAR_EVENT_STATUS_GATE_V01_20260521'],
      ['eventStatusServerBuild', 'MAILCENTER_CALENDAR_EVENT_STATUS_V01_SERVER_ONLY_20260521'],
      ['eventStatusButtonBuild', 'MAILCENTER_CALENDAR_EVENT_STATUS_BUTTON_V01_HTML_ONLY_20260521'],
      ['stableLockBuild', 'MAILCENTER_CALENDAR_STABLE_LOCK_V01_20260521'],
      ['webAppUrl', MC_CALENDAR_EVENT_STATUS_LOCK_V01_WEBAPP_URL],
      ['sourceMasterId', master.getId()],
      ['backupSpreadsheetId', backupId],
      ['lockedAt', now],
      ['lockedBy', actor],
      ['status', 'EVENT_STATUS_LOCKED'],
      ['scope', 'MailCenter calendar event status change server + button + gate'],
      ['note', 'Router/menu/html route structure not modified by this lock file']
    ];
    info.getRange(1, 1, infoRows.length, 2).setValues(infoRows);
    info.setFrozenRows(1);

    mcCalendarEventStatusLockV01AppendByHeaders_(master, 'MAILCENTER_CalendarEventStatusLocks', mcCalendarEventStatusLockV01Headers_(), {
      lockId: lockId,
      build: MC_CALENDAR_EVENT_STATUS_LOCK_V01_BUILD,
      eventStatusGateBuild: 'MAILCENTER_CALENDAR_EVENT_STATUS_GATE_V01_20260521',
      backupName: backupName,
      backupSpreadsheetId: backupId,
      webAppUrl: MC_CALENDAR_EVENT_STATUS_LOCK_V01_WEBAPP_URL,
      status: 'EVENT_STATUS_LOCKED',
      statusReason: 'MailCenter 캘린더 6단계 상태변경 게이트 및 백업 잠금 완료',
      copiedSheetsJson: JSON.stringify(copied),
      createdAt: now,
      createdBy: actor,
      updatedAt: now,
      updatedBy: actor
    });

    try {
      if (typeof mcCalendar19AppendAuditLog_ === 'function') {
        mcCalendar19AppendAuditLog_('MAILCENTER_CALENDAR_EVENT_STATUS_LOCK', actor, lockId, 'SUCCESS', 'MailCenter 캘린더 상태변경 안정 잠금 완료', { backupSpreadsheetId: backupId, backupName: backupName });
      }
    } catch (auditErr) {}

    result.ok = true;
    result.lockId = lockId;
    result.backupSpreadsheetId = backupId;
    result.backupName = backupName;
    result.copiedSheets = copied;
    result.message = 'MailCenter Calendar Event Status Lock V01 완료';
  } catch (err) {
    result.ok = false;
    result.message = mcCalendarEventStatusLockV01Err_(err);
  }
  Logger.log(JSON.stringify(result, null, 2));
  return result;
}

function mcCalendarEventStatusLockV01Headers_() {
  return ['lockId','build','eventStatusGateBuild','backupName','backupSpreadsheetId','webAppUrl','status','statusReason','copiedSheetsJson','createdAt','createdBy','updatedAt','updatedBy'];
}

function mcCalendarEventStatusLockV01AppendByHeaders_(ss, sheetName, baseHeaders, record) {
  var sheet = mcCalendarEventStatusLockV01GetSheetOrCreate_(ss, sheetName, baseHeaders);
  mcCalendarEventStatusLockV01EnsureHeaders_(sheet, Object.keys(record || {}));
  var headers = sheet.getRange(1, 1, 1, sheet.getLastColumn()).getValues()[0];
  var hm = mcCalendarEventStatusLockV01HeaderMap_(headers);
  var row = [];
  for (var i = 0; i < headers.length; i++) row.push('');
  Object.keys(record || {}).forEach(function(key) {
    if (hm.hasOwnProperty(key)) row[hm[key]] = record[key];
  });
  sheet.appendRow(row);
}

function mcCalendarEventStatusLockV01GetSheetOrCreate_(ss, name, headers) {
  var sheet = ss.getSheetByName(name);
  if (!sheet) {
    sheet = ss.insertSheet(name);
    sheet.getRange(1, 1, 1, headers.length).setValues([headers]);
    sheet.setFrozenRows(1);
    return sheet;
  }
  if (sheet.getLastRow() < 1 || sheet.getLastColumn() < 1) {
    sheet.getRange(1, 1, 1, headers.length).setValues([headers]);
    sheet.setFrozenRows(1);
    return sheet;
  }
  mcCalendarEventStatusLockV01EnsureHeaders_(sheet, headers);
  return sheet;
}

function mcCalendarEventStatusLockV01EnsureHeaders_(sheet, requiredHeaders) {
  var lastCol = Math.max(sheet.getLastColumn(), 1);
  var headers = sheet.getRange(1, 1, 1, lastCol).getValues()[0];
  var hm = mcCalendarEventStatusLockV01HeaderMap_(headers);
  var add = [];
  (requiredHeaders || []).forEach(function(h) {
    if (h && !hm.hasOwnProperty(h)) add.push(h);
  });
  if (add.length) sheet.getRange(1, headers.length + 1, 1, add.length).setValues([add]);
}

function mcCalendarEventStatusLockV01OpenMaster_() {
  var setup = SpreadsheetApp.openById(MC_CALENDAR_EVENT_STATUS_LOCK_V01_SETUP_DB_ID);
  var sheet = setup.getSheetByName(MC_CALENDAR_EVENT_STATUS_LOCK_V01_CONFIG_SHEET);
  if (!sheet) throw new Error('SystemConfig 시트를 찾지 못했습니다.');
  var values = sheet.getDataRange().getValues();
  if (!values || values.length < 2) throw new Error('SystemConfig 데이터가 비어 있습니다.');
  var hm = mcCalendarEventStatusLockV01HeaderMap_(values[0]);
  var keyCol = mcCalendarEventStatusLockV01PickIndex_(hm, ['CONFIG_KEY','configKey','key','name']);
  var valCol = mcCalendarEventStatusLockV01PickIndex_(hm, ['VALUE','configValue','value','spreadsheetId']);
  if (keyCol < 0 || valCol < 0) throw new Error('SystemConfig CONFIG_KEY/VALUE 헤더를 찾지 못했습니다.');
  var masterId = '';
  for (var r = 1; r < values.length; r++) {
    var key = String(values[r][keyCol] || '').trim();
    if (key === 'FEELHAUS_DB_MASTER' || key === 'FEELHAUS_DB_MASTER_ID' || key === 'MASTER_DB_ID') {
      masterId = String(values[r][valCol] || '').trim();
      break;
    }
  }
  if (!masterId) throw new Error('SystemConfig에서 FEELHAUS_DB_MASTER ID를 찾지 못했습니다.');
  return SpreadsheetApp.openById(masterId);
}

function mcCalendarEventStatusLockV01HeaderMap_(headers) {
  var out = {};
  (headers || []).forEach(function(h, i) {
    var key = String(h || '').trim();
    if (key) out[key] = i;
  });
  return out;
}

function mcCalendarEventStatusLockV01PickIndex_(hm, keys) {
  for (var i = 0; i < keys.length; i++) {
    if (hm.hasOwnProperty(keys[i])) return hm[keys[i]];
  }
  return -1;
}

function mcCalendarEventStatusLockV01Actor_() {
  return String(Session.getActiveUser().getEmail() || 'MAILCENTER_ADMIN').trim() || 'MAILCENTER_ADMIN';
}

function mcCalendarEventStatusLockV01Now_() {
  return Utilities.formatDate(new Date(), Session.getScriptTimeZone() || 'Asia/Seoul', 'yyyy-MM-dd HH:mm:ss');
}

function mcCalendarEventStatusLockV01Err_(err) {
  return err && err.message ? err.message : String(err);
}
