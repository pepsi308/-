/**
 * FEELHAUS MailCenter Compose Core V01
 * Build: MAILCENTER_SIGNATURE_COMPOSE_SYNC_V01_20260520
 *
 * Purpose:
 * - 기본 발신계정 자동 선택
 * - 계정별 기본 서명 자동 삽입
 * - 폴더/분류 선택
 * - 기존 mcSendTestCoreV01Send 발송 코어 재사용
 * - 성공한 송신/OAuth/설정/라우터 구조 수정 없음
 */

var MC_COMPOSE_CORE_V01_BUILD = 'MAILCENTER_SIGNATURE_COMPOSE_SYNC_V01_20260520';
var MC_COMPOSE_CORE_V01_SETUP_DB_ID = '17VMSpgSZCvIrUlgcw8yCNcnl8WQWo2IcRf5tDCcuJGM';
var MC_COMPOSE_CORE_V01_CONFIG_SHEET = 'SystemConfig';

function runMcComposeCoreV01Smoke() {
  var result = {
    ok: false,
    build: MC_COMPOSE_CORE_V01_BUILD,
    action: 'runMcComposeCoreV01Smoke',
    generatedAt: mcComposeCoreV01Now_(),
    message: '',
    checks: []
  };

  try {
    var ss = mcComposeCoreV01OpenMaster_().ss;
    mcComposeCoreV01EnsureComposeSheets_(ss);

    result.checks.push({ key: 'MasterConnected', ok: !!ss, message: 'FEELHAUS_DB_MASTER 연결 확인' });
    result.checks.push({ key: 'SendCoreReady', ok: typeof mcSendTestCoreV01Send === 'function', message: '기존 Send Core 발송 함수 확인' });
    result.checks.push({ key: 'AccountsReady', ok: !!ss.getSheetByName('MailCenter_Accounts'), message: 'MailCenter_Accounts 확인' });
    result.checks.push({ key: 'SignaturesReady', ok: !!ss.getSheetByName('MailCenter_Signatures'), message: 'MailCenter_Signatures 확인' });
    result.checks.push({ key: 'FoldersReady', ok: !!ss.getSheetByName('MailCenter_Folders'), message: 'MailCenter_Folders 확인' });
    result.checks.push({ key: 'PreferencesReady', ok: !!ss.getSheetByName('MailCenter_Preferences'), message: 'MailCenter_Preferences 확인' });
    result.checks.push({ key: 'ComposeLogsReady', ok: !!ss.getSheetByName('MailCenter_ComposeLogs'), message: 'MailCenter_ComposeLogs 확인' });

    result.ok = result.checks.every(function(c) { return !!c.ok; });
    result.message = result.ok ? 'MailCenter Compose Core V01 준비 완료' : 'MailCenter Compose Core V01 점검 실패';
  } catch (err) {
    result.ok = false;
    result.message = String(err && err.message ? err.message : err);
  }

  mcComposeCoreV01Log_(result);
  return result;
}

function mcComposeCoreV01GetData() {
  var result = {
    ok: false,
    build: MC_COMPOSE_CORE_V01_BUILD,
    action: 'mcComposeCoreV01GetData',
    generatedAt: mcComposeCoreV01Now_(),
    message: '',
    defaultMailAccountId: '',
    defaultSignatureId: '',
    defaultFolderId: '',
    defaultSignatureByAccount: {},
    accounts: [],
    signatures: [],
    folders: [],
    summary: {
      activeAccounts: 0,
      connectedAccounts: 0,
      signatures: 0,
      folders: 0
    }
  };

  try {
    var ss = mcComposeCoreV01OpenMaster_().ss;
    mcComposeCoreV01EnsureComposeSheets_(ss);

    var accounts = mcComposeCoreV01ReadAccounts_(ss);
    var oauthMap = mcComposeCoreV01ReadOAuthMap_(ss);
    var signatures = mcComposeCoreV01ReadSheet_(ss, 'MailCenter_Signatures');
    var folders = mcComposeCoreV01ReadSheet_(ss, 'MailCenter_Folders').filter(function(f) {
      return String(f.folderStatus || '').toUpperCase() !== 'INACTIVE';
    });
    var prefs = mcComposeCoreV01ReadSheet_(ss, 'MailCenter_Preferences');

    accounts.forEach(function(a) {
      var o = oauthMap[a.mailAccountId] || oauthMap[a.emailAddress] || {};
      a.oauthStatus = o.oauthStatus || '';
      a.canSend = String(a.mailAccountStatus || '').toUpperCase() === 'ACTIVE'
        && String(a.oauthStatus || '').toUpperCase() === 'CONNECTED';
    });

    var defaultAccount = '';
    var defaultFolder = '';
    prefs.forEach(function(p) {
      if (String(p.preferenceKey || '') === 'DEFAULT_SEND_ACCOUNT' && String(p.preferenceStatus || '').toUpperCase() === 'ACTIVE') {
        defaultAccount = String(p.mailAccountId || p.preferenceValue || '');
      }
      if (String(p.preferenceKey || '') === 'DEFAULT_FOLDER' && String(p.preferenceStatus || '').toUpperCase() === 'ACTIVE') {
        defaultFolder = String(p.preferenceValue || '');
      }
    });

    if (!defaultAccount) {
      var hq = accounts.filter(function(a) { return a.canSend && String(a.accountPurpose || '') === 'HQ_OFFICIAL'; })[0];
      var any = accounts.filter(function(a) { return a.canSend; })[0];
      defaultAccount = hq ? hq.mailAccountId : (any ? any.mailAccountId : '');
    }

    var activeSignatures = signatures.filter(function(s) {
      return String(s.signatureStatus || '').toUpperCase() !== 'INACTIVE';
    });
    var defaultSigByAccount = {};
    var globalDefaultSig = '';

    activeSignatures.forEach(function(s) {
      var sid = String(s.signatureId || '');
      var accountId = String(s.mailAccountId || '');
      var isDefault = String(s.isDefault || '').toUpperCase() === 'TRUE';
      if (!sid || !isDefault) return;
      if (accountId && !defaultSigByAccount[accountId]) defaultSigByAccount[accountId] = sid;
      if (!accountId && !globalDefaultSig) globalDefaultSig = sid;
    });

    var defaultSig = defaultSigByAccount[String(defaultAccount || '')] || globalDefaultSig || '';
    if (!defaultSig && activeSignatures.length) {
      var accountSig = activeSignatures.filter(function(s) { return String(s.mailAccountId || '') === String(defaultAccount || ''); })[0];
      defaultSig = accountSig ? String(accountSig.signatureId || '') : String(activeSignatures[0].signatureId || '');
    }

    result.defaultMailAccountId = defaultAccount;
    result.defaultSignatureId = defaultSig;
    result.defaultFolderId = defaultFolder;
    result.defaultSignatureByAccount = defaultSigByAccount;
    result.accounts = accounts;
    result.signatures = activeSignatures;
    result.folders = folders;
    result.summary.activeAccounts = accounts.filter(function(a) { return String(a.mailAccountStatus || '').toUpperCase() === 'ACTIVE'; }).length;
    result.summary.connectedAccounts = accounts.filter(function(a) { return a.canSend; }).length;
    result.summary.signatures = result.signatures.length;
    result.summary.folders = folders.length;

    result.ok = true;
    result.message = 'Compose V01 데이터 조회 완료';
  } catch (err) {
    result.ok = false;
    result.message = String(err && err.message ? err.message : err);
  }

  return mcComposeCoreV01Safe_(result);
}

function mcComposeCoreV01Send(payload) {
  var result = {
    ok: false,
    build: MC_COMPOSE_CORE_V01_BUILD,
    action: 'mcComposeCoreV01Send',
    generatedAt: mcComposeCoreV01Now_(),
    message: '',
    sendResult: null,
    mailAccountId: '',
    folderId: '',
    signatureId: ''
  };

  try {
    if (typeof mcSendTestCoreV01Send !== 'function') {
      throw new Error('mcSendTestCoreV01Send 함수가 없습니다.');
    }

    var p = payload || {};
    var mailAccountId = mcComposeCoreV01Require_(p.mailAccountId, 'mailAccountId');
    var toEmail = mcComposeCoreV01NormalizeRecipientList_(mcComposeCoreV01Require_(p.toEmail, 'toEmail'));
    var subject = mcComposeCoreV01Require_(p.subject, 'subject');
    var body = mcComposeCoreV01Require_(p.body, 'body');
    var signatureId = String(p.signatureId || '');
    var folderId = String(p.folderId || '');

    var ss = mcComposeCoreV01OpenMaster_().ss;
    mcComposeCoreV01EnsureComposeSheets_(ss);

    var sig = signatureId ? mcComposeCoreV01FindById_(ss, 'MailCenter_Signatures', 'signatureId', signatureId) : null;
    var finalBody = mcComposeCoreV01NormalizeHtmlForSend_(body);

    if (sig && sig.signatureHtml) {
      finalBody = finalBody + '<br><br>' + String(sig.signatureHtml);
    }

    var sendPayload = {
      mailAccountId: mailAccountId,
      toEmail: toEmail,
      ccEmail: mcComposeCoreV01NormalizeRecipientList_(p.ccEmail || ''),
      bccEmail: mcComposeCoreV01NormalizeRecipientList_(p.bccEmail || ''),
      subject: subject,
      body: finalBody,
      folderId: folderId,
      signatureId: signatureId
    };

    var sent = mcSendTestCoreV01Send('', sendPayload);

    result.sendResult = mcComposeCoreV01Safe_(sent);
    result.mailAccountId = mailAccountId;
    result.folderId = folderId;
    result.signatureId = signatureId;

    mcComposeCoreV01AppendComposeLog_(ss, {
      mailAccountId: mailAccountId,
      folderId: folderId,
      signatureId: signatureId,
      toEmail: toEmail,
      subject: subject,
      composeStatus: sent && sent.ok ? 'SENT' : 'FAILED',
      statusReason: sent && sent.message ? sent.message : '',
      sendBuild: sent && sent.build ? sent.build : '',
      gmailMessageId: sent && sent.gmailMessageId ? sent.gmailMessageId : ''
    });

    if (!sent || !sent.ok) {
      throw new Error((sent && sent.message) ? sent.message : '발송 실패');
    }

    result.ok = true;
    result.message = '메일 발송 완료';
  } catch (err) {
    result.ok = false;
    result.message = String(err && err.message ? err.message : err);
  }

  mcComposeCoreV01Log_(result);
  return mcComposeCoreV01Safe_(result);
}

function mcComposeCoreV01EnsureComposeSheets_(ss) {
  mcComposeCoreV01GetSheetOrCreate_(ss, 'MailCenter_ComposeLogs', [
    'composeLogId','mailAccountId','folderId','signatureId','toEmail','subject','composeStatus',
    'statusReason','sendBuild','gmailMessageId','createdAt','createdBy'
  ]);
}

function mcComposeCoreV01AppendComposeLog_(ss, obj) {
  var sh = ss.getSheetByName('MailCenter_ComposeLogs');
  var headers = mcComposeCoreV01Headers_(sh);
  var rowObj = {
    composeLogId: mcComposeCoreV01NewId_('MCCOMP'),
    mailAccountId: obj.mailAccountId || '',
    folderId: obj.folderId || '',
    signatureId: obj.signatureId || '',
    toEmail: obj.toEmail || '',
    subject: obj.subject || '',
    composeStatus: obj.composeStatus || '',
    statusReason: obj.statusReason || '',
    sendBuild: obj.sendBuild || '',
    gmailMessageId: obj.gmailMessageId || '',
    createdAt: mcComposeCoreV01Now_(),
    createdBy: mcComposeCoreV01User_()
  };
  sh.appendRow(headers.map(function(h) { return rowObj[h] !== undefined ? rowObj[h] : ''; }));
}

function mcComposeCoreV01ReadAccounts_(ss) {
  return mcComposeCoreV01ReadSheet_(ss, 'MailCenter_Accounts').filter(function(a) { return !!a.emailAddress; });
}

function mcComposeCoreV01ReadOAuthMap_(ss) {
  var rows = mcComposeCoreV01ReadSheet_(ss, 'MailCenter_OAuthConnections');
  var map = {};
  function score_(o) {
    var score = 0;
    if (!o) return score;
    if (String(o.oauthStatus || '').toUpperCase() === 'CONNECTED') score += 100;
    if (o.connectorMailAccountId) score += 10;
    if (o.lastConnectedAt) score += 5;
    return score;
  }
  function put_(key, o) {
    if (!key) return;
    var k = String(key);
    if (!map[k] || score_(o) >= score_(map[k])) map[k] = o;
  }
  rows.forEach(function(o) {
    put_(o.mailAccountId, o);
    put_(o.emailAddress, o);
    if (o.emailAddress) put_(String(o.emailAddress).toLowerCase(), o);
  });
  return map;
}

function mcComposeCoreV01FindById_(ss, sheetName, idHeader, idValue) {
  var rows = mcComposeCoreV01ReadSheet_(ss, sheetName);
  for (var i = 0; i < rows.length; i++) {
    if (String(rows[i][idHeader] || '') === String(idValue)) return rows[i];
  }
  return null;
}

function mcComposeCoreV01ReadSheet_(ss, sheetName) {
  var sh = ss.getSheetByName(sheetName);
  if (!sh) return [];
  var values = sh.getDataRange().getValues();
  if (!values || values.length < 2) return [];
  var hm = mcComposeCoreV01HeaderMap_(values[0]);
  var rows = [];
  for (var r = 1; r < values.length; r++) {
    var obj = mcComposeCoreV01RowObject_(values[r], hm);
    if (Object.keys(obj).some(function(k) { return obj[k] !== '' && obj[k] != null; })) rows.push(obj);
  }
  return rows;
}

function mcComposeCoreV01OpenMaster_() {
  if (typeof portal19GetConfigBundle_ === 'function' && typeof portal19OpenMaster_ === 'function') {
    var bundle = portal19GetConfigBundle_();
    var ssByPortal = portal19OpenMaster_(bundle);
    if (ssByPortal) return { ss: ssByPortal, masterDbId: bundle.masterDbId || '' };
  }
  var setup = SpreadsheetApp.openById(MC_COMPOSE_CORE_V01_SETUP_DB_ID);
  var configSheet = setup.getSheetByName(MC_COMPOSE_CORE_V01_CONFIG_SHEET);
  if (!configSheet) throw new Error('SystemConfig 시트를 찾지 못했습니다.');
  var values = configSheet.getDataRange().getValues();
  var hm = mcComposeCoreV01HeaderMap_(values[0]);
  var keyCol = mcComposeCoreV01FindHeader_(hm, ['CONFIG_KEY','configKey','KEY','key']);
  var valCol = mcComposeCoreV01FindHeader_(hm, ['VALUE','CONFIG_VALUE','configValue','value']);
  var masterId = '';
  for (var r = 1; r < values.length; r++) {
    var key = String(values[r][keyCol] || '').trim();
    if (key === 'FEELHAUS_DB_MASTER' || key === 'FEELHAUS_DB_MASTER_ID' || key === 'MASTER_DB_ID') {
      masterId = String(values[r][valCol] || '').trim();
      break;
    }
  }
  if (!masterId) throw new Error('SystemConfig에서 FEELHAUS_DB_MASTER ID를 찾지 못했습니다.');
  return { ss: SpreadsheetApp.openById(masterId), masterDbId: masterId };
}

function mcComposeCoreV01GetSheetOrCreate_(ss, sheetName, headers) {
  var sh = ss.getSheetByName(sheetName);
  if (!sh) sh = ss.insertSheet(sheetName);
  var lastCol = sh.getLastColumn();
  if (lastCol < 1) {
    sh.getRange(1, 1, 1, headers.length).setValues([headers]);
    return sh;
  }
  var existing = sh.getRange(1, 1, 1, lastCol).getValues()[0].map(function(v) { return String(v || '').trim(); });
  var append = [];
  headers.forEach(function(h) { if (existing.indexOf(h) < 0) append.push(h); });
  if (append.length) sh.getRange(1, existing.length + 1, 1, append.length).setValues([append]);
  return sh;
}

function mcComposeCoreV01Headers_(sh) {
  return sh.getRange(1, 1, 1, sh.getLastColumn()).getValues()[0].map(function(h) { return String(h || '').trim(); });
}
function mcComposeCoreV01HeaderMap_(header) {
  var hm = {};
  for (var i = 0; i < header.length; i++) {
    var raw = String(header[i] || '').trim();
    if (!raw) continue;
    hm[raw] = i;
    var norm = mcComposeCoreV01Normalize_(raw);
    if (hm[norm] == null) hm[norm] = i;
  }
  return hm;
}
function mcComposeCoreV01FindHeader_(hm, names) {
  for (var i = 0; i < names.length; i++) {
    if (hm[names[i]] != null) return hm[names[i]];
    var norm = mcComposeCoreV01Normalize_(names[i]);
    if (hm[norm] != null) return hm[norm];
  }
  return -1;
}
function mcComposeCoreV01RowObject_(row, hm) {
  var obj = {};
  Object.keys(hm).forEach(function(k) {
    if (k === mcComposeCoreV01Normalize_(k)) return;
    var val = row[hm[k]];
    obj[k] = val instanceof Date ? Utilities.formatDate(val, Session.getScriptTimeZone() || 'Asia/Seoul', 'yyyy-MM-dd HH:mm:ss') : val;
  });
  return obj;
}

function mcComposeCoreV01NormalizeRecipientList_(v) {
  return String(v || '')
    .split(/[\n\r,;]+/)
    .map(function(x) { return String(x || '').trim(); })
    .filter(function(x) { return !!x; })
    .filter(function(x, i, arr) { return arr.indexOf(x) === i; })
    .join(', ');
}

function mcComposeCoreV01NormalizeHtmlForSend_(body) {
  var s = String(body || '');
  if (!/<\s*(br|p|div|table|ul|ol|li|span|strong|b|i|a|html|body)[\s>]/i.test(s)) {
    s = mcComposeCoreV01EscapeHtml_(s).replace(/\r?\n/g, '<br>');
  }
  if (!/white-space\s*:/i.test(s) || !/line-height\s*:/i.test(s)) {
    s = '<div style="font-family:Pretendard, Noto Sans KR, Malgun Gothic, Arial, sans-serif;font-size:14px;line-height:1.75;white-space:pre-wrap;word-break:keep-all;overflow-wrap:anywhere">' + s + '</div>';
  }
  return s;
}

function mcComposeCoreV01EscapeHtml_(s) {
  return String(s || '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;').replace(/'/g, '&#39;');
}
function mcComposeCoreV01Normalize_(v) { return String(v || '').trim().toUpperCase().replace(/[^A-Z0-9]/g, ''); }
function mcComposeCoreV01Require_(v, name) { var s = String(v || '').trim(); if (!s) throw new Error(name + ' 값이 필요합니다.'); return s; }
function mcComposeCoreV01NewId_(prefix) { return prefix + '-' + Utilities.formatDate(new Date(), Session.getScriptTimeZone() || 'Asia/Seoul', 'yyyyMMddHHmmss') + '-' + Math.floor(Math.random() * 9000 + 1000); }
function mcComposeCoreV01User_() { try { return Session.getActiveUser().getEmail() || ''; } catch(e) { return ''; } }
function mcComposeCoreV01Now_() { return Utilities.formatDate(new Date(), Session.getScriptTimeZone() || 'Asia/Seoul', 'yyyy-MM-dd HH:mm:ss'); }
function mcComposeCoreV01Safe_(obj) { try { return JSON.parse(JSON.stringify(obj)); } catch(e) { return { ok:false, build: MC_COMPOSE_CORE_V01_BUILD, message: String(e) }; } }
function mcComposeCoreV01Log_(obj) { try { Logger.log('JSON_COMPACT_RESULT: ' + JSON.stringify(obj)); } catch(e) { Logger.log(obj); } }
