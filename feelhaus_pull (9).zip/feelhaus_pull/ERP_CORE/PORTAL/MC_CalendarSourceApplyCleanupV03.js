/**
 * FEELHAUS PORTAL / MailCenter Calendar Source Apply Cleanup V03
 * Build: PORTAL_MC_CALENDAR_SOURCE_APPLY_CLEANUP_V03_20260528
 * Purpose:
 * - 원본 행이 없는 EVENT-SAMPLE 계열 APPROVED_PENDING_SOURCE_APPLY 후보를 삭제하지 않고 마감 처리한다.
 * - MAILCENTER_CalendarEvents / MAILCENTER_CalendarApprovalQueue 상태만 안전 변경한다.
 * - ERP 원본, Google, Naver, 삭제/복구/clear는 수행하지 않는다.
 */
var MC_CALENDAR_SOURCE_APPLY_CLEANUP_V03_BUILD = 'PORTAL_MC_CALENDAR_SOURCE_APPLY_CLEANUP_V03_20260528';

function calCleanHelp() {
  var r = mcCalCleanV03Base_('calCleanHelp');
  r.ok = true;
  r.message = '원본 미존재 샘플 원본반영 후보 정리 함수 안내';
  r.runners = [
    { fn:'calCleanTest()', desc:'사전점검: 캘린더/승인큐/변경로그 시트 확인' },
    { fn:'calCleanScan()', desc:'정리 후보 조회. 저장 없음' },
    { fn:'calCleanDry()', desc:'최근 정리 후보 1건 마감 계획 확인. 저장 없음' },
    { fn:'calCleanClose()', desc:'최근 정리 후보 1건 SOURCE_MISSING_CLOSED 마감 처리' },
    { fn:'calCleanList()', desc:'정리 후보 목록 재조회' }
  ];
  r.nextAction = 'calCleanTest() → calCleanScan() → calCleanDry() 순서로 실행하세요.';
  return mcCalCleanV03Print_(r);
}

function calCleanTest() { return mcCalendarSourceApplyCleanupV03SelfTest(); }
function calCleanScan() { return mcCalendarSourceApplyCleanupV03Scan(); }
function calCleanList() { return mcCalendarSourceApplyCleanupV03Scan(); }
function calCleanDry() { return mcCalendarSourceApplyCleanupV03CloseRecentDryRun(); }
function calCleanClose() { return mcCalendarSourceApplyCleanupV03CloseRecent(); }

function mcCalendarSourceApplyCleanupV03SelfTest() {
  var r = mcCalCleanV03Base_('mcCalendarSourceApplyCleanupV03SelfTest');
  try {
    var ss = mcCalCleanV03OpenMaster_();
    var calendar = ss.getSheetByName('MAILCENTER_CalendarEvents');
    var queue = ss.getSheetByName('MAILCENTER_CalendarApprovalQueue');
    var logs = ss.getSheetByName('MAILCENTER_CalendarChangeLogs');
    var ch = calendar ? mcCalCleanV03HeaderMap_(calendar) : {};
    var qh = queue ? mcCalCleanV03HeaderMap_(queue) : {};
    var requiredCalendar = ['calendarEventId','sourceType','eventId','sourceWritePolicy','sourceUpdateStatus','statusReason','updatedAt','updatedBy'];
    var requiredQueue = ['approvalId','calendarEventId','approvalStatus','sourceUpdateStatus','decisionReason','updatedAt','updatedBy'];
    var missingCalendar = calendar ? requiredCalendar.filter(function(h){ return ch[h] === undefined; }) : requiredCalendar;
    var missingQueue = queue ? requiredQueue.filter(function(h){ return qh[h] === undefined; }) : requiredQueue;
    r.ok = !!calendar && !!queue && missingCalendar.length === 0 && missingQueue.length === 0;
    r.checks = {
      masterDbOk: !!ss,
      calendarSheetOk: !!calendar,
      approvalQueueSheetOk: !!queue,
      changeLogSheetOk: !!logs,
      missingCalendarHeaderCount: missingCalendar.length,
      missingQueueHeaderCount: missingQueue.length,
      realApplyExecuted: false,
      destructiveRepairExecuted: false
    };
    r.targetSheets = [
      calendar ? { sheetName:calendar.getName(), lastRow:calendar.getLastRow(), lastColumn:calendar.getLastColumn() } : { sheetName:'MAILCENTER_CalendarEvents', exists:false },
      queue ? { sheetName:queue.getName(), lastRow:queue.getLastRow(), lastColumn:queue.getLastColumn() } : { sheetName:'MAILCENTER_CalendarApprovalQueue', exists:false },
      logs ? { sheetName:logs.getName(), lastRow:logs.getLastRow(), lastColumn:logs.getLastColumn() } : { sheetName:'MAILCENTER_CalendarChangeLogs', exists:false }
    ];
    r.missingCalendarHeaders = missingCalendar;
    r.missingQueueHeaders = missingQueue;
    r.message = r.ok ? 'Source Apply Cleanup V03 준비 완료' : '누락 시트 또는 헤더가 있습니다.';
    r.nextAction = r.ok ? 'calCleanScan()으로 정리 후보를 조회하세요.' : 'missingHeaders를 먼저 확인하세요.';
  } catch (err) { mcCalCleanV03Catch_(r, err); }
  return mcCalCleanV03Print_(r);
}

function mcCalendarSourceApplyCleanupV03Scan() {
  var r = mcCalCleanV03Base_('mcCalendarSourceApplyCleanupV03Scan');
  try {
    var items = mcCalCleanV03FindCandidates_();
    r.ok = true;
    r.summary = {
      found: items.length,
      sampleEventIdCount: items.filter(function(x){ return x.isSampleEventId; }).length,
      sourceMissingCount: items.filter(function(x){ return !x.sourceReady; }).length,
      realApplyExecuted:false,
      destructiveRepairExecuted:false
    };
    r.items = items.map(mcCalCleanV03Compact_).slice(0, 10);
    r.message = '원본 미존재/샘플 원본반영 후보 조회 완료. 저장/삭제는 하지 않았습니다.';
    r.nextAction = items.length ? 'calCleanDry()로 최근 후보 마감 계획을 확인하세요.' : '정리할 후보가 없습니다.';
  } catch (err) { mcCalCleanV03Catch_(r, err); }
  return mcCalCleanV03Print_(r);
}

function mcCalendarSourceApplyCleanupV03CloseRecentDryRun() { return mcCalCleanV03CloseRecent_(true); }
function mcCalendarSourceApplyCleanupV03CloseRecent() { return mcCalCleanV03CloseRecent_(false); }

function mcCalCleanV03CloseRecent_(dryRun) {
  var r = mcCalCleanV03Base_(dryRun ? 'mcCalendarSourceApplyCleanupV03CloseRecentDryRun' : 'mcCalendarSourceApplyCleanupV03CloseRecent');
  try {
    var items = mcCalCleanV03FindCandidates_();
    if (!items.length) throw new Error('정리할 원본 미존재 후보가 없습니다.');
    var target = items[0];
    var now = mcCalCleanV03Now_();
    var actor = mcCalCleanV03Actor_();
    var newStatus = 'SOURCE_MISSING_CLOSED';
    var reason = '원본 행이 없는 테스트/샘플 후보로 확인되어 삭제 없이 마감 처리';
    r.ok = true;
    r.dryRun = !!dryRun;
    r.target = mcCalCleanV03Compact_(target);
    r.plan = {
      ok:true,
      calendarRow:target.calendarRow,
      queueRow:target.queueRow,
      newSourceUpdateStatus:newStatus,
      queueDecisionReason:reason,
      logChangeType:'SOURCE_MISSING_CLOSED',
      erpSourceMutated:false,
      googleRealApplyExecuted:false,
      naverAutoApplyExecuted:false
    };
    r.realApplyExecuted = false;
    r.destructiveRepairExecuted = false;
    if (dryRun) {
      r.saved = false;
      r.message = 'DRY RUN: 원본 미존재 후보 마감 계획만 반환했습니다.';
      r.nextAction = '계획이 맞으면 calCleanClose()를 실행하세요.';
      return mcCalCleanV03Print_(r);
    }
    var ss = mcCalCleanV03OpenMaster_();
    var calendar = ss.getSheetByName('MAILCENTER_CalendarEvents');
    var queue = ss.getSheetByName('MAILCENTER_CalendarApprovalQueue');
    var logs = mcCalCleanV03GetSheetOrCreate_(ss, 'MAILCENTER_CalendarChangeLogs', mcCalCleanV03ChangeLogHeaders_());
    var ch = mcCalCleanV03HeaderMap_(calendar);
    var qh = mcCalCleanV03HeaderMap_(queue);
    var lh = mcCalCleanV03HeaderMap_(logs);
    var before = { calendarSourceUpdateStatus:target.calendar.sourceUpdateStatus || '', queueSourceUpdateStatus:target.queue.sourceUpdateStatus || '', approvalStatus:target.queue.approvalStatus || '' };
    mcCalCleanV03SetCell_(calendar, ch, target.calendarRow, 'sourceUpdateStatus', newStatus);
    mcCalCleanV03SetCell_(calendar, ch, target.calendarRow, 'statusReason', reason);
    mcCalCleanV03SetCell_(calendar, ch, target.calendarRow, 'updatedAt', now);
    mcCalCleanV03SetCell_(calendar, ch, target.calendarRow, 'updatedBy', actor);
    mcCalCleanV03SetCell_(queue, qh, target.queueRow, 'sourceUpdateStatus', newStatus);
    mcCalCleanV03SetCell_(queue, qh, target.queueRow, 'decisionReason', reason);
    mcCalCleanV03SetCell_(queue, qh, target.queueRow, 'updatedAt', now);
    mcCalCleanV03SetCell_(queue, qh, target.queueRow, 'updatedBy', actor);
    var after = { calendarSourceUpdateStatus:newStatus, queueSourceUpdateStatus:newStatus, approvalStatus:target.queue.approvalStatus || '' };
    mcCalCleanV03AppendByHeader_(logs, lh, {
      changeLogId:'MCALCHG-' + mcCalCleanV03Uuid_(),
      calendarEventId:target.calendar.calendarEventId || '',
      changeType:'SOURCE_MISSING_CLOSED',
      changedFields:'sourceUpdateStatus,statusReason,decisionReason',
      beforeJson:JSON.stringify(before),
      afterJson:JSON.stringify(after),
      changeReason:reason,
      changedAt:now,
      changedBy:actor,
      sourceType:target.calendar.sourceType || '',
      sourceWritePolicy:target.calendar.sourceWritePolicy || '',
      sourceUpdateStatus:newStatus,
      realApplyExecuted:'N',
      destructiveRepairExecuted:'N'
    });
    r.saved = true;
    r.message = '원본 미존재 후보를 삭제 없이 SOURCE_MISSING_CLOSED로 마감했습니다.';
    r.nextAction = 'calCleanScan() 또는 calSrcScan()으로 남은 후보를 확인하세요.';
  } catch (err) { mcCalCleanV03Catch_(r, err); }
  return mcCalCleanV03Print_(r);
}

function mcCalCleanV03FindCandidates_() {
  var ss = mcCalCleanV03OpenMaster_();
  var calendar = ss.getSheetByName('MAILCENTER_CalendarEvents');
  var queue = ss.getSheetByName('MAILCENTER_CalendarApprovalQueue');
  if (!calendar || !queue) return [];
  var ch = mcCalCleanV03HeaderMap_(calendar);
  var qh = mcCalCleanV03HeaderMap_(queue);
  var cRows = calendar.getDataRange().getValues();
  var qRows = queue.getDataRange().getValues();
  var queueByCalendarId = {};
  for (var q = 1; q < qRows.length; q++) {
    var qObj = mcCalCleanV03RowToObj_(qRows[q], qh, q + 1);
    var qStatus = String(qObj.approvalStatus || '').toUpperCase();
    var qSourceStatus = String(qObj.sourceUpdateStatus || '').toUpperCase();
    if (qStatus !== 'APPROVED') continue;
    if (qSourceStatus !== 'APPROVED_PENDING_SOURCE_APPLY') continue;
    if (qObj.calendarEventId) queueByCalendarId[String(qObj.calendarEventId)] = qObj;
  }
  var out = [];
  for (var i = cRows.length - 1; i >= 1; i--) {
    var cObj = mcCalCleanV03RowToObj_(cRows[i], ch, i + 1);
    var id = String(cObj.calendarEventId || '');
    if (!id || !queueByCalendarId[id]) continue;
    var sourceStatus = String(cObj.sourceUpdateStatus || '').toUpperCase();
    var policy = String(cObj.sourceWritePolicy || '').toUpperCase();
    if (sourceStatus !== 'APPROVED_PENDING_SOURCE_APPLY') continue;
    if (policy !== 'SYNC_TO_SOURCE') continue;
    var source = mcCalCleanV03ResolveSource_(cObj.sourceType, cObj.eventId, cObj);
    var isSample = /^EVENT-SAMPLE/i.test(String(cObj.eventId || '')) || /^VENDOR-SAMPLE/i.test(String(cObj.vendorId || ''));
    if (source.ready) continue;
    if (!isSample) continue;
    out.push({ calendarRow:i + 1, queueRow:queueByCalendarId[id].rowNumber, calendar:cObj, queue:queueByCalendarId[id], source:source, sourceReady:false, isSampleEventId:isSample });
  }
  return out;
}

function mcCalCleanV03ResolveSource_(sourceType, sourceId, calendarObj) {
  var ss = mcCalCleanV03OpenMaster_();
  var names = ['ERP_행사관리','행사관리','ERP_Events','ERP_EventMaster','ERP_Event','EVENTS','행사'];
  var result = { ready:false, sourceSheetName:'', sourceRowNumber:-1, keyField:'eventId', keyValue:sourceId || '' };
  if (String(sourceType || '').toUpperCase() !== 'ERP_EVENT') return result;
  for (var n = 0; n < names.length; n++) {
    var sh = ss.getSheetByName(names[n]);
    if (!sh) continue;
    var hm = mcCalCleanV03HeaderMap_(sh);
    if (hm.eventId === undefined) continue;
    var rows = sh.getDataRange().getValues();
    for (var i = 1; i < rows.length; i++) {
      if (String(rows[i][hm.eventId] || '') === String(sourceId || '')) {
        return { ready:true, sourceSheetName:sh.getName(), sourceRowNumber:i + 1, keyField:'eventId', keyValue:sourceId || '' };
      }
    }
    if (!result.sourceSheetName) result.sourceSheetName = sh.getName();
  }
  return result;
}

function mcCalCleanV03Compact_(x) {
  return {
    calendarRow:x.calendarRow,
    queueRow:x.queueRow,
    calendarEventId:x.calendar.calendarEventId || '',
    sourceType:x.calendar.sourceType || '',
    eventId:x.calendar.eventId || '',
    vendorId:x.calendar.vendorId || '',
    title:x.calendar.title || x.calendar.eventTitle || '',
    sourceWritePolicy:x.calendar.sourceWritePolicy || '',
    sourceUpdateStatus:x.calendar.sourceUpdateStatus || '',
    approvalStatus:x.queue.approvalStatus || '',
    sourceReady:x.sourceReady,
    sourceSheetName:x.source.sourceSheetName || '',
    sourceRowNumber:x.source.sourceRowNumber || -1,
    isSampleEventId:!!x.isSampleEventId
  };
}

function mcCalCleanV03ChangeLogHeaders_() {
  if (typeof mcCalendarOperationHubV01ChangeLogHeaders_ === 'function') return mcCalendarOperationHubV01ChangeLogHeaders_();
  return ['changeLogId','calendarEventId','changeType','changedFields','beforeJson','afterJson','changeReason','changedAt','changedBy','sourceType','sourceWritePolicy','sourceUpdateStatus','realApplyExecuted','destructiveRepairExecuted'];
}
function mcCalCleanV03OpenMaster_() { if (typeof mcCalendarUnifiedManualInputV1OpenMaster_ === 'function') return mcCalendarUnifiedManualInputV1OpenMaster_(); if (typeof mcCalendarUnifiedManualInputV01OpenMaster_ === 'function') return mcCalendarUnifiedManualInputV01OpenMaster_(); return SpreadsheetApp.getActiveSpreadsheet(); }
function mcCalCleanV03GetSheetOrCreate_(ss, name, headers) { var sh = ss.getSheetByName(name) || ss.insertSheet(name); if (sh.getLastRow() < 1) sh.getRange(1,1,1,headers.length).setValues([headers]); return sh; }
function mcCalCleanV03HeaderMap_(sheet) { var vals = sheet.getRange(1,1,1,Math.max(sheet.getLastColumn(),1)).getValues()[0]; var m = {}; vals.forEach(function(h,i){ if (h !== '') m[String(h).trim()] = i; }); return m; }
function mcCalCleanV03RowToObj_(row, hm, rowNumber) { var o = { rowNumber:rowNumber }; Object.keys(hm).forEach(function(k){ o[k] = row[hm[k]]; }); return o; }
function mcCalCleanV03SetCell_(sheet, hm, row, key, value) { if (hm[key] !== undefined) sheet.getRange(row, hm[key] + 1).setValue(value); }
function mcCalCleanV03AppendByHeader_(sheet, hm, obj) { var width = sheet.getLastColumn(); var row = new Array(width).fill(''); Object.keys(obj).forEach(function(k){ if (hm[k] !== undefined) row[hm[k]] = obj[k]; }); sheet.appendRow(row); }
function mcCalCleanV03Actor_() { try { return Session.getActiveUser().getEmail() || 'unknown'; } catch (e) { return 'unknown'; } }
function mcCalCleanV03Now_() { return Utilities.formatDate(new Date(), 'Asia/Seoul', 'yyyy-MM-dd HH:mm:ss'); }
function mcCalCleanV03Uuid_() { return Utilities.getUuid ? Utilities.getUuid() : String(new Date().getTime()); }
function mcCalCleanV03Base_(action) { return { ok:false, build:MC_CALENDAR_SOURCE_APPLY_CLEANUP_V03_BUILD, action:action, generatedAt:mcCalCleanV03Now_(), realApplyExecuted:false, destructiveRepairExecuted:false, warnings:[], errors:[] }; }
function mcCalCleanV03Catch_(r, err) { r.ok = false; r.message = String(err && err.message ? err.message : err); r.errors.push({ message:r.message, stack:err && err.stack ? err.stack : '' }); r.nextAction = '오류 메시지와 calendarEventId/sourceUpdateStatus를 확인하세요.'; }
function mcCalCleanV03Print_(r) { r.endedAt = mcCalCleanV03Now_(); Logger.log('JSON_COMPACT_RESULT: ' + JSON.stringify(r)); return r; }
