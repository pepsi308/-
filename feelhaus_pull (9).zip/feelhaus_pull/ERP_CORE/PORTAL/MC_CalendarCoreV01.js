/**
 * MAILCENTER_CALENDAR_CORE_CLONE_V01_20260521
 * Source cloned from verified PORTAL calendar file: Portal_Calendar.js
 * Rule:
 * - PORTAL original files are not modified.
 * - Server identifiers are namespaced from portal* to mcCalendar* to avoid collisions.
 * - This is stage 1: core clone / diagnostic separation only.
 */

/* Build: MC_GOOGLE_CALENDAR_BIDIRECTIONAL_SYNC_PREP_V01_20260527
 * Previous: MAILCENTER_CALENDAR_CORE_CLONE_V01_20260521
 * File: MailCenter_Calendar.js
 * Rule: JS-only clean replace. No Google email matching. Actor identity uses MAILCENTER loginId / employeeId / sid.
 * Keep SystemConfig auto-read, FEELHAUS_DB_MASTER, header-map access, provider logs, retry queue, PORTAL master ledger, NAVER outbound/import policy, GOOGLE_BACKUP, Google bidirectional sync prep policy, and safe apply create/link layer.
 */



/**
 * MC_CALENDAR_COMPAT_HELPERS_V03_20260527
 * 목적: Google Calendar sync test gate에서 기존 MC_CalendarCoreV01 단독 적용 시 누락될 수 있는
 * mcCalendar19 공통 helper를 보강합니다. 기존 동일 함수가 있으면 덮어쓰지 않습니다.
 */
var PORTAL_CALENDAR_SAFE01B_R7C_UPDATEDBY_USER_LOCK_CORE_BUILD = 'PORTAL_CALENDAR_SAFE01B_R7C_UPDATEDBY_USER_LOCK_20260602';
var MAILCENTER19_SETUP_DB_ID = (typeof MAILCENTER19_SETUP_DB_ID !== 'undefined' && MAILCENTER19_SETUP_DB_ID) ? MAILCENTER19_SETUP_DB_ID : '17VMSpgSZCvIrUlgcw8yCNcnl8WQWo2IcRf5tDCcuJGM';
var MAILCENTER19_CONFIG_SHEET_NAME = (typeof MAILCENTER19_CONFIG_SHEET_NAME !== 'undefined' && MAILCENTER19_CONFIG_SHEET_NAME) ? MAILCENTER19_CONFIG_SHEET_NAME : 'SystemConfig';

if (typeof mcCalendar19ErrorMessage_ !== 'function') {
  var mcCalendar19ErrorMessage_ = function(err) {
    if (!err) return '';
    if (typeof err === 'string') return err;
    if (err.message) return String(err.message);
    try { return JSON.stringify(err); } catch (jsonErr) { return String(err); }
  };
}

if (typeof mcCalendar19SafeResult_ !== 'function') {
  var mcCalendar19SafeResult_ = function(action) {
    return {
      ok: false,
      build: 'MC_CALENDAR_CORE_COMPAT_HELPERS_V03_20260527',
      action: String(action || ''),
      message: '',
      generatedAt: Utilities.formatDate(new Date(), Session.getScriptTimeZone() || 'Asia/Seoul', 'yyyy-MM-dd HH:mm:ss')
    };
  };
}

if (typeof mcCalendar19HeaderMap_ !== 'function') {
  var mcCalendar19HeaderMap_ = function(headers) {
    var map = {};
    headers = headers || [];
    for (var i = 0; i < headers.length; i++) {
      var key = String(headers[i] || '').trim();
      if (key) map[key] = i;
    }
    return map;
  };
}

if (typeof mcCalendar19ClientSafeObject_ !== 'function') {
  var mcCalendar19ClientSafeObject_ = function(obj) {
    if (obj === null || obj === undefined) return obj;
    try { return JSON.parse(JSON.stringify(obj)); } catch (err) { return obj; }
  };
}

if (typeof mcCalendar19NormalizeConfigKey_ !== 'function') {
  var mcCalendar19NormalizeConfigKey_ = function(key) {
    return String(key || '').trim().replace(/\s+/g, '_').toUpperCase();
  };
}

if (typeof mcCalendar19PickConfig_ !== 'function') {
  var mcCalendar19PickConfig_ = function(config, keys) {
    config = config || {};
    keys = keys || [];
    for (var i = 0; i < keys.length; i++) {
      var raw = String(keys[i] || '').trim();
      var norm = mcCalendar19NormalizeConfigKey_(raw);
      if (config.hasOwnProperty(raw) && config[raw] !== '') return config[raw];
      if (config.hasOwnProperty(norm) && config[norm] !== '') return config[norm];
      var camel = raw.charAt(0).toLowerCase() + raw.slice(1);
      if (config.hasOwnProperty(camel) && config[camel] !== '') return config[camel];
    }
    return '';
  };
}

if (typeof mcCalendar19ExtractSpreadsheetId_ !== 'function') {
  var mcCalendar19ExtractSpreadsheetId_ = function(value) {
    value = String(value || '').trim();
    if (!value) return '';
    var m = value.match(/[-\w]{25,}/);
    return m ? m[0] : value;
  };
}

if (typeof mcCalendar19GetConfigBundle_ !== 'function') {
  var mcCalendar19GetConfigBundle_ = function() {
    var setup = SpreadsheetApp.openById(MAILCENTER19_SETUP_DB_ID);
    var sheet = setup.getSheetByName(MAILCENTER19_CONFIG_SHEET_NAME);
    if (!sheet) throw new Error('SystemConfig 시트를 찾지 못했습니다: ' + MAILCENTER19_CONFIG_SHEET_NAME);
    var values = sheet.getDataRange().getValues();
    if (!values || values.length < 1) throw new Error('SystemConfig 데이터가 비어 있습니다.');
    var hm = mcCalendar19HeaderMap_(values[0]);
    var keyCol = hm.CONFIG_KEY;
    if (keyCol === undefined) keyCol = hm.configKey;
    if (keyCol === undefined) keyCol = hm.key;
    if (keyCol === undefined) keyCol = hm.name;
    var valCol = hm.VALUE;
    if (valCol === undefined) valCol = hm.CONFIG_VALUE;
    if (valCol === undefined) valCol = hm.configValue;
    if (valCol === undefined) valCol = hm.value;
    if (keyCol === undefined || valCol === undefined) throw new Error('SystemConfig 필수 헤더(CONFIG_KEY/VALUE)를 찾지 못했습니다.');
    var config = {};
    for (var r = 1; r < values.length; r++) {
      var k = String(values[r][keyCol] || '').trim();
      if (!k) continue;
      var v = values[r][valCol];
      config[k] = v;
      config[mcCalendar19NormalizeConfigKey_(k)] = v;
    }
    return {
      ok: true,
      setupDbId: MAILCENTER19_SETUP_DB_ID,
      setupSpreadsheet: setup,
      configSheetName: MAILCENTER19_CONFIG_SHEET_NAME,
      config: config,
      generatedAt: Utilities.formatDate(new Date(), Session.getScriptTimeZone() || 'Asia/Seoul', 'yyyy-MM-dd HH:mm:ss')
    };
  };
}

if (typeof mcCalendar19OpenMaster_ !== 'function') {
  var mcCalendar19OpenMaster_ = function(configBundle) {
    configBundle = configBundle || mcCalendar19GetConfigBundle_();
    var cfg = configBundle.config || {};
    var raw = mcCalendar19PickConfig_(cfg, [
      'FEELHAUS_DB_MASTER_ID', 'FEELHAUS_DB_MASTER', 'MASTER_DB_ID', 'MASTER_DB',
      'DB_MASTER_ID', 'PORTAL_DB_ID', 'SPREADSHEET_ID'
    ]);
    var id = mcCalendar19ExtractSpreadsheetId_(raw);
    if (!id) throw new Error('FEELHAUS_DB_MASTER ID를 SystemConfig에서 찾지 못했습니다.');
    return SpreadsheetApp.openById(id);
  };
}

if (typeof mcCalendar19GetSheetOrCreate_ !== 'function') {
  var mcCalendar19GetSheetOrCreate_ = function(ss, sheetName, headers) {
    var sheet = ss.getSheetByName(sheetName);
    if (!sheet) sheet = ss.insertSheet(sheetName);
    headers = headers || [];
    if (headers.length) {
      if (sheet.getLastRow() < 1) {
        sheet.getRange(1, 1, 1, headers.length).setValues([headers]);
      } else {
        var lastCol = Math.max(sheet.getLastColumn(), 1);
        var current = sheet.getRange(1, 1, 1, lastCol).getValues()[0] || [];
        var hm = mcCalendar19HeaderMap_(current);
        var changed = false;
        headers.forEach(function(h) {
          if (!hm.hasOwnProperty(h)) {
            current.push(h);
            hm[h] = current.length - 1;
            changed = true;
          }
        });
        if (changed) sheet.getRange(1, 1, 1, current.length).setValues([current]);
      }
    }
    return sheet;
  };
}

if (typeof mcCalendar19AppendAuditLog_ !== 'function') {
  var mcCalendar19AppendAuditLog_ = function(action, actorKey, targetId, resultStatus, message, payload) {
    try {
      var ss = mcCalendar19OpenMaster_(mcCalendar19GetConfigBundle_());
      var headers = ['logId','createdAt','action','actorKey','targetId','resultStatus','message','payload'];
      var sheet = mcCalendar19GetSheetOrCreate_(ss, 'MAILCENTER_AuditLogs', headers);
      sheet.appendRow([
        'LOG-' + Utilities.formatDate(new Date(), Session.getScriptTimeZone() || 'Asia/Seoul', 'yyyyMMddHHmmss') + '-' + Utilities.getUuid().substring(0, 8).toUpperCase(),
        Utilities.formatDate(new Date(), Session.getScriptTimeZone() || 'Asia/Seoul', 'yyyy-MM-dd HH:mm:ss'),
        String(action || ''), String(actorKey || ''), String(targetId || ''), String(resultStatus || ''), String(message || ''),
        JSON.stringify(payload || {})
      ]);
    } catch (err) {
      Logger.log('AUDIT_LOG_SKIPPED: ' + mcCalendar19ErrorMessage_(err));
    }
  };
}

function mcCalendar186ResolveCalendarActor_(request, configBundle, options) {
  request = request || {};
  options = options || {};
  var sid = String(request.sid || request.mcCalendarSid || request.sessionId || '').trim();
  if (sid && typeof mcCalendar103ValidateSession_ === 'function') {
    var valid = mcCalendar103ValidateSession_(sid);
    if (valid && valid.ok && valid.user) return mcCalendar186NormalizeMailCenterActor_(valid.user, 'sid');
    if (options.requireSid) throw new Error(valid && valid.message ? valid.message : 'MAILCENTER 세션 확인에 실패했습니다.');
  }

  var loginId = String(request.loginId || request.createdBy || '').trim();
  var employeeId = String(request.employeeId || request.ownerEmployeeId || '').trim();
  if (loginId && typeof mcCalendar91LoadProfileByLoginId_ === 'function') {
    var byLogin = mcCalendar91LoadProfileByLoginId_(loginId);
    if (byLogin && byLogin.ok && byLogin.user) return mcCalendar186NormalizeMailCenterActor_(byLogin.user, 'loginId');
  }

  var users = mcCalendar186ReadMailCenterUsersForCalendar_(configBundle);
  var found = null;
  for (var i = 0; i < users.length; i++) {
    if (loginId && String(users[i].loginId || '').toLowerCase() === loginId.toLowerCase()) { found = users[i]; break; }
  }
  if (!found && employeeId) {
    for (var j = 0; j < users.length; j++) {
      if (String(users[j].employeeId || '').toLowerCase() === employeeId.toLowerCase()) { found = users[j]; break; }
    }
  }
  if (!found && options.allowFallback) found = mcCalendar186PickCalendarFallbackUser_(users);
  if (!found) throw new Error('MAILCENTER 로그인 사용자 정보를 찾지 못했습니다. sid 또는 loginId/employeeId를 전달해 주세요.');
  return mcCalendar186NormalizeMailCenterActor_(found, found._source || 'MailCenterUsers');
}

function mcCalendar186ReadMailCenterUsersForCalendar_(configBundle) {
  var ss = mcCalendar19OpenMaster_(configBundle || mcCalendar19GetConfigBundle_());
  var sheet = ss.getSheetByName('MailCenterUsers') || ss.getSheetByName('MAILCENTER_Users');
  if (!sheet) throw new Error('MailCenterUsers 시트를 찾지 못했습니다.');
  var values = sheet.getDataRange().getValues();
  if (!values || values.length < 1) throw new Error('MailCenterUsers 데이터가 비어 있습니다.');
  var headerRowIndex = mcCalendar186DetectCalendarUserHeaderRow_(values);
  if (headerRowIndex < 0) throw new Error('MailCenterUsers 헤더를 찾지 못했습니다.');
  var hm = mcCalendar19HeaderMap_(values[headerRowIndex]);
  var required = ['loginId', 'employeeId', 'roleCode', 'status'];
  var missing = [];
  for (var m = 0; m < required.length; m++) if (!hm.hasOwnProperty(required[m])) missing.push(required[m]);
  if (missing.length) throw new Error('MailCenterUsers 필수 헤더 누락: ' + missing.join(', '));
  var rows = [];
  for (var r = headerRowIndex + 1; r < values.length; r++) {
    var line = values[r] || [];
    var loginId = String(line[hm.loginId] || '').trim();
    var employeeId = String(line[hm.employeeId] || '').trim();
    if (!loginId && !employeeId) continue;
    rows.push({
      userId: hm.hasOwnProperty('userId') ? String(line[hm.userId] || '').trim() : '',
      loginId: loginId,
      employeeId: employeeId,
      employeeName: hm.hasOwnProperty('employeeName') ? String(line[hm.employeeName] || '').trim() : '',
      roleCode: hm.hasOwnProperty('roleCode') ? String(line[hm.roleCode] || '').trim() : '',
      vendorId: hm.hasOwnProperty('vendorId') ? String(line[hm.vendorId] || '').trim() : '',
      isActive: hm.hasOwnProperty('isActive') ? String(line[hm.isActive] || '').trim() : '',
      status: hm.hasOwnProperty('status') ? String(line[hm.status] || '').trim() : '',
      _source: 'MailCenterUsers'
    });
  }
  return rows;
}

function mcCalendar186DetectCalendarUserHeaderRow_(values) {
  for (var r = 0; r < Math.min(values.length, 10); r++) {
    var hm = mcCalendar19HeaderMap_(values[r] || []);
    if (hm.hasOwnProperty('loginId') && hm.hasOwnProperty('employeeId')) return r;
  }
  return -1;
}

function mcCalendar186PickCalendarFallbackUser_(users) {
  users = users || [];
  var preferred = ['pepsi308', 'admin'];
  for (var p = 0; p < preferred.length; p++) {
    for (var i = 0; i < users.length; i++) {
      if (mcCalendar186IsActiveCalendarUser_(users[i]) && String(users[i].loginId || '').toLowerCase() === preferred[p]) return users[i];
    }
  }
  var roles = { 'SUPER_ADMIN': true, 'HQ_ADMIN': true, 'DEV': true };
  for (var j = 0; j < users.length; j++) if (mcCalendar186IsActiveCalendarUser_(users[j]) && roles[String(users[j].roleCode || '').toUpperCase()]) return users[j];
  for (var k = 0; k < users.length; k++) if (mcCalendar186IsActiveCalendarUser_(users[k])) return users[k];
  return users.length ? users[0] : null;
}

function mcCalendar186IsActiveCalendarUser_(user) {
  var status = String(user && user.status || '').toUpperCase();
  var active = String(user && user.isActive || '').toUpperCase();
  if (status && status !== 'ACTIVE') return false;
  if (active && active !== 'TRUE' && active !== 'Y' && active !== '1') return false;
  return true;
}

function mcCalendar186NormalizeMailCenterActor_(user, source) {
  user = user || {};
  var roleCode = String(user.roleCode || '').trim();
  var loginId = String(user.loginId || user.createdBy || '').trim();
  var employeeId = String(user.employeeId || '').trim();
  var permissions = mcCalendar186BuildCalendarPermissions_(roleCode);
  return {
    ok: true,
    source: source || '',
    userId: String(user.userId || '').trim(),
    loginId: loginId,
    email: loginId,
    employeeId: employeeId,
    employeeName: String(user.employeeName || '').trim(),
    roleCode: roleCode,
    vendorId: String(user.vendorId || '').trim(),
    permissions: permissions
  };
}

function mcCalendar186BuildCalendarPermissions_(roleCode) {
  var role = String(roleCode || '').toUpperCase();
  var map = {};
  if (role === 'SUPER_ADMIN' || role === 'HQ_ADMIN' || role === 'DEV') {
    map.ALL = true;
    map.DEV_CONSOLE = true;
    map.CALENDAR_CREATE = true;
    map.CALENDAR_RETRY = true;
    map.CALENDAR_VIEW = true;
    return map;
  }
  if (role === 'STAFF' || role === 'OPERATION' || role === 'VENDOR') {
    map.CALENDAR_CREATE = true;
    map.CALENDAR_VIEW = true;
    if (role === 'OPERATION') map.CALENDAR_RETRY = true;
    return map;
  }
  map.CALENDAR_VIEW = true;
  return map;
}

function mcCalendar186HasPermission_(profile, permissionKey) {
  if (!profile || !profile.permissions) return false;
  return !!(profile.permissions.ALL || profile.permissions[permissionKey]);
}

function mcCalendar186PermissionGuard_(profile, permissionKey) {
  if (!mcCalendar186HasPermission_(profile, permissionKey)) throw new Error('권한이 없습니다: ' + permissionKey + ' / roleCode=' + String(profile && profile.roleCode || ''));
}

function mcCalendar186ActorKey_(profile) {
  return String(profile && (profile.loginId || profile.employeeId || profile.userId) || 'SYSTEM_CALENDAR');
}

function mcCalendar186SafeActorSummary_(profile) {
  return {
    source: String(profile && profile.source || ''),
    loginId: String(profile && profile.loginId || ''),
    employeeId: String(profile && profile.employeeId || ''),
    employeeName: String(profile && profile.employeeName || ''),
    roleCode: String(profile && profile.roleCode || ''),
    vendorId: String(profile && profile.vendorId || '')
  };
}

function mcCalendar19CreateCalendarEvent(request) {
  var result = mcCalendar19SafeResult_('mcCalendar19CreateCalendarEvent');
  request = request || {};
  var actorKey = '';
  var config = null;
  var profile = null;
  var eventRecord = null;
  var providerResults = [];
  try {
    config = mcCalendar19GetConfigBundle_();
    profile = mcCalendar186ResolveCalendarActor_(request, config, { allowFallback: true });
    actorKey = mcCalendar186ActorKey_(profile);
    mcCalendar186PermissionGuard_(profile, 'CALENDAR_CREATE');
    mcCalendar186FeatureGuard_(config.config || {}, 'FEATURE_CALENDAR_ENABLED', '캘린더 기능');

    var normalized = mcCalendar186NormalizeCalendarRequest_(request, profile);
    mcCalendar186ValidateCalendarRequest_(normalized);
    var ss = mcCalendar19OpenMaster_(config);
    mcCalendar186EnsureCalendarModuleSheets_(ss);
    mcCalendar186AssertNoDuplicateCalendarEvent_(ss, normalized);

    eventRecord = mcCalendar186BuildCalendarEventRecord_(normalized, profile);
    mcCalendar186AppendCalendarEvent_(ss, eventRecord);
    mcCalendar186AppendProviderLog_(ss, eventRecord, 'INTERNAL', 'CREATE_EVENT', 'SUCCESS', '', '', '', 'MAILCENTER_CalendarEvents 내부 저장 완료', profile);

    var policy = mcCalendarPolicyV01ResolveProviderPolicy_(config.config || {});

    var naverResult = null;
    if (policy.naverOutboundEnabled) {
      naverResult = mcCalendar186TryProviderCreate_(function(){
        return mcCalendar19CreateNaverCalendarEvent_(config, normalized, normalized._startDate, normalized._endDate);
      }, 'NAVER');
    } else {
      naverResult = mcCalendar186BuildProviderSkippedResult_('NAVER', policy.naverReason);
    }
    providerResults.push(naverResult);
    mcCalendar186ApplyProviderResult_(ss, eventRecord.calendarEventId, 'NAVER', naverResult, profile);

    var googleResult = null;
    if (policy.googleBackupEnabled) {
      googleResult = mcCalendar186TryProviderCreate_(function(){
        return mcCalendar19CreateGoogleCalendarEvent_(config, normalized, normalized._startDate, normalized._endDate, naverResult.ok && !naverResult.skipped ? null : new Error(naverResult.errorMessage || naverResult.message));
      }, 'GOOGLE_BACKUP');
    } else {
      googleResult = mcCalendar186BuildProviderSkippedResult_('GOOGLE_BACKUP', policy.googleReason);
    }
    providerResults.push(googleResult);
    mcCalendar186ApplyProviderResult_(ss, eventRecord.calendarEventId, 'GOOGLE_BACKUP', googleResult, profile);

    var overallStatus = mcCalendar186BuildOverallCalendarStatus_(providerResults);
    mcCalendar186FinalizeCalendarEventStatus_(ss, eventRecord.calendarEventId, overallStatus, profile);
    normalized.calendarProvider = 'INTERNAL,NAVER,GOOGLE_BACKUP';
    normalized.fallbackProvider = 'GOOGLE_BACKUP';
    normalized.calendarEventId = eventRecord.calendarEventId;
    normalized.result = overallStatus.result;
    normalized.statusReason = overallStatus.message;
    normalized.naverStatusReason = naverResult.ok ? '' : naverResult.errorMessage;
    mcCalendar19AppendCalendarLog_(profile, normalized);

    mcCalendar19AppendAuditLog_('CREATE_CALENDAR_EVENT', actorKey, eventRecord.calendarEventId, overallStatus.result, overallStatus.message, {
      calendarEventId: eventRecord.calendarEventId,
      eventTitle: normalized.eventTitle,
      eventId: normalized.eventId,
      customerId: normalized.customerId,
      contractId: normalized.contractId,
      installId: normalized.installId,
      asId: normalized.asId,
      requestId: normalized.requestId,
      providerResults: providerResults,
      actorLoginId: profile.loginId,
      actorEmployeeId: profile.employeeId,
      roleCode: profile.roleCode
    });

    result.ok = true;
    result.calendarEventId = eventRecord.calendarEventId;
    result.eventStatus = overallStatus.result === 'SUCCESS' ? 'REGISTERED' : 'PARTIAL';
    result.createdBy = actorKey;
    result.createdByEmployeeId = profile.employeeId;
    result.ownerEmployeeId = eventRecord.ownerEmployeeId;
    result.assignedEmployeeId = eventRecord.assignedEmployeeId;
    result.providerResults = providerResults;
    result.message = overallStatus.message;
  } catch (err) {
    result.ok = false;
    result.message = mcCalendar19ErrorMessage_(err);
    try {
      if (!config) config = mcCalendar19GetConfigBundle_();
      if (!profile) profile = mcCalendar186ResolveCalendarActor_(request, config, { allowFallback: true });
      actorKey = mcCalendar186ActorKey_(profile);
      request.result = 'FAIL';
      request.statusReason = result.message;
      request.calendarProvider = request.calendarProvider || 'INTERNAL,NAVER_OUTBOUND,GOOGLE_BACKUP';
      request.fallbackProvider = request.fallbackProvider || 'GOOGLE_BACKUP';
      mcCalendar19AppendCalendarLog_(profile, request);
      mcCalendar19AppendAuditLog_('CREATE_CALENDAR_EVENT', actorKey, eventRecord ? eventRecord.calendarEventId : '', 'FAIL', result.message, {
        title: request.eventTitle || request.title || '',
        actorLoginId: profile.loginId,
        actorEmployeeId: profile.employeeId,
        stage: eventRecord ? 'provider_or_log' : 'validation_or_internal_save'
      });
    } catch (ignore) {}
  }
  return mcCalendar19ClientSafeObject_(result);
}

function mcCalendar19CreateNaverCalendarEvent_(configBundle, request, startAt, endAt) {
  var cfg = configBundle.config || {};
  mcCalendar186FeatureGuard_(cfg, 'FEATURE_NAVER_CALENDAR_ENABLED', '네이버 캘린더');
  var freshToken = mcCalendar25EnsureFreshNaverAccessToken_(cfg, 'NAVER_CALENDAR_CREATE');
  if (freshToken.refreshed) {
    configBundle = mcCalendar19GetConfigBundle_();
    cfg = configBundle.config || {};
  }
  var settingCheck = mcCalendar21BuildNaverSettingCheck_(cfg);
  if (!settingCheck.ready) throw new Error('NAVER 캘린더 설정 미완료: ' + settingCheck.missingKeys.join(', '));

  var token = freshToken.accessToken || mcCalendar19PickConfig_(cfg, [
    'NAVER_CALENDAR_ACCESS_TOKEN',
    'NAVER_ACCESS_TOKEN',
    'NAVER_CALENDAR_TOKEN'
  ]);
  if (!token) throw new Error('NAVER 캘린더 토큰이 SystemConfig에 없습니다.');

  // 로그로 성공 확인된 MAILCENTER 31/35 방식: NAVER_CALENDAR_ID를 읽거나 보내지 않고 literal defaultCalendarId 사용.
  var calendarId = 'defaultCalendarId';
  var timezone = Session.getScriptTimeZone() || 'Asia/Seoul';
  var description = String(request.description || 'FEELHAUS MAILCENTER NAVER 실제등록');
  var endpoint = mcCalendar19PickConfig_(cfg, [
    'NAVER_CALENDAR_CREATE_URL',
    'NAVER_CALENDAR_API_URL'
  ]) || 'https://openapi.naver.com/calendar/createSchedule.json';
  var payload = {
    calendarId: calendarId,
    title: String(request.title || ''),
    description: description,
    start: Utilities.formatDate(startAt, timezone, "yyyy-MM-dd'T'HH:mm:ssXXX"),
    end: Utilities.formatDate(endAt, timezone, "yyyy-MM-dd'T'HH:mm:ssXXX"),
    targetType: request.targetType || '',
    targetId: request.targetId || ''
  };
  var ical = mcCalendar19BuildNaverIcal_(payload);
  var encodedBody = mcCalendar26BuildNaverFormBody_({
    calendarId: calendarId,
    scheduleIcalString: ical
  });
  var requestOptions = mcCalendar27BuildNaverCreateRequestOptions_(token, encodedBody);
  var response = UrlFetchApp.fetch(endpoint, requestOptions);
  var code = response.getResponseCode();
  var body = response.getContentText() || '';
  var authRetry = false;
  var retryTokenExpiresAt = freshToken.expiresAt || '';
  var retryMessage = '';

  if (code === 401 && mcCalendar27CanRefreshNaverToken_(cfg)) {
    try {
      var refreshed = mcCalendar25RefreshNaverAccessToken_(cfg, 'NAVER_CALENDAR_401_RETRY');
      authRetry = true;
      token = refreshed.accessToken;
      retryTokenExpiresAt = refreshed.expiresAt || '';
      requestOptions = mcCalendar27BuildNaverCreateRequestOptions_(token, encodedBody);
      response = UrlFetchApp.fetch(endpoint, requestOptions);
      code = response.getResponseCode();
      body = response.getContentText() || '';
      retryMessage = refreshed.message || 'NAVER access token 401 후 강제 갱신';
    } catch (refreshErr) {
      retryMessage = '401 후 token 갱신 실패: ' + mcCalendar19ErrorMessage_(refreshErr);
    }
  }

  if (code < 200 || code >= 300) {
    var debug = {
      endpoint: endpoint,
      calendarId: calendarId,
      calendarIdSource: 'fixed_defaultCalendarId',
      naverCalendarIdIgnored: true,
      authorizationScheme: 'Bearer',
      hasClientIdHeader: false,
      hasClientSecretHeader: false,
      contentType: requestOptions.contentType,
      payloadMode: 'raw_urlencoded_string',
      payloadKeys: ['calendarId', 'scheduleIcalString'],
      scheduleIcalLength: ical.length,
      encodedBodyLength: encodedBody.length,
      bodyPreview: mcCalendar26SafeBodyPreview_(encodedBody),
      tokenRefreshed: !!freshToken.refreshed,
      authRetryAfter401: authRetry,
      retryMessage: retryMessage,
      tokenExpiresAt: retryTokenExpiresAt || freshToken.expiresAt || ''
    };
    throw new Error('NAVER 캘린더 등록 실패: HTTP ' + code + ' ' + body.substring(0, 300) + ' / DEBUG=' + JSON.stringify(debug));
  }

  var parsedBody = null;
  var eventId = '';
  try {
    parsedBody = JSON.parse(body);
  } catch (ignore) {
    parsedBody = null;
  }

  var naverResult = parsedBody && parsedBody.result !== undefined ? String(parsedBody.result || '') : '';
  var naverMessage = parsedBody && parsedBody.message !== undefined ? String(parsedBody.message || '') : '';
  var naverErrorCode = parsedBody && parsedBody.errorCode !== undefined ? String(parsedBody.errorCode || '') : '';
  var naverErrorMessage = parsedBody && parsedBody.errorMessage !== undefined ? String(parsedBody.errorMessage || '') : '';
  var lowerBody = String(body || '').toLowerCase();
  var lowerResult = naverResult.toLowerCase();

  // MAILCENTER 35에서 정정한 기준: HTTP 200이어도 result=fail/errorMessage이면 실패로 처리.
  if (naverErrorCode || naverErrorMessage || lowerResult === 'fail' || lowerBody === 'fail') {
    var failDebug = {
      endpoint: endpoint,
      calendarId: calendarId,
      calendarIdSource: 'fixed_defaultCalendarId',
      naverCalendarIdIgnored: true,
      httpCode: code,
      naverResult: naverResult,
      naverMessage: naverMessage,
      naverErrorCode: naverErrorCode,
      naverErrorMessage: naverErrorMessage,
      bodyPreview: mcCalendar26SafeBodyPreview_(body),
      tokenRefreshed: !!freshToken.refreshed,
      authRetryAfter401: authRetry,
      retryMessage: retryMessage,
      tokenExpiresAt: retryTokenExpiresAt || freshToken.expiresAt || ''
    };
    throw new Error('NAVER 캘린더 등록 실패: HTTP ' + code + ' response=' + body.substring(0, 300) + ' / DEBUG=' + JSON.stringify(failDebug));
  }

  if (parsedBody) {
    var nested = parsedBody && typeof parsedBody.result === 'object' ? parsedBody.result : {};
    eventId = parsedBody.id || parsedBody.scheduleId || parsedBody.uid || parsedBody.eventId || parsedBody.calendarEventId || parsedBody.returnValue ||
      nested.id || nested.scheduleId || nested.uid || nested.eventId || nested.calendarEventId || nested.returnValue || '';
    // NAVER 일반 캘린더 API는 result=success만 반환할 수 있음. MAILCENTER 35 성공 로그 기준으로 성공 placeholder 허용.
    if (!eventId && lowerResult === 'success') eventId = 'NAVER_CALENDAR_EVENT_SUCCESS';
    if (!eventId && naverMessage && naverMessage.toLowerCase() !== 'fail') eventId = naverMessage;
  } else if (body) {
    eventId = 'NAVER_CALENDAR_EVENT';
  }

  if (String(eventId || '').toLowerCase() === 'fail') {
    throw new Error('NAVER 캘린더 등록 실패: HTTP ' + code + ' response=' + body.substring(0, 300));
  }

  return {
    provider: 'NAVER',
    eventId: eventId || 'NAVER_CALENDAR_EVENT',
    providerResponseCode: code,
    providerBodyStatus: String(naverResult || naverMessage || ''),
    message: authRetry ? 'NAVER access token 401 후 강제 갱신 등록 완료' : 'NAVER 기본 캘린더(defaultCalendarId) 등록 완료',
    calendarId: calendarId,
    tokenRefreshed: !!freshToken.refreshed || authRetry,
    tokenExpiresAt: retryTokenExpiresAt || freshToken.expiresAt || ''
  };
}

function mcCalendar27BuildNaverCreateRequestOptions_(token, encodedBody) {
  return {
    method: 'post',
    muteHttpExceptions: true,
    contentType: 'application/x-www-form-urlencoded',
    headers: {
      Authorization: 'Bearer ' + token
    },
    payload: encodedBody
  };
}

function mcCalendar27CanRefreshNaverToken_(cfg) {
  return !!mcCalendar19PickConfig_(cfg, ['NAVER_REFRESH_TOKEN', 'NAVER_CALENDAR_REFRESH_TOKEN'])
    && !!mcCalendar19PickConfig_(cfg, ['NAVER_CLIENT_ID', 'NAVER_CALENDAR_CLIENT_ID'])
    && !!mcCalendar19PickConfig_(cfg, ['NAVER_CLIENT_SECRET', 'NAVER_CALENDAR_CLIENT_SECRET']);
}

function mcCalendar19CreateGoogleCalendarEvent_(configBundle, request, startAt, endAt, naverErr) {
  var cfg = configBundle.config || {};
  mcCalendar186FeatureGuard_(cfg, 'FEATURE_GOOGLE_CALENDAR_BACKUP_ENABLED', '구글 캘린더 백업');
  var googleCalendarId = mcCalendar19PickConfig_(cfg, ['GOOGLE_CALENDAR_ID']);
  var cal = googleCalendarId ? CalendarApp.getCalendarById(String(googleCalendarId)) : CalendarApp.getDefaultCalendar();
  if (!cal) throw new Error('GOOGLE_CALENDAR_ID 캘린더를 찾을 수 없습니다.');
  var description = (typeof portalCalendarExternalAutoSyncV01BusinessDescriptionV05_ === 'function')
    ? portalCalendarExternalAutoSyncV01BusinessDescriptionV05_(request)
    : String(request.eventDescription || request.description || 'FEELHAUS MAILCENTER 캘린더 백업 등록');
  if (naverErr) description += '\nNAVER 기본 캘린더 실패 후 GOOGLE 보조 캘린더로 등록: ' + mcCalendar19ErrorMessage_(naverErr);
  var event = cal.createEvent(String(request.title || request.eventTitle || ''), startAt, endAt, { description: description, location: String(request.location || request.displayLocation || '') });
  try { if ((request.location || request.displayLocation) && typeof event.setLocation === 'function') event.setLocation(String(request.location || request.displayLocation)); } catch (ignoreLocation) {}
  return {
    provider: 'GOOGLE_BACKUP',
    eventId: event.getId(),
    message: naverErr ? 'NAVER 실패 후 GOOGLE 보조 백업 등록 완료' : 'GOOGLE 보조 백업 등록 완료'
  };
}


function mcCalendar26BuildNaverFormBody_(params) {
  var parts = [];
  var keys = Object.keys(params || {});
  for (var i = 0; i < keys.length; i++) {
    var key = keys[i];
    var value = params[key] == null ? '' : String(params[key]);
    parts.push(encodeURIComponent(key) + '=' + encodeURIComponent(value));
  }
  return parts.join('&');
}

function mcCalendar26SafeBodyPreview_(body) {
  body = String(body || '');
  if (!body) return '';
  var preview = body.substring(0, 160);
  preview = preview.replace(/scheduleIcalString=[^&]*/g, 'scheduleIcalString=[ICAL_ENCODED_OMITTED]');
  return preview;
}

function mcCalendar19BuildNaverIcal_(payload) {
  var uid = Utilities.getUuid() + '@feelhaus.mcCalendar35';
  function esc(v) {
    return String(v || '').replace(/\\/g, '\\\\').replace(/;/g, '\\;').replace(/,/g, '\\,').replace(/\n/g, '\\n');
  }
  function dtLocal(v) {
    var d = v instanceof Date ? v : new Date(v);
    if (!d || isNaN(d.getTime())) d = new Date();
    return Utilities.formatDate(d, 'Asia/Seoul', "yyyyMMdd'T'HHmmss");
  }
  function dtUtc(v) {
    var d = v instanceof Date ? v : new Date(v);
    if (!d || isNaN(d.getTime())) d = new Date();
    return Utilities.formatDate(d, 'UTC', "yyyyMMdd'T'HHmmss'Z'");
  }
  var now = new Date();
  return [
    'BEGIN:VCALENDAR',
    'VERSION:2.0',
    'PRODID:-//FEELHAUS//MAILCENTER35//KO',
    'CALSCALE:GREGORIAN',
    'BEGIN:VTIMEZONE',
    'TZID:Asia/Seoul',
    'X-LIC-LOCATION:Asia/Seoul',
    'BEGIN:STANDARD',
    'TZOFFSETFROM:+0900',
    'TZOFFSETTO:+0900',
    'TZNAME:KST',
    'DTSTART:19700101T000000',
    'END:STANDARD',
    'END:VTIMEZONE',
    'BEGIN:VEVENT',
    'SEQUENCE:0',
    'CLASS:PUBLIC',
    'TRANSP:OPAQUE',
    'UID:' + uid,
    'SUMMARY:' + esc(payload.title),
    'DESCRIPTION:' + esc(payload.description + '\n' + payload.targetType + ':' + payload.targetId),
    'DTSTART;TZID=Asia/Seoul:' + dtLocal(payload.start),
    'DTEND;TZID=Asia/Seoul:' + dtLocal(payload.end),
    'CREATED:' + dtUtc(now),
    'DTSTAMP:' + dtUtc(now),
    'LAST-MODIFIED:' + dtUtc(now),
    'PRIORITY:0',
    'END:VEVENT',
    'END:VCALENDAR'
  ].join('\r\n');
}

function mcCalendar19FormatCalendarDateTime_(dateObj) {
  return Utilities.formatDate(dateObj, Session.getScriptTimeZone() || 'Asia/Seoul', 'yyyy-MM-dd HH:mm');
}

function mcCalendar19CreateSelfTestCalendarEvent() {
  var start = new Date(new Date().getTime() + 30 * 60000);
  var end = new Date(start.getTime() + 30 * 60000);
  return mcCalendar19CreateCalendarEvent({
    targetType: 'SELF_TEST',
    targetId: 'MAILCENTER19_CALENDAR_TEST',
    title: 'FEELHAUS MAILCENTER 19 테스트 일정',
    startAt: start.toISOString(),
    endAt: end.toISOString()
  });
}


function mcCalendar21CheckNaverCalendarSettings(request) {
  var result = mcCalendar19SafeResult_('mcCalendar21CheckNaverCalendarSettings');
  request = request || {};
  try {
    var config = mcCalendar19GetConfigBundle_();
    var profile = mcCalendar186ResolveCalendarActor_(request, config, { allowFallback: true });
    var actorKey = mcCalendar186ActorKey_(profile);
    mcCalendar186PermissionGuard_(profile, 'CALENDAR_CREATE');
    var check = mcCalendar21BuildNaverSettingCheck_(config.config || {});
    result.ok = true;
    result.ready = check.ready;
    result.provider = 'NAVER_PRIMARY';
    result.fallbackProvider = 'GOOGLE_BACKUP';
    result.actor = mcCalendar186SafeActorSummary_(profile);
    result.message = check.ready ? 'NAVER 캘린더 설정 준비 완료' : 'NAVER 캘린더 설정 미완료: ' + check.missingKeys.join(', ');
    result.check = check;
    mcCalendar19AppendAuditLog_('NAVER_CALENDAR_SETTING_CHECK', actorKey, '', check.ready ? 'SUCCESS' : 'FAIL', result.message, check.safeSummary);
  } catch (err) {
    result.ok = false;
    result.ready = false;
    result.message = mcCalendar19ErrorMessage_(err);
  }
  return mcCalendar19ClientSafeObject_(result);
}

function mcCalendar21BuildNaverSettingCheck_(cfg) {
  var requiredAny = [
    { name: 'NAVER access token', keys: ['NAVER_CALENDAR_ACCESS_TOKEN', 'NAVER_ACCESS_TOKEN', 'NAVER_CALENDAR_TOKEN'] }
  ];
  var optional = [
    { name: 'NAVER_CALENDAR_ENABLED', keys: ['NAVER_CALENDAR_ENABLED'] },
    { name: 'NAVER_CLIENT_ID', keys: ['NAVER_CLIENT_ID', 'NAVER_CALENDAR_CLIENT_ID'] },
    { name: 'NAVER_CLIENT_SECRET', keys: ['NAVER_CLIENT_SECRET', 'NAVER_CALENDAR_CLIENT_SECRET'] },
    { name: 'NAVER_REFRESH_TOKEN', keys: ['NAVER_REFRESH_TOKEN', 'NAVER_CALENDAR_REFRESH_TOKEN'] },
    { name: 'NAVER_TOKEN_EXPIRES_AT', keys: ['NAVER_TOKEN_EXPIRES_AT', 'NAVER_CALENDAR_TOKEN_EXPIRES_AT'] },
    { name: 'NAVER_CALENDAR_CREATE_URL', keys: ['NAVER_CALENDAR_CREATE_URL', 'NAVER_CALENDAR_API_URL'] }
  ];
  var missing = [];
  var present = [];
  for (var i = 0; i < requiredAny.length; i++) {
    var value = mcCalendar19PickConfig_(cfg, requiredAny[i].keys);
    if (value) present.push(requiredAny[i].name); else missing.push(requiredAny[i].name + ' (' + requiredAny[i].keys.join(' 또는 ') + ')');
  }
  var optionalStatus = [];
  for (var j = 0; j < optional.length; j++) {
    optionalStatus.push({ name: optional[j].name, exists: !!mcCalendar19PickConfig_(cfg, optional[j].keys) });
  }
  var enabled = mcCalendar19PickConfig_(cfg, ['NAVER_CALENDAR_ENABLED']);
  var disabled = String(enabled || '').toUpperCase() === 'N' || String(enabled || '').toUpperCase() === 'FALSE' || String(enabled || '').toUpperCase() === 'OFF';
  if (disabled) missing.push('NAVER_CALENDAR_ENABLED 값이 OFF/FALSE/N 입니다.');
  return {
    ready: missing.length === 0,
    missingKeys: missing,
    presentRequired: present,
    optionalStatus: optionalStatus,
    safeSummary: {
      ready: missing.length === 0,
      missingCount: missing.length,
      calendarIdRequired: false,
      calendarIdConfigured: false,
      calendarIdMode: 'defaultCalendarId',
      accessTokenConfigured: !!mcCalendar19PickConfig_(cfg, ['NAVER_CALENDAR_ACCESS_TOKEN', 'NAVER_ACCESS_TOKEN', 'NAVER_CALENDAR_TOKEN']),
      createUrlConfigured: !!mcCalendar19PickConfig_(cfg, ['NAVER_CALENDAR_CREATE_URL', 'NAVER_CALENDAR_API_URL']),
      fallbackProvider: 'GOOGLE_BACKUP'
    }
  };
}


function mcCalendar22EnsureNaverSystemConfigRows() {
  var result = mcCalendar19SafeResult_('mcCalendar22EnsureNaverSystemConfigRows');
  try {
    var cfgBundle = mcCalendar19GetConfigBundle_();
    var profile = mcCalendar186ResolveCalendarActor_({}, cfgBundle, { allowFallback: true });
    var actorKey = mcCalendar186ActorKey_(profile);
    mcCalendar186PermissionGuard_(profile, 'DEV_CONSOLE');

    var setup = SpreadsheetApp.openById(MAILCENTER19_SETUP_DB_ID);
    var sheet = setup.getSheetByName(MAILCENTER19_CONFIG_SHEET);
    if (!sheet) throw new Error('SystemConfig 시트를 찾을 수 없습니다.');
    var values = sheet.getDataRange().getValues();
    if (!values || values.length < 1) throw new Error('SystemConfig 헤더가 없습니다.');
    var headers = mcCalendar19HeaderMap_(values[0]);
    var keyCol = mcCalendar19FindHeader_(headers, ['CONFIG_KEY']);
    var valueCol = mcCalendar19FindHeader_(headers, ['VALUE']);
    if (keyCol < 0 || valueCol < 0) throw new Error('SystemConfig 필수 헤더(CONFIG_KEY/VALUE)를 찾을 수 없습니다.');

    var existing = {};
    for (var r = 1; r < values.length; r++) {
      var key = String(values[r][keyCol] || '').trim();
      if (key) existing[key] = true;
    }
    var requiredRows = [
      { key: 'NAVER_CALENDAR_ENABLED', value: 'N', category: 'CALENDAR', subCategory: 'NAVER', projectScope: 'MAILCENTER', description: 'NAVER 기본 캘린더 사용 여부. 실등록 검증 전 Y로 변경', isRequired: 'Y', isSensitive: 'N', status: 'ACTIVE' },
      { key: 'NAVER_CLIENT_ID', value: '', category: 'CALENDAR', subCategory: 'NAVER', projectScope: 'MAILCENTER', description: 'NAVER Developers Client ID', isRequired: 'Y', isSensitive: 'N', status: 'ACTIVE' },
      { key: 'NAVER_CLIENT_SECRET', value: '', category: 'CALENDAR', subCategory: 'NAVER', projectScope: 'MAILCENTER', description: 'NAVER Developers Client Secret. 민감값', isRequired: 'Y', isSensitive: 'Y', status: 'ACTIVE' },
      { key: 'NAVER_CALENDAR_ID', value: '', category: 'CALENDAR', subCategory: 'NAVER', projectScope: 'MAILCENTER', description: '사용중지. 일반 네이버 캘린더 API 기준 필수값 아님. 입력 금지.', isRequired: 'N', isSensitive: 'N', status: 'INACTIVE' },
      { key: 'NAVER_CALENDAR_ACCESS_TOKEN', value: '', category: 'CALENDAR', subCategory: 'NAVER', projectScope: 'MAILCENTER', description: 'NAVER 캘린더 API access token. 민감값', isRequired: 'Y', isSensitive: 'Y', status: 'ACTIVE' },
      { key: 'NAVER_REFRESH_TOKEN', value: '', category: 'CALENDAR', subCategory: 'NAVER', projectScope: 'MAILCENTER', description: 'NAVER refresh token. 민감값', isRequired: 'N', isSensitive: 'Y', status: 'ACTIVE' },
      { key: 'NAVER_TOKEN_EXPIRES_AT', value: '', category: 'CALENDAR', subCategory: 'NAVER', projectScope: 'MAILCENTER', description: 'NAVER access token 만료 예정 시간', isRequired: 'N', isSensitive: 'N', status: 'ACTIVE' },
      { key: 'NAVER_TOKEN_TYPE', value: 'bearer', category: 'CALENDAR', subCategory: 'NAVER', projectScope: 'MAILCENTER', description: 'NAVER OAuth token type', isRequired: 'N', isSensitive: 'N', status: 'ACTIVE' },
      { key: 'NAVER_CALENDAR_CREATE_URL', value: 'https://openapi.naver.com/calendar/createSchedule.json', category: 'CALENDAR', subCategory: 'NAVER', projectScope: 'MAILCENTER', description: 'NAVER 일정 생성 API URL', isRequired: 'N', isSensitive: 'N', status: 'ACTIVE' }
    ];
    var created = [];
    var present = [];
    for (var i = 0; i < requiredRows.length; i++) {
      var spec = requiredRows[i];
      if (existing[spec.key]) {
        present.push(spec.key);
        mcCalendar28SyncNaverConfigMetadata_(sheet, headers, values, keyCol, valueCol, spec, actorKey);
        continue;
      }
      var row = [];
      for (var c = 0; c < values[0].length; c++) row.push('');
      row[keyCol] = spec.key;
      row[valueCol] = spec.value;
      mcCalendar22SetIfHeader_(headers, row, 'category', spec.category);
      mcCalendar22SetIfHeader_(headers, row, 'subCategory', spec.subCategory);
      mcCalendar22SetIfHeader_(headers, row, 'projectScope', spec.projectScope);
      mcCalendar22SetIfHeader_(headers, row, 'description', spec.description);
      mcCalendar22SetIfHeader_(headers, row, 'DESCRIPTION', spec.description);
      mcCalendar22SetIfHeader_(headers, row, 'isRequired', spec.isRequired);
      mcCalendar22SetIfHeader_(headers, row, 'isSensitive', spec.isSensitive);
      mcCalendar22SetIfHeader_(headers, row, 'status', spec.status);
      mcCalendar22SetIfHeader_(headers, row, 'updatedAt', mcCalendar19Now_());
      mcCalendar22SetIfHeader_(headers, row, 'UPDATED_AT', mcCalendar19Now_());
      mcCalendar22SetIfHeader_(headers, row, 'updatedBy', actorKey);
      sheet.appendRow(row);
      created.push(spec.key);
    }
    result.ok = true;
    result.createdKeys = created;
    result.existingKeys = present;
    result.message = created.length ? 'NAVER SystemConfig 설정 행 생성 완료: ' + created.join(', ') : 'NAVER SystemConfig 설정 행이 이미 있습니다.';
    mcCalendar19AppendAuditLog_('NAVER_CONFIG_ROWS', actorKey, '', 'SUCCESS', result.message, { createdKeys: created, existingKeys: present });
  } catch (err) {
    result.ok = false;
    result.message = mcCalendar19ErrorMessage_(err);
  }
  return result;
}

function mcCalendar22SetIfHeader_(headers, row, headerName, value) {
  var idx = mcCalendar19FindHeader_(headers, [headerName]);
  if (idx >= 0) row[idx] = value;
}

function mcCalendar28SyncNaverConfigMetadata_(sheet, headers, values, keyCol, valueCol, spec, updatedBy) {
  var targetRow = -1;
  for (var r = 1; r < values.length; r++) {
    if (String(values[r][keyCol] || '').trim() === spec.key) {
      targetRow = r + 1;
      break;
    }
  }
  if (targetRow < 0) return;
  if (spec.key === 'NAVER_CALENDAR_ID') sheet.getRange(targetRow, valueCol + 1).setValue('');
  mcCalendar28SetCellIfHeader_(sheet, headers, targetRow, 'description', spec.description);
  mcCalendar28SetCellIfHeader_(sheet, headers, targetRow, 'DESCRIPTION', spec.description);
  mcCalendar28SetCellIfHeader_(sheet, headers, targetRow, 'isRequired', spec.isRequired);
  mcCalendar28SetCellIfHeader_(sheet, headers, targetRow, 'isSensitive', spec.isSensitive);
  mcCalendar28SetCellIfHeader_(sheet, headers, targetRow, 'status', spec.status);
  mcCalendar28SetCellIfHeader_(sheet, headers, targetRow, 'updatedAt', mcCalendar19Now_());
  mcCalendar28SetCellIfHeader_(sheet, headers, targetRow, 'UPDATED_AT', mcCalendar19Now_());
  mcCalendar28SetCellIfHeader_(sheet, headers, targetRow, 'updatedBy', updatedBy || '');
}

function mcCalendar28SetCellIfHeader_(sheet, headers, rowIndex, headerName, value) {
  var idx = mcCalendar19FindHeader_(headers, [headerName]);
  if (idx >= 0) sheet.getRange(rowIndex, idx + 1).setValue(value);
}

function mcCalendar22CreateNaverOnlySelfTestCalendarEvent() {
  var result = mcCalendar19SafeResult_('mcCalendar22CreateNaverOnlySelfTestCalendarEvent');
  var request = {};
  try {
    var config = mcCalendar19GetConfigBundle_();
    var profile = mcCalendar186ResolveCalendarActor_(request, config, { allowFallback: true });
    var actorKey = mcCalendar186ActorKey_(profile);
    mcCalendar186PermissionGuard_(profile, 'CALENDAR_CREATE');
    var start = new Date(new Date().getTime() + 30 * 60000);
    var end = new Date(start.getTime() + 30 * 60000);
    request = {
      targetType: 'SELF_TEST',
      targetId: 'MAILCENTER24_NAVER_REAL_TEST',
      title: 'FEELHAUS MAILCENTER 29 NAVER no-calendar-id 실제등록 테스트',
      startAt: mcCalendar19FormatCalendarDateTime_(start),
      endAt: mcCalendar19FormatCalendarDateTime_(end),
      fallbackProvider: '',
      calendarProvider: 'NAVER',
      calendarEventId: '',
      naverStatusReason: ''
    };
    var settingCheck = mcCalendar21BuildNaverSettingCheck_(config.config || {});
    if (!settingCheck.ready) throw new Error('NAVER 실제등록 차단: ' + settingCheck.missingKeys.join(', '));
    var providerResult = mcCalendar19CreateNaverCalendarEvent_(config, request, start, end);
    request.calendarProvider = 'NAVER';
    request.calendarEventId = providerResult.eventId || '';
    request.result = 'SUCCESS';
    request.statusReason = providerResult.message || 'NAVER 기본 캘린더(defaultCalendarId) 실제등록 완료';
    request.naverStatusReason = providerResult.tokenRefreshed ? 'NAVER access token 자동 갱신 후 등록 성공' : 'NAVER access token 유효 상태로 등록 성공';
    mcCalendar19AppendCalendarLog_(profile, request);
    mcCalendar19AppendAuditLog_('NAVER_REAL_CREATE', actorKey, request.targetId, 'SUCCESS', request.statusReason, { calendarEventId: request.calendarEventId });
    result.ok = true;
    result.calendarProvider = 'NAVER';
    result.calendarEventId = request.calendarEventId;
    result.calendarId = providerResult.calendarId || '';
    result.message = 'NAVER 기본 캘린더(defaultCalendarId) 실제등록 및 CalendarLog 저장 완료';
  } catch (err) {
    result.ok = false;
    result.message = mcCalendar19ErrorMessage_(err);
    try {
      var failConfig = mcCalendar19GetConfigBundle_();
      var failProfile = mcCalendar186ResolveCalendarActor_(request, failConfig, { allowFallback: true });
      var failActorKey = mcCalendar186ActorKey_(failProfile);
      request.targetType = request.targetType || 'SELF_TEST';
      request.targetId = request.targetId || 'MAILCENTER24_NAVER_REAL_TEST';
      request.title = request.title || 'FEELHAUS MAILCENTER 29 NAVER no-calendar-id 실제등록 테스트';
      request.calendarProvider = 'NAVER';
      request.result = 'FAIL';
      request.statusReason = result.message;
      request.naverStatusReason = result.message;
      mcCalendar19AppendCalendarLog_(failProfile, request);
      mcCalendar19AppendAuditLog_('NAVER_REAL_CREATE', failActorKey, request.targetId, 'FAIL', result.message, {});
    } catch (ignore) {}
  }
  return result;
}


/* Build: MC_CALENDAR_PROVIDER_POLICY_ALIGN_V01_20260527
 * Previous: MAILCENTER_CALENDAR_CORE_CLONE_V01_20260521
 * Calendar module add-on. MAILCENTER body remains light; external providers never run on MailCenterHome boot.
 */
function mcCalendar186CalendarEventHeaders_() {
  return ['calendarEventId','sourceType','sourceModule','sourceId','calendarType','eventId','vendorId','customerId','saleId','contractId','installId','asId','documentId','requestId','mailRecordId','scheduleId','provider','providerEventId','providerCalendarId','eventType','title','eventTitle','description','eventDescription','startAt','endAt','allDay','allDayYn','timezone','location','meetingUrl','attendees','attendeesJson','organizerEmail','ownerEmployeeId','assignedEmployeeId','ownerName','ownerUserId','departmentCode','organizerRole','eventStatus','status','statusReason','syncTarget','googleSyncStatus','naverSyncStatus','lastSyncAt','naverRegisterStatus','naverProviderEventId','naverEventId','naverIcalUid','naverCalendarId','naverProviderCalendarId','naverLastProcessType','naverErrorCode','naverErrorMessage','googleBackupStatus','googleProviderEventId','googleEventId','googleCalendarEventId','googleErrorCode','googleErrorMessage','retryCount','lastRetryAt','locked','createdAt','createdBy','updatedAt','updatedBy'];
}

function mcCalendar186CalendarLogHeaders_() {
  return ['calendarLogId','calendarEventId','provider','actionType','resultStatus','providerEventId','errorCode','errorMessage','requestPayloadSummary','responseSummary','createdAt','createdBy'];
}

function mcCalendar186CalendarRetryHeaders_() {
  return ['retryId','calendarEventId','provider','retryStatus','retryCount','lastErrorCode','lastErrorMessage','nextRetryAt','createdAt','updatedAt'];
}


function mcCalendarPolicyV01ResolveProviderPolicy_(cfg) {
  cfg = cfg || {};
  var naverEnabled = mcCalendarPolicyV01ConfigOn_(cfg, 'FEATURE_NAVER_CALENDAR_ENABLED', false) || mcCalendarPolicyV01ConfigOn_(cfg, 'NAVER_CALENDAR_ENABLED', false);
  var googleEnabled = mcCalendarPolicyV01ConfigOn_(cfg, 'FEATURE_GOOGLE_CALENDAR_BACKUP_ENABLED', false);
  var googleSyncEnabled = mcCalendarPolicyV01ConfigOn_(cfg, 'FEATURE_GOOGLE_CALENDAR_BIDIRECTIONAL_SYNC_ENABLED', false);
  return {
    policyBuild: 'MC_GOOGLE_CALENDAR_BIDIRECTIONAL_SYNC_PREP_V01_20260527',
    masterLedger: 'MAILCENTER_CalendarEvents',
    naverOutboundEnabled: naverEnabled,
    naverInboundAutoImportEnabled: false,
    naverBidirectionalEnabled: false,
    naverReason: naverEnabled ? 'PORTAL 원장 기준 NAVER 캘린더 등록 시도 허용. NAVER 직접입력 자동수집/양방향은 제외' : 'NAVER는 자동 양방향/자동 가져오기 대상이 아니며, SystemConfig OFF 상태에서는 외부 등록도 건너뜀',
    googleBackupEnabled: googleEnabled,
    googleBidirectionalReady: true,
    googleBidirectionalEnabled: googleSyncEnabled,
    googleReason: googleSyncEnabled ? 'GOOGLE 양방향 동기화 준비 완료 및 SystemConfig ON. 실제 동기화는 전용 함수에서 dryRun 우선 수행' : (googleEnabled ? 'GOOGLE_BACKUP 단방향 등록 허용. 양방향은 준비 완료, SystemConfig OFF 상태' : 'GOOGLE_BACKUP/SystemConfig OFF. 양방향 준비 구조만 활성'),
    providerWriteOrder: 'INTERNAL_LEDGER_FIRST',
    naverDataReceiveMode: 'MANUAL_DB_OR_EXPORT_TO_LEDGER',
    googleSyncMode: googleSyncEnabled ? 'BIDIRECTIONAL_SYNC_READY_CONFIG_ON' : 'BIDIRECTIONAL_SYNC_READY_CONFIG_OFF'
  };
}

function mcCalendarPolicyV01ConfigOn_(cfg, key, defaultValue) {
  if (!cfg || !cfg.hasOwnProperty(key)) return !!defaultValue;
  var value = String(cfg[key] || '').trim().toUpperCase();
  if (!value) return !!defaultValue;
  return value === 'Y' || value === 'YES' || value === 'TRUE' || value === '1' || value === 'ON' || value === 'ENABLED';
}

function mcCalendarPolicyV01GetStatus(request) {
  var result = mcCalendar19SafeResult_('mcCalendarPolicyV01GetStatus');
  request = request || {};
  try {
    var config = mcCalendar19GetConfigBundle_();
    var profile = mcCalendar186ResolveCalendarActor_(request, config, { allowFallback: true });
    mcCalendar186PermissionGuard_(profile, 'CALENDAR_VIEW');
    result.ok = true;
    result.build = 'MC_CALENDAR_PROVIDER_POLICY_ALIGN_V01_20260527';
    result.message = '캘린더 provider 정책 조회 완료';
    result.policy = mcCalendarPolicyV01ResolveProviderPolicy_(config.config || {});
    result.actor = mcCalendar186SafeActorSummary_(profile);
  } catch (err) {
    result.ok = false;
    result.message = mcCalendar19ErrorMessage_(err);
  }
  return mcCalendar19ClientSafeObject_(result);
}

function mcCalendar186FeatureGuard_(cfg, key, label) {
  var value = String(cfg && cfg.hasOwnProperty(key) ? cfg[key] : 'Y').toUpperCase();
  if (value === 'N' || value === 'FALSE' || value === 'OFF' || value === '0') throw new Error(label + '이 SystemConfig에서 비활성화되어 있습니다: ' + key);
}

function mcCalendar186EnsureCalendarModuleSheets_(ss) {
  mcCalendar19GetSheetOrCreate_(ss, 'MAILCENTER_CalendarEvents', mcCalendar186CalendarEventHeaders_());
  mcCalendar19GetSheetOrCreate_(ss, 'MAILCENTER_CalendarLogs', mcCalendar186CalendarLogHeaders_());
  mcCalendar19GetSheetOrCreate_(ss, 'MAILCENTER_CalendarRetryQueue', mcCalendar186CalendarRetryHeaders_());
}

function mcCalendar186NormalizeCalendarRequest_(request, profile) {
  var title = String(request.eventTitle || request.title || '').trim();
  var startAt = request.startAt ? new Date(request.startAt) : null;
  var endAt = request.endAt ? new Date(request.endAt) : null;
  var normalized = {
    eventTitle: title,
    title: title,
    eventType: String(request.eventType || request.targetType || 'INTERNAL').trim() || 'INTERNAL',
    eventDescription: String(request.eventDescription || request.description || '').trim(),
    description: String(request.eventDescription || request.description || '').trim(),
    startAt: startAt && !isNaN(startAt.getTime()) ? mcCalendar19FormatCalendarDateTime_(startAt) : String(request.startAt || ''),
    endAt: endAt && !isNaN(endAt.getTime()) ? mcCalendar19FormatCalendarDateTime_(endAt) : String(request.endAt || ''),
    allDayYn: String(request.allDayYn || 'N').toUpperCase() === 'Y' ? 'Y' : 'N',
    location: String(request.location || '').trim(),
    attendees: String(request.attendees || '').trim(),
    ownerEmployeeId: String(request.ownerEmployeeId || profile.employeeId || '').trim(),
    assignedEmployeeId: String(request.assignedEmployeeId || request.ownerEmployeeId || profile.employeeId || '').trim(),
    eventId: String(request.eventId || '').trim(),
    customerId: String(request.customerId || '').trim(),
    contractId: String(request.contractId || '').trim(),
    installId: String(request.installId || '').trim(),
    asId: String(request.asId || '').trim(),
    requestId: String(request.requestId || '').trim(),
    targetType: String(request.targetType || request.eventType || 'INTERNAL').trim() || 'INTERNAL',
    targetId: String(request.targetId || request.eventId || request.customerId || request.installId || request.asId || request.requestId || request.contractId || '').trim(),
    _startDate: startAt,
    _endDate: endAt
  };
  return normalized;
}

function mcCalendar186ValidateCalendarRequest_(request) {
  if (!request.eventTitle) throw new Error('일정 제목을 입력하세요.');
  if (!request._startDate || isNaN(request._startDate.getTime())) throw new Error('시작 일시 형식이 올바르지 않습니다.');
  if (!request._endDate || isNaN(request._endDate.getTime())) throw new Error('종료 일시 형식이 올바르지 않습니다.');
  if (request.allDayYn !== 'Y' && request._endDate.getTime() <= request._startDate.getTime()) throw new Error('종료 일시는 시작 일시보다 뒤여야 합니다.');
}

function mcCalendar186BuildCalendarEventRecord_(request, profile) {
  var id = 'CAL-' + Utilities.formatDate(new Date(), Session.getScriptTimeZone() || 'Asia/Seoul', 'yyyyMMddHHmmss') + '-' + Utilities.getUuid().substring(0, 8).toUpperCase();
  var now = mcCalendar19Now_();
  return {
    calendarEventId: id,
    eventId: request.eventId,
    customerId: request.customerId,
    contractId: request.contractId,
    installId: request.installId,
    asId: request.asId,
    requestId: request.requestId,
    provider: 'INTERNAL',
    providerEventId: '',
    eventType: request.eventType,
    eventTitle: request.eventTitle,
    eventDescription: request.eventDescription,
    startAt: request.startAt,
    endAt: request.endAt,
    allDayYn: request.allDayYn,
    location: request.location,
    attendees: request.attendees,
    ownerEmployeeId: request.ownerEmployeeId,
    assignedEmployeeId: request.assignedEmployeeId,
    eventStatus: 'INTERNAL_SAVED',
    naverRegisterStatus: 'PENDING',
    naverProviderEventId: '',
    naverErrorCode: '',
    naverErrorMessage: '',
    googleBackupStatus: 'PENDING',
    googleProviderEventId: '',
    googleErrorCode: '',
    googleErrorMessage: '',
    retryCount: 0,
    lastRetryAt: '',
    createdAt: now,
    createdBy: profile.employeeId || profile.loginId,
    updatedAt: now,
    updatedBy: profile.employeeId || profile.loginId
  };
}

function mcCalendar186AppendCalendarEvent_(ss, record) {
  var headers = mcCalendar186CalendarEventHeaders_();
  var sheet = mcCalendar19GetSheetOrCreate_(ss, 'MAILCENTER_CalendarEvents', headers);
  mcCalendar19AppendByHeader_(sheet, record, headers);
}

function mcCalendar186AssertNoDuplicateCalendarEvent_(ss, request) {
  var sheet = mcCalendar19GetSheetOrCreate_(ss, 'MAILCENTER_CalendarEvents', mcCalendar186CalendarEventHeaders_());
  var data = mcCalendar19ReadRowsByHeader_(sheet);
  var key = [request.eventTitle, request.startAt, request.endAt, request.ownerEmployeeId, request.customerId, request.installId, request.asId].join('|').toLowerCase();
  for (var i = data.rows.length - 1; i >= 0 && i >= data.rows.length - 200; i--) {
    var row = data.rows[i];
    var rowKey = [row.eventTitle, row.startAt, row.endAt, row.ownerEmployeeId, row.customerId, row.installId, row.asId].join('|').toLowerCase();
    var status = String(row.eventStatus || '').toUpperCase();
    if (key === rowKey && status !== 'CANCELLED' && status !== 'DELETED') throw new Error('중복 의심 일정이 있습니다. 기존 calendarEventId: ' + row.calendarEventId);
  }
}

function mcCalendar186TryProviderCreate_(callback, provider) {
  try {
    var created = callback();
    return { ok: true, skipped: false, provider: provider, resultStatus: 'SUCCESS', providerEventId: created.eventId || '', errorCode: '', errorMessage: '', message: created.message || provider + ' 등록 성공', raw: created };
  } catch (err) {
    return { ok: false, skipped: false, provider: provider, resultStatus: 'FAIL', providerEventId: '', errorCode: mcCalendar186GuessErrorCode_(err), errorMessage: mcCalendar19ErrorMessage_(err), message: provider + ' 등록 실패' };
  }
}

function mcCalendar186BuildProviderSkippedResult_(provider, reason) {
  return {
    ok: true,
    skipped: true,
    provider: provider || '',
    resultStatus: 'SKIPPED',
    providerEventId: '',
    errorCode: '',
    errorMessage: '',
    message: reason || '외부 provider 연동은 현재 정책 또는 SystemConfig 설정에 따라 건너뜀'
  };
}

function mcCalendar186GuessErrorCode_(err) {
  var msg = mcCalendar19ErrorMessage_(err);
  var m = msg.match(/HTTP\s+(\d+)/i);
  if (m) return 'HTTP_' + m[1];
  if (msg.indexOf('권한') >= 0) return 'PERMISSION';
  if (msg.indexOf('토큰') >= 0 || msg.toLowerCase().indexOf('token') >= 0) return 'TOKEN';
  return 'PROVIDER_ERROR';
}

function mcCalendar186ApplyProviderResult_(ss, calendarEventId, provider, providerResult, profile) {
  // PORTAL_STEP08_NAVER_FINAL_409_FIX
  // Preserve existing provider links on failed update attempts so the next save stays on MODIFY path and never creates a duplicate UID.
  var eventHeaders = mcCalendar186CalendarEventHeaders_();
  var sheet = mcCalendar19GetSheetOrCreate_(ss, 'MAILCENTER_CalendarEvents', eventHeaders);
  var data = sheet.getDataRange().getValues();
  if (!data || data.length < 2) return;
  var headers = mcCalendar19HeaderMap_(data[0]);
  var targetRow = -1;
  for (var r = data.length - 1; r >= 1; r--) {
    if (String(data[r][headers.calendarEventId] || '') === String(calendarEventId)) { targetRow = r + 1; break; }
  }
  if (targetRow < 0) return;
  var row = data[targetRow - 1] || [];
  function existingValue_(key) {
    return headers.hasOwnProperty(key) ? String(row[headers[key]] || '').trim() : '';
  }
  var raw = (providerResult && providerResult.raw) || {};
  var now = mcCalendar19Now_();
  var status = providerResult.skipped ? 'SKIPPED' : (providerResult.ok ? 'SUCCESS' : 'FAIL');
  // R7C_SYNC_STATUS_ONLY_DO_NOT_OVERRIDE_USER_UPDATEDBY: provider result may update sync fields, but must preserve user actor fields.
  var updates = { updatedAt: now };
  var providerLogEventId = providerResult.providerEventId || '';
  if (provider === 'NAVER') {
    var existingNaverId = existingValue_('naverProviderEventId') || existingValue_('naverEventId') || existingValue_('providerEventId');
    var nextNaverId = providerResult.providerEventId || raw.providerEventId || raw.eventId || raw.naverIcalUid || existingNaverId || '';
    var nextNaverCalendarId = raw.naverCalendarId || raw.providerCalendarId || existingValue_('naverCalendarId') || existingValue_('providerCalendarId') || '';
    updates.naverRegisterStatus = status;
    updates.naverProviderEventId = nextNaverId;
    updates.naverEventId = nextNaverId;
    updates.naverIcalUid = nextNaverId;
    updates.naverCalendarId = nextNaverCalendarId;
    updates.naverProviderCalendarId = nextNaverCalendarId;
    updates.naverLastProcessType = raw.processType || '';
    updates.naverErrorCode = providerResult.errorCode || '';
    updates.naverErrorMessage = providerResult.errorMessage || '';
    providerLogEventId = nextNaverId;
  }
  if (provider === 'GOOGLE_BACKUP') {
    var existingGoogleId = existingValue_('googleProviderEventId') || existingValue_('googleEventId') || existingValue_('googleCalendarEventId');
    var nextGoogleId = providerResult.providerEventId || raw.providerEventId || raw.eventId || existingGoogleId || '';
    updates.googleBackupStatus = status;
    updates.googleProviderEventId = nextGoogleId;
    updates.googleEventId = nextGoogleId;
    updates.googleErrorCode = providerResult.errorCode || '';
    updates.googleErrorMessage = providerResult.errorMessage || '';
    providerLogEventId = nextGoogleId;
  }
  if (!providerResult.ok) updates.eventStatus = 'PROVIDER_PARTIAL_FAIL';
  mcCalendar186SetRowValuesByHeader_(sheet, targetRow, updates);
  mcCalendar186AppendProviderLog_(ss, { calendarEventId: calendarEventId }, provider, 'CREATE_EVENT', status, providerLogEventId, providerResult.errorCode || '', providerResult.errorMessage || '', providerResult.message || '', profile);
  if (!providerResult.ok) mcCalendar186UpsertRetryQueue_(ss, calendarEventId, provider, providerResult, profile);
}


function mcCalendar186FinalizeCalendarEventStatus_(ss, calendarEventId, overallStatus, profile) {
  var sheet = mcCalendar19GetSheetOrCreate_(ss, 'MAILCENTER_CalendarEvents', mcCalendar186CalendarEventHeaders_());
  var data = sheet.getDataRange().getValues();
  if (!data || data.length < 2) return;
  var headers = mcCalendar19HeaderMap_(data[0]);
  for (var r = data.length - 1; r >= 1; r--) {
    if (String(data[r][headers.calendarEventId] || '') === String(calendarEventId)) {
      mcCalendar186SetRowValuesByHeader_(sheet, r + 1, {
        // R7C_FINALIZE_STATUS_DO_NOT_OVERRIDE_USER_UPDATEDBY
        eventStatus: overallStatus.result === 'SUCCESS' ? 'REGISTERED' : 'PROVIDER_PARTIAL_FAIL',
        updatedAt: mcCalendar19Now_()
      });
      return;
    }
  }
}

function mcCalendar186SetRowValuesByHeader_(sheet, rowNumber, updates) {
  var values = sheet.getDataRange().getValues();
  var headers = mcCalendar19HeaderMap_(values[0]);
  var keys = Object.keys(updates || {});
  for (var i = 0; i < keys.length; i++) {
    var k = keys[i];
    if (headers.hasOwnProperty(k)) sheet.getRange(rowNumber, headers[k] + 1).setValue(updates[k]);
  }
}

function mcCalendar186AppendProviderLog_(ss, eventRecord, provider, actionType, resultStatus, providerEventId, errorCode, errorMessage, responseSummary, profile) {
  var headers = mcCalendar186CalendarLogHeaders_();
  var sheet = mcCalendar19GetSheetOrCreate_(ss, 'MAILCENTER_CalendarLogs', headers);
  mcCalendar19AppendByHeader_(sheet, {
    calendarLogId: 'CLOG-' + Utilities.getUuid(),
    calendarEventId: eventRecord.calendarEventId || '',
    provider: provider || '',
    actionType: actionType || '',
    resultStatus: resultStatus || '',
    providerEventId: providerEventId || '',
    errorCode: errorCode || '',
    errorMessage: errorMessage || '',
    requestPayloadSummary: JSON.stringify(mcCalendar28SanitizePayload_({ calendarEventId: eventRecord.calendarEventId || '', provider: provider || '' })),
    responseSummary: responseSummary || '',
    createdAt: mcCalendar19Now_(),
    createdBy: profile.employeeId || profile.loginId || ''
  }, headers);
}

function mcCalendar186UpsertRetryQueue_(ss, calendarEventId, provider, providerResult, profile) {
  var headers = mcCalendar186CalendarRetryHeaders_();
  var sheet = mcCalendar19GetSheetOrCreate_(ss, 'MAILCENTER_CalendarRetryQueue', headers);
  var next = new Date(new Date().getTime() + 10 * 60000);
  mcCalendar19AppendByHeader_(sheet, {
    retryId: 'RETRY-' + Utilities.getUuid(),
    calendarEventId: calendarEventId,
    provider: provider,
    retryStatus: 'PENDING',
    retryCount: 0,
    lastErrorCode: providerResult.errorCode || '',
    lastErrorMessage: providerResult.errorMessage || '',
    nextRetryAt: Utilities.formatDate(next, Session.getScriptTimeZone() || 'Asia/Seoul', 'yyyy-MM-dd HH:mm:ss'),
    createdAt: mcCalendar19Now_(),
    updatedAt: mcCalendar19Now_()
  }, headers);
}

function mcCalendar186BuildOverallCalendarStatus_(providerResults) {
  var fail = [];
  var skipped = [];
  var success = [];
  for (var i = 0; i < providerResults.length; i++) {
    if (!providerResults[i]) continue;
    if (!providerResults[i].ok) fail.push(providerResults[i].provider);
    else if (providerResults[i].skipped) skipped.push(providerResults[i].provider);
    else success.push(providerResults[i].provider);
  }
  if (!fail.length) {
    var msg = '내부 원장 저장 완료';
    if (success.length) msg += ', 외부 등록 완료: ' + success.join(', ');
    if (skipped.length) msg += ', 정책/설정상 건너뜀: ' + skipped.join(', ');
    return { result: 'SUCCESS', message: msg };
  }
  return { result: 'PARTIAL', message: '내부 원장 저장은 완료되었습니다. 실패 provider: ' + fail.join(', ') + ' / 재전송 대기열에 저장했습니다.' };
}

function mcCalendar186GetCalendarDashboard(request) {
  var result = mcCalendar19SafeResult_('mcCalendar186GetCalendarDashboard');
  request = request || {};
  try {
    var config = mcCalendar19GetConfigBundle_();
    var profile = mcCalendar186ResolveCalendarActor_(request, config, { allowFallback: true });
    mcCalendar186PermissionGuard_(profile, 'CALENDAR_CREATE');
    var ss = mcCalendar19OpenMaster_(config);
    mcCalendar186EnsureCalendarModuleSheets_(ss);
    var events = mcCalendar19ReadRowsByHeader_(ss.getSheetByName('MAILCENTER_CalendarEvents')).rows;
    var retryRows = mcCalendar19ReadRowsByHeader_(ss.getSheetByName('MAILCENTER_CalendarRetryQueue')).rows;
    var today = Utilities.formatDate(new Date(), Session.getScriptTimeZone() || 'Asia/Seoul', 'yyyy-MM-dd');
    var summary = { total: events.length, today: 0, naverSuccess: 0, naverFail: 0, googleSuccess: 0, googleFail: 0, retryPending: 0 };
    var recent = [];
    for (var i = events.length - 1; i >= 0; i--) {
      var row = events[i];
      if (String(row.startAt || '').indexOf(today) === 0) summary.today++;
      if (String(row.naverRegisterStatus || '') === 'SUCCESS') summary.naverSuccess++;
      if (String(row.naverRegisterStatus || '') === 'FAIL') summary.naverFail++;
      if (String(row.googleBackupStatus || '') === 'SUCCESS') summary.googleSuccess++;
      if (String(row.googleBackupStatus || '') === 'FAIL') summary.googleFail++;
      if ((String(row.ownerEmployeeId || '') === String(profile.employeeId || '') || String(row.assignedEmployeeId || '') === String(profile.employeeId || '') || mcCalendar186HasPermission_(profile, 'ALL')) && recent.length < 20) {
        recent.push(mcCalendar186CalendarEventClientRow_(row));
      }
    }
    for (var r = 0; r < retryRows.length; r++) if (String(retryRows[r].retryStatus || '') === 'PENDING') summary.retryPending++;
    result.ok = true;
    result.summary = summary;
    result.recentEvents = recent;
    result.profile = mcCalendar186SafeActorSummary_(profile);
    result.message = '캘린더 요약 조회 완료';
  } catch (err) {
    result.ok = false;
    result.message = mcCalendar19ErrorMessage_(err);
    result.summary = { total: 0, today: 0, naverSuccess: 0, naverFail: 0, googleSuccess: 0, googleFail: 0, retryPending: 0 };
    result.recentEvents = [];
  }
  return mcCalendar19ClientSafeObject_(result);
}

function mcCalendar186CalendarEventClientRow_(row) {
  return {
    calendarEventId: mcCalendar19ClientSafeValue_(row.calendarEventId),
    eventTitle: mcCalendar19ClientSafeValue_(row.eventTitle),
    startAt: mcCalendar19ClientSafeValue_(row.startAt),
    endAt: mcCalendar19ClientSafeValue_(row.endAt),
    ownerEmployeeId: mcCalendar19ClientSafeValue_(row.ownerEmployeeId),
    assignedEmployeeId: mcCalendar19ClientSafeValue_(row.assignedEmployeeId),
    eventStatus: mcCalendar19ClientSafeValue_(row.eventStatus),
    naverRegisterStatus: mcCalendar19ClientSafeValue_(row.naverRegisterStatus),
    googleBackupStatus: mcCalendar19ClientSafeValue_(row.googleBackupStatus),
    createdBy: mcCalendar19ClientSafeValue_(row.createdBy),
    updatedBy: mcCalendar19ClientSafeValue_(row.updatedBy)
  };
}

function mcCalendar186RetryPendingCalendarProviders(request) {
  var result = mcCalendar19SafeResult_('mcCalendar186RetryPendingCalendarProviders');
  request = request || {};
  try {
    var config = mcCalendar19GetConfigBundle_();
    var profile = mcCalendar186ResolveCalendarActor_(request, config, { allowFallback: true });
    mcCalendar186PermissionGuard_(profile, 'CALENDAR_CREATE');
    mcCalendar186PermissionGuard_(profile, 'CALENDAR_RETRY');
    result.ok = true;
    result.actor = mcCalendar186SafeActorSummary_(profile);
    result.message = '재전송 실행 게이트 통과. 실제 provider 재전송은 다음 빌드에서 개별 Adapter 단위로 확장합니다.';
    result.note = '현재 빌드는 실패 provider를 MAILCENTER_CalendarRetryQueue에 안전 저장하는 1차 안정화입니다.';
  } catch (err) {
    result.ok = false;
    result.message = mcCalendar19ErrorMessage_(err);
  }
  return mcCalendar19ClientSafeObject_(result);
}

/*******************************************************
 * MAILCENTER 186 Calendar Clean Debug Runners
 * 목적:
 * - Apps Script 실행 로그에 결과 JSON을 강제로 출력
 * - 함수 인식 여부, 대시보드 조회, 테스트 일정 생성, 네이버 설정 점검을 순서대로 확인
 * 실행 순서:
 * 1) mcCalendar186PingDebug
 * 2) mcCalendar186RunCalendarDashboardDebug
 * 3) mcCalendar186RunCalendarSelfTestDebug
 * 4) mcCalendar186RunNaverSettingsDebug
 *******************************************************/
function mcCalendar186DebugStringify_(value) {
  try {
    return JSON.stringify(value, null, 2);
  } catch (e) {
    return String(value);
  }
}

function mcCalendar186PingDebug() {
  var fn = 'mcCalendar186PingDebug';
  var result = {
    ok: true,
    build: 'MAILCENTER_CALENDAR_CORE_CLONE_V01_20260521',
    action: fn,
    message: 'MailCenter_Calendar.js 함수 인식 성공 - loginId/employeeId 기준 클린빌드',
    generatedAt: Utilities.formatDate(new Date(), Session.getScriptTimeZone() || 'Asia/Seoul', 'yyyy-MM-dd HH:mm:ss')
  };
  Logger.log('[' + fn + '] 실행 결과');
  Logger.log(mcCalendar186DebugStringify_(result));
  return result;
}

function mcCalendar186RunCalendarDashboardDebug() {
  var fn = 'mcCalendar186RunCalendarDashboardDebug';
  Logger.log('[' + fn + '] 실행 시작');

  try {
    var result = mcCalendar186GetCalendarDashboard();
    Logger.log('[' + fn + '] 실행 결과');
    Logger.log(mcCalendar186DebugStringify_(result));
    Logger.log('[' + fn + '] 실행 완료');
    return result;
  } catch (e) {
    Logger.log('[' + fn + '] 오류 발생');
    Logger.log('message: ' + (e && e.message ? e.message : e));
    Logger.log('stack: ' + (e && e.stack ? e.stack : 'no stack'));
    throw e;
  }
}

function mcCalendar186RunCalendarSelfTestDebug() {
  var fn = 'mcCalendar186RunCalendarSelfTestDebug';
  Logger.log('[' + fn + '] 실행 시작');

  try {
    var result = mcCalendar19CreateSelfTestCalendarEvent();
    Logger.log('[' + fn + '] 실행 결과');
    Logger.log(mcCalendar186DebugStringify_(result));
    Logger.log('[' + fn + '] 실행 완료');
    return result;
  } catch (e) {
    Logger.log('[' + fn + '] 오류 발생');
    Logger.log('message: ' + (e && e.message ? e.message : e));
    Logger.log('stack: ' + (e && e.stack ? e.stack : 'no stack'));
    throw e;
  }
}

function mcCalendar186RunNaverSettingsDebug() {
  var fn = 'mcCalendar186RunNaverSettingsDebug';
  Logger.log('[' + fn + '] 실행 시작');

  try {
    var result = mcCalendar21CheckNaverCalendarSettings({});
    Logger.log('[' + fn + '] 실행 결과');
    Logger.log(mcCalendar186DebugStringify_(result));
    Logger.log('[' + fn + '] 실행 완료');
    return result;
  } catch (e) {
    Logger.log('[' + fn + '] 오류 발생');
    Logger.log('message: ' + (e && e.message ? e.message : e));
    Logger.log('stack: ' + (e && e.stack ? e.stack : 'no stack'));
    throw e;
  }
}


/*******************************************************
 * MAILCENTER 189 Calendar Advanced Field Helpers
 * Build: MAILCENTER_CALENDAR_CORE_CLONE_V01_20260521
 * Scope: assignee picker, event detail, retry list. JS only.
 *******************************************************/
function mcCalendar189ListCalendarAssignees(request) {
  var result = mcCalendar19SafeResult_('mcCalendar189ListCalendarAssignees');
  request = request || {};
  try {
    var config = mcCalendar19GetConfigBundle_();
    var profile = mcCalendar186ResolveCalendarActor_(request, config, { allowFallback: true });
    mcCalendar186PermissionGuard_(profile, 'CALENDAR_VIEW');
    var users = mcCalendar186ReadMailCenterUsersForCalendar_(config);
    var list = [];
    for (var i = 0; i < users.length; i++) {
      if (!mcCalendar186IsActiveCalendarUser_(users[i])) continue;
      list.push({
        userId: mcCalendar19ClientSafeValue_(users[i].userId || ''),
        loginId: mcCalendar19ClientSafeValue_(users[i].loginId || ''),
        employeeId: mcCalendar19ClientSafeValue_(users[i].employeeId || ''),
        employeeName: mcCalendar19ClientSafeValue_(users[i].employeeName || ''),
        roleCode: mcCalendar19ClientSafeValue_(users[i].roleCode || ''),
        vendorId: mcCalendar19ClientSafeValue_(users[i].vendorId || '')
      });
    }
    list.sort(function(a, b) {
      var ak = String(a.employeeName || a.loginId || a.employeeId || '');
      var bk = String(b.employeeName || b.loginId || b.employeeId || '');
      return ak.localeCompare(bk, 'ko');
    });
    result.ok = true;
    result.message = '담당자 목록 조회 완료';
    result.actor = mcCalendar186SafeActorSummary_(profile);
    result.assignees = list;
  } catch (err) {
    result.ok = false;
    result.message = mcCalendar19ErrorMessage_(err);
    result.assignees = [];
  }
  return mcCalendar19ClientSafeObject_(result);
}

function mcCalendar189FindCalendarEventRow_(events, calendarEventId) {
  calendarEventId = String(calendarEventId || '').trim();
  for (var i = events.length - 1; i >= 0; i--) {
    if (String(events[i].calendarEventId || '') === calendarEventId) return events[i];
  }
  return null;
}

function mcCalendar189CanViewCalendarEvent_(profile, row) {
  if (mcCalendar186HasPermission_(profile, 'ALL')) return true;
  var emp = String(profile && profile.employeeId || '');
  return String(row.ownerEmployeeId || '') === emp || String(row.assignedEmployeeId || '') === emp || String(row.createdBy || '') === emp || String(row.updatedBy || '') === emp;
}

function mcCalendar189GetCalendarEventDetail(request) {
  var result = mcCalendar19SafeResult_('mcCalendar189GetCalendarEventDetail');
  request = request || {};
  try {
    var calendarEventId = String(request.calendarEventId || '').trim();
    if (!calendarEventId) throw new Error('calendarEventId가 필요합니다.');
    var config = mcCalendar19GetConfigBundle_();
    var profile = mcCalendar186ResolveCalendarActor_(request, config, { allowFallback: true });
    mcCalendar186PermissionGuard_(profile, 'CALENDAR_VIEW');
    var ss = mcCalendar19OpenMaster_(config);
    mcCalendar186EnsureCalendarModuleSheets_(ss);
    var events = mcCalendar19ReadRowsByHeader_(ss.getSheetByName('MAILCENTER_CalendarEvents')).rows;
    var row = mcCalendar189FindCalendarEventRow_(events, calendarEventId);
    if (!row) throw new Error('일정을 찾지 못했습니다: ' + calendarEventId);
    if (!mcCalendar189CanViewCalendarEvent_(profile, row)) throw new Error('해당 일정 조회 권한이 없습니다.');
    var logs = mcCalendar19ReadRowsByHeader_(ss.getSheetByName('MAILCENTER_CalendarLogs')).rows;
    var retries = mcCalendar19ReadRowsByHeader_(ss.getSheetByName('MAILCENTER_CalendarRetryQueue')).rows;
    var eventLogs = [];
    var retryRows = [];
    for (var i = logs.length - 1; i >= 0 && eventLogs.length < 30; i--) {
      if (String(logs[i].calendarEventId || '') === calendarEventId) eventLogs.push(mcCalendar19ClientSafeObject_(logs[i]));
    }
    for (var r = retries.length - 1; r >= 0 && retryRows.length < 20; r--) {
      if (String(retries[r].calendarEventId || '') === calendarEventId) retryRows.push(mcCalendar19ClientSafeObject_(retries[r]));
    }
    result.ok = true;
    result.message = '일정 상세 조회 완료';
    result.actor = mcCalendar186SafeActorSummary_(profile);
    result.event = mcCalendar19ClientSafeObject_(row);
    result.logs = eventLogs;
    result.retryRows = retryRows;
  } catch (err) {
    result.ok = false;
    result.message = mcCalendar19ErrorMessage_(err);
    result.event = null;
    result.logs = [];
    result.retryRows = [];
  }
  return mcCalendar19ClientSafeObject_(result);
}

function mcCalendar189ListCalendarRetryQueue(request) {
  var result = mcCalendar19SafeResult_('mcCalendar189ListCalendarRetryQueue');
  request = request || {};
  try {
    var config = mcCalendar19GetConfigBundle_();
    var profile = mcCalendar186ResolveCalendarActor_(request, config, { allowFallback: true });
    mcCalendar186PermissionGuard_(profile, 'CALENDAR_VIEW');
    var ss = mcCalendar19OpenMaster_(config);
    mcCalendar186EnsureCalendarModuleSheets_(ss);
    var events = mcCalendar19ReadRowsByHeader_(ss.getSheetByName('MAILCENTER_CalendarEvents')).rows;
    var retryRowsRaw = mcCalendar19ReadRowsByHeader_(ss.getSheetByName('MAILCENTER_CalendarRetryQueue')).rows;
    var byId = {};
    for (var i = 0; i < events.length; i++) byId[String(events[i].calendarEventId || '')] = events[i];
    var retryRows = [];
    for (var r = retryRowsRaw.length - 1; r >= 0 && retryRows.length < 50; r--) {
      var q = retryRowsRaw[r];
      var ev = byId[String(q.calendarEventId || '')] || {};
      if (!mcCalendar189CanViewCalendarEvent_(profile, ev || {})) continue;
      retryRows.push({
        retryId: mcCalendar19ClientSafeValue_(q.retryId || ''),
        calendarEventId: mcCalendar19ClientSafeValue_(q.calendarEventId || ''),
        eventTitle: mcCalendar19ClientSafeValue_(ev.eventTitle || ''),
        startAt: mcCalendar19ClientSafeValue_(ev.startAt || ''),
        provider: mcCalendar19ClientSafeValue_(q.provider || ''),
        retryStatus: mcCalendar19ClientSafeValue_(q.retryStatus || ''),
        retryCount: mcCalendar19ClientSafeValue_(q.retryCount || ''),
        lastErrorCode: mcCalendar19ClientSafeValue_(q.lastErrorCode || ''),
        lastErrorMessage: mcCalendar19ClientSafeValue_(q.lastErrorMessage || ''),
        nextRetryAt: mcCalendar19ClientSafeValue_(q.nextRetryAt || ''),
        updatedAt: mcCalendar19ClientSafeValue_(q.updatedAt || '')
      });
    }
    result.ok = true;
    result.message = '재전송 대기열 조회 완료';
    result.actor = mcCalendar186SafeActorSummary_(profile);
    result.retryRows = retryRows;
  } catch (err) {
    result.ok = false;
    result.message = mcCalendar19ErrorMessage_(err);
    result.retryRows = [];
  }
  return mcCalendar19ClientSafeObject_(result);
}

function mcCalendar189CalendarAdvancedDebug() {
  var result = {
    ok: true,
    build: 'MAILCENTER_CALENDAR_CORE_CLONE_V01_20260521',
    action: 'mcCalendar189CalendarAdvancedDebug',
    message: '캘린더 후속 기능 파일 인식 성공: 담당자 선택, 상세 보기, 재전송 목록',
    checks: {
      assigneeListReady: typeof mcCalendar189ListCalendarAssignees === 'function',
      detailReady: typeof mcCalendar189GetCalendarEventDetail === 'function',
      retryListReady: typeof mcCalendar189ListCalendarRetryQueue === 'function',
      calendarCreateReady: typeof mcCalendar19CreateCalendarEvent === 'function',
      dashboardReady: typeof mcCalendar186GetCalendarDashboard === 'function'
    },
    generatedAt: Utilities.formatDate(new Date(), Session.getScriptTimeZone() || 'Asia/Seoul', 'yyyy-MM-dd HH:mm:ss')
  };
  Logger.log(JSON.stringify(result, null, 2));
  return result;
}


/*******************************************************
 * MAILCENTER 190 Calendar Detail/Retry Action Lock
 * Build: MAILCENTER_CALENDAR_CORE_CLONE_V01_20260521
 * Scope: verify detail button, retry list and action functions.
 *******************************************************/
function mcCalendar190CalendarActionDebug() {
  var result = {
    ok: true,
    build: 'MAILCENTER_CALENDAR_CORE_CLONE_V01_20260521',
    action: 'mcCalendar190CalendarActionDebug',
    message: '캘린더 상세/재전송 액션 서버 함수 인식 성공',
    checks: {
      dashboardReady: typeof mcCalendar186GetCalendarDashboard === 'function',
      detailReady: typeof mcCalendar189GetCalendarEventDetail === 'function',
      retryListReady: typeof mcCalendar189ListCalendarRetryQueue === 'function',
      retryActionReady: typeof mcCalendar186RetryPendingCalendarProviders === 'function',
      assigneeListReady: typeof mcCalendar189ListCalendarAssignees === 'function'
    },
    generatedAt: Utilities.formatDate(new Date(), Session.getScriptTimeZone() || 'Asia/Seoul', 'yyyy-MM-dd HH:mm:ss')
  };
  Logger.log(JSON.stringify(result, null, 2));
  return result;
}

function mcCalendar190CalendarLatestDetailSelfCheck(request) {
  var result = mcCalendar19SafeResult_('mcCalendar190CalendarLatestDetailSelfCheck');
  request = request || {};
  try {
    var dashboard = mcCalendar186GetCalendarDashboard(request);
    var latest = dashboard && dashboard.recentEvents && dashboard.recentEvents.length ? dashboard.recentEvents[0] : null;
    var detail = null;
    if (latest && latest.calendarEventId) {
      detail = mcCalendar189GetCalendarEventDetail({
        sid: request.sid || '',
        loginId: request.loginId || '',
        employeeId: request.employeeId || '',
        calendarEventId: latest.calendarEventId
      });
    }
    var retry = mcCalendar189ListCalendarRetryQueue(request);
    result.ok = !!(dashboard && dashboard.ok) && (!latest || !!(detail && detail.ok)) && !!(retry && retry.ok);
    result.build = 'MAILCENTER_CALENDAR_CORE_CLONE_V01_20260521';
    result.message = result.ok ? '최근 일정 상세/재전송 목록 자체점검 통과' : '최근 일정 상세/재전송 목록 자체점검 확인 필요';
    result.dashboardOk = !!(dashboard && dashboard.ok);
    result.latestCalendarEventId = latest ? latest.calendarEventId : '';
    result.detailOk = latest ? !!(detail && detail.ok) : true;
    result.retryListOk = !!(retry && retry.ok);
    result.retryCount = retry && retry.retryRows ? retry.retryRows.length : 0;
  } catch (err) {
    result.ok = false;
    result.build = 'MAILCENTER_CALENDAR_CORE_CLONE_V01_20260521';
    result.message = mcCalendar19ErrorMessage_(err);
  }
  Logger.log(JSON.stringify(result, null, 2));
  return mcCalendar19ClientSafeObject_(result);
}


/*******************************************************
 * MAILCENTER 192 Calendar Range/List View
 * Build: MAILCENTER_CALENDAR_CORE_CLONE_V01_20260521
 * Scope: read-only range search/list for field calendar. No mail/common files touched.
 *******************************************************/
function mcCalendar192ListCalendarEvents(request) {
  var result = mcCalendar19SafeResult_('mcCalendar192ListCalendarEvents');
  request = request || {};
  try {
    var config = mcCalendar19GetConfigBundle_();
    var profile = mcCalendar186ResolveCalendarActor_(request, config, { allowFallback: true });
    mcCalendar186PermissionGuard_(profile, 'CALENDAR_VIEW');
    var ss = mcCalendar19OpenMaster_(config);
    mcCalendar186EnsureCalendarModuleSheets_(ss);
    var events = mcCalendar19ReadRowsByHeader_(ss.getSheetByName('MAILCENTER_CalendarEvents')).rows;
    var rangeStart = mcCalendar192ParseDateLoose_(request.rangeStart || request.startAt || '');
    var rangeEnd = mcCalendar192ParseDateLoose_(request.rangeEnd || request.endAt || '');
    if (rangeEnd) rangeEnd = new Date(rangeEnd.getFullYear(), rangeEnd.getMonth(), rangeEnd.getDate(), 23, 59, 59, 999);
    var keyword = String(request.keyword || '').trim().toLowerCase();
    var assignee = String(request.assignedEmployeeId || '').trim();
    var status = String(request.eventStatus || '').trim();
    var rows = [];
    var totalVisible = 0;
    for (var i = 0; i < events.length; i++) {
      var row = events[i];
      if (!mcCalendar189CanViewCalendarEvent_(profile, row)) continue;
      totalVisible++;
      var start = mcCalendar192ParseDateLoose_(row.startAt || '');
      if (rangeStart && start && start < rangeStart) continue;
      if (rangeEnd && start && start > rangeEnd) continue;
      if (assignee && String(row.assignedEmployeeId || '') !== assignee) continue;
      if (status && String(row.eventStatus || '') !== status) continue;
      if (keyword) {
        var hay = [row.calendarEventId, row.eventTitle, row.eventDescription, row.location, row.eventId, row.customerId, row.contractId, row.installId, row.asId, row.requestId, row.ownerEmployeeId, row.assignedEmployeeId].join(' ').toLowerCase();
        if (hay.indexOf(keyword) < 0) continue;
      }
      rows.push(mcCalendar186CalendarEventClientRow_(row));
    }
    rows.sort(function(a,b){
      var da = mcCalendar192ParseDateLoose_(a.startAt || '') || new Date(0);
      var db = mcCalendar192ParseDateLoose_(b.startAt || '') || new Date(0);
      return da.getTime() - db.getTime();
    });
    result.ok = true;
    result.build = 'MAILCENTER_CALENDAR_CORE_CLONE_V01_20260521';
    result.message = '캘린더 기간/검색 목록 조회 완료';
    result.totalVisible = totalVisible;
    result.filteredCount = rows.length;
    result.rows = rows.slice(0, 100);
    result.profile = mcCalendar186SafeActorSummary_(profile);
    result.filters = {
      rangeStart: request.rangeStart || '',
      rangeEnd: request.rangeEnd || '',
      keyword: request.keyword || '',
      assignedEmployeeId: assignee,
      eventStatus: status
    };
  } catch (err) {
    result.ok = false;
    result.build = 'MAILCENTER_CALENDAR_CORE_CLONE_V01_20260521';
    result.message = mcCalendar19ErrorMessage_(err);
    result.rows = [];
    result.filteredCount = 0;
  }
  return mcCalendar19ClientSafeObject_(result);
}

function mcCalendar192ParseDateLoose_(value) {
  if (value instanceof Date && !isNaN(value.getTime())) return value;
  value = String(value || '').trim();
  if (!value) return null;
  var normalized = value.replace(/\./g, '-').replace(/T/g, ' ');
  var m = normalized.match(/^(\d{4})-(\d{1,2})-(\d{1,2})(?:\s+(\d{1,2}):(\d{1,2})(?::(\d{1,2}))?)?/);
  if (m) return new Date(Number(m[1]), Number(m[2]) - 1, Number(m[3]), Number(m[4] || 0), Number(m[5] || 0), Number(m[6] || 0));
  var d = new Date(value);
  return isNaN(d.getTime()) ? null : d;
}

function mcCalendar192CalendarRangeListDebug() {
  var result = {
    ok: true,
    build: 'MAILCENTER_CALENDAR_CORE_CLONE_V01_20260521',
    action: 'mcCalendar192CalendarRangeListDebug',
    message: '캘린더 기간/검색 목록 서버 함수 인식 성공',
    checks: {
      rangeListReady: typeof mcCalendar192ListCalendarEvents === 'function',
      dashboardReady: typeof mcCalendar186GetCalendarDashboard === 'function',
      detailReady: typeof mcCalendar189GetCalendarEventDetail === 'function',
      assigneeListReady: typeof mcCalendar189ListCalendarAssignees === 'function'
    },
    generatedAt: Utilities.formatDate(new Date(), Session.getScriptTimeZone() || 'Asia/Seoul', 'yyyy-MM-dd HH:mm:ss')
  };
  try {
    var list = mcCalendar192ListCalendarEvents({});
    result.selfCheckOk = !!(list && list.ok);
    result.filteredCount = list && list.filteredCount ? list.filteredCount : 0;
  } catch (e) {
    result.selfCheckOk = false;
    result.selfCheckMessage = e && e.message ? e.message : String(e);
  }
  Logger.log(JSON.stringify(result, null, 2));
  return result;
}

/*
 * MAILCENTER 193 Calendar Edit Event Lock
 * Scope: internal calendar event edit with audit/provider log. External provider update is deferred.
 */
function mcCalendar193FindCalendarEventRowNumber_(sheet, calendarEventId) {
  var values = sheet.getDataRange().getValues();
  if (!values || values.length < 2) return { rowNumber: -1, headers: values && values[0] ? mcCalendar19HeaderMap_(values[0]) : {}, row: null };
  var headers = mcCalendar19HeaderMap_(values[0]);
  for (var r = values.length - 1; r >= 1; r--) {
    if (String(values[r][headers.calendarEventId] || '') === String(calendarEventId)) {
      var rowObj = {};
      Object.keys(headers).forEach(function(k){ rowObj[k] = values[r][headers[k]]; });
      return { rowNumber: r + 1, headers: headers, row: rowObj };
    }
  }
  return { rowNumber: -1, headers: headers, row: null };
}

function mcCalendar193NormalizeEditDate_(value, fallback) {
  var raw = String(value || '').trim();
  if (!raw) raw = String(fallback || '').trim();
  if (!raw) return '';
  var d = new Date(raw);
  if (!isNaN(d.getTime())) return mcCalendar19FormatCalendarDateTime_(d);
  return raw;
}

function mcCalendar193UpdateCalendarEvent(request) {
  var result = mcCalendar19SafeResult_('mcCalendar193UpdateCalendarEvent');
  request = request || {};
  try {
    var calendarEventId = String(request.calendarEventId || '').trim();
    if (!calendarEventId) throw new Error('calendarEventId가 필요합니다.');

    var config = mcCalendar19GetConfigBundle_();
    var profile = mcCalendar186ResolveCalendarActor_(request, config, { allowFallback: true });
    // CALENDAR_EDIT 권한이 별도 없으면 기존 운영 권한인 CALENDAR_CREATE 기준으로 수정 권한을 인정합니다.
    if (!mcCalendar186HasPermission_(profile, 'CALENDAR_EDIT')) mcCalendar186PermissionGuard_(profile, 'CALENDAR_CREATE');

    var ss = mcCalendar19OpenMaster_(config);
    mcCalendar186EnsureCalendarModuleSheets_(ss);
    var sheet = mcCalendar19GetSheetOrCreate_(ss, 'MAILCENTER_CalendarEvents', mcCalendar186CalendarEventHeaders_());
    var found = mcCalendar193FindCalendarEventRowNumber_(sheet, calendarEventId);
    if (found.rowNumber < 0 || !found.row) throw new Error('수정할 일정을 찾지 못했습니다: ' + calendarEventId);
    var existing = found.row;
    if (!mcCalendar189CanViewCalendarEvent_(profile, existing)) throw new Error('해당 일정 수정 권한이 없습니다.');

    var currentStatus = String(existing.eventStatus || '').toUpperCase();
    if (currentStatus === 'LOCKED' || currentStatus === 'COMPLETED' || currentStatus === 'CANCELED' || currentStatus === 'CANCELLED') {
      throw new Error('완료/잠금/취소된 일정은 일반 수정할 수 없습니다: ' + currentStatus);
    }

    var newStart = mcCalendar193NormalizeEditDate_(request.startAt, existing.startAt);
    var newEnd = mcCalendar193NormalizeEditDate_(request.endAt, existing.endAt);
    var ds = new Date(newStart);
    var de = new Date(newEnd);
    if (newStart && newEnd && !isNaN(ds.getTime()) && !isNaN(de.getTime()) && de.getTime() <= ds.getTime()) {
      throw new Error('종료 일시는 시작 일시보다 뒤여야 합니다.');
    }

    var updates = {
      eventTitle: String(request.eventTitle || existing.eventTitle || '').trim(),
      eventType: String(request.eventType || existing.eventType || 'INTERNAL').trim() || 'INTERNAL',
      eventDescription: String(request.eventDescription || request.description || existing.eventDescription || '').trim(),
      startAt: newStart,
      endAt: newEnd,
      location: String(request.location || existing.location || '').trim(),
      assignedEmployeeId: String(request.assignedEmployeeId || existing.assignedEmployeeId || existing.ownerEmployeeId || profile.employeeId || '').trim(),
      eventId: String(request.eventId || existing.eventId || '').trim(),
      customerId: String(request.customerId || existing.customerId || '').trim(),
      contractId: String(request.contractId || existing.contractId || '').trim(),
      installId: String(request.installId || existing.installId || '').trim(),
      asId: String(request.asId || existing.asId || '').trim(),
      requestId: String(request.requestId || existing.requestId || '').trim(),
      eventStatus: 'UPDATED',
      updatedAt: mcCalendar19Now_(),
      updatedBy: profile.employeeId || profile.loginId
    };
    if (!updates.eventTitle) throw new Error('일정 제목을 입력하세요.');
    if (!updates.startAt) throw new Error('시작 일시를 입력하세요.');
    if (!updates.endAt) throw new Error('종료 일시를 입력하세요.');

    mcCalendar186SetRowValuesByHeader_(sheet, found.rowNumber, updates);
    mcCalendar186AppendProviderLog_(ss, { calendarEventId: calendarEventId }, 'INTERNAL', 'UPDATE_EVENT', 'SUCCESS', '', '', '', 'MAILCENTER_CalendarEvents 내부 일정 수정 완료', profile);
    try {
      if (typeof mcCalendar19AppendAuditLog_ === 'function') {
        mcCalendar19AppendAuditLog_('CALENDAR_UPDATE_EVENT', profile.loginId || profile.employeeId || '', calendarEventId, 'SUCCESS', '캘린더 일정 수정 완료', {
          calendarEventId: calendarEventId,
          employeeId: profile.employeeId,
          updatedFields: Object.keys(updates).join(',')
        });
      }
    } catch (auditErr) {}

    result.ok = true;
    result.message = '일정 수정이 완료되었습니다. NAVER/GOOGLE 수정 동기화는 후속 provider update 단계에서 처리합니다.';
    result.calendarEventId = calendarEventId;
    result.eventStatus = 'UPDATED';
    result.updatedBy = updates.updatedBy;
    result.updatedAt = updates.updatedAt;
    result.providerSyncDeferred = true;
    result.event = mcCalendar19ClientSafeObject_(Object.assign({}, existing, updates));
  } catch (err) {
    result.ok = false;
    result.message = mcCalendar19ErrorMessage_(err);
  }
  return mcCalendar19ClientSafeObject_(result);
}

function mcCalendar193CalendarEditDebug() {
  var result = {
    ok: true,
    build: 'MAILCENTER_CALENDAR_CORE_CLONE_V01_20260521',
    action: 'mcCalendar193CalendarEditDebug',
    message: '캘린더 193 일정 수정 서버 기능 인식 성공',
    checks: {
      updateReady: typeof mcCalendar193UpdateCalendarEvent === 'function',
      detailReady: typeof mcCalendar189GetCalendarEventDetail === 'function',
      dashboardReady: typeof mcCalendar186GetCalendarDashboard === 'function',
      rangeListReady: typeof mcCalendar192ListCalendarEvents === 'function',
      logReady: typeof mcCalendar186AppendProviderLog_ === 'function'
    },
    generatedAt: Utilities.formatDate(new Date(), Session.getScriptTimeZone() || 'Asia/Seoul', 'yyyy-MM-dd HH:mm:ss')
  };
  Logger.log(JSON.stringify(result, null, 2));
  return result;
}

/*******************************************************
 * MAILCENTER 199 Calendar Complete Status Engine
 * Build: MAILCENTER_CALENDAR_CORE_CLONE_V01_20260521
 * Scope: clean final calendar status transition server functions.
 *******************************************************/
function mcCalendar199CalendarStatusLabelMap_() {
  return { REGISTERED:'등록', IN_PROGRESS:'진행중', UPDATED:'수정됨', COMPLETED:'완료', CANCELED:'취소', CANCELLED:'취소', LOCKED:'잠금', PROVIDER_PARTIAL_FAIL:'연동 일부 실패', PROVIDER_FAIL:'연동 실패', INTERNAL_SAVED:'내부 저장' };
}
function mcCalendar199NormalizeCalendarStatus_(value) {
  var status = String(value || '').trim().toUpperCase();
  if (status === 'CANCELLED') return 'CANCELED';
  return status;
}
function mcCalendar199CalendarAllowedTransitions_() {
  return {
    INTERNAL_SAVED:{REGISTERED:true,PROVIDER_PARTIAL_FAIL:true,PROVIDER_FAIL:true,CANCELED:true},
    PROVIDER_PARTIAL_FAIL:{REGISTERED:true,PROVIDER_FAIL:true,CANCELED:true},
    PROVIDER_FAIL:{REGISTERED:true,PROVIDER_PARTIAL_FAIL:true,CANCELED:true},
    REGISTERED:{IN_PROGRESS:true,UPDATED:true,COMPLETED:true,CANCELED:true,LOCKED:true},
    UPDATED:{IN_PROGRESS:true,COMPLETED:true,CANCELED:true,LOCKED:true},
    IN_PROGRESS:{UPDATED:true,COMPLETED:true,CANCELED:true,LOCKED:true},
    COMPLETED:{}, CANCELED:{}, LOCKED:{}
  };
}
function mcCalendar199GetCalendarStatusOptions(request) {
  var result = mcCalendar19SafeResult_('mcCalendar199GetCalendarStatusOptions');
  try {
    request = request || {};
    var fromStatus = mcCalendar199NormalizeCalendarStatus_(request.eventStatus || request.fromStatus || 'REGISTERED') || 'REGISTERED';
    var transitions = mcCalendar199CalendarAllowedTransitions_();
    var labels = mcCalendar199CalendarStatusLabelMap_();
    var allowed = transitions[fromStatus] || {};
    result.ok = true;
    result.fromStatus = fromStatus;
    result.options = Object.keys(allowed).map(function(status){ return { value: status, label: labels[status] || status }; });
    result.terminal = result.options.length === 0;
    result.message = result.terminal ? '현재 상태에서는 추가 상태변경이 제한됩니다.' : '상태변경 가능 목록 조회 완료';
  } catch (err) {
    result.ok = false;
    result.message = mcCalendar19ErrorMessage_(err);
  }
  return mcCalendar19ClientSafeObject_(result);
}
function mcCalendar199ChangeCalendarEventStatus(request) {
  var result = mcCalendar19SafeResult_('mcCalendar199ChangeCalendarEventStatus');
  request = request || {};
  try {
    var calendarEventId = String(request.calendarEventId || '').trim();
    var toStatus = mcCalendar199NormalizeCalendarStatus_(request.toStatus || request.eventStatus || '');
    var reason = String(request.reason || request.statusReason || '').trim();
    if (!calendarEventId) throw new Error('calendarEventId가 필요합니다.');
    if (!toStatus) throw new Error('변경할 상태값이 필요합니다.');
    var config = mcCalendar19GetConfigBundle_();
    var profile = mcCalendar186ResolveCalendarActor_(request, config, { allowFallback: true });
    if (!mcCalendar186HasPermission_(profile, 'CALENDAR_STATUS')) mcCalendar186PermissionGuard_(profile, 'CALENDAR_CREATE');
    var ss = mcCalendar19OpenMaster_(config);
    mcCalendar186EnsureCalendarModuleSheets_(ss);
    var sheet = mcCalendar19GetSheetOrCreate_(ss, 'MAILCENTER_CalendarEvents', mcCalendar186CalendarEventHeaders_());
    var found = mcCalendar193FindCalendarEventRowNumber_(sheet, calendarEventId);
    if (found.rowNumber < 0 || !found.row) throw new Error('상태를 변경할 일정을 찾지 못했습니다: ' + calendarEventId);
    var existing = found.row;
    if (!mcCalendar189CanViewCalendarEvent_(profile, existing)) throw new Error('해당 일정 상태변경 권한이 없습니다.');
    var fromStatus = mcCalendar199NormalizeCalendarStatus_(existing.eventStatus || 'REGISTERED') || 'REGISTERED';
    if (fromStatus === toStatus) throw new Error('이미 같은 상태입니다: ' + toStatus);
    var transitions = mcCalendar199CalendarAllowedTransitions_();
    if (!transitions[fromStatus] || !transitions[fromStatus][toStatus]) throw new Error('허용되지 않은 상태전이입니다: ' + fromStatus + ' → ' + toStatus);
    if ((toStatus === 'CANCELED' || toStatus === 'LOCKED') && !reason) throw new Error('취소/잠금 처리에는 사유가 필요합니다.');
    var now = mcCalendar19Now_();
    var actor = profile.employeeId || profile.loginId || '';
    mcCalendar186SetRowValuesByHeader_(sheet, found.rowNumber, { eventStatus: toStatus, statusReason: reason || ('캘린더 상태 변경: ' + fromStatus + ' → ' + toStatus), updatedAt: now, updatedBy: actor });
    mcCalendar186AppendProviderLog_(ss, { calendarEventId: calendarEventId }, 'INTERNAL', 'STATUS_TRANSITION', 'SUCCESS', '', '', '', '캘린더 상태 변경 완료: ' + fromStatus + ' → ' + toStatus + (reason ? ' / 사유: ' + reason : ''), profile);
    try { if (typeof mcCalendar19AppendAuditLog_ === 'function') mcCalendar19AppendAuditLog_('CALENDAR_STATUS_TRANSITION', profile.loginId || actor, calendarEventId, 'SUCCESS', '캘린더 상태 변경 완료', { calendarEventId: calendarEventId, fromStatus: fromStatus, toStatus: toStatus, reason: reason, employeeId: profile.employeeId }); } catch (auditErr) {}
    result.ok = true;
    result.message = '상태변경이 완료되었습니다.';
    result.calendarEventId = calendarEventId;
    result.fromStatus = fromStatus;
    result.toStatus = toStatus;
    result.eventStatus = toStatus;
    result.updatedAt = now;
    result.updatedBy = actor;
  } catch (err) {
    result.ok = false;
    result.message = mcCalendar19ErrorMessage_(err);
  }
  return mcCalendar19ClientSafeObject_(result);
}
function mcCalendar199CalendarCompleteSelfTest() {
  var result = { ok:true, build:'MAILCENTER_CALENDAR_CORE_CLONE_V01_20260521', action:'mcCalendar199CalendarCompleteSelfTest', message:'캘린더 완성형 클린 통합 빌드 서버 함수 인식 성공', checks:{ dashboardReady:typeof mcCalendar186GetCalendarDashboard === 'function', detailReady:typeof mcCalendar189GetCalendarEventDetail === 'function', updateReady:typeof mcCalendar193UpdateCalendarEvent === 'function', statusChangeReady:typeof mcCalendar199ChangeCalendarEventStatus === 'function', statusOptionsReady:typeof mcCalendar199GetCalendarStatusOptions === 'function', providerLogReady:typeof mcCalendar186AppendProviderLog_ === 'function', transitionRuleReady:typeof mcCalendar199CalendarAllowedTransitions_ === 'function' }, generatedAt:Utilities.formatDate(new Date(), Session.getScriptTimeZone() || 'Asia/Seoul', 'yyyy-MM-dd HH:mm:ss') };
  result.ok = !!(result.checks.dashboardReady && result.checks.detailReady && result.checks.updateReady && result.checks.statusChangeReady && result.checks.statusOptionsReady && result.checks.providerLogReady && result.checks.transitionRuleReady);
  try { var options = mcCalendar199GetCalendarStatusOptions({ eventStatus:'REGISTERED' }); result.optionCheckOk = !!(options && options.ok && options.options && options.options.length); } catch (e) { result.optionCheckOk = false; result.optionCheckMessage = e && e.message ? e.message : String(e); }
  Logger.log(JSON.stringify(result, null, 2));
  return mcCalendar19ClientSafeObject_(result);
}

/*******************************************************
 * MC_NAVER_CALENDAR_IMPORT_TO_LEDGER_V01_20260527
 * Scope: NAVER external DB/export received data -> MAILCENTER_CalendarEvents ledger.
 * Policy: NAVER inbound auto/bidirectional sync is not used. This function only reflects received rows into the internal ledger and logs the result.
 *******************************************************/
function mcNaverCalendarImportToLedgerV01Headers_() {
  return ['importLogId','batchId','sourceProvider','sourceName','externalCalendarId','externalEventId','calendarEventId','importAction','importStatus','message','rowPayloadSummary','createdAt','createdBy'];
}

function mcNaverCalendarImportToLedgerV01EnsureSheets_(ss) {
  mcCalendar186EnsureCalendarModuleSheets_(ss);
  mcCalendar19GetSheetOrCreate_(ss, 'MAILCENTER_NaverCalendarImportLogs', mcNaverCalendarImportToLedgerV01Headers_());
}

function mcNaverCalendarImportToLedgerV01(request) {
  var result = mcCalendar19SafeResult_('mcNaverCalendarImportToLedgerV01');
  request = request || {};
  var actorKey = '';
  try {
    var config = mcCalendar19GetConfigBundle_();
    var profile = mcCalendar186ResolveCalendarActor_(request, config, { allowFallback: true });
    actorKey = mcCalendar186ActorKey_(profile);
    mcCalendar186PermissionGuard_(profile, 'CALENDAR_CREATE');
    mcCalendar186FeatureGuard_(config.config || {}, 'FEATURE_CALENDAR_ENABLED', '캘린더 기능');

    var policy = mcCalendarPolicyV01ResolveProviderPolicy_(config.config || {});
    var rows = request.rows || request.events || request.items || [];
    if (!Array.isArray(rows)) throw new Error('rows 배열이 필요합니다. 네이버 export/DB 수신 데이터를 배열로 전달하세요.');
    if (!rows.length) throw new Error('반영할 네이버 일정 데이터가 없습니다.');
    var dryRun = String(request.dryRun || '').toUpperCase() === 'Y' || request.dryRun === true;
    var sourceName = String(request.sourceName || request.fileName || 'NAVER_DB_OR_EXPORT').trim();
    var batchId = String(request.batchId || '').trim() || ('NAVER-IMPORT-' + Utilities.formatDate(new Date(), Session.getScriptTimeZone() || 'Asia/Seoul', 'yyyyMMddHHmmss') + '-' + Utilities.getUuid().substring(0, 8).toUpperCase());
    var ss = mcCalendar19OpenMaster_(config);
    mcNaverCalendarImportToLedgerV01EnsureSheets_(ss);
    var sheet = mcCalendar19GetSheetOrCreate_(ss, 'MAILCENTER_CalendarEvents', mcCalendar186CalendarEventHeaders_());
    var summary = { total: rows.length, inserted: 0, updated: 0, skipped: 0, failed: 0, dryRun: dryRun };
    var details = [];

    for (var i = 0; i < rows.length; i++) {
      var raw = rows[i] || {};
      var normalized = null;
      try {
        normalized = mcNaverCalendarImportToLedgerV01NormalizeRow_(raw, profile, sourceName);
        var existing = mcNaverCalendarImportToLedgerV01FindExisting_(sheet, normalized);
        if (dryRun) {
          summary.skipped++;
          details.push({ rowIndex: i, action: existing.rowNumber > 0 ? 'DRY_UPDATE' : 'DRY_INSERT', externalEventId: normalized.externalEventId, calendarEventId: existing.row && existing.row.calendarEventId || '' });
          continue;
        }
        if (existing.rowNumber > 0) {
          var updates = mcNaverCalendarImportToLedgerV01BuildUpdate_(normalized, profile);
          mcCalendar186SetRowValuesByHeader_(sheet, existing.rowNumber, updates);
          summary.updated++;
          mcCalendar186AppendProviderLog_(ss, { calendarEventId: existing.row.calendarEventId || '' }, 'NAVER_IMPORT', 'IMPORT_UPDATE', 'SUCCESS', normalized.externalEventId, '', '', 'NAVER 수신 데이터 기존 원장 반영 완료', profile);
          mcNaverCalendarImportToLedgerV01AppendImportLog_(ss, batchId, sourceName, normalized, existing.row.calendarEventId || '', 'UPDATE', 'SUCCESS', '기존 원장 일정 갱신 완료', raw, profile);
          details.push({ rowIndex: i, action: 'UPDATE', externalEventId: normalized.externalEventId, calendarEventId: existing.row.calendarEventId || '' });
        } else {
          var record = mcNaverCalendarImportToLedgerV01BuildRecord_(normalized, profile);
          mcCalendar19AppendByHeader_(sheet, record, mcCalendar186CalendarEventHeaders_());
          summary.inserted++;
          mcCalendar186AppendProviderLog_(ss, { calendarEventId: record.calendarEventId }, 'NAVER_IMPORT', 'IMPORT_CREATE', 'SUCCESS', normalized.externalEventId, '', '', 'NAVER 수신 데이터 원장 신규 반영 완료', profile);
          mcNaverCalendarImportToLedgerV01AppendImportLog_(ss, batchId, sourceName, normalized, record.calendarEventId, 'INSERT', 'SUCCESS', '신규 원장 일정 생성 완료', raw, profile);
          details.push({ rowIndex: i, action: 'INSERT', externalEventId: normalized.externalEventId, calendarEventId: record.calendarEventId });
        }
      } catch (rowErr) {
        summary.failed++;
        var msg = mcCalendar19ErrorMessage_(rowErr);
        try { mcNaverCalendarImportToLedgerV01AppendImportLog_(ss, batchId, sourceName, normalized || { externalCalendarId: '', externalEventId: '' }, '', 'ERROR', 'FAIL', msg, raw, profile); } catch (ignore) {}
        details.push({ rowIndex: i, action: 'ERROR', message: msg });
      }
    }

    mcCalendar19AppendAuditLog_('NAVER_CALENDAR_IMPORT_TO_LEDGER', actorKey, batchId, summary.failed ? 'PARTIAL' : 'SUCCESS', 'NAVER 수신 데이터 원장 반영 완료', { batchId: batchId, sourceName: sourceName, summary: summary, policy: policy });
    result.ok = summary.failed === 0;
    result.build = 'MC_NAVER_CALENDAR_IMPORT_TO_LEDGER_V01_20260527';
    result.batchId = batchId;
    result.summary = summary;
    result.details = details.slice(0, 50);
    result.policy = policy;
    result.message = dryRun ? 'DRY RUN 완료: 실제 저장 없이 반영 대상만 점검했습니다.' : (summary.failed ? '일부 행 실패가 있습니다. ImportLogs를 확인하세요.' : '네이버 수신 데이터 원장 반영 완료');
  } catch (err) {
    result.ok = false;
    result.message = mcCalendar19ErrorMessage_(err);
    try { mcCalendar19AppendAuditLog_('NAVER_CALENDAR_IMPORT_TO_LEDGER', actorKey, '', 'FAIL', result.message, {}); } catch (ignore2) {}
  }
  return mcCalendar19ClientSafeObject_(result);
}

function mcNaverCalendarImportToLedgerV01NormalizeRow_(raw, profile, sourceName) {
  raw = raw || {};
  var title = String(raw.eventTitle || raw.title || raw.summary || raw.subject || '').trim();
  var startAtRaw = raw.startAt || raw.start || raw.startDateTime || raw.dtStart || raw.beginAt || '';
  var endAtRaw = raw.endAt || raw.end || raw.endDateTime || raw.dtEnd || raw.finishAt || '';
  var startDate = mcNaverCalendarImportToLedgerV01ParseDate_(startAtRaw);
  var endDate = mcNaverCalendarImportToLedgerV01ParseDate_(endAtRaw);
  var externalEventId = String(raw.externalEventId || raw.naverEventId || raw.eventId || raw.id || raw.uid || '').trim();
  var externalCalendarId = String(raw.externalCalendarId || raw.naverCalendarId || raw.calendarId || raw.calendarName || 'NAVER_DEFAULT').trim();
  if (!title) throw new Error('일정 제목이 없습니다.');
  if (!startDate) throw new Error('시작 일시가 없습니다 또는 형식이 올바르지 않습니다.');
  if (!endDate) {
    endDate = new Date(startDate.getTime() + 30 * 60000);
  }
  if (endDate.getTime() < startDate.getTime()) throw new Error('종료 일시가 시작 일시보다 빠릅니다.');
  if (!externalEventId) {
    externalEventId = 'NAVER-DERIVED-' + Utilities.base64EncodeWebSafe([externalCalendarId, title, startDate.getTime(), endDate.getTime()].join('|')).substring(0, 32);
  }
  var status = String(raw.eventStatus || raw.status || '').toUpperCase();
  var canceled = status === 'CANCELED' || status === 'CANCELLED' || status === 'DELETED' || status === '취소';
  return {
    externalCalendarId: externalCalendarId,
    externalEventId: externalEventId,
    eventTitle: title,
    eventDescription: String(raw.eventDescription || raw.description || raw.memo || '').trim(),
    startAt: mcCalendar19FormatCalendarDateTime_(startDate),
    endAt: mcCalendar19FormatCalendarDateTime_(endDate),
    allDayYn: String(raw.allDayYn || raw.allDay || '').toUpperCase() === 'Y' || raw.allDay === true ? 'Y' : 'N',
    location: String(raw.location || raw.place || '').trim(),
    attendees: String(raw.attendees || raw.participants || '').trim(),
    ownerEmployeeId: String(raw.ownerEmployeeId || profile.employeeId || '').trim(),
    assignedEmployeeId: String(raw.assignedEmployeeId || raw.ownerEmployeeId || profile.employeeId || '').trim(),
    eventId: String(raw.erpEventId || raw.eventRefId || '').trim(),
    customerId: String(raw.customerId || '').trim(),
    contractId: String(raw.contractId || '').trim(),
    installId: String(raw.installId || '').trim(),
    asId: String(raw.asId || '').trim(),
    requestId: String(raw.requestId || '').trim(),
    eventStatus: canceled ? 'CANCELED' : 'REGISTERED',
    sourceName: sourceName || 'NAVER_DB_OR_EXPORT',
    externalUpdatedAt: String(raw.externalUpdatedAt || raw.updatedAt || raw.modifiedAt || '').trim()
  };
}

function mcNaverCalendarImportToLedgerV01ParseDate_(value) {
  if (!value && value !== 0) return null;
  if (Object.prototype.toString.call(value) === '[object Date]' && !isNaN(value.getTime())) return value;
  var s = String(value || '').trim();
  if (!s) return null;
  var date = new Date(s);
  if (!isNaN(date.getTime())) return date;
  var m = s.match(/^(\d{4})[.\-\/]?(\d{2})[.\-\/]?(\d{2})\s*(\d{2})?:?(\d{2})?:?(\d{2})?/);
  if (m) {
    var y = Number(m[1]);
    var mo = Number(m[2]) - 1;
    var d = Number(m[3]);
    var h = Number(m[4] || 0);
    var mi = Number(m[5] || 0);
    var sec = Number(m[6] || 0);
    var parsed = new Date(y, mo, d, h, mi, sec);
    if (!isNaN(parsed.getTime())) return parsed;
  }
  return null;
}

function mcNaverCalendarImportToLedgerV01FindExisting_(sheet, normalized) {
  var data = sheet.getDataRange().getValues();
  var fallback = { rowNumber: -1, row: null };
  if (!data || data.length < 2) return fallback;
  var map = mcCalendar19HeaderMap_(data[0]);
  for (var r = data.length - 1; r >= 1; r--) {
    var row = mcNaverCalendarImportToLedgerV01RowObject_(data[r], data[0]);
    var provider = String(row.provider || '').toUpperCase();
    var pid = String(row.providerEventId || row.naverProviderEventId || '').trim();
    if ((provider === 'NAVER_IMPORT' || provider === 'NAVER') && pid && pid === normalized.externalEventId) {
      return { rowNumber: r + 1, row: row };
    }
    var keyMatch = provider === 'NAVER_IMPORT'
      && String(row.eventTitle || '') === normalized.eventTitle
      && String(row.startAt || '') === normalized.startAt
      && String(row.endAt || '') === normalized.endAt;
    if (keyMatch) return { rowNumber: r + 1, row: row };
  }
  return fallback;
}

function mcNaverCalendarImportToLedgerV01RowObject_(row, headers) {
  var obj = {};
  for (var i = 0; i < headers.length; i++) obj[String(headers[i] || '').trim()] = row[i];
  return obj;
}

function mcNaverCalendarImportToLedgerV01BuildRecord_(normalized, profile) {
  var now = mcCalendar19Now_();
  var id = 'CAL-NAVER-' + Utilities.formatDate(new Date(), Session.getScriptTimeZone() || 'Asia/Seoul', 'yyyyMMddHHmmss') + '-' + Utilities.getUuid().substring(0, 8).toUpperCase();
  return {
    calendarEventId: id,
    eventId: normalized.eventId,
    customerId: normalized.customerId,
    contractId: normalized.contractId,
    installId: normalized.installId,
    asId: normalized.asId,
    requestId: normalized.requestId,
    provider: 'NAVER_IMPORT',
    providerEventId: normalized.externalEventId,
    eventType: 'NAVER_IMPORT',
    eventTitle: normalized.eventTitle,
    eventDescription: mcNaverCalendarImportToLedgerV01Description_(normalized),
    startAt: normalized.startAt,
    endAt: normalized.endAt,
    allDayYn: normalized.allDayYn,
    location: normalized.location,
    attendees: normalized.attendees,
    ownerEmployeeId: normalized.ownerEmployeeId,
    assignedEmployeeId: normalized.assignedEmployeeId,
    eventStatus: normalized.eventStatus,
    naverRegisterStatus: 'IMPORTED',
    naverProviderEventId: normalized.externalEventId,
    naverErrorCode: '',
    naverErrorMessage: '',
    googleBackupStatus: 'SKIPPED',
    googleProviderEventId: '',
    googleErrorCode: '',
    googleErrorMessage: '',
    retryCount: 0,
    lastRetryAt: '',
    createdAt: now,
    createdBy: profile.employeeId || profile.loginId,
    updatedAt: now,
    updatedBy: profile.employeeId || profile.loginId
  };
}

function mcNaverCalendarImportToLedgerV01BuildUpdate_(normalized, profile) {
  return {
    provider: 'NAVER_IMPORT',
    providerEventId: normalized.externalEventId,
    eventType: 'NAVER_IMPORT',
    eventTitle: normalized.eventTitle,
    eventDescription: mcNaverCalendarImportToLedgerV01Description_(normalized),
    startAt: normalized.startAt,
    endAt: normalized.endAt,
    allDayYn: normalized.allDayYn,
    location: normalized.location,
    attendees: normalized.attendees,
    ownerEmployeeId: normalized.ownerEmployeeId,
    assignedEmployeeId: normalized.assignedEmployeeId,
    eventStatus: normalized.eventStatus,
    naverRegisterStatus: 'IMPORTED',
    naverProviderEventId: normalized.externalEventId,
    naverErrorCode: '',
    naverErrorMessage: '',
    googleBackupStatus: 'SKIPPED',
    updatedAt: mcCalendar19Now_(),
    updatedBy: profile.employeeId || profile.loginId
  };
}

function mcNaverCalendarImportToLedgerV01Description_(normalized) {
  var desc = String(normalized.eventDescription || '').trim();
  var meta = '[NAVER_IMPORT] source=' + normalized.sourceName + ' externalCalendarId=' + normalized.externalCalendarId + ' externalEventId=' + normalized.externalEventId + (normalized.externalUpdatedAt ? ' externalUpdatedAt=' + normalized.externalUpdatedAt : '');
  return desc ? desc + '\n' + meta : meta;
}

function mcNaverCalendarImportToLedgerV01AppendImportLog_(ss, batchId, sourceName, normalized, calendarEventId, action, status, message, raw, profile) {
  var headers = mcNaverCalendarImportToLedgerV01Headers_();
  var sheet = mcCalendar19GetSheetOrCreate_(ss, 'MAILCENTER_NaverCalendarImportLogs', headers);
  mcCalendar19AppendByHeader_(sheet, {
    importLogId: 'NIMLOG-' + Utilities.getUuid(),
    batchId: batchId || '',
    sourceProvider: 'NAVER',
    sourceName: sourceName || 'NAVER_DB_OR_EXPORT',
    externalCalendarId: normalized && normalized.externalCalendarId || '',
    externalEventId: normalized && normalized.externalEventId || '',
    calendarEventId: calendarEventId || '',
    importAction: action || '',
    importStatus: status || '',
    message: message || '',
    rowPayloadSummary: JSON.stringify(mcCalendar28SanitizePayload_(raw || {})).substring(0, 1000),
    createdAt: mcCalendar19Now_(),
    createdBy: profile.employeeId || profile.loginId || ''
  }, headers);
}

function mcNaverCalendarImportToLedgerV01SelfTest() {
  var result = {
    ok: true,
    build: 'MC_NAVER_CALENDAR_IMPORT_TO_LEDGER_V01_20260527',
    action: 'mcNaverCalendarImportToLedgerV01SelfTest',
    message: 'NAVER 수신 데이터 원장 반영 함수 인식 성공',
    checks: {
      importReady: typeof mcNaverCalendarImportToLedgerV01 === 'function',
      normalizeReady: typeof mcNaverCalendarImportToLedgerV01NormalizeRow_ === 'function',
      policyReady: typeof mcCalendarPolicyV01ResolveProviderPolicy_ === 'function',
      ledgerHeadersReady: typeof mcCalendar186CalendarEventHeaders_ === 'function',
      importLogHeadersReady: typeof mcNaverCalendarImportToLedgerV01Headers_ === 'function'
    },
    generatedAt: Utilities.formatDate(new Date(), Session.getScriptTimeZone() || 'Asia/Seoul', 'yyyy-MM-dd HH:mm:ss')
  };
  result.ok = !!(result.checks.importReady && result.checks.normalizeReady && result.checks.policyReady && result.checks.ledgerHeadersReady && result.checks.importLogHeadersReady);
  Logger.log(JSON.stringify(result, null, 2));
  return mcCalendar19ClientSafeObject_(result);
}


/* Build: MC_GOOGLE_CALENDAR_BIDIRECTIONAL_SYNC_PREP_V01_20260527
 * Google Calendar bidirectional sync preparation layer.
 * Scope: schema, status, and dry-run candidate inspection only.
 * Principle: PORTAL ledger remains master; Google is external sync channel. No NAVER inbound auto sync.
 */
function mcGoogleCalendarSyncPrepV01StateHeaders_() {
  return ['syncStateId','calendarEventId','googleCalendarId','googleEventId','portalUpdatedAt','googleUpdatedAt','syncDirection','syncStatus','conflictStatus','lastSyncAt','lastErrorCode','lastErrorMessage','createdAt','updatedAt'];
}

function mcGoogleCalendarSyncPrepV01LogHeaders_() {
  return ['syncLogId','batchId','calendarEventId','googleCalendarId','googleEventId','syncDirection','syncAction','syncStatus','conflictStatus','message','payloadSummary','createdAt','createdBy'];
}

function mcGoogleCalendarSyncPrepV01EnsureSheets_(ss) {
  mcCalendar19GetSheetOrCreate_(ss, 'MAILCENTER_GoogleCalendarSyncState', mcGoogleCalendarSyncPrepV01StateHeaders_());
  mcCalendar19GetSheetOrCreate_(ss, 'MAILCENTER_GoogleCalendarSyncLogs', mcGoogleCalendarSyncPrepV01LogHeaders_());
}

function mcGoogleCalendarSyncPrepV01GetStatus(request) {
  var result = mcCalendar19SafeResult_('mcGoogleCalendarSyncPrepV01GetStatus');
  request = request || {};
  var actorKey = '';
  try {
    var config = mcCalendar19GetConfigBundle_();
    var profile = mcCalendar186ResolveCalendarActor_(request, config, { allowFallback: true });
    actorKey = mcCalendar186ActorKey_(profile);
    mcCalendar186PermissionGuard_(profile, 'CALENDAR_VIEW');
    var ss = mcCalendar19OpenMaster_(config);
    mcCalendar186EnsureCalendarModuleSheets_(ss);
    mcGoogleCalendarSyncPrepV01EnsureSheets_(ss);
    var cfg = config.config || {};
    var googleCalendarId = String(mcCalendar19PickConfig_(cfg, ['GOOGLE_CALENDAR_ID']) || '').trim();
    var policy = mcCalendarPolicyV01ResolveProviderPolicy_(cfg);
    var access = { checked: false, ok: false, message: 'GOOGLE_CALENDAR_ID 미설정' };
    if (googleCalendarId) {
      access.checked = true;
      try {
        var cal = CalendarApp.getCalendarById(googleCalendarId);
        access.ok = !!cal;
        access.message = cal ? 'Google Calendar 접근 가능' : 'Google Calendar를 찾지 못했습니다.';
      } catch (calErr) {
        access.ok = false;
        access.message = mcCalendar19ErrorMessage_(calErr);
      }
    }
    result.ok = true;
    result.build = 'MC_GOOGLE_CALENDAR_BIDIRECTIONAL_SYNC_PREP_V01_20260527';
    result.message = 'Google Calendar 양방향 동기화 준비 상태 확인 완료';
    result.policy = policy;
    result.googleCalendarId = googleCalendarId;
    result.googleAccess = access;
    result.sheets = {
      ledger: 'MAILCENTER_CalendarEvents',
      state: 'MAILCENTER_GoogleCalendarSyncState',
      logs: 'MAILCENTER_GoogleCalendarSyncLogs'
    };
    result.actor = mcCalendar186SafeActorSummary_(profile);
    mcCalendar19AppendAuditLog_('GOOGLE_CALENDAR_SYNC_PREP_STATUS', actorKey, googleCalendarId, 'SUCCESS', result.message, { policy: policy, access: access });
  } catch (err) {
    result.ok = false;
    result.message = mcCalendar19ErrorMessage_(err);
    try { mcCalendar19AppendAuditLog_('GOOGLE_CALENDAR_SYNC_PREP_STATUS', actorKey, '', 'FAIL', result.message, {}); } catch (ignore) {}
  }
  return mcCalendar19ClientSafeObject_(result);
}

function mcGoogleCalendarSyncPrepV01DryRun(request) {
  var result = mcCalendar19SafeResult_('mcGoogleCalendarSyncPrepV01DryRun');
  request = request || {};
  var actorKey = '';
  var batchId = 'GSYNC-DRY-' + Utilities.formatDate(new Date(), Session.getScriptTimeZone() || 'Asia/Seoul', 'yyyyMMddHHmmss') + '-' + Utilities.getUuid().substring(0, 8).toUpperCase();
  try {
    var config = mcCalendar19GetConfigBundle_();
    var profile = mcCalendar186ResolveCalendarActor_(request, config, { allowFallback: true });
    actorKey = mcCalendar186ActorKey_(profile);
    mcCalendar186PermissionGuard_(profile, 'CALENDAR_VIEW');
    var ss = mcCalendar19OpenMaster_(config);
    mcCalendar186EnsureCalendarModuleSheets_(ss);
    mcGoogleCalendarSyncPrepV01EnsureSheets_(ss);
    var cfg = config.config || {};
    var googleCalendarId = String(request.googleCalendarId || mcCalendar19PickConfig_(cfg, ['GOOGLE_CALENDAR_ID']) || '').trim();
    if (!googleCalendarId) throw new Error('GOOGLE_CALENDAR_ID가 필요합니다.');
    var fromDate = mcGoogleCalendarSyncPrepV01ParseDate_(request.fromAt || request.startAt) || new Date(new Date().getTime() - 7 * 24 * 60 * 60000);
    var toDate = mcGoogleCalendarSyncPrepV01ParseDate_(request.toAt || request.endAt) || new Date(new Date().getTime() + 60 * 24 * 60 * 60000);
    if (toDate.getTime() < fromDate.getTime()) throw new Error('조회 종료일이 시작일보다 빠릅니다.');

    var ledgerCandidates = mcGoogleCalendarSyncPrepV01CollectPortalCandidates_(ss, fromDate, toDate);
    var googleCandidates = mcGoogleCalendarSyncPrepV01CollectGoogleCandidates_(googleCalendarId, fromDate, toDate);
    var matched = mcGoogleCalendarSyncPrepV01MatchCandidates_(ledgerCandidates, googleCandidates);

    mcGoogleCalendarSyncPrepV01AppendLog_(ss, batchId, '', googleCalendarId, '', 'DRY_RUN', 'INSPECT', 'SUCCESS', '', 'Google 양방향 동기화 후보 점검 완료', {
      portalCandidates: ledgerCandidates.length,
      googleCandidates: googleCandidates.length,
      matches: matched.matches.length,
      portalToGoogle: matched.portalToGoogle.length,
      googleToPortal: matched.googleToPortal.length,
      conflicts: matched.conflicts.length
    }, profile);

    result.ok = true;
    result.build = 'MC_GOOGLE_CALENDAR_BIDIRECTIONAL_SYNC_PREP_V01_20260527';
    result.batchId = batchId;
    result.message = 'DRY RUN 완료: 실제 Google/PORTAL 데이터 수정 없이 동기화 후보만 점검했습니다.';
    result.range = { fromAt: mcCalendar19FormatCalendarDateTime_(fromDate), toAt: mcCalendar19FormatCalendarDateTime_(toDate) };
    result.summary = {
      portalCandidates: ledgerCandidates.length,
      googleCandidates: googleCandidates.length,
      matches: matched.matches.length,
      portalToGoogle: matched.portalToGoogle.length,
      googleToPortal: matched.googleToPortal.length,
      conflicts: matched.conflicts.length
    };
    result.samples = {
      portalToGoogle: matched.portalToGoogle.slice(0, 10),
      googleToPortal: matched.googleToPortal.slice(0, 10),
      conflicts: matched.conflicts.slice(0, 10)
    };
    mcCalendar19AppendAuditLog_('GOOGLE_CALENDAR_SYNC_DRY_RUN', actorKey, batchId, 'SUCCESS', result.message, result.summary);
  } catch (err) {
    result.ok = false;
    result.batchId = batchId;
    result.message = mcCalendar19ErrorMessage_(err);
    try { mcCalendar19AppendAuditLog_('GOOGLE_CALENDAR_SYNC_DRY_RUN', actorKey, batchId, 'FAIL', result.message, {}); } catch (ignore) {}
  }
  return mcCalendar19ClientSafeObject_(result);
}

function mcGoogleCalendarSyncPrepV01CollectPortalCandidates_(ss, fromDate, toDate) {
  var sheet = mcCalendar19GetSheetOrCreate_(ss, 'MAILCENTER_CalendarEvents', mcCalendar186CalendarEventHeaders_());
  var data = sheet.getDataRange().getValues();
  if (!data || data.length < 2) return [];
  var headers = mcCalendar19HeaderMap_(data[0]);
  var rows = [];
  for (var r = 1; r < data.length; r++) {
    var obj = {};
    for (var c = 0; c < data[0].length; c++) obj[String(data[0][c] || '').trim()] = data[r][c];
    var startDate = mcGoogleCalendarSyncPrepV01ParseDate_(obj.startAt);
    if (!startDate || startDate.getTime() < fromDate.getTime() || startDate.getTime() > toDate.getTime()) continue;
    var status = String(obj.eventStatus || '').toUpperCase();
    if (status === 'DELETED' || status === 'CANCELLED' || status === 'CANCELED') continue;
    rows.push({
      calendarEventId: String(obj.calendarEventId || '').trim(),
      title: String(obj.eventTitle || '').trim(),
      startAt: String(obj.startAt || '').trim(),
      endAt: String(obj.endAt || '').trim(),
      googleEventId: String(obj.googleProviderEventId || '').trim(),
      updatedAt: String(obj.updatedAt || '').trim(),
      eventStatus: String(obj.eventStatus || '').trim()
    });
  }
  return rows;
}

function mcGoogleCalendarSyncPrepV01CollectGoogleCandidates_(googleCalendarId, fromDate, toDate) {
  var cal = CalendarApp.getCalendarById(googleCalendarId);
  if (!cal) throw new Error('GOOGLE_CALENDAR_ID 캘린더를 찾을 수 없습니다.');
  var events = cal.getEvents(fromDate, toDate) || [];
  var rows = [];
  for (var i = 0; i < events.length; i++) {
    var ev = events[i];
    var desc = String(ev.getDescription() || '');
    rows.push({
      googleEventId: ev.getId(),
      title: ev.getTitle(),
      startAt: mcCalendar19FormatCalendarDateTime_(ev.getStartTime()),
      endAt: mcCalendar19FormatCalendarDateTime_(ev.getEndTime()),
      portalCalendarEventId: mcGoogleCalendarSyncPrepV01ExtractPortalId_(desc),
      descriptionHasPortalMarker: desc.indexOf('[PORTAL_CALENDAR_EVENT_ID:') >= 0
    });
  }
  return rows;
}

function mcGoogleCalendarSyncPrepV01MatchCandidates_(portalRows, googleRows) {
  var byGoogleId = {};
  var byPortalMarker = {};
  for (var g = 0; g < googleRows.length; g++) {
    if (googleRows[g].googleEventId) byGoogleId[String(googleRows[g].googleEventId)] = googleRows[g];
    if (googleRows[g].portalCalendarEventId) byPortalMarker[String(googleRows[g].portalCalendarEventId)] = googleRows[g];
  }
  var matchedPortal = {};
  var matches = [];
  var portalToGoogle = [];
  var conflicts = [];
  for (var p = 0; p < portalRows.length; p++) {
    var row = portalRows[p];
    var gRow = row.googleEventId ? byGoogleId[row.googleEventId] : null;
    if (!gRow && row.calendarEventId) gRow = byPortalMarker[row.calendarEventId];
    if (gRow) {
      matchedPortal[row.calendarEventId] = true;
      matches.push({ calendarEventId: row.calendarEventId, googleEventId: gRow.googleEventId, title: row.title });
      if (String(row.title || '') !== String(gRow.title || '') || String(row.startAt || '') !== String(gRow.startAt || '') || String(row.endAt || '') !== String(gRow.endAt || '')) {
        conflicts.push({ calendarEventId: row.calendarEventId, googleEventId: gRow.googleEventId, reason: 'TITLE_OR_TIME_DIFF', portalTitle: row.title, googleTitle: gRow.title });
      }
    } else {
      portalToGoogle.push({ calendarEventId: row.calendarEventId, title: row.title, startAt: row.startAt, endAt: row.endAt });
    }
  }
  var googleToPortal = [];
  for (var gi = 0; gi < googleRows.length; gi++) {
    var gOnly = googleRows[gi];
    if (gOnly.portalCalendarEventId && matchedPortal[gOnly.portalCalendarEventId]) continue;
    var already = false;
    for (var mi = 0; mi < matches.length; mi++) if (matches[mi].googleEventId === gOnly.googleEventId) { already = true; break; }
    if (!already) googleToPortal.push({ googleEventId: gOnly.googleEventId, title: gOnly.title, startAt: gOnly.startAt, endAt: gOnly.endAt });
  }
  return { matches: matches, portalToGoogle: portalToGoogle, googleToPortal: googleToPortal, conflicts: conflicts };
}

function mcGoogleCalendarSyncPrepV01ExtractPortalId_(description) {
  var m = String(description || '').match(/\[PORTAL_CALENDAR_EVENT_ID:([^\]]+)\]/);
  return m ? String(m[1] || '').trim() : '';
}

function mcGoogleCalendarSyncPrepV01ParseDate_(value) {
  if (!value && value !== 0) return null;
  if (Object.prototype.toString.call(value) === '[object Date]' && !isNaN(value.getTime())) return value;
  var s = String(value || '').trim();
  if (!s) return null;
  var d = new Date(s);
  if (!isNaN(d.getTime())) return d;
  var m = s.match(/^(\d{4})[.\-\/]?(\d{2})[.\-\/]?(\d{2})\s*(\d{2})?:?(\d{2})?:?(\d{2})?/);
  if (m) {
    var parsed = new Date(Number(m[1]), Number(m[2]) - 1, Number(m[3]), Number(m[4] || 0), Number(m[5] || 0), Number(m[6] || 0));
    if (!isNaN(parsed.getTime())) return parsed;
  }
  return null;
}

function mcGoogleCalendarSyncPrepV01AppendLog_(ss, batchId, calendarEventId, googleCalendarId, googleEventId, direction, action, status, conflictStatus, message, payload, profile) {
  var headers = mcGoogleCalendarSyncPrepV01LogHeaders_();
  var sheet = mcCalendar19GetSheetOrCreate_(ss, 'MAILCENTER_GoogleCalendarSyncLogs', headers);
  mcCalendar19AppendByHeader_(sheet, {
    syncLogId: 'GSLOG-' + Utilities.getUuid(),
    batchId: batchId || '',
    calendarEventId: calendarEventId || '',
    googleCalendarId: googleCalendarId || '',
    googleEventId: googleEventId || '',
    syncDirection: direction || '',
    syncAction: action || '',
    syncStatus: status || '',
    conflictStatus: conflictStatus || '',
    message: message || '',
    payloadSummary: JSON.stringify(mcCalendar28SanitizePayload_(payload || {})).substring(0, 1000),
    createdAt: mcCalendar19Now_(),
    createdBy: profile && (profile.employeeId || profile.loginId) || ''
  }, headers);
}

function mcGoogleCalendarSyncPrepV01SelfTest() {
  var result = {
    ok: true,
    build: 'MC_GOOGLE_CALENDAR_BIDIRECTIONAL_SYNC_PREP_V01_20260527',
    action: 'mcGoogleCalendarSyncPrepV01SelfTest',
    message: 'Google Calendar 양방향 동기화 준비 함수 인식 성공',
    checks: {
      statusReady: typeof mcGoogleCalendarSyncPrepV01GetStatus === 'function',
      dryRunReady: typeof mcGoogleCalendarSyncPrepV01DryRun === 'function',
      stateHeadersReady: typeof mcGoogleCalendarSyncPrepV01StateHeaders_ === 'function',
      logHeadersReady: typeof mcGoogleCalendarSyncPrepV01LogHeaders_ === 'function',
      policyReady: typeof mcCalendarPolicyV01ResolveProviderPolicy_ === 'function'
    },
    generatedAt: Utilities.formatDate(new Date(), Session.getScriptTimeZone() || 'Asia/Seoul', 'yyyy-MM-dd HH:mm:ss')
  };
  result.ok = !!(result.checks.statusReady && result.checks.dryRunReady && result.checks.stateHeadersReady && result.checks.logHeadersReady && result.checks.policyReady);
  Logger.log(JSON.stringify(result, null, 2));
  return mcCalendar19ClientSafeObject_(result);
}

/* Build: MC_GOOGLE_CALENDAR_BIDIRECTIONAL_SYNC_APPLY_V01_20260527
 * Google Calendar bidirectional sync apply layer.
 * Safe scope: create missing events only, link state, log all actions. Existing matched conflicts are logged and not overwritten.
 * PORTAL ledger remains master. NAVER inbound auto sync remains excluded.
 */
function mcGoogleCalendarBidirectionalSyncV01Apply(request) {
  var result = mcCalendar19SafeResult_('mcGoogleCalendarBidirectionalSyncV01Apply');
  request = request || {};
  var actorKey = '';
  var batchId = 'GSYNC-APPLY-' + Utilities.formatDate(new Date(), Session.getScriptTimeZone() || 'Asia/Seoul', 'yyyyMMddHHmmss') + '-' + Utilities.getUuid().substring(0, 8).toUpperCase();
  var summary = { portalToGoogleCreated: 0, googleToPortalCreated: 0, matchedLinked: 0, conflictsSkipped: 0, skipped: 0, failed: 0 };
  var details = [];
  try {
    var config = mcCalendar19GetConfigBundle_();
    var profile = mcCalendar186ResolveCalendarActor_(request, config, { allowFallback: true });
    actorKey = mcCalendar186ActorKey_(profile);
    if (!mcCalendar186HasPermission_(profile, 'CALENDAR_EDIT')) mcCalendar186PermissionGuard_(profile, 'CALENDAR_CREATE');
    var ss = mcCalendar19OpenMaster_(config);
    mcCalendar186EnsureCalendarModuleSheets_(ss);
    mcGoogleCalendarSyncPrepV01EnsureSheets_(ss);
    var cfg = config.config || {};
    var googleCalendarId = String(request.googleCalendarId || mcCalendar19PickConfig_(cfg, ['GOOGLE_CALENDAR_ID']) || '').trim();
    if (!googleCalendarId) throw new Error('GOOGLE_CALENDAR_ID가 필요합니다.');
    var cal = CalendarApp.getCalendarById(googleCalendarId);
    if (!cal) throw new Error('GOOGLE_CALENDAR_ID 캘린더를 찾을 수 없습니다.');

    var direction = String(request.direction || 'BOTH').toUpperCase();
    var dryRun = String(request.dryRun || '').toUpperCase() === 'Y' || request.dryRun === true;

    // MC_GOOGLE_CALENDAR_SYNC_APPROVAL_APPLY_V01_20260527
    // Real Google writes are blocked unless the approval gate wrapper injects the internal token.
    // DryRun remains available for V06 compact gate and preview checks.
    if (!dryRun) {
      var googleBidirectionalConfigOn = mcCalendarPolicyV01ConfigOn_(cfg, 'FEATURE_GOOGLE_CALENDAR_BIDIRECTIONAL_SYNC_ENABLED', false);
      if (!googleBidirectionalConfigOn) {
        throw new Error('Google Calendar 실반영 차단: SystemConfig FEATURE_GOOGLE_CALENDAR_BIDIRECTIONAL_SYNC_ENABLED 값이 ON/Y/TRUE가 아닙니다.');
      }
      if (String(request._approvalGate || '') !== 'MC_GOOGLE_CALENDAR_SYNC_APPROVAL_APPLY_V01') {
        throw new Error('Google Calendar 실반영 차단: 승인 게이트 함수를 통해서만 dryRun:N 실행 가능합니다. mcGoogleCalendarSyncApprovalApplyV01을 사용하세요.');
      }
    }
    var maxOps = Number(request.maxOps || 20);
    if (!maxOps || maxOps < 1) maxOps = 20;
    if (maxOps > 100) maxOps = 100;
    var fromDate = mcGoogleCalendarSyncPrepV01ParseDate_(request.fromAt || request.startAt) || new Date(new Date().getTime() - 7 * 24 * 60 * 60000);
    var toDate = mcGoogleCalendarSyncPrepV01ParseDate_(request.toAt || request.endAt) || new Date(new Date().getTime() + 60 * 24 * 60 * 60000);
    if (toDate.getTime() < fromDate.getTime()) throw new Error('조회 종료일이 시작일보다 빠릅니다.');

    var portalRows = mcGoogleCalendarSyncApplyV01CollectPortalCandidates_(ss, fromDate, toDate);
    var googleRows = mcGoogleCalendarSyncApplyV01CollectGoogleCandidates_(googleCalendarId, fromDate, toDate);
    var matched = mcGoogleCalendarSyncPrepV01MatchCandidates_(portalRows, googleRows);

    for (var m = 0; m < matched.matches.length && summary.matchedLinked < maxOps; m++) {
      var mt = matched.matches[m];
      if (!dryRun) {
        mcGoogleCalendarSyncApplyV01UpdateLedgerGoogleLink_(ss, mt.calendarEventId, mt.googleEventId, googleCalendarId, profile);
        mcGoogleCalendarSyncApplyV01UpsertState_(ss, mt.calendarEventId, googleCalendarId, mt.googleEventId, 'MATCH', 'SYNCED', '', '', profile);
      }
      summary.matchedLinked++;
    }

    for (var c = 0; c < matched.conflicts.length; c++) {
      var cf = matched.conflicts[c];
      summary.conflictsSkipped++;
      mcGoogleCalendarSyncPrepV01AppendLog_(ss, batchId, cf.calendarEventId, googleCalendarId, cf.googleEventId, 'CONFLICT', 'SKIP', dryRun ? 'DRY_CONFLICT' : 'CONFLICT', 'TITLE_OR_TIME_DIFF', '기존 Google/PORTAL 일정 차이 감지. V01에서는 자동 덮어쓰기 제외', cf, profile);
      if (!dryRun) mcGoogleCalendarSyncApplyV01UpsertState_(ss, cf.calendarEventId, googleCalendarId, cf.googleEventId, 'CONFLICT', 'CONFLICT', 'TITLE_OR_TIME_DIFF', '', profile);
      details.push({ action: 'CONFLICT_SKIP', calendarEventId: cf.calendarEventId, googleEventId: cf.googleEventId, reason: cf.reason });
    }

    var ops = 0;
    if (direction === 'BOTH' || direction === 'PORTAL_TO_GOOGLE') {
      for (var p = 0; p < matched.portalToGoogle.length && ops < maxOps; p++) {
        var pr = mcGoogleCalendarSyncApplyV01FindPortalRow_(portalRows, matched.portalToGoogle[p].calendarEventId);
        if (!pr) { summary.skipped++; continue; }
        try {
          if (!dryRun) {
            var created = mcGoogleCalendarSyncApplyV01CreateGoogleFromPortal_(cal, pr, googleCalendarId);
            mcGoogleCalendarSyncApplyV01UpdateLedgerGoogleLink_(ss, pr.calendarEventId, created.googleEventId, googleCalendarId, profile);
            mcGoogleCalendarSyncApplyV01UpsertState_(ss, pr.calendarEventId, googleCalendarId, created.googleEventId, 'PORTAL_TO_GOOGLE', 'SYNCED', '', '', profile);
            mcGoogleCalendarSyncPrepV01AppendLog_(ss, batchId, pr.calendarEventId, googleCalendarId, created.googleEventId, 'PORTAL_TO_GOOGLE', 'CREATE_GOOGLE', 'SUCCESS', '', 'PORTAL 원장 일정을 Google Calendar에 생성 완료', pr, profile);
            details.push({ action: 'CREATE_GOOGLE', calendarEventId: pr.calendarEventId, googleEventId: created.googleEventId });
          } else {
            mcGoogleCalendarSyncPrepV01AppendLog_(ss, batchId, pr.calendarEventId, googleCalendarId, '', 'PORTAL_TO_GOOGLE', 'DRY_CREATE_GOOGLE', 'DRY_RUN', '', 'DRY RUN: Google 생성 후보', pr, profile);
            details.push({ action: 'DRY_CREATE_GOOGLE', calendarEventId: pr.calendarEventId });
          }
          summary.portalToGoogleCreated++;
          ops++;
        } catch (pErr) {
          summary.failed++;
          var pMsg = mcCalendar19ErrorMessage_(pErr);
          mcGoogleCalendarSyncPrepV01AppendLog_(ss, batchId, pr.calendarEventId, googleCalendarId, '', 'PORTAL_TO_GOOGLE', 'CREATE_GOOGLE', 'FAIL', '', pMsg, pr, profile);
          details.push({ action: 'CREATE_GOOGLE_FAIL', calendarEventId: pr.calendarEventId, message: pMsg });
        }
      }
    }

    ops = 0;
    if (direction === 'BOTH' || direction === 'GOOGLE_TO_PORTAL') {
      for (var g = 0; g < matched.googleToPortal.length && ops < maxOps; g++) {
        var gr = mcGoogleCalendarSyncApplyV01FindGoogleRow_(googleRows, matched.googleToPortal[g].googleEventId);
        if (!gr) { summary.skipped++; continue; }
        try {
          if (!dryRun) {
            var record = mcGoogleCalendarSyncApplyV01CreatePortalFromGoogle_(ss, gr, googleCalendarId, profile);
            mcGoogleCalendarSyncApplyV01UpsertState_(ss, record.calendarEventId, googleCalendarId, gr.googleEventId, 'GOOGLE_TO_PORTAL', 'SYNCED', '', '', profile);
            mcGoogleCalendarSyncPrepV01AppendLog_(ss, batchId, record.calendarEventId, googleCalendarId, gr.googleEventId, 'GOOGLE_TO_PORTAL', 'CREATE_PORTAL', 'SUCCESS', '', 'Google Calendar 일정을 PORTAL 원장에 생성 완료', gr, profile);
            details.push({ action: 'CREATE_PORTAL', calendarEventId: record.calendarEventId, googleEventId: gr.googleEventId });
          } else {
            mcGoogleCalendarSyncPrepV01AppendLog_(ss, batchId, '', googleCalendarId, gr.googleEventId, 'GOOGLE_TO_PORTAL', 'DRY_CREATE_PORTAL', 'DRY_RUN', '', 'DRY RUN: PORTAL 원장 생성 후보', gr, profile);
            details.push({ action: 'DRY_CREATE_PORTAL', googleEventId: gr.googleEventId });
          }
          summary.googleToPortalCreated++;
          ops++;
        } catch (gErr) {
          summary.failed++;
          var gMsg = mcCalendar19ErrorMessage_(gErr);
          mcGoogleCalendarSyncPrepV01AppendLog_(ss, batchId, '', googleCalendarId, gr.googleEventId, 'GOOGLE_TO_PORTAL', 'CREATE_PORTAL', 'FAIL', '', gMsg, gr, profile);
          details.push({ action: 'CREATE_PORTAL_FAIL', googleEventId: gr.googleEventId, message: gMsg });
        }
      }
    }

    result.ok = summary.failed === 0;
    result.build = 'MC_GOOGLE_CALENDAR_BIDIRECTIONAL_SYNC_APPLY_V01_20260527';
    result.batchId = batchId;
    result.dryRun = dryRun ? 'Y' : 'N';
    result.direction = direction;
    result.range = { fromAt: mcCalendar19FormatCalendarDateTime_(fromDate), toAt: mcCalendar19FormatCalendarDateTime_(toDate) };
    result.summary = summary;
    result.details = details.slice(0, 80);
    result.message = dryRun ? 'Google 양방향 APPLY DRY RUN 완료: 실제 수정 없이 실행 계획만 기록했습니다.' : (summary.failed ? 'Google 양방향 APPLY 일부 실패. SyncLogs를 확인하세요.' : 'Google 양방향 APPLY 완료');
    mcCalendar19AppendAuditLog_('GOOGLE_CALENDAR_SYNC_APPLY', actorKey, batchId, result.ok ? 'SUCCESS' : 'PARTIAL', result.message, { summary: summary, dryRun: dryRun, direction: direction });
  } catch (err) {
    result.ok = false;
    result.batchId = batchId;
    result.message = mcCalendar19ErrorMessage_(err);
    try { mcCalendar19AppendAuditLog_('GOOGLE_CALENDAR_SYNC_APPLY', actorKey, batchId, 'FAIL', result.message, {}); } catch (ignore) {}
  }
  return mcCalendar19ClientSafeObject_(result);
}

function mcGoogleCalendarSyncApplyV01CollectPortalCandidates_(ss, fromDate, toDate) {
  var sheet = mcCalendar19GetSheetOrCreate_(ss, 'MAILCENTER_CalendarEvents', mcCalendar186CalendarEventHeaders_());
  var data = sheet.getDataRange().getValues();
  if (!data || data.length < 2) return [];
  var rows = [];
  for (var r = 1; r < data.length; r++) {
    var obj = {};
    for (var c = 0; c < data[0].length; c++) obj[String(data[0][c] || '').trim()] = data[r][c];
    var startDate = mcGoogleCalendarSyncPrepV01ParseDate_(obj.startAt);
    var endDate = mcGoogleCalendarSyncPrepV01ParseDate_(obj.endAt) || new Date(startDate ? startDate.getTime() + 30 * 60000 : 0);
    if (!startDate || startDate.getTime() < fromDate.getTime() || startDate.getTime() > toDate.getTime()) continue;
    var status = String(obj.eventStatus || '').toUpperCase();
    if (status === 'DELETED' || status === 'CANCELLED' || status === 'CANCELED') continue;
    rows.push({
      calendarEventId: String(obj.calendarEventId || '').trim(),
      title: String(obj.eventTitle || '').trim(),
      startAt: mcCalendar19FormatCalendarDateTime_(startDate),
      endAt: mcCalendar19FormatCalendarDateTime_(endDate),
      startDate: startDate,
      endDate: endDate,
      description: String(obj.eventDescription || '').trim(),
      location: String(obj.location || '').trim(),
      attendees: String(obj.attendees || '').trim(),
      googleEventId: String(obj.googleProviderEventId || '').trim(),
      updatedAt: String(obj.updatedAt || '').trim(),
      eventStatus: String(obj.eventStatus || '').trim()
    });
  }
  return rows;
}

function mcGoogleCalendarSyncApplyV01CollectGoogleCandidates_(googleCalendarId, fromDate, toDate) {
  var cal = CalendarApp.getCalendarById(googleCalendarId);
  if (!cal) throw new Error('GOOGLE_CALENDAR_ID 캘린더를 찾을 수 없습니다.');
  var events = cal.getEvents(fromDate, toDate) || [];
  var rows = [];
  for (var i = 0; i < events.length; i++) {
    var ev = events[i];
    var desc = String(ev.getDescription() || '');
    rows.push({
      googleEventId: ev.getId(),
      title: ev.getTitle(),
      startAt: mcCalendar19FormatCalendarDateTime_(ev.getStartTime()),
      endAt: mcCalendar19FormatCalendarDateTime_(ev.getEndTime()),
      startDate: ev.getStartTime(),
      endDate: ev.getEndTime(),
      description: desc,
      location: String(ev.getLocation ? ev.getLocation() : ''),
      portalCalendarEventId: mcGoogleCalendarSyncPrepV01ExtractPortalId_(desc),
      descriptionHasPortalMarker: desc.indexOf('[PORTAL_CALENDAR_EVENT_ID:') >= 0
    });
  }
  return rows;
}

function mcGoogleCalendarSyncApplyV01FindPortalRow_(rows, calendarEventId) {
  for (var i = 0; i < rows.length; i++) if (String(rows[i].calendarEventId || '') === String(calendarEventId || '')) return rows[i];
  return null;
}

function mcGoogleCalendarSyncApplyV01FindGoogleRow_(rows, googleEventId) {
  for (var i = 0; i < rows.length; i++) if (String(rows[i].googleEventId || '') === String(googleEventId || '')) return rows[i];
  return null;
}

function mcGoogleCalendarSyncApplyV01CreateGoogleFromPortal_(cal, row, googleCalendarId) {
  var desc = String(row.description || '');
  desc += (desc ? '\n\n' : '') + '[PORTAL_CALENDAR_EVENT_ID:' + row.calendarEventId + ']';
  desc += '\n[FEELHAUS_PORTAL_SYNC:GOOGLE_BIDIRECTIONAL_V01]';
  var options = { description: desc };
  if (row.location) options.location = row.location;
  var ev = cal.createEvent(row.title || '(제목 없음)', row.startDate, row.endDate, options);
  return { googleCalendarId: googleCalendarId, googleEventId: ev.getId() };
}

function mcGoogleCalendarSyncApplyV01CreatePortalFromGoogle_(ss, row, googleCalendarId, profile) {
  var headers = mcCalendar186CalendarEventHeaders_();
  var sheet = mcCalendar19GetSheetOrCreate_(ss, 'MAILCENTER_CalendarEvents', headers);
  var now = mcCalendar19Now_();
  var calendarEventId = row.portalCalendarEventId || ('GCAL-' + Utilities.getUuid());
  var record = {
    calendarEventId: calendarEventId,
    eventId: '',
    customerId: '',
    contractId: '',
    installId: '',
    asId: '',
    requestId: '',
    provider: 'GOOGLE_SYNC',
    providerEventId: row.googleEventId || '',
    eventType: 'GOOGLE_CALENDAR',
    eventTitle: row.title || '(Google 일정)',
    eventDescription: row.description || '',
    startAt: row.startAt || '',
    endAt: row.endAt || '',
    allDayYn: 'N',
    location: row.location || '',
    attendees: '',
    ownerEmployeeId: profile.employeeId || profile.loginId || '',
    assignedEmployeeId: profile.employeeId || profile.loginId || '',
    eventStatus: 'REGISTERED',
    naverRegisterStatus: 'SKIPPED',
    naverProviderEventId: '',
    naverErrorCode: '',
    naverErrorMessage: 'NAVER inbound auto sync excluded by policy',
    googleBackupStatus: 'SYNCED',
    googleProviderEventId: row.googleEventId || '',
    googleErrorCode: '',
    googleErrorMessage: '',
    retryCount: 0,
    lastRetryAt: '',
    createdAt: now,
    createdBy: profile.employeeId || profile.loginId || '',
    updatedAt: now,
    updatedBy: profile.employeeId || profile.loginId || ''
  };
  mcCalendar19AppendByHeader_(sheet, record, headers);
  return record;
}

function mcGoogleCalendarSyncApplyV01UpdateLedgerGoogleLink_(ss, calendarEventId, googleEventId, googleCalendarId, profile) {
  var sheet = mcCalendar19GetSheetOrCreate_(ss, 'MAILCENTER_CalendarEvents', mcCalendar186CalendarEventHeaders_());
  var data = sheet.getDataRange().getValues();
  if (!data || data.length < 2) return false;
  var headers = mcCalendar19HeaderMap_(data[0]);
  for (var r = data.length - 1; r >= 1; r--) {
    if (String(data[r][headers.calendarEventId] || '') === String(calendarEventId || '')) {
      mcCalendar186SetRowValuesByHeader_(sheet, r + 1, {
        // R7C_GOOGLE_LINK_DO_NOT_OVERRIDE_USER_UPDATEDBY
        googleBackupStatus: 'SYNCED',
        googleProviderEventId: googleEventId || '',
        googleErrorCode: '',
        googleErrorMessage: googleCalendarId ? ('GOOGLE_SYNC:' + googleCalendarId) : '',
        updatedAt: mcCalendar19Now_()
      });
      return true;
    }
  }
  return false;
}

function mcGoogleCalendarSyncApplyV01UpsertState_(ss, calendarEventId, googleCalendarId, googleEventId, direction, status, conflictStatus, errorMessage, profile) {
  var headers = mcGoogleCalendarSyncPrepV01StateHeaders_();
  var sheet = mcCalendar19GetSheetOrCreate_(ss, 'MAILCENTER_GoogleCalendarSyncState', headers);
  var data = sheet.getDataRange().getValues();
  var now = mcCalendar19Now_();
  if (data && data.length > 1) {
    var hm = mcCalendar19HeaderMap_(data[0]);
    for (var r = data.length - 1; r >= 1; r--) {
      var ce = hm.calendarEventId >= 0 ? String(data[r][hm.calendarEventId] || '') : '';
      var ge = hm.googleEventId >= 0 ? String(data[r][hm.googleEventId] || '') : '';
      if ((calendarEventId && ce === String(calendarEventId)) || (googleEventId && ge === String(googleEventId))) {
        mcCalendar186SetRowValuesByHeader_(sheet, r + 1, {
          calendarEventId: calendarEventId || ce,
          googleCalendarId: googleCalendarId || '',
          googleEventId: googleEventId || ge,
          syncDirection: direction || '',
          syncStatus: status || '',
          conflictStatus: conflictStatus || '',
          lastSyncAt: now,
          lastErrorCode: errorMessage ? 'SYNC_ERROR' : '',
          lastErrorMessage: errorMessage || '',
          updatedAt: now
        });
        return;
      }
    }
  }
  mcCalendar19AppendByHeader_(sheet, {
    syncStateId: 'GSSTATE-' + Utilities.getUuid(),
    calendarEventId: calendarEventId || '',
    googleCalendarId: googleCalendarId || '',
    googleEventId: googleEventId || '',
    portalUpdatedAt: '',
    googleUpdatedAt: '',
    syncDirection: direction || '',
    syncStatus: status || '',
    conflictStatus: conflictStatus || '',
    lastSyncAt: now,
    lastErrorCode: errorMessage ? 'SYNC_ERROR' : '',
    lastErrorMessage: errorMessage || '',
    createdAt: now,
    updatedAt: now
  }, headers);
}

function mcGoogleCalendarBidirectionalSyncV01SelfTest() {
  var result = {
    ok: true,
    build: 'MC_GOOGLE_CALENDAR_BIDIRECTIONAL_SYNC_APPLY_V01_20260527',
    action: 'mcGoogleCalendarBidirectionalSyncV01SelfTest',
    message: 'Google Calendar 양방향 APPLY 함수 인식 성공',
    checks: {
      applyReady: typeof mcGoogleCalendarBidirectionalSyncV01Apply === 'function',
      prepDryRunReady: typeof mcGoogleCalendarSyncPrepV01DryRun === 'function',
      stateReady: typeof mcGoogleCalendarSyncPrepV01StateHeaders_ === 'function',
      logReady: typeof mcGoogleCalendarSyncPrepV01LogHeaders_ === 'function',
      createGoogleReady: typeof mcGoogleCalendarSyncApplyV01CreateGoogleFromPortal_ === 'function',
      createPortalReady: typeof mcGoogleCalendarSyncApplyV01CreatePortalFromGoogle_ === 'function'
    },
    generatedAt: Utilities.formatDate(new Date(), Session.getScriptTimeZone() || 'Asia/Seoul', 'yyyy-MM-dd HH:mm:ss')
  };
  result.ok = !!(result.checks.applyReady && result.checks.prepDryRunReady && result.checks.stateReady && result.checks.logReady && result.checks.createGoogleReady && result.checks.createPortalReady);
  Logger.log(JSON.stringify(result, null, 2));
  return mcCalendar19ClientSafeObject_(result);
}


/**
 * MC_GOOGLE_CALENDAR_SYNC_TEST_GATE_V01_20260527
 * Apps Script 실행 로그가 접히거나 상세 로그가 보이지 않는 환경을 위해
 * 인자 없이 실행 가능한 테스트 게이트 함수들을 제공합니다.
 * 실데이터 반영은 하지 않으며, Apply도 dryRun:Y로만 실행합니다.
 */
function mcGoogleCalendarSyncTestGateV01All() {
  var startedAt = new Date();
  var result = {
    ok: true,
    build: 'MC_GOOGLE_CALENDAR_SYNC_TEST_GATE_V01_20260527',
    action: 'mcGoogleCalendarSyncTestGateV01All',
    message: 'Google Calendar sync test gate completed.',
    steps: [],
    summary: {},
    startedAt: Utilities.formatDate(startedAt, Session.getScriptTimeZone() || 'Asia/Seoul', 'yyyy-MM-dd HH:mm:ss')
  };
  function runStep_(name, fn) {
    var step = { name: name, ok: false, message: '', summary: null };
    try {
      var res = fn();
      step.ok = !!(res && res.ok);
      step.message = res && res.message ? String(res.message) : '';
      step.summary = res && res.summary ? res.summary : null;
      step.batchId = res && res.batchId ? res.batchId : '';
      step.build = res && res.build ? res.build : '';
      if (!step.ok) result.ok = false;
    } catch (err) {
      step.ok = false;
      step.message = mcCalendar19ErrorMessage_(err);
      result.ok = false;
    }
    result.steps.push(step);
  }
  runStep_('SELF_TEST', function() { return mcGoogleCalendarBidirectionalSyncV01SelfTest(); });
  runStep_('STATUS', function() { return mcGoogleCalendarSyncPrepV01GetStatus({}); });
  runStep_('PREP_DRY_RUN', function() { return mcGoogleCalendarSyncPrepV01DryRun({}); });
  runStep_('APPLY_DRY_RUN', function() { return mcGoogleCalendarBidirectionalSyncV01Apply({ dryRun: 'Y', direction: 'BOTH', maxOps: 20 }); });
  result.summary.totalSteps = result.steps.length;
  result.summary.okSteps = result.steps.filter(function(s) { return s.ok; }).length;
  result.summary.failedSteps = result.steps.length - result.summary.okSteps;
  result.summary.nextAction = result.ok ? '실반영 전 결과 수량과 충돌 후보를 확인하세요. 자동 실반영은 이 함수에서 실행하지 않습니다.' : '실패 step 메시지를 확인하고 실반영을 중지하세요.';
  result.finishedAt = Utilities.formatDate(new Date(), Session.getScriptTimeZone() || 'Asia/Seoul', 'yyyy-MM-dd HH:mm:ss');
  mcGoogleCalendarSyncTestGateV01LogResult_(result);
  return mcCalendar19ClientSafeObject_(result);
}

function mcGoogleCalendarSyncTestGateV01SelfTestOnly() {
  var result = mcGoogleCalendarBidirectionalSyncV01SelfTest();
  mcGoogleCalendarSyncTestGateV01LogResult_({
    ok: !!(result && result.ok),
    build: 'MC_GOOGLE_CALENDAR_SYNC_TEST_GATE_V01_20260527',
    action: 'mcGoogleCalendarSyncTestGateV01SelfTestOnly',
    result: result,
    generatedAt: Utilities.formatDate(new Date(), Session.getScriptTimeZone() || 'Asia/Seoul', 'yyyy-MM-dd HH:mm:ss')
  });
  return result;
}

function mcGoogleCalendarSyncTestGateV01DryRunOnly() {
  var result = mcGoogleCalendarSyncPrepV01DryRun({});
  mcGoogleCalendarSyncTestGateV01LogResult_({
    ok: !!(result && result.ok),
    build: 'MC_GOOGLE_CALENDAR_SYNC_TEST_GATE_V01_20260527',
    action: 'mcGoogleCalendarSyncTestGateV01DryRunOnly',
    result: result,
    generatedAt: Utilities.formatDate(new Date(), Session.getScriptTimeZone() || 'Asia/Seoul', 'yyyy-MM-dd HH:mm:ss')
  });
  return result;
}

function mcGoogleCalendarSyncTestGateV01ApplyDryRunOnly() {
  var result = mcGoogleCalendarBidirectionalSyncV01Apply({ dryRun: 'Y', direction: 'BOTH', maxOps: 20 });
  mcGoogleCalendarSyncTestGateV01LogResult_({
    ok: !!(result && result.ok),
    build: 'MC_GOOGLE_CALENDAR_SYNC_TEST_GATE_V01_20260527',
    action: 'mcGoogleCalendarSyncTestGateV01ApplyDryRunOnly',
    result: result,
    generatedAt: Utilities.formatDate(new Date(), Session.getScriptTimeZone() || 'Asia/Seoul', 'yyyy-MM-dd HH:mm:ss')
  });
  return result;
}

function mcGoogleCalendarSyncTestGateV01LogResult_(result) {
  try {
    var compact = JSON.stringify(result);
    Logger.log('JSON_COMPACT_RESULT: ' + compact);
    if (typeof console !== 'undefined' && console.log) console.log('JSON_COMPACT_RESULT: ' + compact);
  } catch (ignore) {}
}


/**
 * MC_GOOGLE_CALENDAR_SYNC_TEST_GATE_V02_20260527
 * 목적: Apps Script 실행 로그가 접히거나 기존 함수가 ok:false/message:''로 반환될 때
 * 실패 원인을 한 줄 JSON으로 강제 노출합니다. 실제 반영은 하지 않습니다.
 */
function mcGoogleCalendarSyncTestGateV02All() {
  var result = {
    ok: true,
    build: 'MC_GOOGLE_CALENDAR_SYNC_TEST_GATE_V02_20260527',
    action: 'mcGoogleCalendarSyncTestGateV02All',
    message: 'Google Calendar sync test gate V02 completed. No real apply executed.',
    steps: [],
    summary: {},
    startedAt: mcGoogleCalendarSyncTestGateV02Now_()
  };

  mcGoogleCalendarSyncTestGateV02RunStep_(result, 'SELF_TEST', function() {
    return mcGoogleCalendarBidirectionalSyncV01SelfTest();
  });
  mcGoogleCalendarSyncTestGateV02RunStep_(result, 'ENV_CHECK', function() {
    return mcGoogleCalendarSyncTestGateV02EnvCheck_();
  });
  mcGoogleCalendarSyncTestGateV02RunStep_(result, 'STATUS', function() {
    return mcGoogleCalendarSyncPrepV01GetStatus({});
  });
  mcGoogleCalendarSyncTestGateV02RunStep_(result, 'PREP_DRY_RUN', function() {
    return mcGoogleCalendarSyncPrepV01DryRun({});
  });
  mcGoogleCalendarSyncTestGateV02RunStep_(result, 'APPLY_DRY_RUN', function() {
    return mcGoogleCalendarBidirectionalSyncV01Apply({ dryRun: 'Y', direction: 'BOTH', maxOps: 20 });
  });

  var okSteps = 0;
  for (var i = 0; i < result.steps.length; i++) if (result.steps[i].ok) okSteps++;
  result.summary.totalSteps = result.steps.length;
  result.summary.okSteps = okSteps;
  result.summary.failedSteps = result.steps.length - okSteps;
  result.summary.failedStepNames = [];
  for (var j = 0; j < result.steps.length; j++) if (!result.steps[j].ok) result.summary.failedStepNames.push(result.steps[j].name);
  result.ok = result.summary.failedSteps === 0;
  result.summary.nextAction = result.ok
    ? 'V02 게이트 통과. 그래도 실반영 전 후보 수량을 확인하세요.'
    : 'failedStepNames와 각 step의 diagnostic/errorMessage/rawCompact를 확인하세요. 실반영 금지.';
  result.finishedAt = mcGoogleCalendarSyncTestGateV02Now_();
  mcGoogleCalendarSyncTestGateV02LogResult_(result);
  return result;
}

function mcGoogleCalendarSyncTestGateV02EnvCheck_() {
  var out = {
    ok: true,
    build: 'MC_GOOGLE_CALENDAR_SYNC_TEST_GATE_V02_20260527',
    action: 'mcGoogleCalendarSyncTestGateV02EnvCheck_',
    message: '환경 점검 완료',
    checks: {}
  };

  var config = null;
  try {
    config = mcCalendar19GetConfigBundle_();
    out.checks.configBundle = { ok: true };
  } catch (errConfig) {
    out.ok = false;
    out.checks.configBundle = { ok: false, message: mcGoogleCalendarSyncTestGateV02Error_(errConfig) };
    out.message = 'SystemConfig 또는 config bundle 확인 실패';
    return out;
  }

  var cfg = config && config.config ? config.config : {};
  var googleCalendarId = '';
  try {
    googleCalendarId = String(mcCalendar19PickConfig_(cfg, ['GOOGLE_CALENDAR_ID']) || '').trim();
  } catch (errPick) {
    out.checks.googleCalendarId = { ok: false, message: mcGoogleCalendarSyncTestGateV02Error_(errPick) };
  }
  if (!googleCalendarId) {
    out.ok = false;
    out.checks.googleCalendarId = { ok: false, value: '', message: 'GOOGLE_CALENDAR_ID 미설정. DryRun/Apply는 실패합니다.' };
  } else {
    out.checks.googleCalendarId = { ok: true, value: googleCalendarId };
  }

  var ss = null;
  try {
    ss = mcCalendar19OpenMaster_(config);
    out.checks.masterDb = { ok: true, name: ss && ss.getName ? ss.getName() : '' };
  } catch (errMaster) {
    out.ok = false;
    out.checks.masterDb = { ok: false, message: mcGoogleCalendarSyncTestGateV02Error_(errMaster) };
  }

  if (ss) {
    try {
      mcCalendar186EnsureCalendarModuleSheets_(ss);
      mcGoogleCalendarSyncPrepV01EnsureSheets_(ss);
      out.checks.sheets = { ok: true, ledger: 'MAILCENTER_CalendarEvents', state: 'MAILCENTER_GoogleCalendarSyncState', logs: 'MAILCENTER_GoogleCalendarSyncLogs' };
    } catch (errSheets) {
      out.ok = false;
      out.checks.sheets = { ok: false, message: mcGoogleCalendarSyncTestGateV02Error_(errSheets) };
    }
  }

  try {
    var profile = mcCalendar186ResolveCalendarActor_({}, config, { allowFallback: true });
    out.checks.actor = { ok: true, actorKey: mcCalendar186ActorKey_(profile), roleCode: String(profile && profile.roleCode || '') };
    try {
      mcCalendar186PermissionGuard_(profile, 'CALENDAR_VIEW');
      out.checks.permissionView = { ok: true };
    } catch (errPermView) {
      out.ok = false;
      out.checks.permissionView = { ok: false, message: mcGoogleCalendarSyncTestGateV02Error_(errPermView) };
    }
    try {
      if (!mcCalendar186HasPermission_(profile, 'CALENDAR_EDIT')) mcCalendar186PermissionGuard_(profile, 'CALENDAR_CREATE');
      out.checks.permissionApply = { ok: true };
    } catch (errPermApply) {
      out.ok = false;
      out.checks.permissionApply = { ok: false, message: mcGoogleCalendarSyncTestGateV02Error_(errPermApply) };
    }
  } catch (errActor) {
    out.ok = false;
    out.checks.actor = { ok: false, message: mcGoogleCalendarSyncTestGateV02Error_(errActor) };
  }

  if (googleCalendarId) {
    try {
      var cal = CalendarApp.getCalendarById(googleCalendarId);
      out.checks.googleAccess = { ok: !!cal, message: cal ? 'Google Calendar 접근 가능' : 'Google Calendar를 찾지 못했습니다.' };
      if (!cal) out.ok = false;
    } catch (errCal) {
      out.ok = false;
      out.checks.googleAccess = { ok: false, message: mcGoogleCalendarSyncTestGateV02Error_(errCal) };
    }
  }

  out.message = out.ok ? '환경 점검 통과' : '환경 점검 실패. checks 항목을 확인하세요.';
  return out;
}

function mcGoogleCalendarSyncTestGateV02RunStep_(result, name, fn) {
  var step = { name: name, ok: false, message: '', errorMessage: '', summary: null, diagnostic: {}, rawCompact: '' };
  try {
    var res = fn();
    step.ok = !!(res && res.ok);
    step.message = mcGoogleCalendarSyncTestGateV02PickMessage_(res);
    step.summary = res && res.summary ? res.summary : null;
    step.batchId = res && res.batchId ? String(res.batchId) : '';
    step.build = res && res.build ? String(res.build) : '';
    step.diagnostic = mcGoogleCalendarSyncTestGateV02Diagnostic_(res);
    step.rawCompact = mcGoogleCalendarSyncTestGateV02Compact_(res, 3000);
    if (!step.ok && !step.message) step.message = 'ok:false but message is empty. rawCompact/diagnostic 확인 필요';
  } catch (err) {
    step.ok = false;
    step.errorMessage = mcGoogleCalendarSyncTestGateV02Error_(err);
    step.message = step.errorMessage || 'exception without message';
    step.diagnostic = { exceptionName: err && err.name ? String(err.name) : '', stack: err && err.stack ? String(err.stack).substring(0, 1500) : '' };
  }
  result.steps.push(step);
}

function mcGoogleCalendarSyncTestGateV02PickMessage_(res) {
  if (!res) return 'no result returned';
  var fields = ['message', 'errorMessage', 'lastErrorMessage', 'statusMessage'];
  for (var i = 0; i < fields.length; i++) {
    if (res[fields[i]]) return String(res[fields[i]]);
  }
  if (res.googleAccess && res.googleAccess.message) return String(res.googleAccess.message);
  return '';
}

function mcGoogleCalendarSyncTestGateV02Diagnostic_(res) {
  if (!res) return { resultType: 'empty' };
  var d = { resultType: typeof res, keys: [] };
  try { for (var k in res) if (Object.prototype.hasOwnProperty.call(res, k)) d.keys.push(k); } catch (ignore) {}
  if (res.googleCalendarId !== undefined) d.googleCalendarId = String(res.googleCalendarId || '');
  if (res.googleAccess !== undefined) d.googleAccess = res.googleAccess;
  if (res.policy !== undefined) d.policy = res.policy;
  if (res.checks !== undefined) d.checks = res.checks;
  if (res.range !== undefined) d.range = res.range;
  if (res.samples !== undefined) d.samples = res.samples;
  return d;
}

function mcGoogleCalendarSyncTestGateV02Error_(err) {
  if (!err) return '';
  var msg = '';
  try { if (err.message) msg = String(err.message); } catch (ignore1) {}
  if (!msg) {
    try { msg = String(err); } catch (ignore2) { msg = 'unknown error'; }
  }
  if (err && err.name && msg.indexOf(String(err.name)) < 0) msg = String(err.name) + ': ' + msg;
  return msg;
}

function mcGoogleCalendarSyncTestGateV02Compact_(obj, maxLen) {
  maxLen = maxLen || 3000;
  var text = '';
  try {
    text = JSON.stringify(obj, function(key, value) {
      if (value instanceof Date) return mcGoogleCalendarSyncTestGateV02Now_(value);
      if (typeof value === 'function') return '[Function]';
      return value;
    });
  } catch (err) {
    text = '[JSON_STRINGIFY_FAIL] ' + mcGoogleCalendarSyncTestGateV02Error_(err);
  }
  if (text && text.length > maxLen) text = text.substring(0, maxLen) + '...TRUNCATED';
  return text;
}

function mcGoogleCalendarSyncTestGateV02LogResult_(result) {
  var compact = mcGoogleCalendarSyncTestGateV02Compact_(result, 15000);
  try { Logger.log('JSON_COMPACT_RESULT: ' + compact); } catch (ignore) {}
}

function mcGoogleCalendarSyncTestGateV02Now_(dateObj) {
  var d = dateObj || new Date();
  try { return Utilities.formatDate(d, Session.getScriptTimeZone() || 'Asia/Seoul', 'yyyy-MM-dd HH:mm:ss'); }
  catch (err) { return String(d); }
}


/**
 * MC_GOOGLE_CALENDAR_SYNC_TEST_GATE_V03_20260527
 * V02 보정: closure 실행 결과가 함수명 문자열로 잡히는 환경을 피하기 위해 step을 직접 호출하고,
 * helper 누락을 compatibility block으로 보강합니다. 실제 반영은 하지 않습니다.
 */
function mcGoogleCalendarSyncTestGateV03All() {
  var result = {
    ok: true,
    build: 'MC_GOOGLE_CALENDAR_SYNC_TEST_GATE_V03_20260527',
    action: 'mcGoogleCalendarSyncTestGateV03All',
    message: 'Google Calendar sync test gate V03 completed. No real apply executed.',
    steps: [],
    summary: {},
    startedAt: mcGoogleCalendarSyncTestGateV03Now_()
  };

  mcGoogleCalendarSyncTestGateV03PushStep_(result, 'SELF_TEST', mcGoogleCalendarSyncTestGateV03Call_('mcGoogleCalendarBidirectionalSyncV01SelfTest', null));
  mcGoogleCalendarSyncTestGateV03PushStep_(result, 'ENV_CHECK', mcGoogleCalendarSyncTestGateV03EnvCheck_());
  mcGoogleCalendarSyncTestGateV03PushStep_(result, 'STATUS', mcGoogleCalendarSyncTestGateV03Call_('mcGoogleCalendarSyncPrepV01GetStatus', [{}]));
  mcGoogleCalendarSyncTestGateV03PushStep_(result, 'PREP_DRY_RUN', mcGoogleCalendarSyncTestGateV03Call_('mcGoogleCalendarSyncPrepV01DryRun', [{}]));
  mcGoogleCalendarSyncTestGateV03PushStep_(result, 'APPLY_DRY_RUN', mcGoogleCalendarSyncTestGateV03Call_('mcGoogleCalendarBidirectionalSyncV01Apply', [{ dryRun: 'Y', direction: 'BOTH', maxOps: 20 }]));

  var okSteps = 0;
  for (var i = 0; i < result.steps.length; i++) if (result.steps[i].ok) okSteps++;
  result.summary.totalSteps = result.steps.length;
  result.summary.okSteps = okSteps;
  result.summary.failedSteps = result.steps.length - okSteps;
  result.summary.failedStepNames = [];
  for (var j = 0; j < result.steps.length; j++) if (!result.steps[j].ok) result.summary.failedStepNames.push(result.steps[j].name);
  result.ok = result.summary.failedSteps === 0;
  result.summary.nextAction = result.ok
    ? 'V03 게이트 통과. 실반영 전 STATUS/PREP/APPLY_DRY_RUN 후보 수량을 확인하세요.'
    : '실반영 금지. failedStepNames와 각 step의 errorMessage/rawCompact를 확인하세요.';
  result.finishedAt = mcGoogleCalendarSyncTestGateV03Now_();
  mcGoogleCalendarSyncTestGateV03LogResult_(result);
  return result;
}

function mcGoogleCalendarSyncTestGateV03Call_(fnName, args) {
  try {
    var fn = this[fnName];
    if (typeof fn !== 'function') throw new Error(fnName + ' 함수를 찾지 못했습니다.');
    var res = fn.apply(null, args || []);
    return res;
  } catch (err) {
    return {
      ok: false,
      build: 'MC_GOOGLE_CALENDAR_SYNC_TEST_GATE_V03_20260527',
      action: fnName,
      message: mcGoogleCalendarSyncTestGateV03Error_(err),
      errorMessage: mcGoogleCalendarSyncTestGateV03Error_(err)
    };
  }
}

function mcGoogleCalendarSyncTestGateV03EnvCheck_() {
  var out = {
    ok: true,
    build: 'MC_GOOGLE_CALENDAR_SYNC_TEST_GATE_V03_20260527',
    action: 'mcGoogleCalendarSyncTestGateV03EnvCheck_',
    message: '환경 점검 완료',
    checks: {}
  };
  var config = null;
  var ss = null;
  try {
    config = mcCalendar19GetConfigBundle_();
    out.checks.configBundle = { ok: true, setupDbId: config.setupDbId || MAILCENTER19_SETUP_DB_ID, configKeys: Object.keys(config.config || {}).length };
  } catch (errConfig) {
    out.ok = false;
    out.message = 'SystemConfig 확인 실패';
    out.checks.configBundle = { ok: false, message: mcGoogleCalendarSyncTestGateV03Error_(errConfig) };
    return out;
  }
  var cfg = config.config || {};
  var googleCalendarId = '';
  try {
    googleCalendarId = String(mcCalendar19PickConfig_(cfg, ['GOOGLE_CALENDAR_ID']) || '').trim();
    out.checks.googleCalendarId = { ok: !!googleCalendarId, valuePresent: !!googleCalendarId, message: googleCalendarId ? 'GOOGLE_CALENDAR_ID 확인' : 'GOOGLE_CALENDAR_ID 미설정' };
  } catch (errPick) {
    out.ok = false;
    out.checks.googleCalendarId = { ok: false, message: mcGoogleCalendarSyncTestGateV03Error_(errPick) };
  }
  try {
    ss = mcCalendar19OpenMaster_(config);
    out.checks.masterDb = { ok: true, name: ss.getName(), id: ss.getId() };
  } catch (errMaster) {
    out.ok = false;
    out.checks.masterDb = { ok: false, message: mcGoogleCalendarSyncTestGateV03Error_(errMaster) };
    return out;
  }
  try {
    mcCalendar186EnsureCalendarModuleSheets_(ss);
    mcGoogleCalendarSyncPrepV01EnsureSheets_(ss);
    out.checks.sheets = { ok: true, ledger: 'MAILCENTER_CalendarEvents', state: 'MAILCENTER_GoogleCalendarSyncState', logs: 'MAILCENTER_GoogleCalendarSyncLogs' };
  } catch (errSheets) {
    out.ok = false;
    out.checks.sheets = { ok: false, message: mcGoogleCalendarSyncTestGateV03Error_(errSheets) };
  }
  try {
    var profile = mcCalendar186ResolveCalendarActor_({}, config, { allowFallback: true });
    out.checks.actor = { ok: true, actor: mcCalendar186SafeActorSummary_(profile) };
    try { mcCalendar186PermissionGuard_(profile, 'CALENDAR_VIEW'); out.checks.permissionView = { ok: true }; }
    catch (errPermView) { out.ok = false; out.checks.permissionView = { ok: false, message: mcGoogleCalendarSyncTestGateV03Error_(errPermView) }; }
  } catch (errActor) {
    out.ok = false;
    out.checks.actor = { ok: false, message: mcGoogleCalendarSyncTestGateV03Error_(errActor) };
  }
  if (googleCalendarId) {
    try {
      var cal = CalendarApp.getCalendarById(googleCalendarId);
      out.checks.googleAccess = { ok: !!cal, message: cal ? 'Google Calendar 접근 가능' : 'Google Calendar를 찾지 못했습니다.' };
      if (!cal) out.ok = false;
    } catch (errCal) {
      out.ok = false;
      out.checks.googleAccess = { ok: false, message: mcGoogleCalendarSyncTestGateV03Error_(errCal) };
    }
  } else {
    out.ok = false;
    out.checks.googleAccess = { ok: false, message: 'GOOGLE_CALENDAR_ID가 없어 접근 점검 생략' };
  }
  return out;
}

function mcGoogleCalendarSyncTestGateV03PushStep_(result, name, res) {
  var step = { name: name, ok: false, message: '', errorMessage: '', summary: null, diagnostic: {}, rawCompact: '', batchId: '', build: '' };
  try {
    step.ok = !!(res && res.ok === true);
    step.message = mcGoogleCalendarSyncTestGateV03PickMessage_(res);
    step.errorMessage = res && res.errorMessage ? String(res.errorMessage) : '';
    step.summary = res && res.summary ? res.summary : null;
    step.batchId = res && res.batchId ? String(res.batchId) : '';
    step.build = res && res.build ? String(res.build) : '';
    step.diagnostic = mcGoogleCalendarSyncTestGateV03Diagnostic_(res);
    step.rawCompact = mcGoogleCalendarSyncTestGateV03Compact_(res, 4000);
    if (!step.ok && !step.message) step.message = step.errorMessage || 'ok:false but message is empty. rawCompact/diagnostic 확인 필요';
  } catch (err) {
    step.ok = false;
    step.message = mcGoogleCalendarSyncTestGateV03Error_(err);
    step.errorMessage = mcGoogleCalendarSyncTestGateV03Error_(err);
  }
  result.steps.push(step);
}

function mcGoogleCalendarSyncTestGateV03PickMessage_(res) {
  if (!res) return '결과 없음';
  if (typeof res === 'string') return '문자열 반환: ' + res;
  if (res.message) return String(res.message);
  if (res.errorMessage) return String(res.errorMessage);
  return '';
}

function mcGoogleCalendarSyncTestGateV03Diagnostic_(res) {
  var d = { resultType: typeof res };
  if (res && typeof res === 'object') {
    d.keys = Object.keys(res);
    if (res.checks) d.checks = res.checks;
    if (res.googleAccess) d.googleAccess = res.googleAccess;
    if (res.policy) d.policy = res.policy;
    if (res.counts) d.counts = res.counts;
    if (res.summary) d.summary = res.summary;
  }
  return d;
}

function mcGoogleCalendarSyncTestGateV03Error_(err) {
  if (!err) return '';
  if (typeof err === 'string') return err;
  if (err.message) return String(err.message);
  try { return JSON.stringify(err); } catch (jsonErr) { return String(err); }
}

function mcGoogleCalendarSyncTestGateV03Compact_(obj, maxLen) {
  var text = '';
  try { text = JSON.stringify(obj); } catch (err) { text = String(obj); }
  if (maxLen && text.length > maxLen) return text.substring(0, maxLen) + '...TRUNCATED';
  return text;
}

function mcGoogleCalendarSyncTestGateV03LogResult_(result) {
  Logger.log('JSON_COMPACT_RESULT: ' + mcGoogleCalendarSyncTestGateV03Compact_(result, 12000));
}

function mcGoogleCalendarSyncTestGateV03Now_() {
  return Utilities.formatDate(new Date(), Session.getScriptTimeZone() || 'Asia/Seoul', 'yyyy-MM-dd HH:mm:ss');
}
function mcGoogleCalendarSyncAutoSetupAndTestV01() {
  const setupResult = mcGoogleCalendarSyncAutoSetupV01();

  let testResult = null;
  let testError = '';

  try {
    if (typeof mcGoogleCalendarSyncTestGateV03All === 'function') {
      testResult = mcGoogleCalendarSyncTestGateV03All();
    } else {
      testError = 'mcGoogleCalendarSyncTestGateV03All 함수를 찾지 못했습니다.';
    }
  } catch (err) {
    testError = String(err && err.message ? err.message : err);
  }

  const result = {
    ok: !!setupResult.ok && !!testResult && !!testResult.ok,
    build: 'MC_GOOGLE_CALENDAR_SYNC_AUTO_SETUP_AND_TEST_V01_20260527',
    action: 'mcGoogleCalendarSyncAutoSetupAndTestV01',
    setupResult: setupResult,
    testResult: testResult,
    testError: testError,
    generatedAt: Utilities.formatDate(
      new Date(),
      Session.getScriptTimeZone(),
      'yyyy-MM-dd HH:mm:ss'
    )
  };

  Logger.log('JSON_COMPACT_RESULT: ' + JSON.stringify(result));
  return result;
}


function mcGoogleCalendarSyncAutoSetupV01() {
  const BUILD = 'MC_GOOGLE_CALENDAR_SYNC_AUTO_SETUP_V01_20260527';

  const setupDbId = '17VMSpgSZCvIrUlgcw8yCNcnl8WQWo2IcRf5tDCcuJGM';
  const masterDbId = '1TFZ7Ihgnmxu-ziQAoB6nOf1AByxFahk9UtrmiyZ0q_0';

  const result = {
    ok: true,
    build: BUILD,
    action: 'mcGoogleCalendarSyncAutoSetupV01',
    steps: [],
    generatedAt: Utilities.formatDate(
      new Date(),
      Session.getScriptTimeZone(),
      'yyyy-MM-dd HH:mm:ss'
    )
  };

  function addStep(name, ok, message, extra) {
    result.steps.push({
      name: name,
      ok: ok,
      message: message,
      extra: extra || {}
    });

    if (!ok) {
      result.ok = false;
    }
  }

  try {
    const setupSs = SpreadsheetApp.openById(setupDbId);

    const configSheet =
      setupSs.getSheetByName('Config') ||
      setupSs.getSheetByName('CONFIG') ||
      setupSs.getSheetByName('Setup') ||
      setupSs.getSheetByName('SETUP') ||
      setupSs.getSheets()[0];

    const values = configSheet.getDataRange().getValues();

    let foundRow = -1;

    for (let r = 0; r < values.length; r++) {
      const key = String(values[r][0]).trim();

      if (key === 'GOOGLE_CALENDAR_ID') {
        foundRow = r + 1;
        break;
      }
    }

    if (foundRow > 0) {
      const currentValue = String(configSheet.getRange(foundRow, 2).getValue()).trim();

      if (currentValue) {
        addStep('GOOGLE_CALENDAR_ID', true, '이미 설정되어 있어 변경하지 않았습니다.', {
          sheet: configSheet.getName(),
          row: foundRow,
          value: currentValue
        });
      } else {
        configSheet.getRange(foundRow, 2).setValue('primary');

        addStep('GOOGLE_CALENDAR_ID', true, '값이 비어 있어 primary로 설정했습니다.', {
          sheet: configSheet.getName(),
          row: foundRow,
          value: 'primary'
        });
      }
    } else {
      const nextRow = Math.max(configSheet.getLastRow() + 1, 1);

      configSheet.getRange(nextRow, 1).setValue('GOOGLE_CALENDAR_ID');
      configSheet.getRange(nextRow, 2).setValue('primary');

      addStep('GOOGLE_CALENDAR_ID', true, 'GOOGLE_CALENDAR_ID를 새로 만들고 primary로 설정했습니다.', {
        sheet: configSheet.getName(),
        row: nextRow,
        value: 'primary'
      });
    }
  } catch (err) {
    addStep('GOOGLE_CALENDAR_ID', false, 'GOOGLE_CALENDAR_ID 자동 설정 실패', {
      error: String(err && err.message ? err.message : err)
    });
  }

  try {
    const masterSs = SpreadsheetApp.openById(masterDbId);

    let usersSheet = masterSs.getSheetByName('MailCenterUsers');

    if (!usersSheet) {
      usersSheet = masterSs.insertSheet('MailCenterUsers');

      const headers = [
        'email',
        'name',
        'role',
        'active',
        'createdAt',
        'updatedAt'
      ];

      usersSheet.getRange(1, 1, 1, headers.length).setValues([headers]);

      usersSheet.getRange(2, 1, 1, headers.length).setValues([[
        Session.getActiveUser().getEmail() || '',
        '관리자',
        'admin',
        true,
        new Date(),
        new Date()
      ]]);

      usersSheet.setFrozenRows(1);

      addStep('MailCenterUsers', true, 'MailCenterUsers 시트를 새로 만들었습니다.', {
        sheet: 'MailCenterUsers'
      });
    } else {
      addStep('MailCenterUsers', true, 'MailCenterUsers 시트가 이미 있어 변경하지 않았습니다.', {
        sheet: 'MailCenterUsers'
      });
    }
  } catch (err) {
    addStep('MailCenterUsers', false, 'MailCenterUsers 시트 자동 생성 실패', {
      error: String(err && err.message ? err.message : err)
    });
  }

  Logger.log('JSON_COMPACT_RESULT: ' + JSON.stringify(result));
  return result;
}
function mcGoogleCalendarSyncRepairUsersHeaderV01() {
  const BUILD = 'MC_GOOGLE_CALENDAR_SYNC_REPAIR_USERS_HEADER_V01_20260527';

  const masterDbId = '1TFZ7Ihgnmxu-ziQAoB6nOf1AByxFahk9UtrmiyZ0q_0';

  const result = {
    ok: true,
    build: BUILD,
    action: 'mcGoogleCalendarSyncRepairUsersHeaderV01',
    steps: [],
    generatedAt: Utilities.formatDate(
      new Date(),
      Session.getScriptTimeZone(),
      'yyyy-MM-dd HH:mm:ss'
    )
  };

  function addStep(name, ok, message, extra) {
    result.steps.push({
      name: name,
      ok: ok,
      message: message,
      extra: extra || {}
    });
    if (!ok) result.ok = false;
  }

  try {
    const ss = SpreadsheetApp.openById(masterDbId);
    let sh = ss.getSheetByName('MailCenterUsers');

    if (!sh) {
      sh = ss.insertSheet('MailCenterUsers');
      addStep('CREATE_SHEET', true, 'MailCenterUsers 시트를 새로 만들었습니다.');
    }

    const headers = [
      'USER_EMAIL',
      'USER_NAME',
      'ROLE',
      'IS_ACTIVE',
      'email',
      'name',
      'role',
      'active',
      'createdAt',
      'updatedAt'
    ];

    sh.getRange(1, 1, 1, headers.length).setValues([headers]);
    sh.setFrozenRows(1);

    const activeUserEmail = Session.getActiveUser().getEmail() || '';

    const row2 = [
      activeUserEmail,
      '관리자',
      'admin',
      true,
      activeUserEmail,
      '관리자',
      'admin',
      true,
      new Date(),
      new Date()
    ];

    sh.getRange(2, 1, 1, row2.length).setValues([row2]);

    addStep('REPAIR_HEADER', true, 'MailCenterUsers 헤더를 호환형으로 재설정했습니다.', {
      sheet: 'MailCenterUsers',
      headers: headers
    });

  } catch (err) {
    addStep('REPAIR_HEADER', false, 'MailCenterUsers 헤더 복구 실패', {
      error: String(err && err.message ? err.message : err)
    });
  }

  Logger.log('JSON_COMPACT_RESULT: ' + JSON.stringify(result));
  return result;
}
function mcGoogleCalendarSyncRepairUsersHeaderV02() {
  const BUILD = 'MC_GOOGLE_CALENDAR_SYNC_REPAIR_USERS_HEADER_V02_20260527';
  const masterDbId = '1TFZ7Ihgnmxu-ziQAoB6nOf1AByxFahk9UtrmiyZ0q_0';

  const result = {
    ok: true,
    build: BUILD,
    action: 'mcGoogleCalendarSyncRepairUsersHeaderV02',
    steps: [],
    generatedAt: Utilities.formatDate(
      new Date(),
      Session.getScriptTimeZone(),
      'yyyy-MM-dd HH:mm:ss'
    )
  };

  function addStep(name, ok, message, extra) {
    result.steps.push({
      name: name,
      ok: ok,
      message: message,
      extra: extra || {}
    });
    if (!ok) result.ok = false;
  }

  try {
    const ss = SpreadsheetApp.openById(masterDbId);
    let sh = ss.getSheetByName('MailCenterUsers');

    if (!sh) {
      sh = ss.insertSheet('MailCenterUsers');
      addStep('CREATE_SHEET', true, 'MailCenterUsers 시트를 새로 만들었습니다.');
    }

    /**
     * 테스트 코드가 정확히 어떤 헤더명을 찾는지 아직 안 보이므로
     * 가능한 actor/user 계열 헤더를 넓게 깔아줍니다.
     */
    const headers = [
      'ACTOR_EMAIL',
      'ACTOR_NAME',
      'USER_EMAIL',
      'USER_NAME',
      'EMAIL',
      'NAME',
      'ROLE',
      'ACTIVE',
      'IS_ACTIVE',
      'STATUS',
      'email',
      'name',
      'role',
      'active',
      'createdAt',
      'updatedAt'
    ];

    const activeUserEmail =
      Session.getActiveUser().getEmail() ||
      Session.getEffectiveUser().getEmail() ||
      'feelhaus@feelhausfair.com';

    const row = [
      activeUserEmail,
      '관리자',
      activeUserEmail,
      '관리자',
      activeUserEmail,
      '관리자',
      'admin',
      true,
      true,
      'ACTIVE',
      activeUserEmail,
      '관리자',
      'admin',
      true,
      new Date(),
      new Date()
    ];

    sh.clearContents();
    sh.getRange(1, 1, 1, headers.length).setValues([headers]);
    sh.getRange(2, 1, 1, row.length).setValues([row]);
    sh.setFrozenRows(1);

    addStep('REPAIR_HEADER', true, 'MailCenterUsers 헤더를 V02 호환형으로 재설정했습니다.', {
      sheet: 'MailCenterUsers',
      headers: headers,
      userEmail: activeUserEmail
    });

  } catch (err) {
    addStep('REPAIR_HEADER', false, 'MailCenterUsers 헤더 복구 실패', {
      error: String(err && err.message ? err.message : err)
    });
  }

  Logger.log('JSON_COMPACT_RESULT: ' + JSON.stringify(result));
  return result;
}
function mcGoogleCalendarSyncRepairUsersHeaderV03AndTest() {
  const repairResult = mcGoogleCalendarSyncRepairUsersHeaderV03();

  let testResult = null;
  let testError = '';

  try {
    testResult = mcGoogleCalendarSyncTestGateV03All();
  } catch (err) {
    testError = String(err && err.message ? err.message : err);
  }

  const result = {
    ok: !!repairResult.ok && !!testResult && !!testResult.ok,
    build: 'MC_GOOGLE_CALENDAR_SYNC_REPAIR_USERS_HEADER_V03_AND_TEST_20260527',
    action: 'mcGoogleCalendarSyncRepairUsersHeaderV03AndTest',
    repairResult: repairResult,
    testResult: testResult,
    testError: testError,
    generatedAt: Utilities.formatDate(
      new Date(),
      Session.getScriptTimeZone(),
      'yyyy-MM-dd HH:mm:ss'
    )
  };

  Logger.log('JSON_COMPACT_RESULT: ' + JSON.stringify(result));
  return result;
}


function mcGoogleCalendarSyncRepairUsersHeaderV03() {
  const BUILD = 'MC_GOOGLE_CALENDAR_SYNC_REPAIR_USERS_HEADER_V03_20260527';
  const masterDbId = '1TFZ7Ihgnmxu-ziQAoB6nOf1AByxFahk9UtrmiyZ0q_0';

  const result = {
    ok: true,
    build: BUILD,
    action: 'mcGoogleCalendarSyncRepairUsersHeaderV03',
    steps: [],
    generatedAt: Utilities.formatDate(
      new Date(),
      Session.getScriptTimeZone(),
      'yyyy-MM-dd HH:mm:ss'
    )
  };

  function addStep(name, ok, message, extra) {
    result.steps.push({
      name: name,
      ok: ok,
      message: message,
      extra: extra || {}
    });
    if (!ok) result.ok = false;
  }

  try {
    const ss = SpreadsheetApp.openById(masterDbId);

    let sh = ss.getSheetByName('MailCenterUsers');
    if (!sh) {
      sh = ss.insertSheet('MailCenterUsers');
      addStep('CREATE_SHEET', true, 'MailCenterUsers 시트를 새로 만들었습니다.');
    }

    const activeUserEmail =
      Session.getActiveUser().getEmail() ||
      Session.getEffectiveUser().getEmail() ||
      'feelhaus@feelhausfair.com';

    /**
     * 헤더명을 가능한 넓게 깔아둡니다.
     * 테스트 코드가 어떤 이름을 찾는지 몰라도 대부분 걸리도록 구성합니다.
     */
    const headers = [
      'id',
      'userId',
      'user_id',
      'USER_ID',

      'email',
      'userEmail',
      'user_email',
      'USER_EMAIL',
      'EMAIL',
      'ACTOR_EMAIL',

      'name',
      'userName',
      'user_name',
      'USER_NAME',
      'NAME',
      'ACTOR_NAME',

      'role',
      'userRole',
      'user_role',
      'USER_ROLE',
      'ROLE',

      'active',
      'isActive',
      'is_active',
      'IS_ACTIVE',
      'ACTIVE',
      'STATUS',

      'createdAt',
      'created_at',
      'CREATED_AT',
      'updatedAt',
      'updated_at',
      'UPDATED_AT'
    ];

    const row = [
      'admin-001',
      'admin-001',
      'admin-001',
      'admin-001',

      activeUserEmail,
      activeUserEmail,
      activeUserEmail,
      activeUserEmail,
      activeUserEmail,
      activeUserEmail,

      '관리자',
      '관리자',
      '관리자',
      '관리자',
      '관리자',
      '관리자',

      'admin',
      'admin',
      'admin',
      'admin',
      'admin',

      true,
      true,
      true,
      true,
      true,
      'ACTIVE',

      new Date(),
      new Date(),
      new Date(),
      new Date(),
      new Date(),
      new Date()
    ];

    sh.clear();

    sh.getRange(1, 1, 1, headers.length).setValues([headers]);
    sh.getRange(2, 1, 1, row.length).setValues([row]);

    sh.setFrozenRows(1);
    sh.autoResizeColumns(1, headers.length);

    const checkHeaders = sh.getRange(1, 1, 1, headers.length).getValues()[0];

    addStep('REPAIR_HEADER', true, 'MailCenterUsers 헤더를 V03 호환형으로 재설정했습니다.', {
      spreadsheetName: ss.getName(),
      sheet: sh.getName(),
      userEmail: activeUserEmail,
      headerCount: checkHeaders.length,
      headers: checkHeaders
    });

  } catch (err) {
    addStep('REPAIR_HEADER', false, 'MailCenterUsers 헤더 복구 실패', {
      error: String(err && err.message ? err.message : err)
    });
  }

  Logger.log('JSON_COMPACT_RESULT: ' + JSON.stringify(result));
  return result;
}
function mcGoogleCalendarSyncDebugEnvCheckSourceV01() {
  const result = {
    ok: true,
    build: 'MC_GOOGLE_CALENDAR_SYNC_DEBUG_ENV_CHECK_SOURCE_V01_20260527',
    action: 'mcGoogleCalendarSyncDebugEnvCheckSourceV01',
    functions: {},
    generatedAt: Utilities.formatDate(
      new Date(),
      Session.getScriptTimeZone(),
      'yyyy-MM-dd HH:mm:ss'
    )
  };

  function captureFunction(name) {
    try {
      const fn = this[name];

      if (typeof fn !== 'function') {
        result.functions[name] = {
          ok: false,
          message: 'function not found',
          type: typeof fn
        };
        result.ok = false;
        return;
      }

      const source = String(fn);

      result.functions[name] = {
        ok: true,
        name: name,
        length: source.length,
        sourcePreview: source.slice(0, 8000)
      };
    } catch (err) {
      result.functions[name] = {
        ok: false,
        name: name,
        error: String(err && err.message ? err.message : err)
      };
      result.ok = false;
    }
  }

  captureFunction('mcGoogleCalendarSyncTestGateV03EnvCheck_');
  captureFunction('mcGoogleCalendarSyncPrepV01GetStatus');
  captureFunction('mcGoogleCalendarSyncPrepV01DryRun');
  captureFunction('mcGoogleCalendarBidirectionalSyncV01Apply');

  Logger.log('JSON_COMPACT_RESULT: ' + JSON.stringify(result));
  return result;
}
function mcGoogleCalendarSyncDebugCoreSourcesV01() {
  const result = {
    ok: true,
    build: 'MC_GOOGLE_CALENDAR_SYNC_DEBUG_CORE_SOURCES_V01_20260527',
    action: 'mcGoogleCalendarSyncDebugCoreSourcesV01',
    functions: {},
    generatedAt: Utilities.formatDate(
      new Date(),
      Session.getScriptTimeZone(),
      'yyyy-MM-dd HH:mm:ss'
    )
  };

  function captureFunction(name) {
    try {
      const fn = this[name];

      if (typeof fn !== 'function') {
        result.functions[name] = {
          ok: false,
          message: 'function not found',
          type: typeof fn
        };
        result.ok = false;
        return;
      }

      const source = String(fn);

      result.functions[name] = {
        ok: true,
        name: name,
        length: source.length,
        sourcePreview: source.slice(0, 12000)
      };
    } catch (err) {
      result.functions[name] = {
        ok: false,
        name: name,
        error: String(err && err.message ? err.message : err)
      };
      result.ok = false;
    }
  }

  [
    'mcCalendar186ResolveCalendarActor_',
    'mcCalendar186SafeActorSummary_',
    'mcCalendar186PermissionGuard_',
    'mcCalendar186ActorKey_',
    'mcGoogleCalendarSyncTestGateV03All',
    'mcGoogleCalendarSyncTestGateV03RunStep_',
    'mcGoogleCalendarBidirectionalSyncV01Apply'
  ].forEach(captureFunction);

  Logger.log('JSON_COMPACT_RESULT: ' + JSON.stringify(result));
  return result;
}
function mcGoogleCalendarSyncDebugMissingCoreV01() {
  const result = {
    ok: true,
    build: 'MC_GOOGLE_CALENDAR_SYNC_DEBUG_MISSING_CORE_V01_20260527',
    action: 'mcGoogleCalendarSyncDebugMissingCoreV01',
    functions: {},
    generatedAt: Utilities.formatDate(
      new Date(),
      Session.getScriptTimeZone(),
      'yyyy-MM-dd HH:mm:ss'
    )
  };

  function captureFunction(name) {
    try {
      const fn = this[name];

      if (typeof fn !== 'function') {
        result.functions[name] = {
          ok: false,
          message: 'function not found',
          type: typeof fn
        };
        result.ok = false;
        return;
      }

      const source = String(fn);

      result.functions[name] = {
        ok: true,
        name: name,
        length: source.length,
        sourcePreview: source.slice(0, 12000)
      };
    } catch (err) {
      result.functions[name] = {
        ok: false,
        name: name,
        error: String(err && err.message ? err.message : err)
      };
      result.ok = false;
    }
  }

  [
    'mcCalendar186ReadMailCenterUsersForCalendar_',
    'mcCalendar186NormalizeMailCenterActor_',
    'mcCalendar186HasPermission_',
    'mcGoogleCalendarSyncTestGateV03Call_',
    'mcGoogleCalendarSyncTestGateV03PushStep_'
  ].forEach(captureFunction);

  Logger.log('JSON_COMPACT_RESULT: ' + JSON.stringify(result));
  return result;
}
function mcGoogleCalendarSyncRepairUsersHeaderV04AndTest() {
  const repairResult = mcGoogleCalendarSyncRepairUsersHeaderV04();

  let testResult = null;
  let testError = '';

  try {
    testResult = mcGoogleCalendarSyncTestGateV03All();
  } catch (err) {
    testError = String(err && err.message ? err.message : err);
  }

  const result = {
    ok: !!repairResult.ok && !!testResult && !!testResult.ok,
    build: 'MC_GOOGLE_CALENDAR_SYNC_REPAIR_USERS_HEADER_V04_AND_TEST_20260527',
    action: 'mcGoogleCalendarSyncRepairUsersHeaderV04AndTest',
    repairResult: repairResult,
    testResult: testResult,
    testError: testError,
    generatedAt: Utilities.formatDate(
      new Date(),
      Session.getScriptTimeZone(),
      'yyyy-MM-dd HH:mm:ss'
    )
  };

  Logger.log('JSON_COMPACT_RESULT: ' + JSON.stringify(result));
  return result;
}


function mcGoogleCalendarSyncRepairUsersHeaderV04() {
  const BUILD = 'MC_GOOGLE_CALENDAR_SYNC_REPAIR_USERS_HEADER_V04_20260527';
  const masterDbId = '1TFZ7Ihgnmxu-ziQAoB6nOf1AByxFahk9UtrmiyZ0q_0';

  const result = {
    ok: true,
    build: BUILD,
    action: 'mcGoogleCalendarSyncRepairUsersHeaderV04',
    steps: [],
    generatedAt: Utilities.formatDate(
      new Date(),
      Session.getScriptTimeZone(),
      'yyyy-MM-dd HH:mm:ss'
    )
  };

  function addStep(name, ok, message, extra) {
    result.steps.push({
      name: name,
      ok: ok,
      message: message,
      extra: extra || {}
    });
    if (!ok) result.ok = false;
  }

  try {
    const ss = SpreadsheetApp.openById(masterDbId);

    let sh = ss.getSheetByName('MailCenterUsers');
    if (!sh) {
      sh = ss.insertSheet('MailCenterUsers');
    }

    const activeUserEmail =
      Session.getActiveUser().getEmail() ||
      Session.getEffectiveUser().getEmail() ||
      'feelhaus@feelhausfair.com';

    const headers = [
      'userId',
      'loginId',
      'employeeId',
      'employeeName',
      'roleCode',
      'vendorId',
      'isActive',
      'status'
    ];

    const row = [
      'admin-001',
      activeUserEmail,
      'admin-001',
      '관리자',
      'ADMIN',
      '',
      'Y',
      'ACTIVE'
    ];

    sh.clear();
    sh.getRange(1, 1, 1, headers.length).setValues([headers]);
    sh.getRange(2, 1, 1, row.length).setValues([row]);
    sh.setFrozenRows(1);
    sh.autoResizeColumns(1, headers.length);

    addStep('REPAIR_HEADER', true, 'MailCenterUsers 필수 헤더를 정확한 이름으로 재설정했습니다.', {
      spreadsheetName: ss.getName(),
      sheet: sh.getName(),
      headers: headers,
      row: row
    });

  } catch (err) {
    addStep('REPAIR_HEADER', false, 'MailCenterUsers V04 복구 실패', {
      error: String(err && err.message ? err.message : err)
    });
  }

  Logger.log('JSON_COMPACT_RESULT: ' + JSON.stringify(result));
  return result;
}
function mcGoogleCalendarSyncDebugClientSafeV01() {
  const result = {
    ok: true,
    build: 'MC_GOOGLE_CALENDAR_SYNC_DEBUG_CLIENT_SAFE_V01_20260527',
    action: 'mcGoogleCalendarSyncDebugClientSafeV01',
    functions: {},
    directTests: {},
    generatedAt: Utilities.formatDate(
      new Date(),
      Session.getScriptTimeZone(),
      'yyyy-MM-dd HH:mm:ss'
    )
  };

  function captureFunction(name) {
    try {
      const fn = this[name];

      if (typeof fn !== 'function') {
        result.functions[name] = {
          ok: false,
          message: 'function not found',
          type: typeof fn
        };
        result.ok = false;
        return;
      }

      const source = String(fn);

      result.functions[name] = {
        ok: true,
        name: name,
        length: source.length,
        sourcePreview: source.slice(0, 8000)
      };
    } catch (err) {
      result.functions[name] = {
        ok: false,
        name: name,
        error: String(err && err.message ? err.message : err)
      };
      result.ok = false;
    }
  }

  captureFunction('mcCalendar19ClientSafeObject_');
  captureFunction('mcCalendar19SafeResult_');

  try {
    const sample = {
      ok: true,
      action: 'SAMPLE_ACTION',
      message: 'sample message',
      nested: {
        a: 1
      }
    };

    result.directTests.clientSafeObjectInput = sample;

    if (typeof mcCalendar19ClientSafeObject_ === 'function') {
      result.directTests.clientSafeObjectOutput = mcCalendar19ClientSafeObject_(sample);
      result.directTests.clientSafeObjectOutputType = typeof result.directTests.clientSafeObjectOutput;
    } else {
      result.directTests.clientSafeObjectOutput = null;
      result.directTests.clientSafeObjectOutputType = 'function not found';
    }

    if (typeof mcCalendar19SafeResult_ === 'function') {
      result.directTests.safeResultOutput = mcCalendar19SafeResult_('SAMPLE_ACTION');
      result.directTests.safeResultOutputType = typeof result.directTests.safeResultOutput;
    } else {
      result.directTests.safeResultOutput = null;
      result.directTests.safeResultOutputType = 'function not found';
    }
  } catch (err) {
    result.directTests.error = String(err && err.message ? err.message : err);
    result.ok = false;
  }

  Logger.log('JSON_COMPACT_RESULT: ' + JSON.stringify(result));
  return result;
}
/**
 * MC_GOOGLE_CALENDAR_SYNC_SAFE_GATE_V05_20260527
 * 목적: V04까지 누적된 Google Calendar sync 테스트 스택은 보존하되,
 * MailCenterUsers clear()/clearContents() 계열 복구 함수를 실수로 실행하지 못하게 차단하고,
 * 읽기/DRY_RUN 중심의 안전 게이트를 제공합니다.
 */
function mcGoogleCalendarSyncSafeGateV05All() {
  var result = {
    ok: true,
    build: 'MC_GOOGLE_CALENDAR_SYNC_SAFE_GATE_V05_20260527',
    action: 'mcGoogleCalendarSyncSafeGateV05All',
    message: 'Google Calendar sync safe gate V05 completed. No destructive repair and no real apply executed.',
    steps: [],
    summary: {},
    startedAt: mcGoogleCalendarSyncSafeGateV05Now_()
  };

  mcGoogleCalendarSyncSafeGateV05Push_(result, 'SELF_TEST', mcGoogleCalendarSyncSafeGateV05Call_('mcGoogleCalendarBidirectionalSyncV01SelfTest', []));
  mcGoogleCalendarSyncSafeGateV05Push_(result, 'LEGACY_REPAIR_BLOCK_CHECK', mcGoogleCalendarSyncSafeGateV05RepairBlockCheck_());
  mcGoogleCalendarSyncSafeGateV05Push_(result, 'MAILCENTER_USERS_AUDIT_ONLY', mcGoogleCalendarSyncUsersHeaderV05AuditOnly());
  mcGoogleCalendarSyncSafeGateV05Push_(result, 'ENV_CHECK', mcGoogleCalendarSyncSafeGateV05Call_('mcGoogleCalendarSyncTestGateV03EnvCheck_', []));
  mcGoogleCalendarSyncSafeGateV05Push_(result, 'STATUS', mcGoogleCalendarSyncSafeGateV05Call_('mcGoogleCalendarSyncPrepV01GetStatus', [{}]));
  mcGoogleCalendarSyncSafeGateV05Push_(result, 'PREP_DRY_RUN', mcGoogleCalendarSyncSafeGateV05Call_('mcGoogleCalendarSyncPrepV01DryRun', [{}]));
  mcGoogleCalendarSyncSafeGateV05Push_(result, 'APPLY_DRY_RUN', mcGoogleCalendarSyncSafeGateV05Call_('mcGoogleCalendarBidirectionalSyncV01Apply', [{ dryRun: 'Y', direction: 'BOTH', maxOps: 20 }]));

  var okSteps = 0;
  var failed = [];
  for (var i = 0; i < result.steps.length; i++) {
    if (result.steps[i].ok) okSteps++;
    else failed.push(result.steps[i].name);
  }
  result.summary = {
    totalSteps: result.steps.length,
    okSteps: okSteps,
    failedSteps: failed.length,
    failedStepNames: failed,
    destructiveRepairBlocked: true,
    realApplyExecuted: false,
    nextAction: failed.length === 0
      ? 'V05 안전 게이트 통과. 실반영 전 결과의 후보 수량과 충돌 항목을 확인하세요.'
      : '실반영 금지. failedStepNames와 각 step의 errorMessage/rawCompact를 확인하세요.'
  };
  result.ok = failed.length === 0;
  result.finishedAt = mcGoogleCalendarSyncSafeGateV05Now_();
  mcGoogleCalendarSyncSafeGateV05Log_(result);
  return result;
}

function mcGoogleCalendarSyncUsersHeaderV05AuditOnly() {
  var result = {
    ok: true,
    build: 'MC_GOOGLE_CALENDAR_SYNC_SAFE_GATE_V05_20260527',
    action: 'mcGoogleCalendarSyncUsersHeaderV05AuditOnly',
    message: 'MailCenterUsers audit only completed. No sheet clear/write executed.',
    checks: {},
    generatedAt: mcGoogleCalendarSyncSafeGateV05Now_()
  };
  try {
    var config = mcCalendar19GetConfigBundle_();
    var ss = mcCalendar19OpenMaster_(config);
    result.checks.masterDb = { ok: true, name: ss.getName(), id: ss.getId() };
    var sh = ss.getSheetByName('MailCenterUsers');
    if (!sh) {
      result.ok = false;
      result.message = 'MailCenterUsers 시트 없음. 승인형 비파괴 생성이 필요합니다.';
      result.checks.sheet = { ok: false, message: 'sheet not found' };
      return result;
    }
    var lastCol = Math.max(sh.getLastColumn(), 1);
    var headers = sh.getRange(1, 1, 1, lastCol).getValues()[0].map(function(v) { return String(v || '').trim(); });
    var required = ['userId', 'loginId', 'employeeId', 'employeeName', 'roleCode', 'vendorId', 'isActive', 'status'];
    var lowerMap = {};
    headers.forEach(function(h) { if (h) lowerMap[h.toLowerCase()] = true; });
    var missing = [];
    required.forEach(function(h) { if (!lowerMap[h.toLowerCase()]) missing.push(h); });
    result.checks.sheet = {
      ok: true,
      name: sh.getName(),
      lastRow: sh.getLastRow(),
      lastColumn: sh.getLastColumn(),
      headerCount: headers.filter(function(h) { return !!h; }).length,
      headers: headers
    };
    result.checks.requiredHeaders = { ok: missing.length === 0, required: required, missing: missing };
    if (missing.length) {
      result.ok = false;
      result.message = 'MailCenterUsers 필수 헤더 일부 누락. clear 없는 승인형 보강만 허용됩니다.';
    }
  } catch (err) {
    result.ok = false;
    result.message = 'MailCenterUsers audit 실패';
    result.errorMessage = mcGoogleCalendarSyncSafeGateV05Error_(err);
  }
  return result;
}

function mcGoogleCalendarSyncSafeGateV05RepairBlockCheck_() {
  return {
    ok: true,
    build: 'MC_GOOGLE_CALENDAR_SYNC_SAFE_GATE_V05_20260527',
    action: 'mcGoogleCalendarSyncSafeGateV05RepairBlockCheck_',
    message: 'Legacy MailCenterUsers destructive repair functions are blocked by V05 wrappers.',
    blockedFunctions: [
      'mcGoogleCalendarSyncRepairUsersHeaderV01',
      'mcGoogleCalendarSyncRepairUsersHeaderV02',
      'mcGoogleCalendarSyncRepairUsersHeaderV03',
      'mcGoogleCalendarSyncRepairUsersHeaderV03AndTest',
      'mcGoogleCalendarSyncRepairUsersHeaderV04',
      'mcGoogleCalendarSyncRepairUsersHeaderV04AndTest'
    ],
    realApplyExecuted: false,
    destructiveRepairBlocked: true
  };
}

function mcGoogleCalendarSyncSafeGateV05Call_(fnName, args) {
  try {
    var fn = null;
    try {
      if (typeof globalThis !== 'undefined' && typeof globalThis[fnName] === 'function') fn = globalThis[fnName];
    } catch (ignoreGlobal) {}
    if (!fn) {
      try { fn = eval(fnName); } catch (ignoreEval) {}
    }
    if (typeof fn !== 'function') throw new Error(fnName + ' 함수를 찾지 못했습니다.');
    var res = fn.apply(null, args || []);
    return res;
  } catch (err) {
    return {
      ok: false,
      build: 'MC_GOOGLE_CALENDAR_SYNC_SAFE_GATE_V05_20260527',
      action: fnName,
      message: mcGoogleCalendarSyncSafeGateV05Error_(err),
      errorMessage: mcGoogleCalendarSyncSafeGateV05Error_(err)
    };
  }
}

function mcGoogleCalendarSyncSafeGateV05Push_(result, name, res) {
  var step = {
    name: name,
    ok: false,
    message: '',
    errorMessage: '',
    summary: null,
    diagnostic: {},
    rawCompact: '',
    build: ''
  };
  try {
    step.ok = !!(res && res.ok === true);
    step.message = res && res.message ? String(res.message) : '';
    step.errorMessage = res && res.errorMessage ? String(res.errorMessage) : '';
    step.summary = res && res.summary ? res.summary : null;
    step.build = res && res.build ? String(res.build) : '';
    step.diagnostic = mcGoogleCalendarSyncSafeGateV05Diagnostic_(res);
    step.rawCompact = mcGoogleCalendarSyncSafeGateV05Compact_(res, 5000);
    if (!step.ok && !step.message) step.message = step.errorMessage || 'ok:false but message is empty. rawCompact/diagnostic 확인 필요';
  } catch (err) {
    step.ok = false;
    step.message = mcGoogleCalendarSyncSafeGateV05Error_(err);
    step.errorMessage = mcGoogleCalendarSyncSafeGateV05Error_(err);
  }
  result.steps.push(step);
}

function mcGoogleCalendarSyncSafeGateV05Diagnostic_(res) {
  var d = { resultType: typeof res };
  if (res && typeof res === 'object') {
    d.keys = Object.keys(res);
    if (res.checks) d.checks = res.checks;
    if (res.summary) d.summary = res.summary;
    if (res.counts) d.counts = res.counts;
    if (res.policy) d.policy = res.policy;
    if (res.googleAccess) d.googleAccess = res.googleAccess;
    if (res.blockedFunctions) d.blockedFunctions = res.blockedFunctions;
  }
  return d;
}

function mcGoogleCalendarSyncSafeGateV05Error_(err) {
  if (!err) return '';
  if (typeof err === 'string') return err;
  if (err.name && err.message) return String(err.name) + ': ' + String(err.message);
  if (err.message) return String(err.message);
  try { return JSON.stringify(err); } catch (ignore) { return String(err); }
}

function mcGoogleCalendarSyncSafeGateV05Compact_(obj, maxLen) {
  var text = '';
  try {
    text = JSON.stringify(obj, function(key, value) {
      if (value instanceof Date) return mcGoogleCalendarSyncSafeGateV05Now_(value);
      if (typeof value === 'function') return '[Function]';
      return value;
    });
  } catch (err) {
    text = '[JSON_STRINGIFY_FAIL] ' + mcGoogleCalendarSyncSafeGateV05Error_(err);
  }
  if (maxLen && text.length > maxLen) return text.substring(0, maxLen) + '...TRUNCATED';
  return text;
}

function mcGoogleCalendarSyncSafeGateV05Log_(result) {
  try { Logger.log('JSON_COMPACT_RESULT: ' + mcGoogleCalendarSyncSafeGateV05Compact_(result, 20000)); } catch (ignore) {}
}

function mcGoogleCalendarSyncSafeGateV05Now_(dateObj) {
  var d = dateObj || new Date();
  try { return Utilities.formatDate(d, Session.getScriptTimeZone() || 'Asia/Seoul', 'yyyy-MM-dd HH:mm:ss'); }
  catch (err) { return String(d); }
}

function mcGoogleCalendarSyncSafeGateV05BlockedRepair_(actionName) {
  var result = {
    ok: false,
    build: 'MC_GOOGLE_CALENDAR_SYNC_SAFE_GATE_V05_20260527',
    action: actionName,
    message: 'V05 safety block: MailCenterUsers clear/overwrite repair is blocked. No changes executed.',
    destructiveRepairBlocked: true,
    realApplyExecuted: false,
    nextAction: 'mcGoogleCalendarSyncSafeGateV05All 실행 결과를 확인한 뒤, 필요한 경우 승인형 비파괴 보강 함수만 별도 제공받아 실행하세요.',
    generatedAt: mcGoogleCalendarSyncSafeGateV05Now_()
  };
  mcGoogleCalendarSyncSafeGateV05Log_(result);
  return result;
}

// Legacy destructive repair wrappers: later declarations override earlier clear()/clearContents() repair functions in Apps Script V8.
function mcGoogleCalendarSyncRepairUsersHeaderV01() { return mcGoogleCalendarSyncSafeGateV05BlockedRepair_('mcGoogleCalendarSyncRepairUsersHeaderV01'); }
function mcGoogleCalendarSyncRepairUsersHeaderV02() { return mcGoogleCalendarSyncSafeGateV05BlockedRepair_('mcGoogleCalendarSyncRepairUsersHeaderV02'); }
function mcGoogleCalendarSyncRepairUsersHeaderV03() { return mcGoogleCalendarSyncSafeGateV05BlockedRepair_('mcGoogleCalendarSyncRepairUsersHeaderV03'); }
function mcGoogleCalendarSyncRepairUsersHeaderV03AndTest() { return mcGoogleCalendarSyncSafeGateV05BlockedRepair_('mcGoogleCalendarSyncRepairUsersHeaderV03AndTest'); }
function mcGoogleCalendarSyncRepairUsersHeaderV04() { return mcGoogleCalendarSyncSafeGateV05BlockedRepair_('mcGoogleCalendarSyncRepairUsersHeaderV04'); }
function mcGoogleCalendarSyncRepairUsersHeaderV04AndTest() { return mcGoogleCalendarSyncSafeGateV05BlockedRepair_('mcGoogleCalendarSyncRepairUsersHeaderV04AndTest'); }

/*******************************************************
 * MC_GOOGLE_CALENDAR_SYNC_SAFE_GATE_V06_COMPACT_20260527
 * Purpose: compact one-line safe gate result for Apps Script logs.
 * No real apply. No destructive repair. No sheet clear.
 *******************************************************/
function mcGoogleCalendarSyncSafeGateV06CompactAll() {
  var startedAt = mcGoogleCalendarSyncSafeGateV06Now_();
  var steps = [];
  steps.push(mcGoogleCalendarSyncSafeGateV06RunStep_('SELF_TEST', function () {
    return mcGoogleCalendarBidirectionalSyncV01SelfTest();
  }));
  steps.push(mcGoogleCalendarSyncSafeGateV06RunStep_('LEGACY_REPAIR_BLOCK_CHECK', function () {
    if (typeof mcGoogleCalendarSyncSafeGateV05RepairBlockCheck_ === 'function') return mcGoogleCalendarSyncSafeGateV05RepairBlockCheck_();
    return { ok: false, message: 'mcGoogleCalendarSyncSafeGateV05RepairBlockCheck_ not found' };
  }));
  steps.push(mcGoogleCalendarSyncSafeGateV06RunStep_('MAILCENTER_USERS_AUDIT_ONLY', function () {
    if (typeof mcGoogleCalendarSyncUsersHeaderV05AuditOnly === 'function') return mcGoogleCalendarSyncUsersHeaderV05AuditOnly();
    return { ok: false, message: 'mcGoogleCalendarSyncUsersHeaderV05AuditOnly not found' };
  }));
  steps.push(mcGoogleCalendarSyncSafeGateV06RunStep_('ENV_CHECK', function () {
    if (typeof mcGoogleCalendarSyncTestGateV03EnvCheck_ === 'function') return mcGoogleCalendarSyncTestGateV03EnvCheck_();
    return { ok: false, message: 'mcGoogleCalendarSyncTestGateV03EnvCheck_ not found' };
  }));
  steps.push(mcGoogleCalendarSyncSafeGateV06RunStep_('STATUS', function () {
    return mcGoogleCalendarSyncPrepV01GetStatus({});
  }));
  steps.push(mcGoogleCalendarSyncSafeGateV06RunStep_('PREP_DRY_RUN', function () {
    return mcGoogleCalendarSyncPrepV01DryRun({ maxSamples: 0 });
  }));
  steps.push(mcGoogleCalendarSyncSafeGateV06RunStep_('APPLY_DRY_RUN', function () {
    return mcGoogleCalendarBidirectionalSyncV01Apply({ dryRun: 'Y', direction: 'BOTH', maxOps: 20 });
  }));

  var okSteps = 0;
  var failed = [];
  for (var i = 0; i < steps.length; i++) {
    if (steps[i].ok) okSteps++;
    else failed.push(steps[i].name);
  }
  var result = {
    ok: failed.length === 0,
    build: 'MC_GOOGLE_CALENDAR_SYNC_SAFE_GATE_V06_COMPACT_20260527',
    action: 'mcGoogleCalendarSyncSafeGateV06CompactAll',
    message: 'Google Calendar sync safe gate V06 compact completed. No destructive repair and no real apply executed.',
    realApplyExecuted: false,
    destructiveRepairExecuted: false,
    steps: steps,
    summary: {
      totalSteps: steps.length,
      okSteps: okSteps,
      failedSteps: failed.length,
      failedStepNames: failed,
      googleRealApplyAllowed: failed.length === 0 ? 'PENDING_USER_APPROVAL_AND_CONFIG_ON' : 'NO',
      nextAction: failed.length === 0 ? 'V06 compact gate passed. Keep real apply OFF until SystemConfig/approval decision.' : 'Review failedStepNames. Do not execute real apply.'
    },
    startedAt: startedAt,
    finishedAt: mcGoogleCalendarSyncSafeGateV06Now_()
  };
  mcGoogleCalendarSyncSafeGateV06Log_(result);
  return result;
}

function mcGoogleCalendarSyncSafeGateV06RunStep_(name, fn) {
  var started = new Date();
  try {
    var raw = fn();
    return mcGoogleCalendarSyncSafeGateV06Summarize_(name, raw, started);
  } catch (err) {
    return {
      name: name,
      ok: false,
      message: mcGoogleCalendarSyncSafeGateV06Error_(err),
      errorMessage: mcGoogleCalendarSyncSafeGateV06Error_(err),
      elapsedMs: new Date().getTime() - started.getTime()
    };
  }
}

function mcGoogleCalendarSyncSafeGateV06Summarize_(name, raw, started) {
  var obj = raw;
  if (typeof obj === 'string') {
    return {
      name: name,
      ok: false,
      message: 'Function returned string instead of result object: ' + obj,
      resultType: 'string',
      elapsedMs: new Date().getTime() - started.getTime()
    };
  }
  obj = obj || {};
  var step = {
    name: name,
    ok: obj.ok === true,
    message: String(obj.message || ''),
    build: String(obj.build || ''),
    batchId: String(obj.batchId || ''),
    elapsedMs: new Date().getTime() - started.getTime()
  };
  if (!step.ok && !step.message) step.message = mcGoogleCalendarSyncSafeGateV06Error_(obj.error || obj.errorMessage || 'ok:false without message');
  if (obj.summary) step.summary = mcGoogleCalendarSyncSafeGateV06SmallObject_(obj.summary);
  if (name === 'SELF_TEST' && obj.checks) step.checks = mcGoogleCalendarSyncSafeGateV06SmallObject_(obj.checks);
  if (name === 'MAILCENTER_USERS_AUDIT_ONLY' && obj.checks) {
    step.mailCenterUsers = {
      sheetOk: !!(obj.checks.sheet && obj.checks.sheet.ok),
      requiredHeadersOk: !!(obj.checks.requiredHeaders && obj.checks.requiredHeaders.ok),
      lastRow: obj.checks.sheet ? obj.checks.sheet.lastRow : '',
      headerCount: obj.checks.sheet ? obj.checks.sheet.headerCount : '',
      missing: obj.checks.requiredHeaders ? obj.checks.requiredHeaders.missing : []
    };
  }
  if (name === 'ENV_CHECK' && obj.checks) {
    step.env = {
      configBundleOk: !!(obj.checks.configBundle && obj.checks.configBundle.ok),
      masterDbOk: !!(obj.checks.masterDb && obj.checks.masterDb.ok),
      googleCalendarIdOk: !!(obj.checks.googleCalendarId && obj.checks.googleCalendarId.ok),
      googleAccessOk: !!(obj.checks.googleAccess && obj.checks.googleAccess.ok),
      sheetsOk: !!(obj.checks.sheets && obj.checks.sheets.ok),
      actorOk: !!(obj.checks.actor && obj.checks.actor.ok),
      permissionViewOk: !!(obj.checks.permissionView && obj.checks.permissionView.ok)
    };
  }
  if (name === 'STATUS') {
    step.googleAccessOk = !!(obj.googleAccess && obj.googleAccess.ok);
    if (obj.policy) {
      step.policy = {
        googleBidirectionalReady: obj.policy.googleBidirectionalReady,
        googleBidirectionalEnabled: obj.policy.googleBidirectionalEnabled,
        googleSyncMode: obj.policy.googleSyncMode,
        naverInboundAutoImportEnabled: obj.policy.naverInboundAutoImportEnabled,
        naverBidirectionalEnabled: obj.policy.naverBidirectionalEnabled,
        naverDataReceiveMode: obj.policy.naverDataReceiveMode
      };
    }
  }
  if (name === 'PREP_DRY_RUN' && obj.samples) {
    step.sampleCounts = {
      portalToGoogle: obj.samples.portalToGoogle ? obj.samples.portalToGoogle.length : 0,
      googleToPortal: obj.samples.googleToPortal ? obj.samples.googleToPortal.length : 0,
      conflicts: obj.samples.conflicts ? obj.samples.conflicts.length : 0
    };
  }
  if (name === 'APPLY_DRY_RUN') {
    step.dryRun = true;
    if (obj.details) step.detailCount = obj.details.length;
  }
  return step;
}

function mcGoogleCalendarSyncSafeGateV06SmallObject_(obj) {
  var out = {};
  if (!obj) return out;
  var keys = Object.keys(obj);
  for (var i = 0; i < keys.length && i < 40; i++) {
    var k = keys[i];
    var v = obj[k];
    if (v && typeof v === 'object') {
      if (Object.prototype.toString.call(v) === '[object Array]') out[k] = { count: v.length };
      else out[k] = '[object]';
    } else {
      out[k] = v;
    }
  }
  return out;
}

function mcGoogleCalendarSyncSafeGateV06Log_(result) {
  var text;
  try { text = JSON.stringify(result); }
  catch (err) { text = '{"ok":false,"message":"JSON stringify failed"}'; }
  if (text.length > 8000) text = text.substring(0, 8000) + '...TRUNCATED_V06';
  try { Logger.log('JSON_COMPACT_RESULT: ' + text); } catch (ignore) {}
}

function mcGoogleCalendarSyncSafeGateV06Error_(err) {
  try {
    if (err === null || err === undefined) return '';
    if (typeof err === 'string') return err;
    if (err.message) return String(err.message);
    return String(err);
  } catch (ignore) {
    return 'unknown error';
  }
}

function mcGoogleCalendarSyncSafeGateV06Now_() {
  try { return Utilities.formatDate(new Date(), Session.getScriptTimeZone() || 'Asia/Seoul', 'yyyy-MM-dd HH:mm:ss'); }
  catch (err) { return String(new Date()); }
}
