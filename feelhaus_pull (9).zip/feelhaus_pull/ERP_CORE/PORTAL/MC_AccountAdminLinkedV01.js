/**
 * FEELHAUS MailCenter Account Admin Linked V01
 * Build: MC_ACCOUNT_ADMIN_LINKED_V01_20260519
 *
 * Purpose:
 * - 직원/업체 원본을 MailCenter에서 새로 만들지 않는다.
 * - 직원메일: 기존 직원/사용자 원본에서 선택 후 메일계정 연결
 * - 업체대표메일: 기존 업체 원본에서 선택 후 메일계정 연결
 * - MailCenter는 emailAddress / OAuth / 승인 / 발송권한만 관리한다.
 * - 성공한 송신/V04/V05/OAuth/169/171 파일은 수정하지 않는다.
 */

var MC_ACCOUNT_ADMIN_LINKED_V01_BUILD = 'MAILCENTER_ACCOUNT_ADMIN_APPROVAL_V01_20260520';
var MC_ACCOUNT_ADMIN_LINKED_V01_SETUP_DB_ID = '17VMSpgSZCvIrUlgcw8yCNcnl8WQWo2IcRf5tDCcuJGM';
var MC_ACCOUNT_ADMIN_LINKED_V01_CONFIG_SHEET = 'SystemConfig';

function runMcAccountAdminLinkedV01Smoke() {
  var result = {
    ok: false,
    build: MC_ACCOUNT_ADMIN_LINKED_V01_BUILD,
    action: 'runMcAccountAdminLinkedV01Smoke',
    generatedAt: mcAccountAdminLinkedV01Now_(),
    message: '',
    checks: [],
    sourceSheets: {}
  };

  try {
    var ss = mcAccountAdminLinkedV01OpenMaster_().ss;
    mcAccountAdminLinkedV01EnsureSheets_(ss);

    var sources = mcAccountAdminLinkedV01FindSourceSheets_(ss);
    result.sourceSheets = sources;

    result.checks.push({ key: 'MasterConnected', ok: !!ss, message: 'FEELHAUS_DB_MASTER 연결 확인' });
    result.checks.push({ key: 'AccountsSheetReady', ok: !!ss.getSheetByName('MailCenter_Accounts'), message: 'MailCenter_Accounts 확인' });
    result.checks.push({ key: 'ApprovalLogsReady', ok: !!ss.getSheetByName('MailCenter_ApprovalLogs'), message: 'MailCenter_ApprovalLogs 확인' });
    result.checks.push({ key: 'AuditLogsReady', ok: !!ss.getSheetByName('MailCenter_AuditLogs'), message: 'MailCenter_AuditLogs 확인' });
    result.checks.push({ key: 'StaffSourceChecked', ok: true, message: sources.staffSheet ? ('직원 원본 후보 확인: ' + sources.staffSheet) : '직원 원본 후보 없음. 수동 입력 금지, 조회 목록은 비어 있음' });
    result.checks.push({ key: 'VendorSourceChecked', ok: true, message: sources.vendorSheet ? ('업체 원본 후보 확인: ' + sources.vendorSheet) : '업체 원본 후보 없음. 수동 입력 금지, 조회 목록은 비어 있음' });
    result.checks.push({ key: 'OAuthUrlBuilderReady', ok: typeof mailCenterBuildOAuthConnectUrl === 'function', message: 'OAuth URL 생성 함수 확인' });
    result.checks.push({ key: 'SuspendReady', ok: typeof mcAccountAdminLinkedV01SuspendAccount === 'function', message: '계정 사용중지 함수 확인' });
    result.checks.push({ key: 'SetPrimaryReady', ok: typeof mcAccountAdminLinkedV01SetPrimaryAccount === 'function', message: '기본 발신계정 지정 함수 확인' });

    result.ok = result.checks.every(function(c) { return !!c.ok; });
    result.message = result.ok ? 'MailCenter Account Admin Linked V01 준비 완료' : 'MailCenter Account Admin Linked V01 점검 실패';
  } catch (err) {
    result.ok = false;
    result.message = String(err && err.message ? err.message : err);
  }

  mcAccountAdminLinkedV01Log_(result);
  return result;
}

function mcAccountAdminLinkedV01GetAdminData() {
  var result = {
    ok: false,
    build: MC_ACCOUNT_ADMIN_LINKED_V01_BUILD,
    action: 'mcAccountAdminLinkedV01GetAdminData',
    generatedAt: mcAccountAdminLinkedV01Now_(),
    summary: {
      totalAccounts: 0,
      activeAccounts: 0,
      pendingApproval: 0,
      connectedAccounts: 0,
      staffSourceCount: 0,
      vendorSourceCount: 0
    },
    accounts: [],
    staffOwners: [],
    vendorOwners: [],
    sourceSheets: {},
    message: ''
  };

  try {
    var ss = mcAccountAdminLinkedV01OpenMaster_().ss;
    mcAccountAdminLinkedV01EnsureSheets_(ss);

    var sourceSheets = mcAccountAdminLinkedV01FindSourceSheets_(ss);
    var staffOwners = mcAccountAdminLinkedV01ReadStaffOwners_(ss, sourceSheets.staffSheet);
    var vendorOwners = mcAccountAdminLinkedV01ReadVendorOwners_(ss, sourceSheets.vendorSheet);
    var localAccounts = mcAccountAdminLinkedV01ReadAccounts_(ss);
    var portalAccounts = mcAccountAdminLinkedV01ReadPortalAccountsV02_(ss);
    var oauthMap = mcAccountAdminLinkedV01ReadOAuthMap_(ss);
    var tokenMap = mcAccountAdminLinkedV01ReadPortalTokenMapV02_(ss);

    var accounts = mcAccountAdminLinkedV01MergeAccountsV02_(localAccounts, portalAccounts, oauthMap, tokenMap);

    result.sourceSheets = sourceSheets;
    result.staffOwners = staffOwners;
    result.vendorOwners = vendorOwners;
    result.accounts = accounts;
    result.summary.totalAccounts = accounts.length;
    result.summary.activeAccounts = accounts.filter(function(a) { return String(a.mailAccountStatus || a.status || '').toUpperCase() === 'ACTIVE'; }).length;
    result.summary.pendingApproval = accounts.filter(function(a) {
      var s = String(a.approvalStatus || '').toUpperCase();
      var m = String(a.mailAccountStatus || '').toUpperCase();
      return s === 'PENDING' || s === 'REQUESTED' || m === 'APPROVAL_REQUESTED' || m === 'PENDING_AUTH';
    }).length;
    result.summary.connectedAccounts = accounts.filter(function(a) { return String(a.oauthStatus || '').toUpperCase() === 'CONNECTED'; }).length;
    result.summary.staffSourceCount = staffOwners.length;
    result.summary.vendorSourceCount = vendorOwners.length;

    result.ok = true;
    result.message = '계정 등록/승인 데이터 조회 완료. MailCenter_Accounts + PORTAL_MailAccounts + PORTAL_MailTokenIndex 병합 기준입니다.';
    result.payloadFixBuild = 'PORTAL_MAIL_ACCOUNT_ADMIN_PAYLOAD_FIX_V01_20260531';
  } catch (err) {
    result.ok = false;
    result.message = String(err && err.message ? err.message : err);
  }

  return result;
}

function mcAccountAdminLinkedV01ReadPortalAccountsV02_(ss) {
  var sh = ss.getSheetByName('PORTAL_MailAccounts');
  if (!sh) return [];
  var values = sh.getDataRange().getValues();
  if (!values || values.length < 2) return [];
  var hm = mcAccountAdminLinkedV01HeaderMap_(values[0]);
  var rows = [];
  for (var r = 1; r < values.length; r++) {
    var obj = mcAccountAdminLinkedV01RowObject_(values[r], hm);
    if (!obj.mailAccountId && !obj.emailAddress) continue;
    obj.__source = 'PORTAL_MailAccounts';
    rows.push(obj);
  }
  return rows;
}

function mcAccountAdminLinkedV01ReadPortalTokenMapV02_(ss) {
  var sh = ss.getSheetByName('PORTAL_MailTokenIndex');
  var map = {};
  if (!sh) return map;
  var values = sh.getDataRange().getValues();
  if (!values || values.length < 2) return map;
  var hm = mcAccountAdminLinkedV01HeaderMap_(values[0]);
  for (var r = 1; r < values.length; r++) {
    var obj = mcAccountAdminLinkedV01RowObject_(values[r], hm);
    var id = String(obj.mailAccountId || '').trim();
    if (!id) continue;
    map[id] = obj;
  }
  return map;
}

function mcAccountAdminLinkedV01MergeAccountsV02_(localAccounts, portalAccounts, oauthMap, tokenMap) {
  var out = [];
  var byId = {};
  var byEmail = {};

  function put_(row, source) {
    if (!row) return;
    var normalized = mcAccountAdminLinkedV01NormalizeAccountForViewV02_(row, source, oauthMap, tokenMap);
    var id = String(normalized.mailAccountId || '').trim();
    var email = String(normalized.emailAddress || '').trim().toLowerCase();
    if (!id && !email) return;

    var existing = id && byId[id] ? byId[id] : (email && byEmail[email] ? byEmail[email] : null);
    if (existing) {
      Object.keys(normalized).forEach(function(k) {
        if (normalized[k] !== '' && normalized[k] != null) existing[k] = normalized[k];
      });
      if (id) byId[id] = existing;
      if (email) byEmail[email] = existing;
    } else {
      out.push(normalized);
      if (id) byId[id] = normalized;
      if (email) byEmail[email] = normalized;
    }
  }

  (localAccounts || []).forEach(function(a) { put_(a, 'MailCenter_Accounts'); });
  (portalAccounts || []).forEach(function(a) { put_(a, 'PORTAL_MailAccounts'); });

  out.sort(function(a, b) {
    var ap = String(a.isPrimary || '').toUpperCase() === 'TRUE' ? 0 : 1;
    var bp = String(b.isPrimary || '').toUpperCase() === 'TRUE' ? 0 : 1;
    if (ap !== bp) return ap - bp;
    var ao = String(a.ownerType || '');
    var bo = String(b.ownerType || '');
    if (ao !== bo) return ao.localeCompare(bo);
    return String(a.emailAddress || '').localeCompare(String(b.emailAddress || ''));
  });
  return out;
}

function mcAccountAdminLinkedV01NormalizeAccountForViewV02_(row, source, oauthMap, tokenMap) {
  var mailAccountId = String(row.mailAccountId || row.accountId || '').trim();
  var email = String(row.emailAddress || row.email || '').trim();
  var lowerEmail = email.toLowerCase();
  var oauth = (oauthMap && (oauthMap[mailAccountId] || oauthMap[email] || oauthMap[lowerEmail])) || {};
  var token = (tokenMap && tokenMap[mailAccountId]) || {};

  var ownerType = String(row.ownerType || row.accountType || '').trim().toUpperCase();
  if (!ownerType) ownerType = source === 'PORTAL_MailAccounts' ? 'HQ' : '';
  var purpose = String(row.accountPurpose || row.purpose || row.scope || '').trim().toUpperCase();
  if (!purpose) {
    if (ownerType === 'HQ' || ownerType === 'HQ_OFFICIAL') purpose = 'HQ_OFFICIAL';
    else if (ownerType === 'HQ_STAFF') purpose = 'HQ_STAFF';
    else if (ownerType === 'VENDOR') purpose = 'VENDOR_OFFICIAL';
  }

  var authStatus = String(row.authStatus || oauth.oauthStatus || '').trim().toUpperCase();
  var tokenStatus = String(token.tokenStatus || '').trim().toUpperCase();
  var hasRefresh = String(token.hasRefreshToken || '').trim().toUpperCase();
  var oauthStatus = String(oauth.oauthStatus || authStatus || '').trim().toUpperCase();
  if (!oauthStatus && (tokenStatus === 'ACTIVE' || hasRefresh === 'Y' || hasRefresh === 'TRUE')) oauthStatus = 'CONNECTED';
  if (!oauthStatus && authStatus === 'CONNECTED') oauthStatus = 'CONNECTED';
  if (!oauthStatus && authStatus === 'PENDING_AUTH') oauthStatus = 'PENDING_AUTH';

  var status = String(row.mailAccountStatus || row.status || '').trim().toUpperCase();
  if (!status) status = String(row.authStatus || '').toUpperCase() === 'PENDING_AUTH' ? 'APPROVAL_REQUESTED' : 'ACTIVE';
  if (status === 'CONNECTED') status = 'ACTIVE';

  var approval = String(row.approvalStatus || '').trim().toUpperCase();
  if (!approval) approval = (status === 'APPROVAL_REQUESTED' || status === 'PENDING_AUTH') ? 'PENDING' : 'APPROVED';

  var connectorId = String(row.connectorMailAccountId || oauth.connectorMailAccountId || '').trim();
  if (!connectorId && source === 'PORTAL_MailAccounts') connectorId = mailAccountId;

  return {
    mailAccountId: mailAccountId,
    vendorId: String(row.vendorId || '').trim(),
    eventId: String(row.eventId || '').trim(),
    ownerType: ownerType,
    ownerName: String(row.ownerName || row.displayName || row.ownerId || '').trim(),
    ownerUserId: String(row.ownerUserId || row.userId || '').trim(),
    ownerEmployeeId: String(row.ownerEmployeeId || row.employeeId || '').trim(),
    emailAddress: email,
    provider: String(row.provider || 'Gmail').trim(),
    mailAccountStatus: status,
    statusReason: String(row.statusReason || row.lastError || '').trim(),
    approvalStatus: approval,
    requestedBy: String(row.requestedBy || '').trim(),
    requestedAt: String(row.requestedAt || '').trim(),
    approvedBy: String(row.approvedBy || '').trim(),
    approvedAt: String(row.approvedAt || '').trim(),
    lastConnectedAt: String(row.lastConnectedAt || oauth.lastConnectedAt || row.updatedAt || token.updatedAt || '').trim(),
    lastSyncAt: String(row.lastSyncAt || row.lastCheckedAt || oauth.lastCheckedAt || '').trim(),
    createdAt: String(row.createdAt || '').trim(),
    createdBy: String(row.createdBy || '').trim(),
    updatedAt: String(row.updatedAt || token.updatedAt || '').trim(),
    updatedBy: String(row.updatedBy || '').trim(),
    accountPurpose: purpose,
    isPrimary: String(row.isPrimary || '').trim().toUpperCase() === 'TRUE' ? 'TRUE' : 'FALSE',
    displayName: String(row.displayName || row.ownerName || email).trim(),
    roleMemo: String(row.roleMemo || '').trim(),
    oauthStatus: oauthStatus,
    connectorMailAccountId: connectorId,
    tokenStatus: tokenStatus,
    hasRefreshToken: String(token.hasRefreshToken || '').trim(),
    scopeLevel: String(row.scopeLevel || token.scope || '').trim(),
    __source: source
  };
}


/**
 * 원본 연결형 등록.
 * - ownerType=HQ_STAFF 인 경우 ownerEmployeeId 또는 ownerUserId가 필요하다.
 * - ownerType=VENDOR 인 경우 vendorId가 필요하다.
 * - HQ_OFFICIAL은 본사 공식 계정으로 ownerName은 HQ로 고정 가능.
 */
function mcAccountAdminLinkedV01RegisterAccount(payload) {
  var result = {
    ok: false,
    build: MC_ACCOUNT_ADMIN_LINKED_V01_BUILD,
    action: 'mcAccountAdminLinkedV01RegisterAccount',
    generatedAt: mcAccountAdminLinkedV01Now_(),
    message: '',
    account: null
  };

  try {
    var p = payload || {};
    var ownerType = mcAccountAdminLinkedV01Require_(p.ownerType, 'ownerType');
    var accountPurpose = mcAccountAdminLinkedV01Require_(p.accountPurpose, 'accountPurpose');
    var emailAddress = mcAccountAdminLinkedV01Require_(p.emailAddress, 'emailAddress');

    var ss = mcAccountAdminLinkedV01OpenMaster_().ss;
    mcAccountAdminLinkedV01EnsureSheets_(ss);
    var data = mcAccountAdminLinkedV01GetAdminData();
    var owner = null;

    if (ownerType === 'HQ_STAFF') {
      owner = mcAccountAdminLinkedV01FindStaffOwner_(data.staffOwners, p.ownerEmployeeId, p.ownerUserId);
      if (!owner) {
        throw new Error('본사 직원메일은 직원관리 원본에서 직원을 선택해야 합니다.');
      }
      p.ownerName = owner.ownerName;
      p.ownerEmployeeId = owner.ownerEmployeeId;
      p.ownerUserId = owner.ownerUserId;
      p.vendorId = owner.vendorId || '';
    } else if (ownerType === 'VENDOR') {
      owner = mcAccountAdminLinkedV01FindVendorOwner_(data.vendorOwners, p.vendorId);
      if (!owner) {
        throw new Error('업체 대표메일은 업체 원본에서 업체를 선택해야 합니다.');
      }
      p.ownerName = owner.ownerName;
      p.vendorId = owner.vendorId;
      p.ownerEmployeeId = '';
      p.ownerUserId = '';
    } else if (ownerType === 'HQ') {
      p.ownerName = p.ownerName || '(주)필하우스 본사';
      p.vendorId = '';
      p.ownerEmployeeId = '';
      p.ownerUserId = '';
    } else {
      throw new Error('허용되지 않은 ownerType입니다: ' + ownerType);
    }

    var actor = mcAccountAdminLinkedV01User_();
    var now = mcAccountAdminLinkedV01Now_();
    var account = mcAccountAdminLinkedV01UpsertAccount_(ss, {
      mailAccountId: '',
      vendorId: p.vendorId || '',
      eventId: '',
      ownerType: ownerType,
      ownerName: p.ownerName,
      ownerUserId: p.ownerUserId || '',
      ownerEmployeeId: p.ownerEmployeeId || '',
      emailAddress: emailAddress,
      provider: p.provider || 'Gmail',
      mailAccountStatus: 'APPROVAL_REQUESTED',
      statusReason: '원본 연결형 계정 등록/승인 요청',
      approvalStatus: 'PENDING',
      requestedBy: actor,
      requestedAt: now,
      approvedBy: '',
      approvedAt: '',
      accountPurpose: accountPurpose,
      isPrimary: String(p.isPrimary || 'FALSE').toUpperCase(),
      displayName: p.displayName || p.ownerName,
      roleMemo: p.roleMemo || '',
      actor: actor
    });

    mcAccountAdminLinkedV01AppendApprovalLog_(ss, {
      mailAccountId: account.mailAccountId,
      vendorId: account.vendorId || '',
      emailAddress: account.emailAddress || '',
      approvalAction: 'REQUEST',
      approvalStatus: 'PENDING',
      statusReason: '원본 연결형 계정 등록/승인 요청',
      actor: actor
    });

    mcAccountAdminLinkedV01AppendAudit_(ss, {
      targetType: 'MailCenter_Accounts',
      targetId: account.mailAccountId,
      vendorId: account.vendorId || '',
      actionType: 'MAIL_ACCOUNT_REGISTER_LINKED_OWNER',
      beforeValue: '',
      afterValue: JSON.stringify(account),
      reason: '직원/업체 원본 연결형 메일계정 등록',
      createdBy: actor
    });

    result.account = account;
    result.ok = true;
    result.message = '메일 계정 등록/승인 요청 완료';
  } catch (err) {
    result.ok = false;
    result.message = String(err && err.message ? err.message : err);
  }

  mcAccountAdminLinkedV01Log_(result);
  return result;
}

function mcAccountAdminLinkedV01ApproveAccount(payload) {
  var p = payload || {};
  return mcAccountAdminLinkedV01ChangeApproval_(p.mailAccountId, 'APPROVE', 'APPROVED', 'ACTIVE', p.reason || '본사 승인');
}

function mcAccountAdminLinkedV01RejectAccount(payload) {
  var p = payload || {};
  return mcAccountAdminLinkedV01ChangeApproval_(p.mailAccountId, 'REJECT', 'REJECTED', 'REJECTED', p.reason || '본사 반려');
}

function mcAccountAdminLinkedV01SuspendAccount(payload) {
  var p = payload || {};
  return mcAccountAdminLinkedV01ChangeApproval_(p.mailAccountId, 'SUSPEND', 'SUSPENDED', 'SUSPENDED', p.reason || '사용 중지');
}

function mcAccountAdminLinkedV01SetPrimaryAccount(payload) {
  var result = {
    ok: false,
    build: MC_ACCOUNT_ADMIN_LINKED_V01_BUILD,
    action: 'mcAccountAdminLinkedV01SetPrimaryAccount',
    generatedAt: mcAccountAdminLinkedV01Now_(),
    message: '',
    mailAccountId: (payload || {}).mailAccountId || '',
    account: null
  };

  try {
    var p = payload || {};
    var mailAccountId = mcAccountAdminLinkedV01Require_(p.mailAccountId, 'mailAccountId');
    var reason = p.reason || '기본 발신계정 지정';
    var ss = mcAccountAdminLinkedV01OpenMaster_().ss;
    mcAccountAdminLinkedV01EnsureSheets_(ss);
    var sh = ss.getSheetByName('MailCenter_Accounts');
    var values = sh.getDataRange().getValues();
    if (!values || values.length < 2) throw new Error('MailCenter_Accounts 데이터가 없습니다.');
    var hm = mcAccountAdminLinkedV01HeaderMap_(values[0]);
    var targetRow = -1;
    var targetBefore = null;

    for (var r = 1; r < values.length; r++) {
      var rowId = String(mcAccountAdminLinkedV01Cell_(values[r], hm, 'mailAccountId') || '').trim();
      if (rowId === String(mailAccountId)) {
        targetRow = r + 1;
        targetBefore = mcAccountAdminLinkedV01RowObject_(values[r], hm);
        break;
      }
    }
    if (targetRow < 0) throw new Error('계정을 찾을 수 없습니다: ' + mailAccountId);

    var targetStatus = String(targetBefore.mailAccountStatus || '').toUpperCase();
    var targetApproval = String(targetBefore.approvalStatus || '').toUpperCase();
    if (targetStatus !== 'ACTIVE' || targetApproval !== 'APPROVED') {
      throw new Error('기본 발신계정은 승인 완료 ACTIVE 계정만 지정할 수 있습니다.');
    }

    var scopeOwnerType = String(targetBefore.ownerType || '').trim();
    var scopeVendorId = String(targetBefore.vendorId || '').trim();
    var actor = mcAccountAdminLinkedV01User_();
    var now = mcAccountAdminLinkedV01Now_();
    var changed = [];

    for (var i = 1; i < values.length; i++) {
      var rowObj = mcAccountAdminLinkedV01RowObject_(values[i], hm);
      if (!rowObj.emailAddress) continue;
      var sameScope = String(rowObj.ownerType || '').trim() === scopeOwnerType;
      if (scopeOwnerType === 'VENDOR') sameScope = sameScope && String(rowObj.vendorId || '').trim() === scopeVendorId;
      if (!sameScope) continue;
      var rowNo = i + 1;
      var nextPrimary = String(rowObj.mailAccountId) === String(mailAccountId) ? 'TRUE' : 'FALSE';
      if (String(rowObj.isPrimary || '').toUpperCase() !== nextPrimary) {
        mcAccountAdminLinkedV01SetCell_(sh, hm, rowNo, 'isPrimary', nextPrimary);
        mcAccountAdminLinkedV01SetCell_(sh, hm, rowNo, 'updatedAt', now);
        mcAccountAdminLinkedV01SetCell_(sh, hm, rowNo, 'updatedBy', actor);
        changed.push(rowObj.mailAccountId || rowObj.emailAddress || rowNo);
      }
    }

    mcAccountAdminLinkedV01SetCell_(sh, hm, targetRow, 'statusReason', reason);
    mcAccountAdminLinkedV01SetCell_(sh, hm, targetRow, 'updatedAt', now);
    mcAccountAdminLinkedV01SetCell_(sh, hm, targetRow, 'updatedBy', actor);

    var afterValues = sh.getRange(targetRow, 1, 1, sh.getLastColumn()).getValues()[0];
    var afterObj = mcAccountAdminLinkedV01RowObject_(afterValues, mcAccountAdminLinkedV01HeaderMap_(sh.getRange(1, 1, 1, sh.getLastColumn()).getValues()[0]));

    mcAccountAdminLinkedV01AppendApprovalLog_(ss, {
      mailAccountId: mailAccountId,
      vendorId: afterObj.vendorId || '',
      emailAddress: afterObj.emailAddress || '',
      approvalAction: 'SET_PRIMARY',
      approvalStatus: afterObj.approvalStatus || '',
      statusReason: reason,
      actor: actor
    });

    mcAccountAdminLinkedV01AppendAudit_(ss, {
      targetType: 'MailCenter_Accounts',
      targetId: mailAccountId,
      vendorId: afterObj.vendorId || '',
      actionType: 'MAIL_ACCOUNT_SET_PRIMARY',
      beforeValue: JSON.stringify(targetBefore),
      afterValue: JSON.stringify({ account: afterObj, changedScopeAccounts: changed }),
      reason: reason,
      createdBy: actor
    });

    result.account = afterObj;
    result.ok = true;
    result.message = '기본 발신계정 지정 완료';
  } catch (err) {
    result.ok = false;
    result.message = String(err && err.message ? err.message : err);
  }

  mcAccountAdminLinkedV01Log_(result);
  return result;
}


function mcAccountAdminLinkedV01BuildOAuthUrl(payload) {
  var result = {
    ok: false,
    build: MC_ACCOUNT_ADMIN_LINKED_V01_BUILD,
    action: 'mcAccountAdminLinkedV01BuildOAuthUrl',
    generatedAt: mcAccountAdminLinkedV01Now_(),
    message: '',
    account: null,
    oauth: null
  };

  try {
    if (typeof mailCenterBuildOAuthConnectUrl !== 'function') throw new Error('mailCenterBuildOAuthConnectUrl 함수가 없습니다.');
    var mailAccountId = mcAccountAdminLinkedV01Require_((payload || {}).mailAccountId, 'mailAccountId');
    var ss = mcAccountAdminLinkedV01OpenMaster_().ss;
    var account = mcAccountAdminLinkedV01GetAccountById_(ss, mailAccountId);

    var oauth = mailCenterBuildOAuthConnectUrl('', {
      mailAccountId: account.mailAccountId,
      vendorId: account.vendorId || '',
      ownerType: account.ownerType || '',
      ownerName: account.ownerName || '',
      emailAddress: account.emailAddress || '',
      provider: account.provider || 'Gmail'
    });

    result.account = account;
    result.oauth = oauth;
    result.ok = !!(oauth && oauth.ok);
    result.message = result.ok ? 'OAuth 연결 URL 생성 완료' : ((oauth && oauth.message) ? oauth.message : 'OAuth URL 생성 실패');
  } catch (err) {
    result.ok = false;
    result.message = String(err && err.message ? err.message : err);
  }

  mcAccountAdminLinkedV01Log_(result);
  return result;
}

function mcAccountAdminLinkedV01ChangeApproval_(mailAccountId, action, approvalStatus, mailAccountStatus, reason) {
  var result = {
    ok: false,
    build: MC_ACCOUNT_ADMIN_LINKED_V01_BUILD,
    action: 'mcAccountAdminLinkedV01ChangeApproval',
    approvalAction: action,
    generatedAt: mcAccountAdminLinkedV01Now_(),
    message: '',
    mailAccountId: mailAccountId || '',
    account: null
  };

  try {
    mailAccountId = mcAccountAdminLinkedV01Require_(mailAccountId, 'mailAccountId');
    var ss = mcAccountAdminLinkedV01OpenMaster_().ss;
    var sh = ss.getSheetByName('MailCenter_Accounts');
    var values = sh.getDataRange().getValues();
    var hm = mcAccountAdminLinkedV01HeaderMap_(values[0]);
    var foundRow = -1;
    var beforeObj = null;

    for (var r = 1; r < values.length; r++) {
      if (String(mcAccountAdminLinkedV01Cell_(values[r], hm, 'mailAccountId')) === String(mailAccountId)) {
        foundRow = r + 1;
        beforeObj = mcAccountAdminLinkedV01RowObject_(values[r], hm);
        break;
      }
    }
    if (foundRow < 0) throw new Error('계정을 찾을 수 없습니다: ' + mailAccountId);

    var actor = mcAccountAdminLinkedV01User_();
    var now = mcAccountAdminLinkedV01Now_();
    mcAccountAdminLinkedV01SetCell_(sh, hm, foundRow, 'approvalStatus', approvalStatus);
    mcAccountAdminLinkedV01SetCell_(sh, hm, foundRow, 'mailAccountStatus', mailAccountStatus);
    mcAccountAdminLinkedV01SetCell_(sh, hm, foundRow, 'statusReason', reason);
    mcAccountAdminLinkedV01SetCell_(sh, hm, foundRow, 'updatedAt', now);
    mcAccountAdminLinkedV01SetCell_(sh, hm, foundRow, 'updatedBy', actor);

    if (approvalStatus === 'APPROVED') {
      mcAccountAdminLinkedV01SetCell_(sh, hm, foundRow, 'approvedAt', now);
      mcAccountAdminLinkedV01SetCell_(sh, hm, foundRow, 'approvedBy', actor);
    }

    var afterValues = sh.getRange(foundRow, 1, 1, sh.getLastColumn()).getValues()[0];
    var afterObj = mcAccountAdminLinkedV01RowObject_(afterValues, mcAccountAdminLinkedV01HeaderMap_(sh.getRange(1, 1, 1, sh.getLastColumn()).getValues()[0]));

    mcAccountAdminLinkedV01AppendApprovalLog_(ss, {
      mailAccountId: mailAccountId,
      vendorId: afterObj.vendorId || '',
      emailAddress: afterObj.emailAddress || '',
      approvalAction: action,
      approvalStatus: approvalStatus,
      statusReason: reason,
      actor: actor
    });

    mcAccountAdminLinkedV01AppendAudit_(ss, {
      targetType: 'MailCenter_Accounts',
      targetId: mailAccountId,
      vendorId: afterObj.vendorId || '',
      actionType: 'MAIL_ACCOUNT_' + action,
      beforeValue: JSON.stringify(beforeObj),
      afterValue: JSON.stringify(afterObj),
      reason: reason,
      createdBy: actor
    });

    result.account = afterObj;
    result.ok = true;
    result.message = '계정 ' + action + ' 처리 완료';
  } catch (err) {
    result.ok = false;
    result.message = String(err && err.message ? err.message : err);
  }

  mcAccountAdminLinkedV01Log_(result);
  return result;
}

function mcAccountAdminLinkedV01FindSourceSheets_(ss) {
  var staffCandidates = [
    'ERP_Employees', 'ERP_Staff', 'Employees', 'Staff',
    'PORTAL_Users', 'Portal_Users', 'Users', 'UserMaster',
    '직원관리', '직원', '사용자관리'
  ];
  var vendorCandidates = [
    'ERP_Vendors', 'ERP_VendorMaster', 'Vendors', 'VendorMaster',
    'ERP_업체관리', '업체관리', '업체', '협력업체'
  ];

  return {
    staffSheet: mcAccountAdminLinkedV01FirstExistingSheet_(ss, staffCandidates),
    vendorSheet: mcAccountAdminLinkedV01FirstExistingSheet_(ss, vendorCandidates)
  };
}

function mcAccountAdminLinkedV01FirstExistingSheet_(ss, names) {
  for (var i = 0; i < names.length; i++) {
    if (ss.getSheetByName(names[i])) return names[i];
  }
  return '';
}

function mcAccountAdminLinkedV01ReadStaffOwners_(ss, sheetName) {
  if (!sheetName) return [];
  var sh = ss.getSheetByName(sheetName);
  if (!sh) return [];
  var values = sh.getDataRange().getValues();
  if (!values || values.length < 2) return [];
  var hm = mcAccountAdminLinkedV01HeaderMap_(values[0]);
  var rows = [];

  for (var r = 1; r < values.length; r++) {
    var row = values[r];
    var ownerEmployeeId = mcAccountAdminLinkedV01PickCell_(row, hm, ['employeeId','staffId','empId','userId','id']);
    var ownerUserId = mcAccountAdminLinkedV01PickCell_(row, hm, ['userId','loginId','accountId','employeeId','staffId']);
    var ownerName = mcAccountAdminLinkedV01PickCell_(row, hm, ['staffName','employeeName','userName','name','ownerName','displayName']);
    var vendorId = mcAccountAdminLinkedV01PickCell_(row, hm, ['vendorId','branchVendorId']);
    var roleCode = mcAccountAdminLinkedV01PickCell_(row, hm, ['roleCode','role','permissionRole']);
    var status = mcAccountAdminLinkedV01PickCell_(row, hm, ['status','employeeStatus','userStatus']);
    var loginEmail = mcAccountAdminLinkedV01PickCell_(row, hm, ['loginEmail','email','emailAddress']);

    if (!ownerName && !ownerEmployeeId && !ownerUserId) continue;
    rows.push({
      ownerEmployeeId: String(ownerEmployeeId || ownerUserId || '').trim(),
      ownerUserId: String(ownerUserId || ownerEmployeeId || '').trim(),
      ownerName: String(ownerName || ownerUserId || ownerEmployeeId || '').trim(),
      vendorId: String(vendorId || '').trim(),
      roleCode: String(roleCode || '').trim(),
      status: String(status || '').trim(),
      loginEmail: String(loginEmail || '').trim()
    });
  }
  return rows;
}

function mcAccountAdminLinkedV01ReadVendorOwners_(ss, sheetName) {
  if (!sheetName) return [];
  var sh = ss.getSheetByName(sheetName);
  if (!sh) return [];
  var values = sh.getDataRange().getValues();
  if (!values || values.length < 2) return [];
  var hm = mcAccountAdminLinkedV01HeaderMap_(values[0]);
  var rows = [];

  for (var r = 1; r < values.length; r++) {
    var row = values[r];
    var vendorId = mcAccountAdminLinkedV01PickCell_(row, hm, ['vendorId','id','companyId']);
    var vendorName = mcAccountAdminLinkedV01PickCell_(row, hm, ['vendorName','companyName','branchName','name','ownerName']);
    var status = mcAccountAdminLinkedV01PickCell_(row, hm, ['status','vendorStatus']);
    var contactEmail = mcAccountAdminLinkedV01PickCell_(row, hm, ['email','emailAddress','contactEmail','managerEmail']);

    if (!vendorId && !vendorName) continue;
    rows.push({
      vendorId: String(vendorId || '').trim(),
      ownerName: String(vendorName || vendorId || '').trim(),
      status: String(status || '').trim(),
      contactEmail: String(contactEmail || '').trim()
    });
  }
  return rows;
}

function mcAccountAdminLinkedV01FindStaffOwner_(owners, employeeId, userId) {
  employeeId = String(employeeId || '').trim();
  userId = String(userId || '').trim();
  for (var i = 0; i < owners.length; i++) {
    if (employeeId && String(owners[i].ownerEmployeeId) === employeeId) return owners[i];
    if (userId && String(owners[i].ownerUserId) === userId) return owners[i];
  }
  return null;
}

function mcAccountAdminLinkedV01FindVendorOwner_(owners, vendorId) {
  vendorId = String(vendorId || '').trim();
  for (var i = 0; i < owners.length; i++) {
    if (String(owners[i].vendorId) === vendorId) return owners[i];
  }
  return null;
}

function mcAccountAdminLinkedV01ReadAccounts_(ss) {
  var sh = ss.getSheetByName('MailCenter_Accounts');
  if (!sh) return [];
  var values = sh.getDataRange().getValues();
  if (!values || values.length < 2) return [];
  var hm = mcAccountAdminLinkedV01HeaderMap_(values[0]);
  var rows = [];

  for (var r = 1; r < values.length; r++) {
    var obj = mcAccountAdminLinkedV01RowObject_(values[r], hm);
    if (!obj.emailAddress) continue;
    rows.push(obj);
  }
  return rows;
}

function mcAccountAdminLinkedV01ReadOAuthMap_(ss) {
  var sh = ss.getSheetByName('MailCenter_OAuthConnections');
  var map = {};
  if (!sh) return map;
  var values = sh.getDataRange().getValues();
  if (!values || values.length < 2) return map;
  var hm = mcAccountAdminLinkedV01HeaderMap_(values[0]);

  function score_(o) {
    var score = 0;
    if (!o) return score;
    if (String(o.oauthStatus || '').toUpperCase() === 'CONNECTED') score += 100;
    if (o.connectorMailAccountId) score += 10;
    if (o.lastConnectedAt) score += 5;
    return score;
  }
  function put_(key, obj) {
    if (!key) return;
    var k = String(key);
    if (!map[k] || score_(obj) >= score_(map[k])) map[k] = obj;
  }

  for (var r = 1; r < values.length; r++) {
    var obj = mcAccountAdminLinkedV01RowObject_(values[r], hm);
    put_(obj.mailAccountId, obj);
    put_(obj.emailAddress, obj);
    if (obj.emailAddress) put_(String(obj.emailAddress).toLowerCase(), obj);
  }
  return map;
}

function mcAccountAdminLinkedV01UpsertAccount_(ss, spec) {
  var sh = ss.getSheetByName('MailCenter_Accounts');
  var values = sh.getDataRange().getValues();
  var hm = mcAccountAdminLinkedV01HeaderMap_(values[0]);
  var email = String(spec.emailAddress || '').trim();
  var foundRow = -1;

  for (var r = 1; r < values.length; r++) {
    if (String(mcAccountAdminLinkedV01Cell_(values[r], hm, 'emailAddress') || '').toLowerCase() === email.toLowerCase()) {
      foundRow = r + 1;
      break;
    }
  }

  var now = mcAccountAdminLinkedV01Now_();
  var mailAccountId = spec.mailAccountId || '';
  if (!mailAccountId && foundRow > 0) mailAccountId = String(sh.getRange(foundRow, hm.mailAccountId + 1).getValue() || '').trim();
  if (!mailAccountId) mailAccountId = 'MAILACC-' + Utilities.formatDate(new Date(), Session.getScriptTimeZone() || 'Asia/Seoul', 'yyyyMMddHHmmss') + '-' + Math.floor(Math.random() * 9000 + 1000);

  var obj = {
    mailAccountId: mailAccountId,
    vendorId: spec.vendorId || '',
    eventId: spec.eventId || '',
    ownerType: spec.ownerType || '',
    ownerName: spec.ownerName || '',
    ownerUserId: spec.ownerUserId || '',
    ownerEmployeeId: spec.ownerEmployeeId || '',
    emailAddress: email,
    provider: spec.provider || 'Gmail',
    mailAccountStatus: spec.mailAccountStatus || 'APPROVAL_REQUESTED',
    statusReason: spec.statusReason || '',
    approvalStatus: spec.approvalStatus || 'PENDING',
    requestedBy: spec.requestedBy || '',
    requestedAt: spec.requestedAt || now,
    approvedBy: spec.approvedBy || '',
    approvedAt: spec.approvedAt || '',
    updatedAt: now,
    updatedBy: spec.actor || '',
    accountPurpose: spec.accountPurpose || '',
    isPrimary: spec.isPrimary || 'FALSE',
    displayName: spec.displayName || '',
    roleMemo: spec.roleMemo || ''
  };

  if (foundRow < 0) {
    obj.createdAt = now;
    obj.createdBy = spec.actor || '';
    var headers = sh.getRange(1, 1, 1, sh.getLastColumn()).getValues()[0].map(function(h) { return String(h || '').trim(); });
    sh.appendRow(headers.map(function(h) { return obj[h] !== undefined ? obj[h] : ''; }));
  } else {
    Object.keys(obj).forEach(function(k) { mcAccountAdminLinkedV01SetCell_(sh, hm, foundRow, k, obj[k]); });
  }

  return obj;
}

function mcAccountAdminLinkedV01EnsureSheets_(ss) {
  mcAccountAdminLinkedV01GetSheetOrCreate_(ss, 'MailCenter_Accounts', [
    'mailAccountId','vendorId','eventId','ownerType','ownerName','ownerUserId','ownerEmployeeId','emailAddress','provider',
    'mailAccountStatus','statusReason','approvalStatus','requestedBy','requestedAt',
    'approvedBy','approvedAt','lastConnectedAt','lastSyncAt','createdAt','createdBy',
    'updatedAt','updatedBy','accountPurpose','isPrimary','displayName','roleMemo'
  ]);

  mcAccountAdminLinkedV01GetSheetOrCreate_(ss, 'MailCenter_ApprovalLogs', [
    'mailApprovalLogId','mailAccountId','vendorId','emailAddress','approvalAction',
    'approvalStatus','statusReason','createdAt','createdBy'
  ]);

  mcAccountAdminLinkedV01GetSheetOrCreate_(ss, 'MailCenter_AuditLogs', [
    'mailAuditLogId','targetType','targetId','vendorId','eventId','actionType',
    'beforeValue','afterValue','reason','createdAt','createdBy'
  ]);
}

function mcAccountAdminLinkedV01GetSheetOrCreate_(ss, sheetName, headers) {
  var sh = ss.getSheetByName(sheetName);
  if (!sh) sh = ss.insertSheet(sheetName);
  var lastCol = sh.getLastColumn();
  if (lastCol < 1) {
    sh.getRange(1, 1, 1, headers.length).setValues([headers]);
    return sh;
  }
  var existing = sh.getRange(1, 1, 1, lastCol).getValues()[0].map(function(v) { return String(v || '').trim(); });
  var append = [];
  headers.forEach(function(h) { if (existing.indexOf(h) < 0) append.push(h); });
  if (append.length) sh.getRange(1, existing.length + 1, 1, append.length).setValues([append]);
  return sh;
}

function mcAccountAdminLinkedV01AppendApprovalLog_(ss, obj) {
  var sh = ss.getSheetByName('MailCenter_ApprovalLogs');
  var headers = sh.getRange(1, 1, 1, sh.getLastColumn()).getValues()[0].map(function(h) { return String(h || '').trim(); });
  var rowObj = {
    mailApprovalLogId: 'MCAPP-' + Utilities.formatDate(new Date(), Session.getScriptTimeZone() || 'Asia/Seoul', 'yyyyMMddHHmmss') + '-' + Math.floor(Math.random() * 9000 + 1000),
    mailAccountId: obj.mailAccountId || '',
    vendorId: obj.vendorId || '',
    emailAddress: obj.emailAddress || '',
    approvalAction: obj.approvalAction || '',
    approvalStatus: obj.approvalStatus || '',
    statusReason: obj.statusReason || '',
    createdAt: mcAccountAdminLinkedV01Now_(),
    createdBy: obj.actor || ''
  };
  sh.appendRow(headers.map(function(h) { return rowObj[h] !== undefined ? rowObj[h] : ''; }));
}

function mcAccountAdminLinkedV01AppendAudit_(ss, obj) {
  var sh = ss.getSheetByName('MailCenter_AuditLogs');
  var headers = sh.getRange(1, 1, 1, sh.getLastColumn()).getValues()[0].map(function(h) { return String(h || '').trim(); });
  var rowObj = {
    mailAuditLogId: 'MCAUD-' + Utilities.formatDate(new Date(), Session.getScriptTimeZone() || 'Asia/Seoul', 'yyyyMMddHHmmss') + '-' + Math.floor(Math.random() * 9000 + 1000),
    targetType: obj.targetType || '',
    targetId: obj.targetId || '',
    vendorId: obj.vendorId || '',
    eventId: obj.eventId || '',
    actionType: obj.actionType || '',
    beforeValue: obj.beforeValue || '',
    afterValue: obj.afterValue || '',
    reason: obj.reason || '',
    createdAt: mcAccountAdminLinkedV01Now_(),
    createdBy: obj.createdBy || ''
  };
  sh.appendRow(headers.map(function(h) { return rowObj[h] !== undefined ? rowObj[h] : ''; }));
}

function mcAccountAdminLinkedV01GetAccountById_(ss, mailAccountId) {
  var accounts = mcAccountAdminLinkedV01ReadAccounts_(ss);
  for (var i = 0; i < accounts.length; i++) {
    if (String(accounts[i].mailAccountId) === String(mailAccountId)) return accounts[i];
  }
  throw new Error('계정을 찾을 수 없습니다: ' + mailAccountId);
}

function mcAccountAdminLinkedV01OpenMaster_() {
  if (typeof portal19GetConfigBundle_ === 'function' && typeof portal19OpenMaster_ === 'function') {
    var bundle = portal19GetConfigBundle_();
    var ssByPortal = portal19OpenMaster_(bundle);
    if (ssByPortal) return { ss: ssByPortal, masterDbId: bundle.masterDbId || '' };
  }
  var setup = SpreadsheetApp.openById(MC_ACCOUNT_ADMIN_LINKED_V01_SETUP_DB_ID);
  var configSheet = setup.getSheetByName(MC_ACCOUNT_ADMIN_LINKED_V01_CONFIG_SHEET);
  if (!configSheet) throw new Error('SystemConfig 시트를 찾지 못했습니다.');
  var values = configSheet.getDataRange().getValues();
  if (!values || values.length < 2) throw new Error('SystemConfig 데이터가 비어 있습니다.');
  var hm = mcAccountAdminLinkedV01HeaderMap_(values[0]);
  var keyCol = mcAccountAdminLinkedV01FindHeader_(hm, ['CONFIG_KEY','configKey','KEY','key']);
  var valCol = mcAccountAdminLinkedV01FindHeader_(hm, ['VALUE','CONFIG_VALUE','configValue','value']);
  if (keyCol < 0 || valCol < 0) throw new Error('SystemConfig CONFIG_KEY/VALUE 헤더를 찾지 못했습니다.');
  var masterId = '';
  for (var r = 1; r < values.length; r++) {
    var key = String(values[r][keyCol] || '').trim();
    if (key === 'FEELHAUS_DB_MASTER' || key === 'FEELHAUS_DB_MASTER_ID' || key === 'MASTER_DB_ID') {
      masterId = String(values[r][valCol] || '').trim();
      break;
    }
  }
  if (!masterId) throw new Error('SystemConfig에서 FEELHAUS_DB_MASTER ID를 찾지 못했습니다.');
  return { ss: SpreadsheetApp.openById(masterId), masterDbId: masterId };
}

function mcAccountAdminLinkedV01HeaderMap_(header) {
  var hm = {};
  for (var i = 0; i < header.length; i++) {
    var raw = String(header[i] || '').trim();
    if (!raw) continue;
    hm[raw] = i;
    var norm = mcAccountAdminLinkedV01Normalize_(raw);
    if (hm[norm] == null) hm[norm] = i;
  }
  return hm;
}
function mcAccountAdminLinkedV01FindHeader_(hm, names) {
  for (var i = 0; i < names.length; i++) {
    if (hm[names[i]] != null) return hm[names[i]];
    var norm = mcAccountAdminLinkedV01Normalize_(names[i]);
    if (hm[norm] != null) return hm[norm];
  }
  return -1;
}
function mcAccountAdminLinkedV01Cell_(row, hm, key) {
  var idx = hm[key];
  if (idx == null) idx = hm[mcAccountAdminLinkedV01Normalize_(key)];
  if (idx == null) return '';
  return row[idx];
}
function mcAccountAdminLinkedV01PickCell_(row, hm, keys) {
  for (var i = 0; i < keys.length; i++) {
    var v = mcAccountAdminLinkedV01Cell_(row, hm, keys[i]);
    if (v !== '' && v != null) return v;
  }
  return '';
}
function mcAccountAdminLinkedV01SetCell_(sh, hm, row, key, value) {
  var idx = hm[key];
  if (idx == null) idx = hm[mcAccountAdminLinkedV01Normalize_(key)];
  if (idx == null) return;
  sh.getRange(row, idx + 1).setValue(value);
}
function mcAccountAdminLinkedV01RowObject_(row, hm) {
  var obj = {};
  Object.keys(hm).forEach(function(k) {
    if (k === mcAccountAdminLinkedV01Normalize_(k)) return;
    obj[k] = row[hm[k]];
  });
  return obj;
}
function mcAccountAdminLinkedV01Normalize_(v) {
  return String(v || '').trim().toUpperCase().replace(/[^A-Z0-9]/g, '');
}
function mcAccountAdminLinkedV01Require_(v, name) {
  var s = String(v || '').trim();
  if (!s) throw new Error(name + ' 값이 필요합니다.');
  return s;
}
function mcAccountAdminLinkedV01User_() {
  try { return Session.getActiveUser().getEmail() || ''; }
  catch (e) { return ''; }
}
function mcAccountAdminLinkedV01Now_() {
  return Utilities.formatDate(new Date(), Session.getScriptTimeZone() || 'Asia/Seoul', 'yyyy-MM-dd HH:mm:ss');
}
function mcAccountAdminLinkedV01Log_(obj) {
  try { Logger.log('JSON_COMPACT_RESULT: ' + JSON.stringify(obj)); }
  catch (e) { Logger.log(obj); }
}
