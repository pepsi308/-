/**
 * FEELHAUS Google Calendar Sync Patch 04
 * Build: MC_GOOGLE_CALENDAR_SYNC_PATCH_NOW_HELPER_V01_20260527
 *
 * 현재 해결할 오류:
 *   PREP_DRY_RUN / APPLY_DRY_RUN
 *   message: "mcCalendar19Now_ is not defined"
 *
 * 적용 방법:
 * 1. Apps Script에 새 파일을 만듭니다.
 *    파일명 예: MC_GoogleCalendarSync_Patch04
 * 2. 이 파일 전체를 붙여넣습니다.
 * 3. 저장합니다.
 * 4. mcGoogleCalendarSyncPatch04VerifyAndRunGateV01 실행
 */


/**
 * 누락된 시간 헬퍼 복구
 *
 * 기본 반환:
 *   yyyy-MM-dd HH:mm:ss
 *
 * 사용 예:
 *   mcCalendar19Now_()
 *   mcCalendar19Now_('yyyyMMddHHmmss')
 *   mcCalendar19Now_({ format: 'yyyy-MM-dd HH:mm:ss', timezone: 'Asia/Seoul' })
 */
function mcCalendar19Now_(formatOrOptions) {
  var timezone = 'Asia/Seoul';
  var format = 'yyyy-MM-dd HH:mm:ss';

  try {
    timezone = Session.getScriptTimeZone() || timezone;
  } catch (ignoreTz) {}

  if (typeof formatOrOptions === 'string' && formatOrOptions) {
    format = formatOrOptions;
  } else if (formatOrOptions && typeof formatOrOptions === 'object') {
    if (formatOrOptions.format) format = String(formatOrOptions.format);
    if (formatOrOptions.timezone) timezone = String(formatOrOptions.timezone);
    if (formatOrOptions.tz) timezone = String(formatOrOptions.tz);
  }

  try {
    return Utilities.formatDate(new Date(), timezone, format);
  } catch (err) {
    return new Date().toISOString();
  }
}


/**
 * 혹시 다른 이름으로 현재시각 헬퍼를 부르는 코드가 있을 경우 대비
 */
function mcCalendar19Timestamp_() {
  return mcCalendar19Now_('yyyyMMddHHmmss');
}

function mcCalendar19IsoNow_() {
  return new Date().toISOString();
}


/**
 * 패치 04 검증
 */
function mcGoogleCalendarSyncPatch04VerifyV01() {
  var result = {
    ok: true,
    build: 'MC_GOOGLE_CALENDAR_SYNC_PATCH04_VERIFY_V01_20260527',
    action: 'mcGoogleCalendarSyncPatch04VerifyV01',
    checks: {},
    generatedAt: Utilities.formatDate(
      new Date(),
      Session.getScriptTimeZone() || 'Asia/Seoul',
      'yyyy-MM-dd HH:mm:ss'
    )
  };

  try {
    result.checks.nowExists = {
      ok: typeof mcCalendar19Now_ === 'function',
      type: typeof mcCalendar19Now_
    };
    if (!result.checks.nowExists.ok) result.ok = false;
  } catch (errExists) {
    result.ok = false;
    result.checks.nowExists = {
      ok: false,
      error: String(errExists && errExists.message ? errExists.message : errExists)
    };
  }

  try {
    var nowDefault = mcCalendar19Now_();
    var nowCompact = mcCalendar19Now_('yyyyMMddHHmmss');

    result.checks.nowWorks = {
      ok: !!nowDefault && !!nowCompact,
      nowDefault: nowDefault,
      nowCompact: nowCompact
    };

    if (!result.checks.nowWorks.ok) result.ok = false;
  } catch (errWorks) {
    result.ok = false;
    result.checks.nowWorks = {
      ok: false,
      error: String(errWorks && errWorks.message ? errWorks.message : errWorks)
    };
  }

  Logger.log('JSON_COMPACT_RESULT: ' + JSON.stringify(result));
  return result;
}


/**
 * 패치 04 검증 후 테스트 게이트 실행
 */
function mcGoogleCalendarSyncPatch04VerifyAndRunGateV01() {
  var verifyResult = mcGoogleCalendarSyncPatch04VerifyV01();

  var gateResult = null;
  var gateError = '';

  try {
    gateResult = mcGoogleCalendarSyncTestGateV03All();
  } catch (errGate) {
    gateError = String(errGate && errGate.message ? errGate.message : errGate);
  }

  var result = {
    ok: !!verifyResult.ok && !!gateResult && !!gateResult.ok,
    build: 'MC_GOOGLE_CALENDAR_SYNC_PATCH04_VERIFY_AND_RUN_GATE_V01_20260527',
    action: 'mcGoogleCalendarSyncPatch04VerifyAndRunGateV01',
    verifyResult: verifyResult,
    gateResult: gateResult,
    gateError: gateError,
    generatedAt: Utilities.formatDate(
      new Date(),
      Session.getScriptTimeZone() || 'Asia/Seoul',
      'yyyy-MM-dd HH:mm:ss'
    )
  };

  Logger.log('JSON_COMPACT_RESULT: ' + JSON.stringify(result));
  return result;
}
