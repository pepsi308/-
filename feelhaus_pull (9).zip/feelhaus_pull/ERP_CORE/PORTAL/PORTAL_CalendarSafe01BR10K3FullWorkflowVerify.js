/**
 * FEELHAUS PORTAL / Calendar SAFE-01B R10K3 Full Workflow Detail Verify
 * Build: PORTAL_CALENDAR_SAFE01B_R10K3_FULL_WORKFLOW_DETAIL_20260604
 * Safety: READ_ONLY_RUNTIME_VERIFY_NO_SHEET_PROVIDER_WRITE
 * Purpose:
 *  - Verify the calendar modal is no longer simplified around event management only.
 *  - Verify selection process, event management and general schedule workflows are all visible.
 *  - Verify presentation/agreement/event-master information is preserved in first detail page and edit modal.
 */
var PORTAL_CALENDAR_SAFE01B_R10K3_FULL_WORKFLOW_BUILD = 'PORTAL_CALENDAR_SAFE01B_R10K3_FULL_WORKFLOW_DETAIL_20260604';

function portalCalendarSafe01BR10K3FullWorkflowDetailVerify() {
  return portalCalendarSafe01BR10K3FullWorkflowVerify();
}

function portalCalendarSafe01BR10K3WorkflowVerify() {
  return portalCalendarSafe01BR10K3FullWorkflowVerify();
}

function portalCalendarSafe01BR10K3FullWorkflowVerify() {
  var BUILD = PORTAL_CALENDAR_SAFE01B_R10K3_FULL_WORKFLOW_BUILD;
  var BASE_BUILD = 'PORTAL_CALENDAR_SAFE01B_R11_PAGE_AUTO_REFRESH_REENTRY_20260604';
  var ACTION = 'portalCalendarSafe01BR10K3FullWorkflowVerify';
  var html = '';
  var readError = '';

  try {
    html = HtmlService.createTemplateFromFile('MC_CalendarViewV01').getRawContent();
  } catch (e1) {
    try {
      html = HtmlService.createHtmlOutputFromFile('MC_CalendarViewV01').getContent();
    } catch (e2) {
      readError = String(e2 && e2.message ? e2.message : e2);
      html = '';
    }
  }

  function has(s) { return String(html || '').indexOf(s) !== -1; }
  function notHas(s) { return !has(s); }
  function re(r) { return r.test(String(html || '')); }
  function all(arr) { for (var i = 0; i < arr.length; i++) if (!has(arr[i])) return false; return true; }
  function lineNumberAt(text, index) { if (index < 0) return -1; return String(text || '').substring(0, index).split('\n').length; }
  function contextAt(text, index, needle) {
    if (index < 0) return '';
    var size = 220;
    var end = index + String(needle || '').length;
    return String(text || '').substring(Math.max(0, index - size), Math.min(String(text || '').length, end + size));
  }
  function matchInfo(needle) {
    var idx = String(html || '').indexOf(needle);
    return { found: idx !== -1, needle: idx !== -1 ? needle : '', matchIndex: idx, lineNumber: lineNumberAt(html, idx), context: contextAt(html, idx, needle) };
  }

  var selectionStages = ['사전영업','입예협 접촉','제안/프레젠테이션','조건협의','경쟁검토','선정대기','협약식','행사관리 전환'];
  var eventStages = ['행사등록','담당자배정','일정/장소확정','카테고리구성','업체배정','홍보준비','현장준비','행사운영','판매집계','계약관리','설치/A/S','정산','마감/리포트'];
  var generalStages = ['내부회의','외부미팅','개발작업','전자결재','보고','휴무','기타'];

  var checks = {
    viewReadable: !!html && !readError,
    r10k3BuildMarkerPresent: has(BUILD) && has('__MC_CALENDAR_R10K3_FULL_WORKFLOW_BUILD__'),
    r11AutoRefreshKept: has('fhCalendarStartAutoRefreshR11') && has('setInterval(fhCalendarCheckPageRefreshR11,30000)') && has('R11_PAGE_AUTO_REFRESH'),
    r10k2EventMasterKept: has('행사관리 원장 연결 / 담당·참여자 정보') && has('me_eventMasterPicker') && has('ERP_행사관리 원장에서 행사 선택') && has('eventId 기준'),
    noSimpleModeNotice: has('심플모드가 아니라') && has('전체 흐름을 모두 열어둡니다'),
    manualWorkflowGuideReady: has('data-r10k3-workflow-guide="1"') && has('업무 흐름 전체 선택') && has('아래 항목은 숨기지 않습니다'),
    manualWorkflowPickerFunctionReady: has('function fhCalendarR10K3PickWorkType') && has('setManualValue(\'me_calendarBusinessType\'') && has('setManualValue(\'me_businessStage\''),
    threeBusinessTypesVisible: has('SELECTION_PROCESS') && has('EVENT_MANAGEMENT') && has('GENERAL_SCHEDULE') && has('박람회 선정 과정') && has('행사관리') && has('일반/기타 일정'),
    selectionStagesVisible: all(selectionStages),
    eventStagesVisible: all(eventStages),
    generalStagesVisible: all(generalStages),
    selectionStagebarRestored: has("['사전영업','입예협 접촉','제안준비','제안/프레젠테이션','조건협의','경쟁검토','선정대기','협약식','행사관리 전환']"),
    eventStagebarExpanded: has("['행사등록','담당자배정','일정/장소확정','카테고리구성','업체배정','홍보준비','현장준비','행사운영','판매집계','계약관리','설치/A/S','정산','마감/리포트']"),
    detailWorkflowGuideReady: has('function fhCalendarR10K3WorkflowGuideHtml') && has('업무 흐름 전체보기') && has('fhCalendarR10K3WorkflowGuideHtml(type,stage)'),
    firstPageWorkflowKept: has('오늘 업무 브리핑') && has('fhCalendarDetailFaceR10K') && has('fhCalendarR10K3WorkflowGuideHtml(type,stage)'),
    businessSectionWorkflowKept: has('function fhCalendarBusinessModalHtmlR10F') && has('fhCalendarR10K3WorkflowGuideHtml(type,stage);'),
    selectionPresentationAgreementDetailReady: has('선정 과정 상세 / 프레젠테이션 / 협약식') && has('presentationEnabled') && has('presentationMainSpeaker') && has('agreementRequired') && has('agreementStatus'),
    selectionEventConversionReady: has('행사관리 전환') && has('선정 확정 후 ERP_행사관리 eventId 연결'),
    eventManagementStillReadonlyLedger: has('ERP_행사관리 조회형') && has('원본 수정은 ERP 행사관리에서 처리') && has('행사명은 표시용이며 실제 연결·저장은 eventId 기준입니다'),
    legacyLabelRemovedFromUi: notHas('일반 담당자명(레거시)') && notHas('일반 담당자 ID(레거시)') && notHas('일반 담당 부서(레거시)') && notHas('일반 주관 역할(레거시)'),
    providerWriteNotAddedInR10K3: !has('CalendarApp.') && !has('UrlFetchApp.fetch') && !has('appendRow(') && !has('.setValue('),
    noSheetProviderWriteInVerify: true
  };

  var fatal = [];
  Object.keys(checks).forEach(function(k) { if (!checks[k]) fatal.push(k); });
  if (readError) fatal.push('viewHtmlReadError');

  var diagnostics = {
    htmlLength: html.length,
    readError: readError,
    buildMarker: matchInfo(BUILD),
    manualWorkflowGuide: matchInfo('업무 흐름 전체 선택'),
    workflowGuideFunction: matchInfo('function fhCalendarR10K3WorkflowGuideHtml'),
    selectionDetailSection: matchInfo('선정 과정 상세 / 프레젠테이션 / 협약식'),
    eventMasterPicker: matchInfo('me_eventMasterPicker'),
    r11Refresh: matchInfo('fhCalendarStartAutoRefreshR11'),
    selectionStages: selectionStages,
    eventStages: eventStages,
    generalStages: generalStages
  };

  var result = {
    ok: fatal.length === 0,
    build: BUILD,
    baseBuild: BASE_BUILD,
    action: ACTION,
    safety: 'READ_ONLY_RUNTIME_VERIFY_NO_SHEET_PROVIDER_WRITE',
    checks: checks,
    diagnostics: diagnostics,
    warnings: [],
    fatal: fatal,
    summary: {
      mode: 'Full workflow detail restore after R11: no simple mode',
      selectionProcess: '사전영업/입예협/프레젠테이션/조건협의/경쟁검토/선정대기/협약식/행사관리 전환 표시',
      eventManagement: 'ERP_행사관리 eventId 원장 연결 유지 + 행사 운영 단계 확장 표시',
      generalSchedule: '내부회의/외부미팅/개발/전자결재/보고/휴무/기타 표시',
      firstPage: '모달 첫 페이지도 같은 업무 흐름 기준으로 표시',
      providerPolicy: 'No Google/NAVER/ICS/provider write logic added by this verify build'
    },
    message: fatal.length === 0
      ? 'SAFE-01B R10K3 full workflow detail verification passed.'
      : 'SAFE-01B R10K3 full workflow detail verification failed. Check fatal items and diagnostics.'
  };

  try { Logger.log('JSON_COMPACT_RESULT: ' + JSON.stringify(result)); } catch (ignore) {}
  return result;
}
