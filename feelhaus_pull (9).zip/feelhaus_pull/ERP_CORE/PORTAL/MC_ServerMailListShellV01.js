/**
 * FEELHAUS MailCenter Server Mail List Shell V01
 * Build: MAILCENTER_SERVER_MAIL_LIST_FAST_LINK_V01_20260521
 */

var MC_SERVER_MAIL_LIST_SHELL_V01_BUILD = 'MAILCENTER_SERVER_MAIL_LIST_FAST_LINK_V01_20260521';

function runMcServerMailListShellV01() {
  var result = {
    ok: false,
    build: MC_SERVER_MAIL_LIST_SHELL_V01_BUILD,
    action: 'runMcServerMailListShellV01',
    generatedAt: Utilities.formatDate(new Date(), Session.getScriptTimeZone() || 'Asia/Seoul', 'yyyy-MM-dd HH:mm:ss'),
    message: '',
    checks: []
  };

  try {
    result.checks.push({ key: 'CoreReady', ok: typeof mcServerMailListV01GetInitialData === 'function', message: '서버 메일 목록 초기 데이터 함수 확인' });
    result.checks.push({ key: 'ListReady', ok: typeof mcServerMailListV01List === 'function', message: '서버 메일 목록 조회 함수 확인' });
    result.checks.push({ key: 'DetailReady', ok: typeof mcServerMailListV01GetThreadDetail === 'function', message: '스레드 상세 조회 함수 확인' });
    result.checks.push({ key: 'HandleGetReady', ok: typeof mcServerMailListShellV01HandleGet === 'function', message: '서버 메일 목록 화면 핸들러 확인' });
    result.ok = result.checks.every(function(c) { return !!c.ok; });
    result.message = result.ok ? 'MailCenter Server Mail List Shell V01 준비 완료' : 'MailCenter Server Mail List Shell V01 점검 필요';
  } catch (err) {
    result.ok = false;
    result.message = String(err && err.message ? err.message : err);
  }

  Logger.log('JSON_COMPACT_RESULT: ' + JSON.stringify(result));
  return result;
}

function mcServerMailListShellV01HandleGet(e) {
  var data = typeof mcServerMailListV01GetInitialData === 'function'
    ? mcServerMailListV01GetInitialData()
    : { ok: false, message: 'mcServerMailListV01GetInitialData 함수가 없습니다.', accounts: [], quickFilters: [], links: {} };

  var t = HtmlService.createTemplateFromFile('MC_ServerMailListViewV01');
  t.build = MC_SERVER_MAIL_LIST_SHELL_V01_BUILD;
  t.initialJson = JSON.stringify(data);

  return t.evaluate()
    .setTitle('FEELHAUS MailCenter Server Mail List')
    .setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL);
}
