/*******************************************************
 * MC_GOOGLE_CALENDAR_APPROVAL_LOG_VERBOSE_V03_MINIMAL_20260527
 * Purpose: Minimal, visible, non-truncating log output for
 * Google Calendar approval/apply/sync diagnostics.
 *
 * Rules:
 * - Never output START/END only.
 * - Logger output must stay compact enough for Apps Script logs.
 * - Diagnose/ListCompact logger output never includes recentCompact or payloadPreview arrays.
 * - Full row is returned only by GetOne for a single selected log id, while Logger output stays compact.
 * - Does not clear, repair, or rewrite existing rows.
 *******************************************************/

var MC_GCAL_LOG_VERBOSE_V03_BUILD = 'MC_GOOGLE_CALENDAR_APPROVAL_LOG_VERBOSE_V03_MINIMAL_20260527';

function mcGoogleCalendarApprovalLogVerboseV03SelfTest() {
  var result = mcGoogleCalendarApprovalLogVerboseV03BaseResult_('mcGoogleCalendarApprovalLogVerboseV03SelfTest');
  try {
    var ss = mcGoogleCalendarApprovalLogVerboseV03OpenMaster_();
    result.checks = {
      masterDbOk: !!ss,
      auditSheetUpper: !!ss.getSheetByName('MAILCENTER_AuditLogs'),
      auditSheetLegacy: !!ss.getSheetByName('MailCenter_AuditLogs'),
      syncLogSheetUpper: !!ss.getSheetByName('MAILCENTER_GoogleCalendarSyncLogs'),
      syncLogSheetLegacy: !!ss.getSheetByName('MailCenter_GoogleCalendarSyncLogs'),
      v01LogFixReady: typeof mcGoogleCalendarApprovalLogFixV01ListRecent === 'function',
      approvalApplyReady: typeof mcGoogleCalendarSyncApprovalApplyV01 === 'function',
      approvalPreviewReady: typeof mcGoogleCalendarSyncApprovalApplyV01Preview === 'function'
    };
    result.ok = !!result.checks.masterDbOk;
    result.message = result.ok ? 'V03 Minimal 로그 조회 준비 완료' : 'V03 Minimal 로그 조회 준비 실패';
    result.nextAction = 'mcGoogleCalendarApprovalLogVerboseV03Diagnose({ limit: 10 }) 실행';
  } catch (err) {
    mcGoogleCalendarApprovalLogVerboseV03Catch_(result, err);
  }
  return mcGoogleCalendarApprovalLogVerboseV03Finish_(result);
}

function mcGoogleCalendarApprovalLogVerboseV03Diagnose(request) {
  request = request || {};
  var limit = mcGoogleCalendarApprovalLogVerboseV03Limit_(request.limit, 10, 30);
  var result = mcGoogleCalendarApprovalLogVerboseV03BaseResult_('mcGoogleCalendarApprovalLogVerboseV03Diagnose');
  result.filters = { limit: limit, output: 'IDS_ONLY_NO_PAYLOAD' };
  try {
    var ss = mcGoogleCalendarApprovalLogVerboseV03OpenMaster_();
    var ensure = mcGoogleCalendarApprovalLogVerboseV03EnsureSheets_(ss);
    var summary = mcGoogleCalendarApprovalLogVerboseV03ReadSummary_(ss, limit, 0);
    result.ok = true;
    result.message = summary.total > 0 ? 'Google Calendar 로그 compact 조회 완료' : '조회 가능한 Google Calendar 로그가 없습니다. Preview 또는 Apply를 먼저 실행하세요.';
    result.ensure = ensure;
    result.summary = summary.summary;
    result.sheetStatus = summary.sheetStatus;
    result.recentIds = summary.recentIds;
    result.sampleTitles = summary.sampleTitles;
    result.warnings = summary.warnings;
    result.nextAction = summary.total > 0 ? '상세 확인은 mcGoogleCalendarApprovalLogVerboseV03GetOne({ syncLogId: recentIds[0].syncLogId }) 실행' : 'mcGoogleCalendarSyncApprovalApplyV01Preview({ maxOps: 5 }) 실행 후 다시 조회';
  } catch (err) {
    mcGoogleCalendarApprovalLogVerboseV03Catch_(result, err);
  }
  return mcGoogleCalendarApprovalLogVerboseV03Finish_(result);
}

function mcGoogleCalendarApprovalLogVerboseV03ListCompact(request) {
  request = request || {};
  var limit = mcGoogleCalendarApprovalLogVerboseV03Limit_(request.limit, 5, 10);
  var result = mcGoogleCalendarApprovalLogVerboseV03BaseResult_('mcGoogleCalendarApprovalLogVerboseV03ListCompact');
  result.filters = { limit: limit, output: 'IDS_AND_TITLES_ONLY_NO_PAYLOAD' };
  try {
    var ss = mcGoogleCalendarApprovalLogVerboseV03OpenMaster_();
    var summary = mcGoogleCalendarApprovalLogVerboseV03ReadSummary_(ss, limit, 0);
    result.ok = true;
    result.message = summary.total > 0 ? '최근 Google Calendar 로그 compact 목록 조회 완료' : '조회 가능한 Google Calendar 로그가 없습니다.';
    result.summary = summary.summary;
    result.recentIds = summary.recentIds;
    result.sampleTitles = summary.sampleTitles;
    result.warnings = summary.warnings;
    result.nextAction = summary.total > 0 ? '원문 상세가 필요한 syncLogId 1건만 GetOne으로 조회' : 'Preview 또는 Apply 실행 후 재조회';
  } catch (err) {
    mcGoogleCalendarApprovalLogVerboseV03Catch_(result, err);
  }
  return mcGoogleCalendarApprovalLogVerboseV03Finish_(result);
}

function mcGoogleCalendarApprovalLogVerboseV03GetOne(request) {
  request = request || {};
  var syncLogId = String(request.syncLogId || request.logId || '').trim();
  var calendarEventId = String(request.calendarEventId || '').trim();
  var result = mcGoogleCalendarApprovalLogVerboseV03BaseResult_('mcGoogleCalendarApprovalLogVerboseV03GetOne');
  result.filters = { syncLogId: syncLogId, calendarEventId: calendarEventId };
  try {
    if (!syncLogId && !calendarEventId) {
      throw new Error('syncLogId 또는 calendarEventId 중 하나가 필요합니다. 먼저 ListCompact에서 recentIds를 확인하세요.');
    }
    var ss = mcGoogleCalendarApprovalLogVerboseV03OpenMaster_();
    var found = mcGoogleCalendarApprovalLogVerboseV03FindOne_(ss, syncLogId, calendarEventId);
    result.ok = !!found;
    result.message = found ? 'Google Calendar 로그 상세 1건 조회 완료' : '조건에 맞는 로그를 찾지 못했습니다.';
    result.row = found || null;
    result.nextAction = found && !found.googleEventId ? 'googleEventId가 비어 있으면 아직 DryRun 또는 미생성 상태입니다.' : '상세 확인 완료';
    result.rowCompact = found ? mcGoogleCalendarApprovalLogVerboseV03CompactRow_(found, 300) : null;
  } catch (err) {
    mcGoogleCalendarApprovalLogVerboseV03Catch_(result, err);
  }
  return mcGoogleCalendarApprovalLogVerboseV03Finish_(result, { fullRowAllowed: true });
}

function mcGoogleCalendarApprovalLogVerboseV03DiagnoseAndPrint(request) {
  var result = mcGoogleCalendarApprovalLogVerboseV03Diagnose(request || { limit: 10 });
  var printable = {
    ok: result.ok,
    build: result.build,
    action: result.action,
    generatedAt: result.generatedAt,
    message: result.message,
    summary: result.summary,
    recentIds: result.recentIds,
    sampleTitles: result.sampleTitles,
    warnings: result.warnings,
    nextAction: result.nextAction
  };
  Logger.log('JSON_COMPACT_RESULT_PRINTABLE: ' + mcGoogleCalendarApprovalLogVerboseV03Stringify_(printable));
  return printable;
}

function mcGoogleCalendarApprovalLogVerboseV03GetFirst(request) {
  request = request || {};
  var limit = mcGoogleCalendarApprovalLogVerboseV03Limit_(request.limit, 1, 1);
  var result = mcGoogleCalendarApprovalLogVerboseV03BaseResult_('mcGoogleCalendarApprovalLogVerboseV03GetFirst');
  result.filters = { limit: limit, output: 'FIRST_ROW_DETAIL' };
  try {
    var ss = mcGoogleCalendarApprovalLogVerboseV03OpenMaster_();
    var summary = mcGoogleCalendarApprovalLogVerboseV03ReadSummary_(ss, 1, 0);
    if (!summary.recentIds || !summary.recentIds.length || !summary.recentIds[0].syncLogId) {
      throw new Error('최근 syncLogId를 찾지 못했습니다. Preview 또는 Apply 실행 후 다시 조회하세요.');
    }
    var found = mcGoogleCalendarApprovalLogVerboseV03FindOne_(ss, summary.recentIds[0].syncLogId, '');
    result.ok = !!found;
    result.message = found ? '최근 Google Calendar 로그 1건 상세 조회 완료' : '최근 로그 상세를 찾지 못했습니다.';
    result.selected = summary.recentIds[0];
    result.row = found || null;
    result.rowCompact = found ? mcGoogleCalendarApprovalLogVerboseV03CompactRow_(found, 300) : null;
    result.nextAction = found && !found.googleEventId ? 'googleEventId가 비어 있으면 아직 DryRun 또는 미생성 상태입니다.' : '상세 확인 완료';
  } catch (err) {
    mcGoogleCalendarApprovalLogVerboseV03Catch_(result, err);
  }
  return mcGoogleCalendarApprovalLogVerboseV03Finish_(result, { fullRowAllowed: true });
}

function mcGoogleCalendarApprovalLogVerboseV03BaseResult_(action) {
  return {
    ok: false,
    build: MC_GCAL_LOG_VERBOSE_V03_BUILD,
    action: action,
    generatedAt: mcGoogleCalendarApprovalLogVerboseV03Now_(),
    message: '',
    warnings: [],
    errors: []
  };
}

function mcGoogleCalendarApprovalLogVerboseV03Finish_(result, options) {
  options = options || {};
  result.endedAt = mcGoogleCalendarApprovalLogVerboseV03Now_();
  var compact = mcGoogleCalendarApprovalLogVerboseV03CompactResult_(result, !!options.fullRowAllowed);
  Logger.log('JSON_COMPACT_RESULT: ' + mcGoogleCalendarApprovalLogVerboseV03Stringify_(compact));
  return mcGoogleCalendarApprovalLogVerboseV03Safe_(result);
}

function mcGoogleCalendarApprovalLogVerboseV03CompactResult_(result, fullRowAllowed) {
  var compact = {
    ok: result.ok,
    build: result.build,
    action: result.action,
    generatedAt: result.generatedAt,
    endedAt: result.endedAt,
    message: result.message,
    filters: result.filters || undefined,
    checks: result.checks || undefined,
    summary: result.summary || undefined,
    sheetStatus: result.sheetStatus || undefined,
    ensure: result.ensure || undefined,
    recentIds: result.recentIds || undefined,
    sampleTitles: result.sampleTitles || undefined,
    rowCompact: result.rowCompact || undefined,
    warnings: result.warnings || [],
    errors: result.errors || [],
    nextAction: result.nextAction || ''
  };
  if (fullRowAllowed && result.row) {
    compact.row = mcGoogleCalendarApprovalLogVerboseV03CompactRow_(result.row, 500);
  }
  return compact;
}

function mcGoogleCalendarApprovalLogVerboseV03EnsureSheets_(ss) {
  var out = { created: [], existing: [], checked: [] };
  mcGoogleCalendarApprovalLogVerboseV03EnsureSheet_(ss, 'MAILCENTER_AuditLogs', ['logId','createdAt','action','actorKey','targetId','resultStatus','message','payload'], out);
  mcGoogleCalendarApprovalLogVerboseV03EnsureSheet_(ss, 'MAILCENTER_GoogleCalendarSyncLogs', ['logId','createdAt','batchId','calendarEventId','googleCalendarId','googleEventId','direction','action','status','conflictStatus','message','payload','actorKey'], out);
  return out;
}

function mcGoogleCalendarApprovalLogVerboseV03EnsureSheet_(ss, name, headers, out) {
  var sh = ss.getSheetByName(name);
  if (!sh) {
    sh = ss.insertSheet(name);
    out.created.push(name);
  } else {
    out.existing.push(name);
  }
  out.checked.push(name);
  if (sh.getLastRow() < 1) {
    sh.getRange(1, 1, 1, headers.length).setValues([headers]);
  }
  return sh;
}

function mcGoogleCalendarApprovalLogVerboseV03ReadSummary_(ss, limit, previewChars) {
  var auditAliases = ['MAILCENTER_AuditLogs', 'MailCenter_AuditLogs'];
  var syncAliases = ['MAILCENTER_GoogleCalendarSyncLogs', 'MailCenter_GoogleCalendarSyncLogs'];
  var warnings = [];
  var audit = mcGoogleCalendarApprovalLogVerboseV03ReadAliases_(ss, auditAliases, limit, function(row) {
    var action = String(row.action || row.syncAction || '').toUpperCase();
    var msg = String(row.message || '').toUpperCase();
    return action.indexOf('GOOGLE') >= 0 || action.indexOf('CALENDAR') >= 0 || msg.indexOf('GOOGLE') >= 0 || msg.indexOf('CALENDAR') >= 0;
  });
  var sync = mcGoogleCalendarApprovalLogVerboseV03ReadAliases_(ss, syncAliases, limit, null);
  var combined = [];
  for (var i = 0; i < audit.length; i++) combined.push(audit[i]);
  for (var j = 0; j < sync.length; j++) combined.push(sync[j]);
  combined.sort(function(a, b) { return String(b.createdAt || b.generatedAt || '').localeCompare(String(a.createdAt || a.generatedAt || '')); });
  if (combined.length > limit) combined = combined.slice(0, limit);
  var recentIds = [];
  var sampleTitles = [];
  for (var k = 0; k < combined.length; k++) {
    var compact = mcGoogleCalendarApprovalLogVerboseV03CompactRow_(combined[k], 0);
    recentIds.push({
      index: k + 1,
      syncLogId: String(compact.syncLogId || compact.logId || ''),
      calendarEventId: String(compact.calendarEventId || ''),
      batchId: String(compact.batchId || ''),
      status: String(compact.syncStatus || compact.status || compact.resultStatus || ''),
      action: String(compact.syncAction || compact.action || '')
    });
    sampleTitles.push({
      index: k + 1,
      titlePreview: String(compact.titlePreview || ''),
      createdAt: String(compact.createdAt || '')
    });
  }
  var sheetStatus = mcGoogleCalendarApprovalLogVerboseV03SheetStatus_(ss, auditAliases.concat(syncAliases));
  var total = audit.length + sync.length;
  if (total > 0 && combined.length < total) warnings.push('표시 제한으로 최근 ' + combined.length + '건만 compact 출력했습니다.');
  return {
    total: total,
    warnings: warnings,
    summary: {
      auditCount: audit.length,
      syncLogCount: sync.length,
      displayed: combined.length,
      total: total,
      outputMode: 'MINIMAL_NON_TRUNCATING',
      fullPayloadPolicy: 'FULL_ROW_ONLY_BY_GET_ONE'
    },
    sheetStatus: sheetStatus,
    recentIds: recentIds,
    sampleTitles: sampleTitles
  };
}

function mcGoogleCalendarApprovalLogVerboseV03SheetStatus_(ss, names) {
  var out = [];
  var seen = {};
  for (var i = 0; i < names.length; i++) {
    var name = names[i];
    if (seen[name]) continue;
    seen[name] = true;
    var sh = ss.getSheetByName(name);
    out.push({ sheetName: name, exists: !!sh, lastRow: sh ? sh.getLastRow() : 0, lastColumn: sh ? sh.getLastColumn() : 0 });
  }
  return out;
}

function mcGoogleCalendarApprovalLogVerboseV03ReadAliases_(ss, names, limit, filterFn) {
  var out = [];
  var seen = {};
  for (var i = 0; i < names.length; i++) {
    var sh = ss.getSheetByName(names[i]);
    if (!sh) continue;
    var rows = mcGoogleCalendarApprovalLogVerboseV03ReadSheet_(sh, limit * 2);
    for (var j = 0; j < rows.length; j++) {
      var row = rows[j];
      if (filterFn && !filterFn(row)) continue;
      var key = String(row.syncLogId || row.logId || row.createdAt || '') + '|' + String(row.batchId || '') + '|' + String(row.calendarEventId || '');
      if (seen[key]) continue;
      seen[key] = true;
      row._sheetName = names[i];
      out.push(row);
      if (out.length >= limit) break;
    }
    if (out.length >= limit) break;
  }
  out.sort(function(a, b) { return String(b.createdAt || '').localeCompare(String(a.createdAt || '')); });
  if (out.length > limit) out = out.slice(0, limit);
  return out;
}

function mcGoogleCalendarApprovalLogVerboseV03ReadSheet_(sh, limit) {
  var values = sh.getDataRange().getValues();
  if (!values || values.length < 2) return [];
  var headers = values[0].map(function(h) { return String(h || '').trim(); });
  var out = [];
  for (var r = values.length - 1; r >= 1 && out.length < limit; r--) {
    var obj = {};
    for (var c = 0; c < headers.length; c++) obj[headers[c] || ('col' + (c + 1))] = values[r][c];
    out.push(obj);
  }
  return out;
}

function mcGoogleCalendarApprovalLogVerboseV03FindOne_(ss, syncLogId, calendarEventId) {
  var names = ['MAILCENTER_GoogleCalendarSyncLogs', 'MailCenter_GoogleCalendarSyncLogs', 'MAILCENTER_AuditLogs', 'MailCenter_AuditLogs'];
  for (var i = 0; i < names.length; i++) {
    var sh = ss.getSheetByName(names[i]);
    if (!sh) continue;
    var values = sh.getDataRange().getValues();
    if (!values || values.length < 2) continue;
    var headers = values[0].map(function(h) { return String(h || '').trim(); });
    for (var r = values.length - 1; r >= 1; r--) {
      var obj = {};
      for (var c = 0; c < headers.length; c++) obj[headers[c] || ('col' + (c + 1))] = values[r][c];
      obj._sheetName = names[i];
      obj._rowNumber = r + 1;
      if (syncLogId && String(obj.syncLogId || obj.logId || '') === syncLogId) return obj;
      if (calendarEventId && String(obj.calendarEventId || '') === calendarEventId) return obj;
    }
  }
  return null;
}

function mcGoogleCalendarApprovalLogVerboseV03CompactRow_(row, previewChars) {
  var payload = String(row.payloadSummary || row.payload || row.description || '');
  return {
    _sheetName: row._sheetName || '',
    _rowNumber: row._rowNumber || '',
    syncLogId: row.syncLogId || row.logId || '',
    batchId: row.batchId || '',
    calendarEventId: row.calendarEventId || '',
    googleCalendarId: row.googleCalendarId || '',
    googleEventId: row.googleEventId || '',
    syncDirection: row.syncDirection || row.direction || '',
    syncAction: row.syncAction || row.action || '',
    syncStatus: row.syncStatus || row.status || row.resultStatus || '',
    conflictStatus: row.conflictStatus || '',
    message: mcGoogleCalendarApprovalLogVerboseV03Truncate_(row.message || '', 160),
    titlePreview: mcGoogleCalendarApprovalLogVerboseV03ExtractTitle_(payload),
    payloadPreview: previewChars > 0 ? mcGoogleCalendarApprovalLogVerboseV03Truncate_(payload, previewChars) : '',
    payloadLength: payload.length,
    createdAt: row.createdAt || row.generatedAt || '',
    createdBy: row.createdBy || row.actorKey || ''
  };
}

function mcGoogleCalendarApprovalLogVerboseV03ExtractTitle_(payload) {
  var s = String(payload || '');
  var m = s.match(/"title"\s*:\s*"([^"]{1,160})"/);
  if (m && m[1]) return m[1];
  m = s.match(/Subject:\s*([^\\n\n]{1,160})/);
  if (m && m[1]) return m[1];
  return '';
}

function mcGoogleCalendarApprovalLogVerboseV03Truncate_(value, maxLen) {
  var s = String(value == null ? '' : value);
  maxLen = Number(maxLen || 220);
  if (s.length <= maxLen) return s;
  return s.substring(0, maxLen) + '... [truncated ' + (s.length - maxLen) + ' chars]';
}

function mcGoogleCalendarApprovalLogVerboseV03Limit_(value, defaultValue, maxValue) {
  var n = Number(value || defaultValue);
  if (!isFinite(n) || n < 1) n = defaultValue;
  return Math.max(1, Math.min(n, maxValue));
}

function mcGoogleCalendarApprovalLogVerboseV03OpenMaster_() {
  if (typeof mcCalendar19OpenMaster_ === 'function' && typeof mcCalendar19GetConfigBundle_ === 'function') {
    return mcCalendar19OpenMaster_(mcCalendar19GetConfigBundle_());
  }
  if (typeof mcGoogleCalendarApprovalLogFixV01OpenMaster_ === 'function') {
    return mcGoogleCalendarApprovalLogFixV01OpenMaster_();
  }
  var setup = SpreadsheetApp.openById('17VMSpgSZCvIrUlgcw8yCNcnl8WQWo2IcRf5tDCcuJGM');
  var sh = setup.getSheetByName('SystemConfig');
  if (!sh) throw new Error('SystemConfig 시트를 찾지 못했습니다.');
  var values = sh.getDataRange().getValues();
  var id = '';
  for (var r = 1; r < values.length; r++) {
    var key = String(values[r][0] || '').trim();
    var val = String(values[r][1] || '').trim();
    if (['FEELHAUS_DB_MASTER_ID','FEELHAUS_DB_MASTER','MASTER_DB_ID','MASTER_DB','DB_MASTER_ID','PORTAL_DB_ID','SPREADSHEET_ID'].indexOf(key) >= 0 && val) {
      id = val;
      break;
    }
  }
  id = mcGoogleCalendarApprovalLogVerboseV03ExtractId_(id);
  if (!id) throw new Error('FEELHAUS_DB_MASTER ID를 SystemConfig에서 찾지 못했습니다.');
  return SpreadsheetApp.openById(id);
}

function mcGoogleCalendarApprovalLogVerboseV03ExtractId_(text) {
  var s = String(text || '').trim();
  var m = s.match(/[-\w]{25,}/);
  return m ? m[0] : s;
}

function mcGoogleCalendarApprovalLogVerboseV03Catch_(result, err) {
  result.ok = false;
  result.message = mcGoogleCalendarApprovalLogVerboseV03Error_(err);
  result.errors = result.errors || [];
  result.errors.push({ message: result.message, stack: err && err.stack ? String(err.stack).substring(0, 1200) : '' });
  result.nextAction = '오류 메시지 확인 후 SystemConfig, MASTER_DB, 로그 시트 헤더를 점검하세요.';
}

function mcGoogleCalendarApprovalLogVerboseV03Safe_(obj) {
  try { return JSON.parse(JSON.stringify(obj)); } catch (err) { return obj; }
}

function mcGoogleCalendarApprovalLogVerboseV03Stringify_(obj) {
  try { return JSON.stringify(obj); } catch (err) { return mcGoogleCalendarApprovalLogVerboseV03Error_(err); }
}

function mcGoogleCalendarApprovalLogVerboseV03Error_(err) {
  if (!err) return '';
  if (err.name && err.message) return String(err.name) + ': ' + String(err.message);
  if (err.message) return String(err.message);
  return String(err);
}

function mcGoogleCalendarApprovalLogVerboseV03Now_() {
  try { return Utilities.formatDate(new Date(), Session.getScriptTimeZone() || 'Asia/Seoul', 'yyyy-MM-dd HH:mm:ss'); }
  catch (err) { return String(new Date()); }
}
