/**
 * FEELHAUS PORTAL / Calendar SAFE-01B R10K2 Event Master Link
 * Build: PORTAL_CALENDAR_SAFE01B_R10K2_EVENT_MASTER_LINK_DETAIL_20260604
 * Purpose:
 * - Calendar modal event picker reads FEELHAUS_DB_MASTER > ERP_행사관리 first.
 * - UI displays eventName, but linkage/storage remains eventId based.
 * - Read-only: no sheet/provider writes.
 */
var PORTAL_CALENDAR_SAFE01B_R10K2_EVENT_MASTER_LINK_BUILD = 'PORTAL_CALENDAR_SAFE01B_R10K2_EVENT_MASTER_LINK_DETAIL_20260604';
var PORTAL_CALENDAR_R10K2_SETUP_DB_ID = '17VMSpgSZCvIrUlgcw8yCNcnl8WQWo2IcRf5tDCcuJGM';
var PORTAL_CALENDAR_R10K2_CONFIG_SHEET = 'SystemConfig';

function portalCalendarR10K2ListEventMasterOptions(payload) {
  var result = portalCalendarR10K2Base_('portalCalendarR10K2ListEventMasterOptions');
  try {
    payload = payload || {};
    var limit = Math.max(1, Math.min(Number(payload.limit || 80), 200));
    var ss = portalCalendarR10K2OpenMaster_();
    var discovery = portalCalendarR10K2DiscoverEventMaster_(ss);
    if (!discovery.sheet) throw new Error('행사관리 원장 시트를 찾지 못했습니다. 1순위 원장명은 ERP_행사관리입니다.');
    if (!discovery.eventIdHeader) throw new Error(discovery.sheetName + ' 시트에서 eventId 헤더를 찾지 못했습니다.');
    var rows = portalCalendarR10K2ReadRows_(discovery.sheet, discovery.headerMap, discovery.eventIdHeader, limit);
    result.ok = true;
    result.sourceSheetName = discovery.sheetName;
    result.eventIdHeader = discovery.eventIdHeader;
    result.count = rows.length;
    result.items = rows.map(portalCalendarR10K2CompactEvent_);
    result.message = '행사관리 원장 후보 조회 완료. 표시명은 eventName, 실제 연결은 eventId 기준입니다.';
  } catch (err) { portalCalendarR10K2Catch_(result, err); }
  portalCalendarR10K2Log_(result);
  return result;
}

function portalCalendarR10K2GetEventMasterDetail(payload) {
  var result = portalCalendarR10K2Base_('portalCalendarR10K2GetEventMasterDetail');
  try {
    payload = payload || {};
    var eventId = String(payload.eventId || payload.relatedEventId || '').trim();
    if (!eventId) throw new Error('eventId가 필요합니다.');
    var ss = portalCalendarR10K2OpenMaster_();
    var found = portalCalendarR10K2FindEventById_(ss, eventId);
    if (!found.event) throw new Error('ERP_행사관리 원장에서 eventId를 찾지 못했습니다: ' + eventId);
    result.ok = true;
    result.eventId = eventId;
    result.sourceSheetName = found.sourceSheetName;
    result.rowNumber = found.rowNumber;
    result.event = portalCalendarR10K2NormalizeEvent_(found.event, found.sourceSheetName, found.rowNumber);
    result.eventMaster = result.event;
    result.message = '행사관리 원장 상세 조회 완료. 원본은 수정하지 않았습니다.';
  } catch (err) { portalCalendarR10K2Catch_(result, err); }
  portalCalendarR10K2Log_(result);
  return result;
}

function portalCalendarSafe01BR10K2EventMasterLinkVerify() {
  var result = portalCalendarR10K2Base_('portalCalendarSafe01BR10K2EventMasterLinkVerify');
  result.safety = 'READ_ONLY_RUNTIME_VERIFY_NO_SHEET_PROVIDER_WRITE';
  result.checks = {};
  result.warnings = [];
  result.fatal = [];
  function check(k, ok) { result.checks[k] = !!ok; if (!ok) result.fatal.push(k); }
  try {
    var ss = portalCalendarR10K2OpenMaster_();
    var discovery = portalCalendarR10K2DiscoverEventMaster_(ss);
    check('masterOpenReady', !!ss);
    check('preferredEventMasterSheetKnown', portalCalendarR10K2EventSheetCandidates_()[0] === 'ERP_행사관리');
    check('eventMasterSheetFound', !!discovery.sheet);
    check('eventIdHeaderFound', !!discovery.eventIdHeader);
    var items = discovery.sheet && discovery.eventIdHeader ? portalCalendarR10K2ReadRows_(discovery.sheet, discovery.headerMap, discovery.eventIdHeader, 5) : [];
    result.sourceSheetName = discovery.sheetName || '';
    result.eventIdHeader = discovery.eventIdHeader || '';
    result.sampleCount = items.length;
    result.sample = items.map(portalCalendarR10K2CompactEvent_);
    result.summary = {
      build: PORTAL_CALENDAR_SAFE01B_R10K2_EVENT_MASTER_LINK_BUILD,
      eventMasterName: 'ERP_행사관리',
      displayField: 'eventName',
      linkField: 'eventId',
      readOnly: true,
      noProviderWrite: true
    };
    result.ok = result.fatal.length === 0;
    result.message = result.ok ? 'SAFE-01B R10K2 event master link verification passed.' : 'SAFE-01B R10K2 event master link verification failed.';
  } catch (err) { portalCalendarR10K2Catch_(result, err); result.fatal.push('exception'); }
  portalCalendarR10K2Log_(result);
  return result;
}

function portalCalendarR10K2FindEventById_(ss, eventId) {
  var discovery = portalCalendarR10K2DiscoverEventMaster_(ss);
  if (!discovery.sheet || !discovery.eventIdHeader) return { event:null, sourceSheetName:discovery.sheetName || '', rowNumber:0 };
  var values = discovery.sheet.getDataRange().getValues();
  var idx = discovery.headerMap[discovery.eventIdHeader];
  for (var r = 1; r < values.length; r++) {
    if (String(values[r][idx] || '').trim() === String(eventId || '').trim()) {
      return { event:portalCalendarR10K2RowToObject_(values[0], values[r]), sourceSheetName:discovery.sheetName, rowNumber:r + 1 };
    }
  }
  return { event:null, sourceSheetName:discovery.sheetName || '', rowNumber:0 };
}

function portalCalendarR10K2DiscoverEventMaster_(ss) {
  var names = portalCalendarR10K2EventSheetCandidates_();
  for (var i = 0; i < names.length; i++) {
    var sh = ss.getSheetByName(names[i]);
    if (!sh) continue;
    var hm = portalCalendarR10K2HeaderMap_(sh.getRange(1, 1, 1, Math.max(sh.getLastColumn(), 1)).getValues()[0]);
    var eid = portalCalendarR10K2PickExistingHeader_(hm, ['eventId','eventID','event_id','행사ID','행사Id','행사id']);
    return { sheet:sh, sheetName:sh.getName(), headerMap:hm, eventIdHeader:eid };
  }
  return { sheet:null, sheetName:'', headerMap:{}, eventIdHeader:'' };
}
function portalCalendarR10K2EventSheetCandidates_() { return ['ERP_행사관리','행사관리','ERP_Events','ERP_EventMaster','ERP_Event','ERP_행사','EVENT_MASTER','EVENTS','Events','EventMaster','EventList','EventCenterEvents','행사']; }

function portalCalendarR10K2ReadRows_(sheet, hm, eventIdHeader, limit) {
  var values = sheet.getDataRange().getValues();
  var out = [];
  if (values.length < 2) return out;
  var idx = hm[eventIdHeader];
  for (var r = values.length - 1; r >= 1 && out.length < limit; r--) {
    var eventId = String(values[r][idx] || '').trim();
    if (!eventId) continue;
    var obj = portalCalendarR10K2RowToObject_(values[0], values[r]);
    obj.eventId = obj.eventId || eventId;
    obj.__sourceSheetName = sheet.getName();
    obj.__rowNumber = r + 1;
    out.push(obj);
  }
  return out;
}
function portalCalendarR10K2CompactEvent_(ev) {
  ev = ev || {};
  return {
    sourceSheetName: ev.__sourceSheetName || ev.sourceSheetName || '',
    rowNumber: ev.__rowNumber || ev.rowNumber || '',
    eventId: ev.eventId || portalCalendarR10K2PickValue_(ev, ['eventID','행사ID','행사Id']) || '',
    eventName: portalCalendarR10K2PickValue_(ev, ['eventName','title','name','fairName','행사명','행사명칭']) || '',
    eventStatus: portalCalendarR10K2PickValue_(ev, ['eventStatus','status','행사상태','상태']) || '',
    eventStartDate: portalCalendarR10K2PickValue_(ev, ['eventStartDate','eventStartAt','startAt','startDate','행사시작일','시작일','시작일자']) || '',
    eventEndDate: portalCalendarR10K2PickValue_(ev, ['eventEndDate','eventEndAt','endAt','endDate','행사종료일','종료일','종료일자']) || '',
    eventLocation: portalCalendarR10K2PickValue_(ev, ['eventLocation','location','venue','eventPlace','place','행사장소','장소']) || '',
    primaryManagerName: portalCalendarR10K2PickValue_(ev, ['primaryManagerName','eventManagerName','managerName','ownerName','담당자','행사담당자','행사담당']) || '',
    siteManagerName: portalCalendarR10K2PickValue_(ev, ['siteManagerName','fieldManagerName','현장담당자','현장담당']) || '',
    participants: portalCalendarR10K2PickValue_(ev, ['participants','participantJson','staffNames','참여자','참여직원','행사참여자','운영인력']) || '',
    vendorNames: portalCalendarR10K2PickValue_(ev, ['vendorNames','participatingVendors','vendorSummary','참여업체','업체명']) || ''
  };
}
function portalCalendarR10K2NormalizeEvent_(ev, sourceSheetName, rowNumber) {
  ev = ev || {};
  var c = portalCalendarR10K2CompactEvent_(ev);
  Object.keys(c).forEach(function(k){ if (!ev[k] && c[k]) ev[k] = c[k]; });
  ev.__sourceSheetName = sourceSheetName || ev.__sourceSheetName || '';
  ev.__rowNumber = rowNumber || ev.__rowNumber || '';
  return ev;
}
function portalCalendarR10K2OpenMaster_() {
  if (typeof mcCalendarUnifiedManualInputV01OpenMaster_ === 'function') return mcCalendarUnifiedManualInputV01OpenMaster_();
  var setup = SpreadsheetApp.openById(PORTAL_CALENDAR_R10K2_SETUP_DB_ID);
  var sheet = setup.getSheetByName(PORTAL_CALENDAR_R10K2_CONFIG_SHEET);
  if (!sheet) throw new Error('SystemConfig 시트를 찾지 못했습니다.');
  var values = sheet.getDataRange().getValues();
  if (!values || values.length < 2) throw new Error('SystemConfig 데이터가 비어 있습니다.');
  var hm = portalCalendarR10K2HeaderMap_(values[0]);
  var keyCol = portalCalendarR10K2PickIndex_(hm, ['CONFIG_KEY','configKey','key','name']);
  var valCol = portalCalendarR10K2PickIndex_(hm, ['VALUE','configValue','value','spreadsheetId']);
  if (keyCol < 0 || valCol < 0) throw new Error('SystemConfig CONFIG_KEY/VALUE 헤더를 찾지 못했습니다.');
  var masterId = '';
  for (var r = 1; r < values.length; r++) {
    var key = String(values[r][keyCol] || '').trim();
    if (key === 'FEELHAUS_DB_MASTER' || key === 'FEELHAUS_DB_MASTER_ID' || key === 'MASTER_DB_ID') { masterId = String(values[r][valCol] || '').trim(); break; }
  }
  if (!masterId) throw new Error('SystemConfig에서 FEELHAUS_DB_MASTER ID를 찾지 못했습니다.');
  return SpreadsheetApp.openById(masterId);
}
function portalCalendarR10K2HeaderMap_(headers) { var m = {}; (headers || []).forEach(function(h, i){ var k = String(h || '').trim(); if (k) m[k] = i; }); return m; }
function portalCalendarR10K2RowToObject_(headers, row) { var o = {}; (headers || []).forEach(function(h, i){ var k = String(h || '').trim(); if (k) o[k] = portalCalendarR10K2Cell_(row[i]); }); return o; }
function portalCalendarR10K2Cell_(v) { if (v === null || v === undefined) return ''; if (Object.prototype.toString.call(v) === '[object Date]' && !isNaN(v.getTime())) { var tz = 'Asia/Seoul'; try { tz = Session.getScriptTimeZone() || 'Asia/Seoul'; } catch (ignore) {} return Utilities.formatDate(v, tz, 'yyyy-MM-dd HH:mm:ss'); } return v; }
function portalCalendarR10K2PickExistingHeader_(hm, arr) { for (var i = 0; i < arr.length; i++) if (hm.hasOwnProperty(arr[i])) return arr[i]; return ''; }
function portalCalendarR10K2PickIndex_(hm, arr) { var h = portalCalendarR10K2PickExistingHeader_(hm, arr); return h ? hm[h] : -1; }
function portalCalendarR10K2PickValue_(obj, arr) { for (var i = 0; i < arr.length; i++) { var v = obj[arr[i]]; if (v !== undefined && v !== null && String(v).trim()) return String(v).trim(); } return ''; }
function portalCalendarR10K2Now_() { return Utilities.formatDate(new Date(), Session.getScriptTimeZone() || 'Asia/Seoul', 'yyyy-MM-dd HH:mm:ss'); }
function portalCalendarR10K2Base_(action) { return { ok:false, build:PORTAL_CALENDAR_SAFE01B_R10K2_EVENT_MASTER_LINK_BUILD, action:action, generatedAt:portalCalendarR10K2Now_(), realApplyExecuted:false, destructiveRepairExecuted:false, errors:[] }; }
function portalCalendarR10K2Catch_(result, err) { result.ok = false; result.message = String(err && err.message ? err.message : err); result.errors.push({ message:result.message, stack:String(err && err.stack ? err.stack : '') }); }
function portalCalendarR10K2Log_(result) { try { Logger.log('JSON_COMPACT_RESULT: ' + JSON.stringify(result)); } catch (ignore) {} }
