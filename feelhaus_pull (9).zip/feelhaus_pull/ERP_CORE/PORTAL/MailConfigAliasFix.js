/**
 * FEELHAUS MailCenter config alias fix
 * Build: MAIL_CONFIG_ALIAS_FIX_20260525
 * Purpose: Restore PORTAL19_* config aliases required by MailCenter dashboard.
 * Safety: read-only alias definitions only. No write / no send / no create.
 */

var MAIL_CONFIG_ALIAS_FIX_BUILD = 'MAIL_CONFIG_ALIAS_FIX_20260525';

var PORTAL19_SETUP_DB_ID = (typeof PORTAL19_SETUP_DB_ID !== 'undefined' && PORTAL19_SETUP_DB_ID) ? PORTAL19_SETUP_DB_ID :
  ((typeof PORTAL_SETUP_DB_ID !== 'undefined' && PORTAL_SETUP_DB_ID) ? PORTAL_SETUP_DB_ID :
  ((typeof PORTAL_SETUP_DB !== 'undefined' && PORTAL_SETUP_DB) ? PORTAL_SETUP_DB :
  '17VMSpgSZCvIrUlgcw8yCNcnl8WQWo2IcRf5tDCcuJGM'));

var PORTAL19_CONFIG_SHEET = (typeof PORTAL19_CONFIG_SHEET !== 'undefined' && PORTAL19_CONFIG_SHEET) ? PORTAL19_CONFIG_SHEET :
  ((typeof PORTAL19_CONFIG_SHEET_NAME !== 'undefined' && PORTAL19_CONFIG_SHEET_NAME) ? PORTAL19_CONFIG_SHEET_NAME :
  ((typeof PORTAL_CONFIG_SHEET !== 'undefined' && PORTAL_CONFIG_SHEET) ? PORTAL_CONFIG_SHEET :
  ((typeof CONFIG_SHEET_NAME !== 'undefined' && CONFIG_SHEET_NAME) ? CONFIG_SHEET_NAME : 'SystemConfig')));

var PORTAL19_CONFIG_SHEET_NAME = (typeof PORTAL19_CONFIG_SHEET_NAME !== 'undefined' && PORTAL19_CONFIG_SHEET_NAME) ? PORTAL19_CONFIG_SHEET_NAME : PORTAL19_CONFIG_SHEET;

var PORTAL19_SOURCE_DB = (typeof PORTAL19_SOURCE_DB !== 'undefined' && PORTAL19_SOURCE_DB) ? PORTAL19_SOURCE_DB :
  ((typeof PORTAL_SOURCE_DB !== 'undefined' && PORTAL_SOURCE_DB) ? PORTAL_SOURCE_DB : 'FEELHAUS_SETUP_DB');

var PORTAL19_MASTER_DB = (typeof PORTAL19_MASTER_DB !== 'undefined' && PORTAL19_MASTER_DB) ? PORTAL19_MASTER_DB :
  ((typeof PORTAL_MASTER_DB !== 'undefined' && PORTAL_MASTER_DB) ? PORTAL_MASTER_DB : 'FEELHAUS_DB_MASTER');

function runMailConfigAliasFixTest() {
  var result = {
    ok: true,
    build: MAIL_CONFIG_ALIAS_FIX_BUILD,
    mode: 'READONLY_ALIAS_ONLY_NO_WRITE',
    checkedAt: new Date().toISOString(),
    summary: {
      PORTAL19_SETUP_DB_ID: PORTAL19_SETUP_DB_ID,
      PORTAL19_CONFIG_SHEET: PORTAL19_CONFIG_SHEET,
      PORTAL19_CONFIG_SHEET_NAME: PORTAL19_CONFIG_SHEET_NAME,
      PORTAL19_SOURCE_DB: PORTAL19_SOURCE_DB,
      PORTAL19_MASTER_DB: PORTAL19_MASTER_DB,
      writePerformed: false
    },
    fatal: [],
    warnings: []
  };
  ['PORTAL19_SETUP_DB_ID','PORTAL19_CONFIG_SHEET','PORTAL19_CONFIG_SHEET_NAME','PORTAL19_SOURCE_DB','PORTAL19_MASTER_DB'].forEach(function(k){
    if (!result.summary[k]) result.fatal.push(k + ' missing');
  });
  result.ok = result.fatal.length === 0;
  Logger.log('[MAIL_CONFIG_ALIAS_FIX] RESULT :: ' + JSON.stringify(result, null, 2));
  return result;
}
