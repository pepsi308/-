/**
 * FEELHAUS PORTAL / MailCenter Calendar Unified Manual Input No-Arg V02
 * Build: PORTAL_MC_CALENDAR_MANUAL_INPUT_NO_ARG_TEST_V02_20260528
 * Purpose:
 * - Apps Script 실행 버튼만으로 고급 수동일정 실제 저장/후보 DryRun/최근목록을 검증한다.
 * - Google/Naver 실반영은 하지 않는다. Google은 READY_DRY_RUN_REQUIRED 후보만 만든다.
 * - 기존 V01 저장 함수와 원장 구조를 그대로 사용한다.
 */
var MC_CALENDAR_MANUAL_INPUT_NO_ARG_V02_BUILD = 'PORTAL_MC_CALENDAR_MANUAL_INPUT_NO_ARG_TEST_V02_20260528';

function mcCalendarUnifiedManualInputV02SelfTest() {
  var result = mcCalendarUnifiedManualInputV02BaseResult_('mcCalendarUnifiedManualInputV02SelfTest');
  try {
    result.checks = {
      v01SelfTestReady: typeof mcCalendarUnifiedManualInputV01SelfTest === 'function',
      v01CreateReady: typeof mcCalendarUnifiedManualInputV01Create === 'function',
      v01OptionsReady: typeof mcCalendarUnifiedManualInputV01GetOptions === 'function',
      v01OpenMasterReady: typeof mcCalendarUnifiedManualInputV01OpenMaster_ === 'function',
      v01HeaderMapReady: typeof mcCalendarUnifiedManualInputV01HeaderMap_ === 'function',
      googleRealApplyExecuted: false,
      destructiveRepairExecuted: false
    };
    var missingFns = [];
    Object.keys(result.checks).forEach(function(k) {
      if (k !== 'googleRealApplyExecuted' && k !== 'destructiveRepairExecuted' && !result.checks[k]) missingFns.push(k);
    });
    var ss = mcCalendarUnifiedManualInputV01OpenMaster_();
    var sheet = ss.getSheetByName('MAILCENTER_CalendarEvents');
    result.targetSheets = [{ sheetName: 'MAILCENTER_CalendarEvents', exists: !!sheet, lastRow: sheet ? sheet.getLastRow() : 0, lastColumn: sheet ? sheet.getLastColumn() : 0 }];
    result.ok = missingFns.length === 0 && !!sheet;
    result.missingFunctions = missingFns;
    result.message = result.ok ? 'V02 No-Arg 수동일정 테스트 함수 준비 완료' : 'V02 준비 실패: V01 함수 또는 원장 시트가 필요합니다.';
    result.nextAction = 'mcCalendarUnifiedManualInputV02CreateSampleReal() 실행 전 현재 row 수를 확인하고, 저장 테스트 후 ListRecentManual5를 실행하세요.';
  } catch (err) {
    mcCalendarUnifiedManualInputV02Catch_(result, err);
  }
  return mcCalendarUnifiedManualInputV02Print_(result);
}

function mcCalendarUnifiedManualInputV02CreateSampleReal() {
  var payload = mcCalendarUnifiedManualInputV02BaseSamplePayload_('[실저장] 수동입력 고급 일정 테스트', 'NONE');
  payload.description = 'V02 No-Arg 실제 저장 테스트입니다. Google/Naver 실반영은 하지 않습니다.';
  payload.statusReason = 'V02 No-Arg 실제 저장 테스트';
  return mcCalendarUnifiedManualInputV02WrapCreate_('mcCalendarUnifiedManualInputV02CreateSampleReal', payload, '실제 저장 테스트를 실행했습니다. 캘린더 화면 또는 ListRecentManual5에서 표시를 확인하세요.');
}

function mcCalendarUnifiedManualInputV02CreateSampleGoogleCandidateDryRun() {
  var payload = mcCalendarUnifiedManualInputV02BaseSamplePayload_('[DRYRUN] Google 후보 수동일정', 'GOOGLE');
  payload.dryRun = 'Y';
  payload.description = 'Google Sync 후보 저장 계획 DryRun입니다. 실제 원장 저장과 Google 생성은 하지 않습니다.';
  payload.statusReason = 'Google 후보 DryRun';
  return mcCalendarUnifiedManualInputV02WrapCreate_('mcCalendarUnifiedManualInputV02CreateSampleGoogleCandidateDryRun', payload, 'Google 후보 DryRun을 확인했습니다. 실제 Google 생성은 하지 않았습니다.');
}

function mcCalendarUnifiedManualInputV02CreateSampleNaverCandidateDryRun() {
  var payload = mcCalendarUnifiedManualInputV02BaseSamplePayload_('[DRYRUN] Naver export 후보 수동일정', 'NAVER_EXPORT');
  payload.dryRun = 'Y';
  payload.description = 'Naver export 후보 저장 계획 DryRun입니다. 실제 원장 저장과 외부 반영은 하지 않습니다.';
  payload.statusReason = 'Naver export 후보 DryRun';
  return mcCalendarUnifiedManualInputV02WrapCreate_('mcCalendarUnifiedManualInputV02CreateSampleNaverCandidateDryRun', payload, 'Naver export 후보 DryRun을 확인했습니다. 실제 외부 반영은 하지 않았습니다.');
}

function mcCalendarUnifiedManualInputV02CreateSampleBothCandidateDryRun() {
  var payload = mcCalendarUnifiedManualInputV02BaseSamplePayload_('[DRYRUN] Google/Naver 후보 수동일정', 'BOTH');
  payload.dryRun = 'Y';
  payload.description = 'Google/Naver 후보 저장 계획 DryRun입니다. 실제 저장과 외부 반영은 하지 않습니다.';
  payload.statusReason = 'Google/Naver 후보 DryRun';
  return mcCalendarUnifiedManualInputV02WrapCreate_('mcCalendarUnifiedManualInputV02CreateSampleBothCandidateDryRun', payload, 'Google/Naver 후보 DryRun을 확인했습니다. 실제 외부 반영은 하지 않았습니다.');
}

function mcCalendarUnifiedManualInputV02ListRecentManual5() {
  return mcCalendarUnifiedManualInputV02ListRecentManual_(5);
}

function mcCalendarUnifiedManualInputV02ListRecentManual10() {
  return mcCalendarUnifiedManualInputV02ListRecentManual_(10);
}

function mcCalendarUnifiedManualInputV02ListRecentManual_(limit) {
  var result = mcCalendarUnifiedManualInputV02BaseResult_('mcCalendarUnifiedManualInputV02ListRecentManual' + limit);
  try {
    limit = Math.max(1, Math.min(Number(limit || 5), 10));
    var ss = mcCalendarUnifiedManualInputV01OpenMaster_();
    var sheet = ss.getSheetByName('MAILCENTER_CalendarEvents');
    if (!sheet) throw new Error('MAILCENTER_CalendarEvents 시트를 찾을 수 없습니다.');
    var lastRow = sheet.getLastRow();
    var lastCol = sheet.getLastColumn();
    var headers = lastCol ? sheet.getRange(1, 1, 1, lastCol).getValues()[0] : [];
    var hm = mcCalendarUnifiedManualInputV01HeaderMap_(headers);
    var rows = lastRow > 1 ? sheet.getRange(2, 1, lastRow - 1, lastCol).getValues() : [];
    var list = [];
    for (var i = rows.length - 1; i >= 0 && list.length < limit; i--) {
      var row = rows[i];
      var sourceType = mcCalendarUnifiedManualInputV02Cell_(row, hm, ['sourceType','calendarType']);
      var calendarType = mcCalendarUnifiedManualInputV02Cell_(row, hm, ['calendarType']);
      var calendarEventId = mcCalendarUnifiedManualInputV02Cell_(row, hm, ['calendarEventId']);
      if (String(sourceType || calendarType || '').toUpperCase() !== 'MANUAL' && String(calendarEventId || '').indexOf('MCAL-MANUAL') !== 0) continue;
      list.push({
        index: list.length + 1,
        rowNumber: i + 2,
        calendarEventId: String(calendarEventId || ''),
        title: String(mcCalendarUnifiedManualInputV02Cell_(row, hm, ['title','eventTitle']) || ''),
        startAt: String(mcCalendarUnifiedManualInputV02Cell_(row, hm, ['startAt','startDate','startDateTime']) || ''),
        endAt: String(mcCalendarUnifiedManualInputV02Cell_(row, hm, ['endAt','endDate','endDateTime']) || ''),
        status: String(mcCalendarUnifiedManualInputV02Cell_(row, hm, ['eventStatus','status']) || ''),
        syncTarget: String(mcCalendarUnifiedManualInputV02Cell_(row, hm, ['syncTarget']) || ''),
        googleSyncStatus: String(mcCalendarUnifiedManualInputV02Cell_(row, hm, ['googleSyncStatus']) || ''),
        naverSyncStatus: String(mcCalendarUnifiedManualInputV02Cell_(row, hm, ['naverSyncStatus']) || ''),
        createdAt: String(mcCalendarUnifiedManualInputV02Cell_(row, hm, ['createdAt']) || ''),
        createdBy: String(mcCalendarUnifiedManualInputV02Cell_(row, hm, ['createdBy']) || '')
      });
    }
    result.ok = true;
    result.message = '최근 수동일정 목록 조회 완료';
    result.filters = { limit: limit, sourceType: 'MANUAL', output: 'IDS_AND_STATUS_ONLY' };
    result.summary = { sheetName: sheet.getName(), lastRow: lastRow, displayed: list.length, realApplyExecuted: false, destructiveRepairExecuted: false };
    result.recentManualEvents = list;
    result.nextAction = list.length ? '캘린더 화면에서 위 calendarEventId 표시 여부를 확인하세요.' : '수동일정 실제 저장 함수를 먼저 실행하세요.';
  } catch (err) {
    mcCalendarUnifiedManualInputV02Catch_(result, err);
  }
  return mcCalendarUnifiedManualInputV02Print_(result);
}

function mcCalendarUnifiedManualInputV02WrapCreate_(actionName, payload, successMessage) {
  var result = mcCalendarUnifiedManualInputV02BaseResult_(actionName);
  try {
    var before = mcCalendarUnifiedManualInputV02SheetState_();
    var inner = mcCalendarUnifiedManualInputV01Create(payload);
    var after = mcCalendarUnifiedManualInputV02SheetState_();
    result.innerBuild = inner.build;
    result.innerAction = inner.action;
    result.innerOk = inner.ok;
    result.innerMessage = inner.message;
    result.validation = inner.validation || null;
    result.dryRun = !!inner.dryRun;
    result.saved = !!inner.saved;
    result.calendarEventId = inner.calendarEventId || (inner.record && inner.record.calendarEventId) || '';
    result.record = mcCalendarUnifiedManualInputV02CompactRecord_(inner.record || {});
    result.googleSyncCandidate = !!inner.googleSyncCandidate || payload.syncTarget === 'GOOGLE' || payload.syncTarget === 'BOTH';
    result.naverExportCandidate = !!inner.naverExportCandidate || payload.syncTarget === 'NAVER_EXPORT' || payload.syncTarget === 'BOTH';
    result.before = before;
    result.after = after;
    result.rowDelta = after.lastRow - before.lastRow;
    result.realApplyExecuted = false;
    result.destructiveRepairExecuted = false;
    result.ok = !!inner.ok;
    result.message = inner.ok ? successMessage : inner.message;
    result.errors = inner.errors || [];
    result.warnings = inner.warnings || [];
    result.nextAction = inner.saved ? 'mcCalendarUnifiedManualInputV02ListRecentManual5() 실행 후 캘린더 화면 표시를 확인하세요.' : 'DryRun 결과를 확인하고 실제 저장이 필요하면 CreateSampleReal을 실행하세요.';
  } catch (err) {
    mcCalendarUnifiedManualInputV02Catch_(result, err);
  }
  return mcCalendarUnifiedManualInputV02Print_(result);
}

function mcCalendarUnifiedManualInputV02BaseSamplePayload_(title, syncTarget) {
  return {
    title: title,
    sourceType: 'MANUAL',
    categoryCode: 'MEETING',
    startAt: mcCalendarUnifiedManualInputV01TodayAt_('11:00'),
    endAt: mcCalendarUnifiedManualInputV01TodayAt_('11:30'),
    allDay: 'N',
    timezone: 'Asia/Seoul',
    location: 'FEELHAUS 회의실',
    meetingUrl: '',
    description: 'V02 No-Arg 테스트 일정입니다.',
    attendeesText: 'pepsi309@gmail.com, feelhaus@feelhausfair.com',
    organizerEmail: 'feelhaus@feelhausfair.com',
    reminderMinutesText: '10,30',
    repeatType: 'NONE',
    repeatRule: '',
    repeatUntil: '',
    repeatCount: '',
    syncTarget: syncTarget || 'NONE',
    privacyLevel: 'DEFAULT',
    visibility: 'DEFAULT',
    busyStatus: 'BUSY',
    priority: 'NORMAL',
    eventStatus: 'SCHEDULED',
    status: 'SCHEDULED',
    customTypeName: 'No-Arg 테스트',
    colorTag: 'gold'
  };
}

function mcCalendarUnifiedManualInputV02SheetState_() {
  var state = { sheetName: 'MAILCENTER_CalendarEvents', exists: false, lastRow: 0, lastColumn: 0 };
  try {
    var ss = mcCalendarUnifiedManualInputV01OpenMaster_();
    var sheet = ss.getSheetByName('MAILCENTER_CalendarEvents');
    state.exists = !!sheet;
    if (sheet) {
      state.lastRow = sheet.getLastRow();
      state.lastColumn = sheet.getLastColumn();
    }
  } catch (err) {
    state.error = String(err && err.message ? err.message : err);
  }
  return state;
}

function mcCalendarUnifiedManualInputV02CompactRecord_(record) {
  return {
    calendarEventId: record.calendarEventId || '',
    sourceType: record.sourceType || '',
    calendarType: record.calendarType || '',
    title: record.title || '',
    startAt: record.startAt || '',
    endAt: record.endAt || '',
    categoryCode: record.categoryCode || '',
    eventStatus: record.eventStatus || record.status || '',
    syncTarget: record.syncTarget || '',
    googleSyncStatus: record.googleSyncStatus || '',
    naverSyncStatus: record.naverSyncStatus || '',
    privacyLevel: record.privacyLevel || '',
    busyStatus: record.busyStatus || '',
    repeatType: record.repeatType || '',
    reminderEnabled: record.reminderEnabled || '',
    createdAt: record.createdAt || '',
    createdBy: record.createdBy || ''
  };
}

function mcCalendarUnifiedManualInputV02Cell_(row, hm, keys) {
  for (var i = 0; i < keys.length; i++) {
    if (hm[keys[i]] !== undefined) return row[hm[keys[i]]];
  }
  return '';
}

function mcCalendarUnifiedManualInputV02BaseResult_(action) {
  return { ok: false, build: MC_CALENDAR_MANUAL_INPUT_NO_ARG_V02_BUILD, action: action, generatedAt: mcCalendarUnifiedManualInputV01Now_(), realApplyExecuted: false, destructiveRepairExecuted: false, warnings: [], errors: [], message: '', nextAction: '' };
}

function mcCalendarUnifiedManualInputV02Catch_(result, err) {
  result.ok = false;
  result.message = String(err && err.message ? err.message : err);
  result.errors.push({ message: result.message, stack: err && err.stack ? err.stack : '' });
  result.nextAction = 'V01 함수 존재 여부, MAILCENTER_CalendarEvents 헤더, 중복 일정 여부를 확인하세요.';
}

function mcCalendarUnifiedManualInputV02Print_(result) {
  result.endedAt = mcCalendarUnifiedManualInputV01Now_();
  Logger.log('JSON_COMPACT_RESULT: ' + JSON.stringify(result));
  return result;
}
