/**
 * PORTAL_CALENDAR_SAFE01B_R10J3B_DETAIL_AUTOFIND_VERIFY_FIX_20260603
 * READ_ONLY verification. No sheet/provider writes.
 * Purpose: verify that R10J1/R10J2 layout, R10I payload, R10G update binding, and R10J extension headers remain connected for selection, event-management, and general/approval schedule scenarios.
 */
function portalCalendarSafe01BR10J3FlowRuntimeVerify(targetCalendarEventId) {
  var build = 'PORTAL_CALENDAR_SAFE01B_R10J3B_DETAIL_AUTOFIND_VERIFY_FIX_20260603';
  var sampleId = String(targetCalendarEventId || '').trim();
  var result = {
    ok: false,
    build: build,
    action: 'portalCalendarSafe01BR10J3FlowRuntimeVerify',
    safety: 'READ_ONLY_RUNTIME_VERIFY_NO_SHEET_PROVIDER_WRITE',
    calendarEventId: sampleId,
    checks: {},
    warnings: [],
    fatal: [],
    headerSummary: {},
    selectionPatchShape: {},
    selectionChangedFields: [],
    eventManagementPatchShape: {},
    generalApprovalPatchShape: {},
    generalChangedFields: [],
    detailShape: {},
    detailAutoFind: {},
    realApplyExecuted: false,
    sheetCreated: false,
    headersAdded: false,
    actualDeleteExecuted: false,
    actualStatusUpdateExecuted: false
  };
  function add(key, ok, fatal) {
    result.checks[key] = !!ok;
    if (!ok) {
      if (fatal) result.fatal.push(key);
      else result.warnings.push(key);
    }
  }
  function raw(name) {
    try { return HtmlService.createTemplateFromFile(name).getRawContent(); }
    catch (e) { result.warnings.push('read failed: ' + name + ' ' + (e && e.message ? e.message : e)); return ''; }
  }
  function has(src, token) { return String(src || '').indexOf(token) >= 0; }
  function text(v) {
    if (v === null || v === undefined) return '';
    var s = String(v).trim();
    if (!s || s === '[]' || s === '{}' || s.toLowerCase() === 'null' || s.toLowerCase() === 'undefined') return '';
    return s;
  }
  function missingFrom(list, must) {
    list = list || [];
    return must.filter(function(k) { return list.indexOf(k) < 0; });
  }
  function clone(obj) {
    var out = {};
    Object.keys(obj || {}).forEach(function(k) { out[k] = obj[k]; });
    return out;
  }

  function uniquePush_(arr, v) {
    v = String(v || '').trim();
    if (v && arr.indexOf(v) < 0) arr.push(v);
  }
  function dateRank_(v) {
    if (!v) return 0;
    if (Object.prototype.toString.call(v) === '[object Date]' && !isNaN(v.getTime())) return v.getTime();
    var s = String(v || '').trim();
    if (!s) return 0;
    var d = new Date(s.replace(' ', 'T'));
    if (!isNaN(d.getTime())) return d.getTime();
    return 0;
  }
  function headerMap_(headers) {
    var hm = {};
    (headers || []).forEach(function(h, i) {
      var k = String(h || '').trim();
      if (k) hm[k] = i;
    });
    return hm;
  }
  function cellText_(v) {
    if (v === null || v === undefined) return '';
    if (Object.prototype.toString.call(v) === '[object Date]' && !isNaN(v.getTime())) {
      var tz = 'Asia/Seoul';
      try { tz = Session.getScriptTimeZone() || 'Asia/Seoul'; } catch (ignore) {}
      return Utilities.formatDate(v, tz, 'yyyy-MM-dd HH:mm:ss');
    }
    return String(v || '').trim();
  }
  function resolveDetailAuto_(requestedId) {
    var probe = {
      requestedId: String(requestedId || '').trim(),
      selectedId: '',
      autoFindUsed: false,
      candidateCount: 0,
      triedIds: [],
      found: false,
      detail: null,
      note: ''
    };
    if (typeof mcCalendarDetailCoreV01GetDetail !== 'function') {
      probe.note = 'detail function missing';
      return probe;
    }
    var ids = [];
    uniquePush_(ids, probe.requestedId);
    try {
      var ss = (typeof mcCalendarDetailCoreV01OpenMaster_ === 'function') ? mcCalendarDetailCoreV01OpenMaster_() : null;
      var candidates = [];
      if (ss) {
        ['MAILCENTER_CalendarEvents', 'CalendarEvents'].forEach(function(sheetName) {
          var sh = ss.getSheetByName(sheetName);
          if (!sh || sh.getLastRow() < 2) return;
          var values = sh.getDataRange().getValues();
          var hm = headerMap_(values[0]);
          if (hm.calendarEventId === undefined) return;
          for (var r = 1; r < values.length; r++) {
            var id = cellText_(values[r][hm.calendarEventId]);
            if (!id) continue;
            var cbt = hm.calendarBusinessType !== undefined ? cellText_(values[r][hm.calendarBusinessType]) : '';
            var cr = hm.changeReason !== undefined ? cellText_(values[r][hm.changeReason]) : '';
            var lcf = hm.lastChangedFields !== undefined ? cellText_(values[r][hm.lastChangedFields]) : '';
            var upd = hm.updatedAt !== undefined ? values[r][hm.updatedAt] : '';
            var cre = hm.createdAt !== undefined ? values[r][hm.createdAt] : '';
            var score = 0;
            if (probe.requestedId && id === probe.requestedId) score += 1000000000000;
            if (cbt === 'SELECTION_PROCESS') score += 1000000000;
            if (cr || lcf) score += 1000000;
            score += dateRank_(upd || cre || '') || r;
            candidates.push({ id: id, score: score, rowNumber: r + 1, sheetName: sheetName });
          }
        });
      }
      candidates.sort(function(a, b) { return b.score - a.score; });
      candidates.slice(0, 25).forEach(function(c) { uniquePush_(ids, c.id); });
    } catch (scanErr) {
      probe.note = 'auto-find scan warning: ' + (scanErr && scanErr.message ? scanErr.message : scanErr);
    }
    probe.candidateCount = ids.length;
    for (var i = 0; i < ids.length; i++) {
      var id = ids[i];
      probe.triedIds.push(id);
      try {
        var detail = mcCalendarDetailCoreV01GetDetail({ calendarEventId: id, verifyMode: 'R10J3B_DETAIL_AUTOFIND_VERIFY' });
        if (detail && detail.ok && (detail.record || detail.event)) {
          probe.selectedId = id;
          probe.autoFindUsed = !!(probe.requestedId && id !== probe.requestedId) || !probe.requestedId;
          probe.found = true;
          probe.detail = detail;
          return probe;
        }
      } catch (detailErr) {
        // Try the next candidate. Detail failures are reported after all candidates fail.
      }
    }
    probe.note = probe.note || 'no detail record found among candidates';
    return probe;
  }
  try {
    var view = raw('MC_CalendarViewV01');

    add('r10j2ScreenLayoutKept', has(view, 'PORTAL_CALENDAR_SAFE01B_R10J2_SCREEN_LAYOUT_POLISH_20260603'), true);
    add('r10j1SafeOpenKept', has(view, 'fhCalendarRestoreDetailModalR10J1') && has(view, '수정 화면을 열 수 없습니다') && has(view, 'PORTAL_CALENDAR_SAFE01B_R10J1_HEADER_MODAL_SAFE_OPEN_20260603'), true);
    add('r10iPayloadKept', has(view, 'fhCalendarSelectionEditPayloadFinalizeR10I') && has(view, 'payload.__r10iSelectionEditPayload'), true);
    add('r10gUpdateBindingKept', (typeof PORTAL_CALENDAR_SAFE01B_R10G_BUSINESS_UPDATE_PATCH_BUILD !== 'undefined') && String(PORTAL_CALENDAR_SAFE01B_R10G_BUSINESS_UPDATE_PATCH_BUILD || '').indexOf('R10G_BUSINESS_UPDATE') >= 0, true);
    add('r10jNoTempFilesInView', !has(view, 'extracted_view') && !has(view, 'extracted_check'), true);
    add('preCouncilTermKept', has(view, '입예협') && !has(view, '<option value="COUNCIL">입대의</option>') && !has(view, "COUNCIL:'입대의'"), true);
    add('eventManagementReadOnlyNoticeKept', has(view, '행사관리 원장 조회형') && has(view, '원본 수정은 ERP 행사관리 화면에서 처리'), true);
    add('generalApprovalDisplayKept', has(view, '전자결재 ID') && has(view, '캘린더 표시 방식') && has(view, '개인/휴무 구분'), true);

    var updatable = (typeof mcCalendarOperationHubV01UpdatableFields_ === 'function') ? mcCalendarOperationHubV01UpdatableFields_() : [];
    var headers = (typeof mcCalendarOperationHubV01CalendarHeaders_ === 'function') ? mcCalendarOperationHubV01CalendarHeaders_() : [];
    var extMust = [
      'calendarBusinessType','businessStage','scheduleSubType','selectionId','eventId','approvalId',
      'complexName','complexRegion','householdCount','moveInExpectedAt','selectionPossibility',
      'contactTargetType','contactName','contactPhone','contactResponseStatus','proposalStatus','conditionStatus','competitionStatus','nextAction','nextCheckAt','meetingTimelineJson',
      'infoSource','expectedFairPeriod','previousFairHistory','competitorContactYn','internalOwnerName','internalOwnerEmployeeId','internalDepartmentCode','internalOrganizerRole','followUpOwnerName',
      'externalContactRole','externalContactEmail','externalOrganization','decisionInfluenceLevel','lastContactAt',
      'presentationEnabled','presentationAt','presentationPlace','presentationMethod','presentationMainSpeaker','presentationSubSpeaker','presentationMaterialOwner','presentationConditionOwner','presentationOperationOwner','presentationSettlementOwner','presentationParticipantsJson','externalPresentationAttendeesJson','presentationTarget','presentationMaterials','presentationRequestItems','presentationResult',
      'expectedFairAt','venueNegotiationStatus','operationCondition','promotionCondition','vendorCondition','residentBenefitCondition','managementRequest','preCouncilRequest','feelhausProposalCondition','negotiationRisk',
      'competitorNames','competitorCondition','feelhausStrength','concernItems','decisionMaker','decisionDueAt','actionType','actionOwner','actionDueAt','actionPriority','actionDoneYn',
      'selectionStatus','selectedAt','rejectionReason','holdReason','reconnectAt',
      'agreementRequired','agreementAt','agreementPlace','agreementMethod','agreementAgenda','agreementCondition','agreementResult','agreementDocumentRequired','agreementSignRequired','agreementFeelhausAttendeesJson','agreementExternalAttendeesJson','agreementStatus',
      'attachmentMemo','scheduleWorkType','scheduleTargetType','calendarSourceType','approvalRequired','approvalStatus','approvalRequester','approvalApprover','approvalApprovedAt','calendarVisibilityMode','displayPrivacyMode','connectionStatus','connectionTargetType','personalScheduleType'
    ];
    result.headerSummary = {
      updatableCount: updatable.length,
      headerCount: headers.length,
      missingUpdatable: missingFrom(updatable, extMust),
      missingHeaders: missingFrom(headers, extMust)
    };
    add('r10jExtUpdatableFieldsReady', result.headerSummary.missingUpdatable.length === 0, true);
    add('r10jExtHeadersReady', result.headerSummary.missingHeaders.length === 0, true);
    add('r10jExtFieldCountReasonable', result.headerSummary.updatableCount >= 110 && result.headerSummary.headerCount >= 120, true);

    var selectionBefore = {
      calendarEventId: sampleId,
      calendarBusinessType: 'GENERAL_SCHEDULE',
      businessStage: '',
      selectionId: '',
      complexName: '',
      contactName: '박정준',
      contactPhone: '010-1234-2585',
      presentationMainSpeaker: '',
      agreementRequired: '',
      agreementStatus: '',
      meetingTimelineJson: '[{"index":1,"text":"1차 사전영업"}]',
      title: 'R10J3 이전',
      startAt: '2026-06-05 10:00:00',
      endAt: '2026-06-05 11:00:00'
    };
    var selectionPayload = {
      calendarBusinessType: 'SELECTION_PROCESS',
      businessStage: '제안/프레젠테이션',
      selectionId: 'SEL-R10J3-VERIFY',
      complexName: '동탄센트리얼1',
      complexRegion: '동탄',
      householdCount: '1234',
      moveInExpectedAt: '2026년 12월',
      selectionPossibility: '높음',
      contactTargetType: 'PRE_COUNCIL_CHAIR',
      contactName: '김태을',
      contactPhone: '010-9999-0000',
      contactResponseStatus: '관심 있음',
      proposalStatus: '제안서 발송완료',
      conditionStatus: '협의중',
      competitionStatus: '경쟁중',
      nextAction: '협약식 일정 조율',
      nextCheckAt: '2026-06-07T10:30',
      infoSource: '입예협',
      internalOwnerName: '이용필',
      internalOrganizerRole: '총괄',
      externalContactRole: '회장',
      decisionInfluenceLevel: '결정권자',
      presentationEnabled: '예정',
      presentationAt: '2026-06-08T14:00',
      presentationMethod: '방문 발표',
      presentationMainSpeaker: '이용필',
      presentationSubSpeaker: '최유라',
      presentationMaterialOwner: '최유라',
      presentationConditionOwner: '이용필',
      presentationOperationOwner: '현장팀',
      presentationSettlementOwner: '정산팀',
      presentationTarget: '입예협 회장단',
      presentationMaterials: '박람회 운영 제안서\n조건표',
      presentationRequestItems: '홍보 조건 재정리',
      presentationResult: '추가 검토',
      expectedFairAt: '2026-08-15T09:00',
      venueNegotiationStatus: '장소 협의중',
      operationCondition: '운영 조건 검토',
      promotionCondition: '입예협 공지 + 카페 공지',
      preCouncilRequest: '입예협 요청사항 반영',
      agreementRequired: '필요',
      agreementAt: '2026-06-12T11:00',
      agreementMethod: '방문 협약',
      agreementAgenda: '행사 일정 확정\n홍보 방식 확정',
      agreementStatus: '협약식예정',
      agreementResult: '추가 협의 필요',
      selectionMeetingTimelineText: '1차 사전영업\n2차 프레젠테이션 예정\n3차 협약식 조율',
      changeReason: 'R10J3 선정 과정 흐름 검증'
    };
    var selectionPatch = (typeof mcCalendarOperationHubV01NormalizePatch_ === 'function') ? mcCalendarOperationHubV01NormalizePatch_(selectionPayload, selectionBefore, 'verify@feelhaus.test', '2026-06-03 21:00:00') : {};
    result.selectionPatchShape = {
      calendarBusinessType: selectionPatch.calendarBusinessType || '',
      businessStage: selectionPatch.businessStage || '',
      selectionId: selectionPatch.selectionId || '',
      complexName: selectionPatch.complexName || '',
      contactTargetType: selectionPatch.contactTargetType || '',
      contactName: selectionPatch.contactName || '',
      contactPhone: selectionPatch.contactPhone || '',
      nextCheckAt: selectionPatch.nextCheckAt || '',
      presentationMainSpeaker: selectionPatch.presentationMainSpeaker || '',
      agreementRequired: selectionPatch.agreementRequired || '',
      agreementStatus: selectionPatch.agreementStatus || '',
      meetingTimelineJson: selectionPatch.meetingTimelineJson || ''
    };
    add('selectionFlowNormalizeReady', result.selectionPatchShape.calendarBusinessType === 'SELECTION_PROCESS' && result.selectionPatchShape.contactName === '김태을' && result.selectionPatchShape.presentationMainSpeaker === '이용필' && result.selectionPatchShape.agreementRequired === '필요', true);
    add('selectionTimelineNormalizeReady', String(result.selectionPatchShape.meetingTimelineJson || '').indexOf('협약식 조율') >= 0, true);
    add('selectionNextCheckAtNormalized', result.selectionPatchShape.nextCheckAt === '2026-06-07 10:30:00', true);
    var selectionAfter = clone(selectionBefore);
    Object.keys(selectionPatch).forEach(function(k) { selectionAfter[k] = selectionPatch[k]; });
    result.selectionChangedFields = (typeof mcCalendarOperationHubV01ChangedFields_ === 'function') ? mcCalendarOperationHubV01ChangedFields_(selectionBefore, selectionAfter) : [];
    add('selectionChangedFieldsReady', result.selectionChangedFields.indexOf('contactName') >= 0 && result.selectionChangedFields.indexOf('presentationMainSpeaker') >= 0 && result.selectionChangedFields.indexOf('agreementRequired') >= 0 && result.selectionChangedFields.indexOf('meetingTimelineJson') >= 0, true);

    var eventPatch = (typeof mcCalendarOperationHubV01NormalizePatch_ === 'function') ? mcCalendarOperationHubV01NormalizePatch_({
      calendarBusinessType: 'EVENT_MANAGEMENT',
      businessStage: '행사운영',
      eventId: 'EVNT-R10J3-VERIFY',
      fairName: '동탄센트리얼 입주박람회',
      connectionStatus: '행사관리 원장 연결',
      connectionTargetType: 'eventId',
      changeReason: 'R10J3 행사관리 조회형 연결 검증'
    }, { calendarBusinessType: 'GENERAL_SCHEDULE', eventId: '', fairName: '' }, 'verify@feelhaus.test', '2026-06-03 21:00:00') : {};
    result.eventManagementPatchShape = {
      calendarBusinessType: eventPatch.calendarBusinessType || '',
      eventId: eventPatch.eventId || '',
      fairName: eventPatch.fairName || '',
      connectionStatus: eventPatch.connectionStatus || ''
    };
    add('eventManagementLinkNormalizeReady', result.eventManagementPatchShape.calendarBusinessType === 'EVENT_MANAGEMENT' && result.eventManagementPatchShape.eventId === 'EVNT-R10J3-VERIFY', true);

    var generalBefore = { calendarBusinessType: 'GENERAL_SCHEDULE', approvalId: '', calendarVisibilityMode: '', displayPrivacyMode: '', personalScheduleType: '', title: '일반 일정' };
    var generalPayload = {
      calendarBusinessType: 'GENERAL_SCHEDULE',
      scheduleSubType: 'PERSONAL_BLOCK',
      scheduleWorkType: '개인/비업무',
      scheduleTargetType: '내부 직원',
      calendarSourceType: '전자결재 연동',
      approvalRequired: '승인완료',
      approvalId: 'APR-R10J3-VERIFY',
      approvalStatus: '승인완료',
      approvalRequester: '김태을',
      approvalApprover: '이용필',
      approvalApprovedAt: '2026-06-10T09:00',
      calendarVisibilityMode: '담당자만',
      displayPrivacyMode: '부재만 표시',
      personalScheduleType: '연차',
      connectionStatus: '전자결재 연결',
      connectionTargetType: 'approvalId',
      changeReason: 'R10J3 일반/개인/전자결재 흐름 검증'
    };
    var generalPatch = (typeof mcCalendarOperationHubV01NormalizePatch_ === 'function') ? mcCalendarOperationHubV01NormalizePatch_(generalPayload, generalBefore, 'verify@feelhaus.test', '2026-06-03 21:00:00') : {};
    result.generalApprovalPatchShape = {
      calendarBusinessType: generalPatch.calendarBusinessType || '',
      scheduleSubType: generalPatch.scheduleSubType || '',
      approvalId: generalPatch.approvalId || '',
      approvalRequired: generalPatch.approvalRequired || '',
      calendarVisibilityMode: generalPatch.calendarVisibilityMode || '',
      displayPrivacyMode: generalPatch.displayPrivacyMode || '',
      personalScheduleType: generalPatch.personalScheduleType || '',
      connectionTargetType: generalPatch.connectionTargetType || ''
    };
    add('generalApprovalNormalizeReady', result.generalApprovalPatchShape.calendarBusinessType === 'GENERAL_SCHEDULE' && result.generalApprovalPatchShape.approvalId === 'APR-R10J3-VERIFY' && result.generalApprovalPatchShape.displayPrivacyMode === '부재만 표시', true);
    var generalAfter = clone(generalBefore);
    Object.keys(generalPatch).forEach(function(k) { generalAfter[k] = generalPatch[k]; });
    result.generalChangedFields = (typeof mcCalendarOperationHubV01ChangedFields_ === 'function') ? mcCalendarOperationHubV01ChangedFields_(generalBefore, generalAfter) : [];
    add('generalChangedFieldsReady', result.generalChangedFields.indexOf('approvalId') >= 0 && result.generalChangedFields.indexOf('displayPrivacyMode') >= 0 && result.generalChangedFields.indexOf('personalScheduleType') >= 0, true);

    var detailProbe = resolveDetailAuto_(sampleId);
    result.detailAutoFind = {
      requestedId: detailProbe.requestedId,
      selectedId: detailProbe.selectedId,
      autoFindUsed: detailProbe.autoFindUsed,
      candidateCount: detailProbe.candidateCount,
      triedIds: detailProbe.triedIds.slice(0, 10),
      found: detailProbe.found,
      note: detailProbe.note
    };
    if (detailProbe.selectedId) result.calendarEventId = detailProbe.selectedId;
    var detail = detailProbe.detail;
    var record = (detail && (detail.record || detail.event)) || {};
    var summary = (detail && detail.changeHistory) || {};
    result.detailShape = {
      ok: !!(detail && detail.ok),
      sourceSheet: detail && detail.sourceSheet || '',
      rowNumber: detail && detail.rowNumber || 0,
      hasRecord: !!(detail && detail.record),
      hasEvent: !!(detail && detail.event),
      calendarBusinessType: text(record.calendarBusinessType),
      businessStage: text(record.businessStage),
      contactName: text(record.contactName),
      changeReason: text(summary.changeReason) || text(record.changeReason) || text(record.statusReason),
      lastChangedFields: text(summary.lastChangedFields) || text(record.lastChangedFields)
    };
    add('detailRuntimeReady', typeof mcCalendarDetailCoreV01GetDetail === 'function' && !!(detail && detail.ok) && !!(detail && detail.record), true);
    add('detailChangeHistoryStillReady', !!(detail && detail.changeHistory) && !!result.detailShape.changeReason && !!result.detailShape.lastChangedFields, true);

    add('r7dAutosyncKept', typeof portalCalendarExternalAutoSyncV01 === 'function' && (typeof portalCalendarExternalAutoSyncV01R7DMarker_ === 'function' || typeof portalCalendarExternalAutoSyncV01R7DRuntimeVerifyMarker_ === 'function'), false);
    add('r8ViewKept', has(view, 'PORTAL_CALENDAR_SAFE01B_R8_VIEW_DISPLAY_CLEAN_20260602'), true);
    add('r9cStrictUpdateGateKept', typeof mcCalendarOperationHubV01ResolveStrictUpdateActorR9C_ === 'function' || typeof mcCalendarOperationHubV01R9CStrictUpdateGateMarker_ === 'function', true);
    add('r11NotAdvancedByR10J3', !has(view, 'PORTAL_CALENDAR_SAFE01B_R11B') && !has(view, 'PORTAL_CALENDAR_SAFE01B_R12'), true);
    add('noLoginGateRequired', !has(view, 'sid 필수') && !has(view, 'loginGateRequired'), true);

    result.ok = result.fatal.length === 0;
    result.message = result.ok ? 'SAFE-01B R10J3 flow runtime verification passed.' : 'SAFE-01B R10J3 verification failed. Check fatal items.';
  } catch (err) {
    result.ok = false;
    result.fatal.push('exception');
    result.message = err && err.message ? err.message : String(err);
    result.stack = err && err.stack ? err.stack : '';
  }
  Logger.log('JSON_COMPACT_RESULT: ' + JSON.stringify(result));
  return result;
}


function portalCalendarSafe01BR10J3BFlowRuntimeVerify(targetCalendarEventId) {
  return portalCalendarSafe01BR10J3FlowRuntimeVerify(targetCalendarEventId);
}
