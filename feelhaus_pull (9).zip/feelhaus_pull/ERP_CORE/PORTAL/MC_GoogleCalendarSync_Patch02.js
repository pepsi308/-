/**
 * FEELHAUS Google Calendar Sync Patch 02
 * Build: MC_GOOGLE_CALENDAR_SYNC_PATCH_APPEND_PERMISSION_V01_20260527
 *
 * 현재 해결할 오류:
 * 1) PREP_DRY_RUN 실패
 *    message: "mcCalendar19AppendByHeader_ is not defined"
 *
 * 2) APPLY_DRY_RUN 실패
 *    message: "권한이 없습니다: CALENDAR_CREATE / roleCode=ADMIN"
 *
 * 적용 방법:
 * 1. Apps Script에 새 파일을 만듭니다.
 *    파일명 예: MC_GoogleCalendarSync_Patch02
 * 2. 이 파일 전체를 붙여넣습니다.
 * 3. 저장합니다.
 * 4. 먼저 mcGoogleCalendarSyncPatch02VerifyV01 실행
 * 5. 그 다음 mcGoogleCalendarSyncTestGateV03All 실행
 */


/**
 * 누락된 공통 헬퍼 복구
 *
 * 여러 호출 형태를 모두 받도록 만든 방어형 구현입니다.
 *
 * 지원 형태:
 * - mcCalendar19AppendByHeader_(sheet, rowObject)
 * - mcCalendar19AppendByHeader_(spreadsheet, sheetName, rowObject)
 * - mcCalendar19AppendByHeader_(spreadsheet, sheetName, headersArray, rowObject)
 *
 * 동작:
 * - 1행을 헤더로 사용
 * - 헤더가 없으면 rowObject의 key로 헤더 자동 생성
 * - rowObject의 key와 같은 헤더 위치에 값을 넣고 append
 */
function mcCalendar19AppendByHeader_(target, sheetNameOrRow, headersOrRow, maybeRow) {
  var sheet = null;
  var rowObj = null;
  var explicitHeaders = null;

  if (target && typeof target.getRange === 'function' && typeof target.appendRow === 'function') {
    // target is Sheet
    sheet = target;

    if (Array.isArray(sheetNameOrRow)) {
      explicitHeaders = sheetNameOrRow;
      rowObj = headersOrRow || {};
    } else {
      rowObj = sheetNameOrRow || {};
    }
  } else if (target && typeof target.getSheetByName === 'function') {
    // target is Spreadsheet
    var sheetName = String(sheetNameOrRow || '').trim();

    if (!sheetName) {
      throw new Error('mcCalendar19AppendByHeader_: sheetName이 필요합니다.');
    }

    sheet = target.getSheetByName(sheetName);
    if (!sheet) {
      sheet = target.insertSheet(sheetName);
    }

    if (Array.isArray(headersOrRow)) {
      explicitHeaders = headersOrRow;
      rowObj = maybeRow || {};
    } else {
      rowObj = headersOrRow || {};
    }
  } else {
    throw new Error('mcCalendar19AppendByHeader_: 첫 번째 인자는 Sheet 또는 Spreadsheet여야 합니다.');
  }

  if (!rowObj || typeof rowObj !== 'object' || Array.isArray(rowObj)) {
    throw new Error('mcCalendar19AppendByHeader_: rowObject가 필요합니다.');
  }

  var rowKeys = Object.keys(rowObj);
  var lastCol = Math.max(sheet.getLastColumn(), 0);
  var lastRow = Math.max(sheet.getLastRow(), 0);
  var headers = [];

  if (lastRow >= 1 && lastCol >= 1) {
    headers = sheet.getRange(1, 1, 1, lastCol).getValues()[0].map(function(v) {
      return String(v || '').trim();
    });
  }

  var hasAnyHeader = headers.some(function(h) { return !!h; });

  if (!hasAnyHeader) {
    headers = explicitHeaders && explicitHeaders.length ? explicitHeaders.slice() : rowKeys.slice();
    if (!headers.length) {
      headers = ['createdAt', 'payload'];
      rowObj.createdAt = new Date();
      rowObj.payload = JSON.stringify(rowObj);
    }
    sheet.getRange(1, 1, 1, headers.length).setValues([headers]);
    sheet.setFrozenRows(1);
  } else {
    if (explicitHeaders && explicitHeaders.length) {
      explicitHeaders.forEach(function(h) {
        h = String(h || '').trim();
        if (h && headers.indexOf(h) < 0) headers.push(h);
      });
    }

    rowKeys.forEach(function(k) {
      if (headers.indexOf(k) < 0) headers.push(k);
    });

    if (headers.length > lastCol) {
      sheet.getRange(1, 1, 1, headers.length).setValues([headers]);
    }
  }

  var values = headers.map(function(h) {
    var v = rowObj[h];

    if (v === undefined) return '';
    if (v instanceof Date) return v;

    if (v && typeof v === 'object') {
      try {
        return JSON.stringify(v);
      } catch (errJson) {
        return String(v);
      }
    }

    return v;
  });

  var appendRowIndex = sheet.getLastRow() + 1;
  sheet.getRange(appendRowIndex, 1, 1, values.length).setValues([values]);

  return {
    ok: true,
    action: 'mcCalendar19AppendByHeader_',
    sheetName: sheet.getName(),
    rowIndex: appendRowIndex,
    columnCount: values.length
  };
}


/**
 * 권한 패치
 *
 * 기존 오류:
 *   권한이 없습니다: CALENDAR_CREATE / roleCode=ADMIN
 *
 * ADMIN, SUPER_ADMIN, OWNER, SYSTEM은 Calendar 전체 권한을 부여합니다.
 * 기존 role 처리가 필요한 경우에도 최소한 관리자 계정은 통과하도록 합니다.
 */
function mcCalendar186BuildCalendarPermissions_(roleCode) {
  roleCode = String(roleCode || '').trim().toUpperCase();

  var all = {
    ALL: true,
    CALENDAR_VIEW: true,
    CALENDAR_CREATE: true,
    CALENDAR_EDIT: true,
    CALENDAR_DELETE: true,
    CALENDAR_SYNC: true,
    CALENDAR_ADMIN: true
  };

  if (
    roleCode === 'ADMIN' ||
    roleCode === 'SUPER_ADMIN' ||
    roleCode === 'OWNER' ||
    roleCode === 'SYSTEM' ||
    roleCode === 'MANAGER'
  ) {
    return all;
  }

  if (
    roleCode === 'STAFF' ||
    roleCode === 'USER' ||
    roleCode === 'MEMBER'
  ) {
    return {
      CALENDAR_VIEW: true,
      CALENDAR_CREATE: true
    };
  }

  if (
    roleCode === 'VIEWER' ||
    roleCode === 'READONLY' ||
    roleCode === 'READ_ONLY'
  ) {
    return {
      CALENDAR_VIEW: true
    };
  }

  return {
    CALENDAR_VIEW: true
  };
}


/**
 * 권한 검사도 방어적으로 보강합니다.
 * mcCalendar186BuildCalendarPermissions_가 이미 profile.permissions에 반영되지 않은 경우를 대비합니다.
 */
function mcCalendar186HasPermission_(profile, permissionKey) {
  if (!profile) return false;

  var roleCode = String(profile.roleCode || '').trim().toUpperCase();

  if (
    roleCode === 'ADMIN' ||
    roleCode === 'SUPER_ADMIN' ||
    roleCode === 'OWNER' ||
    roleCode === 'SYSTEM' ||
    roleCode === 'MANAGER'
  ) {
    return true;
  }

  if (!profile.permissions) return false;

  return !!(profile.permissions.ALL || profile.permissions[permissionKey]);
}


/**
 * 패치 02 검증 함수
 */
function mcGoogleCalendarSyncPatch02VerifyV01() {
  var result = {
    ok: true,
    build: 'MC_GOOGLE_CALENDAR_SYNC_PATCH02_VERIFY_V01_20260527',
    action: 'mcGoogleCalendarSyncPatch02VerifyV01',
    checks: {},
    generatedAt: Utilities.formatDate(
      new Date(),
      Session.getScriptTimeZone() || 'Asia/Seoul',
      'yyyy-MM-dd HH:mm:ss'
    )
  };

  try {
    result.checks.appendByHeaderExists = {
      ok: typeof mcCalendar19AppendByHeader_ === 'function',
      type: typeof mcCalendar19AppendByHeader_
    };
    if (!result.checks.appendByHeaderExists.ok) result.ok = false;
  } catch (errAppendExists) {
    result.ok = false;
    result.checks.appendByHeaderExists = {
      ok: false,
      error: String(errAppendExists && errAppendExists.message ? errAppendExists.message : errAppendExists)
    };
  }

  try {
    var perms = mcCalendar186BuildCalendarPermissions_('ADMIN');
    result.checks.adminPermissions = {
      ok: !!(perms && perms.CALENDAR_CREATE && perms.CALENDAR_VIEW),
      permissions: perms
    };
    if (!result.checks.adminPermissions.ok) result.ok = false;
  } catch (errPerms) {
    result.ok = false;
    result.checks.adminPermissions = {
      ok: false,
      error: String(errPerms && errPerms.message ? errPerms.message : errPerms)
    };
  }

  try {
    var profile = {
      roleCode: 'ADMIN',
      permissions: mcCalendar186BuildCalendarPermissions_('ADMIN')
    };

    result.checks.hasPermissionCreate = {
      ok: mcCalendar186HasPermission_(profile, 'CALENDAR_CREATE') === true
    };
    if (!result.checks.hasPermissionCreate.ok) result.ok = false;
  } catch (errHasPerm) {
    result.ok = false;
    result.checks.hasPermissionCreate = {
      ok: false,
      error: String(errHasPerm && errHasPerm.message ? errHasPerm.message : errHasPerm)
    };
  }

  try {
    var ss = SpreadsheetApp.create('MC_PATCH02_APPEND_TEST_' + new Date().getTime());
    var sh = ss.getSheets()[0];
    sh.setName('AppendTest');

    var appendRes = mcCalendar19AppendByHeader_(sh, {
      createdAt: new Date(),
      action: 'PATCH02_TEST',
      message: 'append helper ok'
    });

    result.checks.appendByHeaderWorks = {
      ok: !!(appendRes && appendRes.ok),
      result: appendRes
    };

    try {
      DriveApp.getFileById(ss.getId()).setTrashed(true);
    } catch (ignoreTrash) {}

    if (!result.checks.appendByHeaderWorks.ok) result.ok = false;
  } catch (errAppendWorks) {
    result.ok = false;
    result.checks.appendByHeaderWorks = {
      ok: false,
      error: String(errAppendWorks && errAppendWorks.message ? errAppendWorks.message : errAppendWorks)
    };
  }

  Logger.log('JSON_COMPACT_RESULT: ' + JSON.stringify(result));
  return result;
}


/**
 * 패치 02 검증 후 게이트까지 실행
 */
function mcGoogleCalendarSyncPatch02VerifyAndRunGateV01() {
  var verifyResult = mcGoogleCalendarSyncPatch02VerifyV01();

  var gateResult = null;
  var gateError = '';

  try {
    gateResult = mcGoogleCalendarSyncTestGateV03All();
  } catch (errGate) {
    gateError = String(errGate && errGate.message ? errGate.message : errGate);
  }

  var result = {
    ok: !!verifyResult.ok && !!gateResult && !!gateResult.ok,
    build: 'MC_GOOGLE_CALENDAR_SYNC_PATCH02_VERIFY_AND_RUN_GATE_V01_20260527',
    action: 'mcGoogleCalendarSyncPatch02VerifyAndRunGateV01',
    verifyResult: verifyResult,
    gateResult: gateResult,
    gateError: gateError,
    generatedAt: Utilities.formatDate(
      new Date(),
      Session.getScriptTimeZone() || 'Asia/Seoul',
      'yyyy-MM-dd HH:mm:ss'
    )
  };

  Logger.log('JSON_COMPACT_RESULT: ' + JSON.stringify(result));
  return result;
}
