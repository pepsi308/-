/**
 * FEELHAUS MailCenter Dashboard V04 Clean Rollback V02
 * Build: MAILCENTER_DASHBOARD_V04_CLEAN_ROLLBACK_V02_20260520
 *
 * Purpose:
 * - Dashboard V04 화면 오염 복구 유지
 * - 대시보드 내부 왼쪽 메뉴 절대주소 고정
 * - 계정별 테스트 발송 버튼 클릭 시 수신자 이메일을 항상 교체
 * - 다른 화면 Core/Router는 건드리지 않음
 */

var MAILCENTER_DASHBOARD_V04_CLEAN_ROLLBACK_BUILD = 'MAILCENTER_DASHBOARD_V04_CLEAN_ROLLBACK_V02_20260520';
var MAILCENTER_DASHBOARD_V04_CLEAN_ROLLBACK_SETUP_DB_ID = '17VMSpgSZCvIrUlgcw8yCNcnl8WQWo2IcRf5tDCcuJGM';
var MAILCENTER_DASHBOARD_V04_CLEAN_ROLLBACK_CONFIG_SHEET = 'SystemConfig';
var MAILCENTER_DASHBOARD_V04_CLEAN_ROLLBACK_WEBAPP_URL = 'https://script.google.com/macros/s/AKfycbxCyFE7zf4vE8nsfjOeWX0pC56SqU84gm8ie8Txa3qHQGEusJCZeljzCdYeOmZxUVYvjA/exec';

function runMcDashboardV04CleanRollbackSmoke() {
  var result = {
    ok: false,
    build: MAILCENTER_DASHBOARD_V04_CLEAN_ROLLBACK_BUILD,
    action: 'runMcDashboardV04CleanRollbackSmoke',
    generatedAt: mcDashboardV04CleanNow_(),
    message: '',
    checks: []
  };

  try {
    var data = mcDashboardV04CleanGetData();
    result.checks.push({ key: 'HandleGetReady', ok: typeof mcDashboardShellV04HandleGet === 'function', message: 'Dashboard V04 핸들러 확인' });
    result.checks.push({ key: 'DataReady', ok: !!data && !!data.ok, message: 'Dashboard V04 데이터 조회 확인' });
    result.checks.push({ key: 'AccountsReady', ok: !!data && Array.isArray(data.accounts), message: '계정 현황 목록 확인: ' + ((data.accounts || []).length) });
    result.checks.push({ key: 'RecentLogsReady', ok: !!data && Array.isArray(data.recentLogs), message: '최근 발송 로그 목록 확인: ' + ((data.recentLogs || []).length) });
    result.checks.push({ key: 'SendBridgeReady', ok: typeof mcDashboardV04CleanSendTest === 'function', message: '대시보드 테스트 발송 브릿지 확인' });
    result.checks.push({ key: 'WebAppUrlReady', ok: !!MAILCENTER_DASHBOARD_V04_CLEAN_ROLLBACK_WEBAPP_URL, message: '대시보드 메뉴 절대주소 확인' });

    result.ok = result.checks.every(function(c) { return !!c.ok; });
    result.message = result.ok ? 'Dashboard V04 Clean Rollback V02 준비 완료' : 'Dashboard V04 Clean Rollback V02 점검 필요';
  } catch (err) {
    result.ok = false;
    result.message = String(err && err.message ? err.message : err);
  }

  mcDashboardV04CleanLog_(result);
  return result;
}

function mcDashboardShellV04HandleGet(e) {
  var t = HtmlService.createTemplateFromFile('MC_DashboardViewV04');
  t.build = MAILCENTER_DASHBOARD_V04_CLEAN_ROLLBACK_BUILD;
  t.webAppUrl = MAILCENTER_DASHBOARD_V04_CLEAN_ROLLBACK_WEBAPP_URL;
  t.initialJson = JSON.stringify(mcDashboardV04CleanGetData());

  return t.evaluate()
    .setTitle('FEELHAUS MailCenter Dashboard')
    .setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL);
}

function mcDashboardV04CleanGetData() {
  var result = {
    ok: false,
    build: MAILCENTER_DASHBOARD_V04_CLEAN_ROLLBACK_BUILD,
    action: 'mcDashboardV04CleanGetData',
    generatedAt: mcDashboardV04CleanNow_(),
    message: '',
    summary: { totalAccounts: 0, activeAccounts: 0, connectedAccounts: 0, hqAccounts: 0, vendorAccounts: 0, todaySent: 0 },
    accounts: [],
    recentLogs: []
  };

  try {
    var ss = mcDashboardV04CleanOpenMaster_().ss;
    var accountRows = mcDashboardV04CleanReadSheet_(ss, 'MailCenter_Accounts');
    var oauthMap = mcDashboardV04CleanReadOAuthMap_(ss);
    var logRows = mcDashboardV04CleanReadSheet_(ss, 'MailCenter_SendLogs');

    var accounts = accountRows.map(function(r) {
      var email = mcDashboardV04CleanPick_(r, ['emailAddress','accountEmail','mailAddress','email']);
      var ownerType = mcDashboardV04CleanPick_(r, ['ownerType','accountOwnerType','ownerRole','roleCode']);
      var purpose = mcDashboardV04CleanPick_(r, ['accountPurpose','purpose','roleCode','mailPurpose']);
      var vendorId = mcDashboardV04CleanPick_(r, ['vendorId']);
      var status = mcDashboardV04CleanPick_(r, ['accountStatus','status']);
      var oauth = oauthMap[String(mcDashboardV04CleanPick_(r, ['mailAccountId','accountId']) || '')] || oauthMap[String(email || '')] || oauthMap[String(email || '').toLowerCase()] || {};
      var connection = oauth.oauthStatus || mcDashboardV04CleanPick_(r, ['connectionStatus','authStatus','oauthStatus']);
      var isDefault = mcDashboardV04CleanPick_(r, ['isDefault','defaultYn','defaultAccount']);
      var canSend = mcDashboardV04CleanPick_(r, ['canSend','sendEnabled','sendAvailable']);
      var lastConnectedAt = mcDashboardV04CleanPick_(r, ['lastConnectedAt','connectedAt','updatedAt']);
      var displayName = mcDashboardV04CleanPick_(r, ['displayName','ownerName','accountName','memo']);

      return {
        mailAccountId: mcDashboardV04CleanPick_(r, ['mailAccountId','accountId']),
        typeLabel: mcDashboardV04CleanTypeLabel_(ownerType, purpose, vendorId),
        emailAddress: email,
        ownerName: displayName || email,
        ownerType: ownerType,
        roleCode: purpose || ownerType,
        isDefault: mcDashboardV04CleanBoolLabel_(isDefault),
        accountStatus: status || 'ACTIVE',
        connectionStatus: connection || '',
        connectorMailAccountId: oauth.connectorMailAccountId || '',
        lastConnectedAt: oauth.lastConnectedAt || lastConnectedAt,
        canSend: mcDashboardV04CleanCanSend_(canSend, status, connection)
      };
    }).filter(function(a) { return !!a.emailAddress; });

    var recentLogs = logRows.map(function(r) {
      return {
        createdAt: mcDashboardV04CleanPick_(r, ['createdAt','requestedAt','sentAt']),
        fromEmail: mcDashboardV04CleanPick_(r, ['fromEmail','senderEmail','mailFrom']),
        toEmail: mcDashboardV04CleanPick_(r, ['toEmail','recipientEmail','mailTo']),
        subject: mcDashboardV04CleanPick_(r, ['subject']),
        sendStatus: mcDashboardV04CleanPick_(r, ['sendStatus','status']),
        statusReason: mcDashboardV04CleanPick_(r, ['statusReason','reason']),
        gmailMessageId: mcDashboardV04CleanPick_(r, ['gmailMessageId'])
      };
    }).filter(function(x) {
      return x.createdAt || x.fromEmail || x.toEmail || x.subject || x.sendStatus;
    }).sort(function(a, b) {
      return String(b.createdAt || '').localeCompare(String(a.createdAt || ''));
    }).slice(0, 10);

    var today = Utilities.formatDate(new Date(), Session.getScriptTimeZone() || 'Asia/Seoul', 'yyyy-MM-dd');
    result.summary.totalAccounts = accounts.length;
    result.summary.activeAccounts = accounts.filter(function(a) { return String(a.accountStatus).toUpperCase() === 'ACTIVE'; }).length;
    result.summary.connectedAccounts = accounts.filter(function(a) { return String(a.connectionStatus).toUpperCase() === 'CONNECTED'; }).length;
    result.summary.hqAccounts = accounts.filter(function(a) { return String(a.ownerType).indexOf('HQ') >= 0 || String(a.roleCode).indexOf('HQ') >= 0; }).length;
    result.summary.vendorAccounts = accounts.filter(function(a) { return String(a.ownerType).indexOf('VENDOR') >= 0 || String(a.roleCode).indexOf('VENDOR') >= 0; }).length;
    result.summary.todaySent = recentLogs.filter(function(l) { return String(l.createdAt || '').indexOf(today) === 0 && String(l.sendStatus).toUpperCase() === 'SENT'; }).length;

    result.accounts = accounts;
    result.recentLogs = recentLogs;
    result.ok = true;
    result.message = 'Dashboard V04 Clean 데이터 조회 완료';
  } catch (err) {
    result.ok = false;
    result.message = String(err && err.message ? err.message : err);
  }

  return mcDashboardV04CleanSafe_(result);
}

function mcDashboardShellV04GetInitialData() {
  return mcDashboardV04CleanGetData();
}

function mcDashboardV04CleanSendTest(payload) {
  var result = { ok: false, build: MAILCENTER_DASHBOARD_V04_CLEAN_ROLLBACK_BUILD, action: 'mcDashboardV04CleanSendTest', generatedAt: mcDashboardV04CleanNow_(), message: '', tried: [], sendResult: null };

  try {
    var p = payload || {};
    if (!String(p.toEmail || '').trim()) throw new Error('수신자 이메일이 필요합니다.');

    var sendPayload = {
      mailAccountId: String(p.mailAccountId || '').trim(),
      fromEmail: String(p.fromEmail || '').trim(),
      toEmail: String(p.toEmail || '').trim(),
      subject: String(p.subject || '[FEELHAUS] 이메일 테스트 발송입니다.'),
      body: String(p.body || '안녕하세요.\nFEELHAUS MailCenter 테스트 발송입니다.\n정상적으로 수신되면 회신 부탁드립니다.\n감사합니다.'),
      attachments: []
    };

    var names = ['mcComposeCoreV01Send','mcDriveLinkAttachmentV01SendWithLinks','mailCenterSendTestCoreV01Send','mcSendTestCoreV01Send','mcDashboardSendV05Send','mcDashboardSendShellV05Send'];
    var last = null;
    for (var i = 0; i < names.length; i++) {
      var name = names[i];
      if (typeof this[name] !== 'function') continue;
      result.tried.push(name);
      try {
        var sent = this[name](sendPayload);
        last = sent;
        if (sent && sent.ok) {
          result.ok = true;
          result.message = '테스트 발송 완료';
          result.sendResult = sent;
          mcDashboardV04CleanLog_(result);
          return result;
        }
      } catch (inner) {
        last = { ok: false, message: String(inner && inner.message ? inner.message : inner) };
      }
    }

    result.sendResult = last;
    throw new Error((last && last.message) ? last.message : '사용 가능한 발송 함수가 없습니다.');
  } catch (err) {
    result.ok = false;
    result.message = String(err && err.message ? err.message : err);
  }

  mcDashboardV04CleanLog_(result);
  return result;
}

function mcDashboardV04CleanOpenMaster_() {
  if (typeof portal19GetConfigBundle_ === 'function' && typeof portal19OpenMaster_ === 'function') {
    var bundle = portal19GetConfigBundle_();
    var ssByPortal = portal19OpenMaster_(bundle);
    if (ssByPortal) return { ss: ssByPortal, masterDbId: bundle.masterDbId || '' };
  }

  var setup = SpreadsheetApp.openById(MAILCENTER_DASHBOARD_V04_CLEAN_ROLLBACK_SETUP_DB_ID);
  var config = setup.getSheetByName(MAILCENTER_DASHBOARD_V04_CLEAN_ROLLBACK_CONFIG_SHEET);
  if (!config) throw new Error('SystemConfig 시트를 찾지 못했습니다.');

  var values = config.getDataRange().getValues();
  var hm = mcDashboardV04CleanHeaderMap_(values[0]);
  var keyCol = mcDashboardV04CleanFindHeader_(hm, ['CONFIG_KEY','configKey','KEY','key']);
  var valCol = mcDashboardV04CleanFindHeader_(hm, ['VALUE','CONFIG_VALUE','configValue','value']);
  if (keyCol < 0 || valCol < 0) throw new Error('SystemConfig key/value 헤더를 찾지 못했습니다.');

  var masterId = '';
  for (var r = 1; r < values.length; r++) {
    var key = String(values[r][keyCol] || '').trim();
    if (key === 'FEELHAUS_DB_MASTER' || key === 'FEELHAUS_DB_MASTER_ID' || key === 'MASTER_DB_ID') {
      masterId = String(values[r][valCol] || '').trim();
      break;
    }
  }
  if (!masterId) throw new Error('FEELHAUS_DB_MASTER ID를 찾지 못했습니다.');

  return { ss: SpreadsheetApp.openById(masterId), masterDbId: masterId };
}

function mcDashboardV04CleanReadSheet_(ss, name) {
  var sh = ss.getSheetByName(name);
  if (!sh) return [];
  var values = sh.getDataRange().getValues();
  if (!values || values.length < 2) return [];
  var headers = values[0];
  var rows = [];

  for (var r = 1; r < values.length; r++) {
    var obj = {};
    for (var c = 0; c < headers.length; c++) {
      var key = String(headers[c] || '').trim();
      if (!key) continue;
      var v = values[r][c];
      obj[key] = v instanceof Date ? Utilities.formatDate(v, Session.getScriptTimeZone() || 'Asia/Seoul', 'yyyy-MM-dd HH:mm:ss') : v;
    }
    rows.push(obj);
  }
  return rows;
}


function mcDashboardV04CleanReadOAuthMap_(ss) {
  var rows = mcDashboardV04CleanReadSheet_(ss, 'MailCenter_OAuthConnections');
  var map = {};
  function score_(o) {
    var score = 0;
    if (!o) return score;
    if (String(o.oauthStatus || '').toUpperCase() === 'CONNECTED') score += 100;
    if (o.connectorMailAccountId) score += 10;
    if (o.lastConnectedAt) score += 5;
    return score;
  }
  function put_(key, o) {
    if (!key) return;
    var k = String(key);
    if (!map[k] || score_(o) >= score_(map[k])) map[k] = o;
  }
  rows.forEach(function(o) {
    put_(o.mailAccountId, o);
    put_(o.emailAddress, o);
    if (o.emailAddress) put_(String(o.emailAddress).toLowerCase(), o);
  });
  return map;
}

function mcDashboardV04CleanPick_(obj, keys) {
  for (var i = 0; i < keys.length; i++) {
    var k = keys[i];
    if (obj[k] != null && String(obj[k]).trim() !== '') return obj[k];
  }
  return '';
}
function mcDashboardV04CleanTypeLabel_(ownerType, purpose, vendorId) {
  var raw = String(purpose || ownerType || '').toUpperCase();
  if (raw.indexOf('HQ_OFFICIAL') >= 0) return '본사대표';
  if (raw.indexOf('HQ') >= 0) return '본사직원';
  if (raw.indexOf('VENDOR_OFFICIAL') >= 0) return '업체대표';
  if (raw.indexOf('VENDOR') >= 0 || vendorId) return '업체대표';
  return '기타';
}
function mcDashboardV04CleanBoolLabel_(v) {
  var s = String(v || '').toUpperCase();
  return (s === 'TRUE' || s === 'Y' || s === 'YES' || s === '예') ? '예' : '아니요';
}
function mcDashboardV04CleanCanSend_(canSend, status, connection) {
  var c = String(canSend || '').toUpperCase();
  if (c === 'TRUE' || c === 'Y' || c === 'YES' || c === '가능') return '가능';
  if (String(status).toUpperCase() === 'ACTIVE' && String(connection).toUpperCase() === 'CONNECTED') return '가능';
  return '대기';
}
function mcDashboardV04CleanHeaderMap_(header) {
  var hm = {};
  for (var i = 0; i < header.length; i++) {
    var raw = String(header[i] || '').trim();
    if (!raw) continue;
    hm[raw] = i;
    hm[mcDashboardV04CleanNormalize_(raw)] = i;
  }
  return hm;
}
function mcDashboardV04CleanFindHeader_(hm, names) {
  for (var i = 0; i < names.length; i++) {
    if (hm[names[i]] != null) return hm[names[i]];
    var norm = mcDashboardV04CleanNormalize_(names[i]);
    if (hm[norm] != null) return hm[norm];
  }
  return -1;
}
function mcDashboardV04CleanNormalize_(v) { return String(v || '').trim().toUpperCase().replace(/[^A-Z0-9]/g, ''); }
function mcDashboardV04CleanNow_() { return Utilities.formatDate(new Date(), Session.getScriptTimeZone() || 'Asia/Seoul', 'yyyy-MM-dd HH:mm:ss'); }
function mcDashboardV04CleanSafe_(obj) { try { return JSON.parse(JSON.stringify(obj)); } catch (e) { return { ok: false, build: MAILCENTER_DASHBOARD_V04_CLEAN_ROLLBACK_BUILD, message: String(e && e.message ? e.message : e) }; } }
function mcDashboardV04CleanLog_(obj) { try { Logger.log('JSON_COMPACT_RESULT: ' + JSON.stringify(obj)); } catch (e) { Logger.log(obj); } }
