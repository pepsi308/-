/**
 * FEELHAUS MailCenter Calendar Event Status V01
 * Build: MAILCENTER_CALENDAR_EVENT_STATUS_V01_20260521
 * Purpose:
 * - Server-only safe core for calendar event status change
 * - No router/menu/html/shell/view changes
 * - Header-map based update and log append
 * - Uses SystemConfig -> FEELHAUS_DB_MASTER
 */
var MC_CALENDAR_EVENT_STATUS_V01_BUILD = 'MAILCENTER_CALENDAR_EVENT_STATUS_V01_20260521';
var MC_CALENDAR_EVENT_STATUS_V01_SETUP_DB_ID = '17VMSpgSZCvIrUlgcw8yCNcnl8WQWo2IcRf5tDCcuJGM';
var MC_CALENDAR_EVENT_STATUS_V01_CONFIG_SHEET = 'SystemConfig';
var MC_CALENDAR_EVENT_STATUS_V01_ALLOWED = ['요청','예정','진행중','완료','취소'];

function runMcCalendarEventStatusV01Smoke() {
  var result = {
    ok: true,
    build: MC_CALENDAR_EVENT_STATUS_V01_BUILD,
    action: 'runMcCalendarEventStatusV01Smoke',
    generatedAt: mcCalendarEventStatusV01Now_(),
    noWriteMode: true,
    checks: []
  };
  function check(key, ok, message, detail) {
    result.checks.push({ key: key, ok: !!ok, message: message, detail: detail || '' });
    if (!ok) result.ok = false;
  }
  try {
    var master = mcCalendarEventStatusV01OpenMaster_();
    check('MasterOpenReady', !!master, 'SystemConfig -> FEELHAUS_DB_MASTER 연결 확인', master.getId());
    check('ChangeFunctionReady', typeof mcCalendarEventStatusV01ChangeStatus === 'function', '상태변경 서버 함수 확인');
    check('HeaderMapReady', typeof mcCalendarEventStatusV01HeaderMap_ === 'function', '헤더맵 함수 확인');
    check('TransitionRuleReady', typeof mcCalendarEventStatusV01CanTransition_ === 'function', '상태 전이 규칙 함수 확인');
    var eventSheet = master.getSheetByName('MAILCENTER_CalendarEvents');
    check('CalendarEventsSheetReady', !!eventSheet, 'MAILCENTER_CalendarEvents 시트 확인');
    if (eventSheet) {
      var headers = eventSheet.getRange(1, 1, 1, Math.max(eventSheet.getLastColumn(), 1)).getValues()[0];
      var hm = mcCalendarEventStatusV01HeaderMap_(headers);
      var missing = [];
      ['calendarEventId','eventStatus','updatedAt','updatedBy'].forEach(function(h) { if (!hm.hasOwnProperty(h)) missing.push(h); });
      check('CalendarEventsHeadersReady', missing.length === 0, 'MAILCENTER_CalendarEvents 핵심 헤더 확인', 'missing=' + JSON.stringify(missing));
    }
    var logSheet = master.getSheetByName('MAILCENTER_CalendarLogs');
    check('CalendarLogsSheetReady', !!logSheet, 'MAILCENTER_CalendarLogs 시트 확인');
    check('NoRouterMenuHtmlTouch', true, '본 파일은 라우터/메뉴/HTML/Shell/View 변경 없음');
    result.message = result.ok ? 'MailCenter Calendar Event Status V01 Smoke 통과' : 'MailCenter Calendar Event Status V01 점검 필요';
  } catch (err) {
    result.ok = false;
    result.message = mcCalendarEventStatusV01Err_(err);
  }
  Logger.log(JSON.stringify(result, null, 2));
  return result;
}

function runMcCalendarEventStatusV01DryRun() {
  var result = {
    ok: true,
    build: MC_CALENDAR_EVENT_STATUS_V01_BUILD,
    action: 'runMcCalendarEventStatusV01DryRun',
    generatedAt: mcCalendarEventStatusV01Now_(),
    noWriteMode: true,
    sample: null,
    message: ''
  };
  try {
    var master = mcCalendarEventStatusV01OpenMaster_();
    var sheet = master.getSheetByName('MAILCENTER_CalendarEvents');
    if (!sheet || sheet.getLastRow() < 2) throw new Error('Dry Run 대상 일정 데이터가 없습니다. 먼저 일정 1건 이상 등록되어야 합니다.');
    var data = sheet.getDataRange().getValues();
    var headers = data[0];
    var hm = mcCalendarEventStatusV01HeaderMap_(headers);
    var idCol = mcCalendarEventStatusV01RequireCol_(hm, 'calendarEventId');
    var statusCol = mcCalendarEventStatusV01RequireCol_(hm, 'eventStatus');
    var row = data[1];
    var currentStatus = String(row[statusCol] || '').trim();
    var nextStatus = mcCalendarEventStatusV01PickDryRunNext_(currentStatus);
    var rule = mcCalendarEventStatusV01CanTransition_(currentStatus, nextStatus);
    result.sample = {
      calendarEventId: String(row[idCol] || '').trim(),
      currentStatus: currentStatus,
      dryRunNextStatus: nextStatus,
      allowed: rule.ok,
      reason: rule.message
    };
    result.ok = !!rule.ok;
    result.message = result.ok ? 'MailCenter Calendar Event Status V01 Dry Run 통과' : 'MailCenter Calendar Event Status V01 Dry Run 점검 필요';
  } catch (err) {
    result.ok = false;
    result.message = mcCalendarEventStatusV01Err_(err);
  }
  Logger.log(JSON.stringify(result, null, 2));
  return result;
}

function mcCalendarEventStatusV01ChangeStatus(payload) {
  var result = {
    ok: false,
    build: MC_CALENDAR_EVENT_STATUS_V01_BUILD,
    action: 'mcCalendarEventStatusV01ChangeStatus',
    generatedAt: mcCalendarEventStatusV01Now_(),
    calendarEventId: '',
    beforeStatus: '',
    afterStatus: '',
    message: ''
  };
  try {
    payload = payload || {};
    var calendarEventId = String(payload.calendarEventId || payload.calendarId || '').trim();
    var nextStatus = String(payload.nextStatus || payload.status || '').trim();
    var statusReason = String(payload.statusReason || payload.reason || '일정 상태변경').trim();
    var actor = mcCalendarEventStatusV01Actor_(payload);
    if (!calendarEventId) throw new Error('calendarEventId 값이 필요합니다.');
    if (MC_CALENDAR_EVENT_STATUS_V01_ALLOWED.indexOf(nextStatus) < 0) throw new Error('허용되지 않은 상태값입니다: ' + nextStatus);

    var master = mcCalendarEventStatusV01OpenMaster_();
    var sheet = master.getSheetByName('MAILCENTER_CalendarEvents');
    if (!sheet) throw new Error('MAILCENTER_CalendarEvents 시트를 찾지 못했습니다.');
    mcCalendarEventStatusV01EnsureHeaders_(sheet, ['calendarEventId','eventStatus','statusReason','updatedAt','updatedBy']);
    var values = sheet.getDataRange().getValues();
    var headers = values[0];
    var hm = mcCalendarEventStatusV01HeaderMap_(headers);
    var idCol = mcCalendarEventStatusV01RequireCol_(hm, 'calendarEventId');
    var statusCol = mcCalendarEventStatusV01RequireCol_(hm, 'eventStatus');
    var reasonCol = mcCalendarEventStatusV01RequireCol_(hm, 'statusReason');
    var updatedAtCol = mcCalendarEventStatusV01RequireCol_(hm, 'updatedAt');
    var updatedByCol = mcCalendarEventStatusV01RequireCol_(hm, 'updatedBy');

    var foundRow = -1;
    for (var r = 1; r < values.length; r++) {
      if (String(values[r][idCol] || '').trim() === calendarEventId) {
        foundRow = r + 1;
        break;
      }
    }
    if (foundRow < 0) throw new Error('calendarEventId를 찾지 못했습니다: ' + calendarEventId);

    var beforeStatus = String(sheet.getRange(foundRow, statusCol + 1).getValue() || '').trim();
    if (beforeStatus === nextStatus) {
      result.ok = true;
      result.calendarEventId = calendarEventId;
      result.beforeStatus = beforeStatus;
      result.afterStatus = nextStatus;
      result.message = '이미 같은 상태입니다. 변경 없음';
      Logger.log(JSON.stringify(result, null, 2));
      return result;
    }

    var rule = mcCalendarEventStatusV01CanTransition_(beforeStatus, nextStatus);
    if (!rule.ok) throw new Error(rule.message);

    var now = mcCalendarEventStatusV01Now_();
    sheet.getRange(foundRow, statusCol + 1).setValue(nextStatus);
    sheet.getRange(foundRow, reasonCol + 1).setValue(statusReason);
    sheet.getRange(foundRow, updatedAtCol + 1).setValue(now);
    sheet.getRange(foundRow, updatedByCol + 1).setValue(actor);

    mcCalendarEventStatusV01AppendByHeaders_(master, 'MAILCENTER_CalendarLogs', mcCalendarEventStatusV01LogHeaders_(), {
      calendarLogId: 'MCALLOG-' + Utilities.formatDate(new Date(), Session.getScriptTimeZone() || 'Asia/Seoul', 'yyyyMMddHHmmss') + '-' + Utilities.getUuid().substring(0, 8).toUpperCase(),
      calendarEventId: calendarEventId,
      provider: 'MAIL_LINK',
      actionType: 'STATUS_CHANGE',
      resultStatus: 'SUCCESS',
      providerEventId: '',
      errorCode: '',
      errorMessage: '',
      requestPayloadSummary: JSON.stringify({ calendarEventId: calendarEventId, beforeStatus: beforeStatus, nextStatus: nextStatus, statusReason: statusReason }).slice(0, 900),
      responseSummary: '일정 상태변경 완료: ' + beforeStatus + ' -> ' + nextStatus,
      createdAt: now,
      createdBy: actor
    });

    result.ok = true;
    result.calendarEventId = calendarEventId;
    result.beforeStatus = beforeStatus;
    result.afterStatus = nextStatus;
    result.message = '일정 상태변경 완료';
  } catch (err) {
    result.ok = false;
    result.message = mcCalendarEventStatusV01Err_(err);
  }
  Logger.log(JSON.stringify(result, null, 2));
  return result;
}

function mcCalendarEventStatusV01CanTransition_(fromStatus, toStatus) {
  fromStatus = String(fromStatus || '').trim();
  toStatus = String(toStatus || '').trim();
  if (MC_CALENDAR_EVENT_STATUS_V01_ALLOWED.indexOf(toStatus) < 0) return { ok: false, message: '허용되지 않은 목표 상태입니다: ' + toStatus };
  var initial = ['', 'MAIL_LINK_SAVED', 'CREATED', 'REQUESTED'];
  if (initial.indexOf(fromStatus) >= 0) return { ok: true, message: '초기 상태 전이 허용' };
  var map = {
    '요청': ['예정','진행중','취소'],
    '예정': ['진행중','완료','취소'],
    '진행중': ['완료','취소'],
    '완료': [],
    '취소': []
  };
  if (!map.hasOwnProperty(fromStatus)) return { ok: false, message: '알 수 없는 현재 상태입니다: ' + fromStatus };
  if (map[fromStatus].indexOf(toStatus) >= 0) return { ok: true, message: '허용된 상태 전이' };
  return { ok: false, message: '허용되지 않은 상태 전이입니다: ' + fromStatus + ' -> ' + toStatus };
}

function mcCalendarEventStatusV01PickDryRunNext_(currentStatus) {
  currentStatus = String(currentStatus || '').trim();
  if (!currentStatus || currentStatus === 'MAIL_LINK_SAVED' || currentStatus === 'CREATED' || currentStatus === 'REQUESTED') return '예정';
  if (currentStatus === '요청') return '예정';
  if (currentStatus === '예정') return '진행중';
  if (currentStatus === '진행중') return '완료';
  return currentStatus;
}

function mcCalendarEventStatusV01LogHeaders_() {
  return ['calendarLogId','calendarEventId','provider','actionType','resultStatus','providerEventId','errorCode','errorMessage','requestPayloadSummary','responseSummary','createdAt','createdBy'];
}

function mcCalendarEventStatusV01AppendByHeaders_(ss, sheetName, baseHeaders, record) {
  var sheet = mcCalendarEventStatusV01GetSheetOrCreate_(ss, sheetName, baseHeaders);
  mcCalendarEventStatusV01EnsureHeaders_(sheet, Object.keys(record || {}));
  var headers = sheet.getRange(1, 1, 1, sheet.getLastColumn()).getValues()[0];
  var hm = mcCalendarEventStatusV01HeaderMap_(headers);
  var row = [];
  for (var i = 0; i < headers.length; i++) row.push('');
  Object.keys(record || {}).forEach(function(key) {
    if (hm.hasOwnProperty(key)) row[hm[key]] = record[key];
  });
  sheet.appendRow(row);
}

function mcCalendarEventStatusV01GetSheetOrCreate_(ss, name, headers) {
  var sheet = ss.getSheetByName(name);
  if (!sheet) {
    sheet = ss.insertSheet(name);
    sheet.getRange(1, 1, 1, headers.length).setValues([headers]);
    sheet.setFrozenRows(1);
    return sheet;
  }
  if (sheet.getLastRow() < 1 || sheet.getLastColumn() < 1) {
    sheet.getRange(1, 1, 1, headers.length).setValues([headers]);
    sheet.setFrozenRows(1);
    return sheet;
  }
  mcCalendarEventStatusV01EnsureHeaders_(sheet, headers);
  return sheet;
}

function mcCalendarEventStatusV01EnsureHeaders_(sheet, requiredHeaders) {
  var lastCol = Math.max(sheet.getLastColumn(), 1);
  var headers = sheet.getRange(1, 1, 1, lastCol).getValues()[0];
  var hm = mcCalendarEventStatusV01HeaderMap_(headers);
  var add = [];
  (requiredHeaders || []).forEach(function(h) { if (h && !hm.hasOwnProperty(h)) add.push(h); });
  if (add.length) sheet.getRange(1, headers.length + 1, 1, add.length).setValues([add]);
}

function mcCalendarEventStatusV01OpenMaster_() {
  var setup = SpreadsheetApp.openById(MC_CALENDAR_EVENT_STATUS_V01_SETUP_DB_ID);
  var sheet = setup.getSheetByName(MC_CALENDAR_EVENT_STATUS_V01_CONFIG_SHEET);
  if (!sheet) throw new Error('SystemConfig 시트를 찾지 못했습니다.');
  var values = sheet.getDataRange().getValues();
  if (!values || values.length < 2) throw new Error('SystemConfig 데이터가 비어 있습니다.');
  var hm = mcCalendarEventStatusV01HeaderMap_(values[0]);
  var keyCol = mcCalendarEventStatusV01PickIndex_(hm, ['CONFIG_KEY','configKey','key','name']);
  var valCol = mcCalendarEventStatusV01PickIndex_(hm, ['VALUE','configValue','value','spreadsheetId']);
  if (keyCol < 0 || valCol < 0) throw new Error('SystemConfig CONFIG_KEY/VALUE 헤더를 찾지 못했습니다.');
  var masterId = '';
  for (var r = 1; r < values.length; r++) {
    var key = String(values[r][keyCol] || '').trim();
    if (key === 'FEELHAUS_DB_MASTER' || key === 'FEELHAUS_DB_MASTER_ID' || key === 'MASTER_DB_ID') {
      masterId = String(values[r][valCol] || '').trim();
      break;
    }
  }
  if (!masterId) throw new Error('SystemConfig에서 FEELHAUS_DB_MASTER ID를 찾지 못했습니다.');
  return SpreadsheetApp.openById(masterId);
}

function mcCalendarEventStatusV01HeaderMap_(headers) {
  var out = {};
  (headers || []).forEach(function(h, i) {
    var key = String(h || '').trim();
    if (key) out[key] = i;
  });
  return out;
}

function mcCalendarEventStatusV01RequireCol_(hm, key) {
  if (!hm.hasOwnProperty(key)) throw new Error('필수 헤더가 없습니다: ' + key);
  return hm[key];
}

function mcCalendarEventStatusV01PickIndex_(hm, keys) {
  for (var i = 0; i < keys.length; i++) if (hm.hasOwnProperty(keys[i])) return hm[keys[i]];
  return -1;
}

function mcCalendarEventStatusV01Actor_(payload) {
  payload = payload || {};
  return String(payload.createdBy || payload.updatedBy || payload.loginId || payload.userEmail || Session.getActiveUser().getEmail() || 'MAILCENTER_USER').trim() || 'MAILCENTER_USER';
}

function mcCalendarEventStatusV01Now_() {
  return Utilities.formatDate(new Date(), Session.getScriptTimeZone() || 'Asia/Seoul', 'yyyy-MM-dd HH:mm:ss');
}

function mcCalendarEventStatusV01Err_(err) {
  return err && err.message ? err.message : String(err);
}
