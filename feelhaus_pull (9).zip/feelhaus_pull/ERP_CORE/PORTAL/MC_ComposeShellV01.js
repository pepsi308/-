/**
 * FEELHAUS MailCenter Compose Shell V01
 * Build: MC_COMPOSE_SHELL_V01_20260519
 */

var MC_COMPOSE_SHELL_V01_BUILD = 'MC_COMPOSE_PREFILL_TOKEN_BRIDGE_V01_20260521';
var MC_COMPOSE_EDITOR_VIEW_V01_BUILD = 'MAILCENTER_COMPOSE_PREFILL_TOKEN_BRIDGE_V01_20260521';

function runMcComposeShellV01() {
  var result = {
    ok: false,
    build: MC_COMPOSE_SHELL_V01_BUILD,
    action: 'runMcComposeShellV01',
    generatedAt: Utilities.formatDate(new Date(), Session.getScriptTimeZone() || 'Asia/Seoul', 'yyyy-MM-dd HH:mm:ss'),
    message: '',
    checks: []
  };

  try {
    result.checks.push({ key: 'CoreReady', ok: typeof mcComposeCoreV01GetData === 'function', message: 'Compose Core 데이터 함수 확인' });
    result.checks.push({ key: 'SendReady', ok: typeof mcComposeCoreV01Send === 'function', message: 'Compose 발송 함수 확인' });
    result.checks.push({ key: 'SendCoreReady', ok: typeof mcSendTestCoreV01Send === 'function', message: '기존 Send Core 확인' });
    result.ok = result.checks.every(function(c) { return !!c.ok; });
    result.message = result.ok ? 'MailCenter Compose Shell V01 준비 완료' : 'Compose Shell V01 필수 함수 확인 필요';
  } catch (err) {
    result.ok = false;
    result.message = String(err && err.message ? err.message : err);
  }

  Logger.log('JSON_COMPACT_RESULT: ' + JSON.stringify(result));
  return result;
}

function mcComposeShellV01HandleGet(e) {
  var data = typeof mcComposeCoreV01GetData === 'function'
    ? mcComposeCoreV01GetData()
    : { ok: false, message: 'mcComposeCoreV01GetData 함수가 없습니다.', accounts: [], signatures: [], folders: [] };

  var t = HtmlService.createTemplateFromFile('MC_ComposeViewV01');
  t.build = MC_COMPOSE_EDITOR_VIEW_V01_BUILD;
  t.initialJson = JSON.stringify(data);
  t.prefillJson = JSON.stringify(mcComposeShellV01BuildPrefill_(e));

  return t.evaluate()
    .setTitle('FEELHAUS MailCenter Compose')
    .setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL);
}

function mcComposeShellV01BuildPrefill_(e) {
  var p = (e && e.parameter) ? e.parameter : {};
  var kind = String(p.mcPrefillKind || '').trim();
  var has = !!(p.mcPrefill || kind || p.mcTo || p.mcSubject || p.mcBody || p.mcSourceThreadId);
  if (!has) return { ok: false, source: 'none' };

  return {
    ok: true,
    source: 'serverParameter',
    mcPrefill: String(p.mcPrefill || 'url'),
    mcPrefillKind: kind,
    mcTo: String(p.mcTo || ''),
    mcSubject: String(p.mcSubject || ''),
    mcBody: String(p.mcBody || ''),
    mcSourceThreadId: String(p.mcSourceThreadId || ''),
    generatedAt: Utilities.formatDate(new Date(), Session.getScriptTimeZone() || 'Asia/Seoul', 'yyyy-MM-dd HH:mm:ss')
  };
}
