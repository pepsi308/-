/**
 * MAILCENTER_CALENDAR_CORE_CLONE_V01_20260521
 * Source cloned from verified PORTAL calendar file: Portal_Run206_CalendarDiagFixOnly.js
 * Rule:
 * - PORTAL original files are not modified.
 * - Server identifiers are namespaced from portal* to mcCalendar* to avoid collisions.
 * - This is stage 1: core clone / diagnostic separation only.
 */

/**
 * MAILCENTER_CALENDAR_CORE_CLONE_V01_20260521
 * Purpose: Calendar diagnostic only. No write, no UI change, no bridge/common file change.
 * Fixes overly strict 204 check that required mcCalendar187GetCalendarEventDetail by exact name.
 */
var MAILCENTER_206_CALENDAR_DIAG_FIX_ONLY_BUILD = 'MAILCENTER_CALENDAR_CORE_CLONE_V01_20260521';

function mcCalendar206CalendarDiagFixOnlySelfTest() {
  return mcCalendar206CalendarDiagFixOnlyDebug();
}

function mcCalendar206CalendarDiagFixOnlyDebug() {
  var result = {
    ok: false,
    build: MAILCENTER_206_CALENDAR_DIAG_FIX_ONLY_BUILD,
    action: 'mcCalendar206CalendarDiagFixOnlyDebug',
    message: '캘린더 진단 기준 보정 점검',
    noWriteMode: true,
    generatedAt: mcCalendar206CalendarDiagNow_(),
    checks: {},
    dashboard: {},
    status: {},
    selfTest: {},
    warnings: [],
    missing: []
  };

  result.checks.mcCalendar186GetCalendarDashboard = typeof mcCalendar186GetCalendarDashboard === 'function';
  result.checks.mcCalendar186RunCalendarDashboardDebug = typeof mcCalendar186RunCalendarDashboardDebug === 'function';
  result.checks.mcCalendar193UpdateCalendarEvent = typeof mcCalendar193UpdateCalendarEvent === 'function';
  result.checks.mcCalendar199ChangeCalendarEventStatus = typeof mcCalendar199ChangeCalendarEventStatus === 'function';
  result.checks.mcCalendar199GetCalendarStatusOptions = typeof mcCalendar199GetCalendarStatusOptions === 'function';
  result.checks.mcCalendar199CalendarCompleteSelfTest = typeof mcCalendar199CalendarCompleteSelfTest === 'function';

  // 204 used only this exact function name. In the actual 199 build, detail readiness is verified by the 199 self-test.
  result.checks.mcCalendar187GetCalendarEventDetail = typeof mcCalendar187GetCalendarEventDetail === 'function';

  if (result.checks.mcCalendar186GetCalendarDashboard) {
    try {
      var dash = mcCalendar186GetCalendarDashboard();
      result.dashboard = {
        ok: !!(dash && dash.ok),
        total: dash && dash.summary ? dash.summary.total : '',
        today: dash && dash.summary ? dash.summary.today : '',
        recentCount: dash && dash.recentEvents ? dash.recentEvents.length : 0,
        naverSuccess: dash && dash.summary ? dash.summary.naverSuccess : '',
        googleSuccess: dash && dash.summary ? dash.summary.googleSuccess : '',
        retryPending: dash && dash.summary ? dash.summary.retryPending : ''
      };
    } catch (errDash) {
      result.dashboard = { ok: false, error: String(errDash && errDash.message ? errDash.message : errDash) };
    }
  }

  if (result.checks.mcCalendar199GetCalendarStatusOptions) {
    try {
      var opt = mcCalendar199GetCalendarStatusOptions();
      var list = opt && opt.options ? opt.options : [];
      result.status = {
        optionsOk: !!(opt && opt.ok),
        optionCount: list.length,
        currentBuild: opt && opt.build ? opt.build : ''
      };
    } catch (errOpt) {
      result.status = { optionsOk: false, error: String(errOpt && errOpt.message ? errOpt.message : errOpt) };
    }
  }

  if (result.checks.mcCalendar199CalendarCompleteSelfTest) {
    try {
      var st = mcCalendar199CalendarCompleteSelfTest();
      result.selfTest = {
        ok: !!(st && st.ok),
        detailReady: !!(st && st.checks && st.checks.detailReady),
        dashboardReady: !!(st && st.checks && st.checks.dashboardReady),
        updateReady: !!(st && st.checks && st.checks.updateReady),
        statusChangeReady: !!(st && st.checks && st.checks.statusChangeReady),
        statusOptionsReady: !!(st && st.checks && st.checks.statusOptionsReady),
        providerLogReady: !!(st && st.checks && st.checks.providerLogReady),
        transitionRuleReady: !!(st && st.checks && st.checks.transitionRuleReady)
      };
    } catch (errSt) {
      result.selfTest = { ok: false, error: String(errSt && errSt.message ? errSt.message : errSt) };
    }
  }

  // Corrected detail readiness: accept the direct function OR the verified 199 complete self-test detailReady.
  result.checks.detailReadyCorrected = !!(result.checks.mcCalendar187GetCalendarEventDetail || result.selfTest.detailReady);

  result.checks.calendarBridgeUntouchedByThisBuild = true;
  result.checks.commonFilesUntouchedByThisBuild = true;
  result.checks.uiChangedByThisBuild = false;
  result.checks.writeChangedByThisBuild = false;

  var required = [
    'mcCalendar186GetCalendarDashboard',
    'mcCalendar186RunCalendarDashboardDebug',
    'mcCalendar193UpdateCalendarEvent',
    'mcCalendar199ChangeCalendarEventStatus',
    'mcCalendar199GetCalendarStatusOptions',
    'mcCalendar199CalendarCompleteSelfTest',
    'detailReadyCorrected'
  ];

  for (var i = 0; i < required.length; i++) {
    if (!result.checks[required[i]]) result.missing.push(required[i]);
  }

  result.ok = result.missing.length === 0 && !!result.dashboard.ok && !!result.status.optionsOk && !!result.selfTest.ok;
  result.message = result.ok ? '캘린더 진단 통과' : '캘린더 진단 확인 필요';

  Logger.log(JSON.stringify(result, null, 2));
  return result;
}

function mcCalendar206CalendarDiagNow_() {
  try {
    return Utilities.formatDate(new Date(), Session.getScriptTimeZone() || 'Asia/Seoul', 'yyyy-MM-dd HH:mm:ss');
  } catch (e) {
    return new Date().toISOString();
  }
}
