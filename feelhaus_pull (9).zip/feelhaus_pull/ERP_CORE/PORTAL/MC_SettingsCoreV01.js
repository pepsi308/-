/**
 * FEELHAUS MailCenter Settings Core V01
 * Build: MC_SETTINGS_CORE_V01_20260519
 *
 * Purpose:
 * - MailCenter 계정별 서명 관리
 * - 폴더/분류 라벨 관리
 * - 기본 발신계정 설정
 * - 기존 송신/OAuth/계정등록 성공 파일 수정 없음
 */

var MC_SETTINGS_CORE_V01_BUILD = 'MAILCENTER_DEFAULT_POLICY_SETTINGS_V01_20260520';
var MC_SETTINGS_CORE_V01_SETUP_DB_ID = '17VMSpgSZCvIrUlgcw8yCNcnl8WQWo2IcRf5tDCcuJGM';
var MC_SETTINGS_CORE_V01_CONFIG_SHEET = 'SystemConfig';

function runMcSettingsCoreV01Smoke() {
  var result = {
    ok: false,
    build: MC_SETTINGS_CORE_V01_BUILD,
    action: 'runMcSettingsCoreV01Smoke',
    generatedAt: mcSettingsCoreV01Now_(),
    message: '',
    checks: []
  };

  try {
    var ss = mcSettingsCoreV01OpenMaster_().ss;
    mcSettingsCoreV01EnsureSheets_(ss);

    result.checks.push({ key: 'MasterConnected', ok: !!ss, message: 'FEELHAUS_DB_MASTER 연결 확인' });
    result.checks.push({ key: 'AccountsReady', ok: !!ss.getSheetByName('MailCenter_Accounts'), message: 'MailCenter_Accounts 확인' });
    result.checks.push({ key: 'SignaturesReady', ok: !!ss.getSheetByName('MailCenter_Signatures'), message: 'MailCenter_Signatures 확인' });
    result.checks.push({ key: 'FoldersReady', ok: !!ss.getSheetByName('MailCenter_Folders'), message: 'MailCenter_Folders 확인' });
    result.checks.push({ key: 'PreferencesReady', ok: !!ss.getSheetByName('MailCenter_Preferences'), message: 'MailCenter_Preferences 확인' });
    result.checks.push({ key: 'AuditReady', ok: !!ss.getSheetByName('MailCenter_AuditLogs'), message: 'MailCenter_AuditLogs 확인' });

    result.ok = result.checks.every(function(c) { return !!c.ok; });
    result.message = result.ok ? 'MailCenter Settings Core V01 준비 완료' : 'MailCenter Settings Core V01 점검 실패';
  } catch (err) {
    result.ok = false;
    result.message = String(err && err.message ? err.message : err);
  }

  mcSettingsCoreV01Log_(result);
  return result;
}

function mcSettingsCoreV01GetData() {
  var result = {
    ok: false,
    build: MC_SETTINGS_CORE_V01_BUILD,
    action: 'mcSettingsCoreV01GetData',
    generatedAt: mcSettingsCoreV01Now_(),
    message: '',
    summary: {
      accountCount: 0,
      activeAccountCount: 0,
      signatureCount: 0,
      folderCount: 0,
      defaultAccountCount: 0,
      defaultFolderCount: 0,
      policyCount: 0
    },
    accounts: [],
    signatures: [],
    folders: [],
    preferences: [],
    policies: {}
  };

  try {
    var ss = mcSettingsCoreV01OpenMaster_().ss;
    mcSettingsCoreV01EnsureSheets_(ss);

    var accounts = mcSettingsCoreV01ReadAccounts_(ss);
    var signatures = mcSettingsCoreV01ReadSheet_(ss, 'MailCenter_Signatures');
    var folders = mcSettingsCoreV01ReadSheet_(ss, 'MailCenter_Folders');
    var prefs = mcSettingsCoreV01ReadSheet_(ss, 'MailCenter_Preferences');

    result.accounts = accounts;
    result.signatures = signatures;
    result.folders = folders;
    result.preferences = prefs;
    result.policies = mcSettingsCoreV01BuildPolicyMap_(prefs);

    result.summary.accountCount = accounts.length;
    result.summary.activeAccountCount = accounts.filter(function(a) { return String(a.mailAccountStatus || '').toUpperCase() === 'ACTIVE'; }).length;
    result.summary.signatureCount = signatures.length;
    result.summary.folderCount = folders.length;
    result.summary.defaultAccountCount = prefs.filter(function(p) {
      return String(p.preferenceKey || '') === 'DEFAULT_SEND_ACCOUNT' && String(p.preferenceStatus || '').toUpperCase() === 'ACTIVE';
    }).length;
    result.summary.defaultFolderCount = prefs.filter(function(p) {
      return String(p.preferenceKey || '') === 'DEFAULT_FOLDER' && String(p.preferenceStatus || '').toUpperCase() === 'ACTIVE';
    }).length;
    result.summary.policyCount = Object.keys(result.policies || {}).length;

    result.ok = true;
    result.message = 'MailCenter Settings V01 데이터 조회 완료';
  } catch (err) {
    result.ok = false;
    result.message = String(err && err.message ? err.message : err);
  }

  return mcSettingsCoreV01Safe_(result);
}

function mcSettingsCoreV01SaveSignature(payload) {
  var result = {
    ok: false,
    build: MC_SETTINGS_CORE_V01_BUILD,
    action: 'mcSettingsCoreV01SaveSignature',
    generatedAt: mcSettingsCoreV01Now_(),
    message: '',
    signatureId: ''
  };

  try {
    var p = payload || {};
    var mailAccountId = mcSettingsCoreV01Require_(p.mailAccountId, 'mailAccountId');
    var signatureName = mcSettingsCoreV01Require_(p.signatureName, 'signatureName');
    var signatureHtml = mcSettingsCoreV01Require_(p.signatureHtml, 'signatureHtml');
    var isDefault = String(p.isDefault || 'FALSE').toUpperCase();
    var ss = mcSettingsCoreV01OpenMaster_().ss;
    mcSettingsCoreV01EnsureSheets_(ss);

    var account = mcSettingsCoreV01GetAccount_(ss, mailAccountId);
    var sh = ss.getSheetByName('MailCenter_Signatures');
    var headers = mcSettingsCoreV01Headers_(sh);
    var hm = mcSettingsCoreV01HeaderMap_(headers);
    var signatureId = String(p.signatureId || '').trim();
    var foundRow = -1;
    var existingRowObj = null;
    var values = sh.getDataRange().getValues();

    if (signatureId) {
      for (var r = 1; r < values.length; r++) {
        if (String(mcSettingsCoreV01Cell_(values[r], hm, 'signatureId')) === signatureId) {
          foundRow = r + 1;
          existingRowObj = mcSettingsCoreV01RowObject_(values[r], hm);
          break;
        }
      }
    }

    mcSettingsCoreV01AssertUniqueActive_(sh, hm, {
      idKey: 'signatureId',
      idValue: signatureId,
      scopeKey: 'mailAccountId',
      scopeValue: mailAccountId,
      nameKey: 'signatureName',
      nameValue: signatureName,
      statusKey: 'signatureStatus',
      label: '같은 계정에 동일한 서명명'
    });

    if (!signatureId) signatureId = mcSettingsCoreV01NewId_('MCSIG');
    var now = mcSettingsCoreV01Now_();
    var actor = mcSettingsCoreV01User_();

    if (isDefault === 'TRUE') {
      mcSettingsCoreV01ClearDefaultSignature_(sh, mailAccountId);
    }

    var obj = {
      signatureId: signatureId,
      mailAccountId: mailAccountId,
      emailAddress: account.emailAddress || '',
      signatureName: signatureName,
      signatureHtml: signatureHtml,
      signatureText: String(p.signatureText || mcSettingsCoreV01StripHtml_(signatureHtml)).substring(0, 500),
      isDefault: isDefault,
      signatureStatus: 'ACTIVE',
      statusReason: '저장 완료',
      createdAt: existingRowObj && existingRowObj.createdAt ? existingRowObj.createdAt : now,
      createdBy: existingRowObj && existingRowObj.createdBy ? existingRowObj.createdBy : actor,
      updatedAt: now,
      updatedBy: actor
    };

    if (foundRow > 0) {
      Object.keys(obj).forEach(function(k) { mcSettingsCoreV01SetCell_(sh, hm, foundRow, k, obj[k]); });
    } else {
      sh.appendRow(headers.map(function(h) { return obj[h] !== undefined ? obj[h] : ''; }));
    }

    mcSettingsCoreV01AppendAudit_(ss, 'MailCenter_Signatures', signatureId, mailAccountId, 'SAVE_SIGNATURE', JSON.stringify(obj), '서명 저장');
    result.ok = true;
    result.signatureId = signatureId;
    result.message = '서명 저장 완료';
  } catch (err) {
    result.ok = false;
    result.message = String(err && err.message ? err.message : err);
  }

  mcSettingsCoreV01Log_(result);
  return mcSettingsCoreV01Safe_(result);
}

function mcSettingsCoreV01SaveFolder(payload) {
  var result = {
    ok: false,
    build: MC_SETTINGS_CORE_V01_BUILD,
    action: 'mcSettingsCoreV01SaveFolder',
    generatedAt: mcSettingsCoreV01Now_(),
    message: '',
    folderId: ''
  };

  try {
    var p = payload || {};
    var folderName = mcSettingsCoreV01Require_(p.folderName, 'folderName');
    var folderType = String(p.folderType || 'USER').trim();
    var ss = mcSettingsCoreV01OpenMaster_().ss;
    mcSettingsCoreV01EnsureSheets_(ss);

    var sh = ss.getSheetByName('MailCenter_Folders');
    var headers = mcSettingsCoreV01Headers_(sh);
    var hm = mcSettingsCoreV01HeaderMap_(headers);
    var folderId = String(p.folderId || '').trim();
    var foundRow = folderId ? mcSettingsCoreV01FindRow_(sh, hm, 'folderId', folderId) : -1;
    var existingRowObj = foundRow > 0 ? mcSettingsCoreV01RowObject_(sh.getRange(foundRow, 1, 1, sh.getLastColumn()).getValues()[0], hm) : null;

    mcSettingsCoreV01AssertUniqueActive_(sh, hm, {
      idKey: 'folderId',
      idValue: folderId,
      nameKey: 'folderName',
      nameValue: folderName,
      statusKey: 'folderStatus',
      label: '동일한 폴더명'
    });

    if (!folderId) folderId = mcSettingsCoreV01NewId_('MCFOL');
    var now = mcSettingsCoreV01Now_();
    var actor = mcSettingsCoreV01User_();

    var obj = {
      folderId: folderId,
      folderName: folderName,
      folderType: folderType,
      folderColor: String(p.folderColor || ''),
      sortOrder: String(p.sortOrder || '100'),
      folderStatus: 'ACTIVE',
      statusReason: '저장 완료',
      createdAt: existingRowObj && existingRowObj.createdAt ? existingRowObj.createdAt : now,
      createdBy: existingRowObj && existingRowObj.createdBy ? existingRowObj.createdBy : actor,
      updatedAt: now,
      updatedBy: actor
    };
    if (foundRow > 0) {
      Object.keys(obj).forEach(function(k) { mcSettingsCoreV01SetCell_(sh, hm, foundRow, k, obj[k]); });
    } else {
      sh.appendRow(headers.map(function(h) { return obj[h] !== undefined ? obj[h] : ''; }));
    }

    mcSettingsCoreV01AppendAudit_(ss, 'MailCenter_Folders', folderId, '', 'SAVE_FOLDER', JSON.stringify(obj), '폴더 저장');
    result.ok = true;
    result.folderId = folderId;
    result.message = '폴더 저장 완료';
  } catch (err) {
    result.ok = false;
    result.message = String(err && err.message ? err.message : err);
  }

  mcSettingsCoreV01Log_(result);
  return mcSettingsCoreV01Safe_(result);
}


function mcSettingsCoreV01SetDefaultSignature(payload) {
  var result = {
    ok: false,
    build: MC_SETTINGS_CORE_V01_BUILD,
    action: 'mcSettingsCoreV01SetDefaultSignature',
    generatedAt: mcSettingsCoreV01Now_(),
    message: '',
    signatureId: ''
  };

  try {
    var signatureId = mcSettingsCoreV01Require_((payload || {}).signatureId, 'signatureId');
    var ss = mcSettingsCoreV01OpenMaster_().ss;
    mcSettingsCoreV01EnsureSheets_(ss);
    var sh = ss.getSheetByName('MailCenter_Signatures');
    var headers = mcSettingsCoreV01Headers_(sh);
    var hm = mcSettingsCoreV01HeaderMap_(headers);
    var row = mcSettingsCoreV01FindRow_(sh, hm, 'signatureId', signatureId);
    if (row < 1) throw new Error('서명을 찾을 수 없습니다: ' + signatureId);
    var sig = mcSettingsCoreV01RowObject_(sh.getRange(row, 1, 1, sh.getLastColumn()).getValues()[0], hm);
    if (String(sig.signatureStatus || 'ACTIVE').toUpperCase() !== 'ACTIVE') throw new Error('사용중지된 서명은 기본서명으로 지정할 수 없습니다.');
    mcSettingsCoreV01ClearDefaultSignature_(sh, sig.mailAccountId);
    mcSettingsCoreV01SetCell_(sh, hm, row, 'isDefault', 'TRUE');
    mcSettingsCoreV01SetCell_(sh, hm, row, 'statusReason', '기본 서명 지정');
    mcSettingsCoreV01SetCell_(sh, hm, row, 'updatedAt', mcSettingsCoreV01Now_());
    mcSettingsCoreV01SetCell_(sh, hm, row, 'updatedBy', mcSettingsCoreV01User_());
    mcSettingsCoreV01AppendAudit_(ss, 'MailCenter_Signatures', signatureId, sig.mailAccountId || '', 'SET_DEFAULT_SIGNATURE', JSON.stringify(sig), '기본 서명 지정');
    result.ok = true;
    result.signatureId = signatureId;
    result.message = '기본 서명 지정 완료';
  } catch (err) {
    result.ok = false;
    result.message = String(err && err.message ? err.message : err);
  }

  mcSettingsCoreV01Log_(result);
  return mcSettingsCoreV01Safe_(result);
}

function mcSettingsCoreV01DisableSignature(payload) {
  var result = {
    ok: false,
    build: MC_SETTINGS_CORE_V01_BUILD,
    action: 'mcSettingsCoreV01DisableSignature',
    generatedAt: mcSettingsCoreV01Now_(),
    message: '',
    signatureId: ''
  };

  try {
    var signatureId = mcSettingsCoreV01Require_((payload || {}).signatureId, 'signatureId');
    var reason = String((payload || {}).reason || '사용중지').trim();
    var ss = mcSettingsCoreV01OpenMaster_().ss;
    mcSettingsCoreV01EnsureSheets_(ss);
    var sh = ss.getSheetByName('MailCenter_Signatures');
    var hm = mcSettingsCoreV01HeaderMap_(mcSettingsCoreV01Headers_(sh));
    var row = mcSettingsCoreV01FindRow_(sh, hm, 'signatureId', signatureId);
    if (row < 1) throw new Error('서명을 찾을 수 없습니다: ' + signatureId);
    mcSettingsCoreV01SetCell_(sh, hm, row, 'signatureStatus', 'INACTIVE');
    mcSettingsCoreV01SetCell_(sh, hm, row, 'isDefault', 'FALSE');
    mcSettingsCoreV01SetCell_(sh, hm, row, 'statusReason', reason);
    mcSettingsCoreV01SetCell_(sh, hm, row, 'updatedAt', mcSettingsCoreV01Now_());
    mcSettingsCoreV01SetCell_(sh, hm, row, 'updatedBy', mcSettingsCoreV01User_());
    mcSettingsCoreV01AppendAudit_(ss, 'MailCenter_Signatures', signatureId, '', 'DISABLE_SIGNATURE', '', reason);
    result.ok = true;
    result.signatureId = signatureId;
    result.message = '서명 사용중지 완료';
  } catch (err) {
    result.ok = false;
    result.message = String(err && err.message ? err.message : err);
  }

  mcSettingsCoreV01Log_(result);
  return mcSettingsCoreV01Safe_(result);
}

function mcSettingsCoreV01DisableFolder(payload) {
  var result = {
    ok: false,
    build: MC_SETTINGS_CORE_V01_BUILD,
    action: 'mcSettingsCoreV01DisableFolder',
    generatedAt: mcSettingsCoreV01Now_(),
    message: '',
    folderId: ''
  };

  try {
    var folderId = mcSettingsCoreV01Require_((payload || {}).folderId, 'folderId');
    var reason = String((payload || {}).reason || '사용중지').trim();
    var ss = mcSettingsCoreV01OpenMaster_().ss;
    mcSettingsCoreV01EnsureSheets_(ss);
    var sh = ss.getSheetByName('MailCenter_Folders');
    var hm = mcSettingsCoreV01HeaderMap_(mcSettingsCoreV01Headers_(sh));
    var row = mcSettingsCoreV01FindRow_(sh, hm, 'folderId', folderId);
    if (row < 1) throw new Error('폴더를 찾을 수 없습니다: ' + folderId);
    mcSettingsCoreV01SetCell_(sh, hm, row, 'folderStatus', 'INACTIVE');
    mcSettingsCoreV01SetCell_(sh, hm, row, 'statusReason', reason);
    mcSettingsCoreV01SetCell_(sh, hm, row, 'updatedAt', mcSettingsCoreV01Now_());
    mcSettingsCoreV01SetCell_(sh, hm, row, 'updatedBy', mcSettingsCoreV01User_());
    mcSettingsCoreV01AppendAudit_(ss, 'MailCenter_Folders', folderId, '', 'DISABLE_FOLDER', '', reason);
    result.ok = true;
    result.folderId = folderId;
    result.message = '폴더 사용중지 완료';
  } catch (err) {
    result.ok = false;
    result.message = String(err && err.message ? err.message : err);
  }

  mcSettingsCoreV01Log_(result);
  return mcSettingsCoreV01Safe_(result);
}


function mcSettingsCoreV01SetDefaultFolder(payload) {
  var result = {
    ok: false,
    build: MC_SETTINGS_CORE_V01_BUILD,
    action: 'mcSettingsCoreV01SetDefaultFolder',
    generatedAt: mcSettingsCoreV01Now_(),
    message: '',
    folderId: ''
  };

  try {
    var folderId = mcSettingsCoreV01Require_((payload || {}).folderId, 'folderId');
    var ss = mcSettingsCoreV01OpenMaster_().ss;
    mcSettingsCoreV01EnsureSheets_(ss);

    var folderSheet = ss.getSheetByName('MailCenter_Folders');
    var folderHm = mcSettingsCoreV01HeaderMap_(mcSettingsCoreV01Headers_(folderSheet));
    var folderRow = mcSettingsCoreV01FindRow_(folderSheet, folderHm, 'folderId', folderId);
    if (folderRow < 1) throw new Error('폴더를 찾을 수 없습니다: ' + folderId);
    var folder = mcSettingsCoreV01RowObject_(folderSheet.getRange(folderRow, 1, 1, folderSheet.getLastColumn()).getValues()[0], folderHm);
    if (String(folder.folderStatus || 'ACTIVE').toUpperCase() !== 'ACTIVE') throw new Error('사용중지된 폴더는 기본 폴더로 지정할 수 없습니다.');

    var prefSheet = ss.getSheetByName('MailCenter_Preferences');
    var headers = mcSettingsCoreV01Headers_(prefSheet);
    var hm = mcSettingsCoreV01HeaderMap_(headers);
    var values = prefSheet.getDataRange().getValues();
    for (var r = 1; r < values.length; r++) {
      if (String(mcSettingsCoreV01Cell_(values[r], hm, 'preferenceKey')) === 'DEFAULT_FOLDER') {
        mcSettingsCoreV01SetCell_(prefSheet, hm, r + 1, 'preferenceStatus', 'INACTIVE');
        mcSettingsCoreV01SetCell_(prefSheet, hm, r + 1, 'updatedAt', mcSettingsCoreV01Now_());
        mcSettingsCoreV01SetCell_(prefSheet, hm, r + 1, 'updatedBy', mcSettingsCoreV01User_());
      }
    }

    var obj = {
      preferenceId: mcSettingsCoreV01NewId_('MCPREF'),
      preferenceScope: 'GLOBAL',
      ownerType: '',
      ownerId: '',
      mailAccountId: '',
      emailAddress: '',
      preferenceKey: 'DEFAULT_FOLDER',
      preferenceValue: folderId,
      preferenceStatus: 'ACTIVE',
      createdAt: mcSettingsCoreV01Now_(),
      createdBy: mcSettingsCoreV01User_(),
      updatedAt: mcSettingsCoreV01Now_(),
      updatedBy: mcSettingsCoreV01User_()
    };

    prefSheet.appendRow(headers.map(function(h) { return obj[h] !== undefined ? obj[h] : ''; }));
    mcSettingsCoreV01AppendAudit_(ss, 'MailCenter_Preferences', obj.preferenceId, folderId, 'SET_DEFAULT_FOLDER', JSON.stringify(obj), '기본 폴더 설정');
    result.ok = true;
    result.folderId = folderId;
    result.message = '기본 폴더 설정 완료';
  } catch (err) {
    result.ok = false;
    result.message = String(err && err.message ? err.message : err);
  }

  mcSettingsCoreV01Log_(result);
  return mcSettingsCoreV01Safe_(result);
}

function mcSettingsCoreV01SetDefaultAccount(payload) {
  var result = {
    ok: false,
    build: MC_SETTINGS_CORE_V01_BUILD,
    action: 'mcSettingsCoreV01SetDefaultAccount',
    generatedAt: mcSettingsCoreV01Now_(),
    message: ''
  };

  try {
    var mailAccountId = mcSettingsCoreV01Require_((payload || {}).mailAccountId, 'mailAccountId');
    var ss = mcSettingsCoreV01OpenMaster_().ss;
    mcSettingsCoreV01EnsureSheets_(ss);
    var account = mcSettingsCoreV01GetAccount_(ss, mailAccountId);

    var sh = ss.getSheetByName('MailCenter_Preferences');
    var headers = mcSettingsCoreV01Headers_(sh);
    var hm = mcSettingsCoreV01HeaderMap_(headers);
    var values = sh.getDataRange().getValues();

    for (var r = 1; r < values.length; r++) {
      if (String(mcSettingsCoreV01Cell_(values[r], hm, 'preferenceKey')) === 'DEFAULT_SEND_ACCOUNT') {
        mcSettingsCoreV01SetCell_(sh, hm, r + 1, 'preferenceStatus', 'INACTIVE');
        mcSettingsCoreV01SetCell_(sh, hm, r + 1, 'updatedAt', mcSettingsCoreV01Now_());
      }
    }

    var obj = {
      preferenceId: mcSettingsCoreV01NewId_('MCPREF'),
      preferenceScope: 'GLOBAL',
      ownerType: account.ownerType || '',
      ownerId: account.ownerEmployeeId || account.ownerUserId || account.vendorId || '',
      mailAccountId: mailAccountId,
      emailAddress: account.emailAddress || '',
      preferenceKey: 'DEFAULT_SEND_ACCOUNT',
      preferenceValue: mailAccountId,
      preferenceStatus: 'ACTIVE',
      createdAt: mcSettingsCoreV01Now_(),
      createdBy: mcSettingsCoreV01User_(),
      updatedAt: mcSettingsCoreV01Now_(),
      updatedBy: mcSettingsCoreV01User_()
    };

    sh.appendRow(headers.map(function(h) { return obj[h] !== undefined ? obj[h] : ''; }));
    mcSettingsCoreV01AppendAudit_(ss, 'MailCenter_Preferences', obj.preferenceId, mailAccountId, 'SET_DEFAULT_ACCOUNT', JSON.stringify(obj), '기본 발신계정 설정');

    result.ok = true;
    result.message = '기본 발신계정 설정 완료';
  } catch (err) {
    result.ok = false;
    result.message = String(err && err.message ? err.message : err);
  }

  mcSettingsCoreV01Log_(result);
  return mcSettingsCoreV01Safe_(result);
}


function mcSettingsCoreV01SavePolicySettings(payload) {
  var result = {
    ok: false,
    build: MC_SETTINGS_CORE_V01_BUILD,
    action: 'mcSettingsCoreV01SavePolicySettings',
    generatedAt: mcSettingsCoreV01Now_(),
    message: '',
    savedKeys: []
  };

  try {
    var p = payload || {};
    var policyGroup = String(p.policyGroup || 'GLOBAL').toUpperCase();
    var policies = p.policies || {};
    var allowed = mcSettingsCoreV01PolicyAllowedMap_();
    var keys = Object.keys(policies).filter(function(k) { return allowed[k]; });
    if (!keys.length) throw new Error('저장할 정책값이 없습니다.');

    var ss = mcSettingsCoreV01OpenMaster_().ss;
    mcSettingsCoreV01EnsureSheets_(ss);
    var sh = ss.getSheetByName('MailCenter_Preferences');
    var headers = mcSettingsCoreV01Headers_(sh);
    var hm = mcSettingsCoreV01HeaderMap_(headers);
    var values = sh.getDataRange().getValues();
    var now = mcSettingsCoreV01Now_();
    var actor = mcSettingsCoreV01User_();

    keys.forEach(function(key) {
      var val = mcSettingsCoreV01NormalizePolicyValue_(key, policies[key]);
      for (var r = 1; r < values.length; r++) {
        if (String(mcSettingsCoreV01Cell_(values[r], hm, 'preferenceKey')) === key &&
            String(mcSettingsCoreV01Cell_(values[r], hm, 'preferenceStatus')).toUpperCase() === 'ACTIVE') {
          mcSettingsCoreV01SetCell_(sh, hm, r + 1, 'preferenceStatus', 'INACTIVE');
          mcSettingsCoreV01SetCell_(sh, hm, r + 1, 'updatedAt', now);
          mcSettingsCoreV01SetCell_(sh, hm, r + 1, 'updatedBy', actor);
        }
      }
      var obj = {
        preferenceId: mcSettingsCoreV01NewId_('MCPREF'),
        preferenceScope: 'GLOBAL',
        ownerType: policyGroup,
        ownerId: '',
        mailAccountId: '',
        emailAddress: '',
        preferenceKey: key,
        preferenceValue: val,
        preferenceStatus: 'ACTIVE',
        createdAt: now,
        createdBy: actor,
        updatedAt: now,
        updatedBy: actor
      };
      sh.appendRow(headers.map(function(h) { return obj[h] !== undefined ? obj[h] : ''; }));
      result.savedKeys.push(key);
    });

    mcSettingsCoreV01AppendAudit_(ss, 'MailCenter_Preferences', policyGroup, '', 'SAVE_POLICY_SETTINGS', JSON.stringify({ policyGroup: policyGroup, policies: policies }), '기본 발송/첨부 정책 저장');
    result.ok = true;
    result.message = '정책 설정 저장 완료';
  } catch (err) {
    result.ok = false;
    result.message = String(err && err.message ? err.message : err);
  }

  mcSettingsCoreV01Log_(result);
  return mcSettingsCoreV01Safe_(result);
}

function mcSettingsCoreV01BuildPolicyMap_(prefs) {
  var out = {};
  (prefs || []).forEach(function(p) {
    if (String(p.preferenceStatus || '').toUpperCase() !== 'ACTIVE') return;
    var k = String(p.preferenceKey || '');
    if (!k) return;
    out[k] = p.preferenceValue;
  });
  return out;
}

function mcSettingsCoreV01PolicyAllowedMap_() {
  return {
    CONFIRM_BEFORE_SEND: true,
    DEFAULT_SUBJECT_PREFIX: true,
    SEND_LOG_LEVEL: true,
    RECIPIENT_LIMIT: true,
    DEFAULT_ATTACHMENT_SHARE_MODE: true,
    ATTACHMENT_SECTION_TITLE: true,
    ATTACHMENT_LINK_TEXT: true,
    ATTACHMENT_MAX_FILE_COUNT: true,
    ATTACHMENT_CHUNK_MB: true,
    ATTACHMENT_ALLOWED_EXTENSIONS: true,
    ATTACHMENT_BLOCKED_EXTENSIONS: true
  };
}

function mcSettingsCoreV01NormalizePolicyValue_(key, value) {
  var v = String(value == null ? '' : value).trim();
  if (key === 'CONFIRM_BEFORE_SEND') return v.toUpperCase() === 'FALSE' ? 'FALSE' : 'TRUE';
  if (key === 'DEFAULT_ATTACHMENT_SHARE_MODE') return v.toUpperCase() === 'PRIVATE' ? 'PRIVATE' : 'PUBLIC_LINK';
  if (key === 'SEND_LOG_LEVEL') return v.toUpperCase() === 'BASIC' ? 'BASIC' : 'DETAIL';
  if (key === 'RECIPIENT_LIMIT') return String(Math.max(1, Math.min(500, Number(v || 50))));
  if (key === 'ATTACHMENT_MAX_FILE_COUNT') return String(Math.max(1, Math.min(50, Number(v || 10))));
  if (key === 'ATTACHMENT_CHUNK_MB') return String(Math.max(1, Math.min(15, Number(v || 5))));
  if (key === 'DEFAULT_SUBJECT_PREFIX') return v.substring(0, 80);
  if (key === 'ATTACHMENT_SECTION_TITLE') return v.substring(0, 80) || '첨부파일 다운로드';
  if (key === 'ATTACHMENT_LINK_TEXT') return v.substring(0, 120) || '파일명을 클릭하여 다운로드하세요.';
  if (key === 'ATTACHMENT_ALLOWED_EXTENSIONS' || key === 'ATTACHMENT_BLOCKED_EXTENSIONS') return v.replace(/\s+/g, '').substring(0, 300);
  return v.substring(0, 500);
}

function mcSettingsCoreV01EnsureSheets_(ss) {
  mcSettingsCoreV01GetSheetOrCreate_(ss, 'MailCenter_Signatures', [
    'signatureId','mailAccountId','emailAddress','signatureName','signatureHtml','signatureText',
    'isDefault','signatureStatus','statusReason','createdAt','createdBy','updatedAt','updatedBy'
  ]);

  mcSettingsCoreV01GetSheetOrCreate_(ss, 'MailCenter_Folders', [
    'folderId','folderName','folderType','folderColor','sortOrder','folderStatus','statusReason',
    'createdAt','createdBy','updatedAt','updatedBy'
  ]);

  mcSettingsCoreV01GetSheetOrCreate_(ss, 'MailCenter_Preferences', [
    'preferenceId','preferenceScope','ownerType','ownerId','mailAccountId','emailAddress',
    'preferenceKey','preferenceValue','preferenceStatus','createdAt','createdBy','updatedAt','updatedBy'
  ]);

  mcSettingsCoreV01GetSheetOrCreate_(ss, 'MailCenter_AuditLogs', [
    'mailAuditLogId','targetType','targetId','vendorId','eventId','actionType',
    'beforeValue','afterValue','reason','createdAt','createdBy'
  ]);
}

function mcSettingsCoreV01ReadAccounts_(ss) {
  var sh = ss.getSheetByName('MailCenter_Accounts');
  if (!sh) return [];
  return mcSettingsCoreV01ReadSheet_(ss, 'MailCenter_Accounts').filter(function(a) { return !!a.emailAddress; });
}

function mcSettingsCoreV01ReadSheet_(ss, sheetName) {
  var sh = ss.getSheetByName(sheetName);
  if (!sh) return [];
  var values = sh.getDataRange().getValues();
  if (!values || values.length < 2) return [];
  var hm = mcSettingsCoreV01HeaderMap_(values[0]);
  var rows = [];
  for (var r = 1; r < values.length; r++) {
    var obj = mcSettingsCoreV01RowObject_(values[r], hm);
    if (Object.keys(obj).some(function(k) { return obj[k] !== '' && obj[k] != null; })) rows.push(obj);
  }
  return rows;
}

function mcSettingsCoreV01GetAccount_(ss, mailAccountId) {
  var accounts = mcSettingsCoreV01ReadAccounts_(ss);
  for (var i = 0; i < accounts.length; i++) {
    if (String(accounts[i].mailAccountId) === String(mailAccountId)) return accounts[i];
  }
  throw new Error('메일 계정을 찾을 수 없습니다: ' + mailAccountId);
}

function mcSettingsCoreV01ClearDefaultSignature_(sh, mailAccountId) {
  var values = sh.getDataRange().getValues();
  if (!values || values.length < 2) return;
  var hm = mcSettingsCoreV01HeaderMap_(values[0]);
  for (var r = 1; r < values.length; r++) {
    if (String(mcSettingsCoreV01Cell_(values[r], hm, 'mailAccountId')) === String(mailAccountId)) {
      mcSettingsCoreV01SetCell_(sh, hm, r + 1, 'isDefault', 'FALSE');
    }
  }
}

function mcSettingsCoreV01GetSheetOrCreate_(ss, sheetName, headers) {
  var sh = ss.getSheetByName(sheetName);
  if (!sh) sh = ss.insertSheet(sheetName);
  var lastCol = sh.getLastColumn();
  if (lastCol < 1) {
    sh.getRange(1, 1, 1, headers.length).setValues([headers]);
    return sh;
  }
  var existing = sh.getRange(1, 1, 1, lastCol).getValues()[0].map(function(v) { return String(v || '').trim(); });
  var append = [];
  headers.forEach(function(h) { if (existing.indexOf(h) < 0) append.push(h); });
  if (append.length) sh.getRange(1, existing.length + 1, 1, append.length).setValues([append]);
  return sh;
}

function mcSettingsCoreV01AppendAudit_(ss, targetType, targetId, mailAccountId, actionType, afterValue, reason) {
  var sh = ss.getSheetByName('MailCenter_AuditLogs');
  if (!sh) return;
  var headers = mcSettingsCoreV01Headers_(sh);
  var rowObj = {
    mailAuditLogId: mcSettingsCoreV01NewId_('MCAUD'),
    targetType: targetType || '',
    targetId: targetId || '',
    vendorId: '',
    eventId: '',
    actionType: actionType || '',
    beforeValue: '',
    afterValue: afterValue || '',
    reason: reason || '',
    createdAt: mcSettingsCoreV01Now_(),
    createdBy: mcSettingsCoreV01User_()
  };
  sh.appendRow(headers.map(function(h) { return rowObj[h] !== undefined ? rowObj[h] : ''; }));
}

function mcSettingsCoreV01OpenMaster_() {
  if (typeof portal19GetConfigBundle_ === 'function' && typeof portal19OpenMaster_ === 'function') {
    var bundle = portal19GetConfigBundle_();
    var ssByPortal = portal19OpenMaster_(bundle);
    if (ssByPortal) return { ss: ssByPortal, masterDbId: bundle.masterDbId || '' };
  }
  var setup = SpreadsheetApp.openById(MC_SETTINGS_CORE_V01_SETUP_DB_ID);
  var configSheet = setup.getSheetByName(MC_SETTINGS_CORE_V01_CONFIG_SHEET);
  if (!configSheet) throw new Error('SystemConfig 시트를 찾지 못했습니다.');
  var values = configSheet.getDataRange().getValues();
  var hm = mcSettingsCoreV01HeaderMap_(values[0]);
  var keyCol = mcSettingsCoreV01FindHeader_(hm, ['CONFIG_KEY','configKey','KEY','key']);
  var valCol = mcSettingsCoreV01FindHeader_(hm, ['VALUE','CONFIG_VALUE','configValue','value']);
  var masterId = '';
  for (var r = 1; r < values.length; r++) {
    var key = String(values[r][keyCol] || '').trim();
    if (key === 'FEELHAUS_DB_MASTER' || key === 'FEELHAUS_DB_MASTER_ID' || key === 'MASTER_DB_ID') {
      masterId = String(values[r][valCol] || '').trim();
      break;
    }
  }
  if (!masterId) throw new Error('SystemConfig에서 FEELHAUS_DB_MASTER ID를 찾지 못했습니다.');
  return { ss: SpreadsheetApp.openById(masterId), masterDbId: masterId };
}

function mcSettingsCoreV01Headers_(sh) {
  return sh.getRange(1, 1, 1, sh.getLastColumn()).getValues()[0].map(function(h) { return String(h || '').trim(); });
}
function mcSettingsCoreV01HeaderMap_(header) {
  var hm = {};
  for (var i = 0; i < header.length; i++) {
    var raw = String(header[i] || '').trim();
    if (!raw) continue;
    hm[raw] = i;
    var norm = mcSettingsCoreV01Normalize_(raw);
    if (hm[norm] == null) hm[norm] = i;
  }
  return hm;
}
function mcSettingsCoreV01FindHeader_(hm, names) {
  for (var i = 0; i < names.length; i++) {
    if (hm[names[i]] != null) return hm[names[i]];
    var norm = mcSettingsCoreV01Normalize_(names[i]);
    if (hm[norm] != null) return hm[norm];
  }
  return -1;
}
function mcSettingsCoreV01Cell_(row, hm, key) {
  var idx = hm[key];
  if (idx == null) idx = hm[mcSettingsCoreV01Normalize_(key)];
  if (idx == null) return '';
  return row[idx];
}
function mcSettingsCoreV01SetCell_(sh, hm, row, key, value) {
  var idx = hm[key];
  if (idx == null) idx = hm[mcSettingsCoreV01Normalize_(key)];
  if (idx == null) return;
  sh.getRange(row, idx + 1).setValue(value);
}
function mcSettingsCoreV01RowObject_(row, hm) {
  var obj = {};
  Object.keys(hm).forEach(function(k) {
    if (k === mcSettingsCoreV01Normalize_(k)) return;
    var val = row[hm[k]];
    obj[k] = val instanceof Date ? Utilities.formatDate(val, Session.getScriptTimeZone() || 'Asia/Seoul', 'yyyy-MM-dd HH:mm:ss') : val;
  });
  return obj;
}
function mcSettingsCoreV01FindRow_(sh, hm, key, value) {
  var values = sh.getDataRange().getValues();
  for (var r = 1; r < values.length; r++) {
    if (String(mcSettingsCoreV01Cell_(values[r], hm, key)) === String(value)) return r + 1;
  }
  return -1;
}

function mcSettingsCoreV01AssertUniqueActive_(sh, hm, opt) {
  var values = sh.getDataRange().getValues();
  var idKey = opt.idKey;
  var idValue = String(opt.idValue || '').trim();
  var nameKey = opt.nameKey;
  var nameValue = String(opt.nameValue || '').trim().toLowerCase();
  var statusKey = opt.statusKey;
  var scopeKey = opt.scopeKey || '';
  var scopeValue = String(opt.scopeValue || '').trim();
  for (var r = 1; r < values.length; r++) {
    var rowId = String(mcSettingsCoreV01Cell_(values[r], hm, idKey) || '').trim();
    if (idValue && rowId === idValue) continue;
    var rowName = String(mcSettingsCoreV01Cell_(values[r], hm, nameKey) || '').trim().toLowerCase();
    if (rowName !== nameValue) continue;
    if (scopeKey && String(mcSettingsCoreV01Cell_(values[r], hm, scopeKey) || '').trim() !== scopeValue) continue;
    var status = String(mcSettingsCoreV01Cell_(values[r], hm, statusKey) || 'ACTIVE').toUpperCase();
    if (status === 'ACTIVE') throw new Error((opt.label || '중복 항목') + '이 이미 있습니다.');
  }
}

function mcSettingsCoreV01StripHtml_(html) {
  return String(html || '').replace(/<[^>]*>/g, ' ').replace(/\s+/g, ' ').trim();
}
function mcSettingsCoreV01NewId_(prefix) {
  return prefix + '-' + Utilities.formatDate(new Date(), Session.getScriptTimeZone() || 'Asia/Seoul', 'yyyyMMddHHmmss') + '-' + Math.floor(Math.random() * 9000 + 1000);
}
function mcSettingsCoreV01Normalize_(v) { return String(v || '').trim().toUpperCase().replace(/[^A-Z0-9]/g, ''); }
function mcSettingsCoreV01Require_(v, name) { var s = String(v || '').trim(); if (!s) throw new Error(name + ' 값이 필요합니다.'); return s; }
function mcSettingsCoreV01User_() { try { return Session.getActiveUser().getEmail() || ''; } catch(e) { return ''; } }
function mcSettingsCoreV01Now_() { return Utilities.formatDate(new Date(), Session.getScriptTimeZone() || 'Asia/Seoul', 'yyyy-MM-dd HH:mm:ss'); }
function mcSettingsCoreV01Safe_(obj) { try { return JSON.parse(JSON.stringify(obj)); } catch(e) { return { ok:false, build: MC_SETTINGS_CORE_V01_BUILD, message: String(e) }; } }
function mcSettingsCoreV01Log_(obj) { try { Logger.log('JSON_COMPACT_RESULT: ' + JSON.stringify(obj)); } catch(e) { Logger.log(obj); } }
