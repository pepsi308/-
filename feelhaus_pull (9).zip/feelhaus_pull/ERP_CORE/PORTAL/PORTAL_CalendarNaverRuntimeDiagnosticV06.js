/**
 * PORTAL_CALENDAR_STEP08_NAVER_RUNTIME_DIAG_V06_20260601
 * Purpose: runtime diagnostics for NAVER Calendar createSchedule.json create/modify flow.
 * Safety: read-only for sheets/config; does not create or modify NAVER schedules unless explicitly called by caller with a real request.
 */

var PORTAL_CALENDAR_STEP08_NAVER_RUNTIME_DIAG_V06_20260601 = 'PORTAL_CALENDAR_STEP08_NAVER_RUNTIME_DIAG_V06_20260601';

function portalCalendarStep08NaverRuntimeDiagnoseV06() {
  var result = {
    ok: false,
    build: PORTAL_CALENDAR_STEP08_NAVER_RUNTIME_DIAG_V06_20260601,
    action: 'portalCalendarStep08NaverRuntimeDiagnoseV06',
    safety: 'READ_ONLY_CONFIG_AND_TOKEN_STATUS_NO_NAVER_WRITE',
    generatedAt: portalCalendarStep08NaverDiagNowV06_(),
    config: {},
    token: {},
    naver: {},
    fatal: [],
    warnings: []
  };
  try {
    var cfg = portalCalendarStep08NaverDiagConfigV06_();
    var token = String(cfg.NAVER_CALENDAR_ACCESS_TOKEN || '').trim();
    var refresh = String(cfg.NAVER_REFRESH_TOKEN || '').trim();
    var createUrl = String(cfg.NAVER_CALENDAR_CREATE_URL || 'https://openapi.naver.com/calendar/createSchedule.json').trim();
    var calendarId = String(cfg.NAVER_UPDATE_CALENDAR_ID || cfg.NAVER_NUMERIC_CALENDAR_ID || '').trim();
    var expiresAt = String(cfg.NAVER_TOKEN_EXPIRES_AT || '').trim();
    var enabled = String(cfg.NAVER_CALENDAR_ENABLED || '').toUpperCase() === 'Y';
    var featureEnabled = String(cfg.FEATURE_NAVER_CALENDAR_ENABLED || '').toUpperCase() === 'Y';
    var expired = portalCalendarStep08NaverDiagIsExpiredV06_(expiresAt);

    result.config = {
      NAVER_CALENDAR_ENABLED: cfg.NAVER_CALENDAR_ENABLED || '',
      FEATURE_NAVER_CALENDAR_ENABLED: cfg.FEATURE_NAVER_CALENDAR_ENABLED || '',
      NAVER_CALENDAR_CREATE_URL: createUrl,
      NAVER_UPDATE_CALENDAR_ID: cfg.NAVER_UPDATE_CALENDAR_ID || '',
      NAVER_NUMERIC_CALENDAR_ID: cfg.NAVER_NUMERIC_CALENDAR_ID || ''
    };
    result.token = {
      accessTokenExists: !!token,
      refreshTokenExists: !!refresh,
      expiresAt: expiresAt,
      expiredOrUnknown: expired
    };
    result.naver = {
      effectiveCalendarId: calendarId,
      createScheduleEndpoint: createUrl,
      officialCreateModifyMode: createUrl.indexOf('/calendar/createSchedule.json') >= 0
    };

    if (!enabled) result.fatal.push('NAVER_CALENDAR_ENABLED_NOT_Y');
    if (!featureEnabled) result.fatal.push('FEATURE_NAVER_CALENDAR_ENABLED_NOT_Y');
    if (!token) result.fatal.push('NAVER_ACCESS_TOKEN_MISSING');
    if (!refresh) result.warnings.push('NAVER_REFRESH_TOKEN_MISSING');
    if (expired) result.fatal.push('NAVER_ACCESS_TOKEN_EXPIRED_OR_UNKNOWN');
    if (!calendarId) result.fatal.push('NAVER_UPDATE_CALENDAR_ID_MISSING');
    if (createUrl.indexOf('/calendar/createSchedule.json') < 0) result.fatal.push('NAVER_CREATE_SCHEDULE_URL_NOT_OFFICIAL');

    result.ok = result.fatal.length === 0;
    Logger.log('JSON_COMPACT_RESULT: ' + JSON.stringify(result));
    return result;
  } catch (err) {
    result.fatal.push('EXCEPTION');
    result.error = String(err && err.stack ? err.stack : err);
    Logger.log('JSON_COMPACT_RESULT: ' + JSON.stringify(result));
    return result;
  }
}

function portalCalendarStep08NaverDiagConfigV06_() {
  var out = {};
  var ssId = '17VMSpgSZCvIrUlgcw8yCNcnl8WQWo2IcRf5tDCcuJGM';
  var sheetName = 'SystemConfig';
  try {
    if (typeof PropertiesService !== 'undefined') {
      var p = PropertiesService.getScriptProperties();
      ssId = p.getProperty('SETUP_DB_ID') || p.getProperty('FEELHAUS_SETUP_DB_ID') || ssId;
      sheetName = p.getProperty('CONFIG_SHEET_NAME') || sheetName;
    }
  } catch (ignore) {}
  var ss = SpreadsheetApp.openById(ssId);
  var sh = ss.getSheetByName(sheetName);
  if (!sh) throw new Error('SystemConfig sheet not found: ' + sheetName);
  var values = sh.getDataRange().getValues();
  if (!values.length) return out;
  var header = values[0].map(function(h){ return String(h || '').trim(); });
  var keyCol = header.indexOf('CONFIG_KEY');
  var valCol = header.indexOf('VALUE');
  var statusCol = header.indexOf('status');
  if (keyCol < 0) keyCol = 0;
  if (valCol < 0) valCol = 1;
  for (var r = 1; r < values.length; r++) {
    var key = String(values[r][keyCol] || '').trim();
    if (!key) continue;
    var status = statusCol >= 0 ? String(values[r][statusCol] || '').trim().toUpperCase() : 'ACTIVE';
    if (status && status !== 'ACTIVE') continue;
    out[key] = values[r][valCol];
  }
  return out;
}

function portalCalendarStep08NaverDiagIsExpiredV06_(expiresAt) {
  if (!expiresAt) return true;
  var d = new Date(expiresAt);
  if (isNaN(d.getTime())) return true;
  return d.getTime() <= new Date().getTime();
}

function portalCalendarStep08NaverDiagNowV06_() {
  return Utilities.formatDate(new Date(), 'Asia/Seoul', 'yyyy-MM-dd HH:mm:ss');
}

function portalCalendarStep08NaverBuildDiagnosticMessageV06_(diag) {
  diag = diag || portalCalendarStep08NaverRuntimeDiagnoseV06();
  return [
    'NAVER 진단 V06',
    'ok=' + diag.ok,
    'calendarId=' + ((diag.naver && diag.naver.effectiveCalendarId) || ''),
    'endpoint=' + ((diag.naver && diag.naver.createScheduleEndpoint) || ''),
    'tokenExists=' + ((diag.token && diag.token.accessTokenExists) ? 'Y' : 'N'),
    'tokenExpired=' + ((diag.token && diag.token.expiredOrUnknown) ? 'Y' : 'N'),
    'expiresAt=' + ((diag.token && diag.token.expiresAt) || ''),
    'fatal=' + (diag.fatal || []).join('|'),
    'warnings=' + (diag.warnings || []).join('|')
  ].join(' / ');
}
