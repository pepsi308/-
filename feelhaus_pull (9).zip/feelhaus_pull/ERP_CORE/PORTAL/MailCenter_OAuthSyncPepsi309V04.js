/**
 * FEELHAUS MailCenter OAuth Sync Pepsi309 FAST V04
 * Build: MAILCENTER_OAUTH_SYNC_PEPSI309_FAST_V04_20260519
 * Purpose:
 * - 매개변수 없이 pepsi309@gmail.com OAuth 연결상태를 MailCenter_OAuthConnections에 동기화한다.
 * - 기존 MailCenter_OAuthConnect.js / Portal_Run169 / Portal_Run171은 건드리지 않는다.
 */

var MAILCENTER_OAUTH_SYNC_PEPSI309_V04_BUILD = 'MAILCENTER_OAUTH_SYNC_PEPSI309_FAST_V04_20260519';

/**
 * 실행 함수: 이것 1개만 실행
 * 파일명: MailCenter_OAuthSyncPepsi309V04.js
 */
function runMailCenterSyncOAuthPepsi309FastV04() {
  var payload = {
    mailAccountId: 'MAILACC-20260519084815-7841',
    connectorMailAccountId: 'MAILACC-20260519084829-9777',
    emailAddress: 'pepsi309@gmail.com',
    ownerType: 'HQ',
    vendorId: ''
  };

  var result = {
    ok: false,
    build: MAILCENTER_OAUTH_SYNC_PEPSI309_V04_BUILD,
    action: 'runMailCenterSyncOAuthPepsi309FastV04',
    message: '',
    generatedAt: mailCenterOAuthSyncV04Now_(),
    payload: payload,
    syncResult: null
  };

  try {
    if (typeof mailCenterSyncOAuthConnectionStatus !== 'function') {
      throw new Error('mailCenterSyncOAuthConnectionStatus 함수가 없습니다. MailCenter_OAuthConnect.js 적용 상태를 확인하세요.');
    }

    var syncResult = mailCenterSyncOAuthConnectionStatus('', payload);
    result.syncResult = syncResult;
    result.ok = !!(syncResult && syncResult.ok);
    result.message = result.ok ? 'pepsi309@gmail.com OAuth 연결상태 동기화 완료' : 'OAuth 연결상태 동기화 실패';
  } catch (err) {
    result.ok = false;
    result.message = String(err && err.message ? err.message : err);
  }

  mailCenterOAuthSyncV04Log_(result);
  return result;
}

/**
 * 마지막 pepsi309 동기화 상태 빠른 확인
 */
function getMailCenterPepsi309OAuthSyncStatusV04() {
  var result = {
    ok: false,
    build: MAILCENTER_OAUTH_SYNC_PEPSI309_V04_BUILD,
    action: 'getMailCenterPepsi309OAuthSyncStatusV04',
    generatedAt: mailCenterOAuthSyncV04Now_(),
    emailAddress: 'pepsi309@gmail.com',
    mailAccountId: 'MAILACC-20260519084815-7841',
    connectorMailAccountId: 'MAILACC-20260519084829-9777',
    status: null,
    row: null
  };

  try {
    var ss = mailCenterOAuthSyncV04GetMasterSpreadsheet_();
    var sh = ss.getSheetByName('MailCenter_OAuthConnections');
    if (!sh) throw new Error('MailCenter_OAuthConnections 시트가 없습니다.');

    var values = sh.getDataRange().getValues();
    if (!values || values.length < 2) {
      result.ok = true;
      result.status = 'NO_ROWS';
      return result;
    }

    var header = values[0];
    var hm = {};
    header.forEach(function(h, i) { hm[String(h)] = i; });

    var emailIdx = hm.emailAddress;
    var mailIdx = hm.mailAccountId;
    var statusIdx = hm.oauthStatus;

    for (var r = values.length - 1; r >= 1; r--) {
      var row = values[r];
      if ((emailIdx != null && row[emailIdx] === 'pepsi309@gmail.com') ||
          (mailIdx != null && row[mailIdx] === 'MAILACC-20260519084815-7841')) {
        result.ok = true;
        result.status = statusIdx != null ? row[statusIdx] : '';
        result.row = row;
        return result;
      }
    }

    result.ok = true;
    result.status = 'NOT_FOUND';
    return result;
  } catch (err) {
    result.ok = false;
    result.message = String(err && err.message ? err.message : err);
    return result;
  }
}

function mailCenterOAuthSyncV04Now_() {
  return Utilities.formatDate(new Date(), Session.getScriptTimeZone() || 'Asia/Seoul', 'yyyy-MM-dd HH:mm:ss');
}

function mailCenterOAuthSyncV04Log_(obj) {
  try {
    Logger.log('JSON_COMPACT_RESULT: ' + JSON.stringify(obj));
  } catch (e) {
    Logger.log(obj);
  }
}

function mailCenterOAuthSyncV04GetMasterSpreadsheet_() {
  if (typeof mailCenterOAuthGetMasterSpreadsheet_ === 'function') {
    return mailCenterOAuthGetMasterSpreadsheet_();
  }
  if (typeof mailCenterGetMasterSpreadsheet_ === 'function') {
    return mailCenterGetMasterSpreadsheet_();
  }
  if (typeof getMasterSpreadsheet_ === 'function') {
    return getMasterSpreadsheet_();
  }
  return SpreadsheetApp.getActiveSpreadsheet();
}
