/**
 * PORTAL_CALENDAR_STEP01_REBASE_VERIFY_V03_20260531
 *
 * File:
 * - PORTAL_CALENDAR_STEP01_REBASE_VERIFY_V03_20260531.js
 *
 * Function:
 * - portalCalendarStep01RebaseVerifyV03
 */
function portalCalendarStep01RebaseVerifyV03() {
  var out = {
    ok: false,
    build: 'PORTAL_CALENDAR_STEP01_REBASE_VERIFY_V03_20260531',
    action: 'portalCalendarStep01RebaseVerifyV03',
    safety: 'READ_ONLY_NO_API_NO_SHEET_MUTATION',
    scope: 'UI_ONLY_MODAL_CLOSE_FULL_MONTH_LIST',
    checks: {},
    fatal: [],
    warnings: [],
    generatedAt: Utilities.formatDate(new Date(), 'Asia/Seoul', 'yyyy-MM-dd HH:mm:ss')
  };

  try {
    var html = HtmlService.createHtmlOutputFromFile('MC_CalendarViewV01').getContent();
    function has(s){ return String(html || '').indexOf(s) >= 0; }

    out.checks.uiLoaded = html.length > 1000;
    out.checks.closeManualEventModal = has('function closeManualEventModal()');
    out.checks.closeUsesImportant = has("setProperty('display','none','important')");
    out.checks.saveManualEvent = has('function saveManualEvent()');
    out.checks.saveCloseImmediate = has('closeManualEventModal();\n    setTimeout(closeManualEventModal,60);');
    out.checks.saveCloseRetry180 = has('setTimeout(closeManualEventModal,180);');
    out.checks.saveCloseRetry400 = has('setTimeout(closeManualEventModal,400);');
    out.checks.saveRefreshesMonthlyFullList = has('fhRefreshAfterManualSaveV09J14H(payload,res,doneMsg)');
    out.checks.fullListAfterSave = has("fhRenderPostSaveListV09J16A('',doneMsg");
    out.checks.reloadFullListAfterSave = has("fhReloadMonthAfterManualSaveV09J16A('',doneMsg");
    out.checks.noSelectedDayFocusAfterSave = has("reloadMonth({listMode:'all',message:state.pendingFocusMessage})");
    out.checks.moveMonthClearsFocus = has("function moveMonth(delta)") && has("state.pendingListMode='all';");
    out.checks.goTodayClearsFocus = has("function goToday()") && has("reloadMonth({listMode:'all'});");
    out.checks.renderListExists = has('function renderList()');
    out.checks.renderCalendarExists = has('function renderCalendar()');
    out.checks.noActorAudit = !has('portalActorAuditLockV01') && !has('PORTAL_ACTOR_AUDIT');

    Object.keys(out.checks).forEach(function(k){
      if (!out.checks[k]) out.fatal.push(k);
    });
    out.ok = out.fatal.length === 0;
  } catch (err) {
    out.ok = false;
    out.fatal.push(err && err.stack ? String(err.stack) : String(err && err.message ? err.message : err));
  }

  Logger.log('JSON_COMPACT_RESULT: ' + JSON.stringify(out));
  return out;
}
