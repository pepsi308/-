/**
 * PORTAL_CALENDAR_STEP08_NAVER_REQUEST_RESPONSE_TRACE_V09_20260601
 * NAVER request/response trace helper for createSchedule official UID mode.
 * Safety: this file does not execute NAVER writes by itself. It provides wrappers
 * and diagnostics that can be called from the existing NAVER save/update path.
 */
var PORTAL_CALENDAR_STEP08_NAVER_REQUEST_RESPONSE_TRACE_V09_20260601 = true;

function portalCalendarStep08NaverTraceBuildV09_(ctx) {
  ctx = ctx || {};
  var ical = String(ctx.scheduleIcalString || ctx.ical || '');
  var responseText = String(ctx.responseText || ctx.body || '');
  var parsed = portalCalendarStep08NaverTraceParseResponseV09_(responseText);
  var trace = {
    build: 'PORTAL_CALENDAR_STEP08_NAVER_REQUEST_RESPONSE_TRACE_V09_20260601',
    tracedAt: portalCalendarStep08NaverTraceNowV09_(),
    request: {
      calendarId: String(ctx.calendarId || ctx.naverCalendarId || ''),
      url: String(ctx.url || ctx.endpoint || 'https://openapi.naver.com/calendar/createSchedule.json'),
      httpMethod: String(ctx.method || 'post').toUpperCase(),
      uid: portalCalendarStep08NaverTracePickIcalFieldV09_(ical, 'UID'),
      summary: portalCalendarStep08NaverTracePickIcalFieldV09_(ical, 'SUMMARY'),
      dtStart: portalCalendarStep08NaverTracePickDateLineV09_(ical, 'DTSTART'),
      dtEnd: portalCalendarStep08NaverTracePickDateLineV09_(ical, 'DTEND'),
      timeZoneHint: portalCalendarStep08NaverTraceTimezoneHintV09_(ical),
      scheduleIcalString: ical
    },
    response: {
      httpCode: Number(ctx.httpCode || ctx.responseCode || 0),
      body: responseText,
      ok: parsed.ok,
      code: parsed.code,
      message: parsed.message,
      processType: parsed.processType,
      icalUid: parsed.icalUid,
      calendarId: parsed.calendarId,
      returnValue: parsed.returnValue
    },
    judgement: portalCalendarStep08NaverTraceJudgeV09_(ctx, parsed, ical)
  };
  return trace;
}

function portalCalendarStep08NaverTraceJudgeV09_(ctx, parsed, ical) {
  var httpCode = Number(ctx.httpCode || ctx.responseCode || 0);
  var uid = portalCalendarStep08NaverTracePickIcalFieldV09_(ical, 'UID');
  var dtStart = portalCalendarStep08NaverTracePickDateLineV09_(ical, 'DTSTART');
  var calendarId = String(ctx.calendarId || ctx.naverCalendarId || parsed.calendarId || '');
  var problems = [];
  if (!calendarId) problems.push('NAVER_CALENDAR_ID_MISSING');
  if (!uid) problems.push('NAVER_ICAL_UID_MISSING');
  if (!dtStart) problems.push('NAVER_ICAL_DTSTART_MISSING');
  if (httpCode >= 400) problems.push('NAVER_HTTP_ERROR_' + httpCode);
  if (String(parsed.processType || '').toLowerCase() === 'create' && ctx.existingNaverSuccess === true) {
    problems.push('NAVER_MODIFY_RETURNED_CREATE_DUPLICATE_RISK');
  }
  return {
    ok: problems.length === 0,
    problems: problems,
    display: portalCalendarStep08NaverTraceDisplayV09_({
      httpCode: httpCode,
      calendarId: calendarId,
      uid: uid,
      dtStart: dtStart,
      processType: parsed.processType,
      icalUid: parsed.icalUid,
      message: parsed.message,
      problems: problems
    })
  };
}

function portalCalendarStep08NaverTraceDisplayV09_(x) {
  var parts = [];
  parts.push('NAVER 응답진단 V09');
  parts.push('HTTP ' + (x.httpCode || 'UNKNOWN'));
  if (x.processType) parts.push('processType=' + x.processType);
  if (x.icalUid) parts.push('icalUid=' + x.icalUid);
  if (x.calendarId) parts.push('calendarId=' + x.calendarId);
  if (x.uid) parts.push('requestUid=' + x.uid);
  if (x.dtStart) parts.push('DTSTART=' + x.dtStart);
  if (x.message) parts.push('message=' + x.message);
  if (x.problems && x.problems.length) parts.push('problems=' + x.problems.join(','));
  return parts.join(' | ');
}

function portalCalendarStep08NaverTraceParseResponseV09_(text) {
  var out = { ok: false, code: '', message: '', processType: '', icalUid: '', calendarId: '', returnValue: null };
  if (!text) return out;
  try {
    var j = JSON.parse(text);
    out.ok = !!(j && (j.result === 'success' || j.code === 'success' || j.message === 'success' || j.returnValue));
    out.code = String(j.code || j.result || '');
    out.message = String(j.message || j.errorMessage || '');
    var rv = j.returnValue || j.response || j.resultValue || {};
    out.returnValue = rv;
    out.processType = String(rv.processType || rv.process_type || j.processType || '');
    out.icalUid = String(rv.icalUid || rv.icalUID || rv.uid || rv.UID || j.icalUid || '');
    out.calendarId = String(rv.calendarId || rv.calendarID || rv.calendar_id || j.calendarId || '');
    return out;
  } catch (e) {
    out.message = 'JSON_PARSE_FAIL: ' + String(e && e.message || e);
    return out;
  }
}

function portalCalendarStep08NaverTracePickIcalFieldV09_(ical, key) {
  ical = String(ical || '');
  key = String(key || '').replace(/[-\/\\^$*+?.()|[\]{}]/g, '\\$&');
  var re = new RegExp('(?:^|\\r?\\n)' + key + '(?:;[^:]*)?:([^\\r\\n]*)', 'i');
  var m = ical.match(re);
  return m ? String(m[1] || '').trim() : '';
}

function portalCalendarStep08NaverTracePickDateLineV09_(ical, key) {
  ical = String(ical || '');
  key = String(key || '').replace(/[-\/\\^$*+?.()|[\]{}]/g, '\\$&');
  var re = new RegExp('(?:^|\\r?\\n)(' + key + '(?:;[^:]*)?:[^\\r\\n]*)', 'i');
  var m = ical.match(re);
  return m ? String(m[1] || '').trim() : '';
}

function portalCalendarStep08NaverTraceTimezoneHintV09_(ical) {
  ical = String(ical || '');
  if (/TZID=Asia\/Seoul/i.test(ical)) return 'TZID_ASIA_SEOUL';
  if (/Z\s*(?:\r?\n|$)/.test(portalCalendarStep08NaverTracePickDateLineV09_(ical, 'DTSTART'))) return 'UTC_Z';
  if (/VALUE=DATE/i.test(portalCalendarStep08NaverTracePickDateLineV09_(ical, 'DTSTART'))) return 'ALL_DAY_DATE';
  return 'FLOATING_OR_UNKNOWN';
}

function portalCalendarStep08NaverTraceLogV09_(trace) {
  try {
    console.log('NAVER_REQUEST_RESPONSE_TRACE_V09 ' + JSON.stringify(trace));
  } catch (e) {
    console.log('NAVER_REQUEST_RESPONSE_TRACE_V09_LOG_FAIL ' + String(e && e.message || e));
  }
  return trace;
}

function portalCalendarStep08NaverRuntimeResponseDiagnoseV09() {
  var sampleIcal = [
    'BEGIN:VCALENDAR',
    'VERSION:2.0',
    'PRODID:-//FEELHAUS//PORTAL//KO',
    'BEGIN:VEVENT',
    'UID:FH-MCAL-DIAG-V09@feelhaus.portal',
    'SUMMARY:NAVER V09 진단 샘플',
    'DTSTART;TZID=Asia/Seoul:20260608T204500',
    'DTEND;TZID=Asia/Seoul:20260608T211500',
    'DESCRIPTION:TRACE ONLY NO NAVER WRITE',
    'END:VEVENT',
    'END:VCALENDAR'
  ].join('\r\n');
  var sampleResponse = JSON.stringify({
    returnValue: { processType: 'modify', icalUid: 'FH-MCAL-DIAG-V09@feelhaus.portal', calendarId: '2162375' },
    message: 'sample only'
  });
  var trace = portalCalendarStep08NaverTraceBuildV09_({
    calendarId: '2162375',
    url: 'https://openapi.naver.com/calendar/createSchedule.json',
    scheduleIcalString: sampleIcal,
    httpCode: 200,
    responseText: sampleResponse,
    existingNaverSuccess: true
  });
  return 'JSON_COMPACT_RESULT: ' + JSON.stringify({
    ok: true,
    build: 'PORTAL_CALENDAR_STEP08_NAVER_REQUEST_RESPONSE_TRACE_V09_20260601',
    action: 'portalCalendarStep08NaverRuntimeResponseDiagnoseV09',
    safety: 'TRACE_SAMPLE_ONLY_NO_NAVER_WRITE',
    trace: trace
  });
}
