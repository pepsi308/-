/**
 * FEELHAUS MailCenter Template Apply Preview V01
 * Build: MAILCENTER_TEMPLATE_APPLY_PREVIEW_V01_20260520
 *
 * Purpose:
 * - Compose 화면에서 ACTIVE 템플릿 목록 조회
 * - 템플릿 선택 시 subject/bodyHtml 적용
 * - 기존 Compose 발송/서명/기본계정 로직 수정 없음
 */

var MC_COMPOSE_TEMPLATE_APPLY_V01_BUILD = 'MAILCENTER_TEMPLATE_APPLY_PREVIEW_V01_20260520';

function runMcComposeTemplateApplyV01Smoke() {
  var result = {
    ok: false,
    build: MC_COMPOSE_TEMPLATE_APPLY_V01_BUILD,
    action: 'runMcComposeTemplateApplyV01Smoke',
    generatedAt: mcComposeTemplateApplyV01Now_(),
    message: '',
    checks: []
  };

  try {
    result.checks.push({
      key: 'TemplateCoreReady',
      ok: typeof mcTemplateCoreV01GetData === 'function',
      message: 'Template Core V01 데이터 함수 확인'
    });
    result.checks.push({
      key: 'ComposeCoreReady',
      ok: typeof mcComposeCoreV01GetData === 'function',
      message: 'Compose Core V01 데이터 함수 확인'
    });
    result.checks.push({
      key: 'TemplateListReady',
      ok: typeof mcComposeTemplateApplyV01GetTemplates === 'function',
      message: 'Compose 템플릿 목록 함수 확인'
    });
    result.checks.push({
      key: 'TemplateSaveReady',
      ok: typeof mcTemplateCoreV01SaveTemplate === 'function',
      message: '현재 작성본 새 템플릿 저장 함수 확인'
    });
    result.checks.push({
      key: 'TemplatePreviewViewReady',
      ok: mcComposeTemplateApplyPreviewV01CheckView_(),
      message: 'Compose 템플릿 미리보기/삽입/교체 화면 요소 확인'
    });

    result.ok = result.checks.every(function(c) { return !!c.ok; });
    result.message = result.ok ? 'Template Apply Preview V01 준비 완료' : 'Template Apply Preview V01 점검 필요';
  } catch (err) {
    result.ok = false;
    result.message = String(err && err.message ? err.message : err);
  }

  mcComposeTemplateApplyV01Log_(result);
  return result;
}


function runMcComposeTemplateApplyPreviewV01Smoke() {
  return runMcComposeTemplateApplyV01Smoke();
}

function mcComposeTemplateApplyPreviewV01CheckView_() {
  try {
    var t = HtmlService.createTemplateFromFile('MC_ComposeViewV01');
    t.initialJson = JSON.stringify({ ok: true, accounts: [], signatures: [], folders: [] });
    var html = t.evaluate().getContent();
    return html.indexOf('templatePreviewBox') >= 0
      && html.indexOf('templateInsertBtn') >= 0
      && html.indexOf('templateReplaceBtn') >= 0
      && html.indexOf('templateSaveBtn') >= 0
      && html.indexOf('insertSelectedTemplate') >= 0
      && html.indexOf('saveCurrentAsTemplate') >= 0;
  } catch (err) {
    return false;
  }
}

function mcComposeTemplateApplyV01GetTemplates() {
  var result = {
    ok: false,
    build: MC_COMPOSE_TEMPLATE_APPLY_V01_BUILD,
    action: 'mcComposeTemplateApplyV01GetTemplates',
    generatedAt: mcComposeTemplateApplyV01Now_(),
    message: '',
    templates: [],
    summary: {
      total: 0,
      active: 0
    }
  };

  try {
    var cached = mcComposeTemplateApplyV01CacheGet_();
    if (cached && Array.isArray(cached.templates)) {
      result.templates = cached.templates;
      result.summary.total = Number(cached.total || cached.templates.length || 0);
      result.summary.active = Number(cached.active || cached.templates.length || 0);
      result.ok = true;
      result.cacheHit = true;
      result.message = 'Compose 템플릿 목록 조회 완료 - CacheService';
      return mcComposeTemplateApplyV01Safe_(result);
    }

    if (typeof mcTemplateCoreV01GetData !== 'function') {
      throw new Error('mcTemplateCoreV01GetData 함수가 없습니다.');
    }

    var data = mcTemplateCoreV01GetData({});
    if (!data || !data.ok) {
      throw new Error((data && data.message) ? data.message : '템플릿 데이터 조회 실패');
    }

    var templates = (data.templates || []).filter(function(t) {
      return String(t.templateStatus || '').toUpperCase() === 'ACTIVE';
    }).map(function(t) {
      return {
        templateId: String(t.templateId || ''),
        templateScope: String(t.templateScope || ''),
        templateCategory: String(t.templateCategory || ''),
        templateName: String(t.templateName || ''),
        subject: String(t.subject || ''),
        bodyHtml: String(t.bodyHtml || ''),
        bodyText: String(t.bodyText || ''),
        useSignature: String(t.useSignature || 'TRUE')
      };
    });

    result.templates = templates;
    result.summary.total = (data.templates || []).length;
    result.summary.active = templates.length;
    result.ok = true;
    result.cacheHit = false;
    result.message = 'Compose 템플릿 목록 조회 완료';
    mcComposeTemplateApplyV01CachePut_({
      templates: templates,
      total: result.summary.total,
      active: result.summary.active
    });
  } catch (err) {
    result.ok = false;
    result.message = String(err && err.message ? err.message : err);
  }

  return mcComposeTemplateApplyV01Safe_(result);
}

function runMcComposeTemplateApplyV01List() {
  var result = mcComposeTemplateApplyV01GetTemplates();
  mcComposeTemplateApplyV01Log_(result);
  return result;
}

function mcComposeTemplateApplyV01Now_() {
  return Utilities.formatDate(new Date(), Session.getScriptTimeZone() || 'Asia/Seoul', 'yyyy-MM-dd HH:mm:ss');
}

function mcComposeTemplateApplyV01Safe_(obj) {
  try {
    return JSON.parse(JSON.stringify(obj));
  } catch (e) {
    return {
      ok: false,
      build: MC_COMPOSE_TEMPLATE_APPLY_V01_BUILD,
      action: 'mcComposeTemplateApplyV01Safe_',
      generatedAt: mcComposeTemplateApplyV01Now_(),
      message: String(e && e.message ? e.message : e)
    };
  }
}


function mcComposeTemplateApplyV01CacheGet_() {
  try {
    var raw = CacheService.getScriptCache().get(MC_COMPOSE_TEMPLATE_APPLY_V01_CACHE_KEY);
    if (!raw) return null;
    var obj = JSON.parse(raw);
    if (!obj || !Array.isArray(obj.templates)) return null;
    return obj;
  } catch (e) {
    return null;
  }
}

function mcComposeTemplateApplyV01CachePut_(obj) {
  try {
    CacheService.getScriptCache().put(
      MC_COMPOSE_TEMPLATE_APPLY_V01_CACHE_KEY,
      JSON.stringify(obj || {}),
      MC_COMPOSE_TEMPLATE_APPLY_V01_CACHE_TTL_SEC
    );
  } catch (e) {}
}

function mcComposeTemplateApplyV01ClearCache_() {
  try {
    CacheService.getScriptCache().remove(MC_COMPOSE_TEMPLATE_APPLY_V01_CACHE_KEY);
    return { ok: true, build: MC_COMPOSE_TEMPLATE_APPLY_V01_BUILD, action: 'mcComposeTemplateApplyV01ClearCache_' };
  } catch (e) {
    return { ok: false, build: MC_COMPOSE_TEMPLATE_APPLY_V01_BUILD, action: 'mcComposeTemplateApplyV01ClearCache_', message: String(e && e.message ? e.message : e) };
  }
}

function mcComposeTemplateApplyV01Log_(obj) {
  try {
    Logger.log('JSON_COMPACT_RESULT: ' + JSON.stringify(obj));
  } catch (e) {
    Logger.log(obj);
  }
}
