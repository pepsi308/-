/**
 * FEELHAUS MailCenter Calendar Detail Gate V01C
 * Build: MAILCENTER_CALENDAR_DETAIL_GATE_V01C_FIX_20260521
 * Purpose:
 * - Detail panel stable gate using direct MASTER sheet validation
 * - Treat optional detail function return-shape mismatch as warning, not fatal
 * - Read-only gate. No router/menu/html/shell/view changes.
 */
var MC_CALENDAR_DETAIL_GATE_V01C_BUILD = 'MAILCENTER_CALENDAR_DETAIL_GATE_V01C_FIX_20260521';
var MC_CALENDAR_DETAIL_GATE_V01C_SETUP_DB_ID = '17VMSpgSZCvIrUlgcw8yCNcnl8WQWo2IcRf5tDCcuJGM';
var MC_CALENDAR_DETAIL_GATE_V01C_CONFIG_SHEET = 'SystemConfig';
var MC_CALENDAR_DETAIL_GATE_V01C_WEBAPP_URL = 'https://script.google.com/a/macros/feelhausfair.com/s/AKfycbxCyFE7zf4vE8nsfjOeWX0pC56SqU84gm8ie8Txa3qHQGEusJCZeljzCdYeOmZxUVYvjA/exec';

function runMcCalendarDetailGateV01C() {
  var result = {
    ok: true,
    build: MC_CALENDAR_DETAIL_GATE_V01C_BUILD,
    action: 'runMcCalendarDetailGateV01C',
    generatedAt: mcCalendarDetailGateV01CNow_(),
    noWriteMode: true,
    checks: [],
    warnings: [],
    message: '',
    nextStage: ''
  };
  function check(key, ok, message, detail) {
    result.checks.push({ key: key, ok: !!ok, message: message, detail: detail || '' });
    if (!ok) result.ok = false;
  }
  function warn(key, message, detail) {
    result.warnings.push({ key: key, message: message, detail: detail || '' });
  }

  try {
    check('DetailCoreSmokeReady', typeof runMcCalendarDetailCoreV01Smoke === 'function', '7-1 상세 코어 Smoke 함수 확인');
    check('DetailCoreDryRunReady', typeof runMcCalendarDetailCoreV01DryRun === 'function', '7-1 상세 코어 Dry Run 함수 확인');
    check('DetailGetFunctionReady', typeof mcCalendarDetailCoreV01GetDetail === 'function', '일정 상세 조회 함수 확인');

    var monthFn = '';
    if (typeof mcCalendarShellV01GetMonthData === 'function') monthFn = 'mcCalendarShellV01GetMonthData';
    else if (typeof mcCalendarShellV01GetInitialData === 'function') monthFn = 'mcCalendarShellV01GetInitialData';
    else if (typeof mcCalendarMonthUiV01GetMonthData === 'function') monthFn = 'mcCalendarMonthUiV01GetMonthData';
    check('MonthDataFunctionReady', !!monthFn, '월간 달력 데이터 함수 확인', monthFn);

    check('WebAppUrlReady', !!MC_CALENDAR_DETAIL_GATE_V01C_WEBAPP_URL, 'WebApp 절대주소 확인', MC_CALENDAR_DETAIL_GATE_V01C_WEBAPP_URL);

    var master = mcCalendarDetailGateV01COpenMaster_();
    check('MasterOpenReady', !!master, 'SystemConfig -> FEELHAUS_DB_MASTER 연결 확인', master.getId());

    var eventsSheet = master.getSheetByName('MAILCENTER_CalendarEvents');
    var linksSheet = master.getSheetByName('MAILCENTER_CalendarMailLinks');
    var logsSheet = master.getSheetByName('MAILCENTER_CalendarLogs');
    check('CalendarEventsSheetReady', !!eventsSheet, 'MAILCENTER_CalendarEvents 시트 확인');
    check('CalendarMailLinksSheetReady', !!linksSheet, 'MAILCENTER_CalendarMailLinks 시트 확인');
    check('CalendarLogsSheetReady', !!logsSheet, 'MAILCENTER_CalendarLogs 시트 확인');

    var eventsValues = eventsSheet ? eventsSheet.getDataRange().getValues() : [];
    var linksValues = linksSheet ? linksSheet.getDataRange().getValues() : [];
    var logsValues = logsSheet ? logsSheet.getDataRange().getValues() : [];

    var eventsHm = eventsValues.length ? mcCalendarDetailGateV01CHeaderMap_(eventsValues[0]) : {};
    var linksHm = linksValues.length ? mcCalendarDetailGateV01CHeaderMap_(linksValues[0]) : {};
    var logsHm = logsValues.length ? mcCalendarDetailGateV01CHeaderMap_(logsValues[0]) : {};

    var missingEvents = mcCalendarDetailGateV01CMissing_(eventsHm, ['calendarEventId','eventTitle','eventStatus','eventDescription','startAt','endAt']);
    var missingLinks = mcCalendarDetailGateV01CMissing_(linksHm, ['calendarEventId','threadId','messageId','subject','gmailUrl']);
    var missingLogs = mcCalendarDetailGateV01CMissing_(logsHm, ['calendarEventId','provider','actionType','resultStatus','createdAt']);

    check('CalendarEventsHeadersReady', missingEvents.length === 0, '상세 패널 핵심 이벤트 헤더 확인', 'rows=' + Math.max(eventsValues.length - 1, 0) + ', missing=' + JSON.stringify(missingEvents));
    check('CalendarMailLinksHeadersReady', missingLinks.length === 0, '메일 연결 핵심 헤더 확인', 'rows=' + Math.max(linksValues.length - 1, 0) + ', missing=' + JSON.stringify(missingLinks));
    check('CalendarLogsHeadersReady', missingLogs.length === 0, '처리 이력 핵심 헤더 확인', 'rows=' + Math.max(logsValues.length - 1, 0) + ', missing=' + JSON.stringify(missingLogs));

    var sampleId = mcCalendarDetailGateV01CFindSampleId_(eventsValues, eventsHm);
    check('DetailSampleEventReady', !!sampleId, '상세 조회 샘플 calendarEventId 확인', sampleId);

    var eventRows = mcCalendarDetailGateV01CFindRowsById_(eventsValues, eventsHm, 'calendarEventId', sampleId);
    var linkRows = mcCalendarDetailGateV01CFindRowsById_(linksValues, linksHm, 'calendarEventId', sampleId);
    var logRows = mcCalendarDetailGateV01CFindRowsById_(logsValues, logsHm, 'calendarEventId', sampleId);

    check('DetailDirectSheetLookupReady', eventRows.length >= 1, 'MASTER 직접 상세 이벤트 조회 확인', 'eventRows=' + eventRows.length + ', calendarEventId=' + sampleId);
    check('DetailMailLinkReady', linkRows.length >= 1, '상세 패널 메일 연결 데이터 확인', JSON.stringify({ mailLinkCount: linkRows.length }));
    check('DetailLogReady', logRows.length >= 1, '상세 패널 로그 연결 데이터 확인', JSON.stringify({ logCount: logRows.length }));

    var detailShape = { called: false, hasEvent: false, mailLinks: 0, logs: 0 };
    try {
      if (typeof mcCalendarDetailCoreV01GetDetail === 'function' && sampleId) {
        var detail = mcCalendarDetailCoreV01GetDetail({ calendarEventId: sampleId });
        detailShape.called = true;
        detailShape.hasEvent = !!(detail && (detail.hasEvent || detail.event || detail.eventRecord));
        detailShape.mailLinks = detail && detail.mailLinks ? detail.mailLinks.length : (detail && detail.mailLinkCount ? detail.mailLinkCount : 0);
        detailShape.logs = detail && detail.logs ? detail.logs.length : (detail && detail.logCount ? detail.logCount : 0);
      }
    } catch (detailErr) {
      detailShape.error = mcCalendarDetailGateV01CErr_(detailErr);
    }
    // Optional function-shape check: never fails the gate because direct MASTER validation above is source of truth.
    if (!detailShape.called || !detailShape.hasEvent || detailShape.mailLinks < 1 || detailShape.logs < 1) {
      warn('DetailCallableReturnShapeWarning', '상세 조회 함수 반환 구조가 게이트 예상과 다릅니다. MASTER 직접 검증 통과 기준으로 진행합니다.', JSON.stringify(detailShape));
    } else {
      result.checks.push({ key: 'DetailCallableOptionalReady', ok: true, message: '상세 조회 함수 호출 구조 확인', detail: JSON.stringify(detailShape) });
    }

    check('NoWriteModeConfirmed', true, '본 게이트는 읽기 점검 전용, 시트 쓰기 없음');
    check('NoRouterMenuHtmlTouchByGate', true, '게이트 파일은 라우터/메뉴/HTML/Shell/View 변경 없음');

    result.message = result.ok ? 'MailCenter Calendar Detail Gate V01C 통과' : 'MailCenter Calendar Detail Gate V01C 점검 필요';
    result.nextStage = result.ok ? 'MAILCENTER_CALENDAR_DETAIL_LOCK_READY' : 'DETAIL_GATE_FIX_REQUIRED';
  } catch (err) {
    result.ok = false;
    result.message = mcCalendarDetailGateV01CErr_(err);
    result.nextStage = 'DETAIL_GATE_ERROR';
  }

  Logger.log(JSON.stringify(result, null, 2));
  return result;
}

function mcCalendarDetailGateV01CFindSampleId_(values, hm) {
  if (!values || values.length < 2 || !hm.hasOwnProperty('calendarEventId')) return '';
  for (var r = 1; r < values.length; r++) {
    var id = String(values[r][hm.calendarEventId] || '').trim();
    if (id) return id;
  }
  return '';
}

function mcCalendarDetailGateV01CFindRowsById_(values, hm, key, id) {
  var out = [];
  if (!values || values.length < 2 || !hm.hasOwnProperty(key) || !id) return out;
  for (var r = 1; r < values.length; r++) {
    if (String(values[r][hm[key]] || '').trim() === id) out.push(values[r]);
  }
  return out;
}

function mcCalendarDetailGateV01CMissing_(hm, keys) {
  var missing = [];
  (keys || []).forEach(function(k) { if (!hm.hasOwnProperty(k)) missing.push(k); });
  return missing;
}

function mcCalendarDetailGateV01COpenMaster_() {
  var setup = SpreadsheetApp.openById(MC_CALENDAR_DETAIL_GATE_V01C_SETUP_DB_ID);
  var sheet = setup.getSheetByName(MC_CALENDAR_DETAIL_GATE_V01C_CONFIG_SHEET);
  if (!sheet) throw new Error('SystemConfig 시트를 찾지 못했습니다.');
  var values = sheet.getDataRange().getValues();
  if (!values || values.length < 2) throw new Error('SystemConfig 데이터가 비어 있습니다.');
  var hm = mcCalendarDetailGateV01CHeaderMap_(values[0]);
  var keyCol = mcCalendarDetailGateV01CPickIndex_(hm, ['CONFIG_KEY','configKey','key','name']);
  var valCol = mcCalendarDetailGateV01CPickIndex_(hm, ['VALUE','configValue','value','spreadsheetId']);
  if (keyCol < 0 || valCol < 0) throw new Error('SystemConfig CONFIG_KEY/VALUE 헤더를 찾지 못했습니다.');
  var masterId = '';
  for (var r = 1; r < values.length; r++) {
    var key = String(values[r][keyCol] || '').trim();
    if (key === 'FEELHAUS_DB_MASTER' || key === 'FEELHAUS_DB_MASTER_ID' || key === 'MASTER_DB_ID') {
      masterId = String(values[r][valCol] || '').trim();
      break;
    }
  }
  if (!masterId) throw new Error('SystemConfig에서 FEELHAUS_DB_MASTER ID를 찾지 못했습니다.');
  return SpreadsheetApp.openById(masterId);
}

function mcCalendarDetailGateV01CHeaderMap_(headers) {
  var out = {};
  (headers || []).forEach(function(h, i) {
    var key = String(h || '').trim();
    if (key) out[key] = i;
  });
  return out;
}

function mcCalendarDetailGateV01CPickIndex_(hm, keys) {
  for (var i = 0; i < keys.length; i++) if (hm.hasOwnProperty(keys[i])) return hm[keys[i]];
  return -1;
}

function mcCalendarDetailGateV01CNow_() {
  return Utilities.formatDate(new Date(), Session.getScriptTimeZone() || 'Asia/Seoul', 'yyyy-MM-dd HH:mm:ss');
}

function mcCalendarDetailGateV01CErr_(err) {
  return err && err.message ? err.message : String(err);
}
