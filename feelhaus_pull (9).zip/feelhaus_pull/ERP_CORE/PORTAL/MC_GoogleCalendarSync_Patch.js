/**
 * FEELHAUS Google Calendar Sync Patch
 * Build: MC_GOOGLE_CALENDAR_SYNC_PATCH_SAFE_RESULT_V01_20260527
 *
 * 사용법:
 * 1) 이 파일 전체를 Apps Script에 새 파일로 추가하세요.
 *    예: 파일명 MC_GoogleCalendarSync_Patch.gs
 * 2) 기존 코드 안에 같은 이름의 function mcCalendar19SafeResult_ 가 있으면
 *    기존 함수를 삭제하거나 주석 처리하세요.
 *    Apps Script에서는 같은 이름 함수가 여러 개 있으면 마지막 로드 함수가 적용되어 혼동될 수 있습니다.
 * 3) 저장 후 mcGoogleCalendarSyncPatchVerifyV01 실행
 * 4) 그 다음 mcGoogleCalendarSyncTestGateV03All 실행
 */


/**
 * PATCHED
 * 기존 문제:
 *   mcCalendar19SafeResult_('mcGoogleCalendarSyncPrepV01GetStatus')
 * 처럼 문자열을 넣으면 객체가 아니라 문자열 그대로 반환되어
 * STATUS / PREP_DRY_RUN / APPLY_DRY_RUN 단계가 "문자열 반환"으로 실패했음.
 *
 * 수정:
 *   문자열 입력을 { ok:true, action:'...' } 형태의 객체로 변환.
 */
function mcCalendar19SafeResult_(payload) {
  var result;

  if (typeof payload === 'string') {
    result = {
      ok: true,
      build: '',
      action: payload,
      message: '',
      generatedAt: ''
    };
  } else if (payload && typeof payload === 'object') {
    result = payload;

    if (!result.action) {
      result.action = '';
    }

    if (!result.message) {
      result.message = '';
    }

    if (!result.build) {
      result.build = '';
    }
  } else {
    result = {
      ok: true,
      build: '',
      action: '',
      message: '',
      generatedAt: ''
    };
  }

  if (result.ok === undefined) {
    result.ok = true;
  }

  if (!result.generatedAt) {
    try {
      result.generatedAt = Utilities.formatDate(
        new Date(),
        Session.getScriptTimeZone() || 'Asia/Seoul',
        'yyyy-MM-dd HH:mm:ss'
      );
    } catch (err) {
      result.generatedAt = new Date().toISOString();
    }
  }

  return mcCalendar19ClientSafeObject_(result);
}


/**
 * 패치 검증 함수
 * Apps Script에서 이 함수 실행:
 *   mcGoogleCalendarSyncPatchVerifyV01
 */
function mcGoogleCalendarSyncPatchVerifyV01() {
  var result = {
    ok: true,
    build: 'MC_GOOGLE_CALENDAR_SYNC_PATCH_VERIFY_V01_20260527',
    action: 'mcGoogleCalendarSyncPatchVerifyV01',
    checks: {},
    generatedAt: Utilities.formatDate(
      new Date(),
      Session.getScriptTimeZone() || 'Asia/Seoul',
      'yyyy-MM-dd HH:mm:ss'
    )
  };

  try {
    var safeResult = mcCalendar19SafeResult_('PATCH_TEST_ACTION');

    result.checks.safeResultStringInput = {
      ok: !!safeResult &&
          typeof safeResult === 'object' &&
          safeResult.action === 'PATCH_TEST_ACTION',
      type: typeof safeResult,
      value: safeResult
    };

    if (!result.checks.safeResultStringInput.ok) {
      result.ok = false;
    }
  } catch (err) {
    result.ok = false;
    result.checks.safeResultStringInput = {
      ok: false,
      error: String(err && err.message ? err.message : err)
    };
  }

  try {
    var status = mcGoogleCalendarSyncPrepV01GetStatus({});

    result.checks.status = {
      ok: !!status && typeof status === 'object',
      type: typeof status,
      action: status && status.action ? status.action : '',
      message: status && status.message ? status.message : '',
      raw: status
    };

    if (!result.checks.status.ok) {
      result.ok = false;
    }
  } catch (errStatus) {
    result.ok = false;
    result.checks.status = {
      ok: false,
      error: String(errStatus && errStatus.message ? errStatus.message : errStatus)
    };
  }

  try {
    var gate = mcGoogleCalendarSyncTestGateV03All();

    result.checks.testGate = {
      ok: !!gate && typeof gate === 'object',
      gateOk: !!(gate && gate.ok),
      summary: gate && gate.summary ? gate.summary : null,
      failedStepNames: gate && gate.summary ? gate.summary.failedStepNames : null,
      raw: gate
    };

    if (!result.checks.testGate.ok) {
      result.ok = false;
    }
  } catch (errGate) {
    result.ok = false;
    result.checks.testGate = {
      ok: false,
      error: String(errGate && errGate.message ? errGate.message : errGate)
    };
  }

  Logger.log('JSON_COMPACT_RESULT: ' + JSON.stringify(result));
  return result;
}


/**
 * 선택 실행 함수
 * 패치 검증 후 바로 테스트 게이트까지 실행.
 */
function mcGoogleCalendarSyncPatchVerifyAndRunGateV01() {
  var verifyResult = mcGoogleCalendarSyncPatchVerifyV01();

  var gateResult = null;
  var gateError = '';

  try {
    gateResult = mcGoogleCalendarSyncTestGateV03All();
  } catch (err) {
    gateError = String(err && err.message ? err.message : err);
  }

  var result = {
    ok: !!verifyResult.ok && !!gateResult && !!gateResult.ok,
    build: 'MC_GOOGLE_CALENDAR_SYNC_PATCH_VERIFY_AND_RUN_GATE_V01_20260527',
    action: 'mcGoogleCalendarSyncPatchVerifyAndRunGateV01',
    verifyResult: verifyResult,
    gateResult: gateResult,
    gateError: gateError,
    generatedAt: Utilities.formatDate(
      new Date(),
      Session.getScriptTimeZone() || 'Asia/Seoul',
      'yyyy-MM-dd HH:mm:ss'
    )
  };

  Logger.log('JSON_COMPACT_RESULT: ' + JSON.stringify(result));
  return result;
}
