/**
 * FEELHAUS PORTAL / Calendar SAFE-01B R10K4 Staff Workflow Card Verify
 * Build: PORTAL_CALENDAR_SAFE01B_R10K4_STAFF_WORKFLOW_CARD_DETAIL_20260604
 * Safety: READ_ONLY_RUNTIME_VERIFY_NO_SHEET_PROVIDER_WRITE
 * Purpose:
 *  - Verify the workflow UI is staff-facing card detail, not developer/simple guide.
 *  - Verify selection/event/general cards are visible in edit and detail modals.
 *  - Preserve R10K2 event master link and R11 auto-refresh.
 */
var PORTAL_CALENDAR_SAFE01B_R10K4_STAFF_WORKFLOW_CARD_BUILD = 'PORTAL_CALENDAR_SAFE01B_R10K4_STAFF_WORKFLOW_CARD_DETAIL_20260604';

function portalCalendarSafe01BR10K4StaffWorkflowCardDetailVerify(){return portalCalendarSafe01BR10K4StaffWorkflowCardVerify();}
function portalCalendarSafe01BR10K4WorkflowCardVerify(){return portalCalendarSafe01BR10K4StaffWorkflowCardVerify();}
function portalCalendarSafe01BR10K4StaffWorkflowCardVerify(){
  var BUILD=PORTAL_CALENDAR_SAFE01B_R10K4_STAFF_WORKFLOW_CARD_BUILD;
  var BASE_BUILD='PORTAL_CALENDAR_SAFE01B_R10K3_FULL_WORKFLOW_DETAIL_20260604';
  var ACTION='portalCalendarSafe01BR10K4StaffWorkflowCardVerify';
  var html='';var readError='';
  try{html=HtmlService.createTemplateFromFile('MC_CalendarViewV01').getRawContent();}
  catch(e1){try{html=HtmlService.createHtmlOutputFromFile('MC_CalendarViewV01').getContent();}catch(e2){readError=String(e2&&e2.message?e2.message:e2);html='';}}
  function has(s){return String(html||'').indexOf(s)!==-1;}
  function notHas(s){return !has(s);}
  function all(arr){for(var i=0;i<arr.length;i++)if(!has(arr[i]))return false;return true;}
  function lineNumberAt(text,index){if(index<0)return -1;return String(text||'').substring(0,index).split('\n').length;}
  function contextAt(text,index,needle){if(index<0)return '';var size=220;var end=index+String(needle||'').length;return String(text||'').substring(Math.max(0,index-size),Math.min(String(text||'').length,end+size));}
  function matchInfo(needle){var idx=String(html||'').indexOf(needle);return {found:idx!==-1,needle:idx!==-1?needle:'',matchIndex:idx,lineNumber:lineNumberAt(html,idx),context:contextAt(html,idx,needle)};}
  var selectionStages=['사전영업','입예협 접촉','제안/프레젠테이션','조건협의','경쟁검토','선정대기','협약식','행사관리 전환'];
  var eventStages=['행사등록','담당자배정','일정/장소확정','카테고리구성','업체배정','홍보준비','현장준비','행사운영','판매집계','계약관리','설치/A/S','정산','마감/리포트'];
  var generalStages=['내부회의','외부미팅','개발작업','전자결재','보고','휴무','기타'];
  var checks={
    viewReadable:!!html&&!readError,
    r10k4BuildMarkerPresent:has(BUILD)&&has('__MC_CALENDAR_R10K4_STAFF_WORKFLOW_CARD_BUILD__'),
    staffCardCssReady:has('cal-r10k4-staff-card-guide')&&has('cal-r10k4-info-grid')&&has('cal-r10k4-selected-card'),
    manualStaffCardReady:has('data-r10k4-staff-card-guide="1"')&&has('업무 타입별 직원 판단 카드')&&has('직원이 확인할 정보')&&has('원장/연결 기준'),
    notDeveloperSummaryOnly:has('단계 나열형이 아니라')&&has('직원용 업무 판단 카드'),
    threeTypeCardsVisible:has('박람회 선정 과정')&&has('행사관리')&&has('일반/기타 일정'),
    selectionCardDetailed:has('대상 단지 · 입예협/협의체')&&has('제안/프레젠테이션')&&has('협약식')&&has('행사관리 전환'),
    eventCardDetailed:has('ERP_행사관리 원장을 eventId로 연결')&&has('판매집계')&&has('계약관리')&&has('설치/A/S')&&has('정산')&&has('마감/리포트'),
    generalCardDetailed:has('업무 목적')&&has('장소/방식')&&has('결과/메모')&&has('연결 자료'),
    detailSelectedCardsReady:has('박람회 선정 과정 상세 카드')&&has('행사관리 상세 카드 / ERP_행사관리 원장')&&has('일반/기타 일정 상세 카드'),
    firstPageUsesStaffWorkflowCards:has('fhCalendarR10K4StaffWorkflowCardsHtml(type,current')&&has('return fhCalendarR10K4StaffWorkflowCardsHtml(type,current'),
    r10k3WorkflowPreservedAsWrapper:has('function fhCalendarR10K3WorkflowGuideHtml')&&has('fhCalendarR10K4StaffWorkflowCardsHtml(type,current'),
    r10k2EventMasterKept:has('me_eventMasterPicker')&&has('ERP_행사관리 원장에서 행사 선택')&&has('행사명은 표시용이며 실제 연결·저장은 eventId 기준'),
    r11AutoRefreshKept:has('fhCalendarStartAutoRefreshR11')&&has('setInterval(fhCalendarCheckPageRefreshR11,30000)')&&has('R11_PAGE_AUTO_REFRESH'),
    selectionStagesVisible:all(selectionStages),
    eventStagesVisible:all(eventStages),
    generalStagesVisible:all(generalStages),
    legacyLabelRemovedFromUi:notHas('일반 담당자명(레거시)')&&notHas('일반 담당자 ID(레거시)')&&notHas('일반 담당 부서(레거시)')&&notHas('일반 주관 역할(레거시)'),
    providerWriteNotAddedInR10K4:!has('CalendarApp.')&&!has('UrlFetchApp.fetch')&&!has('appendRow(')&&!has('.setValue('),
    noSheetProviderWriteInVerify:true
  };
  var fatal=[];Object.keys(checks).forEach(function(k){if(!checks[k])fatal.push(k);});if(readError)fatal.push('viewHtmlReadError');
  var diagnostics={htmlLength:html.length,readError:readError,buildMarker:matchInfo(BUILD),manualStaffCard:matchInfo('업무 타입별 직원 판단 카드'),selectionDetail:matchInfo('박람회 선정 과정 상세 카드'),eventDetail:matchInfo('행사관리 상세 카드 / ERP_행사관리 원장'),generalDetail:matchInfo('일반/기타 일정 상세 카드'),eventMasterPicker:matchInfo('me_eventMasterPicker'),r11Refresh:matchInfo('fhCalendarStartAutoRefreshR11'),selectionStages:selectionStages,eventStages:eventStages,generalStages:generalStages};
  var result={ok:fatal.length===0,build:BUILD,baseBuild:BASE_BUILD,action:ACTION,safety:'READ_ONLY_RUNTIME_VERIFY_NO_SHEET_PROVIDER_WRITE',checks:checks,diagnostics:diagnostics,warnings:[],fatal:fatal,summary:{mode:'Staff-facing workflow card detail after R10K3',selectionProcess:'대상 단지/입예협/프레젠테이션/조건/경쟁/협약식/전환 표시',eventManagement:'ERP_행사관리 eventId 연결 + 운영/판매/계약/설치/A/S/정산/마감 카드 표시',generalSchedule:'업무 목적/참여자/장소/내용/결과/다음 액션/연결 자료 표시',preserved:'R10K2 event master link and R11 auto refresh kept',providerPolicy:'No Google/NAVER/ICS/provider write logic added by this verify build'},message:fatal.length===0?'SAFE-01B R10K4 staff workflow card detail verification passed.':'SAFE-01B R10K4 staff workflow card detail verification failed. Check fatal items and diagnostics.'};
  try{Logger.log('JSON_COMPACT_RESULT: '+JSON.stringify(result));}catch(ignore){}
  return result;
}
