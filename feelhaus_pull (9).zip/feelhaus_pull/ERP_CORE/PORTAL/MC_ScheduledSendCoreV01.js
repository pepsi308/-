/**
 * MC_SCHEDULED_SEND_RETRY_V01_20260527
 * MailCenter 예약 발송 큐/캘린더 연결 V01.
 * - FEELHAUS_SETUP_DB > SystemConfig > FEELHAUS_DB_MASTER 기준 연결
 * - MailCenter_ScheduledQueue 헤더맵 기반 저장
 * - 예약 등록은 QUEUED, 트리거는 mcScheduledSendCoreV01ProcessDue 실행
 * - 실제 발송은 기존 안정 브릿지 mcSendBridgeV02Send(payload)를 재사용
 */
var MC_SCHEDULED_SEND_CORE_V01_BUILD = 'MC_SCHEDULED_SEND_RETRY_V01_20260527';
var MC_SCHEDULED_SEND_CORE_V01_SETUP_DB_ID = '17VMSpgSZCvIrUlgcw8yCNcnl8WQWo2IcRf5tDCcuJGM';
var MC_SCHEDULED_SEND_CORE_V01_CONFIG_SHEET = 'SystemConfig';
var MC_SCHEDULED_SEND_CORE_V01_QUEUE_SHEET = 'MailCenter_ScheduledQueue';
var MC_SCHEDULED_SEND_CORE_V01_TRIGGER_FN = 'mcScheduledSendCoreV01ProcessDue';

function mcScheduledSendCoreV01Enqueue(req) {
  var result = mcScheduledSendCoreV01Result_('mcScheduledSendCoreV01Enqueue');
  try {
    req = req || {};
    var payload = req.payload || {};
    var scheduledAt = mcScheduledSendCoreV01ParseDate_(req.scheduledAt);
    if (!scheduledAt || isNaN(scheduledAt.getTime())) throw new Error('예약 일시가 올바르지 않습니다.');
    if (scheduledAt.getTime() < Date.now() + 2 * 60 * 1000) throw new Error('예약 일시는 현재 시각보다 최소 2분 이후여야 합니다.');

    var mailAccountId = mcScheduledSendCoreV01Require_(payload.mailAccountId || payload.mailAccountID || payload.accountId, 'mailAccountId');
    var toEmail = mcScheduledSendCoreV01Require_(payload.toEmail || payload.to, '수신자');
    var subject = mcScheduledSendCoreV01Require_(payload.subject, '제목');
    var body = mcScheduledSendCoreV01Require_(payload.body || payload.bodyHtml || payload.htmlBody, '본문');

    var ss = mcScheduledSendCoreV01OpenMaster_();
    var sh = mcScheduledSendCoreV01EnsureQueueSheet_(ss);
    var headers = mcScheduledSendCoreV01Headers_(sh);
    var hm = mcScheduledSendCoreV01HeaderMap_(headers);
    var now = mcScheduledSendCoreV01Now_();
    var scheduleId = mcScheduledSendCoreV01NewId_('MSCH');
    var rowObj = {
      scheduleId: scheduleId,
      calendarEventId: '',
      status: 'QUEUED',
      statusReason: '예약 등록 완료',
      scheduledAt: mcScheduledSendCoreV01FmtDate_(scheduledAt),
      mailAccountId: mailAccountId,
      toEmail: String(toEmail || '').trim(),
      subject: String(subject || '').trim(),
      payloadJson: JSON.stringify(payload || {}),
      attemptCount: 0,
      lastAttemptAt: '',
      sentAt: '',
      gmailMessageId: '',
      gmailThreadId: '',
      createdAt: now,
      createdBy: mcScheduledSendCoreV01User_(),
      updatedAt: now,
      updatedBy: mcScheduledSendCoreV01User_()
    };
    var row = headers.map(function(h){ return rowObj[h] != null ? rowObj[h] : ''; });
    sh.appendRow(row);
    var appendedRowNo = sh.getLastRow();

    var calendarLink = mcScheduledSendCoreV01CreateOrUpdateCalendarLink_(ss, rowObj, payload);
    if (calendarLink && calendarLink.calendarEventId) {
      rowObj.calendarEventId = calendarLink.calendarEventId;
      mcScheduledSendCoreV01SetRow_(sh, hm, appendedRowNo, {
        calendarEventId: calendarLink.calendarEventId,
        updatedAt: mcScheduledSendCoreV01Now_(),
        updatedBy: mcScheduledSendCoreV01User_() || 'SYSTEM'
      });
    }

    result.ok = true;
    result.message = '예약 발송 등록 완료';
    result.scheduleId = scheduleId;
    result.calendarEventId = rowObj.calendarEventId || '';
    result.calendarLinked = !!rowObj.calendarEventId;
    result.status = 'QUEUED';
    result.scheduledAt = rowObj.scheduledAt;
  } catch (err) {
    result.ok = false;
    result.message = String(err && err.message ? err.message : err);
  }
  mcScheduledSendCoreV01Log_(result);
  return result;
}

function mcScheduledSendCoreV01ProcessDue() {
  var result = mcScheduledSendCoreV01Result_('mcScheduledSendCoreV01ProcessDue');
  var lock = LockService.getScriptLock();
  try {
    if (!lock.tryLock(25000)) throw new Error('예약 발송 처리 잠금을 획득하지 못했습니다.');
    if (typeof mcSendBridgeV02Send !== 'function') throw new Error('mcSendBridgeV02Send 함수가 없습니다.');
    var ss = mcScheduledSendCoreV01OpenMaster_();
    var sh = mcScheduledSendCoreV01EnsureQueueSheet_(ss);
    var values = sh.getDataRange().getValues();
    if (values.length < 2) {
      result.ok = true;
      result.message = '처리할 예약 발송이 없습니다.';
      return result;
    }
    var headers = values[0].map(function(x){ return String(x || '').trim(); });
    var hm = mcScheduledSendCoreV01HeaderMap_(headers);
    var now = new Date();
    var processed = 0, sent = 0, failed = 0, skipped = 0;
    for (var r = 1; r < values.length; r++) {
      if (processed >= 10) break;
      var row = values[r];
      var status = String(row[hm.status] || '').trim().toUpperCase();
      if (status !== 'QUEUED') { skipped++; continue; }
      var due = mcScheduledSendCoreV01ParseDate_(row[hm.scheduledAt]);
      if (!due || isNaN(due.getTime()) || due.getTime() > now.getTime()) { skipped++; continue; }
      processed++;
      var rowNo = r + 1;
      var attempt = Number(row[hm.attemptCount] || 0) + 1;
      mcScheduledSendCoreV01SetRow_(sh, hm, rowNo, {
        status: 'SENDING',
        statusReason: '예약 발송 처리 중',
        attemptCount: attempt,
        lastAttemptAt: mcScheduledSendCoreV01Now_(),
        updatedAt: mcScheduledSendCoreV01Now_(),
        updatedBy: 'SYSTEM_TRIGGER'
      });
      try {
        var payload = JSON.parse(String(row[hm.payloadJson] || '{}'));
        var sendRes = mcSendBridgeV02Send(payload);
        if (!sendRes || !sendRes.ok) throw new Error((sendRes && sendRes.message) ? sendRes.message : '예약 발송 실패');
        sent++;
        mcScheduledSendCoreV01SetRow_(sh, hm, rowNo, {
          status: 'SENT',
          statusReason: sendRes.message || '예약 발송 완료',
          sentAt: mcScheduledSendCoreV01Now_(),
          gmailMessageId: sendRes.gmailMessageId || '',
          gmailThreadId: sendRes.gmailThreadId || '',
          updatedAt: mcScheduledSendCoreV01Now_(),
          updatedBy: 'SYSTEM_TRIGGER'
        });
        mcScheduledSendCoreV01UpdateCalendarLinkStatus_(ss, row[hm.calendarEventId], 'SENT', sendRes.message || '예약 발송 완료');
      } catch (sendErr) {
        failed++;
        var failMsg = String(sendErr && sendErr.message ? sendErr.message : sendErr);
        mcScheduledSendCoreV01SetRow_(sh, hm, rowNo, {
          status: 'FAILED',
          statusReason: failMsg,
          updatedAt: mcScheduledSendCoreV01Now_(),
          updatedBy: 'SYSTEM_TRIGGER'
        });
        mcScheduledSendCoreV01UpdateCalendarLinkStatus_(ss, row[hm.calendarEventId], 'FAILED', failMsg);
      }
    }
    result.ok = true;
    result.message = '예약 발송 처리 완료';
    result.summary = { processed: processed, sent: sent, failed: failed, skipped: skipped };
  } catch (err) {
    result.ok = false;
    result.message = String(err && err.message ? err.message : err);
  } finally {
    try { lock.releaseLock(); } catch(ignore) {}
  }
  mcScheduledSendCoreV01Log_(result);
  return result;
}


function mcScheduledSendCoreV01List(req) {
  var result = mcScheduledSendCoreV01Result_('mcScheduledSendCoreV01List');
  try {
    req = req || {};
    var filterStatus = String(req.status || '').trim().toUpperCase();
    var limit = Math.max(1, Math.min(Number(req.limit || 50), 200));
    var ss = mcScheduledSendCoreV01OpenMaster_();
    var sh = mcScheduledSendCoreV01EnsureQueueSheet_(ss);
    var values = sh.getDataRange().getValues();
    var items = [];
    var summary = { total: 0, queued: 0, sending: 0, sent: 0, failed: 0, canceled: 0 };
    if (values.length >= 2) {
      var headers = values[0].map(function(x){ return String(x || '').trim(); });
      var hm = mcScheduledSendCoreV01HeaderMap_(headers);
      for (var r = values.length - 1; r >= 1; r--) {
        var row = values[r];
        var status = String(row[hm.status] || '').trim().toUpperCase();
        if (!status) status = '-';
        summary.total++;
        if (status === 'QUEUED') summary.queued++;
        else if (status === 'SENDING') summary.sending++;
        else if (status === 'SENT') summary.sent++;
        else if (status === 'FAILED') summary.failed++;
        else if (status === 'CANCELED') summary.canceled++;
        if (filterStatus && status !== filterStatus) continue;
        if (items.length >= limit) continue;
        items.push({
          scheduleId: String(row[hm.scheduleId] || '').trim(),
          calendarEventId: hm.calendarEventId == null ? '' : String(row[hm.calendarEventId] || '').trim(),
          status: status,
          statusReason: String(row[hm.statusReason] || ''),
          scheduledAt: mcScheduledSendCoreV01CellText_(row[hm.scheduledAt]),
          mailAccountId: String(row[hm.mailAccountId] || ''),
          toEmail: String(row[hm.toEmail] || ''),
          subject: String(row[hm.subject] || ''),
          attemptCount: Number(row[hm.attemptCount] || 0),
          lastAttemptAt: mcScheduledSendCoreV01CellText_(row[hm.lastAttemptAt]),
          sentAt: mcScheduledSendCoreV01CellText_(row[hm.sentAt]),
          gmailMessageId: String(row[hm.gmailMessageId] || ''),
          gmailThreadId: String(row[hm.gmailThreadId] || ''),
          createdAt: mcScheduledSendCoreV01CellText_(row[hm.createdAt]),
          createdBy: String(row[hm.createdBy] || ''),
          updatedAt: mcScheduledSendCoreV01CellText_(row[hm.updatedAt]),
          updatedBy: String(row[hm.updatedBy] || '')
        });
      }
    }
    result.ok = true;
    result.message = '예약 발송 목록 조회 완료';
    result.items = items;
    result.summary = summary;
  } catch (err) {
    result.ok = false;
    result.message = String(err && err.message ? err.message : err);
  }
  mcScheduledSendCoreV01Log_(result);
  return result;
}

function mcScheduledSendCoreV01Cancel(req) {
  var result = mcScheduledSendCoreV01Result_('mcScheduledSendCoreV01Cancel');
  try {
    req = req || {};
    var scheduleId = mcScheduledSendCoreV01Require_(req.scheduleId, 'scheduleId');
    var ss = mcScheduledSendCoreV01OpenMaster_();
    var sh = mcScheduledSendCoreV01EnsureQueueSheet_(ss);
    var values = sh.getDataRange().getValues();
    if (values.length < 2) throw new Error('예약 발송 큐가 비어 있습니다.');
    var headers = values[0].map(function(x){ return String(x || '').trim(); });
    var hm = mcScheduledSendCoreV01HeaderMap_(headers);
    var foundRow = -1;
    var currentStatus = '';
    var calendarEventId = '';
    for (var r = 1; r < values.length; r++) {
      if (String(values[r][hm.scheduleId] || '').trim() === scheduleId) {
        foundRow = r + 1;
        currentStatus = String(values[r][hm.status] || '').trim().toUpperCase();
        calendarEventId = hm.calendarEventId == null ? '' : String(values[r][hm.calendarEventId] || '').trim();
        break;
      }
    }
    if (foundRow < 0) throw new Error('예약 발송 건을 찾지 못했습니다: ' + scheduleId);
    if (currentStatus !== 'QUEUED') throw new Error('예약대기 상태만 취소할 수 있습니다. 현재 상태: ' + currentStatus);
    mcScheduledSendCoreV01SetRow_(sh, hm, foundRow, {
      status: 'CANCELED',
      statusReason: '사용자 예약 취소',
      updatedAt: mcScheduledSendCoreV01Now_(),
      updatedBy: mcScheduledSendCoreV01User_()
    });
    mcScheduledSendCoreV01UpdateCalendarLinkStatus_(ss, calendarEventId, 'CANCELED', '사용자 예약 취소');
    result.ok = true;
    result.message = '예약 발송 취소 완료';
    result.scheduleId = scheduleId;
    result.status = 'CANCELED';
  } catch (err) {
    result.ok = false;
    result.message = String(err && err.message ? err.message : err);
  }
  mcScheduledSendCoreV01Log_(result);
  return result;
}


function mcScheduledSendCoreV01RetryFailed(req) {
  var result = mcScheduledSendCoreV01Result_('mcScheduledSendCoreV01RetryFailed');
  try {
    req = req || {};
    var scheduleId = mcScheduledSendCoreV01Require_(req.scheduleId, 'scheduleId');
    var ss = mcScheduledSendCoreV01OpenMaster_();
    var sh = mcScheduledSendCoreV01EnsureQueueSheet_(ss);
    var values = sh.getDataRange().getValues();
    if (values.length < 2) throw new Error('예약 발송 큐가 비어 있습니다.');
    var headers = values[0].map(function(x){ return String(x || '').trim(); });
    var hm = mcScheduledSendCoreV01HeaderMap_(headers);
    var foundRow = -1;
    var currentStatus = '';
    var calendarEventId = '';
    for (var r = 1; r < values.length; r++) {
      if (String(values[r][hm.scheduleId] || '').trim() === scheduleId) {
        foundRow = r + 1;
        currentStatus = String(values[r][hm.status] || '').trim().toUpperCase();
        calendarEventId = hm.calendarEventId == null ? '' : String(values[r][hm.calendarEventId] || '').trim();
        break;
      }
    }
    if (foundRow < 0) throw new Error('예약 발송 건을 찾지 못했습니다: ' + scheduleId);
    if (currentStatus !== 'FAILED') throw new Error('실패 상태만 재시도할 수 있습니다. 현재 상태: ' + currentStatus);
    var reason = String(req.reason || '').trim() || '사용자 예약 실패 재시도';
    mcScheduledSendCoreV01SetRow_(sh, hm, foundRow, {
      status: 'QUEUED',
      statusReason: reason,
      sentAt: '',
      gmailMessageId: '',
      gmailThreadId: '',
      updatedAt: mcScheduledSendCoreV01Now_(),
      updatedBy: mcScheduledSendCoreV01User_() || 'SYSTEM'
    });
    mcScheduledSendCoreV01UpdateCalendarLinkStatus_(ss, calendarEventId, 'QUEUED', reason);
    result.ok = true;
    result.message = '예약 발송 재시도 대기 전환 완료';
    result.scheduleId = scheduleId;
    result.status = 'QUEUED';
    result.calendarEventId = calendarEventId;
  } catch (err) {
    result.ok = false;
    result.message = String(err && err.message ? err.message : err);
  }
  mcScheduledSendCoreV01Log_(result);
  return result;
}


function mcScheduledSendCoreV01CreateOrUpdateCalendarLink_(ss, rowObj, payload) {
  var result = { ok: false, calendarEventId: '' };
  try {
    rowObj = rowObj || {};
    payload = payload || {};
    var scheduleId = String(rowObj.scheduleId || '').trim();
    if (!scheduleId) return result;
    var calendarEventId = 'MCAL-' + scheduleId;
    var sh = mcScheduledSendCoreV01EnsureCalendarEventsSheet_(ss);
    var headers = mcScheduledSendCoreV01Headers_(sh);
    var hm = mcScheduledSendCoreV01HeaderMap_(headers);
    var foundRow = mcScheduledSendCoreV01FindRow_(sh, hm, 'calendarEventId', calendarEventId);
    var scheduledAt = mcScheduledSendCoreV01ParseDate_(rowObj.scheduledAt);
    var endAt = scheduledAt ? new Date(scheduledAt.getTime() + 5 * 60 * 1000) : null;
    var subject = String(rowObj.subject || payload.subject || '').trim() || '예약 발송';
    var toEmail = String(rowObj.toEmail || payload.toEmail || payload.to || '').trim();
    var mailAccountId = String(rowObj.mailAccountId || payload.mailAccountId || '').trim();
    var desc = [
      'FEELHAUS MailCenter 예약 발송 일정',
      'scheduleId: ' + scheduleId,
      'status: QUEUED',
      'scheduledAt: ' + String(rowObj.scheduledAt || ''),
      'mailAccountId: ' + mailAccountId,
      'toEmail: ' + toEmail,
      'subject: ' + subject,
      'createdAt: ' + String(rowObj.createdAt || ''),
      'createdBy: ' + String(rowObj.createdBy || '')
    ].join('\n');
    var obj = {
      calendarEventId: calendarEventId,
      provider: 'MAILCENTER',
      providerEventId: '',
      eventType: 'MAIL_RESERVED',
      calendarType: 'MAIL_RESERVED',
      sourceModule: 'MAILCENTER_SCHEDULED_SEND',
      sourceId: scheduleId,
      requestId: scheduleId,
      eventTitle: '[예약발송] ' + subject,
      title: '[예약발송] ' + subject,
      eventDescription: desc,
      description: desc,
      startAt: scheduledAt ? mcScheduledSendCoreV01FmtDate_(scheduledAt) : String(rowObj.scheduledAt || ''),
      endAt: endAt ? mcScheduledSendCoreV01FmtDate_(endAt) : String(rowObj.scheduledAt || ''),
      allDayYn: 'N',
      location: 'MailCenter 예약 발송',
      attendees: toEmail,
      ownerEmployeeId: '',
      assignedEmployeeId: '',
      eventStatus: '예정',
      statusReason: '예약 발송 대기: ' + scheduleId,
      naverRegisterStatus: 'SKIP',
      googleBackupStatus: 'SKIP',
      createdAt: String(rowObj.createdAt || mcScheduledSendCoreV01Now_()),
      createdBy: String(rowObj.createdBy || mcScheduledSendCoreV01User_()),
      updatedAt: mcScheduledSendCoreV01Now_(),
      updatedBy: mcScheduledSendCoreV01User_() || 'SYSTEM'
    };
    if (foundRow > 0) {
      mcScheduledSendCoreV01SetRow_(sh, hm, foundRow, obj);
    } else {
      sh.appendRow(headers.map(function(h){ return obj[h] != null ? obj[h] : ''; }));
    }
    mcScheduledSendCoreV01AppendCalendarLog_(ss, calendarEventId, 'SCHEDULE_LINK', 'SUCCESS', '예약 발송 캘린더 표시 생성/갱신: ' + scheduleId);
    result.ok = true;
    result.calendarEventId = calendarEventId;
  } catch (err) {
    try { Logger.log('Scheduled calendar link failed: ' + String(err && err.message ? err.message : err)); } catch(ignore) {}
  }
  return result;
}

function mcScheduledSendCoreV01UpdateCalendarLinkStatus_(ss, calendarEventId, scheduleStatus, reason) {
  calendarEventId = String(calendarEventId || '').trim();
  if (!calendarEventId) return { ok: false, message: 'calendarEventId 없음' };
  var result = { ok: false, calendarEventId: calendarEventId };
  try {
    var sh = mcScheduledSendCoreV01EnsureCalendarEventsSheet_(ss);
    var headers = mcScheduledSendCoreV01Headers_(sh);
    var hm = mcScheduledSendCoreV01HeaderMap_(headers);
    var rowNo = mcScheduledSendCoreV01FindRow_(sh, hm, 'calendarEventId', calendarEventId);
    if (rowNo < 1) throw new Error('캘린더 예약 일정을 찾지 못했습니다: ' + calendarEventId);
    var calStatus = '예정';
    var eventType = 'MAIL_RESERVED';
    if (scheduleStatus === 'SENT') { calStatus = '완료'; eventType = 'MAIL_SENT'; }
    else if (scheduleStatus === 'FAILED') { calStatus = '취소'; eventType = 'MAIL_FAILED'; }
    else if (scheduleStatus === 'CANCELED') { calStatus = '취소'; eventType = 'MAIL_CANCELED'; }
    var now = mcScheduledSendCoreV01Now_();
    mcScheduledSendCoreV01SetRow_(sh, hm, rowNo, {
      eventStatus: calStatus,
      eventType: eventType,
      calendarType: eventType,
      statusReason: String(reason || scheduleStatus || ''),
      updatedAt: now,
      updatedBy: mcScheduledSendCoreV01User_() || 'SYSTEM'
    });
    mcScheduledSendCoreV01AppendCalendarLog_(ss, calendarEventId, 'SCHEDULE_STATUS', 'SUCCESS', scheduleStatus + ': ' + String(reason || ''));
    result.ok = true;
    result.status = calStatus;
    result.eventType = eventType;
  } catch (err) {
    result.message = String(err && err.message ? err.message : err);
    try { Logger.log('Scheduled calendar status update failed: ' + result.message); } catch(ignore) {}
  }
  return result;
}

function mcScheduledSendCoreV01EnsureCalendarEventsSheet_(ss) {
  var headers = [
    'calendarEventId','eventId','customerId','contractId','installId','asId','requestId','provider','providerEventId','eventType','calendarType','sourceModule','sourceId','title','eventTitle','description','eventDescription','startAt','endAt','allDayYn','location','attendees','ownerEmployeeId','assignedEmployeeId','eventStatus','statusReason','naverRegisterStatus','naverProviderEventId','naverErrorCode','naverErrorMessage','googleBackupStatus','googleProviderEventId','googleErrorCode','googleErrorMessage','retryCount','lastRetryAt','createdAt','createdBy','updatedAt','updatedBy'
  ];
  var sh = ss.getSheetByName('MAILCENTER_CalendarEvents');
  if (!sh) sh = ss.insertSheet('MAILCENTER_CalendarEvents');
  var lastCol = Math.max(sh.getLastColumn(), headers.length);
  var current = sh.getRange(1, 1, 1, lastCol).getValues()[0].map(function(x){ return String(x || '').trim(); });
  var hasAny = current.some(function(x){ return !!x; });
  if (!hasAny) {
    sh.getRange(1, 1, 1, headers.length).setValues([headers]);
    sh.setFrozenRows(1);
  } else {
    var existing = {};
    current.forEach(function(h){ if (h) existing[h] = true; });
    var append = [];
    headers.forEach(function(h){ if (!existing[h]) append.push(h); });
    if (append.length) sh.getRange(1, sh.getLastColumn() + 1, 1, append.length).setValues([append]);
  }
  return sh;
}

function mcScheduledSendCoreV01FindRow_(sh, hm, key, value) {
  if (!sh || hm[key] == null) return -1;
  var lastRow = sh.getLastRow();
  if (lastRow < 2) return -1;
  var vals = sh.getRange(2, hm[key] + 1, lastRow - 1, 1).getValues();
  for (var i = 0; i < vals.length; i++) {
    if (String(vals[i][0] || '').trim() === String(value || '').trim()) return i + 2;
  }
  return -1;
}

function mcScheduledSendCoreV01AppendCalendarLog_(ss, calendarEventId, actionType, resultStatus, summary) {
  try {
    var headers = ['calendarLogId','calendarEventId','provider','actionType','resultStatus','providerEventId','errorCode','errorMessage','requestPayloadSummary','responseSummary','createdAt','createdBy'];
    var sh = ss.getSheetByName('MAILCENTER_CalendarLogs');
    if (!sh) sh = ss.insertSheet('MAILCENTER_CalendarLogs');
    var lastCol = Math.max(sh.getLastColumn(), headers.length);
    var current = sh.getRange(1,1,1,lastCol).getValues()[0].map(function(x){ return String(x || '').trim(); });
    if (!current.some(function(x){ return !!x; })) { sh.getRange(1,1,1,headers.length).setValues([headers]); sh.setFrozenRows(1); }
    else {
      var existing = {}; current.forEach(function(h){ if(h) existing[h]=true; });
      var append = []; headers.forEach(function(h){ if(!existing[h]) append.push(h); });
      if (append.length) sh.getRange(1, sh.getLastColumn()+1, 1, append.length).setValues([append]);
    }
    var hm = mcScheduledSendCoreV01HeaderMap_(mcScheduledSendCoreV01Headers_(sh));
    var now = mcScheduledSendCoreV01Now_();
    var obj = {
      calendarLogId: 'MCALLOG-' + Utilities.formatDate(new Date(), Session.getScriptTimeZone() || 'Asia/Seoul', 'yyyyMMddHHmmss') + '-' + Math.floor(Math.random() * 900000 + 100000),
      calendarEventId: calendarEventId,
      provider: 'SCHEDULED_SEND',
      actionType: actionType,
      resultStatus: resultStatus,
      providerEventId: '',
      errorCode: '',
      errorMessage: '',
      requestPayloadSummary: '',
      responseSummary: String(summary || '').slice(0, 900),
      createdAt: now,
      createdBy: mcScheduledSendCoreV01User_() || 'SYSTEM'
    };
    sh.appendRow(mcScheduledSendCoreV01Headers_(sh).map(function(h){ return obj[h] != null ? obj[h] : ''; }));
  } catch(ignore) {}
}

function mcScheduledSendCoreV01InstallTrigger() {
  var result = mcScheduledSendCoreV01Result_('mcScheduledSendCoreV01InstallTrigger');
  try {
    var triggers = ScriptApp.getProjectTriggers();
    for (var i = 0; i < triggers.length; i++) {
      if (triggers[i].getHandlerFunction && triggers[i].getHandlerFunction() === MC_SCHEDULED_SEND_CORE_V01_TRIGGER_FN) {
        ScriptApp.deleteTrigger(triggers[i]);
      }
    }
    ScriptApp.newTrigger(MC_SCHEDULED_SEND_CORE_V01_TRIGGER_FN).timeBased().everyMinutes(5).create();
    mcScheduledSendCoreV01EnsureQueueSheet_(mcScheduledSendCoreV01OpenMaster_());
    result.ok = true;
    result.message = '예약 발송 트리거 설치 완료: 5분 단위';
    result.triggerFunction = MC_SCHEDULED_SEND_CORE_V01_TRIGGER_FN;
    result.calendarLinkReady = typeof mcScheduledSendCoreV01CreateOrUpdateCalendarLink_ === 'function';
  } catch (err) {
    result.ok = false;
    result.message = String(err && err.message ? err.message : err);
  }
  mcScheduledSendCoreV01Log_(result);
  return result;
}

function mcScheduledSendCoreV01RemoveTrigger() {
  var result = mcScheduledSendCoreV01Result_('mcScheduledSendCoreV01RemoveTrigger');
  try {
    var removed = 0;
    var triggers = ScriptApp.getProjectTriggers();
    for (var i = 0; i < triggers.length; i++) {
      if (triggers[i].getHandlerFunction && triggers[i].getHandlerFunction() === MC_SCHEDULED_SEND_CORE_V01_TRIGGER_FN) {
        ScriptApp.deleteTrigger(triggers[i]);
        removed++;
      }
    }
    result.ok = true;
    result.message = '예약 발송 트리거 제거 완료';
    result.removed = removed;
  } catch (err) {
    result.ok = false;
    result.message = String(err && err.message ? err.message : err);
  }
  mcScheduledSendCoreV01Log_(result);
  return result;
}

function mcScheduledSendCoreV01Smoke() {
  var result = mcScheduledSendCoreV01Result_('mcScheduledSendCoreV01Smoke');
  try {
    var ss = mcScheduledSendCoreV01OpenMaster_();
    var sh = mcScheduledSendCoreV01EnsureQueueSheet_(ss);
    result.ok = true;
    result.message = '예약 발송 코어 점검 완료';
    result.sheet = sh.getName();
    result.bridgeReady = typeof mcSendBridgeV02Send === 'function';
    result.triggerFunction = MC_SCHEDULED_SEND_CORE_V01_TRIGGER_FN;
  } catch (err) {
    result.ok = false;
    result.message = String(err && err.message ? err.message : err);
  }
  mcScheduledSendCoreV01Log_(result);
  return result;
}

function mcScheduledSendCoreV01EnsureQueueSheet_(ss) {
  var headers = [
    'scheduleId','calendarEventId','status','statusReason','scheduledAt','mailAccountId','toEmail','subject','payloadJson',
    'attemptCount','lastAttemptAt','sentAt','gmailMessageId','gmailThreadId','createdAt','createdBy','updatedAt','updatedBy'
  ];
  var sh = ss.getSheetByName(MC_SCHEDULED_SEND_CORE_V01_QUEUE_SHEET);
  if (!sh) sh = ss.insertSheet(MC_SCHEDULED_SEND_CORE_V01_QUEUE_SHEET);
  var lastCol = Math.max(sh.getLastColumn(), headers.length);
  var current = sh.getRange(1, 1, 1, lastCol).getValues()[0].map(function(x){ return String(x || '').trim(); });
  var hasAny = current.some(function(x){ return !!x; });
  if (!hasAny) {
    sh.getRange(1, 1, 1, headers.length).setValues([headers]);
    sh.setFrozenRows(1);
  } else {
    var existing = {};
    current.forEach(function(h){ if (h) existing[h] = true; });
    var append = [];
    headers.forEach(function(h){ if (!existing[h]) append.push(h); });
    if (append.length) sh.getRange(1, sh.getLastColumn() + 1, 1, append.length).setValues([append]);
  }
  return sh;
}

function mcScheduledSendCoreV01OpenMaster_() {
  if (typeof mcComposeCoreV01OpenMaster_ === 'function') {
    var opened = mcComposeCoreV01OpenMaster_();
    if (opened && opened.ss) return opened.ss;
    if (opened && opened.getSheetByName) return opened;
  }
  if (typeof mailCenterOpenMasterDb_ === 'function') {
    var m = mailCenterOpenMasterDb_();
    if (m && m.ss) return m.ss;
    if (m && m.getSheetByName) return m;
  }
  var setup = SpreadsheetApp.openById(MC_SCHEDULED_SEND_CORE_V01_SETUP_DB_ID);
  var config = setup.getSheetByName(MC_SCHEDULED_SEND_CORE_V01_CONFIG_SHEET);
  if (!config) throw new Error('SystemConfig 시트를 찾지 못했습니다.');
  var values = config.getDataRange().getValues();
  if (!values || values.length < 2) throw new Error('SystemConfig 데이터가 비어 있습니다.');
  var headers = values[0].map(function(x){ return String(x || '').trim(); });
  var keyIdx = headers.indexOf('CONFIG_KEY');
  var valIdx = headers.indexOf('VALUE');
  if (keyIdx < 0 || valIdx < 0) throw new Error('SystemConfig CONFIG_KEY/VALUE 헤더를 찾지 못했습니다.');
  var masterId = '';
  for (var i = 1; i < values.length; i++) {
    var key = String(values[i][keyIdx] || '').trim();
    if (['FEELHAUS_DB_MASTER','FEELHAUS_DB_MASTER_ID','MASTER_DB_ID','DB_MASTER_ID'].indexOf(key) >= 0) {
      masterId = String(values[i][valIdx] || '').trim();
      if (masterId) break;
    }
  }
  if (!masterId) throw new Error('SystemConfig에서 FEELHAUS_DB_MASTER ID를 찾지 못했습니다.');
  return SpreadsheetApp.openById(masterId);
}

function mcScheduledSendCoreV01Headers_(sh) {
  return sh.getRange(1, 1, 1, sh.getLastColumn()).getValues()[0].map(function(x){ return String(x || '').trim(); });
}
function mcScheduledSendCoreV01HeaderMap_(headers) {
  var hm = {};
  (headers || []).forEach(function(h, i){ if (h) hm[h] = i; });
  return hm;
}
function mcScheduledSendCoreV01SetRow_(sh, hm, rowNo, obj) {
  Object.keys(obj || {}).forEach(function(k){
    if (hm[k] == null) return;
    sh.getRange(rowNo, hm[k] + 1).setValue(obj[k]);
  });
}
function mcScheduledSendCoreV01ParseDate_(v) {
  if (v instanceof Date) return v;
  var s = String(v || '').trim();
  if (!s) return null;
  var d = new Date(s);
  if (!isNaN(d.getTime())) return d;
  d = new Date(s.replace(' ', 'T'));
  return d;
}
function mcScheduledSendCoreV01FmtDate_(d) {
  return Utilities.formatDate(d, Session.getScriptTimeZone() || 'Asia/Seoul', 'yyyy-MM-dd HH:mm:ss');
}
function mcScheduledSendCoreV01Now_() {
  return Utilities.formatDate(new Date(), Session.getScriptTimeZone() || 'Asia/Seoul', 'yyyy-MM-dd HH:mm:ss');
}
function mcScheduledSendCoreV01NewId_(prefix) {
  return prefix + '-' + Utilities.formatDate(new Date(), Session.getScriptTimeZone() || 'Asia/Seoul', 'yyyyMMddHHmmss') + '-' + Math.floor(Math.random() * 900000 + 100000);
}
function mcScheduledSendCoreV01User_() {
  try { return Session.getActiveUser().getEmail() || ''; } catch(e) { return ''; }
}
function mcScheduledSendCoreV01Require_(v, name) {
  var s = String(v || '').trim();
  if (!s) throw new Error(name + ' 값이 필요합니다.');
  return s;
}
function mcScheduledSendCoreV01Result_(action) {
  return { ok:false, build:MC_SCHEDULED_SEND_CORE_V01_BUILD, action:action, message:'', generatedAt:mcScheduledSendCoreV01Now_() };
}
function mcScheduledSendCoreV01Log_(obj) {
  try { Logger.log('JSON_COMPACT_RESULT: ' + JSON.stringify(obj)); } catch(e) { Logger.log(obj); }
}

// MC_SCHEDULED_SEND_CELLTEXT_ALIAS_FIX_V01_20260527
// 예약 목록 표시용 셀 값 문자열 정리 보조 함수 누락 복구.
function mcScheduledSendCoreV01CellText_(v) {
  if (v === null || v === undefined) return '';
  if (Object.prototype.toString.call(v) === '[object Date]' || v instanceof Date) {
    try {
      return Utilities.formatDate(v, Session.getScriptTimeZone() || 'Asia/Seoul', 'yyyy-MM-dd HH:mm:ss');
    } catch (e) {
      return String(v || '').trim();
    }
  }
  return String(v).trim();
}
