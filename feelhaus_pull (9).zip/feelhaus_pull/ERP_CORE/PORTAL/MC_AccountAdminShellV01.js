/**
 * FEELHAUS MailCenter Account Admin Shell V01
 * Build: MC_ACCOUNT_ADMIN_SHELL_V01_20260519
 * Linked owner version.
 */

var MC_ACCOUNT_ADMIN_SHELL_V01_BUILD = 'MAILCENTER_ACCOUNT_ADMIN_APPROVAL_V01_20260520';
var MC_ACCOUNT_ADMIN_SHELL_V01_DESC = 'MailCenter 계정 등록/승인/사용중지/기본계정 운영관리 V01';

function runMcAccountAdminShellV01() {
  var result = {
    ok: false,
    build: MC_ACCOUNT_ADMIN_SHELL_V01_BUILD,
    action: 'runMcAccountAdminShellV01',
    generatedAt: mcAccountAdminShellV01Now_(),
    message: '',
    checks: []
  };

  try {
    result.checks.push({ key: 'CoreReady', ok: typeof mcAccountAdminLinkedV01GetAdminData === 'function', message: '계정 관리 Linked Core 확인' });
    result.checks.push({ key: 'RegisterReady', ok: typeof mcAccountAdminLinkedV01RegisterAccount === 'function', message: '원본 연결형 계정 등록 함수 확인' });
    result.checks.push({ key: 'ApproveReady', ok: typeof mcAccountAdminLinkedV01ApproveAccount === 'function', message: '승인 함수 확인' });
    result.checks.push({ key: 'OAuthUrlReady', ok: typeof mcAccountAdminLinkedV01BuildOAuthUrl === 'function', message: 'OAuth URL 생성 함수 확인' });
    result.checks.push({ key: 'SuspendReady', ok: typeof mcAccountAdminLinkedV01SuspendAccount === 'function', message: '계정 사용중지 함수 확인' });
    result.checks.push({ key: 'SetPrimaryReady', ok: typeof mcAccountAdminLinkedV01SetPrimaryAccount === 'function', message: '기본 발신계정 지정 함수 확인' });
    result.ok = result.checks.every(function(c) { return !!c.ok; });
    result.message = result.ok ? 'MailCenter Account Admin Approval V01 준비 완료' : '필수 함수 확인 필요';
  } catch (err) {
    result.ok = false;
    result.message = String(err && err.message ? err.message : err);
  }

  Logger.log('JSON_COMPACT_RESULT: ' + JSON.stringify(result));
  return result;
}

function mcAccountAdminShellV01HandleGet(e) {
  var data = (typeof mcAccountAdminLinkedV01GetAdminData === 'function')
    ? mcAccountAdminLinkedV01GetAdminData()
    : { ok: false, message: 'mcAccountAdminLinkedV01GetAdminData 함수가 없습니다.', accounts: [], summary: {}, staffOwners: [], vendorOwners: [] };

  var t = HtmlService.createTemplateFromFile('MC_AccountAdminViewV01');
  t.build = MC_ACCOUNT_ADMIN_SHELL_V01_BUILD;
  t.buildDesc = MC_ACCOUNT_ADMIN_SHELL_V01_DESC;
  t.initialJson = JSON.stringify(data);

  return t.evaluate()
    .setTitle('FEELHAUS MailCenter Account Admin')
    .setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL);
}

function mcAccountAdminShellV01Now_() {
  return Utilities.formatDate(new Date(), Session.getScriptTimeZone() || 'Asia/Seoul', 'yyyy-MM-dd HH:mm:ss');
}
