function portalCalendarSafe01BR10K4BStaffCardModalRealApplyVerify(){
  var build='PORTAL_CALENDAR_SAFE01B_R10K4B_STAFF_CARD_MODAL_REAL_APPLY_20260604';
  var html='';var readError='';
  try{html=HtmlService.createHtmlOutputFromFile('MC_CalendarViewV01').getContent();}catch(e){readError=String(e&&e.message||e);}
  function has(x){return html.indexOf(x)>=0;}
  var checks={
    viewReadable:!!html&&!readError,
    r10k4bBuildMarkerPresent:has(build),
    manualOldGuideRemoved:!has('업무 흐름 전체 선택'),
    manualStaffPickerReady:has('업무 타입별 직원 판단 카드')&&has('cal-r10k4-staff-picker-grid'),
    selectionStaffCardReady:has('data-r10k4-selection-detail')&&has('박람회 선정 과정 상세 카드'),
    eventStaffCardReady:has('data-r10k4-event-detail')&&has('행사관리 상세 카드'),
    generalStaffCardReady:has('data-r10k4-general-detail')&&has('일반/기타 일정 상세 카드'),
    firstPageK4SummaryReady:has('fhCalendarR10K4StaffWorkflowSummaryHtml(type,stage)'),
    operationSectionUsesK4Cards:has('return fhCalendarR10K4EventStaffDetailHtml')&&has('return fhCalendarR10K4SelectionStaffDetailHtml'),
    r10k2EventMasterKept:has('me_eventMasterPicker')&&has('ERP_행사관리'),
    r11AutoRefreshKept:has('fhCalendarStartAutoRefreshR11')&&has('setInterval(fhCalendarCheckPageRefreshR11,30000)'),
    providerWriteNotAddedInR10K4B:html.indexOf('CalendarApp.createEvent')<0&&html.indexOf('UrlFetchApp.fetch')<0,
    noSheetProviderWriteInVerify:true
  };
  var fatal=[];Object.keys(checks).forEach(function(k){if(!checks[k])fatal.push(k);});
  var res={ok:fatal.length===0,build:build,baseBuild:'PORTAL_CALENDAR_SAFE01B_R10K4_STAFF_WORKFLOW_CARD_DETAIL_20260604',action:'portalCalendarSafe01BR10K4BStaffCardModalRealApplyVerify',safety:'READ_ONLY_RUNTIME_VERIFY_NO_SHEET_PROVIDER_WRITE',checks:checks,diagnostics:{htmlLength:html.length,readError:readError},warnings:[],fatal:fatal,summary:{mode:'R10K4B real modal apply: staff-facing workflow cards replace developer guide',manual:'수정 모달의 업무 흐름 안내를 직원용 3분류 카드로 교체',detail:'상세 모달 4번 섹션을 선정/행사관리/일반별 직원용 카드로 교체',preserved:'R10K2 ERP_행사관리 eventId picker and R11 auto refresh kept'},message:fatal.length?'R10K4B verification failed.':'R10K4B staff card modal real apply verification passed.'};
  Logger.log('JSON_COMPACT_RESULT: '+JSON.stringify(res));
  return res;
}
function portalCalendarSafe01BR10K4BStaffWorkflowCardVerify(){return portalCalendarSafe01BR10K4BStaffCardModalRealApplyVerify();}
