/**
 * FEELHAUS MailCenter Send Test V05 Clean View Fix
 * Build: MC_SENDTEST_CLEAN_VIEW_FIX_0130_20260520
 *
 * Scope:
 * - MailCenterSendTestV05 화면만 안정화
 * - 대시보드 표/로그 혼선 제거
 * - 서버 initial data로 계정/로그 직접 렌더링
 * - 다른 MailCenter 화면은 건드리지 않음
 */

var MC_SENDTEST_CLEAN_VIEW_FIX_0130_BUILD = 'MC_SENDTEST_CLEAN_VIEW_FIX_0130_20260520';
var MC_SENDTEST_CLEAN_VIEW_FIX_0130_WEBAPP_URL = 'https://script.google.com/macros/s/AKfycbxCyFE7zf4vE8nsfjOeWX0pC56SqU84gm8ie8Txa3qHQGEusJCZeljzCdYeOmZxUVYvjA/exec';

function runMcSendTestCleanViewFix0130Smoke() {
  var result = {
    ok: false,
    build: MC_SENDTEST_CLEAN_VIEW_FIX_0130_BUILD,
    action: 'runMcSendTestCleanViewFix0130Smoke',
    generatedAt: mcSendTestClean0130Now_(),
    message: '',
    checks: []
  };
  try {
    var data = mcSendTestClean0130GetInitialData();
    result.checks.push({key:'HandleGetReady', ok: typeof mcDashboardSendShellV05HandleGet === 'function', message:'테스트 발송 화면 핸들러 확인'});
    result.checks.push({key:'InitialDataReady', ok: !!data && !!data.ok, message:'초기 데이터 확인'});
    result.checks.push({key:'AccountsReady', ok: !!data && Array.isArray(data.accounts), message:'발신 계정 목록 확인: ' + ((data.accounts || []).length)});
    result.checks.push({key:'RecentLogsReady', ok: !!data && Array.isArray(data.recentLogs), message:'최근 발송 로그 확인: ' + ((data.recentLogs || []).length)});
    result.checks.push({key:'SendBridgeReady', ok: typeof mcSendTestClean0130Send === 'function', message:'테스트 발송 브릿지 확인'});
    result.ok = result.checks.every(function(c){ return !!c.ok; });
    result.message = result.ok ? '테스트 발송 Clean View Fix 0130 준비 완료' : '테스트 발송 Clean View Fix 0130 점검 필요';
  } catch (err) {
    result.ok = false;
    result.message = String(err && err.message ? err.message : err);
  }
  Logger.log('JSON_COMPACT_RESULT: ' + JSON.stringify(result));
  return result;
}

function mcDashboardSendShellV05HandleGet(e) {
  var t = HtmlService.createTemplateFromFile('MC_DashboardSendViewV05');
  t.build = MC_SENDTEST_CLEAN_VIEW_FIX_0130_BUILD;
  t.webAppUrl = MC_SENDTEST_CLEAN_VIEW_FIX_0130_WEBAPP_URL;
  t.initialJson = JSON.stringify(mcSendTestClean0130GetInitialData());
  return t.evaluate()
    .setTitle('FEELHAUS MailCenter Send Test')
    .setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL);
}

function mcSendTestClean0130GetInitialData() {
  var result = {
    ok: false,
    build: MC_SENDTEST_CLEAN_VIEW_FIX_0130_BUILD,
    action: 'mcSendTestClean0130GetInitialData',
    generatedAt: mcSendTestClean0130Now_(),
    message: '',
    summary: {
      totalAccounts: 0,
      activeAccounts: 0,
      connectedAccounts: 0,
      hqAccounts: 0,
      vendorAccounts: 0,
      todaySent: 0
    },
    accounts: [],
    recentLogs: []
  };

  try {
    var data = null;
    if (typeof mcDashboardV04CleanGetData === 'function') {
      data = mcDashboardV04CleanGetData();
    } else if (typeof mcDashboardShellV04GetInitialData === 'function') {
      data = mcDashboardShellV04GetInitialData();
    }

    if (data && data.ok) {
      result.accounts = (data.accounts || []).map(mcSendTestClean0130NormalizeAccount_);
      result.recentLogs = (data.recentLogs || data.logs || []).map(mcSendTestClean0130NormalizeLog_);
    } else {
      result.accounts = mcSendTestClean0130ReadAccounts_();
      result.recentLogs = mcSendTestClean0130ReadLogs_();
    }

    result.summary.totalAccounts = result.accounts.length;
    result.summary.activeAccounts = result.accounts.filter(function(a){ return String(a.accountStatus).toUpperCase() === 'ACTIVE'; }).length;
    result.summary.connectedAccounts = result.accounts.filter(function(a){ return String(a.connectionStatus).toUpperCase() === 'CONNECTED'; }).length;
    result.summary.hqAccounts = result.accounts.filter(function(a){ return String(a.roleCode).indexOf('HQ') >= 0 || String(a.ownerType).indexOf('HQ') >= 0; }).length;
    result.summary.vendorAccounts = result.accounts.filter(function(a){ return String(a.roleCode).indexOf('VENDOR') >= 0 || String(a.ownerType).indexOf('VENDOR') >= 0; }).length;

    var today = Utilities.formatDate(new Date(), Session.getScriptTimeZone() || 'Asia/Seoul', 'yyyy-MM-dd');
    result.summary.todaySent = result.recentLogs.filter(function(l) {
      return String(l.createdAt || '').indexOf(today) === 0 && String(l.sendStatus).toUpperCase() === 'SENT';
    }).length;

    result.ok = true;
    result.message = '테스트 발송 Clean View 초기 데이터 조회 완료';
  } catch (err) {
    result.ok = false;
    result.message = String(err && err.message ? err.message : err);
  }

  Logger.log('JSON_COMPACT_RESULT: ' + JSON.stringify(result));
  return mcSendTestClean0130Safe_(result);
}

function mcSendTestClean0130Send(payload) {
  var result = {
    ok: false,
    build: MC_SENDTEST_CLEAN_VIEW_FIX_0130_BUILD,
    action: 'mcSendTestClean0130Send',
    generatedAt: mcSendTestClean0130Now_(),
    message: '',
    tried: [],
    sendResult: null
  };
  try {
    var p = payload || {};
    var toEmail = String(p.toEmail || '').trim();
    if (!toEmail) throw new Error('수신자 이메일이 필요합니다.');

    var sendPayload = {
      mailAccountId: String(p.mailAccountId || '').trim(),
      fromEmail: String(p.fromEmail || '').trim(),
      toEmail: toEmail,
      subject: String(p.subject || '[FEELHAUS] 이메일 테스트 발송입니다.'),
      body: String(p.body || '안녕하세요.\nFEELHAUS MailCenter 테스트 발송입니다.\n정상적으로 수신되면 회신 부탁드립니다.\n감사합니다.'),
      bodyText: String(p.body || ''),
      bodyHtml: String(p.bodyHtml || ''),
      attachments: []
    };

    var names = [
      'mcDashboardV04CleanSendTest',
      'mcComposeCoreV01Send',
      'mcDriveLinkAttachmentV01SendWithLinks',
      'mailCenterSendTestCoreV01Send',
      'mcSendTestCoreV01Send',
      'mcDashboardSendV05Send',
      'mcDashboardSendShellV05Send',
      'portal169GmailSend'
    ];

    var last = null;
    for (var i = 0; i < names.length; i++) {
      var name = names[i];
      if (typeof this[name] !== 'function') continue;
      result.tried.push(name);
      try {
        var sent = this[name](sendPayload);
        last = sent;
        if (sent && sent.ok) {
          result.ok = true;
          result.message = '테스트 발송 완료';
          result.sendResult = sent;
          Logger.log('JSON_COMPACT_RESULT: ' + JSON.stringify(result));
          return result;
        }
      } catch (inner) {
        last = { ok: false, message: String(inner && inner.message ? inner.message : inner) };
      }
    }

    result.sendResult = last;
    throw new Error((last && last.message) ? last.message : '사용 가능한 발송 함수가 없습니다.');
  } catch (err) {
    result.ok = false;
    result.message = String(err && err.message ? err.message : err);
  }
  Logger.log('JSON_COMPACT_RESULT: ' + JSON.stringify(result));
  return result;
}

function mcDashboardSendShellV05GetRecentLogsForView(payload) {
  var data = mcSendTestClean0130GetInitialData();
  return {
    ok: !!(data && data.ok),
    build: MC_SENDTEST_CLEAN_VIEW_FIX_0130_BUILD,
    action: 'mcDashboardSendShellV05GetRecentLogsForView',
    generatedAt: mcSendTestClean0130Now_(),
    message: data && data.ok ? '최근 발송 로그 조회 완료' : ((data && data.message) || '최근 발송 로그 조회 실패'),
    logs: (data && data.recentLogs) || []
  };
}

function mcDashboardSendShellV05GetDirectInitialData0129() {
  return mcSendTestClean0130GetInitialData();
}

function runMcSendLogDirectRenderFix0129Smoke() {
  return runMcSendTestCleanViewFix0130Smoke();
}

function runMcDashboardSendLogMiniFix0128() {
  var result = {
    ok: false,
    build: MC_SENDTEST_CLEAN_VIEW_FIX_0130_BUILD,
    action: 'runMcDashboardSendLogMiniFix0128',
    generatedAt: mcSendTestClean0130Now_(),
    message: '',
    checks: []
  };
  try {
    var r = mcDashboardSendShellV05GetRecentLogsForView({limit:10});
    result.checks.push({key:'RecentLogsFunctionReady', ok: typeof mcDashboardSendShellV05GetRecentLogsForView === 'function', message:'최근 로그 보조 함수 확인'});
    result.checks.push({key:'RecentLogsLoaded', ok: !!r && r.ok && Array.isArray(r.logs), message:'최근 발송 로그 조회 확인: ' + ((r && r.logs) ? r.logs.length : 0)});
    result.ok = result.checks.every(function(c){ return !!c.ok; });
    result.message = result.ok ? '테스트 발송 로그 미니 수정 준비 완료' : '테스트 발송 로그 미니 수정 점검 필요';
  } catch (err) {
    result.ok = false;
    result.message = String(err && err.message ? err.message : err);
  }
  Logger.log('JSON_COMPACT_RESULT: ' + JSON.stringify(result));
  return result;
}

function mcSendTestClean0130NormalizeAccount_(a) {
  a = a || {};
  var email = a.emailAddress || a.accountEmail || a.mailAddress || a.email || '';
  var role = a.roleCode || a.accountPurpose || a.purpose || a.ownerType || '';
  return {
    mailAccountId: a.mailAccountId || a.accountId || '',
    typeLabel: a.typeLabel || mcSendTestClean0130TypeLabel_(a.ownerType, role, a.vendorId),
    emailAddress: email,
    ownerName: a.ownerName || a.displayName || a.accountName || email,
    ownerType: a.ownerType || '',
    roleCode: role,
    isDefault: a.isDefault || '아니요',
    accountStatus: a.accountStatus || a.status || 'ACTIVE',
    connectionStatus: a.connectionStatus || a.authStatus || a.oauthStatus || '',
    lastConnectedAt: a.lastConnectedAt || a.connectedAt || a.updatedAt || '',
    canSend: a.canSend || '가능'
  };
}

function mcSendTestClean0130NormalizeLog_(l) {
  l = l || {};
  return {
    createdAt: l.createdAt || l.requestedAt || l.sentAt || '',
    fromEmail: l.fromEmail || l.senderEmail || l.mailFrom || '',
    toEmail: l.toEmail || l.recipientEmail || l.mailTo || '',
    subject: l.subject || '',
    sendStatus: l.sendStatus || l.status || '',
    statusReason: l.statusReason || l.reason || '',
    gmailMessageId: l.gmailMessageId || ''
  };
}

function mcSendTestClean0130ReadAccounts_() {
  var ss = mcSendTestClean0130OpenMaster_();
  return mcSendTestClean0130ReadSheet_(ss, 'MailCenter_Accounts').map(mcSendTestClean0130NormalizeAccount_);
}

function mcSendTestClean0130ReadLogs_() {
  var ss = mcSendTestClean0130OpenMaster_();
  return mcSendTestClean0130ReadSheet_(ss, 'MailCenter_SendLogs').map(mcSendTestClean0130NormalizeLog_).filter(function(x) {
    return x.createdAt || x.fromEmail || x.toEmail || x.subject || x.sendStatus;
  }).sort(function(a,b) {
    return String(b.createdAt || '').localeCompare(String(a.createdAt || ''));
  }).slice(0,10);
}

function mcSendTestClean0130OpenMaster_() {
  if (typeof portal19GetConfigBundle_ === 'function' && typeof portal19OpenMaster_ === 'function') {
    var bundle = portal19GetConfigBundle_();
    var ssByPortal = portal19OpenMaster_(bundle);
    if (ssByPortal) return ssByPortal;
  }
  var setupId = '17VMSpgSZCvIrUlgcw8yCNcnl8WQWo2IcRf5tDCcuJGM';
  var setup = SpreadsheetApp.openById(setupId);
  var sh = setup.getSheetByName('SystemConfig');
  if (!sh) throw new Error('SystemConfig 시트를 찾지 못했습니다.');
  var values = sh.getDataRange().getValues();
  var headers = values[0].map(function(h){ return String(h || '').trim(); });
  var keyCol = headers.indexOf('configKey');
  var valueCol = headers.indexOf('configValue');
  if (keyCol < 0 || valueCol < 0) throw new Error('SystemConfig 헤더 configKey/configValue를 찾지 못했습니다.');
  var masterId = '';
  for (var r = 1; r < values.length; r++) {
    if (String(values[r][keyCol] || '').trim() === 'FEELHAUS_DB_MASTER') {
      masterId = String(values[r][valueCol] || '').trim();
      break;
    }
  }
  if (!masterId) throw new Error('FEELHAUS_DB_MASTER configValue를 찾지 못했습니다.');
  return SpreadsheetApp.openById(masterId);
}

function mcSendTestClean0130ReadSheet_(ss, name) {
  var sh = ss.getSheetByName(name);
  if (!sh) return [];
  var values = sh.getDataRange().getValues();
  if (!values || values.length < 2) return [];
  var headers = values[0].map(function(h){ return String(h || '').trim(); });
  var rows = [];
  for (var r = 1; r < values.length; r++) {
    var obj = {};
    for (var c = 0; c < headers.length; c++) {
      if (!headers[c]) continue;
      var v = values[r][c];
      obj[headers[c]] = v instanceof Date
        ? Utilities.formatDate(v, Session.getScriptTimeZone() || 'Asia/Seoul', 'yyyy-MM-dd HH:mm:ss')
        : v;
    }
    rows.push(obj);
  }
  return rows;
}

function mcSendTestClean0130TypeLabel_(ownerType, role, vendorId) {
  var raw = String(role || ownerType || '').toUpperCase();
  if (raw.indexOf('HQ_OFFICIAL') >= 0) return '본사대표';
  if (raw.indexOf('HQ') >= 0) return '본사직원';
  if (raw.indexOf('VENDOR') >= 0 || vendorId) return '업체대표';
  return '기타';
}

function mcSendTestClean0130Now_() {
  return Utilities.formatDate(new Date(), Session.getScriptTimeZone() || 'Asia/Seoul', 'yyyy-MM-dd HH:mm:ss');
}

function mcSendTestClean0130Safe_(obj) {
  try { return JSON.parse(JSON.stringify(obj)); }
  catch (e) { return { ok:false, build:MC_SENDTEST_CLEAN_VIEW_FIX_0130_BUILD, message:String(e && e.message ? e.message : e) }; }
}
