/**
 * FEELHAUS MailCenter Calendar Record Link Pack V01
 * Build: MAILCENTER_CALENDAR_RECORD_LINK_PACK_V01_20260521
 * Purpose:
 * - Stage 8-A server pack for recordId / 상담기록 자동 연결 preparation
 * - Find calendar mail link rows with missing recordId/requestId and match MailCenter saved records by threadId/messageId/subject
 * - Provide dry-run, optional write function, gate, lock, summary
 * - Do not modify router/menu/html/shell/view files
 */
var MC_CALENDAR_RECORD_LINK_PACK_V01_BUILD = 'MAILCENTER_CALENDAR_RECORD_LINK_PACK_V01_20260521';
var MC_CALENDAR_RECORD_LINK_PACK_V01_SETUP_DB_ID = '17VMSpgSZCvIrUlgcw8yCNcnl8WQWo2IcRf5tDCcuJGM';
var MC_CALENDAR_RECORD_LINK_PACK_V01_CONFIG_SHEET = 'SystemConfig';
var MC_CALENDAR_RECORD_LINK_PACK_V01_WEBAPP_URL = 'https://script.google.com/a/macros/feelhausfair.com/s/AKfycbxCyFE7zf4vE8nsfjOeWX0pC56SqU84gm8ie8Txa3qHQGEusJCZeljzCdYeOmZxUVYvjA/exec';

function runMcCalendarRecordLinkPackV01Smoke() {
  var result = {
    ok: true,
    build: MC_CALENDAR_RECORD_LINK_PACK_V01_BUILD,
    action: 'runMcCalendarRecordLinkPackV01Smoke',
    generatedAt: mcCalendarRecordLinkPackV01Now_(),
    noWriteMode: true,
    checks: []
  };
  function check(key, ok, message, detail) {
    result.checks.push({ key: key, ok: !!ok, message: message, detail: detail || '' });
    if (!ok) result.ok = false;
  }
  try {
    check('MasterOpenReady', !!mcCalendarRecordLinkPackV01OpenMaster_(), 'SystemConfig -> FEELHAUS_DB_MASTER 연결 확인', 'FEELHAUS_DB_MASTER');
    check('CandidateScanReady', typeof mcCalendarRecordLinkPackV01ScanCandidates_ === 'function', 'recordId 자동 연결 후보 스캔 함수 확인');
    check('DryRunReady', typeof runMcCalendarRecordLinkPackV01DryRun === 'function', 'Dry Run 함수 확인');
    check('ApplyFunctionReady', typeof runMcCalendarRecordLinkPackV01ApplyLinks === 'function', '자동 연결 실행 함수 확인');
    check('GateFunctionReady', typeof runMcCalendarRecordLinkPackV01Gate === 'function', '게이트 함수 확인');
    check('LockFunctionReady', typeof runMcCalendarRecordLinkPackV01CreateBackupAndLock === 'function', '잠금 함수 확인');
    check('SummaryFunctionReady', typeof runMcCalendarRecordLinkPackV01Summary === 'function', '요약 기록 함수 확인');
    check('WebAppUrlReady', !!MC_CALENDAR_RECORD_LINK_PACK_V01_WEBAPP_URL, 'WebApp 절대주소 확인', MC_CALENDAR_RECORD_LINK_PACK_V01_WEBAPP_URL);
    check('NoRouterMenuHtmlTouch', true, '본 파일은 라우터/메뉴/HTML/Shell/View 변경 없음');
    result.message = result.ok ? 'MailCenter Calendar Record Link Pack V01 Smoke 통과' : 'MailCenter Calendar Record Link Pack V01 점검 필요';
  } catch (err) {
    result.ok = false;
    result.message = mcCalendarRecordLinkPackV01Err_(err);
  }
  Logger.log(JSON.stringify(result, null, 2));
  return result;
}

function runMcCalendarRecordLinkPackV01DryRun() {
  var result = {
    ok: true,
    build: MC_CALENDAR_RECORD_LINK_PACK_V01_BUILD,
    action: 'runMcCalendarRecordLinkPackV01DryRun',
    generatedAt: mcCalendarRecordLinkPackV01Now_(),
    noWriteMode: true,
    checks: [],
    summary: {},
    candidates: []
  };
  function check(key, ok, message, detail) {
    result.checks.push({ key: key, ok: !!ok, message: message, detail: detail || '' });
    if (!ok) result.ok = false;
  }
  try {
    var master = mcCalendarRecordLinkPackV01OpenMaster_();
    var scan = mcCalendarRecordLinkPackV01ScanCandidates_(master);
    result.summary = scan.summary;
    result.candidates = scan.candidates.slice(0, 10);
    check('CalendarEventsSheetReady', !!scan.sheets.events, 'MAILCENTER_CalendarEvents 시트 확인');
    check('CalendarMailLinksSheetReady', !!scan.sheets.links, 'MAILCENTER_CalendarMailLinks 시트 확인');
    check('RecordSourceCheckCompleted', true, '상담/저장기록 후보 원장 확인 완료', JSON.stringify(scan.recordSources));
    check('ScanCompleted', true, 'recordId 자동 연결 후보 스캔 완료', JSON.stringify(scan.summary));
    check('NoWriteModeConfirmed', true, 'Dry Run은 읽기 전용, 시트 쓰기 없음');
    result.message = result.ok ? 'MailCenter Calendar Record Link Pack V01 Dry Run 통과' : 'MailCenter Calendar Record Link Pack V01 Dry Run 점검 필요';
  } catch (err) {
    result.ok = false;
    result.message = mcCalendarRecordLinkPackV01Err_(err);
  }
  Logger.log(JSON.stringify(result, null, 2));
  return result;
}

function runMcCalendarRecordLinkPackV01ApplyLinks() {
  var result = {
    ok: false,
    build: MC_CALENDAR_RECORD_LINK_PACK_V01_BUILD,
    action: 'runMcCalendarRecordLinkPackV01ApplyLinks',
    generatedAt: mcCalendarRecordLinkPackV01Now_(),
    appliedCount: 0,
    skippedCount: 0,
    applied: [],
    message: ''
  };
  var actor = mcCalendarRecordLinkPackV01Actor_();
  try {
    var master = mcCalendarRecordLinkPackV01OpenMaster_();
    var scan = mcCalendarRecordLinkPackV01ScanCandidates_(master);
    var now = mcCalendarRecordLinkPackV01Now_();
    var eventsSheet = scan.sheets.events;
    var linksSheet = scan.sheets.links;
    var logsSheet = mcCalendarRecordLinkPackV01GetSheetOrCreate_(master, 'MAILCENTER_CalendarLogs', mcCalendarRecordLinkPackV01LogHeaders_());
    var eventsHm = scan.headers.eventsHm;
    var linksHm = scan.headers.linksHm;
    var maxApply = 50;
    scan.candidates.forEach(function(c) {
      if (result.appliedCount >= maxApply) {
        result.skippedCount++;
        return;
      }
      if (!c.recordId || c.confidence < 70) {
        result.skippedCount++;
        return;
      }
      if (eventsSheet && c.eventRowIndex && eventsHm.hasOwnProperty('requestId')) {
        eventsSheet.getRange(c.eventRowIndex, eventsHm.requestId + 1).setValue(c.recordId);
        if (eventsHm.hasOwnProperty('updatedAt')) eventsSheet.getRange(c.eventRowIndex, eventsHm.updatedAt + 1).setValue(now);
        if (eventsHm.hasOwnProperty('updatedBy')) eventsSheet.getRange(c.eventRowIndex, eventsHm.updatedBy + 1).setValue(actor);
      }
      if (linksSheet && c.linkRowIndex && linksHm.hasOwnProperty('recordId')) {
        linksSheet.getRange(c.linkRowIndex, linksHm.recordId + 1).setValue(c.recordId);
        if (linksHm.hasOwnProperty('updatedAt')) linksSheet.getRange(c.linkRowIndex, linksHm.updatedAt + 1).setValue(now);
        if (linksHm.hasOwnProperty('updatedBy')) linksSheet.getRange(c.linkRowIndex, linksHm.updatedBy + 1).setValue(actor);
        if (linksHm.hasOwnProperty('statusReason')) linksSheet.getRange(c.linkRowIndex, linksHm.statusReason + 1).setValue('recordId 자동 연결 완료');
      }
      mcCalendarRecordLinkPackV01AppendByHeaders_(master, 'MAILCENTER_CalendarLogs', mcCalendarRecordLinkPackV01LogHeaders_(), {
        calendarLogId: 'MCALLOG-' + Utilities.formatDate(new Date(), Session.getScriptTimeZone() || 'Asia/Seoul', 'yyyyMMddHHmmss') + '-' + Utilities.getUuid().substring(0, 8).toUpperCase(),
        calendarEventId: c.calendarEventId,
        provider: 'RECORD_LINK',
        actionType: 'AUTO_LINK_RECORD_ID',
        resultStatus: 'SUCCESS',
        providerEventId: '',
        errorCode: '',
        errorMessage: '',
        requestPayloadSummary: JSON.stringify({ calendarEventId: c.calendarEventId, threadId: c.threadId, messageId: c.messageId, subject: c.subject, matchedBy: c.matchedBy }).slice(0, 900),
        responseSummary: 'recordId 자동 연결 완료: ' + c.recordId,
        createdAt: now,
        createdBy: actor
      });
      result.appliedCount++;
      result.applied.push(c);
    });
    result.ok = true;
    result.message = 'MailCenter Calendar Record Link Pack V01 자동 연결 완료';
  } catch (err) {
    result.ok = false;
    result.message = mcCalendarRecordLinkPackV01Err_(err);
  }
  Logger.log(JSON.stringify(result, null, 2));
  return result;
}

function runMcCalendarRecordLinkPackV01Gate() {
  var result = {
    ok: true,
    build: MC_CALENDAR_RECORD_LINK_PACK_V01_BUILD,
    action: 'runMcCalendarRecordLinkPackV01Gate',
    generatedAt: mcCalendarRecordLinkPackV01Now_(),
    noWriteMode: true,
    checks: [],
    warnings: []
  };
  function check(key, ok, message, detail) {
    result.checks.push({ key: key, ok: !!ok, message: message, detail: detail || '' });
    if (!ok) result.ok = false;
  }
  try {
    var master = mcCalendarRecordLinkPackV01OpenMaster_();
    var scan = mcCalendarRecordLinkPackV01ScanCandidates_(master);
    check('MasterOpenReady', !!master, 'SystemConfig -> FEELHAUS_DB_MASTER 연결 확인', master.getId());
    check('CalendarEventsSheetReady', !!scan.sheets.events, 'MAILCENTER_CalendarEvents 시트 확인');
    check('CalendarMailLinksSheetReady', !!scan.sheets.links, 'MAILCENTER_CalendarMailLinks 시트 확인');
    check('EventsHeadersReady', scan.missing.events.length === 0, '이벤트 핵심 헤더 확인', 'missing=' + JSON.stringify(scan.missing.events));
    check('LinksHeadersReady', scan.missing.links.length === 0, '메일링크 핵심 헤더 확인', 'missing=' + JSON.stringify(scan.missing.links));
    check('RecordSourceScanReady', true, '상담/저장기록 원장 스캔 확인', JSON.stringify(scan.recordSources));
    check('CandidateScanReady', true, 'recordId 후보 스캔 확인', JSON.stringify(scan.summary));
    check('NoWriteModeConfirmed', true, '본 게이트는 읽기 점검 전용, 시트 쓰기 없음');
    check('NoRouterMenuHtmlTouchByGate', true, '게이트는 라우터/메뉴/HTML/Shell/View 변경 없음');
    result.message = result.ok ? 'MailCenter Calendar Record Link Pack V01 Gate 통과' : 'MailCenter Calendar Record Link Pack V01 Gate 점검 필요';
    result.nextStage = result.ok ? 'MAILCENTER_CALENDAR_RECORD_LINK_LOCK_READY' : 'RECORD_LINK_FIX_REQUIRED';
  } catch (err) {
    result.ok = false;
    result.message = mcCalendarRecordLinkPackV01Err_(err);
    result.nextStage = 'RECORD_LINK_FIX_REQUIRED';
  }
  Logger.log(JSON.stringify(result, null, 2));
  return result;
}

function runMcCalendarRecordLinkPackV01CreateBackupAndLock() {
  var result = {
    ok: false,
    build: MC_CALENDAR_RECORD_LINK_PACK_V01_BUILD,
    action: 'runMcCalendarRecordLinkPackV01CreateBackupAndLock',
    generatedAt: mcCalendarRecordLinkPackV01Now_(),
    lockId: '',
    backupSpreadsheetId: '',
    backupName: '',
    copiedSheets: [],
    message: ''
  };
  var actor = mcCalendarRecordLinkPackV01Actor_();
  try {
    var master = mcCalendarRecordLinkPackV01OpenMaster_();
    var now = mcCalendarRecordLinkPackV01Now_();
    var stamp = Utilities.formatDate(new Date(), Session.getScriptTimeZone() || 'Asia/Seoul', 'yyyyMMdd_HHmmss');
    var lockId = 'MCALRECLINKLOCK-' + Utilities.formatDate(new Date(), Session.getScriptTimeZone() || 'Asia/Seoul', 'yyyyMMddHHmmss') + '-' + Utilities.getUuid().substring(0, 8).toUpperCase();
    var backupName = 'MAILCENTER_CALENDAR_RECORD_LINK_BACKUP_' + stamp;
    var backup = SpreadsheetApp.create(backupName);
    var backupId = backup.getId();
    var targetSheets = [
      'MAILCENTER_CalendarEvents',
      'MAILCENTER_CalendarMailLinks',
      'MAILCENTER_CalendarLogs',
      'MAILCENTER_CalendarDetailLocks',
      'MAILCENTER_CalendarDetailSummaries'
    ];
    var copied = [];
    targetSheets.forEach(function(sheetName) {
      var src = master.getSheetByName(sheetName);
      if (src) {
        var copy = src.copyTo(backup);
        copy.setName(sheetName);
        copied.push({ sheetName: sheetName, rows: src.getLastRow(), cols: src.getLastColumn() });
      } else {
        copied.push({ sheetName: sheetName, rows: 0, cols: 0, missing: true });
      }
    });
    var defaultSheet = backup.getSheetByName('Sheet1');
    if (defaultSheet && backup.getSheets().length > 1) backup.deleteSheet(defaultSheet);
    var info = backup.insertSheet('LOCK_INFO');
    var infoRows = [
      ['key', 'value'],
      ['lockId', lockId],
      ['build', MC_CALENDAR_RECORD_LINK_PACK_V01_BUILD],
      ['webAppUrl', MC_CALENDAR_RECORD_LINK_PACK_V01_WEBAPP_URL],
      ['sourceMasterId', master.getId()],
      ['backupSpreadsheetId', backupId],
      ['lockedAt', now],
      ['lockedBy', actor],
      ['status', 'RECORD_LINK_PACK_LOCKED'],
      ['scope', 'MailCenter calendar recordId / saved record linking server pack'],
      ['note', 'Router/menu/html/shell/view not modified by this pack']
    ];
    info.getRange(1, 1, infoRows.length, 2).setValues(infoRows);
    info.setFrozenRows(1);

    mcCalendarRecordLinkPackV01AppendByHeaders_(master, 'MAILCENTER_CalendarRecordLinkLocks', mcCalendarRecordLinkPackV01LockHeaders_(), {
      lockId: lockId,
      build: MC_CALENDAR_RECORD_LINK_PACK_V01_BUILD,
      backupName: backupName,
      backupSpreadsheetId: backupId,
      webAppUrl: MC_CALENDAR_RECORD_LINK_PACK_V01_WEBAPP_URL,
      status: 'RECORD_LINK_PACK_LOCKED',
      statusReason: 'recordId / 상담기록 자동 연결 서버팩 잠금 완료',
      copiedSheetsJson: JSON.stringify(copied),
      createdAt: now,
      createdBy: actor,
      updatedAt: now,
      updatedBy: actor
    });

    result.ok = true;
    result.lockId = lockId;
    result.backupSpreadsheetId = backupId;
    result.backupName = backupName;
    result.copiedSheets = copied;
    result.message = 'MailCenter Calendar Record Link Pack V01 Lock 완료';
  } catch (err) {
    result.ok = false;
    result.message = mcCalendarRecordLinkPackV01Err_(err);
  }
  Logger.log(JSON.stringify(result, null, 2));
  return result;
}

function runMcCalendarRecordLinkPackV01Summary() {
  var result = {
    ok: false,
    build: MC_CALENDAR_RECORD_LINK_PACK_V01_BUILD,
    action: 'runMcCalendarRecordLinkPackV01Summary',
    generatedAt: mcCalendarRecordLinkPackV01Now_(),
    summaryId: '',
    message: ''
  };
  var actor = mcCalendarRecordLinkPackV01Actor_();
  try {
    var master = mcCalendarRecordLinkPackV01OpenMaster_();
    var scan = mcCalendarRecordLinkPackV01ScanCandidates_(master);
    var now = mcCalendarRecordLinkPackV01Now_();
    var summaryId = 'MCALRECLINKSUM-' + Utilities.formatDate(new Date(), Session.getScriptTimeZone() || 'Asia/Seoul', 'yyyyMMddHHmmss') + '-' + Utilities.getUuid().substring(0, 8).toUpperCase();
    mcCalendarRecordLinkPackV01AppendByHeaders_(master, 'MAILCENTER_CalendarRecordLinkSummaries', mcCalendarRecordLinkPackV01SummaryHeaders_(), {
      summaryId: summaryId,
      build: MC_CALENDAR_RECORD_LINK_PACK_V01_BUILD,
      webAppUrl: MC_CALENDAR_RECORD_LINK_PACK_V01_WEBAPP_URL,
      status: 'SUMMARY_RECORDED',
      statusReason: 'recordId / 상담기록 자동 연결 서버팩 요약 기록 완료',
      summaryJson: JSON.stringify(scan.summary),
      recordSourcesJson: JSON.stringify(scan.recordSources),
      createdAt: now,
      createdBy: actor,
      updatedAt: now,
      updatedBy: actor
    });
    result.ok = true;
    result.summaryId = summaryId;
    result.message = 'MailCenter Calendar Record Link Pack V01 Summary 기록 완료';
  } catch (err) {
    result.ok = false;
    result.message = mcCalendarRecordLinkPackV01Err_(err);
  }
  Logger.log(JSON.stringify(result, null, 2));
  return result;
}

function mcCalendarRecordLinkPackV01ScanCandidates_(master) {
  master = master || mcCalendarRecordLinkPackV01OpenMaster_();
  var events = master.getSheetByName('MAILCENTER_CalendarEvents');
  var links = master.getSheetByName('MAILCENTER_CalendarMailLinks');
  var logs = master.getSheetByName('MAILCENTER_CalendarLogs');
  var missing = { events: [], links: [] };
  var candidates = [];
  var summary = {
    eventRows: 0,
    linkRows: 0,
    missingRecordIdRows: 0,
    linkedRows: 0,
    candidateRows: 0,
    highConfidenceCandidates: 0,
    recordSourceRows: 0
  };
  var recordSources = mcCalendarRecordLinkPackV01LoadRecordSources_(master);
  summary.recordSourceRows = recordSources.records.length;
  var eventValues = events ? events.getDataRange().getValues() : [];
  var linkValues = links ? links.getDataRange().getValues() : [];
  var eventHeaders = eventValues.length ? eventValues[0] : [];
  var linkHeaders = linkValues.length ? linkValues[0] : [];
  var eHm = mcCalendarRecordLinkPackV01HeaderMap_(eventHeaders);
  var lHm = mcCalendarRecordLinkPackV01HeaderMap_(linkHeaders);
  ['calendarEventId','requestId','eventTitle','eventDescription','eventStatus','updatedAt','updatedBy'].forEach(function(h) { if (!eHm.hasOwnProperty(h)) missing.events.push(h); });
  ['calendarEventId','threadId','messageId','recordId','subject','fromEmail','toEmail','mailDate','updatedAt','updatedBy'].forEach(function(h) { if (!lHm.hasOwnProperty(h)) missing.links.push(h); });
  summary.eventRows = Math.max(0, eventValues.length - 1);
  summary.linkRows = Math.max(0, linkValues.length - 1);
  var eventById = {};
  for (var i = 1; i < eventValues.length; i++) {
    var evId = mcCalendarRecordLinkPackV01Cell_(eventValues[i], eHm.calendarEventId);
    if (evId) eventById[evId] = { row: eventValues[i], rowIndex: i + 1 };
  }
  for (var r = 1; r < linkValues.length; r++) {
    var row = linkValues[r];
    var calendarEventId = mcCalendarRecordLinkPackV01Cell_(row, lHm.calendarEventId);
    var recordId = mcCalendarRecordLinkPackV01Cell_(row, lHm.recordId);
    var threadId = mcCalendarRecordLinkPackV01Cell_(row, lHm.threadId);
    var messageId = mcCalendarRecordLinkPackV01Cell_(row, lHm.messageId);
    var subject = mcCalendarRecordLinkPackV01Cell_(row, lHm.subject);
    if (recordId) {
      summary.linkedRows++;
      continue;
    }
    summary.missingRecordIdRows++;
    var match = mcCalendarRecordLinkPackV01FindRecordMatch_(recordSources.records, { threadId: threadId, messageId: messageId, subject: subject, calendarEventId: calendarEventId });
    if (match && match.recordId) {
      var ev = eventById[calendarEventId] || { row: [], rowIndex: 0 };
      var candidate = {
        calendarEventId: calendarEventId,
        recordId: match.recordId,
        threadId: threadId,
        messageId: messageId,
        subject: subject,
        matchedBy: match.matchedBy,
        confidence: match.confidence,
        linkRowIndex: r + 1,
        eventRowIndex: ev.rowIndex
      };
      candidates.push(candidate);
      summary.candidateRows++;
      if (match.confidence >= 70) summary.highConfidenceCandidates++;
    }
  }
  return {
    sheets: { events: events, links: links, logs: logs },
    headers: { eventsHm: eHm, linksHm: lHm },
    missing: missing,
    summary: summary,
    candidates: candidates,
    recordSources: { sheetsChecked: recordSources.sheetsChecked, records: recordSources.records.slice(0, 20), total: recordSources.records.length }
  };
}

function mcCalendarRecordLinkPackV01LoadRecordSources_(master) {
  var possibleSheets = [
    'MAILCENTER_SavedRecords',
    'MAILCENTER_SaveRecords',
    'MAILCENTER_ConsultRecords',
    'MAILCENTER_SalesRecords',
    'MAILCENTER_RecordLogs',
    'MailCenterSavedRecords',
    'MailCenterRecords'
  ];
  var records = [];
  var sheetsChecked = [];
  possibleSheets.forEach(function(name) {
    var sh = master.getSheetByName(name);
    if (!sh) return;
    var values = sh.getDataRange().getValues();
    if (!values || values.length < 2) {
      sheetsChecked.push({ sheetName: name, rows: Math.max(0, values.length - 1), usable: false });
      return;
    }
    var hm = mcCalendarRecordLinkPackV01HeaderMap_(values[0]);
    var recordCol = mcCalendarRecordLinkPackV01PickIndex_(hm, ['recordId','consultRecordId','salesRecordId','mailRecordId','requestId','logId']);
    var threadCol = mcCalendarRecordLinkPackV01PickIndex_(hm, ['threadId','gmailThreadId','mailThreadId']);
    var msgCol = mcCalendarRecordLinkPackV01PickIndex_(hm, ['messageId','gmailMessageId','mailMessageId']);
    var subjectCol = mcCalendarRecordLinkPackV01PickIndex_(hm, ['subject','mailSubject','title']);
    var createdCol = mcCalendarRecordLinkPackV01PickIndex_(hm, ['createdAt','savedAt','recordedAt']);
    var usable = recordCol >= 0 && (threadCol >= 0 || msgCol >= 0 || subjectCol >= 0);
    sheetsChecked.push({ sheetName: name, rows: values.length - 1, usable: usable });
    if (!usable) return;
    for (var i = 1; i < values.length; i++) {
      var row = values[i];
      var recordId = mcCalendarRecordLinkPackV01Cell_(row, recordCol);
      if (!recordId) continue;
      records.push({
        sheetName: name,
        rowIndex: i + 1,
        recordId: recordId,
        threadId: mcCalendarRecordLinkPackV01Cell_(row, threadCol),
        messageId: mcCalendarRecordLinkPackV01Cell_(row, msgCol),
        subject: mcCalendarRecordLinkPackV01Cell_(row, subjectCol),
        createdAt: mcCalendarRecordLinkPackV01Cell_(row, createdCol)
      });
    }
  });
  return { sheetsChecked: sheetsChecked, records: records };
}

function mcCalendarRecordLinkPackV01FindRecordMatch_(records, mail) {
  var best = null;
  records.forEach(function(rec) {
    var score = 0;
    var by = [];
    if (mail.threadId && rec.threadId && mail.threadId === rec.threadId) { score += 80; by.push('threadId'); }
    if (mail.messageId && rec.messageId && mail.messageId === rec.messageId) { score += 80; by.push('messageId'); }
    if (mail.subject && rec.subject && mcCalendarRecordLinkPackV01Norm_(mail.subject) === mcCalendarRecordLinkPackV01Norm_(rec.subject)) { score += 40; by.push('subject'); }
    if (score > 100) score = 100;
    if (score > 0 && (!best || score > best.confidence)) {
      best = { recordId: rec.recordId, confidence: score, matchedBy: by.join('+'), sourceSheet: rec.sheetName, sourceRowIndex: rec.rowIndex };
    }
  });
  return best;
}

function mcCalendarRecordLinkPackV01Norm_(s) {
  return String(s || '').trim().replace(/\s+/g, ' ').toLowerCase();
}

function mcCalendarRecordLinkPackV01LockHeaders_() {
  return ['lockId','build','backupName','backupSpreadsheetId','webAppUrl','status','statusReason','copiedSheetsJson','createdAt','createdBy','updatedAt','updatedBy'];
}

function mcCalendarRecordLinkPackV01SummaryHeaders_() {
  return ['summaryId','build','webAppUrl','status','statusReason','summaryJson','recordSourcesJson','createdAt','createdBy','updatedAt','updatedBy'];
}

function mcCalendarRecordLinkPackV01LogHeaders_() {
  return ['calendarLogId','calendarEventId','provider','actionType','resultStatus','providerEventId','errorCode','errorMessage','requestPayloadSummary','responseSummary','createdAt','createdBy'];
}

function mcCalendarRecordLinkPackV01AppendByHeaders_(ss, sheetName, baseHeaders, record) {
  var sheet = mcCalendarRecordLinkPackV01GetSheetOrCreate_(ss, sheetName, baseHeaders);
  mcCalendarRecordLinkPackV01EnsureHeaders_(sheet, Object.keys(record || {}));
  var headers = sheet.getRange(1, 1, 1, sheet.getLastColumn()).getValues()[0];
  var hm = mcCalendarRecordLinkPackV01HeaderMap_(headers);
  var row = [];
  for (var i = 0; i < headers.length; i++) row.push('');
  Object.keys(record || {}).forEach(function(key) {
    if (hm.hasOwnProperty(key)) row[hm[key]] = record[key];
  });
  sheet.appendRow(row);
}

function mcCalendarRecordLinkPackV01GetSheetOrCreate_(ss, name, headers) {
  var sheet = ss.getSheetByName(name);
  if (!sheet) {
    sheet = ss.insertSheet(name);
    sheet.getRange(1, 1, 1, headers.length).setValues([headers]);
    sheet.setFrozenRows(1);
    return sheet;
  }
  if (sheet.getLastRow() < 1 || sheet.getLastColumn() < 1) {
    sheet.getRange(1, 1, 1, headers.length).setValues([headers]);
    sheet.setFrozenRows(1);
    return sheet;
  }
  mcCalendarRecordLinkPackV01EnsureHeaders_(sheet, headers);
  return sheet;
}

function mcCalendarRecordLinkPackV01EnsureHeaders_(sheet, requiredHeaders) {
  var lastCol = Math.max(sheet.getLastColumn(), 1);
  var headers = sheet.getRange(1, 1, 1, lastCol).getValues()[0];
  var hm = mcCalendarRecordLinkPackV01HeaderMap_(headers);
  var add = [];
  (requiredHeaders || []).forEach(function(h) { if (h && !hm.hasOwnProperty(h)) add.push(h); });
  if (add.length) sheet.getRange(1, headers.length + 1, 1, add.length).setValues([add]);
}

function mcCalendarRecordLinkPackV01OpenMaster_() {
  var setup = SpreadsheetApp.openById(MC_CALENDAR_RECORD_LINK_PACK_V01_SETUP_DB_ID);
  var sheet = setup.getSheetByName(MC_CALENDAR_RECORD_LINK_PACK_V01_CONFIG_SHEET);
  if (!sheet) throw new Error('SystemConfig 시트를 찾지 못했습니다.');
  var values = sheet.getDataRange().getValues();
  if (!values || values.length < 2) throw new Error('SystemConfig 데이터가 비어 있습니다.');
  var hm = mcCalendarRecordLinkPackV01HeaderMap_(values[0]);
  var keyCol = mcCalendarRecordLinkPackV01PickIndex_(hm, ['CONFIG_KEY','configKey','key','name']);
  var valCol = mcCalendarRecordLinkPackV01PickIndex_(hm, ['VALUE','configValue','value','spreadsheetId']);
  if (keyCol < 0 || valCol < 0) throw new Error('SystemConfig CONFIG_KEY/VALUE 헤더를 찾지 못했습니다.');
  var masterId = '';
  for (var r = 1; r < values.length; r++) {
    var key = String(values[r][keyCol] || '').trim();
    if (key === 'FEELHAUS_DB_MASTER' || key === 'FEELHAUS_DB_MASTER_ID' || key === 'MASTER_DB_ID') {
      masterId = String(values[r][valCol] || '').trim();
      break;
    }
  }
  if (!masterId) throw new Error('SystemConfig에서 FEELHAUS_DB_MASTER ID를 찾지 못했습니다.');
  return SpreadsheetApp.openById(masterId);
}

function mcCalendarRecordLinkPackV01HeaderMap_(headers) {
  var out = {};
  (headers || []).forEach(function(h, i) {
    var key = String(h || '').trim();
    if (key) out[key] = i;
  });
  return out;
}

function mcCalendarRecordLinkPackV01PickIndex_(hm, keys) {
  for (var i = 0; i < keys.length; i++) if (hm.hasOwnProperty(keys[i])) return hm[keys[i]];
  return -1;
}

function mcCalendarRecordLinkPackV01Cell_(row, index) {
  if (index === undefined || index === null || index < 0) return '';
  return String(row[index] || '').trim();
}

function mcCalendarRecordLinkPackV01Actor_() {
  return String(Session.getActiveUser().getEmail() || 'MAILCENTER_ADMIN').trim() || 'MAILCENTER_ADMIN';
}

function mcCalendarRecordLinkPackV01Now_() {
  return Utilities.formatDate(new Date(), Session.getScriptTimeZone() || 'Asia/Seoul', 'yyyy-MM-dd HH:mm:ss');
}

function mcCalendarRecordLinkPackV01Err_(err) {
  return err && err.message ? err.message : String(err);
}
