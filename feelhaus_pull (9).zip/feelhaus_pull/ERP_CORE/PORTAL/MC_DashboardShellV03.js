/**
 * FEELHAUS MailCenter Dashboard Shell V03
 * Build: MAILCENTER_DASHBOARD_SHELL_V03_20260519
 *
 * Naming rule:
 * - JS file:   MC_DashboardShellV03.js
 * - HTML file: MC_DashboardViewV03.html
 * - 앞 이름 충돌 방지. JS/HTML base name intentionally different.
 */

var MC_DASHBOARD_SHELL_V03_BUILD = 'MAILCENTER_DASHBOARD_SHELL_V03_20260519';
var MC_DASHBOARD_SHELL_V03_DESC = '독립형 MailCenter 기본 UI 골격 / JS-HTML 파일명 완전 분리 / PORTAL 본체 비침범';
var MC_DASHBOARD_SHELL_V03_SETUP_DB_ID = '17VMSpgSZCvIrUlgcw8yCNcnl8WQWo2IcRf5tDCcuJGM';
var MC_DASHBOARD_SHELL_V03_CONFIG_SHEET = 'SystemConfig';

function runMcDashboardShellV03() {
  var result = {
    ok: false,
    build: MC_DASHBOARD_SHELL_V03_BUILD,
    action: 'runMcDashboardShellV03',
    generatedAt: mcDashboardShellV03Now_(),
    message: '',
    changedFiles: ['MC_DashboardShellV03.js', 'MC_DashboardViewV03.html'],
    protectedRule: 'PORTAL 본체 비침범 / JS-HTML 앞이름 충돌 방지',
    checks: []
  };

  try {
    var info = mcDashboardShellV03OpenMaster_();
    var data = mcDashboardShellV03GetInitialData();
    result.masterDbId = info.masterDbId;
    result.spreadsheetName = info.ss.getName();
    result.summary = data.summary;
    result.checks.push({ key: 'MasterConnected', ok: true, message: 'FEELHAUS_DB_MASTER 연결 확인' });
    result.checks.push({ key: 'JsHtmlNameSeparated', ok: true, message: 'MC_DashboardShellV03 / MC_DashboardViewV03 이름 분리' });
    result.checks.push({ key: 'NoPortalMainTouch', ok: true, message: 'Portal_Main.js 수정 없음' });
    result.ok = true;
    result.message = 'MailCenter Dashboard Shell V03 준비 완료';
  } catch (err) {
    result.ok = false;
    result.message = String(err && err.message ? err.message : err);
  }

  mcDashboardShellV03Log_(result);
  return result;
}

function mcDashboardShellV03HandleGet(e) {
  var t = HtmlService.createTemplateFromFile('MC_DashboardViewV03');
  t.build = MC_DASHBOARD_SHELL_V03_BUILD;
  t.buildDesc = MC_DASHBOARD_SHELL_V03_DESC;
  return t.evaluate()
    .setTitle('FEELHAUS MailCenter')
    .setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL);
}

function mcDashboardShellV03GetInitialData() {
  var result = {
    ok: false,
    build: MC_DASHBOARD_SHELL_V03_BUILD,
    action: 'mcDashboardShellV03GetInitialData',
    generatedAt: mcDashboardShellV03Now_(),
    summary: {
      totalAccounts: 0,
      activeAccounts: 0,
      connectedAccounts: 0,
      hqAccounts: 0,
      vendorAccounts: 0,
      sendLogsToday: 0
    },
    accounts: [],
    recentSendLogs: [],
    quickActions: [
      { code: 'ACCOUNT_REGISTER', title: '계정 등록/추가', desc: '새로운 이메일 계정을 등록합니다.', enabled: false },
      { code: 'MAIL_SETTINGS', title: '메일 설정 관리', desc: '메일 서명, 폴더, 기본설정을 관리합니다.', enabled: false },
      { code: 'TEMPLATE_MANAGE', title: '발송 템플릿 관리', desc: '자주 사용하는 메일 템플릿을 관리합니다.', enabled: false },
      { code: 'SEND_STATS', title: '발송 통계', desc: '메일 발송 통계를 확인합니다.', enabled: false }
    ],
    message: ''
  };

  try {
    var info = mcDashboardShellV03OpenMaster_();
    var ss = info.ss;

    var accounts = mcDashboardShellV03ReadAccounts_(ss);
    var oauthMap = mcDashboardShellV03ReadOAuthMap_(ss);
    accounts.forEach(function(a) {
      var key = a.mailAccountId || a.emailAddress;
      var o = oauthMap[key] || oauthMap[a.emailAddress] || {};
      a.oauthStatus = o.oauthStatus || a.oauthStatus || '';
      a.connectorMailAccountId = o.connectorMailAccountId || '';
      a.lastConnectedAt = o.lastConnectedAt || '';
      a.lastCheckedAt = o.lastCheckedAt || '';
      a.canSend = String(a.mailAccountStatus).toUpperCase() === 'ACTIVE' &&
                  String(a.oauthStatus).toUpperCase() === 'CONNECTED';
    });

    result.accounts = accounts;
    result.summary.totalAccounts = accounts.length;
    result.summary.activeAccounts = accounts.filter(function(a) { return String(a.mailAccountStatus).toUpperCase() === 'ACTIVE'; }).length;
    result.summary.connectedAccounts = accounts.filter(function(a) { return String(a.oauthStatus).toUpperCase() === 'CONNECTED'; }).length;
    result.summary.hqAccounts = accounts.filter(function(a) { return String(a.ownerType).indexOf('HQ') === 0; }).length;
    result.summary.vendorAccounts = accounts.filter(function(a) { return String(a.ownerType).toUpperCase() === 'VENDOR'; }).length;
    result.recentSendLogs = mcDashboardShellV03ReadRecentSendLogs_(ss);

    result.ok = true;
    result.message = 'MailCenter Dashboard V03 초기 데이터 조회 완료';
  } catch (err) {
    result.ok = false;
    result.message = String(err && err.message ? err.message : err);
  }

  return result;
}

function mcDashboardShellV03ReadAccounts_(ss) {
  var sh = ss.getSheetByName('MailCenter_Accounts');
  if (!sh) return [];
  var values = sh.getDataRange().getValues();
  if (!values || values.length < 2) return [];
  var hm = mcDashboardShellV03HeaderMap_(values[0]);
  var rows = [];

  for (var r = 1; r < values.length; r++) {
    var row = values[r];
    var email = mcDashboardShellV03Cell_(row, hm, 'emailAddress');
    if (!email) continue;

    rows.push({
      mailAccountId: mcDashboardShellV03Cell_(row, hm, 'mailAccountId'),
      vendorId: mcDashboardShellV03Cell_(row, hm, 'vendorId'),
      ownerType: mcDashboardShellV03Cell_(row, hm, 'ownerType'),
      ownerName: mcDashboardShellV03Cell_(row, hm, 'ownerName'),
      emailAddress: email,
      provider: mcDashboardShellV03Cell_(row, hm, 'provider'),
      mailAccountStatus: mcDashboardShellV03Cell_(row, hm, 'mailAccountStatus'),
      approvalStatus: mcDashboardShellV03Cell_(row, hm, 'approvalStatus'),
      accountPurpose: mcDashboardShellV03Cell_(row, hm, 'accountPurpose'),
      isPrimary: mcDashboardShellV03Cell_(row, hm, 'isPrimary'),
      displayName: mcDashboardShellV03Cell_(row, hm, 'displayName'),
      roleMemo: mcDashboardShellV03Cell_(row, hm, 'roleMemo'),
      updatedAt: mcDashboardShellV03Cell_(row, hm, 'updatedAt')
    });
  }

  rows.sort(function(a, b) {
    var rank = function(x) {
      if (x.accountPurpose === 'HQ_OFFICIAL') return 1;
      if (x.accountPurpose === 'HQ_STAFF') return 2;
      if (x.accountPurpose === 'VENDOR_OFFICIAL') return 3;
      return 9;
    };
    return rank(a) - rank(b);
  });

  return rows;
}

function mcDashboardShellV03ReadOAuthMap_(ss) {
  var sh = ss.getSheetByName('MailCenter_OAuthConnections');
  var map = {};
  if (!sh) return map;
  var values = sh.getDataRange().getValues();
  if (!values || values.length < 2) return map;
  var hm = mcDashboardShellV03HeaderMap_(values[0]);

  for (var r = 1; r < values.length; r++) {
    var row = values[r];
    var mailAccountId = mcDashboardShellV03Cell_(row, hm, 'mailAccountId');
    var emailAddress = mcDashboardShellV03Cell_(row, hm, 'emailAddress');
    var item = {
      mailAccountId: mailAccountId,
      connectorMailAccountId: mcDashboardShellV03Cell_(row, hm, 'connectorMailAccountId'),
      emailAddress: emailAddress,
      oauthStatus: mcDashboardShellV03Cell_(row, hm, 'oauthStatus'),
      lastConnectedAt: mcDashboardShellV03Cell_(row, hm, 'lastConnectedAt'),
      lastCheckedAt: mcDashboardShellV03Cell_(row, hm, 'lastCheckedAt')
    };
    if (mailAccountId) map[mailAccountId] = item;
    if (emailAddress) map[emailAddress] = item;
  }
  return map;
}

function mcDashboardShellV03ReadRecentSendLogs_(ss) {
  var sh = ss.getSheetByName('MailCenter_SendLogs') || ss.getSheetByName('MailCenter_SendLogs_Fast');
  if (!sh) return [];
  var values = sh.getDataRange().getValues();
  if (!values || values.length < 2) return [];
  var hm = mcDashboardShellV03HeaderMap_(values[0]);
  var logs = [];

  for (var r = Math.max(1, values.length - 10); r < values.length; r++) {
    var row = values[r];
    logs.push({
      createdAt: mcDashboardShellV03Cell_(row, hm, 'createdAt'),
      fromEmail: mcDashboardShellV03Cell_(row, hm, 'fromEmail'),
      toEmail: mcDashboardShellV03Cell_(row, hm, 'toEmail'),
      subject: mcDashboardShellV03Cell_(row, hm, 'subject'),
      sendStatus: mcDashboardShellV03Cell_(row, hm, 'sendStatus'),
      errorMessage: mcDashboardShellV03Cell_(row, hm, 'errorMessage')
    });
  }

  return logs.reverse();
}

function mcDashboardShellV03OpenMaster_() {
  if (typeof portal19GetConfigBundle_ === 'function' && typeof portal19OpenMaster_ === 'function') {
    var bundle = portal19GetConfigBundle_();
    var ssByPortal = portal19OpenMaster_(bundle);
    if (ssByPortal) return { ss: ssByPortal, masterDbId: bundle.masterDbId || '' };
  }

  var setup = SpreadsheetApp.openById(MC_DASHBOARD_SHELL_V03_SETUP_DB_ID);
  var configSheet = setup.getSheetByName(MC_DASHBOARD_SHELL_V03_CONFIG_SHEET);
  if (!configSheet) throw new Error('SystemConfig 시트를 찾지 못했습니다.');

  var values = configSheet.getDataRange().getValues();
  if (!values || values.length < 2) throw new Error('SystemConfig 데이터가 비어 있습니다.');

  var hm = mcDashboardShellV03HeaderMap_(values[0]);
  var keyCol = mcDashboardShellV03FindHeader_(hm, ['CONFIG_KEY','configKey','KEY','key']);
  var valCol = mcDashboardShellV03FindHeader_(hm, ['VALUE','CONFIG_VALUE','configValue','value']);
  if (keyCol < 0 || valCol < 0) throw new Error('SystemConfig CONFIG_KEY/VALUE 헤더를 찾지 못했습니다.');

  var masterId = '';
  for (var r = 1; r < values.length; r++) {
    var key = String(values[r][keyCol] || '').trim();
    if (key === 'FEELHAUS_DB_MASTER' || key === 'FEELHAUS_DB_MASTER_ID' || key === 'MASTER_DB_ID') {
      masterId = String(values[r][valCol] || '').trim();
      break;
    }
  }
  if (!masterId) throw new Error('SystemConfig에서 FEELHAUS_DB_MASTER ID를 찾지 못했습니다.');

  return { ss: SpreadsheetApp.openById(masterId), masterDbId: masterId };
}

function mcDashboardShellV03HeaderMap_(header) {
  var hm = {};
  for (var i = 0; i < header.length; i++) {
    var raw = String(header[i] || '').trim();
    if (!raw) continue;
    hm[raw] = i;
    var norm = mcDashboardShellV03Normalize_(raw);
    if (hm[norm] == null) hm[norm] = i;
  }
  return hm;
}

function mcDashboardShellV03FindHeader_(hm, names) {
  for (var i = 0; i < names.length; i++) {
    if (hm[names[i]] != null) return hm[names[i]];
    var norm = mcDashboardShellV03Normalize_(names[i]);
    if (hm[norm] != null) return hm[norm];
  }
  return -1;
}

function mcDashboardShellV03Cell_(row, hm, key) {
  var idx = hm[key];
  if (idx == null) idx = hm[mcDashboardShellV03Normalize_(key)];
  if (idx == null) return '';
  return row[idx];
}

function mcDashboardShellV03Normalize_(v) {
  return String(v || '').trim().toUpperCase().replace(/[^A-Z0-9]/g, '');
}

function mcDashboardShellV03Now_() {
  return Utilities.formatDate(new Date(), Session.getScriptTimeZone() || 'Asia/Seoul', 'yyyy-MM-dd HH:mm:ss');
}

function mcDashboardShellV03Log_(obj) {
  try { Logger.log('JSON_COMPACT_RESULT: ' + JSON.stringify(obj)); }
  catch (e) { Logger.log(obj); }
}
