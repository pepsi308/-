/**
 * FEELHAUS MailCenter Calendar Mail Link V01
 * Build: MAILCENTER_CALENDAR_CREATE_WITH_RECORDID_V01_20260521
 * Purpose:
 * - MailCenter selected mail -> internal calendar schedule save
 * - Do not call NAVER/GOOGLE external provider in Stage 3
 * - Keep SystemConfig -> FEELHAUS_DB_MASTER and header-map based writes
 */
var MC_CALENDAR_MAIL_LINK_V01_BUILD = 'MAILCENTER_CALENDAR_CREATE_WITH_RECORDID_V01_20260521';
var MC_CALENDAR_MAIL_LINK_V01_SETUP_DB_ID = '17VMSpgSZCvIrUlgcw8yCNcnl8WQWo2IcRf5tDCcuJGM';
var MC_CALENDAR_MAIL_LINK_V01_CONFIG_SHEET = 'SystemConfig';

function runMcCalendarMailLinkV01Smoke() {
  var result = {
    ok: true,
    build: MC_CALENDAR_MAIL_LINK_V01_BUILD,
    action: 'runMcCalendarMailLinkV01Smoke',
    generatedAt: mcCalendarMailLinkV01Now_(),
    noWriteMode: true,
    checks: []
  };
  function check(key, ok, message) {
    result.checks.push({ key: key, ok: !!ok, message: message });
    if (!ok) result.ok = false;
  }
  try {
    check('CreateFunctionReady', typeof mcCalendarMailLinkV01CreateFromMail === 'function', '메일 기준 일정 등록 서버 함수 확인');
    check('ConfigReaderReady', typeof mcCalendarMailLinkV01OpenMaster_ === 'function', 'SystemConfig -> FEELHAUS_DB_MASTER 연결 함수 확인');
    check('HeaderMapReady', typeof mcCalendarMailLinkV01HeaderMap_ === 'function', '헤더맵 기반 저장 함수 확인');
    check('NoExternalProviderByStage3', true, '3단계는 NAVER/GOOGLE Provider 호출 없이 내부 일정/메일링크만 저장');
    result.message = result.ok ? 'MailCenter Calendar Mail Link V01 준비 완료' : 'MailCenter Calendar Mail Link V01 점검 필요';
  } catch (err) {
    result.ok = false;
    result.message = mcCalendarMailLinkV01Err_(err);
  }
  return result;
}

function mcCalendarMailLinkV01CreateFromMail(payload) {
  var result = {
    ok: false,
    build: MC_CALENDAR_MAIL_LINK_V01_BUILD,
    action: 'mcCalendarMailLinkV01CreateFromMail',
    generatedAt: mcCalendarMailLinkV01Now_(),
    calendarId: '',
    calendarEventId: '',
    status: '',
    message: ''
  };
  try {
    payload = payload || {};
    var normalized = mcCalendarMailLinkV01Normalize_(payload);
    mcCalendarMailLinkV01Validate_(normalized);

    var ss = mcCalendarMailLinkV01OpenMaster_();
    var actor = mcCalendarMailLinkV01Actor_(payload);
    var now = mcCalendarMailLinkV01Now_();
    var calendarId = 'MCAL-' + Utilities.formatDate(new Date(), Session.getScriptTimeZone() || 'Asia/Seoul', 'yyyyMMddHHmmss') + '-' + Utilities.getUuid().substring(0, 8).toUpperCase();
    var status = 'MAIL_LINK_SAVED';
    var gmailUrl = normalized.threadId ? ('https://mail.google.com/mail/u/0/#all/' + encodeURIComponent(normalized.threadId)) : '';

    var eventRecord = {
      calendarEventId: calendarId,
      eventId: '',
      customerId: '',
      contractId: '',
      installId: '',
      asId: '',
      requestId: normalized.recordId,
      provider: 'MAIL_LINK',
      providerEventId: '',
      eventType: 'MAIL_LINK',
      eventTitle: normalized.title,
      eventDescription: mcCalendarMailLinkV01Description_(normalized, gmailUrl),
      startAt: normalized.startAtText,
      endAt: normalized.endAtText,
      allDayYn: 'N',
      location: normalized.location,
      attendees: normalized.toEmail,
      ownerEmployeeId: actor,
      assignedEmployeeId: actor,
      eventStatus: status,
      naverRegisterStatus: 'SKIP_STAGE3',
      naverProviderEventId: '',
      naverErrorCode: '',
      naverErrorMessage: '',
      googleBackupStatus: 'SKIP_STAGE3',
      googleProviderEventId: '',
      googleErrorCode: '',
      googleErrorMessage: '',
      retryCount: 0,
      lastRetryAt: '',
      createdAt: now,
      createdBy: actor,
      updatedAt: now,
      updatedBy: actor
    };
    mcCalendarMailLinkV01AppendByHeaders_(ss, 'MAILCENTER_CalendarEvents', mcCalendarMailLinkV01EventHeaders_(), eventRecord);

    var linkRecord = {
      calendarId: calendarId,
      calendarEventId: calendarId,
      threadId: normalized.threadId,
      messageId: normalized.messageId,
      recordId: normalized.recordId,
      fromEmail: normalized.fromEmail,
      toEmail: normalized.toEmail,
      subject: normalized.subject,
      mailDate: normalized.mailDate,
      scheduleDate: normalized.scheduleDate,
      scheduleTime: normalized.scheduleTime,
      memo: normalized.memo,
      status: status,
      statusReason: '선택 메일 기준 일정 등록 완료',
      gmailUrl: gmailUrl,
      createdAt: now,
      createdBy: actor,
      updatedAt: now,
      updatedBy: actor
    };
    mcCalendarMailLinkV01AppendByHeaders_(ss, 'MAILCENTER_CalendarMailLinks', mcCalendarMailLinkV01LinkHeaders_(), linkRecord);

    mcCalendarMailLinkV01AppendByHeaders_(ss, 'MAILCENTER_CalendarLogs', mcCalendarMailLinkV01LogHeaders_(), {
      calendarLogId: 'MCALLOG-' + Utilities.formatDate(new Date(), Session.getScriptTimeZone() || 'Asia/Seoul', 'yyyyMMddHHmmss') + '-' + Utilities.getUuid().substring(0, 8).toUpperCase(),
      calendarEventId: calendarId,
      provider: 'MAIL_LINK',
      actionType: 'CREATE_FROM_MAIL',
      resultStatus: 'SUCCESS',
      providerEventId: '',
      errorCode: '',
      errorMessage: '',
      requestPayloadSummary: JSON.stringify({ threadId: normalized.threadId, messageId: normalized.messageId, recordId: normalized.recordId, subject: normalized.subject }).slice(0, 900),
      responseSummary: 'MAILCENTER_CalendarEvents / MAILCENTER_CalendarMailLinks 저장 완료',
      createdAt: now,
      createdBy: actor
    });

    try {
      if (typeof mcCalendar19AppendAuditLog_ === 'function') {
        mcCalendar19AppendAuditLog_('MAIL_CALENDAR_LINK_CREATE', actor, calendarId, 'SUCCESS', '메일 기준 일정 등록 완료', { threadId: normalized.threadId, messageId: normalized.messageId, recordId: normalized.recordId });
      }
    } catch (auditErr) {}

    result.ok = true;
    result.calendarId = calendarId;
    result.calendarEventId = calendarId;
    result.status = status;
    result.gmailUrl = gmailUrl;
    result.message = '메일 기준 일정 등록 완료';
  } catch (err) {
    result.ok = false;
    result.message = mcCalendarMailLinkV01Err_(err);
    try {
      var ssFail = mcCalendarMailLinkV01OpenMaster_();
      mcCalendarMailLinkV01AppendByHeaders_(ssFail, 'MAILCENTER_CalendarLogs', mcCalendarMailLinkV01LogHeaders_(), {
        calendarLogId: 'MCALLOG-' + Utilities.formatDate(new Date(), Session.getScriptTimeZone() || 'Asia/Seoul', 'yyyyMMddHHmmss') + '-' + Utilities.getUuid().substring(0, 8).toUpperCase(),
        calendarEventId: '',
        provider: 'MAIL_LINK',
        actionType: 'CREATE_FROM_MAIL',
        resultStatus: 'FAIL',
        providerEventId: '',
        errorCode: 'MAIL_LINK_CREATE_FAIL',
        errorMessage: result.message,
        requestPayloadSummary: JSON.stringify(payload || {}).slice(0, 900),
        responseSummary: '',
        createdAt: mcCalendarMailLinkV01Now_(),
        createdBy: mcCalendarMailLinkV01Actor_(payload || {})
      });
    } catch (logErr) {}
  }
  return result;
}

function mcCalendarMailLinkV01Normalize_(payload) {
  var scheduleDate = String(payload.scheduleDate || '').trim();
  var scheduleTime = String(payload.scheduleTime || '').trim();
  var durationMinutes = parseInt(payload.durationMinutes || '30', 10);
  if (!durationMinutes || durationMinutes < 5) durationMinutes = 30;
  if (durationMinutes > 1440) durationMinutes = 1440;

  var startDate = mcCalendarMailLinkV01ParseLocalDateTime_(scheduleDate, scheduleTime);
  var endDate = startDate && !isNaN(startDate.getTime()) ? new Date(startDate.getTime() + durationMinutes * 60000) : new Date('invalid');
  var startAtText = '';
  var endAtText = '';
  if (startDate && !isNaN(startDate.getTime())) {
    startAtText = mcCalendarMailLinkV01FormatDateTime_(startDate);
    endAtText = mcCalendarMailLinkV01FormatDateTime_(endDate);
  }
  var subject = String(payload.subject || '').trim();
  var title = String(payload.eventTitle || payload.title || '').trim();
  if (!title) title = '[메일일정] ' + (subject || '제목 없음');

  return {
    threadId: String(payload.threadId || '').trim(),
    messageId: String(payload.messageId || '').trim(),
    recordId: String(payload.recordId || payload.requestId || '').trim(),
    fromEmail: String(payload.fromEmail || payload.from || '').trim(),
    toEmail: String(payload.toEmail || payload.to || '').trim(),
    subject: subject,
    mailDate: String(payload.mailDate || payload.lastDate || '').trim(),
    scheduleDate: scheduleDate,
    scheduleTime: scheduleTime,
    durationMinutes: durationMinutes,
    memo: String(payload.memo || '').trim(),
    location: String(payload.location || '').trim(),
    title: title,
    startAtDate: startDate,
    endAtDate: endDate,
    startAtText: startAtText,
    endAtText: endAtText
  };
}

function mcCalendarMailLinkV01Validate_(n) {
  if (!n.threadId) throw new Error('threadId 값이 필요합니다. 먼저 메일을 선택하세요.');
  if (!n.subject && !n.title) throw new Error('일정 제목으로 사용할 메일 제목이 없습니다.');
  if (!n.scheduleDate) throw new Error('일정 날짜를 입력하세요.');
  if (!n.scheduleTime) throw new Error('일정 시간을 입력하세요.');
  if (!n.startAtDate || isNaN(n.startAtDate.getTime())) throw new Error('일정 일시 형식이 올바르지 않습니다.');
}

function mcCalendarMailLinkV01Description_(n, gmailUrl) {
  return [
    'FEELHAUS MailCenter 메일 연동 일정',
    'From: ' + n.fromEmail,
    'To: ' + n.toEmail,
    'Subject: ' + n.subject,
    'MailDate: ' + n.mailDate,
    'threadId: ' + n.threadId,
    'messageId: ' + n.messageId,
    'recordId: ' + n.recordId,
    'Gmail: ' + gmailUrl,
    'Memo: ' + n.memo
  ].join('\n');
}

function mcCalendarMailLinkV01EventHeaders_() {
  if (typeof mcCalendar186CalendarEventHeaders_ === 'function') return mcCalendar186CalendarEventHeaders_();
  return ['calendarEventId','eventId','customerId','contractId','installId','asId','requestId','provider','providerEventId','eventType','eventTitle','eventDescription','startAt','endAt','allDayYn','location','attendees','ownerEmployeeId','assignedEmployeeId','eventStatus','naverRegisterStatus','naverProviderEventId','naverErrorCode','naverErrorMessage','googleBackupStatus','googleProviderEventId','googleErrorCode','googleErrorMessage','retryCount','lastRetryAt','createdAt','createdBy','updatedAt','updatedBy'];
}

function mcCalendarMailLinkV01LinkHeaders_() {
  return ['calendarId','calendarEventId','threadId','messageId','recordId','fromEmail','toEmail','subject','mailDate','scheduleDate','scheduleTime','memo','status','statusReason','gmailUrl','createdAt','createdBy','updatedAt','updatedBy'];
}

function mcCalendarMailLinkV01LogHeaders_() {
  if (typeof mcCalendar186CalendarLogHeaders_ === 'function') return mcCalendar186CalendarLogHeaders_();
  return ['calendarLogId','calendarEventId','provider','actionType','resultStatus','providerEventId','errorCode','errorMessage','requestPayloadSummary','responseSummary','createdAt','createdBy'];
}

function mcCalendarMailLinkV01AppendByHeaders_(ss, sheetName, baseHeaders, record) {
  var sheet = mcCalendarMailLinkV01GetSheetOrCreate_(ss, sheetName, baseHeaders);
  mcCalendarMailLinkV01EnsureHeaders_(sheet, Object.keys(record || {}));
  var values = sheet.getDataRange().getValues();
  var headers = values && values.length ? values[0] : baseHeaders;
  var hm = mcCalendarMailLinkV01HeaderMap_(headers);
  var row = [];
  for (var i = 0; i < headers.length; i++) row.push('');
  Object.keys(record || {}).forEach(function(key) {
    if (hm.hasOwnProperty(key)) row[hm[key]] = record[key];
  });
  sheet.appendRow(row);
}

function mcCalendarMailLinkV01GetSheetOrCreate_(ss, name, headers) {
  var sheet = ss.getSheetByName(name);
  if (!sheet) {
    sheet = ss.insertSheet(name);
    sheet.getRange(1, 1, 1, headers.length).setValues([headers]);
    return sheet;
  }
  if (sheet.getLastRow() < 1 || sheet.getLastColumn() < 1) {
    sheet.getRange(1, 1, 1, headers.length).setValues([headers]);
    return sheet;
  }
  var first = sheet.getRange(1, 1, 1, Math.max(sheet.getLastColumn(), headers.length)).getValues()[0];
  var empty = first.join('').trim() === '';
  if (empty) sheet.getRange(1, 1, 1, headers.length).setValues([headers]);
  mcCalendarMailLinkV01EnsureHeaders_(sheet, headers);
  return sheet;
}

function mcCalendarMailLinkV01EnsureHeaders_(sheet, requiredHeaders) {
  var lastCol = Math.max(sheet.getLastColumn(), 1);
  var headers = sheet.getRange(1, 1, 1, lastCol).getValues()[0];
  var hm = mcCalendarMailLinkV01HeaderMap_(headers);
  var add = [];
  (requiredHeaders || []).forEach(function(h) { if (h && !hm.hasOwnProperty(h)) add.push(h); });
  if (add.length) sheet.getRange(1, headers.length + 1, 1, add.length).setValues([add]);
}

function mcCalendarMailLinkV01OpenMaster_() {
  var setup = SpreadsheetApp.openById(MC_CALENDAR_MAIL_LINK_V01_SETUP_DB_ID);
  var sheet = setup.getSheetByName(MC_CALENDAR_MAIL_LINK_V01_CONFIG_SHEET);
  if (!sheet) throw new Error('SystemConfig 시트를 찾지 못했습니다.');
  var values = sheet.getDataRange().getValues();
  if (!values || values.length < 2) throw new Error('SystemConfig 데이터가 비어 있습니다.');
  var hm = mcCalendarMailLinkV01HeaderMap_(values[0]);
  var keyCol = mcCalendarMailLinkV01PickIndex_(hm, ['CONFIG_KEY','configKey','key','name']);
  var valCol = mcCalendarMailLinkV01PickIndex_(hm, ['VALUE','configValue','value','spreadsheetId']);
  if (keyCol < 0 || valCol < 0) throw new Error('SystemConfig CONFIG_KEY/VALUE 헤더를 찾지 못했습니다.');
  var masterId = '';
  for (var r = 1; r < values.length; r++) {
    var key = String(values[r][keyCol] || '').trim();
    if (key === 'FEELHAUS_DB_MASTER' || key === 'FEELHAUS_DB_MASTER_ID' || key === 'MASTER_DB_ID') {
      masterId = String(values[r][valCol] || '').trim();
      break;
    }
  }
  if (!masterId) throw new Error('SystemConfig에서 FEELHAUS_DB_MASTER ID를 찾지 못했습니다.');
  return SpreadsheetApp.openById(masterId);
}

function mcCalendarMailLinkV01HeaderMap_(headers) {
  var out = {};
  (headers || []).forEach(function(h, i) {
    var key = String(h || '').trim();
    if (key) out[key] = i;
  });
  return out;
}

function mcCalendarMailLinkV01PickIndex_(hm, keys) {
  for (var i = 0; i < keys.length; i++) if (hm.hasOwnProperty(keys[i])) return hm[keys[i]];
  return -1;
}

function mcCalendarMailLinkV01ParseLocalDateTime_(dateText, timeText) {
  var m = String(dateText || '').match(/^(\d{4})-(\d{2})-(\d{2})$/);
  var t = String(timeText || '').match(/^(\d{2}):(\d{2})$/);
  if (!m || !t) return new Date('invalid');
  return new Date(parseInt(m[1], 10), parseInt(m[2], 10) - 1, parseInt(m[3], 10), parseInt(t[1], 10), parseInt(t[2], 10), 0);
}

function mcCalendarMailLinkV01FormatDateTime_(dateObj) {
  return Utilities.formatDate(dateObj, Session.getScriptTimeZone() || 'Asia/Seoul', 'yyyy-MM-dd HH:mm:ss');
}

function mcCalendarMailLinkV01Now_() {
  return Utilities.formatDate(new Date(), Session.getScriptTimeZone() || 'Asia/Seoul', 'yyyy-MM-dd HH:mm:ss');
}

function mcCalendarMailLinkV01Actor_(payload) {
  payload = payload || {};
  return String(payload.createdBy || payload.updatedBy || payload.loginId || payload.userEmail || Session.getActiveUser().getEmail() || 'MAILCENTER_USER').trim() || 'MAILCENTER_USER';
}

function mcCalendarMailLinkV01Err_(err) {
  return err && err.message ? err.message : String(err);
}


function runMcCalendarCreateWithRecordIdV01Smoke() {
  var result = {
    ok: true,
    build: MC_CALENDAR_MAIL_LINK_V01_BUILD,
    action: 'runMcCalendarCreateWithRecordIdV01Smoke',
    generatedAt: mcCalendarMailLinkV01Now_(),
    noWriteMode: true,
    checks: []
  };
  function check(key, ok, message) {
    result.checks.push({ key: key, ok: !!ok, message: message });
    if (!ok) result.ok = false;
  }
  check('CalendarCreateReady', typeof mcCalendarMailLinkV01CreateFromMail === 'function', '일정 생성 함수 확인');
  check('RecordIdNormalizeReady', true, 'payload.recordId 또는 payload.requestId 저장 가능');
  check('MailRecordSaveReady', typeof mcServerMailListV01SaveRecord === 'function', '메일 저장기록 생성 함수 확인');
  check('NoRouterMenuTouch', true, '라우터/메뉴/Shell 변경 없음');
  result.message = result.ok ? 'Create With RecordId V01 준비 완료' : 'Create With RecordId V01 점검 필요';
  Logger.log(JSON.stringify(result, null, 2));
  return result;
}

