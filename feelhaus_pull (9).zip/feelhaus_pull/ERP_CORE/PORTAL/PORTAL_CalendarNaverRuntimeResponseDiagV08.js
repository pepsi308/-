/**
 * PORTAL_CALENDAR_STEP08_NAVER_RUNTIME_RESPONSE_DIAG_V08_20260601
 * NAVER runtime response diagnostic / createSchedule official UID mode helper.
 * - Ensures fresh NAVER access token before create/modify.
 * - Calls official createSchedule.json only.
 * - Captures HTTP code/body/processType/icalUid/calendarId.
 * - Blocks fallback create when an existing NAVER SUCCESS row is being modified.
 */
var PORTAL_CALENDAR_STEP08_NAVER_RUNTIME_RESPONSE_DIAG_V08_20260601 = true;

function portalCalendarStep08NaverRuntimeResponseDiagBuildMarkerV08_(){
  return 'PORTAL_CALENDAR_STEP08_NAVER_RUNTIME_RESPONSE_DIAG_V08_20260601';
}

function portalCalendarStep08NaverRuntimeResponseDiagGetConfigV08_(){
  var ss = SpreadsheetApp.openById('17VMSpgSZCvIrUlgcw8yCNcnl8WQWo2IcRf5tDCcuJGM');
  var sh = ss.getSheetByName('SystemConfig');
  if (!sh) throw new Error('SystemConfig sheet not found');
  var values = sh.getDataRange().getValues();
  var headers = values[0].map(function(h){ return String(h || '').trim(); });
  var keyIdx = headers.indexOf('CONFIG_KEY');
  var valueIdx = headers.indexOf('VALUE');
  var statusIdx = headers.indexOf('status');
  if (keyIdx < 0 || valueIdx < 0) throw new Error('SystemConfig CONFIG_KEY/VALUE headers missing');
  var map = {};
  var rows = {};
  for (var i = 1; i < values.length; i++) {
    var key = String(values[i][keyIdx] || '').trim();
    if (!key) continue;
    var status = statusIdx >= 0 ? String(values[i][statusIdx] || '').trim().toUpperCase() : 'ACTIVE';
    if (status && status !== 'ACTIVE' && status !== '') continue;
    map[key] = values[i][valueIdx];
    rows[key] = i + 1;
  }
  return {ss:ss, sheet:sh, headers:headers, keyIdx:keyIdx, valueIdx:valueIdx, rows:rows, map:map};
}

function portalCalendarStep08NaverRuntimeResponseDiagSetConfigV08_(cfg, key, value){
  if (!cfg.rows[key]) return false;
  cfg.sheet.getRange(cfg.rows[key], cfg.valueIdx + 1).setValue(value);
  return true;
}

function portalCalendarStep08NaverRuntimeResponseDiagParseDateV08_(value){
  if (!value) return null;
  var d = new Date(String(value));
  if (isNaN(d.getTime())) return null;
  return d;
}

function portalCalendarStep08NaverRuntimeResponseDiagEnsureFreshTokenV08_(){
  var cfg = portalCalendarStep08NaverRuntimeResponseDiagGetConfigV08_();
  var map = cfg.map;
  var now = new Date();
  var expiresAt = portalCalendarStep08NaverRuntimeResponseDiagParseDateV08_(map.NAVER_TOKEN_EXPIRES_AT);
  var accessToken = String(map.NAVER_CALENDAR_ACCESS_TOKEN || '').trim();
  var refreshToken = String(map.NAVER_REFRESH_TOKEN || '').trim();
  var needRefresh = !accessToken || !expiresAt || (expiresAt.getTime() - now.getTime() < 5 * 60 * 1000);
  var before = {
    accessTokenExists: !!accessToken,
    refreshTokenExists: !!refreshToken,
    expiresAt: String(map.NAVER_TOKEN_EXPIRES_AT || '')
  };
  if (!needRefresh) {
    return {ok:true, refreshed:false, accessToken:accessToken, before:before, expiresAt:String(map.NAVER_TOKEN_EXPIRES_AT || '')};
  }
  if (!refreshToken) {
    return {ok:false, refreshed:false, before:before, error:'NAVER_REFRESH_TOKEN_MISSING'};
  }
  var clientId = String(map.NAVER_CLIENT_ID || '').trim();
  var clientSecret = String(map.NAVER_CLIENT_SECRET || '').trim();
  if (!clientId || !clientSecret) {
    return {ok:false, refreshed:false, before:before, error:'NAVER_CLIENT_ID_OR_SECRET_MISSING'};
  }
  var url = 'https://nid.naver.com/oauth2.0/token';
  var payload = {
    grant_type: 'refresh_token',
    client_id: clientId,
    client_secret: clientSecret,
    refresh_token: refreshToken
  };
  var res = UrlFetchApp.fetch(url, {method:'post', payload:payload, muteHttpExceptions:true});
  var code = res.getResponseCode();
  var body = res.getContentText();
  var json = {};
  try { json = JSON.parse(body || '{}'); } catch(e) { json = {parseError:String(e), raw:body}; }
  if (code < 200 || code >= 300 || !json.access_token) {
    return {ok:false, refreshed:false, before:before, httpCode:code, responseBody:body, error:'NAVER_TOKEN_REFRESH_FAILED'};
  }
  var newAccessToken = String(json.access_token || '').trim();
  var expiresInSec = Number(json.expires_in || 3600);
  var newExpires = new Date(new Date().getTime() + Math.max(60, expiresInSec - 60) * 1000);
  var tz = String(map.DEFAULT_TIMEZONE || 'Asia/Seoul');
  var expiresText = Utilities.formatDate(newExpires, tz, "yyyy-MM-dd'T'HH:mm:ssXXX");
  portalCalendarStep08NaverRuntimeResponseDiagSetConfigV08_(cfg, 'NAVER_CALENDAR_ACCESS_TOKEN', newAccessToken);
  portalCalendarStep08NaverRuntimeResponseDiagSetConfigV08_(cfg, 'NAVER_TOKEN_EXPIRES_AT', expiresText);
  portalCalendarStep08NaverRuntimeResponseDiagSetConfigV08_(cfg, 'NAVER_TOKEN_TYPE', String(json.token_type || 'bearer'));
  return {ok:true, refreshed:true, accessToken:newAccessToken, before:before, expiresAt:expiresText, httpCode:code};
}

function portalCalendarStep08NaverRuntimeResponseDiagPickCalendarIdV08_(row, request, icalText){
  row = row || {};
  request = request || {};
  var cfg = portalCalendarStep08NaverRuntimeResponseDiagGetConfigV08_().map;
  var candidates = [
    row.naverCalendarId,
    row.naverProviderCalendarId,
    row.naverNumericCalendarId,
    request.calendarId,
    request.providerCalendarId,
    request.naverCalendarId,
    portalCalendarStep08NaverRuntimeResponseDiagExtractCalendarIdFromIcalV08_(icalText),
    cfg.NAVER_UPDATE_CALENDAR_ID,
    cfg.NAVER_NUMERIC_CALENDAR_ID
  ];
  for (var i = 0; i < candidates.length; i++) {
    var v = String(candidates[i] || '').trim();
    if (v) return v;
  }
  return '';
}

function portalCalendarStep08NaverRuntimeResponseDiagExtractUidFromIcalV08_(icalText){
  var m = String(icalText || '').match(/(?:^|\r?\n)UID:([^\r\n]+)/i);
  return m ? String(m[1]).trim() : '';
}

function portalCalendarStep08NaverRuntimeResponseDiagExtractCalendarIdFromIcalV08_(icalText){
  // [CALENDAR-ID] marker from NAVER iCal info dialog.
  var m = String(icalText || '').match(/\[CALENDAR-ID\]\s*:\s*([^\r\n]+)/i);
  return m ? String(m[1]).trim() : '';
}

function portalCalendarStep08NaverRuntimeResponseDiagParseNaverBodyV08_(body){
  var out = {raw: String(body || '')};
  try {
    var json = JSON.parse(body || '{}');
    out.json = json;
    var rv = json.returnValue || json.result || json;
    out.processType = rv.processType || json.processType || '';
    out.icalUid = rv.icalUid || rv.uid || json.icalUid || '';
    out.calendarId = rv.calendarId || json.calendarId || '';
    out.message = json.message || json.errorMessage || rv.message || '';
  } catch(e) {
    out.parseError = String(e);
  }
  return out;
}

function portalCalendarStep08NaverRuntimeResponseDiagFetchCreateScheduleV08_(args){
  args = args || {};
  var row = args.row || {};
  var request = args.request || {};
  var icalText = String(args.scheduleIcalString || args.ical || '');
  var existingSuccess = String(row.naverStatus || row.naverRegisterStatus || row.providerStatus || '').toUpperCase().indexOf('SUCCESS') >= 0;
  var existingUid = String(row.naverIcalUid || row.naverProviderEventId || row.naverEventUid || portalCalendarStep08NaverRuntimeResponseDiagExtractUidFromIcalV08_(icalText) || '').trim();
  var calendarId = portalCalendarStep08NaverRuntimeResponseDiagPickCalendarIdV08_(row, request, icalText);
  var endpoint = String(portalCalendarStep08NaverRuntimeResponseDiagGetConfigV08_().map.NAVER_CALENDAR_CREATE_URL || 'https://openapi.naver.com/calendar/createSchedule.json').trim();
  if (!endpoint) endpoint = 'https://openapi.naver.com/calendar/createSchedule.json';
  if (endpoint.indexOf('createSchedule.json') < 0) return {ok:false, blocked:true, reason:'NAVER_CREATE_SCHEDULE_URL_NOT_OFFICIAL', endpoint:endpoint};
  if (!calendarId) return {ok:false, blocked:true, reason:'NAVER_CALENDAR_ID_MISSING'};
  if (existingSuccess && !existingUid) return {ok:false, blocked:true, reason:'NAVER_EXISTING_SUCCESS_UID_MISSING_CREATE_BLOCKED'};
  var token = portalCalendarStep08NaverRuntimeResponseDiagEnsureFreshTokenV08_();
  if (!token.ok) return {ok:false, blocked:true, reason:'NAVER_TOKEN_REFRESH_FAILED', token:token};
  var payload = {calendarId: calendarId, scheduleIcalString: icalText};
  var options = {method:'post', payload:payload, headers:{Authorization:'Bearer ' + token.accessToken}, muteHttpExceptions:true};
  var res = UrlFetchApp.fetch(endpoint, options);
  var code = res.getResponseCode();
  var body = res.getContentText();
  var parsed = portalCalendarStep08NaverRuntimeResponseDiagParseNaverBodyV08_(body);
  var retried = false;
  if (code === 401 || code === 403) {
    var retryToken = portalCalendarStep08NaverRuntimeResponseDiagEnsureFreshTokenV08_();
    if (retryToken.ok) {
      retried = true;
      options.headers.Authorization = 'Bearer ' + retryToken.accessToken;
      res = UrlFetchApp.fetch(endpoint, options);
      code = res.getResponseCode();
      body = res.getContentText();
      parsed = portalCalendarStep08NaverRuntimeResponseDiagParseNaverBodyV08_(body);
    }
  }
  var processType = String(parsed.processType || '').toLowerCase();
  if (existingSuccess && processType === 'create') {
    return {ok:false, duplicateRiskBlocked:true, httpCode:code, responseBody:body, parsed:parsed, retried:retried, calendarId:calendarId, uid:existingUid, reason:'NAVER_PROCESS_TYPE_CREATE_ON_EXISTING_UPDATE_BLOCKED'};
  }
  return {ok:code >= 200 && code < 300, httpCode:code, responseBody:body, parsed:parsed, retried:retried, calendarId:calendarId, uid:existingUid, endpoint:endpoint, tokenRefreshed:token.refreshed};
}

function portalCalendarStep08NaverRuntimeResponseDiagFormatMessageV08_(result){
  result = result || {};
  var p = result.parsed || {};
  return [
    'NAVER_DIAG_V08',
    'ok=' + result.ok,
    'httpCode=' + (result.httpCode || ''),
    'calendarId=' + (result.calendarId || p.calendarId || ''),
    'uid=' + (result.uid || p.icalUid || ''),
    'processType=' + (p.processType || ''),
    'icalUid=' + (p.icalUid || ''),
    'retried=' + (!!result.retried),
    'reason=' + (result.reason || ''),
    'body=' + String(result.responseBody || '').slice(0, 800)
  ].join(' | ');
}

function portalCalendarStep08NaverRuntimeResponseDiagnoseV08(){
  var cfg = portalCalendarStep08NaverRuntimeResponseDiagGetConfigV08_().map;
  var token = portalCalendarStep08NaverRuntimeResponseDiagEnsureFreshTokenV08_();
  var out = {
    ok: !!token.ok,
    build: 'PORTAL_CALENDAR_STEP08_NAVER_RUNTIME_RESPONSE_DIAG_V08_20260601',
    action: 'portalCalendarStep08NaverRuntimeResponseDiagnoseV08',
    safety: 'TOKEN_REFRESH_AND_CONFIG_ONLY_NO_NAVER_CALENDAR_WRITE',
    config: {
      NAVER_CALENDAR_ENABLED: cfg.NAVER_CALENDAR_ENABLED || '',
      FEATURE_NAVER_CALENDAR_ENABLED: cfg.FEATURE_NAVER_CALENDAR_ENABLED || '',
      NAVER_CALENDAR_CREATE_URL: cfg.NAVER_CALENDAR_CREATE_URL || '',
      NAVER_UPDATE_CALENDAR_ID: cfg.NAVER_UPDATE_CALENDAR_ID || ''
    },
    token: token,
    generatedAt: Utilities.formatDate(new Date(), 'Asia/Seoul', 'yyyy-MM-dd HH:mm:ss')
  };
  Logger.log('JSON_COMPACT_RESULT: ' + JSON.stringify(out));
  return out;
}
