
function portalCalendarSafe01BR10K4H2FCreateResetScrollStabilityVerify() {
  var build='PORTAL_CALENDAR_SAFE01B_R10K4H2F_CREATE_RESET_SCROLL_STABILITY_20260604';
  var html=''; var err='';
  try{html=HtmlService.createHtmlOutputFromFile('MC_CalendarViewV01').getContent();}catch(e){err=String(e&&e.message?e.message:e);}
  var checks={
    viewReadable: !!html,
    buildMarkerPresent: html.indexOf(build)>=0,
    createResetReady: html.indexOf('fhCalendarR10K4H2FResetCreateForm')>=0,
    allMeFieldResetReady: html.indexOf('create-mode-reset-all-me-fields')>=0 && html.indexOf('querySelectorAll(\'input,select,textarea\')')>=0,
    setManualModeCreateWrapped: html.indexOf('setManualModeCreate-wrapped')>=0 && html.indexOf('window.setManualModeCreate=setManualModeCreate=wrapped')>=0,
    openManualWrapped: html.indexOf('openManualEventModal-wrapped')>=0,
    scrollPositionGuardReady: html.indexOf('select-scroll-position-guard')>=0 && html.indexOf('restoreScroll')>=0,
    staleMeetingClearReady: html.indexOf("setVal('me_meetingAddYn','N')")>=0 && html.indexOf("setVal('me_meetingRecorderName',actorName())")>=0,
    h2cSaveUxKept: html.indexOf('PORTAL_CALENDAR_SAFE01B_R10K4H2C_SAVE_UX_AUTORF_PAUSE_20260604')>=0,
    h2eMeetingDisplayKept: html.indexOf('PORTAL_CALENDAR_SAFE01B_R10K4H2E_MEETING_LEDGER_TARGET_DISPLAY_20260604')>=0,
    h2bBindingKept: html.indexOf('PORTAL_CALENDAR_SAFE01B_R10K4H2B_INPUT_BINDING_SAVE_LINK_REPAIR_20260604')>=0,
    g6ScrollKept: html.indexOf('PORTAL_CALENDAR_SAFE01B_R10K4G6_MODAL_SCROLL_REPAIR_20260604')>=0,
    providerWriteNotAdded: html.indexOf('Calendar.Events.insert')<0 && html.indexOf('Calendar.Events.update')<0 && html.indexOf('UrlFetchApp.fetch')<0
  };
  var fatal=[];
  Object.keys(checks).forEach(function(k){ if(checks[k]!==true) fatal.push(k); });
  var result={ok:fatal.length===0, build:build, baseBuild:'PORTAL_CALENDAR_SAFE01B_R10K4H2E_MEETING_LEDGER_TARGET_DISPLAY_20260604', action:'portalCalendarSafe01BR10K4H2FCreateResetScrollStabilityVerify', safety:'READ_ONLY_RUNTIME_VERIFY_NO_SHEET_PROVIDER_WRITE', checks:checks, diagnostics:{htmlLength:html.length, readError:err}, fatal:fatal, message:fatal.length?'R10K4H2F create reset/scroll stability verification failed.':'R10K4H2F create reset/scroll stability verification passed.'};
  Logger.log('JSON_COMPACT_RESULT: '+JSON.stringify(result));
  return result;
}
function portalCalendarSafe01BR10K4H2FVerify(){return portalCalendarSafe01BR10K4H2FCreateResetScrollStabilityVerify();}
function runPortalCalendarH2FVerifyLog(){return portalCalendarSafe01BR10K4H2FCreateResetScrollStabilityVerify();}
