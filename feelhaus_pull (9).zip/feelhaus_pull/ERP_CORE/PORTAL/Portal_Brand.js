/*
================================================================================
 BUILD: PORTAL_108_APPROVAL_LIST_FILTER_FIX_LOCK_20260514
 MODULE: PORTAL 브랜드/로고 자산 정책
 RULE: 공식 로고/변경권한/AuditLog 정책 고정, 새 시트 자동 생성 금지
================================================================================
*/
var PORTAL_BRAND_BUILD = 'PORTAL_BRAND_ASSET_CONFIG_LOCK_20260514';
var PORTAL_BRAND_OFFICIAL_NAME = '(주)필하우스';
var PORTAL_BRAND_OFFICIAL_LOGO_MODE = 'EMBEDDED_OFFICIAL_LOGO';
var PORTAL_BRAND_FUTURE_CONFIG_BUILD = 'PORTAL_BRAND_ASSET_CONFIG_LOCK';
var PORTAL_BRAND_ALLOWED_CHANGE_ROLES = ['SUPER_ADMIN'];

function portalBrandOfficialLogoDataUri_() {
  return portal107OfficialLogoDataUri_();
}

function portalBrandPolicy_() {
  return {
    ok: true,
    build: PORTAL_BRAND_BUILD,
    officialName: PORTAL_BRAND_OFFICIAL_NAME,
    logoMode: PORTAL_BRAND_OFFICIAL_LOGO_MODE,
    officialLogoDescription: '금색 집 모양 심볼 + (주)필하우스 로고',
    displayTargets: ['LoginPage','LeftMenu','PortalHome','PrintGuide'],
    futureConfig: {
      enabledLater: true,
      build: PORTAL_BRAND_FUTURE_CONFIG_BUILD,
      allowedRoles: PORTAL_BRAND_ALLOWED_CHANGE_ROLES,
      storage: 'Drive fileId/logoUrl + SystemConfig 또는 브랜드 설정값',
      audit: 'Portal_AuditLog 기록 필수',
      sensitivePolicy: 'Drive 파일 권한과 민감 설정값 전체 표시 금지'
    },
    protection: {
      noAutoSheetCreation: true,
      noPortalUsersHeaderChange: true,
      noNaverOAuthChange: true,
      noMailBodyChange: true,
      noErpSignFormControlBodyChange: true
    }
  };
}

function portalBrandCanChangeLogo_(user) {
  var role = '';
  try { role = portal104NormalizeRoleRaw_(user && user.roleCode); } catch (err) { role = String(user && user.roleCode || '').toUpperCase(); }
  return PORTAL_BRAND_ALLOWED_CHANGE_ROLES.indexOf(role) >= 0;
}

function portalBrandNoAutoSheetCreationSmoke_() {
  var blocks = [
    portalBrandPolicy_.toString(),
    portalBrandOfficialLogoDataUri_.toString(),
    portalBrandCanChangeLogo_.toString()
  ].join('\n');
  return blocks.indexOf('insertSheet') < 0 && blocks.indexOf('getOrAdd') < 0 && blocks.indexOf('getSheetOrCreate') < 0;
}

function portalBrandLogoDataSmoke_() {
  var logo = portalBrandOfficialLogoDataUri_();
  return String(logo).indexOf('data:image/png;base64,') === 0 && String(logo).length > 1000;
}

function testPortalBrandAssetConfigLock() {
  var policy = portalBrandPolicy_();
  var checks = [];
  var currentTopBuild = (typeof PORTAL19_BUILD !== 'undefined' ? PORTAL19_BUILD : '');
  var brandBuildOk = (PORTAL_BRAND_BUILD === 'PORTAL_BRAND_ASSET_CONFIG_LOCK_20260514');
  var currentBuildOk = !!currentTopBuild || (typeof PORTAL_STRUCTURE_SPLIT_BUILD !== 'undefined');
  checks.push(portalPlanningCheck_('BrandBuildNameVisible', brandBuildOk && currentBuildOk, '브랜드 정책 빌드 고정 및 최신 상위 빌드 허용'));
  checks.push(portalPlanningCheck_('OfficialLogoEmbedded', portalBrandLogoDataSmoke_(), '공식 로고 data URI 반영'));
  checks.push(portalPlanningCheck_('OfficialLogoFunctionBridge', portalBrandOfficialLogoDataUri_() === portal107OfficialLogoDataUri_(), 'PORTAL 공통 로고 함수와 107 사이드 메뉴 로고 연결'));
  checks.push(portalPlanningCheck_('BrandChangeSuperAdminOnly', portalBrandCanChangeLogo_({roleCode:'SUPER_ADMIN'}) && !portalBrandCanChangeLogo_({roleCode:'HQ_ADMIN'}) && !portalBrandCanChangeLogo_({roleCode:'DEV'}), '로고 변경은 SUPER_ADMIN만 허용 정책'));
  checks.push(portalPlanningCheck_('BrandAuditPolicyFixed', policy.futureConfig.audit.indexOf('AuditLog') >= 0, '로고 변경 AuditLog 기록 정책'));
  checks.push(portalPlanningCheck_('BrandNoAutoSheetCreation', portalBrandNoAutoSheetCreationSmoke_(), '브랜드 설정에서 새 시트 자동 생성 없음'));
  checks.push(portalPlanningCheck_('Portal103To106Maintained', typeof portal103ValidateSession_ === 'function' && typeof portal104InjectEmployeeAdminPanel_ === 'function' && typeof testPortal105FullVisibleSmokeLock === 'function' && typeof testPortal106FullVisibleSmokeLock === 'function', 'PORTAL 103~106 완료축 유지'));
  checks.push(portalPlanningCheck_('PlanningLockMaintained', typeof testPortalPlanningFixedLock === 'function', 'PORTAL 기획 고정축 유지'));
  var ok = checks.every(function(c){ return c.ok; });
  var result = {
    ok: ok,
    build: PORTAL_BRAND_BUILD,
    action: 'testPortalBrandAssetConfigLock',
    message: ok ? 'PORTAL 브랜드 자산 설정 smoke check 통과' : 'PORTAL 브랜드 자산 설정 smoke check 실패',
    generatedAt: portal107Now_ ? portal107Now_() : new Date().toISOString(),
    policy: policy,
    checks: checks,
    nextRecommendedAction: '실화면 로그인/사이드 메뉴에서 공식 로고 표시 확인 후 PORTAL 107 실화면 검수로 진행'
  };
  Logger.log('===== PORTAL BRAND ASSET CONFIG CHECK START =====');
  Logger.log('ACTION: ' + result.action);
  Logger.log('BUILD: ' + result.build);
  Logger.log('OK: ' + result.ok);
  Logger.log('MESSAGE: ' + result.message);
  Logger.log('JSON_COMPACT_RESULT: ' + JSON.stringify(result));
  Logger.log('===== PORTAL BRAND ASSET CONFIG CHECK END =====');
  if (!result.ok) throw new Error(result.message + ' / JSON_COMPACT_RESULT=' + JSON.stringify(result));
  return result;
}
