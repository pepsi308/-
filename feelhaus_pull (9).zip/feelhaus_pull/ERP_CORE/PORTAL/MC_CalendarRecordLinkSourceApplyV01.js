/**
 * FEELHAUS MailCenter Calendar Record Link Source Apply V01
 * Build: MAILCENTER_CALENDAR_RECORD_LINK_SOURCE_APPLY_V01_20260521
 * Purpose:
 * - Use PORTAL_MailLogs as primary record source
 * - Map requestId -> recordId
 * - Match by threadId/messageId first, subject/from/to second
 * - Update MAILCENTER_CalendarMailLinks.recordId and MAILCENTER_CalendarEvents.requestId
 * - Append MAILCENTER_CalendarLogs LINK_SOURCE_APPLY logs
 * - Include Smoke / DryRun / Gate / Apply / Lock / Summary in one server pack
 * - Do not modify router/menu/html/shell/view files
 */
var MC_CAL_RECLINK_SRC_APPLY_V01_BUILD = 'MAILCENTER_CALENDAR_RECORD_LINK_SOURCE_APPLY_V01_20260521';
var MC_CAL_RECLINK_SRC_APPLY_V01_SETUP_DB_ID = '17VMSpgSZCvIrUlgcw8yCNcnl8WQWo2IcRf5tDCcuJGM';
var MC_CAL_RECLINK_SRC_APPLY_V01_CONFIG_SHEET = 'SystemConfig';
var MC_CAL_RECLINK_SRC_APPLY_V01_WEBAPP_URL = 'https://script.google.com/a/macros/feelhausfair.com/s/AKfycbxCyFE7zf4vE8nsfjOeWX0pC56SqU84gm8ie8Txa3qHQGEusJCZeljzCdYeOmZxUVYvjA/exec';
var MC_CAL_RECLINK_SRC_APPLY_V01_SOURCE_SHEET = 'PORTAL_MailLogs';

function runMcCalendarRecordLinkSourceApplyV01Smoke() {
  var result = mcCalRecLinkSrcApplyV01BaseResult_('runMcCalendarRecordLinkSourceApplyV01Smoke', true);
  function check(key, ok, message, detail) { mcCalRecLinkSrcApplyV01Check_(result, key, ok, message, detail); }
  try {
    check('MasterOpenReady', !!mcCalRecLinkSrcApplyV01OpenMaster_(), 'SystemConfig -> FEELHAUS_DB_MASTER 연결 확인', 'FEELHAUS_DB_MASTER');
    check('SourceScanReady', typeof mcCalRecLinkSrcApplyV01ScanCandidates_ === 'function', 'PORTAL_MailLogs 기준 후보 스캔 함수 확인');
    check('DryRunReady', typeof runMcCalendarRecordLinkSourceApplyV01DryRun === 'function', 'Dry Run 함수 확인');
    check('GateReady', typeof runMcCalendarRecordLinkSourceApplyV01Gate === 'function', 'Gate 함수 확인');
    check('ApplyReady', typeof runMcCalendarRecordLinkSourceApplyV01ApplyLinks === 'function', '실제 자동 연결 함수 확인');
    check('LockReady', typeof runMcCalendarRecordLinkSourceApplyV01CreateBackupAndLock === 'function', '백업/잠금 함수 확인');
    check('SummaryReady', typeof runMcCalendarRecordLinkSourceApplyV01Summary === 'function', '요약 기록 함수 확인');
    check('WebAppUrlReady', !!MC_CAL_RECLINK_SRC_APPLY_V01_WEBAPP_URL, 'WebApp 절대주소 확인', MC_CAL_RECLINK_SRC_APPLY_V01_WEBAPP_URL);
    check('NoRouterMenuHtmlTouch', true, '본 파일은 라우터/메뉴/HTML/Shell/View 변경 없음');
    result.message = result.ok ? 'MailCenter Calendar Record Link Source Apply V01 Smoke 통과' : 'MailCenter Calendar Record Link Source Apply V01 점검 필요';
  } catch (err) {
    result.ok = false;
    result.message = mcCalRecLinkSrcApplyV01Err_(err);
  }
  Logger.log(JSON.stringify(result, null, 2));
  return result;
}

function runMcCalendarRecordLinkSourceApplyV01DryRun() {
  var result = mcCalRecLinkSrcApplyV01BaseResult_('runMcCalendarRecordLinkSourceApplyV01DryRun', true);
  function check(key, ok, message, detail) { mcCalRecLinkSrcApplyV01Check_(result, key, ok, message, detail); }
  try {
    var ss = mcCalRecLinkSrcApplyV01OpenMaster_();
    var scan = mcCalRecLinkSrcApplyV01ScanCandidates_(ss);
    check('SourceSheetReady', scan.sourceReady, MC_CAL_RECLINK_SRC_APPLY_V01_SOURCE_SHEET + ' 시트 확인', scan.sourceDetail);
    check('CalendarMailLinksReady', scan.linksReady, 'MAILCENTER_CalendarMailLinks 시트 확인', scan.linksDetail);
    check('CalendarEventsReady', scan.eventsReady, 'MAILCENTER_CalendarEvents 시트 확인', scan.eventsDetail);
    check('CandidateScanCompleted', true, 'PORTAL_MailLogs 기준 recordId 연결 후보 스캔 완료', JSON.stringify(scan.summary));
    check('NoWriteModeConfirmed', true, 'Dry Run은 읽기 전용, 시트 쓰기 없음');
    result.summary = scan.summary;
    result.candidates = scan.candidates.slice(0, 50);
    result.message = result.ok ? 'MailCenter Calendar Record Link Source Apply V01 Dry Run 통과' : 'MailCenter Calendar Record Link Source Apply V01 Dry Run 점검 필요';
  } catch (err) {
    result.ok = false;
    result.message = mcCalRecLinkSrcApplyV01Err_(err);
  }
  Logger.log(JSON.stringify(result, null, 2));
  return result;
}

function runMcCalendarRecordLinkSourceApplyV01Gate() {
  var result = mcCalRecLinkSrcApplyV01BaseResult_('runMcCalendarRecordLinkSourceApplyV01Gate', true);
  function check(key, ok, message, detail) { mcCalRecLinkSrcApplyV01Check_(result, key, ok, message, detail); }
  try {
    var ss = mcCalRecLinkSrcApplyV01OpenMaster_();
    var scan = mcCalRecLinkSrcApplyV01ScanCandidates_(ss);
    check('MasterOpenReady', !!ss, 'SystemConfig -> FEELHAUS_DB_MASTER 연결 확인', ss.getId());
    check('SourceSheetReady', scan.sourceReady, MC_CAL_RECLINK_SRC_APPLY_V01_SOURCE_SHEET + ' 시트 확인', scan.sourceDetail);
    check('SourceHeadersReady', scan.sourceHeadersReady, 'PORTAL_MailLogs 핵심 헤더 확인', scan.sourceHeaderDetail);
    check('CalendarMailLinksReady', scan.linksReady, 'MAILCENTER_CalendarMailLinks 시트 확인', scan.linksDetail);
    check('CalendarEventsReady', scan.eventsReady, 'MAILCENTER_CalendarEvents 시트 확인', scan.eventsDetail);
    check('LinksHeadersReady', scan.linksHeadersReady, '메일링크 핵심 헤더 확인', scan.linksHeaderDetail);
    check('EventsHeadersReady', scan.eventsHeadersReady, '이벤트 핵심 헤더 확인', scan.eventsHeaderDetail);
    check('CandidateScanReady', true, '자동 연결 후보 스캔 확인', JSON.stringify(scan.summary));
    check('CandidateZeroAllowed', true, '후보 0건이어도 게이트 실패 아님 - 실데이터 상황에 따라 정상');
    check('NoWriteModeConfirmed', true, '본 게이트는 읽기 점검 전용, 시트 쓰기 없음');
    check('NoRouterMenuHtmlTouchByGate', true, '게이트는 라우터/메뉴/HTML/Shell/View 변경 없음');
    result.summary = scan.summary;
    result.message = result.ok ? 'MailCenter Calendar Record Link Source Apply V01 Gate 통과' : 'MailCenter Calendar Record Link Source Apply V01 Gate 점검 필요';
    result.nextStage = result.ok ? 'MAILCENTER_CALENDAR_RECORD_LINK_SOURCE_APPLY_READY' : 'RECORD_LINK_SOURCE_APPLY_GATE_FIX_REQUIRED';
  } catch (err) {
    result.ok = false;
    result.message = mcCalRecLinkSrcApplyV01Err_(err);
  }
  Logger.log(JSON.stringify(result, null, 2));
  return result;
}

function runMcCalendarRecordLinkSourceApplyV01ApplyLinks() {
  var result = mcCalRecLinkSrcApplyV01BaseResult_('runMcCalendarRecordLinkSourceApplyV01ApplyLinks', false);
  result.appliedCount = 0;
  result.skippedCount = 0;
  result.applied = [];
  result.skipped = [];
  try {
    var ss = mcCalRecLinkSrcApplyV01OpenMaster_();
    var scan = mcCalRecLinkSrcApplyV01ScanCandidates_(ss);
    var linksSheet = ss.getSheetByName('MAILCENTER_CalendarMailLinks');
    var eventsSheet = ss.getSheetByName('MAILCENTER_CalendarEvents');
    var logSheetName = 'MAILCENTER_CalendarLogs';
    var actor = mcCalRecLinkSrcApplyV01Actor_();
    var now = mcCalRecLinkSrcApplyV01Now_();

    if (!linksSheet || !eventsSheet) throw new Error('MAILCENTER_CalendarMailLinks 또는 MAILCENTER_CalendarEvents 시트를 찾지 못했습니다.');
    var linkValues = linksSheet.getDataRange().getValues();
    var linkHm = mcCalRecLinkSrcApplyV01HeaderMap_(linkValues[0]);
    var eventValues = eventsSheet.getDataRange().getValues();
    var eventHm = mcCalRecLinkSrcApplyV01HeaderMap_(eventValues[0]);

    scan.candidates.forEach(function(c) {
      if (!c.recordId || !c.calendarEventId) {
        result.skippedCount++;
        result.skipped.push({ calendarEventId: c.calendarEventId || '', reason: 'recordId/calendarEventId 누락' });
        return;
      }
      if (c.confidence !== 'HIGH' && c.confidence !== 'MEDIUM') {
        result.skippedCount++;
        result.skipped.push({ calendarEventId: c.calendarEventId, recordId: c.recordId, reason: 'confidence 낮음', confidence: c.confidence });
        return;
      }

      var linkUpdated = false;
      for (var r = 1; r < linkValues.length; r++) {
        var ceid = String(linkValues[r][linkHm.calendarEventId] || '').trim();
        if (ceid === c.calendarEventId) {
          if (linkHm.recordId >= 0 && !String(linkValues[r][linkHm.recordId] || '').trim()) {
            linksSheet.getRange(r + 1, linkHm.recordId + 1).setValue(c.recordId);
            linkUpdated = true;
          }
          if (linkHm.statusReason >= 0) linksSheet.getRange(r + 1, linkHm.statusReason + 1).setValue('PORTAL_MailLogs 기준 requestId 자동 연결');
          if (linkHm.updatedAt >= 0) linksSheet.getRange(r + 1, linkHm.updatedAt + 1).setValue(now);
          if (linkHm.updatedBy >= 0) linksSheet.getRange(r + 1, linkHm.updatedBy + 1).setValue(actor);
        }
      }

      var eventUpdated = false;
      for (var er = 1; er < eventValues.length; er++) {
        var evCeid = String(eventValues[er][eventHm.calendarEventId] || '').trim();
        if (evCeid === c.calendarEventId) {
          if (eventHm.requestId >= 0 && !String(eventValues[er][eventHm.requestId] || '').trim()) {
            eventsSheet.getRange(er + 1, eventHm.requestId + 1).setValue(c.recordId);
            eventUpdated = true;
          }
          if (eventHm.updatedAt >= 0) eventsSheet.getRange(er + 1, eventHm.updatedAt + 1).setValue(now);
          if (eventHm.updatedBy >= 0) eventsSheet.getRange(er + 1, eventHm.updatedBy + 1).setValue(actor);
        }
      }

      mcCalRecLinkSrcApplyV01AppendLog_(ss, {
        calendarEventId: c.calendarEventId,
        provider: 'MAIL_LINK',
        actionType: 'LINK_SOURCE_APPLY',
        resultStatus: 'SUCCESS',
        providerEventId: '',
        errorCode: '',
        errorMessage: '',
        requestPayloadSummary: JSON.stringify({ sourceSheet: MC_CAL_RECLINK_SRC_APPLY_V01_SOURCE_SHEET, recordId: c.recordId, requestId: c.recordId, threadId: c.threadId, messageId: c.messageId, matchType: c.matchType, confidence: c.confidence }).slice(0, 900),
        responseSummary: 'CalendarMailLinks.recordId=' + linkUpdated + ', CalendarEvents.requestId=' + eventUpdated,
        createdAt: now,
        createdBy: actor
      });

      result.appliedCount++;
      result.applied.push({ calendarEventId: c.calendarEventId, recordId: c.recordId, matchType: c.matchType, confidence: c.confidence, linkUpdated: linkUpdated, eventUpdated: eventUpdated });
    });
    result.ok = true;
    result.message = 'MailCenter Calendar Record Link Source Apply V01 자동 연결 완료';
  } catch (err) {
    result.ok = false;
    result.message = mcCalRecLinkSrcApplyV01Err_(err);
  }
  Logger.log(JSON.stringify(result, null, 2));
  return result;
}

function runMcCalendarRecordLinkSourceApplyV01CreateBackupAndLock() {
  var result = mcCalRecLinkSrcApplyV01BaseResult_('runMcCalendarRecordLinkSourceApplyV01CreateBackupAndLock', false);
  result.lockId = '';
  result.backupSpreadsheetId = '';
  result.backupName = '';
  result.copiedSheets = [];
  try {
    var master = mcCalRecLinkSrcApplyV01OpenMaster_();
    var actor = mcCalRecLinkSrcApplyV01Actor_();
    var now = mcCalRecLinkSrcApplyV01Now_();
    var stamp = Utilities.formatDate(new Date(), Session.getScriptTimeZone() || 'Asia/Seoul', 'yyyyMMdd_HHmmss');
    var lockId = 'MCALRECLINKSRCAPPLYLOCK-' + Utilities.formatDate(new Date(), Session.getScriptTimeZone() || 'Asia/Seoul', 'yyyyMMddHHmmss') + '-' + Utilities.getUuid().substring(0, 8).toUpperCase();
    var backupName = 'MAILCENTER_CALENDAR_RECORD_LINK_SOURCE_APPLY_BACKUP_' + stamp;
    var backup = SpreadsheetApp.create(backupName);
    var backupId = backup.getId();
    var targetSheets = ['MAILCENTER_CalendarEvents','MAILCENTER_CalendarMailLinks','MAILCENTER_CalendarLogs','PORTAL_MailLogs','MAILCENTER_CalendarRecordSourceDiscoveryLocks','MAILCENTER_CalendarRecordSourceDiscoverySummaries'];
    var copied = [];
    targetSheets.forEach(function(name) {
      var sh = master.getSheetByName(name);
      if (sh) {
        var cp = sh.copyTo(backup);
        cp.setName(name);
        copied.push({ sheetName: name, rows: sh.getLastRow(), cols: sh.getLastColumn() });
      } else {
        copied.push({ sheetName: name, rows: 0, cols: 0, missing: true });
      }
    });
    var defaultSheet = backup.getSheetByName('Sheet1');
    if (defaultSheet && backup.getSheets().length > 1) backup.deleteSheet(defaultSheet);
    var info = backup.insertSheet('LOCK_INFO');
    var infoRows = [
      ['key','value'],
      ['lockId', lockId],
      ['build', MC_CAL_RECLINK_SRC_APPLY_V01_BUILD],
      ['sourceSheet', MC_CAL_RECLINK_SRC_APPLY_V01_SOURCE_SHEET],
      ['sourceDiscoveryBuild','MAILCENTER_CALENDAR_RECORD_SOURCE_DISCOVERY_V01_20260521'],
      ['webAppUrl', MC_CAL_RECLINK_SRC_APPLY_V01_WEBAPP_URL],
      ['sourceMasterId', master.getId()],
      ['backupSpreadsheetId', backupId],
      ['lockedAt', now],
      ['lockedBy', actor],
      ['status','STABLE_LOCKED'],
      ['scope','Record link source apply using PORTAL_MailLogs requestId mapping'],
      ['note','Router/menu/html/shell/view files not modified by this server pack']
    ];
    info.getRange(1,1,infoRows.length,2).setValues(infoRows);
    info.setFrozenRows(1);

    mcCalRecLinkSrcApplyV01AppendByHeaders_(master, 'MAILCENTER_CalendarRecordLinkSourceApplyLocks', mcCalRecLinkSrcApplyV01LockHeaders_(), {
      lockId: lockId,
      build: MC_CAL_RECLINK_SRC_APPLY_V01_BUILD,
      sourceSheet: MC_CAL_RECLINK_SRC_APPLY_V01_SOURCE_SHEET,
      backupName: backupName,
      backupSpreadsheetId: backupId,
      webAppUrl: MC_CAL_RECLINK_SRC_APPLY_V01_WEBAPP_URL,
      status: 'STABLE_LOCKED',
      statusReason: 'PORTAL_MailLogs 기준 recordId 자동 연결 보강 잠금 완료',
      copiedSheetsJson: JSON.stringify(copied),
      createdAt: now,
      createdBy: actor,
      updatedAt: now,
      updatedBy: actor
    });

    result.ok = true;
    result.lockId = lockId;
    result.backupSpreadsheetId = backupId;
    result.backupName = backupName;
    result.copiedSheets = copied;
    result.message = 'MailCenter Calendar Record Link Source Apply V01 Lock 완료';
  } catch (err) {
    result.ok = false;
    result.message = mcCalRecLinkSrcApplyV01Err_(err);
  }
  Logger.log(JSON.stringify(result, null, 2));
  return result;
}

function runMcCalendarRecordLinkSourceApplyV01Summary() {
  var result = mcCalRecLinkSrcApplyV01BaseResult_('runMcCalendarRecordLinkSourceApplyV01Summary', false);
  try {
    var ss = mcCalRecLinkSrcApplyV01OpenMaster_();
    var scan = mcCalRecLinkSrcApplyV01ScanCandidates_(ss);
    var now = mcCalRecLinkSrcApplyV01Now_();
    var actor = mcCalRecLinkSrcApplyV01Actor_();
    var summaryId = 'MCALRECLINKSRCAPPLYSUM-' + Utilities.formatDate(new Date(), Session.getScriptTimeZone() || 'Asia/Seoul', 'yyyyMMddHHmmss') + '-' + Utilities.getUuid().substring(0, 8).toUpperCase();
    mcCalRecLinkSrcApplyV01AppendByHeaders_(ss, 'MAILCENTER_CalendarRecordLinkSourceApplySummaries', mcCalRecLinkSrcApplyV01SummaryHeaders_(), {
      summaryId: summaryId,
      build: MC_CAL_RECLINK_SRC_APPLY_V01_BUILD,
      sourceSheet: MC_CAL_RECLINK_SRC_APPLY_V01_SOURCE_SHEET,
      eventRows: scan.summary.eventRows,
      linkRows: scan.summary.linkRows,
      sourceRows: scan.summary.sourceRows,
      missingRecordIdRows: scan.summary.missingRecordIdRows,
      candidateRows: scan.summary.candidateRows,
      highConfidenceCandidates: scan.summary.highConfidenceCandidates,
      webAppUrl: MC_CAL_RECLINK_SRC_APPLY_V01_WEBAPP_URL,
      status: 'SUMMARY_RECORDED',
      note: 'PORTAL_MailLogs requestId -> recordId mapping prepared/applied where candidate exists',
      createdAt: now,
      createdBy: actor
    });
    result.ok = true;
    result.summaryId = summaryId;
    result.message = 'MailCenter Calendar Record Link Source Apply V01 Summary 기록 완료';
  } catch (err) {
    result.ok = false;
    result.message = mcCalRecLinkSrcApplyV01Err_(err);
  }
  Logger.log(JSON.stringify(result, null, 2));
  return result;
}

function mcCalRecLinkSrcApplyV01ScanCandidates_(ss) {
  var sourceSheet = ss.getSheetByName(MC_CAL_RECLINK_SRC_APPLY_V01_SOURCE_SHEET);
  var linksSheet = ss.getSheetByName('MAILCENTER_CalendarMailLinks');
  var eventsSheet = ss.getSheetByName('MAILCENTER_CalendarEvents');
  var out = {
    sourceReady: !!sourceSheet,
    sourceDetail: sourceSheet ? 'rows=' + sourceSheet.getLastRow() + ', cols=' + sourceSheet.getLastColumn() : 'missing',
    sourceHeadersReady: false,
    sourceHeaderDetail: '',
    linksReady: !!linksSheet,
    linksDetail: linksSheet ? 'rows=' + linksSheet.getLastRow() + ', cols=' + linksSheet.getLastColumn() : 'missing',
    linksHeadersReady: false,
    linksHeaderDetail: '',
    eventsReady: !!eventsSheet,
    eventsDetail: eventsSheet ? 'rows=' + eventsSheet.getLastRow() + ', cols=' + eventsSheet.getLastColumn() : 'missing',
    eventsHeadersReady: false,
    eventsHeaderDetail: '',
    summary: { sourceRows: 0, eventRows: 0, linkRows: 0, missingRecordIdRows: 0, alreadyLinkedRows: 0, candidateRows: 0, highConfidenceCandidates: 0, mediumConfidenceCandidates: 0 },
    candidates: []
  };
  if (!sourceSheet || !linksSheet || !eventsSheet) return out;

  var sourceValues = sourceSheet.getDataRange().getValues();
  var linkValues = linksSheet.getDataRange().getValues();
  var eventValues = eventsSheet.getDataRange().getValues();
  var sourceHm = mcCalRecLinkSrcApplyV01HeaderMap_(sourceValues[0] || []);
  var linkHm = mcCalRecLinkSrcApplyV01HeaderMap_(linkValues[0] || []);
  var eventHm = mcCalRecLinkSrcApplyV01HeaderMap_(eventValues[0] || []);

  var sourceReqCol = mcCalRecLinkSrcApplyV01PickIndex_(sourceHm, ['requestId','recordId']);
  var sourceThreadCol = mcCalRecLinkSrcApplyV01PickIndex_(sourceHm, ['threadId','gmailThreadId']);
  var sourceMsgCol = mcCalRecLinkSrcApplyV01PickIndex_(sourceHm, ['messageId','gmailMessageId']);
  var sourceSubjectCol = mcCalRecLinkSrcApplyV01PickIndex_(sourceHm, ['subject']);
  var sourceSenderCol = mcCalRecLinkSrcApplyV01PickIndex_(sourceHm, ['sender','fromEmail','from']);
  var sourceToCol = mcCalRecLinkSrcApplyV01PickIndex_(sourceHm, ['toEmail','recipient','to']);
  var srcMissing = [];
  if (sourceReqCol < 0) srcMissing.push('requestId');
  if (sourceThreadCol < 0 && sourceMsgCol < 0) srcMissing.push('threadId/messageId');
  out.sourceHeadersReady = srcMissing.length === 0;
  out.sourceHeaderDetail = 'missing=' + JSON.stringify(srcMissing);

  var linkMissing = [];
  ['calendarEventId','recordId','threadId','messageId','subject'].forEach(function(h){ if (!linkHm.hasOwnProperty(h)) linkMissing.push(h); });
  out.linksHeadersReady = linkMissing.length === 0;
  out.linksHeaderDetail = 'missing=' + JSON.stringify(linkMissing);

  var eventMissing = [];
  ['calendarEventId','requestId'].forEach(function(h){ if (!eventHm.hasOwnProperty(h)) eventMissing.push(h); });
  out.eventsHeadersReady = eventMissing.length === 0;
  out.eventsHeaderDetail = 'missing=' + JSON.stringify(eventMissing);

  out.summary.sourceRows = Math.max(sourceValues.length - 1, 0);
  out.summary.linkRows = Math.max(linkValues.length - 1, 0);
  out.summary.eventRows = Math.max(eventValues.length - 1, 0);

  var byThread = {};
  var byMessage = {};
  var bySubject = {};
  for (var s = 1; s < sourceValues.length; s++) {
    var row = sourceValues[s];
    var requestId = sourceReqCol >= 0 ? String(row[sourceReqCol] || '').trim() : '';
    if (!requestId) continue;
    var threadId = sourceThreadCol >= 0 ? String(row[sourceThreadCol] || '').trim() : '';
    var messageId = sourceMsgCol >= 0 ? String(row[sourceMsgCol] || '').trim() : '';
    var subject = sourceSubjectCol >= 0 ? String(row[sourceSubjectCol] || '').trim() : '';
    var sender = sourceSenderCol >= 0 ? String(row[sourceSenderCol] || '').trim().toLowerCase() : '';
    var toEmail = sourceToCol >= 0 ? String(row[sourceToCol] || '').trim().toLowerCase() : '';
    var rec = { requestId: requestId, threadId: threadId, messageId: messageId, subject: subject, sender: sender, toEmail: toEmail, sourceRow: s + 1 };
    if (threadId) byThread[threadId] = rec;
    if (messageId) byMessage[messageId] = rec;
    if (subject) bySubject[mcCalRecLinkSrcApplyV01NormSubject_(subject)] = rec;
  }

  for (var r = 1; r < linkValues.length; r++) {
    var lrow = linkValues[r];
    var existingRecordId = linkHm.recordId >= 0 ? String(lrow[linkHm.recordId] || '').trim() : '';
    if (existingRecordId) { out.summary.alreadyLinkedRows++; continue; }
    out.summary.missingRecordIdRows++;
    var calendarEventId = linkHm.calendarEventId >= 0 ? String(lrow[linkHm.calendarEventId] || '').trim() : '';
    var threadId = linkHm.threadId >= 0 ? String(lrow[linkHm.threadId] || '').trim() : '';
    var messageId = linkHm.messageId >= 0 ? String(lrow[linkHm.messageId] || '').trim() : '';
    var subject = linkHm.subject >= 0 ? String(lrow[linkHm.subject] || '').trim() : '';
    var fromEmail = linkHm.fromEmail >= 0 ? String(lrow[linkHm.fromEmail] || '').trim().toLowerCase() : '';
    var toEmail = linkHm.toEmail >= 0 ? String(lrow[linkHm.toEmail] || '').trim().toLowerCase() : '';
    var match = null;
    var matchType = '';
    var confidence = 'LOW';
    if (threadId && byThread[threadId]) { match = byThread[threadId]; matchType = 'threadId'; confidence = 'HIGH'; }
    else if (messageId && byMessage[messageId]) { match = byMessage[messageId]; matchType = 'messageId'; confidence = 'HIGH'; }
    else if (subject && bySubject[mcCalRecLinkSrcApplyV01NormSubject_(subject)]) {
      var m = bySubject[mcCalRecLinkSrcApplyV01NormSubject_(subject)];
      var emailHit = (fromEmail && m.sender && fromEmail === m.sender) || (toEmail && m.toEmail && toEmail === m.toEmail) || (toEmail && m.sender && toEmail === m.sender) || (fromEmail && m.toEmail && fromEmail === m.toEmail);
      match = m;
      matchType = emailHit ? 'subject+email' : 'subject';
      confidence = emailHit ? 'MEDIUM' : 'LOW';
    }
    if (match) {
      out.summary.candidateRows++;
      if (confidence === 'HIGH') out.summary.highConfidenceCandidates++;
      if (confidence === 'MEDIUM') out.summary.mediumConfidenceCandidates++;
      out.candidates.push({
        calendarEventId: calendarEventId,
        recordId: match.requestId,
        requestId: match.requestId,
        threadId: threadId,
        messageId: messageId,
        subject: subject,
        matchType: matchType,
        confidence: confidence,
        linkRow: r + 1,
        sourceRow: match.sourceRow,
        sourceSheet: MC_CAL_RECLINK_SRC_APPLY_V01_SOURCE_SHEET
      });
    }
  }
  return out;
}

function mcCalRecLinkSrcApplyV01AppendLog_(ss, record) {
  record.calendarLogId = 'MCALLOG-' + Utilities.formatDate(new Date(), Session.getScriptTimeZone() || 'Asia/Seoul', 'yyyyMMddHHmmss') + '-' + Utilities.getUuid().substring(0, 8).toUpperCase();
  mcCalRecLinkSrcApplyV01AppendByHeaders_(ss, 'MAILCENTER_CalendarLogs', mcCalRecLinkSrcApplyV01LogHeaders_(), record);
}

function mcCalRecLinkSrcApplyV01LogHeaders_() {
  return ['calendarLogId','calendarEventId','provider','actionType','resultStatus','providerEventId','errorCode','errorMessage','requestPayloadSummary','responseSummary','createdAt','createdBy'];
}
function mcCalRecLinkSrcApplyV01LockHeaders_() {
  return ['lockId','build','sourceSheet','backupName','backupSpreadsheetId','webAppUrl','status','statusReason','copiedSheetsJson','createdAt','createdBy','updatedAt','updatedBy'];
}
function mcCalRecLinkSrcApplyV01SummaryHeaders_() {
  return ['summaryId','build','sourceSheet','eventRows','linkRows','sourceRows','missingRecordIdRows','candidateRows','highConfidenceCandidates','webAppUrl','status','note','createdAt','createdBy'];
}

function mcCalRecLinkSrcApplyV01AppendByHeaders_(ss, sheetName, baseHeaders, record) {
  var sheet = mcCalRecLinkSrcApplyV01GetSheetOrCreate_(ss, sheetName, baseHeaders);
  mcCalRecLinkSrcApplyV01EnsureHeaders_(sheet, Object.keys(record || {}));
  var headers = sheet.getRange(1,1,1,sheet.getLastColumn()).getValues()[0];
  var hm = mcCalRecLinkSrcApplyV01HeaderMap_(headers);
  var row = [];
  for (var i = 0; i < headers.length; i++) row.push('');
  Object.keys(record || {}).forEach(function(k){ if (hm.hasOwnProperty(k)) row[hm[k]] = record[k]; });
  sheet.appendRow(row);
}
function mcCalRecLinkSrcApplyV01GetSheetOrCreate_(ss, name, headers) {
  var sh = ss.getSheetByName(name);
  if (!sh) {
    sh = ss.insertSheet(name);
    sh.getRange(1,1,1,headers.length).setValues([headers]);
    sh.setFrozenRows(1);
    return sh;
  }
  if (sh.getLastRow() < 1 || sh.getLastColumn() < 1) {
    sh.getRange(1,1,1,headers.length).setValues([headers]);
    sh.setFrozenRows(1);
  }
  mcCalRecLinkSrcApplyV01EnsureHeaders_(sh, headers);
  return sh;
}
function mcCalRecLinkSrcApplyV01EnsureHeaders_(sheet, required) {
  var lastCol = Math.max(sheet.getLastColumn(), 1);
  var headers = sheet.getRange(1,1,1,lastCol).getValues()[0];
  var hm = mcCalRecLinkSrcApplyV01HeaderMap_(headers);
  var add = [];
  (required || []).forEach(function(h){ if (h && !hm.hasOwnProperty(h)) add.push(h); });
  if (add.length) sheet.getRange(1, headers.length + 1, 1, add.length).setValues([add]);
}
function mcCalRecLinkSrcApplyV01OpenMaster_() {
  var setup = SpreadsheetApp.openById(MC_CAL_RECLINK_SRC_APPLY_V01_SETUP_DB_ID);
  var sheet = setup.getSheetByName(MC_CAL_RECLINK_SRC_APPLY_V01_CONFIG_SHEET);
  if (!sheet) throw new Error('SystemConfig 시트를 찾지 못했습니다.');
  var values = sheet.getDataRange().getValues();
  if (!values || values.length < 2) throw new Error('SystemConfig 데이터가 비어 있습니다.');
  var hm = mcCalRecLinkSrcApplyV01HeaderMap_(values[0]);
  var keyCol = mcCalRecLinkSrcApplyV01PickIndex_(hm, ['CONFIG_KEY','configKey','key','name']);
  var valCol = mcCalRecLinkSrcApplyV01PickIndex_(hm, ['VALUE','configValue','value','spreadsheetId']);
  if (keyCol < 0 || valCol < 0) throw new Error('SystemConfig CONFIG_KEY/VALUE 헤더를 찾지 못했습니다.');
  var masterId = '';
  for (var r = 1; r < values.length; r++) {
    var key = String(values[r][keyCol] || '').trim();
    if (key === 'FEELHAUS_DB_MASTER' || key === 'FEELHAUS_DB_MASTER_ID' || key === 'MASTER_DB_ID') { masterId = String(values[r][valCol] || '').trim(); break; }
  }
  if (!masterId) throw new Error('SystemConfig에서 FEELHAUS_DB_MASTER ID를 찾지 못했습니다.');
  return SpreadsheetApp.openById(masterId);
}
function mcCalRecLinkSrcApplyV01HeaderMap_(headers) {
  var out = {};
  (headers || []).forEach(function(h,i){ var k = String(h || '').trim(); if (k) out[k] = i; });
  return out;
}
function mcCalRecLinkSrcApplyV01PickIndex_(hm, keys) {
  for (var i = 0; i < keys.length; i++) if (hm.hasOwnProperty(keys[i])) return hm[keys[i]];
  return -1;
}
function mcCalRecLinkSrcApplyV01NormSubject_(s) {
  return String(s || '').replace(/^\s*(re|fw|fwd)\s*:\s*/ig, '').replace(/\s+/g, ' ').trim().toLowerCase();
}
function mcCalRecLinkSrcApplyV01BaseResult_(action, noWriteMode) {
  return { ok: true, build: MC_CAL_RECLINK_SRC_APPLY_V01_BUILD, action: action, generatedAt: mcCalRecLinkSrcApplyV01Now_(), noWriteMode: !!noWriteMode, checks: [] };
}
function mcCalRecLinkSrcApplyV01Check_(result, key, ok, message, detail) {
  result.checks.push({ key: key, ok: !!ok, message: message, detail: detail || '' });
  if (!ok) result.ok = false;
}
function mcCalRecLinkSrcApplyV01Actor_() {
  return String(Session.getActiveUser().getEmail() || 'MAILCENTER_ADMIN').trim() || 'MAILCENTER_ADMIN';
}
function mcCalRecLinkSrcApplyV01Now_() {
  return Utilities.formatDate(new Date(), Session.getScriptTimeZone() || 'Asia/Seoul', 'yyyy-MM-dd HH:mm:ss');
}
function mcCalRecLinkSrcApplyV01Err_(err) { return err && err.message ? err.message : String(err); }
