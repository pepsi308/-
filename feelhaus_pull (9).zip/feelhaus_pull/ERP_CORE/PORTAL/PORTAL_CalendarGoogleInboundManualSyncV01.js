/**
 * PORTAL_CALENDAR_STEP07_GOOGLE_INBOUND_FIXED_CALENDAR_POLICY_V06_20260601
 * Manual Google Calendar -> PORTAL inbound sync for the current month.
 * Scope:
 * - Creates only new PORTAL ledger rows for Google events that are not already linked.
 * - Does not modify existing PORTAL rows.
 * - Does not touch NAVER.
 * - Does not auto-run; called only from the calendar screen button.
 */
function portalCalendarStep07GoogleInboundManualSyncV01(request) {
  request = request || {};
  var result = {
    ok: false,
    build: 'PORTAL_CALENDAR_STEP07_GOOGLE_INBOUND_FIXED_CALENDAR_POLICY_V06_20260601',
    action: 'portalCalendarStep07GoogleInboundManualSyncV01',
    step07SafePreviewMarker: 'PORTAL_CALENDAR_STEP07_GOOGLE_INBOUND_FIXED_CALENDAR_POLICY_V06_20260601',
    safety: 'GOOGLE_READ_PORTAL_LEDGER_APPEND_ONLY_NO_EXISTING_ROW_UPDATE_NO_NAVER',
    scope: 'GOOGLE_TO_PORTAL_MANUAL_CURRENT_MONTH_PREVIEW_CONFIRM_APPEND_ONLY',
    summary: { scannedGoogle: 0, candidates: 0, created: 0, skippedExisting: 0, skippedPortalLinked: 0, skippedInvalid: 0, skippedUnsafe: 0, skippedNotSelected: 0, failed: 0 },
    details: [],
    fatal: [],
    warnings: [],
    generatedAt: Utilities.formatDate(new Date(), 'Asia/Seoul', 'yyyy-MM-dd HH:mm:ss')
  };
  try {
    var configBundle = mcCalendar19GetConfigBundle_();
    var profile = mcCalendar186ResolveCalendarActor_(request, configBundle, { allowFallback: true });
    if (!mcCalendar186HasPermission_(profile, 'CALENDAR_EDIT')) mcCalendar186PermissionGuard_(profile, 'CALENDAR_CREATE');
    var cfg = configBundle.config || {};
    var policy = portalCalendarStep07GoogleInboundResolveCalendarPolicyV06_(configBundle, profile, request);
    var sourceCalendars = portalCalendarStep07GoogleInboundSourceCalendarsV06_(policy.googleCalendarId, policy);
    if (!sourceCalendars.length) throw new Error('Google 가져오기 대상 캘린더를 찾을 수 없습니다.');
    result.calendarPolicy = { policyType: policy.policyType, vendorId: policy.vendorId || '', googleCalendarId: policy.googleCalendarId || '', naverAllowed: policy.naverAllowed === true };
    result.sourceCalendars = sourceCalendars.map(function(item){ return { calendarId: item.id, calendarName: item.name, policyType: policy.policyType }; });

    var year = Number(request.year || Utilities.formatDate(new Date(), 'Asia/Seoul', 'yyyy'));
    var month = Number(request.month || Utilities.formatDate(new Date(), 'Asia/Seoul', 'M'));
    if (!year || !month || month < 1 || month > 12) throw new Error('year/month 값이 올바르지 않습니다.');
    var fromDate = new Date(year, month - 1, 1, 0, 0, 0);
    var toDate = new Date(year, month, 1, 0, 0, 0);
    var maxCreate = Math.max(1, Math.min(Number(request.maxCreate || 20), 50));
    var previewOnly = request.previewOnly === true;
    var allowedIds = portalCalendarStep07GoogleInboundAllowedIdMap_(request.candidateGoogleEventIds || request.allowedGoogleEventIds || []);

    var ss = mcCalendar19OpenMaster_(configBundle);
    mcCalendar186EnsureCalendarModuleSheets_(ss);
    var headers = mcCalendar186CalendarEventHeaders_();
    var sheet = mcCalendar19GetSheetOrCreate_(ss, 'MAILCENTER_CalendarEvents', headers);
    var existing = portalCalendarStep07GoogleInboundExistingMap_(sheet);
    var events = portalCalendarStep07GoogleInboundCollectEventsV06_(sourceCalendars, fromDate, toDate);
    result.summary.scannedGoogle = events.length;

    for (var i = 0; i < events.length; i++) {
      if (result.summary.created >= maxCreate) {
        result.warnings.push('maxCreate limit reached: ' + maxCreate);
        break;
      }
      var wrap = events[i] || {};
      var ev = wrap.event;
      var eventCalendarId = wrap.calendarId || googleCalendarId;
      var eventCalendarName = wrap.calendarName || '';
      var googleEventId = String(ev.getId() || '').trim();
      if (!googleEventId) { result.summary.skippedInvalid++; continue; }
      if (existing.googleEventIds[googleEventId]) {
        result.summary.skippedExisting++;
        result.details.push({ action: 'SKIP_EXISTING_GOOGLE_ID', googleEventId: googleEventId, title: ev.getTitle() || '' });
        continue;
      }
      var safe = portalCalendarStep07GoogleInboundSafetyCheck_(ev);
      if (!safe.ok) {
        result.summary.skippedUnsafe++;
        result.details.push({ action: 'SKIP_UNSAFE_GOOGLE_EVENT', googleEventId: googleEventId, title: ev.getTitle() || '', reason: safe.reason });
        continue;
      }
      var desc = String(ev.getDescription() || '');
      var portalId = portalCalendarStep07GoogleInboundExtractPortalId_(desc);
      if (portalId) {
        result.summary.skippedPortalLinked++;
        result.details.push({ action: 'SKIP_PORTAL_MARKER_LINKED', calendarEventId: portalId, googleEventId: googleEventId, title: ev.getTitle() || '' });
        continue;
      }
      var candidate = portalCalendarStep07GoogleInboundCandidate_(ev, googleEventId, eventCalendarId, eventCalendarName);
      result.summary.candidates++;
      if (previewOnly) {
        result.details.push(candidate);
        continue;
      }
      if (Object.keys(allowedIds).length && !allowedIds[googleEventId]) {
        result.summary.skippedNotSelected++;
        result.details.push({ action: 'SKIP_NOT_SELECTED_BY_PREVIEW', googleEventId: googleEventId, title: ev.getTitle() || '' });
        continue;
      }
      try {
        var record = portalCalendarStep07GoogleInboundBuildRecord_(ev, googleEventId, eventCalendarId, profile);
        mcCalendar19AppendByHeader_(sheet, record, headers);
        existing.googleEventIds[googleEventId] = true;
        existing.portalIds[record.calendarEventId] = true;
        result.summary.created++;
        result.details.push({ action: 'CREATE_PORTAL_FROM_GOOGLE', calendarEventId: record.calendarEventId, googleEventId: googleEventId, title: record.eventTitle });
        portalCalendarStep07GoogleInboundAppendLog_(ss, record.calendarEventId, googleEventId, 'SUCCESS', 'Google Calendar 수동 가져오기 생성 완료', profile);
      } catch (rowErr) {
        result.summary.failed++;
        result.details.push({ action: 'CREATE_PORTAL_FROM_GOOGLE_FAIL', googleEventId: googleEventId, message: portalCalendarStep07GoogleInboundError_(rowErr) });
      }
    }

    result.ok = result.summary.failed === 0;
    result.message = previewOnly ? 'Google Calendar 가져오기 미리보기 완료' : (result.ok ? 'Google Calendar 수동 가져오기 완료' : 'Google Calendar 수동 가져오기 일부 실패');
  } catch (err) {
    result.ok = false;
    result.fatal.push(portalCalendarStep07GoogleInboundError_(err));
    result.message = portalCalendarStep07GoogleInboundError_(err);
  }
  try { Logger.log('JSON_COMPACT_RESULT: ' + JSON.stringify(result)); } catch (ignore) {}
  return mcCalendar19ClientSafeObject_(result);
}




function portalCalendarStep07GoogleInboundResolveCalendarPolicyV06_(configBundle, profile, request) {
  var cfg = (configBundle && configBundle.config) || {};
  var actor = profile || {};
  var vendorId = String((request && request.vendorId) || actor.vendorId || actor.vendorID || '').trim();
  var isHq = portalCalendarStep07GoogleInboundIsHqActorV06_(actor, vendorId);
  var calendarId = '';
  var policyType = '';
  if (isHq) {
    calendarId = String((request && request.googleCalendarId) || mcCalendar19PickConfig_(cfg, ['HQ_GOOGLE_CALENDAR_ID','PORTAL_GOOGLE_CALENDAR_ID','GOOGLE_CALENDAR_ID']) || '').trim();
    policyType = 'HQ_FIXED_GOOGLE_CALENDAR';
  } else {
    calendarId = portalCalendarStep07GoogleInboundVendorCalendarIdV06_(configBundle, vendorId, request);
    policyType = 'VENDOR_FIXED_GOOGLE_CALENDAR';
  }
  if (!calendarId) {
    throw new Error(isHq ? 'HQ_GOOGLE_CALENDAR_ID 설정이 필요합니다.' : '업체 대표 Google Calendar ID 설정이 필요합니다: ' + vendorId);
  }
  return {
    policyType: policyType,
    googleCalendarId: calendarId,
    vendorId: vendorId,
    naverAllowed: isHq,
    actorRoleCode: String(actor.roleCode || actor.role || '').trim()
  };
}

function portalCalendarStep07GoogleInboundIsHqActorV06_(profile, vendorId) {
  var role = String((profile && (profile.roleCode || profile.role || profile.userRole)) || '').toUpperCase();
  var vendor = String(vendorId || '').trim();
  if (!vendor) return true;
  if (role.indexOf('SUPER') >= 0 || role.indexOf('ADMIN') >= 0 || role.indexOf('HQ') >= 0 || role.indexOf('본사') >= 0) return true;
  return false;
}

function portalCalendarStep07GoogleInboundVendorCalendarIdV06_(configBundle, vendorId, request) {
  var cfg = (configBundle && configBundle.config) || {};
  vendorId = String(vendorId || '').trim();
  var direct = String((request && request.googleCalendarId) || '').trim();
  if (direct) return direct;
  var keys = [];
  if (vendorId) {
    keys.push('VENDOR_GOOGLE_CALENDAR_ID_' + vendorId);
    keys.push('GOOGLE_CALENDAR_ID_' + vendorId);
  }
  keys.push('VENDOR_GOOGLE_CALENDAR_ID');
  var byConfig = String(mcCalendar19PickConfig_(cfg, keys) || '').trim();
  if (byConfig) return byConfig;
  try {
    var ss = mcCalendar19OpenMaster_(configBundle);
    var names = ['VendorGoogleCalendarMap','VENDOR_GOOGLE_CALENDAR_MAP','ERP_VendorGoogleCalendarMap','ERP_Vendors','Vendors'];
    for (var i = 0; i < names.length; i++) {
      var sh = ss.getSheetByName(names[i]);
      if (!sh) continue;
      var values = sh.getDataRange().getValues();
      if (!values || values.length < 2) continue;
      var hm = mcCalendar19HeaderMap_(values[0]);
      var vendorCol = hm.vendorId !== undefined ? hm.vendorId : (hm.vendorID !== undefined ? hm.vendorID : -1);
      var calCol = hm.googleCalendarId !== undefined ? hm.googleCalendarId : (hm.googleCalendarID !== undefined ? hm.googleCalendarID : (hm.calendarId !== undefined ? hm.calendarId : -1));
      var enabledCol = hm.googleSyncEnabled !== undefined ? hm.googleSyncEnabled : (hm.syncEnabled !== undefined ? hm.syncEnabled : -1);
      if (vendorCol < 0 || calCol < 0) continue;
      for (var r = 1; r < values.length; r++) {
        if (String(values[r][vendorCol] || '').trim() !== vendorId) continue;
        if (enabledCol >= 0) {
          var enabled = String(values[r][enabledCol] || '').toUpperCase();
          if (enabled && enabled !== 'TRUE' && enabled !== 'Y' && enabled !== 'YES' && enabled !== '1') continue;
        }
        var found = String(values[r][calCol] || '').trim();
        if (found) return found;
      }
    }
  } catch (ignore) {}
  return '';
}

function portalCalendarStep07GoogleInboundSourceCalendarsV06_(fixedCalendarId, policy) {
  var cal = null;
  try { cal = CalendarApp.getCalendarById(String(fixedCalendarId || '').trim()); } catch (ignore) { cal = null; }
  if (!cal) throw new Error('고정 Google Calendar ID 캘린더를 찾을 수 없습니다: ' + fixedCalendarId);
  var name = '';
  try { name = String(cal.getName ? cal.getName() : fixedCalendarId); } catch (ignore2) { name = String(fixedCalendarId || ''); }
  return [{ id: String(fixedCalendarId || '').trim(), name: name, calendar: cal, reason: (policy && policy.policyType) || 'FIXED_CALENDAR_POLICY' }];
}

function portalCalendarStep07GoogleInboundCollectEventsV06_(sourceCalendars, fromDate, toDate) {
  var out = [];
  for (var c = 0; c < sourceCalendars.length; c++) {
    var item = sourceCalendars[c];
    var events = [];
    try { events = item.calendar.getEvents(fromDate, toDate) || []; } catch (err) { events = []; }
    for (var i = 0; i < events.length; i++) {
      out.push({ event: events[i], calendarId: item.id, calendarName: item.name });
    }
  }
  return out;
}

function portalCalendarStep07GoogleInboundAllowedIdMap_(ids) {
  var out = {};
  if (!ids || !ids.length) return out;
  for (var i = 0; i < ids.length; i++) {
    var id = String(ids[i] || '').trim();
    if (id) out[id] = true;
  }
  return out;
}

function portalCalendarStep07GoogleInboundSafetyCheck_(ev) {
  var title = String(ev && ev.getTitle ? ev.getTitle() : '').trim();
  var lowered = title.toLowerCase();
  if (!title) return { ok: false, reason: 'EMPTY_TITLE' };
  if (title === '제목 없음' || title === '시작 제목 없음' || title === '종료 제목 없음') return { ok: false, reason: 'UNTITLED_SYSTEM_EVENT' };
  if (lowered === 'no title' || lowered === 'untitled' || lowered.indexOf('untitled') >= 0) return { ok: false, reason: 'UNTITLED_SYSTEM_EVENT' };
  try {
    if (ev.isAllDayEvent && ev.isAllDayEvent()) return { ok: false, reason: 'ALL_DAY_EVENT_EXCLUDED_FOR_STEP07_SAFE_PREVIEW' };
  } catch (ignore) {}
  return { ok: true, reason: '' };
}

function portalCalendarStep07GoogleInboundCandidate_(ev, googleEventId, googleCalendarId, googleCalendarName) {
  return {
    action: 'PREVIEW_GOOGLE_EVENT_CANDIDATE',
    googleEventId: googleEventId,
    googleCalendarId: googleCalendarId || '',
    googleCalendarName: googleCalendarName || '',
    title: String(ev.getTitle() || ''),
    startAt: portalCalendarStep07GoogleInboundFormatDate_(ev.getStartTime()),
    endAt: portalCalendarStep07GoogleInboundFormatDate_(ev.getEndTime())
  };
}

function portalCalendarStep07GoogleInboundExistingMap_(sheet) {
  var out = { googleEventIds: {}, portalIds: {} };
  var values = sheet.getDataRange().getValues();
  if (!values || values.length < 2) return out;
  var hm = mcCalendar19HeaderMap_(values[0]);
  for (var r = 1; r < values.length; r++) {
    var ce = hm.calendarEventId !== undefined ? String(values[r][hm.calendarEventId] || '').trim() : '';
    var g1 = hm.googleProviderEventId !== undefined ? String(values[r][hm.googleProviderEventId] || '').trim() : '';
    var g2 = hm.providerEventId !== undefined ? String(values[r][hm.providerEventId] || '').trim() : '';
    var g3 = hm.googleEventId !== undefined ? String(values[r][hm.googleEventId] || '').trim() : '';
    if (ce) out.portalIds[ce] = true;
    if (g1) out.googleEventIds[g1] = true;
    if (g2) out.googleEventIds[g2] = true;
    if (g3) out.googleEventIds[g3] = true;
  }
  return out;
}

function portalCalendarStep07GoogleInboundBuildRecord_(ev, googleEventId, googleCalendarId, profile) {
  var now = portalCalendarStep07GoogleInboundNow_();
  var calendarEventId = 'GCAL-IN-' + Utilities.formatDate(new Date(), 'Asia/Seoul', 'yyyyMMddHHmmss') + '-' + Utilities.getUuid().substring(0, 8).toUpperCase();
  var title = String(ev.getTitle() || '(Google 일정)');
  var desc = String(ev.getDescription() || '');
  var location = '';
  try { location = String(ev.getLocation ? ev.getLocation() : ''); } catch (ignore) { location = ''; }
  return {
    calendarEventId: calendarEventId,
    eventId: '',
    customerId: '',
    contractId: '',
    installId: '',
    asId: '',
    requestId: '',
    provider: 'GOOGLE_SYNC',
    providerEventId: googleEventId,
    eventType: 'GOOGLE_IMPORTED',
    eventTitle: title,
    eventDescription: desc,
    startAt: portalCalendarStep07GoogleInboundFormatDate_(ev.getStartTime()),
    endAt: portalCalendarStep07GoogleInboundFormatDate_(ev.getEndTime()),
    allDayYn: ev.isAllDayEvent && ev.isAllDayEvent() ? 'Y' : 'N',
    location: location,
    attendees: '',
    ownerEmployeeId: profile.employeeId || profile.loginId || '',
    assignedEmployeeId: profile.employeeId || profile.loginId || '',
    eventStatus: 'REGISTERED',
    naverRegisterStatus: 'SKIPPED',
    naverProviderEventId: '',
    naverErrorCode: '',
    naverErrorMessage: 'NAVER inbound auto sync excluded by policy',
    googleBackupStatus: 'SUCCESS',
    googleProviderEventId: googleEventId,
    googleErrorCode: '',
    googleErrorMessage: 'GOOGLE_INBOUND_MANUAL:' + googleCalendarId,
    retryCount: 0,
    lastRetryAt: '',
    createdAt: now,
    createdBy: profile.employeeId || profile.loginId || '',
    updatedAt: now,
    updatedBy: profile.employeeId || profile.loginId || ''
  };
}

function portalCalendarStep07GoogleInboundAppendLog_(ss, calendarEventId, googleEventId, status, message, profile) {
  try {
    var headers = mcCalendar186CalendarLogHeaders_();
    var sheet = mcCalendar19GetSheetOrCreate_(ss, 'MAILCENTER_CalendarLogs', headers);
    mcCalendar19AppendByHeader_(sheet, {
      calendarLogId: 'MCALLOG-' + Utilities.getUuid(),
      calendarEventId: calendarEventId || '',
      provider: 'GOOGLE_INBOUND',
      actionType: 'CREATE_PORTAL_FROM_GOOGLE_MANUAL',
      resultStatus: status || '',
      providerEventId: googleEventId || '',
      errorCode: '',
      errorMessage: '',
      requestPayloadSummary: '',
      responseSummary: message || '',
      createdAt: portalCalendarStep07GoogleInboundNow_(),
      createdBy: profile && (profile.employeeId || profile.loginId) || ''
    }, headers);
  } catch (ignore) {}
}

function portalCalendarStep07GoogleInboundExtractPortalId_(description) {
  var m = String(description || '').match(/\[PORTAL_CALENDAR_EVENT_ID:([^\]]+)\]/);
  return m ? String(m[1] || '').trim() : '';
}

function portalCalendarStep07GoogleInboundFormatDate_(dateValue) {
  return Utilities.formatDate(dateValue, 'Asia/Seoul', 'yyyy-MM-dd HH:mm:ss');
}

function portalCalendarStep07GoogleInboundNow_() {
  return Utilities.formatDate(new Date(), 'Asia/Seoul', 'yyyy-MM-dd HH:mm:ss');
}

function portalCalendarStep07GoogleInboundError_(err) {
  if (!err) return '';
  if (err.message) return String(err.message);
  return String(err);
}
