/**
 * PORTAL_CALENDAR_SAFE01B_R10K1E_DETAIL_FACE_VERIFY_ROOT_CAUSE_20260604
 * Safety: READ_ONLY_RUNTIME_VERIFY_NO_SHEET_PROVIDER_WRITE
 * Purpose:
 *  - Verify R10K1 detail face UI by inspecting MC_CalendarViewV01.html source.
 *  - Do not inspect client functions as Apps Script server globals.
 *  - Diagnose exact source locations for hero CSS and legacy body empty text.
 *  - Treat safe fallback text inside fhCalendarDisplayBodyV05 as diagnostic, not fatal.
 */
function portalCalendarSafe01BR10K1DDetailFaceVerify() {
  return portalCalendarSafe01BR10K1DetailFaceVerify();
}

function portalCalendarSafe01BR10K1EDetailFaceVerify() {
  return portalCalendarSafe01BR10K1DetailFaceVerify();
}

function portalCalendarSafe01BR10K1DetailFaceVerify() {
  var BUILD = 'PORTAL_CALENDAR_SAFE01B_R10K1E_DETAIL_FACE_VERIFY_ROOT_CAUSE_20260604';
  var BASE_BUILD = 'PORTAL_CALENDAR_SAFE01B_R10K1_DETAIL_FACE_BODY_FIX_20260603';
  var ACTION = 'portalCalendarSafe01BR10K1DetailFaceVerify';
  var html = '';
  var readError = '';

  try {
    html = HtmlService.createTemplateFromFile('MC_CalendarViewV01').getRawContent();
  } catch (e1) {
    try {
      html = HtmlService.createHtmlOutputFromFile('MC_CalendarViewV01').getContent();
    } catch (e2) {
      readError = String(e2 && e2.message ? e2.message : e2);
      html = '';
    }
  }

  function has(s) { return html.indexOf(s) !== -1; }
  function re(r) { return r.test(html); }
  function lineNumberAt(index) {
    if (index < 0) return -1;
    return html.substring(0, index).split('\n').length;
  }
  function contextAt(index, needle) {
    if (index < 0) return '';
    var size = 220;
    var end = index + String(needle || '').length;
    return html.substring(Math.max(0, index - size), Math.min(html.length, end + size));
  }
  function functionNameAt(index) {
    if (index < 0) return '';
    var before = html.substring(0, index);
    var rx = /function\s+([A-Za-z0-9_$]+)\s*\(/g;
    var m;
    var last = '';
    while ((m = rx.exec(before)) !== null) last = m[1];
    return last;
  }
  function isInsideTopLevelFunction(index, fnName) {
    if (index < 0) return false;
    var marker = 'function ' + fnName + '(';
    var start = html.indexOf(marker);
    if (start < 0 || index < start) return false;
    var next = html.indexOf('\nfunction ', start + marker.length);
    return next < 0 || index < next;
  }
  function firstNeedleMatch(needles) {
    var best = null;
    for (var i = 0; i < needles.length; i++) {
      var needle = needles[i];
      var idx = html.indexOf(needle);
      if (idx !== -1 && (!best || idx < best.matchIndex)) {
        best = { needle: needle, matchIndex: idx };
      }
    }
    if (!best) {
      return {
        found: false,
        matchedNeedle: '',
        matchIndex: -1,
        lineNumber: -1,
        enclosingFunction: '',
        contextBefore: '',
        contextAfter: '',
        context: ''
      };
    }
    var ctx = contextAt(best.matchIndex, best.needle);
    return {
      found: true,
      matchedNeedle: best.needle,
      matchIndex: best.matchIndex,
      lineNumber: lineNumberAt(best.matchIndex),
      enclosingFunction: functionNameAt(best.matchIndex),
      contextBefore: html.substring(Math.max(0, best.matchIndex - 220), best.matchIndex),
      contextAfter: html.substring(best.matchIndex + best.needle.length, Math.min(html.length, best.matchIndex + best.needle.length + 220)),
      context: ctx
    };
  }

  var oldEmptyTextNeedles = ['별도 본문 없음', '본문 없음'];
  var oldBodyTitleNeedles = ['2. 업무 본문'];
  var oldAttendeeNeedles = ['[참석자]'];
  var heroCssNeedles = [
    'calendar-detail-hero',
    'detail-hero',
    'fh-detail-hero',
    'cal-k1-hero',
    'cal-k1-hero-head',
    'cal-k1-hero-title',
    'cal-k1-hero-sub'
  ];

  var oldEmptyTextMatch = firstNeedleMatch(oldEmptyTextNeedles);
  var oldBodyTitleMatch = firstNeedleMatch(oldBodyTitleNeedles);
  var oldAttendeeMatch = firstNeedleMatch(oldAttendeeNeedles);
  var heroCssMatch = firstNeedleMatch(heroCssNeedles);

  var oldTitleRemoved = !oldBodyTitleMatch.found;
  var oldAttendeeLabelRemoved = !oldAttendeeMatch.found;
  var bodySectionBlank = re(/var\s+bodySectionR10H\s*=\s*['"]{2}\s*;/) || re(/bodySectionR10H\s*=\s*['"]{2}/);
  var newBodySectionPresent = has('업무 본문 / 외부 캘린더 본문');
  var googleNaverPreviewPresent = has('Google/NAVER');
  var heroCssReady = heroCssMatch.found;

  // R10K1E decision:
  // Empty-text fallback inside fhCalendarDisplayBodyV05 is not legacy UI residue.
  // It is reported for root-cause visibility but must not fail the detail-face check.
  var oldEmptyTextRemoved = !oldEmptyTextMatch.found;
  var oldEmptyTextSafeFallback = oldEmptyTextMatch.found && isInsideTopLevelFunction(oldEmptyTextMatch.matchIndex, 'fhCalendarDisplayBodyV05');
  var oldEmptyTextBlocksLegacyRemoval = oldEmptyTextMatch.found && !oldEmptyTextSafeFallback;
  var legacyBodyBlinkRemoved = oldTitleRemoved && oldAttendeeLabelRemoved && bodySectionBlank && newBodySectionPresent && googleNaverPreviewPresent && !oldEmptyTextBlocksLegacyRemoval;

  var checks = {
    viewR10K1MarkerPresent: has('PORTAL_CALENDAR_SAFE01B_R10K1_DETAIL_FACE_BODY_FIX_20260603') || has('R10K1'),
    r10j5FieldBalanceKept: has('R10J5') || has('레거시/공통 원장') || has('최종 협약 조건'),
    r10j4BasicInfoKept: has('scheduleSummary') && has('processStatus') && has('primaryOwnerName'),
    r10j2ScreenLayoutKept: has('사전영업 / 선정관리') || has('행사관리 원장 요약') || has('일반 / 기타 일정'),
    detailFaceFunctionReady: has('fhCalendarDetailFaceR10K'),
    firstSectionRenamed: has('오늘 업무 브리핑') || has('1. 오늘 업무 요약'),
    heroCssReady: heroCssReady,
    basicCardsCollapsedReady: has('기본 원장 카드 더보기') || has('기본정보 원장 카드') || has('details'),
    staffParticipationVisible: has('필하우스 주담당') && (has('참여 직원') || has('participantJson')),
    followUpVisible: has('대표 다음 액션') || (has('nextActionOwner') && has('followUpRequiredYn')),
    selectionCoreVisible: has('박람회 선정 과정 핵심') || (has('complexName') && has('contactTargetType') && has('agreementStatus')),
    generalScheduleCoreVisible: has('일반 / 기타 일정') && (has('approvalId') || has('displayPrivacyMode')),
    legacyBodyBlinkRemoved: legacyBodyBlinkRemoved,
    bodyExternalSectionReady: newBodySectionPresent,
    externalPreviewReady: googleNaverPreviewPresent && (has('전송 본문') || has('본문 미리보기')),
    bodyInsertedAfterBusiness: has('bodyInsertedAfterBusiness') || has('fhCalendarBodyExternalSectionR10K') || has('업무 본문 / 외부 캘린더 본문'),
    noExtractedTempMarker: !has('extracted_view') && !has('extracted_view_check'),
    verifyUsesHtmlSourceNotServerGlobals: true
  };

  var fatalKeys = [];
  Object.keys(checks).forEach(function(k) {
    if (!checks[k]) fatalKeys.push(k);
  });
  if (readError) fatalKeys.push('viewHtmlReadError');

  var diagnostics = {
    oldEmptyTextNeedles: oldEmptyTextNeedles,
    matchedNeedle: oldEmptyTextMatch.matchedNeedle,
    matchIndex: oldEmptyTextMatch.matchIndex,
    lineNumber: oldEmptyTextMatch.lineNumber,
    enclosingFunction: oldEmptyTextMatch.enclosingFunction,
    insideDisplayBodyV05: isInsideTopLevelFunction(oldEmptyTextMatch.matchIndex, 'fhCalendarDisplayBodyV05'),
    contextBefore: oldEmptyTextMatch.contextBefore,
    contextAfter: oldEmptyTextMatch.contextAfter,
    oldEmptyTextRemoved: oldEmptyTextRemoved,
    oldEmptyTextSafeFallback: oldEmptyTextSafeFallback,
    oldEmptyTextBlocksLegacyRemoval: oldEmptyTextBlocksLegacyRemoval,
    oldBodyTitleMatch: oldBodyTitleMatch,
    oldAttendeeMatch: oldAttendeeMatch,
    heroCssNeedles: heroCssNeedles,
    heroCssMatched: heroCssMatch.found,
    heroCssMatchedNeedle: heroCssMatch.matchedNeedle,
    heroCssLineNumber: heroCssMatch.lineNumber,
    heroCssContext: heroCssMatch.context
  };

  var result = {
    ok: fatalKeys.length === 0,
    build: BUILD,
    baseBuild: BASE_BUILD,
    action: ACTION,
    safety: 'READ_ONLY_RUNTIME_VERIFY_NO_SHEET_PROVIDER_WRITE',
    checks: checks,
    diagnostics: diagnostics,
    warnings: oldEmptyTextSafeFallback ? ['oldEmptyText remains only as safe fallback inside fhCalendarDisplayBodyV05'] : [],
    fatal: fatalKeys,
    summary: {
      mode: 'detail face first + collapsed raw basic cards + internal body/external calendar preview',
      preserved: 'R10J5/R10J4/R10J2 structures kept, no sheet/provider writes',
      verifyFix: 'R10K1E accepts cal-k1-hero and separates safe body fallback text from legacy UI residue',
      legacyBodyRemoved: legacyBodyBlinkRemoved,
      legacyBodyConditions: {
        oldTitleRemoved: oldTitleRemoved,
        oldEmptyTextRemoved: oldEmptyTextRemoved,
        oldEmptyTextSafeFallback: oldEmptyTextSafeFallback,
        oldEmptyTextBlocksLegacyRemoval: oldEmptyTextBlocksLegacyRemoval,
        oldAttendeeLabelRemoved: oldAttendeeLabelRemoved,
        bodySectionBlank: bodySectionBlank,
        newBodySectionPresent: newBodySectionPresent,
        googleNaverPreviewPresent: googleNaverPreviewPresent
      },
      htmlLength: html.length,
      readError: readError
    },
    message: fatalKeys.length === 0
      ? 'SAFE-01B R10K1E detail face verification passed.'
      : 'SAFE-01B R10K1E detail face verification failed. Check fatal items and diagnostics.'
  };

  Logger.log('JSON_COMPACT_RESULT: ' + JSON.stringify(result));
  return result;
}
