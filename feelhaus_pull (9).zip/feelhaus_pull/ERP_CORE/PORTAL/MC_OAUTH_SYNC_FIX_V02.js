
/**
 * MC OAuth status sync/fix V02
 * Build: MC_OAUTH_SYNC_FIX_V02_20260527
 * Purpose:
 * - Google OAuth callback이 PORTAL_MailAccounts 쪽 mailAccountId로 완료되고,
 *   MailCenter_Accounts의 현재 mailAccountId와 불일치하는 경우를 emailAddress 기준으로 동기화한다.
 * - 중복/과거 OAuth row 때문에 PENDING_AUTH가 CONNECTED를 덮어쓰는 문제를 방지한다.
 */
var MC_OAUTH_SYNC_FIX_V02_BUILD = 'MC_OAUTH_SYNC_FIX_V02_20260527';

function mcOAuthSync() {
  return mcOAuthSyncV02Run_({apply:true});
}

function mcOAuthFail() {
  var r = mcOAuthSyncV02Run_({apply:false});
  var fails = [];
  if (!r.ok) fails.push({name:'oauth sync', ok:false, message:r.message});
  if (r.summary.connectedMailCenterAccounts < 1) fails.push({name:'connected account count', ok:false, message:'MailCenter CONNECTED account is 0'});
  return {ok:fails.length===0, build:'MC_OAUTH_FAIL', failedResults:fails, summary:{fail:fails.length, connected:r.summary.connectedMailCenterAccounts}};
}

function mcOAuthSyncV02Run_(opt) {
  var apply = !!(opt && opt.apply);
  var result = {ok:false, build:MC_OAUTH_SYNC_FIX_V02_BUILD, applied:apply, checkedAt:mcOAuthSyncV02Now_(), message:'', summary:{portalConnected:0, mailCenterAccounts:0, connectedMailCenterAccounts:0, updatedOAuthRows:0, updatedAccountRows:0}, updates:[]};
  try {
    var ss = mcOAuthSyncV02OpenMaster_();
    var portalAccounts = mcOAuthSyncV02Read_(ss, 'PORTAL_MailAccounts');
    var mcAccounts = mcOAuthSyncV02Read_(ss, 'MailCenter_Accounts');
    var connectedByEmail = {};
    portalAccounts.forEach(function(p){
      var email = String(p.emailAddress || '').trim().toLowerCase();
      if (!email) return;
      if (String(p.authStatus || '').toUpperCase() !== 'CONNECTED') return;
      var old = connectedByEmail[email];
      if (!old || String(p.lastConnectedAt || '') >= String(old.lastConnectedAt || '')) connectedByEmail[email] = p;
    });

    result.summary.portalConnected = Object.keys(connectedByEmail).length;
    result.summary.mailCenterAccounts = mcAccounts.length;

    mcAccounts.forEach(function(a){
      var email = String(a.emailAddress || '').trim().toLowerCase();
      if (!email) return;
      var p = connectedByEmail[email];
      if (!p) return;
      var now = mcOAuthSyncV02Now_();
      var connectedAt = p.lastConnectedAt || now;
      var row = {
        oauthConnectionId: 'OAUTH-SYNC-' + String(a.mailAccountId || '').replace(/[^A-Za-z0-9_-]/g,'_'),
        mailAccountId: a.mailAccountId || '',
        connectorMailAccountId: p.mailAccountId || '',
        vendorId: a.vendorId || p.vendorId || '',
        emailAddress: a.emailAddress || p.emailAddress || '',
        provider: a.provider || 'GMAIL',
        oauthStatus: 'CONNECTED',
        authUrl: '',
        redirectUri: '',
        lastConnectedAt: connectedAt,
        lastCheckedAt: now,
        lastError: '',
        createdAt: now,
        createdBy: 'MC_OAUTH_SYNC_FIX_V02',
        updatedAt: now,
        updatedBy: 'MC_OAUTH_SYNC_FIX_V02'
      };
      result.updates.push({emailAddress:a.emailAddress, mailAccountId:a.mailAccountId, connectorMailAccountId:p.mailAccountId, oauthStatus:'CONNECTED'});
      if (apply) {
        mcOAuthSyncV02Upsert_(ss, 'MailCenter_OAuthConnections', ['oauthConnectionId','mailAccountId','connectorMailAccountId','vendorId','emailAddress','provider','oauthStatus','authUrl','redirectUri','lastConnectedAt','lastCheckedAt','lastError','createdAt','createdBy','updatedAt','updatedBy'], 'oauthConnectionId', row);
        mcOAuthSyncV02PatchAccount_(ss, a.mailAccountId, connectedAt);
        result.summary.updatedOAuthRows++;
        result.summary.updatedAccountRows++;
      }
    });

    var oauthRows = mcOAuthSyncV02Read_(ss, 'MailCenter_OAuthConnections');
    var mcById = {}, mcByEmail = {};
    mcAccounts.forEach(function(a){ mcById[String(a.mailAccountId||'')] = a; mcByEmail[String(a.emailAddress||'').toLowerCase()] = a; });
    result.summary.connectedMailCenterAccounts = mcAccounts.filter(function(a){
      var id = String(a.mailAccountId||'');
      var email = String(a.emailAddress||'').toLowerCase();
      return oauthRows.concat(apply ? result.updates.map(function(u){return {mailAccountId:u.mailAccountId,emailAddress:u.emailAddress,oauthStatus:'CONNECTED'};}) : []).some(function(o){
        return String(o.oauthStatus||'').toUpperCase()==='CONNECTED' && (String(o.mailAccountId||'')===id || String(o.emailAddress||'').toLowerCase()===email);
      });
    }).length;

    result.ok = true;
    result.message = apply ? 'OAuth CONNECTED 상태 동기화 완료' : 'OAuth CONNECTED 상태 점검 완료';
  } catch (err) {
    result.ok = false;
    result.message = String(err && err.message ? err.message : err);
  }
  Logger.log(JSON.stringify(result));
  return result;
}

function mcOAuthSyncV02PatchAccount_(ss, mailAccountId, connectedAt) {
  var sh = ss.getSheetByName('MailCenter_Accounts');
  if (!sh) return;
  var values = sh.getDataRange().getValues();
  if (values.length < 2) return;
  var hm = mcOAuthSyncV02HeaderMap_(values[0]);
  for (var r=1; r<values.length; r++) {
    if (String(values[r][hm.mailAccountId] || '') === String(mailAccountId || '')) {
      mcOAuthSyncV02Set_(sh, hm, r+1, 'lastConnectedAt', connectedAt);
      mcOAuthSyncV02Set_(sh, hm, r+1, 'lastSyncAt', mcOAuthSyncV02Now_());
      mcOAuthSyncV02Set_(sh, hm, r+1, 'updatedAt', mcOAuthSyncV02Now_());
      mcOAuthSyncV02Set_(sh, hm, r+1, 'updatedBy', 'MC_OAUTH_SYNC_FIX_V02');
      return;
    }
  }
}

function mcOAuthSyncV02OpenMaster_() {
  if (typeof portal19GetConfigBundle_ === 'function' && typeof portal19OpenMaster_ === 'function') {
    var b = portal19GetConfigBundle_();
    var ss = portal19OpenMaster_(b);
    if (ss) return ss;
  }
  if (typeof mailCenterOAuthOpenMasterDb_ === 'function') return mailCenterOAuthOpenMasterDb_();
  throw new Error('FEELHAUS_DB_MASTER 연결 함수를 찾지 못했습니다.');
}

function mcOAuthSyncV02Read_(ss, sheetName) {
  var sh = ss.getSheetByName(sheetName);
  if (!sh) return [];
  var values = sh.getDataRange().getValues();
  if (!values || values.length < 2) return [];
  var heads = values[0].map(function(h){return String(h||'').trim();});
  var out=[];
  for (var r=1; r<values.length; r++) {
    var obj={}, blank=true;
    for (var c=0; c<heads.length; c++) { if (!heads[c]) continue; var v=values[r][c]; if (v!=='' && v!=null) blank=false; obj[heads[c]]=v instanceof Date ? Utilities.formatDate(v, Session.getScriptTimeZone() || 'Asia/Seoul', 'yyyy-MM-dd HH:mm:ss') : v; }
    if (!blank) out.push(obj);
  }
  return out;
}

function mcOAuthSyncV02Upsert_(ss, sheetName, headers, keyName, obj) {
  var sh = ss.getSheetByName(sheetName) || ss.insertSheet(sheetName);
  if (sh.getLastRow() < 1) sh.getRange(1,1,1,headers.length).setValues([headers]);
  var values = sh.getDataRange().getValues();
  var hm = mcOAuthSyncV02HeaderMap_(values[0]);
  headers.forEach(function(h){ if (hm[h] == null) { sh.getRange(1, sh.getLastColumn()+1).setValue(h); }});
  values = sh.getDataRange().getValues();
  hm = mcOAuthSyncV02HeaderMap_(values[0]);
  var rowIndex=-1;
  for (var r=1; r<values.length; r++) if (String(values[r][hm[keyName]]||'') === String(obj[keyName]||'')) { rowIndex=r+1; break; }
  if (rowIndex < 0) { rowIndex = sh.getLastRow()+1; }
  headers.forEach(function(h){ mcOAuthSyncV02Set_(sh, hm, rowIndex, h, obj[h] == null ? '' : obj[h]); });
}

function mcOAuthSyncV02HeaderMap_(heads) { var hm={}; for (var i=0;i<heads.length;i++){ var h=String(heads[i]||'').trim(); if(h) hm[h]=i; } return hm; }
function mcOAuthSyncV02Set_(sh, hm, row, key, val) { if (hm[key] == null) return; sh.getRange(row, hm[key]+1).setValue(val); }
function mcOAuthSyncV02Now_() { return Utilities.formatDate(new Date(), Session.getScriptTimeZone() || 'Asia/Seoul', 'yyyy-MM-dd HH:mm:ss'); }
