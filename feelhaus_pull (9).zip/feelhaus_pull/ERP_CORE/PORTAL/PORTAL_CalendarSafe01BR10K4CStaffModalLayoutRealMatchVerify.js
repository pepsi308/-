function portalCalendarSafe01BR10K4CStaffModalLayoutRealMatchVerify(){
  var build='PORTAL_CALENDAR_SAFE01B_R10K4C_STAFF_MODAL_LAYOUT_REAL_MATCH_20260604';
  var html='';var readError='';
  try{html=HtmlService.createHtmlOutputFromFile('MC_CalendarViewV01').getContent();}catch(e){readError=String(e&&e.message||e);}
  function has(x){return html.indexOf(x)>=0;}
  var checks={
    viewReadable:!!html&&!readError,
    r10k4cBuildMarkerPresent:has(build),
    modalWideReady:has('.cal-modal.r10k4c-wide')&&has('width:min(1360px,98vw)'),
    staffLayoutFrameReady:has('data-r10k4c-staff-layout'),
    firstBriefTopReady:has('1. 오늘 업무 브리핑')&&has('r10k4c-brief-section'),
    typeTabsReady:has('2. 업무 타입 구분')&&has('data-r10k4c-type-tabs'),
    selectedDetailFirstReady:has('3. 행사관리 상세 카드 / ERP_행사관리 원장')&&has('3. 박람회 선정 과정 상세 카드')&&has('3. 일반/기타 일정 상세 카드'),
    oldBusinessSectionRemovedFromMainRender:html.indexOf("'<div class=\"cal-modal-section\"><h3>'+businessSectionTitleR10H+'</h3>'+fhCalendarBusinessModalHtmlR10F")<0,
    bodyMovedToLowerDetail:has('업무 본문 / 외부 캘린더 본문 보기'),
    ledgerCardsMovedToLowerDetail:has('기본 원장 카드 더보기'),
    adminMovedToLowerDetail:has('관리자/진단 보기'),
    r10k2EventMasterKept:has('me_eventMasterPicker')&&has('ERP_행사관리')&&has('fhCalendarR10K2EventMaster'),
    r11AutoRefreshKept:has('fhCalendarStartAutoRefreshR11')&&has('setInterval(fhCalendarCheckPageRefreshR11,30000)'),
    providerWriteNotAddedInR10K4C:html.indexOf('CalendarApp.createEvent')<0&&html.indexOf('UrlFetchApp.fetch')<0,
    noSheetProviderWriteInVerify:true
  };
  var fatal=[];Object.keys(checks).forEach(function(k){if(!checks[k])fatal.push(k);});
  var res={ok:fatal.length===0,build:build,baseBuild:'PORTAL_CALENDAR_SAFE01B_R10K4B_STAFF_CARD_MODAL_REAL_APPLY_20260604',action:'portalCalendarSafe01BR10K4CStaffModalLayoutRealMatchVerify',safety:'READ_ONLY_RUNTIME_VERIFY_NO_SHEET_PROVIDER_WRITE',checks:checks,diagnostics:{htmlLength:html.length,readError:readError},warnings:[],fatal:fatal,summary:{mode:'R10K4C staff modal layout real match',detail:'상세 모달 첫 화면을 이미지형 직원용 대시보드 구조로 재배치',layout:'넓은 모달 + 오늘 업무 브리핑 + 업무 타입 구분 + 선택 업무 상세 카드 우선 표시',lower:'업무본문/원장카드/외부반영/관리자진단은 하단 접힘 영역으로 이동',preserved:'R10K2 ERP_행사관리 eventId 연결과 R11 자동갱신 유지'},message:fatal.length?'R10K4C verification failed.':'R10K4C staff modal layout real match verification passed.'};
  Logger.log('JSON_COMPACT_RESULT: '+JSON.stringify(res));
  return res;
}
function portalCalendarSafe01BR10K4CStaffWorkflowCardVerify(){return portalCalendarSafe01BR10K4CStaffModalLayoutRealMatchVerify();}
function portalCalendarSafe01BR10K4CModalLayoutVerify(){return portalCalendarSafe01BR10K4CStaffModalLayoutRealMatchVerify();}
