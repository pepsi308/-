/**
 * FEELHAUS PORTAL legacy auth compatibility guard - complete replacement
 * BUILD: PORTAL_AUTH_LEGACY_PROFILE_GUARD_COMPLETE_V02_20260530
 * PURPOSE:
 * - Keep existing Portal_Main login path(loginId/passwordHash) untouched.
 * - Prevent legacy portal19LoadUserProfile_/portal19PermissionGuard_ from failing because
 *   PortalUsers no longer has email/permissions headers.
 * - Self-contained helper set for permission load report.
 * - No sheet create/update/delete. No external API.
 */
var PORTAL_AUTH_LEGACY_PROFILE_GUARD_BUILD = 'PORTAL_AUTH_LEGACY_PROFILE_GUARD_COMPLETE_V02_20260530';

function portal19GetCurrentEmail_() {
  var email = Session.getActiveUser().getEmail() || Session.getEffectiveUser().getEmail();
  if (!email) throw new Error('현재 로그인 사용자 이메일을 확인할 수 없습니다. Google Workspace 권한 또는 웹앱 실행 권한을 확인하세요.');
  return String(email).toLowerCase().trim();
}

function portal19LoadUserProfile_(email, configBundle) {
  var ss = portal19OpenMaster_(configBundle);
  var sheet = ss.getSheetByName('PortalUsers');
  if (!sheet) throw new Error('PortalUsers 시트가 없습니다. employeeId/roleCode/vendorId 기준 사용자 확인을 할 수 없습니다.');

  var data = portal19ReadRowsByHeader_(sheet);
  var headers = data.headers || {};
  var required = ['employeeId', 'roleCode', 'status'];
  var missing = [];
  for (var i = 0; i < required.length; i++) {
    if (!headers.hasOwnProperty(required[i])) missing.push(required[i]);
  }
  if (missing.length) throw new Error('PortalUsers 필수 헤더 누락: ' + missing.join(', '));

  var normalizedEmail = String(email || '').toLowerCase().trim();
  var lookupFields = ['email', 'loginEmail', 'loginId'];
  var candidateRows = [];

  for (var r = 0; r < data.rows.length; r++) {
    var row = data.rows[r] || {};
    if (portal19IsBlankUserRow_(row)) continue;
    for (var f = 0; f < lookupFields.length; f++) {
      var key = lookupFields[f];
      if (!headers.hasOwnProperty(key)) continue;
      var value = String(row[key] || '').toLowerCase().trim();
      if (value && value === normalizedEmail) {
        candidateRows.push(row);
        break;
      }
    }
  }

  if (!candidateRows.length) {
    throw new Error('PortalUsers에서 현재 이메일/loginEmail/loginId와 매칭되는 사용자를 찾을 수 없습니다: ' + email);
  }

  var matched = candidateRows[0];
  var status = String(matched.status || 'ACTIVE').toUpperCase().trim();
  var isActive = String(matched.isActive || '').toUpperCase().trim();
  if (status && status !== 'ACTIVE') throw new Error('사용자 계정이 활성 상태가 아닙니다: ' + status);
  if (isActive && isActive !== 'TRUE' && isActive !== 'Y' && isActive !== 'YES' && isActive !== '1') {
    throw new Error('사용자 계정 isActive 값이 활성 기준이 아닙니다: ' + isActive);
  }

  var roleCode = String(matched.roleCode || '').trim();
  var permissions = portal19BuildCompatPermissions_(matched, headers);

  return {
    build: PORTAL_AUTH_LEGACY_PROFILE_GUARD_BUILD,
    email: String(email || ''),
    loginId: String(matched.loginId || ''),
    loginEmail: String(matched.loginEmail || matched.email || email || ''),
    userId: String(matched.userId || ''),
    employeeId: String(matched.employeeId || ''),
    employeeName: String(matched.employeeName || matched.displayName || ''),
    displayName: String(matched.displayName || matched.employeeName || ''),
    roleCode: roleCode,
    roleName: String(matched.roleName || ''),
    vendorId: String(matched.vendorId || ''),
    eventId: String(matched.eventId || ''),
    primaryEventId: String(matched.primaryEventId || ''),
    allowedEventIds: String(matched.allowedEventIds || ''),
    allowedVendorIds: String(matched.allowedVendorIds || ''),
    dataScopeCode: String(matched.dataScopeCode || ''),
    approvalLevel: String(matched.approvalLevel || ''),
    permissions: permissions,
    compatMode: headers.hasOwnProperty('permissions') ? 'EXPLICIT_PERMISSIONS_HEADER' : 'ROLE_AND_FLAG_COMPAT_PERMISSIONS',
    sourceSheet: 'PortalUsers'
  };
}

function portal19IsBlankUserRow_(row) {
  return !String(row.userId || '').trim() &&
    !String(row.loginId || '').trim() &&
    !String(row.loginEmail || '').trim() &&
    !String(row.email || '').trim() &&
    !String(row.employeeId || '').trim() &&
    !String(row.employeeName || '').trim();
}

function portal19BuildCompatPermissions_(row, headers) {
  var permissions = {};
  if (headers && headers.hasOwnProperty('permissions')) {
    permissions = portal19ParsePermissions_(row.permissions);
  }

  var roleCode = String(row.roleCode || '').toUpperCase().trim();
  if (roleCode) permissions['ROLE_' + roleCode] = true;

  if (roleCode === 'SUPER_ADMIN' || roleCode === 'ADMIN' || roleCode === 'DEV' || roleCode === 'HQ_ADMIN') {
    permissions.ALL = true;
    permissions.PORTAL_ACCESS = true;
    permissions.DEV_CONSOLE = true;
  }
  if (roleCode === 'MANAGER' || roleCode === 'STAFF' || roleCode === 'GENERAL_STAFF' || roleCode === 'INSTALL_MANAGER') {
    permissions.PORTAL_ACCESS = true;
  }
  if (roleCode === 'VENDOR_ADMIN' || roleCode === 'VENDOR_STAFF') {
    permissions.PORTAL_ACCESS = true;
    permissions.VENDOR_SCOPE = true;
  }
  if (roleCode === 'VIEWER') {
    permissions.PORTAL_ACCESS = true;
    permissions.READ_ONLY = true;
  }

  portal19ApplyYnPermission_(permissions, row, 'sensitiveAccessYn', 'SENSITIVE_ACCESS');
  portal19ApplyYnPermission_(permissions, row, 'downloadAccessYn', 'DOWNLOAD_ACCESS');
  portal19ApplyYnPermission_(permissions, row, 'settlementEditYn', 'SETTLEMENT_EDIT');
  portal19ApplyYnPermission_(permissions, row, 'cancelSettlementYn', 'CANCEL_SETTLEMENT');
  portal19ApplyYnPermission_(permissions, row, 'recoveryPaymentYn', 'RECOVERY_PAYMENT');
  portal19ApplyYnPermission_(permissions, row, 'additionalPaymentYn', 'ADDITIONAL_PAYMENT');
  portal19ApplyYnPermission_(permissions, row, 'unlockAccessYn', 'UNLOCK_ACCESS');
  portal19ApplyYnPermission_(permissions, row, 'reopenAccessYn', 'REOPEN_ACCESS');

  if (!permissions.PORTAL_ACCESS) permissions.PORTAL_ACCESS = true;
  return permissions;
}

function portal19ApplyYnPermission_(permissions, row, fieldName, permissionKey) {
  var value = String(row[fieldName] || '').toUpperCase().trim();
  if (value === 'Y' || value === 'YES' || value === 'TRUE' || value === '1') permissions[permissionKey] = true;
}

function portal19ParsePermissions_(value) {
  var map = {};
  var text = String(value || '').trim();
  if (!text) return map;
  var parts = text.split(/[;,\n]/);
  for (var i = 0; i < parts.length; i++) {
    var p = String(parts[i] || '').trim();
    if (p) map[p] = true;
  }
  return map;
}

function portal19HasPermission_(profile, permissionKey) {
  if (!profile || !profile.permissions) return false;
  if (!permissionKey) return true;
  return !!(profile.permissions[permissionKey] || profile.permissions.ALL || profile.permissions['ALL']);
}

function portal19PermissionGuard_(profile, permissionKey) {
  if (!portal19HasPermission_(profile, permissionKey)) {
    throw new Error('권한이 없습니다: ' + permissionKey + ' / roleCode=' + String(profile && profile.roleCode || ''));
  }
  return true;
}

function portal19BuildMenu_(profile) {
  var p = profile || {};
  var role = String(p.roleCode || '').toUpperCase().trim();
  var perms = p.permissions || {};
  var isAdmin = !!(perms.ALL || role === 'SUPER_ADMIN' || role === 'ADMIN' || role === 'HQ_ADMIN' || role === 'DEV');
  var menu = [
    { menuId: 'home', label: '홈', route: 'home', enabled: true },
    { menuId: 'mail', label: '메일센터', route: 'mail', enabled: !!(perms.PORTAL_ACCESS || perms.ALL) },
    { menuId: 'calendar', label: '캘린더', route: 'calendar', enabled: !!(perms.PORTAL_ACCESS || perms.ALL) },
    { menuId: 'event', label: '행사관리', route: 'event', enabled: !!(perms.PORTAL_ACCESS || perms.ALL) },
    { menuId: 'vendor', label: '업체관리', route: 'vendor', enabled: isAdmin || !!perms.VENDOR_SCOPE },
    { menuId: 'customer', label: '고객관리', route: 'customer', enabled: !!(perms.PORTAL_ACCESS || perms.ALL) },
    { menuId: 'dev', label: '개발/점검', route: 'dev', enabled: !!(perms.DEV_CONSOLE || perms.ALL || role === 'DEV') }
  ];
  return menu.filter(function(item) { return item.enabled; });
}

function portal19ErrorMessage_(err) {
  if (!err) return '';
  if (typeof err === 'string') return err;
  if (err.message) return String(err.message);
  try { return JSON.stringify(err); } catch (e) { return String(err); }
}

function portal19SafeResult_(payload) {
  var base = {
    ok: true,
    build: PORTAL_AUTH_LEGACY_PROFILE_GUARD_BUILD,
    generatedAt: Utilities.formatDate(new Date(), 'Asia/Seoul', 'yyyy-MM-dd HH:mm:ss'),
    realApplyExecuted: false,
    googleRealApplyExecuted: false,
    naverRealApplyExecuted: false,
    externalApiExecuted: false,
    destructiveRepairExecuted: false,
    actualDeleteExecuted: false,
    actualStatusUpdateExecuted: false,
    sheetCreated: false,
    headersAdded: false,
    safety: 'AUTH_LEGACY_PROFILE_GUARD_COMPLETE_READ_ONLY_NO_CREATE_NO_DELETE'
  };
  if (typeof payload === 'string') {
    base.action = payload;
  } else if (payload && typeof payload === 'object') {
    Object.keys(payload).forEach(function(key) { base[key] = payload[key]; });
  }
  return base;
}

function portal19SafeError_(action, err, extra) {
  var payload = extra || {};
  payload.ok = false;
  payload.action = action || 'portal19SafeError_';
  payload.fatal = [portal19ErrorMessage_(err)];
  payload.message = portal19ErrorMessage_(err);
  return portal19SafeResult_(payload);
}

function portal19GetPermissionLoadReport() {
  var result = portal19SafeResult_('portal19GetPermissionLoadReport');
  try {
    var email = portal19GetCurrentEmail_();
    var config = portal19GetConfigBundle_();
    var profile = portal19LoadUserProfile_(email, config);
    result.ok = true;
    result.build = PORTAL_AUTH_LEGACY_PROFILE_GUARD_BUILD;
    result.email = email;
    result.profile = profile;
    result.menu = portal19BuildMenu_(profile);
    result.message = '사용자 식별/권한 로딩 성공';
  } catch (err) {
    result.ok = false;
    result.build = PORTAL_AUTH_LEGACY_PROFILE_GUARD_BUILD;
    result.fatal = [portal19ErrorMessage_(err)];
    result.message = portal19ErrorMessage_(err);
  }
  Logger.log('JSON_COMPACT_RESULT: ' + JSON.stringify(result));
  return result;
}

function portalAuthLegacyProfileGuardPatchDryRun() {
  var result = portal19SafeResult_({
    ok: false,
    build: PORTAL_AUTH_LEGACY_PROFILE_GUARD_BUILD,
    action: 'portalAuthLegacyProfileGuardPatchDryRun',
    safety: 'AUTH_LEGACY_PROFILE_GUARD_COMPLETE_READ_ONLY_NO_CREATE_NO_DELETE',
    fatal: [],
    checks: {}
  });
  try {
    var config = portal19GetConfigBundle_();
    var ss = portal19OpenMaster_(config);
    var sheet = ss.getSheetByName('PortalUsers');
    if (!sheet) throw new Error('PortalUsers 시트가 없습니다.');
    var data = portal19ReadRowsByHeader_(sheet);
    result.spreadsheetName = ss.getName();
    result.portalUsers = {
      exists: true,
      lastRow: sheet.getLastRow(),
      lastColumn: sheet.getLastColumn(),
      headerCount: Object.keys(data.headers || {}).length,
      hasEmailHeader: !!(data.headers || {}).email,
      hasLoginEmailHeader: !!(data.headers || {}).loginEmail,
      hasLoginIdHeader: !!(data.headers || {}).loginId,
      hasPermissionsHeader: !!(data.headers || {}).permissions,
      hasRoleCodeHeader: !!(data.headers || {}).roleCode,
      hasEmployeeIdHeader: !!(data.headers || {}).employeeId
    };
    result.checks.legacyEmailPermissionsHeaderNoLongerRequired = true;
    result.checks.compatLookupFields = ['email', 'loginEmail', 'loginId'];
    result.checks.compatPermissionSource = 'permissions header if present, otherwise roleCode + *_Yn flags';
    result.checks.localHelpersIncluded = ['portal19SafeResult_', 'portal19ErrorMessage_', 'portal19SafeError_', 'portal19BuildMenu_'];
    result.ok = true;
    result.message = 'Portal_Auth complete guard loaded. No data changed.';
  } catch (err) {
    result.ok = false;
    result.fatal.push(portal19ErrorMessage_(err));
    result.message = 'Portal_Auth complete guard 점검 중 오류 발생';
  }
  Logger.log('JSON_COMPACT_RESULT: ' + JSON.stringify(result));
  return result;
}

function portalAuthLegacyProfileGuardCompleteSelfTest() {
  var result = portal19SafeResult_({
    ok: true,
    action: 'portalAuthLegacyProfileGuardCompleteSelfTest',
    checks: {
      hasPortal19SafeResult: typeof portal19SafeResult_ === 'function',
      hasPortal19ErrorMessage: typeof portal19ErrorMessage_ === 'function',
      hasPortal19SafeError: typeof portal19SafeError_ === 'function',
      hasPortal19BuildMenu: typeof portal19BuildMenu_ === 'function',
      hasPortal19LoadUserProfile: typeof portal19LoadUserProfile_ === 'function',
      hasPortal19PermissionGuard: typeof portal19PermissionGuard_ === 'function'
    },
    message: 'Complete helper dependency self-test finished. No data changed.'
  });
  var checks = result.checks || {};
  Object.keys(checks).forEach(function(key) {
    if (!checks[key]) result.ok = false;
  });
  Logger.log('JSON_COMPACT_RESULT: ' + JSON.stringify(result));
  return result;
}
