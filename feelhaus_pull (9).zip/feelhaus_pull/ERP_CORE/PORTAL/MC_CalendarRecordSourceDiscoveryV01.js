/**
 * FEELHAUS MailCenter Calendar Record Source Discovery V01
 * Build: MAILCENTER_CALENDAR_RECORD_SOURCE_DISCOVERY_V01_20260521
 * Purpose:
 * - Discover MASTER sheets that can be used as 상담/저장기록 source for calendar recordId auto-link
 * - Scan headers only and produce candidate source list
 * - Provide gate, backup/lock, summary
 * - Do not modify router/menu/html/shell/view files
 */
var MC_CALENDAR_RECORD_SOURCE_DISCOVERY_V01_BUILD = 'MAILCENTER_CALENDAR_RECORD_SOURCE_DISCOVERY_V01_20260521';
var MC_CALENDAR_RECORD_SOURCE_DISCOVERY_V01_SETUP_DB_ID = '17VMSpgSZCvIrUlgcw8yCNcnl8WQWo2IcRf5tDCcuJGM';
var MC_CALENDAR_RECORD_SOURCE_DISCOVERY_V01_CONFIG_SHEET = 'SystemConfig';
var MC_CALENDAR_RECORD_SOURCE_DISCOVERY_V01_WEBAPP_URL = 'https://script.google.com/a/macros/feelhausfair.com/s/AKfycbxCyFE7zf4vE8nsfjOeWX0pC56SqU84gm8ie8Txa3qHQGEusJCZeljzCdYeOmZxUVYvjA/exec';

function runMcCalendarRecordSourceDiscoveryV01Smoke() {
  var result = {
    ok: true,
    build: MC_CALENDAR_RECORD_SOURCE_DISCOVERY_V01_BUILD,
    action: 'runMcCalendarRecordSourceDiscoveryV01Smoke',
    generatedAt: mcCalendarRecordSourceDiscoveryV01Now_(),
    noWriteMode: true,
    checks: []
  };
  function check(key, ok, message, detail) {
    result.checks.push({ key: key, ok: !!ok, message: message, detail: detail || '' });
    if (!ok) result.ok = false;
  }
  try {
    check('MasterOpenReady', !!mcCalendarRecordSourceDiscoveryV01OpenMaster_(), 'SystemConfig -> FEELHAUS_DB_MASTER 연결 확인', 'FEELHAUS_DB_MASTER');
    check('DiscoveryFunctionReady', typeof runMcCalendarRecordSourceDiscoveryV01Scan === 'function', '원장 후보 탐색 함수 확인');
    check('GateFunctionReady', typeof runMcCalendarRecordSourceDiscoveryV01Gate === 'function', '게이트 함수 확인');
    check('LockFunctionReady', typeof runMcCalendarRecordSourceDiscoveryV01CreateBackupAndLock === 'function', '백업/잠금 함수 확인');
    check('SummaryFunctionReady', typeof runMcCalendarRecordSourceDiscoveryV01Summary === 'function', '요약 기록 함수 확인');
    check('WebAppUrlReady', !!MC_CALENDAR_RECORD_SOURCE_DISCOVERY_V01_WEBAPP_URL, 'WebApp 절대주소 확인', MC_CALENDAR_RECORD_SOURCE_DISCOVERY_V01_WEBAPP_URL);
    check('NoRouterMenuHtmlTouch', true, '본 파일은 라우터/메뉴/HTML/Shell/View 변경 없음');
    result.message = result.ok ? 'MailCenter Calendar Record Source Discovery V01 Smoke 통과' : 'MailCenter Calendar Record Source Discovery V01 점검 필요';
  } catch (err) {
    result.ok = false;
    result.message = mcCalendarRecordSourceDiscoveryV01Err_(err);
  }
  Logger.log(JSON.stringify(result, null, 2));
  return result;
}

function runMcCalendarRecordSourceDiscoveryV01Scan() {
  var result = {
    ok: true,
    build: MC_CALENDAR_RECORD_SOURCE_DISCOVERY_V01_BUILD,
    action: 'runMcCalendarRecordSourceDiscoveryV01Scan',
    generatedAt: mcCalendarRecordSourceDiscoveryV01Now_(),
    noWriteMode: true,
    checks: [],
    summary: {},
    candidates: [],
    warnings: []
  };
  function check(key, ok, message, detail) {
    result.checks.push({ key: key, ok: !!ok, message: message, detail: detail || '' });
    if (!ok) result.ok = false;
  }
  try {
    var master = mcCalendarRecordSourceDiscoveryV01OpenMaster_();
    var scan = mcCalendarRecordSourceDiscoveryV01ScanMaster_(master);
    result.summary = scan.summary;
    result.candidates = scan.candidates;
    result.warnings = scan.warnings;
    check('MasterOpenReady', !!master, 'SystemConfig -> FEELHAUS_DB_MASTER 연결 확인', master.getId());
    check('SheetScanReady', scan.summary.totalSheets >= 1, 'MASTER 전체 시트 탐색 완료', JSON.stringify(scan.summary));
    check('CalendarMailLinksReady', !!master.getSheetByName('MAILCENTER_CalendarMailLinks'), 'MAILCENTER_CalendarMailLinks 시트 확인');
    check('CandidateDiscoveryCompleted', true, 'recordId 후보 원장 탐색 완료', 'candidateSheets=' + scan.summary.candidateSheets);
    check('NoWriteModeConfirmed', true, 'Scan은 읽기 전용, 시트 쓰기 없음');
    if (scan.summary.candidateSheets === 0) {
      result.warnings.push('recordId 자동 연결 원장 후보가 0건입니다. 저장기록/상담기록 시트명 또는 헤더 확인이 필요합니다.');
    }
    result.message = result.ok ? 'MailCenter Calendar Record Source Discovery V01 Scan 완료' : 'MailCenter Calendar Record Source Discovery V01 Scan 점검 필요';
  } catch (err) {
    result.ok = false;
    result.message = mcCalendarRecordSourceDiscoveryV01Err_(err);
  }
  Logger.log(JSON.stringify(result, null, 2));
  return result;
}

function runMcCalendarRecordSourceDiscoveryV01Gate() {
  var result = {
    ok: true,
    build: MC_CALENDAR_RECORD_SOURCE_DISCOVERY_V01_BUILD,
    action: 'runMcCalendarRecordSourceDiscoveryV01Gate',
    generatedAt: mcCalendarRecordSourceDiscoveryV01Now_(),
    noWriteMode: true,
    checks: [],
    warnings: [],
    summary: {}
  };
  function check(key, ok, message, detail) {
    result.checks.push({ key: key, ok: !!ok, message: message, detail: detail || '' });
    if (!ok) result.ok = false;
  }
  try {
    var master = mcCalendarRecordSourceDiscoveryV01OpenMaster_();
    var scan = mcCalendarRecordSourceDiscoveryV01ScanMaster_(master);
    result.summary = scan.summary;
    result.warnings = scan.warnings;
    check('MasterOpenReady', !!master, 'SystemConfig -> FEELHAUS_DB_MASTER 연결 확인', master.getId());
    check('CalendarEventsSheetReady', !!master.getSheetByName('MAILCENTER_CalendarEvents'), 'MAILCENTER_CalendarEvents 시트 확인');
    check('CalendarMailLinksSheetReady', !!master.getSheetByName('MAILCENTER_CalendarMailLinks'), 'MAILCENTER_CalendarMailLinks 시트 확인');
    check('CalendarLogsSheetReady', !!master.getSheetByName('MAILCENTER_CalendarLogs'), 'MAILCENTER_CalendarLogs 시트 확인');
    check('SheetScanReady', scan.summary.totalSheets >= 1, 'MASTER 시트 전체 스캔 확인', JSON.stringify(scan.summary));
    check('HeaderPatternScanReady', true, 'recordId/threadId/messageId/subject/email 헤더 패턴 탐색 확인', JSON.stringify({ candidateSheets: scan.summary.candidateSheets, strongCandidates: scan.summary.strongCandidates }));
    check('CandidateZeroAllowed', true, '후보 0건이어도 게이트 실패 아님 - 원장 확정 전 탐색 단계');
    check('NoWriteModeConfirmed', true, '본 게이트는 읽기 점검 전용, 시트 쓰기 없음');
    check('NoRouterMenuHtmlTouchByGate', true, '게이트는 라우터/메뉴/HTML/Shell/View 변경 없음');
    if (scan.summary.candidateSheets === 0) {
      result.warnings.push('자동 연결 원장 후보 0건: MailCenter 저장기록/상담기록 시트명 또는 헤더 기준 추가 확인 필요');
    }
    result.message = result.ok ? 'MailCenter Calendar Record Source Discovery V01 Gate 통과' : 'MailCenter Calendar Record Source Discovery V01 Gate 점검 필요';
    result.nextStage = result.ok ? 'MAILCENTER_CALENDAR_RECORD_SOURCE_DISCOVERY_LOCK_READY' : 'RECORD_SOURCE_DISCOVERY_FIX_REQUIRED';
  } catch (err) {
    result.ok = false;
    result.message = mcCalendarRecordSourceDiscoveryV01Err_(err);
    result.nextStage = 'RECORD_SOURCE_DISCOVERY_FIX_REQUIRED';
  }
  Logger.log(JSON.stringify(result, null, 2));
  return result;
}

function runMcCalendarRecordSourceDiscoveryV01CreateBackupAndLock() {
  var result = {
    ok: false,
    build: MC_CALENDAR_RECORD_SOURCE_DISCOVERY_V01_BUILD,
    action: 'runMcCalendarRecordSourceDiscoveryV01CreateBackupAndLock',
    generatedAt: mcCalendarRecordSourceDiscoveryV01Now_(),
    lockId: '',
    backupSpreadsheetId: '',
    backupName: '',
    copiedSheets: [],
    summary: {},
    message: ''
  };
  var actor = mcCalendarRecordSourceDiscoveryV01Actor_();
  try {
    var master = mcCalendarRecordSourceDiscoveryV01OpenMaster_();
    var scan = mcCalendarRecordSourceDiscoveryV01ScanMaster_(master);
    var now = mcCalendarRecordSourceDiscoveryV01Now_();
    var stamp = Utilities.formatDate(new Date(), Session.getScriptTimeZone() || 'Asia/Seoul', 'yyyyMMdd_HHmmss');
    var lockId = 'MCALRECSRCLOCK-' + Utilities.formatDate(new Date(), Session.getScriptTimeZone() || 'Asia/Seoul', 'yyyyMMddHHmmss') + '-' + Utilities.getUuid().substring(0, 8).toUpperCase();
    var backupName = 'MAILCENTER_CALENDAR_RECORD_SOURCE_DISCOVERY_BACKUP_' + stamp;
    var backup = SpreadsheetApp.create(backupName);
    var backupId = backup.getId();
    var copied = [];

    var coreSheets = ['MAILCENTER_CalendarEvents','MAILCENTER_CalendarMailLinks','MAILCENTER_CalendarLogs','MAILCENTER_CalendarRecordLinkLocks','MAILCENTER_CalendarRecordLinkSummaries'];
    coreSheets.forEach(function(sheetName) {
      var src = master.getSheetByName(sheetName);
      if (src) {
        var copy = src.copyTo(backup);
        copy.setName(sheetName);
        copied.push({ sheetName: sheetName, rows: src.getLastRow(), cols: src.getLastColumn() });
      }
    });

    var discoverySheet = backup.insertSheet('RECORD_SOURCE_DISCOVERY');
    var rows = [['rank','sheetName','score','rows','cols','recordIdHeaders','mailHeaders','dateHeaders','matchedHeaders','reason']];
    scan.candidates.forEach(function(c, idx) {
      rows.push([
        idx + 1,
        c.sheetName,
        c.score,
        c.rows,
        c.cols,
        c.recordIdHeaders.join(', '),
        c.mailHeaders.join(', '),
        c.dateHeaders.join(', '),
        c.matchedHeaders.join(', '),
        c.reason
      ]);
    });
    if (rows.length === 1) rows.push(['', 'NO_CANDIDATE', 0, '', '', '', '', '', '', '원장 후보 없음']);
    discoverySheet.getRange(1, 1, rows.length, rows[0].length).setValues(rows);
    discoverySheet.setFrozenRows(1);

    var info = backup.insertSheet('LOCK_INFO');
    var infoRows = [
      ['key','value'],
      ['lockId', lockId],
      ['build', MC_CALENDAR_RECORD_SOURCE_DISCOVERY_V01_BUILD],
      ['recordLinkBuild', 'MAILCENTER_CALENDAR_RECORD_LINK_PACK_V01_20260521'],
      ['webAppUrl', MC_CALENDAR_RECORD_SOURCE_DISCOVERY_V01_WEBAPP_URL],
      ['sourceMasterId', master.getId()],
      ['backupSpreadsheetId', backupId],
      ['lockedAt', now],
      ['lockedBy', actor],
      ['status', 'DISCOVERY_LOCKED'],
      ['summary', JSON.stringify(scan.summary)],
      ['note', 'Router/menu/html/shell/view files not modified by this discovery lock']
    ];
    info.getRange(1, 1, infoRows.length, 2).setValues(infoRows);
    info.setFrozenRows(1);

    var defaultSheet = backup.getSheetByName('Sheet1');
    if (defaultSheet && backup.getSheets().length > 1) backup.deleteSheet(defaultSheet);

    mcCalendarRecordSourceDiscoveryV01AppendByHeaders_(master, 'MAILCENTER_CalendarRecordSourceDiscoveryLocks', mcCalendarRecordSourceDiscoveryV01LockHeaders_(), {
      lockId: lockId,
      build: MC_CALENDAR_RECORD_SOURCE_DISCOVERY_V01_BUILD,
      backupName: backupName,
      backupSpreadsheetId: backupId,
      webAppUrl: MC_CALENDAR_RECORD_SOURCE_DISCOVERY_V01_WEBAPP_URL,
      status: 'DISCOVERY_LOCKED',
      statusReason: 'recordId 자동 연결 원장 후보 탐색 및 백업 잠금 완료',
      totalSheets: scan.summary.totalSheets,
      candidateSheets: scan.summary.candidateSheets,
      strongCandidates: scan.summary.strongCandidates,
      topCandidatesJson: JSON.stringify(scan.candidates.slice(0, 10)),
      copiedSheetsJson: JSON.stringify(copied),
      createdAt: now,
      createdBy: actor,
      updatedAt: now,
      updatedBy: actor
    });

    result.ok = true;
    result.lockId = lockId;
    result.backupSpreadsheetId = backupId;
    result.backupName = backupName;
    result.copiedSheets = copied;
    result.summary = scan.summary;
    result.message = 'MailCenter Calendar Record Source Discovery V01 Lock 완료';
  } catch (err) {
    result.ok = false;
    result.message = mcCalendarRecordSourceDiscoveryV01Err_(err);
  }
  Logger.log(JSON.stringify(result, null, 2));
  return result;
}

function runMcCalendarRecordSourceDiscoveryV01Summary() {
  var result = {
    ok: false,
    build: MC_CALENDAR_RECORD_SOURCE_DISCOVERY_V01_BUILD,
    action: 'runMcCalendarRecordSourceDiscoveryV01Summary',
    generatedAt: mcCalendarRecordSourceDiscoveryV01Now_(),
    summaryId: '',
    message: ''
  };
  var actor = mcCalendarRecordSourceDiscoveryV01Actor_();
  try {
    var master = mcCalendarRecordSourceDiscoveryV01OpenMaster_();
    var scan = mcCalendarRecordSourceDiscoveryV01ScanMaster_(master);
    var now = mcCalendarRecordSourceDiscoveryV01Now_();
    var summaryId = 'MCALRECSRCSUM-' + Utilities.formatDate(new Date(), Session.getScriptTimeZone() || 'Asia/Seoul', 'yyyyMMddHHmmss') + '-' + Utilities.getUuid().substring(0, 8).toUpperCase();
    mcCalendarRecordSourceDiscoveryV01AppendByHeaders_(master, 'MAILCENTER_CalendarRecordSourceDiscoverySummaries', mcCalendarRecordSourceDiscoveryV01SummaryHeaders_(), {
      summaryId: summaryId,
      build: MC_CALENDAR_RECORD_SOURCE_DISCOVERY_V01_BUILD,
      webAppUrl: MC_CALENDAR_RECORD_SOURCE_DISCOVERY_V01_WEBAPP_URL,
      totalSheets: scan.summary.totalSheets,
      candidateSheets: scan.summary.candidateSheets,
      strongCandidates: scan.summary.strongCandidates,
      topCandidatesJson: JSON.stringify(scan.candidates.slice(0, 10)),
      warningJson: JSON.stringify(scan.warnings),
      status: 'SUMMARY_RECORDED',
      statusReason: 'recordId 자동 연결 원장 후보 탐색 요약 기록 완료',
      createdAt: now,
      createdBy: actor,
      updatedAt: now,
      updatedBy: actor
    });
    result.ok = true;
    result.summaryId = summaryId;
    result.message = 'MailCenter Calendar Record Source Discovery V01 Summary 기록 완료';
  } catch (err) {
    result.ok = false;
    result.message = mcCalendarRecordSourceDiscoveryV01Err_(err);
  }
  Logger.log(JSON.stringify(result, null, 2));
  return result;
}

function mcCalendarRecordSourceDiscoveryV01ScanMaster_(master) {
  var sheets = master.getSheets();
  var candidates = [];
  var warnings = [];
  var totalRows = 0;
  var strong = 0;
  sheets.forEach(function(sheet) {
    var name = sheet.getName();
    var lastRow = sheet.getLastRow();
    var lastCol = sheet.getLastColumn();
    totalRows += Math.max(lastRow - 1, 0);
    if (lastCol < 1) return;
    var headers = sheet.getRange(1, 1, 1, lastCol).getValues()[0].map(function(h) { return String(h || '').trim(); });
    var lower = headers.map(function(h) { return h.toLowerCase(); });
    var matched = [];
    var recordIdHeaders = [];
    var mailHeaders = [];
    var dateHeaders = [];
    var score = 0;

    headers.forEach(function(h, idx) {
      var l = lower[idx];
      if (!h) return;
      if (l === 'recordid' || l === 'record_id' || l === 'requestid' || l === 'request_id' || l === 'consultrecordid' || l === 'saverecordid' || l === 'mailrecordid' || l === 'historyid') {
        recordIdHeaders.push(h);
        matched.push(h);
        score += 35;
      }
      if (l === 'threadid' || l === 'thread_id' || l === 'messageid' || l === 'message_id' || l === 'gmailthreadid' || l === 'gmailmessageid') {
        mailHeaders.push(h);
        matched.push(h);
        score += 25;
      }
      if (l === 'subject' || l === 'mailsubject' || l === 'title' || l === 'fromemail' || l === 'toemail' || l === 'from' || l === 'to' || l === 'sender' || l === 'recipient') {
        mailHeaders.push(h);
        matched.push(h);
        score += 10;
      }
      if (l === 'maildate' || l === 'createdat' || l === 'updatedat' || l === 'savedat' || l === 'recordedat') {
        dateHeaders.push(h);
        matched.push(h);
        score += 5;
      }
    });

    var nameLower = name.toLowerCase();
    if (nameLower.indexOf('mail') >= 0) score += 10;
    if (nameLower.indexOf('record') >= 0 || nameLower.indexOf('save') >= 0 || nameLower.indexOf('consult') >= 0 || nameLower.indexOf('history') >= 0 || name.indexOf('상담') >= 0 || name.indexOf('저장') >= 0) score += 15;
    if (nameLower.indexOf('backup') >= 0 || nameLower.indexOf('lock') >= 0 || nameLower.indexOf('summary') >= 0) score -= 20;

    var isCalendarInternal = name.indexOf('MAILCENTER_Calendar') === 0;
    if (isCalendarInternal) score -= 15;
    var qualifies = score >= 30 && (recordIdHeaders.length > 0 || mailHeaders.length > 0);
    if (qualifies) {
      if (score >= 60) strong++;
      candidates.push({
        sheetName: name,
        score: score,
        rows: lastRow,
        cols: lastCol,
        recordIdHeaders: mcCalendarRecordSourceDiscoveryV01Unique_(recordIdHeaders),
        mailHeaders: mcCalendarRecordSourceDiscoveryV01Unique_(mailHeaders),
        dateHeaders: mcCalendarRecordSourceDiscoveryV01Unique_(dateHeaders),
        matchedHeaders: mcCalendarRecordSourceDiscoveryV01Unique_(matched),
        reason: mcCalendarRecordSourceDiscoveryV01Reason_(score, recordIdHeaders, mailHeaders, dateHeaders, name)
      });
    }
  });
  candidates.sort(function(a, b) { return b.score - a.score; });
  if (candidates.length === 0) warnings.push('후보 시트 0건: MailCenter 저장기록/상담기록 원장의 실제 시트명과 헤더 기준 확인 필요');
  return {
    summary: {
      totalSheets: sheets.length,
      totalDataRowsApprox: totalRows,
      candidateSheets: candidates.length,
      strongCandidates: strong,
      topCandidate: candidates.length ? candidates[0].sheetName : ''
    },
    candidates: candidates,
    warnings: warnings
  };
}

function mcCalendarRecordSourceDiscoveryV01Reason_(score, recordIdHeaders, mailHeaders, dateHeaders, sheetName) {
  var parts = [];
  if (recordIdHeaders.length) parts.push('recordId계열=' + recordIdHeaders.join('|'));
  if (mailHeaders.length) parts.push('메일키=' + mailHeaders.join('|'));
  if (dateHeaders.length) parts.push('일시=' + dateHeaders.join('|'));
  parts.push('score=' + score);
  return parts.join(', ');
}

function mcCalendarRecordSourceDiscoveryV01LockHeaders_() {
  return ['lockId','build','backupName','backupSpreadsheetId','webAppUrl','status','statusReason','totalSheets','candidateSheets','strongCandidates','topCandidatesJson','copiedSheetsJson','createdAt','createdBy','updatedAt','updatedBy'];
}

function mcCalendarRecordSourceDiscoveryV01SummaryHeaders_() {
  return ['summaryId','build','webAppUrl','totalSheets','candidateSheets','strongCandidates','topCandidatesJson','warningJson','status','statusReason','createdAt','createdBy','updatedAt','updatedBy'];
}

function mcCalendarRecordSourceDiscoveryV01AppendByHeaders_(ss, sheetName, baseHeaders, record) {
  var sheet = mcCalendarRecordSourceDiscoveryV01GetSheetOrCreate_(ss, sheetName, baseHeaders);
  mcCalendarRecordSourceDiscoveryV01EnsureHeaders_(sheet, Object.keys(record || {}));
  var headers = sheet.getRange(1, 1, 1, sheet.getLastColumn()).getValues()[0];
  var hm = mcCalendarRecordSourceDiscoveryV01HeaderMap_(headers);
  var row = [];
  for (var i = 0; i < headers.length; i++) row.push('');
  Object.keys(record || {}).forEach(function(key) {
    if (hm.hasOwnProperty(key)) row[hm[key]] = record[key];
  });
  sheet.appendRow(row);
}

function mcCalendarRecordSourceDiscoveryV01GetSheetOrCreate_(ss, name, headers) {
  var sheet = ss.getSheetByName(name);
  if (!sheet) {
    sheet = ss.insertSheet(name);
    sheet.getRange(1, 1, 1, headers.length).setValues([headers]);
    sheet.setFrozenRows(1);
    return sheet;
  }
  if (sheet.getLastRow() < 1 || sheet.getLastColumn() < 1) {
    sheet.getRange(1, 1, 1, headers.length).setValues([headers]);
    sheet.setFrozenRows(1);
    return sheet;
  }
  mcCalendarRecordSourceDiscoveryV01EnsureHeaders_(sheet, headers);
  return sheet;
}

function mcCalendarRecordSourceDiscoveryV01EnsureHeaders_(sheet, requiredHeaders) {
  var lastCol = Math.max(sheet.getLastColumn(), 1);
  var headers = sheet.getRange(1, 1, 1, lastCol).getValues()[0];
  var hm = mcCalendarRecordSourceDiscoveryV01HeaderMap_(headers);
  var add = [];
  (requiredHeaders || []).forEach(function(h) { if (h && !hm.hasOwnProperty(h)) add.push(h); });
  if (add.length) sheet.getRange(1, headers.length + 1, 1, add.length).setValues([add]);
}

function mcCalendarRecordSourceDiscoveryV01OpenMaster_() {
  var setup = SpreadsheetApp.openById(MC_CALENDAR_RECORD_SOURCE_DISCOVERY_V01_SETUP_DB_ID);
  var sheet = setup.getSheetByName(MC_CALENDAR_RECORD_SOURCE_DISCOVERY_V01_CONFIG_SHEET);
  if (!sheet) throw new Error('SystemConfig 시트를 찾지 못했습니다.');
  var values = sheet.getDataRange().getValues();
  if (!values || values.length < 2) throw new Error('SystemConfig 데이터가 비어 있습니다.');
  var hm = mcCalendarRecordSourceDiscoveryV01HeaderMap_(values[0]);
  var keyCol = mcCalendarRecordSourceDiscoveryV01PickIndex_(hm, ['CONFIG_KEY','configKey','key','name']);
  var valCol = mcCalendarRecordSourceDiscoveryV01PickIndex_(hm, ['VALUE','configValue','value','spreadsheetId']);
  if (keyCol < 0 || valCol < 0) throw new Error('SystemConfig CONFIG_KEY/VALUE 헤더를 찾지 못했습니다.');
  var masterId = '';
  for (var r = 1; r < values.length; r++) {
    var key = String(values[r][keyCol] || '').trim();
    if (key === 'FEELHAUS_DB_MASTER' || key === 'FEELHAUS_DB_MASTER_ID' || key === 'MASTER_DB_ID') {
      masterId = String(values[r][valCol] || '').trim();
      break;
    }
  }
  if (!masterId) throw new Error('SystemConfig에서 FEELHAUS_DB_MASTER ID를 찾지 못했습니다.');
  return SpreadsheetApp.openById(masterId);
}

function mcCalendarRecordSourceDiscoveryV01HeaderMap_(headers) {
  var out = {};
  (headers || []).forEach(function(h, i) {
    var key = String(h || '').trim();
    if (key) out[key] = i;
  });
  return out;
}

function mcCalendarRecordSourceDiscoveryV01PickIndex_(hm, keys) {
  for (var i = 0; i < keys.length; i++) if (hm.hasOwnProperty(keys[i])) return hm[keys[i]];
  return -1;
}

function mcCalendarRecordSourceDiscoveryV01Unique_(arr) {
  var out = [];
  var seen = {};
  (arr || []).forEach(function(v) {
    var key = String(v || '').trim();
    if (key && !seen[key]) {
      seen[key] = true;
      out.push(key);
    }
  });
  return out;
}

function mcCalendarRecordSourceDiscoveryV01Actor_() {
  return String(Session.getActiveUser().getEmail() || 'MAILCENTER_ADMIN').trim() || 'MAILCENTER_ADMIN';
}

function mcCalendarRecordSourceDiscoveryV01Now_() {
  return Utilities.formatDate(new Date(), Session.getScriptTimeZone() || 'Asia/Seoul', 'yyyy-MM-dd HH:mm:ss');
}

function mcCalendarRecordSourceDiscoveryV01Err_(err) {
  return err && err.message ? err.message : String(err);
}
