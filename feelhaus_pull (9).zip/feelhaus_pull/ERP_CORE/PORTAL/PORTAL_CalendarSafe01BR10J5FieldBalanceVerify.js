/**
 * PORTAL_CALENDAR_SAFE01B_R10J5_FIELD_BALANCE_REVIEW_20260603
 * READ_ONLY verification. No sheet/provider writes.
 */
function portalCalendarSafe01BR10J5FieldBalanceVerify() {
  var build = 'PORTAL_CALENDAR_SAFE01B_R10J5_FIELD_BALANCE_REVIEW_20260603';
  var out = { ok:false, build:build, action:'portalCalendarSafe01BR10J5FieldBalanceVerify', safety:'READ_ONLY_RUNTIME_VERIFY_NO_SHEET_PROVIDER_WRITE', checks:{}, warnings:[], fatal:[] };
  function html_(name){ try { return String(HtmlService.createHtmlOutputFromFile(name).getContent() || ''); } catch(e){ out.warnings.push('html read failed: '+name+' '+e.message); return ''; } }
  function src_(fn){ try { return String(fn && fn.toString ? fn.toString() : ''); } catch(e){ return ''; } }
  var view = html_('MC_CalendarViewV01');
  var opFields = [];
  try { opFields = mcCalendarOperationHubV01UpdatableFields_(); } catch(e) { out.warnings.push('updatable fields runtime failed: '+e.message); }
  var up = {}; (opFields || []).forEach(function(k){ up[k]=true; });
  var manualNorm = src_(typeof mcCalendarUnifiedManualInputV01NormalizePayload_ !== 'undefined' ? mcCalendarUnifiedManualInputV01NormalizePayload_ : null);
  var requiredKeep = ['scheduleSummary','processStatus','primaryOwnerName','assistantOwnerName','shareTargetsJson','reportTargetsJson','nextActionOwner','followUpRequiredYn','followUpCreatedYn','sensitiveInfoLevel','relatedLinks','relatedDocumentIds','internalOwnerName','presentationMainSpeaker','agreementCondition','calendarBusinessType','selectionId','eventId','approvalId'];
  var checks = out.checks;
  checks.viewR10J5MarkerPresent = view.indexOf(build) >= 0 && view.indexOf('__MC_CALENDAR_R10J5_FIELD_BALANCE_BUILD__') >= 0;
  checks.r10j4BasicInfoKept = view.indexOf('PORTAL_CALENDAR_SAFE01B_R10J4_BASIC_INFO_EXPANSION_20260603') >= 0 && view.indexOf('1. 일정 기본정보 / 공통 업무카드') >= 0;
  checks.r10j2ScreenLayoutKept = view.indexOf('PORTAL_CALENDAR_SAFE01B_R10J2_SCREEN_LAYOUT_POLISH_20260603') >= 0 && view.indexOf('operationInfoSectionTitleR10J2') >= 0;
  checks.r10j1SafeOpenKept = view.indexOf('fhCalendarRestoreDetailModalR10J1') >= 0 && view.indexOf('closeCalendarDetailPopup();') >= 0;
  checks.commonInternalStaffKept = view.indexOf('필하우스 주담당자') >= 0 && view.indexOf('필하우스 보조담당자') >= 0 && view.indexOf('공유 대상자') >= 0 && view.indexOf('보고 대상자') >= 0;
  checks.selectionRoleSeparated = view.indexOf('선정 과정 역할 담당') >= 0 && view.indexOf('선정 총괄/실무 담당자') >= 0 && view.indexOf('공통 주담당/참여 직원은 1번 기본정보') >= 0;
  checks.preCouncilContactKept = view.indexOf('입예협 / 외부 접촉처 보조정보') >= 0 && view.indexOf('입대의') < 0 && view.indexOf('PRE_COUNCIL_CHAIR') >= 0;
  checks.presentationParticipantsSeparated = view.indexOf('프레젠테이션 참여 직원') >= 0 && view.indexOf('프레젠테이션 외부 참석자') >= 0 && view.indexOf('메인 발표자') >= 0;
  checks.conditionAgreementSeparated = view.indexOf('운영 조건 협의안') >= 0 && view.indexOf('홍보 조건 협의안') >= 0 && view.indexOf('최종 협약 조건') >= 0;
  checks.actionAndGeneralSubsectionsReady = view.indexOf('대표 다음 액션') >= 0 && view.indexOf('일반/기타 일정 확장') >= 0;
  checks.legacyBlockClarified = view.indexOf('회의/참여자/후속업무 보조정보(레거시/공통 원장)') >= 0 && view.indexOf('일반 담당자명(레거시)') >= 0 && view.indexOf('확정/연결 행사명') >= 0;
  checks.presentationSpellingUnified = view.indexOf('프리젠테이션') < 0 && view.indexOf('프레젠테이션') >= 0;
  checks.changedFieldLabelsBalanced = view.indexOf("internalOwnerName:'선정 총괄/실무 담당자'") >= 0 && view.indexOf("operationCondition:'운영 조건 협의안'") >= 0 && view.indexOf("agreementCondition:'최종 협약 조건'") >= 0;
  checks.operationUpdatableKept = requiredKeep.every(function(k){ return !!up[k]; });
  checks.manualNormalizeKept = ['scheduleSummary','primaryOwnerName','internalOwnerName','presentationMainSpeaker','agreementCondition','approvalId'].every(function(k){ return manualNorm.indexOf(k + ':') >= 0; });
  checks.noExtractedTempMarker = view.indexOf('extracted_view') < 0 && view.indexOf('_scripts_clean') < 0;
  Object.keys(checks).forEach(function(k){ if(!checks[k]) out.fatal.push(k); });
  out.balanceSummary = {
    sectionMode: 'common basic info + selection role info + presentation role info + agreement final conditions + legacy auxiliary fields',
    requiredKeepCount: requiredKeep.length,
    updatableCount: (opFields || []).length,
    missingUpdatable: requiredKeep.filter(function(k){ return !up[k]; })
  };
  out.message = out.fatal.length ? 'SAFE-01B R10J5 field-balance verification failed. Check fatal items.' : 'SAFE-01B R10J5 field-balance verification passed.';
  out.ok = out.fatal.length === 0;
  Logger.log('JSON_COMPACT_RESULT: ' + JSON.stringify(out));
  return out;
}
