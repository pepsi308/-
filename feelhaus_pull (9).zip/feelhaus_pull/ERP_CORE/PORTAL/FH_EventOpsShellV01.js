/**
 * FEELHAUS Event Ops Shell V01
 * Build: EVENT_CENTER_FAST_STABILIZE_V01_READONLY_LOCK_20260523
 * Purpose:
 * - ERP 행사관리 + Calendar + 대관신청 + 인력셋팅 + 행사장셋팅 V01 화면 진입
 * - SystemConfig -> FEELHAUS_DB_MASTER 기준 연결
 */

var FH_EVENT_OPS_V01_BUILD = 'EVENT_CENTER_FAST_STABILIZE_V01_READONLY_LOCK_20260523';

function fhEventOpsV01HandleGet(e) {
  var tpl = HtmlService.createTemplateFromFile('FH_EventOpsViewV01');
  tpl.build = FH_EVENT_OPS_V01_BUILD;
  tpl.webAppUrl = fhEventOpsV01GetWebAppUrl_();
  tpl.initialJson = JSON.stringify(fhEventOpsV01GetInitialData(e || {}));
  return tpl.evaluate()
    .setTitle('FEELHAUS 행사관리센터 읽기전용 잠금')
    .setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL);
}

function fhEventOpsV01GetWebAppUrl_() {
  var fallbackUrl = 'https://script.google.com/macros/s/AKfycbxCyFE7zf4vE8nsfjOeWX0pC56SqU84gm8ie8Txa3qHQGEusJCZeljzCdYeOmZxUVYvjA/exec';
  try {
    var serviceUrl = ScriptApp.getService().getUrl();
    return serviceUrl || fallbackUrl;
  } catch (err) {
    return fallbackUrl;
  }
}

function fhEventOpsV01GetInitialData(e) {
  var result = {
    ok: true,
    build: FH_EVENT_OPS_V01_BUILD,
    action: 'fhEventOpsV01GetInitialData',
    generatedAt: fhEventOpsV01Now_(),
    userEmail: '',
    stage: 'EVENT_CENTER_FAST_STABILIZE_V01_READONLY_LOCK',
    schema: {},
    dashboard: {},
    events: [],
    message: '행사관리센터 읽기전용 잠금 화면 초기 데이터 준비 완료'
  };
  try {
    try { result.userEmail = Session.getActiveUser().getEmail() || Session.getEffectiveUser().getEmail() || ''; } catch (ignoreUser) {}
    var requestedEventId = String((e && e.parameter && e.parameter.eventId) || '').trim();
    result.requestedEventId = requestedEventId;
    result.schema = fhEventOpsV01EnsureSchema({ silent: true });
    result.dashboard = fhEventOpsV01GetDashboard({ silent: true });
    var list = fhEventOpsV01ListEvents({ limit: 50 });
    result.events = list.events || [];
    if (requestedEventId) {
      result.requestedDetail = fhEventOpsV01GetEventDetail({ eventId: requestedEventId });
    }
  } catch (err) {
    result.ok = false;
    result.message = String(err && err.message ? err.message : err);
  }
  return fhEventOpsV01Safe_(result);
}

function runFhEventOpsV01Smoke() {
  var result = {
    ok: true,
    build: FH_EVENT_OPS_V01_BUILD,
    action: 'runFhEventOpsV01Smoke',
    generatedAt: fhEventOpsV01Now_(),
    checks: [],
    message: ''
  };
  function check(key, ok, message) {
    result.checks.push({ key: key, ok: !!ok, message: message });
    if (!ok) result.ok = false;
  }
  try {
    check('ShellReady', typeof fhEventOpsV01HandleGet === 'function', '행사관리 화면 핸들러 확인');
    check('CoreReady', typeof fhEventOpsV01EnsureSchema === 'function', '행사관리 Core 함수 확인');
    check('MasterOpenReady', typeof fhEventOpsV01OpenMaster_ === 'function', 'SystemConfig -> FEELHAUS_DB_MASTER 연결 함수 확인');
    var schema = fhEventOpsV01EnsureSchema({ silent: true });
    check('SchemaReady', schema && schema.ok !== false, '행사관리 V01 필수 시트/헤더 준비 확인');
    result.message = result.ok ? 'FEELHAUS 행사관리센터 읽기전용 잠금 준비 완료' : 'FEELHAUS 행사관리센터 읽기전용 잠금 점검 필요';
  } catch (err) {
    result.ok = false;
    result.message = String(err && err.message ? err.message : err);
  }
  try { Logger.log(JSON.stringify(result, null, 2)); } catch (ignoreLog) {}
  return fhEventOpsV01Safe_(result);
}

function fhEventOpsV01Now_() {
  return Utilities.formatDate(new Date(), Session.getScriptTimeZone() || 'Asia/Seoul', 'yyyy-MM-dd HH:mm:ss');
}

function fhEventOpsV01Safe_(obj) {
  try { return JSON.parse(JSON.stringify(obj || {})); } catch (err) { return obj; }
}
