/**
 * PORTAL_CALENDAR_SAFE01B_R10J2_SCREEN_LAYOUT_POLISH_20260603
 * READ_ONLY verification. No sheet/provider writes.
 */
function portalCalendarSafe01BR10J2ScreenLayoutVerify() {
  var build = 'PORTAL_CALENDAR_SAFE01B_R10J2_SCREEN_LAYOUT_POLISH_20260603';
  var out = { ok:false, build:build, action:'portalCalendarSafe01BR10J2ScreenLayoutVerify', safety:'READ_ONLY_RUNTIME_VERIFY_NO_SHEET_PROVIDER_WRITE', checks:{}, warnings:[], fatal:[] };
  function src_(name) { try { return String(HtmlService.createHtmlOutputFromFile(name).getContent() || ''); } catch(e) { out.warnings.push('html read failed: '+name+' '+e.message); return ''; } }
  var view = src_('MC_CalendarViewV01');
  var checks = out.checks;
  checks.viewR10J2MarkerPresent = view.indexOf(build) >= 0;
  checks.r10j1SafeOpenKept = view.indexOf('fhCalendarRestoreDetailModalR10J1') >= 0 && view.indexOf('수정 화면을 열 수 없습니다') >= 0;
  checks.r10iPayloadKept = view.indexOf('fhCalendarSelectionEditPayloadFinalizeR10I') >= 0;
  checks.r10gUpdateBindingKept = view.indexOf('contactName:manualVal') >= 0 || view.indexOf('contactName: manualVal') >= 0 || view.indexOf('manualContactNamePayloadReady') >= 0;
  checks.manualLayoutCommonReady = view.indexOf('2. 업무 타입 / 공통 연결') >= 0;
  checks.manualLayoutPreSalesReady = view.indexOf('3. 단지 / 입주정보 / 입예협 접촉') >= 0;
  checks.manualLayoutPresentationReady = view.indexOf('4. 제안 / 프레젠테이션 / 조건 협의') >= 0 && view.indexOf('메인 발표자') >= 0 && view.indexOf('정산/수수료 설명 담당') >= 0;
  checks.manualLayoutAgreementReady = view.indexOf('협약식 필요 여부') >= 0 && view.indexOf('협약식예정') >= 0 && view.indexOf('행사관리전환완료') >= 0;
  checks.manualLayoutGeneralReady = view.indexOf('전자결재 ID') >= 0 && view.indexOf('캘린더 표시 방식') >= 0 && view.indexOf('개인/휴무 구분') >= 0;
  checks.oldIptdaeuiContactLabelRemoved = view.indexOf("COUNCIL:'입대의'") < 0 && view.indexOf('<option value="COUNCIL">입대의</option>') < 0;
  checks.preCouncilLabelReady = view.indexOf("COUNCIL:'입예협'") >= 0 && view.indexOf('PRE_COUNCIL_CHAIR') >= 0;
  checks.detailDynamicSectionTitleReady = view.indexOf('operationInfoSectionTitleR10J2') >= 0 && view.indexOf('4. 사전영업 / 선정관리 정보') >= 0 && view.indexOf('4. 행사관리 원장 요약') >= 0 && view.indexOf('4. 일반 / 기타 일정 정보') >= 0;
  checks.detailOldFairOperationTitleRemoved = view.indexOf('<h3>4. 박람회 운영 정보</h3>') < 0;
  checks.r10j2CssReady = view.indexOf('manual-section.r10j-section') >= 0 && view.indexOf('cal-business-section-title-r10j2') >= 0;
  checks.noExtractedTempMarker = view.indexOf('extracted_view') < 0;
  Object.keys(checks).forEach(function(k){ if(!checks[k]) out.fatal.push(k); });
  out.message = out.fatal.length ? 'SAFE-01B R10J2 screen layout verification failed. Check fatal items.' : 'SAFE-01B R10J2 screen layout verification passed.';
  out.ok = out.fatal.length === 0;
  Logger.log('JSON_COMPACT_RESULT: ' + JSON.stringify(out));
  return out;
}
