/**
 * FEELHAUS MailCenter Attachment Library Shell V01
 * Build: MC_ATTACHMENT_LIBRARY_SHELL_V01_20260519
 */

var MC_ATTACHMENT_LIBRARY_SHELL_V01_BUILD = 'MC_ATTACHMENT_LIBRARY_SHELL_V01_20260519';

function runMcAttachmentLibraryShellV01() {
  var result = {
    ok: false,
    build: MC_ATTACHMENT_LIBRARY_SHELL_V01_BUILD,
    action: 'runMcAttachmentLibraryShellV01',
    generatedAt: Utilities.formatDate(new Date(), Session.getScriptTimeZone() || 'Asia/Seoul', 'yyyy-MM-dd HH:mm:ss'),
    message: '',
    checks: []
  };

  try {
    result.checks.push({ key: 'CoreReady', ok: typeof mcAttachmentLibraryCoreV01GetData === 'function', message: '자료함 데이터 함수 확인' });
    result.checks.push({ key: 'UploadReady', ok: typeof mcAttachmentLibraryCoreV01UploadFiles === 'function', message: '다중 업로드 함수 확인' });
    result.checks.push({ key: 'RegisterLinkReady', ok: typeof mcAttachmentLibraryCoreV01RegisterDriveLink === 'function', message: 'Drive 링크 등록 함수 확인' });
    result.checks.push({ key: 'StatusReady', ok: typeof mcAttachmentLibraryCoreV01SetStatus === 'function', message: '상태 변경 함수 확인' });
    result.checks.push({ key: 'HandleGetReady', ok: typeof mcAttachmentLibraryShellV01HandleGet === 'function', message: '자료함 화면 핸들러 확인' });

    result.ok = result.checks.every(function(c) { return !!c.ok; });
    result.message = result.ok ? 'MailCenter Attachment Library Shell V01 준비 완료' : 'MailCenter Attachment Library Shell V01 점검 필요';
  } catch (err) {
    result.ok = false;
    result.message = String(err && err.message ? err.message : err);
  }

  Logger.log('JSON_COMPACT_RESULT: ' + JSON.stringify(result));
  return result;
}

function mcAttachmentLibraryShellV01HandleGet(e) {
  var data = typeof mcAttachmentLibraryCoreV01GetData === 'function'
    ? mcAttachmentLibraryCoreV01GetData({})
    : { ok: false, message: 'mcAttachmentLibraryCoreV01GetData 함수가 없습니다.', attachments: [], summary: {} };

  var t = HtmlService.createTemplateFromFile('MC_AttachmentLibraryViewV01');
  t.build = MC_ATTACHMENT_LIBRARY_SHELL_V01_BUILD;
  t.initialJson = JSON.stringify(data);

  return t.evaluate()
    .setTitle('FEELHAUS MailCenter Attachment Library')
    .setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL);
}
