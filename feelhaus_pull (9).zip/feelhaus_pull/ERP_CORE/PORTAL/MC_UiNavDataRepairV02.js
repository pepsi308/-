
/**
 * FEELHAUS MailCenter UI Nav & Dashboard Send Repair V02
 * Build: MAILCENTER_UI_NAV_DASHBOARD_SEND_REPAIR_V02_20260520
 *
 * Purpose:
 * - 사용자가 HTML View에 직접 스니펫을 넣지 않도록 Router 자동 주입 방식 사용
 * - 왼쪽 메뉴 빈페이지 방지: 모든 ?page 링크를 WebApp 절대주소로 변환
 * - 대시보드 최근 발송 로그 보조 조회
 * - 대시보드 테스트 발송 버튼 브릿지
 * - 기존 발송/자료함/템플릿/설정 Core는 직접 수정하지 않음
 */
var MAILCENTER_UI_REPAIR_V02_BUILD = 'MAILCENTER_UI_NAV_DASHBOARD_SEND_REPAIR_V02_20260520';
var MAILCENTER_UI_REPAIR_V02_FALLBACK_URL = 'https://script.google.com/macros/s/AKfycbxCyFE7zf4vE8nsfjOeWX0pC56SqU84gm8ie8Txa3qHQGEusJCZeljzCdYeOmZxUVYvjA/exec';
var MAILCENTER_UI_REPAIR_V02_SETUP_DB_ID = '17VMSpgSZCvIrUlgcw8yCNcnl8WQWo2IcRf5tDCcuJGM';
var MAILCENTER_UI_REPAIR_V02_CONFIG_SHEET = 'SystemConfig';

function runMcUiNavDataRepairV02Smoke() {
  var result = {ok:false, build:MAILCENTER_UI_REPAIR_V02_BUILD, action:'runMcUiNavDataRepairV02Smoke', generatedAt:mcUiRepairV02Now_(), message:'', checks:[]};
  try {
    var payload = mcUiRepairV02GetPayload();
    result.checks.push({key:'PayloadReady', ok:!!payload && !!payload.baseUrl, message:'공통 UI payload 확인: ' + (payload.baseUrl || '')});
    result.checks.push({key:'NavItemsReady', ok:!!payload && Array.isArray(payload.navItems) && payload.navItems.length >= 8, message:'MailCenter 메뉴 주소 목록 확인'});
    result.checks.push({key:'DashboardRecentLogsReady', ok:typeof mcUiRepairV02GetDashboardRecentLogs === 'function', message:'대시보드 최근 발송 로그 보조 함수 확인'});
    result.checks.push({key:'DashboardSendBridgeReady', ok:typeof mcUiRepairV02SendDashboardTest === 'function', message:'대시보드 테스트 발송 브릿지 확인'});
    result.checks.push({key:'MasterOpenReady', ok:!!mcUiRepairV02OpenMaster_().ss, message:'FEELHAUS_DB_MASTER 연결 확인'});
    result.ok = result.checks.every(function(c){return !!c.ok;});
    result.message = result.ok ? 'MailCenter UI Nav & Dashboard Send Repair V02 준비 완료' : 'MailCenter UI Nav & Dashboard Send Repair V02 점검 필요';
  } catch (err) {
    result.ok = false;
    result.message = String(err && err.message ? err.message : err);
  }
  mcUiRepairV02Log_(result);
  return result;
}

function mcUiRepairV02GetPayload() {
  var baseUrl = mcUiRepairV02GetWebAppUrl_();
  return {
    ok:true,
    build:MAILCENTER_UI_REPAIR_V02_BUILD,
    baseUrl:baseUrl,
    navItems:[
      {label:'대시보드', page:'MailCenterDashboardV04', url:baseUrl + '?page=MailCenterDashboardV04'},
      {label:'메일 작성/발송', page:'MailCenterComposeV01', url:baseUrl + '?page=MailCenterComposeV01'},
      {label:'테스트 발송', page:'MailCenterSendTestV05', url:baseUrl + '?page=MailCenterSendTestV05'},
      {label:'자료함', page:'MailCenterAttachmentLibraryV01', url:baseUrl + '?page=MailCenterAttachmentLibraryV01'},
      {label:'템플릿 관리', page:'MailCenterTemplateV01', url:baseUrl + '?page=MailCenterTemplateV01'},
      {label:'로그/감사 조회', page:'MailCenterLogAuditV01', url:baseUrl + '?page=MailCenterLogAuditV01'},
      {label:'계정 등록/승인', page:'MailCenterAccountAdminV01', url:baseUrl + '?page=MailCenterAccountAdminV01'},
      {label:'서명/폴더/설정', page:'MailCenterSettingsV01', url:baseUrl + '?page=MailCenterSettingsV01'},
      {label:'주소표', page:'MailCenterRouteIndexV03', url:baseUrl + '?page=MailCenterRouteIndexV03'}
    ]
  };
}

function mcUiRepairV02GetDashboardRecentLogs(payload) {
  var result = {ok:false, build:MAILCENTER_UI_REPAIR_V02_BUILD, action:'mcUiRepairV02GetDashboardRecentLogs', generatedAt:mcUiRepairV02Now_(), message:'', logs:[]};
  try {
    var limit = Number((payload && payload.limit) || 10);
    var ss = mcUiRepairV02OpenMaster_().ss;
    var rows = [];
    mcUiRepairV02ReadSheet_(ss, 'MailCenter_SendLogs').forEach(function(r){
      rows.push({
        createdAt:String(r.createdAt || r.requestedAt || r.sentAt || ''),
        fromEmail:String(r.fromEmail || r.mailFrom || r.senderEmail || ''),
        toEmail:String(r.toEmail || r.recipientEmail || ''),
        subject:String(r.subject || ''),
        sendStatus:String(r.sendStatus || r.status || ''),
        statusReason:String(r.statusReason || r.reason || ''),
        gmailMessageId:String(r.gmailMessageId || '')
      });
    });
    if (!rows.length) {
      mcUiRepairV02ReadSheet_(ss, 'MailCenter_ComposeLogs').forEach(function(r){
        rows.push({
          createdAt:String(r.createdAt || ''),
          fromEmail:String(r.fromEmail || r.senderEmail || ''),
          toEmail:String(r.toEmail || ''),
          subject:String(r.subject || ''),
          sendStatus:String(r.composeStatus || r.sendStatus || ''),
          statusReason:String(r.statusReason || ''),
          gmailMessageId:String(r.gmailMessageId || '')
        });
      });
    }
    rows = rows.filter(function(x){return x.createdAt || x.fromEmail || x.toEmail || x.subject || x.sendStatus;})
      .sort(function(a,b){return String(b.createdAt || '').localeCompare(String(a.createdAt || ''));})
      .slice(0, limit);
    result.ok = true;
    result.logs = rows;
    result.message = rows.length ? '최근 발송 로그 조회 완료' : '최근 발송 로그가 없습니다.';
  } catch (err) {
    result.ok = false;
    result.message = String(err && err.message ? err.message : err);
  }
  mcUiRepairV02Log_(result);
  return result;
}

function mcUiRepairV02SendDashboardTest(payload) {
  var result = {ok:false, build:MAILCENTER_UI_REPAIR_V02_BUILD, action:'mcUiRepairV02SendDashboardTest', generatedAt:mcUiRepairV02Now_(), message:'', tried:[], sendResult:null};
  try {
    var p = payload || {};
    var toEmail = String(p.toEmail || '').trim();
    if (!toEmail) throw new Error('수신자 이메일이 필요합니다.');

    var mailAccountId = String(p.mailAccountId || '').trim();
    var fromEmail = String(p.fromEmail || '').trim();

    if (!mailAccountId && fromEmail) {
      mailAccountId = mcUiRepairV02FindMailAccountIdByEmail_(fromEmail);
    }
    if (!mailAccountId) {
      mailAccountId = mcUiRepairV02FindDefaultMailAccountId_();
    }

    var sendPayload = {
      mailAccountId: mailAccountId,
      fromEmail: fromEmail,
      toEmail: toEmail,
      subject: String(p.subject || '[FEELHAUS] 이메일 테스트 발송입니다.'),
      body: String(p.body || '안녕하세요.\nFEELHAUS MailCenter 테스트 발송입니다.\n정상적으로 수신되면 회신 부탁드립니다.\n감사합니다.'),
      attachments: []
    };

    var fnNames = [
      'mcComposeCoreV01Send',
      'mcDriveLinkAttachmentV01SendWithLinks',
      'mailCenterSendTestCoreV01Send',
      'mcSendTestCoreV01Send',
      'mcDashboardSendV05Send',
      'mcDashboardSendShellV05Send'
    ];

    var last = null;
    for (var i = 0; i < fnNames.length; i++) {
      var name = fnNames[i];
      if (typeof this[name] !== 'function') continue;
      result.tried.push(name);
      try {
        var sent = this[name](sendPayload);
        last = sent;
        if (sent && sent.ok) {
          result.ok = true;
          result.sendResult = sent;
          result.message = '대시보드 테스트 발송 완료';
          mcUiRepairV02Log_(result);
          return result;
        }
      } catch (inner) {
        last = {ok:false, message:String(inner && inner.message ? inner.message : inner)};
      }
    }

    result.sendResult = last;
    throw new Error((last && last.message) ? last.message : '사용 가능한 발송 함수가 없습니다.');
  } catch (err) {
    result.ok = false;
    result.message = String(err && err.message ? err.message : err);
  }
  mcUiRepairV02Log_(result);
  return result;
}

function mcUiRepairV02GetAccountAdminData(payload) {
  var result = {ok:false, build:MAILCENTER_UI_REPAIR_V02_BUILD, action:'mcUiRepairV02GetAccountAdminData', generatedAt:mcUiRepairV02Now_(), message:'', data:null};
  try {
    if (typeof mcAccountAdminLinkedV01GetAdminData === 'function') {
      var data = mcAccountAdminLinkedV01GetAdminData(payload || {});
      result.ok = !!(data && data.ok);
      result.data = data;
      result.message = result.ok ? '계정 등록/승인 데이터 재조회 완료' : ((data && data.message) || '계정 데이터 조회 실패');
      return result;
    }
    if (typeof mcAccountAdminLinkedV01GetData === 'function') {
      var data2 = mcAccountAdminLinkedV01GetData(payload || {});
      result.ok = !!(data2 && data2.ok);
      result.data = data2;
      result.message = result.ok ? '계정 등록/승인 데이터 재조회 완료' : ((data2 && data2.message) || '계정 데이터 조회 실패');
      return result;
    }
    throw new Error('계정 등록/승인 데이터 함수가 없습니다.');
  } catch (err) {
    result.ok = false;
    result.message = String(err && err.message ? err.message : err);
  }
  mcUiRepairV02Log_(result);
  return result;
}

function mcUiRepairV02FindMailAccountIdByEmail_(email) {
  var ss = mcUiRepairV02OpenMaster_().ss;
  var rows = mcUiRepairV02ReadSheet_(ss, 'MailCenter_Accounts');
  var target = String(email || '').toLowerCase().trim();
  for (var i = 0; i < rows.length; i++) {
    var r = rows[i];
    var e = String(r.emailAddress || r.accountEmail || r.mailAddress || r.email || '').toLowerCase().trim();
    if (e && e === target) return String(r.mailAccountId || r.accountId || '');
  }
  return '';
}

function mcUiRepairV02FindDefaultMailAccountId_() {
  var ss = mcUiRepairV02OpenMaster_().ss;
  var rows = mcUiRepairV02ReadSheet_(ss, 'MailCenter_Accounts');
  for (var i = 0; i < rows.length; i++) {
    var r = rows[i];
    if (String(r.isDefault || r.defaultYn || '').toUpperCase() === 'TRUE' || String(r.isDefault || r.defaultYn || '') === '예') {
      return String(r.mailAccountId || r.accountId || '');
    }
  }
  for (var j = 0; j < rows.length; j++) {
    var a = rows[j];
    if (String(a.connectionStatus || '').toUpperCase() === 'CONNECTED' && String(a.accountStatus || a.status || '').toUpperCase() === 'ACTIVE') {
      return String(a.mailAccountId || a.accountId || '');
    }
  }
  return rows.length ? String(rows[0].mailAccountId || rows[0].accountId || '') : '';
}

function mcUiRepairV02GetWebAppUrl_() {
  var url = '';
  try { url = ScriptApp.getService().getUrl() || ''; } catch (err) { url = ''; }
  if (!url) url = MAILCENTER_UI_REPAIR_V02_FALLBACK_URL;
  return String(url || '').trim();
}

function mcUiRepairV02OpenMaster_() {
  if (typeof portal19GetConfigBundle_ === 'function' && typeof portal19OpenMaster_ === 'function') {
    var bundle = portal19GetConfigBundle_();
    var ssByPortal = portal19OpenMaster_(bundle);
    if (ssByPortal) return {ss:ssByPortal, masterDbId:bundle.masterDbId || ''};
  }
  var setup = SpreadsheetApp.openById(MAILCENTER_UI_REPAIR_V02_SETUP_DB_ID);
  var configSheet = setup.getSheetByName(MAILCENTER_UI_REPAIR_V02_CONFIG_SHEET);
  if (!configSheet) throw new Error('SystemConfig 시트를 찾지 못했습니다.');
  var values = configSheet.getDataRange().getValues();
  var hm = mcUiRepairV02HeaderMap_(values[0]);
  var keyCol = mcUiRepairV02FindHeader_(hm, ['CONFIG_KEY','configKey','KEY','key']);
  var valCol = mcUiRepairV02FindHeader_(hm, ['VALUE','CONFIG_VALUE','configValue','value']);
  var masterId = '';
  for (var r=1; r<values.length; r++) {
    var key = String(values[r][keyCol] || '').trim();
    if (key === 'FEELHAUS_DB_MASTER' || key === 'FEELHAUS_DB_MASTER_ID' || key === 'MASTER_DB_ID') {
      masterId = String(values[r][valCol] || '').trim();
      break;
    }
  }
  if (!masterId) throw new Error('SystemConfig에서 FEELHAUS_DB_MASTER ID를 찾지 못했습니다.');
  return {ss:SpreadsheetApp.openById(masterId), masterDbId:masterId};
}

function mcUiRepairV02ReadSheet_(ss, sheetName) {
  var sh = ss.getSheetByName(sheetName);
  if (!sh) return [];
  var values = sh.getDataRange().getValues();
  if (!values || values.length < 2) return [];
  var headers = values[0];
  var rows = [];
  for (var r=1; r<values.length; r++) {
    var obj = {};
    for (var c=0; c<headers.length; c++) {
      var key = String(headers[c] || '').trim();
      if (!key) continue;
      var v = values[r][c];
      obj[key] = v instanceof Date ? Utilities.formatDate(v, Session.getScriptTimeZone() || 'Asia/Seoul', 'yyyy-MM-dd HH:mm:ss') : v;
    }
    rows.push(obj);
  }
  return rows;
}

function mcUiRepairV02HeaderMap_(header) {
  var hm = {};
  for (var i=0; i<header.length; i++) {
    var raw = String(header[i] || '').trim();
    if (!raw) continue;
    hm[raw] = i;
    hm[mcUiRepairV02Normalize_(raw)] = i;
  }
  return hm;
}
function mcUiRepairV02FindHeader_(hm, names) {
  for (var i=0; i<names.length; i++) {
    if (hm[names[i]] != null) return hm[names[i]];
    var norm = mcUiRepairV02Normalize_(names[i]);
    if (hm[norm] != null) return hm[norm];
  }
  return -1;
}
function mcUiRepairV02Normalize_(v){return String(v || '').trim().toUpperCase().replace(/[^A-Z0-9]/g,'');}
function mcUiRepairV02Now_(){return Utilities.formatDate(new Date(), Session.getScriptTimeZone() || 'Asia/Seoul', 'yyyy-MM-dd HH:mm:ss');}
function mcUiRepairV02Log_(obj){try{Logger.log('JSON_COMPACT_RESULT: ' + JSON.stringify(obj));}catch(e){Logger.log(obj);}}
