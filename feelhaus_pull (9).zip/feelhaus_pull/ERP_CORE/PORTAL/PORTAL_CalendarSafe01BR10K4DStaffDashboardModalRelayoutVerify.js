function portalCalendarSafe01BR10K4DStaffDashboardModalRelayoutVerify(){
  var build='PORTAL_CALENDAR_SAFE01B_R10K4D_STAFF_DASHBOARD_MODAL_RELAYOUT_20260604';
  var html='';var readError='';
  try{html=HtmlService.createHtmlOutputFromFile('MC_CalendarViewV01').getContent();}catch(e){readError=String(e&&e.message||e);}
  function has(x){return html.indexOf(x)>=0;}
  function idx(x){return html.indexOf(x);}
  var dashboardIdx=idx('data-r10k4d-staff-dashboard');
  var briefIdx=dashboardIdx>=0?html.indexOf('compactBriefR10K4D',dashboardIdx):idx('data-r10k4d-compact-brief');
  var typeIdx=dashboardIdx>=0?html.indexOf('typeTabsR10K4D',dashboardIdx):idx('data-r10k4d-type-panel');
  var selectedIdx=dashboardIdx>=0?html.indexOf('data-r10k4d-selected-detail',dashboardIdx):idx('data-r10k4d-selected-detail');
  var lowerIdx=dashboardIdx>=0?html.indexOf('data-r10k4d-lower-zone',dashboardIdx):idx('data-r10k4d-lower-zone');
  var ledgerIdx=idx('기본 원장 카드 더보기');
  var checks={
    viewReadable:!!html&&!readError,
    r10k4dBuildMarkerPresent:has(build),
    modalWideExpanded:has('r10k4d-wide')&&has('width:min(1480px,99vw)')&&has('max-height:95vh'),
    compactBriefFunctionReady:has('function fhCalendarR10K4DCompactBriefHtml')&&has('data-r10k4d-compact-brief'),
    compactBriefUsesLimitedDashboard:has('r10k4d-brief-grid')&&has('대표 다음 액션')&&has('연결 행사')&&has('eventId'),
    typePanelCompactReady:has('function fhCalendarR10K4DTypePanelHtml')&&has('data-r10k4d-type-panel')&&has('r10k4d-type-card'),
    dashboardShellReady:dashboardIdx>=0&&has('r10k4d-hero-grid')&&has('r10k4d-selected-detail'),
    selectedDetailBeforeLower:dashboardIdx>=0&&briefIdx>dashboardIdx&&typeIdx>dashboardIdx&&selectedIdx>typeIdx&&lowerIdx>selectedIdx,
    selectedDetailBeforeLedger:ledgerIdx<0||selectedIdx<ledgerIdx,
    eventDetailCardReady:has('3. 행사관리 상세 카드 / ERP_행사관리 원장')&&has('data-r10k4-event-detail'),
    selectionDetailCardReady:has('3. 박람회 선정 과정 상세 카드')&&has('data-r10k4-selection-detail'),
    generalDetailCardReady:has('3. 일반/기타 일정 상세 카드')&&has('data-r10k4-general-detail'),
    oldHugeFaceNotUsedInMainRender:html.indexOf("'+detailFaceR10K+'")<0&&html.indexOf('var detailFaceR10K=')<0,
    lowerSectionsFolded:has('업무 본문 / 외부 캘린더 본문 보기')&&has('기본 원장 카드 더보기')&&has('외부 반영 상태 보기')&&has('관리자/진단 보기'),
    r10k2EventMasterKept:has('me_eventMasterPicker')&&has('ERP_행사관리')&&has('fhCalendarR10K2EventMaster'),
    r11AutoRefreshKept:has('fhCalendarStartAutoRefreshR11')&&has('setInterval(fhCalendarCheckPageRefreshR11,30000)'),
    providerWriteNotAddedInR10K4D:html.indexOf('CalendarApp.createEvent')<0&&html.indexOf('UrlFetchApp.fetch')<0,
    noSheetProviderWriteInVerify:true
  };
  var fatal=[];Object.keys(checks).forEach(function(k){if(!checks[k])fatal.push(k);});
  var res={ok:fatal.length===0,build:build,baseBuild:'PORTAL_CALENDAR_SAFE01B_R10K4C_STAFF_MODAL_LAYOUT_REAL_MATCH_20260604',action:'portalCalendarSafe01BR10K4DStaffDashboardModalRelayoutVerify',safety:'READ_ONLY_RUNTIME_VERIFY_NO_SHEET_PROVIDER_WRITE',checks:checks,diagnostics:{htmlLength:html.length,readError:readError,order:{dashboardIdx:dashboardIdx,briefIdx:briefIdx,typeIdx:typeIdx,selectedIdx:selectedIdx,lowerIdx:lowerIdx,ledgerIdx:ledgerIdx}},warnings:[],fatal:fatal,summary:{mode:'R10K4D staff dashboard modal relayout',detail:'상세 모달 첫 화면을 직원용 대시보드로 재배치하고 기존 대형 상세 얼굴을 컴팩트 브리핑으로 교체',layout:'상단: 컴팩트 브리핑 + 업무 타입 구분 / 바로 아래: 선택 업무 타입 상세 카드 / 하단: 원장·본문·이력·진단 접힘',preserved:'R10K2 ERP_행사관리 eventId 연결과 R11 자동갱신 유지'},message:fatal.length?'R10K4D verification failed.':'R10K4D staff dashboard modal relayout verification passed.'};
  Logger.log('JSON_COMPACT_RESULT: '+JSON.stringify(res));
  return res;
}
function portalCalendarSafe01BR10K4DStaffDashboardVerify(){return portalCalendarSafe01BR10K4DStaffDashboardModalRelayoutVerify();}
function portalCalendarSafe01BR10K4DModalRelayoutVerify(){return portalCalendarSafe01BR10K4DStaffDashboardModalRelayoutVerify();}
