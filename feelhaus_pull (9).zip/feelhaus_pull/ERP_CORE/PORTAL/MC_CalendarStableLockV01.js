/**
 * FEELHAUS MailCenter Calendar Stable Lock V01
 * Build: MAILCENTER_CALENDAR_STABLE_LOCK_V01_20260521
 * Purpose:
 * - Create actual backup spreadsheet for MailCenter calendar stable scope
 * - Append stable lock record to FEELHAUS_DB_MASTER
 * - Do not modify router/menu/html/calendar UI files
 */
var MC_CALENDAR_STABLE_LOCK_V01_BUILD = 'MAILCENTER_CALENDAR_STABLE_LOCK_V01_20260521';
var MC_CALENDAR_STABLE_LOCK_V01_SETUP_DB_ID = '17VMSpgSZCvIrUlgcw8yCNcnl8WQWo2IcRf5tDCcuJGM';
var MC_CALENDAR_STABLE_LOCK_V01_CONFIG_SHEET = 'SystemConfig';
var MC_CALENDAR_STABLE_LOCK_V01_WEBAPP_URL = 'https://script.google.com/a/macros/feelhausfair.com/s/AKfycbxCyFE7zf4vE8nsfjOeWX0pC56SqU84gm8ie8Txa3qHQGEusJCZeljzCdYeOmZxUVYvjA/exec';

function runMcCalendarStableLockV01Smoke() {
  var result = {
    ok: true,
    build: MC_CALENDAR_STABLE_LOCK_V01_BUILD,
    action: 'runMcCalendarStableLockV01Smoke',
    generatedAt: mcCalendarStableLockV01Now_(),
    noWriteMode: true,
    checks: []
  };
  function check(key, ok, message, detail) {
    result.checks.push({ key: key, ok: !!ok, message: message, detail: detail || '' });
    if (!ok) result.ok = false;
  }
  try {
    check('MasterOpenReady', !!mcCalendarStableLockV01OpenMaster_(), 'SystemConfig -> FEELHAUS_DB_MASTER 연결 확인', 'FEELHAUS_DB_MASTER');
    check('BackupFunctionReady', typeof runMcCalendarStableLockV01CreateBackupAndLock === 'function', '실제 백업/잠금 함수 확인');
    check('WebAppUrlReady', !!MC_CALENDAR_STABLE_LOCK_V01_WEBAPP_URL, 'WebApp 절대주소 확인', MC_CALENDAR_STABLE_LOCK_V01_WEBAPP_URL);
    check('NoRouterMenuHtmlTouch', true, '본 파일은 라우터/메뉴/HTML 변경 없음');
    result.message = result.ok ? 'MailCenter Calendar Stable Lock V01 Smoke 통과' : 'MailCenter Calendar Stable Lock V01 점검 필요';
  } catch (err) {
    result.ok = false;
    result.message = mcCalendarStableLockV01Err_(err);
  }
  return result;
}

function runMcCalendarStableLockV01CreateBackupAndLock() {
  var result = {
    ok: false,
    build: MC_CALENDAR_STABLE_LOCK_V01_BUILD,
    action: 'runMcCalendarStableLockV01CreateBackupAndLock',
    generatedAt: mcCalendarStableLockV01Now_(),
    lockId: '',
    backupSpreadsheetId: '',
    backupName: '',
    copiedSheets: [],
    message: ''
  };
  var actor = mcCalendarStableLockV01Actor_();
  try {
    var master = mcCalendarStableLockV01OpenMaster_();
    var now = mcCalendarStableLockV01Now_();
    var stamp = Utilities.formatDate(new Date(), Session.getScriptTimeZone() || 'Asia/Seoul', 'yyyyMMdd_HHmmss');
    var lockId = 'MCALLOCK-' + Utilities.formatDate(new Date(), Session.getScriptTimeZone() || 'Asia/Seoul', 'yyyyMMddHHmmss') + '-' + Utilities.getUuid().substring(0, 8).toUpperCase();
    var backupName = 'MAILCENTER_CALENDAR_STABLE_BACKUP_' + stamp;
    var backup = SpreadsheetApp.create(backupName);
    var backupId = backup.getId();

    var targetSheets = ['MAILCENTER_CalendarEvents', 'MAILCENTER_CalendarMailLinks', 'MAILCENTER_CalendarLogs'];
    var copied = [];
    targetSheets.forEach(function(sheetName) {
      var src = master.getSheetByName(sheetName);
      if (src) {
        var copy = src.copyTo(backup);
        copy.setName(sheetName);
        copied.push({ sheetName: sheetName, rows: src.getLastRow(), cols: src.getLastColumn() });
      } else {
        copied.push({ sheetName: sheetName, rows: 0, cols: 0, missing: true });
      }
    });

    var defaultSheet = backup.getSheetByName('Sheet1');
    if (defaultSheet && backup.getSheets().length > 1) backup.deleteSheet(defaultSheet);

    var info = backup.insertSheet('LOCK_INFO');
    var infoRows = [
      ['key', 'value'],
      ['lockId', lockId],
      ['build', MC_CALENDAR_STABLE_LOCK_V01_BUILD],
      ['stableGateBuild', 'MAILCENTER_CALENDAR_STABLE_GATE_V01_20260521'],
      ['monthUiBuild', 'MAILCENTER_CALENDAR_MONTH_UI_V01_20260521'],
      ['mailLinkBuild', 'MAILCENTER_CALENDAR_MAIL_LINK_V01_20260521'],
      ['navUrlFixBuild', 'MAILCENTER_CALENDAR_NAV_URL_FIX_V01_20260521'],
      ['webAppUrl', MC_CALENDAR_STABLE_LOCK_V01_WEBAPP_URL],
      ['sourceMasterId', master.getId()],
      ['backupSpreadsheetId', backupId],
      ['lockedAt', now],
      ['lockedBy', actor],
      ['status', 'STABLE_LOCKED'],
      ['scope', 'MailCenter calendar stages 1-4 + stable gate + backup dry run'],
      ['note', 'Router/menu/html route structure not modified by this lock file']
    ];
    info.getRange(1, 1, infoRows.length, 2).setValues(infoRows);
    info.setFrozenRows(1);

    mcCalendarStableLockV01AppendByHeaders_(master, 'MAILCENTER_CalendarStableLocks', mcCalendarStableLockV01LockHeaders_(), {
      lockId: lockId,
      build: MC_CALENDAR_STABLE_LOCK_V01_BUILD,
      stableGateBuild: 'MAILCENTER_CALENDAR_STABLE_GATE_V01_20260521',
      backupName: backupName,
      backupSpreadsheetId: backupId,
      webAppUrl: MC_CALENDAR_STABLE_LOCK_V01_WEBAPP_URL,
      status: 'STABLE_LOCKED',
      statusReason: 'MailCenter 캘린더 1~4단계 안정 게이트 및 백업 잠금 완료',
      copiedSheetsJson: JSON.stringify(copied),
      createdAt: now,
      createdBy: actor,
      updatedAt: now,
      updatedBy: actor
    });

    try {
      if (typeof mcCalendar19AppendAuditLog_ === 'function') {
        mcCalendar19AppendAuditLog_('MAILCENTER_CALENDAR_STABLE_LOCK', actor, lockId, 'SUCCESS', 'MailCenter 캘린더 안정 잠금 완료', { backupSpreadsheetId: backupId, backupName: backupName });
      }
    } catch (auditErr) {}

    result.ok = true;
    result.lockId = lockId;
    result.backupSpreadsheetId = backupId;
    result.backupName = backupName;
    result.copiedSheets = copied;
    result.message = 'MailCenter Calendar Stable Lock V01 완료';
  } catch (err) {
    result.ok = false;
    result.message = mcCalendarStableLockV01Err_(err);
  }
  return result;
}

function mcCalendarStableLockV01LockHeaders_() {
  return ['lockId','build','stableGateBuild','backupName','backupSpreadsheetId','webAppUrl','status','statusReason','copiedSheetsJson','createdAt','createdBy','updatedAt','updatedBy'];
}

function mcCalendarStableLockV01AppendByHeaders_(ss, sheetName, baseHeaders, record) {
  var sheet = mcCalendarStableLockV01GetSheetOrCreate_(ss, sheetName, baseHeaders);
  mcCalendarStableLockV01EnsureHeaders_(sheet, Object.keys(record || {}));
  var headers = sheet.getRange(1, 1, 1, sheet.getLastColumn()).getValues()[0];
  var hm = mcCalendarStableLockV01HeaderMap_(headers);
  var row = [];
  for (var i = 0; i < headers.length; i++) row.push('');
  Object.keys(record || {}).forEach(function(key) {
    if (hm.hasOwnProperty(key)) row[hm[key]] = record[key];
  });
  sheet.appendRow(row);
}

function mcCalendarStableLockV01GetSheetOrCreate_(ss, name, headers) {
  var sheet = ss.getSheetByName(name);
  if (!sheet) {
    sheet = ss.insertSheet(name);
    sheet.getRange(1, 1, 1, headers.length).setValues([headers]);
    sheet.setFrozenRows(1);
    return sheet;
  }
  if (sheet.getLastRow() < 1 || sheet.getLastColumn() < 1) {
    sheet.getRange(1, 1, 1, headers.length).setValues([headers]);
    sheet.setFrozenRows(1);
    return sheet;
  }
  mcCalendarStableLockV01EnsureHeaders_(sheet, headers);
  return sheet;
}

function mcCalendarStableLockV01EnsureHeaders_(sheet, requiredHeaders) {
  var lastCol = Math.max(sheet.getLastColumn(), 1);
  var headers = sheet.getRange(1, 1, 1, lastCol).getValues()[0];
  var hm = mcCalendarStableLockV01HeaderMap_(headers);
  var add = [];
  (requiredHeaders || []).forEach(function(h) { if (h && !hm.hasOwnProperty(h)) add.push(h); });
  if (add.length) sheet.getRange(1, headers.length + 1, 1, add.length).setValues([add]);
}

function mcCalendarStableLockV01OpenMaster_() {
  var setup = SpreadsheetApp.openById(MC_CALENDAR_STABLE_LOCK_V01_SETUP_DB_ID);
  var sheet = setup.getSheetByName(MC_CALENDAR_STABLE_LOCK_V01_CONFIG_SHEET);
  if (!sheet) throw new Error('SystemConfig 시트를 찾지 못했습니다.');
  var values = sheet.getDataRange().getValues();
  if (!values || values.length < 2) throw new Error('SystemConfig 데이터가 비어 있습니다.');
  var hm = mcCalendarStableLockV01HeaderMap_(values[0]);
  var keyCol = mcCalendarStableLockV01PickIndex_(hm, ['CONFIG_KEY','configKey','key','name']);
  var valCol = mcCalendarStableLockV01PickIndex_(hm, ['VALUE','configValue','value','spreadsheetId']);
  if (keyCol < 0 || valCol < 0) throw new Error('SystemConfig CONFIG_KEY/VALUE 헤더를 찾지 못했습니다.');
  var masterId = '';
  for (var r = 1; r < values.length; r++) {
    var key = String(values[r][keyCol] || '').trim();
    if (key === 'FEELHAUS_DB_MASTER' || key === 'FEELHAUS_DB_MASTER_ID' || key === 'MASTER_DB_ID') {
      masterId = String(values[r][valCol] || '').trim();
      break;
    }
  }
  if (!masterId) throw new Error('SystemConfig에서 FEELHAUS_DB_MASTER ID를 찾지 못했습니다.');
  return SpreadsheetApp.openById(masterId);
}

function mcCalendarStableLockV01HeaderMap_(headers) {
  var out = {};
  (headers || []).forEach(function(h, i) {
    var key = String(h || '').trim();
    if (key) out[key] = i;
  });
  return out;
}

function mcCalendarStableLockV01PickIndex_(hm, keys) {
  for (var i = 0; i < keys.length; i++) if (hm.hasOwnProperty(keys[i])) return hm[keys[i]];
  return -1;
}

function mcCalendarStableLockV01Actor_() {
  return String(Session.getActiveUser().getEmail() || 'MAILCENTER_ADMIN').trim() || 'MAILCENTER_ADMIN';
}

function mcCalendarStableLockV01Now_() {
  return Utilities.formatDate(new Date(), Session.getScriptTimeZone() || 'Asia/Seoul', 'yyyy-MM-dd HH:mm:ss');
}

function mcCalendarStableLockV01Err_(err) {
  return err && err.message ? err.message : String(err);
}
