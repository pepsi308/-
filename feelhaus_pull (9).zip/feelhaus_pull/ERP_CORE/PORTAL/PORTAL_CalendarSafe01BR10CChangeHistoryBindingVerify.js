/**
 * FEELHAUS PORTAL Calendar SAFE-01B R10C change-history binding verification.
 * READ_ONLY_RUNTIME_VERIFY_NO_SHEET_PROVIDER_WRITE.
 * Purpose: verify actual detail response and view binding paths, not marker-only checks.
 */
function portalCalendarSafe01BR10CChangeHistoryBindingVerify(targetCalendarEventId) {
  var build = 'PORTAL_CALENDAR_SAFE01B_R10C_DETAIL_BINDING_FIX_20260603';
  var sampleId = String(targetCalendarEventId || 'MCAL-MANUAL-20260602225343-22A21C6A').trim();
  var result = {
    ok: false,
    build: build,
    action: 'portalCalendarSafe01BR10CChangeHistoryBindingVerify',
    safety: 'READ_ONLY_RUNTIME_VERIFY_NO_SHEET_PROVIDER_WRITE',
    calendarEventId: sampleId,
    checks: {},
    warnings: [],
    fatal: [],
    detailShape: {},
    realApplyExecuted: false,
    sheetCreated: false,
    headersAdded: false,
    actualDeleteExecuted: false,
    actualStatusUpdateExecuted: false
  };
  function add(key, ok, fatal) {
    result.checks[key] = !!ok;
    if (!ok) {
      if (fatal) result.fatal.push(key);
      else result.warnings.push(key);
    }
  }
  function raw(name) {
    try { return HtmlService.createTemplateFromFile(name).getRawContent(); } catch (e) { return ''; }
  }
  function has(src, token) { return String(src || '').indexOf(token) >= 0; }
  function text(v) {
    if (v === null || v === undefined) return '';
    var s = String(v).trim();
    if (!s || s === '[]' || s === '{}' || s.toLowerCase() === 'null' || s.toLowerCase() === 'undefined') return '';
    return s;
  }
  try {
    var view = raw('MC_CalendarViewV01');
    add('detailFunctionReady', typeof mcCalendarDetailCoreV01GetDetail === 'function', true);
    add('viewR10CKept', has(view, 'PORTAL_CALENDAR_SAFE01B_R10C_DETAIL_BINDING_FIX_20260603'), true);
    add('viewUsesRecordAliasFirst', has(view, 'res.record||res.event'), true);
    add('viewReadsChangeHistoryChangeReason', has(view, 'summary.changeReason'), true);
    add('viewReadsRecordChangeReasonFallback', has(view, "detailVal(ev,'changeReason')") && has(view, 'e.changeReason'), true);
    add('viewReadsChangeHistoryLastChangedFields', has(view, 'summary.lastChangedFields'), true);
    add('viewReadsRecordLastChangedFieldsFallback', has(view, "detailVal(ev,'lastChangedFields')") && has(view, 'e.lastChangedFields'), true);
    add('fieldKoreanLabelStartEndReady', has(view, "startAt:'시작'") && has(view, "endAt:'종료'"), true);
    add('fieldKoreanLabelProviderReady', has(view, "googleSyncStatus:'Google 상태'") && has(view, "naverSyncStatus:'NAVER 상태'"), true);
    add('fieldKoreanLabelOperationReady', has(view, "participantJson:'참여 담당자'") && has(view, "externalPartyJson:'외부 참석자'") && has(view, "agendaJson:'회의 안건'"), true);

    var detail = mcCalendarDetailCoreV01GetDetail({ calendarEventId: sampleId, verifyMode: 'R10C_CHANGE_HISTORY_BINDING' });
    var record = (detail && (detail.record || detail.event)) || {};
    var summary = (detail && detail.changeHistory) || {};
    var changeReason = text(summary.changeReason) || text(record.changeReason) || text(record.statusReason);
    var lastChangedFields = text(summary.lastChangedFields) || text(record.lastChangedFields);
    result.detailShape = {
      ok: !!(detail && detail.ok),
      sourceSheet: detail && detail.sourceSheet || '',
      rowNumber: detail && detail.rowNumber || 0,
      hasRecord: !!(detail && detail.record),
      hasEvent: !!(detail && detail.event),
      changeLogCount: detail && detail.changeLogs ? detail.changeLogs.length : 0,
      changeHistorySource: summary.source || '',
      updatedAt: text(summary.updatedAt) || text(record.updatedAt),
      updatedByName: text(summary.updatedByName) || text(record.updatedByName),
      updatedByEmail: text(summary.updatedByEmail) || text(record.updatedByEmail),
      changeReason: changeReason,
      lastChangedFields: lastChangedFields
    };
    add('detailReturnsOkForSample', !!(detail && detail.ok), true);
    add('detailReturnsRecordAlias', !!(detail && detail.record), true);
    add('detailReturnsChangeHistoryObject', !!(detail && detail.changeHistory), true);
    add('detailHasUpdatedAt', !!result.detailShape.updatedAt, true);
    add('detailHasUpdatedByName', !!result.detailShape.updatedByName, true);
    add('detailHasUpdatedByEmail', !!result.detailShape.updatedByEmail, true);
    add('detailHasChangeReason', !!changeReason, true);
    add('detailHasLastChangedFields', !!lastChangedFields, true);

    add('r7dAutosyncKept', typeof portalCalendarExternalAutoSyncV01 === 'function' && (typeof portalCalendarExternalAutoSyncV01R7DMarker_ === 'function' || typeof portalCalendarExternalAutoSyncV01R7DRuntimeVerifyMarker_ === 'function'), false);
    add('r8ViewKept', has(view, 'PORTAL_CALENDAR_SAFE01B_R8_VIEW_DISPLAY_CLEAN_20260602'), true);
    add('r9cStrictUpdateGateKept', typeof mcCalendarOperationHubV01ResolveStrictUpdateActorR9C_ === 'function' || typeof mcCalendarOperationHubV01R9CStrictUpdateGateMarker_ === 'function', true);
    add('noLoginGateRequired', !has(view, 'sid 필수') && !has(view, 'loginGateRequired'), true);
    result.ok = result.fatal.length === 0;
    result.message = result.ok
      ? 'SAFE-01B R10C change-history binding verification passed.'
      : 'SAFE-01B R10C verification failed. Check fatal checks and detailShape.';
    result.expectedModal = {
      recentModified: result.detailShape.updatedAt,
      updater: result.detailShape.updatedByName + (result.detailShape.updatedByEmail ? ' [' + result.detailShape.updatedByEmail + ']' : ''),
      changeReason: changeReason,
      lastChangedFields: lastChangedFields
    };
  } catch (err) {
    result.ok = false;
    result.fatal.push('exception');
    result.message = err && err.message ? err.message : String(err);
    result.stack = err && err.stack ? err.stack : '';
  }
  Logger.log('JSON_COMPACT_RESULT: ' + JSON.stringify(result));
  return result;
}
