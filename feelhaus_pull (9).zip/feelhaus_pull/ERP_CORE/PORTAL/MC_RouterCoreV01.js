/**
 * FEELHAUS MailCenter Router Core V01
 * Build: MAILCENTER_CALENDAR_LINK_V01_20260521
 * Rollback: NO AUTO INJECT
 *
 * Purpose:
 * - UI Auto Repair V02 자동주입 제거
 * - 화면 HTML을 감싸거나 getContent로 재작성하지 않음
 * - RouteIndex V03 route는 유지
 * - 성공한 각 화면 핸들러 원본 반환
 */

var MC_ROUTER_CORE_V01_BUILD = 'MAILCENTER_CALENDAR_LINK_V01_20260521';

function runMcRouterCoreV01Check() {
  var result = {
    ok: false,
    build: MC_ROUTER_CORE_V01_BUILD,
    action: 'runMcRouterCoreV01Check',
    generatedAt: mcRouterCoreV01Now_(),
    message: '',
    routes: mcRouterCoreV01ListRoutes_(),
    checks: []
  };

  try {
    result.checks.push({
      key: 'RouteIndexV03Ready',
      ok: typeof mcRouteIndexV03HandleGet === 'function',
      message: 'MailCenterRouteIndexV03 핸들러 확인'
    });
    result.checks.push({
      key: 'RouteIndexV02Ready',
      ok: typeof mcRouteIndexV02HandleGet === 'function',
      message: 'MailCenterRouteIndexV02 핸들러 확인'
    });
    result.checks.push({
      key: 'RouteIndexV01Ready',
      ok: typeof mcRouteIndexV01HandleGet === 'function',
      message: 'MailCenterRouteIndexV01 핸들러 확인'
    });
    result.checks.push({
      key: 'DashboardV04Ready',
      ok: typeof mcDashboardShellV04HandleGet === 'function',
      message: 'MailCenterDashboardV04 핸들러 확인'
    });
    result.checks.push({
      key: 'SendTestV05Ready',
      ok: typeof mcDashboardSendShellV05HandleGet === 'function',
      message: 'MailCenterSendTestV05 핸들러 확인'
    });
    result.checks.push({
      key: 'ServerMailListV01Ready',
      ok: typeof mcServerMailListShellV01HandleGet === 'function',
      message: 'MailCenterServerMailListV01 핸들러 확인'
    });

    result.checks.push({
      key: 'CalendarV01Ready',
      ok: typeof mcCalendarShellV01HandleGet === 'function',
      message: 'MailCenterCalendarV01 핸들러 확인'
    });
    result.checks.push({
      key: 'ComposeV01Ready',
      ok: typeof mcComposeShellV01HandleGet === 'function',
      message: 'MailCenterComposeV01 핸들러 확인'
    });
    result.checks.push({
      key: 'AttachmentLibraryV01Ready',
      ok: typeof mcAttachmentLibraryShellV01HandleGet === 'function',
      message: 'MailCenterAttachmentLibraryV01 핸들러 확인'
    });
    result.checks.push({
      key: 'TemplateV01Ready',
      ok: typeof mcTemplateShellV01HandleGet === 'function',
      message: 'MailCenterTemplateV01 핸들러 확인'
    });
    result.checks.push({
      key: 'AccountAdminV01Ready',
      ok: typeof mcAccountAdminShellV01HandleGet === 'function',
      message: 'MailCenterAccountAdminV01 핸들러 확인'
    });
    result.checks.push({
      key: 'SettingsV01Ready',
      ok: typeof mcSettingsShellV01HandleGet === 'function',
      message: 'MailCenterSettingsV01 핸들러 확인'
    });
    result.checks.push({
      key: 'LogAuditV01Ready',
      ok: typeof mcLogAuditShellV01HandleGet === 'function',
      message: 'MailCenterLogAuditV01 핸들러 확인'
    });
    result.checks.push({
      key: 'StandaloneFallbackReady',
      ok: typeof mailCenterStandaloneHandleGet === 'function',
      message: '기존 MailCenterStandalone 핸들러 확인'
    });
    result.checks.push({
      key: 'Portal169FallbackReady',
      ok: typeof portal169HandleGet === 'function',
      message: '기존 MailCenter169 핸들러 확인'
    });
    result.checks.push({
      key: 'RouterFunctionReady',
      ok: typeof mcRouterHandleGet === 'function',
      message: 'mcRouterHandleGet 함수 확인'
    });
    result.checks.push({
      key: 'AutoInjectRemoved',
      ok: typeof mcRouterCoreV01WrapOutput_ !== 'function',
      message: 'UI 자동주입 제거 확인'
    });

    result.ok = result.checks.every(function(c) { return !!c.ok; });
    result.message = result.ok
      ? 'MailCenter Router Core V01 롤백 준비 완료'
      : 'MailCenter Router Core V01 일부 연결 확인 필요';
  } catch (err) {
    result.ok = false;
    result.message = String(err && err.message ? err.message : err);
  }

  mcRouterCoreV01Log_(result);
  return result;
}


function runMcRouterRuntimeRouteCheckV01() {
  var page = 'MailCenterServerMailListV01';
  var routes = mcRouterCoreV01ListRoutes_();
  var matched = null;
  for (var i = 0; i < routes.length; i++) {
    if (routes[i] && routes[i].page === page) {
      matched = routes[i];
      break;
    }
  }

  var result = {
    ok: false,
    build: MC_ROUTER_CORE_V01_BUILD,
    action: 'runMcRouterRuntimeRouteCheckV01',
    generatedAt: mcRouterCoreV01Now_(),
    page: page,
    matchedRoute: matched,
    checks: []
  };

  result.checks.push({
    key: 'RouteListed',
    ok: !!matched,
    message: page + ' route 목록 등록 확인'
  });
  result.checks.push({
    key: 'HandlerReady',
    ok: typeof mcServerMailListShellV01HandleGet === 'function',
    message: 'mcServerMailListShellV01HandleGet 함수 확인'
  });
  result.checks.push({
    key: 'RouterReady',
    ok: typeof mcRouterHandleGet === 'function',
    message: 'mcRouterHandleGet 함수 확인'
  });

  result.ok = result.checks.every(function(c) { return !!c.ok; });
  result.message = result.ok
    ? 'MailCenterServerMailListV01 런타임 route 연결 준비 완료'
    : 'MailCenterServerMailListV01 런타임 route 연결 확인 필요';

  mcRouterCoreV01Log_(result);
  return result;
}

function mcRouterHandleGet(e) {
  var mcBackupRoutePageV01 = (arguments && arguments[0] && arguments[0].parameter && arguments[0].parameter.page) ? String(arguments[0].parameter.page) : '';
  if (mcBackupRoutePageV01 === 'MailCenterBackupRestoreV01') {
    return mcBackupRestoreV01HandleGet(arguments[0]);
  }

  var mcRouterPageV01 = (arguments && arguments[0] && arguments[0].parameter && arguments[0].parameter.page) ? String(arguments[0].parameter.page) : '';
  if (mcRouterPageV01 === 'MailCenterHealthCheckV01') {
    return mcHealthCheckV01HandleGet(arguments[0]);
  }

  var page = mcRouterCoreV01GetPage_(e);

  if (page === 'MailCenterRouteIndexV03' || page === 'MailCenterIndexV03') {
    return mcRouterCoreV01RequireHandler_('mcRouteIndexV03HandleGet')(e || {});
  }

  if (page === 'MailCenterRouteIndexV02' || page === 'MailCenterIndexV02') {
    return mcRouterCoreV01RequireHandler_('mcRouteIndexV02HandleGet')(e || {});
  }

  if (page === 'MailCenterRouteIndexV01' || page === 'MailCenterIndexV01') {
    return mcRouterCoreV01RequireHandler_('mcRouteIndexV01HandleGet')(e || {});
  }

  if (
    page === 'MailCenter' ||
    page === 'MailCenterRouter' ||
    page === 'MailCenterDashboard' ||
    page === 'MailCenterDashboardV04'
  ) {
    return mcRouterCoreV01RequireHandler_('mcDashboardShellV04HandleGet')(e || {});
  }

  if (page === 'MailCenterDashboardV03') {
    if (typeof mcDashboardShellV04HandleGet === 'function') {
      return mcDashboardShellV04HandleGet(e || {});
    }
    return mcRouterCoreV01RequireHandler_('mcDashboardShellV03HandleGet')(e || {});
  }

  if (page === 'MailCenterSendTestV05') {
    return mcRouterCoreV01RequireHandler_('mcDashboardSendShellV05HandleGet')(e || {});
  }

  if (page === 'MailCenterServerMailListV01' || page === 'MailCenterMailListV01' || page === 'MailCenterInboxV01') {
    return mcRouterCoreV01RequireHandler_('mcServerMailListShellV01HandleGet')(e || {});
  }

  if (page === 'MailCenterCalendarV01' || page === 'MailCenterMailCalendarV01' || page === 'MailCenterScheduleV01') {
    return mcRouterCoreV01RequireHandler_('mcCalendarShellV01HandleGet')(e || {});
  }

  if (page === 'eventVendor') {
    return mcRouterCoreV01RequireHandler_('portalEventVendorLegacyBridgeV01HandleGet')(e || {});
  }

  if (page === 'ERPEventOpsV01' || page === 'EventOpsV01') {
    return mcRouterCoreV01RenderDisabledEventOpsRoute_(page);
  }

  if (page === 'MailCenterComposeV01' || page === 'MailCenterCompose') {
    return mcRouterCoreV01RequireHandler_('mcComposeShellV01HandleGet')(e || {});
  }

  if (
    page === 'MailCenterAttachmentLibraryV01' ||
    page === 'MailCenterLibraryV01' ||
    page === 'MailCenterAttachmentV01'
  ) {
    return mcRouterCoreV01RequireHandler_('mcAttachmentLibraryShellV01HandleGet')(e || {});
  }

  if (page === 'MailCenterTemplateV01' || page === 'MailCenterTemplatesV01') {
    return mcRouterCoreV01RequireHandler_('mcTemplateShellV01HandleGet')(e || {});
  }

  if (
    page === 'MailCenterAccountAdminV01' ||
    page === 'MailCenterAccountRegisterV01' ||
    page === 'MailCenterApprovalCenterV01'
  ) {
    return mcRouterCoreV01RequireHandler_('mcAccountAdminShellV01HandleGet')(e || {});
  }

  if (
    page === 'MailCenterSettingsV01' ||
    page === 'MailCenterSignatureFolderSettingsV01'
  ) {
    return mcRouterCoreV01RequireHandler_('mcSettingsShellV01HandleGet')(e || {});
  }

  if (page === 'MailCenterLogAuditV01' || page === 'MailCenterLogsV01') {
    return mcRouterCoreV01RequireHandler_('mcLogAuditShellV01HandleGet')(e || {});
  }

  if (page === 'MailCenterStandalone') {
    return mcRouterCoreV01RequireHandler_('mailCenterStandaloneHandleGet')(e || {});
  }

  if (page === 'MailCenter169') {
    return mcRouterCoreV01RequireHandler_('portal169HandleGet')(e || {});
  }

  return mcRouterCoreV01RenderNotFound_(page);
}

function mcRouterCoreV01ListRoutes_() {
  return [
    {
      page: 'MailCenterRouteIndexV03',
      target: 'mcRouteIndexV03HandleGet',
      purpose: 'MailCenter 성공 잠금 주소표 V3 fallback URL'
    },
    {
      page: 'MailCenterRouteIndexV02',
      target: 'mcRouteIndexV02HandleGet',
      purpose: 'MailCenter 성공 잠금 주소표 V2 절대링크'
    },
    {
      page: 'MailCenterRouteIndexV01',
      target: 'mcRouteIndexV01HandleGet',
      purpose: 'MailCenter 성공 잠금 주소표 V1'
    },
    {
      page: 'MailCenter',
      target: 'mcDashboardShellV04HandleGet',
      purpose: '기본 MailCenter 진입'
    },
    {
      page: 'MailCenterDashboardV04',
      target: 'mcDashboardShellV04HandleGet',
      purpose: '성공 잠금 대시보드'
    },
    {
      page: 'MailCenterSendTestV05',
      target: 'mcDashboardSendShellV05HandleGet',
      purpose: '테스트 발송 화면'
    },
    {
      page: 'MailCenterServerMailListV01',
      target: 'mcServerMailListShellV01HandleGet',
      purpose: '서버 메일 목록 빠른 조회 및 작성/로그/자료함 연결'
    },
    {
      page: 'MailCenterCalendarV01',
      target: 'mcCalendarShellV01HandleGet',
      purpose: 'MailCenter 메일 일정 관리 화면'
    },
    {
      page: 'eventVendor',
      target: 'portalEventVendorLegacyBridgeV01HandleGet',
      purpose: 'EVENT_CENTER 전환 게이트 - 기존 ERP 자동 이동 차단'
    },
    {
      page: 'MailCenterComposeV01',
      target: 'mcComposeShellV01HandleGet',
      purpose: '서명/기본계정/템플릿/Drive 링크 작성/발송 화면'
    },
    {
      page: 'MailCenterAttachmentLibraryV01',
      target: 'mcAttachmentLibraryShellV01HandleGet',
      purpose: '자료함/다중 업로드/Drive 링크 관리'
    },
    {
      page: 'MailCenterTemplateV01',
      target: 'mcTemplateShellV01HandleGet',
      purpose: '메일 템플릿 관리 센터'
    },
    {
      page: 'MailCenterAccountAdminV01',
      target: 'mcAccountAdminShellV01HandleGet',
      purpose: '직원/업체 원본 연결형 계정 등록/승인 센터'
    },
    {
      page: 'MailCenterSettingsV01',
      target: 'mcSettingsShellV01HandleGet',
      purpose: '서명/폴더/기본설정 센터'
    },
    {
      page: 'MailCenterLogAuditV01',
      target: 'mcLogAuditShellV01HandleGet',
      purpose: '발송/작성/감사 로그 조회 센터'
    },
    {
      page: 'MailCenterStandalone',
      target: 'mailCenterStandaloneHandleGet',
      purpose: '기존 독립형 화면 보존'
    },
    {
      page: 'MailCenter169',
      target: 'portal169HandleGet',
      purpose: '기존 169 메일 커넥터 보존'
    }
  ];
}

function mcRouterCoreV01GetPage_(e) {
  try {
    return String((e && e.parameter && e.parameter.page) || '').trim();
  } catch (err) {
    return '';
  }
}

function mcRouterCoreV01RequireHandler_(name) {
  var fn = this[name];
  if (typeof fn !== 'function') {
    throw new Error(name + ' 함수가 없습니다. 관련 MailCenter 파일 적용 상태를 확인하세요.');
  }
  return fn;
}

function mcRouterCoreV01RenderNotFound_(page) {
  var html = ''
    + '<!doctype html><html><head><meta charset="utf-8">'
    + '<title>FEELHAUS MailCenter Router</title></head>'
    + '<body style="font-family:Arial,Noto Sans KR,sans-serif;padding:32px;background:#f6f7f9">'
    + '<div style="max-width:880px;background:white;border:1px solid #e5e7eb;border-radius:16px;padding:24px">'
    + '<h1>MailCenter route를 찾을 수 없습니다.</h1>'
    + '<p>요청 page: <code>' + mcRouterCoreV01Escape_(page || '') + '</code></p>'
    + '<ul>'
    + '<li>?page=MailCenterRouteIndexV03</li>'
    + '<li>?page=MailCenterDashboardV04</li>'
    + '<li>?page=MailCenterServerMailListV01</li>'
    + '<li>?page=MailCenterComposeV01</li>'
    + '<li>?page=MailCenterCalendarV01</li>'
    + '<li>?page=MailCenterAttachmentLibraryV01</li>'
    + '<li>?page=MailCenterTemplateV01</li>'
    + '<li>?page=MailCenterLogAuditV01</li>'
    + '<li>?page=MailCenterSettingsV01</li>'
    + '</ul>'
    + '</div></body></html>';

  return HtmlService.createHtmlOutput(html)
    .setTitle('FEELHAUS MailCenter Router')
    .setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL);
}

function mcRouterCoreV01Escape_(value) {
  return String(value || '')
    .replace(/&/g,'&amp;')
    .replace(/</g,'&lt;')
    .replace(/>/g,'&gt;')
    .replace(/"/g,'&quot;')
    .replace(/'/g,'&#039;');
}

function mcRouterCoreV01Now_() {
  return Utilities.formatDate(
    new Date(),
    Session.getScriptTimeZone() || 'Asia/Seoul',
    'yyyy-MM-dd HH:mm:ss'
  );
}

function mcRouterCoreV01Log_(obj) {
  try {
    Logger.log('JSON_COMPACT_RESULT: ' + JSON.stringify(obj));
  } catch (e) {
    Logger.log(obj);
  }
}

function mcRouterCoreV01RenderDisabledEventOpsRoute_(page) {
  var safePage = String(page || 'EventOpsV01');
  var html = ''
    + '<!doctype html><html><head><base target="_top"><meta charset="utf-8">'
    + '<style>body{font-family:Arial,sans-serif;background:#f7f3ec;margin:0;padding:32px;color:#2b2118}.card{max-width:760px;margin:0 auto;background:#fff;border:1px solid #e6d8c3;border-radius:18px;padding:28px;box-shadow:0 14px 35px rgba(50,35,15,.08)}h1{margin:0 0 12px;color:#8a6a2a}.badge{display:inline-block;background:#f2e7d3;border-radius:999px;padding:6px 12px;font-size:12px;margin-bottom:14px}.muted{color:#786b5c;line-height:1.7}</style>'
    + '</head><body><div class="card"><div class="badge">FEELHAUS EVENT ROUTE SAFE BLOCK</div>'
    + '<h1>행사관리 신규 V01 경로가 차단되었습니다.</h1>'
    + '<p class="muted">요청 경로 <b>' + safePage.replace(/[<>&]/g, function(c){return {"<":"&lt;",">":"&gt;","&":"&amp;"}[c];}) + '</b> 는 현재 운영 기준에서 사용하지 않습니다.<br>행사관리는 PORTAL의 <b>?page=eventVendor</b> EVENT_CENTER 전환 게이트에서 고정합니다. 기존 ERP 자동 이동은 차단되었습니다.</p>'
    + '</div></body></html>';
  return HtmlService.createHtmlOutput(html).setTitle('FEELHAUS 행사관리 경로 차단').setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL);
}
