/**
 * FEELHAUS PORTAL / MailCenter Calendar Manual Display Detail Fix V03
 * Build: PORTAL_MC_CALENDAR_MANUAL_DISPLAY_DETAIL_FIX_V03_20260528
 * Purpose:
 * - 수동입력 일정 상세 모달의 날짜/메모/동기화/고급 필드 표시 품질을 보정한다.
 * - 화면 표시 보정 전용이며 저장/Google/Naver 실반영을 수행하지 않는다.
 */
var MC_CALENDAR_MANUAL_DISPLAY_DETAIL_FIX_V03_BUILD = 'PORTAL_MC_CALENDAR_MANUAL_DISPLAY_DETAIL_FIX_V03_20260528';

function mcCalendarManualDisplayDetailFixV03SelfTest() {
  var result = mcCalendarManualDisplayDetailFixV03BaseResult_('mcCalendarManualDisplayDetailFixV03SelfTest');
  try {
    result.checks = {
      calendarShellReady: typeof mcCalendarShellV01GetMonthData === 'function',
      detailCoreReady: typeof mcCalendarDetailCoreV01GetDetail === 'function',
      v01CreateReady: typeof mcCalendarUnifiedManualInputV01Create === 'function',
      v02ListRecentReady: typeof mcCalendarUnifiedManualInputV02ListRecentManual5 === 'function',
      googleRealApplyExecuted: false,
      destructiveRepairExecuted: false
    };
    var missing = [];
    Object.keys(result.checks).forEach(function(k) {
      if (k !== 'googleRealApplyExecuted' && k !== 'destructiveRepairExecuted' && !result.checks[k]) missing.push(k);
    });
    var ss = mcCalendarManualDisplayDetailFixV03OpenMaster_();
    var sheet = ss.getSheetByName('MAILCENTER_CalendarEvents');
    var recent = mcCalendarManualDisplayDetailFixV03FindRecentManual_(sheet);
    result.targetSheets = [{ sheetName: 'MAILCENTER_CalendarEvents', exists: !!sheet, lastRow: sheet ? sheet.getLastRow() : 0, lastColumn: sheet ? sheet.getLastColumn() : 0 }];
    result.recentManualSample = recent ? {
      rowNumber: recent.rowNumber,
      calendarEventId: recent.row.calendarEventId || '',
      title: recent.row.title || recent.row.eventTitle || '',
      startAt: String(recent.row.startAt || ''),
      endAt: String(recent.row.endAt || ''),
      syncTarget: recent.row.syncTarget || '',
      googleSyncStatus: recent.row.googleSyncStatus || '',
      naverSyncStatus: recent.row.naverSyncStatus || ''
    } : null;
    result.ok = missing.length === 0 && !!sheet;
    result.missingFunctions = missing;
    result.message = result.ok ? '수동일정 상세 표시 V03 보정 준비 완료' : '수동일정 상세 표시 V03 준비 실패';
    result.nextAction = '배포 화면 캘린더에서 최근 수동일정을 열어 날짜/메모/동기화/고급필드 표시를 확인하세요.';
  } catch (err) {
    mcCalendarManualDisplayDetailFixV03Catch_(result, err);
  }
  return mcCalendarManualDisplayDetailFixV03Print_(result);
}

function mcCalendarManualDisplayDetailFixV03CheckRecentManualDetail() {
  var result = mcCalendarManualDisplayDetailFixV03BaseResult_('mcCalendarManualDisplayDetailFixV03CheckRecentManualDetail');
  try {
    var ss = mcCalendarManualDisplayDetailFixV03OpenMaster_();
    var sheet = ss.getSheetByName('MAILCENTER_CalendarEvents');
    var recent = mcCalendarManualDisplayDetailFixV03FindRecentManual_(sheet);
    if (!recent) throw new Error('최근 수동일정을 찾지 못했습니다. 먼저 수동일정 저장 테스트를 실행하세요.');
    var row = recent.row || {};
    var detail = mcCalendarDetailCoreV01GetDetail({ calendarEventId: row.calendarEventId });
    var ev = detail && detail.event ? detail.event : {};
    result.ok = !!(detail && detail.ok && ev.calendarEventId);
    result.message = result.ok ? '최근 수동일정 상세 조회 확인 완료' : '최근 수동일정 상세 조회 확인 실패';
    result.calendarEventId = row.calendarEventId || '';
    result.displayExpectations = {
      formattedDateExpected: true,
      descriptionVisibleExpected: !!(ev.description || ev.eventDescription || row.description),
      syncStatusVisibleExpected: true,
      advancedFieldsVisibleExpected: true
    };
    result.compactDetail = {
      rowNumber: recent.rowNumber,
      title: ev.title || ev.eventTitle || row.title || '',
      startAt: String(ev.startAt || row.startAt || ''),
      endAt: String(ev.endAt || row.endAt || ''),
      descriptionLength: String(ev.description || ev.eventDescription || row.description || '').length,
      categoryCode: ev.categoryCode || row.categoryCode || '',
      privacyLevel: ev.privacyLevel || row.privacyLevel || '',
      busyStatus: ev.busyStatus || row.busyStatus || '',
      repeatType: ev.repeatType || row.repeatType || '',
      remindersJson: ev.remindersJson || row.remindersJson || '',
      syncTarget: ev.syncTarget || row.syncTarget || '',
      googleSyncStatus: ev.googleSyncStatus || row.googleSyncStatus || '',
      naverSyncStatus: ev.naverSyncStatus || row.naverSyncStatus || ''
    };
    result.realApplyExecuted = false;
    result.destructiveRepairExecuted = false;
    result.nextAction = '화면에서 해당 calendarEventId를 열어 V03 상세 표시를 확인하세요.';
  } catch (err) {
    mcCalendarManualDisplayDetailFixV03Catch_(result, err);
  }
  return mcCalendarManualDisplayDetailFixV03Print_(result);
}

function mcCalendarManualDisplayDetailFixV03FindRecentManual_(sheet) {
  if (!sheet || sheet.getLastRow() < 2) return null;
  var lastRow = sheet.getLastRow();
  var lastCol = sheet.getLastColumn();
  var headers = sheet.getRange(1, 1, 1, lastCol).getValues()[0];
  var hm = {};
  headers.forEach(function(h, i) { if (h !== '' && h !== null && h !== undefined) hm[String(h).trim()] = i; });
  var rows = sheet.getRange(2, 1, lastRow - 1, lastCol).getValues();
  for (var i = rows.length - 1; i >= 0; i--) {
    var obj = {};
    Object.keys(hm).forEach(function(k) { obj[k] = rows[i][hm[k]]; });
    var sourceType = String(obj.sourceType || obj.calendarType || '').toUpperCase();
    var cid = String(obj.calendarEventId || '');
    if (sourceType === 'MANUAL' || cid.indexOf('MCAL-MANUAL') === 0) return { rowNumber: i + 2, row: obj };
  }
  return null;
}

function mcCalendarManualDisplayDetailFixV03OpenMaster_() {
  if (typeof mcCalendarUnifiedManualInputV01OpenMaster_ === 'function') return mcCalendarUnifiedManualInputV01OpenMaster_();
  var setupId = '17VMSpgSZCvIrUlgcw8yCNcnl8WQWo2IcRf5tDCcuJGM';
  return SpreadsheetApp.openById(setupId);
}

function mcCalendarManualDisplayDetailFixV03BaseResult_(action) {
  return {
    ok: false,
    build: MC_CALENDAR_MANUAL_DISPLAY_DETAIL_FIX_V03_BUILD,
    action: action,
    generatedAt: Utilities.formatDate(new Date(), Session.getScriptTimeZone(), 'yyyy-MM-dd HH:mm:ss'),
    realApplyExecuted: false,
    destructiveRepairExecuted: false,
    warnings: [],
    errors: []
  };
}

function mcCalendarManualDisplayDetailFixV03Catch_(result, err) {
  result.ok = false;
  result.message = 'Error: ' + (err && err.message ? err.message : String(err));
  result.errors.push({ message: err && err.message ? err.message : String(err), stack: err && err.stack ? String(err.stack) : '' });
  result.realApplyExecuted = false;
  result.destructiveRepairExecuted = false;
}

function mcCalendarManualDisplayDetailFixV03Print_(result) {
  result.endedAt = Utilities.formatDate(new Date(), Session.getScriptTimeZone(), 'yyyy-MM-dd HH:mm:ss');
  Logger.log('JSON_COMPACT_RESULT: ' + JSON.stringify(result));
  return result;
}
