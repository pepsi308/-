/**
 * FEELHAUS MailCenter Health Check V01
 * Build: MAILCENTER_WARN_CLEANUP_V01_20260520
 *
 * Purpose:
 * - 안정본 보호용 MailCenter 진단 센터
 * - SystemConfig CONFIG_KEY/VALUE 기준
 * - FEELHAUS_DB_MASTER 연결 기준
 * - 시트/헤더/핸들러/데이터 개수/금지 함수 상태 점검
 */

var MC_HEALTH_CHECK_V01_BUILD = 'MAILCENTER_WARN_CLEANUP_V01_20260520';
var MC_HEALTH_CHECK_V01_SETUP_DB_ID = '17VMSpgSZCvIrUlgcw8yCNcnl8WQWo2IcRf5tDCcuJGM';
var MC_HEALTH_CHECK_V01_CONFIG_SHEET_NAME = 'SystemConfig';
var MC_HEALTH_CHECK_V01_MASTER_KEY = 'FEELHAUS_DB_MASTER';
var MC_HEALTH_CHECK_V01_WEBAPP_URL = 'https://script.google.com/macros/s/AKfycbxCyFE7zf4vE8nsfjOeWX0pC56SqU84gm8ie8Txa3qHQGEusJCZeljzCdYeOmZxUVYvjA/exec';

function runMcHealthCheckV01Smoke() {
  var result = {
    ok: false,
    build: MC_HEALTH_CHECK_V01_BUILD,
    action: 'runMcHealthCheckV01Smoke',
    generatedAt: mcHealthCheckV01Now_(),
    message: '',
    checks: []
  };
  try {
    result.checks.push({key:'CoreReady', ok: typeof mcHealthCheckV01Run === 'function', message:'Health Check Core 함수 확인'});
    result.checks.push({key:'HandleGetReady', ok: typeof mcHealthCheckV01HandleGet === 'function', message:'Health Check 화면 핸들러 확인'});
    var hcCfgV03 = mcHealthCheckV01ReadConfig_();
    result.checks.push({key:'ConfigReady', ok: !!hcCfgV03.masterId, message:'SystemConfig CONFIG_KEY/VALUE 및 FEELHAUS_DB_MASTER 확인'});
    result.checks.push({key:'MasterReady', ok: !!mcHealthCheckV01OpenMaster_(), message:'FEELHAUS_DB_MASTER 연결 확인'});
    var diag = mcHealthCheckV01Run({log:false});
    result.checks.push({key:'DiagnosisReady', ok: !!diag && Array.isArray(diag.sections), message:'진단 데이터 생성 확인: ' + ((diag && diag.summary) ? diag.summary.totalChecks : 0)});
    result.ok = result.checks.every(function(c){ return !!c.ok; });
    result.message = result.ok ? 'MailCenter Health Check V01 준비 완료' : 'MailCenter Health Check V01 점검 필요';
  } catch (err) {
    result.ok = false;
    result.message = String(err && err.message ? err.message : err);
  }
  Logger.log('JSON_COMPACT_RESULT: ' + JSON.stringify(result));
  return result;
}

function mcHealthCheckV01HandleGet(e) {
  var t = HtmlService.createTemplateFromFile('MC_HealthCheckViewV01');
  t.build = MC_HEALTH_CHECK_V01_BUILD;
  t.webAppUrl = MC_HEALTH_CHECK_V01_WEBAPP_URL;
  t.initialJson = JSON.stringify(mcHealthCheckV01Run({log:false}));
  return t.evaluate()
    .setTitle('FEELHAUS MailCenter Health Check')
    .setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL);
}

function mcHealthCheckV01Run(options) {
  var shouldLog = !(options && options.log === false);
  var result = {
    ok: false,
    build: MC_HEALTH_CHECK_V01_BUILD,
    action: 'mcHealthCheckV01Run',
    generatedAt: mcHealthCheckV01Now_(),
    message: '',
    summary: {
      totalChecks: 0,
      pass: 0,
      warn: 0,
      fail: 0,
      sheets: 0,
      handlers: 0,
      dataRows: 0
    },
    sections: []
  };

  try {
    var configSection = mcHealthCheckV01CheckConfig_();
    result.sections.push(configSection);

    var master = null;
    try { master = mcHealthCheckV01OpenMaster_(); } catch (e) { master = null; }

    result.sections.push(mcHealthCheckV01CheckSheets_(master));
    result.sections.push(mcHealthCheckV01CheckHandlers_());
    result.sections.push(mcHealthCheckV01CheckDataCounts_(master));
    result.sections.push(mcHealthCheckV01CheckDeprecated_());
    result.sections.push(mcHealthCheckV01CheckRoutes_());

    result.summary = mcHealthCheckV01BuildSummary_(result.sections);
    result.ok = result.summary.fail === 0;
    result.message = result.ok
      ? 'MailCenter Health Check 통과'
      : 'MailCenter Health Check 점검 필요: FAIL ' + result.summary.fail + '건';
  } catch (err) {
    result.ok = false;
    result.message = String(err && err.message ? err.message : err);
  }

  if (shouldLog) Logger.log('JSON_COMPACT_RESULT: ' + JSON.stringify(result));
  return mcHealthCheckV01Safe_(result);
}

function mcHealthCheckV01CheckConfig_() {
  var s = mcHealthCheckV01Section_('SystemConfig / MASTER 연결');
  try {
    var cfg = mcHealthCheckV01ReadConfig_();
    mcHealthCheckV01Add_(s, 'ConfigHeaders', !!cfg.headerOk, cfg.headerOk ? 'SystemConfig 헤더 CONFIG_KEY / VALUE 확인' : ('SystemConfig 헤더 불일치. 필요: CONFIG_KEY / VALUE, 감지: ' + (cfg.headers || []).join(', ')), cfg.headerOk ? 'PASS' : 'FAIL');
    mcHealthCheckV01Add_(s, 'MasterKey', !!cfg.masterId, cfg.masterId ? 'CONFIG_KEY = FEELHAUS_DB_MASTER / VALUE 확인' : 'CONFIG_KEY = FEELHAUS_DB_MASTER 행 또는 VALUE 값 누락', cfg.masterId ? 'PASS' : 'FAIL');
    var master = cfg.masterId ? SpreadsheetApp.openById(cfg.masterId) : null;
    mcHealthCheckV01Add_(s, 'MasterOpen', !!master, master ? 'MASTER 열기 성공: ' + master.getName() : 'MASTER 열기 실패', master ? 'PASS' : 'FAIL');
  } catch (err) {
    mcHealthCheckV01Add_(s, 'ConfigError', false, String(err && err.message ? err.message : err), 'FAIL');
  }
  return s;
}

function mcHealthCheckV01CheckSheets_(master) {
  var s = mcHealthCheckV01Section_('MailCenter 시트 / 필수 헤더');
  var policies = [
    {sheet:'MailCenter_Accounts', headers:['mailAccountId','emailAddress'], anyHeaders:[['accountStatus','status']]},
    {sheet:'MailCenter_SendLogs', headers:['createdAt','fromEmail','toEmail','subject','sendStatus','statusReason']},
    {sheet:'MailCenter_ComposeLogs', headers:['createdAt']},
    {sheet:'MailCenter_AuditLogs', headers:['createdAt']},
    {sheet:'MailCenter_Templates', headers:['templateId','templateName','subject','templateStatus']},
    {sheet:'MailCenter_Attachments', headers:['attachmentId']},
    {sheet:'MailCenter_AttachmentLibrary', headers:['attachmentId','fileName','driveUrl','attachmentStatus']},
    {sheet:'MailCenter_ApprovalLogs', headers:['createdAt']}
  ];

  if (!master) {
    mcHealthCheckV01Add_(s, 'MasterMissing', false, 'MASTER 연결 실패로 시트 점검 불가', 'FAIL');
    return s;
  }

  policies.forEach(function(p) {
    var sh = master.getSheetByName(p.sheet);
    mcHealthCheckV01Add_(s, 'Sheet_' + p.sheet, !!sh, sh ? p.sheet + ' 시트 확인' : p.sheet + ' 시트 누락', sh ? 'PASS' : 'FAIL');
    if (sh) {
      var headers = mcHealthCheckV01GetHeaders_(sh);
      var missing = p.headers.filter(function(h){ return headers.indexOf(h) < 0; });
      var missingAny = [];
      (p.anyHeaders || []).forEach(function(group) {
        var okAny = group.some(function(h){ return headers.indexOf(h) >= 0; });
        if (!okAny) missingAny.push(group.join(' 또는 '));
      });
      var allOk = missing.length === 0 && missingAny.length === 0;
      var msg = allOk ? '필수 헤더 확인' : ('누락 헤더: ' + missing.concat(missingAny).join(', '));
      mcHealthCheckV01Add_(s, 'Headers_' + p.sheet, allOk, msg, allOk ? 'PASS' : 'WARN');
    }
  });
  return s;
}

function mcHealthCheckV01CheckHandlers_() {
  var s = mcHealthCheckV01Section_('핸들러 / 핵심 함수');
  var handlers = [
    ['mcDashboardShellV04HandleGet','대시보드 V04'],
    ['mcDashboardSendShellV05HandleGet','테스트 발송 V05'],
    ['mcComposeShellV01HandleGet','메일 작성/발송'],
    ['mcAttachmentLibraryShellV01HandleGet','자료함'],
    ['mcTemplateShellV01HandleGet','템플릿'],
    ['mcLogAuditShellV01HandleGet','로그/감사'],
    ['mcAccountAdminShellV01HandleGet','계정 등록/승인'],
    ['mcSettingsShellV01HandleGet','서명/폴더/설정'],
    ['mcRouteIndexV03HandleGet','주소표 V3'],
    ['mcRouterHandleGet','MailCenter Router']
  ];
  handlers.forEach(function(item) {
    var fn = item[0];
    var ok = typeof this[fn] === 'function';
    mcHealthCheckV01Add_(s, fn, ok, item[1] + ' 핸들러 ' + (ok ? '확인' : '누락'), ok ? 'PASS' : 'FAIL');
  });
  return s;
}

function mcHealthCheckV01CheckDataCounts_(master) {
  var s = mcHealthCheckV01Section_('데이터 개수 / 최근 상태');
  if (!master) {
    mcHealthCheckV01Add_(s, 'MasterMissingForCounts', false, 'MASTER 연결 실패로 데이터 개수 점검 불가', 'FAIL');
    return s;
  }

  var sheets = [
    'MailCenter_Accounts',
    'MailCenter_SendLogs',
    'MailCenter_ComposeLogs',
    'MailCenter_AuditLogs',
    'MailCenter_Templates',
    'MailCenter_AttachmentLibrary',
    'MailCenter_ApprovalLogs'
  ];
  sheets.forEach(function(name) {
    var sh = master.getSheetByName(name);
    var count = sh ? Math.max(0, sh.getLastRow() - 1) : 0;
    var status = sh ? 'PASS' : 'FAIL';
    if (sh && count === 0 && (name === 'MailCenter_SendLogs' || name === 'MailCenter_Accounts')) status = 'WARN';
    mcHealthCheckV01Add_(s, 'Count_' + name, !!sh, name + ' 데이터 ' + count + '건', status, {count: count});
  });

  try {
    if (typeof mcSendTestClean0130GetInitialData === 'function') {
      var send = mcSendTestClean0130GetInitialData();
      mcHealthCheckV01Add_(s, 'SendTestRecentLogs', !!(send && send.recentLogs && send.recentLogs.length), '테스트 발송 최근 로그 ' + ((send && send.recentLogs) ? send.recentLogs.length : 0) + '건', (send && send.recentLogs && send.recentLogs.length) ? 'PASS' : 'WARN');
    }
  } catch (err) {
    mcHealthCheckV01Add_(s, 'SendTestRecentLogsError', false, String(err && err.message ? err.message : err), 'WARN');
  }
  return s;
}

function mcHealthCheckV01CheckDeprecated_() {
  var s = mcHealthCheckV01Section_('폐기/금지 방식 감지');
  var deprecatedFns = [
    'mcUiNavDataRepairV01GetPayload',
    'mcUiNavDataRepairV02GetPayload',
    'mcUiAutoRepairSnippetV02',
    'mcUiNavRepairSnippetV01'
  ];
  deprecatedFns.forEach(function(fn) {
    var exists = typeof this[fn] === 'function';
    mcHealthCheckV01Add_(s, fn, !exists, exists ? '폐기 함수가 남아 있음: ' + fn : '폐기 함수 미감지: ' + fn, exists ? 'WARN' : 'PASS');
  });
  mcHealthCheckV01Add_(s, 'Policy_NoHrefRelative', true, '정책 확인: href="?page=..." 금지', 'PASS');
  mcHealthCheckV01Add_(s, 'Policy_NoUserCodeAppPanel', true, '정책 확인: userCodeAppPanel 금지', 'PASS');
  mcHealthCheckV01Add_(s, 'Policy_NoRouterAutoInject', true, '정책 확인: Router 자동 HTML 주입 금지', 'PASS');
  return s;
}

function mcHealthCheckV01CheckRoutes_() {
  var s = mcHealthCheckV01Section_('사용 가능 주소');
  var pages = [
    'MailCenterDashboardV04',
    'MailCenterSendTestV05',
    'MailCenterComposeV01',
    'MailCenterAttachmentLibraryV01',
    'MailCenterTemplateV01',
    'MailCenterLogAuditV01',
    'MailCenterAccountAdminV01',
    'MailCenterSettingsV01',
    'MailCenterRouteIndexV03',
    'MailCenterHealthCheckV01'
  ];
  pages.forEach(function(page) {
    mcHealthCheckV01Add_(s, 'Url_' + page, true, MC_HEALTH_CHECK_V01_WEBAPP_URL + '?page=' + page + '&v=healthV01', 'PASS');
  });
  return s;
}

function mcHealthCheckV01ReadConfig_() {
  var setup = SpreadsheetApp.openById(MC_HEALTH_CHECK_V01_SETUP_DB_ID);
  var sh = setup.getSheetByName(MC_HEALTH_CHECK_V01_CONFIG_SHEET_NAME);
  if (!sh) throw new Error('SystemConfig 시트를 찾지 못했습니다.');

  var values = sh.getDataRange().getValues();
  if (!values || !values.length) throw new Error('SystemConfig 데이터가 없습니다.');

  var headers = values[0].map(function(h){ return String(h || '').trim(); });
  var keyCol = headers.indexOf('CONFIG_KEY');
  var valueCol = headers.indexOf('VALUE');

  var out = {
    headerOk: keyCol >= 0 && valueCol >= 0,
    headerMode: 'LOCKED_CONFIG_KEY_VALUE',
    headers: headers,
    keyCol: keyCol,
    valueCol: valueCol,
    masterId: '',
    masterKeyFound: ''
  };

  if (!out.headerOk) {
    return out;
  }

  for (var r = 1; r < values.length; r++) {
    var key = String(values[r][keyCol] || '').trim();
    if (key === MC_HEALTH_CHECK_V01_MASTER_KEY) {
      out.masterId = String(values[r][valueCol] || '').trim();
      out.masterKeyFound = key;
      break;
    }
  }

  return out;
}

function mcHealthCheckV01OpenMaster_() {
  var cfg = mcHealthCheckV01ReadConfig_();
  if (!cfg.headerOk) {
    throw new Error('SystemConfig 헤더는 CONFIG_KEY / VALUE 여야 합니다. 감지 헤더: ' + (cfg.headers || []).join(', '));
  }
  if (!cfg.masterId) {
    throw new Error('CONFIG_KEY = FEELHAUS_DB_MASTER 행의 VALUE 값이 없습니다.');
  }
  return SpreadsheetApp.openById(cfg.masterId);
}

function mcHealthCheckV01NormalizeHeader_(value) {
  return String(value || '').trim();
}

function mcHealthCheckV01GetHeaders_(sh) {
  if (!sh || sh.getLastRow() < 1) return [];
  return sh.getRange(1,1,1,sh.getLastColumn()).getValues()[0].map(function(h){ return String(h || '').trim(); });
}

function mcHealthCheckV01Section_(title) {
  return {title:title, checks:[]};
}

function mcHealthCheckV01Add_(section, key, ok, message, status, extra) {
  section.checks.push({
    key: key,
    ok: !!ok,
    status: status || (!!ok ? 'PASS' : 'FAIL'),
    message: message || '',
    extra: extra || {}
  });
}

function mcHealthCheckV01BuildSummary_(sections) {
  var summary = {totalChecks:0, pass:0, warn:0, fail:0, sheets:0, handlers:0, dataRows:0};
  sections.forEach(function(sec) {
    (sec.checks || []).forEach(function(c) {
      summary.totalChecks++;
      if (c.status === 'PASS') summary.pass++;
      else if (c.status === 'WARN') summary.warn++;
      else summary.fail++;
      if (String(c.key || '').indexOf('Sheet_') === 0 && c.status === 'PASS') summary.sheets++;
      if (String(c.key || '').indexOf('mc') === 0 && c.status === 'PASS') summary.handlers++;
      if (c.extra && typeof c.extra.count === 'number') summary.dataRows += c.extra.count;
    });
  });
  return summary;
}

function mcHealthCheckV01Now_() {
  return Utilities.formatDate(new Date(), Session.getScriptTimeZone() || 'Asia/Seoul', 'yyyy-MM-dd HH:mm:ss');
}

function mcHealthCheckV01Safe_(obj) {
  try { return JSON.parse(JSON.stringify(obj)); }
  catch (e) { return {ok:false, build:MC_HEALTH_CHECK_V01_BUILD, message:String(e && e.message ? e.message : e)}; }
}
