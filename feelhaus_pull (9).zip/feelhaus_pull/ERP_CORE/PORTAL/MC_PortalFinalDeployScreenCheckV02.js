/**
 * FEELHAUS PORTAL / MailCenter
 * Build: PORTAL_MC_FINAL_DEPLOY_SCREEN_CHECK_V02_20260527
 * Purpose: Final deploy screen smoke check V02. Read-only. Separates critical MailCenter routes from optional CONTROL route.
 * Scope: PORTAL V06 shell, MailCenter dashboard/calendar routes, log runners, Google real apply locked state.
 */

var MC_PORTAL_FINAL_DEPLOY_SCREEN_CHECK_V02_BUILD = 'PORTAL_MC_FINAL_DEPLOY_SCREEN_CHECK_V02_20260527';

function mcPortalFinalDeployScreenCheckV02SelfTest() {
  var result = mcPortalFinalDeployScreenCheckV02Base_('mcPortalFinalDeployScreenCheckV02SelfTest');
  result.message = 'FINAL_DEPLOY_SCREEN_CHECK V02 준비 완료: CONTROL 설정 route는 선택 점검으로 분리했습니다.';
  result.checks = {
    doGetReady: typeof doGet === 'function',
    portalRendererReady: typeof portalMenuUiRendererV06HandleGet === 'function',
    mailRouterReady: typeof mcRouterHandleGet === 'function',
    v04SelfTestReady: typeof mcGoogleCalendarApprovalLogVerboseV04SelfTest === 'function',
    v04ListRecent5Ready: typeof mcGoogleCalendarApprovalLogVerboseV04ListRecent5 === 'function',
    v04PreviewDefaultReady: typeof mcGoogleCalendarApprovalLogVerboseV04PreviewDefaultMax5 === 'function',
    v04RealApplyLockedReady: typeof mcGoogleCalendarApprovalLogVerboseV04RealApplyMax5_LOCKED === 'function'
  };
  result.ok = mcPortalFinalDeployScreenCheckV02AllTrue_(result.checks);
  result.nextAction = result.ok ? 'mcPortalFinalDeployScreenCheckV02Run() 실행' : '누락된 필수 함수 파일을 먼저 확인하세요.';
  return mcPortalFinalDeployScreenCheckV02Finish_(result);
}

function mcPortalFinalDeployScreenCheckV02Run() {
  var result = mcPortalFinalDeployScreenCheckV02Base_('mcPortalFinalDeployScreenCheckV02Run');
  result.message = 'PORTAL / MailCenter 배포화면 최종 점검 V02를 실행했습니다. 실제 Google 생성은 하지 않습니다.';
  result.mode = 'READONLY_SCREEN_SMOKE_NO_REAL_APPLY';
  result.policy = {
    criticalRoutes: ['portalHome', 'MailCenterDashboardV04', 'MailCenterCalendarV01'],
    optionalRoutes: ['controlSettings'],
    controlSettingsPolicy: 'OPTIONAL_REFERENCE_ROUTE_NOT_MAILCENTER_BLOCKER',
    realApplyAllowed: false,
    destructiveRepairAllowed: false
  };
  result.routeChecks = [];
  result.functionChecks = [];
  result.policyChecks = [];

  mcPortalFinalDeployScreenCheckV02AddFunction_(result, 'doGet', typeof doGet === 'function', true);
  mcPortalFinalDeployScreenCheckV02AddFunction_(result, 'portalMenuUiRendererV06HandleGet', typeof portalMenuUiRendererV06HandleGet === 'function', true);
  mcPortalFinalDeployScreenCheckV02AddFunction_(result, 'mcRouterHandleGet', typeof mcRouterHandleGet === 'function', true);
  mcPortalFinalDeployScreenCheckV02AddFunction_(result, 'mcGoogleCalendarApprovalLogVerboseV04ListRecent5', typeof mcGoogleCalendarApprovalLogVerboseV04ListRecent5 === 'function', true);
  mcPortalFinalDeployScreenCheckV02AddFunction_(result, 'mcGoogleCalendarApprovalLogVerboseV04PreviewDefaultMax5', typeof mcGoogleCalendarApprovalLogVerboseV04PreviewDefaultMax5 === 'function', true);
  mcPortalFinalDeployScreenCheckV02AddFunction_(result, 'mcGoogleCalendarApprovalLogVerboseV04RealApplyMax5_LOCKED', typeof mcGoogleCalendarApprovalLogVerboseV04RealApplyMax5_LOCKED === 'function', true);

  if (typeof doGet === 'function') {
    mcPortalFinalDeployScreenCheckV02RouteSmoke_(result, 'portalHome', {}, true, ['FEELHAUS', '필하우스', 'MailCenter', '메일', 'Calendar', '캘린더']);
    mcPortalFinalDeployScreenCheckV02RouteSmoke_(result, 'MailCenterDashboardV04', { page: 'MailCenterDashboardV04' }, true, ['FEELHAUS', '필하우스', 'MailCenter', '메일']);
    mcPortalFinalDeployScreenCheckV02RouteSmoke_(result, 'MailCenterCalendarV01', { page: 'MailCenterCalendarV01' }, true, ['FEELHAUS', '필하우스', 'MailCenter', '메일', 'Calendar', '캘린더']);
    mcPortalFinalDeployScreenCheckV02RouteSmoke_(result, 'controlSettings', { page: 'controlSettings' }, false, ['CONTROL', '설정', 'FEELHAUS', '필하우스']);
  } else {
    result.errors.push({ step: 'ROUTE_SMOKE', critical: true, message: 'doGet 함수가 없어 화면 라우트 점검을 생략했습니다.' });
  }

  var propValue = '';
  try {
    propValue = PropertiesService.getScriptProperties().getProperty('MC_GOOGLE_REAL_APPLY_NO_ARG_APPROVED') || '';
  } catch (propErr) {
    result.warnings.push({ step: 'SCRIPT_PROPERTIES', message: String(propErr && propErr.message ? propErr.message : propErr) });
  }
  result.policyChecks.push({
    name: 'REAL_APPLY_NO_ARG_APPROVED_PROPERTY',
    critical: true,
    ok: propValue !== 'YES',
    expected: 'NOT YES for safe close',
    actual: propValue || '(empty)',
    message: propValue === 'YES' ? '주의: 실반영 잠금 해제 속성이 YES입니다.' : '정상: 실반영 잠금 해제 속성이 비어있거나 YES가 아닙니다.'
  });

  result.summary = mcPortalFinalDeployScreenCheckV02Summary_(result);
  result.ok = result.summary.criticalFailed === 0;
  result.nextAction = result.ok
    ? '배포화면 핵심 점검 통과. 화면에서 PORTAL 홈, 메일센터, 캘린더 진입만 확인하고 실반영은 보류하세요.'
    : 'criticalFailed 항목을 먼저 확인하세요. Google 실반영 함수는 실행하지 마세요.';
  return mcPortalFinalDeployScreenCheckV02Finish_(result);
}

function mcPortalFinalDeployScreenCheckV02RunCoreOnly() {
  var result = mcPortalFinalDeployScreenCheckV02Base_('mcPortalFinalDeployScreenCheckV02RunCoreOnly');
  result.message = '핵심 배포 점검만 실행했습니다: PORTAL 홈, MailCenter Dashboard, Calendar, 실반영 잠금.';
  result.mode = 'READONLY_CORE_ONLY_NO_REAL_APPLY';
  result.routeChecks = [];
  result.functionChecks = [];
  result.policyChecks = [];
  mcPortalFinalDeployScreenCheckV02AddFunction_(result, 'doGet', typeof doGet === 'function', true);
  mcPortalFinalDeployScreenCheckV02AddFunction_(result, 'mcRouterHandleGet', typeof mcRouterHandleGet === 'function', true);
  mcPortalFinalDeployScreenCheckV02AddFunction_(result, 'mcGoogleCalendarApprovalLogVerboseV04RealApplyMax5_LOCKED', typeof mcGoogleCalendarApprovalLogVerboseV04RealApplyMax5_LOCKED === 'function', true);
  if (typeof doGet === 'function') {
    mcPortalFinalDeployScreenCheckV02RouteSmoke_(result, 'portalHome', {}, true, ['FEELHAUS', '필하우스', 'MailCenter', '메일']);
    mcPortalFinalDeployScreenCheckV02RouteSmoke_(result, 'MailCenterDashboardV04', { page: 'MailCenterDashboardV04' }, true, ['MailCenter', '메일']);
    mcPortalFinalDeployScreenCheckV02RouteSmoke_(result, 'MailCenterCalendarV01', { page: 'MailCenterCalendarV01' }, true, ['Calendar', '캘린더', 'MailCenter', '메일']);
  }
  var propValue = '';
  try { propValue = PropertiesService.getScriptProperties().getProperty('MC_GOOGLE_REAL_APPLY_NO_ARG_APPROVED') || ''; } catch (e) { propValue = 'PROPERTY_READ_ERROR'; }
  result.policyChecks.push({ name: 'REAL_APPLY_UNLOCK', critical: true, ok: propValue !== 'YES', actual: propValue || '(empty)' });
  result.summary = mcPortalFinalDeployScreenCheckV02Summary_(result);
  result.ok = result.summary.criticalFailed === 0;
  result.nextAction = result.ok ? '핵심 배포 점검 통과' : 'criticalFailed 항목 확인';
  return mcPortalFinalDeployScreenCheckV02Finish_(result);
}

function mcPortalFinalDeployScreenCheckV02Guide() {
  var result = mcPortalFinalDeployScreenCheckV02Base_('mcPortalFinalDeployScreenCheckV02Guide');
  result.ok = true;
  result.message = '배포화면 수동 확인 가이드 V02';
  result.manualChecklist = [
    'PORTAL 홈 접속: 빈페이지가 아니라 FEELHAUS 통합 운영센터가 보여야 합니다.',
    '좌측 메뉴: 커뮤니케이션 / 알림 > 메일 / 알림센터가 보여야 합니다.',
    '메일센터 진입: MailCenterDashboardV04 화면이 열려야 합니다.',
    '캘린더 진입: MailCenterCalendarV01 화면이 열려야 합니다.',
    'CONTROL 설정 route는 MailCenter 마감 필수 조건이 아니라 선택 점검입니다.',
    'Google 실반영 버튼/함수는 일반 사용자가 바로 실행하지 않는 상태여야 합니다.',
    '오늘은 SystemConfig Google Sync OFF 유지 상태로 마감합니다.'
  ];
  result.nextAction = 'mcPortalFinalDeployScreenCheckV02Run() 실행';
  return mcPortalFinalDeployScreenCheckV02Finish_(result);
}

function mcPortalFinalDeployScreenCheckV02RouteSmoke_(result, name, parameter, critical, markers) {
  var item = { name: name, critical: !!critical, ok: false, title: '', contentLength: 0, matchedMarkers: [], markerCount: 0, error: '' };
  try {
    var out = doGet({ parameter: parameter || {} });
    if (out && typeof out.getTitle === 'function') item.title = String(out.getTitle() || '');
    var html = '';
    if (out && typeof out.getContent === 'function') html = String(out.getContent() || '');
    item.contentLength = html.length;
    for (var i = 0; i < (markers || []).length; i++) {
      if (html.indexOf(markers[i]) >= 0 || item.title.indexOf(markers[i]) >= 0) item.matchedMarkers.push(markers[i]);
    }
    item.markerCount = item.matchedMarkers.length;
    item.ok = item.contentLength > 200 && item.markerCount > 0;
    if (!item.ok) {
      item.error = critical
        ? '필수 route HTML 내용이 너무 짧거나 핵심 표식이 부족합니다.'
        : '선택 route 표식이 부족합니다. MailCenter 핵심 마감 차단 항목은 아닙니다.';
    }
  } catch (err) {
    item.ok = false;
    item.error = String(err && err.message ? err.message : err);
  }
  if (!item.ok && !item.critical) result.warnings.push({ step: 'OPTIONAL_ROUTE', name: name, message: item.error });
  result.routeChecks.push(item);
}

function mcPortalFinalDeployScreenCheckV02AddFunction_(result, name, ok, critical) {
  result.functionChecks.push({ name: name, critical: !!critical, ok: !!ok, status: ok ? 'READY' : 'MISSING' });
}

function mcPortalFinalDeployScreenCheckV02Summary_(result) {
  var total = 0;
  var okCount = 0;
  var failed = 0;
  var criticalFailed = 0;
  var optionalFailed = 0;
  function count(list) {
    for (var i = 0; i < (list || []).length; i++) {
      total++;
      if (list[i].ok) okCount++;
      if (!list[i].ok) {
        failed++;
        if (list[i].critical) criticalFailed++;
        else optionalFailed++;
      }
    }
  }
  count(result.functionChecks);
  count(result.routeChecks);
  count(result.policyChecks);
  return {
    total: total,
    ok: okCount,
    failed: failed,
    criticalFailed: criticalFailed,
    optionalFailed: optionalFailed,
    routeFailed: mcPortalFinalDeployScreenCheckV02FailedNames_(result.routeChecks, null),
    criticalRouteFailed: mcPortalFinalDeployScreenCheckV02FailedNames_(result.routeChecks, true),
    optionalRouteFailed: mcPortalFinalDeployScreenCheckV02FailedNames_(result.routeChecks, false),
    functionFailed: mcPortalFinalDeployScreenCheckV02FailedNames_(result.functionChecks, null),
    policyFailed: mcPortalFinalDeployScreenCheckV02FailedNames_(result.policyChecks, null),
    realApplyExecuted: false,
    destructiveRepairExecuted: false
  };
}

function mcPortalFinalDeployScreenCheckV02FailedNames_(list, criticalFilter) {
  var out = [];
  for (var i = 0; i < (list || []).length; i++) {
    if (list[i].ok) continue;
    if (criticalFilter === true && !list[i].critical) continue;
    if (criticalFilter === false && list[i].critical) continue;
    out.push(list[i].name || list[i].step || ('index' + i));
  }
  return out;
}

function mcPortalFinalDeployScreenCheckV02Base_(action) {
  return {
    ok: false,
    build: MC_PORTAL_FINAL_DEPLOY_SCREEN_CHECK_V02_BUILD,
    action: action,
    generatedAt: mcPortalFinalDeployScreenCheckV02Now_(),
    realApplyExecuted: false,
    destructiveRepairExecuted: false,
    warnings: [],
    errors: []
  };
}

function mcPortalFinalDeployScreenCheckV02Finish_(result) {
  result.endedAt = mcPortalFinalDeployScreenCheckV02Now_();
  Logger.log('JSON_COMPACT_RESULT: ' + JSON.stringify(result));
  return result;
}

function mcPortalFinalDeployScreenCheckV02AllTrue_(obj) {
  for (var k in obj) if (obj.hasOwnProperty(k) && !obj[k]) return false;
  return true;
}

function mcPortalFinalDeployScreenCheckV02Now_() {
  try { return Utilities.formatDate(new Date(), Session.getScriptTimeZone() || 'Asia/Seoul', 'yyyy-MM-dd HH:mm:ss'); }
  catch (e) { return new Date().toISOString(); }
}
