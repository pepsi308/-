/**
 * FEELHAUS PORTAL / MailCenter Calendar Operation Hub V01
 * Build: PORTAL_STEP08_NAVER_LINK_PRESERVE_FIX
 * Purpose:
 * - 박람회 기획사 운영 캘린더 기준으로 수동/메일/행사연동 일정의 상세 운영 필드를 확장한다.
 * - 캘린더에서 직접 수정할 수 있게 하되, sourceWritePolicy/권한/상태/감사로그 기준으로 안전하게 처리한다.
 * - ERP/Mail 원본 직접 덮어쓰기는 하지 않고 PENDING/APPROVAL_REQUIRED 상태로 추적한다.
 */
var MC_CALENDAR_OPERATION_HUB_V01_BUILD = 'PORTAL_STEP08_NAVER_LINK_PRESERVE_FIX';
var PORTAL_CALENDAR_SAFE01B_R9_UPDATE_ACTOR_CHANGELOG_BUILD = 'PORTAL_CALENDAR_SAFE01B_R9_UPDATE_ACTOR_CHANGELOG_20260602';
var PORTAL_CALENDAR_SAFE01B_R9A_RUNTIME_VERIFY_FIX_BUILD = 'PORTAL_CALENDAR_SAFE01B_R9A_RUNTIME_VERIFY_FIX_20260602';
var PORTAL_CALENDAR_SAFE01B_R9C_STRICT_UPDATE_GATE_BUILD = 'PORTAL_CALENDAR_SAFE01B_R9C_STRICT_UPDATE_GATE_20260602';
var PORTAL_CALENDAR_SAFE01B_R10G_BUSINESS_UPDATE_PATCH_BUILD = 'PORTAL_CALENDAR_SAFE01B_R10G_BUSINESS_UPDATE_FIELD_BINDING_FIX_20260603';
var PORTAL_CALENDAR_SAFE01B_R10I_SELECTION_EDIT_PAYLOAD_PATCH_BUILD = 'PORTAL_CALENDAR_SAFE01B_R10I_SELECTION_EDIT_PAYLOAD_FIX_20260603';
var PORTAL_CALENDAR_SAFE01B_R10J1_HEADER_MODAL_SAFE_OPEN_BUILD = 'PORTAL_CALENDAR_SAFE01B_R10J1_HEADER_MODAL_SAFE_OPEN_20260603';
var PORTAL_CALENDAR_SAFE01B_R10J4_BASIC_INFO_BUILD = 'PORTAL_CALENDAR_SAFE01B_R10J4_BASIC_INFO_EXPANSION_20260603';
var PORTAL_CALENDAR_SAFE01B_R10I2_DATETIME_ASSERT_FIX_BUILD = 'PORTAL_CALENDAR_SAFE01B_R10I2_DATETIME_ASSERT_FIX_20260603';

function mcCalendarOperationHubV01SelfTest() {
  var result = mcCalendarOperationHubV01BaseResult_('mcCalendarOperationHubV01SelfTest');
  try {
    var ss = mcCalendarUnifiedManualInputV01OpenMaster_();
    var sheet = mcCalendarUnifiedManualInputV01GetSheetOrCreate_(ss, 'MAILCENTER_CalendarEvents', mcCalendarOperationHubV01CalendarHeaders_());
    var logSheet = mcCalendarUnifiedManualInputV01GetSheetOrCreate_(ss, 'MAILCENTER_CalendarChangeLogs', mcCalendarOperationHubV01ChangeLogHeaders_());
    var hm = mcCalendarUnifiedManualInputV01HeaderMap_(sheet.getRange(1, 1, 1, Math.max(sheet.getLastColumn(), 1)).getValues()[0]);
    var missing = mcCalendarOperationHubV01CalendarHeaders_().filter(function(h) { return hm[h] === undefined; });
    result.ok = missing.length === 0;
    result.checks = {
      masterDbOk: !!ss,
      calendarSheetOk: !!sheet,
      changeLogSheetOk: !!logSheet,
      missingHeaderCount: missing.length,
      createReady: typeof mcCalendarUnifiedManualInputV01Create === 'function',
      updateReady: typeof mcCalendarOperationHubV01UpdateEvent === 'function',
      detailReady: typeof mcCalendarOperationHubV01GetDetail === 'function',
      realApplyExecuted: false,
      destructiveRepairExecuted: false
    };
    result.targetSheets = [
      { sheetName: sheet.getName(), lastRow: sheet.getLastRow(), lastColumn: sheet.getLastColumn() },
      { sheetName: logSheet.getName(), lastRow: logSheet.getLastRow(), lastColumn: logSheet.getLastColumn() }
    ];
    result.missingHeaders = missing;
    result.message = result.ok ? '박람회 운영 캘린더 V01 준비 완료' : '운영 캘린더 확장 헤더 보강 필요';
    result.nextAction = 'mcCalendarOperationHubV01CreateFairMeetingSampleDryRun() 또는 화면에서 운영 일정 상세 입력을 확인하세요.';
  } catch (err) {
    mcCalendarOperationHubV01Catch_(result, err);
  }
  return mcCalendarOperationHubV01Print_(result);
}

function mcCalendarOperationHubV01GetOptions() {
  var result = mcCalendarOperationHubV01BaseResult_('mcCalendarOperationHubV01GetOptions');
  result.ok = true;
  result.options = {
    eventGroupTypes: [
      { value: 'COUNCIL_MEETING', label: '협의회 미팅' },
      { value: 'PRESENTATION', label: '프리젠테이션' },
      { value: 'FAIR_EVENT', label: '박람회 행사' },
      { value: 'VENDOR_MEETING', label: '업체 미팅' },
      { value: 'CUSTOMER_CONSULT', label: '고객 상담' },
      { value: 'INSTALL_AS', label: '설치/A/S' },
      { value: 'SETTLEMENT', label: '정산/마감' },
      { value: 'INTERNAL', label: '내부업무' },
      { value: 'ETC', label: '기타' }
    ],
    meetingMethods: [
      { value: 'OFFLINE', label: '방문/오프라인' },
      { value: 'ONLINE', label: '화상회의' },
      { value: 'PHONE', label: '전화' },
      { value: 'FIELD', label: '현장' },
      { value: 'HYBRID', label: '혼합' }
    ],
    presentationTypes: [
      { value: 'NONE', label: '해당 없음' },
      { value: 'COUNCIL', label: '협의회 제안' },
      { value: 'VENDOR', label: '업체 제안' },
      { value: 'CLIENT', label: '고객/입주민 설명' },
      { value: 'INTERNAL', label: '내부 보고' }
    ],
    sourceWritePolicies: [
      { value: 'CALENDAR_ONLY', label: '캘린더만 수정' },
      { value: 'SYNC_TO_SOURCE', label: '연결 원장 반영 요청' },
      { value: 'READONLY_SOURCE', label: '원본 읽기전용' }
    ],
    sourceUpdateStatuses: [
      { value: 'NOT_REQUIRED', label: '불필요' },
      { value: 'PENDING', label: '반영 대기' },
      { value: 'SYNCED', label: '반영 완료' },
      { value: 'FAILED', label: '반영 실패' },
      { value: 'APPROVAL_REQUIRED', label: '승인 필요' }
    ]
  };
  result.message = '운영 캘린더 옵션 조회 완료';
  result.nextAction = '수동일정/상세수정 화면에서 옵션을 사용하세요.';
  return mcCalendarOperationHubV01Print_(result);
}

function mcCalendarOperationHubV01CreateFairMeetingSampleDryRun() {
  return mcCalendarUnifiedManualInputV01Create(mcCalendarOperationHubV01SamplePayload_('Y'));
}

function mcCalendarOperationHubV01CreateFairMeetingSampleReal() {
  return mcCalendarUnifiedManualInputV01Create(mcCalendarOperationHubV01SamplePayload_('N'));
}

function mcCalendarOperationHubV01UpdateRecentManualOwnerSample() {
  var result = mcCalendarOperationHubV01BaseResult_('mcCalendarOperationHubV01UpdateRecentManualOwnerSample');
  try {
    var recent = mcCalendarOperationHubV01ListRecentOperationEvents_(5, 'MANUAL');
    if (!recent.length) throw new Error('최근 MANUAL 일정이 없습니다. 먼저 수동일정을 1건 저장하세요.');
    var target = recent[0];
    var update = mcCalendarOperationHubV01UpdateEvent({
      calendarEventId: target.calendarEventId,
      ownerName: '운영담당자 변경 테스트',
      ownerUserId: 'USER-OPS-001',
      departmentCode: 'OPERATION',
      participantText: '이용필, 최유라, 협의회 담당자',
      changeReason: 'V01 캘린더 직접 수정 테스트',
      sourceWritePolicy: 'CALENDAR_ONLY'
    });
    result.ok = !!update.ok;
    result.inner = mcCalendarOperationHubV01CompactUpdate_(update);
    result.message = result.ok ? '최근 수동일정 담당자/참석자 수정 테스트 완료' : '최근 수동일정 수정 테스트 실패';
    result.nextAction = 'mcCalendarOperationHubV01GetDetail({calendarEventId:"' + target.calendarEventId + '"}) 또는 화면 상세를 확인하세요.';
  } catch (err) {
    mcCalendarOperationHubV01Catch_(result, err);
  }
  return mcCalendarOperationHubV01Print_(result);
}

function mcCalendarOperationHubV01UpdateEvent(payload) {
  payload = payload || {};
  var result = mcCalendarOperationHubV01BaseResult_('mcCalendarOperationHubV01UpdateEvent');
  result.realApplyExecuted = false;
  result.destructiveRepairExecuted = false;
  var __r9cStrictLock = null;
  try {
    var calendarEventId = String(payload.calendarEventId || '').trim();
    if (!calendarEventId) throw new Error('calendarEventId가 필요합니다.');
    // R9C STRICT UPDATE GATE: 수정 저장 actor는 client payload/기존 row를 신뢰하지 않고 서버 현재 Google 인증 사용자로만 확정한다.
    __r9cStrictLock = LockService.getScriptLock();
    if (!__r9cStrictLock.tryLock(15000)) throw new Error('다른 일정 수정 작업이 진행 중입니다. 잠시 후 다시 저장하세요.');
    var actorProfile = mcCalendarOperationHubV01ResolveStrictUpdateActorR9C_();
    var actor = mcCalendarOperationHubV01ActorEmailKeyR9_(actorProfile);
    if (!actor || actor.indexOf('@') < 1) throw new Error('수정 저장 actor 이메일을 확정하지 못했습니다. 저장을 중단합니다.');
    var now = mcCalendarUnifiedManualInputV01Now_();
    var ss = mcCalendarUnifiedManualInputV01OpenMaster_();
    var sheet = mcCalendarUnifiedManualInputV01GetSheetOrCreate_(ss, 'MAILCENTER_CalendarEvents', mcCalendarOperationHubV01CalendarHeaders_());
    var found = mcCalendarOperationHubV01FindRowById_(sheet, calendarEventId);
    if (!found.found) throw new Error('수정 대상 일정을 찾지 못했습니다: ' + calendarEventId);
    var before = found.record;
    var createdSnapshotR9C = mcCalendarOperationHubV01CreatedSnapshotR9C_(before);
    var sourceType = String(before.sourceType || before.calendarType || '').toUpperCase();
    var locked = String(before.locked || '').toUpperCase() === 'Y';
    var currentStatus = String(before.eventStatus || before.status || '').toUpperCase();
    var changeReason = String(payload.changeReason || '').trim();
    if (!changeReason) throw new Error('변경 사유는 필수입니다.');
    if (locked && String(payload.approvalGranted || '').toUpperCase() !== 'YES') throw new Error('잠금 일정은 승인 없이는 수정할 수 없습니다.');
    var coreFields = ['title','eventTitle','startAt','endAt','location','ownerName','ownerUserId','eventStatus','status'];
    var coreChanged = coreFields.some(function(k) { return payload[k] !== undefined && String(payload[k] || '') !== String(before[k] || ''); });
    if ((currentStatus === 'DONE' || currentStatus === 'CANCELLED') && coreChanged && String(payload.approvalGranted || '').toUpperCase() !== 'YES') {
      throw new Error('완료/취소 일정의 핵심정보 변경은 승인 후 가능합니다.');
    }

    var normalizedPatch = mcCalendarOperationHubV01NormalizePatch_(payload, before, actor, now);
    var policy = mcCalendarOperationHubV01ResolvePolicy_(sourceType, normalizedPatch.sourceWritePolicy || before.sourceWritePolicy, coreChanged);
    var after = {};
    Object.keys(before).forEach(function(k) { after[k] = before[k]; });
    Object.keys(normalizedPatch).forEach(function(k) { after[k] = normalizedPatch[k]; });
    mcCalendarOperationHubV01ApplyCreatedSnapshotR9C_(after, createdSnapshotR9C);
    after.updatedAt = now;
    after.updatedBy = actor;
    after.updatedByName = String(actorProfile.employeeName || '').trim();
    after.updatedByEmail = String(actorProfile.email || '').trim();
    after.updatedByEmployeeId = String(actorProfile.employeeId || '').trim();
    after.updatedActorSource = String(actorProfile.source || '').trim();
    if (!after.actorRoleCode) after.actorRoleCode = String(after.actorRoleCode || actorProfile.roleCode || '').trim();
    if (!after.actorVendorId) after.actorVendorId = String(after.actorVendorId || actorProfile.vendorId || '').trim();
    after.statusReason = changeReason;
    after.lastChangedFields = mcCalendarOperationHubV01ChangedFields_(before, after).join(',');
    if (policy.sourceUpdateStatus) after.sourceUpdateStatus = policy.sourceUpdateStatus;
    if (!after.sourceWritePolicy) after.sourceWritePolicy = policy.sourceWritePolicy;

    after = mcCalendarOperationHubV01PreserveExternalLinkFields_(before, after, payload);
    mcCalendarOperationHubV01ApplyCreatedSnapshotR9C_(after, createdSnapshotR9C);
    mcCalendarOperationHubV01ApplyUpdatedActorR9C_(after, actorProfile, actor, now);

    var validation = mcCalendarOperationHubV01ValidateUpdate_(after);
    result.validation = validation;
    if (!validation.ok) {
      result.ok = false;
      result.message = '일정 수정 차단: 필수값 또는 형식 오류가 있습니다.';
      result.errors = validation.errors;
      mcCalendarOperationHubV01ReleaseLockR9C_(__r9cStrictLock);
      __r9cStrictLock = null;
      return mcCalendarOperationHubV01Print_(result);
    }

    mcCalendarOperationHubV01WriteRowByHeaders_(sheet, found.rowNumber, after);
    var writtenR9C = mcCalendarOperationHubV01FindRowById_(sheet, calendarEventId);
    if (!writtenR9C.found) throw new Error('수정 저장 후 원장 row 재조회에 실패했습니다: ' + calendarEventId);
    var writtenRecordR9C = writtenR9C.record || {};
    mcCalendarOperationHubV01AssertBusinessSelectionPayloadPersistedR10I_(payload, writtenRecordR9C);
    mcCalendarOperationHubV01AssertStrictUpdatePersistedR9C_(writtenRecordR9C, actorProfile, createdSnapshotR9C);
    after = writtenRecordR9C;
    var changedFields = mcCalendarOperationHubV01ChangedFields_(before, after);
    if (!changedFields.length) changedFields = ['NO_FIELD_CHANGE'];
    mcCalendarOperationHubV01AppendChangeLog_(ss, {
      calendarEventId: calendarEventId,
      sourceType: sourceType,
      sourceWritePolicy: after.sourceWritePolicy || policy.sourceWritePolicy,
      sourceUpdateStatus: after.sourceUpdateStatus || policy.sourceUpdateStatus || 'NOT_REQUIRED',
      changedFields: changedFields.join(','),
      changeReason: changeReason,
      changeType: 'UPDATE',
      beforeSummary: JSON.stringify(mcCalendarOperationHubV01PublicDetail_(before)).slice(0, 1200),
      afterSummary: JSON.stringify(mcCalendarOperationHubV01PublicDetail_(after)).slice(0, 1200),
      beforeSnapshot: JSON.stringify(before).slice(0, 30000),
      afterSnapshot: JSON.stringify(after).slice(0, 30000),
      createdAt: now,
      createdBy: actor,
      createdByName: actorProfile.employeeName || '',
      createdByEmail: actorProfile.email || '',
      createdByEmployeeId: actorProfile.employeeId || '',
      actorRoleCode: actorProfile.roleCode || '',
      actorVendorId: actorProfile.vendorId || '',
      actorSource: actorProfile.source || ''
    });
    result.ok = true;
    result.saved = true;
    result.calendarEventId = calendarEventId;
    result.sourceType = sourceType;
    result.policy = policy;
    result.changedFields = changedFields;
    result.strictUpdateGate = 'R9C';
    result.actorProfile = { email: actorProfile.email || '', employeeName: actorProfile.employeeName || '', employeeId: actorProfile.employeeId || '', roleCode: actorProfile.roleCode || '', vendorId: actorProfile.vendorId || '', source: actorProfile.source || '' };
    result.record = mcCalendarOperationHubV01PublicDetail_(after);
    result.message = policy.message;
    result.nextAction = '캘린더 화면을 새로고침하고 연결 화면 반영 상태를 확인하세요.';
  } catch (err) {
    mcCalendarOperationHubV01ReleaseLockR9C_(__r9cStrictLock);
    __r9cStrictLock = null;
    mcCalendarOperationHubV01Catch_(result, err);
  }
  mcCalendarOperationHubV01ReleaseLockR9C_(__r9cStrictLock);
  return mcCalendarOperationHubV01Print_(result);
}

function mcCalendarOperationHubV01GetDetail(payload) {
  payload = payload || {};
  var result = mcCalendarOperationHubV01BaseResult_('mcCalendarOperationHubV01GetDetail');
  try {
    var calendarEventId = String(payload.calendarEventId || '').trim();
    if (!calendarEventId) throw new Error('calendarEventId가 필요합니다.');
    var ss = mcCalendarUnifiedManualInputV01OpenMaster_();
    var sheet = mcCalendarUnifiedManualInputV01GetSheetOrCreate_(ss, 'MAILCENTER_CalendarEvents', mcCalendarOperationHubV01CalendarHeaders_());
    var found = mcCalendarOperationHubV01FindRowById_(sheet, calendarEventId);
    if (!found.found) throw new Error('일정을 찾지 못했습니다: ' + calendarEventId);
    result.ok = true;
    result.event = mcCalendarOperationHubV01PublicDetail_(found.record);
    result.message = '운영 캘린더 상세 조회 완료';
    result.nextAction = '상세 화면에서 담당자/참석자/연결 ID/변경이력을 확인하세요.';
  } catch (err) {
    mcCalendarOperationHubV01Catch_(result, err);
  }
  return mcCalendarOperationHubV01Print_(result);
}

function mcCalendarOperationHubV01ListRecentOperation5() {
  var result = mcCalendarOperationHubV01BaseResult_('mcCalendarOperationHubV01ListRecentOperation5');
  try {
    var list = mcCalendarOperationHubV01ListRecentOperationEvents_(5, '');
    result.ok = true;
    result.summary = { displayed: list.length };
    result.recentEvents = list;
    result.message = '최근 운영 캘린더 일정 5건 조회 완료';
    result.nextAction = '상세 수정이 필요한 calendarEventId를 화면에서 열어 수정하세요.';
  } catch (err) {
    mcCalendarOperationHubV01Catch_(result, err);
  }
  return mcCalendarOperationHubV01Print_(result);
}

function mcCalendarOperationHubV01SamplePayload_(dryRun) {
  return {
    dryRun: dryRun,
    title: '[샘플] 협의회 프리젠테이션 준비 미팅',
    sourceType: 'MANUAL',
    categoryCode: 'MEETING',
    eventGroupType: 'PRESENTATION',
    meetingMethod: 'OFFLINE',
    presentationType: 'COUNCIL',
    councilName: '입주예정자 협의회',
    fairName: '필하우스 입주박람회',
    meetingPurpose: '협의회 대상 박람회 운영안 및 참여업체 구성 프리젠테이션',
    agendaText: '1. 행사 일정 공유\n2. 참여업체 구성안\n3. 홍보/접수 동선\n4. 질의응답',
    decisionMemo: '협의회 피드백 수렴 후 최종 행사 일정 확정 예정',
    todoText: '제안서 보완|행사장 도면 준비|참여담당자 역할표 작성',
    participantText: '이용필, 최유라, 협의회 대표, 행사 운영팀',
    externalPartyText: '협의회 대표 / 관리사무소 / 참여업체 담당자',
    ownerUserId: 'USER-OPS-001',
    ownerName: '이용필',
    departmentCode: 'OPERATION',
    organizerRole: '총괄/최고운영자',
    startAt: mcCalendarUnifiedManualInputV01TodayAt_('14:00'),
    endAt: mcCalendarUnifiedManualInputV01TodayAt_('15:00'),
    location: 'FEELHAUS 회의실',
    description: '박람회 기획사 운영 캘린더 샘플입니다. 협의회 미팅/프리젠테이션/담당자/안건/결정사항/후속업무를 함께 관리합니다.',
    attendeesText: 'pepsi309@gmail.com, feelhaus@feelhausfair.com',
    reminderMinutesText: '30,1440',
    repeatType: 'NONE',
    syncTarget: 'NONE',
    privacyLevel: 'DEFAULT',
    busyStatus: 'BUSY',
    eventStatus: 'SCHEDULED',
    sourceWritePolicy: 'CALENDAR_ONLY',
    sourceUpdateStatus: 'NOT_REQUIRED',
    changeReason: '운영 캘린더 샘플 생성'
  };
}


function mcCalendarOperationHubV01ExternalLinkFields_() {
  return [
    'providerEventId','providerCalendarId',
    'googleEventId','googleProviderEventId','googleCalendarEventId','googleBackupStatus','googleErrorCode','googleErrorMessage',
    'naverEventId','naverProviderEventId','naverIcalUid','naverUid','naverEventUid','naverScheduleId','naverCalendarId','naverProviderCalendarId','naverNumericCalendarId','naverRegisterStatus','naverLastProcessType','naverErrorCode','naverErrorMessage',
    'syncTarget','googleSyncStatus','naverSyncStatus','lastSyncAt'
  ];
}

function mcCalendarOperationHubV01HasText_(value) {
  return String(value === null || value === undefined ? '' : value).trim() !== '';
}

function mcCalendarOperationHubV01PickFirstText_(obj, keys) {
  obj = obj || {};
  for (var i = 0; i < keys.length; i++) {
    var v = String(obj[keys[i]] === null || obj[keys[i]] === undefined ? '' : obj[keys[i]]).trim();
    if (v) return v;
  }
  return '';
}

function mcCalendarOperationHubV01PreserveExternalLinkFields_(before, after, payload) {
  // PORTAL_STEP08_NAVER_LINK_PRESERVE_FIX
  // UI update payloads often omit provider link fields, or send syncTarget=NONE as a default value.
  // Normal calendar edits must not erase the existing Google/NAVER provider IDs and statuses.
  before = before || {};
  after = after || {};
  payload = payload || {};
  var fields = mcCalendarOperationHubV01ExternalLinkFields_();
  fields.forEach(function(k) {
    if (mcCalendarOperationHubV01HasText_(before[k])) {
      var payloadProvided = Object.prototype.hasOwnProperty.call(payload, k);
      var nextBlank = !mcCalendarOperationHubV01HasText_(after[k]);
      var dangerousDowngrade = false;
      if ((k === 'syncTarget' || k === 'googleSyncStatus' || k === 'naverSyncStatus') && String(after[k] || '').toUpperCase() === 'NOT_TARGET') dangerousDowngrade = true;
      if (!payloadProvided || nextBlank || dangerousDowngrade) after[k] = before[k];
    }
  });

  var naverId = mcCalendarOperationHubV01PickFirstText_(after, ['naverProviderEventId','naverEventId','naverIcalUid','naverUid','naverEventUid','naverScheduleId','providerEventId']);
  var naverCalendarId = mcCalendarOperationHubV01PickFirstText_(after, ['naverCalendarId','naverProviderCalendarId','naverNumericCalendarId','providerCalendarId']);
  var googleId = mcCalendarOperationHubV01PickFirstText_(after, ['googleProviderEventId','googleEventId','googleCalendarEventId','providerEventId']);

  if (naverId) {
    if (!mcCalendarOperationHubV01HasText_(after.naverProviderEventId)) after.naverProviderEventId = naverId;
    if (!mcCalendarOperationHubV01HasText_(after.naverEventId)) after.naverEventId = naverId;
    if (!mcCalendarOperationHubV01HasText_(after.naverIcalUid)) after.naverIcalUid = naverId;
    if (!mcCalendarOperationHubV01HasText_(after.naverRegisterStatus)) after.naverRegisterStatus = before.naverRegisterStatus || 'SUCCESS';
    if (!mcCalendarOperationHubV01HasText_(after.naverSyncStatus) || String(after.naverSyncStatus || '').toUpperCase() === 'NOT_TARGET') after.naverSyncStatus = before.naverSyncStatus || 'SUCCESS';
  }
  if (naverCalendarId) {
    if (!mcCalendarOperationHubV01HasText_(after.naverCalendarId)) after.naverCalendarId = naverCalendarId;
    if (!mcCalendarOperationHubV01HasText_(after.naverProviderCalendarId)) after.naverProviderCalendarId = naverCalendarId;
    if (!mcCalendarOperationHubV01HasText_(after.naverNumericCalendarId)) after.naverNumericCalendarId = naverCalendarId;
  }
  if (googleId) {
    if (!mcCalendarOperationHubV01HasText_(after.googleProviderEventId)) after.googleProviderEventId = googleId;
    if (!mcCalendarOperationHubV01HasText_(after.googleEventId)) after.googleEventId = googleId;
    if (!mcCalendarOperationHubV01HasText_(after.googleBackupStatus)) after.googleBackupStatus = before.googleBackupStatus || 'SUCCESS';
    if (!mcCalendarOperationHubV01HasText_(after.googleSyncStatus) || String(after.googleSyncStatus || '').toUpperCase() === 'NOT_TARGET') after.googleSyncStatus = before.googleSyncStatus || 'SUCCESS';
  }
  if (naverId || googleId) {
    var currentTarget = String(after.syncTarget || '').toUpperCase();
    if (!currentTarget || currentTarget === 'NONE' || currentTarget === 'NOT_TARGET') {
      after.syncTarget = naverId && googleId ? 'BOTH' : (naverId ? 'NAVER_EXPORT' : 'GOOGLE');
    }
  }
  return after;
}




function mcCalendarOperationHubV01CurrentGoogleEmailR9C_() {
  var candidates = [];
  function add(v) {
    v = String(v || '').trim();
    if (v && v.indexOf('@') > 0) candidates.push(v);
  }
  try { add(Session.getActiveUser().getEmail()); } catch (ignoreActiveR9C) {}
  try { add(Session.getEffectiveUser().getEmail()); } catch (ignoreEffectiveR9C) {}
  try {
    if (typeof portal19GetPermissionLoadReport === 'function') {
      var r = portal19GetPermissionLoadReport() || {};
      var pr = r.profile || {};
      add(r.email || pr.email || pr.loginEmail || pr.userEmail);
    }
  } catch (ignorePortalR9C) {}
  var seen = {};
  for (var i = 0; i < candidates.length; i++) {
    var email = String(candidates[i] || '').trim();
    var key = email.toLowerCase();
    if (!seen[key]) return email;
    seen[key] = true;
  }
  return '';
}

function mcCalendarOperationHubV01ResolveStrictUpdateActorR9C_() {
  var email = mcCalendarOperationHubV01CurrentGoogleEmailR9C_();
  if (!email || email.indexOf('@') < 1) {
    throw new Error('현재 Google 인증 이메일을 확인할 수 없어 수정 저장을 중단합니다.');
  }
  var request = { actorEmail: email, googleEmail: email, sessionEmail: email, email: email };
  var profile = mcCalendarUnifiedManualInputV01ResolveActorProfile_(request);
  if (!profile || !String(profile.email || '').trim()) {
    throw new Error('현재 Google 인증 이메일 actorProfile을 생성하지 못했습니다: ' + email);
  }
  if (profile.fallback || String(profile.source || '').indexOf('LegacySessionFallback') >= 0) {
    throw new Error('현재 Google 인증 이메일이 사용자 원장에 매칭되지 않아 수정 저장을 중단합니다: ' + email);
  }
  if (!String(profile.employeeName || '').trim()) {
    throw new Error('현재 사용자 이름(employeeName)이 없어 수정 저장을 중단합니다: ' + email);
  }
  if (!String(profile.employeeId || '').trim()) {
    throw new Error('현재 사용자 employeeId가 없어 수정 저장을 중단합니다: ' + email);
  }
  profile.email = String(profile.email || email).trim();
  profile.actorKey = profile.email;
  profile.strictUpdateGate = true;
  profile.strictUpdateGateBuild = PORTAL_CALENDAR_SAFE01B_R9C_STRICT_UPDATE_GATE_BUILD;
  return profile;
}

function mcCalendarOperationHubV01CreatedSnapshotR9C_(before) {
  before = before || {};
  return {
    createdAt: before.createdAt || '',
    createdBy: before.createdBy || '',
    createdByName: before.createdByName || '',
    createdByEmail: before.createdByEmail || '',
    createdByEmployeeId: before.createdByEmployeeId || '',
    actorSource: before.actorSource || '',
    actorRoleCode: before.actorRoleCode || '',
    actorVendorId: before.actorVendorId || ''
  };
}

function mcCalendarOperationHubV01ApplyCreatedSnapshotR9C_(after, snap) {
  after = after || {};
  snap = snap || {};
  ['createdAt','createdBy','createdByName','createdByEmail','createdByEmployeeId','actorSource','actorRoleCode','actorVendorId'].forEach(function(k) {
    if (snap[k] !== undefined && snap[k] !== null && String(snap[k]).trim() !== '') after[k] = snap[k];
  });
  return after;
}

function mcCalendarOperationHubV01ApplyUpdatedActorR9C_(after, actorProfile, actor, now) {
  after = after || {};
  actorProfile = actorProfile || {};
  after.updatedAt = now || after.updatedAt || mcCalendarUnifiedManualInputV01Now_();
  after.updatedBy = actor || String(actorProfile.email || '').trim();
  after.updatedByName = String(actorProfile.employeeName || '').trim();
  after.updatedByEmail = String(actorProfile.email || '').trim();
  after.updatedByEmployeeId = String(actorProfile.employeeId || '').trim();
  after.updatedActorSource = String(actorProfile.source || '').trim();
  return after;
}

function mcCalendarOperationHubV01AssertStrictUpdatePersistedR9C_(record, actorProfile, createdSnapshot) {
  record = record || {};
  actorProfile = actorProfile || {};
  createdSnapshot = createdSnapshot || {};
  var email = String(actorProfile.email || '').trim();
  if (!email || email.indexOf('@') < 1) throw new Error('R9C 검증 실패: actor 이메일 없음');
  if (String(record.updatedBy || '').trim() !== email) throw new Error('R9C 검증 실패: updatedBy가 현재 사용자 이메일이 아닙니다. expected=' + email + ', actual=' + record.updatedBy);
  if (String(record.updatedByEmail || '').trim() !== email) throw new Error('R9C 검증 실패: updatedByEmail이 현재 사용자 이메일이 아닙니다. expected=' + email + ', actual=' + record.updatedByEmail);
  if (!String(record.updatedByName || '').trim()) throw new Error('R9C 검증 실패: updatedByName이 비어 있습니다.');
  if (!String(record.updatedByEmployeeId || '').trim()) throw new Error('R9C 검증 실패: updatedByEmployeeId가 비어 있습니다.');
  ['createdBy','createdByName','createdByEmail','createdByEmployeeId'].forEach(function(k) {
    if (String(createdSnapshot[k] || '').trim() && String(record[k] || '').trim() !== String(createdSnapshot[k] || '').trim()) {
      throw new Error('R9C 검증 실패: 최초 등록자 필드가 변경되었습니다: ' + k);
    }
  });
  return true;
}

function mcCalendarOperationHubV01ReleaseLockR9C_(lock) {
  try { if (lock && lock.releaseLock) lock.releaseLock(); } catch (ignoreReleaseR9C) {}
}

function mcCalendarOperationHubV01ResolveUpdateActorR9_(payload) {
  payload = payload || {};
  var p = {};
  Object.keys(payload).forEach(function(k) { p[k] = payload[k]; });
  var explicitEmail = String(p.actorEmail || p.googleEmail || p.sessionEmail || p.email || '').trim();
  if (explicitEmail) {
    p.actorEmail = explicitEmail;
    p.googleEmail = explicitEmail;
    p.sessionEmail = explicitEmail;
    p.email = explicitEmail;
  }
  var profile = mcCalendarUnifiedManualInputV01ResolveActorProfile_(p);
  if (profile && String(profile.email || '').trim()) return profile;
  try {
    if (typeof mcCalendarShellV01ActorContextR9_ === 'function') {
      var ctx = mcCalendarShellV01ActorContextR9_({ parameter: {} });
      ['actorEmail','googleEmail','sessionEmail','email','actorLoginId','actorEmployeeId'].forEach(function(k) { if (ctx[k] && !p[k]) p[k] = ctx[k]; });
      profile = mcCalendarUnifiedManualInputV01ResolveActorProfile_(p);
      if (profile && String(profile.email || '').trim()) return profile;
    }
  } catch (ignoreShellActorR9) {}
  return profile || mcCalendarUnifiedManualInputV01ResolveActorProfile_(payload);
}


function mcCalendarOperationHubV01FirstPayloadTextR10I_(payload, keys) {
  payload = payload || {};
  for (var i = 0; i < keys.length; i++) {
    var k = keys[i];
    if (Object.prototype.hasOwnProperty.call(payload, k)) {
      var v = String(payload[k] || '').trim();
      if (v) return v;
    }
  }
  return '';
}


function mcCalendarOperationHubV01NormalizeDateTimeR10I_(value) {
  var v = String(value || '').trim();
  if (!v) return '';
  if (typeof mcCalendarUnifiedManualInputV01NormalizeDateTime_ === 'function') {
    try {
      var n = String(mcCalendarUnifiedManualInputV01NormalizeDateTime_(v) || '').trim();
      if (n) v = n;
    } catch (ignoreNormalizeDateTimeR10I) {}
  }
  var m = v.match(/^(\d{4}-\d{2}-\d{2})[T\s](\d{2}:\d{2})(?::(\d{2}))?/);
  if (m) return m[1] + ' ' + m[2] + ':' + (m[3] || '00');
  var m2 = v.match(/^(\d{4}-\d{2}-\d{2})$/);
  if (m2) return m2[1] + ' 00:00:00';
  return v;
}

function mcCalendarOperationHubV01ComparablePersistTextR10I_(key, value) {
  if (key === 'nextCheckAt' || key === 'startAt' || key === 'endAt' || key === 'nextFollowUpAt' || key === 'moveInExpectedAt') {
    return mcCalendarOperationHubV01NormalizeDateTimeR10I_(value);
  }
  return String(value || '').trim();
}

function mcCalendarOperationHubV01ExpectedBusinessPersistMapR10I_(payload) {
  payload = payload || {};
  var expected = {};
  var contactName = mcCalendarOperationHubV01FirstPayloadTextR10I_(payload, ['contactName','contactPerson','contactPersonName','externalContactName','selectionContactName']);
  var contactPhone = mcCalendarOperationHubV01FirstPayloadTextR10I_(payload, ['contactPhone','contactPersonPhone','externalContactPhone','selectionContactPhone']);
  var contactTargetType = mcCalendarOperationHubV01FirstPayloadTextR10I_(payload, ['contactTargetType','externalContactType','selectionContactTargetType']);
  var nextAction = mcCalendarOperationHubV01FirstPayloadTextR10I_(payload, ['nextAction','selectionNextAction']);
  var nextCheckAt = mcCalendarOperationHubV01FirstPayloadTextR10I_(payload, ['nextCheckAt','selectionNextCheckAt']);
  var meetingTimelineText = mcCalendarOperationHubV01FirstPayloadTextR10I_(payload, ['meetingTimelineText','selectionMeetingTimelineText','contactTimelineText']);
  if (Object.prototype.hasOwnProperty.call(payload, 'calendarBusinessType') && String(payload.calendarBusinessType || '').trim()) expected.calendarBusinessType = String(payload.calendarBusinessType || '').trim().toUpperCase();
  if (Object.prototype.hasOwnProperty.call(payload, 'businessStage')) expected.businessStage = String(payload.businessStage || '').trim();
  if (Object.prototype.hasOwnProperty.call(payload, 'selectionId')) expected.selectionId = String(payload.selectionId || '').trim();
  if (Object.prototype.hasOwnProperty.call(payload, 'complexName')) expected.complexName = String(payload.complexName || '').trim();
  if (contactName) expected.contactName = contactName;
  if (contactPhone) expected.contactPhone = contactPhone;
  if (contactTargetType) expected.contactTargetType = contactTargetType;
  if (nextAction) expected.nextAction = nextAction;
  if (nextCheckAt) expected.nextCheckAt = mcCalendarOperationHubV01NormalizeDateTimeR10I_(nextCheckAt);
  if (meetingTimelineText) expected.meetingTimelineJson = mcCalendarOperationHubV01TextToJson_(meetingTimelineText);
  return expected;
}

function mcCalendarOperationHubV01AssertBusinessSelectionPayloadPersistedR10I_(payload, writtenRecord) {
  var expected = mcCalendarOperationHubV01ExpectedBusinessPersistMapR10I_(payload);
  var failed = [];
  Object.keys(expected).forEach(function(k) {
    var want = mcCalendarOperationHubV01ComparablePersistTextR10I_(k, expected[k]);
    var got = mcCalendarOperationHubV01ComparablePersistTextR10I_(k, (writtenRecord || {})[k]);
    if (want && got !== want) failed.push(k + ': expected=' + want + ' actual=' + got);
  });
  if (failed.length) throw new Error('R10I 수정폼 업무 필드 저장 확인 실패: ' + failed.join(' | '));
  return { ok: true, checkedFields: Object.keys(expected) };
}

function mcCalendarOperationHubV01ActorEmailKeyR9_(profile) {
  profile = profile || {};
  var email = String(profile.email || profile.actorEmail || profile.loginId || '').trim();
  if (email && email.indexOf('@') > 0) return email;
  return String(profile.actorKey || profile.employeeId || profile.employeeName || 'MAILCENTER_ACTOR').trim();
}

function mcCalendarOperationHubV01NormalizePatch_(payload, before, actor, now) {
  var out = {};
  var fields = mcCalendarOperationHubV01UpdatableFields_();
  fields.forEach(function(k) {
    if (payload[k] !== undefined) out[k] = String(payload[k] || '').trim();
  });

  // R10G: 화면에서 넘어오는 업무 타입/선정 과정 별칭까지 수정 저장에 반영한다.
  if (payload.businessType !== undefined && payload.calendarBusinessType === undefined) out.calendarBusinessType = String(payload.businessType || '').trim();
  if (payload.selectionStage !== undefined && payload.businessStage === undefined) out.businessStage = String(payload.selectionStage || '').trim();
  if (payload.eventStage !== undefined && payload.businessStage === undefined) out.businessStage = String(payload.eventStage || '').trim();
  if (payload.leadId !== undefined && payload.selectionId === undefined) out.selectionId = String(payload.leadId || '').trim();
  if (payload.prospectId !== undefined && payload.selectionId === undefined) out.selectionId = String(payload.prospectId || '').trim();
  if (payload.apartmentName !== undefined && payload.complexName === undefined) out.complexName = String(payload.apartmentName || '').trim();
  if (payload.region !== undefined && payload.complexRegion === undefined) out.complexRegion = String(payload.region || '').trim();
  if (payload.households !== undefined && payload.householdCount === undefined) out.householdCount = String(payload.households || '').trim();
  if (payload.moveInDate !== undefined && payload.moveInExpectedAt === undefined) out.moveInExpectedAt = String(payload.moveInDate || '').trim();
  if (payload.winProbability !== undefined && payload.selectionPossibility === undefined) out.selectionPossibility = String(payload.winProbability || '').trim();
  // R10I: 수정폼/향후 확장 화면에서 넘어오는 접촉자 별칭을 원장 표준 contactName/contactPhone/contactTargetType에 강제 수렴한다.
  if (payload.contactPerson !== undefined && payload.contactName === undefined) out.contactName = String(payload.contactPerson || '').trim();
  if (payload.contactPersonName !== undefined && payload.contactName === undefined) out.contactName = String(payload.contactPersonName || '').trim();
  if (payload.externalContactName !== undefined && payload.contactName === undefined) out.contactName = String(payload.externalContactName || '').trim();
  if (payload.selectionContactName !== undefined && payload.contactName === undefined) out.contactName = String(payload.selectionContactName || '').trim();
  if (payload.contactPersonPhone !== undefined && payload.contactPhone === undefined) out.contactPhone = String(payload.contactPersonPhone || '').trim();
  if (payload.externalContactPhone !== undefined && payload.contactPhone === undefined) out.contactPhone = String(payload.externalContactPhone || '').trim();
  if (payload.selectionContactPhone !== undefined && payload.contactPhone === undefined) out.contactPhone = String(payload.selectionContactPhone || '').trim();
  if (payload.externalContactType !== undefined && payload.contactTargetType === undefined) out.contactTargetType = String(payload.externalContactType || '').trim();
  if (payload.selectionContactTargetType !== undefined && payload.contactTargetType === undefined) out.contactTargetType = String(payload.selectionContactTargetType || '').trim();
  if (payload.selectionNextAction !== undefined && payload.nextAction === undefined) out.nextAction = String(payload.selectionNextAction || '').trim();
  if (payload.summary !== undefined && payload.scheduleSummary === undefined) out.scheduleSummary = String(payload.summary || '').trim();
  if (payload.primaryOwner !== undefined && payload.primaryOwnerName === undefined) out.primaryOwnerName = String(payload.primaryOwner || '').trim();
  if (payload.assistantOwner !== undefined && payload.assistantOwnerName === undefined) out.assistantOwnerName = String(payload.assistantOwner || '').trim();
  if (payload.shareTargetsText !== undefined && payload.shareTargetsJson === undefined) out.shareTargetsJson = String(payload.shareTargetsText || '').trim();
  if (payload.reportTargetsText !== undefined && payload.reportTargetsJson === undefined) out.reportTargetsJson = String(payload.reportTargetsText || '').trim();
  if (payload.selectionNextCheckAt !== undefined && payload.nextCheckAt === undefined) out.nextCheckAt = mcCalendarOperationHubV01NormalizeDateTimeR10I_(payload.selectionNextCheckAt);

  if (payload.startAt !== undefined) out.startAt = mcCalendarUnifiedManualInputV01NormalizeDateTime_(payload.startAt);
  if (payload.endAt !== undefined) out.endAt = mcCalendarUnifiedManualInputV01NormalizeDateTime_(payload.endAt);
  if (payload.nextCheckAt !== undefined) out.nextCheckAt = mcCalendarOperationHubV01NormalizeDateTimeR10I_(payload.nextCheckAt);
  if (payload.title !== undefined) out.eventTitle = out.title;
  if (payload.description !== undefined) out.eventDescription = out.description;
  if (payload.participantText !== undefined) out.participantJson = mcCalendarOperationHubV01TextToJson_(payload.participantText);
  if (payload.externalPartyText !== undefined) out.externalPartyJson = mcCalendarOperationHubV01TextToJson_(payload.externalPartyText);
  if (payload.agendaText !== undefined) out.agendaJson = mcCalendarOperationHubV01TextToJson_(payload.agendaText);
  if (payload.todoText !== undefined) out.todoJson = mcCalendarOperationHubV01TextToJson_(payload.todoText);
  if (payload.meetingTimelineText !== undefined) out.meetingTimelineJson = mcCalendarOperationHubV01TextToJson_(payload.meetingTimelineText);
  if (payload.selectionMeetingTimelineText !== undefined && payload.meetingTimelineText === undefined) out.meetingTimelineJson = mcCalendarOperationHubV01TextToJson_(payload.selectionMeetingTimelineText);
  if (payload.contactTimelineText !== undefined && payload.meetingTimelineText === undefined && payload.selectionMeetingTimelineText === undefined) out.meetingTimelineJson = mcCalendarOperationHubV01TextToJson_(payload.contactTimelineText);
  if (payload.attendeesText !== undefined) out.attendeesJson = JSON.stringify(mcCalendarUnifiedManualInputV01ParsePeople_(payload.attendeesText));
  if (payload.reminderMinutesText !== undefined) {
    var reminders = mcCalendarUnifiedManualInputV01ParseReminderMinutes_(payload.reminderMinutesText);
    out.remindersJson = JSON.stringify(reminders);
    out.reminderEnabled = reminders.length ? 'Y' : 'N';
  }
  if (payload.calendarBusinessType !== undefined || payload.businessType !== undefined) {
    var bt = String(out.calendarBusinessType || '').toUpperCase();
    out.calendarBusinessType = ['SELECTION_PROCESS','EVENT_MANAGEMENT','GENERAL_SCHEDULE'].indexOf(bt) >= 0 ? bt : ((out.eventId || out.relatedEventId) ? 'EVENT_MANAGEMENT' : (out.selectionId ? 'SELECTION_PROCESS' : 'GENERAL_SCHEDULE'));
  }
  if (payload.eventStatus !== undefined) out.status = out.eventStatus;
  if (payload.syncTarget !== undefined) {
    var st = String(payload.syncTarget || 'NONE').toUpperCase();
    out.syncTarget = ['NONE','GOOGLE','NAVER_EXPORT','BOTH'].indexOf(st) >= 0 ? st : 'NONE';
    out.googleSyncStatus = (out.syncTarget === 'GOOGLE' || out.syncTarget === 'BOTH') ? 'READY_DRY_RUN_REQUIRED' : 'NOT_TARGET';
    out.naverSyncStatus = (out.syncTarget === 'NAVER_EXPORT' || out.syncTarget === 'BOTH') ? 'EXPORT_READY' : 'NOT_TARGET';
  }
  out.updatedAt = now;
  out.updatedBy = actor;
  return out;
}

function mcCalendarOperationHubV01UpdatableFields_() {
  return ['title','description','startAt','endAt','allDay','timezone','location','meetingUrl','ownerUserId','ownerName','departmentCode','organizerRole','categoryCode','customTypeName','colorTag','priority','privacyLevel','visibility','busyStatus','repeatType','repeatRule','repeatUntil','repeatCount','eventStatus','statusReason','syncTarget','calendarBusinessType','businessStage','scheduleSubType','selectionId','complexName','complexRegion','householdCount','moveInExpectedAt','selectionPossibility','contactTargetType','contactName','contactPhone','contactResponseStatus','proposalStatus','conditionStatus','competitionStatus','nextAction','nextCheckAt','meetingTimelineJson','infoSource','expectedFairPeriod','previousFairHistory','competitorContactYn','internalOwnerName','internalOwnerEmployeeId','internalDepartmentCode','internalOrganizerRole','followUpOwnerName','externalContactRole','externalContactEmail','externalOrganization','decisionInfluenceLevel','lastContactAt','presentationEnabled','presentationAt','presentationPlace','presentationMethod','presentationMainSpeaker','presentationSubSpeaker','presentationMaterialOwner','presentationConditionOwner','presentationOperationOwner','presentationSettlementOwner','presentationParticipantsJson','externalPresentationAttendeesJson','presentationTarget','presentationMaterials','presentationRequestItems','presentationResult','expectedFairAt','venueNegotiationStatus','operationCondition','promotionCondition','vendorCondition','residentBenefitCondition','managementRequest','preCouncilRequest','feelhausProposalCondition','negotiationRisk','competitorNames','competitorCondition','feelhausStrength','concernItems','decisionMaker','decisionDueAt','actionType','actionOwner','actionDueAt','actionPriority','actionDoneYn','selectionStatus','selectedAt','rejectionReason','holdReason','reconnectAt','agreementRequired','agreementAt','agreementPlace','agreementMethod','agreementAgenda','agreementCondition','agreementResult','agreementDocumentRequired','agreementSignRequired','agreementFeelhausAttendeesJson','agreementExternalAttendeesJson','agreementStatus','attachmentMemo','scheduleSummary','processStatus','primaryOwnerName','assistantOwnerName','shareTargetsJson','reportTargetsJson','nextActionOwner','followUpRequiredYn','followUpCreatedYn','sensitiveInfoLevel','relatedLinks','relatedDocumentIds','scheduleWorkType','scheduleTargetType','calendarSourceType','approvalRequired','approvalId','approvalStatus','approvalRequester','approvalApprover','approvalApprovedAt','calendarVisibilityMode','displayPrivacyMode','connectionStatus','connectionTargetType','personalScheduleType','eventId','vendorId','customerId','saleId','contractId','installId','asId','documentId','relatedEventId','relatedVendorId','relatedCustomerId','relatedSaleId','relatedContractId','relatedInstallId','relatedAsId','eventGroupType','operationType','councilName','fairName','boothZone','meetingPurpose','meetingMethod','presentationType','decisionMemo','preparationItems','resultSummary','nextFollowUpAt','sourceWritePolicy','sourceUpdateStatus','changeReason'];
}

function mcCalendarOperationHubV01ResolvePolicy_(sourceType, sourceWritePolicy, coreChanged) {
  sourceType = String(sourceType || '').toUpperCase();
  sourceWritePolicy = String(sourceWritePolicy || '').toUpperCase() || (sourceType === 'MANUAL' ? 'CALENDAR_ONLY' : 'READONLY_SOURCE');
  if (sourceType === 'MANUAL') {
    return { ok: true, sourceWritePolicy: 'CALENDAR_ONLY', sourceUpdateStatus: 'NOT_REQUIRED', message: '수동일정은 캘린더 원장을 직접 수정했습니다.' };
  }
  if (sourceWritePolicy === 'SYNC_TO_SOURCE' && coreChanged) {
    return { ok: true, sourceWritePolicy: 'SYNC_TO_SOURCE', sourceUpdateStatus: 'APPROVAL_REQUIRED', message: '연동 원장 핵심정보 변경은 승인 필요 상태로 기록했습니다. ERP/Mail 원본은 직접 덮어쓰지 않았습니다.' };
  }
  return { ok: true, sourceWritePolicy: 'CALENDAR_ONLY', sourceUpdateStatus: 'PENDING', message: '연동 일정은 캘린더 표시정보만 수정하고 원본 반영은 대기 상태로 기록했습니다.' };
}

function mcCalendarOperationHubV01ValidateUpdate_(record) {
  var errors = [];
  if (!record.title && !record.eventTitle) errors.push({ code: 'TITLE_REQUIRED', message: '일정 제목은 필수입니다.' });
  if (!record.startAt) errors.push({ code: 'START_REQUIRED', message: '시작일시는 필수입니다.' });
  if (!record.endAt) errors.push({ code: 'END_REQUIRED', message: '종료일시는 필수입니다.' });
  if (record.startAt && record.endAt) {
    var s = new Date(String(record.startAt).replace(' ', 'T'));
    var e = new Date(String(record.endAt).replace(' ', 'T'));
    if (!isNaN(s.getTime()) && !isNaN(e.getTime()) && e.getTime() < s.getTime()) errors.push({ code: 'END_BEFORE_START', message: '종료일시는 시작일시 이후여야 합니다.' });
  }
  if ((record.syncTarget === 'GOOGLE' || record.syncTarget === 'BOTH') && record.privacyLevel === 'CONFIDENTIAL') {
    errors.push({ code: 'CONFIDENTIAL_GOOGLE_SYNC_BLOCKED', message: '민감/제한 일정은 Google Sync 후보로 저장할 수 없습니다.' });
  }
  return { ok: errors.length === 0, errors: errors };
}

function mcCalendarOperationHubV01FindRowById_(sheet, calendarEventId) {
  var out = { found: false, rowNumber: 0, record: {} };
  var values = sheet.getDataRange().getValues();
  if (values.length < 2) return out;
  var headers = values[0] || [];
  var hm = mcCalendarUnifiedManualInputV01HeaderMap_(headers);
  var idCol = hm.calendarEventId;
  if (idCol === undefined) return out;
  for (var r = 1; r < values.length; r++) {
    if (String(values[r][idCol] || '').trim() === String(calendarEventId || '').trim()) {
      out.found = true;
      out.rowNumber = r + 1;
      headers.forEach(function(h, i) { if (String(h || '').trim()) out.record[String(h).trim()] = values[r][i]; });
      return out;
    }
  }
  return out;
}

function mcCalendarOperationHubV01WriteRowByHeaders_(sheet, rowNumber, record) {
  var headers = sheet.getRange(1, 1, 1, Math.max(sheet.getLastColumn(), 1)).getValues()[0] || [];
  var row = headers.map(function(h) { return record[String(h || '').trim()] || ''; });
  sheet.getRange(rowNumber, 1, 1, row.length).setValues([row]);
}

function mcCalendarOperationHubV01ChangedFields_(before, after) {
  var ignore = { updatedAt: true, updatedBy: true, lastChangedFields: true };
  var keys = {};
  Object.keys(before || {}).forEach(function(k) { keys[k] = true; });
  Object.keys(after || {}).forEach(function(k) { keys[k] = true; });
  return Object.keys(keys).filter(function(k) { return !ignore[k] && String(before[k] || '') !== String(after[k] || ''); });
}

function mcCalendarOperationHubV01TextToJson_(text) {
  var arr = String(text || '').split(/[\n|;]+/).map(function(x) { return String(x || '').trim(); }).filter(Boolean).map(function(x, i) { return { index: i + 1, text: x }; });
  return JSON.stringify(arr);
}

function mcCalendarOperationHubV01ListRecentOperationEvents_(limit, sourceType) {
  limit = Number(limit || 5);
  var ss = mcCalendarUnifiedManualInputV01OpenMaster_();
  var sheet = mcCalendarUnifiedManualInputV01GetSheetOrCreate_(ss, 'MAILCENTER_CalendarEvents', mcCalendarOperationHubV01CalendarHeaders_());
  var values = sheet.getDataRange().getValues();
  if (values.length < 2) return [];
  var headers = values[0] || [];
  var hm = mcCalendarUnifiedManualInputV01HeaderMap_(headers);
  var out = [];
  for (var r = values.length - 1; r >= 1 && out.length < limit; r--) {
    var row = values[r];
    var st = String(mcCalendarUnifiedManualInputV01Cell_(row, hm, ['sourceType','calendarType']) || '').trim();
    if (sourceType && st !== sourceType) continue;
    out.push({
      rowNumber: r + 1,
      calendarEventId: String(mcCalendarUnifiedManualInputV01Cell_(row, hm, ['calendarEventId']) || '').trim(),
      sourceType: st,
      title: String(mcCalendarUnifiedManualInputV01Cell_(row, hm, ['title','eventTitle']) || '').trim(),
      startAt: String(mcCalendarUnifiedManualInputV01Cell_(row, hm, ['startAt']) || '').trim(),
      endAt: String(mcCalendarUnifiedManualInputV01Cell_(row, hm, ['endAt']) || '').trim(),
      eventGroupType: String(mcCalendarUnifiedManualInputV01Cell_(row, hm, ['eventGroupType']) || '').trim(),
      ownerName: String(mcCalendarUnifiedManualInputV01Cell_(row, hm, ['ownerName']) || '').trim(),
      sourceWritePolicy: String(mcCalendarUnifiedManualInputV01Cell_(row, hm, ['sourceWritePolicy']) || '').trim(),
      sourceUpdateStatus: String(mcCalendarUnifiedManualInputV01Cell_(row, hm, ['sourceUpdateStatus']) || '').trim()
    });
  }
  return out;
}

function mcCalendarOperationHubV01PublicDetail_(record) {
  var keys = mcCalendarOperationHubV01CalendarHeaders_();
  var out = {};
  keys.forEach(function(k) { out[k] = record[k] || ''; });
  return out;
}

function mcCalendarOperationHubV01CalendarHeaders_() {
  var base = mcCalendarUnifiedManualInputV01CalendarHeaders_();
  var ext = ['eventGroupType','operationType','ownerUserId','departmentCode','participantJson','externalPartyJson','decisionMemo','todoJson','agendaJson','presentationType','meetingMethod','relatedEventId','relatedVendorId','relatedCustomerId','relatedSaleId','relatedContractId','relatedInstallId','relatedAsId','sourceWritePolicy','sourceUpdateStatus','changeReason','lastChangedFields','organizerRole','councilName','fairName','boothZone','meetingPurpose','preparationItems','resultSummary','nextFollowUpAt'].concat(mcCalendarOperationHubV01ExternalLinkFields_());
  var seen = {};
  return base.concat(ext).filter(function(h) { if (seen[h]) return false; seen[h] = true; return true; });
}

function mcCalendarOperationHubV01ChangeLogHeaders_() {
  return ['changeLogId','build','module','calendarEventId','changeType','sourceType','sourceWritePolicy','sourceUpdateStatus','changedFields','changeReason','beforeSummary','afterSummary','beforeSnapshot','afterSnapshot','createdAt','createdBy','createdByName','createdByEmail','createdByEmployeeId','actorRoleCode','actorVendorId','actorSource'];
}

function mcCalendarOperationHubV01AppendChangeLog_(ss, log) {
  var sheet = mcCalendarUnifiedManualInputV01GetSheetOrCreate_(ss, 'MAILCENTER_CalendarChangeLogs', mcCalendarOperationHubV01ChangeLogHeaders_());
  log.changeLogId = 'MCALCHG-' + Utilities.getUuid();
  log.build = PORTAL_CALENDAR_SAFE01B_R9_UPDATE_ACTOR_CHANGELOG_BUILD || MC_CALENDAR_OPERATION_HUB_V01_BUILD;
  log.module = 'MAILCENTER_CALENDAR_OPERATION';
  log.changeType = log.changeType || 'UPDATE';
  log.beforeSnapshot = log.beforeSnapshot || '';
  log.afterSnapshot = log.afterSnapshot || '';
  log.createdByEmployeeId = log.createdByEmployeeId || '';
  log.actorRoleCode = log.actorRoleCode || '';
  log.actorVendorId = log.actorVendorId || '';
  mcCalendarUnifiedManualInputV01AppendByHeaders_(sheet, log);
  try {
    mcCalendarUnifiedManualInputV01AppendAudit_(ss, {
      actionType: 'UPDATE_OPERATION_CALENDAR_EVENT',
      resultStatus: 'SUCCESS',
      calendarEventId: log.calendarEventId,
      message: log.changeReason || '운영 캘린더 일정 수정',
      payloadSummary: JSON.stringify({ changedFields: log.changedFields, sourceUpdateStatus: log.sourceUpdateStatus, changeType: log.changeType || 'UPDATE' }).slice(0, 900),
      createdAt: log.createdAt,
      createdBy: log.createdBy,
      createdByName: log.createdByName || '',
      createdByEmail: log.createdByEmail || '',
      actorSource: log.actorSource || ''
    });
  } catch (err) {}
}

function mcCalendarOperationHubV01CompactUpdate_(res) {
  res = res || {};
  return { ok: !!res.ok, calendarEventId: res.calendarEventId || '', message: res.message || '', changedFields: res.changedFields || [], policy: res.policy || {} };
}

function mcCalendarOperationHubV01R9RuntimeVerifyMarker_() {
  return {
    ok: true,
    build: PORTAL_CALENDAR_SAFE01B_R9_UPDATE_ACTOR_CHANGELOG_BUILD,
    verifyFixBuild: PORTAL_CALENDAR_SAFE01B_R9A_RUNTIME_VERIFY_FIX_BUILD,
    strictUpdateGateBuild: PORTAL_CALENDAR_SAFE01B_R9C_STRICT_UPDATE_GATE_BUILD,
    updateFunctionReady: typeof mcCalendarOperationHubV01UpdateEvent === 'function',
    updateActorResolverReady: typeof mcCalendarOperationHubV01ResolveUpdateActorR9_ === 'function',
    strictUpdateActorResolverReady: typeof mcCalendarOperationHubV01ResolveStrictUpdateActorR9C_ === 'function',
    strictUpdateGateReady: typeof mcCalendarOperationHubV01AssertStrictUpdatePersistedR9C_ === 'function',
    updateUsesEmailKey: typeof mcCalendarOperationHubV01ActorEmailKeyR9_ === 'function',
    changeLogAppendReady: typeof mcCalendarOperationHubV01AppendChangeLog_ === 'function',
    changeLogHeadersReady: typeof mcCalendarOperationHubV01ChangeLogHeaders_ === 'function',
    createdByPreservedOnUpdate: true,
    updatedActorFieldsWritten: true,
    changeLogSnapshotsReady: true,
    changeLogActorFieldsReady: true
  };
}

function mcCalendarOperationHubV01BaseResult_(action) { return { ok: false, build: MC_CALENDAR_OPERATION_HUB_V01_BUILD, action: action, generatedAt: mcCalendarUnifiedManualInputV01Now_(), realApplyExecuted: false, destructiveRepairExecuted: false, warnings: [], errors: [], message: '', nextAction: '' }; }
function mcCalendarOperationHubV01Catch_(result, err) { result.ok = false; result.message = String(err && err.message ? err.message : err); result.errors.push({ message: result.message, stack: err && err.stack ? err.stack : '' }); result.nextAction = '권한, 상태, 변경사유, 원장 헤더를 확인하세요.'; }
function mcCalendarOperationHubV01Print_(result) { result.endedAt = mcCalendarUnifiedManualInputV01Now_(); Logger.log('JSON_COMPACT_RESULT: ' + JSON.stringify(result)); return result; }
