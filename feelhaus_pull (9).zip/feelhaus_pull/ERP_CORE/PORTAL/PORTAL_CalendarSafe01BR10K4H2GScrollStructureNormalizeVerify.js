function portalCalendarSafe01BR10K4H2GScrollStructureNormalizeVerify() {
  var build='PORTAL_CALENDAR_SAFE01B_R10K4H2G_SCROLL_STRUCTURE_NORMALIZE_20260604';
  var html=''; var err='';
  try{html=HtmlService.createHtmlOutputFromFile('MC_CalendarViewV01').getContent();}catch(e){err=String(e&&e.message?e.message:e);}
  var htmlClose=html.lastIndexOf('</html>');
  var afterHtml=htmlClose>=0?html.slice(htmlClose+7).trim():'';
  var checks={
    viewReadable: !!html,
    buildMarkerPresent: html.indexOf(build)>=0,
    postBodyPatchRemoved: afterHtml==='',
    h2fPostBodyScrollGuardRemoved: html.indexOf('PORTAL_CALENDAR_SAFE01B_R10K4H2F_CREATE_RESET_SCROLL_STABILITY_20260604')<0,
    scrollMargin96Removed: html.indexOf('scroll-margin-top:96px')<0,
    manualBodySingleScrollReady: html.indexOf('function scrollBody()')>=0 && html.indexOf("r.querySelector('.manual-body.r10k4e-manual-body')")>=0,
    modalBoxNotUsedAsScrollRestoreTarget: html.indexOf('function modal(){var r=root();return r?(r.querySelector(\'.manual-modal\')||r):null}')<0,
    h2gNormalizeFunctionReady: html.indexOf('fhCalendarR10K4H2GNormalizeManualScroll')>=0,
    createResetPreserved: html.indexOf('fhCalendarR10K4H2GResetCreateForm')>=0 && html.indexOf("setVal('me_meetingAddYn','N')")>=0 && html.indexOf("setVal('me_meetingRecorderName',actorName())")>=0,
    h2fResetAliasReady: html.indexOf('fhCalendarR10K4H2FResetCreateForm=window.fhCalendarR10K4H2GResetCreateForm')>=0,
    setManualModeCreateNormalized: html.indexOf('setManualModeCreate-normalized')>=0 && html.indexOf('__r10k4h2gNormalizedWrapped')>=0,
    openManualNormalized: html.indexOf('openManualEventModal-normalized')>=0,
    editModePreserved: html.indexOf('openOperationEditModal-normalized')>=0 && html.indexOf("data-create-reset-ready','EDIT'")>=0,
    fieldFocusGuardReady: html.indexOf('pointerdown')>=0 && html.indexOf('focusin')>=0 && html.indexOf('restoreScroll(window.__r10k4h2gScrollKeep')>=0,
    h2cSaveUxKept: html.indexOf('PORTAL_CALENDAR_SAFE01B_R10K4H2C_SAVE_UX_AUTORF_PAUSE_20260604')>=0,
    h2eMeetingDisplayKept: html.indexOf('PORTAL_CALENDAR_SAFE01B_R10K4H2E_MEETING_LEDGER_TARGET_DISPLAY_20260604')>=0,
    h2bBindingKept: html.indexOf('PORTAL_CALENDAR_SAFE01B_R10K4H2B_INPUT_BINDING_SAVE_LINK_REPAIR_20260604')>=0,
    g4DataLoadingKept: html.indexOf('PORTAL_CALENDAR_SAFE01B_R10K4G4_DATA_LOAD_SPEED_REPAIR_20260604')>=0,
    g5RecordInitialStateKept: html.indexOf('recordInitialState')>=0,
    g6BaseScrollKept: html.indexOf('PORTAL_CALENDAR_SAFE01B_R10K4G6_MODAL_SCROLL_REPAIR_20260604')>=0,
    providerWriteNotAdded: html.indexOf('Calendar.Events.insert')<0 && html.indexOf('Calendar.Events.update')<0 && html.indexOf('UrlFetchApp.fetch')<0
  };
  var fatal=[];
  Object.keys(checks).forEach(function(k){ if(checks[k]!==true) fatal.push(k); });
  var result={ok:fatal.length===0, build:build, baseBuild:'PORTAL_CALENDAR_SAFE01B_R10K4H2F_CREATE_RESET_SCROLL_STABILITY_20260604', action:'portalCalendarSafe01BR10K4H2GScrollStructureNormalizeVerify', safety:'READ_ONLY_RUNTIME_VERIFY_NO_SHEET_PROVIDER_WRITE', checks:checks, diagnostics:{htmlLength:html.length, readError:err, afterHtmlLength:afterHtml.length}, fatal:fatal, message:fatal.length?'R10K4H2G scroll structure normalize verification failed.':'R10K4H2G scroll structure normalize verification passed.'};
  Logger.log('JSON_COMPACT_RESULT: '+JSON.stringify(result));
  return result;
}
function portalCalendarSafe01BR10K4H2GVerify(){return portalCalendarSafe01BR10K4H2GScrollStructureNormalizeVerify();}
