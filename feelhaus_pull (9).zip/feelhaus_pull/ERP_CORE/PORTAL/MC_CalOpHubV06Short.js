/**
 * FEELHAUS PORTAL / MailCenter Calendar Operation Hub V06 Short Runner
 * Build: PORTAL_MC_CALENDAR_OPERATION_HUB_SHORT_RUNNER_V06_20260528
 * Purpose: provide short Apps Script runnable function names and keep color marker as warning.
 * Safety: no Google/Naver real apply, no destructive repair, no clear/delete.
 */
var PORTAL_MC_CALENDAR_OPERATION_HUB_SHORT_RUNNER_V06_BUILD = 'PORTAL_MC_CALENDAR_OPERATION_HUB_SHORT_RUNNER_V06_20260528';

function _fhCalV06Now_() {
  return Utilities.formatDate(new Date(), Session.getScriptTimeZone() || 'Asia/Seoul', 'yyyy-MM-dd HH:mm:ss');
}
function _fhCalV06Log_(result) {
  try { Logger.log('JSON_COMPACT_RESULT: ' + JSON.stringify(result)); } catch (e) { Logger.log(String(result)); }
  return result;
}
function _fhCalV06Call_(action, fnName) {
  var startedAt = _fhCalV06Now_();
  var result = {
    ok: false,
    build: PORTAL_MC_CALENDAR_OPERATION_HUB_SHORT_RUNNER_V06_BUILD,
    action: action,
    targetFunction: fnName,
    generatedAt: startedAt,
    realApplyExecuted: false,
    destructiveRepairExecuted: false,
    warnings: [],
    errors: []
  };
  try {
    if (typeof this[fnName] !== 'function') throw new Error('대상 함수가 없습니다: ' + fnName);
    var inner = this[fnName]();
    result.ok = !!(inner && inner.ok !== false);
    result.innerBuild = inner && inner.build ? inner.build : '';
    result.innerAction = inner && inner.action ? inner.action : fnName;
    result.innerMessage = inner && inner.message ? inner.message : '';
    result.summary = inner && inner.summary ? inner.summary : undefined;
    result.calendarEventId = inner && inner.calendarEventId ? inner.calendarEventId : (inner && inner.inner && inner.inner.calendarEventId ? inner.inner.calendarEventId : '');
    result.message = '짧은 실행 함수가 정상 호출되었습니다.';
    result.nextAction = '다음 짧은 함수 실행 또는 화면 확인';
    result.endedAt = _fhCalV06Now_();
    return _fhCalV06Log_(result);
  } catch (err) {
    result.ok = false;
    result.message = 'Error: ' + (err && err.message ? err.message : String(err));
    result.errors.push({ message: result.message, stack: err && err.stack ? err.stack : '' });
    result.endedAt = _fhCalV06Now_();
    return _fhCalV06Log_(result);
  }
}

// 짧은 실행 함수 목록
function calTest() { return _fhCalV06Call_('calTest', 'mcCalendarOperationHubScreenSaveVerifyV05SelfTest'); }
function calDry() { return _fhCalV06Call_('calDry', 'mcCalendarOperationHubScreenSaveVerifyV05CreateScreenSampleDryRun'); }
function calSave() { return _fhCalV06Call_('calSave', 'mcCalendarOperationHubScreenSaveVerifyV05CreateScreenSampleReal'); }
function calCheck() { return _fhCalV06Call_('calCheck', 'mcCalendarOperationHubScreenSaveVerifyV05VerifyRecentScreenSaved'); }
function calEdit() { return _fhCalV06Call_('calEdit', 'mcCalendarOperationHubScreenSaveVerifyV05UpdateRecentScreenSample'); }
function calList() { return _fhCalV06Call_('calList', 'mcCalendarOperationHubV01ListRecentOperation5'); }
function calColor() { return _fhCalV06Call_('calColor', 'feelhausCommonUiColorRefreshV02CheckCalendarRoute'); }

function calHelp() {
  return _fhCalV06Log_({
    ok: true,
    build: PORTAL_MC_CALENDAR_OPERATION_HUB_SHORT_RUNNER_V06_BUILD,
    action: 'calHelp',
    generatedAt: _fhCalV06Now_(),
    realApplyExecuted: false,
    destructiveRepairExecuted: false,
    message: '짧은 실행 함수 안내',
    runOrder: ['calTest','calDry','calSave','calCheck','calEdit','calCheck'],
    optional: ['calList','calColor'],
    notes: [
      'calSave는 MAILCENTER_CalendarEvents에 검증용 일정 1건을 실제 저장합니다.',
      'Google/Naver 실반영은 실행하지 않습니다.',
      '앞으로 긴 함수명 대신 이 짧은 함수명을 우선 사용하세요.'
    ]
  });
}
