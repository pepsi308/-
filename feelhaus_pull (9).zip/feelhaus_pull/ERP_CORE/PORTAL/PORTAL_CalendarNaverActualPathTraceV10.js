/**
 * PORTAL_CALENDAR_STEP08_NAVER_ACTUAL_PATH_TRACE_V10_20260601
 * NAVER actual save-path request/response trace helpers.
 * Safety: helper/diagnostic only. No calendar write unless an existing NAVER createSchedule call explicitly routes through fhNaverTraceV10FetchCreateScheduleWithTrace_().
 */
var PORTAL_CALENDAR_STEP08_NAVER_ACTUAL_PATH_TRACE_V10_20260601 = true;

function portalCalendarStep08NaverActualPathTraceDiagnoseV10() {
  var cfg = fhNaverTraceV10ReadConfig_();
  var out = {
    ok: true,
    build: 'PORTAL_CALENDAR_STEP08_NAVER_ACTUAL_PATH_TRACE_V10_20260601',
    action: 'portalCalendarStep08NaverActualPathTraceDiagnoseV10',
    safety: 'READ_ONLY_CONFIG_TRACE_DIAG_NO_NAVER_WRITE',
    generatedAt: fhNaverTraceV10Now_(),
    config: {
      NAVER_CALENDAR_ENABLED: cfg.NAVER_CALENDAR_ENABLED || '',
      FEATURE_NAVER_CALENDAR_ENABLED: cfg.FEATURE_NAVER_CALENDAR_ENABLED || '',
      NAVER_CALENDAR_CREATE_URL: cfg.NAVER_CALENDAR_CREATE_URL || '',
      NAVER_UPDATE_CALENDAR_ID: cfg.NAVER_UPDATE_CALENDAR_ID || '',
      NAVER_NUMERIC_CALENDAR_ID: cfg.NAVER_NUMERIC_CALENDAR_ID || ''
    },
    requiredTraceKeys: [
      'NAVER_ACTUAL_PATH_TRACE_V10',
      'request.calendarEventId',
      'request.action',
      'request.calendarId',
      'request.uid',
      'request.dtStart',
      'request.dtEnd',
      'request.summary',
      'request.scheduleIcalString',
      'response.httpCode',
      'response.body',
      'response.processType',
      'response.icalUid',
      'response.calendarId',
      'judgement.displayHint'
    ],
    nextAction: 'Route the real NAVER createSchedule fetch through fhNaverTraceV10FetchCreateScheduleWithTrace_ and upload PORTAL_latest.log after one save.'
  };
  Logger.log('JSON_COMPACT_RESULT: ' + JSON.stringify(out));
  return out;
}

function portalCalendarStep08NaverActualPathTraceUsageV10() {
  var out = {
    ok: true,
    build: 'PORTAL_CALENDAR_STEP08_NAVER_ACTUAL_PATH_TRACE_V10_20260601',
    action: 'portalCalendarStep08NaverActualPathTraceUsageV10',
    safety: 'READ_ONLY_USAGE_GUIDE',
    usage: [
      'Find the real NAVER createSchedule UrlFetchApp.fetch call inside PORTAL_CalendarExternalAutoSyncV01.js.',
      'Immediately before the fetch, build traceContext with calendarEventId, action, calendarId, uid, and scheduleIcalString.',
      'Replace UrlFetchApp.fetch(url, options) with fhNaverTraceV10FetchCreateScheduleWithTrace_(url, options, traceContext).',
      'After saving one PORTAL schedule, upload PORTAL_latest.log and check NAVER_ACTUAL_PATH_TRACE_V10 entries.'
    ],
    sample: "var traceContext={calendarEventId:ev.calendarEventId||ev.id,action:isModify?'MODIFY':'CREATE',calendarId:calendarId,uid:uid,scheduleIcalString:scheduleIcalString};\nvar response=fhNaverTraceV10FetchCreateScheduleWithTrace_(url,options,traceContext);"
  };
  Logger.log('JSON_COMPACT_RESULT: ' + JSON.stringify(out));
  return out;
}

function fhNaverTraceV10FetchCreateScheduleWithTrace_(url, options, traceContext) {
  traceContext = traceContext || {};
  var requestTrace = fhNaverTraceV10BuildRequestTrace_(url, options, traceContext);
  fhNaverTraceV10Log_('REQUEST', requestTrace);
  var response = null;
  var responseTrace = null;
  try {
    response = UrlFetchApp.fetch(url, options);
    responseTrace = fhNaverTraceV10BuildResponseTrace_(response, requestTrace);
    fhNaverTraceV10Log_('RESPONSE', responseTrace);
    return response;
  } catch (err) {
    responseTrace = {
      trace: 'NAVER_ACTUAL_PATH_TRACE_V10',
      phase: 'ERROR',
      build: 'PORTAL_CALENDAR_STEP08_NAVER_ACTUAL_PATH_TRACE_V10_20260601',
      generatedAt: fhNaverTraceV10Now_(),
      request: requestTrace.request,
      error: String(err && err.stack ? err.stack : err),
      judgement: { displayHint: 'NAVER fetch threw exception before response body was available.' }
    };
    fhNaverTraceV10Log_('ERROR', responseTrace);
    throw err;
  }
}

function fhNaverTraceV10BuildRequestTrace_(url, options, traceContext) {
  var payload = (options && options.payload) || {};
  var scheduleIcalString = traceContext.scheduleIcalString || payload.scheduleIcalString || payload.scheduleIcal || '';
  var ical = fhNaverTraceV10ExtractIcalFields_(scheduleIcalString);
  var calendarId = String(traceContext.calendarId || payload.calendarId || payload.calendarid || '').trim();
  var uid = String(traceContext.uid || ical.UID || '').trim();
  return {
    trace: 'NAVER_ACTUAL_PATH_TRACE_V10',
    phase: 'REQUEST',
    build: 'PORTAL_CALENDAR_STEP08_NAVER_ACTUAL_PATH_TRACE_V10_20260601',
    generatedAt: fhNaverTraceV10Now_(),
    request: {
      url: url,
      method: options && options.method || 'post',
      calendarEventId: traceContext.calendarEventId || traceContext.eventId || '',
      action: traceContext.action || traceContext.mode || '',
      calendarId: calendarId,
      uid: uid,
      dtStart: ical.DTSTART || '',
      dtEnd: ical.DTEND || '',
      summary: ical.SUMMARY || '',
      description: ical.DESCRIPTION || '',
      scheduleIcalString: scheduleIcalString
    },
    judgement: {
      missingCalendarId: !calendarId,
      missingUid: !uid,
      missingDtStart: !ical.DTSTART,
      displayHint: 'Compare request DTSTART/DTEND and UID with the NAVER UI/iCal detail.'
    }
  };
}

function fhNaverTraceV10BuildResponseTrace_(response, requestTrace) {
  var httpCode = response && response.getResponseCode ? response.getResponseCode() : '';
  var body = response && response.getContentText ? response.getContentText() : '';
  var parsed = fhNaverTraceV10SafeJson_(body);
  var rv = parsed && parsed.returnValue ? parsed.returnValue : {};
  var processType = rv.processType || parsed.processType || '';
  var icalUid = rv.icalUid || rv.uid || parsed.icalUid || parsed.uid || '';
  var calendarId = rv.calendarId || parsed.calendarId || '';
  var judgement = {
    successHttp: Number(httpCode) >= 200 && Number(httpCode) < 300,
    processType: processType,
    isModify: String(processType).toLowerCase() === 'modify',
    isCreate: String(processType).toLowerCase() === 'create',
    displayHint: fhNaverTraceV10DisplayHint_(httpCode, body, processType, icalUid, calendarId, requestTrace)
  };
  return {
    trace: 'NAVER_ACTUAL_PATH_TRACE_V10',
    phase: 'RESPONSE',
    build: 'PORTAL_CALENDAR_STEP08_NAVER_ACTUAL_PATH_TRACE_V10_20260601',
    generatedAt: fhNaverTraceV10Now_(),
    request: requestTrace.request,
    response: {
      httpCode: httpCode,
      body: body,
      processType: processType,
      icalUid: icalUid,
      calendarId: calendarId,
      rawReturnValue: rv
    },
    judgement: judgement
  };
}

function fhNaverTraceV10DisplayHint_(httpCode, body, processType, icalUid, calendarId, requestTrace) {
  if (String(httpCode) === '401' || String(httpCode) === '403') return 'Auth failure. Token refresh path is not connected or permission is rejected.';
  if (String(httpCode).charAt(0) === '4') return 'Client/API parameter failure. Inspect response.body and request.scheduleIcalString.';
  if (!icalUid) return 'NAVER did not return icalUid. Need response schema adjustment.';
  if (!calendarId) return 'NAVER did not return calendarId. Compare configured NAVER_UPDATE_CALENDAR_ID.';
  if (String(processType).toLowerCase() === 'create' && requestTrace && requestTrace.request && requestTrace.request.action === 'MODIFY') return 'Modify path returned create. UID reuse failed or NAVER treated it as new event.';
  return 'Check NAVER UI by request.dtStart/request.dtEnd and response.calendarId.';
}

function fhNaverTraceV10ExtractIcalFields_(ical) {
  ical = String(ical || '');
  var keys = ['UID','DTSTART','DTEND','SUMMARY','DESCRIPTION'];
  var out = {};
  keys.forEach(function(k){
    var re = new RegExp('^' + k + '(?:;[^:]*)?:(.*)$', 'mi');
    var m = ical.match(re);
    out[k] = m ? String(m[1] || '').trim() : '';
  });
  var cal = ical.match(/\[CALENDAR-ID\]\s*:\s*([^\r\n]+)/i);
  out.CALENDAR_ID = cal ? String(cal[1] || '').trim() : '';
  return out;
}

function fhNaverTraceV10SafeJson_(text) {
  try { return JSON.parse(String(text || '')); } catch (e) { return {}; }
}

function fhNaverTraceV10Log_(phase, obj) {
  Logger.log('[NAVER_ACTUAL_PATH_TRACE_V10][' + phase + '] ' + JSON.stringify(obj));
}

function fhNaverTraceV10Now_() {
  return Utilities.formatDate(new Date(), 'Asia/Seoul', 'yyyy-MM-dd HH:mm:ss');
}

function fhNaverTraceV10ReadConfig_() {
  var out = {};
  try {
    var ss = SpreadsheetApp.openById('17VMSpgSZCvIrUlgcw8yCNcnl8WQWo2IcRf5tDCcuJGM');
    var sh = ss.getSheetByName('SystemConfig');
    if (!sh) return out;
    var values = sh.getDataRange().getValues();
    var head = values.shift() || [];
    var keyIdx = head.indexOf('CONFIG_KEY');
    var valIdx = head.indexOf('VALUE');
    var statusIdx = head.indexOf('status');
    values.forEach(function(r){
      var k = String(r[keyIdx] || '').trim();
      if (!k) return;
      if (statusIdx >= 0 && String(r[statusIdx] || '').toUpperCase() === 'INACTIVE') return;
      out[k] = r[valIdx];
    });
  } catch (e) {
    out.__error = String(e);
  }
  return out;
}
