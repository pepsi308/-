/**
 * PORTAL_CALENDAR_SAFE01B_R10J4_BASIC_INFO_EXPANSION_20260603
 * READ_ONLY verification. No sheet/provider writes.
 */
function portalCalendarSafe01BR10J4BasicInfoVerify() {
  var build = 'PORTAL_CALENDAR_SAFE01B_R10J4_BASIC_INFO_EXPANSION_20260603';
  var out = { ok:false, build:build, action:'portalCalendarSafe01BR10J4BasicInfoVerify', safety:'READ_ONLY_RUNTIME_VERIFY_NO_SHEET_PROVIDER_WRITE', checks:{}, warnings:[], fatal:[] };
  function html_(name){ try { return String(HtmlService.createHtmlOutputFromFile(name).getContent() || ''); } catch(e){ out.warnings.push('html read failed: '+name+' '+e.message); return ''; } }
  function src_(fn){ try { return String(fn && fn.toString ? fn.toString() : ''); } catch(e){ return ''; } }
  var view = html_('MC_CalendarViewV01');
  var opFields = [];
  try { opFields = mcCalendarOperationHubV01UpdatableFields_(); } catch(e) { out.warnings.push('updatable fields runtime failed: '+e.message); }
  var up = {}; (opFields || []).forEach(function(k){ up[k]=true; });
  var manualNorm = src_(typeof mcCalendarUnifiedManualInputV01NormalizePayload_ !== 'undefined' ? mcCalendarUnifiedManualInputV01NormalizePayload_ : null);
  var required = ['scheduleSummary','processStatus','primaryOwnerName','assistantOwnerName','shareTargetsJson','reportTargetsJson','nextActionOwner','followUpRequiredYn','followUpCreatedYn','sensitiveInfoLevel','relatedLinks','relatedDocumentIds'];
  var checks = out.checks;
  checks.viewR10J4MarkerPresent = view.indexOf(build) >= 0 && view.indexOf('__MC_CALENDAR_R10J4_BASIC_INFO_BUILD__') >= 0;
  checks.r10j2ScreenLayoutKept = view.indexOf('PORTAL_CALENDAR_SAFE01B_R10J2_SCREEN_LAYOUT_POLISH_20260603') >= 0 && view.indexOf('operationInfoSectionTitleR10J2') >= 0;
  checks.basicInfoSectionRenamed = view.indexOf('1. 일정 기본정보 / 공통 업무카드') >= 0;
  checks.scheduleSummaryFieldReady = view.indexOf('me_scheduleSummary') >= 0 && view.indexOf('일정 요약') >= 0;
  checks.internalStaffCommonReady = view.indexOf('me_primaryOwnerName') >= 0 && view.indexOf('필하우스 주담당자') >= 0 && view.indexOf('me_assistantOwnerName') >= 0;
  checks.shareReportTargetsReady = view.indexOf('me_shareTargetsJson') >= 0 && view.indexOf('me_reportTargetsJson') >= 0;
  checks.followUpCommonReady = view.indexOf('me_nextActionOwner') >= 0 && view.indexOf('me_followUpRequiredYn') >= 0 && view.indexOf('me_followUpCreatedYn') >= 0;
  checks.privacySensitiveReady = view.indexOf('me_sensitiveInfoLevel') >= 0 && view.indexOf('민감정보 여부') >= 0;
  checks.relatedLinksReady = view.indexOf('me_relatedLinks') >= 0 && view.indexOf('me_relatedDocumentIds') >= 0;
  checks.detailBasicCardsReady = view.indexOf('r10j4-basic-card') >= 0 && view.indexOf('후속 담당/일정') >= 0 && view.indexOf('관련 링크/문서') >= 0;
  checks.changedFieldLabelsReady = view.indexOf("scheduleSummary:'일정 요약'") >= 0 && view.indexOf("primaryOwnerName:'필하우스 주담당자'") >= 0;
  checks.operationUpdatableBasicReady = required.every(function(k){ return !!up[k]; });
  checks.manualNormalizeBasicReady = required.every(function(k){ return manualNorm.indexOf(k + ':') >= 0; });
  checks.noExtractedTempMarker = view.indexOf('extracted_view') < 0;
  Object.keys(checks).forEach(function(k){ if(!checks[k]) out.fatal.push(k); });
  out.requiredBasicFields = required;
  out.headerSummary = { updatableCount: (opFields || []).length, missingUpdatable: required.filter(function(k){ return !up[k]; }) };
  out.message = out.fatal.length ? 'SAFE-01B R10J4 basic-info verification failed. Check fatal items.' : 'SAFE-01B R10J4 basic-info verification passed.';
  out.ok = out.fatal.length === 0;
  Logger.log('JSON_COMPACT_RESULT: ' + JSON.stringify(out));
  return out;
}
