/*******************************************************
 * MC_GOOGLE_CALENDAR_SYNC_APPROVAL_APPLY_V01_20260527
 * Purpose: Google Calendar real apply approval gate.
 * - Direct dryRun:N through mcGoogleCalendarBidirectionalSyncV01Apply is blocked by internal token.
 * - This wrapper is the only approved real apply path.
 * - User confirmation + SystemConfig ON + maxOps limit are required.
 * - V01 allows PORTAL_TO_GOOGLE creates first. GOOGLE_TO_PORTAL remains a later separated phase.
 *******************************************************/
function mcGoogleCalendarSyncApprovalApplyV01(request) {
  var BUILD = 'MC_GOOGLE_CALENDAR_SYNC_APPROVAL_APPLY_V01_20260527';
  var ACTION = 'mcGoogleCalendarSyncApprovalApplyV01';
  request = request || {};
  var actorKey = '';
  var batchId = 'GSYNC-APPROVAL-' + mcGoogleCalendarSyncApprovalApplyV01Now_() + '-' + Utilities.getUuid().substring(0, 8).toUpperCase();
  var result = {
    ok: false,
    build: BUILD,
    action: ACTION,
    batchId: batchId,
    realApplyExecuted: false,
    destructiveRepairExecuted: false,
    approved: false,
    message: '',
    policy: {
      requireConfirmApply: 'YES',
      requireSystemConfigOn: 'FEATURE_GOOGLE_CALENDAR_BIDIRECTIONAL_SYNC_ENABLED',
      allowedDirection: 'PORTAL_TO_GOOGLE',
      googleToPortalAllowed: false,
      conflictOverwriteAllowed: false,
      maxOpsCap: 10,
      defaultMaxOps: 5
    },
    dryRunPlan: null,
    applyResult: null,
    generatedAt: mcGoogleCalendarSyncApprovalApplyV01Now_()
  };

  try {
    var config = mcCalendar19GetConfigBundle_();
    var profile = mcCalendar186ResolveCalendarActor_(request, config, { allowFallback: true });
    actorKey = mcCalendar186ActorKey_(profile);
    var cfg = config.config || {};

    var maxOps = Number(request.maxOps || 5);
    if (!maxOps || maxOps < 1) maxOps = 5;
    if (maxOps > 10) maxOps = 10;

    var direction = String(request.direction || 'PORTAL_TO_GOOGLE').toUpperCase();
    if (direction !== 'PORTAL_TO_GOOGLE') {
      throw new Error('Google Calendar 승인 실반영 차단: V01은 PORTAL_TO_GOOGLE 신규 생성만 허용합니다. googleToPortal은 다음 단계에서 분리 적용하세요.');
    }

    var configOn = mcCalendarPolicyV01ConfigOn_(cfg, 'FEATURE_GOOGLE_CALENDAR_BIDIRECTIONAL_SYNC_ENABLED', false);
    result.policy.systemConfigOn = configOn;
    if (!configOn) {
      result.dryRunPlan = mcGoogleCalendarBidirectionalSyncV01Apply({
        dryRun: 'Y',
        direction: 'PORTAL_TO_GOOGLE',
        maxOps: maxOps,
        fromAt: request.fromAt || request.startAt,
        toAt: request.toAt || request.endAt,
        googleCalendarId: request.googleCalendarId
      });
      result.message = 'Google Calendar 실반영 차단: SystemConfig FEATURE_GOOGLE_CALENDAR_BIDIRECTIONAL_SYNC_ENABLED 값이 OFF입니다. DryRun 계획만 반환합니다.';
      mcGoogleCalendarSyncApprovalApplyV01Audit_(actorKey, batchId, 'BLOCKED_CONFIG_OFF', result.message, { maxOps: maxOps, dryRunSummary: result.dryRunPlan && result.dryRunPlan.summary });
      mcGoogleCalendarSyncApprovalApplyV01Log_(result);
      return mcCalendar19ClientSafeObject_(result);
    }

    result.dryRunPlan = mcGoogleCalendarBidirectionalSyncV01Apply({
      dryRun: 'Y',
      direction: 'PORTAL_TO_GOOGLE',
      maxOps: maxOps,
      fromAt: request.fromAt || request.startAt,
      toAt: request.toAt || request.endAt,
      googleCalendarId: request.googleCalendarId
    });

    var confirmApply = String(request.confirmApply || '').trim().toUpperCase();
    result.approved = confirmApply === 'YES';
    if (!result.approved) {
      result.message = 'Google Calendar 실반영 대기: request.confirmApply === "YES"가 아니므로 dryRun:N은 실행하지 않았습니다.';
      mcGoogleCalendarSyncApprovalApplyV01Audit_(actorKey, batchId, 'PENDING_CONFIRMATION', result.message, { maxOps: maxOps, dryRunSummary: result.dryRunPlan && result.dryRunPlan.summary });
      mcGoogleCalendarSyncApprovalApplyV01Log_(result);
      return mcCalendar19ClientSafeObject_(result);
    }

    if (!result.dryRunPlan || result.dryRunPlan.ok !== true) {
      throw new Error('Google Calendar 승인 실반영 차단: 사전 DryRun이 통과하지 못했습니다.');
    }

    var drySummary = result.dryRunPlan.summary || {};
    if (Number(drySummary.conflictsSkipped || 0) > 0) {
      throw new Error('Google Calendar 승인 실반영 차단: 충돌 후보가 있어 자동 덮어쓰기를 금지합니다.');
    }

    result.applyResult = mcGoogleCalendarBidirectionalSyncV01Apply({
      dryRun: 'N',
      direction: 'PORTAL_TO_GOOGLE',
      maxOps: maxOps,
      fromAt: request.fromAt || request.startAt,
      toAt: request.toAt || request.endAt,
      googleCalendarId: request.googleCalendarId,
      _approvalGate: 'MC_GOOGLE_CALENDAR_SYNC_APPROVAL_APPLY_V01'
    });
    result.realApplyExecuted = true;
    result.ok = !!(result.applyResult && result.applyResult.ok === true);
    result.message = result.ok ? 'Google Calendar 승인 실반영 완료: PORTAL 원장 일정 신규 생성만 제한 실행했습니다.' : 'Google Calendar 승인 실반영 일부 실패. applyResult 및 SyncLogs를 확인하세요.';
    mcGoogleCalendarSyncApprovalApplyV01Audit_(actorKey, batchId, result.ok ? 'SUCCESS' : 'PARTIAL', result.message, { maxOps: maxOps, applySummary: result.applyResult && result.applyResult.summary });
  } catch (err) {
    result.ok = false;
    result.message = mcGoogleCalendarSyncApprovalApplyV01Error_(err);
    try { mcGoogleCalendarSyncApprovalApplyV01Audit_(actorKey, batchId, 'FAIL', result.message, {}); } catch (ignoreAudit) {}
  }

  mcGoogleCalendarSyncApprovalApplyV01Log_(result);
  return mcCalendar19ClientSafeObject_(result);
}

function mcGoogleCalendarSyncApprovalApplyV01Preview(request) {
  request = request || {};
  request.confirmApply = '';
  return mcGoogleCalendarSyncApprovalApplyV01(request);
}

function mcGoogleCalendarSyncApprovalApplyV01SelfTest() {
  var checks = {
    approvalFunctionReady: typeof mcGoogleCalendarSyncApprovalApplyV01 === 'function',
    previewFunctionReady: typeof mcGoogleCalendarSyncApprovalApplyV01Preview === 'function',
    baseApplyReady: typeof mcGoogleCalendarBidirectionalSyncV01Apply === 'function',
    v06GateReady: typeof mcGoogleCalendarSyncSafeGateV06CompactAll === 'function',
    configOnHelperReady: typeof mcCalendarPolicyV01ConfigOn_ === 'function',
    auditReady: typeof mcCalendar19AppendAuditLog_ === 'function'
  };
  var ok = true;
  for (var k in checks) if (checks.hasOwnProperty(k) && !checks[k]) ok = false;
  return {
    ok: ok,
    build: 'MC_GOOGLE_CALENDAR_SYNC_APPROVAL_APPLY_V01_20260527',
    action: 'mcGoogleCalendarSyncApprovalApplyV01SelfTest',
    message: ok ? 'Google Calendar 승인형 APPLY 함수 인식 성공' : 'Google Calendar 승인형 APPLY 함수 의존성 확인 필요',
    checks: checks,
    generatedAt: mcGoogleCalendarSyncApprovalApplyV01Now_()
  };
}

function mcGoogleCalendarSyncApprovalApplyV01Audit_(actorKey, targetId, resultStatus, message, payload) {
  try {
    mcCalendar19AppendAuditLog_('GOOGLE_CALENDAR_SYNC_APPROVAL_APPLY', actorKey || '', targetId || '', resultStatus || '', message || '', payload || {});
  } catch (ignore) {}
}

function mcGoogleCalendarSyncApprovalApplyV01Log_(result) {
  try { Logger.log('JSON_COMPACT_RESULT: ' + mcGoogleCalendarSyncApprovalApplyV01Compact_(result, 20000)); } catch (ignore) {}
}

function mcGoogleCalendarSyncApprovalApplyV01Compact_(obj, maxLen) {
  var text = '';
  try {
    text = JSON.stringify(obj, function(key, value) {
      if (value instanceof Date) return mcGoogleCalendarSyncApprovalApplyV01Now_(value);
      if (typeof value === 'function') return '[Function]';
      return value;
    });
  } catch (err) {
    text = '[JSON_STRINGIFY_FAIL] ' + mcGoogleCalendarSyncApprovalApplyV01Error_(err);
  }
  if (maxLen && text.length > maxLen) return text.substring(0, maxLen) + '...TRUNCATED';
  return text;
}

function mcGoogleCalendarSyncApprovalApplyV01Error_(err) {
  if (!err) return '';
  if (typeof err === 'string') return err;
  if (err.name && err.message) return String(err.name) + ': ' + String(err.message);
  if (err.message) return String(err.message);
  try { return JSON.stringify(err); } catch (ignore) { return String(err); }
}

function mcGoogleCalendarSyncApprovalApplyV01Now_(dateObj) {
  var d = dateObj || new Date();
  try { return Utilities.formatDate(d, Session.getScriptTimeZone() || 'Asia/Seoul', 'yyyyMMddHHmmss'); }
  catch (err) { return String(d); }
}
