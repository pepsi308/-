/**
 * PORTAL_CALENDAR_STEP03_PROVIDER_PAYLOAD_VERIFY_V01_20260531
 *
 * File:
 * - PORTAL_CALENDAR_STEP03_PROVIDER_PAYLOAD_VERIFY_V01_20260531.js
 *
 * Function:
 * - portalCalendarStep03ProviderPayloadVerifyV01
 *
 * Scope:
 * - Provider card counts can only work if month payload includes NAVER/GOOGLE provider fields.
 * - This verify checks MC_CalendarShellV01 server payload + Step02 UI row-count logic.
 * - Read-only. No external API. No sheet mutation.
 */
function portalCalendarStep03ProviderPayloadVerifyV01() {
  var out = {
    ok: false,
    build: 'PORTAL_CALENDAR_STEP03_PROVIDER_PAYLOAD_VERIFY_V01_20260531',
    action: 'portalCalendarStep03ProviderPayloadVerifyV01',
    safety: 'READ_ONLY_NO_API_NO_SHEET_MUTATION',
    scope: 'MONTH_PAYLOAD_PROVIDER_FIELDS_FOR_NAVER_GOOGLE_CARDS',
    checks: {},
    sample: {},
    fatal: [],
    warnings: [],
    generatedAt: Utilities.formatDate(new Date(), 'Asia/Seoul', 'yyyy-MM-dd HH:mm:ss')
  };

  try {
    var ui = HtmlService.createHtmlOutputFromFile('MC_CalendarViewV01').getContent();
    var shellText = String(mcCalendarShellV01GetMonthData || '');

    function hasText(text, s){ return String(text || '').indexOf(s) >= 0; }

    out.checks.uiStep01StillFixed = hasText(ui, 'setTimeout(closeManualEventModal,60);') && hasText(ui, "reloadMonth({listMode:'all',message:state.pendingFocusMessage})");
    out.checks.uiStep02RowCount = hasText(ui, 'function fhCalendarProviderCountsStep02(events)') && hasText(ui, 'var pc=fhCalendarProviderCountsStep02(state.events);');
    out.checks.payloadNaverStatus = hasText(shellText, 'naverRegisterStatus');
    out.checks.payloadNaverProviderId = hasText(shellText, 'naverProviderEventId');
    out.checks.payloadGoogleStatus = hasText(shellText, 'googleBackupStatus');
    out.checks.payloadGoogleProviderId = hasText(shellText, 'googleProviderEventId');
    out.checks.payloadDashboardSummary = typeof mcCalendarShellV01ProviderSummary_ === 'function';

    var now = new Date();
    var payload = mcCalendarShellV01GetMonthData({ year: now.getFullYear(), month: now.getMonth() + 1 });
    out.sample.ok = payload && payload.ok === true;
    out.sample.total = payload && payload.total;
    out.sample.dashboard = payload && payload.dashboard ? payload.dashboard : null;

    var events = payload && payload.events ? payload.events : [];
    var withNaverFields = 0;
    var withGoogleFields = 0;
    for (var i = 0; i < events.length; i++) {
      var e = events[i] || {};
      if (e.hasOwnProperty('naverRegisterStatus') || e.hasOwnProperty('naverProviderEventId')) withNaverFields++;
      if (e.hasOwnProperty('googleBackupStatus') || e.hasOwnProperty('googleProviderEventId')) withGoogleFields++;
    }
    out.sample.eventsChecked = events.length;
    out.sample.withNaverFields = withNaverFields;
    out.sample.withGoogleFields = withGoogleFields;
    out.checks.monthPayloadRuns = payload && payload.ok === true;
    out.checks.monthRowsExposeNaverFields = events.length === 0 || withNaverFields === events.length;
    out.checks.monthRowsExposeGoogleFields = events.length === 0 || withGoogleFields === events.length;

    Object.keys(out.checks).forEach(function(k){
      if (!out.checks[k]) out.fatal.push(k);
    });

    out.ok = out.fatal.length === 0;
  } catch (err) {
    out.ok = false;
    out.fatal.push(err && err.stack ? String(err.stack) : String(err && err.message ? err.message : err));
  }

  Logger.log('JSON_COMPACT_RESULT: ' + JSON.stringify(out));
  return out;
}
