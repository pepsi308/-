/**
 * MAILCENTER_CALENDAR_CORE_CLONE_V01_20260521
 * Source cloned from verified PORTAL calendar file: Portal_Run187_CalendarPanelBridge.js
 * Rule:
 * - PORTAL original files are not modified.
 * - Server identifiers are namespaced from portal* to mcCalendar* to avoid collisions.
 * - This is stage 1: core clone / diagnostic separation only.
 */

/* Build: MAILCENTER_CALENDAR_CORE_CLONE_V01_20260521
 * File: MailCenter_Run187_CalendarPanelBridge.js
 * Purpose: Calendar stable field UI lock - Korean date display, stable empty states, detail/retry UI.
 * Scope: UI bridge only. Mail files not touched. JS only.
 */

function mcCalendar187BuildCalendarModulePanel_(user, sid) {
  var safeSid = mcCalendar187CalendarJsString_(String(sid || ''));
  var safeUser = user || {};
  var roleCode = String(safeUser.roleCode || '').toUpperCase();
  if (!mcCalendar187CanAccessCalendar_(safeUser)) {
    return '<section class="fh-panel fh189-calendar-shell"><div class="fh189-empty-card"><div class="fh189-empty-icon">!</div><h2>캘린더 접근 권한이 없습니다.</h2><p>일정 기능은 권한이 있는 본사/운영/직원 계정만 사용할 수 있습니다.</p><p class="fh189-small">필요 권한: SUPER_ADMIN, HQ_ADMIN, DEV, STAFF, OPERATION, HQ_MANAGER</p></div></section>';
  }
  var employeeId = mcCalendar187CalendarEscape_(safeUser.employeeId || '');
  var loginId = mcCalendar187CalendarEscape_(safeUser.loginId || '');
  var employeeName = mcCalendar187CalendarEscape_(safeUser.employeeName || '');
  var roleLabel = mcCalendar187CalendarEscape_(roleCode || '');
  var vendorId = mcCalendar187CalendarEscape_(safeUser.vendorId || '본사');

  var panel = '' +
    '<section class="fh-panel fh189-calendar-shell" id="mcCalendar118CalendarPanel">' +
      '<div class="fh189-topline">' +
        '<div><p class="fh189-eyebrow">MAILCENTER Calendar Module · Edit Lock</p><h2>일정 등록/현황</h2><p>일정 등록, 상세 보기, 일정 수정, 재전송 목록, 기간/검색 조회를 한 화면에서 처리합니다.</p></div>' +
        '<div class="fh189-user-card"><span class="fh189-user-label">로그인 직원</span><b>' + (employeeName || loginId || '사용자') + '</b><span>loginId: ' + loginId + '</span><span>employeeId: ' + employeeId + '</span><span>roleCode: ' + roleLabel + '</span><span>vendorId: ' + vendorId + '</span></div>' +
      '</div>' +
      '<div class="fh189-stat-grid" aria-label="캘린더 요약">' +
        '<button type="button" class="fh189-stat-card" onclick="mcCalendar187CalDashboard()"><span>전체 일정</span><strong id="p187StatTotal">0</strong><small>내부 원장 기준</small></button>' +
        '<button type="button" class="fh189-stat-card" onclick="mcCalendar187CalDashboard()"><span>오늘 일정</span><strong id="p187StatToday">0</strong><small>오늘 시작 일정</small></button>' +
        '<button type="button" class="fh189-stat-card" onclick="mcCalendar187CalDashboard()"><span>NAVER</span><strong><em id="p187StatNaverOk">0</em>/<em id="p187StatNaverFail">0</em></strong><small>성공 / 실패</small></button>' +
        '<button type="button" class="fh189-stat-card" onclick="mcCalendar189CalRetryList()"><span>재전송 대기</span><strong id="p187StatRetry">0</strong><small>목록 보기</small></button>' +
      '</div>' +
'<article class="fh189-card fh192-range-card"><div class="fh189-card-head"><div><p class="fh189-chip">기간/검색</p><h3>일정 검색 / 기간 보기</h3></div><button type="button" class="fh189-light-btn" onclick="mcCalendar192SetThisMonth()">이번 달</button></div>' +
        '<div class="fh192-filter-row"><div class="fh189-field"><label for="p192RangeStart">시작일</label><input id="p192RangeStart" type="date"></div><div class="fh189-field"><label for="p192RangeEnd">종료일</label><input id="p192RangeEnd" type="date"></div><div class="fh189-field"><label for="p192Keyword">검색어</label><input id="p192Keyword" placeholder="제목, 장소, ID"></div><div class="fh189-field"><label for="p192Status">상태</label><select id="p192Status"><option value="">전체</option><option value="REGISTERED">REGISTERED</option><option value="PARTIAL">PARTIAL</option><option value="FAIL">FAIL</option></select></div></div>' +
        '<div class="fh189-actions"><button type="button" class="fh189-primary-btn" onclick="mcCalendar192CalRangeList()">검색/조회</button><button type="button" class="fh189-light-btn" onclick="mcCalendar192ClearRangeFilter()">필터 초기화</button></div>' +
        '<div class="fh189-table-wrap fh192-table-wrap"><table class="fh189-table"><thead><tr><th>일정 ID</th><th>제목</th><th>시작</th><th>담당</th><th>NAVER</th><th>GOOGLE</th><th>상태</th><th>상세</th></tr></thead><tbody id="p192RangeRows"><tr><td colspan="8" class="fh189-empty-cell">기간 조회 전입니다.</td></tr></tbody></table></div></article>' +
      '<div class="fh189-work-grid">' +
        '<article class="fh189-card fh189-form-card">' +
          '<div class="fh189-card-head"><div><p class="fh189-chip">신규 등록</p><h3>새 일정 등록</h3></div><button type="button" class="fh189-light-btn" onclick="mcCalendar187CalQuick()">30분 뒤 기본값</button></div>' +
          '<div class="fh189-field"><label for="p187CalTitle">일정 제목</label><input id="p187CalTitle" value="FEELHAUS 업무 일정" autocomplete="off"></div>' +
          '<div class="fh189-two"><div class="fh189-field"><label for="p187CalType">일정 유형</label><select id="p187CalType"><option value="INTERNAL">내부 일정</option><option value="CUSTOMER_MEETING">고객 미팅</option><option value="INSTALL">설치</option><option value="AS">A/S</option><option value="CONTRACT">계약</option><option value="MEETING">회의</option></select></div><div class="fh189-field"><label for="p187AssignedEmployeeId">담당자 선택</label><select id="p187AssignedEmployeeId"><option value="">로그인 직원</option></select></div></div>' +
          '<div class="fh189-two"><div class="fh189-field"><label for="p187CalStart">시작</label><input id="p187CalStart" type="datetime-local"></div><div class="fh189-field"><label for="p187CalEnd">종료</label><input id="p187CalEnd" type="datetime-local"></div></div>' +
          '<div class="fh189-field"><label for="p187CalLocation">장소</label><input id="p187CalLocation" placeholder="예: 동탄 회의실"></div>' +
          '<details class="fh189-linked-ids"><summary>연결 ID 입력</summary>' +
            '<div class="fh189-two"><div class="fh189-field"><label for="p187EventId">eventId</label><input id="p187EventId" placeholder="EVT-..."></div><div class="fh189-field"><label for="p187CustomerId">customerId</label><input id="p187CustomerId" placeholder="CUST-..."></div></div>' +
            '<div class="fh189-two"><div class="fh189-field"><label for="p187ContractId">contractId</label><input id="p187ContractId" placeholder="CON-..."></div><div class="fh189-field"><label for="p187InstallId">installId</label><input id="p187InstallId" placeholder="INST-..."></div></div>' +
            '<div class="fh189-two"><div class="fh189-field"><label for="p187AsId">asId</label><input id="p187AsId" placeholder="AS-..."></div><div class="fh189-field"><label for="p187RequestId">requestId</label><input id="p187RequestId" placeholder="REQ-..."></div></div>' +
          '</details>' +
          '<div class="fh189-field"><label for="p187CalDescription">내용</label><textarea id="p187CalDescription" rows="4" placeholder="일정 내용"></textarea></div>' +
          '<div class="fh189-actions"><button type="button" class="fh189-primary-btn" onclick="mcCalendar187CalCreate()">내부 저장 + NAVER + GOOGLE 백업</button><button type="button" class="fh189-light-btn" onclick="mcCalendar187CalDashboard()">요약 새로고침</button></div>' +
        '</article>' +
        '<article class="fh189-card fh189-result-card">' +
          '<div class="fh189-card-head"><div><p class="fh189-chip">처리 결과</p><h3>저장/등록 상태</h3></div><span id="p187ResultBadge" class="fh189-state-badge fh189-wait">대기</span></div>' +
          '<div id="p187ResultSummary" class="fh189-result-summary">아직 실행 전입니다. 일정을 저장하면 내부 저장, NAVER 등록, GOOGLE 백업 결과가 표시됩니다.</div>' +
          '<div class="fh189-provider-grid"><div class="fh189-provider"><span>INTERNAL</span><b id="p187InternalStatus">대기</b><small>MAILCENTER_CalendarEvents</small></div><div class="fh189-provider"><span>NAVER</span><b id="p187NaverStatus">대기</b><small>기본 캘린더 등록</small></div><div class="fh189-provider"><span>GOOGLE</span><b id="p187GoogleStatus">대기</b><small>보조 백업</small></div></div>' +
          '<div class="fh189-process"><span>권한 검사</span><span>필수값 검사</span><span>중복 검사</span><span>내부 저장</span><span>로그 기록</span><span>NAVER</span><span>GOOGLE</span><span>AuditLog</span></div>' +
          '<details class="fh189-devbox"><summary>개발자 로그 보기</summary><pre id="p187CalResult">아직 실행 전입니다.</pre></details>' +
        '</article>' +
      '</div>' +
      '<div class="fh189-advanced-grid">' +
        '<article class="fh189-card"><div class="fh189-card-head"><div><p class="fh189-chip">상세 보기</p><h3>선택 일정 상세</h3></div><button type="button" class="fh189-light-btn" onclick="mcCalendar189ClearDetail()">비우기</button></div><div id="p189DetailBox" class="fh189-detail-box">최근 일정에서 <b>상세</b> 버튼을 누르면 일정 정보, provider 로그, 재전송 이력이 표시됩니다.</div></article>' +
        '<article class="fh189-card"><div class="fh189-card-head"><div><p class="fh189-chip">재전송</p><h3>실패 provider 대기열</h3></div><button type="button" class="fh189-light-btn" onclick="mcCalendar189CalRetryList()">목록 조회</button></div><div id="p189RetryBox" class="fh189-retry-box">재전송 대기 건이 있으면 provider, 오류, 다음 재시도 시각이 표시됩니다.</div><div class="fh189-actions"><button type="button" class="fh189-primary-btn" onclick="mcCalendar187CalRetry()">선택 없이 전체 재전송 시도</button></div></article>' +
      '</div>' +
      '<article class="fh189-card fh189-list-card"><div class="fh189-card-head"><div><p class="fh189-chip">최근 일정</p><h3>최근 내 일정 / 담당 일정</h3></div><button type="button" class="fh189-light-btn" onclick="mcCalendar187CalDashboard()">새로고침</button></div><div class="fh189-table-wrap"><table class="fh189-table"><thead><tr><th>일정 ID</th><th>제목</th><th>시작</th><th>담당</th><th>NAVER</th><th>GOOGLE</th><th>등록자</th><th>상세</th></tr></thead><tbody id="p187RecentRows"><tr><td colspan="8" class="fh189-empty-cell">요약 조회 전입니다.</td></tr></tbody></table></div></article>' +
      '<div class="fh189-footer">© 2026 FEELHAUS. All rights reserved. · (주)필하우스 · 총괄/최고운영자: 이용필 · 메인 개발/기획: 이용필 · 개발 참여: 최유라</div>' +
    '</section>';
  return mcCalendar187CalendarPanelStyle_() + panel + mcCalendar187CalendarPanelScript_(safeSid);
}

function mcCalendar187CanAccessCalendar_(user) {
  var role = String(user && user.roleCode || '').toUpperCase();
  return role === 'SUPER_ADMIN' || role === 'HQ_ADMIN' || role === 'DEV' || role === 'STAFF' || role === 'OPERATION' || role === 'HQ_MANAGER';
}

function mcCalendar187CalendarPanelStyle_() {
  return '<style>' +
    '.fh189-calendar-shell{--fh-gold:#b08a12;--fh-gold2:#d7b650;--fh-ink:#1f1a10;--fh-soft:#fbf7ed;--fh-line:#eadfca;--fh-muted:#786b55;background:#fbf7ed!important;padding:18px!important;border-radius:22px!important}' +
    '.fh189-topline{display:flex;justify-content:space-between;gap:18px;align-items:stretch;background:linear-gradient(135deg,#1d170d 0%,#3b2c08 52%,#80620c 100%);color:#fff;border-radius:22px;padding:24px 26px;margin-bottom:16px;box-shadow:0 20px 46px rgba(42,31,6,.22)}' +
    '.fh189-eyebrow{margin:0 0 8px;color:#f6d46e;font-weight:900;letter-spacing:.12em;font-size:12px}.fh189-topline h2{margin:0 0 9px;font-size:30px;line-height:1.1;color:#fff}.fh189-topline p{margin:0;color:#fff4cf;line-height:1.6}.fh189-user-card{min-width:238px;background:rgba(255,255,255,.12);border:1px solid rgba(246,212,110,.55);border-radius:16px;padding:14px 16px;display:grid;gap:4px;align-content:center}.fh189-user-label{color:#f6d46e;font-size:12px;font-weight:900}.fh189-user-card b{font-size:17px;color:#fff}.fh189-user-card span{font-size:12px;color:#fff7df}' +
    '.fh189-stat-grid{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:12px;margin:14px 0}.fh189-stat-card{background:#fff;border:1px solid var(--fh-line);border-radius:17px;padding:15px 16px;text-align:left;color:var(--fh-ink);cursor:pointer;box-shadow:0 10px 24px rgba(38,29,8,.06)}.fh189-stat-card span{display:block;color:#6f624d;font-weight:800;font-size:12px}.fh189-stat-card strong{display:block;margin-top:6px;font-size:28px}.fh189-stat-card small{color:#8b7b63}.fh189-stat-card em{font-style:normal}' +
    '.fh189-work-grid{display:grid;grid-template-columns:minmax(440px,1.2fr) minmax(360px,.95fr);gap:14px}.fh189-advanced-grid{display:grid;grid-template-columns:1fr 1fr;gap:14px;margin-top:14px}.fh189-card{background:#fff;border:1px solid var(--fh-line);border-radius:18px;padding:16px;box-shadow:0 12px 26px rgba(42,31,6,.07)}.fh189-card-head{display:flex;align-items:flex-start;justify-content:space-between;gap:10px;margin-bottom:12px}.fh189-card h3{margin:4px 0 0;font-size:20px}.fh189-chip{display:inline-block;margin:0;background:#fff7db;border:1px solid #d8bb5a;border-radius:999px;padding:4px 10px;color:#735806;font-weight:900;font-size:12px}' +
    '.fh189-field{display:grid;gap:6px;margin-bottom:12px}.fh189-field label{font-weight:900;color:#2a2112}.fh189-field input,.fh189-field select,.fh189-field textarea{width:100%;border:1px solid #d2b75a;border-radius:10px;padding:10px 12px;background:#fff;color:#211a10;box-sizing:border-box}.fh189-field input:focus,.fh189-field select:focus,.fh189-field textarea:focus{outline:2px solid rgba(176,138,18,.25);border-color:#9a7300}.fh189-two{display:grid;grid-template-columns:1fr 1fr;gap:12px}.fh189-linked-ids{border:1px dashed #d8bb5a;border-radius:12px;padding:10px 12px;background:#fffdf6;margin:2px 0 12px}.fh189-linked-ids summary{font-weight:900;color:#5b4608;cursor:pointer}' +
    '.fh189-actions{display:flex;gap:8px;flex-wrap:wrap}.fh189-primary-btn,.fh189-light-btn{border-radius:10px;padding:10px 14px;font-weight:900;cursor:pointer}.fh189-primary-btn{border:1px solid #8d6b07;background:#9d790b;color:#fff}.fh189-light-btn{border:1px solid #d8bb5a;background:#fff8df;color:#5d4708}.fh189-state-badge,.fh189-badge{display:inline-block;border-radius:999px;padding:5px 10px;font-weight:900;font-size:12px}.fh189-ok{background:#dcfce7;color:#166534}.fh189-fail{background:#fee2e2;color:#991b1b}.fh189-wait{background:#fef3c7;color:#92400e}' +
    '.fh189-result-summary{background:#1d170d;color:#fff7df;border-radius:13px;padding:14px 16px;line-height:1.65;font-weight:800;margin-bottom:12px}.fh189-provider-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:10px}.fh189-provider{border:1px solid #eadfca;border-radius:13px;padding:12px;background:#fffdf8}.fh189-provider span{display:block;font-weight:900;color:#5e4a11;font-size:12px}.fh189-provider b{display:block;margin-top:4px}.fh189-provider small{color:#8a7a61}.fh189-process{display:flex;gap:7px;flex-wrap:wrap;margin:12px 0}.fh189-process span{background:#fff2c6;border:1px solid #d8bb5a;border-radius:999px;padding:5px 9px;font-weight:900;font-size:12px}.fh189-devbox{margin-top:8px}.fh189-devbox summary{font-weight:900;cursor:pointer}.fh189-devbox pre{white-space:pre-wrap;background:#111;color:#fff;border-radius:10px;padding:12px;max-height:260px;overflow:auto}' +
    '.fh189-table-wrap{overflow:auto}.fh189-table{width:100%;border-collapse:separate;border-spacing:0}.fh189-table th{background:#fff2c6;color:#2a2112;font-weight:900;text-align:left;padding:10px;border-bottom:1px solid #eadfca}.fh189-table td{padding:10px;border-bottom:1px solid #f0e6d2;color:#211a10}.fh189-row-btn{border:1px solid #d8bb5a;background:#fff8df;border-radius:9px;padding:6px 9px;font-weight:900;cursor:pointer}.fh189-empty-cell{text-align:center!important;color:#8b7b63!important;padding:22px!important}.fh189-detail-box,.fh189-retry-box{min-height:96px;border:1px solid #eadfca;background:#fffdf8;border-radius:13px;padding:12px;line-height:1.65}.fh189-detail-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:8px}.fh189-detail-item{background:#fff;border:1px solid #f0e6d2;border-radius:10px;padding:9px}.fh189-detail-item span{display:block;color:#7b6b53;font-size:12px;font-weight:900}.fh189-detail-item b{display:block;margin-top:3px}.fh189-mini-log{margin-top:10px;border-top:1px solid #eadfca;padding-top:10px}.fh189-mini-log div{font-size:12px;padding:5px 0;border-bottom:1px dashed #eadfca}.fh189-footer{margin-top:14px;background:#18130b;color:#fff7df;border-radius:16px;padding:13px 16px;font-size:12px;text-align:center}.fh189-empty-card{background:#fff;border:1px solid #eadfca;border-radius:18px;padding:28px;text-align:center}.fh189-empty-icon{width:42px;height:42px;line-height:42px;margin:0 auto 10px;border-radius:50%;background:#fef3c7;color:#92400e;font-weight:900}.fh189-small{color:#7a6b55;font-size:12px}' +
    '@media(max-width:1100px){.fh189-work-grid,.fh189-advanced-grid{grid-template-columns:1fr}.fh189-stat-grid{grid-template-columns:repeat(2,1fr)}}@media(max-width:760px){.fh189-topline{display:block}.fh189-user-card{margin-top:14px;min-width:0}.fh189-stat-grid,.fh189-two,.fh189-provider-grid{grid-template-columns:1fr}.fh189-calendar-shell{padding:10px!important}}' +
  '</style>';
}

function mcCalendar187CalendarPanelScript_(safeSid) {
  var sidJson = JSON.stringify(String(safeSid || ''));
  return '<script>' +
    'window.MAILCENTER187_CALENDAR_SID=' + sidJson + ';' +
    'function p187$(id){return document.getElementById(id);}function p187Val(id){var x=p187$(id);return x?String(x.value||"").trim():"";}function p187Esc(v){return String(v==null?"":v).replace(/[&<>]/g,function(c){return {"&":"&amp;","<":"&lt;",">":"&gt;"}[c];});}function p187Json(obj){var b=p187$("p187CalResult");if(b)b.textContent=(typeof obj==="string")?obj:JSON.stringify(obj,null,2);}function p187SetText(id,v){var x=p187$(id);if(x)x.textContent=v;}function p187SetBadge(kind,text){var x=p187$("p187ResultBadge");if(!x)return;x.className="fh189-state-badge "+(kind==="ok"?"fh189-ok":(kind==="fail"?"fh189-fail":"fh189-wait"));x.textContent=text||"대기";}function p187Summary(html){var x=p187$("p187ResultSummary");if(x)x.innerHTML=html;}' +
    'function p187StatusLabel(v){v=String(v||"PENDING").toUpperCase();if(v==="SUCCESS")return "성공";if(v==="FAIL")return "실패";if(v==="REGISTERED")return "등록";return "대기";}function p187Badge(v){v=String(v||"PENDING").toUpperCase();var c=v==="SUCCESS"?"fh189-ok":(v==="FAIL"?"fh189-fail":"fh189-wait");return "<span class=\\"fh189-badge "+c+"\\">"+p187Esc(p187StatusLabel(v))+"</span>";}function p191Pad(n){return String(n).padStart(2,"0");}function p191FmtDateTime(v){if(!v)return "-";var d=(v instanceof Date)?v:new Date(v);if(isNaN(d.getTime()))return String(v).replace("T"," ").replace(".000Z","");var h=d.getHours();var ap=h<12?"오전":"오후";var hh=h%12;if(hh===0)hh=12;return d.getFullYear()+"-"+p191Pad(d.getMonth()+1)+"-"+p191Pad(d.getDate())+" "+ap+" "+p191Pad(hh)+":"+p191Pad(d.getMinutes());}function p191FmtRange(s,e){return p191FmtDateTime(s)+" ~ "+p191FmtDateTime(e);}function p191ShortId(v){v=String(v||"");return v.length>22?v.substring(0,18)+"…":v;}' +
    'function mcCalendar189LoadAssignees(){google.script.run.withSuccessHandler(function(res){var s=p187$("p187AssignedEmployeeId");if(!s)return;if(!res||!res.ok){return;}var html="<option value=\\"\\">로그인 직원</option>";(res.assignees||[]).forEach(function(u){var label=(u.employeeName||u.loginId||u.employeeId)+" · "+u.employeeId+" · "+u.roleCode;html+="<option value=\\""+p187Esc(u.employeeId)+"\\">"+p187Esc(label)+"</option>";});s.innerHTML=html;}).withFailureHandler(function(e){p187Json({ok:false,action:"mcCalendar189ListCalendarAssignees",message:e&&e.message?e.message:String(e)});}).mcCalendar189ListCalendarAssignees({sid:window.MAILCENTER187_CALENDAR_SID});}' +
    'function mcCalendar187CalQuick(){var s=p187$("p187CalStart"),e=p187$("p187CalEnd");if(!s||!e)return;var a=new Date(Date.now()+30*60000),b=new Date(Date.now()+60*60000);function f(x){return x.getFullYear()+"-"+String(x.getMonth()+1).padStart(2,"0")+"-"+String(x.getDate()).padStart(2,"0")+"T"+String(x.getHours()).padStart(2,"0")+":"+String(x.getMinutes()).padStart(2,"0");}s.value=f(a);e.value=f(b);p187SetBadge("wait","대기");p187Summary("일정 기본값을 30분 뒤로 채웠습니다. 내용을 확인한 뒤 저장하세요.");}' +
    'function mcCalendar187RenderDashboard(res){p187Json(res||{});if(!res||!res.ok){p187SetBadge("fail","조회 실패");p187Summary("캘린더 요약 조회에 실패했습니다.<br>"+p187Esc(res&&res.message?res.message:"오류 내용을 확인하세요."));return;}var s=res.summary||{};p187SetText("p187StatTotal",s.total||0);p187SetText("p187StatToday",s.today||0);p187SetText("p187StatNaverOk",s.naverSuccess||0);p187SetText("p187StatNaverFail",s.naverFail||0);p187SetText("p187StatRetry",s.retryPending||0);var rows=res.recentEvents||[],html="";if(!rows.length){html="<tr><td colspan=\\"8\\" class=\\"fh189-empty-cell\\">최근 일정이 없습니다. 새 일정을 등록해 주세요.</td></tr>";}else{rows.forEach(function(r){html+="<tr><td title=\\""+p187Esc(r.calendarEventId)+"\\">"+p187Esc(p191ShortId(r.calendarEventId))+"</td><td>"+p187Esc(r.eventTitle)+"</td><td>"+p187Esc(p191FmtDateTime(r.startAt))+"</td><td>"+p187Esc(r.assignedEmployeeId)+"</td><td>"+p187Badge(r.naverRegisterStatus)+"</td><td>"+p187Badge(r.googleBackupStatus)+"</td><td>"+p187Esc(r.createdBy||r.createdByEmployeeId)+"</td><td><button type=\\"button\\" class=\\"fh189-row-btn\\" onclick=\\"mcCalendar189CalDetail(\'"+p187Esc(r.calendarEventId)+"\')\\">상세</button></td></tr>";});}var body=p187$("p187RecentRows");if(body)body.innerHTML=html;p187SetBadge("ok","요약 완료");p187Summary("캘린더 요약 조회가 완료되었습니다.<br>전체 일정 <b>"+(s.total||0)+"건</b>, 오늘 일정 <b>"+(s.today||0)+"건</b>, 재전송 대기 <b>"+(s.retryPending||0)+"건</b>입니다.");}' +
    'function mcCalendar187CalDashboard(){p187SetBadge("wait","조회 중");p187Summary("캘린더 요약을 조회 중입니다.");google.script.run.withSuccessHandler(mcCalendar187RenderDashboard).withFailureHandler(function(e){p187SetBadge("fail","조회 실패");p187Summary("캘린더 요약 조회에 실패했습니다.<br>"+p187Esc(e&&e.message?e.message:String(e)));p187Json({ok:false,message:e&&e.message?e.message:String(e)});}).mcCalendar186GetCalendarDashboard({sid:window.MAILCENTER187_CALENDAR_SID});}' +
    'function p187RenderCreateResult(res){p187Json(res||{});if(!res||!res.ok){p187SetBadge("fail","저장 실패");p187Summary("일정 저장에 실패했습니다.<br>"+p187Esc(res&&res.message?res.message:"오류 내용을 확인하세요."));return;}var n="대기",g="대기";(res.providerResults||[]).forEach(function(x){if(x.provider==="NAVER")n=p187StatusLabel(x.resultStatus);if(x.provider==="GOOGLE_BACKUP")g=p187StatusLabel(x.resultStatus);});p187SetText("p187InternalStatus","성공");p187SetText("p187NaverStatus",n);p187SetText("p187GoogleStatus",g);p187SetBadge("ok","저장 완료");p187Summary("일정이 저장되었습니다.<br><b>"+p187Esc(res.calendarEventId||"")+"</b><br>등록자: "+p187Esc(res.createdBy||"")+" / 담당자: "+p187Esc(res.assignedEmployeeId||"")+"<br>NAVER: <b>"+p187Esc(n)+"</b> · GOOGLE: <b>"+p187Esc(g)+"</b>");mcCalendar187CalDashboard();}' +
    'function mcCalendar187CalCreate(){var payload={sid:window.MAILCENTER187_CALENDAR_SID,eventTitle:p187Val("p187CalTitle"),title:p187Val("p187CalTitle"),eventType:p187Val("p187CalType"),targetType:p187Val("p187CalType"),startAt:p187Val("p187CalStart"),endAt:p187Val("p187CalEnd"),location:p187Val("p187CalLocation"),assignedEmployeeId:p187Val("p187AssignedEmployeeId"),eventDescription:p187Val("p187CalDescription"),description:p187Val("p187CalDescription"),eventId:p187Val("p187EventId"),customerId:p187Val("p187CustomerId"),contractId:p187Val("p187ContractId"),installId:p187Val("p187InstallId"),asId:p187Val("p187AsId"),requestId:p187Val("p187RequestId")};p187SetBadge("wait","저장 중");p187Summary("내부 저장 후 NAVER 등록, GOOGLE 백업을 순서대로 처리 중입니다.");p187SetText("p187InternalStatus","처리 중");p187SetText("p187NaverStatus","대기");p187SetText("p187GoogleStatus","대기");google.script.run.withSuccessHandler(p187RenderCreateResult).withFailureHandler(function(e){p187SetBadge("fail","저장 실패");p187Summary("일정 저장 중 오류가 발생했습니다.<br>"+p187Esc(e&&e.message?e.message:String(e)));p187Json({ok:false,message:e&&e.message?e.message:String(e)});}).mcCalendar19CreateCalendarEvent(payload);}' +
    'function mcCalendar189ClearDetail(){var b=p187$("p189DetailBox");if(b)b.innerHTML="최근 일정에서 <b>상세</b> 버튼을 누르면 일정 정보, provider 로그, 재전송 이력이 표시됩니다.";}function mcCalendar193ToInputDateTime(v){if(!v)return "";var d=new Date(v);if(isNaN(d.getTime())){var s=String(v).replace(" ","T");return s.length>=16?s.substring(0,16):"";}return d.getFullYear()+"-"+String(d.getMonth()+1).padStart(2,"0")+"-"+String(d.getDate()).padStart(2,"0")+"T"+String(d.getHours()).padStart(2,"0")+":"+String(d.getMinutes()).padStart(2,"0");}function mcCalendar193BuildEditFormHtml(e){return "<div class=\'fh193-edit-form\'><b>일정 수정</b><div class=\'fh193-edit-grid\'><div><label>제목</label><input id=\'p193EditTitle\' value=\'"+p187Esc(e.eventTitle||"")+"\'></div><div><label>담당</label><input id=\'p193EditAssignee\' value=\'"+p187Esc(e.assignedEmployeeId||"")+"\'></div><div><label>시작</label><input id=\'p193EditStart\' type=\'datetime-local\' value=\'"+p187Esc(mcCalendar193ToInputDateTime(e.startAt))+"\'></div><div><label>종료</label><input id=\'p193EditEnd\' type=\'datetime-local\' value=\'"+p187Esc(mcCalendar193ToInputDateTime(e.endAt))+"\'></div><div><label>장소</label><input id=\'p193EditLocation\' value=\'"+p187Esc(e.location||"")+"\'></div><div><label>일정 유형</label><input id=\'p193EditType\' value=\'"+p187Esc(e.eventType||"INTERNAL")+"\'></div><textarea id=\'p193EditDesc\' placeholder=\'내용\'>"+p187Esc(e.eventDescription||"")+"</textarea></div><div class=\'fh189-actions\'><button type=\'button\' class=\'fh189-primary-btn\' id=\'p193EditSaveBtn\'>수정 저장</button><span class=\'fh189-mini\'>수정 시 내부 원장과 로그에 UPDATE_EVENT가 기록됩니다.</span></div></div>";}function mcCalendar193UpdateEvent(id){var payload={sid:window.MAILCENTER187_CALENDAR_SID,calendarEventId:id,eventTitle:p187Val("p193EditTitle"),eventType:p187Val("p193EditType"),assignedEmployeeId:p187Val("p193EditAssignee"),startAt:p187Val("p193EditStart"),endAt:p187Val("p193EditEnd"),location:p187Val("p193EditLocation"),eventDescription:p187Val("p193EditDesc")};p187SetBadge("wait","수정 중");p187Summary("일정 수정 내용을 저장 중입니다.");google.script.run.withSuccessHandler(function(res){p187Json(res||{});if(!res||!res.ok){p187SetBadge("fail","수정 실패");p187Summary("일정 수정 실패<br>"+p187Esc(res&&res.message?res.message:"오류"));return;}p187SetBadge("ok","수정 완료");p187Summary("일정 수정이 완료되었습니다.<br><b>"+p187Esc(res.calendarEventId||id)+"</b>");mcCalendar187CalDashboard();mcCalendar192CalRangeList();mcCalendar189CalDetail(id);}).withFailureHandler(function(e){p187SetBadge("fail","수정 오류");p187Summary("일정 수정 중 오류가 발생했습니다.<br>"+p187Esc(e&&e.message?e.message:String(e)));}).mcCalendar193UpdateCalendarEvent(payload);}' +
    'function mcCalendar189CalDetail(id){var box=p187$("p189DetailBox");if(box)box.innerHTML="상세 정보를 조회 중입니다.";google.script.run.withSuccessHandler(function(res){p187Json(res||{});if(!res||!res.ok){if(box)box.innerHTML="<b>상세 조회 실패</b><br>"+p187Esc(res&&res.message?res.message:"오류");return;}var e=res.event||{};var html="<div class=\\"fh189-detail-grid\\"><div class=\\"fh189-detail-item\\"><span>일정 ID</span><b>"+p187Esc(e.calendarEventId)+"</b></div><div class=\\"fh189-detail-item\\"><span>상태</span><b>"+p187Esc(e.eventStatus)+"</b></div><div class=\\"fh189-detail-item\\"><span>제목</span><b>"+p187Esc(e.eventTitle)+"</b></div><div class=\\"fh189-detail-item\\"><span>시작/종료</span><b>"+p187Esc(p191FmtRange(e.startAt,e.endAt))+"</b></div><div class=\\"fh189-detail-item\\"><span>담당</span><b>"+p187Esc(e.assignedEmployeeId)+"</b></div><div class=\\"fh189-detail-item\\"><span>등록자</span><b>"+p187Esc(e.createdBy)+"</b></div></div>";html+=mcCalendar193BuildEditFormHtml(e);html+="<div class=\\"fh189-mini-log\\"><b>처리 로그</b>";(res.logs||[]).slice(0,8).forEach(function(l){html+="<div>"+p187Esc(p191FmtDateTime(l.createdAt))+" · "+p187Esc(l.provider)+" · "+p187Esc(l.actionType)+" · "+p187Esc(l.resultStatus)+" · "+p187Esc(l.responseSummary||l.errorMessage||"")+"</div>";});if(!(res.logs||[]).length)html+="<div>처리 로그가 없습니다.</div>";html+="</div>";if(box){box.innerHTML=html;window.MAILCENTER193_SELECTED_ID=e.calendarEventId||id;var eb=p187$("p193EditSaveBtn");if(eb)eb.onclick=function(){mcCalendar193UpdateEvent(window.MAILCENTER193_SELECTED_ID);};}}).withFailureHandler(function(e){if(box)box.innerHTML="<b>상세 조회 오류</b><br>"+p187Esc(e&&e.message?e.message:String(e));}).mcCalendar189GetCalendarEventDetail({sid:window.MAILCENTER187_CALENDAR_SID,calendarEventId:id});}' +
    'function mcCalendar189CalRetryList(){var box=p187$("p189RetryBox");if(box)box.innerHTML="재전송 대기열을 조회 중입니다.";google.script.run.withSuccessHandler(function(res){p187Json(res||{});if(!res||!res.ok){if(box)box.innerHTML="<b>재전송 목록 조회 실패</b><br>"+p187Esc(res&&res.message?res.message:"오류");return;}var rows=res.retryRows||[];if(!rows.length){if(box)box.innerHTML="재전송 대기 건이 없습니다.";return;}var html="";rows.forEach(function(r){html+="<div class=\\"fh189-detail-item\\"><span>"+p187Esc(r.provider)+" · "+p187Esc(r.retryStatus)+"</span><b>"+p187Esc(r.eventTitle||r.calendarEventId)+"</b><small>오류: "+p187Esc(r.lastErrorCode)+" / "+p187Esc(r.lastErrorMessage)+"<br>다음 재시도: "+p187Esc(p191FmtDateTime(r.nextRetryAt))+"</small></div>";});if(box)box.innerHTML=html;}).withFailureHandler(function(e){if(box)box.innerHTML="<b>재전송 목록 오류</b><br>"+p187Esc(e&&e.message?e.message:String(e));}).mcCalendar189ListCalendarRetryQueue({sid:window.MAILCENTER187_CALENDAR_SID});}' +
    'function mcCalendar187CalRetry(){p187SetBadge("wait","재전송 중");p187Summary("실패 provider 재전송을 확인 중입니다.");google.script.run.withSuccessHandler(function(res){p187Json(res||{});p187SetBadge(res&&res.ok?"ok":"fail",res&&res.ok?"재전송 완료":"재전송 실패");p187Summary(res&&res.ok?"재전송 처리가 완료되었습니다. 요약을 다시 조회합니다.":"재전송 처리 중 오류가 발생했습니다.");mcCalendar187CalDashboard();mcCalendar189CalRetryList();}).withFailureHandler(function(e){p187SetBadge("fail","재전송 실패");p187Summary("재전송 처리 중 오류가 발생했습니다.<br>"+p187Esc(e&&e.message?e.message:String(e)));p187Json({ok:false,message:e&&e.message?e.message:String(e)});}).mcCalendar186RetryPendingCalendarProviders({sid:window.MAILCENTER187_CALENDAR_SID});}' +
    'function mcCalendar192TodayDate(){var d=new Date();return d.getFullYear()+"-"+String(d.getMonth()+1).padStart(2,"0")+"-"+String(d.getDate()).padStart(2,"0");}function mcCalendar192SetThisMonth(){var d=new Date(),s=new Date(d.getFullYear(),d.getMonth(),1),e=new Date(d.getFullYear(),d.getMonth()+1,0);function f(x){return x.getFullYear()+"-"+String(x.getMonth()+1).padStart(2,"0")+"-"+String(x.getDate()).padStart(2,"0");}var a=p187$("p192RangeStart"),b=p187$("p192RangeEnd");if(a)a.value=f(s);if(b)b.value=f(e);mcCalendar192CalRangeList();}function mcCalendar192ClearRangeFilter(){["p192RangeStart","p192RangeEnd","p192Keyword","p192Status"].forEach(function(id){var el=p187$(id);if(el)el.value="";});mcCalendar192CalRangeList();}function mcCalendar192RenderRangeList(res){p187Json(res||{});var body=p187$("p192RangeRows");if(!body)return;if(!res||!res.ok){body.innerHTML="<tr><td colspan=\\"8\\" class=\\"fh189-empty-cell\\">기간 조회 실패: "+p187Esc(res&&res.message?res.message:"오류")+"</td></tr>";return;}var rows=res.rows||[],html="";if(!rows.length){html="<tr><td colspan=\\"8\\" class=\\"fh189-empty-cell\\">조건에 맞는 일정이 없습니다.</td></tr>";}else{rows.forEach(function(r){html+="<tr><td title=\\""+p187Esc(r.calendarEventId)+"\\">"+p187Esc(p191ShortId(r.calendarEventId))+"</td><td>"+p187Esc(r.eventTitle)+"</td><td>"+p187Esc(p191FmtDateTime(r.startAt))+"</td><td>"+p187Esc(r.assignedEmployeeId)+"</td><td>"+p187Badge(r.naverRegisterStatus)+"</td><td>"+p187Badge(r.googleBackupStatus)+"</td><td>"+p187Esc(r.eventStatus)+"</td><td><button type=\\"button\\" class=\\"fh189-row-btn\\" onclick=\\"mcCalendar189CalDetail(\'"+p187Esc(r.calendarEventId)+"\')\\">상세</button></td></tr>";});}body.innerHTML=html;p187Summary("기간/검색 조회가 완료되었습니다.<br>표시 일정 <b>"+(res.filteredCount||0)+"건</b> / 접근 가능 일정 <b>"+(res.totalVisible||0)+"건</b>입니다.");}function mcCalendar192CalRangeList(){var payload={sid:window.MAILCENTER187_CALENDAR_SID,rangeStart:p187Val("p192RangeStart"),rangeEnd:p187Val("p192RangeEnd"),keyword:p187Val("p192Keyword"),eventStatus:p187Val("p192Status")};google.script.run.withSuccessHandler(mcCalendar192RenderRangeList).withFailureHandler(function(e){mcCalendar192RenderRangeList({ok:false,message:e&&e.message?e.message:String(e)});}).mcCalendar192ListCalendarEvents(payload);}' +
    'setTimeout(function(){mcCalendar187CalQuick();mcCalendar189LoadAssignees();mcCalendar187CalDashboard();mcCalendar189CalRetryList();mcCalendar192SetThisMonth();},300);' +
  '</script>';
}

function mcCalendar187CalendarEscape_(v) {
  return String(v == null ? '' : v).replace(/[&<>"']/g, function(c) { return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]; });
}

function mcCalendar187CalendarJsString_(v) {
  return String(v == null ? '' : v).replace(/\\/g, '\\\\').replace(/'/g, "\\'").replace(/\r/g, '').replace(/\n/g, '\\n');
}

function mcCalendar189CalendarAdvancedUiDebug() {
  var result = {
    ok: true,
    build: 'MAILCENTER_CALENDAR_CORE_CLONE_V01_20260521',
    action: 'mcCalendar189CalendarAdvancedUiDebug',
    message: '캘린더 후속 UI 브릿지 파일 인식 성공',
    checks: {
      builderReady: typeof mcCalendar187BuildCalendarModulePanel_ === 'function',
      assigneeListReady: typeof mcCalendar189ListCalendarAssignees === 'function',
      detailReady: typeof mcCalendar189GetCalendarEventDetail === 'function',
      retryListReady: typeof mcCalendar189ListCalendarRetryQueue === 'function',
      dashboardReady: typeof mcCalendar186GetCalendarDashboard === 'function',
      createReady: typeof mcCalendar19CreateCalendarEvent === 'function',
      run105FunctionReady: typeof mcCalendar105ApplyMailCenterLayout_ === 'function',
      run105LayoutHookApplied: (typeof mcCalendar105ApplyMailCenterLayout_ === 'function') ? String(mcCalendar105ApplyMailCenterLayout_).indexOf('mcCalendar187BuildCalendarModulePanel_') >= 0 : false
    },
    nextAction: 'MAILCENTER 로그인 후 좌측 일정 메뉴에서 담당자 선택, 상세 보기, 재전송 목록을 확인하세요.',
    generatedAt: Utilities.formatDate(new Date(), Session.getScriptTimeZone() || 'Asia/Seoul', 'yyyy-MM-dd HH:mm:ss')
  };
  Logger.log(JSON.stringify(result, null, 2));
  return result;
}

/*******************************************************
 * MAILCENTER 190 Calendar Action UI Fix
 * Build: MAILCENTER_CALENDAR_CORE_CLONE_V01_20260521
 * Scope: restore working 189 dashboard script and keep 190 detail/retry action checks.
 *******************************************************/
function mcCalendar190CalendarActionUiDebug() {
  var generated = '';
  try {
    if (typeof mcCalendar187BuildCalendarModulePanel_ === 'function') {
      generated = String(mcCalendar187BuildCalendarModulePanel_({loginId:'debug', employeeId:'EMP-DEBUG', employeeName:'Debug User', roleCode:'SUPER_ADMIN', vendorId:''}, 'DEBUG_SID') || '');
    }
  } catch (e) {
    generated = 'BUILD_ERROR: ' + (e && e.message ? e.message : e);
  }

  var badQuotePattern = generated.indexOf('data-calendar-event-id=""+cid+""') >= 0 || generated.indexOf('class="fh189-detail-grid"') >= 0;
  var result = {
    ok: true,
    build: 'MAILCENTER_CALENDAR_CORE_CLONE_V01_20260521',
    action: 'mcCalendar190CalendarActionUiDebug',
    message: '캘린더 상세/재전송 UI 복구 확인 완료 - 189 안정 UI 기준으로 최근 일정 표시를 복구했습니다.',
    checks: {
      builderReady: typeof mcCalendar187BuildCalendarModulePanel_ === 'function',
      detailReady: typeof mcCalendar189GetCalendarEventDetail === 'function',
      retryListReady: typeof mcCalendar189ListCalendarRetryQueue === 'function',
      retryActionReady: typeof mcCalendar186RetryPendingCalendarProviders === 'function',
      dashboardScriptRestored: generated.indexOf('mcCalendar187RenderDashboard') >= 0,
      recentRowsTargetReady: generated.indexOf('p187RecentRows') >= 0,
      scriptQuoteFixReady: generated.indexOf('td title=\\\"') >= 0,
      brokenQuotePatternRemoved: !badQuotePattern,
      actionButtonMode: '189 안정 inline detail call 복구'
    },
    nextAction: 'MAILCENTER 일정 메뉴를 새로고침한 뒤 최근 일정이 다시 보이는지 확인하고, 상세 버튼을 눌러 주세요.',
    generatedAt: Utilities.formatDate(new Date(), Session.getScriptTimeZone() || 'Asia/Seoul', 'yyyy-MM-dd HH:mm:ss')
  };
  Logger.log(JSON.stringify(result, null, 2));
  return result;
}


/*******************************************************
 * MAILCENTER 191 Calendar Stable UI Lock
 * Build: MAILCENTER_CALENDAR_CORE_CLONE_V01_20260521
 * Scope: stable display lock after 190 action checks.
 *******************************************************/
function mcCalendar191CalendarStableUiDebug() {
  var generated = '';
  try {
    if (typeof mcCalendar187BuildCalendarModulePanel_ === 'function') {
      generated = String(mcCalendar187BuildCalendarModulePanel_({loginId:'debug', employeeId:'EMP-DEBUG', employeeName:'Debug User', roleCode:'SUPER_ADMIN', vendorId:''}, 'DEBUG_SID') || '');
    }
  } catch (e) {
    generated = 'BUILD_ERROR: ' + (e && e.message ? e.message : e);
  }
  var result = {
    ok: true,
    build: 'MAILCENTER_CALENDAR_CORE_CLONE_V01_20260521',
    action: 'mcCalendar191CalendarStableUiDebug',
    message: '캘린더 191 현장 안정화 UI 파일 인식 성공 - 권한 사용자 기준 검사',
    checks: {
      builderReady: typeof mcCalendar187BuildCalendarModulePanel_ === 'function',
      dashboardReady: typeof mcCalendar186GetCalendarDashboard === 'function',
      createReady: typeof mcCalendar19CreateCalendarEvent === 'function',
      detailReady: typeof mcCalendar189GetCalendarEventDetail === 'function',
      retryListReady: typeof mcCalendar189ListCalendarRetryQueue === 'function',
      retryActionReady: typeof mcCalendar186RetryPendingCalendarProviders === 'function',
      assigneeListReady: typeof mcCalendar189ListCalendarAssignees === 'function',
      run105LayoutHookApplied: (typeof mcCalendar105ApplyMailCenterLayout_ === 'function') ? String(mcCalendar105ApplyMailCenterLayout_).indexOf('mcCalendar187BuildCalendarModulePanel_') >= 0 : false,
      stableHeaderApplied: generated.indexOf('Stable Lock') >= 0,
      koreanDateHelperReady: generated.indexOf('p191FmtDateTime') >= 0,
      recentRowsTargetReady: generated.indexOf('p187RecentRows') >= 0,
      scriptQuoteFixReady: generated.indexOf('td title=\\\"') >= 0,
      developerLogCollapsed: generated.indexOf('fh189-devbox') >= 0
    },
    nextAction: 'MAILCENTER 로그인 후 일정 메뉴에서 최근 일정 날짜 표시, 상세 보기 날짜 표시, 재전송 목록 안내문을 확인하세요.',
    generatedAt: Utilities.formatDate(new Date(), Session.getScriptTimeZone() || 'Asia/Seoul', 'yyyy-MM-dd HH:mm:ss')
  };
  Logger.log(JSON.stringify(result, null, 2));
  return result;
}


/*******************************************************
 * MAILCENTER 192 Calendar Range/List View UI Debug
 *******************************************************/
function mcCalendar192CalendarRangeListUiDebug() {
  var generated = '';
  try {
    if (typeof mcCalendar187BuildCalendarModulePanel_ === 'function') {
      generated = String(mcCalendar187BuildCalendarModulePanel_({loginId:'debug', employeeId:'EMP-DEBUG', employeeName:'Debug User', roleCode:'SUPER_ADMIN', vendorId:''}, 'DEBUG_SID') || '');
    }
  } catch (e) {
    generated = 'BUILD_ERROR: ' + (e && e.message ? e.message : e);
  }
  var result = {
    ok: true,
    build: 'MAILCENTER_CALENDAR_CORE_CLONE_V01_20260521',
    action: 'mcCalendar192CalendarRangeListUiDebug',
    message: '캘린더 192 기간/검색 UI 파일 인식 성공',
    checks: {
      builderReady: typeof mcCalendar187BuildCalendarModulePanel_ === 'function',
      rangeListServerReady: typeof mcCalendar192ListCalendarEvents === 'function',
      rangeRowsTargetReady: generated.indexOf('p192RangeRows') >= 0,
      rangeSearchFunctionReady: generated.indexOf('mcCalendar192CalRangeList') >= 0,
      thisMonthButtonReady: generated.indexOf('mcCalendar192SetThisMonth') >= 0,
      detailReady: typeof mcCalendar189GetCalendarEventDetail === 'function',
      run105LayoutHookApplied: (typeof mcCalendar105ApplyMailCenterLayout_ === 'function') ? String(mcCalendar105ApplyMailCenterLayout_).indexOf('mcCalendar187BuildCalendarModulePanel_') >= 0 : false
    },
    nextAction: 'MAILCENTER 로그인 후 일정 메뉴에서 기간/검색 영역, 이번 달 버튼, 검색/조회 버튼을 확인하세요.',
    generatedAt: Utilities.formatDate(new Date(), Session.getScriptTimeZone() || 'Asia/Seoul', 'yyyy-MM-dd HH:mm:ss')
  };
  Logger.log(JSON.stringify(result, null, 2));
  return result;
}

function mcCalendar193CalendarEditUiDebug() {
  var generated = '';
  try {
    generated = String(mcCalendar187BuildCalendarModulePanel_({
      loginId: 'debug',
      employeeId: 'EMP-DEBUG',
      employeeName: '디버그 사용자',
      roleCode: 'SUPER_ADMIN',
      vendorId: '',
      permissions: { ALL: true, CALENDAR_CREATE: true, CALENDAR_VIEW: true, CALENDAR_RETRY: true }
    }, 'DEBUG-SID') || '');
  } catch (e) {
    generated = 'ERROR: ' + (e && e.message ? e.message : e);
  }
  var result = {
    ok: true,
    build: 'MAILCENTER_CALENDAR_CORE_CLONE_V01_20260521',
    action: 'mcCalendar193CalendarEditUiDebug',
    message: '캘린더 193 일정 수정 UI 파일 인식 성공',
    checks: {
      builderReady: typeof mcCalendar187BuildCalendarModulePanel_ === 'function',
      updateServerReady: typeof mcCalendar193UpdateCalendarEvent === 'function',
      detailReady: typeof mcCalendar189GetCalendarEventDetail === 'function',
      editFormReady: generated.indexOf('p193EditTitle') >= 0,
      editSaveButtonReady: generated.indexOf('mcCalendar193UpdateEvent') >= 0,
      dashboardReady: typeof mcCalendar186GetCalendarDashboard === 'function',
      rangeListReady: typeof mcCalendar192ListCalendarEvents === 'function',
      run105LayoutHookApplied: (typeof mcCalendar105ApplyMailCenterLayout_ === 'function') ? String(mcCalendar105ApplyMailCenterLayout_).indexOf('mcCalendar187BuildCalendarModulePanel_') >= 0 : false
    },
    nextAction: 'MAILCENTER 일정 메뉴에서 상세 버튼을 누른 뒤 일정 수정 영역과 수정 저장 버튼을 확인하세요.',
    generatedAt: Utilities.formatDate(new Date(), Session.getScriptTimeZone() || 'Asia/Seoul', 'yyyy-MM-dd HH:mm:ss')
  };
  Logger.log(JSON.stringify(result, null, 2));
  return result;
}
