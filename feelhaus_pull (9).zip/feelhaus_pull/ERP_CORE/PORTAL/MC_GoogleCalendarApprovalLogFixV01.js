/*******************************************************
 * MC_GOOGLE_CALENDAR_APPROVAL_LOG_FIX_V01_20260527
 * Purpose: Log visibility helper for Google Calendar approval apply gate.
 * - Does not clear or repair existing rows.
 * - Reads both legacy display names and protected uppercase sheet names.
 * - Ensures required log sheets/headers only when missing.
 *******************************************************/

function mcGoogleCalendarApprovalLogFixV01SelfTest() {
  var BUILD = 'MC_GOOGLE_CALENDAR_APPROVAL_LOG_FIX_V01_20260527';
  var result = {
    ok: false,
    build: BUILD,
    action: 'mcGoogleCalendarApprovalLogFixV01SelfTest',
    generatedAt: mcGoogleCalendarApprovalLogFixV01Now_(),
    message: '',
    checks: {}
  };
  try {
    var ss = mcGoogleCalendarApprovalLogFixV01OpenMaster_();
    result.checks.masterDbOk = !!ss;
    result.checks.auditSheetUpper = !!ss.getSheetByName('MAILCENTER_AuditLogs');
    result.checks.auditSheetLegacy = !!ss.getSheetByName('MailCenter_AuditLogs');
    result.checks.syncLogSheet = !!ss.getSheetByName('MAILCENTER_GoogleCalendarSyncLogs');
    result.checks.baseApprovalReady = typeof mcGoogleCalendarSyncApprovalApplyV01 === 'function';
    result.checks.basePreviewReady = typeof mcGoogleCalendarSyncApprovalApplyV01Preview === 'function';
    result.ok = !!result.checks.masterDbOk;
    result.message = result.ok ? 'Google Calendar 승인 로그 조회 보정 준비 완료' : 'Google Calendar 승인 로그 조회 보정 점검 실패';
  } catch (err) {
    result.ok = false;
    result.message = mcGoogleCalendarApprovalLogFixV01Error_(err);
  }
  Logger.log('JSON_COMPACT_RESULT: ' + mcGoogleCalendarApprovalLogFixV01Stringify_(result));
  return mcGoogleCalendarApprovalLogFixV01Safe_(result);
}

function mcGoogleCalendarApprovalLogFixV01EnsureSheets() {
  var BUILD = 'MC_GOOGLE_CALENDAR_APPROVAL_LOG_FIX_V01_20260527';
  var result = {
    ok: false,
    build: BUILD,
    action: 'mcGoogleCalendarApprovalLogFixV01EnsureSheets',
    generatedAt: mcGoogleCalendarApprovalLogFixV01Now_(),
    message: '',
    created: [],
    existing: []
  };
  try {
    var ss = mcGoogleCalendarApprovalLogFixV01OpenMaster_();
    mcGoogleCalendarApprovalLogFixV01EnsureSheet_(ss, 'MAILCENTER_AuditLogs', ['logId','createdAt','action','actorKey','targetId','resultStatus','message','payload'], result);
    mcGoogleCalendarApprovalLogFixV01EnsureSheet_(ss, 'MAILCENTER_GoogleCalendarSyncLogs', ['logId','createdAt','batchId','calendarEventId','googleCalendarId','googleEventId','direction','action','status','conflictStatus','message','payload','actorKey'], result);
    result.ok = true;
    result.message = 'Google Calendar 승인 로그 시트 확인 완료. 기존 행은 수정/삭제하지 않았습니다.';
  } catch (err) {
    result.ok = false;
    result.message = mcGoogleCalendarApprovalLogFixV01Error_(err);
  }
  Logger.log('JSON_COMPACT_RESULT: ' + mcGoogleCalendarApprovalLogFixV01Stringify_(result));
  return mcGoogleCalendarApprovalLogFixV01Safe_(result);
}

function mcGoogleCalendarApprovalLogFixV01ListRecent(request) {
  request = request || {};
  var limit = Math.max(1, Math.min(Number(request.limit || 30), 200));
  var BUILD = 'MC_GOOGLE_CALENDAR_APPROVAL_LOG_FIX_V01_20260527';
  var result = {
    ok: false,
    build: BUILD,
    action: 'mcGoogleCalendarApprovalLogFixV01ListRecent',
    generatedAt: mcGoogleCalendarApprovalLogFixV01Now_(),
    message: '',
    filters: { limit: limit },
    summary: { auditCount: 0, syncLogCount: 0, total: 0 },
    sheets: {
      auditAliases: ['MAILCENTER_AuditLogs', 'MailCenter_AuditLogs'],
      syncLogAliases: ['MAILCENTER_GoogleCalendarSyncLogs', 'MailCenter_GoogleCalendarSyncLogs']
    },
    auditLogs: [],
    googleSyncLogs: []
  };
  try {
    var ss = mcGoogleCalendarApprovalLogFixV01OpenMaster_();
    result.auditLogs = mcGoogleCalendarApprovalLogFixV01ReadAliases_(ss, result.sheets.auditAliases, limit, function(row) {
      var action = String(row.action || '').toUpperCase();
      return action.indexOf('GOOGLE_CALENDAR') >= 0 || action.indexOf('CALENDAR') >= 0;
    });
    result.googleSyncLogs = mcGoogleCalendarApprovalLogFixV01ReadAliases_(ss, result.sheets.syncLogAliases, limit, null);
    result.summary.auditCount = result.auditLogs.length;
    result.summary.syncLogCount = result.googleSyncLogs.length;
    result.summary.total = result.summary.auditCount + result.summary.syncLogCount;
    result.ok = true;
    result.message = result.summary.total ? 'Google Calendar 승인/동기화 최근 로그 조회 완료' : '조회 가능한 Google Calendar 승인/동기화 로그가 없습니다. 먼저 Preview 또는 SelfTest를 실행하세요.';
  } catch (err) {
    result.ok = false;
    result.message = mcGoogleCalendarApprovalLogFixV01Error_(err);
  }
  Logger.log('JSON_COMPACT_RESULT: ' + mcGoogleCalendarApprovalLogFixV01Stringify_(result));
  return mcGoogleCalendarApprovalLogFixV01Safe_(result);
}

function mcGoogleCalendarApprovalLogFixV01DiagnoseAndList(request) {
  var ensure = mcGoogleCalendarApprovalLogFixV01EnsureSheets();
  var recent = mcGoogleCalendarApprovalLogFixV01ListRecent(request || { limit: 30 });
  return mcGoogleCalendarApprovalLogFixV01Safe_({
    ok: !!(ensure && ensure.ok && recent && recent.ok),
    build: 'MC_GOOGLE_CALENDAR_APPROVAL_LOG_FIX_V01_20260527',
    action: 'mcGoogleCalendarApprovalLogFixV01DiagnoseAndList',
    generatedAt: mcGoogleCalendarApprovalLogFixV01Now_(),
    message: 'Google Calendar 로그 시트 확인 및 최근 로그 조회 완료',
    ensure: ensure,
    recent: recent
  });
}

function mcGoogleCalendarApprovalLogFixV01OpenMaster_() {
  if (typeof mcCalendar19OpenMaster_ === 'function' && typeof mcCalendar19GetConfigBundle_ === 'function') {
    return mcCalendar19OpenMaster_(mcCalendar19GetConfigBundle_());
  }
  var setup = SpreadsheetApp.openById('17VMSpgSZCvIrUlgcw8yCNcnl8WQWo2IcRf5tDCcuJGM');
  var sh = setup.getSheetByName('SystemConfig');
  if (!sh) throw new Error('SystemConfig 시트를 찾지 못했습니다.');
  var values = sh.getDataRange().getValues();
  var id = '';
  for (var r = 1; r < values.length; r++) {
    var key = String(values[r][0] || '').trim();
    var val = String(values[r][1] || '').trim();
    if (['FEELHAUS_DB_MASTER_ID','FEELHAUS_DB_MASTER','MASTER_DB_ID','MASTER_DB','DB_MASTER_ID','PORTAL_DB_ID','SPREADSHEET_ID'].indexOf(key) >= 0 && val) {
      id = val;
      break;
    }
  }
  id = mcGoogleCalendarApprovalLogFixV01ExtractId_(id);
  if (!id) throw new Error('FEELHAUS_DB_MASTER ID를 SystemConfig에서 찾지 못했습니다.');
  return SpreadsheetApp.openById(id);
}

function mcGoogleCalendarApprovalLogFixV01EnsureSheet_(ss, name, headers, result) {
  var sh = ss.getSheetByName(name);
  if (!sh) {
    sh = ss.insertSheet(name);
    result.created.push(name);
  } else {
    result.existing.push(name);
  }
  if (sh.getLastRow() < 1) {
    sh.getRange(1, 1, 1, headers.length).setValues([headers]);
  }
  return sh;
}

function mcGoogleCalendarApprovalLogFixV01ReadAliases_(ss, names, limit, filterFn) {
  var out = [];
  var seen = {};
  for (var i = 0; i < names.length; i++) {
    var sh = ss.getSheetByName(names[i]);
    if (!sh) continue;
    var rows = mcGoogleCalendarApprovalLogFixV01ReadSheet_(sh, limit);
    for (var j = 0; j < rows.length; j++) {
      var row = rows[j];
      if (filterFn && !filterFn(row)) continue;
      var key = String(row.logId || row.createdAt || '') + '|' + String(row.action || '') + '|' + String(row.message || '');
      if (seen[key]) continue;
      seen[key] = true;
      row._sheetName = names[i];
      out.push(row);
    }
  }
  out.sort(function(a, b) { return String(b.createdAt || '').localeCompare(String(a.createdAt || '')); });
  if (out.length > limit) out = out.slice(0, limit);
  return out;
}

function mcGoogleCalendarApprovalLogFixV01ReadSheet_(sh, limit) {
  var values = sh.getDataRange().getValues();
  if (!values || values.length < 2) return [];
  var headers = values[0].map(function(h) { return String(h || '').trim(); });
  var out = [];
  for (var r = values.length - 1; r >= 1 && out.length < limit; r--) {
    var obj = {};
    for (var c = 0; c < headers.length; c++) obj[headers[c] || ('col' + (c + 1))] = values[r][c];
    out.push(obj);
  }
  return out;
}

function mcGoogleCalendarApprovalLogFixV01ExtractId_(text) {
  var s = String(text || '').trim();
  var m = s.match(/[-\w]{25,}/);
  return m ? m[0] : s;
}

function mcGoogleCalendarApprovalLogFixV01Safe_(obj) {
  try { return JSON.parse(JSON.stringify(obj)); } catch (err) { return obj; }
}

function mcGoogleCalendarApprovalLogFixV01Stringify_(obj) {
  try { return JSON.stringify(obj); } catch (err) { return mcGoogleCalendarApprovalLogFixV01Error_(err); }
}

function mcGoogleCalendarApprovalLogFixV01Error_(err) {
  if (!err) return '';
  if (err.name && err.message) return String(err.name) + ': ' + String(err.message);
  if (err.message) return String(err.message);
  return String(err);
}

function mcGoogleCalendarApprovalLogFixV01Now_() {
  try { return Utilities.formatDate(new Date(), Session.getScriptTimeZone() || 'Asia/Seoul', 'yyyy-MM-dd HH:mm:ss'); }
  catch (err) { return String(new Date()); }
}
