/**
 * FEELHAUS MailCenter Calendar Record Manual Link V01
 * Build: MAILCENTER_CALENDAR_RECORD_MANUAL_LINK_V01_20260521
 * Purpose:
 * - Prepare safe server functions for manual recordId/requestId linking
 * - Search PORTAL_MailLogs candidates by mail keys
 * - Apply selected requestId to MAILCENTER_CalendarEvents.requestId and MAILCENTER_CalendarMailLinks.recordId
 * - Write audit trail to MAILCENTER_CalendarLogs
 * - Do not modify router/menu/html/calendar UI files
 */
var MC_CALENDAR_RECORD_MANUAL_LINK_V01_BUILD = 'MAILCENTER_CALENDAR_RECORD_MANUAL_LINK_V01_20260521';
var MC_CALENDAR_RECORD_MANUAL_LINK_V01_SETUP_DB_ID = '17VMSpgSZCvIrUlgcw8yCNcnl8WQWo2IcRf5tDCcuJGM';
var MC_CALENDAR_RECORD_MANUAL_LINK_V01_CONFIG_SHEET = 'SystemConfig';
var MC_CALENDAR_RECORD_MANUAL_LINK_V01_WEBAPP_URL = 'https://script.google.com/a/macros/feelhausfair.com/s/AKfycbxCyFE7zf4vE8nsfjOeWX0pC56SqU84gm8ie8Txa3qHQGEusJCZeljzCdYeOmZxUVYvjA/exec';
var MC_CALENDAR_RECORD_MANUAL_LINK_V01_SOURCE_SHEET = 'PORTAL_MailLogs';

function runMcCalendarRecordManualLinkV01Smoke() {
  var result = {
    ok: true,
    build: MC_CALENDAR_RECORD_MANUAL_LINK_V01_BUILD,
    action: 'runMcCalendarRecordManualLinkV01Smoke',
    generatedAt: mcCalendarRecordManualLinkV01Now_(),
    noWriteMode: true,
    checks: []
  };
  function check(key, ok, message, detail) {
    result.checks.push({ key: key, ok: !!ok, message: message, detail: detail || '' });
    if (!ok) result.ok = false;
  }
  try {
    check('MasterOpenReady', !!mcCalendarRecordManualLinkV01OpenMaster_(), 'SystemConfig -> FEELHAUS_DB_MASTER 연결 확인', 'FEELHAUS_DB_MASTER');
    check('CandidateSearchReady', typeof mcCalendarRecordManualLinkV01SearchCandidates === 'function', '수동 연결 후보 검색 함수 확인');
    check('ApplyFunctionReady', typeof mcCalendarRecordManualLinkV01Apply === 'function', '수동 연결 적용 함수 확인');
    check('DryRunReady', typeof runMcCalendarRecordManualLinkV01DryRun === 'function', 'Dry Run 함수 확인');
    check('GateReady', typeof runMcCalendarRecordManualLinkV01Gate === 'function', 'Gate 함수 확인');
    check('LockReady', typeof runMcCalendarRecordManualLinkV01CreateBackupAndLock === 'function', '백업/잠금 함수 확인');
    check('SummaryReady', typeof runMcCalendarRecordManualLinkV01Summary === 'function', '요약 기록 함수 확인');
    check('WebAppUrlReady', !!MC_CALENDAR_RECORD_MANUAL_LINK_V01_WEBAPP_URL, 'WebApp 절대주소 확인', MC_CALENDAR_RECORD_MANUAL_LINK_V01_WEBAPP_URL);
    check('NoRouterMenuHtmlTouch', true, '본 파일은 라우터/메뉴/HTML/Shell/View 변경 없음');
    result.message = result.ok ? 'MailCenter Calendar Record Manual Link V01 Smoke 통과' : 'MailCenter Calendar Record Manual Link V01 점검 필요';
  } catch (err) {
    result.ok = false;
    result.message = mcCalendarRecordManualLinkV01Err_(err);
  }
  Logger.log(JSON.stringify(result, null, 2));
  return result;
}

function runMcCalendarRecordManualLinkV01DryRun() {
  var result = {
    ok: true,
    build: MC_CALENDAR_RECORD_MANUAL_LINK_V01_BUILD,
    action: 'runMcCalendarRecordManualLinkV01DryRun',
    generatedAt: mcCalendarRecordManualLinkV01Now_(),
    noWriteMode: true,
    checks: [],
    sampleCalendarEventId: '',
    candidateCount: 0,
    candidates: []
  };
  function check(key, ok, message, detail) {
    result.checks.push({ key: key, ok: !!ok, message: message, detail: detail || '' });
    if (!ok) result.ok = false;
  }
  try {
    var ss = mcCalendarRecordManualLinkV01OpenMaster_();
    var events = ss.getSheetByName('MAILCENTER_CalendarEvents');
    var links = ss.getSheetByName('MAILCENTER_CalendarMailLinks');
    var source = ss.getSheetByName(MC_CALENDAR_RECORD_MANUAL_LINK_V01_SOURCE_SHEET);
    check('CalendarEventsReady', !!events, 'MAILCENTER_CalendarEvents 시트 확인', events ? ('rows=' + events.getLastRow() + ', cols=' + events.getLastColumn()) : '');
    check('CalendarMailLinksReady', !!links, 'MAILCENTER_CalendarMailLinks 시트 확인', links ? ('rows=' + links.getLastRow() + ', cols=' + links.getLastColumn()) : '');
    check('SourceSheetReady', !!source, 'PORTAL_MailLogs 시트 확인', source ? ('rows=' + source.getLastRow() + ', cols=' + source.getLastColumn()) : '');

    if (events && links && source) {
      var sampleId = mcCalendarRecordManualLinkV01FindSampleEventId_(ss);
      result.sampleCalendarEventId = sampleId;
      check('SampleCalendarEventReady', !!sampleId, '수동 연결 샘플 calendarEventId 확인', sampleId || '샘플 없음');
      if (sampleId) {
        var detail = mcCalendarRecordManualLinkV01BuildMailKeyContext_(ss, sampleId);
        var candidates = mcCalendarRecordManualLinkV01FindCandidatesByContext_(ss, detail, 10);
        result.candidateCount = candidates.length;
        result.candidates = candidates;
        check('CandidateSearchCompleted', true, '수동 연결 후보 검색 완료', JSON.stringify({ sampleCalendarEventId: sampleId, candidateCount: candidates.length }).slice(0, 900));
      }
    }
    check('NoWriteModeConfirmed', true, 'Dry Run은 읽기 전용, 시트 쓰기 없음');
    result.message = result.ok ? 'MailCenter Calendar Record Manual Link V01 Dry Run 통과' : 'MailCenter Calendar Record Manual Link V01 Dry Run 점검 필요';
  } catch (err) {
    result.ok = false;
    result.message = mcCalendarRecordManualLinkV01Err_(err);
  }
  Logger.log(JSON.stringify(result, null, 2));
  return result;
}

function runMcCalendarRecordManualLinkV01Gate() {
  var result = {
    ok: true,
    build: MC_CALENDAR_RECORD_MANUAL_LINK_V01_BUILD,
    action: 'runMcCalendarRecordManualLinkV01Gate',
    generatedAt: mcCalendarRecordManualLinkV01Now_(),
    noWriteMode: true,
    checks: [],
    nextStage: 'MAILCENTER_CALENDAR_RECORD_MANUAL_LINK_UI_READY'
  };
  function check(key, ok, message, detail) {
    result.checks.push({ key: key, ok: !!ok, message: message, detail: detail || '' });
    if (!ok) result.ok = false;
  }
  try {
    var ss = mcCalendarRecordManualLinkV01OpenMaster_();
    check('MasterOpenReady', !!ss, 'SystemConfig -> FEELHAUS_DB_MASTER 연결 확인', ss ? ss.getId() : '');
    var events = ss.getSheetByName('MAILCENTER_CalendarEvents');
    var links = ss.getSheetByName('MAILCENTER_CalendarMailLinks');
    var logs = ss.getSheetByName('MAILCENTER_CalendarLogs');
    var source = ss.getSheetByName(MC_CALENDAR_RECORD_MANUAL_LINK_V01_SOURCE_SHEET);
    check('CalendarEventsReady', !!events, 'MAILCENTER_CalendarEvents 시트 확인', events ? ('rows=' + events.getLastRow() + ', cols=' + events.getLastColumn()) : '');
    check('CalendarMailLinksReady', !!links, 'MAILCENTER_CalendarMailLinks 시트 확인', links ? ('rows=' + links.getLastRow() + ', cols=' + links.getLastColumn()) : '');
    check('CalendarLogsReady', !!logs, 'MAILCENTER_CalendarLogs 시트 확인', logs ? ('rows=' + logs.getLastRow() + ', cols=' + logs.getLastColumn()) : '');
    check('SourceSheetReady', !!source, 'PORTAL_MailLogs 시트 확인', source ? ('rows=' + source.getLastRow() + ', cols=' + source.getLastColumn()) : '');

    if (events) check('EventsHeadersReady', mcCalendarRecordManualLinkV01RequiredHeadersReady_(events, ['calendarEventId','requestId','updatedAt','updatedBy']), '이벤트 수동 연결 핵심 헤더 확인', mcCalendarRecordManualLinkV01MissingHeadersText_(events, ['calendarEventId','requestId','updatedAt','updatedBy']));
    if (links) check('LinksHeadersReady', mcCalendarRecordManualLinkV01RequiredHeadersReady_(links, ['calendarEventId','recordId','threadId','messageId','subject','updatedAt','updatedBy']), '메일링크 수동 연결 핵심 헤더 확인', mcCalendarRecordManualLinkV01MissingHeadersText_(links, ['calendarEventId','recordId','threadId','messageId','subject','updatedAt','updatedBy']));
    if (logs) check('LogsHeadersReady', mcCalendarRecordManualLinkV01RequiredHeadersReady_(logs, ['calendarLogId','calendarEventId','provider','actionType','resultStatus','requestPayloadSummary','responseSummary','createdAt','createdBy']), '로그 핵심 헤더 확인', mcCalendarRecordManualLinkV01MissingHeadersText_(logs, ['calendarLogId','calendarEventId','provider','actionType','resultStatus','requestPayloadSummary','responseSummary','createdAt','createdBy']));
    if (source) check('SourceHeadersReady', mcCalendarRecordManualLinkV01RequiredAnyHeadersReady_(source, [['requestId'], ['threadId','messageId','subject']]), 'PORTAL_MailLogs 수동 연결 후보 헤더 확인', mcCalendarRecordManualLinkV01HeaderListText_(source));

    check('SearchFunctionReady', typeof mcCalendarRecordManualLinkV01SearchCandidates === 'function', '수동 후보 검색 함수 확인');
    check('ApplyFunctionReady', typeof mcCalendarRecordManualLinkV01Apply === 'function', '수동 연결 적용 함수 확인');
    check('NoWriteModeConfirmed', true, '본 게이트는 읽기 전용, 시트 쓰기 없음');
    check('NoRouterMenuHtmlTouchByGate', true, '게이트는 라우터/메뉴/HTML/Shell/View 변경 없음');
    result.message = result.ok ? 'MailCenter Calendar Record Manual Link V01 Gate 통과' : 'MailCenter Calendar Record Manual Link V01 점검 필요';
  } catch (err) {
    result.ok = false;
    result.message = mcCalendarRecordManualLinkV01Err_(err);
  }
  Logger.log(JSON.stringify(result, null, 2));
  return result;
}

function mcCalendarRecordManualLinkV01SearchCandidates(payload) {
  payload = payload || {};
  var result = {
    ok: false,
    build: MC_CALENDAR_RECORD_MANUAL_LINK_V01_BUILD,
    action: 'mcCalendarRecordManualLinkV01SearchCandidates',
    generatedAt: mcCalendarRecordManualLinkV01Now_(),
    calendarEventId: String(payload.calendarEventId || '').trim(),
    candidates: [],
    message: ''
  };
  try {
    if (!result.calendarEventId) throw new Error('calendarEventId가 필요합니다.');
    var ss = mcCalendarRecordManualLinkV01OpenMaster_();
    var context = mcCalendarRecordManualLinkV01BuildMailKeyContext_(ss, result.calendarEventId);
    result.context = context;
    result.candidates = mcCalendarRecordManualLinkV01FindCandidatesByContext_(ss, context, parseInt(payload.limit || 10, 10) || 10);
    result.ok = true;
    result.message = '수동 recordId/requestId 연결 후보 조회 완료';
  } catch (err) {
    result.ok = false;
    result.message = mcCalendarRecordManualLinkV01Err_(err);
  }
  Logger.log(JSON.stringify(result, null, 2));
  return result;
}

function mcCalendarRecordManualLinkV01Apply(payload) {
  payload = payload || {};
  var result = {
    ok: false,
    build: MC_CALENDAR_RECORD_MANUAL_LINK_V01_BUILD,
    action: 'mcCalendarRecordManualLinkV01Apply',
    generatedAt: mcCalendarRecordManualLinkV01Now_(),
    calendarEventId: String(payload.calendarEventId || '').trim(),
    recordId: String(payload.recordId || payload.requestId || '').trim(),
    message: ''
  };
  try {
    if (!result.calendarEventId) throw new Error('calendarEventId가 필요합니다.');
    if (!result.recordId) throw new Error('연결할 recordId/requestId가 필요합니다.');

    var ss = mcCalendarRecordManualLinkV01OpenMaster_();
    var actor = mcCalendarRecordManualLinkV01Actor_();
    var now = mcCalendarRecordManualLinkV01Now_();

    var eventUpdate = mcCalendarRecordManualLinkV01UpdateById_(ss, 'MAILCENTER_CalendarEvents', 'calendarEventId', result.calendarEventId, {
      requestId: result.recordId,
      updatedAt: now,
      updatedBy: actor
    });
    var linkUpdate = mcCalendarRecordManualLinkV01UpdateById_(ss, 'MAILCENTER_CalendarMailLinks', 'calendarEventId', result.calendarEventId, {
      recordId: result.recordId,
      updatedAt: now,
      updatedBy: actor
    });

    mcCalendarRecordManualLinkV01AppendByHeaders_(ss, 'MAILCENTER_CalendarLogs', mcCalendarRecordManualLinkV01LogHeaders_(), {
      calendarLogId: 'MCALLOG-' + Utilities.formatDate(new Date(), Session.getScriptTimeZone() || 'Asia/Seoul', 'yyyyMMddHHmmss') + '-' + Utilities.getUuid().substring(0, 8).toUpperCase(),
      calendarEventId: result.calendarEventId,
      provider: 'MANUAL_RECORD_LINK',
      actionType: 'MANUAL_RECORD_LINK',
      resultStatus: 'SUCCESS',
      providerEventId: '',
      errorCode: '',
      errorMessage: '',
      requestPayloadSummary: JSON.stringify({ calendarEventId: result.calendarEventId, recordId: result.recordId, sourceSheet: payload.sourceSheet || MC_CALENDAR_RECORD_MANUAL_LINK_V01_SOURCE_SHEET }).slice(0, 900),
      responseSummary: JSON.stringify({ eventUpdatedRows: eventUpdate.updatedRows, linkUpdatedRows: linkUpdate.updatedRows }).slice(0, 900),
      createdAt: now,
      createdBy: actor
    });

    result.ok = true;
    result.eventUpdatedRows = eventUpdate.updatedRows;
    result.linkUpdatedRows = linkUpdate.updatedRows;
    result.message = '수동 recordId/requestId 연결 완료';
  } catch (err) {
    result.ok = false;
    result.message = mcCalendarRecordManualLinkV01Err_(err);
  }
  Logger.log(JSON.stringify(result, null, 2));
  return result;
}

function runMcCalendarRecordManualLinkV01CreateBackupAndLock() {
  var result = {
    ok: false,
    build: MC_CALENDAR_RECORD_MANUAL_LINK_V01_BUILD,
    action: 'runMcCalendarRecordManualLinkV01CreateBackupAndLock',
    generatedAt: mcCalendarRecordManualLinkV01Now_(),
    lockId: '',
    backupSpreadsheetId: '',
    backupName: '',
    copiedSheets: [],
    message: ''
  };
  try {
    var ss = mcCalendarRecordManualLinkV01OpenMaster_();
    var actor = mcCalendarRecordManualLinkV01Actor_();
    var now = mcCalendarRecordManualLinkV01Now_();
    var stamp = Utilities.formatDate(new Date(), Session.getScriptTimeZone() || 'Asia/Seoul', 'yyyyMMdd_HHmmss');
    var lockId = 'MCALMANLINKLOCK-' + Utilities.formatDate(new Date(), Session.getScriptTimeZone() || 'Asia/Seoul', 'yyyyMMddHHmmss') + '-' + Utilities.getUuid().substring(0, 8).toUpperCase();
    var backupName = 'MAILCENTER_CALENDAR_RECORD_MANUAL_LINK_BACKUP_' + stamp;
    var backup = SpreadsheetApp.create(backupName);
    var copied = [];
    ['MAILCENTER_CalendarEvents','MAILCENTER_CalendarMailLinks','MAILCENTER_CalendarLogs','PORTAL_MailLogs','MAILCENTER_CalendarRecordLinkSourceApplyLocks','MAILCENTER_CalendarRecordLinkSourceApplySummaries'].forEach(function(name) {
      var src = ss.getSheetByName(name);
      if (src) {
        var copy = src.copyTo(backup);
        copy.setName(name);
        copied.push({ sheetName: name, rows: src.getLastRow(), cols: src.getLastColumn() });
      } else {
        copied.push({ sheetName: name, rows: 0, cols: 0, missing: true });
      }
    });
    var defaultSheet = backup.getSheetByName('Sheet1');
    if (defaultSheet && backup.getSheets().length > 1) backup.deleteSheet(defaultSheet);
    var info = backup.insertSheet('LOCK_INFO');
    var rows = [
      ['key','value'],
      ['lockId', lockId],
      ['build', MC_CALENDAR_RECORD_MANUAL_LINK_V01_BUILD],
      ['webAppUrl', MC_CALENDAR_RECORD_MANUAL_LINK_V01_WEBAPP_URL],
      ['sourceSheet', MC_CALENDAR_RECORD_MANUAL_LINK_V01_SOURCE_SHEET],
      ['sourceMasterId', ss.getId()],
      ['backupSpreadsheetId', backup.getId()],
      ['lockedAt', now],
      ['lockedBy', actor],
      ['status', 'STABLE_LOCKED'],
      ['scope', 'Manual recordId/requestId link server pack'],
      ['note', 'Router/menu/html route structure not modified by this lock file']
    ];
    info.getRange(1, 1, rows.length, 2).setValues(rows);
    info.setFrozenRows(1);

    mcCalendarRecordManualLinkV01AppendByHeaders_(ss, 'MAILCENTER_CalendarRecordManualLinkLocks', mcCalendarRecordManualLinkV01LockHeaders_(), {
      lockId: lockId,
      build: MC_CALENDAR_RECORD_MANUAL_LINK_V01_BUILD,
      backupName: backupName,
      backupSpreadsheetId: backup.getId(),
      webAppUrl: MC_CALENDAR_RECORD_MANUAL_LINK_V01_WEBAPP_URL,
      sourceSheet: MC_CALENDAR_RECORD_MANUAL_LINK_V01_SOURCE_SHEET,
      status: 'STABLE_LOCKED',
      statusReason: 'MailCenter 캘린더 수동 recordId/requestId 연결 서버팩 잠금 완료',
      copiedSheetsJson: JSON.stringify(copied),
      createdAt: now,
      createdBy: actor,
      updatedAt: now,
      updatedBy: actor
    });

    result.ok = true;
    result.lockId = lockId;
    result.backupSpreadsheetId = backup.getId();
    result.backupName = backupName;
    result.copiedSheets = copied;
    result.message = 'MailCenter Calendar Record Manual Link V01 Lock 완료';
  } catch (err) {
    result.ok = false;
    result.message = mcCalendarRecordManualLinkV01Err_(err);
  }
  Logger.log(JSON.stringify(result, null, 2));
  return result;
}

function runMcCalendarRecordManualLinkV01Summary() {
  var result = {
    ok: false,
    build: MC_CALENDAR_RECORD_MANUAL_LINK_V01_BUILD,
    action: 'runMcCalendarRecordManualLinkV01Summary',
    generatedAt: mcCalendarRecordManualLinkV01Now_(),
    summaryId: '',
    message: ''
  };
  try {
    var ss = mcCalendarRecordManualLinkV01OpenMaster_();
    var now = mcCalendarRecordManualLinkV01Now_();
    var actor = mcCalendarRecordManualLinkV01Actor_();
    var summaryId = 'MCALMANLINKSUM-' + Utilities.formatDate(new Date(), Session.getScriptTimeZone() || 'Asia/Seoul', 'yyyyMMddHHmmss') + '-' + Utilities.getUuid().substring(0, 8).toUpperCase();
    mcCalendarRecordManualLinkV01AppendByHeaders_(ss, 'MAILCENTER_CalendarRecordManualLinkSummaries', mcCalendarRecordManualLinkV01SummaryHeaders_(), {
      summaryId: summaryId,
      build: MC_CALENDAR_RECORD_MANUAL_LINK_V01_BUILD,
      webAppUrl: MC_CALENDAR_RECORD_MANUAL_LINK_V01_WEBAPP_URL,
      sourceSheet: MC_CALENDAR_RECORD_MANUAL_LINK_V01_SOURCE_SHEET,
      status: 'SUMMARY_RECORDED',
      summaryText: '수동 recordId/requestId 연결 서버팩 준비 완료. 화면팩에서 후보 선택 UI 연결 예정.',
      nextStage: 'MAILCENTER_CALENDAR_RECORD_MANUAL_LINK_UI_V01',
      createdAt: now,
      createdBy: actor,
      updatedAt: now,
      updatedBy: actor
    });
    result.ok = true;
    result.summaryId = summaryId;
    result.message = 'MailCenter Calendar Record Manual Link V01 Summary 기록 완료';
  } catch (err) {
    result.ok = false;
    result.message = mcCalendarRecordManualLinkV01Err_(err);
  }
  Logger.log(JSON.stringify(result, null, 2));
  return result;
}

function mcCalendarRecordManualLinkV01FindSampleEventId_(ss) {
  var sheet = ss.getSheetByName('MAILCENTER_CalendarEvents');
  if (!sheet || sheet.getLastRow() < 2) return '';
  var values = sheet.getDataRange().getValues();
  var hm = mcCalendarRecordManualLinkV01HeaderMap_(values[0]);
  var idCol = hm.calendarEventId;
  var reqCol = hm.requestId;
  if (idCol === undefined) return '';
  for (var r = 1; r < values.length; r++) {
    var id = String(values[r][idCol] || '').trim();
    var req = reqCol === undefined ? '' : String(values[r][reqCol] || '').trim();
    if (id && !req) return id;
  }
  return String(values[1][idCol] || '').trim();
}

function mcCalendarRecordManualLinkV01BuildMailKeyContext_(ss, calendarEventId) {
  var out = { calendarEventId: calendarEventId, event: {}, link: {}, keys: {} };
  var events = ss.getSheetByName('MAILCENTER_CalendarEvents');
  var links = ss.getSheetByName('MAILCENTER_CalendarMailLinks');
  out.event = mcCalendarRecordManualLinkV01FindRecordById_(events, 'calendarEventId', calendarEventId) || {};
  out.link = mcCalendarRecordManualLinkV01FindRecordById_(links, 'calendarEventId', calendarEventId) || {};
  out.keys.threadId = String(out.link.threadId || '').trim();
  out.keys.messageId = String(out.link.messageId || '').trim();
  out.keys.subject = String(out.link.subject || out.event.eventTitle || '').trim();
  out.keys.fromEmail = String(out.link.fromEmail || '').trim();
  out.keys.toEmail = String(out.link.toEmail || '').trim();
  return out;
}

function mcCalendarRecordManualLinkV01FindCandidatesByContext_(ss, context, limit) {
  limit = limit || 10;
  var source = ss.getSheetByName(MC_CALENDAR_RECORD_MANUAL_LINK_V01_SOURCE_SHEET);
  if (!source || source.getLastRow() < 2) return [];
  var values = source.getDataRange().getValues();
  var headers = values[0];
  var hm = mcCalendarRecordManualLinkV01HeaderMap_(headers);
  var out = [];
  for (var r = 1; r < values.length; r++) {
    var rec = mcCalendarRecordManualLinkV01RowToObject_(headers, values[r]);
    var score = 0;
    var reasons = [];
    var req = String(rec.requestId || rec.recordId || '').trim();
    if (!req) continue;
    var srcThread = String(rec.threadId || rec.gmailThreadId || '').trim();
    var srcMsg = String(rec.messageId || rec.gmailMessageId || '').trim();
    var srcSubject = String(rec.subject || '').trim();
    var srcFrom = String(rec.sender || rec.fromEmail || '').trim();
    var srcTo = String(rec.recipient || rec.toEmail || '').trim();
    if (context.keys.threadId && srcThread && context.keys.threadId === srcThread) { score += 100; reasons.push('threadId'); }
    if (context.keys.messageId && srcMsg && context.keys.messageId === srcMsg) { score += 90; reasons.push('messageId'); }
    if (context.keys.subject && srcSubject && mcCalendarRecordManualLinkV01Norm_(context.keys.subject) === mcCalendarRecordManualLinkV01Norm_(srcSubject)) { score += 30; reasons.push('subject'); }
    if (context.keys.fromEmail && srcFrom && mcCalendarRecordManualLinkV01NormEmail_(context.keys.fromEmail) === mcCalendarRecordManualLinkV01NormEmail_(srcFrom)) { score += 20; reasons.push('fromEmail'); }
    if (context.keys.toEmail && srcTo && mcCalendarRecordManualLinkV01NormEmail_(context.keys.toEmail) === mcCalendarRecordManualLinkV01NormEmail_(srcTo)) { score += 20; reasons.push('toEmail'); }
    if (score > 0) {
      out.push({
        sourceSheet: MC_CALENDAR_RECORD_MANUAL_LINK_V01_SOURCE_SHEET,
        sourceRow: r + 1,
        requestId: req,
        score: score,
        reasons: reasons,
        threadId: srcThread,
        messageId: srcMsg,
        subject: srcSubject,
        sender: srcFrom,
        recipient: srcTo,
        createdAt: rec.createdAt || ''
      });
    }
  }
  out.sort(function(a, b) { return b.score - a.score; });
  return out.slice(0, limit);
}

function mcCalendarRecordManualLinkV01FindRecordById_(sheet, idHeader, idValue) {
  if (!sheet || sheet.getLastRow() < 2) return null;
  var values = sheet.getDataRange().getValues();
  var headers = values[0];
  var hm = mcCalendarRecordManualLinkV01HeaderMap_(headers);
  var idCol = hm[idHeader];
  if (idCol === undefined) return null;
  for (var r = 1; r < values.length; r++) {
    if (String(values[r][idCol] || '').trim() === String(idValue || '').trim()) return mcCalendarRecordManualLinkV01RowToObject_(headers, values[r]);
  }
  return null;
}

function mcCalendarRecordManualLinkV01UpdateById_(ss, sheetName, idHeader, idValue, updates) {
  var sheet = ss.getSheetByName(sheetName);
  if (!sheet) throw new Error(sheetName + ' 시트를 찾지 못했습니다.');
  mcCalendarRecordManualLinkV01EnsureHeaders_(sheet, Object.keys(updates || {}));
  var values = sheet.getDataRange().getValues();
  var headers = values[0];
  var hm = mcCalendarRecordManualLinkV01HeaderMap_(headers);
  var idCol = hm[idHeader];
  if (idCol === undefined) throw new Error(sheetName + '에서 ' + idHeader + ' 헤더를 찾지 못했습니다.');
  var updatedRows = 0;
  for (var r = 1; r < values.length; r++) {
    if (String(values[r][idCol] || '').trim() === String(idValue || '').trim()) {
      Object.keys(updates || {}).forEach(function(key) {
        if (hm[key] !== undefined) sheet.getRange(r + 1, hm[key] + 1).setValue(updates[key]);
      });
      updatedRows++;
    }
  }
  return { updatedRows: updatedRows };
}

function mcCalendarRecordManualLinkV01AppendByHeaders_(ss, sheetName, baseHeaders, record) {
  var sheet = mcCalendarRecordManualLinkV01GetSheetOrCreate_(ss, sheetName, baseHeaders);
  mcCalendarRecordManualLinkV01EnsureHeaders_(sheet, Object.keys(record || {}));
  var headers = sheet.getRange(1, 1, 1, sheet.getLastColumn()).getValues()[0];
  var hm = mcCalendarRecordManualLinkV01HeaderMap_(headers);
  var row = [];
  for (var i = 0; i < headers.length; i++) row.push('');
  Object.keys(record || {}).forEach(function(key) { if (hm[key] !== undefined) row[hm[key]] = record[key]; });
  sheet.appendRow(row);
}

function mcCalendarRecordManualLinkV01GetSheetOrCreate_(ss, name, headers) {
  var sheet = ss.getSheetByName(name);
  if (!sheet) {
    sheet = ss.insertSheet(name);
    sheet.getRange(1, 1, 1, headers.length).setValues([headers]);
    sheet.setFrozenRows(1);
    return sheet;
  }
  if (sheet.getLastRow() < 1 || sheet.getLastColumn() < 1) {
    sheet.getRange(1, 1, 1, headers.length).setValues([headers]);
    sheet.setFrozenRows(1);
  }
  mcCalendarRecordManualLinkV01EnsureHeaders_(sheet, headers);
  return sheet;
}

function mcCalendarRecordManualLinkV01EnsureHeaders_(sheet, requiredHeaders) {
  var lastCol = Math.max(sheet.getLastColumn(), 1);
  var headers = sheet.getRange(1, 1, 1, lastCol).getValues()[0];
  var hm = mcCalendarRecordManualLinkV01HeaderMap_(headers);
  var add = [];
  (requiredHeaders || []).forEach(function(h) { if (h && hm[h] === undefined) add.push(h); });
  if (add.length) sheet.getRange(1, headers.length + 1, 1, add.length).setValues([add]);
}

function mcCalendarRecordManualLinkV01OpenMaster_() {
  var setup = SpreadsheetApp.openById(MC_CALENDAR_RECORD_MANUAL_LINK_V01_SETUP_DB_ID);
  var sheet = setup.getSheetByName(MC_CALENDAR_RECORD_MANUAL_LINK_V01_CONFIG_SHEET);
  if (!sheet) throw new Error('SystemConfig 시트를 찾지 못했습니다.');
  var values = sheet.getDataRange().getValues();
  if (!values || values.length < 2) throw new Error('SystemConfig 데이터가 비어 있습니다.');
  var hm = mcCalendarRecordManualLinkV01HeaderMap_(values[0]);
  var keyCol = mcCalendarRecordManualLinkV01PickIndex_(hm, ['CONFIG_KEY','configKey','key','name']);
  var valCol = mcCalendarRecordManualLinkV01PickIndex_(hm, ['VALUE','configValue','value','spreadsheetId']);
  if (keyCol < 0 || valCol < 0) throw new Error('SystemConfig CONFIG_KEY/VALUE 헤더를 찾지 못했습니다.');
  var masterId = '';
  for (var r = 1; r < values.length; r++) {
    var key = String(values[r][keyCol] || '').trim();
    if (key === 'FEELHAUS_DB_MASTER' || key === 'FEELHAUS_DB_MASTER_ID' || key === 'MASTER_DB_ID') {
      masterId = String(values[r][valCol] || '').trim();
      break;
    }
  }
  if (!masterId) throw new Error('SystemConfig에서 FEELHAUS_DB_MASTER ID를 찾지 못했습니다.');
  return SpreadsheetApp.openById(masterId);
}

function mcCalendarRecordManualLinkV01HeaderMap_(headers) {
  var out = {};
  (headers || []).forEach(function(h, i) { var k = String(h || '').trim(); if (k) out[k] = i; });
  return out;
}
function mcCalendarRecordManualLinkV01PickIndex_(hm, keys) { for (var i = 0; i < keys.length; i++) if (hm[keys[i]] !== undefined) return hm[keys[i]]; return -1; }
function mcCalendarRecordManualLinkV01RowToObject_(headers, row) { var obj = {}; (headers || []).forEach(function(h, i) { var k = String(h || '').trim(); if (k) obj[k] = row[i]; }); return obj; }
function mcCalendarRecordManualLinkV01RequiredHeadersReady_(sheet, headers) { return mcCalendarRecordManualLinkV01MissingHeaders_(sheet, headers).length === 0; }
function mcCalendarRecordManualLinkV01MissingHeaders_(sheet, headers) { if (!sheet) return headers || []; var hm = mcCalendarRecordManualLinkV01HeaderMap_(sheet.getRange(1,1,1,Math.max(sheet.getLastColumn(),1)).getValues()[0]); return (headers || []).filter(function(h) { return hm[h] === undefined; }); }
function mcCalendarRecordManualLinkV01MissingHeadersText_(sheet, headers) { return 'missing=' + JSON.stringify(mcCalendarRecordManualLinkV01MissingHeaders_(sheet, headers)); }
function mcCalendarRecordManualLinkV01RequiredAnyHeadersReady_(sheet, groups) { if (!sheet) return false; var hm = mcCalendarRecordManualLinkV01HeaderMap_(sheet.getRange(1,1,1,Math.max(sheet.getLastColumn(),1)).getValues()[0]); return (groups || []).every(function(group) { return group.some(function(h) { return hm[h] !== undefined; }); }); }
function mcCalendarRecordManualLinkV01HeaderListText_(sheet) { if (!sheet) return ''; return JSON.stringify(sheet.getRange(1,1,1,Math.max(sheet.getLastColumn(),1)).getValues()[0]).slice(0,900); }
function mcCalendarRecordManualLinkV01LogHeaders_() { return ['calendarLogId','calendarEventId','provider','actionType','resultStatus','providerEventId','errorCode','errorMessage','requestPayloadSummary','responseSummary','createdAt','createdBy']; }
function mcCalendarRecordManualLinkV01LockHeaders_() { return ['lockId','build','backupName','backupSpreadsheetId','webAppUrl','sourceSheet','status','statusReason','copiedSheetsJson','createdAt','createdBy','updatedAt','updatedBy']; }
function mcCalendarRecordManualLinkV01SummaryHeaders_() { return ['summaryId','build','webAppUrl','sourceSheet','status','summaryText','nextStage','createdAt','createdBy','updatedAt','updatedBy']; }
function mcCalendarRecordManualLinkV01Norm_(v) { return String(v || '').toLowerCase().replace(/\s+/g, ' ').trim(); }
function mcCalendarRecordManualLinkV01NormEmail_(v) { return String(v || '').toLowerCase().replace(/[<>]/g, '').trim(); }
function mcCalendarRecordManualLinkV01Actor_() { return String(Session.getActiveUser().getEmail() || 'MAILCENTER_ADMIN').trim() || 'MAILCENTER_ADMIN'; }
function mcCalendarRecordManualLinkV01Now_() { return Utilities.formatDate(new Date(), Session.getScriptTimeZone() || 'Asia/Seoul', 'yyyy-MM-dd HH:mm:ss'); }
function mcCalendarRecordManualLinkV01Err_(err) { return err && err.message ? err.message : String(err); }


/**
 * WebApp-safe aliases for Manual Link UI Recovery V02.
 * These wrappers keep the browser call stable even if the internal function names change later.
 */
function mcCalendarRecordManualLinkV01SearchCandidatesWeb(payload) {
  return mcCalendarRecordManualLinkV01SearchCandidates(payload || {});
}

function mcCalendarRecordManualLinkV01ApplyWeb(payload) {
  return mcCalendarRecordManualLinkV01Apply(payload || {});
}

function runMcCalendarRecordManualLinkV01WebAliasSmoke() {
  var result = {
    ok: true,
    build: MC_CALENDAR_RECORD_MANUAL_LINK_V01_BUILD,
    action: 'runMcCalendarRecordManualLinkV01WebAliasSmoke',
    generatedAt: mcCalendarRecordManualLinkV01Now_(),
    noWriteMode: true,
    checks: []
  };
  function check(key, ok, message) {
    result.checks.push({ key: key, ok: !!ok, message: message });
    if (!ok) result.ok = false;
  }
  check('SearchAliasReady', typeof mcCalendarRecordManualLinkV01SearchCandidatesWeb === 'function', '후보 조회 Web alias 확인');
  check('ApplyAliasReady', typeof mcCalendarRecordManualLinkV01ApplyWeb === 'function', '수동 연결 Web alias 확인');
  check('OriginalSearchReady', typeof mcCalendarRecordManualLinkV01SearchCandidates === 'function', '원본 후보 조회 함수 확인');
  check('OriginalApplyReady', typeof mcCalendarRecordManualLinkV01Apply === 'function', '원본 수동 연결 함수 확인');
  result.message = result.ok ? 'Manual Link Web Alias Smoke 통과' : 'Manual Link Web Alias 점검 필요';
  Logger.log(JSON.stringify(result, null, 2));
  return result;
}

