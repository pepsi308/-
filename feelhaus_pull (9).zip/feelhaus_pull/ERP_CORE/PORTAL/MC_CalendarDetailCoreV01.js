/**
 * FEELHAUS MailCenter Calendar Detail Core V01
 * Build: MAILCENTER_CALENDAR_DETAIL_CORE_V01_20260521
 * Purpose:
 * - Server-only detail lookup core for MailCenter calendar events
 * - Read calendar event, mail link, and logs by calendarEventId
 * - Do not modify router/menu/html/calendar UI files
 */
var MC_CALENDAR_DETAIL_CORE_V01_BUILD = 'MAILCENTER_CALENDAR_DETAIL_CORE_V01_20260521';
var PORTAL_CALENDAR_SAFE01B_R10_CHANGE_HISTORY_MODAL_BUILD = 'PORTAL_CALENDAR_SAFE01B_R10_CHANGE_HISTORY_MODAL_20260603';
var PORTAL_CALENDAR_SAFE01B_R10B_CHANGE_HISTORY_DISPLAY_FIX_BUILD = 'PORTAL_CALENDAR_SAFE01B_R10B_CHANGE_HISTORY_DISPLAY_FIX_20260603';
var PORTAL_CALENDAR_SAFE01B_R10C_DETAIL_BINDING_FIX_BUILD = 'PORTAL_CALENDAR_SAFE01B_R10C_DETAIL_BINDING_FIX_20260603';
var PORTAL_CALENDAR_SAFE01B_R11_PAGE_AUTO_REFRESH_KST_BUILD = 'PORTAL_CALENDAR_SAFE01B_R11_PAGE_AUTO_REFRESH_KST_20260603';
var PORTAL_CALENDAR_SAFE01B_R10K2_EVENT_MASTER_LINK_BUILD = 'PORTAL_CALENDAR_SAFE01B_R10K2_EVENT_MASTER_LINK_DETAIL_20260604';
var MC_CALENDAR_DETAIL_CORE_V01_SETUP_DB_ID = '17VMSpgSZCvIrUlgcw8yCNcnl8WQWo2IcRf5tDCcuJGM';
var MC_CALENDAR_DETAIL_CORE_V01_CONFIG_SHEET = 'SystemConfig';
var MC_CALENDAR_DETAIL_CORE_V01_WEBAPP_URL = 'https://script.google.com/a/macros/feelhausfair.com/s/AKfycbxCyFE7zf4vE8nsfjOeWX0pC56SqU84gm8ie8Txa3qHQGEusJCZeljzCdYeOmZxUVYvjA/exec';

function runMcCalendarDetailCoreV01Smoke() {
  var result = {
    ok: true,
    build: MC_CALENDAR_DETAIL_CORE_V01_BUILD,
    action: 'runMcCalendarDetailCoreV01Smoke',
    generatedAt: mcCalendarDetailCoreV01Now_(),
    noWriteMode: true,
    checks: []
  };
  function check(key, ok, message, detail) {
    result.checks.push({ key: key, ok: !!ok, message: message, detail: detail || '' });
    if (!ok) result.ok = false;
  }
  try {
    check('GetDetailReady', typeof mcCalendarDetailCoreV01GetDetail === 'function', '일정 상세 조회 함수 확인');
    check('OpenMasterReady', !!mcCalendarDetailCoreV01OpenMaster_(), 'SystemConfig -> FEELHAUS_DB_MASTER 연결 확인');
    check('HeaderMapReady', typeof mcCalendarDetailCoreV01HeaderMap_ === 'function', '헤더맵 함수 확인');
    check('WebAppUrlReady', !!MC_CALENDAR_DETAIL_CORE_V01_WEBAPP_URL, 'WebApp 절대주소 확인', MC_CALENDAR_DETAIL_CORE_V01_WEBAPP_URL);
    check('NoRouterMenuHtmlTouch', true, '본 파일은 라우터/메뉴/HTML 변경 없음');
    result.message = result.ok ? 'MailCenter Calendar Detail Core V01 Smoke 통과' : 'MailCenter Calendar Detail Core V01 점검 필요';
  } catch (err) {
    result.ok = false;
    result.message = mcCalendarDetailCoreV01Err_(err);
  }
  Logger.log(JSON.stringify(result, null, 2));
  return result;
}

function runMcCalendarDetailCoreV01DryRun() {
  var result = {
    ok: true,
    build: MC_CALENDAR_DETAIL_CORE_V01_BUILD,
    action: 'runMcCalendarDetailCoreV01DryRun',
    generatedAt: mcCalendarDetailCoreV01Now_(),
    noWriteMode: true,
    sampleCalendarEventId: '',
    detail: null,
    checks: []
  };
  function check(key, ok, message, detail) {
    result.checks.push({ key: key, ok: !!ok, message: message, detail: detail || '' });
    if (!ok) result.ok = false;
  }
  try {
    var ss = mcCalendarDetailCoreV01OpenMaster_();
    var eventSheet = ss.getSheetByName('MAILCENTER_CalendarEvents');
    check('CalendarEventsSheetReady', !!eventSheet, 'MAILCENTER_CalendarEvents 시트 확인');
    var sampleId = mcCalendarDetailCoreV01FindFirstEventId_(eventSheet);
    result.sampleCalendarEventId = sampleId;
    check('SampleEventReady', !!sampleId, '상세 조회 샘플 calendarEventId 확인', sampleId);
    if (sampleId) {
      var detail = mcCalendarDetailCoreV01GetDetail({ calendarEventId: sampleId });
      result.detail = {
        ok: detail.ok,
        calendarEventId: detail.calendarEventId,
        hasEvent: !!detail.event,
        mailLinkCount: detail.mailLinks ? detail.mailLinks.length : 0,
        logCount: detail.logs ? detail.logs.length : 0
      };
      check('DetailCallable', detail && detail.ok, '일정 상세 조회 호출 확인', 'mailLinks=' + (detail.mailLinks || []).length + ', logs=' + (detail.logs || []).length);
    }
    check('NoWriteModeConfirmed', true, 'Dry Run은 읽기 전용, 시트 쓰기 없음');
    result.message = result.ok ? 'MailCenter Calendar Detail Core V01 Dry Run 통과' : 'MailCenter Calendar Detail Core V01 Dry Run 점검 필요';
  } catch (err) {
    result.ok = false;
    result.message = mcCalendarDetailCoreV01Err_(err);
  }
  Logger.log(JSON.stringify(result, null, 2));
  return result;
}

function mcCalendarDetailCoreV01GetDetail(payload) {
  var result = {
    ok: false,
    build: MC_CALENDAR_DETAIL_CORE_V01_BUILD,
    action: 'mcCalendarDetailCoreV01GetDetail',
    generatedAt: mcCalendarDetailCoreV01Now_(),
    calendarEventId: '',
    event: null,
    record: null,
    sourceSheet: '',
    rowNumber: 0,
    mailLinks: [],
    logs: [],
    changeLogs: [],
    changeHistory: null,
    eventMaster: null,
    eventMasterSourceSheet: '',
    message: ''
  };
  try {
    payload = payload || {};
    var calendarEventId = String(payload.calendarEventId || payload.calendarId || '').trim();
    if (!calendarEventId) throw new Error('calendarEventId 값이 필요합니다.');
    result.calendarEventId = calendarEventId;

    var ss = mcCalendarDetailCoreV01OpenMaster_();
    var foundEventR10C = mcCalendarDetailCoreV01FindLatestEventRecordR10C_(ss, calendarEventId);
    result.event = foundEventR10C.record;
    result.record = foundEventR10C.record;
    result.sourceSheet = foundEventR10C.sheetName;
    result.rowNumber = foundEventR10C.rowNumber;
    if (!result.record) throw new Error('일정 데이터를 찾지 못했습니다: ' + calendarEventId);
    var linkedEventIdR10K2 = mcCalendarDetailCoreV01PickTextR10B_(result.record.eventId, result.record.relatedEventId, result.record.sourceId);
    if (linkedEventIdR10K2) {
      var eventMasterR10K2 = mcCalendarDetailCoreV01FindEventMasterR10K2_(ss, linkedEventIdR10K2);
      result.eventMaster = eventMasterR10K2.record;
      result.eventMasterSourceSheet = eventMasterR10K2.sheetName || '';
      if (result.eventMaster) result.record.__eventMasterR10K2 = result.eventMaster;
    }
    result.mailLinks = mcCalendarDetailCoreV01FindManyAcrossSheetsR10C_(ss, ['MAILCENTER_CalendarMailLinks', 'CalendarMailLinks'], ['calendarEventId', 'calendarId'], calendarEventId);
    result.logs = mcCalendarDetailCoreV01FindManyAcrossSheetsR10C_(ss, ['MAILCENTER_CalendarLogs', 'CalendarLogs'], ['calendarEventId'], calendarEventId);
    result.changeLogs = mcCalendarDetailCoreV01FindManyAcrossSheetsR10C_(ss, ['MAILCENTER_CalendarChangeLogs', 'CalendarChangeLogs'], ['calendarEventId'], calendarEventId);
    result.changeLogs = mcCalendarDetailCoreV01SortChangeLogsR10_(result.changeLogs).slice(0, 10);
    result.changeHistory = mcCalendarDetailCoreV01BuildChangeHistorySummaryR10B_(result.record, result.changeLogs);
    result.record.changeHistory = result.changeHistory;
    result.event = result.record;
    result.ok = true;
    result.message = '일정 상세 조회 완료';
  } catch (err) {
    result.ok = false;
    result.message = mcCalendarDetailCoreV01Err_(err);
  }
  return result;
}

function mcCalendarDetailCoreV01FindFirstEventId_(sheet) {
  if (!sheet || sheet.getLastRow() < 2) return '';
  var values = sheet.getDataRange().getValues();
  var hm = mcCalendarDetailCoreV01HeaderMap_(values[0]);
  var idx = hm.calendarEventId;
  if (idx === undefined) return '';
  for (var r = 1; r < values.length; r++) {
    var id = String(values[r][idx] || '').trim();
    if (id) return id;
  }
  return '';
}

function mcCalendarDetailCoreV01FindOneByKey_(ss, sheetName, key, value) {
  var rows = mcCalendarDetailCoreV01FindManyByAnyKey_(ss, sheetName, [key], value);
  return rows.length ? rows[0] : null;
}

function mcCalendarDetailCoreV01FindLatestEventRecordR10C_(ss, calendarEventId) {
  var rows = [];
  ['MAILCENTER_CalendarEvents', 'CalendarEvents'].forEach(function(sheetName) {
    mcCalendarDetailCoreV01FindManyByAnyKey_(ss, sheetName, ['calendarEventId', 'calendarId'], calendarEventId).forEach(function(row) {
      row.__sourceSheet = row.__sourceSheet || sheetName;
      rows.push(row);
    });
  });
  if (!rows.length) return { record: null, sheetName: '', rowNumber: 0 };
  rows.sort(function(a, b) {
    var ar = mcCalendarDetailCoreV01DateRankR10C_(a.updatedAt || a.createdAt || a.startAt);
    var br = mcCalendarDetailCoreV01DateRankR10C_(b.updatedAt || b.createdAt || b.startAt);
    if (ar !== br) return br - ar;
    return Number(b.__rowNumber || 0) - Number(a.__rowNumber || 0);
  });
  var record = rows[0];
  var sheetName = String(record.__sourceSheet || '');
  var rowNumber = Number(record.__rowNumber || 0);
  delete record.__sourceSheet;
  delete record.__rowNumber;
  return { record: record, sheetName: sheetName, rowNumber: rowNumber };
}

function mcCalendarDetailCoreV01FindManyAcrossSheetsR10C_(ss, sheetNames, keys, value) {
  var out = [];
  (sheetNames || []).forEach(function(sheetName) {
    mcCalendarDetailCoreV01FindManyByAnyKey_(ss, sheetName, keys, value).forEach(function(row) {
      row.__sourceSheet = row.__sourceSheet || sheetName;
      out.push(row);
    });
  });
  return out;
}

function mcCalendarDetailCoreV01FindManyByAnyKey_(ss, sheetName, keys, value) {
  var out = [];
  var sheet = ss.getSheetByName(sheetName);
  if (!sheet || sheet.getLastRow() < 2) return out;
  var values = sheet.getDataRange().getValues();
  var headers = values[0];
  var hm = mcCalendarDetailCoreV01HeaderMap_(headers);
  var indexes = [];
  (keys || []).forEach(function(k) {
    if (hm.hasOwnProperty(k)) indexes.push(hm[k]);
  });
  if (!indexes.length) return out;
  for (var r = 1; r < values.length; r++) {
    var matched = false;
    for (var i = 0; i < indexes.length; i++) {
      if (String(values[r][indexes[i]] || '').trim() === String(value || '').trim()) {
        matched = true;
        break;
      }
    }
    if (matched) {
      var obj = mcCalendarDetailCoreV01RowToObject_(headers, values[r]);
      obj.__sourceSheet = sheetName;
      obj.__rowNumber = r + 1;
      out.push(obj);
    }
  }
  return out;
}

function mcCalendarDetailCoreV01RowToObject_(headers, row) {
  var obj = {};
  (headers || []).forEach(function(h, i) {
    var key = String(h || '').trim();
    if (key) obj[key] = mcCalendarDetailCoreV01CellToJsonSafeR10C_(row[i]);
  });
  return obj;
}

function mcCalendarDetailCoreV01CellToJsonSafeR10C_(v) {
  if (v === null || v === undefined) return '';
  if (Object.prototype.toString.call(v) === '[object Date]' && !isNaN(v.getTime())) {
    var tz = 'Asia/Seoul';
    try { tz = Session.getScriptTimeZone() || 'Asia/Seoul'; } catch (ignore) {}
    return Utilities.formatDate(v, tz, 'yyyy-MM-dd HH:mm:ss');
  }
  return v;
}

function mcCalendarDetailCoreV01DateRankR10C_(v) {
  if (v === null || v === undefined || v === '') return 0;
  if (Object.prototype.toString.call(v) === '[object Date]' && !isNaN(v.getTime())) return v.getTime();
  var s = String(v || '').trim();
  if (!s) return 0;
  var d = new Date(s.replace(' ', 'T'));
  if (!isNaN(d.getTime())) return d.getTime();
  d = new Date(s);
  return isNaN(d.getTime()) ? 0 : d.getTime();
}


function mcCalendarDetailCoreV01SortChangeLogsR10_(rows) {
  rows = rows || [];
  return rows.sort(function(a, b) {
    var av = String((a && (a.createdAt || a.updatedAt)) || '');
    var bv = String((b && (b.createdAt || b.updatedAt)) || '');
    return av < bv ? 1 : (av > bv ? -1 : 0);
  });
}

function mcCalendarDetailCoreV01PickTextR10B_() {
  for (var i = 0; i < arguments.length; i++) {
    var v = arguments[i];
    if (v === null || v === undefined) continue;
    var s = String(v).trim();
    if (s && s !== '[]' && s !== '{}' && s.toLowerCase() !== 'null' && s.toLowerCase() !== 'undefined') return s;
  }
  return '';
}

function mcCalendarDetailCoreV01BuildChangeHistorySummaryR10B_(eventRow, changeLogs) {
  eventRow = eventRow || {};
  changeLogs = changeLogs || [];
  var latestLog = changeLogs.length ? changeLogs[0] : {};
  return {
    build: PORTAL_CALENDAR_SAFE01B_R10B_CHANGE_HISTORY_DISPLAY_FIX_BUILD,
    source: changeLogs.length ? 'MAILCENTER_CalendarChangeLogs' : 'MAILCENTER_CalendarEvents',
    hasChangeLogs: changeLogs.length > 0,
    calendarEventId: mcCalendarDetailCoreV01PickTextR10B_(eventRow.calendarEventId, latestLog.calendarEventId),
    updatedAt: mcCalendarDetailCoreV01PickTextR10B_(latestLog.createdAt, latestLog.updatedAt, eventRow.updatedAt),
    updatedBy: mcCalendarDetailCoreV01PickTextR10B_(latestLog.createdBy, latestLog.updatedBy, eventRow.updatedBy),
    updatedByName: mcCalendarDetailCoreV01PickTextR10B_(latestLog.createdByName, latestLog.updatedByName, eventRow.updatedByName),
    updatedByEmail: mcCalendarDetailCoreV01PickTextR10B_(latestLog.createdByEmail, latestLog.updatedByEmail, eventRow.updatedByEmail, latestLog.createdBy, latestLog.updatedBy, eventRow.updatedBy),
    updatedByEmployeeId: mcCalendarDetailCoreV01PickTextR10B_(latestLog.createdByEmployeeId, latestLog.updatedByEmployeeId, eventRow.updatedByEmployeeId),
    actorSource: mcCalendarDetailCoreV01PickTextR10B_(latestLog.actorSource, latestLog.updatedActorSource, eventRow.updatedActorSource),
    changeReason: mcCalendarDetailCoreV01PickTextR10B_(latestLog.changeReason, latestLog.statusReason, eventRow.changeReason, eventRow.statusReason),
    lastChangedFields: mcCalendarDetailCoreV01PickTextR10B_(latestLog.changedFields, latestLog.lastChangedFields, eventRow.lastChangedFields),
    beforeSnapshot: mcCalendarDetailCoreV01PickTextR10B_(latestLog.beforeSnapshot),
    afterSnapshot: mcCalendarDetailCoreV01PickTextR10B_(latestLog.afterSnapshot)
  };
}

function mcCalendarDetailCoreV01R10ChangeHistoryMarker_() {
  return {
    ok: true,
    build: PORTAL_CALENDAR_SAFE01B_R10_CHANGE_HISTORY_MODAL_BUILD,
    r10bBuild: PORTAL_CALENDAR_SAFE01B_R10B_CHANGE_HISTORY_DISPLAY_FIX_BUILD,
    r10cBuild: PORTAL_CALENDAR_SAFE01B_R10C_DETAIL_BINDING_FIX_BUILD,
    detailFunctionReady: typeof mcCalendarDetailCoreV01GetDetail === 'function',
    changeLogSheetName: 'MAILCENTER_CalendarChangeLogs',
    changeLogsReturned: true,
    changeHistorySummaryReady: typeof mcCalendarDetailCoreV01BuildChangeHistorySummaryR10B_ === 'function',
    ledgerFallbackFields: ['changeReason','lastChangedFields','updatedAt','updatedByName','updatedByEmail'],
    latestRecordLookup: ['MAILCENTER_CalendarEvents','CalendarEvents'],
    recordAliasReturned: true,
    readOnly: true
  };
}

function mcCalendarDetailCoreV01R11PageRefreshMarker_() {
  return {
    ok: true,
    build: PORTAL_CALENDAR_SAFE01B_R11_PAGE_AUTO_REFRESH_KST_BUILD,
    detailFunctionReady: typeof mcCalendarDetailCoreV01GetDetail === 'function',
    forceFreshPayloadAccepted: true,
    changeHistorySummaryReady: typeof mcCalendarDetailCoreV01BuildChangeHistorySummaryR10B_ === 'function',
    ledgerFallbackFields: ['changeReason','lastChangedFields','updatedAt','updatedByName','updatedByEmail'],
    readOnly: true
  };
}

function mcCalendarDetailCoreV01FindEventMasterR10K2_(ss, eventId) {
  var out = { record:null, sheetName:'', rowNumber:0 };
  if (!ss || !eventId) return out;
  var names = ['ERP_행사관리','행사관리','ERP_Events','ERP_EventMaster','ERP_Event','ERP_행사','EVENT_MASTER','EVENTS','Events','EventMaster','EventList','EventCenterEvents','행사'];
  for (var i = 0; i < names.length; i++) {
    var sh = ss.getSheetByName(names[i]);
    if (!sh || sh.getLastRow() < 2) continue;
    var values = sh.getDataRange().getValues();
    var headers = values[0];
    var hm = mcCalendarDetailCoreV01HeaderMap_(headers);
    var eventIdHeader = mcCalendarDetailCoreV01PickHeaderR10K2_(hm, ['eventId','eventID','event_id','행사ID','행사Id','행사id']);
    if (!eventIdHeader) continue;
    var col = hm[eventIdHeader];
    for (var r = 1; r < values.length; r++) {
      if (String(values[r][col] || '').trim() === String(eventId || '').trim()) {
        var record = mcCalendarDetailCoreV01RowToObject_(headers, values[r]);
        record.__sourceSheetName = sh.getName();
        record.__rowNumber = r + 1;
        return { record:record, sheetName:sh.getName(), rowNumber:r + 1 };
      }
    }
  }
  return out;
}
function mcCalendarDetailCoreV01PickHeaderR10K2_(hm, keys) {
  for (var i = 0; i < keys.length; i++) if (hm.hasOwnProperty(keys[i])) return keys[i];
  return '';
}

function mcCalendarDetailCoreV01OpenMaster_() {
  var setup = SpreadsheetApp.openById(MC_CALENDAR_DETAIL_CORE_V01_SETUP_DB_ID);
  var sheet = setup.getSheetByName(MC_CALENDAR_DETAIL_CORE_V01_CONFIG_SHEET);
  if (!sheet) throw new Error('SystemConfig 시트를 찾지 못했습니다.');
  var values = sheet.getDataRange().getValues();
  if (!values || values.length < 2) throw new Error('SystemConfig 데이터가 비어 있습니다.');
  var hm = mcCalendarDetailCoreV01HeaderMap_(values[0]);
  var keyCol = mcCalendarDetailCoreV01PickIndex_(hm, ['CONFIG_KEY','configKey','key','name']);
  var valCol = mcCalendarDetailCoreV01PickIndex_(hm, ['VALUE','configValue','value','spreadsheetId']);
  if (keyCol < 0 || valCol < 0) throw new Error('SystemConfig CONFIG_KEY/VALUE 헤더를 찾지 못했습니다.');
  var masterId = '';
  for (var r = 1; r < values.length; r++) {
    var key = String(values[r][keyCol] || '').trim();
    if (key === 'FEELHAUS_DB_MASTER' || key === 'FEELHAUS_DB_MASTER_ID' || key === 'MASTER_DB_ID') {
      masterId = String(values[r][valCol] || '').trim();
      break;
    }
  }
  if (!masterId) throw new Error('SystemConfig에서 FEELHAUS_DB_MASTER ID를 찾지 못했습니다.');
  return SpreadsheetApp.openById(masterId);
}

function mcCalendarDetailCoreV01HeaderMap_(headers) {
  var out = {};
  (headers || []).forEach(function(h, i) {
    var key = String(h || '').trim();
    if (key) out[key] = i;
  });
  return out;
}

function mcCalendarDetailCoreV01PickIndex_(hm, keys) {
  for (var i = 0; i < keys.length; i++) if (hm.hasOwnProperty(keys[i])) return hm[keys[i]];
  return -1;
}

function mcCalendarDetailCoreV01Now_() {
  return Utilities.formatDate(new Date(), Session.getScriptTimeZone() || 'Asia/Seoul', 'yyyy-MM-dd HH:mm:ss');
}

function mcCalendarDetailCoreV01Err_(err) {
  return err && err.message ? err.message : String(err);
}
