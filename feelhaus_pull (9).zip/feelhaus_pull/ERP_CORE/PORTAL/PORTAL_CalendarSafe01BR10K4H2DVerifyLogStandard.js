/**
 * PORTAL_CALENDAR_SAFE01B_R10K4H2D_VERIFY_LOG_STANDARD_20260604
 * Purpose: Standardize verification logging so Apps Script execution logs always show JSON_COMPACT_RESULT.
 * Safety: READ_ONLY_VERIFY_LOG_ONLY_NO_SHEET_PROVIDER_WRITE
 */

var PORTAL_CALENDAR_SAFE01B_R10K4H2D_VERIFY_LOG_STANDARD_20260604 = true;

function fhPortalVerifyLogStandard_(label, result) {
  var safeResult = result || { ok: false, fatal: ['emptyVerifyResult'], message: 'Verify returned empty result.' };
  try {
    Logger.log('JSON_COMPACT_RESULT: ' + JSON.stringify(safeResult));
  } catch (err) {
    Logger.log('JSON_COMPACT_RESULT: ' + String(safeResult));
  }
  return safeResult;
}

function fhPortalVerifyCallAndLog_(fnName) {
  var result;
  try {
    if (typeof this[fnName] !== 'function') {
      result = {
        ok: false,
        build: 'PORTAL_CALENDAR_SAFE01B_R10K4H2D_VERIFY_LOG_STANDARD_20260604',
        action: 'fhPortalVerifyCallAndLog_',
        requestedFunction: fnName,
        fatal: ['verifyFunctionNotFound'],
        message: 'Verify function not found: ' + fnName
      };
      return fhPortalVerifyLogStandard_(fnName, result);
    }
    result = this[fnName]();
    return fhPortalVerifyLogStandard_(fnName, result);
  } catch (err) {
    result = {
      ok: false,
      build: 'PORTAL_CALENDAR_SAFE01B_R10K4H2D_VERIFY_LOG_STANDARD_20260604',
      action: 'fhPortalVerifyCallAndLog_',
      requestedFunction: fnName,
      fatal: ['verifyException'],
      diagnostics: {
        error: String(err && err.stack ? err.stack : err)
      },
      message: 'Verify exception: ' + String(err && err.message ? err.message : err)
    };
    return fhPortalVerifyLogStandard_(fnName, result);
  }
}

function runPortalCalendarLatestVerifyLog() {
  return fhPortalVerifyCallAndLog_('portalCalendarSafe01BR10K4IManualModalV02RebuildVerify');
}

function runPortalCalendarH2CVerifyLog() {
  return fhPortalVerifyCallAndLog_('portalCalendarSafe01BR10K4H2CSaveUxAutoRefreshPauseVerify');
}

function runPortalCalendarH2BVerifyLog() {
  return fhPortalVerifyCallAndLog_('portalCalendarSafe01BR10K4H2BVerify');
}

function runPortalCalendarH2VerifyLog() {
  return fhPortalVerifyCallAndLog_('portalCalendarSafe01BR10K4H2FullInputFieldMapVerify');
}

function portalCalendarSafe01BR10K4H2DVerifyLogStandardVerify() {
  var result = {
    ok: true,
    build: 'PORTAL_CALENDAR_SAFE01B_R10K4H2D_VERIFY_LOG_STANDARD_20260604',
    baseBuild: 'PORTAL_CALENDAR_SAFE01B_R10K4I_MANUAL_MODAL_V02_REBUILD_20260604',
    action: 'portalCalendarSafe01BR10K4H2DVerifyLogStandardVerify',
    safety: 'READ_ONLY_VERIFY_LOG_ONLY_NO_SHEET_PROVIDER_WRITE',
    checks: {
      loggerStandardReady: typeof fhPortalVerifyLogStandard_ === 'function',
      latestLogWrapperReady: typeof runPortalCalendarLatestVerifyLog === 'function',
      h2cLogWrapperReady: typeof runPortalCalendarH2CVerifyLog === 'function',
      h2bLogWrapperReady: typeof runPortalCalendarH2BVerifyLog === 'function',
      h2LogWrapperReady: typeof runPortalCalendarH2VerifyLog === 'function'
    },
    fatal: [],
    message: 'Verify log standard wrapper is ready. Run runPortalCalendarLatestVerifyLog to print JSON_COMPACT_RESULT.'
  };
  var keys = Object.keys(result.checks);
  for (var i = 0; i < keys.length; i++) {
    if (!result.checks[keys[i]]) result.fatal.push(keys[i]);
  }
  result.ok = result.fatal.length === 0;
  return fhPortalVerifyLogStandard_('portalCalendarSafe01BR10K4H2DVerifyLogStandardVerify', result);
}
