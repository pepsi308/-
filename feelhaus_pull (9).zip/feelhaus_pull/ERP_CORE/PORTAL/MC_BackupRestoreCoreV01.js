/**
 * FEELHAUS MailCenter Backup / Restore V01
 * Build: MC_BACKUP_RESTORE_V01_20260520
 *
 * Scope:
 * - MailCenter 안정본 보호용 백업/복구 센터
 * - SystemConfig: CONFIG_KEY / VALUE 고정
 * - MASTER: CONFIG_KEY = FEELHAUS_DB_MASTER
 * - V01 restore는 승인문구 기반으로 잠금
 */

var MC_BACKUP_RESTORE_V01_BUILD = 'MC_BACKUP_RESTORE_V02_20260520';
var MC_BACKUP_RESTORE_V01_SETUP_DB_ID = '17VMSpgSZCvIrUlgcw8yCNcnl8WQWo2IcRf5tDCcuJGM';
var MC_BACKUP_RESTORE_V01_CONFIG_SHEET_NAME = 'SystemConfig';
var MC_BACKUP_RESTORE_V01_MASTER_KEY = 'FEELHAUS_DB_MASTER';
var MC_BACKUP_RESTORE_V01_BACKUP_FOLDER_KEY = 'BACKUP_DB_FOLDER_ID';
var MC_BACKUP_RESTORE_V01_WEBAPP_URL = 'https://script.google.com/macros/s/AKfycbxCyFE7zf4vE8nsfjOeWX0pC56SqU84gm8ie8Txa3qHQGEusJCZeljzCdYeOmZxUVYvjA/exec';

var MC_BACKUP_RESTORE_V01_SHEETS = [
  'MailCenter_Accounts',
  'MailCenter_SendLogs',
  'MailCenter_ComposeLogs',
  'MailCenter_AuditLogs',
  'MailCenter_Templates',
  'MailCenter_Attachments',
  'MailCenter_AttachmentLibrary',
  'MailCenter_ApprovalLogs'
];

function runMcBackupRestoreV01Smoke() {
  var result = {
    ok: false,
    build: MC_BACKUP_RESTORE_V01_BUILD,
    action: 'runMcBackupRestoreV01Smoke',
    generatedAt: mcBackupRestoreV01Now_(),
    message: '',
    checks: []
  };

  try {
    result.checks.push({key:'CoreReady', ok: typeof mcBackupRestoreV01GetData === 'function', message:'Backup/Restore Core 데이터 함수 확인'});
    result.checks.push({key:'HandleGetReady', ok: typeof mcBackupRestoreV01HandleGet === 'function', message:'Backup/Restore 화면 핸들러 확인'});
    var cfg = mcBackupRestoreV01ReadConfig_();
    result.checks.push({key:'ConfigReady', ok: !!cfg.masterId, message:'SystemConfig CONFIG_KEY/VALUE 및 FEELHAUS_DB_MASTER 확인'});
    result.checks.push({key:'BackupFolderReady', ok: !!cfg.backupFolderId, message:'BACKUP_DB_FOLDER_ID 확인'});
    var folderCheck = mcBackupRestoreV01CheckBackupFolder_();
    result.checks.push({key:'BackupFolderOpenReady', ok: !!folderCheck.ok, message: folderCheck.message});
    result.checks.push({key:'MasterReady', ok: !!mcBackupRestoreV01OpenMaster_(), message:'FEELHAUS_DB_MASTER 연결 확인'});
    var data = mcBackupRestoreV01GetData({log:false});
    result.checks.push({key:'DataReady', ok: !!data && data.ok, message:'Backup/Restore 현황 데이터 확인: ' + ((data && data.message) || '')});
    result.ok = result.checks.every(function(c){ return !!c.ok; });
    result.message = result.ok ? 'MailCenter Backup/Restore V01 준비 완료' : 'MailCenter Backup/Restore V01 점검 필요';
  } catch (err) {
    result.ok = false;
    result.message = String(err && err.message ? err.message : err);
  }

  Logger.log('JSON_COMPACT_RESULT: ' + JSON.stringify(result));
  return result;
}

function mcBackupRestoreV01HandleGet(e) {
  var t = HtmlService.createTemplateFromFile('MC_BackupRestoreViewV01');
  t.build = MC_BACKUP_RESTORE_V01_BUILD;
  t.webAppUrl = MC_BACKUP_RESTORE_V01_WEBAPP_URL;
  t.initialJson = JSON.stringify(mcBackupRestoreV01GetData({log:false}));
  return t.evaluate()
    .setTitle('FEELHAUS MailCenter Backup Restore')
    .setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL);
}

function mcBackupRestoreV01GetData(options) {
  var shouldLog = !(options && options.log === false);
  var result = {
    ok: false,
    build: MC_BACKUP_RESTORE_V01_BUILD,
    action: 'mcBackupRestoreV01GetData',
    generatedAt: mcBackupRestoreV01Now_(),
    message: '',
    config: {},
    sheets: [],
    backups: [],
    warnings: [],
    summary: {sheetCount:0,totalRows:0,backupCount:0}
  };

  try {
    var cfg = mcBackupRestoreV01ReadConfig_();
    var master = mcBackupRestoreV01OpenMaster_();
    result.config = {
      masterId: cfg.masterId,
      backupFolderId: cfg.backupFolderId,
      backupFolderUrl: cfg.backupFolderId ? 'https://drive.google.com/drive/folders/' + cfg.backupFolderId : ''
    };

    result.sheets = MC_BACKUP_RESTORE_V01_SHEETS.map(function(name) {
      var sh = master.getSheetByName(name);
      var rowCount = sh ? Math.max(0, sh.getLastRow() - 1) : 0;
      var colCount = sh ? sh.getLastColumn() : 0;
      return {sheetName:name, exists:!!sh, rowCount:rowCount, colCount:colCount};
    });

    try {
      result.backups = mcBackupRestoreV01ListBackups_();
    } catch (listErr) {
      result.backups = [];
      result.warnings.push({
        key: 'BackupListWarning',
        message: '백업 목록 조회 실패: ' + String(listErr && listErr.message ? listErr.message : listErr)
      });
    }

    result.summary.sheetCount = result.sheets.filter(function(s){return s.exists;}).length;
    result.summary.totalRows = result.sheets.reduce(function(sum, s){ return sum + (s.rowCount || 0); }, 0);
    result.summary.backupCount = result.backups.length;

    // 데이터 현황은 MASTER와 대상 시트가 읽히면 OK. 백업 목록 조회 실패는 WARN으로만 둔다.
    result.ok = result.summary.sheetCount > 0;
    result.message = result.ok
      ? ('MailCenter Backup/Restore 데이터 조회 완료' + (result.warnings.length ? ' / WARN ' + result.warnings.length + '건' : ''))
      : '백업 대상 MailCenter 시트를 찾지 못했습니다.';
  } catch (err) {
    result.ok = false;
    result.message = String(err && err.message ? err.message : err);
  }

  if (shouldLog) Logger.log('JSON_COMPACT_RESULT: ' + JSON.stringify(result));
  return mcBackupRestoreV01Safe_(result);
}

function mcBackupRestoreV01CreateSnapshot(options) {
  var result = {
    ok: false,
    build: MC_BACKUP_RESTORE_V01_BUILD,
    action: 'mcBackupRestoreV01CreateSnapshot',
    generatedAt: mcBackupRestoreV01Now_(),
    message: '',
    backup: null,
    sheets: []
  };

  try {
    var cfg = mcBackupRestoreV01ReadConfig_();
    if (!cfg.backupFolderId) throw new Error('BACKUP_DB_FOLDER_ID VALUE가 없습니다.');

    var master = mcBackupRestoreV01OpenMaster_();
    var stamp = Utilities.formatDate(new Date(), Session.getScriptTimeZone() || 'Asia/Seoul', 'yyyyMMdd_HHmmss');
    var name = 'MAILCENTER_BACKUP_' + stamp + '_STABLE_0131';
    var backupSs = SpreadsheetApp.create(name);
    var backupFile = DriveApp.getFileById(backupSs.getId());
    DriveApp.getFolderById(cfg.backupFolderId).addFile(backupFile);
    try { DriveApp.getRootFolder().removeFile(backupFile); } catch (ignore) {}

    var defaultSheet = backupSs.getSheets()[0];
    var manifest = backupSs.insertSheet('BackupManifest');
    var manifestRows = [
      ['key','value'],
      ['build', MC_BACKUP_RESTORE_V01_BUILD],
      ['createdAt', result.generatedAt],
      ['sourceMasterId', cfg.masterId],
      ['backupSpreadsheetId', backupSs.getId()],
      ['backupSpreadsheetUrl', backupSs.getUrl()],
      ['mode', 'MAILCENTER_SHEETS_COPY'],
      ['sheetList', MC_BACKUP_RESTORE_V01_SHEETS.join(',')]
    ];
    manifest.getRange(1,1,manifestRows.length,2).setValues(manifestRows);

    MC_BACKUP_RESTORE_V01_SHEETS.forEach(function(sheetName) {
      var src = master.getSheetByName(sheetName);
      if (!src) {
        result.sheets.push({sheetName:sheetName, copied:false, reason:'SOURCE_SHEET_MISSING'});
        return;
      }
      var copied = src.copyTo(backupSs).setName(sheetName);
      result.sheets.push({
        sheetName: sheetName,
        copied: true,
        rows: Math.max(0, src.getLastRow() - 1),
        cols: src.getLastColumn(),
        backupSheetId: copied.getSheetId()
      });
    });

    if (defaultSheet) backupSs.deleteSheet(defaultSheet);

    mcBackupRestoreV01Audit_('BACKUP_CREATED', 'MailCenter 백업 생성', {
      backupSpreadsheetId: backupSs.getId(),
      backupSpreadsheetUrl: backupSs.getUrl(),
      copiedSheets: result.sheets.filter(function(s){return s.copied;}).length
    });

    result.backup = {
      name: name,
      spreadsheetId: backupSs.getId(),
      url: backupSs.getUrl(),
      folderId: cfg.backupFolderId
    };
    result.ok = true;
    result.message = 'MailCenter 백업 생성 완료';
  } catch (err) {
    result.ok = false;
    result.message = String(err && err.message ? err.message : err);
  }

  Logger.log('JSON_COMPACT_RESULT: ' + JSON.stringify(result));
  return mcBackupRestoreV01Safe_(result);
}

function mcBackupRestoreV01RestoreDryRun(payload) {
  var result = {
    ok: false,
    build: MC_BACKUP_RESTORE_V01_BUILD,
    action: 'mcBackupRestoreV01RestoreDryRun',
    generatedAt: mcBackupRestoreV01Now_(),
    message: '',
    backupSpreadsheetId: '',
    sheets: []
  };

  try {
    var p = payload || {};
    var backupId = String(p.backupSpreadsheetId || '').trim();
    if (!backupId) throw new Error('backupSpreadsheetId가 필요합니다.');

    var backup = SpreadsheetApp.openById(backupId);
    var master = mcBackupRestoreV01OpenMaster_();

    MC_BACKUP_RESTORE_V01_SHEETS.forEach(function(sheetName) {
      var b = backup.getSheetByName(sheetName);
      var m = master.getSheetByName(sheetName);
      result.sheets.push({
        sheetName: sheetName,
        backupExists: !!b,
        masterExists: !!m,
        backupRows: b ? Math.max(0, b.getLastRow() - 1) : 0,
        masterRows: m ? Math.max(0, m.getLastRow() - 1) : 0,
        restorable: !!b && !!m
      });
    });

    result.backupSpreadsheetId = backupId;
    result.ok = true;
    result.message = '복구 사전점검 완료';
  } catch (err) {
    result.ok = false;
    result.message = String(err && err.message ? err.message : err);
  }

  Logger.log('JSON_COMPACT_RESULT: ' + JSON.stringify(result));
  return mcBackupRestoreV01Safe_(result);
}

function mcBackupRestoreV01RestoreFromBackup(payload) {
  var result = {
    ok: false,
    build: MC_BACKUP_RESTORE_V01_BUILD,
    action: 'mcBackupRestoreV01RestoreFromBackup',
    generatedAt: mcBackupRestoreV01Now_(),
    message: '',
    restored: []
  };

  try {
    var p = payload || {};
    var backupId = String(p.backupSpreadsheetId || '').trim();
    var confirmText = String(p.confirmText || '').trim();

    if (!backupId) throw new Error('backupSpreadsheetId가 필요합니다.');
    if (confirmText !== 'RESTORE_MAILCENTER') throw new Error('복구 승인문구가 일치하지 않습니다. RESTORE_MAILCENTER 입력 필요');

    var backup = SpreadsheetApp.openById(backupId);
    var master = mcBackupRestoreV01OpenMaster_();

    MC_BACKUP_RESTORE_V01_SHEETS.forEach(function(sheetName) {
      var src = backup.getSheetByName(sheetName);
      if (!src) {
        result.restored.push({sheetName:sheetName, restored:false, reason:'BACKUP_SHEET_MISSING'});
        return;
      }

      var dest = master.getSheetByName(sheetName);
      if (!dest) dest = master.insertSheet(sheetName);

      dest.clear({contentsOnly:false});
      var rows = src.getLastRow();
      var cols = src.getLastColumn();
      if (rows > 0 && cols > 0) {
        var range = src.getRange(1,1,rows,cols);
        var values = range.getValues();
        dest.getRange(1,1,rows,cols).setValues(values);
      }

      result.restored.push({
        sheetName: sheetName,
        restored: true,
        rows: Math.max(0, rows - 1),
        cols: cols
      });
    });

    mcBackupRestoreV01Audit_('RESTORE_COMPLETED', 'MailCenter 복구 실행', {
      backupSpreadsheetId: backupId,
      restoredSheets: result.restored.filter(function(s){return s.restored;}).length
    });

    result.ok = true;
    result.message = 'MailCenter 복구 완료';
  } catch (err) {
    result.ok = false;
    result.message = String(err && err.message ? err.message : err);
  }

  Logger.log('JSON_COMPACT_RESULT: ' + JSON.stringify(result));
  return mcBackupRestoreV01Safe_(result);
}

function mcBackupRestoreV01ListBackups_() {
  var cfg = mcBackupRestoreV01ReadConfig_();
  if (!cfg.backupFolderId) return [];
  var folder = DriveApp.getFolderById(cfg.backupFolderId);
  var files = folder.getFiles();
  var out = [];

  while (files.hasNext()) {
    var f = files.next();
    var name = f.getName();
    if (name.indexOf('MAILCENTER_BACKUP_') !== 0) continue;
    out.push({
      name: name,
      spreadsheetId: f.getId(),
      url: f.getUrl(),
      createdAt: Utilities.formatDate(f.getDateCreated(), Session.getScriptTimeZone() || 'Asia/Seoul', 'yyyy-MM-dd HH:mm:ss'),
      updatedAt: Utilities.formatDate(f.getLastUpdated(), Session.getScriptTimeZone() || 'Asia/Seoul', 'yyyy-MM-dd HH:mm:ss')
    });
  }

  out.sort(function(a,b){ return String(b.createdAt).localeCompare(String(a.createdAt)); });
  return out.slice(0, 20);
}


function mcBackupRestoreV01CheckBackupFolder_() {
  var result = {ok:false, message:''};
  try {
    var cfg = mcBackupRestoreV01ReadConfig_();
    if (!cfg.backupFolderId) {
      result.message = 'BACKUP_DB_FOLDER_ID VALUE가 비어 있습니다.';
      return result;
    }
    var folder = DriveApp.getFolderById(cfg.backupFolderId);
    result.ok = !!folder;
    result.message = folder ? ('백업 폴더 열기 성공: ' + folder.getName()) : '백업 폴더 열기 실패';
    return result;
  } catch (err) {
    result.ok = false;
    result.message = '백업 폴더 열기 실패: ' + String(err && err.message ? err.message : err);
    return result;
  }
}

function mcBackupRestoreV01ReadConfig_() {
  var setup = SpreadsheetApp.openById(MC_BACKUP_RESTORE_V01_SETUP_DB_ID);
  var sh = setup.getSheetByName(MC_BACKUP_RESTORE_V01_CONFIG_SHEET_NAME);
  if (!sh) throw new Error('SystemConfig 시트를 찾지 못했습니다.');
  var values = sh.getDataRange().getValues();
  if (!values || !values.length) throw new Error('SystemConfig 데이터가 없습니다.');

  var headers = values[0].map(function(h){ return String(h || '').trim(); });
  var keyCol = headers.indexOf('CONFIG_KEY');
  var valueCol = headers.indexOf('VALUE');
  if (keyCol < 0 || valueCol < 0) {
    throw new Error('SystemConfig 헤더는 CONFIG_KEY / VALUE 여야 합니다. 감지 헤더: ' + headers.join(', '));
  }

  var out = {masterId:'', backupFolderId:'', headers:headers};
  for (var r = 1; r < values.length; r++) {
    var key = String(values[r][keyCol] || '').trim();
    var value = String(values[r][valueCol] || '').trim();
    if (key === MC_BACKUP_RESTORE_V01_MASTER_KEY) out.masterId = value;
    if (key === MC_BACKUP_RESTORE_V01_BACKUP_FOLDER_KEY) out.backupFolderId = value;
  }
  if (!out.masterId) throw new Error('CONFIG_KEY = FEELHAUS_DB_MASTER 행의 VALUE 값이 없습니다.');
  return out;
}

function mcBackupRestoreV01OpenMaster_() {
  var cfg = mcBackupRestoreV01ReadConfig_();
  return SpreadsheetApp.openById(cfg.masterId);
}

function mcBackupRestoreV01Audit_(action, message, detail) {
  try {
    var master = mcBackupRestoreV01OpenMaster_();
    var sh = master.getSheetByName('MailCenter_AuditLogs') || master.insertSheet('MailCenter_AuditLogs');
    var headers = sh.getLastRow() >= 1 ? sh.getRange(1,1,1,sh.getLastColumn()).getValues()[0].map(function(h){return String(h || '').trim();}) : [];
    var required = ['createdAt','action','message','detailJson','createdBy'];
    if (headers.length === 0) {
      headers = required;
      sh.getRange(1,1,1,headers.length).setValues([headers]);
    }
    required.forEach(function(h) {
      if (headers.indexOf(h) < 0) {
        headers.push(h);
        sh.getRange(1,headers.length).setValue(h);
      }
    });
    var row = headers.map(function(h) {
      if (h === 'createdAt') return mcBackupRestoreV01Now_();
      if (h === 'action') return action;
      if (h === 'message') return message;
      if (h === 'detailJson') return JSON.stringify(detail || {});
      if (h === 'createdBy') return Session.getActiveUser().getEmail() || 'SYSTEM';
      return '';
    });
    sh.appendRow(row);
  } catch (ignore) {}
}

function mcBackupRestoreV01Now_() {
  return Utilities.formatDate(new Date(), Session.getScriptTimeZone() || 'Asia/Seoul', 'yyyy-MM-dd HH:mm:ss');
}

function mcBackupRestoreV01Safe_(obj) {
  try { return JSON.parse(JSON.stringify(obj)); }
  catch (e) { return {ok:false, build:MC_BACKUP_RESTORE_V01_BUILD, message:String(e && e.message ? e.message : e)}; }
}
