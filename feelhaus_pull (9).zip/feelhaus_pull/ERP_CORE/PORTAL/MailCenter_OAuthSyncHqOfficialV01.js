/**
 * FEELHAUS MailCenter OAuth Sync HQ Official FAST V01
 * Build: MAILCENTER_OAUTH_SYNC_HQ_OFFICIAL_FAST_V01_20260519
 *
 * Purpose:
 * - feelhaus@feelhausfair.com 본사 공식 대표메일 OAuth 연결상태를 CONNECTED로 동기화한다.
 * - 매개변수 없이 1개 함수만 실행한다.
 * - 기존 파일/PORTAL 본체/169/171 OAuth 파일은 건드리지 않는다.
 */

var MAILCENTER_OAUTH_SYNC_HQ_OFFICIAL_V01_BUILD = 'MAILCENTER_OAUTH_SYNC_HQ_OFFICIAL_FAST_V01_20260519';

function runMailCenterSyncOAuthHqOfficialFastV01() {
  var payload = {
    mailAccountId: 'MAILACC-20260519092514-8445',
    connectorMailAccountId: 'MAILACC-20260518091732-6530',
    emailAddress: 'feelhaus@feelhausfair.com',
    ownerType: 'HQ',
    vendorId: ''
  };

  var result = {
    ok: false,
    build: MAILCENTER_OAUTH_SYNC_HQ_OFFICIAL_V01_BUILD,
    action: 'runMailCenterSyncOAuthHqOfficialFastV01',
    generatedAt: mailCenterOAuthSyncHqOfficialV01Now_(),
    message: '',
    payload: payload,
    syncResult: null
  };

  try {
    if (typeof mailCenterSyncOAuthConnectionStatus !== 'function') {
      throw new Error('mailCenterSyncOAuthConnectionStatus 함수가 없습니다. MailCenter_OAuthConnect.js 적용 상태를 확인하세요.');
    }

    var syncResult = mailCenterSyncOAuthConnectionStatus('', payload);
    result.syncResult = syncResult;
    result.ok = !!(syncResult && syncResult.ok);
    result.message = result.ok
      ? 'feelhaus@feelhausfair.com 본사 공식 대표메일 OAuth 연결상태 동기화 완료'
      : '본사 공식 대표메일 OAuth 연결상태 동기화 실패';
  } catch (err) {
    result.ok = false;
    result.message = String(err && err.message ? err.message : err);
  }

  mailCenterOAuthSyncHqOfficialV01Log_(result);
  return result;
}

function getMailCenterHqOfficialOAuthSyncStatusV01() {
  var result = {
    ok: false,
    build: MAILCENTER_OAUTH_SYNC_HQ_OFFICIAL_V01_BUILD,
    action: 'getMailCenterHqOfficialOAuthSyncStatusV01',
    generatedAt: mailCenterOAuthSyncHqOfficialV01Now_(),
    emailAddress: 'feelhaus@feelhausfair.com',
    mailAccountId: 'MAILACC-20260519092514-8445',
    connectorMailAccountId: 'MAILACC-20260518091732-6530',
    status: null,
    row: null
  };

  try {
    var ss = mailCenterOAuthSyncHqOfficialV01GetMasterSpreadsheet_();
    var sh = ss.getSheetByName('MailCenter_OAuthConnections');
    if (!sh) throw new Error('MailCenter_OAuthConnections 시트가 없습니다.');

    var values = sh.getDataRange().getValues();
    if (!values || values.length < 2) {
      result.ok = true;
      result.status = 'NO_ROWS';
      return result;
    }

    var header = values[0];
    var hm = {};
    header.forEach(function(h, i) { hm[String(h)] = i; });

    var emailIdx = hm.emailAddress;
    var mailIdx = hm.mailAccountId;
    var statusIdx = hm.oauthStatus;

    for (var r = values.length - 1; r >= 1; r--) {
      var row = values[r];
      if ((emailIdx != null && row[emailIdx] === 'feelhaus@feelhausfair.com') ||
          (mailIdx != null && row[mailIdx] === 'MAILACC-20260519092514-8445')) {
        result.ok = true;
        result.status = statusIdx != null ? row[statusIdx] : '';
        result.row = row;
        return result;
      }
    }

    result.ok = true;
    result.status = 'NOT_FOUND';
    return result;
  } catch (err) {
    result.ok = false;
    result.message = String(err && err.message ? err.message : err);
    return result;
  }
}

function mailCenterOAuthSyncHqOfficialV01Now_() {
  return Utilities.formatDate(new Date(), Session.getScriptTimeZone() || 'Asia/Seoul', 'yyyy-MM-dd HH:mm:ss');
}

function mailCenterOAuthSyncHqOfficialV01Log_(obj) {
  try {
    Logger.log('JSON_COMPACT_RESULT: ' + JSON.stringify(obj));
  } catch (e) {
    Logger.log(obj);
  }
}

function mailCenterOAuthSyncHqOfficialV01GetMasterSpreadsheet_() {
  if (typeof mailCenterOAuthGetMasterSpreadsheet_ === 'function') {
    var ss1 = mailCenterOAuthGetMasterSpreadsheet_();
    if (ss1) return ss1;
  }
  if (typeof mailCenterGetMasterSpreadsheet_ === 'function') {
    var ss2 = mailCenterGetMasterSpreadsheet_();
    if (ss2) return ss2;
  }
  if (typeof getMasterSpreadsheet_ === 'function') {
    var ss3 = getMasterSpreadsheet_();
    if (ss3) return ss3;
  }

  var setupDbId = '17VMSpgSZCvIrUlgcw8yCNcnl8WQWo2IcRf5tDCcuJGM';
  var setup = SpreadsheetApp.openById(setupDbId);
  var configSheet = setup.getSheetByName('SystemConfig');
  if (!configSheet) throw new Error('SystemConfig 시트를 찾지 못했습니다.');

  var values = configSheet.getDataRange().getValues();
  var hm = {};
  values[0].forEach(function(h, i) {
    var raw = String(h || '').trim();
    hm[raw] = i;
    hm[raw.toUpperCase().replace(/[^A-Z0-9]/g, '')] = i;
  });

  var keyIdx = hm.CONFIGKEY != null ? hm.CONFIGKEY : hm.KEY;
  var valIdx = hm.VALUE != null ? hm.VALUE : hm.CONFIGVALUE;
  if (keyIdx == null || valIdx == null) throw new Error('SystemConfig CONFIG_KEY/VALUE 헤더를 찾지 못했습니다.');

  var masterId = '';
  for (var r = 1; r < values.length; r++) {
    var key = String(values[r][keyIdx] || '').trim();
    if (key === 'FEELHAUS_DB_MASTER' || key === 'FEELHAUS_DB_MASTER_ID' || key === 'MASTER_DB_ID') {
      masterId = String(values[r][valIdx] || '').trim();
      break;
    }
  }
  if (!masterId) throw new Error('SystemConfig에서 FEELHAUS_DB_MASTER ID를 찾지 못했습니다.');

  return SpreadsheetApp.openById(masterId);
}
