/**
 * FEELHAUS MailCenter Native Button Nav V01
 * Build: MAILCENTER_NATIVE_BUTTON_NAV_AUDIT_FIX_V01_20260520
 *
 * Purpose:
 * - MailCenter 전 화면 href ?page 링크 금지
 * - userCodeAppPanel 링크 금지
 * - Router 자동주입 금지
 * - button onclick + window.top.location.href + fixed WebApp URL 방식만 사용
 */

var MAILCENTER_NATIVE_BUTTON_NAV_CORE_V01_BUILD = 'PORTAL_NATIVE_MENU_EXACT_SYNC_V03_20260531';
var MAILCENTER_NATIVE_BUTTON_NAV_CORE_V01_WEBAPP_URL = 'https://script.google.com/macros/s/AKfycbxCyFE7zf4vE8nsfjOeWX0pC56SqU84gm8ie8Txa3qHQGEusJCZeljzCdYeOmZxUVYvjA/exec';

function runMcNativeButtonNavCoreV01Smoke() {
  var result = {
    ok: false,
    build: MAILCENTER_NATIVE_BUTTON_NAV_CORE_V01_BUILD,
    action: 'runMcNativeButtonNavCoreV01Smoke',
    generatedAt: Utilities.formatDate(new Date(), Session.getScriptTimeZone() || 'Asia/Seoul', 'yyyy-MM-dd HH:mm:ss'),
    message: '',
    checks: []
  };

  try {
    var routes = mcNativeButtonNavV01GetRoutes();
    result.checks.push({
      key: 'WebAppUrlReady',
      ok: /^https:\/\/script\.google\.com\/macros\/s\//.test(MAILCENTER_NATIVE_BUTTON_NAV_CORE_V01_WEBAPP_URL),
      message: '고정 WebApp URL 확인'
    });
    result.checks.push({
      key: 'RoutesReady',
      ok: Array.isArray(routes) && routes.length >= 8,
      message: 'MailCenter Native Button 메뉴 route 확인: ' + routes.length
    });
    result.checks.push({
      key: 'NavHtmlReady',
      ok: typeof mcNativeButtonNavCoreV01GetHtml === 'function',
      message: '공통 버튼 메뉴 HTML 함수 확인'
    });

    result.ok = result.checks.every(function(c) { return !!c.ok; });
    result.message = result.ok ? 'Native Button Nav V01 준비 완료' : 'Native Button Nav V01 점검 필요';
  } catch (err) {
    result.ok = false;
    result.message = String(err && err.message ? err.message : err);
  }

  Logger.log('JSON_COMPACT_RESULT: ' + JSON.stringify(result));
  return result;
}

function mcNativeButtonNavV01GetGroups() {
  return [
  {
    "groupId": "home",
    "order": 1,
    "label": "01. 통합 현황",
    "status": "준비중",
    "defaultOpen": false,
    "items": [
      {
        "menuId": "home.dashboard",
        "label": "오늘의 운영 현황",
        "route": "home",
        "note": "준비중",
        "enabled": false
      },
      {
        "menuId": "home.eventProgress",
        "label": "진행 중 박람회",
        "route": "home",
        "note": "준비중",
        "enabled": false
      },
      {
        "menuId": "home.eventReady",
        "label": "준비 중 박람회",
        "route": "home",
        "note": "준비중",
        "enabled": false
      },
      {
        "menuId": "home.eventKpi",
        "label": "행사별 핵심 지표",
        "route": "home",
        "note": "준비중",
        "enabled": false
      },
      {
        "menuId": "home.fieldEntry",
        "label": "현장 입장 현황",
        "route": "home",
        "note": "준비중",
        "enabled": false
      },
      {
        "menuId": "home.qr",
        "label": "QR 접수 현황",
        "route": "home",
        "note": "준비중",
        "enabled": false
      },
      {
        "menuId": "home.consultWait",
        "label": "상담 대기 현황",
        "route": "home",
        "note": "준비중",
        "enabled": false
      },
      {
        "menuId": "home.saleContract",
        "label": "판매 / 계약 현황",
        "route": "home",
        "note": "준비중",
        "enabled": false
      },
      {
        "menuId": "home.signWait",
        "label": "SIGN 서명 대기",
        "route": "home",
        "note": "준비중",
        "enabled": false
      },
      {
        "menuId": "home.install",
        "label": "설치 예정",
        "route": "home",
        "note": "준비중",
        "enabled": false
      },
      {
        "menuId": "home.as",
        "label": "A/S 접수",
        "route": "home",
        "note": "준비중",
        "enabled": false
      },
      {
        "menuId": "home.settlementWait",
        "label": "정산 대기",
        "route": "home",
        "note": "읽기 전용",
        "enabled": false
      },
      {
        "menuId": "home.giftWait",
        "label": "상품권 / 기프트 지급 대기",
        "route": "home",
        "note": "준비중",
        "enabled": false
      },
      {
        "menuId": "home.approvalWait",
        "label": "승인 대기",
        "route": "home",
        "note": "준비중",
        "enabled": false
      },
      {
        "menuId": "home.sendFail",
        "label": "발송 실패",
        "route": "home",
        "note": "준비중",
        "enabled": false
      },
      {
        "menuId": "home.errorAlert",
        "label": "오류 알림",
        "route": "home",
        "note": "준비중",
        "enabled": false
      },
      {
        "menuId": "home.sensitiveAlert",
        "label": "민감업무 알림",
        "route": "home",
        "note": "민감 권한",
        "enabled": false
      },
      {
        "menuId": "home.staffKpi",
        "label": "직원 KPI 요약",
        "route": "home",
        "note": "준비중",
        "enabled": false
      },
      {
        "menuId": "home.checklist",
        "label": "오늘의 체크리스트",
        "route": "home",
        "note": "준비중",
        "enabled": false
      },
      {
        "menuId": "home.quickRun",
        "label": "빠른 실행",
        "route": "home",
        "note": "사용 가능",
        "enabled": false
      },
      {
        "menuId": "home.qrEntry",
        "label": "QR 입장",
        "route": "home",
        "note": "준비중",
        "enabled": false
      },
      {
        "menuId": "home.customerReg",
        "label": "고객 등록",
        "route": "home",
        "note": "준비중",
        "enabled": false
      },
      {
        "menuId": "home.consultAssign",
        "label": "상담 배정",
        "route": "home",
        "note": "준비중",
        "enabled": false
      },
      {
        "menuId": "home.mailWrite",
        "label": "메일 작성",
        "route": "MailCenterComposeV01",
        "note": "사용 가능",
        "enabled": true
      },
      {
        "menuId": "home.contractSend",
        "label": "계약서 발송",
        "route": "home",
        "note": "준비중",
        "enabled": false
      },
      {
        "menuId": "home.giftConfirm",
        "label": "상품권 지급 확인",
        "route": "home",
        "note": "준비중",
        "enabled": false
      },
      {
        "menuId": "home.settlementConfirm",
        "label": "정산 확인",
        "route": "settlement",
        "note": "읽기 전용",
        "enabled": false
      },
      {
        "menuId": "home.taskRequest",
        "label": "업무요청",
        "route": "home",
        "note": "준비중",
        "enabled": false
      },
      {
        "menuId": "home.errorForward",
        "label": "오류 전달",
        "route": "home",
        "note": "준비중",
        "enabled": false
      },
      {
        "menuId": "home.recentAudit",
        "label": "최근 감사 로그",
        "route": "auditLog",
        "note": "읽기 전용",
        "enabled": true
      }
    ]
  },
  {
    "groupId": "hq",
    "order": 2,
    "label": "02. 본사 / 그룹웨어",
    "status": "준비중",
    "defaultOpen": false,
    "items": []
  },
  {
    "groupId": "eventPrep",
    "order": 3,
    "label": "03. 박람회 준비",
    "status": "준비중",
    "defaultOpen": false,
    "items": [
      {
        "menuId": "event.ops",
        "label": "행사관리",
        "route": "eventVendor",
        "note": "박람회 준비 기준 메뉴",
        "enabled": true
      }
    ]
  },
  {
    "groupId": "fieldOps",
    "order": 4,
    "label": "04. 현장 운영",
    "status": "준비중",
    "defaultOpen": false,
    "items": []
  },
  {
    "groupId": "customer",
    "order": 5,
    "label": "05. 고객 / 영업 / 계약",
    "status": "준비중",
    "defaultOpen": false,
    "items": []
  },
  {
    "groupId": "vendor",
    "order": 6,
    "label": "06. 업체 / 협력사",
    "status": "준비중",
    "defaultOpen": false,
    "items": []
  },
  {
    "groupId": "benefit",
    "order": 7,
    "label": "07. 상품 / 혜택 / 프로모션",
    "status": "준비중",
    "defaultOpen": false,
    "items": []
  },
  {
    "groupId": "installAs",
    "order": 8,
    "label": "08. 설치 / A/S / 품질",
    "status": "준비중",
    "defaultOpen": false,
    "items": []
  },
  {
    "groupId": "settlement",
    "order": 9,
    "label": "09. 정산 / 회계 / 재무",
    "status": "읽기 전용",
    "defaultOpen": false,
    "items": []
  },
  {
    "groupId": "comm",
    "order": 10,
    "label": "10. 커뮤니케이션 / 알림",
    "status": "사용 가능",
    "defaultOpen": true,
    "items": [
      {
        "menuId": "mail.dashboard",
        "label": "메일 / 알림센터",
        "route": "MailCenterDashboardV04",
        "note": "사용 가능 · 메일센터 기능",
        "enabled": true
      },
      {
        "menuId": "mail.list",
        "label": "메일 목록",
        "route": "MailCenterServerMailListV01",
        "note": "사용 가능 · 메일센터 기능",
        "enabled": true
      },
      {
        "menuId": "mail.compose",
        "label": "메일 작성/발송",
        "route": "MailCenterComposeV01",
        "note": "사용 가능 · 메일센터 기능",
        "enabled": true
      },
      {
        "menuId": "mail.calendar",
        "label": "메일 캘린더",
        "route": "MailCenterCalendarV01",
        "note": "사용 가능 · 메일센터 기능",
        "enabled": true
      },
      {
        "menuId": "mail.test",
        "label": "테스트 발송",
        "route": "MailCenterSendTestV05",
        "note": "사용 가능 · 메일센터 기능",
        "enabled": true
      },
      {
        "menuId": "mail.library",
        "label": "자료함",
        "route": "MailCenterAttachmentLibraryV01",
        "note": "사용 가능 · 메일센터 기능",
        "enabled": true
      },
      {
        "menuId": "mail.template",
        "label": "템플릿 관리",
        "route": "MailCenterTemplateV01",
        "note": "사용 가능 · 메일센터 기능",
        "enabled": true
      },
      {
        "menuId": "mail.audit",
        "label": "로그/감사 조회",
        "route": "MailCenterLogAuditV01",
        "note": "사용 가능 · 메일센터 기능",
        "enabled": true
      },
      {
        "menuId": "mail.account",
        "label": "계정 등록/승인",
        "route": "MailCenterAccountAdminV01",
        "note": "사용 가능 · 메일센터 기능",
        "enabled": true
      },
      {
        "menuId": "mail.setting",
        "label": "서명/폴더/설정",
        "route": "MailCenterSettingsV01",
        "note": "사용 가능 · 메일센터 기능",
        "enabled": true
      },
      {
        "menuId": "mail.routeIndex",
        "label": "주소표",
        "route": "MailCenterRouteIndexV03",
        "note": "사용 가능 · 메일센터 기능",
        "enabled": true
      },
      {
        "menuId": "mail.customerGuideBundle",
        "label": "고객 안내 발송 묶음",
        "route": "home",
        "note": "PORTAL 기준 메뉴",
        "enabled": false
      },
      {
        "menuId": "mail.smsKakaoAlimtalk",
        "label": "문자 / 카카오 / 알림톡",
        "route": "home",
        "note": "PORTAL 기준 메뉴",
        "enabled": false
      },
      {
        "menuId": "mail.callcenter",
        "label": "콜센터 / 고객응대",
        "route": "home",
        "note": "PORTAL 기준 메뉴",
        "enabled": false
      },
      {
        "menuId": "mail.automation",
        "label": "자동화 / 워크플로우",
        "route": "home",
        "note": "PORTAL 기준 메뉴",
        "enabled": false
      }
    ]
  },
  {
    "groupId": "report",
    "order": 11,
    "label": "11. 자료 / 증빙 / 리포트",
    "status": "준비중",
    "defaultOpen": false,
    "items": []
  },
  {
    "groupId": "approval",
    "order": 12,
    "label": "12. 승인 / 감사 / 보안",
    "status": "관리자",
    "defaultOpen": false,
    "items": []
  },
  {
    "groupId": "control",
    "order": 13,
    "label": "13. 설정 / CONTROL",
    "status": "관리자",
    "defaultOpen": true,
    "items": [
      {
        "menuId": "control.users",
        "label": "권한 / 사용자",
        "route": "controlSettings",
        "note": "관리자 전용",
        "enabled": true
      },
      {
        "menuId": "control.profile",
        "label": "권한 프로파일",
        "route": "permissionPolicy",
        "note": "관리자 전용",
        "enabled": true
      },
      {
        "menuId": "control.policy",
        "label": "설정 / 정책",
        "route": "permissionPolicy",
        "note": "관리자 전용",
        "enabled": true
      },
      {
        "menuId": "control.menu",
        "label": "메뉴 관리",
        "route": "menuRegistry",
        "note": "관리자 전용",
        "enabled": false
      },
      {
        "menuId": "control.menuList",
        "label": "전체 메뉴 목록",
        "route": "menuRegistry",
        "note": "준비중",
        "enabled": false
      },
      {
        "menuId": "control.parentAdd",
        "label": "상위 메뉴 추가",
        "route": "menuRegistry",
        "note": "준비중",
        "enabled": false
      },
      {
        "menuId": "control.childAdd",
        "label": "하위 메뉴 추가",
        "route": "menuRegistry",
        "note": "준비중",
        "enabled": false
      },
      {
        "menuId": "control.menuNameEdit",
        "label": "메뉴명 수정",
        "route": "menuRegistry",
        "note": "준비중",
        "enabled": false
      },
      {
        "menuId": "control.orderEdit",
        "label": "메뉴 순서 변경",
        "route": "menuRegistry",
        "note": "준비중",
        "enabled": false
      },
      {
        "menuId": "control.iconEdit",
        "label": "메뉴 아이콘 설정",
        "route": "menuRegistry",
        "note": "준비중",
        "enabled": false
      },
      {
        "menuId": "control.statusEdit",
        "label": "메뉴 상태 설정",
        "route": "menuRegistry",
        "note": "준비중",
        "enabled": false
      },
      {
        "menuId": "control.permissionEdit",
        "label": "메뉴 권한 설정",
        "route": "menuRegistry",
        "note": "준비중",
        "enabled": false
      },
      {
        "menuId": "control.visibleEdit",
        "label": "메뉴 표시 / 숨김",
        "route": "menuRegistry",
        "note": "준비중",
        "enabled": false
      },
      {
        "menuId": "control.readyText",
        "label": "준비중 문구 설정",
        "route": "menuRegistry",
        "note": "준비중",
        "enabled": false
      },
      {
        "menuId": "control.routeEdit",
        "label": "메뉴 연결 route 설정",
        "route": "menuRegistry",
        "note": "준비중",
        "enabled": false
      },
      {
        "menuId": "control.descriptionEdit",
        "label": "메뉴 설명 설정",
        "route": "menuRegistry",
        "note": "준비중",
        "enabled": false
      },
      {
        "menuId": "control.dashboard",
        "label": "CONTROL 대시보드",
        "route": "controlDashboard",
        "note": "관리자 전용",
        "enabled": true
      },
      {
        "menuId": "control.audit",
        "label": "로그 / 감사추적",
        "route": "auditLog",
        "note": "관리자 전용",
        "enabled": true
      },
      {
        "menuId": "control.diagnostic",
        "label": "CONTROL / 진단 / 배포",
        "route": "controlDiagnostics",
        "note": "관리자 전용",
        "enabled": true
      },
      {
        "menuId": "control.backup",
        "label": "백업 / 복구 / 롤백",
        "route": "backupRestore",
        "note": "관리자 전용",
        "enabled": true
      },
      {
        "menuId": "control.build",
        "label": "배포 / 빌드 이력",
        "route": "buildRelease",
        "note": "관리자 전용",
        "enabled": true
      },
      {
        "menuId": "control.systemConfig",
        "label": "SystemConfig 기준 안내",
        "route": "systemConfigGuide",
        "note": "기준 안내",
        "enabled": true
      }
    ]
  },
  {
    "groupId": "external",
    "order": 14,
    "label": "14. 외부 포털 / 연동",
    "status": "준비중",
    "defaultOpen": false,
    "items": []
  },
  {
    "groupId": "help",
    "order": 15,
    "label": "15. 도움말 / 교육",
    "status": "준비중",
    "defaultOpen": false,
    "items": []
  }
];
}

function mcNativeButtonNavV01GetRoutes() {
  return [
  {
    "menuId": "home.dashboard",
    "label": "오늘의 운영 현황",
    "route": "home",
    "note": "준비중",
    "enabled": false,
    "section": "01. 통합 현황",
    "sectionId": "home",
    "groupStatus": "준비중",
    "groupOrder": 1,
    "defaultOpen": false,
    "icon": "•"
  },
  {
    "menuId": "home.eventProgress",
    "label": "진행 중 박람회",
    "route": "home",
    "note": "준비중",
    "enabled": false,
    "section": "01. 통합 현황",
    "sectionId": "home",
    "groupStatus": "준비중",
    "groupOrder": 1,
    "defaultOpen": false,
    "icon": "•"
  },
  {
    "menuId": "home.eventReady",
    "label": "준비 중 박람회",
    "route": "home",
    "note": "준비중",
    "enabled": false,
    "section": "01. 통합 현황",
    "sectionId": "home",
    "groupStatus": "준비중",
    "groupOrder": 1,
    "defaultOpen": false,
    "icon": "•"
  },
  {
    "menuId": "home.eventKpi",
    "label": "행사별 핵심 지표",
    "route": "home",
    "note": "준비중",
    "enabled": false,
    "section": "01. 통합 현황",
    "sectionId": "home",
    "groupStatus": "준비중",
    "groupOrder": 1,
    "defaultOpen": false,
    "icon": "•"
  },
  {
    "menuId": "home.fieldEntry",
    "label": "현장 입장 현황",
    "route": "home",
    "note": "준비중",
    "enabled": false,
    "section": "01. 통합 현황",
    "sectionId": "home",
    "groupStatus": "준비중",
    "groupOrder": 1,
    "defaultOpen": false,
    "icon": "•"
  },
  {
    "menuId": "home.qr",
    "label": "QR 접수 현황",
    "route": "home",
    "note": "준비중",
    "enabled": false,
    "section": "01. 통합 현황",
    "sectionId": "home",
    "groupStatus": "준비중",
    "groupOrder": 1,
    "defaultOpen": false,
    "icon": "•"
  },
  {
    "menuId": "home.consultWait",
    "label": "상담 대기 현황",
    "route": "home",
    "note": "준비중",
    "enabled": false,
    "section": "01. 통합 현황",
    "sectionId": "home",
    "groupStatus": "준비중",
    "groupOrder": 1,
    "defaultOpen": false,
    "icon": "•"
  },
  {
    "menuId": "home.saleContract",
    "label": "판매 / 계약 현황",
    "route": "home",
    "note": "준비중",
    "enabled": false,
    "section": "01. 통합 현황",
    "sectionId": "home",
    "groupStatus": "준비중",
    "groupOrder": 1,
    "defaultOpen": false,
    "icon": "•"
  },
  {
    "menuId": "home.signWait",
    "label": "SIGN 서명 대기",
    "route": "home",
    "note": "준비중",
    "enabled": false,
    "section": "01. 통합 현황",
    "sectionId": "home",
    "groupStatus": "준비중",
    "groupOrder": 1,
    "defaultOpen": false,
    "icon": "•"
  },
  {
    "menuId": "home.install",
    "label": "설치 예정",
    "route": "home",
    "note": "준비중",
    "enabled": false,
    "section": "01. 통합 현황",
    "sectionId": "home",
    "groupStatus": "준비중",
    "groupOrder": 1,
    "defaultOpen": false,
    "icon": "•"
  },
  {
    "menuId": "home.as",
    "label": "A/S 접수",
    "route": "home",
    "note": "준비중",
    "enabled": false,
    "section": "01. 통합 현황",
    "sectionId": "home",
    "groupStatus": "준비중",
    "groupOrder": 1,
    "defaultOpen": false,
    "icon": "•"
  },
  {
    "menuId": "home.settlementWait",
    "label": "정산 대기",
    "route": "home",
    "note": "읽기 전용",
    "enabled": false,
    "section": "01. 통합 현황",
    "sectionId": "home",
    "groupStatus": "준비중",
    "groupOrder": 1,
    "defaultOpen": false,
    "icon": "•"
  },
  {
    "menuId": "home.giftWait",
    "label": "상품권 / 기프트 지급 대기",
    "route": "home",
    "note": "준비중",
    "enabled": false,
    "section": "01. 통합 현황",
    "sectionId": "home",
    "groupStatus": "준비중",
    "groupOrder": 1,
    "defaultOpen": false,
    "icon": "•"
  },
  {
    "menuId": "home.approvalWait",
    "label": "승인 대기",
    "route": "home",
    "note": "준비중",
    "enabled": false,
    "section": "01. 통합 현황",
    "sectionId": "home",
    "groupStatus": "준비중",
    "groupOrder": 1,
    "defaultOpen": false,
    "icon": "•"
  },
  {
    "menuId": "home.sendFail",
    "label": "발송 실패",
    "route": "home",
    "note": "준비중",
    "enabled": false,
    "section": "01. 통합 현황",
    "sectionId": "home",
    "groupStatus": "준비중",
    "groupOrder": 1,
    "defaultOpen": false,
    "icon": "•"
  },
  {
    "menuId": "home.errorAlert",
    "label": "오류 알림",
    "route": "home",
    "note": "준비중",
    "enabled": false,
    "section": "01. 통합 현황",
    "sectionId": "home",
    "groupStatus": "준비중",
    "groupOrder": 1,
    "defaultOpen": false,
    "icon": "•"
  },
  {
    "menuId": "home.sensitiveAlert",
    "label": "민감업무 알림",
    "route": "home",
    "note": "민감 권한",
    "enabled": false,
    "section": "01. 통합 현황",
    "sectionId": "home",
    "groupStatus": "준비중",
    "groupOrder": 1,
    "defaultOpen": false,
    "icon": "•"
  },
  {
    "menuId": "home.staffKpi",
    "label": "직원 KPI 요약",
    "route": "home",
    "note": "준비중",
    "enabled": false,
    "section": "01. 통합 현황",
    "sectionId": "home",
    "groupStatus": "준비중",
    "groupOrder": 1,
    "defaultOpen": false,
    "icon": "•"
  },
  {
    "menuId": "home.checklist",
    "label": "오늘의 체크리스트",
    "route": "home",
    "note": "준비중",
    "enabled": false,
    "section": "01. 통합 현황",
    "sectionId": "home",
    "groupStatus": "준비중",
    "groupOrder": 1,
    "defaultOpen": false,
    "icon": "•"
  },
  {
    "menuId": "home.quickRun",
    "label": "빠른 실행",
    "route": "home",
    "note": "사용 가능",
    "enabled": false,
    "section": "01. 통합 현황",
    "sectionId": "home",
    "groupStatus": "준비중",
    "groupOrder": 1,
    "defaultOpen": false,
    "icon": "•"
  },
  {
    "menuId": "home.qrEntry",
    "label": "QR 입장",
    "route": "home",
    "note": "준비중",
    "enabled": false,
    "section": "01. 통합 현황",
    "sectionId": "home",
    "groupStatus": "준비중",
    "groupOrder": 1,
    "defaultOpen": false,
    "icon": "•"
  },
  {
    "menuId": "home.customerReg",
    "label": "고객 등록",
    "route": "home",
    "note": "준비중",
    "enabled": false,
    "section": "01. 통합 현황",
    "sectionId": "home",
    "groupStatus": "준비중",
    "groupOrder": 1,
    "defaultOpen": false,
    "icon": "•"
  },
  {
    "menuId": "home.consultAssign",
    "label": "상담 배정",
    "route": "home",
    "note": "준비중",
    "enabled": false,
    "section": "01. 통합 현황",
    "sectionId": "home",
    "groupStatus": "준비중",
    "groupOrder": 1,
    "defaultOpen": false,
    "icon": "•"
  },
  {
    "menuId": "home.mailWrite",
    "label": "메일 작성",
    "route": "MailCenterComposeV01",
    "note": "사용 가능",
    "enabled": true,
    "section": "01. 통합 현황",
    "sectionId": "home",
    "groupStatus": "준비중",
    "groupOrder": 1,
    "defaultOpen": false,
    "icon": "•"
  },
  {
    "menuId": "home.contractSend",
    "label": "계약서 발송",
    "route": "home",
    "note": "준비중",
    "enabled": false,
    "section": "01. 통합 현황",
    "sectionId": "home",
    "groupStatus": "준비중",
    "groupOrder": 1,
    "defaultOpen": false,
    "icon": "•"
  },
  {
    "menuId": "home.giftConfirm",
    "label": "상품권 지급 확인",
    "route": "home",
    "note": "준비중",
    "enabled": false,
    "section": "01. 통합 현황",
    "sectionId": "home",
    "groupStatus": "준비중",
    "groupOrder": 1,
    "defaultOpen": false,
    "icon": "•"
  },
  {
    "menuId": "home.settlementConfirm",
    "label": "정산 확인",
    "route": "settlement",
    "note": "읽기 전용",
    "enabled": false,
    "section": "01. 통합 현황",
    "sectionId": "home",
    "groupStatus": "준비중",
    "groupOrder": 1,
    "defaultOpen": false,
    "icon": "•"
  },
  {
    "menuId": "home.taskRequest",
    "label": "업무요청",
    "route": "home",
    "note": "준비중",
    "enabled": false,
    "section": "01. 통합 현황",
    "sectionId": "home",
    "groupStatus": "준비중",
    "groupOrder": 1,
    "defaultOpen": false,
    "icon": "•"
  },
  {
    "menuId": "home.errorForward",
    "label": "오류 전달",
    "route": "home",
    "note": "준비중",
    "enabled": false,
    "section": "01. 통합 현황",
    "sectionId": "home",
    "groupStatus": "준비중",
    "groupOrder": 1,
    "defaultOpen": false,
    "icon": "•"
  },
  {
    "menuId": "home.recentAudit",
    "label": "최근 감사 로그",
    "route": "auditLog",
    "note": "읽기 전용",
    "enabled": true,
    "section": "01. 통합 현황",
    "sectionId": "home",
    "groupStatus": "준비중",
    "groupOrder": 1,
    "defaultOpen": false,
    "icon": "•"
  },
  {
    "menuId": "event.ops",
    "label": "행사관리",
    "route": "eventVendor",
    "note": "박람회 준비 기준 메뉴",
    "enabled": true,
    "section": "03. 박람회 준비",
    "sectionId": "eventPrep",
    "groupStatus": "준비중",
    "groupOrder": 3,
    "defaultOpen": false,
    "icon": "•"
  },
  {
    "menuId": "mail.dashboard",
    "label": "메일 / 알림센터",
    "route": "MailCenterDashboardV04",
    "note": "사용 가능 · 메일센터 기능",
    "enabled": true,
    "section": "10. 커뮤니케이션 / 알림",
    "sectionId": "comm",
    "groupStatus": "사용 가능",
    "groupOrder": 10,
    "defaultOpen": true,
    "icon": "▣"
  },
  {
    "menuId": "mail.list",
    "label": "메일 목록",
    "route": "MailCenterServerMailListV01",
    "note": "사용 가능 · 메일센터 기능",
    "enabled": true,
    "section": "10. 커뮤니케이션 / 알림",
    "sectionId": "comm",
    "groupStatus": "사용 가능",
    "groupOrder": 10,
    "defaultOpen": true,
    "icon": "▣"
  },
  {
    "menuId": "mail.compose",
    "label": "메일 작성/발송",
    "route": "MailCenterComposeV01",
    "note": "사용 가능 · 메일센터 기능",
    "enabled": true,
    "section": "10. 커뮤니케이션 / 알림",
    "sectionId": "comm",
    "groupStatus": "사용 가능",
    "groupOrder": 10,
    "defaultOpen": true,
    "icon": "▣"
  },
  {
    "menuId": "mail.calendar",
    "label": "메일 캘린더",
    "route": "MailCenterCalendarV01",
    "note": "사용 가능 · 메일센터 기능",
    "enabled": true,
    "section": "10. 커뮤니케이션 / 알림",
    "sectionId": "comm",
    "groupStatus": "사용 가능",
    "groupOrder": 10,
    "defaultOpen": true,
    "icon": "▣"
  },
  {
    "menuId": "mail.test",
    "label": "테스트 발송",
    "route": "MailCenterSendTestV05",
    "note": "사용 가능 · 메일센터 기능",
    "enabled": true,
    "section": "10. 커뮤니케이션 / 알림",
    "sectionId": "comm",
    "groupStatus": "사용 가능",
    "groupOrder": 10,
    "defaultOpen": true,
    "icon": "▣"
  },
  {
    "menuId": "mail.library",
    "label": "자료함",
    "route": "MailCenterAttachmentLibraryV01",
    "note": "사용 가능 · 메일센터 기능",
    "enabled": true,
    "section": "10. 커뮤니케이션 / 알림",
    "sectionId": "comm",
    "groupStatus": "사용 가능",
    "groupOrder": 10,
    "defaultOpen": true,
    "icon": "▣"
  },
  {
    "menuId": "mail.template",
    "label": "템플릿 관리",
    "route": "MailCenterTemplateV01",
    "note": "사용 가능 · 메일센터 기능",
    "enabled": true,
    "section": "10. 커뮤니케이션 / 알림",
    "sectionId": "comm",
    "groupStatus": "사용 가능",
    "groupOrder": 10,
    "defaultOpen": true,
    "icon": "▣"
  },
  {
    "menuId": "mail.audit",
    "label": "로그/감사 조회",
    "route": "MailCenterLogAuditV01",
    "note": "사용 가능 · 메일센터 기능",
    "enabled": true,
    "section": "10. 커뮤니케이션 / 알림",
    "sectionId": "comm",
    "groupStatus": "사용 가능",
    "groupOrder": 10,
    "defaultOpen": true,
    "icon": "▣"
  },
  {
    "menuId": "mail.account",
    "label": "계정 등록/승인",
    "route": "MailCenterAccountAdminV01",
    "note": "사용 가능 · 메일센터 기능",
    "enabled": true,
    "section": "10. 커뮤니케이션 / 알림",
    "sectionId": "comm",
    "groupStatus": "사용 가능",
    "groupOrder": 10,
    "defaultOpen": true,
    "icon": "▣"
  },
  {
    "menuId": "mail.setting",
    "label": "서명/폴더/설정",
    "route": "MailCenterSettingsV01",
    "note": "사용 가능 · 메일센터 기능",
    "enabled": true,
    "section": "10. 커뮤니케이션 / 알림",
    "sectionId": "comm",
    "groupStatus": "사용 가능",
    "groupOrder": 10,
    "defaultOpen": true,
    "icon": "▣"
  },
  {
    "menuId": "mail.routeIndex",
    "label": "주소표",
    "route": "MailCenterRouteIndexV03",
    "note": "사용 가능 · 메일센터 기능",
    "enabled": true,
    "section": "10. 커뮤니케이션 / 알림",
    "sectionId": "comm",
    "groupStatus": "사용 가능",
    "groupOrder": 10,
    "defaultOpen": true,
    "icon": "▣"
  },
  {
    "menuId": "mail.customerGuideBundle",
    "label": "고객 안내 발송 묶음",
    "route": "home",
    "note": "PORTAL 기준 메뉴",
    "enabled": false,
    "section": "10. 커뮤니케이션 / 알림",
    "sectionId": "comm",
    "groupStatus": "사용 가능",
    "groupOrder": 10,
    "defaultOpen": true,
    "icon": "▣"
  },
  {
    "menuId": "mail.smsKakaoAlimtalk",
    "label": "문자 / 카카오 / 알림톡",
    "route": "home",
    "note": "PORTAL 기준 메뉴",
    "enabled": false,
    "section": "10. 커뮤니케이션 / 알림",
    "sectionId": "comm",
    "groupStatus": "사용 가능",
    "groupOrder": 10,
    "defaultOpen": true,
    "icon": "▣"
  },
  {
    "menuId": "mail.callcenter",
    "label": "콜센터 / 고객응대",
    "route": "home",
    "note": "PORTAL 기준 메뉴",
    "enabled": false,
    "section": "10. 커뮤니케이션 / 알림",
    "sectionId": "comm",
    "groupStatus": "사용 가능",
    "groupOrder": 10,
    "defaultOpen": true,
    "icon": "▣"
  },
  {
    "menuId": "mail.automation",
    "label": "자동화 / 워크플로우",
    "route": "home",
    "note": "PORTAL 기준 메뉴",
    "enabled": false,
    "section": "10. 커뮤니케이션 / 알림",
    "sectionId": "comm",
    "groupStatus": "사용 가능",
    "groupOrder": 10,
    "defaultOpen": true,
    "icon": "▣"
  },
  {
    "menuId": "control.users",
    "label": "권한 / 사용자",
    "route": "controlSettings",
    "note": "관리자 전용",
    "enabled": true,
    "section": "13. 설정 / CONTROL",
    "sectionId": "control",
    "groupStatus": "관리자",
    "groupOrder": 13,
    "defaultOpen": true,
    "icon": "⚙"
  },
  {
    "menuId": "control.profile",
    "label": "권한 프로파일",
    "route": "permissionPolicy",
    "note": "관리자 전용",
    "enabled": true,
    "section": "13. 설정 / CONTROL",
    "sectionId": "control",
    "groupStatus": "관리자",
    "groupOrder": 13,
    "defaultOpen": true,
    "icon": "⚙"
  },
  {
    "menuId": "control.policy",
    "label": "설정 / 정책",
    "route": "permissionPolicy",
    "note": "관리자 전용",
    "enabled": true,
    "section": "13. 설정 / CONTROL",
    "sectionId": "control",
    "groupStatus": "관리자",
    "groupOrder": 13,
    "defaultOpen": true,
    "icon": "⚙"
  },
  {
    "menuId": "control.menu",
    "label": "메뉴 관리",
    "route": "menuRegistry",
    "note": "관리자 전용",
    "enabled": false,
    "section": "13. 설정 / CONTROL",
    "sectionId": "control",
    "groupStatus": "관리자",
    "groupOrder": 13,
    "defaultOpen": true,
    "icon": "⚙"
  },
  {
    "menuId": "control.menuList",
    "label": "전체 메뉴 목록",
    "route": "menuRegistry",
    "note": "준비중",
    "enabled": false,
    "section": "13. 설정 / CONTROL",
    "sectionId": "control",
    "groupStatus": "관리자",
    "groupOrder": 13,
    "defaultOpen": true,
    "icon": "⚙"
  },
  {
    "menuId": "control.parentAdd",
    "label": "상위 메뉴 추가",
    "route": "menuRegistry",
    "note": "준비중",
    "enabled": false,
    "section": "13. 설정 / CONTROL",
    "sectionId": "control",
    "groupStatus": "관리자",
    "groupOrder": 13,
    "defaultOpen": true,
    "icon": "⚙"
  },
  {
    "menuId": "control.childAdd",
    "label": "하위 메뉴 추가",
    "route": "menuRegistry",
    "note": "준비중",
    "enabled": false,
    "section": "13. 설정 / CONTROL",
    "sectionId": "control",
    "groupStatus": "관리자",
    "groupOrder": 13,
    "defaultOpen": true,
    "icon": "⚙"
  },
  {
    "menuId": "control.menuNameEdit",
    "label": "메뉴명 수정",
    "route": "menuRegistry",
    "note": "준비중",
    "enabled": false,
    "section": "13. 설정 / CONTROL",
    "sectionId": "control",
    "groupStatus": "관리자",
    "groupOrder": 13,
    "defaultOpen": true,
    "icon": "⚙"
  },
  {
    "menuId": "control.orderEdit",
    "label": "메뉴 순서 변경",
    "route": "menuRegistry",
    "note": "준비중",
    "enabled": false,
    "section": "13. 설정 / CONTROL",
    "sectionId": "control",
    "groupStatus": "관리자",
    "groupOrder": 13,
    "defaultOpen": true,
    "icon": "⚙"
  },
  {
    "menuId": "control.iconEdit",
    "label": "메뉴 아이콘 설정",
    "route": "menuRegistry",
    "note": "준비중",
    "enabled": false,
    "section": "13. 설정 / CONTROL",
    "sectionId": "control",
    "groupStatus": "관리자",
    "groupOrder": 13,
    "defaultOpen": true,
    "icon": "⚙"
  },
  {
    "menuId": "control.statusEdit",
    "label": "메뉴 상태 설정",
    "route": "menuRegistry",
    "note": "준비중",
    "enabled": false,
    "section": "13. 설정 / CONTROL",
    "sectionId": "control",
    "groupStatus": "관리자",
    "groupOrder": 13,
    "defaultOpen": true,
    "icon": "⚙"
  },
  {
    "menuId": "control.permissionEdit",
    "label": "메뉴 권한 설정",
    "route": "menuRegistry",
    "note": "준비중",
    "enabled": false,
    "section": "13. 설정 / CONTROL",
    "sectionId": "control",
    "groupStatus": "관리자",
    "groupOrder": 13,
    "defaultOpen": true,
    "icon": "⚙"
  },
  {
    "menuId": "control.visibleEdit",
    "label": "메뉴 표시 / 숨김",
    "route": "menuRegistry",
    "note": "준비중",
    "enabled": false,
    "section": "13. 설정 / CONTROL",
    "sectionId": "control",
    "groupStatus": "관리자",
    "groupOrder": 13,
    "defaultOpen": true,
    "icon": "⚙"
  },
  {
    "menuId": "control.readyText",
    "label": "준비중 문구 설정",
    "route": "menuRegistry",
    "note": "준비중",
    "enabled": false,
    "section": "13. 설정 / CONTROL",
    "sectionId": "control",
    "groupStatus": "관리자",
    "groupOrder": 13,
    "defaultOpen": true,
    "icon": "⚙"
  },
  {
    "menuId": "control.routeEdit",
    "label": "메뉴 연결 route 설정",
    "route": "menuRegistry",
    "note": "준비중",
    "enabled": false,
    "section": "13. 설정 / CONTROL",
    "sectionId": "control",
    "groupStatus": "관리자",
    "groupOrder": 13,
    "defaultOpen": true,
    "icon": "⚙"
  },
  {
    "menuId": "control.descriptionEdit",
    "label": "메뉴 설명 설정",
    "route": "menuRegistry",
    "note": "준비중",
    "enabled": false,
    "section": "13. 설정 / CONTROL",
    "sectionId": "control",
    "groupStatus": "관리자",
    "groupOrder": 13,
    "defaultOpen": true,
    "icon": "⚙"
  },
  {
    "menuId": "control.dashboard",
    "label": "CONTROL 대시보드",
    "route": "controlDashboard",
    "note": "관리자 전용",
    "enabled": true,
    "section": "13. 설정 / CONTROL",
    "sectionId": "control",
    "groupStatus": "관리자",
    "groupOrder": 13,
    "defaultOpen": true,
    "icon": "⚙"
  },
  {
    "menuId": "control.audit",
    "label": "로그 / 감사추적",
    "route": "auditLog",
    "note": "관리자 전용",
    "enabled": true,
    "section": "13. 설정 / CONTROL",
    "sectionId": "control",
    "groupStatus": "관리자",
    "groupOrder": 13,
    "defaultOpen": true,
    "icon": "⚙"
  },
  {
    "menuId": "control.diagnostic",
    "label": "CONTROL / 진단 / 배포",
    "route": "controlDiagnostics",
    "note": "관리자 전용",
    "enabled": true,
    "section": "13. 설정 / CONTROL",
    "sectionId": "control",
    "groupStatus": "관리자",
    "groupOrder": 13,
    "defaultOpen": true,
    "icon": "⚙"
  },
  {
    "menuId": "control.backup",
    "label": "백업 / 복구 / 롤백",
    "route": "backupRestore",
    "note": "관리자 전용",
    "enabled": true,
    "section": "13. 설정 / CONTROL",
    "sectionId": "control",
    "groupStatus": "관리자",
    "groupOrder": 13,
    "defaultOpen": true,
    "icon": "⚙"
  },
  {
    "menuId": "control.build",
    "label": "배포 / 빌드 이력",
    "route": "buildRelease",
    "note": "관리자 전용",
    "enabled": true,
    "section": "13. 설정 / CONTROL",
    "sectionId": "control",
    "groupStatus": "관리자",
    "groupOrder": 13,
    "defaultOpen": true,
    "icon": "⚙"
  },
  {
    "menuId": "control.systemConfig",
    "label": "SystemConfig 기준 안내",
    "route": "systemConfigGuide",
    "note": "기준 안내",
    "enabled": true,
    "section": "13. 설정 / CONTROL",
    "sectionId": "control",
    "groupStatus": "관리자",
    "groupOrder": 13,
    "defaultOpen": true,
    "icon": "⚙"
  }
];
}

function mcNativeButtonNavCoreV01GetHtml(activePage) {
  var t = HtmlService.createTemplateFromFile('MC_NativeButtonNavPartialV01');
  t.activePage = activePage || '';
  t.webAppUrl = MAILCENTER_NATIVE_BUTTON_NAV_CORE_V01_WEBAPP_URL;
  t.routesJson = JSON.stringify(mcNativeButtonNavV01GetRoutes());
  t.groupsJson = JSON.stringify(mcNativeButtonNavV01GetGroups());
  return t.evaluate().getContent();
}
