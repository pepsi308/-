/**
 * FEELHAUS PORTAL / MailCenter Calendar Source Apply Event Picker V03 KO SOURCE
 * Build: PORTAL_MC_CALENDAR_SOURCE_APPLY_EVENT_PICKER_V03_KO_SOURCE_20260528
 * Purpose:
 * - ERP_Events / ERP_행사관리 등 실제 ERP 행사 원장 후보를 조회한다.
 * - 실제 존재하는 eventId로 ERP_EVENT 캘린더 연동 일정을 생성할 수 있게 한다.
 * - 원본반영(calSrcApply)은 실행하지 않는다. 승인/원본반영 흐름의 사전 준비만 수행한다.
 */
var MC_CALENDAR_SOURCE_APPLY_EVENT_PICKER_V02_BUILD = 'PORTAL_MC_CALENDAR_SOURCE_APPLY_EVENT_PICKER_V03_KO_SOURCE_20260528';

function calEvtHelp() {
  var r = mcCalEvtV02Base_('calEvtHelp');
  r.ok = true;
  r.message = '실제 ERP eventId 후보 조회 및 ERP_EVENT 캘린더 연동 테스트용 짧은 함수 안내';
  r.runners = [
    { fn:'calEvtTest()', desc:'사전점검: ERP 행사 후보 시트/헤더/필수 함수 확인' },
    { fn:'calEvtList()', desc:'실제 ERP 행사 eventId 후보 10건 조회. 저장 없음' },
    { fn:'calEvtDry()', desc:'첫 번째 실제 eventId로 캘린더 연동 일정 DryRun. 저장 없음' },
    { fn:'calEvtSave()', desc:'첫 번째 실제 eventId로 ERP_EVENT 캘린더 일정 1건 저장. ERP 원본 수정 없음' },
    { fn:'calEvtEdit()', desc:'최근 실제 ERP_EVENT 연동 일정 표시정보 수정. 원본 직접 수정 없음, 승인 필요 상태로 전환' },
    { fn:'calEvtCheck()', desc:'최근 실제 ERP_EVENT 연동 일정과 원본 매칭 상태 확인' },
    { fn:'calEvtListCal()', desc:'최근 ERP_EVENT 캘린더 일정 목록' }
  ];
  r.nextAction = 'calEvtTest() -> calEvtList() -> calEvtDry() 순서로 실행하세요.';
  return mcCalEvtV02Print_(r);
}
function calEvtTest() { return mcCalendarSourceApplyEventPickerV02SelfTest(); }
function calEvtList() { return mcCalendarSourceApplyEventPickerV02ListEvents(); }
function calEvtDry() { return mcCalendarSourceApplyEventPickerV02CreateFromFirstDryRun(); }
function calEvtSave() { return mcCalendarSourceApplyEventPickerV02CreateFromFirstReal(); }
function calEvtEdit() { return mcCalendarSourceApplyEventPickerV02EditRecentActualEvent(); }
function calEvtCheck() { return mcCalendarSourceApplyEventPickerV02CheckRecentActualEvent(); }
function calEvtListCal() { return mcCalendarSourceApplyEventPickerV02ListRecentCalendarLinks(); }

function mcCalendarSourceApplyEventPickerV02SelfTest() {
  var r = mcCalEvtV02Base_('mcCalendarSourceApplyEventPickerV02SelfTest');
  try {
    var ss = mcCalEvtV02OpenMaster_();
    var discovery = mcCalEvtV02DiscoverEventSource_();
    var sample = discovery.sheet ? mcCalEvtV02ReadEventCandidates_(discovery.sheet, discovery.headerMap, 5) : [];
    r.ok = !!ss && !!discovery.sheet && !!discovery.eventIdHeader && typeof mcCalendarUnifiedManualInputV01Create === 'function' && typeof mcCalendarOperationHubV01UpdateEvent === 'function';
    r.checks = {
      masterDbOk: !!ss,
      erpEventSourceSheetFound: !!discovery.sheet,
      sourceSheetName: discovery.sheetName || '',
      eventIdHeaderFound: !!discovery.eventIdHeader,
      eventIdHeader: discovery.eventIdHeader || '',
      candidateCountPreview: sample.length,
      createReady: typeof mcCalendarUnifiedManualInputV01Create === 'function',
      updateReady: typeof mcCalendarOperationHubV01UpdateEvent === 'function',
      sourceApplyReady: typeof calSrcDry === 'function',
      approvalQueueReady: typeof calApprScan === 'function',
      realApplyExecuted: false,
      destructiveRepairExecuted: false
    };
    r.sourceSheetCandidates = mcCalEvtV02SourceSheetCandidates_();
    r.foundSheet = discovery.sheet ? { sheetName: discovery.sheet.getName(), lastRow: discovery.sheet.getLastRow(), lastColumn: discovery.sheet.getLastColumn() } : null;
    r.sampleEvents = sample.map(mcCalEvtV02CompactEvent_);
    r.message = r.ok ? '실제 ERP 행사 eventId 후보 조회 준비 완료' : 'ERP 행사 후보 시트 또는 eventId 헤더/필수 함수가 부족합니다.';
    r.nextAction = r.ok ? 'calEvtList()로 실제 eventId 후보를 확인하세요.' : 'ERP 행사 원장 시트명/헤더(eventId)를 확인하세요.';
  } catch (err) { mcCalEvtV02Catch_(r, err); }
  return mcCalEvtV02Print_(r);
}

function mcCalendarSourceApplyEventPickerV02ListEvents() {
  var r = mcCalEvtV02Base_('mcCalendarSourceApplyEventPickerV02ListEvents');
  try {
    var discovery = mcCalEvtV02DiscoverEventSource_();
    if (!discovery.sheet) throw new Error('ERP 행사 후보 시트를 찾지 못했습니다.');
    if (!discovery.eventIdHeader) throw new Error('ERP 행사 후보 시트에서 eventId 헤더를 찾지 못했습니다.');
    var events = mcCalEvtV02ReadEventCandidates_(discovery.sheet, discovery.headerMap, 10);
    r.ok = true;
    r.sourceSheet = { sheetName: discovery.sheet.getName(), lastRow: discovery.sheet.getLastRow(), lastColumn: discovery.sheet.getLastColumn(), eventIdHeader: discovery.eventIdHeader };
    r.summary = { displayed: events.length, output:'ERP_EVENT_ID_CANDIDATES', realApplyExecuted:false, destructiveRepairExecuted:false };
    r.events = events.map(mcCalEvtV02CompactEvent_);
    r.message = '실제 ERP eventId 후보 조회 완료. 저장/수정은 하지 않았습니다.';
    r.nextAction = events.length ? 'calEvtDry()로 첫 번째 eventId 캘린더 연동 계획을 확인하세요.' : 'ERP 행사 원장에 eventId가 있는 행을 먼저 확인하세요.';
  } catch (err) { mcCalEvtV02Catch_(r, err); }
  return mcCalEvtV02Print_(r);
}

function mcCalendarSourceApplyEventPickerV02CreateFromFirstDryRun() { return mcCalEvtV02CreateFromFirst_(true); }
function mcCalendarSourceApplyEventPickerV02CreateFromFirstReal() { return mcCalEvtV02CreateFromFirst_(false); }

function mcCalEvtV02CreateFromFirst_(dryRun) {
  var r = mcCalEvtV02Base_(dryRun ? 'mcCalendarSourceApplyEventPickerV02CreateFromFirstDryRun' : 'mcCalendarSourceApplyEventPickerV02CreateFromFirstReal');
  try {
    var discovery = mcCalEvtV02DiscoverEventSource_();
    if (!discovery.sheet || !discovery.eventIdHeader) throw new Error('실제 ERP eventId 후보를 찾지 못했습니다. calEvtList()를 먼저 확인하세요.');
    var events = mcCalEvtV02ReadEventCandidates_(discovery.sheet, discovery.headerMap, 1);
    if (!events.length) throw new Error('ERP 행사 원장에 eventId 후보가 없습니다.');
    var event = events[0];
    var before = mcCalEvtV02CalendarStatus_();
    var payload = mcCalEvtV02BuildCalendarPayload_(event, dryRun ? 'Y' : 'N');
    var inner = mcCalendarUnifiedManualInputV01Create(payload);
    var after = mcCalEvtV02CalendarStatus_();
    r.ok = !!inner.ok && (dryRun || !!inner.saved);
    r.dryRun = !!dryRun;
    r.saved = !!inner.saved;
    r.sourceEvent = mcCalEvtV02CompactEvent_(event);
    r.innerBuild = inner.build || '';
    r.innerAction = inner.action || '';
    r.innerMessage = inner.message || '';
    r.validation = inner.validation || {};
    r.calendarEventId = inner.calendarEventId || (inner.record && inner.record.calendarEventId) || '';
    r.record = mcCalEvtV02CompactCalendarRecord_(inner.record || {});
    r.before = before;
    r.after = after;
    r.rowDelta = (after.lastRow || 0) - (before.lastRow || 0);
    r.erpSourceMutated = false;
    r.message = dryRun ? 'DRY RUN: 실제 ERP eventId 기반 캘린더 연동 일정 계획만 반환했습니다.' : '실제 ERP eventId 기반 ERP_EVENT 캘린더 연동 일정을 저장했습니다. ERP 원본은 수정하지 않았습니다.';
    r.nextAction = dryRun ? '결과가 맞으면 calEvtSave()를 실행하세요.' : 'calEvtCheck() 후 calEvtEdit()로 승인 필요 상태를 만들 수 있습니다.';
  } catch (err) { mcCalEvtV02Catch_(r, err); }
  return mcCalEvtV02Print_(r);
}

function mcCalendarSourceApplyEventPickerV02EditRecentActualEvent() {
  var r = mcCalEvtV02Base_('mcCalendarSourceApplyEventPickerV02EditRecentActualEvent');
  try {
    var target = mcCalEvtV02FindRecentActualCalendarLink_();
    if (!target) throw new Error('실제 eventId와 매칭되는 최근 ERP_EVENT 캘린더 일정이 없습니다. calEvtSave()를 먼저 실행하세요.');
    var beforeLog = mcCalEvtV02ChangeLogStatus_();
    var inner = mcCalendarOperationHubV01UpdateEvent({
      calendarEventId: target.calendarEventId,
      title: '[실ERP수정요청] ' + (target.title || target.eventTitle || 'ERP 행사 일정'),
      ownerName: '이용필 총괄',
      ownerUserId: 'USER-YONGPIL-001',
      departmentCode: 'OPERATION',
      participantText: '이용필, 최유라, ERP 행사 담당자',
      agendaText: '실제 ERP eventId 기반 캘린더 수정 요청 검증\n승인 후 원본 반영 가능 여부 확인',
      decisionMemo: 'ERP 원본은 즉시 덮어쓰지 않고 승인 후 Source Apply 단계에서만 반영한다.',
      todoText: '승인큐 등록 확인\ncalApprScan -> calApprApprove -> calSrcDry 순서로 검증',
      sourceWritePolicy: 'SYNC_TO_SOURCE',
      sourceUpdateStatus: 'APPROVAL_REQUIRED',
      changeReason: 'EVENT_PICKER_V02 실제 eventId 기반 캘린더 수정 요청 검증'
    });
    var afterLog = mcCalEvtV02ChangeLogStatus_();
    r.ok = !!inner.ok;
    r.calendarEventId = target.calendarEventId;
    r.eventId = target.eventId;
    r.inner = { ok:!!inner.ok, message:inner.message || '', changedFields:inner.changedFields || [], policy:inner.policy || {}, sourceType:inner.sourceType || '' };
    r.changeLogDelta = (afterLog.lastRow || 0) - (beforeLog.lastRow || 0);
    r.erpSourceMutated = false;
    r.message = r.ok ? '실제 ERP eventId 연동 일정 수정 요청을 만들었습니다. 원본은 직접 수정하지 않았습니다.' : '실제 ERP eventId 연동 일정 수정 요청 실패';
    r.nextAction = 'calApprScan() -> calApprApproveDry() -> calApprApprove() -> calSrcDry() 순서로 진행하세요.';
  } catch (err) { mcCalEvtV02Catch_(r, err); }
  return mcCalEvtV02Print_(r);
}

function mcCalendarSourceApplyEventPickerV02CheckRecentActualEvent() {
  var r = mcCalEvtV02Base_('mcCalendarSourceApplyEventPickerV02CheckRecentActualEvent');
  try {
    var target = mcCalEvtV02FindRecentActualCalendarLink_();
    if (!target) throw new Error('실제 eventId와 매칭되는 최근 ERP_EVENT 캘린더 일정이 없습니다.');
    var source = mcCalEvtV02ResolveEventSource_(target.eventId);
    r.ok = !!source.ready;
    r.calendar = target;
    r.source = { ready:!!source.ready, sheetName:source.sheetName || '', rowNumber:source.rowNumber || -1, eventId:target.eventId || '' };
    r.message = r.ok ? '최근 ERP_EVENT 캘린더 일정이 실제 ERP 원본 eventId와 매칭됩니다.' : '최근 ERP_EVENT 캘린더 일정의 eventId가 원본과 매칭되지 않습니다.';
    r.nextAction = r.ok ? '수정 요청이 필요하면 calEvtEdit()을 실행하세요.' : 'calEvtList()에서 실제 eventId 후보를 다시 확인하세요.';
  } catch (err) { mcCalEvtV02Catch_(r, err); }
  return mcCalEvtV02Print_(r);
}

function mcCalendarSourceApplyEventPickerV02ListRecentCalendarLinks() {
  var r = mcCalEvtV02Base_('mcCalendarSourceApplyEventPickerV02ListRecentCalendarLinks');
  try {
    var list = mcCalEvtV02ListRecentCalendarLinks_(10);
    r.ok = true;
    r.summary = { displayed:list.length, output:'RECENT_ERP_EVENT_CALENDAR_LINKS' };
    r.items = list;
    r.message = '최근 ERP_EVENT 캘린더 연동 일정 목록 조회 완료';
    r.nextAction = '실제 원본 매칭은 calEvtCheck()로 확인하세요.';
  } catch (err) { mcCalEvtV02Catch_(r, err); }
  return mcCalEvtV02Print_(r);
}

function mcCalEvtV02DiscoverEventSource_() {
  var ss = mcCalEvtV02OpenMaster_();
  var names = mcCalEvtV02SourceSheetCandidates_();
  for (var i = 0; i < names.length; i++) {
    var sh = ss.getSheetByName(names[i]);
    if (!sh) continue;
    var hm = mcCalEvtV02HeaderMap_(sh);
    var eid = mcCalEvtV02PickExistingHeader_(hm, ['eventId','eventID','event_id','행사ID','행사Id','행사id']);
    return { sheet:sh, sheetName:sh.getName(), headerMap:hm, eventIdHeader:eid };
  }
  return { sheet:null, sheetName:'', headerMap:{}, eventIdHeader:'' };
}
function mcCalEvtV02SourceSheetCandidates_() { return ['ERP_행사관리','행사관리','ERP_Events','ERP_EventMaster','ERP_Event','ERP_행사','EVENT_MASTER','EVENTS','Events','EventMaster','EventList','EventCenterEvents','행사']; }
function mcCalEvtV02ReadEventCandidates_(sheet, hm, limit) {
  limit = Math.max(1, Math.min(Number(limit || 10), 30));
  var values = sheet.getDataRange().getValues();
  var eventIdHeader = mcCalEvtV02PickExistingHeader_(hm, ['eventId','eventID','event_id','행사ID','행사Id','행사id']);
  if (!eventIdHeader || values.length < 2) return [];
  var out = [];
  for (var r = values.length - 1; r >= 1 && out.length < limit; r--) {
    var obj = mcCalEvtV02RowToObj_(values[r], hm, r + 1);
    var eventId = obj[eventIdHeader];
    if (!eventId) continue;
    obj._sourceSheetName = sheet.getName();
    obj._rowNumber = r + 1;
    obj._eventIdHeader = eventIdHeader;
    obj.eventId = obj.eventId || eventId;
    out.push(obj);
  }
  return out;
}
function mcCalEvtV02BuildCalendarPayload_(ev, dryRun) {
  var title = mcCalEvtV02PickValue_(ev, ['eventTitle','title','eventName','name','행사명','행사명칭']) || 'ERP 행사 연동 일정';
  var startAt = mcCalEvtV02NormalizeDateText_(mcCalEvtV02PickValue_(ev, ['startAt','eventStartAt','startDate','scheduledAt','행사시작일','시작일','시작일자'])) || mcCalEvtV02TodayAt_('15:00:00');
  var endAt = mcCalEvtV02NormalizeDateText_(mcCalEvtV02PickValue_(ev, ['endAt','eventEndAt','endDate','행사종료일','종료일','종료일자'])) || mcCalEvtV02TodayAt_('16:00:00');
  var location = mcCalEvtV02PickValue_(ev, ['location','eventLocation','venue','eventPlace','place','장소','행사장소','행사장']) || '행사 운영센터';
  var vendorId = mcCalEvtV02PickValue_(ev, ['vendorId','업체ID']) || '';
  var customerId = mcCalEvtV02PickValue_(ev, ['customerId','고객ID']) || '';
  return {
    dryRun: dryRun,
    title: '[실ERP연동] ' + title,
    sourceType: 'ERP_EVENT',
    sourceModule: 'ERP_EVENT_CENTER',
    sourceId: ev.eventId || '',
    eventId: ev.eventId || '',
    vendorId: vendorId,
    customerId: customerId,
    relatedEventId: ev.eventId || '',
    relatedVendorId: vendorId,
    relatedCustomerId: customerId,
    description: '실제 ERP 행사 원장 eventId 기준으로 생성된 캘린더 연동 일정입니다. ERP 원본은 직접 수정하지 않습니다.',
    startAt: startAt,
    endAt: endAt,
    location: location,
    attendeesText: 'feelhaus@feelhausfair.com',
    organizerEmail: 'feelhaus@feelhausfair.com',
    ownerName: mcCalEvtV02PickValue_(ev, ['ownerName','managerName','manager','담당자','담당','담당자명']) || '이용필 총괄',
    ownerUserId: mcCalEvtV02PickValue_(ev, ['ownerUserId','managerId']) || '',
    departmentCode: mcCalEvtV02PickValue_(ev, ['departmentCode','department']) || 'OPERATION',
    eventGroupType: 'FAIR_EVENT',
    operationType: 'ERP_EVENT_LINK',
    participantText: '이용필, 최유라, 행사 운영 담당자',
    externalPartyText: mcCalEvtV02PickValue_(ev, ['councilName','협의회명']) || '입주예정자 협의회',
    agendaText: '실제 ERP eventId 기반 캘린더 연동 확인\n행사 운영 일정 변경 승인 흐름 확인',
    decisionMemo: '캘린더는 ERP 원장을 참조하며 원본 직접 덮어쓰기는 승인 후 별도 단계에서만 수행한다.',
    todoText: '승인큐와 Source Apply 단계 검증',
    councilName: mcCalEvtV02PickValue_(ev, ['councilName','협의회명']) || '입주예정자 협의회',
    fairName: title,
    meetingPurpose: '실제 ERP 행사 원장 연동 검증',
    meetingMethod: 'OFFLINE',
    presentationType: 'COUNCIL',
    categoryCode: 'EVENT',
    customTypeName: '실제 ERP 행사연동',
    priority: 'HIGH',
    privacyLevel: 'DEFAULT',
    busyStatus: 'BUSY',
    repeatType: 'NONE',
    reminderMinutesText: '30,1440',
    eventStatus: 'SCHEDULED',
    syncTarget: 'NONE',
    sourceWritePolicy: 'READONLY_SOURCE',
    sourceUpdateStatus: 'NOT_REQUIRED',
    changeReason: 'EVENT_PICKER_V02 실제 ERP eventId 기반 캘린더 연동 생성'
  };
}
function mcCalEvtV02FindRecentActualCalendarLink_() {
  var list = mcCalEvtV02ListRecentCalendarLinks_(30);
  for (var i = 0; i < list.length; i++) {
    if (list[i].eventId && mcCalEvtV02ResolveEventSource_(list[i].eventId).ready) return list[i];
  }
  return null;
}
function mcCalEvtV02ListRecentCalendarLinks_(limit) {
  limit = Math.max(1, Math.min(Number(limit || 10), 30));
  var ss = mcCalEvtV02OpenMaster_();
  var sh = ss.getSheetByName('MAILCENTER_CalendarEvents');
  if (!sh) return [];
  var values = sh.getDataRange().getValues();
  if (values.length < 2) return [];
  var hm = mcCalEvtV02HeaderMap_(sh);
  var out = [];
  for (var r = values.length - 1; r >= 1 && out.length < limit; r--) {
    var obj = mcCalEvtV02RowToObj_(values[r], hm, r + 1);
    if (String(obj.sourceType || '').toUpperCase() !== 'ERP_EVENT') continue;
    out.push({ rowNumber:r + 1, calendarEventId:obj.calendarEventId || '', sourceType:obj.sourceType || '', eventId:obj.eventId || obj.relatedEventId || '', vendorId:obj.vendorId || '', customerId:obj.customerId || '', title:obj.title || obj.eventTitle || '', startAt:obj.startAt || '', endAt:obj.endAt || '', ownerName:obj.ownerName || '', sourceWritePolicy:obj.sourceWritePolicy || '', sourceUpdateStatus:obj.sourceUpdateStatus || '' });
  }
  return out;
}
function mcCalEvtV02ResolveEventSource_(eventId) {
  var discovery = mcCalEvtV02DiscoverEventSource_();
  var out = { ready:false, sheetName:discovery.sheetName || '', rowNumber:-1 };
  if (!eventId || !discovery.sheet || !discovery.eventIdHeader) return out;
  var values = discovery.sheet.getDataRange().getValues();
  var col = discovery.headerMap[discovery.eventIdHeader];
  for (var i = 1; i < values.length; i++) {
    if (String(values[i][col] || '') === String(eventId)) {
      out.ready = true; out.rowNumber = i + 1; return out;
    }
  }
  return out;
}
function mcCalEvtV02CompactEvent_(ev) { return { sourceSheetName:ev._sourceSheetName || '', rowNumber:ev._rowNumber || '', eventId:ev.eventId || '', title:mcCalEvtV02PickValue_(ev, ['eventTitle','title','eventName','name','행사명','행사명칭']) || '', startAt:mcCalEvtV02PickValue_(ev, ['startAt','eventStartAt','startDate','scheduledAt','행사시작일','시작일','시작일자']) || '', endAt:mcCalEvtV02PickValue_(ev, ['endAt','eventEndAt','endDate','행사종료일','종료일','종료일자']) || '', location:mcCalEvtV02PickValue_(ev, ['location','eventLocation','venue','eventPlace','place','장소','행사장소','행사장']) || '', ownerName:mcCalEvtV02PickValue_(ev, ['ownerName','managerName','manager','담당자','담당','담당자명']) || '' }; }
function mcCalEvtV02CompactCalendarRecord_(rec) { return { calendarEventId:rec.calendarEventId || '', sourceType:rec.sourceType || '', eventId:rec.eventId || '', vendorId:rec.vendorId || '', customerId:rec.customerId || '', title:rec.title || rec.eventTitle || '', startAt:rec.startAt || '', endAt:rec.endAt || '', ownerName:rec.ownerName || '', eventGroupType:rec.eventGroupType || '', operationType:rec.operationType || '', sourceWritePolicy:rec.sourceWritePolicy || '', sourceUpdateStatus:rec.sourceUpdateStatus || '', eventStatus:rec.eventStatus || rec.status || '' }; }
function mcCalEvtV02CalendarStatus_() { var ss = mcCalEvtV02OpenMaster_(); var sh = ss.getSheetByName('MAILCENTER_CalendarEvents'); return sh ? { sheetName:sh.getName(), exists:true, lastRow:sh.getLastRow(), lastColumn:sh.getLastColumn() } : { sheetName:'MAILCENTER_CalendarEvents', exists:false, lastRow:0, lastColumn:0 }; }
function mcCalEvtV02ChangeLogStatus_() { var ss = mcCalEvtV02OpenMaster_(); var sh = ss.getSheetByName('MAILCENTER_CalendarChangeLogs'); return sh ? { sheetName:sh.getName(), exists:true, lastRow:sh.getLastRow(), lastColumn:sh.getLastColumn() } : { sheetName:'MAILCENTER_CalendarChangeLogs', exists:false, lastRow:0, lastColumn:0 }; }
function mcCalEvtV02OpenMaster_() { if (typeof mcCalendarUnifiedManualInputV01OpenMaster_ === 'function') return mcCalendarUnifiedManualInputV01OpenMaster_(); return SpreadsheetApp.getActiveSpreadsheet(); }
function mcCalEvtV02HeaderMap_(sheetOrHeaders) { var headers = Array.isArray(sheetOrHeaders) ? sheetOrHeaders : sheetOrHeaders.getRange(1,1,1,Math.max(sheetOrHeaders.getLastColumn(),1)).getValues()[0]; var m = {}; headers.forEach(function(h,i){ if (h !== '') m[String(h).trim()] = i; }); return m; }
function mcCalEvtV02RowToObj_(row, hm, rowNumber) { var o = { rowNumber:rowNumber }; Object.keys(hm).forEach(function(k){ o[k] = row[hm[k]]; }); return o; }
function mcCalEvtV02PickExistingHeader_(hm, arr) { for (var i = 0; i < arr.length; i++) if (hm[arr[i]] !== undefined) return arr[i]; return ''; }
function mcCalEvtV02PickValue_(obj, arr) { for (var i = 0; i < arr.length; i++) { var v = obj[arr[i]]; if (v !== undefined && v !== null && String(v) !== '') return v; } return ''; }
function mcCalEvtV02NormalizeDateText_(v) { if (!v) return ''; if (Object.prototype.toString.call(v) === '[object Date]' && !isNaN(v.getTime())) return Utilities.formatDate(v, 'Asia/Seoul', 'yyyy-MM-dd HH:mm:ss'); return String(v); }
function mcCalEvtV02TodayAt_(timeText) { return Utilities.formatDate(new Date(), 'Asia/Seoul', 'yyyy-MM-dd') + ' ' + timeText; }
function mcCalEvtV02Now_() { return Utilities.formatDate(new Date(), 'Asia/Seoul', 'yyyy-MM-dd HH:mm:ss'); }
function mcCalEvtV02Base_(action) { return { ok:false, build:MC_CALENDAR_SOURCE_APPLY_EVENT_PICKER_V02_BUILD, action:action, generatedAt:mcCalEvtV02Now_(), realApplyExecuted:false, destructiveRepairExecuted:false, warnings:[], errors:[] }; }
function mcCalEvtV02Catch_(r, err) { r.ok = false; r.message = String(err && err.message ? err.message : err); r.errors.push({ message:r.message, stack:String(err && err.stack ? err.stack : '') }); r.nextAction = '오류 메시지와 ERP 행사 원장 eventId 헤더를 확인하세요.'; }
function mcCalEvtV02Print_(r) { r.endedAt = mcCalEvtV02Now_(); Logger.log('JSON_COMPACT_RESULT: ' + JSON.stringify(r)); return r; }
