/**
 * PORTAL_CALENDAR_STEP01_MODAL_LIST_VERIFY_V01_20260531
 *
 * Scope:
 * - Step 01 only: modal close + full monthly list after save + month navigation stability.
 * - Does not verify or change Google/Naver server integration.
 * - Read-only, no external API, no sheet mutation.
 */
function portalCalendarStep01ModalListVerifyV01() {
  var out = {
    ok: false,
    build: 'PORTAL_CALENDAR_STEP01_MODAL_LIST_VERIFY_V01_20260531',
    action: 'portalCalendarStep01ModalListVerifyV01',
    safety: 'READ_ONLY_NO_API_NO_SHEET_MUTATION',
    scope: 'UI_ONLY_MODAL_CLOSE_FULL_LIST_MONTH_NAV',
    checks: {},
    fatal: [],
    warnings: [],
    generatedAt: Utilities.formatDate(new Date(), 'Asia/Seoul', 'yyyy-MM-dd HH:mm:ss')
  };

  try {
    var html = HtmlService.createHtmlOutputFromFile('MC_CalendarViewV01').getContent();
    function has(s){ return String(html || '').indexOf(s) >= 0; }

    out.checks.uiLoaded = html.length > 1000;
    out.checks.closeManualEventModal = has('function closeManualEventModal()');
    out.checks.forceDisplayNone = has("setProperty('display','none','important')");
    out.checks.successCloseImmediate = has('closeManualEventModal();\n      setTimeout(closeManualEventModal,50);');
    out.checks.successCloseRetry = has('setTimeout(closeManualEventModal,200);');
    out.checks.fullListAfterSave = has("fhRenderPostSaveListV09J16A('',doneMsg");
    out.checks.reloadFullListAfterSave = has("fhReloadMonthAfterManualSaveV09J16A('',doneMsg");
    out.checks.noDayFocusAfterSave = has("reloadMonth({listMode:'all',message:state.pendingFocusMessage})");
    out.checks.moveMonthClearsFocus = has("function moveMonth(delta)") && has("state.pendingFocusDayKey='';");
    out.checks.goTodayClearsFocus = has("function goToday()") && has("reloadMonth({listMode:'all'});");
    out.checks.renderListExists = has('function renderList()');
    out.checks.renderCalendarExists = has('function renderCalendar()');
    out.checks.saveManualEventExists = has('function saveManualEvent()');

    Object.keys(out.checks).forEach(function(k){
      if (!out.checks[k]) out.fatal.push(k);
    });
    out.ok = out.fatal.length === 0;
  } catch (err) {
    out.ok = false;
    out.fatal.push(err && err.stack ? String(err.stack) : String(err && err.message ? err.message : err));
  }

  Logger.log('JSON_COMPACT_RESULT: ' + JSON.stringify(out));
  return out;
}
