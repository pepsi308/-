/**
 * FEELHAUS MailCenter Route Index Shell V01
 * Build: MC_ROUTE_INDEX_V01_20260519
 *
 * Purpose:
 * - MailCenter 성공 잠금 주소표
 * - 메인 대시보드/Compose/자료함/템플릿/로그 화면을 건드리지 않음
 * - 독립 진입 화면으로만 사용
 */

var MC_ROUTE_INDEX_V01_BUILD = 'MC_ROUTE_INDEX_V01_20260519';

function runMcRouteIndexV01Smoke() {
  var result = {
    ok: false,
    build: MC_ROUTE_INDEX_V01_BUILD,
    action: 'runMcRouteIndexV01Smoke',
    generatedAt: Utilities.formatDate(new Date(), Session.getScriptTimeZone() || 'Asia/Seoul', 'yyyy-MM-dd HH:mm:ss'),
    message: '',
    checks: []
  };

  try {
    result.checks.push({
      key: 'HandleGetReady',
      ok: typeof mcRouteIndexV01HandleGet === 'function',
      message: '주소표 화면 핸들러 확인'
    });
    result.checks.push({
      key: 'RouteDataReady',
      ok: typeof mcRouteIndexV01GetData === 'function',
      message: '주소표 데이터 함수 확인'
    });
    result.checks.push({
      key: 'RouterReady',
      ok: typeof mcRouterHandleGet === 'function',
      message: 'MailCenter Router 함수 확인'
    });

    result.ok = result.checks.every(function(c) { return !!c.ok; });
    result.message = result.ok ? 'MailCenter Route Index V01 준비 완료' : 'MailCenter Route Index V01 점검 필요';
  } catch (err) {
    result.ok = false;
    result.message = String(err && err.message ? err.message : err);
  }

  Logger.log('JSON_COMPACT_RESULT: ' + JSON.stringify(result));
  return result;
}

function mcRouteIndexV01GetData() {
  return {
    ok: true,
    build: MC_ROUTE_INDEX_V01_BUILD,
    action: 'mcRouteIndexV01GetData',
    generatedAt: Utilities.formatDate(new Date(), Session.getScriptTimeZone() || 'Asia/Seoul', 'yyyy-MM-dd HH:mm:ss'),
    message: 'MailCenter 성공 잠금 주소표',
    currentStableCompose: 'MC_COMPOSE_SAFE_ROLLBACK_DRIVE_LINK_V01_20260519',
    routes: [
      {
        group: '기본',
        page: 'MailCenterRouteIndexV01',
        title: 'MailCenter 주소표',
        status: 'LOCKED',
        desc: '성공 잠금 주소와 보류 기능을 확인하는 독립 화면'
      },
      {
        group: '대시보드',
        page: 'MailCenterDashboardV04',
        title: '대시보드 V04',
        status: 'LOCKED',
        desc: '계정 현황, 발송 로그 조회'
      },
      {
        group: '발송',
        page: 'MailCenterComposeV01',
        title: '메일 작성/발송',
        status: 'LOCKED',
        desc: '템플릿, 서명, 직접 Drive 링크 발송 안정본'
      },
      {
        group: '발송',
        page: 'MailCenterSendTestV05',
        title: '테스트 발송',
        status: 'LOCKED',
        desc: '계정별 테스트 발송'
      },
      {
        group: '자료',
        page: 'MailCenterAttachmentLibraryV01',
        title: '자료함',
        status: 'LOCKED',
        desc: '다중 업로드, 업로드 진행상태, 리스트화'
      },
      {
        group: '자료',
        page: 'MailCenterTemplateV01',
        title: '템플릿 관리',
        status: 'LOCKED',
        desc: '메일 템플릿 등록/수정/상태관리'
      },
      {
        group: '운영',
        page: 'MailCenterLogAuditV01',
        title: '로그/감사 조회',
        status: 'LOCKED',
        desc: 'SendLogs, ComposeLogs, AuditLogs 조회'
      },
      {
        group: '운영',
        page: 'MailCenterAccountAdminV01',
        title: '계정 등록/승인',
        status: 'LOCKED',
        desc: '직원/업체 원본 연결형 계정 관리, OAuth 승인'
      },
      {
        group: '운영',
        page: 'MailCenterSettingsV01',
        title: '서명/폴더/설정',
        status: 'LOCKED',
        desc: '서명, 폴더, 기본 발신계정 관리'
      }
    ],
    hold: [
      {
        name: 'MC_COMPOSE_ATTACHMENT_PICKER_V02',
        status: 'HOLD',
        reason: 'Compose 직접 삽입 시 자료함 불러오는 중 먹통/빈페이지 발생'
      },
      {
        name: 'MAILCENTER_DASHBOARD_MAIN_LINK_APPLY_V01',
        status: 'DISCARDED',
        reason: '대시보드 로그/메뉴/발송 동작 깨짐'
      }
    ]
  };
}

function mcRouteIndexV01HandleGet(e) {
  var t = HtmlService.createTemplateFromFile('MC_RouteIndexViewV01');
  t.build = MC_ROUTE_INDEX_V01_BUILD;
  t.initialJson = JSON.stringify(mcRouteIndexV01GetData());

  return t.evaluate()
    .setTitle('FEELHAUS MailCenter Route Index')
    .setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL);
}
