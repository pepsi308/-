/**
 * FEELHAUS MailCenter Route Index Shell V03
 * Build: MC_ROUTE_INDEX_LINK_FIX_V03_20260519
 *
 * Purpose:
 * - V02에서 ScriptApp.getService().getUrl()이 편집기 실행 시 빈값 반환 가능
 * - V03는 현재 안정 WebApp URL fallback 고정
 * - Route Index 열기 버튼 빈페이지 방지
 */

var MC_ROUTE_INDEX_LINK_FIX_V03_BUILD = 'MC_ROUTE_INDEX_LINK_FIX_V03_20260519';
var MC_ROUTE_INDEX_LINK_FIX_V03_FALLBACK_URL = 'https://script.google.com/macros/s/AKfycbxCyFE7zf4vE8nsfjOeWX0pC56SqU84gm8ie8Txa3qHQGEusJCZeljzCdYeOmZxUVYvjA/exec';

function runMcRouteIndexV03Smoke() {
  var result = {
    ok: false,
    build: MC_ROUTE_INDEX_LINK_FIX_V03_BUILD,
    action: 'runMcRouteIndexV03Smoke',
    generatedAt: Utilities.formatDate(new Date(), Session.getScriptTimeZone() || 'Asia/Seoul', 'yyyy-MM-dd HH:mm:ss'),
    message: '',
    checks: []
  };

  try {
    var webAppUrl = mcRouteIndexV03GetWebAppUrl_();

    result.checks.push({
      key: 'HandleGetReady',
      ok: typeof mcRouteIndexV03HandleGet === 'function',
      message: '주소표 V03 화면 핸들러 확인'
    });
    result.checks.push({
      key: 'RouteDataReady',
      ok: typeof mcRouteIndexV03GetData === 'function',
      message: '주소표 V03 데이터 함수 확인'
    });
    result.checks.push({
      key: 'WebAppUrlReady',
      ok: /^https:\/\/script\.google\.com\/macros\/s\//.test(webAppUrl),
      message: 'WebApp 절대 URL fallback 확인: ' + webAppUrl
    });
    result.checks.push({
      key: 'RouterReady',
      ok: typeof mcRouterHandleGet === 'function',
      message: 'MailCenter Router 함수 확인'
    });

    result.ok = result.checks.every(function(c) { return !!c.ok; });
    result.message = result.ok ? 'MailCenter Route Index Link Fix V03 준비 완료' : 'MailCenter Route Index Link Fix V03 점검 필요';
  } catch (err) {
    result.ok = false;
    result.message = String(err && err.message ? err.message : err);
  }

  Logger.log('JSON_COMPACT_RESULT: ' + JSON.stringify(result));
  return result;
}

function mcRouteIndexV03GetData() {
  var baseUrl = mcRouteIndexV03GetWebAppUrl_();

  return {
    ok: true,
    build: MC_ROUTE_INDEX_LINK_FIX_V03_BUILD,
    action: 'mcRouteIndexV03GetData',
    generatedAt: Utilities.formatDate(new Date(), Session.getScriptTimeZone() || 'Asia/Seoul', 'yyyy-MM-dd HH:mm:ss'),
    message: 'MailCenter 성공 잠금 주소표 V3',
    baseUrl: baseUrl,
    currentStableCompose: 'MC_COMPOSE_SAFE_ROLLBACK_DRIVE_LINK_V01_20260519',
    routes: [
      { group: '기본', page: 'MailCenterRouteIndexV03', title: 'MailCenter 주소표 V3', status: 'LOCKED', desc: '고정 WebApp URL 기반 성공 잠금 주소표' },
      { group: '대시보드', page: 'MailCenterDashboardV04', title: '대시보드 V04', status: 'LOCKED', desc: '계정 현황, 발송 로그 조회' },
      { group: '목록', page: 'MailCenterServerMailListV01', title: '메일 목록', status: 'LOCKED', desc: 'Gmail 서버 메일 목록 빠른 로딩, 답장/전달/로그/자료함 연결' },
      { group: '발송', page: 'MailCenterComposeV01', title: '메일 작성/발송', status: 'LOCKED', desc: '템플릿, 서명, 직접 Drive 링크 발송 안정본' },
      { group: '발송', page: 'MailCenterSendTestV05', title: '테스트 발송', status: 'LOCKED', desc: '계정별 테스트 발송' },
      { group: '자료', page: 'MailCenterAttachmentLibraryV01', title: '자료함', status: 'LOCKED', desc: '다중 업로드, 업로드 진행상태, 리스트화' },
      { group: '자료', page: 'MailCenterTemplateV01', title: '템플릿 관리', status: 'LOCKED', desc: '메일 템플릿 등록/수정/상태관리' },
      { group: '운영', page: 'MailCenterLogAuditV01', title: '로그/감사 조회', status: 'LOCKED', desc: 'SendLogs, ComposeLogs, AuditLogs 조회' },
      { group: '운영', page: 'MailCenterAccountAdminV01', title: '계정 등록/승인', status: 'LOCKED', desc: '직원/업체 원본 연결형 계정 관리, OAuth 승인' },
      { group: '운영', page: 'MailCenterSettingsV01', title: '서명/폴더/설정', status: 'LOCKED', desc: '서명, 폴더, 기본 발신계정 관리' }
    ],
    hold: [
      { name: 'MC_COMPOSE_ATTACHMENT_PICKER_V02', status: 'HOLD', reason: 'Compose 직접 삽입 시 자료함 불러오는 중 먹통/빈페이지 발생' },
      { name: 'MC_COMPOSE_ATTACHMENT_PICKER_V02_REAPPLY', status: 'HOLD', reason: '재적용 후에도 화면 안정성 부족' },
      { name: 'MAILCENTER_DASHBOARD_MAIN_LINK_APPLY_V01', status: 'DISCARDED', reason: '대시보드 로그/메뉴/발송 동작 깨짐' }
    ]
  };
}

function mcRouteIndexV03HandleGet(e) {
  var t = HtmlService.createTemplateFromFile('MC_RouteIndexViewV03');
  t.build = MC_ROUTE_INDEX_LINK_FIX_V03_BUILD;
  t.initialJson = JSON.stringify(mcRouteIndexV03GetData());

  return t.evaluate()
    .setTitle('FEELHAUS MailCenter Route Index V3')
    .setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL);
}

function mcRouteIndexV03GetWebAppUrl_() {
  var url = '';
  try {
    url = ScriptApp.getService().getUrl() || '';
  } catch (err) {
    url = '';
  }
  if (!url) url = MC_ROUTE_INDEX_LINK_FIX_V03_FALLBACK_URL;
  return String(url || '').trim();
}


function runMcRouteIndexNoSplitFix0128Smoke() {
  var result = {
    ok: false,
    build: 'MC_MIN_ERROR_FIX_0128_20260520',
    action: 'runMcRouteIndexNoSplitFix0128Smoke',
    generatedAt: Utilities.formatDate(new Date(), Session.getScriptTimeZone() || 'Asia/Seoul', 'yyyy-MM-dd HH:mm:ss'),
    message: '',
    checks: []
  };
  try {
    result.checks.push({key:'RouteIndexV03HandlerReady', ok: typeof mcRouteIndexV03HandleGet === 'function', message:'주소표 V03 핸들러 확인'});
    result.checks.push({key:'NoSplitPatchReady', ok: true, message:'주소표 분할 방지 패치 확인'});
    result.ok = result.checks.every(function(c){return !!c.ok;});
    result.message = result.ok ? '주소표 분할 방지 미니 수정 준비 완료' : '주소표 분할 방지 미니 수정 점검 필요';
  } catch (err) {
    result.ok = false;
    result.message = String(err && err.message ? err.message : err);
  }
  Logger.log('JSON_COMPACT_RESULT: ' + JSON.stringify(result));
  return result;
}
