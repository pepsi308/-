/**
 * PORTAL_MC_CALENDAR_OPERATION_HUB_UI_BINDING_V02_20260528
 * Verifies that the actual MailCenter Calendar route renders the operation-grade manual input UI.
 */
var MC_CALENDAR_OPERATION_HUB_UI_BINDING_V02_BUILD = 'PORTAL_MC_CALENDAR_OPERATION_HUB_UI_BINDING_V02_20260528';

function mcCalendarOperationHubUiBindingV02SelfTest() {
  var result = mcCalendarOperationHubUiBindingV02BaseResult_('mcCalendarOperationHubUiBindingV02SelfTest');
  try {
    var html = '';
    var renderedOk = false;
    if (typeof mcCalendarShellV01HandleGet === 'function') {
      var out = mcCalendarShellV01HandleGet({ parameter: { page: 'MailCenterCalendarV01' } });
      if (out && typeof out.getContent === 'function') {
        html = String(out.getContent() || '');
        renderedOk = true;
      }
    }
    var markers = mcCalendarOperationHubUiBindingV02RequiredMarkers_();
    var markerResults = markers.map(function(m) { return { marker: m, ok: html.indexOf(m) >= 0 }; });
    var missing = markerResults.filter(function(x) { return !x.ok; }).map(function(x) { return x.marker; });
    result.checks = {
      calendarShellReady: typeof mcCalendarShellV01HandleGet === 'function',
      renderedHtmlOk: renderedOk,
      renderedLength: html.length,
      operationMarkerOk: html.indexOf('OPERATION_HUB_UI_BINDING_V02_MARKER') >= 0,
      missingMarkerCount: missing.length,
      createReady: typeof mcCalendarUnifiedManualInputV01Create === 'function',
      updateReady: typeof mcCalendarOperationHubV01UpdateEvent === 'function'
    };
    result.markerResults = markerResults;
    result.missingMarkers = missing;
    result.ok = !!(renderedOk && missing.length === 0 && result.checks.createReady && result.checks.updateReady);
    result.message = result.ok
      ? '운영 캘린더 UI V02가 실제 Calendar route HTML에 반영되어 있습니다.'
      : '운영 캘린더 UI V02 일부가 실제 Calendar route HTML에 반영되지 않았습니다. missingMarkers를 확인하세요.';
    result.nextAction = result.ok
      ? '배포 화면을 강력 새로고침한 뒤 수동일정 등록 모달 상단의 OPERATION_HUB_UI_BINDING_V02 문구를 확인하세요.'
      : '업로드된 PORTAL 폴더 기준으로 MC_CalendarViewV01.html / MC_CalendarShellV01.js가 실제 배포본에 반영됐는지 확인하세요.';
  } catch (err) {
    result.ok = false;
    result.errors.push(mcCalendarOperationHubUiBindingV02Err_(err));
    result.message = String(err && err.message ? err.message : err);
  }
  return mcCalendarOperationHubUiBindingV02Finish_(result);
}

function mcCalendarOperationHubUiBindingV02CheckRenderedHtml() {
  var result = mcCalendarOperationHubUiBindingV02SelfTest();
  result.action = 'mcCalendarOperationHubUiBindingV02CheckRenderedHtml';
  return mcCalendarOperationHubUiBindingV02Finish_(result);
}

function mcCalendarOperationHubUiBindingV02CheckMonthPayloadRecent() {
  var result = mcCalendarOperationHubUiBindingV02BaseResult_('mcCalendarOperationHubUiBindingV02CheckMonthPayloadRecent');
  try {
    if (typeof mcCalendarShellV01GetMonthData !== 'function') throw new Error('mcCalendarShellV01GetMonthData 함수가 없습니다.');
    var now = new Date();
    var month = mcCalendarShellV01GetMonthData({ year: now.getFullYear(), month: now.getMonth() + 1 }) || {};
    var events = month.events || [];
    var manual = events.filter(function(e) { return String(e.sourceType || '').toUpperCase() === 'MANUAL'; }).slice(-5).reverse();
    result.ok = !!month.ok;
    result.message = '월간 payload의 최근 MANUAL 운영 필드 포함 여부를 확인했습니다.';
    result.summary = { totalEvents: events.length, manualDisplayed: manual.length };
    result.recentManualPayload = manual.map(function(e) {
      return {
        calendarEventId: e.calendarEventId || '',
        title: e.title || '',
        startAt: e.startAt || '',
        eventGroupType: e.eventGroupType || '',
        ownerName: e.ownerName || '',
        ownerUserId: e.ownerUserId || '',
        departmentCode: e.departmentCode || '',
        councilName: e.councilName || '',
        fairName: e.fairName || '',
        sourceWritePolicy: e.sourceWritePolicy || '',
        sourceUpdateStatus: e.sourceUpdateStatus || ''
      };
    });
    result.nextAction = 'recentManualPayload에 eventGroupType/ownerName/sourceWritePolicy가 보이면 화면 바인딩 준비 상태입니다.';
  } catch (err) {
    result.ok = false;
    result.errors.push(mcCalendarOperationHubUiBindingV02Err_(err));
    result.message = String(err && err.message ? err.message : err);
  }
  return mcCalendarOperationHubUiBindingV02Finish_(result);
}

function mcCalendarOperationHubUiBindingV02RequiredMarkers_() {
  return [
    'OPERATION_HUB_UI_BINDING_V02_MARKER',
    '박람회 운영 수동일정 등록 V02',
    '협의회 미팅',
    '프리젠테이션',
    '담당자명',
    '참여 담당자',
    '외부 참석자',
    '회의 안건',
    '결정사항',
    '후속 할일',
    '원장 반영 정책'
  ];
}

function mcCalendarOperationHubUiBindingV02BaseResult_(action) {
  return {
    ok: false,
    build: MC_CALENDAR_OPERATION_HUB_UI_BINDING_V02_BUILD,
    action: action,
    generatedAt: mcCalendarOperationHubUiBindingV02Now_(),
    realApplyExecuted: false,
    destructiveRepairExecuted: false,
    warnings: [],
    errors: []
  };
}
function mcCalendarOperationHubUiBindingV02Finish_(result) {
  result.endedAt = mcCalendarOperationHubUiBindingV02Now_();
  Logger.log('JSON_COMPACT_RESULT: ' + JSON.stringify(result));
  return result;
}
function mcCalendarOperationHubUiBindingV02Now_() {
  return Utilities.formatDate(new Date(), Session.getScriptTimeZone() || 'Asia/Seoul', 'yyyy-MM-dd HH:mm:ss');
}
function mcCalendarOperationHubUiBindingV02Err_(err) {
  return { message: err && err.message ? err.message : String(err), stack: err && err.stack ? String(err.stack) : '' };
}
