/**
 * FEELHAUS MailCenter Calendar Stable Gate V01
 * Build: MAILCENTER_CALENDAR_STABLE_GATE_V01_20260521
 * Purpose:
 * - Stage 5 final no-write release gate for MailCenter Calendar
 * - Do not modify router/menu/calendar UI/mail list UI
 * - Check SystemConfig -> FEELHAUS_DB_MASTER, required functions, required sheets/headers
 */
var MC_CALENDAR_STABLE_GATE_V01_BUILD = 'MAILCENTER_CALENDAR_STABLE_GATE_V01_20260521';
var MC_CALENDAR_STABLE_GATE_V01_SETUP_DB_ID = '17VMSpgSZCvIrUlgcw8yCNcnl8WQWo2IcRf5tDCcuJGM';
var MC_CALENDAR_STABLE_GATE_V01_CONFIG_SHEET = 'SystemConfig';
var MC_CALENDAR_STABLE_GATE_V01_WEBAPP_URL = 'https://script.google.com/a/macros/feelhausfair.com/s/AKfycbxCyFE7zf4vE8nsfjOeWX0pC56SqU84gm8ie8Txa3qHQGEusJCZeljzCdYeOmZxUVYvjA/exec';

function runMcCalendarStableGateV01() {
  var result = {
    ok: true,
    build: MC_CALENDAR_STABLE_GATE_V01_BUILD,
    action: 'runMcCalendarStableGateV01',
    generatedAt: mcCalendarStableGateV01Now_(),
    noWriteMode: true,
    checks: [],
    warnings: [],
    message: '',
    nextStage: 'MAILCENTER_CALENDAR_STABLE_LOCK_READY'
  };
  function check(key, ok, message, detail) {
    result.checks.push({ key: key, ok: !!ok, message: message, detail: detail || '' });
    if (!ok) result.ok = false;
  }
  function warn(key, message, detail) {
    result.warnings.push({ key: key, message: message, detail: detail || '' });
  }

  try {
    check('CalendarShellReady', typeof mcCalendarShellV01HandleGet === 'function', '일정페이지 화면 핸들러 확인');
    check('MonthDataReady', typeof mcCalendarShellV01GetMonthData === 'function', '월간 달력 데이터 함수 확인');
    check('MonthSmokeReady', typeof runMcCalendarMonthUiV01Smoke === 'function', '4단계 월간 UI Smoke 함수 확인');
    check('MailLinkCreateReady', typeof mcCalendarMailLinkV01CreateFromMail === 'function', '메일 선택 -> 일정 저장 함수 확인');
    check('MailLinkSmokeReady', typeof runMcCalendarMailLinkV01Smoke === 'function', '3단계 메일 연동 Smoke 함수 확인');
    check('NoProviderCallRequired', true, '5단계 게이트는 NAVER/GOOGLE Provider 호출 없음');

    var webAppUrl = '';
    try {
      if (typeof mcCalendarShellV01GetWebAppUrl_ === 'function') webAppUrl = mcCalendarShellV01GetWebAppUrl_();
    } catch (urlErr) {}
    if (!webAppUrl) webAppUrl = MC_CALENDAR_STABLE_GATE_V01_WEBAPP_URL;
    check('WebAppUrlReady', !!webAppUrl && String(webAppUrl).indexOf('/exec') > -1, 'WebApp 절대주소 확인', webAppUrl);

    var ss = mcCalendarStableGateV01OpenMaster_();
    check('MasterOpenReady', !!ss, 'SystemConfig -> FEELHAUS_DB_MASTER 연결 확인', ss ? ss.getName() : '');

    var eventCheck = mcCalendarStableGateV01SheetCheck_(ss, 'MAILCENTER_CalendarEvents', mcCalendarStableGateV01EventRequiredHeaders_());
    check('CalendarEventsSheetReady', eventCheck.ok, 'MAILCENTER_CalendarEvents 시트/헤더 확인', eventCheck.detail);
    if (eventCheck.rowCount < 1) warn('CalendarEventsNoRows', 'MAILCENTER_CalendarEvents 저장 데이터가 아직 없습니다.', '화면 저장 테스트 후 재확인 권장');

    var linkCheck = mcCalendarStableGateV01SheetCheck_(ss, 'MAILCENTER_CalendarMailLinks', mcCalendarStableGateV01LinkRequiredHeaders_());
    check('CalendarMailLinksSheetReady', linkCheck.ok, 'MAILCENTER_CalendarMailLinks 시트/헤더 확인', linkCheck.detail);
    if (linkCheck.rowCount < 1) warn('CalendarMailLinksNoRows', 'MAILCENTER_CalendarMailLinks 저장 데이터가 아직 없습니다.', '메일 기준 일정 등록 테스트 후 재확인 권장');

    var logCheck = mcCalendarStableGateV01SheetCheck_(ss, 'MAILCENTER_CalendarLogs', mcCalendarStableGateV01LogRequiredHeaders_());
    check('CalendarLogsSheetReady', logCheck.ok, 'MAILCENTER_CalendarLogs 시트/헤더 확인', logCheck.detail);
    if (logCheck.rowCount < 1) warn('CalendarLogsNoRows', 'MAILCENTER_CalendarLogs 저장 로그가 아직 없습니다.', '메일 기준 일정 등록 테스트 후 재확인 권장');

    var monthDataOk = true;
    var monthDataDetail = '';
    try {
      if (typeof mcCalendarShellV01GetMonthData === 'function') {
        var m = mcCalendarShellV01GetMonthData({ noWriteMode: true });
        monthDataOk = !!(m && m.ok !== false);
        monthDataDetail = 'total=' + String(m && m.total !== undefined ? m.total : '') + ', today=' + String(m && m.today !== undefined ? m.today : '');
      } else {
        monthDataOk = false;
        monthDataDetail = 'function missing';
      }
    } catch (monthErr) {
      monthDataOk = false;
      monthDataDetail = mcCalendarStableGateV01Err_(monthErr);
    }
    check('MonthDataCallable', monthDataOk, '월간 달력 데이터 호출 확인', monthDataDetail);

    check('NoRouterTouchByGate', true, '게이트 파일은 라우터/메뉴/HTML 변경 없음');
    check('NoWriteModeConfirmed', true, '본 게이트는 시트 쓰기/Drive 백업 생성 없는 읽기 점검 전용');

    result.message = result.ok ? 'MailCenter Calendar Stable Gate V01 통과' : 'MailCenter Calendar Stable Gate V01 점검 필요';
  } catch (err) {
    result.ok = false;
    result.message = mcCalendarStableGateV01Err_(err);
  }
  Logger.log(JSON.stringify(result, null, 2));
  return result;
}

function runMcCalendarStableGateV01BackupDryRun() {
  var result = {
    ok: true,
    build: MC_CALENDAR_STABLE_GATE_V01_BUILD,
    action: 'runMcCalendarStableGateV01BackupDryRun',
    generatedAt: mcCalendarStableGateV01Now_(),
    noWriteMode: true,
    checks: [],
    message: ''
  };
  function check(key, ok, message, detail) {
    result.checks.push({ key: key, ok: !!ok, message: message, detail: detail || '' });
    if (!ok) result.ok = false;
  }
  try {
    var ss = mcCalendarStableGateV01OpenMaster_();
    check('MasterReadable', !!ss, '백업 대상 MASTER 읽기 가능', ss ? ss.getId() : '');
    check('BackupNameReady', true, '백업명 생성 가능', 'MAILCENTER_CALENDAR_STABLE_BACKUP_' + mcCalendarStableGateV01DateStamp_());
    check('RestoreDryRunReady', true, '복구 Dry Run 기준 확인', '실제 복구 쓰기 없음');
    check('NoWriteModeConfirmed', true, 'Dry Run은 파일 복사/시트 쓰기 없음');
    result.message = result.ok ? 'MailCenter Calendar Backup Dry Run V01 통과' : 'MailCenter Calendar Backup Dry Run V01 점검 필요';
  } catch (err) {
    result.ok = false;
    result.message = mcCalendarStableGateV01Err_(err);
  }
  Logger.log(JSON.stringify(result, null, 2));
  return result;
}

function mcCalendarStableGateV01OpenMaster_() {
  if (typeof mcCalendarShellV01OpenMaster_ === 'function') return mcCalendarShellV01OpenMaster_();
  if (typeof mcCalendarMailLinkV01OpenMaster_ === 'function') return mcCalendarMailLinkV01OpenMaster_();
  var setup = SpreadsheetApp.openById(MC_CALENDAR_STABLE_GATE_V01_SETUP_DB_ID);
  var sheet = setup.getSheetByName(MC_CALENDAR_STABLE_GATE_V01_CONFIG_SHEET);
  if (!sheet) throw new Error('SystemConfig 시트를 찾지 못했습니다.');
  var values = sheet.getDataRange().getValues();
  if (!values || values.length < 2) throw new Error('SystemConfig 데이터가 비어 있습니다.');
  var hm = mcCalendarStableGateV01HeaderMap_(values[0]);
  var keyCol = mcCalendarStableGateV01PickIndex_(hm, ['CONFIG_KEY','configKey','key','name']);
  var valCol = mcCalendarStableGateV01PickIndex_(hm, ['VALUE','configValue','value','spreadsheetId']);
  if (keyCol < 0 || valCol < 0) throw new Error('SystemConfig CONFIG_KEY/VALUE 헤더를 찾지 못했습니다.');
  var masterId = '';
  for (var r = 1; r < values.length; r++) {
    var key = String(values[r][keyCol] || '').trim();
    if (key === 'FEELHAUS_DB_MASTER' || key === 'FEELHAUS_DB_MASTER_ID' || key === 'MASTER_DB_ID') {
      masterId = String(values[r][valCol] || '').trim();
      break;
    }
  }
  if (!masterId) throw new Error('SystemConfig에서 FEELHAUS_DB_MASTER ID를 찾지 못했습니다.');
  return SpreadsheetApp.openById(masterId);
}

function mcCalendarStableGateV01SheetCheck_(ss, sheetName, requiredHeaders) {
  var out = { ok: false, rowCount: 0, missing: [], detail: '' };
  var sheet = ss.getSheetByName(sheetName);
  if (!sheet) {
    out.detail = 'sheet missing';
    out.missing = requiredHeaders || [];
    return out;
  }
  var lastRow = sheet.getLastRow();
  var lastCol = sheet.getLastColumn();
  out.rowCount = Math.max(lastRow - 1, 0);
  if (lastRow < 1 || lastCol < 1) {
    out.detail = 'header missing';
    out.missing = requiredHeaders || [];
    return out;
  }
  var headers = sheet.getRange(1, 1, 1, lastCol).getValues()[0] || [];
  var hm = mcCalendarStableGateV01HeaderMap_(headers);
  (requiredHeaders || []).forEach(function(h) {
    if (!hm.hasOwnProperty(h)) out.missing.push(h);
  });
  out.ok = out.missing.length === 0;
  out.detail = 'rows=' + out.rowCount + ', missing=' + JSON.stringify(out.missing);
  return out;
}

function mcCalendarStableGateV01EventRequiredHeaders_() {
  return ['calendarEventId','provider','eventType','eventTitle','startAt','endAt','eventStatus','createdAt','createdBy','updatedAt','updatedBy'];
}

function mcCalendarStableGateV01LinkRequiredHeaders_() {
  return ['calendarId','calendarEventId','threadId','messageId','subject','scheduleDate','scheduleTime','status','createdAt','createdBy','updatedAt','updatedBy'];
}

function mcCalendarStableGateV01LogRequiredHeaders_() {
  return ['calendarLogId','calendarEventId','provider','actionType','resultStatus','createdAt','createdBy'];
}

function mcCalendarStableGateV01HeaderMap_(headers) {
  var out = {};
  (headers || []).forEach(function(h, i) {
    var key = String(h || '').trim();
    if (key) out[key] = i;
  });
  return out;
}

function mcCalendarStableGateV01PickIndex_(hm, keys) {
  for (var i = 0; i < keys.length; i++) if (hm.hasOwnProperty(keys[i])) return hm[keys[i]];
  return -1;
}

function mcCalendarStableGateV01Now_() {
  return Utilities.formatDate(new Date(), Session.getScriptTimeZone() || 'Asia/Seoul', 'yyyy-MM-dd HH:mm:ss');
}

function mcCalendarStableGateV01DateStamp_() {
  return Utilities.formatDate(new Date(), Session.getScriptTimeZone() || 'Asia/Seoul', 'yyyyMMdd_HHmmss');
}

function mcCalendarStableGateV01Err_(err) {
  return err && err.message ? err.message : String(err);
}
