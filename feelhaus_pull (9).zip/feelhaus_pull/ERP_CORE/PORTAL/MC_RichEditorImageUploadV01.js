/**
 * FEELHAUS MailCenter RichEditor Image Upload V01
 * Build: MC_RICH_EDITOR_IMAGE_UPLOAD_V02_20260527
 *
 * Purpose:
 * - Common image upload endpoint for MailCenter rich editors.
 * - Used by Compose body, Signature editor, and Template editor.
 * - Reuses MailCenter_AttachmentLibrary where available for Drive/file tracking.
 *
 * Protected:
 * - No send core, OAuth, account, PORTAL shell changes.
 */
var MC_RICH_EDITOR_IMAGE_UPLOAD_V01_BUILD = 'MC_RICH_EDITOR_IMAGE_UPLOAD_V04_LOGO_PREVIEW_SAFE_20260527';
var MC_RICH_EDITOR_IMAGE_UPLOAD_V01_FOLDER_NAME = 'FEELHAUS_MailCenter_RichEditor_Images';

function mcRichEditorImageUploadV01Upload(payload) {
  var result = {
    ok: false,
    build: MC_RICH_EDITOR_IMAGE_UPLOAD_V01_BUILD,
    action: 'mcRichEditorImageUploadV01Upload',
    message: '',
    attachmentId: '',
    fileName: '',
    mimeType: '',
    fileSize: 0,
    driveFileId: '',
    driveUrl: '',
    fileUrl: '',
    directImageUrl: '',
    usageType: '',
    sourceType: 'RICH_EDITOR_IMAGE',
    createdAt: mcRichEditorImageUploadV01Now_(),
    createdBy: mcRichEditorImageUploadV01User_()
  };
  try {
    var p = payload || {};
    var fileName = mcRichEditorImageUploadV01Require_(p.fileName || p.name, 'fileName');
    var mimeType = String(p.mimeType || p.type || 'image/png');
    var base64 = mcRichEditorImageUploadV01Require_(p.base64 || p.data, 'base64');
    var usageType = String(p.usageType || 'MAIL_BODY_IMAGE').toUpperCase();
    var mailAccountId = String(p.mailAccountId || '').trim();

    if (!/^image\/(png|jpe?g|gif|webp)$/i.test(mimeType)) throw new Error('PNG, JPG, GIF, WebP 이미지만 업로드할 수 있습니다.');
    var bytes = Utilities.base64Decode(base64);
    if (bytes.length > 3 * 1024 * 1024) throw new Error('편집기 이미지는 3MB 이하만 업로드할 수 있습니다.');

    // Prefer the existing attachment library because it already records Drive/file metadata.
    if (typeof mcAttachmentLibraryCoreV01UploadFiles === 'function') {
      var upload = mcAttachmentLibraryCoreV01UploadFiles({
        attachmentCategory: usageType,
        description: 'MailCenter rich editor image / ' + usageType + (mailAccountId ? ' / ' + mailAccountId : ''),
        shareAccess: 'ANYONE_WITH_LINK',
        files: [{ fileName: fileName, mimeType: mimeType, base64: base64, description: usageType }]
      });
      if (upload && upload.ok && upload.uploaded && upload.uploaded.length) {
        var u = upload.uploaded[0];
        result.ok = true;
        result.message = '이미지 업로드 완료';
        result.attachmentId = String(u.attachmentId || '');
        result.fileName = String(u.fileName || fileName);
        result.mimeType = String(u.mimeType || mimeType);
        result.fileSize = Number(u.fileSize || bytes.length || 0);
        result.driveFileId = String(u.driveFileId || '');
        result.driveUrl = String(u.driveUrl || u.webViewUrl || '');
        mcRichEditorImageUploadV01EnsurePublic_(result.driveFileId);
        result.fileUrl = mcRichEditorImageUploadV01DirectImageUrl_(result.driveFileId) || result.driveUrl;
        result.directImageUrl = result.fileUrl;
        result.usageType = usageType;
        return mcRichEditorImageUploadV01Safe_(result);
      }
      if (upload && upload.failed && upload.failed.length) throw new Error(upload.failed[0].message || '이미지 업로드 실패');
    }

    // Fallback. This should rarely be used, but keeps the editor functional if the library is unavailable.
    var folder = mcRichEditorImageUploadV01GetOrCreateFolder_();
    var blob = Utilities.newBlob(bytes, mimeType, fileName);
    var driveFile = folder.createFile(blob);
    try { driveFile.setSharing(DriveApp.Access.ANYONE_WITH_LINK, DriveApp.Permission.VIEW); } catch (shareErr) {}
    result.ok = true;
    result.message = '이미지 업로드 완료';
    result.attachmentId = mcRichEditorImageUploadV01NewId_('MCREIMG');
    result.fileName = fileName;
    result.mimeType = mimeType;
    result.fileSize = bytes.length;
    result.driveFileId = driveFile.getId();
    result.driveUrl = driveFile.getUrl();
    result.fileUrl = mcRichEditorImageUploadV01DirectImageUrl_(result.driveFileId) || result.driveUrl;
    result.directImageUrl = result.fileUrl;
    result.usageType = usageType;
  } catch (err) {
    result.ok = false;
    result.message = String(err && err.message ? err.message : err);
  }
  return mcRichEditorImageUploadV01Safe_(result);
}

function runMcRichEditorImageUploadV01Smoke() {
  return { ok: true, build: MC_RICH_EDITOR_IMAGE_UPLOAD_V01_BUILD, message: 'RichEditor image upload endpoint ready', uploadFunction: typeof mcRichEditorImageUploadV01Upload === 'function' };
}

function mcRichEditorImageUploadV01GetOrCreateFolder_() {
  var name = MC_RICH_EDITOR_IMAGE_UPLOAD_V01_FOLDER_NAME;
  var it = DriveApp.getFoldersByName(name);
  if (it.hasNext()) return it.next();
  return DriveApp.createFolder(name);
}
function mcRichEditorImageUploadV01Require_(v, label) { var s = String(v == null ? '' : v).trim(); if (!s) throw new Error(label + ' 값이 필요합니다.'); return s; }
function mcRichEditorImageUploadV01Now_() { return Utilities.formatDate(new Date(), Session.getScriptTimeZone() || 'Asia/Seoul', "yyyy-MM-dd'T'HH:mm:ssXXX"); }
function mcRichEditorImageUploadV01User_() { try { return Session.getActiveUser().getEmail() || 'SYSTEM'; } catch (e) { return 'SYSTEM'; } }
function mcRichEditorImageUploadV01NewId_(prefix) { return prefix + '-' + Utilities.formatDate(new Date(), Session.getScriptTimeZone() || 'Asia/Seoul', 'yyyyMMddHHmmss') + '-' + Math.floor(Math.random() * 9000 + 1000); }
function mcRichEditorImageUploadV01Safe_(obj) { return JSON.parse(JSON.stringify(obj || {})); }


function mcRichEditorImageUploadV01EnsurePublic_(fileId) {
  var id = String(fileId || '').trim();
  if (!id) return false;
  try {
    DriveApp.getFileById(id).setSharing(DriveApp.Access.ANYONE_WITH_LINK, DriveApp.Permission.VIEW);
    return true;
  } catch (e) {
    return false;
  }
}

/**
 * Returns a Gmail/HTML-friendly direct image URL for a Drive file id.
 * Required by mcRichEditorImageUploadV01Upload().
 * Kept server-side because upload fallback and attachment-library paths both use it.
 */
function mcRichEditorImageUploadV01DirectImageUrl_(fileId) {
  var id = String(fileId || '').trim();
  if (!id) return '';
  return 'https://lh3.googleusercontent.com/d/' + encodeURIComponent(id) + '=s600';
}

/**
 * Public diagnostic alias. Not required for normal use, but useful for Apps Script checks.
 */
function mcRichEditorImageUploadV01DirectImageUrl(fileId) {
  return mcRichEditorImageUploadV01DirectImageUrl_(fileId);
}
