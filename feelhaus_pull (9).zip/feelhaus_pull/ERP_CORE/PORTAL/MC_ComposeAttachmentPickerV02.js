/**
 * FEELHAUS MailCenter Compose Attachment Picker V02 REAPPLY
 * Build: MC_COMPOSE_ATTACHMENT_PICKER_V02_REAPPLY_20260519
 */
var MC_COMPOSE_ATTACHMENT_PICKER_V02_BUILD = 'MC_COMPOSE_ATTACHMENT_PICKER_V02_REAPPLY_20260519';

function runMcComposeAttachmentPickerV02Smoke() {
  var result = {ok:false, build:MC_COMPOSE_ATTACHMENT_PICKER_V02_BUILD, action:'runMcComposeAttachmentPickerV02Smoke', generatedAt:mcComposeAttachmentPickerV02Now_(), message:'', checks:[]};
  try {
    result.checks.push({key:'AttachmentLibraryReady', ok:typeof mcAttachmentLibraryCoreV01GetData === 'function', message:'자료함 데이터 함수 확인'});
    result.checks.push({key:'DriveLinkSendReady', ok:typeof mcDriveLinkAttachmentV01SendWithLinks === 'function', message:'Drive 링크 포함 발송 함수 확인'});
    result.checks.push({key:'ComposeCoreReady', ok:typeof mcComposeCoreV01GetData === 'function', message:'Compose 데이터 함수 확인'});
    result.checks.push({key:'PickerListReady', ok:typeof mcComposeAttachmentPickerV02GetActiveLibrary === 'function', message:'Compose 자료함 선택 목록 함수 확인'});
    result.checks.push({key:'PickerSendReady', ok:typeof mcComposeAttachmentPickerV02SendWithLibrary === 'function', message:'자료함 선택 발송 함수 확인'});
    result.ok = result.checks.every(function(c){return !!c.ok;});
    result.message = result.ok ? 'Compose Attachment Picker V02 REAPPLY 준비 완료' : 'Compose Attachment Picker V02 REAPPLY 점검 필요';
  } catch(e) { result.ok=false; result.message=String(e && e.message ? e.message : e); }
  mcComposeAttachmentPickerV02Log_(result); return result;
}

function mcComposeAttachmentPickerV02GetActiveLibrary(payload) {
  var result = {ok:false, build:MC_COMPOSE_ATTACHMENT_PICKER_V02_BUILD, action:'mcComposeAttachmentPickerV02GetActiveLibrary', generatedAt:mcComposeAttachmentPickerV02Now_(), message:'', summary:{total:0, active:0}, attachments:[]};
  try {
    if (typeof mcAttachmentLibraryCoreV01GetData !== 'function') throw new Error('mcAttachmentLibraryCoreV01GetData 함수가 없습니다.');
    var data = mcAttachmentLibraryCoreV01GetData({});
    if (!data || !data.ok) throw new Error((data && data.message) ? data.message : '자료함 데이터 조회 실패');
    var q = String((payload && payload.q) || '').toLowerCase().trim();
    var rows = (data.attachments || []).filter(function(a){
      if (String(a.attachmentStatus || '').toUpperCase() !== 'ACTIVE') return false;
      if (!a.driveUrl && !a.webViewUrl) return false;
      if (!q) return true;
      return [a.attachmentCategory,a.fileName,a.description,a.attachmentSource,a.mimeType,a.driveUrl].join(' ').toLowerCase().indexOf(q) >= 0;
    }).map(function(a){
      return {attachmentId:String(a.attachmentId||''), fileName:String(a.fileName||''), driveUrl:String(a.driveUrl||a.webViewUrl||''), webViewUrl:String(a.webViewUrl||a.driveUrl||''), description:String(a.description||''), attachmentCategory:String(a.attachmentCategory||''), attachmentSource:String(a.attachmentSource||''), fileSize:String(a.fileSize||''), mimeType:String(a.mimeType||''), createdAt:String(a.createdAt||'')};
    });
    result.attachments = rows; result.summary.total=(data.attachments||[]).length; result.summary.active=rows.length; result.ok=true; result.message='Compose 자료함 ACTIVE 목록 조회 완료';
  } catch(e) { result.ok=false; result.message=String(e && e.message ? e.message : e); }
  return mcComposeAttachmentPickerV02Safe_(result);
}

function runMcComposeAttachmentPickerV02List() {
  var result = mcComposeAttachmentPickerV02GetActiveLibrary({});
  mcComposeAttachmentPickerV02Log_(result); return result;
}

function mcComposeAttachmentPickerV02SendWithLibrary(payload) {
  var result = {ok:false, build:MC_COMPOSE_ATTACHMENT_PICKER_V02_BUILD, action:'mcComposeAttachmentPickerV02SendWithLibrary', generatedAt:mcComposeAttachmentPickerV02Now_(), message:'', selectedAttachmentIds:[], sendResult:null};
  try {
    if (typeof mcDriveLinkAttachmentV01SendWithLinks !== 'function') throw new Error('mcDriveLinkAttachmentV01SendWithLinks 함수가 없습니다.');
    var p = payload || {};
    var ids = p.selectedAttachmentIds || p.attachmentIds || [];
    if (!Array.isArray(ids)) ids = [];
    var library = mcComposeAttachmentPickerV02GetActiveLibrary({});
    if (!library.ok) throw new Error(library.message || '자료함 목록 조회 실패');
    var attachments = [];
    ids.forEach(function(id){
      var found = (library.attachments || []).find(function(a){return String(a.attachmentId) === String(id);});
      if (found) {
        attachments.push({attachmentId:found.attachmentId, fileName:found.fileName, driveUrl:found.driveUrl || found.webViewUrl, description:found.description, attachmentType:'LIBRARY_DRIVE_LINK'});
        result.selectedAttachmentIds.push(found.attachmentId);
      }
    });
    var manual = p.attachments || [];
    if (Array.isArray(manual)) manual.forEach(function(a){ if (a && (a.driveUrl || a.url)) attachments.push(a); });
    var sent = mcDriveLinkAttachmentV01SendWithLinks({mailAccountId:p.mailAccountId||'', folderId:p.folderId||'', signatureId:p.signatureId||'', toEmail:p.toEmail||'', ccEmail:p.ccEmail||'', bccEmail:p.bccEmail||'', subject:p.subject||'', body:p.body||'', attachments:attachments});
    result.sendResult = mcComposeAttachmentPickerV02Safe_(sent);
    if (!sent || !sent.ok) throw new Error((sent && sent.message) ? sent.message : '자료함 링크 포함 발송 실패');
    result.ok=true; result.message='자료함 링크 포함 메일 발송 완료';
  } catch(e) { result.ok=false; result.message=String(e && e.message ? e.message : e); }
  mcComposeAttachmentPickerV02Log_(result); return mcComposeAttachmentPickerV02Safe_(result);
}

function mcComposeAttachmentPickerV02Now_(){return Utilities.formatDate(new Date(), Session.getScriptTimeZone() || 'Asia/Seoul', 'yyyy-MM-dd HH:mm:ss');}
function mcComposeAttachmentPickerV02Safe_(obj){try{return JSON.parse(JSON.stringify(obj));}catch(e){return {ok:false, build:MC_COMPOSE_ATTACHMENT_PICKER_V02_BUILD, message:String(e && e.message ? e.message : e)};}}
function mcComposeAttachmentPickerV02Log_(obj){try{Logger.log('JSON_COMPACT_RESULT: '+JSON.stringify(obj));}catch(e){Logger.log(obj);}}
