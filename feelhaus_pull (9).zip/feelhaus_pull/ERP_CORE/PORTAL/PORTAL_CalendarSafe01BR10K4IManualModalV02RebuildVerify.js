function portalCalendarSafe01BR10K4IManualModalV02RebuildVerify() {
  var build='PORTAL_CALENDAR_SAFE01B_R10K4I_MANUAL_MODAL_V02_REBUILD_20260604';
  var baseBuild='PORTAL_CALENDAR_SAFE01B_R10K4H2G_SCROLL_STRUCTURE_NORMALIZE_20260604';
  var html=''; var err='';
  try{html=HtmlService.createHtmlOutputFromFile('MC_CalendarViewV01').getContent();}catch(e){err=String(e&&e.message?e.message:e);}
  var htmlClose=html.lastIndexOf('</html>');
  var afterHtml=htmlClose>=0?html.slice(htmlClose+7).trim():'';
  var checks={
    viewReadable: !!html,
    buildMarkerPresent: html.indexOf(build)>=0,
    postBodyPatchAbsent: afterHtml==='',
    h2gFocusGuardRemoved: html.indexOf('r10k4h2gScrollStructureNormalizeScript')<0 && html.indexOf('restoreScroll(window.__r10k4h2gScrollKeep')<0,
    manualModalV02StyleReady: html.indexOf('r10k4iManualModalV02RebuildStyle')>=0 && html.indexOf('align-items:center!important')>=0 && html.indexOf('height:min(840px,calc(100vh - 72px))')>=0,
    manualModalV02RuntimeReady: html.indexOf('fhCalendarR10K4IApplyManualModalV02')>=0 && html.indexOf('fhCalendarR10K4IResetCreateForm')>=0,
    noFieldScrollRestoreLoop: html.indexOf("document.addEventListener('focusin',keepAfter,true)")<0 && html.indexOf("'pointerdown',keepBefore")<0,
    g6ManualFlexStartDisabled: html.indexOf("if(modalId!=='manualEventModal')")>=0,
    devVisibleHeaderRemoved: html.indexOf('<b>R10K4H2_FULL_INPUT_FIELD_MAP</b>')<0 && html.indexOf('업무 타입별 전체 입력필드를 간소화 없이 표시하고')<0,
    compactStatusTextReady: html.indexOf('입력 화면이 열렸습니다')<0 && html.indexOf('입력 가능 · 자동 새로고침 일시중지')>=0,
    malformedNestedStyleFixed: html.indexOf('<style>\n\n<style>')<0 && html.indexOf('</style>\n\n/* PORTAL_CALENDAR_SAFE01B_R10K4H2C_SAVE_UX_AUTORF_PAUSE_20260604 */')<0,
    statusFooterOverrideReady: html.indexOf('#manualEventModal .manual-actions #manualSaveStatusH2C')>=0 && html.indexOf('r10k4i-footer-status')>=0,
    createResetPreserved: html.indexOf("setVal('me_meetingAddYn','N')")>=0 && html.indexOf("setVal('me_meetingRecorderName',actorName())")>=0,
    editModePreserved: html.indexOf('openOperationEditModal=wrapped')>=0 && html.indexOf("window.__r10k4iManualMode='edit'")>=0,
    h2cSaveUxKept: html.indexOf('PORTAL_CALENDAR_SAFE01B_R10K4H2C_SAVE_UX_AUTORF_PAUSE_20260604')>=0,
    h2eMeetingDisplayKept: html.indexOf('PORTAL_CALENDAR_SAFE01B_R10K4H2E_MEETING_LEDGER_TARGET_DISPLAY_20260604')>=0,
    h2bBindingKept: html.indexOf('PORTAL_CALENDAR_SAFE01B_R10K4H2B_INPUT_BINDING_SAVE_LINK_REPAIR_20260604')>=0,
    g4DataLoadingKept: html.indexOf('PORTAL_CALENDAR_SAFE01B_R10K4G4_DATA_LOAD_SPEED_REPAIR_20260604')>=0,
    g5RecordInitialStateKept: html.indexOf('recordInitialState')>=0,
    g6BaseScrollMarkerKept: html.indexOf('PORTAL_CALENDAR_SAFE01B_R10K4G6_MODAL_SCROLL_REPAIR_20260604')>=0,
    providerWriteNotAdded: html.indexOf('Calendar.Events.insert')<0 && html.indexOf('Calendar.Events.update')<0 && html.indexOf('UrlFetchApp.fetch')<0
  };
  var fatal=[];
  Object.keys(checks).forEach(function(k){ if(checks[k]!==true) fatal.push(k); });
  var result={ok:fatal.length===0, build:build, baseBuild:baseBuild, action:'portalCalendarSafe01BR10K4IManualModalV02RebuildVerify', safety:'READ_ONLY_RUNTIME_VERIFY_NO_SHEET_PROVIDER_WRITE', checks:checks, diagnostics:{htmlLength:html.length, readError:err, afterHtmlLength:afterHtml.length}, fatal:fatal, message:fatal.length?'R10K4I manual modal V02 rebuild verification failed.':'R10K4I manual modal V02 rebuild verification passed.'};
  Logger.log('JSON_COMPACT_RESULT: '+JSON.stringify(result));
  return result;
}
function portalCalendarSafe01BR10K4IVerify(){return portalCalendarSafe01BR10K4IManualModalV02RebuildVerify();}
