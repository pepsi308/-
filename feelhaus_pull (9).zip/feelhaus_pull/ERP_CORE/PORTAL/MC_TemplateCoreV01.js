/**
 * FEELHAUS MailCenter Template Manager Core V01
 * Build: MC_TEMPLATE_MANAGER_V01_20260519
 *
 * Purpose:
 * - MailCenter 메일 템플릿 등록/조회/상태관리
 * - 작성 화면 연동 전 단계
 * - 기존 발송/작성/로그/설정/계정/OAuth 성공 파일 수정 없음
 */

var MC_TEMPLATE_CORE_V01_BUILD = 'MC_TEMPLATE_MANAGER_V01_20260519';
var MC_TEMPLATE_CORE_V01_SETUP_DB_ID = '17VMSpgSZCvIrUlgcw8yCNcnl8WQWo2IcRf5tDCcuJGM';
var MC_TEMPLATE_CORE_V01_CONFIG_SHEET = 'SystemConfig';

function runMcTemplateCoreV01Smoke() {
  var result = {
    ok: false,
    build: MC_TEMPLATE_CORE_V01_BUILD,
    action: 'runMcTemplateCoreV01Smoke',
    generatedAt: mcTemplateCoreV01Now_(),
    message: '',
    checks: []
  };

  try {
    var ss = mcTemplateCoreV01OpenMaster_().ss;
    mcTemplateCoreV01EnsureSheets_(ss);

    result.checks.push({ key: 'MasterConnected', ok: !!ss, message: 'FEELHAUS_DB_MASTER 연결 확인' });
    result.checks.push({ key: 'TemplatesSheetReady', ok: !!ss.getSheetByName('MailCenter_Templates'), message: 'MailCenter_Templates 시트 확인' });
    result.checks.push({ key: 'AuditLogsReady', ok: !!ss.getSheetByName('MailCenter_AuditLogs'), message: 'MailCenter_AuditLogs 확인' });
    result.checks.push({ key: 'DataFunctionReady', ok: typeof mcTemplateCoreV01GetData === 'function', message: '템플릿 데이터 함수 확인' });
    result.checks.push({ key: 'SaveFunctionReady', ok: typeof mcTemplateCoreV01SaveTemplate === 'function', message: '템플릿 저장 함수 확인' });

    result.ok = result.checks.every(function(c) { return !!c.ok; });
    result.message = result.ok ? 'MailCenter Template Core V01 준비 완료' : 'MailCenter Template Core V01 점검 실패';
  } catch (err) {
    result.ok = false;
    result.message = String(err && err.message ? err.message : err);
  }

  mcTemplateCoreV01Log_(result);
  return mcTemplateCoreV01Safe_(result);
}

function mcTemplateCoreV01GetData(payload) {
  var result = {
    ok: false,
    build: MC_TEMPLATE_CORE_V01_BUILD,
    action: 'mcTemplateCoreV01GetData',
    generatedAt: mcTemplateCoreV01Now_(),
    message: '',
    summary: {
      total: 0,
      active: 0,
      inactive: 0,
      shared: 0
    },
    templates: []
  };

  try {
    var ss = mcTemplateCoreV01OpenMaster_().ss;
    mcTemplateCoreV01EnsureSheets_(ss);

    var rows = mcTemplateCoreV01ReadSheet_(ss, 'MailCenter_Templates');
    var templates = rows.map(mcTemplateCoreV01NormalizeTemplate_);

    result.templates = templates;
    result.summary.total = templates.length;
    result.summary.active = templates.filter(function(t) { return String(t.templateStatus || '').toUpperCase() === 'ACTIVE'; }).length;
    result.summary.inactive = templates.filter(function(t) { return String(t.templateStatus || '').toUpperCase() === 'INACTIVE'; }).length;
    result.summary.shared = templates.filter(function(t) { return String(t.templateScope || '').toUpperCase() === 'GLOBAL'; }).length;
    result.ok = true;
    result.message = 'MailCenter 템플릿 데이터 조회 완료';
  } catch (err) {
    result.ok = false;
    result.message = String(err && err.message ? err.message : err);
  }

  return mcTemplateCoreV01Safe_(result);
}

function runMcTemplateCoreV01ListRecent() {
  var result = mcTemplateCoreV01GetData({});
  mcTemplateCoreV01Log_(result);
  return result;
}

function mcTemplateCoreV01SeedDefaultTemplates() {
  var result = {
    ok: false,
    build: MC_TEMPLATE_CORE_V01_BUILD,
    action: 'mcTemplateCoreV01SeedDefaultTemplates',
    generatedAt: mcTemplateCoreV01Now_(),
    message: '',
    inserted: 0,
    skipped: 0
  };

  try {
    var defaults = [
      {
        templateCategory: '입주박람회',
        templateName: '입주박람회 안내',
        subject: '[FEELHAUS] 입주박람회 안내드립니다.',
        bodyHtml: '안녕하세요.<br>FEELHAUS 입주박람회 안내드립니다.<br>자세한 일정과 혜택은 아래 내용을 확인 부탁드립니다.<br>감사합니다.'
      },
      {
        templateCategory: '계약',
        templateName: '계약 안내',
        subject: '[FEELHAUS] 계약 진행 안내드립니다.',
        bodyHtml: '안녕하세요.<br>계약 진행 관련 안내드립니다.<br>계약 내용 확인 후 문의사항이 있으시면 회신 부탁드립니다.<br>감사합니다.'
      },
      {
        templateCategory: '설치',
        templateName: '설치 일정 안내',
        subject: '[FEELHAUS] 설치 일정 안내드립니다.',
        bodyHtml: '안녕하세요.<br>설치 일정 안내드립니다.<br>방문 가능 일정 확인 후 회신 부탁드립니다.<br>감사합니다.'
      },
      {
        templateCategory: 'A/S',
        templateName: 'A/S 접수 안내',
        subject: '[FEELHAUS] A/S 접수 안내드립니다.',
        bodyHtml: '안녕하세요.<br>A/S 접수 관련 안내드립니다.<br>증상과 사진을 함께 보내주시면 빠르게 확인하겠습니다.<br>감사합니다.'
      },
      {
        templateCategory: '업체공지',
        templateName: '업체 공지',
        subject: '[FEELHAUS] 업체 공지사항 안내드립니다.',
        bodyHtml: '안녕하세요.<br>FEELHAUS 업체 공지사항 안내드립니다.<br>내용 확인 후 필요한 사항은 회신 부탁드립니다.<br>감사합니다.'
      }
    ];

    for (var i = 0; i < defaults.length; i++) {
      var saved = mcTemplateCoreV01SaveTemplate({
        templateScope: 'GLOBAL',
        templateCategory: defaults[i].templateCategory,
        templateName: defaults[i].templateName,
        subject: defaults[i].subject,
        bodyHtml: defaults[i].bodyHtml,
        useSignature: 'TRUE',
        templateStatus: 'ACTIVE',
        memo: '기본 템플릿 자동 생성'
      });
      if (saved && saved.ok) result.inserted++;
      else result.skipped++;
    }

    result.ok = true;
    result.message = '기본 템플릿 생성 완료';
  } catch (err) {
    result.ok = false;
    result.message = String(err && err.message ? err.message : err);
  }

  mcTemplateCoreV01Log_(result);
  return mcTemplateCoreV01Safe_(result);
}

function mcTemplateCoreV01SaveTemplate(payload) {
  var result = {
    ok: false,
    build: MC_TEMPLATE_CORE_V01_BUILD,
    action: 'mcTemplateCoreV01SaveTemplate',
    generatedAt: mcTemplateCoreV01Now_(),
    message: '',
    templateId: ''
  };

  try {
    var p = payload || {};
    var templateName = mcTemplateCoreV01Require_(p.templateName, 'templateName');
    var subject = mcTemplateCoreV01Require_(p.subject, 'subject');
    var bodyHtml = mcTemplateCoreV01Require_(p.bodyHtml || p.body || p.templateBody, 'bodyHtml');

    var ss = mcTemplateCoreV01OpenMaster_().ss;
    mcTemplateCoreV01EnsureSheets_(ss);

    var sh = ss.getSheetByName('MailCenter_Templates');
    var headers = mcTemplateCoreV01Headers_(sh);
    var hm = mcTemplateCoreV01HeaderMap_(headers);

    var templateId = String(p.templateId || '').trim();
    var foundRow = templateId ? mcTemplateCoreV01FindRow_(sh, hm, 'templateId', templateId) : -1;
    if (!templateId) templateId = mcTemplateCoreV01NewId_('MCTPL');

    var now = mcTemplateCoreV01Now_();
    var actor = mcTemplateCoreV01User_();

    var obj = {
      templateId: templateId,
      templateScope: String(p.templateScope || 'GLOBAL').trim(),
      ownerType: String(p.ownerType || '').trim(),
      ownerId: String(p.ownerId || '').trim(),
      vendorId: String(p.vendorId || '').trim(),
      templateCategory: String(p.templateCategory || '공통').trim(),
      templateName: templateName,
      subject: subject,
      bodyHtml: bodyHtml,
      bodyText: String(p.bodyText || mcTemplateCoreV01StripHtml_(bodyHtml)).substring(0, 1000),
      useSignature: String(p.useSignature || 'TRUE').toUpperCase(),
      templateStatus: String(p.templateStatus || 'ACTIVE').toUpperCase(),
      statusReason: String(p.statusReason || '저장 완료'),
      memo: String(p.memo || ''),
      createdAt: now,
      createdBy: actor,
      updatedAt: now,
      updatedBy: actor
    };

    if (foundRow > 0) {
      Object.keys(obj).forEach(function(k) { mcTemplateCoreV01SetCell_(sh, hm, foundRow, k, obj[k]); });
    } else {
      sh.appendRow(headers.map(function(h) { return obj[h] !== undefined ? obj[h] : ''; }));
    }

    mcTemplateCoreV01AppendAudit_(ss, 'MailCenter_Templates', templateId, 'SAVE_TEMPLATE', JSON.stringify(obj), '메일 템플릿 저장');
    mcTemplateCoreV01ClearComposeTemplateCache_();

    result.ok = true;
    result.templateId = templateId;
    result.message = '템플릿 저장 완료';
  } catch (err) {
    result.ok = false;
    result.message = String(err && err.message ? err.message : err);
  }

  mcTemplateCoreV01Log_(result);
  return mcTemplateCoreV01Safe_(result);
}

function mcTemplateCoreV01SetTemplateStatus(payload) {
  var result = {
    ok: false,
    build: MC_TEMPLATE_CORE_V01_BUILD,
    action: 'mcTemplateCoreV01SetTemplateStatus',
    generatedAt: mcTemplateCoreV01Now_(),
    message: '',
    templateId: ''
  };

  try {
    var p = payload || {};
    var templateId = mcTemplateCoreV01Require_(p.templateId, 'templateId');
    var status = mcTemplateCoreV01Require_(p.templateStatus || p.status, 'templateStatus').toUpperCase();
    if (['ACTIVE','INACTIVE'].indexOf(status) < 0) throw new Error('허용되지 않는 상태입니다: ' + status);

    var ss = mcTemplateCoreV01OpenMaster_().ss;
    mcTemplateCoreV01EnsureSheets_(ss);

    var sh = ss.getSheetByName('MailCenter_Templates');
    var headers = mcTemplateCoreV01Headers_(sh);
    var hm = mcTemplateCoreV01HeaderMap_(headers);
    var row = mcTemplateCoreV01FindRow_(sh, hm, 'templateId', templateId);
    if (row < 1) throw new Error('템플릿을 찾지 못했습니다: ' + templateId);

    mcTemplateCoreV01SetCell_(sh, hm, row, 'templateStatus', status);
    mcTemplateCoreV01SetCell_(sh, hm, row, 'statusReason', String(p.reason || '상태 변경'));
    mcTemplateCoreV01SetCell_(sh, hm, row, 'updatedAt', mcTemplateCoreV01Now_());
    mcTemplateCoreV01SetCell_(sh, hm, row, 'updatedBy', mcTemplateCoreV01User_());

    mcTemplateCoreV01AppendAudit_(ss, 'MailCenter_Templates', templateId, 'SET_TEMPLATE_STATUS', status, String(p.reason || '상태 변경'));
    mcTemplateCoreV01ClearComposeTemplateCache_();

    result.ok = true;
    result.templateId = templateId;
    result.message = '템플릿 상태 변경 완료';
  } catch (err) {
    result.ok = false;
    result.message = String(err && err.message ? err.message : err);
  }

  mcTemplateCoreV01Log_(result);
  return mcTemplateCoreV01Safe_(result);
}


function mcTemplateCoreV01ClearComposeTemplateCache_() {
  try {
    if (typeof mcComposeTemplateApplyV01ClearCache_ === 'function') {
      mcComposeTemplateApplyV01ClearCache_();
    }
  } catch (e) {}
}

function mcTemplateCoreV01EnsureSheets_(ss) {
  mcTemplateCoreV01GetSheetOrCreate_(ss, 'MailCenter_Templates', [
    'templateId','templateScope','ownerType','ownerId','vendorId','templateCategory','templateName',
    'subject','bodyHtml','bodyText','useSignature','templateStatus','statusReason','memo',
    'createdAt','createdBy','updatedAt','updatedBy'
  ]);

  mcTemplateCoreV01GetSheetOrCreate_(ss, 'MailCenter_AuditLogs', [
    'mailAuditLogId','targetType','targetId','vendorId','eventId','actionType',
    'beforeValue','afterValue','reason','createdAt','createdBy'
  ]);
}

function mcTemplateCoreV01ReadSheet_(ss, sheetName) {
  var sh = ss.getSheetByName(sheetName);
  if (!sh) return [];
  var values = sh.getDataRange().getValues();
  if (!values || values.length < 2) return [];
  var hm = mcTemplateCoreV01HeaderMap_(values[0]);
  var rows = [];
  for (var r = 1; r < values.length; r++) {
    var obj = mcTemplateCoreV01RowObject_(values[r], hm);
    if (Object.keys(obj).some(function(k) { return obj[k] !== '' && obj[k] != null; })) rows.push(obj);
  }
  return rows;
}

function mcTemplateCoreV01NormalizeTemplate_(x) {
  return {
    templateId: String(x.templateId || ''),
    templateScope: String(x.templateScope || ''),
    ownerType: String(x.ownerType || ''),
    ownerId: String(x.ownerId || ''),
    vendorId: String(x.vendorId || ''),
    templateCategory: String(x.templateCategory || ''),
    templateName: String(x.templateName || ''),
    subject: String(x.subject || ''),
    bodyHtml: String(x.bodyHtml || ''),
    bodyText: String(x.bodyText || ''),
    useSignature: String(x.useSignature || ''),
    templateStatus: String(x.templateStatus || ''),
    statusReason: String(x.statusReason || ''),
    memo: String(x.memo || ''),
    createdAt: String(x.createdAt || ''),
    createdBy: String(x.createdBy || ''),
    updatedAt: String(x.updatedAt || ''),
    updatedBy: String(x.updatedBy || '')
  };
}

function mcTemplateCoreV01GetSheetOrCreate_(ss, sheetName, headers) {
  var sh = ss.getSheetByName(sheetName);
  if (!sh) sh = ss.insertSheet(sheetName);
  var lastCol = sh.getLastColumn();
  if (lastCol < 1) {
    sh.getRange(1, 1, 1, headers.length).setValues([headers]);
    return sh;
  }
  var existing = sh.getRange(1, 1, 1, lastCol).getValues()[0].map(function(v) { return String(v || '').trim(); });
  var append = [];
  headers.forEach(function(h) { if (existing.indexOf(h) < 0) append.push(h); });
  if (append.length) sh.getRange(1, existing.length + 1, 1, append.length).setValues([append]);
  return sh;
}

function mcTemplateCoreV01AppendAudit_(ss, targetType, targetId, actionType, afterValue, reason) {
  var sh = ss.getSheetByName('MailCenter_AuditLogs');
  if (!sh) return;
  var headers = mcTemplateCoreV01Headers_(sh);
  var rowObj = {
    mailAuditLogId: mcTemplateCoreV01NewId_('MCAUD'),
    targetType: targetType || '',
    targetId: targetId || '',
    vendorId: '',
    eventId: '',
    actionType: actionType || '',
    beforeValue: '',
    afterValue: afterValue || '',
    reason: reason || '',
    createdAt: mcTemplateCoreV01Now_(),
    createdBy: mcTemplateCoreV01User_()
  };
  sh.appendRow(headers.map(function(h) { return rowObj[h] !== undefined ? rowObj[h] : ''; }));
}

function mcTemplateCoreV01OpenMaster_() {
  if (typeof portal19GetConfigBundle_ === 'function' && typeof portal19OpenMaster_ === 'function') {
    var bundle = portal19GetConfigBundle_();
    var ssByPortal = portal19OpenMaster_(bundle);
    if (ssByPortal) return { ss: ssByPortal, masterDbId: bundle.masterDbId || '' };
  }

  var setup = SpreadsheetApp.openById(MC_TEMPLATE_CORE_V01_SETUP_DB_ID);
  var configSheet = setup.getSheetByName(MC_TEMPLATE_CORE_V01_CONFIG_SHEET);
  if (!configSheet) throw new Error('SystemConfig 시트를 찾지 못했습니다.');

  var values = configSheet.getDataRange().getValues();
  if (!values || values.length < 2) throw new Error('SystemConfig 데이터가 비어 있습니다.');

  var hm = mcTemplateCoreV01HeaderMap_(values[0]);
  var keyCol = mcTemplateCoreV01FindHeader_(hm, ['CONFIG_KEY','configKey','KEY','key']);
  var valCol = mcTemplateCoreV01FindHeader_(hm, ['VALUE','CONFIG_VALUE','configValue','value']);
  if (keyCol < 0 || valCol < 0) throw new Error('SystemConfig CONFIG_KEY/VALUE 헤더를 찾지 못했습니다.');

  var masterId = '';
  for (var r = 1; r < values.length; r++) {
    var key = String(values[r][keyCol] || '').trim();
    if (key === 'FEELHAUS_DB_MASTER' || key === 'FEELHAUS_DB_MASTER_ID' || key === 'MASTER_DB_ID') {
      masterId = String(values[r][valCol] || '').trim();
      break;
    }
  }
  if (!masterId) throw new Error('SystemConfig에서 FEELHAUS_DB_MASTER ID를 찾지 못했습니다.');

  return { ss: SpreadsheetApp.openById(masterId), masterDbId: masterId };
}

function mcTemplateCoreV01Headers_(sh) {
  return sh.getRange(1, 1, 1, sh.getLastColumn()).getValues()[0].map(function(h) { return String(h || '').trim(); });
}
function mcTemplateCoreV01HeaderMap_(header) {
  var hm = {};
  for (var i = 0; i < header.length; i++) {
    var raw = String(header[i] || '').trim();
    if (!raw) continue;
    hm[raw] = i;
    var norm = mcTemplateCoreV01Normalize_(raw);
    if (hm[norm] == null) hm[norm] = i;
  }
  return hm;
}
function mcTemplateCoreV01FindHeader_(hm, names) {
  for (var i = 0; i < names.length; i++) {
    if (hm[names[i]] != null) return hm[names[i]];
    var norm = mcTemplateCoreV01Normalize_(names[i]);
    if (hm[norm] != null) return hm[norm];
  }
  return -1;
}
function mcTemplateCoreV01RowObject_(row, hm) {
  var obj = {};
  Object.keys(hm).forEach(function(k) {
    if (k === mcTemplateCoreV01Normalize_(k)) return;
    var val = row[hm[k]];
    obj[k] = val instanceof Date
      ? Utilities.formatDate(val, Session.getScriptTimeZone() || 'Asia/Seoul', 'yyyy-MM-dd HH:mm:ss')
      : val;
  });
  return obj;
}
function mcTemplateCoreV01FindRow_(sh, hm, key, value) {
  var values = sh.getDataRange().getValues();
  for (var r = 1; r < values.length; r++) {
    var idx = hm[key] != null ? hm[key] : hm[mcTemplateCoreV01Normalize_(key)];
    if (idx != null && String(values[r][idx]) === String(value)) return r + 1;
  }
  return -1;
}
function mcTemplateCoreV01SetCell_(sh, hm, row, key, value) {
  var idx = hm[key];
  if (idx == null) idx = hm[mcTemplateCoreV01Normalize_(key)];
  if (idx == null) return;
  sh.getRange(row, idx + 1).setValue(value);
}
function mcTemplateCoreV01StripHtml_(html) {
  return String(html || '').replace(/<br\s*\/?>/gi, '\n').replace(/<[^>]*>/g, ' ').replace(/\s+/g, ' ').trim();
}
function mcTemplateCoreV01Normalize_(v) { return String(v || '').trim().toUpperCase().replace(/[^A-Z0-9]/g, ''); }
function mcTemplateCoreV01Require_(v, name) { var s = String(v || '').trim(); if (!s) throw new Error(name + ' 값이 필요합니다.'); return s; }
function mcTemplateCoreV01NewId_(prefix) { return prefix + '-' + Utilities.formatDate(new Date(), Session.getScriptTimeZone() || 'Asia/Seoul', 'yyyyMMddHHmmss') + '-' + Math.floor(Math.random() * 9000 + 1000); }
function mcTemplateCoreV01User_() { try { return Session.getActiveUser().getEmail() || ''; } catch(e) { return ''; } }
function mcTemplateCoreV01Now_() { return Utilities.formatDate(new Date(), Session.getScriptTimeZone() || 'Asia/Seoul', 'yyyy-MM-dd HH:mm:ss'); }
function mcTemplateCoreV01Safe_(obj) { try { return JSON.parse(JSON.stringify(obj)); } catch(e) { return { ok:false, build: MC_TEMPLATE_CORE_V01_BUILD, message: String(e) }; } }
function mcTemplateCoreV01Log_(obj) { try { Logger.log('JSON_COMPACT_RESULT: ' + JSON.stringify(obj)); } catch(e) { Logger.log(obj); } }
