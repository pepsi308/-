/**
 * FEELHAUS MailCenter Attachment Library Core V01
 * Build: MC_ATTACHMENT_LIBRARY_V01_20260519
 *
 * Purpose:
 * - MailCenter 자료함
 * - 다중 파일 업로드
 * - Drive fileId / driveUrl / fileName / fileSize / mimeType 기록
 * - Drive URL 직접 등록
 * - 업로드 리스트화
 * - 삭제 대신 INACTIVE 처리
 *
 * Note:
 * - Compose 발송 직접 연결은 후속 V02에서 진행
 * - 기존 Compose/Send/Template/Log/Settings/OAuth 성공 기능 수정 없음
 */

var MC_ATTACHMENT_LIBRARY_CORE_V01_BUILD = 'MAILCENTER_ATTACHMENT_AUTO_DRIVE_CLEAN_UI_V01_20260520';
var MC_ATTACHMENT_LIBRARY_CORE_V01_SETUP_DB_ID = '17VMSpgSZCvIrUlgcw8yCNcnl8WQWo2IcRf5tDCcuJGM';
var MC_ATTACHMENT_LIBRARY_CORE_V01_CONFIG_SHEET = 'SystemConfig';
var MC_ATTACHMENT_LIBRARY_CORE_V01_FOLDER_NAME = 'FEELHAUS_MailCenter_Attachments';

function runMcAttachmentLibraryCoreV01Smoke() {
  var result = {
    ok: false,
    build: MC_ATTACHMENT_LIBRARY_CORE_V01_BUILD,
    action: 'runMcAttachmentLibraryCoreV01Smoke',
    generatedAt: mcAttachmentLibraryCoreV01Now_(),
    message: '',
    checks: []
  };

  try {
    var ss = mcAttachmentLibraryCoreV01OpenMaster_().ss;
    mcAttachmentLibraryCoreV01EnsureSheets_(ss);

    var folder = mcAttachmentLibraryCoreV01GetOrCreateFolder_();

    result.checks.push({
      key: 'MasterConnected',
      ok: !!ss,
      message: 'FEELHAUS_DB_MASTER 연결 확인'
    });
    result.checks.push({
      key: 'LibrarySheetReady',
      ok: !!ss.getSheetByName('MailCenter_AttachmentLibrary'),
      message: 'MailCenter_AttachmentLibrary 시트 확인'
    });
    result.checks.push({
      key: 'AttachmentsSheetReady',
      ok: !!ss.getSheetByName('MailCenter_Attachments'),
      message: 'MailCenter_Attachments 시트 확인'
    });
    result.checks.push({
      key: 'DriveFolderReady',
      ok: !!folder,
      message: 'Drive 자료함 폴더 확인'
    });
    result.checks.push({
      key: 'UploadFunctionReady',
      ok: typeof mcAttachmentLibraryCoreV01UploadFiles === 'function',
      message: '파일 업로드 함수 확인'
    });
    result.checks.push({
      key: 'LargeUploadSessionReady',
      ok: typeof mcAttachmentLibraryCoreV01StartLargeUpload === 'function' && typeof mcAttachmentLibraryCoreV01UploadLargeChunk === 'function' && typeof mcAttachmentLibraryCoreV01FinalizeLargeUpload === 'function',
      message: '대용량 Drive 자동 업로드 세션/조각/확정 함수 확인'
    });
    result.checks.push({
      key: 'RegisterLinkReady',
      ok: typeof mcAttachmentLibraryCoreV01RegisterDriveLink === 'function',
      message: 'Drive 링크 등록 함수 확인'
    });
    result.checks.push({
      key: 'ListFunctionReady',
      ok: typeof mcAttachmentLibraryCoreV01GetData === 'function',
      message: '자료함 목록 함수 확인'
    });

    result.ok = result.checks.every(function(c) { return !!c.ok; });
    result.message = result.ok ? 'MailCenter Attachment Library Core V01 준비 완료' : 'MailCenter Attachment Library Core V01 점검 필요';
  } catch (err) {
    result.ok = false;
    result.message = String(err && err.message ? err.message : err);
  }

  mcAttachmentLibraryCoreV01Log_(result);
  return mcAttachmentLibraryCoreV01Safe_(result);
}

function mcAttachmentLibraryCoreV01GetData(payload) {
  var result = {
    ok: false,
    build: MC_ATTACHMENT_LIBRARY_CORE_V01_BUILD,
    action: 'mcAttachmentLibraryCoreV01GetData',
    generatedAt: mcAttachmentLibraryCoreV01Now_(),
    message: '',
    summary: {
      total: 0,
      active: 0,
      inactive: 0,
      upload: 0,
      driveLink: 0
    },
    attachments: []
  };

  try {
    var ss = mcAttachmentLibraryCoreV01OpenMaster_().ss;
    mcAttachmentLibraryCoreV01EnsureSheets_(ss);

    var rows = mcAttachmentLibraryCoreV01ReadSheet_(ss, 'MailCenter_AttachmentLibrary').map(mcAttachmentLibraryCoreV01NormalizeAttachment_);

    result.attachments = rows.reverse();
    result.summary.total = rows.length;
    result.summary.active = rows.filter(function(x) { return String(x.attachmentStatus || '').toUpperCase() === 'ACTIVE'; }).length;
    result.summary.inactive = rows.filter(function(x) { return String(x.attachmentStatus || '').toUpperCase() === 'INACTIVE'; }).length;
    result.summary.upload = rows.filter(function(x) { return String(x.attachmentSource || '').toUpperCase() === 'UPLOAD'; }).length;
    result.summary.driveLink = rows.filter(function(x) { return String(x.attachmentSource || '').toUpperCase() === 'DRIVE_LINK'; }).length;

    result.ok = true;
    result.message = 'MailCenter 자료함 데이터 조회 완료';
  } catch (err) {
    result.ok = false;
    result.message = String(err && err.message ? err.message : err);
  }

  return mcAttachmentLibraryCoreV01Safe_(result);
}

function runMcAttachmentLibraryCoreV01ListRecent() {
  var result = mcAttachmentLibraryCoreV01GetData({});
  mcAttachmentLibraryCoreV01Log_(result);
  return result;
}

function mcAttachmentLibraryCoreV01ApplyShare_(driveFile, shareAccess) {
  var mode = String(shareAccess || 'ANYONE_WITH_LINK').toUpperCase();
  if (mode === 'PRIVATE' || mode === 'NONE') return 'PRIVATE';
  try {
    driveFile.setSharing(DriveApp.Access.ANYONE_WITH_LINK, DriveApp.Permission.VIEW);
    return 'ANYONE_WITH_LINK';
  } catch (shareErr) {
    return 'SHARE_FAILED: ' + String(shareErr && shareErr.message ? shareErr.message : shareErr);
  }
}

function mcAttachmentLibraryCoreV01UploadFiles(payload) {
  var result = {
    ok: false,
    build: MC_ATTACHMENT_LIBRARY_CORE_V01_BUILD,
    action: 'mcAttachmentLibraryCoreV01UploadFiles',
    generatedAt: mcAttachmentLibraryCoreV01Now_(),
    message: '',
    uploaded: [],
    failed: [],
    speedMode: 'BATCH_WRITE_FOLDER_SHARE_V01'
  };

  try {
    var p = payload || {};
    var files = p.files || [];
    var shareAccess = String(p.shareAccess || 'ANYONE_WITH_LINK').toUpperCase();
    if (!Array.isArray(files) || !files.length) throw new Error('업로드 파일이 없습니다.');

    var ss = mcAttachmentLibraryCoreV01OpenMaster_().ss;
    mcAttachmentLibraryCoreV01EnsureSheets_(ss);

    var folder = mcAttachmentLibraryCoreV01GetOrCreateFolder_();
    var libraryRows = [];
    var auditRows = [];
    var now = mcAttachmentLibraryCoreV01Now_();
    var user = mcAttachmentLibraryCoreV01User_();

    for (var i = 0; i < files.length; i++) {
      var f = files[i] || {};
      try {
        var fileName = mcAttachmentLibraryCoreV01Require_(f.fileName || f.name, 'fileName');
        var mimeType = String(f.mimeType || f.type || 'application/octet-stream');
        var base64 = mcAttachmentLibraryCoreV01Require_(f.base64 || f.data, 'base64');
        var description = String(f.description || p.description || '');
        var category = String(f.attachmentCategory || p.attachmentCategory || '공통');

        var bytes = Utilities.base64Decode(base64);
        var blob = Utilities.newBlob(bytes, mimeType, fileName);
        var driveFile = folder.createFile(blob);
        var appliedShareAccess = mcAttachmentLibraryCoreV01ApplyShare_(driveFile, shareAccess);

        var attachmentId = mcAttachmentLibraryCoreV01NewId_('MCATTLIB');
        var driveUrl = driveFile.getUrl();
        var rowObj = {
          attachmentId: attachmentId,
          sourceAttachmentId: '',
          fileName: fileName,
          driveFileId: driveFile.getId(),
          driveUrl: driveUrl,
          webViewUrl: driveUrl,
          fileSize: bytes.length,
          mimeType: mimeType,
          description: description,
          attachmentCategory: category,
          attachmentSource: 'UPLOAD',
          attachmentStatus: 'ACTIVE',
          statusReason: '업로드 완료 / 권한: ' + appliedShareAccess,
          createdAt: now,
          createdBy: user,
          updatedAt: now,
          updatedBy: user
        };

        result.uploaded.push(rowObj);
        libraryRows.push(rowObj);
        auditRows.push(mcAttachmentLibraryCoreV01BuildAuditRow_('MailCenter_AttachmentLibrary', attachmentId, 'UPLOAD_ATTACHMENT', JSON.stringify(rowObj), '자료함 파일 업로드', now, user));
      } catch (fileErr) {
        result.failed.push({
          fileName: String((f && (f.fileName || f.name)) || ''),
          message: String(fileErr && fileErr.message ? fileErr.message : fileErr)
        });
      }
    }

    if (libraryRows.length) mcAttachmentLibraryCoreV01AppendLibraryRows_(ss, libraryRows);
    if (auditRows.length) mcAttachmentLibraryCoreV01AppendAuditRows_(ss, auditRows);

    result.ok = result.uploaded.length > 0 && result.failed.length === 0;
    if (result.uploaded.length > 0 && result.failed.length > 0) {
      result.ok = true;
      result.message = '일부 파일 업로드 완료';
    } else {
      result.message = result.ok ? '파일 업로드 완료' : '파일 업로드 실패';
    }
  } catch (err) {
    result.ok = false;
    result.message = String(err && err.message ? err.message : err);
  }

  mcAttachmentLibraryCoreV01Log_(result);
  return mcAttachmentLibraryCoreV01Safe_(result);
}


function mcAttachmentLibraryCoreV01StartLargeUpload(payload) {
  var result = {
    ok: false,
    build: MC_ATTACHMENT_LIBRARY_CORE_V01_BUILD,
    action: 'mcAttachmentLibraryCoreV01StartLargeUpload',
    generatedAt: mcAttachmentLibraryCoreV01Now_(),
    message: '',
    uploadUrl: '',
    folderId: ''
  };

  try {
    var p = payload || {};
    var fileName = mcAttachmentLibraryCoreV01Require_(p.fileName || p.name, 'fileName');
    var mimeType = String(p.mimeType || p.type || 'application/octet-stream');
    var fileSize = Number(p.fileSize || p.size || 0);
    var folder = mcAttachmentLibraryCoreV01GetOrCreateFolder_();
    var metadata = {
      name: fileName,
      mimeType: mimeType,
      parents: [folder.getId()]
    };
    var url = 'https://www.googleapis.com/upload/drive/v3/files?uploadType=resumable&fields=id,name,mimeType,size,webViewLink,webContentLink';
    var resp = UrlFetchApp.fetch(url, {
      method: 'post',
      contentType: 'application/json; charset=UTF-8',
      payload: JSON.stringify(metadata),
      headers: {
        Authorization: 'Bearer ' + ScriptApp.getOAuthToken(),
        'X-Upload-Content-Type': mimeType,
        'X-Upload-Content-Length': String(fileSize || '')
      },
      muteHttpExceptions: true
    });
    var code = resp.getResponseCode();
    var headers = resp.getAllHeaders ? resp.getAllHeaders() : resp.getHeaders();
    var location = headers.Location || headers.location || '';
    if (code < 200 || code >= 300 || !location) {
      throw new Error('Drive 대용량 업로드 세션 생성 실패 HTTP ' + code + ' ' + resp.getContentText());
    }
    result.ok = true;
    result.uploadUrl = location;
    result.folderId = folder.getId();
    result.message = '대용량 Drive 직접 업로드 세션 생성 완료';
  } catch (err) {
    result.ok = false;
    result.message = String(err && err.message ? err.message : err);
  }

  return mcAttachmentLibraryCoreV01Safe_(result);
}


function mcAttachmentLibraryCoreV01UploadLargeChunk(payload) {
  var result = {
    ok: false,
    build: MC_ATTACHMENT_LIBRARY_CORE_V01_BUILD,
    action: 'mcAttachmentLibraryCoreV01UploadLargeChunk',
    generatedAt: mcAttachmentLibraryCoreV01Now_(),
    message: '',
    done: false,
    driveFileId: '',
    driveMeta: null,
    nextStart: 0
  };

  try {
    var p = payload || {};
    var uploadUrl = mcAttachmentLibraryCoreV01Require_(p.uploadUrl, 'uploadUrl');
    var mimeType = String(p.mimeType || p.type || 'application/octet-stream');
    var start = Number(p.start || 0);
    var end = Number(p.end || 0);
    var total = Number(p.total || p.fileSize || 0);
    var base64 = mcAttachmentLibraryCoreV01Require_(p.chunkBase64 || p.base64 || p.data, 'chunkBase64');
    if (!total || end < start) throw new Error('대용량 조각 범위가 올바르지 않습니다.');

    var bytes = Utilities.base64Decode(base64);
    var headers = {
      Authorization: 'Bearer ' + ScriptApp.getOAuthToken(),
      'Content-Type': mimeType,
      'Content-Range': 'bytes ' + start + '-' + end + '/' + total
    };
    var resp = UrlFetchApp.fetch(uploadUrl, {
      method: 'put',
      contentType: mimeType,
      payload: bytes,
      headers: headers,
      muteHttpExceptions: true
    });
    var code = resp.getResponseCode();
    var text = resp.getContentText() || '';
    if (code === 308) {
      var hs = resp.getAllHeaders ? resp.getAllHeaders() : resp.getHeaders();
      var range = String(hs.Range || hs.range || '');
      var m = range.match(/bytes=0-(\d+)/);
      result.ok = true;
      result.done = false;
      result.nextStart = m && m[1] ? Number(m[1]) + 1 : end + 1;
      result.message = '대용량 파일 조각 업로드 완료';
    } else if (code >= 200 && code < 300) {
      var meta = {};
      try { meta = JSON.parse(text || '{}'); } catch (parseErr) { meta = {}; }
      result.ok = true;
      result.done = true;
      result.driveFileId = meta.id || '';
      result.driveMeta = meta;
      result.nextStart = total;
      result.message = '대용량 Drive 업로드 완료';
    } else {
      throw new Error('대용량 Drive 조각 업로드 실패 HTTP ' + code + ' ' + text);
    }
  } catch (err) {
    result.ok = false;
    result.message = String(err && err.message ? err.message : err);
  }

  return mcAttachmentLibraryCoreV01Safe_(result);
}

function mcAttachmentLibraryCoreV01FinalizeLargeUpload(payload) {
  var result = {
    ok: false,
    build: MC_ATTACHMENT_LIBRARY_CORE_V01_BUILD,
    action: 'mcAttachmentLibraryCoreV01FinalizeLargeUpload',
    generatedAt: mcAttachmentLibraryCoreV01Now_(),
    message: '',
    attachment: null
  };

  try {
    var p = payload || {};
    var driveFileId = mcAttachmentLibraryCoreV01Require_(p.driveFileId || p.fileId || p.id, 'driveFileId');
    var fileName = String(p.fileName || p.name || '대용량 첨부자료').trim();
    var mimeType = String(p.mimeType || p.type || 'application/octet-stream');
    var fileSize = String(p.fileSize || p.size || '');
    var shareAccess = String(p.shareAccess || 'ANYONE_WITH_LINK').toUpperCase();
    var description = String(p.description || 'MailCenter 작성 화면 대용량 첨부');
    var category = String(p.attachmentCategory || 'ComposeUpload');

    var ss = mcAttachmentLibraryCoreV01OpenMaster_().ss;
    mcAttachmentLibraryCoreV01EnsureSheets_(ss);

    var driveFile = DriveApp.getFileById(driveFileId);
    var appliedShareAccess = mcAttachmentLibraryCoreV01ApplyShare_(driveFile, shareAccess);
    var driveUrl = driveFile.getUrl();
    var now = mcAttachmentLibraryCoreV01Now_();
    var user = mcAttachmentLibraryCoreV01User_();
    var attachmentId = mcAttachmentLibraryCoreV01NewId_('MCATTLIB');
    var rowObj = {
      attachmentId: attachmentId,
      sourceAttachmentId: '',
      fileName: fileName || driveFile.getName(),
      driveFileId: driveFileId,
      driveUrl: driveUrl,
      webViewUrl: driveUrl,
      fileSize: fileSize,
      mimeType: mimeType,
      description: description,
      attachmentCategory: category,
      attachmentSource: 'LARGE_DRIVE_UPLOAD',
      attachmentStatus: 'ACTIVE',
      statusReason: '대용량 Drive 직접 업로드 완료 / 권한: ' + appliedShareAccess,
      createdAt: now,
      createdBy: user,
      updatedAt: now,
      updatedBy: user
    };

    mcAttachmentLibraryCoreV01AppendLibrary_(ss, rowObj);
    mcAttachmentLibraryCoreV01AppendAudit_(ss, 'MailCenter_AttachmentLibrary', attachmentId, 'UPLOAD_LARGE_DRIVE_ATTACHMENT', JSON.stringify(rowObj), '대용량 Drive 직접 업로드');

    result.ok = true;
    result.attachment = rowObj;
    result.message = '대용량 Drive 첨부확정 완료';
  } catch (err) {
    result.ok = false;
    result.message = String(err && err.message ? err.message : err);
  }

  mcAttachmentLibraryCoreV01Log_(result);
  return mcAttachmentLibraryCoreV01Safe_(result);
}

function mcAttachmentLibraryCoreV01RegisterDriveLink(payload) {
  var result = {
    ok: false,
    build: MC_ATTACHMENT_LIBRARY_CORE_V01_BUILD,
    action: 'mcAttachmentLibraryCoreV01RegisterDriveLink',
    generatedAt: mcAttachmentLibraryCoreV01Now_(),
    message: '',
    attachment: null
  };

  try {
    var p = payload || {};
    var driveUrl = mcAttachmentLibraryCoreV01Require_(p.driveUrl || p.url, 'driveUrl');
    if (!/^https?:\/\//i.test(driveUrl)) throw new Error('Drive URL 형식이 올바르지 않습니다.');

    var fileName = String(p.fileName || 'Drive 링크 자료').trim();
    var description = String(p.description || '');
    var category = String(p.attachmentCategory || '공통');

    var ss = mcAttachmentLibraryCoreV01OpenMaster_().ss;
    mcAttachmentLibraryCoreV01EnsureSheets_(ss);

    var attachmentId = mcAttachmentLibraryCoreV01NewId_('MCATTLIB');
    var rowObj = {
      attachmentId: attachmentId,
      sourceAttachmentId: '',
      fileName: fileName,
      driveFileId: mcAttachmentLibraryCoreV01ExtractDriveFileId_(driveUrl),
      driveUrl: driveUrl,
      webViewUrl: driveUrl,
      fileSize: '',
      mimeType: '',
      description: description,
      attachmentCategory: category,
      attachmentSource: 'DRIVE_LINK',
      attachmentStatus: 'ACTIVE',
      statusReason: 'Drive 링크 등록 완료',
      createdAt: mcAttachmentLibraryCoreV01Now_(),
      createdBy: mcAttachmentLibraryCoreV01User_(),
      updatedAt: mcAttachmentLibraryCoreV01Now_(),
      updatedBy: mcAttachmentLibraryCoreV01User_()
    };

    mcAttachmentLibraryCoreV01AppendLibrary_(ss, rowObj);
    mcAttachmentLibraryCoreV01AppendAudit_(ss, 'MailCenter_AttachmentLibrary', attachmentId, 'REGISTER_DRIVE_LINK', JSON.stringify(rowObj), 'Drive 링크 등록');

    result.ok = true;
    result.attachment = rowObj;
    result.message = 'Drive 링크 등록 완료';
  } catch (err) {
    result.ok = false;
    result.message = String(err && err.message ? err.message : err);
  }

  mcAttachmentLibraryCoreV01Log_(result);
  return mcAttachmentLibraryCoreV01Safe_(result);
}

function mcAttachmentLibraryCoreV01SetStatus(payload) {
  var result = {
    ok: false,
    build: MC_ATTACHMENT_LIBRARY_CORE_V01_BUILD,
    action: 'mcAttachmentLibraryCoreV01SetStatus',
    generatedAt: mcAttachmentLibraryCoreV01Now_(),
    message: '',
    attachmentId: ''
  };

  try {
    var p = payload || {};
    var attachmentId = mcAttachmentLibraryCoreV01Require_(p.attachmentId, 'attachmentId');
    var status = mcAttachmentLibraryCoreV01Require_(p.attachmentStatus || p.status, 'attachmentStatus').toUpperCase();
    if (['ACTIVE', 'INACTIVE'].indexOf(status) < 0) throw new Error('허용되지 않는 상태입니다: ' + status);

    var ss = mcAttachmentLibraryCoreV01OpenMaster_().ss;
    mcAttachmentLibraryCoreV01EnsureSheets_(ss);

    var sh = ss.getSheetByName('MailCenter_AttachmentLibrary');
    var headers = mcAttachmentLibraryCoreV01Headers_(sh);
    var hm = mcAttachmentLibraryCoreV01HeaderMap_(headers);
    var row = mcAttachmentLibraryCoreV01FindRow_(sh, hm, 'attachmentId', attachmentId);
    if (row < 1) throw new Error('자료를 찾지 못했습니다: ' + attachmentId);

    mcAttachmentLibraryCoreV01SetCell_(sh, hm, row, 'attachmentStatus', status);
    mcAttachmentLibraryCoreV01SetCell_(sh, hm, row, 'statusReason', String(p.reason || '상태 변경'));
    mcAttachmentLibraryCoreV01SetCell_(sh, hm, row, 'updatedAt', mcAttachmentLibraryCoreV01Now_());
    mcAttachmentLibraryCoreV01SetCell_(sh, hm, row, 'updatedBy', mcAttachmentLibraryCoreV01User_());

    mcAttachmentLibraryCoreV01AppendAudit_(ss, 'MailCenter_AttachmentLibrary', attachmentId, 'SET_ATTACHMENT_STATUS', status, String(p.reason || '상태 변경'));

    result.ok = true;
    result.attachmentId = attachmentId;
    result.message = '자료 상태 변경 완료';
  } catch (err) {
    result.ok = false;
    result.message = String(err && err.message ? err.message : err);
  }

  mcAttachmentLibraryCoreV01Log_(result);
  return mcAttachmentLibraryCoreV01Safe_(result);
}

function mcAttachmentLibraryCoreV01EnsureSheets_(ss) {
  mcAttachmentLibraryCoreV01GetSheetOrCreate_(ss, 'MailCenter_AttachmentLibrary', [
    'attachmentId','sourceAttachmentId','fileName','driveFileId','driveUrl','webViewUrl','fileSize','mimeType',
    'description','attachmentCategory','attachmentSource','attachmentStatus','statusReason',
    'createdAt','createdBy','updatedAt','updatedBy'
  ]);

  mcAttachmentLibraryCoreV01GetSheetOrCreate_(ss, 'MailCenter_Attachments', [
    'attachmentId','mailAccountId','toEmail','subject','fileName','driveUrl','description',
    'attachmentType','attachmentStatus','gmailMessageId','createdAt','createdBy'
  ]);

  mcAttachmentLibraryCoreV01GetSheetOrCreate_(ss, 'MailCenter_AuditLogs', [
    'mailAuditLogId','targetType','targetId','vendorId','eventId','actionType',
    'beforeValue','afterValue','reason','createdAt','createdBy'
  ]);
}

function mcAttachmentLibraryCoreV01AppendLibrary_(ss, rowObj) {
  var sh = ss.getSheetByName('MailCenter_AttachmentLibrary');
  var headers = mcAttachmentLibraryCoreV01Headers_(sh);
  sh.appendRow(headers.map(function(h) { return rowObj[h] !== undefined ? rowObj[h] : ''; }));
}

function mcAttachmentLibraryCoreV01AppendAudit_(ss, targetType, targetId, actionType, afterValue, reason) {
  var sh = ss.getSheetByName('MailCenter_AuditLogs');
  if (!sh) return;
  var headers = mcAttachmentLibraryCoreV01Headers_(sh);
  var rowObj = {
    mailAuditLogId: mcAttachmentLibraryCoreV01NewId_('MCAUD'),
    targetType: targetType || '',
    targetId: targetId || '',
    vendorId: '',
    eventId: '',
    actionType: actionType || '',
    beforeValue: '',
    afterValue: afterValue || '',
    reason: reason || '',
    createdAt: mcAttachmentLibraryCoreV01Now_(),
    createdBy: mcAttachmentLibraryCoreV01User_()
  };
  sh.appendRow(headers.map(function(h) { return rowObj[h] !== undefined ? rowObj[h] : ''; }));
}

function mcAttachmentLibraryCoreV01AppendLibraryRows_(ss, rows) {
  if (!rows || !rows.length) return;
  var sh = ss.getSheetByName('MailCenter_AttachmentLibrary');
  var headers = mcAttachmentLibraryCoreV01Headers_(sh);
  var values = rows.map(function(rowObj) {
    return headers.map(function(h) { return rowObj[h] !== undefined ? rowObj[h] : ''; });
  });
  sh.getRange(sh.getLastRow() + 1, 1, values.length, headers.length).setValues(values);
}

function mcAttachmentLibraryCoreV01BuildAuditRow_(targetType, targetId, actionType, afterValue, reason, now, user) {
  return {
    mailAuditLogId: mcAttachmentLibraryCoreV01NewId_('MCAUD'),
    targetType: targetType || '',
    targetId: targetId || '',
    vendorId: '',
    eventId: '',
    actionType: actionType || '',
    beforeValue: '',
    afterValue: afterValue || '',
    reason: reason || '',
    createdAt: now || mcAttachmentLibraryCoreV01Now_(),
    createdBy: user || mcAttachmentLibraryCoreV01User_()
  };
}

function mcAttachmentLibraryCoreV01AppendAuditRows_(ss, rows) {
  if (!rows || !rows.length) return;
  var sh = ss.getSheetByName('MailCenter_AuditLogs');
  if (!sh) return;
  var headers = mcAttachmentLibraryCoreV01Headers_(sh);
  var values = rows.map(function(rowObj) {
    return headers.map(function(h) { return rowObj[h] !== undefined ? rowObj[h] : ''; });
  });
  sh.getRange(sh.getLastRow() + 1, 1, values.length, headers.length).setValues(values);
}

function mcAttachmentLibraryCoreV01ReadSheet_(ss, sheetName) {
  var sh = ss.getSheetByName(sheetName);
  if (!sh) return [];
  var values = sh.getDataRange().getValues();
  if (!values || values.length < 2) return [];
  var hm = mcAttachmentLibraryCoreV01HeaderMap_(values[0]);
  var rows = [];
  for (var r = 1; r < values.length; r++) {
    var obj = mcAttachmentLibraryCoreV01RowObject_(values[r], hm);
    if (Object.keys(obj).some(function(k) { return obj[k] !== '' && obj[k] != null; })) rows.push(obj);
  }
  return rows;
}

function mcAttachmentLibraryCoreV01NormalizeAttachment_(x) {
  return {
    attachmentId: String(x.attachmentId || ''),
    sourceAttachmentId: String(x.sourceAttachmentId || ''),
    fileName: String(x.fileName || ''),
    driveFileId: String(x.driveFileId || ''),
    driveUrl: String(x.driveUrl || ''),
    webViewUrl: String(x.webViewUrl || x.driveUrl || ''),
    fileSize: String(x.fileSize || ''),
    mimeType: String(x.mimeType || ''),
    description: String(x.description || ''),
    attachmentCategory: String(x.attachmentCategory || ''),
    attachmentSource: String(x.attachmentSource || ''),
    attachmentStatus: String(x.attachmentStatus || ''),
    statusReason: String(x.statusReason || ''),
    createdAt: String(x.createdAt || ''),
    createdBy: String(x.createdBy || ''),
    updatedAt: String(x.updatedAt || ''),
    updatedBy: String(x.updatedBy || '')
  };
}

function mcAttachmentLibraryCoreV01GetOrCreateFolder_() {
  var folders = DriveApp.getFoldersByName(MC_ATTACHMENT_LIBRARY_CORE_V01_FOLDER_NAME);
  var folder = folders.hasNext() ? folders.next() : DriveApp.createFolder(MC_ATTACHMENT_LIBRARY_CORE_V01_FOLDER_NAME);
  try {
    folder.setSharing(DriveApp.Access.ANYONE_WITH_LINK, DriveApp.Permission.VIEW);
  } catch (shareErr) {
    // 조직 정책상 공유 설정이 막혀도 업로드와 기록은 유지한다.
  }
  return folder;
}

function mcAttachmentLibraryCoreV01ExtractDriveFileId_(url) {
  var s = String(url || '');
  var m = s.match(/\/d\/([a-zA-Z0-9_-]+)/);
  if (m && m[1]) return m[1];
  m = s.match(/[?&]id=([a-zA-Z0-9_-]+)/);
  if (m && m[1]) return m[1];
  return '';
}

function mcAttachmentLibraryCoreV01OpenMaster_() {
  if (typeof portal19GetConfigBundle_ === 'function' && typeof portal19OpenMaster_ === 'function') {
    var bundle = portal19GetConfigBundle_();
    var ssByPortal = portal19OpenMaster_(bundle);
    if (ssByPortal) return { ss: ssByPortal, masterDbId: bundle.masterDbId || '' };
  }

  var setup = SpreadsheetApp.openById(MC_ATTACHMENT_LIBRARY_CORE_V01_SETUP_DB_ID);
  var configSheet = setup.getSheetByName(MC_ATTACHMENT_LIBRARY_CORE_V01_CONFIG_SHEET);
  if (!configSheet) throw new Error('SystemConfig 시트를 찾지 못했습니다.');

  var values = configSheet.getDataRange().getValues();
  var hm = mcAttachmentLibraryCoreV01HeaderMap_(values[0]);
  var keyCol = mcAttachmentLibraryCoreV01FindHeader_(hm, ['CONFIG_KEY','configKey','KEY','key']);
  var valCol = mcAttachmentLibraryCoreV01FindHeader_(hm, ['VALUE','CONFIG_VALUE','configValue','value']);

  var masterId = '';
  for (var r = 1; r < values.length; r++) {
    var key = String(values[r][keyCol] || '').trim();
    if (key === 'FEELHAUS_DB_MASTER' || key === 'FEELHAUS_DB_MASTER_ID' || key === 'MASTER_DB_ID') {
      masterId = String(values[r][valCol] || '').trim();
      break;
    }
  }
  if (!masterId) throw new Error('SystemConfig에서 FEELHAUS_DB_MASTER ID를 찾지 못했습니다.');
  return { ss: SpreadsheetApp.openById(masterId), masterDbId: masterId };
}

function mcAttachmentLibraryCoreV01GetSheetOrCreate_(ss, sheetName, headers) {
  var sh = ss.getSheetByName(sheetName);
  if (!sh) sh = ss.insertSheet(sheetName);
  var lastCol = sh.getLastColumn();
  if (lastCol < 1) {
    sh.getRange(1, 1, 1, headers.length).setValues([headers]);
    return sh;
  }
  var existing = sh.getRange(1, 1, 1, lastCol).getValues()[0].map(function(v) { return String(v || '').trim(); });
  var append = [];
  headers.forEach(function(h) { if (existing.indexOf(h) < 0) append.push(h); });
  if (append.length) sh.getRange(1, existing.length + 1, 1, append.length).setValues([append]);
  return sh;
}

function mcAttachmentLibraryCoreV01Headers_(sh) {
  return sh.getRange(1, 1, 1, sh.getLastColumn()).getValues()[0].map(function(h) { return String(h || '').trim(); });
}
function mcAttachmentLibraryCoreV01HeaderMap_(header) {
  var hm = {};
  for (var i = 0; i < header.length; i++) {
    var raw = String(header[i] || '').trim();
    if (!raw) continue;
    hm[raw] = i;
    var norm = mcAttachmentLibraryCoreV01Normalize_(raw);
    if (hm[norm] == null) hm[norm] = i;
  }
  return hm;
}
function mcAttachmentLibraryCoreV01FindHeader_(hm, names) {
  for (var i = 0; i < names.length; i++) {
    if (hm[names[i]] != null) return hm[names[i]];
    var norm = mcAttachmentLibraryCoreV01Normalize_(names[i]);
    if (hm[norm] != null) return hm[norm];
  }
  return -1;
}
function mcAttachmentLibraryCoreV01RowObject_(row, hm) {
  var obj = {};
  Object.keys(hm).forEach(function(k) {
    if (k === mcAttachmentLibraryCoreV01Normalize_(k)) return;
    var val = row[hm[k]];
    obj[k] = val instanceof Date
      ? Utilities.formatDate(val, Session.getScriptTimeZone() || 'Asia/Seoul', 'yyyy-MM-dd HH:mm:ss')
      : val;
  });
  return obj;
}
function mcAttachmentLibraryCoreV01FindRow_(sh, hm, key, value) {
  var values = sh.getDataRange().getValues();
  var idx = hm[key] != null ? hm[key] : hm[mcAttachmentLibraryCoreV01Normalize_(key)];
  for (var r = 1; r < values.length; r++) {
    if (idx != null && String(values[r][idx]) === String(value)) return r + 1;
  }
  return -1;
}
function mcAttachmentLibraryCoreV01SetCell_(sh, hm, row, key, value) {
  var idx = hm[key];
  if (idx == null) idx = hm[mcAttachmentLibraryCoreV01Normalize_(key)];
  if (idx == null) return;
  sh.getRange(row, idx + 1).setValue(value);
}
function mcAttachmentLibraryCoreV01Normalize_(v) { return String(v || '').trim().toUpperCase().replace(/[^A-Z0-9]/g, ''); }
function mcAttachmentLibraryCoreV01Require_(v, name) { var s = String(v || '').trim(); if (!s) throw new Error(name + ' 값이 필요합니다.'); return s; }
function mcAttachmentLibraryCoreV01NewId_(prefix) { return prefix + '-' + Utilities.formatDate(new Date(), Session.getScriptTimeZone() || 'Asia/Seoul', 'yyyyMMddHHmmss') + '-' + Math.floor(Math.random() * 9000 + 1000); }
function mcAttachmentLibraryCoreV01User_() { try { return Session.getActiveUser().getEmail() || ''; } catch(e) { return ''; } }
function mcAttachmentLibraryCoreV01Now_() { return Utilities.formatDate(new Date(), Session.getScriptTimeZone() || 'Asia/Seoul', 'yyyy-MM-dd HH:mm:ss'); }
function mcAttachmentLibraryCoreV01Safe_(obj) { try { return JSON.parse(JSON.stringify(obj)); } catch(e) { return { ok:false, build: MC_ATTACHMENT_LIBRARY_CORE_V01_BUILD, message: String(e) }; } }
function mcAttachmentLibraryCoreV01Log_(obj) { try { Logger.log('JSON_COMPACT_RESULT: ' + JSON.stringify(obj)); } catch(e) { Logger.log(obj); } }
