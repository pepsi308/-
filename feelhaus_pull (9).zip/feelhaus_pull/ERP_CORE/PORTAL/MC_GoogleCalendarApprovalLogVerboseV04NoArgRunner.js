/*******************************************************
 * MC_GOOGLE_CALENDAR_APPROVAL_LOG_VERBOSE_V04_NO_ARG_RUNNER_20260527
 * Purpose: Apps Script execution-button friendly no-argument runners.
 *
 * Rules:
 * - Never output START/END only.
 * - No-arg log runners must return compact, visible JSON.
 * - GetRecent1~5 are safe read-only wrappers around V03 GetOne.
 * - PreviewDefault is dry-run / no real Google Calendar apply.
 * - Real apply wrapper is intentionally property-locked to prevent accidental dropdown execution.
 *******************************************************/

var MC_GCAL_LOG_VERBOSE_V04_BUILD = 'MC_GOOGLE_CALENDAR_APPROVAL_LOG_VERBOSE_V04_NO_ARG_RUNNER_20260527';

function mcGoogleCalendarApprovalLogVerboseV04SelfTest() {
  var result = mcGoogleCalendarApprovalLogVerboseV04BaseResult_('mcGoogleCalendarApprovalLogVerboseV04SelfTest');
  try {
    result.checks = {
      v03SelfTestReady: typeof mcGoogleCalendarApprovalLogVerboseV03SelfTest === 'function',
      v03DiagnoseReady: typeof mcGoogleCalendarApprovalLogVerboseV03Diagnose === 'function',
      v03ListCompactReady: typeof mcGoogleCalendarApprovalLogVerboseV03ListCompact === 'function',
      v03GetOneReady: typeof mcGoogleCalendarApprovalLogVerboseV03GetOne === 'function',
      v03GetFirstReady: typeof mcGoogleCalendarApprovalLogVerboseV03GetFirst === 'function',
      approvalPreviewReady: typeof mcGoogleCalendarSyncApprovalApplyV01Preview === 'function',
      approvalApplyReady: typeof mcGoogleCalendarSyncApprovalApplyV01 === 'function'
    };
    result.ok = true;
    for (var k in result.checks) {
      if (result.checks.hasOwnProperty(k) && !result.checks[k]) result.ok = false;
    }
    result.message = result.ok ? 'V04 No-Arg Runner 준비 완료' : 'V04 No-Arg Runner 의존 함수 확인 필요';
    result.availableRunners = [
      'mcGoogleCalendarApprovalLogVerboseV04DiagnoseDefault',
      'mcGoogleCalendarApprovalLogVerboseV04ListRecent5',
      'mcGoogleCalendarApprovalLogVerboseV04GetRecent1',
      'mcGoogleCalendarApprovalLogVerboseV04GetRecent2',
      'mcGoogleCalendarApprovalLogVerboseV04GetRecent3',
      'mcGoogleCalendarApprovalLogVerboseV04GetRecent4',
      'mcGoogleCalendarApprovalLogVerboseV04GetRecent5',
      'mcGoogleCalendarApprovalLogVerboseV04PreviewDefaultMax5',
      'mcGoogleCalendarApprovalLogVerboseV04RealApplyMax5_LOCKED'
    ];
    result.nextAction = 'mcGoogleCalendarApprovalLogVerboseV04DiagnoseDefault 실행';
  } catch (err) {
    mcGoogleCalendarApprovalLogVerboseV04Catch_(result, err);
  }
  return mcGoogleCalendarApprovalLogVerboseV04Finish_(result);
}

function mcGoogleCalendarApprovalLogVerboseV04DiagnoseDefault() {
  return mcGoogleCalendarApprovalLogVerboseV04Wrap_('mcGoogleCalendarApprovalLogVerboseV04DiagnoseDefault', function() {
    return mcGoogleCalendarApprovalLogVerboseV03Diagnose({ limit: 10 });
  }, 'V03 Minimal 진단을 기본 limit 10으로 실행했습니다.');
}

function mcGoogleCalendarApprovalLogVerboseV04ListRecent5() {
  return mcGoogleCalendarApprovalLogVerboseV04Wrap_('mcGoogleCalendarApprovalLogVerboseV04ListRecent5', function() {
    return mcGoogleCalendarApprovalLogVerboseV03ListCompact({ limit: 5 });
  }, '최근 Google Calendar Sync 로그 5건 ID 목록을 조회했습니다.');
}

function mcGoogleCalendarApprovalLogVerboseV04GetRecent1() { return mcGoogleCalendarApprovalLogVerboseV04GetRecentByIndex_(1); }
function mcGoogleCalendarApprovalLogVerboseV04GetRecent2() { return mcGoogleCalendarApprovalLogVerboseV04GetRecentByIndex_(2); }
function mcGoogleCalendarApprovalLogVerboseV04GetRecent3() { return mcGoogleCalendarApprovalLogVerboseV04GetRecentByIndex_(3); }
function mcGoogleCalendarApprovalLogVerboseV04GetRecent4() { return mcGoogleCalendarApprovalLogVerboseV04GetRecentByIndex_(4); }
function mcGoogleCalendarApprovalLogVerboseV04GetRecent5() { return mcGoogleCalendarApprovalLogVerboseV04GetRecentByIndex_(5); }

function mcGoogleCalendarApprovalLogVerboseV04GetFirst() {
  return mcGoogleCalendarApprovalLogVerboseV04Wrap_('mcGoogleCalendarApprovalLogVerboseV04GetFirst', function() {
    return mcGoogleCalendarApprovalLogVerboseV03GetFirst();
  }, '최근 Google Calendar Sync 로그 1건 상세를 조회했습니다.');
}

function mcGoogleCalendarApprovalLogVerboseV04GetRecentByIndex_(index) {
  return mcGoogleCalendarApprovalLogVerboseV04Wrap_('mcGoogleCalendarApprovalLogVerboseV04GetRecent' + index, function() {
    var list = mcGoogleCalendarApprovalLogVerboseV03ListCompact({ limit: Math.max(index, 5) });
    var ids = list && list.recentIds ? list.recentIds : [];
    var target = ids[index - 1];
    if (!target || !target.syncLogId) {
      throw new Error('최근 로그 ' + index + '번 syncLogId를 찾지 못했습니다. 먼저 V04ListRecent5를 실행하세요.');
    }
    var one = mcGoogleCalendarApprovalLogVerboseV03GetOne({ syncLogId: target.syncLogId });
    one.selectedIndex = index;
    one.selected = target;
    return one;
  }, '최근 Google Calendar Sync 로그 ' + index + '번 상세를 조회했습니다.');
}

function mcGoogleCalendarApprovalLogVerboseV04PreviewDefaultMax5() {
  return mcGoogleCalendarApprovalLogVerboseV04Wrap_('mcGoogleCalendarApprovalLogVerboseV04PreviewDefaultMax5', function() {
    if (typeof mcGoogleCalendarSyncApprovalApplyV01Preview !== 'function') {
      throw new Error('mcGoogleCalendarSyncApprovalApplyV01Preview 함수를 찾지 못했습니다. Approval Apply V01 파일 적용 여부를 확인하세요.');
    }
    return mcGoogleCalendarSyncApprovalApplyV01Preview({
      direction: 'PORTAL_TO_GOOGLE',
      maxOps: 5
    });
  }, 'Google Calendar 승인 실반영 전 Preview를 maxOps 5로 실행했습니다. 실제 Google 생성은 하지 않습니다.');
}

function mcGoogleCalendarApprovalLogVerboseV04PreviewDefaultMax10() {
  return mcGoogleCalendarApprovalLogVerboseV04Wrap_('mcGoogleCalendarApprovalLogVerboseV04PreviewDefaultMax10', function() {
    if (typeof mcGoogleCalendarSyncApprovalApplyV01Preview !== 'function') {
      throw new Error('mcGoogleCalendarSyncApprovalApplyV01Preview 함수를 찾지 못했습니다. Approval Apply V01 파일 적용 여부를 확인하세요.');
    }
    return mcGoogleCalendarSyncApprovalApplyV01Preview({
      direction: 'PORTAL_TO_GOOGLE',
      maxOps: 10
    });
  }, 'Google Calendar 승인 실반영 전 Preview를 maxOps 10으로 실행했습니다. 실제 Google 생성은 하지 않습니다.');
}

function mcGoogleCalendarApprovalLogVerboseV04RealApplyMax5_LOCKED() {
  return mcGoogleCalendarApprovalLogVerboseV04Wrap_('mcGoogleCalendarApprovalLogVerboseV04RealApplyMax5_LOCKED', function() {
    var props = PropertiesService.getScriptProperties();
    var allow = String(props.getProperty('MC_GOOGLE_REAL_APPLY_NO_ARG_APPROVED') || '').trim().toUpperCase();
    if (allow !== 'YES') {
      throw new Error('실반영 차단: no-arg 실반영은 Script Properties의 MC_GOOGLE_REAL_APPLY_NO_ARG_APPROVED 값이 YES일 때만 실행됩니다. 먼저 PreviewDefaultMax5 결과와 SystemConfig ON을 확인하세요.');
    }
    if (typeof mcGoogleCalendarSyncApprovalApplyV01 !== 'function') {
      throw new Error('mcGoogleCalendarSyncApprovalApplyV01 함수를 찾지 못했습니다. Approval Apply V01 파일 적용 여부를 확인하세요.');
    }
    return mcGoogleCalendarSyncApprovalApplyV01({
      confirmApply: 'YES',
      direction: 'PORTAL_TO_GOOGLE',
      maxOps: 5
    });
  }, 'Google Calendar 실제 반영 maxOps 5 실행 래퍼입니다. Script Properties 승인값이 없으면 차단됩니다.');
}

function mcGoogleCalendarApprovalLogVerboseV04ShowRealApplyUnlockGuide() {
  var result = mcGoogleCalendarApprovalLogVerboseV04BaseResult_('mcGoogleCalendarApprovalLogVerboseV04ShowRealApplyUnlockGuide');
  result.ok = true;
  result.message = '실제 Google Calendar 생성 실행 전 확인 절차입니다.';
  result.requiredChecks = [
    'mcGoogleCalendarApprovalLogVerboseV04PreviewDefaultMax5 실행 결과 ok=true 확인',
    'Preview 결과에서 realApplyExecuted=false 확인',
    'SystemConfig FEATURE_GOOGLE_CALENDAR_BIDIRECTIONAL_SYNC_ENABLED=ON 확인',
    'portalToGoogle 생성 예정 건수와 maxOps=5 확인',
    '충돌/conflicts=0 확인',
    '실행 직전 Script Properties에 MC_GOOGLE_REAL_APPLY_NO_ARG_APPROVED=YES 설정',
    'mcGoogleCalendarApprovalLogVerboseV04RealApplyMax5_LOCKED 실행',
    '실행 후 MC_GOOGLE_REAL_APPLY_NO_ARG_APPROVED 값을 비우거나 NO로 변경'
  ];
  result.nextAction = '실반영 승인 전에는 PreviewDefaultMax5만 실행하세요.';
  return mcGoogleCalendarApprovalLogVerboseV04Finish_(result);
}

function mcGoogleCalendarApprovalLogVerboseV04Wrap_(action, fn, message) {
  var result = mcGoogleCalendarApprovalLogVerboseV04BaseResult_(action);
  try {
    var inner = fn();
    result.ok = !!(inner && inner.ok === true);
    result.message = message || (inner && inner.message) || 'V04 no-arg runner 실행 완료';
    result.innerAction = inner && inner.action ? inner.action : '';
    result.innerBuild = inner && inner.build ? inner.build : '';
    result.summary = inner && inner.summary ? inner.summary : undefined;
    result.filters = inner && inner.filters ? inner.filters : undefined;
    result.recentIds = inner && inner.recentIds ? inner.recentIds : undefined;
    result.sampleTitles = inner && inner.sampleTitles ? inner.sampleTitles : undefined;
    result.rowCompact = inner && inner.rowCompact ? inner.rowCompact : undefined;
    result.selected = inner && inner.selected ? inner.selected : undefined;
    result.selectedIndex = inner && inner.selectedIndex ? inner.selectedIndex : undefined;
    result.policy = inner && inner.policy ? inner.policy : undefined;
    result.realApplyExecuted = inner && typeof inner.realApplyExecuted !== 'undefined' ? inner.realApplyExecuted : undefined;
    result.approved = inner && typeof inner.approved !== 'undefined' ? inner.approved : undefined;
    result.dryRunSummary = inner && inner.dryRunPlan && inner.dryRunPlan.summary ? inner.dryRunPlan.summary : undefined;
    result.applySummary = inner && inner.applyResult && inner.applyResult.summary ? inner.applyResult.summary : undefined;
    result.innerMessage = inner && inner.message ? inner.message : '';
    result.warnings = inner && inner.warnings ? inner.warnings : [];
    result.errors = inner && inner.errors ? inner.errors : [];
    result.nextAction = mcGoogleCalendarApprovalLogVerboseV04NextAction_(action, inner);
  } catch (err) {
    mcGoogleCalendarApprovalLogVerboseV04Catch_(result, err);
  }
  return mcGoogleCalendarApprovalLogVerboseV04Finish_(result);
}

function mcGoogleCalendarApprovalLogVerboseV04NextAction_(action, inner) {
  if (action === 'mcGoogleCalendarApprovalLogVerboseV04SelfTest') return 'mcGoogleCalendarApprovalLogVerboseV04DiagnoseDefault 실행';
  if (action === 'mcGoogleCalendarApprovalLogVerboseV04DiagnoseDefault') return 'mcGoogleCalendarApprovalLogVerboseV04ListRecent5 또는 PreviewDefaultMax5 실행';
  if (action === 'mcGoogleCalendarApprovalLogVerboseV04ListRecent5') return '상세 확인은 GetRecent1~5 중 하나를 실행';
  if (action.indexOf('GetRecent') >= 0 || action === 'mcGoogleCalendarApprovalLogVerboseV04GetFirst') return '상세 확인 완료. 실반영 전에는 PreviewDefaultMax5 실행';
  if (action === 'mcGoogleCalendarApprovalLogVerboseV04PreviewDefaultMax5' || action === 'mcGoogleCalendarApprovalLogVerboseV04PreviewDefaultMax10') return '실반영이 필요하면 결과 확인 후 ShowRealApplyUnlockGuide를 먼저 실행';
  if (action === 'mcGoogleCalendarApprovalLogVerboseV04RealApplyMax5_LOCKED') return '실반영 후 ListRecent5와 GetRecent1로 googleEventId 기록 여부 확인';
  return inner && inner.nextAction ? inner.nextAction : '다음 단계 확인';
}

function mcGoogleCalendarApprovalLogVerboseV04BaseResult_(action) {
  return {
    ok: false,
    build: MC_GCAL_LOG_VERBOSE_V04_BUILD,
    action: action,
    generatedAt: mcGoogleCalendarApprovalLogVerboseV04Now_(),
    message: '',
    warnings: [],
    errors: []
  };
}

function mcGoogleCalendarApprovalLogVerboseV04Finish_(result) {
  result.endedAt = mcGoogleCalendarApprovalLogVerboseV04Now_();
  var compact = mcGoogleCalendarApprovalLogVerboseV04CompactResult_(result);
  Logger.log('JSON_COMPACT_RESULT: ' + mcGoogleCalendarApprovalLogVerboseV04Stringify_(compact));
  return mcGoogleCalendarApprovalLogVerboseV04Safe_(result);
}

function mcGoogleCalendarApprovalLogVerboseV04CompactResult_(result) {
  return {
    ok: result.ok,
    build: result.build,
    action: result.action,
    generatedAt: result.generatedAt,
    endedAt: result.endedAt,
    message: result.message,
    innerBuild: result.innerBuild || undefined,
    innerAction: result.innerAction || undefined,
    innerMessage: result.innerMessage || undefined,
    filters: result.filters || undefined,
    checks: result.checks || undefined,
    availableRunners: result.availableRunners || undefined,
    summary: result.summary || undefined,
    dryRunSummary: result.dryRunSummary || undefined,
    applySummary: result.applySummary || undefined,
    policy: result.policy || undefined,
    realApplyExecuted: result.realApplyExecuted,
    approved: result.approved,
    recentIds: result.recentIds || undefined,
    sampleTitles: result.sampleTitles || undefined,
    selectedIndex: result.selectedIndex || undefined,
    selected: result.selected || undefined,
    rowCompact: result.rowCompact || undefined,
    requiredChecks: result.requiredChecks || undefined,
    warnings: result.warnings || [],
    errors: result.errors || [],
    nextAction: result.nextAction || ''
  };
}

function mcGoogleCalendarApprovalLogVerboseV04Catch_(result, err) {
  result.ok = false;
  result.message = mcGoogleCalendarApprovalLogVerboseV04Error_(err);
  result.errors = result.errors || [];
  result.errors.push({ message: result.message, stack: err && err.stack ? String(err.stack).substring(0, 1200) : '' });
  result.nextAction = '오류 메시지 확인 후 함수 선택/Script Properties/SystemConfig 상태를 점검하세요.';
}

function mcGoogleCalendarApprovalLogVerboseV04Safe_(obj) {
  try { return JSON.parse(JSON.stringify(obj)); } catch (err) { return obj; }
}

function mcGoogleCalendarApprovalLogVerboseV04Stringify_(obj) {
  try { return JSON.stringify(obj); } catch (err) { return mcGoogleCalendarApprovalLogVerboseV04Error_(err); }
}

function mcGoogleCalendarApprovalLogVerboseV04Error_(err) {
  if (!err) return '';
  if (err.name && err.message) return String(err.name) + ': ' + String(err.message);
  if (err.message) return String(err.message);
  return String(err);
}

function mcGoogleCalendarApprovalLogVerboseV04Now_() {
  try { return Utilities.formatDate(new Date(), Session.getScriptTimeZone() || 'Asia/Seoul', 'yyyy-MM-dd HH:mm:ss'); }
  catch (err) { return String(new Date()); }
}
