/**
 * FEELHAUS PORTAL / MailCenter Calendar Approval Queue V01
 * Build: PORTAL_MC_CALENDAR_APPROVAL_QUEUE_V01_20260528
 * Purpose:
 * - ERP/Mail 연동 캘린더 일정 중 sourceUpdateStatus=APPROVAL_REQUIRED/PENDING 건을 승인대기 목록으로 수집한다.
 * - 승인/반려는 캘린더 원장과 승인 큐/변경 로그에만 기록한다.
 * - ERP 원본, Google Calendar, Naver 자동반영은 이 단계에서 실행하지 않는다.
 */
var MC_CALENDAR_APPROVAL_QUEUE_V01_BUILD = 'PORTAL_MC_CALENDAR_APPROVAL_QUEUE_V01_20260528';

function calApprHelp() {
  var r = mcCalApprV01Base_('calApprHelp');
  r.ok = true;
  r.message = '캘린더 승인대기 짧은 실행 함수 안내';
  r.runners = [
    { fn: 'calApprTest()', desc: '사전점검: 캘린더 원장/승인큐/변경로그/필수 헤더 확인' },
    { fn: 'calApprScan()', desc: 'APPROVAL_REQUIRED/PENDING 일정을 승인큐로 수집/동기화' },
    { fn: 'calApprList()', desc: '최근 승인대기/승인/반려 목록 조회' },
    { fn: 'calApprApproveDry()', desc: '최근 승인대기 1건 승인 DryRun. 저장 없음' },
    { fn: 'calApprApprove()', desc: '최근 승인대기 1건 승인 처리. ERP 원본 반영 없음' },
    { fn: 'calApprRejectDry()', desc: '최근 승인대기 1건 반려 DryRun. 저장 없음' },
    { fn: 'calApprReject()', desc: '최근 승인대기 1건 반려 처리. ERP 원본 반영 없음' }
  ];
  r.nextAction = 'calApprTest() 실행 후 calApprScan()을 실행하세요.';
  return mcCalApprV01Print_(r);
}

function calApprTest() { return mcCalendarApprovalQueueV01SelfTest(); }
function calApprScan() { return mcCalendarApprovalQueueV01Scan(); }
function calApprList() { return mcCalendarApprovalQueueV01ListRecent(); }
function calApprApproveDry() { return mcCalendarApprovalQueueV01ApproveRecentDryRun(); }
function calApprApprove() { return mcCalendarApprovalQueueV01ApproveRecent(); }
function calApprRejectDry() { return mcCalendarApprovalQueueV01RejectRecentDryRun(); }
function calApprReject() { return mcCalendarApprovalQueueV01RejectRecent(); }

function mcCalendarApprovalQueueV01SelfTest() {
  var r = mcCalApprV01Base_('mcCalendarApprovalQueueV01SelfTest');
  try {
    var ss = mcCalApprV01OpenMaster_();
    var calendar = mcCalApprV01GetSheetOrCreate_(ss, 'MAILCENTER_CalendarEvents', mcCalApprV01CalendarHeaders_());
    var queue = mcCalApprV01GetSheetOrCreate_(ss, 'MAILCENTER_CalendarApprovalQueue', mcCalApprV01QueueHeaders_());
    var logs = mcCalApprV01GetSheetOrCreate_(ss, 'MAILCENTER_CalendarChangeLogs', mcCalApprV01ChangeLogHeaders_());
    var ch = mcCalApprV01HeaderMap_(calendar);
    var qh = mcCalApprV01HeaderMap_(queue);
    var requiredCalendar = ['calendarEventId','sourceType','sourceWritePolicy','sourceUpdateStatus','title','eventTitle','eventId','vendorId','customerId','updatedAt','updatedBy'];
    var requiredQueue = mcCalApprV01QueueHeaders_();
    var missingCalendar = requiredCalendar.filter(function(h){ return ch[h] === undefined; });
    var missingQueue = requiredQueue.filter(function(h){ return qh[h] === undefined; });
    r.ok = missingCalendar.length === 0 && missingQueue.length === 0;
    r.checks = {
      masterDbOk: !!ss,
      calendarSheetOk: !!calendar,
      approvalQueueSheetOk: !!queue,
      changeLogSheetOk: !!logs,
      missingCalendarHeaderCount: missingCalendar.length,
      missingQueueHeaderCount: missingQueue.length,
      realApplyExecuted: false,
      destructiveRepairExecuted: false
    };
    r.targetSheets = [
      { sheetName: calendar.getName(), lastRow: calendar.getLastRow(), lastColumn: calendar.getLastColumn() },
      { sheetName: queue.getName(), lastRow: queue.getLastRow(), lastColumn: queue.getLastColumn() },
      { sheetName: logs.getName(), lastRow: logs.getLastRow(), lastColumn: logs.getLastColumn() }
    ];
    r.missingCalendarHeaders = missingCalendar;
    r.missingQueueHeaders = missingQueue;
    r.message = r.ok ? '캘린더 승인대기 V01 준비 완료' : '승인대기 사전점검에서 누락 헤더가 있습니다.';
    r.nextAction = r.ok ? 'calApprScan() 실행으로 승인대기 건을 수집하세요.' : 'missingHeaders를 먼저 확인하세요.';
  } catch (err) { mcCalApprV01Catch_(r, err); }
  return mcCalApprV01Print_(r);
}

function mcCalendarApprovalQueueV01Scan() {
  var r = mcCalApprV01Base_('mcCalendarApprovalQueueV01Scan');
  try {
    var ss = mcCalApprV01OpenMaster_();
    var calendar = mcCalApprV01GetSheetOrCreate_(ss, 'MAILCENTER_CalendarEvents', mcCalApprV01CalendarHeaders_());
    var queue = mcCalApprV01GetSheetOrCreate_(ss, 'MAILCENTER_CalendarApprovalQueue', mcCalApprV01QueueHeaders_());
    var ch = mcCalApprV01HeaderMap_(calendar);
    var qh = mcCalApprV01HeaderMap_(queue);
    var existing = mcCalApprV01QueueIndex_(queue, qh);
    var rows = calendar.getDataRange().getValues();
    var found = [];
    var created = [];
    var updated = [];
    for (var i = 1; i < rows.length; i++) {
      var row = rows[i];
      var status = String(mcCalApprV01Get_(row, ch, 'sourceUpdateStatus') || '').toUpperCase();
      var policy = String(mcCalApprV01Get_(row, ch, 'sourceWritePolicy') || '').toUpperCase();
      var calendarEventId = String(mcCalApprV01Get_(row, ch, 'calendarEventId') || '');
      if (!calendarEventId) continue;
      if (['APPROVAL_REQUIRED','PENDING'].indexOf(status) < 0) continue;
      if (policy !== 'SYNC_TO_SOURCE' && status !== 'APPROVAL_REQUIRED') continue;
      var item = mcCalApprV01BuildQueueRecord_(row, ch, i + 1);
      found.push(mcCalApprV01CompactQueue_(item));
      if (existing[item.calendarEventId]) {
        var qr = existing[item.calendarEventId].rowNumber;
        mcCalApprV01WriteQueueRow_(queue, qh, qr, item, false);
        updated.push(item.calendarEventId);
      } else {
        item.approvalId = 'MCALAPR-' + mcCalApprV01Uuid_();
        mcCalApprV01AppendByHeader_(queue, qh, item);
        created.push(item.calendarEventId);
      }
    }
    r.ok = true;
    r.summary = { found: found.length, created: created.length, updated: updated.length, realApplyExecuted: false, destructiveRepairExecuted: false };
    r.createdCalendarEventIds = created;
    r.updatedCalendarEventIds = updated;
    r.pendingItems = found.slice(0, 10);
    r.message = '캘린더 승인대기 후보 수집 완료. ERP/Mail 원본은 수정하지 않았습니다.';
    r.nextAction = 'calApprList()로 대기 목록을 확인하세요.';
  } catch (err) { mcCalApprV01Catch_(r, err); }
  return mcCalApprV01Print_(r);
}

function mcCalendarApprovalQueueV01ListRecent() {
  var r = mcCalApprV01Base_('mcCalendarApprovalQueueV01ListRecent');
  try {
    var ss = mcCalApprV01OpenMaster_();
    var queue = mcCalApprV01GetSheetOrCreate_(ss, 'MAILCENTER_CalendarApprovalQueue', mcCalApprV01QueueHeaders_());
    var qh = mcCalApprV01HeaderMap_(queue);
    var rows = queue.getDataRange().getValues();
    var list = [];
    for (var i = rows.length - 1; i >= 1 && list.length < 10; i--) {
      list.push(mcCalApprV01CompactQueue_(mcCalApprV01RowToObj_(rows[i], qh, i + 1)));
    }
    r.ok = true;
    r.summary = { displayed: list.length, queueLastRow: queue.getLastRow() };
    r.items = list;
    r.message = '캘린더 승인대기 최근 목록 조회 완료';
    r.nextAction = '승인하려면 calApprApproveDry() 후 calApprApprove()를 실행하세요.';
  } catch (err) { mcCalApprV01Catch_(r, err); }
  return mcCalApprV01Print_(r);
}

function mcCalendarApprovalQueueV01ApproveRecentDryRun() { return mcCalApprV01DecisionRecent_('APPROVE', true); }
function mcCalendarApprovalQueueV01ApproveRecent() { return mcCalApprV01DecisionRecent_('APPROVE', false); }
function mcCalendarApprovalQueueV01RejectRecentDryRun() { return mcCalApprV01DecisionRecent_('REJECT', true); }
function mcCalendarApprovalQueueV01RejectRecent() { return mcCalApprV01DecisionRecent_('REJECT', false); }

function mcCalApprV01DecisionRecent_(decision, dryRun) {
  var action = decision === 'APPROVE' ? (dryRun ? 'mcCalendarApprovalQueueV01ApproveRecentDryRun' : 'mcCalendarApprovalQueueV01ApproveRecent') : (dryRun ? 'mcCalendarApprovalQueueV01RejectRecentDryRun' : 'mcCalendarApprovalQueueV01RejectRecent');
  var r = mcCalApprV01Base_(action);
  try {
    var target = mcCalApprV01FindRecentPending_();
    if (!target) throw new Error('처리할 승인대기 건이 없습니다. 먼저 calApprScan()을 실행하세요.');
    var nextQueueStatus = decision === 'APPROVE' ? 'APPROVED' : 'REJECTED';
    var nextSourceStatus = decision === 'APPROVE' ? 'APPROVED_PENDING_SOURCE_APPLY' : 'REJECTED';
    r.ok = true;
    r.dryRun = !!dryRun;
    r.decision = decision;
    r.target = mcCalApprV01CompactQueue_(target.queueItem);
    r.plan = {
      queueStatus: nextQueueStatus,
      calendarSourceUpdateStatus: nextSourceStatus,
      erpSourceMutated: false,
      googleRealApplyExecuted: false,
      naverAutoApplyExecuted: false
    };
    if (!dryRun) {
      mcCalApprV01ApplyDecision_(target, decision, nextQueueStatus, nextSourceStatus);
      r.saved = true;
    } else {
      r.saved = false;
    }
    r.message = dryRun ? 'DRY RUN: 승인/반려 처리 계획만 반환했습니다.' : '승인대기 건을 처리했습니다. ERP/Mail 원본은 아직 반영하지 않았습니다.';
    r.nextAction = dryRun ? (decision === 'APPROVE' ? '실제 승인 처리하려면 calApprApprove() 실행' : '실제 반려 처리하려면 calApprReject() 실행') : 'calApprList()로 결과를 확인하세요.';
  } catch (err) { mcCalApprV01Catch_(r, err); }
  return mcCalApprV01Print_(r);
}

function mcCalApprV01ApplyDecision_(target, decision, queueStatus, sourceStatus) {
  var ss = mcCalApprV01OpenMaster_();
  var calendar = ss.getSheetByName('MAILCENTER_CalendarEvents');
  var queue = ss.getSheetByName('MAILCENTER_CalendarApprovalQueue');
  var logs = mcCalApprV01GetSheetOrCreate_(ss, 'MAILCENTER_CalendarChangeLogs', mcCalApprV01ChangeLogHeaders_());
  var ch = mcCalApprV01HeaderMap_(calendar);
  var qh = mcCalApprV01HeaderMap_(queue);
  var actor = mcCalApprV01Actor_();
  var now = mcCalApprV01Now_();
  mcCalApprV01SetCell_(queue, qh, target.queueRow, 'approvalStatus', queueStatus);
  mcCalApprV01SetCell_(queue, qh, target.queueRow, 'approvedAt', now);
  mcCalApprV01SetCell_(queue, qh, target.queueRow, 'approvedBy', actor);
  mcCalApprV01SetCell_(queue, qh, target.queueRow, 'decisionReason', decision === 'APPROVE' ? '캘린더 변경 요청 승인. 원본 반영은 다음 단계에서 처리.' : '캘린더 변경 요청 반려. 원본 반영하지 않음.');
  mcCalApprV01SetCell_(queue, qh, target.queueRow, 'updatedAt', now);
  mcCalApprV01SetCell_(queue, qh, target.queueRow, 'updatedBy', actor);
  mcCalApprV01SetCell_(calendar, ch, target.calendarRow, 'sourceUpdateStatus', sourceStatus);
  mcCalApprV01SetCell_(calendar, ch, target.calendarRow, 'statusReason', decision === 'APPROVE' ? '승인 완료: 원본 반영 대기' : '반려: 원본 반영 안 함');
  mcCalApprV01SetCell_(calendar, ch, target.calendarRow, 'updatedAt', now);
  mcCalApprV01SetCell_(calendar, ch, target.calendarRow, 'updatedBy', actor);
  var lh = mcCalApprV01HeaderMap_(logs);
  mcCalApprV01AppendByHeader_(logs, lh, {
    changeLogId: 'MCALCHG-' + mcCalApprV01Uuid_(),
    calendarEventId: target.queueItem.calendarEventId,
    changeType: decision === 'APPROVE' ? 'APPROVAL_APPROVED' : 'APPROVAL_REJECTED',
    changedFields: 'sourceUpdateStatus,statusReason,approvalStatus',
    beforeJson: JSON.stringify({ sourceUpdateStatus: target.queueItem.sourceUpdateStatus, approvalStatus: target.queueItem.approvalStatus }),
    afterJson: JSON.stringify({ sourceUpdateStatus: sourceStatus, approvalStatus: queueStatus }),
    changeReason: decision === 'APPROVE' ? '승인큐 승인 처리' : '승인큐 반려 처리',
    changedAt: now,
    changedBy: actor,
    sourceType: target.queueItem.sourceType,
    sourceWritePolicy: target.queueItem.sourceWritePolicy,
    sourceUpdateStatus: sourceStatus,
    realApplyExecuted: 'N',
    destructiveRepairExecuted: 'N'
  });
}

function mcCalApprV01FindRecentPending_() {
  var ss = mcCalApprV01OpenMaster_();
  var calendar = ss.getSheetByName('MAILCENTER_CalendarEvents');
  var queue = ss.getSheetByName('MAILCENTER_CalendarApprovalQueue');
  if (!calendar || !queue) return null;
  var ch = mcCalApprV01HeaderMap_(calendar);
  var qh = mcCalApprV01HeaderMap_(queue);
  var qRows = queue.getDataRange().getValues();
  for (var i = qRows.length - 1; i >= 1; i--) {
    var item = mcCalApprV01RowToObj_(qRows[i], qh, i + 1);
    var st = String(item.approvalStatus || '').toUpperCase();
    if (st !== 'WAITING' && st !== 'PENDING') continue;
    var calendarRow = mcCalApprV01FindCalendarRow_(calendar, ch, item.calendarEventId);
    if (calendarRow > 1) return { queueRow: i + 1, calendarRow: calendarRow, queueItem: item };
  }
  return null;
}

function mcCalApprV01BuildQueueRecord_(row, ch, rowNumber) {
  var now = mcCalApprV01Now_();
  var title = mcCalApprV01Get_(row, ch, 'title') || mcCalApprV01Get_(row, ch, 'eventTitle') || '';
  return {
    approvalId: '',
    calendarEventId: mcCalApprV01Get_(row, ch, 'calendarEventId') || '',
    sourceType: mcCalApprV01Get_(row, ch, 'sourceType') || '',
    sourceId: mcCalApprV01Get_(row, ch, 'sourceId') || '',
    eventId: mcCalApprV01Get_(row, ch, 'eventId') || mcCalApprV01Get_(row, ch, 'relatedEventId') || '',
    vendorId: mcCalApprV01Get_(row, ch, 'vendorId') || mcCalApprV01Get_(row, ch, 'relatedVendorId') || '',
    customerId: mcCalApprV01Get_(row, ch, 'customerId') || mcCalApprV01Get_(row, ch, 'relatedCustomerId') || '',
    title: title,
    requestedChangeSummary: mcCalApprV01Get_(row, ch, 'changeReason') || mcCalApprV01Get_(row, ch, 'statusReason') || '캘린더 연동 원본 반영 승인 필요',
    sourceWritePolicy: mcCalApprV01Get_(row, ch, 'sourceWritePolicy') || '',
    sourceUpdateStatus: mcCalApprV01Get_(row, ch, 'sourceUpdateStatus') || '',
    approvalStatus: 'WAITING',
    requestedAt: mcCalApprV01Get_(row, ch, 'updatedAt') || now,
    requestedBy: mcCalApprV01Get_(row, ch, 'updatedBy') || mcCalApprV01Actor_(),
    approvedAt: '',
    approvedBy: '',
    decisionReason: '',
    createdAt: now,
    createdBy: mcCalApprV01Actor_(),
    updatedAt: now,
    updatedBy: mcCalApprV01Actor_(),
    calendarRowNumber: rowNumber
  };
}

function mcCalApprV01QueueHeaders_() {
  return ['approvalId','calendarEventId','sourceType','sourceId','eventId','vendorId','customerId','title','requestedChangeSummary','sourceWritePolicy','sourceUpdateStatus','approvalStatus','requestedAt','requestedBy','approvedAt','approvedBy','decisionReason','createdAt','createdBy','updatedAt','updatedBy','calendarRowNumber'];
}
function mcCalApprV01CalendarHeaders_() {
  if (typeof mcCalendarOperationHubV01CalendarHeaders_ === 'function') return mcCalendarOperationHubV01CalendarHeaders_();
  return ['calendarEventId','sourceType','sourceId','eventId','vendorId','customerId','title','eventTitle','startAt','endAt','sourceWritePolicy','sourceUpdateStatus','statusReason','updatedAt','updatedBy','createdAt','createdBy'];
}
function mcCalApprV01ChangeLogHeaders_() {
  if (typeof mcCalendarOperationHubV01ChangeLogHeaders_ === 'function') return mcCalendarOperationHubV01ChangeLogHeaders_();
  return ['changeLogId','calendarEventId','changeType','changedFields','beforeJson','afterJson','changeReason','changedAt','changedBy','sourceType','sourceWritePolicy','sourceUpdateStatus','realApplyExecuted','destructiveRepairExecuted'];
}
function mcCalApprV01OpenMaster_() {
  if (typeof mcCalendarUnifiedManualInputV01OpenMaster_ === 'function') return mcCalendarUnifiedManualInputV01OpenMaster_();
  return SpreadsheetApp.getActiveSpreadsheet();
}
function mcCalApprV01GetSheetOrCreate_(ss, name, headers) {
  if (typeof mcCalendarUnifiedManualInputV01GetSheetOrCreate_ === 'function') return mcCalendarUnifiedManualInputV01GetSheetOrCreate_(ss, name, headers);
  var sh = ss.getSheetByName(name) || ss.insertSheet(name);
  if (sh.getLastRow() < 1) sh.getRange(1,1,1,headers.length).setValues([headers]);
  return sh;
}
function mcCalApprV01HeaderMap_(sheet) {
  var vals = sheet.getRange(1, 1, 1, Math.max(sheet.getLastColumn(), 1)).getValues()[0];
  var m = {};
  vals.forEach(function(h, i){ if (h !== '') m[String(h).trim()] = i; });
  return m;
}
function mcCalApprV01QueueIndex_(sheet, hm) {
  var rows = sheet.getDataRange().getValues();
  var idx = {};
  for (var i = 1; i < rows.length; i++) {
    var id = String(mcCalApprV01Get_(rows[i], hm, 'calendarEventId') || '');
    if (id) idx[id] = { rowNumber: i + 1 };
  }
  return idx;
}
function mcCalApprV01FindCalendarRow_(sheet, hm, calendarEventId) {
  var rows = sheet.getDataRange().getValues();
  for (var i = 1; i < rows.length; i++) {
    if (String(mcCalApprV01Get_(rows[i], hm, 'calendarEventId') || '') === String(calendarEventId)) return i + 1;
  }
  return -1;
}
function mcCalApprV01Get_(row, hm, key) { return hm[key] === undefined ? '' : row[hm[key]]; }
function mcCalApprV01SetCell_(sheet, hm, row, key, value) { if (hm[key] !== undefined) sheet.getRange(row, hm[key] + 1).setValue(value); }
function mcCalApprV01AppendByHeader_(sheet, hm, obj) {
  var width = sheet.getLastColumn();
  var row = new Array(width).fill('');
  Object.keys(obj).forEach(function(k){ if (hm[k] !== undefined) row[hm[k]] = obj[k]; });
  sheet.appendRow(row);
}
function mcCalApprV01WriteQueueRow_(sheet, hm, rowNumber, item, preserveDecision) {
  var skip = preserveDecision ? { approvalStatus:1, approvedAt:1, approvedBy:1, decisionReason:1 } : {};
  Object.keys(item).forEach(function(k){ if (!skip[k] && hm[k] !== undefined && k !== 'approvalId') sheet.getRange(rowNumber, hm[k] + 1).setValue(item[k]); });
}
function mcCalApprV01RowToObj_(row, hm, rowNumber) {
  var o = { rowNumber: rowNumber };
  Object.keys(hm).forEach(function(k){ o[k] = row[hm[k]]; });
  return o;
}
function mcCalApprV01CompactQueue_(o) {
  return {
    rowNumber: o.rowNumber || o.calendarRowNumber || '',
    approvalId: o.approvalId || '',
    calendarEventId: o.calendarEventId || '',
    sourceType: o.sourceType || '',
    eventId: o.eventId || '',
    vendorId: o.vendorId || '',
    customerId: o.customerId || '',
    title: o.title || '',
    sourceWritePolicy: o.sourceWritePolicy || '',
    sourceUpdateStatus: o.sourceUpdateStatus || '',
    approvalStatus: o.approvalStatus || '',
    requestedBy: o.requestedBy || '',
    requestedAt: o.requestedAt || '',
    requestedChangeSummary: o.requestedChangeSummary || ''
  };
}
function mcCalApprV01Actor_() {
  try { return Session.getActiveUser().getEmail() || 'unknown'; } catch (e) { return 'unknown'; }
}
function mcCalApprV01Now_() { return Utilities.formatDate(new Date(), 'Asia/Seoul', 'yyyy-MM-dd HH:mm:ss'); }
function mcCalApprV01Uuid_() { return Utilities.getUuid ? Utilities.getUuid() : String(new Date().getTime()); }
function mcCalApprV01Base_(action) {
  return { ok:false, build:MC_CALENDAR_APPROVAL_QUEUE_V01_BUILD, action:action, generatedAt:mcCalApprV01Now_(), realApplyExecuted:false, destructiveRepairExecuted:false, warnings:[], errors:[] };
}
function mcCalApprV01Catch_(r, err) {
  r.ok = false;
  r.message = String(err && err.message ? err.message : err);
  r.errors.push({ message:r.message, stack:err && err.stack ? err.stack : '' });
  r.nextAction = '오류 메시지와 missingHeaders 또는 승인큐 상태를 확인하세요.';
}
function mcCalApprV01Print_(r) {
  r.endedAt = mcCalApprV01Now_();
  Logger.log('JSON_COMPACT_RESULT: ' + JSON.stringify(r));
  return r;
}
