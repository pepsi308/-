/**
 * PORTAL_CALENDAR_SAFE01B_R10J1_HEADER_MODAL_SAFE_OPEN_20260603
 * READ_ONLY verification. No sheet/provider writes.
 */
function portalCalendarSafe01BR10J1HeaderModalSafeOpenVerify() {
  var build = 'PORTAL_CALENDAR_SAFE01B_R10J1_HEADER_MODAL_SAFE_OPEN_20260603';
  var out = { ok:false, build:build, action:'portalCalendarSafe01BR10J1HeaderModalSafeOpenVerify', safety:'READ_ONLY_RUNTIME_VERIFY_NO_SHEET_PROVIDER_WRITE', checks:{}, warnings:[], fatal:[] };
  function src_(name) { try { return String(HtmlService.createHtmlOutputFromFile(name).getContent() || ''); } catch(e) { return ''; } }
  function gs_(name) { try { return String(DriveApp ? '' : ''); } catch(e) {} return ''; }
  var view = src_('MC_CalendarViewV01');
  var ext = ["infoSource", "expectedFairPeriod", "previousFairHistory", "competitorContactYn", "internalOwnerName", "internalOwnerEmployeeId", "internalDepartmentCode", "internalOrganizerRole", "followUpOwnerName", "externalContactRole", "externalContactEmail", "externalOrganization", "decisionInfluenceLevel", "lastContactAt", "presentationEnabled", "presentationAt", "presentationPlace", "presentationMethod", "presentationMainSpeaker", "presentationSubSpeaker", "presentationMaterialOwner", "presentationConditionOwner", "presentationOperationOwner", "presentationSettlementOwner", "presentationParticipantsJson", "externalPresentationAttendeesJson", "presentationTarget", "presentationMaterials", "presentationRequestItems", "presentationResult", "expectedFairAt", "venueNegotiationStatus", "operationCondition", "promotionCondition", "vendorCondition", "residentBenefitCondition", "managementRequest", "preCouncilRequest", "feelhausProposalCondition", "negotiationRisk", "competitorNames", "competitorCondition", "feelhausStrength", "concernItems", "decisionMaker", "decisionDueAt", "actionType", "actionOwner", "actionDueAt", "actionPriority", "actionDoneYn", "selectionStatus", "selectedAt", "rejectionReason", "holdReason", "reconnectAt", "agreementRequired", "agreementAt", "agreementPlace", "agreementMethod", "agreementAgenda", "agreementCondition", "agreementResult", "agreementDocumentRequired", "agreementSignRequired", "agreementFeelhausAttendeesJson", "agreementExternalAttendeesJson", "agreementStatus", "attachmentMemo", "scheduleWorkType", "scheduleTargetType", "calendarSourceType", "approvalRequired", "approvalId", "approvalStatus", "approvalRequester", "approvalApprover", "approvalApprovedAt", "calendarVisibilityMode", "displayPrivacyMode", "connectionStatus", "connectionTargetType", "personalScheduleType"];
  var checks = out.checks;
  checks.viewR10J1MarkerPresent = view.indexOf(build) >= 0;
  checks.safeEditOpenDoesNotCloseFirst = view.indexOf('function openOperationEditModal()') >= 0 && view.indexOf('수정 화면을 열 수 없습니다') >= 0 && view.indexOf('fhCalendarRestoreDetailModalR10J1') >= 0;
  checks.noEarlyDetailCloseInEditOpen = view.indexOf('function openOperationEditModal(){__fhCalendarEditModalActive=true;fhCalendarHideDetailModalSafe()') < 0;
  checks.preCouncilContactOptionsReady = view.indexOf('입예협 회장') >= 0 && view.indexOf('PRE_COUNCIL_CHAIR') >= 0;
  checks.oldIptdaeuiRemovedFromContactSelect = view.indexOf('<option value="COUNCIL">입대의</option>') < 0;
  checks.presentationExpandedReady = view.indexOf('presentationMainSpeaker') >= 0 && view.indexOf('프레젠테이션 결과') >= 0;
  checks.agreementExpandedReady = view.indexOf('agreementRequired') >= 0 && view.indexOf('협약식 필요 여부') >= 0;
  checks.generalScheduleApprovalReady = view.indexOf('approvalId') >= 0 && view.indexOf('캘린더 표시 방식') >= 0;
  checks.manualPayloadExtReady = ext.every(function(k){ return view.indexOf(k+':manualVal(\'me_'+k+'\')') >= 0 || view.indexOf(k+':manualVal("me_'+k+'")') >= 0; });
  checks.manualHydrationExtReady = view.indexOf('fhCalendarSetManualExtFieldsR10J1(get)') >= 0;
  // Server-side source checks use function text where possible.
  var opText = String(mcCalendarOperationHubV01UpdatableFields_ || '');
  var fields = [];
  try { fields = mcCalendarOperationHubV01UpdatableFields_(); } catch(e) { fields = []; }
  checks.operationUpdatableExtReady = ext.every(function(k){ return fields.indexOf(k) >= 0; });
  var normalized = {};
  try { normalized = mcCalendarUnifiedManualInputV01NormalizePayload_({title:'R10J',startAt:'2026-06-05T10:00',endAt:'2026-06-05T10:30',calendarBusinessType:'SELECTION_PROCESS',presentationMainSpeaker:'이용필',agreementRequired:'필요',approvalId:'APR-R10J'}, 'tester', '2026-06-03 00:00:00', {email:'tester@example.com'}); } catch(e) { out.warnings.push('normalize sample unavailable: '+e.message); normalized = {}; }
  checks.manualNormalizeExtReady = normalized.presentationMainSpeaker === '이용필' && normalized.agreementRequired === '필요' && normalized.approvalId === 'APR-R10J';
  checks.r10iPayloadKept = view.indexOf('fhCalendarSelectionEditPayloadFinalizeR10I') >= 0;
  checks.r10gUpdateBindingKept = fields.indexOf('contactName') >= 0 && fields.indexOf('meetingTimelineJson') >= 0;
  checks.r10cRecordFallbackKept = view.indexOf('recordFallbackStillKept') >= 0 || view.indexOf('res.record||res.event') >= 0 || view.indexOf('res.record || res.event') >= 0;
  Object.keys(checks).forEach(function(k){ if(!checks[k]) out.fatal.push(k); });
  out.extFieldCount = ext.length;
  out.message = out.fatal.length ? 'SAFE-01B R10J1 verification failed. Check fatal items.' : 'SAFE-01B R10J1 header/modal safe-open verification passed.';
  out.ok = out.fatal.length === 0;
  Logger.log('JSON_COMPACT_RESULT: ' + JSON.stringify(out));
  return out;
}
