@echo off
setlocal EnableExtensions
title FEELHAUS DOWNLOAD ERP_FIELD

if not exist "D:\pepsi308\OneDrive\feelhaus_pull\ERP_FIELD" mkdir "D:\pepsi308\OneDrive\feelhaus_pull\ERP_FIELD"
cd /d D:\pepsi308\OneDrive\feelhaus_pull\ERP_FIELD

if exist ".clasp.json" (
  echo [ERP_FIELD] clasp pull
  clasp.cmd pull
) else (
  echo [ERP_FIELD] clasp clone
  clasp.cmd clone 1P97-lV9yuqq90UWzK_qtph3B3gPfbK28XIW8QhkD4PPeVEZJJJvgFbsS
)

pause
