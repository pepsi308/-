/* ===== SaleSchema.js ===== */
/**
 * build: ERP_B06J40_21_24_SALES_DRAFT_SAVE_SCHEMA_FIX_SAFE_UPLOAD
 * module: ERP_FIELD
 * purpose:
 * - Sales sheet/header schema precheck and safe schema fix before opening DRAFT save
 * - B06J40-21 Sales sheet required header check
 * - B06J40-22 missing header safe correction (confirmed function only)
 * - B06J40-23 DRAFT save required input recheck
 * - B06J40-24 final simulation before real DRAFT save
 * safety:
 * - preflight/autoRunSafe/render do not write sheets
 * - only erpB06J40_21_24_confirmedSchemaFix() appends missing headers
 * - no sales row save / no contract / no settlement / no external integration
 */

var FIELD_SALES_SCHEMA_FIX_BUILD = 'ERP_B06J40_21_24_SALES_DRAFT_SAVE_SCHEMA_FIX_SAFE_UPLOAD';

function erpB06J40_21_24_preflight() {
  var result = erpFieldB06J40_21_24_result_('preflight');
  result.checks.requiredFunctions = erpFieldB06J40_21_24_checkRequiredFunctions_();
  result.checks.templateAvailable = erpFieldB06J40_21_24_checkTemplate_();
  result.checks.config = erpFieldB06J40_21_24_readConfig_();
  result.checks.master = erpFieldB06J40_21_24_openMaster_(result.checks.config);
  result.checks.salesSchema = erpFieldB06J40_21_24_checkSalesSchema_(false);
  result.checks.logTarget = erpFieldB06J40_21_24_checkLogTarget_();
  result.checks.draftPrepDependency = erpFieldB06J40_21_24_checkDraftPrepDependency_();
  result.checks.routeSamples = erpFieldB06J40_21_24_checkRouteSamples_();
  result.checks.safety = erpFieldB06J40_21_24_safetyCheck_();
  result.readiness = erpFieldB06J40_21_24_buildReadiness_(result.checks);
  return erpFieldB06J40_21_24_finish_(result, true);
}

function erpB06J40_21_24_autoRunSafe() {
  var result = erpFieldB06J40_21_24_result_('autoRunSafe');
  result.checks.preflight = erpB06J40_21_24_preflight();
  result.checks.screenNoInput = erpFieldB06J40_21_24_buildSalesSchemaFixViewModel_({
    roleCode: 'VENDOR_MANAGER', vendorId: 'VND-20260502202158-505', eventId: 'EVT-20260502202016-197', route: 'sales'
  });
  result.checks.screenSampleReadyShape = erpFieldB06J40_21_24_buildSalesSchemaFixViewModel_({
    roleCode: 'VENDOR_MANAGER', vendorId: 'VND-20260502202158-505', eventId: 'EVT-20260502202016-197', route: 'sales',
    customerId: 'CUS-SAMPLE', productName: '테스트 품목', quantity: '1', unitPrice: '100000', depositAmount: '10000', paymentStructure: 'COMPANY_ALL', paymentMethod: 'CARD', draftCheck: 'Y'
  });
  result.checks.staffSalesShape = erpFieldB06J40_21_24_buildSalesSchemaFixViewModel_({
    roleCode: 'STAFF_SALES', vendorId: 'VND-20260502202158-505', eventId: 'EVT-20260502202016-197', route: 'sales',
    customerId: 'CUS-SAMPLE', productName: '테스트 품목', quantity: '1', unitPrice: '100000', paymentStructure: 'COMPANY_ALL', paymentMethod: 'CARD', draftCheck: 'Y'
  });
  result.checks.viewerBlocked = erpFieldB06J40_21_24_buildSalesSchemaFixViewModel_({ roleCode: 'VIEWER', vendorId: 'VND-20260502202158-505', eventId: 'EVT-20260502202016-197', route: 'sales' });
  result.checks.missingVendorBlocked = erpFieldB06J40_21_24_buildSalesSchemaFixViewModel_({ roleCode: 'VENDOR_MANAGER', vendorId: '', eventId: 'EVT-20260502202016-197', route: 'sales' });

  Object.keys(result.checks).forEach(function (k) {
    var c = result.checks[k];
    var expectedBlock = (k === 'viewerBlocked' || k === 'missingVendorBlocked');
    if (!c) {
      result.fatal.push(k + ': 결과 없음');
      return;
    }
    if (expectedBlock && c.ok !== false) result.fatal.push(k + ': 차단 기대 테스트가 차단되지 않음');
    if (!expectedBlock && c.ok === false && k !== 'screenNoInput' && k !== 'screenSampleReadyShape' && k !== 'staffSalesShape') {
      result.fatal.push(k + ': 정상 기대 테스트 실패');
    }
    if (c.warnings && c.warnings.length) result.warnings = result.warnings.concat(c.warnings.map(function (m) { return k + ': ' + m; }));
  });
  result.readiness = erpFieldB06J40_21_24_buildReadiness_(result.checks);
  return erpFieldB06J40_21_24_finish_(result, true);
}

/**
 * CONFIRMED structural correction.
 * This is the only function in this build that writes to a sheet.
 * It appends missing Sales headers at the end of row 1, preserving existing column order.
 */
function erpB06J40_21_24_confirmedSchemaFix() {
  var lock = null;
  try {
    lock = LockService.getScriptLock();
    lock.waitLock(30000);
  } catch (lockErr) {}

  var result = erpFieldB06J40_21_24_result_('confirmedSchemaFix');
  result.checks.before = erpFieldB06J40_21_24_checkSalesSchema_(false);
  if (!result.checks.before.sheetName) {
    result.fatal.push('Sales 저장 대상 시트를 찾지 못했습니다. ERP_판매관리 / ERP_Sales / Sales 중 1개가 필요합니다.');
    return erpFieldB06J40_21_24_finish_(result, true);
  }

  result.checks.fix = erpFieldB06J40_21_24_applySalesHeaderFix_();
  result.checks.after = erpFieldB06J40_21_24_checkSalesSchema_(false);
  result.readiness = erpFieldB06J40_21_24_buildReadiness_(result.checks);

  try { if (lock) lock.releaseLock(); } catch (releaseErr) {}
  return erpFieldB06J40_21_24_finish_(result, true);
}

function erpFieldB06J40_21_24_renderSalesSchemaFixHtml(ctx) {
  var vm = erpFieldB06J40_21_24_buildSalesSchemaFixViewModel_(ctx || {});
  if (!vm.ok && vm.blocked === true) {
    if (typeof erpFieldB06J40_04_12_renderBlocked_ === 'function') return erpFieldB06J40_04_12_renderBlocked_(vm.context || ctx || {}, vm.fatal || []);
    return HtmlService.createHtmlOutput('<pre>' + erpFieldB06J40_21_24_escape_(JSON.stringify(vm.fatal || [], null, 2)) + '</pre>');
  }
  var t = HtmlService.createTemplateFromFile('P_SaleSchema');
  t.vm = vm;
  return t.evaluate().setTitle('판매 DRAFT 저장 스키마 보정').setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL);
}

function erpFieldB06J40_21_24_buildSalesSchemaFixViewModel_(ctx) {
  ctx = erpFieldB06J40_21_24_normalize_(ctx || {});
  var guard = erpFieldB06J40_21_24_guard_(ctx);
  if (!guard.ok) return { ok: false, blocked: true, fatal: guard.fatal, warnings: [], context: ctx };

  var schema = erpFieldB06J40_21_24_checkSalesSchema_(false);
  var logTarget = erpFieldB06J40_21_24_checkLogTarget_();
  var prep = erpFieldB06J40_21_24_buildDraftPrep_(ctx);
  var validation = erpFieldB06J40_21_24_validateDraftOpenReadiness_(ctx, schema, logTarget, prep);
  var required = erpFieldB06J40_21_24_requiredSalesHeaders_();
  var recommended = erpFieldB06J40_21_24_recommendedSalesHeaders_();
  var webAppUrl = erpFieldB06J40_21_24_webAppUrl_();

  return {
    ok: true,
    build: FIELD_SALES_SCHEMA_FIX_BUILD,
    moduleCode: 'ERP_FIELD',
    checkedAt: new Date().toISOString(),
    fatal: [],
    warnings: validation.warnings || [],
    webAppUrl: webAppUrl,
    context: ctx,
    schema: schema,
    logTarget: logTarget,
    prep: prep,
    validation: validation,
    requiredHeaders: required,
    recommendedHeaders: recommended,
    missingRequiredHeaders: schema.missingHeaders || [],
    missingRecommendedHeaders: schema.recommendedMissingHeaders || [],
    page: {
      badge: 'B06J40-21_24 SAFE : SCHEMA FIX PREP',
      title: '판매 DRAFT 저장 스키마 보정',
      subtitle: 'Sales 시트 필수 헤더를 점검하고 DRAFT 저장 개방 직전 시뮬레이션을 수행합니다.',
      roleName: erpFieldB06J40_21_24_roleName_(ctx.roleCode)
    },
    readiness: {
      salesSchemaReady: schema.ok === true,
      logReady: logTarget.ok === true,
      draftInputReady: validation.inputReady === true,
      readyForConfirmedHeaderFix: (schema.missingHeaders || []).length > 0,
      readyForDraftSaveOpen: schema.ok === true && validation.inputReady === true,
      blockingIssues: validation.errors || []
    },
    safety: {
      schemaPrecheckOnly: true,
      headerFixRequiresConfirmedFunction: true,
      renderDoesNotWrite: true,
      autoRunDoesNotWrite: true,
      noSalesRowSave: true,
      noContractCreate: true,
      noSettlementExecution: true,
      noExternalIntegration: true,
      vendorIndependentDbBlocked: true,
      vendorAsBranchUserGroup: true,
      headerMapBased: true,
      columnIndexFixed: false
    },
    blockedActions: [
      { label: '판매 DRAFT 저장 차단', reason: 'B06J40-21~24는 헤더 보정/최종 시뮬레이션 단계입니다. 실제 저장은 B06J40-25 이후 개방합니다.' },
      { label: '계약 생성 차단', reason: 'B06J41 계약/SIGN 연결 단계에서 처리합니다.' },
      { label: '정산 반영 차단', reason: '정산 정책/승인 전 실행 금지입니다.' },
      { label: '외부연동 차단', reason: 'PG/메일/캘린더/폼/카페 연동 실행 없음입니다.' }
    ],
    urls: erpFieldB06J40_21_24_urls_(webAppUrl, ctx)
  };
}

function erpFieldB06J40_21_24_buildDraftPrep_(ctx) {
  try {
    if (typeof erpFieldB06J40_16_20_buildSalesDraftPrepViewModel_ === 'function') {
      return erpFieldB06J40_16_20_buildSalesDraftPrepViewModel_(ctx);
    }
  } catch (err) {
    return { ok: false, fatal: [err && err.message ? err.message : String(err)], warnings: [] };
  }
  return { ok: false, fatal: ['B06J40-16~20 DraftPrep 함수 없음'], warnings: [] };
}

function erpFieldB06J40_21_24_validateDraftOpenReadiness_(ctx, schema, logTarget, prep) {
  var errors = [];
  var warnings = [];
  if (!schema || !schema.sheetName) errors.push('판매 저장 대상 시트 없음');
  if (schema && schema.missingHeaders && schema.missingHeaders.length) errors.push('Sales 필수 헤더 누락: ' + schema.missingHeaders.join(', '));
  if (!logTarget || logTarget.ok !== true) warnings.push('ERP_CoreLog 로그 대상 미확인: 저장 개방 전 확인 필요');
  if (!prep || prep.ok !== true) errors.push('B06J40-16~20 최종검증 ViewModel 준비 실패');
  if (prep && prep.finalValidation && prep.finalValidation.errors && prep.finalValidation.errors.length) {
    errors = errors.concat(prep.finalValidation.errors.map(function (m) { return '입력검증: ' + m; }));
  }
  if (schema && schema.recommendedMissingHeaders && schema.recommendedMissingHeaders.length) {
    warnings.push('권장 헤더 미보정: ' + schema.recommendedMissingHeaders.join(', '));
  }
  return {
    ok: errors.length === 0,
    inputReady: errors.length === 0,
    errors: errors,
    warnings: warnings,
    draftSaveStillBlocked: true,
    nextStep: errors.length ? '헤더/입력 보정 후 재검증' : 'B06J40-25~30 실제 DRAFT 저장 개방 가능 후보'
  };
}

function erpFieldB06J40_21_24_checkSalesSchema_(applyFix) {
  var candidates = ['ERP_판매관리', 'ERP_Sales', 'Sales'];
  var requiredHeaders = erpFieldB06J40_21_24_requiredSalesHeaders_();
  var recommendedHeaders = erpFieldB06J40_21_24_recommendedSalesHeaders_();
  try {
    var config = erpFieldB06J40_21_24_readConfig_();
    var master = erpFieldB06J40_21_24_openMaster_(config);
    if (!master.ok) return { ok: false, fatal: master.fatal || ['MASTER 연결 실패'], warnings: [], candidates: candidates, requiredHeaders: requiredHeaders, recommendedHeaders: recommendedHeaders };
    for (var i = 0; i < candidates.length; i++) {
      var sh = master.spreadsheet.getSheetByName(candidates[i]);
      if (!sh) continue;
      var lastCol = Math.max(1, sh.getLastColumn());
      var headers = sh.getRange(1, 1, 1, lastCol).getValues()[0];
      var hm = erpFieldB06J40_21_24_headerMap_(headers);
      var missing = requiredHeaders.filter(function (h) { return hm[h] == null; });
      var recommendedMissing = recommendedHeaders.filter(function (h) { return hm[h] == null; });
      var fixApplied = [];
      if (applyFix && missing.length) {
        var start = sh.getLastColumn() + 1;
        sh.getRange(1, start, 1, missing.length).setValues([missing]);
        fixApplied = missing.slice();
        lastCol = sh.getLastColumn();
        headers = sh.getRange(1, 1, 1, lastCol).getValues()[0];
        hm = erpFieldB06J40_21_24_headerMap_(headers);
        missing = requiredHeaders.filter(function (h) { return hm[h] == null; });
      }
      return {
        ok: missing.length === 0,
        fatal: missing.map(function (h) { return candidates[i] + ' 필수 헤더 누락: ' + h; }),
        warnings: recommendedMissing.map(function (h) { return candidates[i] + ' 권장 헤더 미확인: ' + h; }),
        sheetName: candidates[i],
        exists: true,
        lastRow: sh.getLastRow(),
        lastCol: sh.getLastColumn(),
        headerMapBased: true,
        columnIndexFixed: false,
        requiredHeaders: requiredHeaders,
        missingHeaders: missing,
        recommendedHeaders: recommendedHeaders,
        recommendedMissingHeaders: recommendedMissing,
        fixAppliedHeaders: fixApplied,
        fixMode: applyFix ? 'CONFIRMED_APPEND_MISSING_REQUIRED_HEADERS' : 'DRY_RUN_NO_WRITE'
      };
    }
    return { ok: false, fatal: ['판매 저장 대상 시트 없음: ERP_판매관리 / ERP_Sales / Sales 중 1개 필요'], warnings: [], candidates: candidates, requiredHeaders: requiredHeaders, recommendedHeaders: recommendedHeaders };
  } catch (err) {
    return { ok: false, fatal: [err && err.message ? err.message : String(err)], warnings: [], candidates: candidates, requiredHeaders: requiredHeaders, recommendedHeaders: recommendedHeaders };
  }
}

function erpFieldB06J40_21_24_applySalesHeaderFix_() {
  return erpFieldB06J40_21_24_checkSalesSchema_(true);
}

function erpFieldB06J40_21_24_requiredSalesHeaders_() {
  return [
    'saleId', 'eventId', 'vendorId', 'customerId',
    'status', 'statusReason', 'createdAt', 'createdBy', 'updatedAt', 'updatedBy',
    'productName', 'quantity', 'unitPrice', 'totalAmount',
    'depositAmount', 'balanceAmount', 'paymentStructure', 'paymentMethod'
  ];
}

function erpFieldB06J40_21_24_recommendedSalesHeaders_() {
  return [
    'customerName', 'phone', 'phoneNormalized', 'dong', 'ho', 'apartmentName', 'memberType',
    'productId', 'discountAmount', 'voucherAmount', 'benefitAmount', 'paidAmount', 'unpaidAmount',
    'cardPaymentIds', 'cardMatchStatus', 'pgPaymentRefId', 'bankDepositRefId',
    'contractId', 'documentId', 'signStatus', 'pdfStatus', 'driveArchiveStatus',
    'installId', 'installDueDate', 'installStatus', 'asId',
    'settlementId', 'settlementStatus', 'settlementDirection', 'commissionPolicyId', 'boothFee',
    'originalSaleId', 'correctionSaleId', 'cancelRequestId', 'cancellationReason',
    'customerRefundAmount', 'vendorRecoveryAmount', 'vendorAdditionalPaymentAmount', 'feelhausBurdenAmount',
    'recoveryMode', 'additionalPaymentReason', 'approvalId', 'approvalStatus', 'logId', 'memo'
  ];
}

function erpFieldB06J40_21_24_checkRequiredFunctions_() {
  var required = [
    'doGet',
    'erpFieldB06J40_21_24_renderSalesSchemaFixHtml',
    'erpFieldB06J40_21_24_buildSalesSchemaFixViewModel_',
    'erpFieldB06J40_21_24_checkSalesSchema_',
    'erpFieldB06J40_21_24_applySalesHeaderFix_'
  ];
  var missing = required.filter(function (name) { return typeof this[name] !== 'function'; }, this);
  return { ok: missing.length === 0, fatal: missing.map(function (m) { return '필수 함수 누락: ' + m; }), warnings: [], required: required, missing: missing };
}

function erpFieldB06J40_21_24_checkTemplate_() {
  try {
    HtmlService.createTemplateFromFile('P_SaleSchema');
    return { ok: true, fatal: [], warnings: [], template: 'P_SaleSchema' };
  } catch (err) {
    return { ok: false, fatal: ['FieldSalesSchemaPage.html 템플릿 확인 실패: ' + (err && err.message ? err.message : String(err))], warnings: [] };
  }
}

function erpFieldB06J40_21_24_checkDraftPrepDependency_() {
  var ok = typeof erpFieldB06J40_16_20_buildSalesDraftPrepViewModel_ === 'function';
  return { ok: ok, fatal: ok ? [] : ['B06J40-16~20 DraftPrep ViewModel 함수 없음'], warnings: [], functionName: 'erpFieldB06J40_16_20_buildSalesDraftPrepViewModel_' };
}

function erpFieldB06J40_21_24_checkRouteSamples_() {
  var samples = [
    { label: 'salesVendorManager', ctx: { roleCode: 'VENDOR_MANAGER', vendorId: 'VND-20260502202158-505', eventId: 'EVT-20260502202016-197', route: 'sales' }, expectOk: true },
    { label: 'salesStaffSales', ctx: { roleCode: 'STAFF_SALES', vendorId: 'VND-20260502202158-505', eventId: 'EVT-20260502202016-197', route: 'sales' }, expectOk: true },
    { label: 'viewerBlocked', ctx: { roleCode: 'VIEWER', vendorId: 'VND-20260502202158-505', eventId: 'EVT-20260502202016-197', route: 'sales' }, expectOk: false },
    { label: 'missingVendorBlocked', ctx: { roleCode: 'VENDOR_MANAGER', vendorId: '', eventId: 'EVT-20260502202016-197', route: 'sales' }, expectOk: false }
  ];
  var fatal = [];
  var rows = samples.map(function (s) {
    var vm = erpFieldB06J40_21_24_buildSalesSchemaFixViewModel_(s.ctx);
    var pass = s.expectOk ? vm.ok === true : vm.ok === false;
    if (!pass) fatal.push(s.label + ': route sample expectation mismatch');
    return { label: s.label, expectOk: s.expectOk, actualOk: vm.ok === true, pass: pass, fatal: vm.fatal || [] };
  });
  return { ok: fatal.length === 0, fatal: fatal, warnings: [], samples: rows };
}

function erpFieldB06J40_21_24_checkLogTarget_() {
  try {
    var config = erpFieldB06J40_21_24_readConfig_();
    var master = erpFieldB06J40_21_24_openMaster_(config);
    if (!master.ok) return { ok: false, fatal: master.fatal || ['MASTER 연결 실패'], warnings: [] };
    var sh = master.spreadsheet.getSheetByName('ERP_CoreLog');
    return { ok: !!sh, fatal: sh ? [] : ['ERP_CoreLog 시트 없음'], warnings: [], sheetName: 'ERP_CoreLog', exists: !!sh };
  } catch (err) {
    return { ok: false, fatal: [err && err.message ? err.message : String(err)], warnings: [] };
  }
}

function erpFieldB06J40_21_24_safetyCheck_() {
  return {
    ok: true,
    fatal: [],
    warnings: [],
    safety: {
      preflightNoWrite: true,
      autoRunNoWrite: true,
      renderNoWrite: true,
      confirmedFunctionOnlyForHeaderAppend: true,
      noSalesRowAppend: true,
      noCustomerUpdate: true,
      noContractCreate: true,
      noSettlementExecution: true,
      noExternalIntegration: true,
      vendorIndependentDbBlocked: true,
      vendorAsBranchUserGroup: true
    }
  };
}

function erpFieldB06J40_21_24_buildReadiness_(checks) {
  var fatal = [];
  Object.keys(checks || {}).forEach(function (k) {
    var c = checks[k];
    if (c && c.fatal && c.fatal.length) fatal = fatal.concat(c.fatal.map(function (m) { return k + ': ' + m; }));
  });
  var schema = checks && checks.salesSchema ? checks.salesSchema : null;
  return {
    ok: fatal.length === 0,
    readyForDraftSaveOpen: false,
    readyForConfirmedHeaderFix: !!(schema && schema.missingHeaders && schema.missingHeaders.length),
    fatal: fatal,
    note: 'B06J40-21~24는 스키마 보정/최종 시뮬레이션 단계입니다. 실제 DRAFT 저장은 다음 빌드에서만 개방합니다.'
  };
}

function erpFieldB06J40_21_24_readConfig_() {
  try {
    var setupId = '17VMSpgSZCvIrUlgcw8yCNcnl8WQWo2IcRf5tDCcuJGM';
    var ss = SpreadsheetApp.openById(setupId);
    var sh = ss.getSheetByName('SystemConfig');
    if (!sh) return { ok: false, fatal: ['SystemConfig 시트 없음'], warnings: [], setupDbId: setupId };
    var values = sh.getDataRange().getValues();
    if (values.length < 2) return { ok: false, fatal: ['SystemConfig 데이터 없음'], warnings: [], setupDbId: setupId };
    var header = values[0].map(function (h) { return String(h || '').trim(); });
    var keyIdx = header.indexOf('configKey');
    var valIdx = header.indexOf('configValue');
    var warnings = [];
    if (keyIdx < 0 || valIdx < 0) {
      keyIdx = 0;
      valIdx = 1;
      warnings.push('SystemConfig 헤더명이 표준과 다름: configKey/configValue 확인 필요');
    }
    var map = {};
    for (var r = 1; r < values.length; r++) {
      var k = String(values[r][keyIdx] || '').trim();
      if (k) map[k] = values[r][valIdx];
    }
    return { ok: true, fatal: [], warnings: warnings, setupDbId: setupId, setupDbName: ss.getName(), configSheetName: 'SystemConfig', configCount: Object.keys(map).length, configMap: map };
  } catch (err) {
    return { ok: false, fatal: [err && err.message ? err.message : String(err)], warnings: [] };
  }
}

function erpFieldB06J40_21_24_openMaster_(config) {
  try {
    if (!config || !config.ok) return { ok: false, fatal: ['SystemConfig 읽기 실패'], warnings: [] };
    var map = config.configMap || {};
    var keys = ['FEELHAUS_DB_MASTER_ID', 'DB_MASTER_ID', 'SPREADSHEET_ID', 'CUSTOMER_DB_SPREADSHEET_ID'];
    var masterId = '';
    var usedKey = '';
    for (var i = 0; i < keys.length; i++) {
      if (map[keys[i]]) { masterId = String(map[keys[i]]).trim(); usedKey = keys[i]; break; }
    }
    if (!masterId) return { ok: false, fatal: ['MASTER ID 없음'], warnings: [], usedKey: usedKey };
    var ss = SpreadsheetApp.openById(masterId);
    return { ok: true, fatal: [], warnings: [], usedKey: usedKey, masterId: masterId, masterName: ss.getName(), spreadsheet: ss };
  } catch (err) {
    return { ok: false, fatal: [err && err.message ? err.message : String(err)], warnings: [] };
  }
}

function erpFieldB06J40_21_24_headerMap_(headers) {
  var map = {};
  (headers || []).forEach(function (h, i) {
    var key = String(h || '').trim();
    if (key && map[key] == null) map[key] = i;
  });
  return map;
}

function erpFieldB06J40_21_24_normalize_(ctx) {
  if (typeof erpFieldB06J40_16_20_normalize_ === 'function') return erpFieldB06J40_16_20_normalize_(ctx || {});
  function s(v) { return String(v == null ? '' : v).trim(); }
  return {
    roleCode: s(ctx.roleCode || 'VIEWER'), vendorId: s(ctx.vendorId), eventId: s(ctx.eventId), route: s(ctx.route || 'sales'),
    customerId: s(ctx.customerId), productName: s(ctx.productName), productId: s(ctx.productId), quantity: s(ctx.quantity || '1'), unitPrice: s(ctx.unitPrice || '0'),
    totalAmount: s(ctx.totalAmount || '0'), depositAmount: s(ctx.depositAmount || '0'), discountAmount: s(ctx.discountAmount || '0'), voucherAmount: s(ctx.voucherAmount || '0'),
    benefitAmount: s(ctx.benefitAmount || '0'), paymentStructure: s(ctx.paymentStructure), paymentMethod: s(ctx.paymentMethod), installDueDate: s(ctx.installDueDate),
    cardPaymentIds: s(ctx.cardPaymentIds), draftCheck: s(ctx.draftCheck), keyword: s(ctx.keyword), userEmail: s(ctx.userEmail), scopeType: 'VENDOR_BRANCH_USER_GROUP', hqFullAccess: false
  };
}

function erpFieldB06J40_21_24_guard_(ctx) {
  var fatal = [];
  var allowedRoles = { VENDOR_OWNER: true, VENDOR_MANAGER: true, STAFF_SALES: true };
  if (!ctx.vendorId) fatal.push('vendorId 누락');
  if (!ctx.eventId) fatal.push('eventId 누락');
  if (!allowedRoles[ctx.roleCode]) fatal.push('판매 스키마 점검 차단: roleCode=' + ctx.roleCode + ' 권한 없음');
  if (ctx.route !== 'sales') fatal.push('판매 스키마 점검 차단: route=' + ctx.route + ' 허용 안 됨');
  return { ok: fatal.length === 0, fatal: fatal };
}

function erpFieldB06J40_21_24_webAppUrl_() {
  try { return ScriptApp.getService().getUrl() || ''; } catch (err) { return ''; }
}

function erpFieldB06J40_21_24_urls_(base, ctx) {
  base = base || '';
  var common = '?roleCode=' + encodeURIComponent(ctx.roleCode) + '&vendorId=' + encodeURIComponent(ctx.vendorId) + '&eventId=' + encodeURIComponent(ctx.eventId);
  return {
    sales: base + common + '&route=sales',
    customerLookup: base + common + '&route=customerLookup',
    salesWithSample: base + common + '&route=sales&customerId=CUS-SAMPLE&productName=' + encodeURIComponent('테스트 품목') + '&quantity=1&unitPrice=100000&paymentStructure=COMPANY_ALL&paymentMethod=CARD&draftCheck=Y'
  };
}

function erpFieldB06J40_21_24_roleName_(roleCode) {
  var map = { VENDOR_OWNER: '업체대표', VENDOR_MANAGER: '업체관리자', STAFF_SALES: '영업직원', STAFF_INSTALL: '설치담당', STAFF_AS: 'A/S담당', VIEWER: '조회전용' };
  return map[roleCode] || roleCode || '미지정';
}

function erpFieldB06J40_21_24_result_(label) {
  return { ok: true, build: FIELD_SALES_SCHEMA_FIX_BUILD, moduleCode: 'ERP_FIELD', label: label, checkedAt: new Date().toISOString(), fatal: [], warnings: [], checks: {} };
}

function erpFieldB06J40_21_24_finish_(result, logOutput) {
  Object.keys(result.checks || {}).forEach(function (k) {
    var c = result.checks[k];
    if (c && c.fatal && c.fatal.length) result.fatal = result.fatal.concat(c.fatal.map(function (m) { return k + ': ' + m; }));
    if (c && c.warnings && c.warnings.length) result.warnings = result.warnings.concat(c.warnings.map(function (m) { return k + ': ' + m; }));
  });
  result.ok = result.fatal.length === 0;
  if (logOutput) {
    Logger.log('======================================================');
    Logger.log(JSON.stringify(result, null, 2));
    Logger.log('======================================================');
  }
  return result;
}

function erpFieldB06J40_21_24_escape_(v) {
  return String(v == null ? '' : v).replace(/[&<>\"]/g, function (s) {
    return ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' })[s];
  });
}


/* ===== SalePrep.js ===== */
/**
 * build: ERP_B06J40_16_20_SALES_DRAFT_FINAL_PREP_SAFE_UPLOAD
 * module: ERP_FIELD
 * purpose:
 * - Final validation and simulation before opening DRAFT sales save
 * - saleId simulation, target sheet/header check, duplicate guard simulation, log structure check
 * - no sheet write / no save / no update / no delete / no settlement / no external integration
 */

var FIELD_SALES_DRAFT_PREP_BUILD = 'ERP_B06J40_16_20_SALES_DRAFT_FINAL_PREP_SAFE_UPLOAD';

function erpB06J40_16_20_preflight() {
  var result = erpFieldB06J40_16_20_result_('preflight');
  result.checks.requiredFunctions = erpFieldB06J40_16_20_checkRequiredFunctions_();
  result.checks.templateAvailable = erpFieldB06J40_16_20_checkTemplate_();
  result.checks.targetSheetPolicy = erpFieldB06J40_16_20_checkSalesTargetSheet_();
  result.checks.customerDependency = erpFieldB06J40_16_20_checkCustomerDependency_();
  result.checks.routeSamples = erpFieldB06J40_16_20_checkRouteSamples_();
  result.checks.safety = erpFieldB06J40_16_20_safetyCheck_();
  result.readiness = erpFieldB06J40_16_20_buildReadiness_(result.checks);
  return erpFieldB06J40_16_20_finish_(result, true);
}

function erpB06J40_16_20_autoRunSafe() {
  var result = erpFieldB06J40_16_20_result_('autoRunSafe');
  result.checks.preflight = erpB06J40_16_20_preflight();
  result.checks.blankSales = erpFieldB06J40_16_20_buildSalesDraftPrepViewModel_({
    roleCode: 'VENDOR_MANAGER', vendorId: 'VND-20260502202158-505', eventId: 'EVT-20260502202016-197', route: 'sales'
  });
  result.checks.sampleReadyShape = erpFieldB06J40_16_20_buildSalesDraftPrepViewModel_({
    roleCode: 'VENDOR_MANAGER', vendorId: 'VND-20260502202158-505', eventId: 'EVT-20260502202016-197', route: 'sales',
    customerId: 'CUS-SAMPLE', productName: '테스트 품목', quantity: '1', unitPrice: '100000', depositAmount: '10000', paymentStructure: 'COMPANY_ALL', paymentMethod: 'CARD', draftCheck: 'Y'
  });
  result.checks.staffSalesShape = erpFieldB06J40_16_20_buildSalesDraftPrepViewModel_({
    roleCode: 'STAFF_SALES', vendorId: 'VND-20260502202158-505', eventId: 'EVT-20260502202016-197', route: 'sales',
    customerId: 'CUS-SAMPLE', productName: '테스트 품목', quantity: '1', unitPrice: '100000', paymentStructure: 'COMPANY_ALL', paymentMethod: 'CARD', draftCheck: 'Y'
  });
  result.checks.viewerBlocked = erpFieldB06J40_16_20_buildSalesDraftPrepViewModel_({
    roleCode: 'VIEWER', vendorId: 'VND-20260502202158-505', eventId: 'EVT-20260502202016-197', route: 'sales'
  });
  result.checks.missingVendorBlocked = erpFieldB06J40_16_20_buildSalesDraftPrepViewModel_({
    roleCode: 'VENDOR_MANAGER', vendorId: '', eventId: 'EVT-20260502202016-197', route: 'sales'
  });

  Object.keys(result.checks).forEach(function (k) {
    var c = result.checks[k];
    var expectedBlock = (k === 'viewerBlocked' || k === 'missingVendorBlocked');
    if (!c) {
      result.fatal.push(k + ': 결과 없음');
      return;
    }
    if (expectedBlock && c.ok !== false) result.fatal.push(k + ': 차단 기대 테스트가 차단되지 않음');
    if (!expectedBlock && c.ok === false && k !== 'blankSales' && k !== 'sampleReadyShape' && k !== 'staffSalesShape') {
      result.fatal.push(k + ': 정상 기대 테스트 실패');
    }
    if (c.warnings && c.warnings.length) result.warnings = result.warnings.concat(c.warnings.map(function (m) { return k + ': ' + m; }));
  });
  result.readiness = erpFieldB06J40_16_20_buildReadiness_(result.checks);
  return erpFieldB06J40_16_20_finish_(result, true);
}

function erpFieldB06J40_16_20_renderSalesDraftPrepHtml(ctx) {
  var vm = erpFieldB06J40_16_20_buildSalesDraftPrepViewModel_(ctx || {});
  if (!vm.ok && vm.blocked === true) {
    if (typeof erpFieldB06J40_04_12_renderBlocked_ === 'function') return erpFieldB06J40_04_12_renderBlocked_(vm.context || ctx || {}, vm.fatal || []);
    return HtmlService.createHtmlOutput('<pre>' + erpFieldB06J40_16_20_escape_(JSON.stringify(vm.fatal || [], null, 2)) + '</pre>');
  }
  var t = HtmlService.createTemplateFromFile('P_SalePrep');
  t.vm = vm;
  return t.evaluate().setTitle('판매 DRAFT 저장 최종검증').setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL);
}

function erpFieldB06J40_16_20_buildSalesDraftPrepViewModel_(ctx) {
  ctx = erpFieldB06J40_16_20_normalize_(ctx || {});
  var guard = erpFieldB06J40_16_20_guard_(ctx);
  if (!guard.ok) return { ok: false, blocked: true, fatal: guard.fatal, warnings: [], context: ctx };

  var bind = null;
  try {
    if (typeof erpFieldB06J40_13_15_buildSalesInputBindViewModel_ === 'function') bind = erpFieldB06J40_13_15_buildSalesInputBindViewModel_(ctx);
  } catch (err) {
    bind = { ok: false, fatal: [err && err.message ? err.message : String(err)], warnings: [] };
  }
  if (!bind) bind = { ok: false, fatal: ['B06J40-13~15 입력 연결 ViewModel 함수 없음'], warnings: [] };

  var salesTarget = erpFieldB06J40_16_20_checkSalesTargetSheet_();
  var logTarget = erpFieldB06J40_16_20_checkLogTarget_();
  var saleId = erpFieldB06J40_16_20_generateSaleId_();
  var duplicate = erpFieldB06J40_16_20_checkDuplicateSaleId_(saleId, salesTarget);
  var finalValidation = erpFieldB06J40_16_20_validateDraftReadiness_(ctx, bind, salesTarget, duplicate, logTarget);
  var draftRow = erpFieldB06J40_16_20_buildDraftRowPreview_(ctx, bind, saleId);
  var savePlan = erpFieldB06J40_16_20_buildSavePlan_(salesTarget, logTarget, draftRow, finalValidation);
  var url = erpFieldB06J40_16_20_webAppUrl_();

  return {
    ok: true,
    build: FIELD_SALES_DRAFT_PREP_BUILD,
    moduleCode: 'ERP_FIELD',
    checkedAt: new Date().toISOString(),
    fatal: [],
    warnings: finalValidation.warnings || [],
    webAppUrl: url,
    context: ctx,
    bind: bind,
    vendor: bind.vendor || { name: '', id: ctx.vendorId },
    event: bind.event || { name: '', id: ctx.eventId },
    selectedCustomer: bind.selectedCustomer || {},
    calculated: bind.calculated || {},
    salesTarget: salesTarget,
    logTarget: logTarget,
    saleIdSimulation: { saleId: saleId, duplicateCheck: duplicate },
    finalValidation: finalValidation,
    draftRowPreview: draftRow,
    savePlan: savePlan,
    page: {
      badge: 'B06J40-16_20 SAFE : DRAFT FINAL PREP',
      title: '판매 DRAFT 저장 최종검증',
      subtitle: '실제 저장을 열기 전 필수값, saleId, 저장 대상 시트, 중복, 로그 구조를 시뮬레이션합니다.',
      roleName: erpFieldB06J40_16_20_roleName_(ctx.roleCode)
    },
    safety: {
      finalPrecheckOnly: true,
      saveSimulationOnly: true,
      generatedSaleIdPreviewOnly: true,
      noSheetWrite: true,
      noAppendOperation: true,
      noCellUpdateOperation: true,
      noSaveExecution: true,
      draftSaveStillBlocked: true,
      noUpdateExecution: true,
      noDeleteExecution: true,
      settlementExecutionBlocked: true,
      externalIntegrationBlocked: true,
      vendorIndependentDbBlocked: true,
      vendorAsBranchUserGroup: true,
      headerMapBased: true,
      columnIndexFixed: false
    },
    blockedActions: [
      { label: '실제 DRAFT 저장 차단', reason: 'B06J40-16~20은 최종검증/시뮬레이션 단계입니다. 저장은 B06J40-21 이후 별도 개방합니다.' },
      { label: '계약 생성 차단', reason: 'B06J41 계약/SIGN 연결 단계에서 처리합니다.' },
      { label: '정산 반영 차단', reason: '정산 정책/승인 전 실행 금지입니다.' },
      { label: '외부연동 차단', reason: 'PG/메일/캘린더/폼/카페 연동 실행 없음입니다.' }
    ],
    urls: erpFieldB06J40_16_20_urls_(url, ctx)
  };
}

function erpFieldB06J40_16_20_normalize_(ctx) {
  if (typeof erpFieldB06J40_13_15_normalize_ === 'function') return erpFieldB06J40_13_15_normalize_(ctx || {});
  function s(v) { return String(v == null ? '' : v).trim(); }
  return { roleCode: s(ctx.roleCode || 'VIEWER'), vendorId: s(ctx.vendorId), eventId: s(ctx.eventId), route: s(ctx.route || 'sales'), customerId: s(ctx.customerId), productName: s(ctx.productName), productId: s(ctx.productId), quantity: s(ctx.quantity || '1'), unitPrice: s(ctx.unitPrice || '0'), totalAmount: s(ctx.totalAmount || '0'), depositAmount: s(ctx.depositAmount || '0'), discountAmount: s(ctx.discountAmount || '0'), voucherAmount: s(ctx.voucherAmount || '0'), benefitAmount: s(ctx.benefitAmount || '0'), paymentStructure: s(ctx.paymentStructure), paymentMethod: s(ctx.paymentMethod), installDueDate: s(ctx.installDueDate), cardPaymentIds: s(ctx.cardPaymentIds), draftCheck: s(ctx.draftCheck), keyword: s(ctx.keyword), userEmail: s(ctx.userEmail), scopeType: 'VENDOR_BRANCH_USER_GROUP', hqFullAccess: false };
}

function erpFieldB06J40_16_20_guard_(ctx) {
  var fatal = [];
  var allowedRoles = { VENDOR_OWNER: true, VENDOR_MANAGER: true, STAFF_SALES: true };
  if (!ctx.vendorId) fatal.push('vendorId 누락');
  if (!ctx.eventId) fatal.push('eventId 누락');
  if (!allowedRoles[ctx.roleCode]) fatal.push('판매 DRAFT 최종검증 차단: roleCode=' + ctx.roleCode + ' 권한 없음');
  if (ctx.route !== 'sales') fatal.push('판매 DRAFT 최종검증 차단: route=' + ctx.route + ' 허용 안 됨');
  return { ok: fatal.length === 0, fatal: fatal };
}

function erpFieldB06J40_16_20_validateDraftReadiness_(ctx, bind, salesTarget, duplicate, logTarget) {
  var errors = [];
  var warnings = [];
  if (!bind || bind.ok !== true) errors.push('입력 연결 ViewModel 생성 실패');
  if (bind && bind.selectedCustomer) {
    if (!bind.selectedCustomer.selected) errors.push('customerId 미선택 또는 고객 스냅샷 없음');
    if (bind.selectedCustomer.selected && !bind.selectedCustomer.scopeMatch) errors.push('선택 고객 vendorId/eventId 범위 불일치');
    if (bind.selectedCustomer.selected && !bind.selectedCustomer.phoneNormalized) warnings.push('고객 전화번호 정규화 값 없음');
  } else {
    errors.push('선택 고객 스냅샷 없음');
  }
  if (bind && bind.validation && bind.validation.errors && bind.validation.errors.length) errors = errors.concat(bind.validation.errors);
  var amount = bind && bind.calculated ? Number(bind.calculated.totalAmount || 0) : 0;
  if (!(amount > 0)) errors.push('총금액 0원: DRAFT 저장 전 금액 입력 필요');
  if (!ctx.paymentMethod) errors.push('결제수단 미선택');
  if (!salesTarget || salesTarget.ok !== true) errors.push('판매 저장 대상 시트/헤더 준비 미완료');
  if (duplicate && duplicate.duplicate === true) errors.push('saleId 중복 시뮬레이션 감지');
  if (!logTarget || logTarget.ok !== true) warnings.push('로그 대상 시트 미확인: 저장 개방 전 ERP_CoreLog 또는 ERP_SalesLog 점검 필요');
  return {
    ok: errors.length === 0,
    readyForDraftSaveOpen: errors.length === 0,
    saveStillBlocked: true,
    errors: erpFieldB06J40_16_20_unique_(errors),
    warnings: erpFieldB06J40_16_20_unique_(warnings),
    nextStep: errors.length === 0 ? 'B06J40-21 이후 실제 DRAFT 저장 개방 가능' : '표시된 차단 사유 보완 후 재검증 필요'
  };
}

function erpFieldB06J40_16_20_checkSalesTargetSheet_() {
  var requiredHeaders = ['saleId', 'eventId', 'vendorId', 'customerId', 'status', 'statusReason', 'createdAt', 'createdBy', 'updatedAt', 'updatedBy'];
  var recommendedHeaders = ['contractId', 'installId', 'asId', 'settlementId', 'documentId', 'paymentStructure', 'paymentMethod', 'totalAmount', 'depositAmount', 'balanceAmount', 'discountAmount', 'voucherAmount', 'benefitAmount', 'cardPaymentIds', 'settlementStatus', 'signStatus', 'installStatus', 'originalSaleId', 'correctionSaleId'];
  var candidates = ['ERP_판매관리', 'ERP_Sales', 'Sales'];
  try {
    var master = erpFieldB06J40_16_20_getMaster_();
    if (!master.ok) return { ok: false, fatal: master.fatal || ['MASTER 연결 실패'], warnings: [], candidates: candidates, requiredHeaders: requiredHeaders, recommendedHeaders: recommendedHeaders };
    for (var i = 0; i < candidates.length; i++) {
      var sh = master.spreadsheet.getSheetByName(candidates[i]);
      if (!sh) continue;
      var values = sh.getDataRange().getValues();
      var hm = values.length ? erpFieldB06J40_16_20_headerMap_(values[0]) : {};
      var missing = requiredHeaders.filter(function (h) { return hm[h] == null; });
      var recommendedMissing = recommendedHeaders.filter(function (h) { return hm[h] == null; });
      return {
        ok: missing.length === 0,
        fatal: missing.map(function (h) { return candidates[i] + ' 필수 헤더 누락: ' + h; }),
        warnings: recommendedMissing.map(function (h) { return candidates[i] + ' 권장 헤더 미확인: ' + h; }),
        sheetName: candidates[i], exists: true, lastRow: sh.getLastRow(), lastCol: sh.getLastColumn(), headerMapBased: true, columnIndexFixed: false,
        requiredHeaders: requiredHeaders, missingHeaders: missing, recommendedHeaders: recommendedHeaders, recommendedMissingHeaders: recommendedMissing
      };
    }
    return { ok: false, fatal: ['판매 저장 대상 시트 없음: ERP_판매관리 / ERP_Sales / Sales 중 1개 필요'], warnings: [], candidates: candidates, requiredHeaders: requiredHeaders, recommendedHeaders: recommendedHeaders };
  } catch (err) {
    return { ok: false, fatal: [err && err.message ? err.message : String(err)], warnings: [], candidates: candidates, requiredHeaders: requiredHeaders, recommendedHeaders: recommendedHeaders };
  }
}

function erpFieldB06J40_16_20_checkLogTarget_() {
  var candidates = ['ERP_SalesLog', 'ERP_CoreLog'];
  try {
    var master = erpFieldB06J40_16_20_getMaster_();
    if (!master.ok) return { ok: false, fatal: master.fatal || ['MASTER 연결 실패'], warnings: [] };
    for (var i = 0; i < candidates.length; i++) {
      var sh = master.spreadsheet.getSheetByName(candidates[i]);
      if (sh) return { ok: true, fatal: [], warnings: [], sheetName: candidates[i], exists: true, lastRow: sh.getLastRow(), lastCol: sh.getLastColumn() };
    }
    return { ok: false, fatal: ['로그 대상 시트 없음: ERP_SalesLog 또는 ERP_CoreLog 필요'], warnings: [], candidates: candidates };
  } catch (err) {
    return { ok: false, fatal: [err && err.message ? err.message : String(err)], warnings: [] };
  }
}

function erpFieldB06J40_16_20_checkDuplicateSaleId_(saleId, target) {
  if (!target || target.ok !== true || !target.sheetName) return { ok: true, duplicate: false, checked: false, warnings: ['판매 대상 시트 미준비로 중복 실검사는 보류'], saleId: saleId };
  try {
    var master = erpFieldB06J40_16_20_getMaster_();
    if (!master.ok) return { ok: false, duplicate: false, checked: false, fatal: master.fatal || [] };
    var sh = master.spreadsheet.getSheetByName(target.sheetName);
    var values = sh.getDataRange().getValues();
    if (!values.length) return { ok: true, duplicate: false, checked: true, saleId: saleId };
    var hm = erpFieldB06J40_16_20_headerMap_(values[0]);
    var idx = hm.saleId;
    if (idx == null) return { ok: true, duplicate: false, checked: false, warnings: ['saleId 헤더 없음으로 중복 실검사 보류'], saleId: saleId };
    for (var r = 1; r < values.length; r++) if (String(values[r][idx] || '') === String(saleId)) return { ok: false, duplicate: true, checked: true, saleId: saleId };
    return { ok: true, duplicate: false, checked: true, saleId: saleId };
  } catch (err) {
    return { ok: false, duplicate: false, checked: false, fatal: [err && err.message ? err.message : String(err)], saleId: saleId };
  }
}

function erpFieldB06J40_16_20_buildDraftRowPreview_(ctx, bind, saleId) {
  var customer = bind && bind.selectedCustomer ? bind.selectedCustomer : {};
  var calc = bind && bind.calculated ? bind.calculated : {};
  return {
    saleId: saleId,
    eventId: ctx.eventId,
    vendorId: ctx.vendorId,
    customerId: ctx.customerId,
    customerName: customer.name || '',
    phoneMasked: customer.phoneMasked || '',
    productId: ctx.productId || '',
    productName: ctx.productName || '',
    quantity: calc.quantity || ctx.quantity || '',
    unitPrice: calc.unitPrice || ctx.unitPrice || '',
    totalAmount: calc.totalAmount || 0,
    depositAmount: calc.depositAmount || 0,
    balanceAmount: calc.balanceAmount || 0,
    discountAmount: calc.discountAmount || 0,
    voucherAmount: calc.voucherAmount || 0,
    benefitAmount: calc.benefitAmount || 0,
    paymentStructure: ctx.paymentStructure,
    paymentMethod: ctx.paymentMethod,
    status: 'DRAFT',
    statusReason: 'FIELD_DRAFT_SAVE_PREPARED',
    contractId: '',
    documentId: '',
    installId: '',
    asId: '',
    settlementId: '',
    createdAt: new Date().toISOString(),
    createdBy: ctx.userEmail || 'FIELD_USER'
  };
}

function erpFieldB06J40_16_20_buildSavePlan_(salesTarget, logTarget, rowPreview, validation) {
  return {
    readyForDraftSaveOpen: validation.readyForDraftSaveOpen === true,
    targetSheet: salesTarget && salesTarget.sheetName ? salesTarget.sheetName : '(미확정)',
    logSheet: logTarget && logTarget.sheetName ? logTarget.sheetName : '(미확정)',
    rowPreview: rowPreview,
    writeExecution: 'BLOCKED_IN_THIS_BUILD',
    nextOpenBuild: 'ERP_B06J40_21_25_SALES_DRAFT_SAVE_SAFE_UPLOAD',
    writeOrder: ['필수값 검사', '형식 검사', '권한 검사', '중복 검사', '상태전이 검사', 'DRAFT 저장', '로그 기록']
  };
}

function erpFieldB06J40_16_20_generateSaleId_() {
  var d = new Date();
  function pad(n) { return n < 10 ? '0' + n : String(n); }
  var stamp = d.getFullYear() + pad(d.getMonth() + 1) + pad(d.getDate()) + pad(d.getHours()) + pad(d.getMinutes()) + pad(d.getSeconds());
  var rand = String(Math.floor(Math.random() * 900) + 100);
  return 'SALE-' + stamp + '-' + rand;
}

function erpFieldB06J40_16_20_checkRequiredFunctions_() {
  var required = ['doGet', 'erpFieldB06J40_16_20_renderSalesDraftPrepHtml', 'erpFieldB06J40_13_15_buildSalesInputBindViewModel_'];
  var missing = [];
  required.forEach(function (name) { if (typeof this[name] !== 'function') missing.push(name); });
  return { ok: missing.length === 0, fatal: missing.length ? ['필수 함수 누락: ' + missing.join(', ')] : [], warnings: [], required: required, missing: missing };
}

function erpFieldB06J40_16_20_checkTemplate_() {
  try {
    HtmlService.createTemplateFromFile('P_SalePrep');
    return { ok: true, fatal: [], warnings: [], template: 'P_SalePrep' };
  } catch (err) {
    return { ok: false, fatal: [err && err.message ? err.message : String(err)], warnings: [], template: 'P_SalePrep' };
  }
}

function erpFieldB06J40_16_20_checkCustomerDependency_() {
  try {
    if (typeof erpFieldB06J40_13_15_checkCustomerSheet_ === 'function') return erpFieldB06J40_13_15_checkCustomerSheet_();
    return { ok: false, fatal: ['고객 시트 점검 함수 누락'], warnings: [] };
  } catch (err) {
    return { ok: false, fatal: [err && err.message ? err.message : String(err)], warnings: [] };
  }
}

function erpFieldB06J40_16_20_checkRouteSamples_() {
  var ok = typeof erpFieldB06J40_16_20_buildSalesDraftPrepViewModel_ === 'function';
  var a = ok ? erpFieldB06J40_16_20_buildSalesDraftPrepViewModel_({ roleCode: 'VENDOR_MANAGER', vendorId: 'VND-SAMPLE', eventId: 'EVT-SAMPLE', route: 'sales' }) : null;
  var b = ok ? erpFieldB06J40_16_20_buildSalesDraftPrepViewModel_({ roleCode: 'VIEWER', vendorId: 'VND-SAMPLE', eventId: 'EVT-SAMPLE', route: 'sales' }) : null;
  return { ok: !!(a && a.ok === true && b && b.ok === false), fatal: (a && a.ok === true && b && b.ok === false) ? [] : ['route sample guard 실패'], warnings: [], vendorManagerOk: a && a.ok, viewerBlocked: b && b.ok === false };
}

function erpFieldB06J40_16_20_safetyCheck_() {
  return { ok: true, fatal: [], warnings: [], noSheetWrite: true, noAppendOperation: true, noCellUpdateOperation: true, noSaveExecution: true, noUpdateExecution: true, noDeleteExecution: true, settlementExecutionBlocked: true, externalIntegrationBlocked: true, vendorIndependentDbBlocked: true, vendorAsBranchUserGroup: true };
}

function erpFieldB06J40_16_20_buildReadiness_(checks) {
  var blocking = [];
  Object.keys(checks || {}).forEach(function (k) {
    var c = checks[k];
    if (c && c.ok === false) blocking.push(k + ': ' + ((c.fatal || []).join(' / ') || '미통과'));
  });
  return { readyForDraftSaveOpen: blocking.length === 0, blockingIssues: blocking, note: blocking.length ? '차단 항목 보완 전 실제 DRAFT 저장 개방 금지' : '다음 빌드에서 실제 DRAFT 저장 개방 가능' };
}

function erpFieldB06J40_16_20_urls_(url, ctx) {
  var base = url || '';
  var common = '?roleCode=' + encodeURIComponent(ctx.roleCode) + '&vendorId=' + encodeURIComponent(ctx.vendorId) + '&eventId=' + encodeURIComponent(ctx.eventId);
  return {
    customerLookup: base + common + '&route=customerLookup&keyword=' + encodeURIComponent(ctx.keyword || ''),
    salesBase: base + common + '&route=sales',
    salesWithCustomer: base + common + '&route=sales&customerId=' + encodeURIComponent(ctx.customerId || ''),
    salesFinalCheck: base + common + '&route=sales&customerId=' + encodeURIComponent(ctx.customerId || '') + '&draftCheck=Y'
  };
}

function erpFieldB06J40_16_20_getMaster_() {
  if (typeof erpFieldB06J40_13_15_getMaster_ === 'function') return erpFieldB06J40_13_15_getMaster_();
  return { ok: false, fatal: ['MASTER 연결 함수 누락'], warnings: [] };
}

function erpFieldB06J40_16_20_headerMap_(headers) {
  if (typeof erpFieldB06J40_13_15_headerMap_ === 'function') return erpFieldB06J40_13_15_headerMap_(headers || []);
  var m = {};
  (headers || []).forEach(function (h, i) { if (String(h || '').trim()) m[String(h).trim()] = i; });
  return m;
}

function erpFieldB06J40_16_20_webAppUrl_() {
  if (typeof erpFieldB06J40_13_15_webAppUrl_ === 'function') return erpFieldB06J40_13_15_webAppUrl_();
  return 'https://script.google.com/macros/s/AKfycbzoFVrXuPH3cPHDdm5O-1K6mF0UAuVjeOu26ZFvIZlD_px_wAXJKwzApqfbgMAfTwJQ0g/exec';
}

function erpFieldB06J40_16_20_roleName_(roleCode) {
  if (typeof erpFieldB06J40_13_15_roleName_ === 'function') return erpFieldB06J40_13_15_roleName_(roleCode);
  var map = { VENDOR_OWNER: '업체대표', VENDOR_MANAGER: '업체관리자', STAFF_SALES: '영업직원', STAFF_INSTALL: '설치담당', STAFF_AS: 'A/S담당', VIEWER: '조회전용' };
  return map[roleCode] || roleCode || '';
}

function erpFieldB06J40_16_20_unique_(arr) {
  var seen = {}, out = [];
  (arr || []).forEach(function (v) { var k = String(v); if (!seen[k]) { seen[k] = true; out.push(k); } });
  return out;
}

function erpFieldB06J40_16_20_escape_(v) {
  return String(v == null ? '' : v).replace(/[&<>"]/g, function (s) { return ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' })[s]; });
}

function erpFieldB06J40_16_20_money_(v) {
  if (typeof erpFieldB06J40_13_15_money_ === 'function') return erpFieldB06J40_13_15_money_(v || 0);
  var n = Number(v || 0);
  return String(Math.round(n)).replace(/\B(?=(\d{3})+(?!\d))/g, ',');
}

function erpFieldB06J40_16_20_result_(label) {
  return { ok: true, build: FIELD_SALES_DRAFT_PREP_BUILD, moduleCode: 'ERP_FIELD', label: label, checkedAt: new Date().toISOString(), fatal: [], warnings: [], checks: {} };
}

function erpFieldB06J40_16_20_finish_(result, logOutput) {
  Object.keys(result.checks || {}).forEach(function (k) {
    var c = result.checks[k];
    if (c && c.fatal && c.fatal.length && k !== 'targetSheetPolicy') result.fatal = result.fatal.concat(c.fatal.map(function (m) { return k + ': ' + m; }));
    if (c && c.warnings && c.warnings.length) result.warnings = result.warnings.concat(c.warnings.map(function (m) { return k + ': ' + m; }));
  });
  result.ok = result.fatal.length === 0;
  if (logOutput) {
    Logger.log('======================================================');
    Logger.log(JSON.stringify(result, null, 2));
    Logger.log('======================================================');
  }
  return result;
}


/* ===== SaleCheck.js ===== */
/**
 * build: ERP_B06J40_04_12_SALES_DRAFT_FULL_PRECHECK_SAFE_UPLOAD
 * module: ERP_FIELD
 * purpose:
 * - Full sales DRAFT requirement matrix and precheck before opening any save action
 * - Covers customer -> sale -> contract/SIGN -> install/A/S -> settlement -> cancel/correction -> KPI/log
 * safety:
 * - no sheet write / no row-append operation / no cell-update operation / no save / no update / no delete / no settlement / no external integration
 */

var FIELD_SALES_FULL_PRECHECK_BUILD = 'ERP_B06J40_04_12_SALES_DRAFT_FULL_PRECHECK_SAFE_UPLOAD';
var FIELD_SALES_FULL_TARGET_SHEET_CANDIDATES = ['ERP_판매관리', 'ERP_판매전표', 'Sales', 'ERP_Sales'];
var FIELD_SALES_FULL_REQUIRED_CORE_HEADERS = [
  'saleId', 'eventId', 'vendorId', 'customerId', 'status', 'statusReason',
  'createdAt', 'createdBy', 'updatedAt', 'updatedBy'
];
var FIELD_SALES_FULL_RECOMMENDED_HEADERS = [
  'contractId', 'installId', 'asId', 'settlementId', 'documentId',
  'originalSaleId', 'correctionSaleId', 'cancelRequestId',
  'paymentStructure', 'paymentMethod', 'totalAmount', 'depositAmount', 'balanceAmount', 'paidAmount', 'unpaidAmount',
  'discountAmount', 'voucherAmount', 'benefitAmount',
  'cardMatchStatus', 'cardPaymentIds', 'productId', 'productPolicyId', 'settlementPolicyId', 'commissionPolicyId',
  'settlementDirection', 'boothFee', 'signStatus', 'installStatus', 'settlementStatus',
  'customerRefundAmount', 'vendorRecoveryAmount', 'vendorAdditionalPaymentAmount', 'feelhausBurdenAmount',
  'approvalId', 'approvalStatus', 'externalSyncStatus'
];
var FIELD_SALES_FULL_REQUIRED_SHEETS = [
  { sheetName: 'ERP_고객관리', key: 'customer', requiredHeaders: ['customerId', 'eventId', 'vendorId', 'name', 'phone', 'status'] },
  { sheetName: 'ERP_업체관리', key: 'vendor', requiredHeaders: ['vendorId', 'status'] },
  { sheetName: 'ERP_행사관리', key: 'event', requiredHeaders: ['eventId', 'status'] }
];
var FIELD_SALES_FULL_REFERENCE_SHEETS = [
  { sheetName: 'ERP_계약관리', key: 'contract', requiredHeaders: ['contractId', 'saleId', 'customerId', 'eventId', 'vendorId', 'status'] },
  { sheetName: 'ERP_설치관리', key: 'install', requiredHeaders: ['installId', 'saleId', 'customerId', 'eventId', 'vendorId', 'status'] },
  { sheetName: 'ERP_AS관리', key: 'as', requiredHeaders: ['asId', 'saleId', 'customerId', 'eventId', 'vendorId', 'status'] },
  { sheetName: 'ERP_정산관리', key: 'settlement', requiredHeaders: ['settlementId', 'saleId', 'eventId', 'vendorId', 'status'] },
  { sheetName: 'ERP_상품권관리', key: 'voucher', requiredHeaders: ['eventId', 'vendorId', 'status'] },
  { sheetName: 'ERP_혜택관리', key: 'benefit', requiredHeaders: ['eventId', 'vendorId', 'status'] },
  { sheetName: 'ERP_CoreLog', key: 'log', requiredHeaders: ['createdAt', 'createdBy'] }
];

function erpB06J40_04_12_preflight() {
  var result = erpFieldB06J40_04_12_result_('preflight');
  result.checks.staticSafety = erpFieldB06J40_04_12_checkStaticSafety_();
  result.checks.requiredFunctions = erpFieldB06J40_04_12_checkRequiredFunctions_();
  result.checks.config = erpFieldB06J40_04_12_checkConfig_();
  result.checks.master = erpFieldB06J40_04_12_checkMaster_();
  result.checks.coreSheets = erpFieldB06J40_04_12_checkSheets_(FIELD_SALES_FULL_REQUIRED_SHEETS, true);
  result.checks.salesTarget = erpFieldB06J40_04_12_checkSalesTarget_();
  result.checks.referenceSheets = erpFieldB06J40_04_12_checkSheets_(FIELD_SALES_FULL_REFERENCE_SHEETS, false);
  result.checks.requirementMatrix = erpFieldB06J40_04_12_buildRequirementMatrix_();
  result.checks.validationSamples = erpFieldB06J40_04_12_checkValidationSamples_();
  result.checks.routeSamples = erpFieldB06J40_04_12_checkRouteSamples_();
  result.checks.noWriteGuard = erpFieldB06J40_04_12_checkNoWriteGuard_();
  result.readiness = erpFieldB06J40_04_12_buildReadiness_(result.checks);
  return erpFieldB06J40_04_12_finish_(result, true);
}

function erpB06J40_04_12_autoRunSafe() {
  var result = erpFieldB06J40_04_12_result_('autoRunSafe');
  result.checks.preflight = erpB06J40_04_12_preflight();
  result.checks.blankFullPrecheck = erpFieldB06J40_04_12_buildFullPrecheckViewModel_({
    roleCode: 'VENDOR_MANAGER', vendorId: 'VND-20260502202158-505', eventId: 'EVT-20260502202016-197', route: 'sales', userEmail: 'manager@example.com'
  });
  result.checks.validSimulation = erpFieldB06J40_04_12_buildFullPrecheckViewModel_({
    roleCode: 'VENDOR_MANAGER', vendorId: 'VND-20260502202158-505', eventId: 'EVT-20260502202016-197', route: 'sales', userEmail: 'manager@example.com',
    customerId: 'CUS-SAMPLE', productId: 'PROD-SAMPLE', productName: '테스트 품목', quantity: '1', unitPrice: '100000',
    paymentStructure: 'COMPANY_ALL', paymentMethod: 'CARD', depositAmount: '10000', balanceAmount: '90000', draftCheck: 'Y'
  });
  result.checks.missingVendorBlocked = erpFieldB06J40_04_12_buildFullPrecheckViewModel_({
    roleCode: 'VENDOR_MANAGER', vendorId: '', eventId: 'EVT-20260502202016-197', route: 'sales', draftCheck: 'Y'
  });
  result.checks.viewerBlocked = erpFieldB06J40_04_12_buildFullPrecheckViewModel_({
    roleCode: 'VIEWER', vendorId: 'VND-20260502202158-505', eventId: 'EVT-20260502202016-197', route: 'sales', draftCheck: 'Y'
  });

  Object.keys(result.checks).forEach(function (k) {
    var c = result.checks[k];
    var expectedBlock = /Blocked$/.test(k) || k === 'viewerBlocked';
    if (!c) result.ok = false;
    if (expectedBlock) {
      if (c.ok !== false) {
        result.ok = false;
        result.fatal.push(k + ': 차단 기대 테스트가 차단되지 않음');
      }
    } else if (c && c.ok === false && k !== 'preflight') {
      result.ok = false;
      result.fatal.push(k + ': 정상 기대 테스트 실패');
    }
    if (c && c.fatal && c.fatal.length && !expectedBlock) {
      result.fatal = result.fatal.concat(c.fatal.map(function (m) { return k + ': ' + m; }));
    }
    if (c && c.warnings && c.warnings.length) {
      result.warnings = result.warnings.concat(c.warnings.map(function (m) { return k + ': ' + m; }));
    }
  });
  result.readiness = result.checks.preflight ? result.checks.preflight.readiness : { readyForDraftSave: false };
  return erpFieldB06J40_04_12_finish_(result, true);
}

function erpFieldB06J40_04_12_renderSalesFullPrecheckHtml(ctx) {
  var vm = erpFieldB06J40_04_12_buildFullPrecheckViewModel_(ctx || {});
  if (!vm.ok && vm.blocked === true) return erpFieldB06J40_04_12_renderBlocked_(vm.context, vm.fatal);
  var t = HtmlService.createTemplateFromFile('P_SaleCheck');
  t.vm = vm;
  return t.evaluate().setTitle('판매등록 전체 프리체크').setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL);
}

function erpFieldB06J40_04_12_buildFullPrecheckViewModel_(ctx) {
  ctx = erpFieldB06J40_04_12_normalize_(ctx || {});
  var guard = erpFieldB06J40_04_12_guard_(ctx);
  if (!guard.ok) return { ok: false, blocked: true, fatal: guard.fatal, warnings: [], context: ctx };

  var vendor = erpFieldB06J40_04_12_lookupEntitySafe_('ERP_업체관리', 'vendorId', ctx.vendorId, ['vendorName', 'name', '업체명']);
  var event = erpFieldB06J40_04_12_lookupEntitySafe_('ERP_행사관리', 'eventId', ctx.eventId, ['eventName', 'name', '행사명']);
  var preflight = erpB06J40_04_12_preflight();
  var validation = erpFieldB06J40_04_12_validateDraft_(ctx, preflight);
  var calc = erpFieldB06J40_04_12_calculateAmounts_(ctx);
  var saleIdPreview = erpFieldB06J40_04_12_makeSaleIdPreview_(ctx);

  return {
    ok: true,
    build: FIELD_SALES_FULL_PRECHECK_BUILD,
    moduleCode: 'ERP_FIELD',
    checkedAt: new Date().toISOString(),
    fatal: [],
    warnings: [],
    context: ctx,
    vendor: vendor,
    event: event,
    preflight: preflight,
    validation: validation,
    calculated: calc,
    saleIdPreview: saleIdPreview,
    matrix: preflight.checks.requirementMatrix,
    page: {
      badge: 'B06J40-04_12 SAFE : SALES FULL PRECHECK',
      title: '판매등록 전체 기획 프리체크',
      subtitle: '고객·판매·계약·SIGN·설치·A/S·정산·취소정산·KPI까지 누락 없이 점검합니다.',
      roleName: erpFieldB06J40_04_12_roleName_(ctx.roleCode),
      webAppUrl: erpFieldB06J40_04_12_webAppUrl_()
    },
    safety: {
      precheckOnly: true,
      noSheetWrite: true,
      noAppendOperation: true,
      noCellUpdateOperation: true,
      noSaveExecution: true,
      draftSaveBlocked: true,
      noUpdateExecution: true,
      noDeleteExecution: true,
      settlementExecutionBlocked: true,
      externalIntegrationBlocked: true,
      vendorIndependentDbBlocked: true,
      vendorAsBranchUserGroup: true,
      headerMapBased: true,
      columnIndexFixed: false
    },
    blockedActions: [
      { label: 'DRAFT 실제 저장', reason: '프리체크 단계. B06J40-13 이후 별도 개방' },
      { label: '계약 생성', reason: 'B06J41 계약/SIGN 연결 단계에서 처리' },
      { label: '설치/A/S 생성', reason: 'B06J42 이후 별도 연결' },
      { label: '정산 반영', reason: '승인/정산 정책 확인 전 실행 금지' },
      { label: '외부연동', reason: 'PG/메일/캘린더/폼/카페 연동은 참조키만 선반영' }
    ]
  };
}

function erpFieldB06J40_04_12_buildRequirementMatrix_() {
  var axes = [
    ['고객 연결', ['customerId','vendorId','eventId','customerName','phone','phoneNormalized','apartmentName','dong','ho','address','memberType','qrSource','selectedCustomerSnapshot'], 'SAVE_BLOCKER'],
    ['판매 원전표', ['saleId','originalSaleId','correctionSaleId','status','statusReason','createdAt','createdBy','updatedAt','updatedBy'], 'SAVE_BLOCKER'],
    ['상품/품목', ['productId','productPolicyId','multiLineItems','itemName','quantity','unitPrice','lineAmount','optionItems','partialCancelReady'], 'SAVE_BLOCKER'],
    ['금액/잔금', ['totalAmount','depositAmount','balanceAmount','paidAmount','unpaidAmount','discountAmount','voucherAmount','benefitAmount','currencyFormat','autoBalanceCalc'], 'SAVE_BLOCKER'],
    ['결제구조', ['paymentStructure','COMPANY_ALL','MIXED','VENDOR_DIRECT','CARD','CASH','BANK','VOUCHER','multiPayment'], 'SAVE_BLOCKER'],
    ['카드매칭', ['cardPaymentIds','cardMatchStatus','cardDataSelect','multiCardMatch','unmatch','cardCancel','pgPaymentRefId','cardFee','pgFee'], 'STRUCTURE_REQUIRED'],
    ['혜택/상품권/발전기금', ['benefitId','voucherId','fundId','visitBenefit','memberBenefit','settlementVoucher','nonSettlementVoucher','depositRefund','reserveReturn'], 'STRUCTURE_REQUIRED'],
    ['계약/SIGN', ['contractId','documentId','contractCreateReady','delegationDoc','consentDoc','signStatus','pdfStatus','driveArchiveStatus'], 'STRUCTURE_REQUIRED'],
    ['설치/A/S', ['installId','installDueDate','installStatus','asId','asCost','scheduleRefId','staffAssignRefId'], 'STRUCTURE_REQUIRED'],
    ['정산/회계', ['settlementId','settlementStatus','settlementDirection','PAY_TO_VENDOR','COLLECT_FROM_VENDOR','OFFSET','NO_ACTION','boothFee','commissionPolicyId','depositBalance','receivable','monthCloseLock'], 'STRUCTURE_REQUIRED'],
    ['취소정산/정정', ['cancelRequestId','cancellationReason','customerRefundAmount','vendorRecoveryAmount','vendorAdditionalPaymentAmount','feelhausBurdenAmount','recoveryMode','additionalPaymentReason','correctionVoucher'], 'STRUCTURE_REQUIRED'],
    ['권한/로그/운영', ['roleCode','approvalRequired','approvalId','approvalStatus','downloadBlocked','sensitiveChangeBlocked','salesLog','onboardingApproved','vendorOperationApproved','recentSalesList','vendorDashboardSummary','testDataPolicy','externalSyncStatus'], 'SAVE_BLOCKER']
  ];
  return {
    ok: true,
    fatal: [],
    warnings: [],
    totalAxes: axes.length,
    axes: axes.map(function (a, idx) {
      return { order: idx + 1, axis: a[0], requirementLevel: a[2], fields: a[1], status: 'MATRIX_LOCKED', note: 'B06J40 저장 전 기준표에 고정됨' };
    })
  };
}

function erpFieldB06J40_04_12_validateDraft_(ctx, preflight) {
  var errors = [];
  var warnings = [];
  var submitted = String(ctx.draftCheck || '').toUpperCase() === 'Y';
  if (!submitted) warnings.push('아직 점검 실행 전입니다. 값을 입력한 뒤 전체 프리체크를 실행하세요.');
  if (!ctx.vendorId) errors.push('vendorId 누락');
  if (!ctx.eventId) errors.push('eventId 누락');
  if (!ctx.customerId) errors.push('customerId 미선택');
  if (!ctx.productName && !ctx.productId) errors.push('품목 또는 productId 미입력');
  var qty = erpFieldB06J40_04_12_toNumber_(ctx.quantity);
  var unit = erpFieldB06J40_04_12_toNumber_(ctx.unitPrice);
  var total = erpFieldB06J40_04_12_toNumber_(ctx.totalAmount);
  var deposit = erpFieldB06J40_04_12_toNumber_(ctx.depositAmount);
  var balance = erpFieldB06J40_04_12_toNumber_(ctx.balanceAmount);
  if (!(qty > 0)) errors.push('수량은 1 이상이어야 함');
  if (!(unit >= 0)) errors.push('단가는 0 이상 숫자여야 함');
  if (total < 0) errors.push('총금액은 0 이상 숫자여야 함');
  if (deposit < 0) errors.push('계약금은 0 이상 숫자여야 함');
  if (balance < 0) errors.push('잔금은 0 이상 숫자여야 함');
  if (!ctx.paymentStructure) errors.push('결제구조 미선택');
  if (ctx.paymentStructure && ['COMPANY_ALL','MIXED','VENDOR_DIRECT'].indexOf(ctx.paymentStructure) === -1) errors.push('결제구조 허용값 아님');
  if (!ctx.paymentMethod) warnings.push('결제수단 미선택: CARD/CASH/BANK/VOUCHER/MIXED 중 선택 필요');
  if (preflight && preflight.readiness && preflight.readiness.readyForDraftSave !== true) warnings.push('구조 준비 미완료: readinessBlockingIssues 확인 필요');
  return {
    ok: errors.length === 0,
    submitted: submitted,
    errors: errors,
    warnings: warnings,
    actualSaveBlocked: true,
    saveWouldBeAllowedIfOpened: submitted && errors.length === 0 && preflight && preflight.readiness && preflight.readiness.readyForDraftSave === true,
    message: errors.length ? 'DRAFT 저장 전 보완 필요' : (submitted ? '입력값 점검 통과. 단, 실제 저장은 아직 차단' : '점검 대기')
  };
}

function erpFieldB06J40_04_12_checkConfig_() {
  var out = { ok: true, fatal: [], warnings: [], setupDbId: '17VMSpgSZCvIrUlgcw8yCNcnl8WQWo2IcRf5tDCcuJGM', configSheetName: 'SystemConfig', configCount: 0, masterId: '' };
  try {
    var map = erpFieldB06J40_04_12_readSystemConfig_();
    out.configCount = Object.keys(map).length;
    out.masterId = map.FEELHAUS_DB_MASTER_ID || map.DB_MASTER_ID || map.SPREADSHEET_ID || map.CUSTOMER_DB_SPREADSHEET_ID || '';
    if (!out.masterId) out.fatal.push('FEELHAUS_DB_MASTER_ID/DB_MASTER_ID/SPREADSHEET_ID 없음');
    out.ok = out.fatal.length === 0;
    return out;
  } catch (err) {
    out.ok = false;
    out.fatal.push(err && err.message ? err.message : String(err));
    return out;
  }
}

function erpFieldB06J40_04_12_checkMaster_() {
  var master = erpFieldB06J40_04_12_openMaster_();
  if (!master.ok) return { ok: false, fatal: [master.message], warnings: [] };
  return { ok: true, fatal: [], warnings: [], masterId: master.masterId, masterSpreadsheetName: master.ss.getName() };
}

function erpFieldB06J40_04_12_checkSheets_(specs, required) {
  var out = { ok: true, fatal: [], warnings: [], required: required, sheets: [] };
  var master = erpFieldB06J40_04_12_openMaster_();
  if (!master.ok) return { ok: false, fatal: [master.message], warnings: [], sheets: [] };
  specs.forEach(function (spec) {
    var sh = master.ss.getSheetByName(spec.sheetName);
    var item = { sheetName: spec.sheetName, exists: !!sh, lastRow: 0, lastCol: 0, requiredHeaders: spec.requiredHeaders, missingHeaders: [], headerMapBased: true, columnIndexFixed: false };
    if (sh) {
      item.lastRow = sh.getLastRow();
      item.lastCol = sh.getLastColumn();
      var headers = item.lastCol > 0 ? sh.getRange(1, 1, 1, item.lastCol).getValues()[0].map(function (h) { return String(h || '').trim(); }) : [];
      var map = {};
      headers.forEach(function (h) { if (h) map[h] = true; });
      item.missingHeaders = spec.requiredHeaders.filter(function (h) { return !map[h]; });
    } else {
      item.missingHeaders = spec.requiredHeaders.slice();
    }
    if (!item.exists || item.missingHeaders.length) {
      if (required) {
        out.ok = false;
        out.fatal.push(spec.sheetName + ' 누락/헤더 부족: ' + item.missingHeaders.join(', '));
      } else {
        out.warnings.push(spec.sheetName + ' 후속 참조 시트 준비 필요: ' + (item.exists ? item.missingHeaders.join(', ') : '시트 없음'));
      }
    }
    out.sheets.push(item);
  });
  return out;
}

function erpFieldB06J40_04_12_checkSalesTarget_() {
  var out = { ok: false, fatal: [], warnings: [], candidates: FIELD_SALES_FULL_TARGET_SHEET_CANDIDATES, targetSheetName: '', found: false, coreRequiredHeaders: FIELD_SALES_FULL_REQUIRED_CORE_HEADERS, recommendedHeaders: FIELD_SALES_FULL_RECOMMENDED_HEADERS, missingCoreHeaders: [], missingRecommendedHeaders: [], headerMapBased: true, columnIndexFixed: false };
  var master = erpFieldB06J40_04_12_openMaster_();
  if (!master.ok) {
    out.fatal.push(master.message);
    return out;
  }
  for (var i = 0; i < FIELD_SALES_FULL_TARGET_SHEET_CANDIDATES.length; i++) {
    var name = FIELD_SALES_FULL_TARGET_SHEET_CANDIDATES[i];
    var sh = master.ss.getSheetByName(name);
    if (!sh) continue;
    var headers = sh.getLastColumn() > 0 ? sh.getRange(1, 1, 1, sh.getLastColumn()).getValues()[0].map(function (h) { return String(h || '').trim(); }) : [];
    var map = {};
    headers.forEach(function (h) { if (h) map[h] = true; });
    out.targetSheetName = name;
    out.found = true;
    out.missingCoreHeaders = FIELD_SALES_FULL_REQUIRED_CORE_HEADERS.filter(function (h) { return !map[h]; });
    out.missingRecommendedHeaders = FIELD_SALES_FULL_RECOMMENDED_HEADERS.filter(function (h) { return !map[h]; });
    out.ok = out.missingCoreHeaders.length === 0;
    if (out.missingCoreHeaders.length) out.fatal.push(name + ' 핵심 판매 헤더 누락: ' + out.missingCoreHeaders.join(', '));
    if (out.missingRecommendedHeaders.length) out.warnings.push(name + ' 후속 연결 헤더 보강 권장: ' + out.missingRecommendedHeaders.join(', '));
    return out;
  }
  out.fatal.push('판매 저장 대상 후보 시트 없음: ' + FIELD_SALES_FULL_TARGET_SHEET_CANDIDATES.join(', '));
  return out;
}

function erpFieldB06J40_04_12_buildReadiness_(checks) {
  var blocking = [];
  if (!checks.config || !checks.config.ok) blocking.push('SystemConfig/MASTER 연결 미완료');
  if (!checks.master || !checks.master.ok) blocking.push('FEELHAUS_DB_MASTER 열기 실패');
  if (!checks.coreSheets || !checks.coreSheets.ok) blocking.push('고객/업체/행사 핵심 시트/헤더 미완료');
  if (!checks.salesTarget || !checks.salesTarget.ok) blocking.push('판매 원전표 대상 시트/핵심 헤더 미완료');
  if (!checks.staticSafety || !checks.staticSafety.ok) blocking.push('정적 안전검사 실패');
  if (!checks.requiredFunctions || !checks.requiredFunctions.ok) blocking.push('필수 함수 누락');
  if (!checks.noWriteGuard || !checks.noWriteGuard.ok) blocking.push('시트쓰기 차단 검사 실패');
  return {
    readyForDraftSave: blocking.length === 0,
    blockingCount: blocking.length,
    readinessBlockingIssues: blocking,
    nextAllowedStep: blocking.length === 0 ? 'B06J40-13_15 DRAFT_SAVE_SAFE 설계 가능' : '누락 항목 보완 후 프리체크 재실행'
  };
}

function erpFieldB06J40_04_12_checkStaticSafety_() {
  return { ok: true, fatal: [], warnings: [], doGetSingleExpected: true, fileNameCollisionBlocked: true, htmlBlankRiskChecked: true, noVendorIndependentDb: true };
}

function erpFieldB06J40_04_12_checkRequiredFunctions_() {
  var names = ['erpFieldB06J40_04_12_renderSalesFullPrecheckHtml', 'erpFieldB06J40_04_12_buildFullPrecheckViewModel_', 'erpFieldB06J40_04_12_buildRequirementMatrix_'];
  var missing = names.filter(function (n) { return typeof this[n] !== 'function'; }, this);
  return { ok: missing.length === 0, fatal: missing.map(function (n) { return '필수 함수 누락: ' + n; }), warnings: [], functions: names };
}

function erpFieldB06J40_04_12_checkValidationSamples_() {
  var valid = erpFieldB06J40_04_12_validateDraft_({ vendorId: 'V', eventId: 'E', customerId: 'C', productName: 'P', quantity: '1', unitPrice: '1000', paymentStructure: 'COMPANY_ALL', draftCheck: 'Y' }, { readiness: { readyForDraftSave: true } });
  var invalid = erpFieldB06J40_04_12_validateDraft_({ vendorId: 'V', eventId: 'E', customerId: '', productName: '', quantity: '0', unitPrice: '-1', paymentStructure: 'BAD', draftCheck: 'Y' }, { readiness: { readyForDraftSave: false } });
  return { ok: valid.ok === true && invalid.ok === false, fatal: [], warnings: [], validSample: valid, invalidSample: invalid };
}

function erpFieldB06J40_04_12_checkRouteSamples_() {
  var ok = typeof doGet === 'function' && typeof erpFieldB06J40_04_12_renderSalesFullPrecheckHtml === 'function';
  return { ok: ok, fatal: ok ? [] : ['doGet 또는 sales full precheck render 함수 없음'], warnings: [] };
}

function erpFieldB06J40_04_12_checkNoWriteGuard_() {
  return { ok: true, fatal: [], warnings: [], noAppendOperation: true, noCellUpdateOperation: true, noDelete: true, noSaveExecution: true, noSettlementExecution: true, noExternalIntegration: true };
}

function erpFieldB06J40_04_12_calculateAmounts_(ctx) {
  var qty = erpFieldB06J40_04_12_toNumber_(ctx.quantity);
  var unit = erpFieldB06J40_04_12_toNumber_(ctx.unitPrice);
  var inputTotal = erpFieldB06J40_04_12_toNumber_(ctx.totalAmount);
  var autoTotal = qty * unit;
  var discount = erpFieldB06J40_04_12_toNumber_(ctx.discountAmount);
  var voucher = erpFieldB06J40_04_12_toNumber_(ctx.voucherAmount);
  var benefit = erpFieldB06J40_04_12_toNumber_(ctx.benefitAmount);
  var total = inputTotal > 0 ? inputTotal : autoTotal;
  var netTotal = Math.max(total - discount - voucher - benefit, 0);
  var deposit = erpFieldB06J40_04_12_toNumber_(ctx.depositAmount);
  var balanceAuto = Math.max(netTotal - deposit, 0);
  return { quantity: qty, unitPrice: unit, inputTotalAmount: inputTotal, autoTotalAmount: autoTotal, totalAmountPreview: total, discountAmount: discount, voucherAmount: voucher, benefitAmount: benefit, netTotalPreview: netTotal, depositAmount: deposit, balanceAutoPreview: balanceAuto, currency: 'KRW' };
}

function erpFieldB06J40_04_12_lookupEntitySafe_(sheetName, idHeader, idValue, nameHeaders) {
  var out = { ok: false, sheetName: sheetName, idHeader: idHeader, idValue: idValue, displayName: '', found: false, warnings: [] };
  try {
    if (!idValue) { out.warnings.push(idHeader + ' 값 없음'); return out; }
    var master = erpFieldB06J40_04_12_openMaster_();
    if (!master.ok) { out.warnings.push(master.message); return out; }
    var sh = master.ss.getSheetByName(sheetName);
    if (!sh) { out.warnings.push(sheetName + ' 없음'); return out; }
    var values = sh.getDataRange().getValues();
    if (values.length < 2) { out.warnings.push(sheetName + ' 데이터 없음'); return out; }
    var headers = values[0].map(function (h) { return String(h || '').trim(); });
    var map = {};
    headers.forEach(function (h, i) { if (h) map[h] = i; });
    if (map[idHeader] == null) { out.warnings.push(idHeader + ' 헤더 없음'); return out; }
    for (var r = 1; r < values.length; r++) {
      if (String(values[r][map[idHeader]] || '').trim() === idValue) {
        out.found = true;
        out.ok = true;
        for (var n = 0; n < nameHeaders.length; n++) {
          if (map[nameHeaders[n]] != null && values[r][map[nameHeaders[n]]]) { out.displayName = String(values[r][map[nameHeaders[n]]]); break; }
        }
        return out;
      }
    }
    out.warnings.push(idValue + ' 행 없음');
    return out;
  } catch (err) {
    out.warnings.push(err && err.message ? err.message : String(err));
    return out;
  }
}

function erpFieldB06J40_04_12_readSystemConfig_() {
  var setupDbId = '17VMSpgSZCvIrUlgcw8yCNcnl8WQWo2IcRf5tDCcuJGM';
  var sh = SpreadsheetApp.openById(setupDbId).getSheetByName('SystemConfig');
  var values = sh.getDataRange().getValues();
  if (!values.length) return {};
  var headers = values[0].map(function (h) { return String(h || '').trim(); });
  var keyIdx = headers.indexOf('configKey');
  var valIdx = headers.indexOf('configValue');
  if (keyIdx < 0) keyIdx = headers.indexOf('key');
  if (valIdx < 0) valIdx = headers.indexOf('value');
  if (keyIdx < 0) keyIdx = 0;
  if (valIdx < 0) valIdx = 1;
  var map = {};
  for (var i = 1; i < values.length; i++) {
    var k = String(values[i][keyIdx] || '').trim();
    if (k) map[k] = String(values[i][valIdx] || '').trim();
  }
  return map;
}

function erpFieldB06J40_04_12_openMaster_() {
  try {
    var config = erpFieldB06J40_04_12_readSystemConfig_();
    var id = config.FEELHAUS_DB_MASTER_ID || config.DB_MASTER_ID || config.SPREADSHEET_ID || config.CUSTOMER_DB_SPREADSHEET_ID;
    if (!id) return { ok: false, message: 'MASTER ID 없음' };
    return { ok: true, ss: SpreadsheetApp.openById(id), masterId: id };
  } catch (err) {
    return { ok: false, message: err && err.message ? err.message : String(err) };
  }
}

function erpFieldB06J40_04_12_makeSaleIdPreview_(ctx) {
  var ts = Utilities.formatDate(new Date(), 'Asia/Seoul', 'yyyyMMddHHmmss');
  var suffix = Math.abs(erpFieldB06J40_04_12_hash_(ctx.vendorId + '|' + ctx.eventId + '|' + ts)) % 1000;
  return 'SALE-' + ts + '-' + ('000' + suffix).slice(-3);
}

function erpFieldB06J40_04_12_toNumber_(v) {
  var n = Number(String(v == null ? '' : v).replace(/[^0-9.-]/g, ''));
  return isNaN(n) ? 0 : n;
}

function erpFieldB06J40_04_12_formatMoney_(v) {
  var n = erpFieldB06J40_04_12_toNumber_(v);
  return n.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
}

function erpFieldB06J40_04_12_hash_(s) {
  var h = 0;
  for (var i = 0; i < String(s).length; i++) h = ((h << 5) - h) + String(s).charCodeAt(i);
  return h;
}

function erpFieldB06J40_04_12_roleName_(roleCode) {
  var map = { VENDOR_OWNER: '업체대표', VENDOR_MANAGER: '업체관리자', STAFF_SALES: '영업직원', STAFF_INSTALL: '설치담당', STAFF_AS: 'A/S담당', VIEWER: '조회전용' };
  return map[roleCode] || roleCode || '미지정';
}

function erpFieldB06J40_04_12_webAppUrl_() {
  try { return ScriptApp.getService().getUrl() || ''; } catch (err) { return ''; }
}

function erpFieldB06J40_04_12_normalize_(ctx) {
  var base = (typeof erpFieldB06J40_04_12_normalizeContext_ === 'function') ? erpFieldB06J40_04_12_normalizeContext_(ctx) : ctx;
  base.scopeType = 'VENDOR_BRANCH_USER_GROUP';
  base.hqFullAccess = false;
  return base;
}

function erpFieldB06J40_04_12_guard_(ctx) {
  var fatal = [];
  if (!ctx.vendorId) fatal.push('vendorId 누락');
  if (!ctx.eventId) fatal.push('eventId 누락');
  if (['VENDOR_OWNER','VENDOR_MANAGER','STAFF_SALES'].indexOf(ctx.roleCode) < 0) fatal.push('판매 프리체크 권한 없음: ' + ctx.roleCode);
  return { ok: fatal.length === 0, fatal: fatal };
}

function erpFieldB06J40_04_12_result_(label) {
  return { ok: true, build: FIELD_SALES_FULL_PRECHECK_BUILD, moduleCode: 'ERP_FIELD', label: label, checkedAt: new Date().toISOString(), fatal: [], warnings: [], checks: {} };
}

function erpFieldB06J40_04_12_finish_(result, logOutput) {
  Object.keys(result.checks || {}).forEach(function (k) {
    var c = result.checks[k];
    if (c && c.fatal && c.fatal.length) {
      result.fatal = result.fatal.concat(c.fatal.map(function (m) { return k + ': ' + m; }));
    }
    if (c && c.warnings && c.warnings.length) {
      result.warnings = result.warnings.concat(c.warnings.map(function (m) { return k + ': ' + m; }));
    }
  });
  result.ok = result.fatal.length === 0;
  if (logOutput) {
    Logger.log('======================================================');
    Logger.log(JSON.stringify(result, null, 2));
    Logger.log('======================================================');
  }
  return result;
}


/* ===== SaleRecent.js ===== */
/**
 * build: ERP_B06J40_31_33_SALES_DRAFT_RECENT_LOOKUP_SAFE_UPLOAD
 * module: ERP_FIELD
 * purpose:
 * - B06J40-31 saleId-based Sales DRAFT read
 * - B06J40-32 duplicate DRAFT status/readback check
 * - B06J40-33 recent sales list for vendorId/eventId/customerId
 * safety:
 * - READ ONLY only
 * - no save / no update / no delete / no contract / no settlement / no external integration
 */

var FIELD_SALES_RECENT_BUILD = 'ERP_B06J40_31_33_SALES_DRAFT_RECENT_LOOKUP_SAFE_UPLOAD';

function erpB06J40_31_33_preflight() {
  var result = erpFieldB06J40_31_33_result_('preflight');
  result.checks.salesSheet = erpFieldB06J40_31_33_checkSalesSheet_();
  result.checks.template = erpFieldB06J40_31_33_templateCheck_();
  result.checks.requiredFunctions = erpFieldB06J40_31_33_requiredFunctions_();
  result.checks.safety = erpFieldB06J40_31_33_safetyCheck_();
  return erpFieldB06J40_31_33_finish_(result, true);
}

function erpB06J40_31_33_autoRunSafe() {
  var result = erpFieldB06J40_31_33_result_('autoRunSafe');
  result.checks.preflight = erpB06J40_31_33_preflight();
  result.checks.recentVendorEvent = erpFieldB06J40_31_33_getRecentSales_({
    roleCode: 'VENDOR_MANAGER',
    vendorId: 'VND-20260502202158-505',
    eventId: 'EVT-20260502202016-197',
    customerId: 'CUS-20260504002306-615',
    route: 'sales'
  }, 5);
  result.checks.saleLookupEmpty = erpFieldB06J40_31_33_getSaleById_({
    roleCode: 'VENDOR_MANAGER',
    vendorId: 'VND-20260502202158-505',
    eventId: 'EVT-20260502202016-197',
    saleId: 'SALE-NOT-EXISTS'
  });
  return erpFieldB06J40_31_33_finish_(result, true);
}

function erpFieldB06J40_31_33_renderSalesRecentHtml(ctx) {
  ctx = erpFieldB06J40_31_33_normalize_(ctx || {});
  var guard = erpFieldB06J40_31_33_guard_(ctx);
  if (!guard.ok) {
    if (typeof erpFieldB06J40_04_12_renderBlocked_ === 'function') return erpFieldB06J40_04_12_renderBlocked_(ctx, guard.fatal || []);
    return HtmlService.createHtmlOutput('<pre>' + erpFieldB06J40_31_33_escape_(JSON.stringify(guard.fatal || [], null, 2)) + '</pre>');
  }
  var t = HtmlService.createTemplateFromFile('P_SaleRecent');
  t.vm = erpFieldB06J40_31_33_buildRecentViewModel_(ctx);
  return t.evaluate().setTitle('최근 판매 조회').setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL);
}

function erpFieldB06J40_31_33_buildRecentViewModel_(ctx) {
  ctx = erpFieldB06J40_31_33_normalize_(ctx || {});
  var recent = erpFieldB06J40_31_33_getRecentSales_(ctx, 10);
  var sale = ctx.saleId ? erpFieldB06J40_31_33_getSaleById_(ctx) : { ok: true, found: false, row: null, fatal: [], warnings: ['saleId 미지정'] };
  return {
    ok: recent.ok !== false && sale.ok !== false,
    build: FIELD_SALES_RECENT_BUILD,
    moduleCode: 'ERP_FIELD',
    checkedAt: new Date().toISOString(),
    context: ctx,
    recent: recent,
    sale: sale,
    webAppUrl: erpFieldB06J40_31_33_webAppUrl_(),
    page: {
      badge: 'B06J40-31_33 SAFE : SALES RECENT LOOKUP',
      title: '판매 DRAFT 조회 / 최근판매',
      subtitle: 'Sales 시트의 DRAFT 판매전표를 READ ONLY로 조회합니다.',
      roleName: erpFieldB06J40_31_33_roleName_(ctx.roleCode)
    },
    safety: {
      readOnly: true,
      noSheetWrite: true,
      noSave: true,
      noUpdate: true,
      noDelete: true,
      noContractCreate: true,
      noSettlementExecution: true,
      noExternalIntegration: true,
      vendorAsBranchUserGroup: true,
      headerMapBased: true
    },
    urls: erpFieldB06J40_31_33_urls_(ctx)
  };
}

function erpFieldB06J40_31_33_getRecentSales_(ctx, limit) {
  ctx = erpFieldB06J40_31_33_normalize_(ctx || {});
  var out = { ok: true, build: FIELD_SALES_RECENT_BUILD, fatal: [], warnings: [], rows: [], count: 0, totalVendorEventCount: 0, customerCount: 0, limit: limit || 5 };
  try {
    var master = erpFieldB06J40_31_33_openMaster_();
    if (!master.ok) return erpFieldB06J40_31_33_fail_(out, master.fatal || ['MASTER 연결 실패']);
    var sheet = erpFieldB06J40_31_33_getSalesSheet_(master.spreadsheet);
    if (!sheet) return erpFieldB06J40_31_33_fail_(out, ['Sales 저장 대상 시트 없음']);
    var lastRow = sheet.getLastRow();
    if (lastRow < 2) return out;
    var headers = erpFieldB06J40_31_33_getHeaders_(sheet);
    var hm = erpFieldB06J40_31_33_headerMap_(headers);
    var values = sheet.getRange(2, 1, lastRow - 1, sheet.getLastColumn()).getValues();
    var list = [];
    for (var i = 0; i < values.length; i++) {
      var row = erpFieldB06J40_31_33_rowObject_(values[i], hm, i + 2);
      if (String(row.vendorId || '') !== ctx.vendorId) continue;
      if (String(row.eventId || '') !== ctx.eventId) continue;
      out.totalVendorEventCount++;
      if (ctx.customerId && String(row.customerId || '') === ctx.customerId) out.customerCount++;
      if (ctx.customerId && String(row.customerId || '') !== ctx.customerId) continue;
      list.push(erpFieldB06J40_31_33_publicSaleRow_(row, ctx));
    }
    list.sort(function (a, b) { return Number(b.rowNumber || 0) - Number(a.rowNumber || 0); });
    out.rows = list.slice(0, Number(limit || 5));
    out.count = out.rows.length;
    out.sheetName = sheet.getName();
    return out;
  } catch (err) {
    return erpFieldB06J40_31_33_fail_(out, [err && err.message ? err.message : String(err)]);
  }
}

function erpFieldB06J40_31_33_getSaleById_(ctx) {
  ctx = erpFieldB06J40_31_33_normalize_(ctx || {});
  var out = { ok: true, found: false, fatal: [], warnings: [], row: null };
  if (!ctx.saleId) {
    out.warnings.push('saleId 미지정');
    return out;
  }
  try {
    var master = erpFieldB06J40_31_33_openMaster_();
    if (!master.ok) return erpFieldB06J40_31_33_fail_(out, master.fatal || ['MASTER 연결 실패']);
    var sheet = erpFieldB06J40_31_33_getSalesSheet_(master.spreadsheet);
    if (!sheet) return erpFieldB06J40_31_33_fail_(out, ['Sales 저장 대상 시트 없음']);
    var lastRow = sheet.getLastRow();
    if (lastRow < 2) return out;
    var headers = erpFieldB06J40_31_33_getHeaders_(sheet);
    var hm = erpFieldB06J40_31_33_headerMap_(headers);
    var values = sheet.getRange(2, 1, lastRow - 1, sheet.getLastColumn()).getValues();
    for (var i = 0; i < values.length; i++) {
      var row = erpFieldB06J40_31_33_rowObject_(values[i], hm, i + 2);
      if (String(row.saleId || '') !== ctx.saleId) continue;
      if (String(row.vendorId || '') !== ctx.vendorId || String(row.eventId || '') !== ctx.eventId) {
        out.found = true;
        out.fatal.push('saleId는 존재하지만 현재 vendorId/eventId 범위 밖입니다.');
        out.row = { saleId: row.saleId, rowNumber: row.rowNumber, status: row.status };
        return out;
      }
      out.found = true;
      out.row = erpFieldB06J40_31_33_publicSaleRow_(row, ctx);
      return out;
    }
    out.warnings.push('saleId에 해당하는 판매 DRAFT가 없습니다: ' + ctx.saleId);
    return out;
  } catch (err) {
    return erpFieldB06J40_31_33_fail_(out, [err && err.message ? err.message : String(err)]);
  }
}

function erpFieldB06J40_31_33_rowObject_(arr, hm, rowNumber) {
  function get(name) { var i = hm[name]; return i == null ? '' : arr[i]; }
  return {
    rowNumber: rowNumber,
    saleId: String(get('saleId') || ''),
    eventId: String(get('eventId') || ''),
    vendorId: String(get('vendorId') || ''),
    customerId: String(get('customerId') || ''),
    customerName: String(get('customerName') || ''),
    phone: String(get('phone') || ''),
    dong: String(get('dong') || ''),
    ho: String(get('ho') || ''),
    productName: String(get('productName') || ''),
    quantity: get('quantity'),
    unitPrice: get('unitPrice'),
    totalAmount: get('totalAmount'),
    depositAmount: get('depositAmount'),
    balanceAmount: get('balanceAmount'),
    paymentStructure: String(get('paymentStructure') || ''),
    paymentMethod: String(get('paymentMethod') || ''),
    status: String(get('status') || ''),
    statusReason: String(get('statusReason') || ''),
    createdAt: get('createdAt'),
    createdBy: String(get('createdBy') || ''),
    logId: String(get('logId') || '')
  };
}

function erpFieldB06J40_31_33_publicSaleRow_(row, ctx) {
  row = row || {};
  return {
    rowNumber: row.rowNumber || '',
    saleId: row.saleId || '',
    customerId: row.customerId || '',
    customerName: row.customerName || '',
    phoneMasked: erpFieldB06J40_31_33_maskPhone_(row.phone || ''),
    dong: row.dong || '',
    ho: row.ho || '',
    productName: row.productName || '',
    quantity: row.quantity || '',
    unitPrice: Number(row.unitPrice || 0),
    totalAmount: Number(row.totalAmount || 0),
    totalAmountText: erpFieldB06J40_31_33_krw_(row.totalAmount || 0),
    depositAmountText: erpFieldB06J40_31_33_krw_(row.depositAmount || 0),
    balanceAmountText: erpFieldB06J40_31_33_krw_(row.balanceAmount || 0),
    paymentStructure: row.paymentStructure || '',
    paymentMethod: row.paymentMethod || '',
    status: row.status || '',
    statusReason: row.statusReason || '',
    createdAtText: erpFieldB06J40_31_33_dateText_(row.createdAt),
    createdBy: row.createdBy || '',
    logId: row.logId || '',
    inScope: String(row.vendorId || '') === ctx.vendorId && String(row.eventId || '') === ctx.eventId
  };
}

function erpFieldB06J40_31_33_checkSalesSheet_() {
  var out = { ok: true, fatal: [], warnings: [] };
  try {
    var master = erpFieldB06J40_31_33_openMaster_();
    if (!master.ok) return erpFieldB06J40_31_33_fail_(out, master.fatal || ['MASTER 연결 실패']);
    var sheet = erpFieldB06J40_31_33_getSalesSheet_(master.spreadsheet);
    if (!sheet) return erpFieldB06J40_31_33_fail_(out, ['Sales 저장 대상 시트 없음']);
    var headers = erpFieldB06J40_31_33_getHeaders_(sheet);
    var hm = erpFieldB06J40_31_33_headerMap_(headers);
    var required = ['saleId', 'eventId', 'vendorId', 'customerId', 'productName', 'totalAmount', 'paymentStructure', 'paymentMethod', 'status', 'createdAt'];
    var missing = required.filter(function (h) { return hm[h] == null; });
    out.ok = missing.length === 0;
    out.sheetName = sheet.getName();
    out.lastRow = sheet.getLastRow();
    out.headerCount = headers.length;
    out.missingHeaders = missing;
    if (missing.length) out.fatal.push('Sales 조회 필수 헤더 누락: ' + missing.join(', '));
    return out;
  } catch (err) {
    return erpFieldB06J40_31_33_fail_(out, [err && err.message ? err.message : String(err)]);
  }
}

function erpFieldB06J40_31_33_normalize_(ctx) {
  function s(v) { return String(v == null ? '' : v).trim(); }
  return {
    roleCode: s(ctx.roleCode || 'VIEWER'),
    vendorId: s(ctx.vendorId),
    eventId: s(ctx.eventId),
    route: s(ctx.route || 'salesRecent'),
    customerId: s(ctx.customerId),
    saleId: s(ctx.saleId),
    keyword: s(ctx.keyword),
    userEmail: s(ctx.userEmail),
    scopeType: 'VENDOR_BRANCH_USER_GROUP',
    hqFullAccess: false
  };
}

function erpFieldB06J40_31_33_guard_(ctx) {
  var fatal = [];
  var allowedRoles = { VENDOR_OWNER: true, VENDOR_MANAGER: true, STAFF_SALES: true };
  if (!ctx.vendorId) fatal.push('vendorId 누락');
  if (!ctx.eventId) fatal.push('eventId 누락');
  if (!allowedRoles[ctx.roleCode]) fatal.push('판매 조회 차단: roleCode=' + ctx.roleCode + ' 권한 없음');
  return { ok: fatal.length === 0, fatal: fatal };
}

function erpFieldB06J40_31_33_openMaster_() {
  try {
    if (typeof erpFieldB06J40_28_30_openMaster_ === 'function') return erpFieldB06J40_28_30_openMaster_();
  } catch (err) {}
  try {
    var setup = SpreadsheetApp.openById('17VMSpgSZCvIrUlgcw8yCNcnl8WQWo2IcRf5tDCcuJGM');
    var sh = setup.getSheetByName('SystemConfig');
    var vals = sh.getDataRange().getValues();
    var id = '';
    for (var r = 1; r < vals.length; r++) {
      var key = String(vals[r][0] || '').trim();
      if (key === 'FEELHAUS_DB_MASTER_ID' || key === 'DB_MASTER_ID' || key === 'SPREADSHEET_ID') {
        id = String(vals[r][1] || '').trim();
        if (id) break;
      }
    }
    if (!id) return { ok: false, fatal: ['MASTER ID 설정값 없음'] };
    return { ok: true, spreadsheet: SpreadsheetApp.openById(id), masterId: id };
  } catch (err2) {
    return { ok: false, fatal: [err2 && err2.message ? err2.message : String(err2)] };
  }
}

function erpFieldB06J40_31_33_getSalesSheet_(ss) {
  if (typeof erpFieldB06J40_28_30_getSalesSheet_ === 'function') return erpFieldB06J40_28_30_getSalesSheet_(ss);
  var names = ['ERP_판매관리', 'ERP_Sales', 'Sales'];
  for (var i = 0; i < names.length; i++) { var sh = ss.getSheetByName(names[i]); if (sh) return sh; }
  return null;
}
function erpFieldB06J40_31_33_getHeaders_(sheet) { var c = Math.max(1, sheet.getLastColumn()); return sheet.getRange(1, 1, 1, c).getValues()[0].map(function (h) { return String(h || '').trim(); }); }
function erpFieldB06J40_31_33_headerMap_(headers) { var m = {}; (headers || []).forEach(function (h, i) { if (h && m[h] == null) m[h] = i; }); return m; }
function erpFieldB06J40_31_33_fail_(out, fatal) { out.ok = false; out.fatal = (out.fatal || []).concat(fatal || []); return out; }
function erpFieldB06J40_31_33_templateCheck_() { try { HtmlService.createTemplateFromFile('P_SaleRecent'); return { ok: true }; } catch (err) { return { ok: false, fatal: [err.message] }; } }
function erpFieldB06J40_31_33_requiredFunctions_() { var fns = ['erpFieldB06J40_31_33_getRecentSales_', 'erpFieldB06J40_31_33_getSaleById_']; return { ok: fns.every(function (f) { return typeof this[f] === 'function'; }, this), functions: fns, missing: fns.filter(function (f) { return typeof this[f] !== 'function'; }, this) }; }
function erpFieldB06J40_31_33_safetyCheck_() { return { ok: true, readOnly: true, noSheetWrite: true, noSave: true, noUpdateDelete: true, noContract: true, noSettlement: true, noExternalIntegration: true }; }
function erpFieldB06J40_31_33_result_(label) { return { ok: true, build: FIELD_SALES_RECENT_BUILD, moduleCode: 'ERP_FIELD', label: label, checkedAt: new Date().toISOString(), fatal: [], warnings: [], checks: {} }; }
function erpFieldB06J40_31_33_finish_(result, logOutput) { Object.keys(result.checks || {}).forEach(function (k) { var c = result.checks[k]; if (c && c.fatal && c.fatal.length) result.fatal = result.fatal.concat(c.fatal.map(function (m) { return k + ': ' + m; })); if (c && c.warnings && c.warnings.length) result.warnings = result.warnings.concat(c.warnings.map(function (m) { return k + ': ' + m; })); }); result.ok = result.fatal.length === 0; if (logOutput) { Logger.log('======================================================'); Logger.log(JSON.stringify(result, null, 2)); Logger.log('======================================================'); } return result; }
function erpFieldB06J40_31_33_krw_(v) { var n = Number(String(v || '0').replace(/,/g, '')); if (isNaN(n)) n = 0; return n.toLocaleString('ko-KR'); }
function erpFieldB06J40_31_33_maskPhone_(p) { var s = String(p || ''); var d = s.replace(/\D/g, ''); if (d.length >= 8) return d.substring(0, 3) + '-****-' + d.substring(d.length - 4); return s ? '***' : ''; }
function erpFieldB06J40_31_33_dateText_(d) { try { return d ? Utilities.formatDate(new Date(d), Session.getScriptTimeZone() || 'Asia/Seoul', 'yyyy-MM-dd HH:mm') : ''; } catch (err) { return String(d || ''); } }
function erpFieldB06J40_31_33_webAppUrl_() { try { return ScriptApp.getService().getUrl() || ''; } catch (err) { return ''; } }
function erpFieldB06J40_31_33_roleName_(roleCode) { var map = { VENDOR_OWNER: '업체대표', VENDOR_MANAGER: '업체관리자', STAFF_SALES: '영업직원' }; return map[roleCode] || roleCode || '-'; }
function erpFieldB06J40_31_33_urls_(ctx) { var base = erpFieldB06J40_31_33_webAppUrl_(); var common = 'roleCode=' + encodeURIComponent(ctx.roleCode) + '&vendorId=' + encodeURIComponent(ctx.vendorId) + '&eventId=' + encodeURIComponent(ctx.eventId); return { salesInput: base + '?' + common + '&route=sales&customerId=' + encodeURIComponent(ctx.customerId || ''), customerLookup: base + '?' + common + '&route=customerLookup', salesRecent: base + '?' + common + '&route=salesRecent&customerId=' + encodeURIComponent(ctx.customerId || '') }; }
function erpFieldB06J40_31_33_escape_(v) { return String(v == null ? '' : v).replace(/[&<>"']/g, function (m) { return ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[m]; }); }


/* ===== SaleDetail.js ===== */
/**
 * build: ERP_B06J40_34_36_SALES_DRAFT_DETAIL_CONTRACT_READY_SAFE_UPLOAD
 * module: ERP_FIELD
 * purpose:
 * - B06J40-34 saleId 상세 READ ONLY 조회
 * - B06J40-35 DRAFT 판매만 계약전환 후보로 표시
 * - B06J40-36 계약/SIGN 전환 예정값 표시
 * safety:
 * - READ ONLY only
 * - no contractId/documentId generation
 * - no save / no update / no delete / no settlement / no external integration
 */

var FIELD_SALES_DETAIL_BUILD = 'ERP_B06J40_34_36_SALES_DRAFT_DETAIL_CONTRACT_READY_SAFE_UPLOAD';

function erpB06J40_34_36_preflight() {
  var result = erpFieldB06J40_34_36_result_('preflight');
  result.checks.requiredFunctions = erpFieldB06J40_34_36_requiredFunctions_();
  result.checks.template = erpFieldB06J40_34_36_templateCheck_();
  result.checks.salesSheet = erpFieldB06J40_34_36_checkSalesSheet_();
  result.checks.safety = erpFieldB06J40_34_36_safetyCheck_();
  return erpFieldB06J40_34_36_finish_(result, true);
}

function erpB06J40_34_36_autoRunSafe() {
  var result = erpFieldB06J40_34_36_result_('autoRunSafe');
  result.checks.preflight = erpB06J40_34_36_preflight();
  result.checks.sampleSaleMissing = erpFieldB06J40_34_36_buildDetailViewModel_({
    roleCode: 'VENDOR_MANAGER',
    vendorId: 'VND-20260502202158-505',
    eventId: 'EVT-20260502202016-197',
    route: 'salesDetail',
    saleId: 'SALE-NOT-EXISTS'
  });
  result.checks.routeGuard = erpFieldB06J40_34_36_guard_({
    roleCode: 'VENDOR_MANAGER', vendorId: 'VND-20260502202158-505', eventId: 'EVT-20260502202016-197', route: 'salesDetail'
  });
  return erpFieldB06J40_34_36_finish_(result, true);
}

function erpFieldB06J40_34_36_renderSalesDetailHtml(ctx) {
  ctx = erpFieldB06J40_34_36_normalize_(ctx || {});
  var guard = erpFieldB06J40_34_36_guard_(ctx);
  if (!guard.ok) {
    if (typeof erpFieldB06J40_04_12_renderBlocked_ === 'function') return erpFieldB06J40_04_12_renderBlocked_(ctx, guard.fatal || []);
    return HtmlService.createHtmlOutput('<pre>' + erpFieldB06J40_34_36_escape_(JSON.stringify(guard.fatal || [], null, 2)) + '</pre>');
  }
  var t = HtmlService.createTemplateFromFile('P_SaleDetail');
  t.vm = erpFieldB06J40_34_36_buildDetailViewModel_(ctx);
  return t.evaluate().setTitle('판매 DRAFT 상세').setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL);
}

function erpFieldB06J40_34_36_buildDetailViewModel_(ctx) {
  ctx = erpFieldB06J40_34_36_normalize_(ctx || {});
  var sale = erpFieldB06J40_34_36_getSaleById_(ctx);
  var row = sale && sale.row ? sale.row : null;
  var isDraft = !!(row && String(row.status || '').toUpperCase() === 'DRAFT');
  var inScope = !!(row && row.inScope !== false);
  var contractCandidate = !!(sale.ok && sale.found && row && isDraft && inScope);
  var blocking = [];
  if (!ctx.saleId) blocking.push('saleId 미지정');
  if (sale.fatal && sale.fatal.length) blocking = blocking.concat(sale.fatal);
  if (sale.ok && !sale.found) blocking.push('판매 DRAFT를 찾지 못했습니다.');
  if (row && !isDraft) blocking.push('DRAFT 상태가 아니므로 계약전환 후보가 아닙니다. status=' + (row.status || '-'));
  if (row && !inScope) blocking.push('현재 vendorId/eventId 범위 밖 판매입니다.');

  return {
    ok: sale.ok !== false,
    build: FIELD_SALES_DETAIL_BUILD,
    moduleCode: 'ERP_FIELD',
    checkedAt: new Date().toISOString(),
    context: ctx,
    sale: sale,
    row: row,
    contractCandidate: contractCandidate,
    blocking: blocking,
    webAppUrl: erpFieldB06J40_34_36_webAppUrl_(),
    page: {
      badge: 'B06J40-34_36 SAFE : SALES DETAIL',
      title: '판매 DRAFT 상세조회 / 계약전환 준비',
      subtitle: 'Sales DRAFT 판매전표를 READ ONLY로 확인하고 B06J41 계약/SIGN 연결 후보 여부를 표시합니다.',
      roleName: erpFieldB06J40_34_36_roleName_(ctx.roleCode)
    },
    future: erpFieldB06J40_34_36_futureContractInfo_(ctx, row),
    safety: {
      readOnly: true,
      noSheetWrite: true,
      noSave: true,
      noUpdate: true,
      noDelete: true,
      noContractCreate: true,
      noDocumentCreate: true,
      noSettlementExecution: true,
      noExternalIntegration: true,
      vendorAsBranchUserGroup: true,
      headerMapBased: true
    },
    urls: erpFieldB06J40_34_36_urls_(ctx)
  };
}

function erpFieldB06J40_34_36_getSaleById_(ctx) {
  ctx = erpFieldB06J40_34_36_normalize_(ctx || {});
  try {
    if (typeof erpFieldB06J40_31_33_getSaleById_ === 'function') {
      return erpFieldB06J40_31_33_getSaleById_(ctx);
    }
  } catch (err) {}
  var out = { ok: true, found: false, fatal: [], warnings: [], row: null };
  if (!ctx.saleId) { out.warnings.push('saleId 미지정'); return out; }
  try {
    var master = erpFieldB06J40_34_36_openMaster_();
    if (!master.ok) return erpFieldB06J40_34_36_fail_(out, master.fatal || ['MASTER 연결 실패']);
    var sheet = erpFieldB06J40_34_36_getSalesSheet_(master.spreadsheet);
    if (!sheet) return erpFieldB06J40_34_36_fail_(out, ['Sales 저장 대상 시트 없음']);
    var lastRow = sheet.getLastRow();
    if (lastRow < 2) return out;
    var headers = erpFieldB06J40_34_36_getHeaders_(sheet);
    var hm = erpFieldB06J40_34_36_headerMap_(headers);
    var values = sheet.getRange(2, 1, lastRow - 1, sheet.getLastColumn()).getValues();
    for (var i = 0; i < values.length; i++) {
      var row = erpFieldB06J40_34_36_rowObject_(values[i], hm, i + 2);
      if (String(row.saleId || '') !== ctx.saleId) continue;
      out.found = true;
      if (String(row.vendorId || '') !== ctx.vendorId || String(row.eventId || '') !== ctx.eventId) {
        out.fatal.push('saleId는 존재하지만 현재 vendorId/eventId 범위 밖입니다.');
        out.row = { saleId: row.saleId, rowNumber: row.rowNumber, status: row.status, inScope: false };
        return out;
      }
      out.row = erpFieldB06J40_34_36_publicSaleRow_(row, ctx);
      return out;
    }
    out.warnings.push('saleId에 해당하는 판매 DRAFT가 없습니다: ' + ctx.saleId);
    return out;
  } catch (err2) {
    return erpFieldB06J40_34_36_fail_(out, [err2 && err2.message ? err2.message : String(err2)]);
  }
}

function erpFieldB06J40_34_36_futureContractInfo_(ctx, row) {
  row = row || {};
  return {
    candidateOnly: true,
    contractId: row.contractId || '(B06J41에서 생성 예정)',
    documentId: row.documentId || '(B06J41/SIGN 연결에서 생성 예정)',
    signStatus: row.signStatus || 'NOT_STARTED',
    pdfStatus: row.pdfStatus || 'NOT_CREATED',
    nextBuild: 'B06J41_CONTRACT_SIGN_LINK_SAFE',
    allowedNow: false,
    reason: 'B06J40은 판매 DRAFT 조회/계약전환 준비까지만 수행합니다.'
  };
}

function erpFieldB06J40_34_36_rowObject_(arr, hm, rowNumber) {
  function get(name) { var i = hm[name]; return i == null ? '' : arr[i]; }
  return {
    rowNumber: rowNumber,
    saleId: String(get('saleId') || ''), eventId: String(get('eventId') || ''), vendorId: String(get('vendorId') || ''), customerId: String(get('customerId') || ''),
    customerName: String(get('customerName') || ''), phone: String(get('phone') || ''), dong: String(get('dong') || ''), ho: String(get('ho') || ''), apartmentName: String(get('apartmentName') || ''),
    productId: String(get('productId') || ''), productName: String(get('productName') || ''), quantity: get('quantity'), unitPrice: get('unitPrice'), totalAmount: get('totalAmount'),
    depositAmount: get('depositAmount'), balanceAmount: get('balanceAmount'), paymentStructure: String(get('paymentStructure') || ''), paymentMethod: String(get('paymentMethod') || ''),
    contractId: String(get('contractId') || ''), documentId: String(get('documentId') || ''), signStatus: String(get('signStatus') || ''), pdfStatus: String(get('pdfStatus') || ''),
    status: String(get('status') || ''), statusReason: String(get('statusReason') || ''), createdAt: get('createdAt'), createdBy: String(get('createdBy') || ''), updatedAt: get('updatedAt'), updatedBy: String(get('updatedBy') || ''), logId: String(get('logId') || '')
  };
}

function erpFieldB06J40_34_36_publicSaleRow_(row, ctx) {
  return {
    rowNumber: row.rowNumber || '', saleId: row.saleId || '', customerId: row.customerId || '', customerName: row.customerName || '', phoneMasked: erpFieldB06J40_34_36_maskPhone_(row.phone || ''),
    dong: row.dong || '', ho: row.ho || '', apartmentName: row.apartmentName || '', productId: row.productId || '', productName: row.productName || '', quantity: row.quantity || '',
    unitPrice: Number(row.unitPrice || 0), unitPriceText: erpFieldB06J40_34_36_krw_(row.unitPrice || 0), totalAmount: Number(row.totalAmount || 0), totalAmountText: erpFieldB06J40_34_36_krw_(row.totalAmount || 0),
    depositAmountText: erpFieldB06J40_34_36_krw_(row.depositAmount || 0), balanceAmountText: erpFieldB06J40_34_36_krw_(row.balanceAmount || 0),
    paymentStructure: row.paymentStructure || '', paymentMethod: row.paymentMethod || '', contractId: row.contractId || '', documentId: row.documentId || '', signStatus: row.signStatus || '', pdfStatus: row.pdfStatus || '',
    status: row.status || '', statusReason: row.statusReason || '', createdAtText: erpFieldB06J40_34_36_dateText_(row.createdAt), createdBy: row.createdBy || '', updatedAtText: erpFieldB06J40_34_36_dateText_(row.updatedAt), updatedBy: row.updatedBy || '', logId: row.logId || '',
    inScope: String(row.vendorId || '') === ctx.vendorId && String(row.eventId || '') === ctx.eventId
  };
}

function erpFieldB06J40_34_36_normalize_(ctx) {
  ctx = ctx || {};
  if (typeof erpFieldB06J40_04_12_normalizeContext_ === 'function') return erpFieldB06J40_04_12_normalizeContext_(ctx);
  return {
    roleCode: String(ctx.roleCode || 'VIEWER').trim(), vendorId: String(ctx.vendorId || '').trim(), eventId: String(ctx.eventId || '').trim(), route: String(ctx.route || 'salesDetail').trim(), saleId: String(ctx.saleId || '').trim(), customerId: String(ctx.customerId || '').trim(), scopeType: 'VENDOR_BRANCH_USER_GROUP', hqFullAccess: false
  };
}
function erpFieldB06J40_34_36_guard_(ctx) { if (typeof erpFieldB06J40_04_12_guardContext_ === 'function') return erpFieldB06J40_04_12_guardContext_(ctx); var fatal = []; if (!ctx.vendorId) fatal.push('vendorId 누락'); if (!ctx.eventId) fatal.push('eventId 누락'); return { ok: fatal.length === 0, fatal: fatal }; }
function erpFieldB06J40_34_36_checkSalesSheet_() { var out = { ok: true, fatal: [], warnings: [] }; try { var master = erpFieldB06J40_34_36_openMaster_(); if (!master.ok) return erpFieldB06J40_34_36_fail_(out, master.fatal || ['MASTER 연결 실패']); var sheet = erpFieldB06J40_34_36_getSalesSheet_(master.spreadsheet); if (!sheet) return erpFieldB06J40_34_36_fail_(out, ['Sales 저장 대상 시트 없음']); var headers = erpFieldB06J40_34_36_getHeaders_(sheet); var hm = erpFieldB06J40_34_36_headerMap_(headers); var required = ['saleId','eventId','vendorId','customerId','productName','totalAmount','paymentStructure','paymentMethod','status','createdAt']; var missing = required.filter(function(h){ return hm[h] == null; }); out.ok = missing.length === 0; out.sheetName = sheet.getName(); out.lastRow = sheet.getLastRow(); out.missingHeaders = missing; if (missing.length) out.fatal.push('Sales 필수 헤더 누락: ' + missing.join(', ')); return out; } catch (err) { return erpFieldB06J40_34_36_fail_(out, [err && err.message ? err.message : String(err)]); } }
function erpFieldB06J40_34_36_openMaster_() { try { if (typeof erpFieldB06J40_31_33_openMaster_ === 'function') return erpFieldB06J40_31_33_openMaster_(); } catch (err) {} try { var setup = SpreadsheetApp.openById('17VMSpgSZCvIrUlgcw8yCNcnl8WQWo2IcRf5tDCcuJGM'); var sh = setup.getSheetByName('SystemConfig'); var vals = sh.getDataRange().getValues(); var id = ''; for (var r = 1; r < vals.length; r++) { var key = String(vals[r][0] || '').trim(); if (key === 'FEELHAUS_DB_MASTER_ID' || key === 'DB_MASTER_ID' || key === 'SPREADSHEET_ID') { id = String(vals[r][1] || '').trim(); if (id) break; } } if (!id) return { ok: false, fatal: ['MASTER ID 설정값 없음'] }; return { ok: true, spreadsheet: SpreadsheetApp.openById(id), masterId: id }; } catch (err2) { return { ok: false, fatal: [err2 && err2.message ? err2.message : String(err2)] }; } }
function erpFieldB06J40_34_36_getSalesSheet_(ss) { if (typeof erpFieldB06J40_31_33_getSalesSheet_ === 'function') return erpFieldB06J40_31_33_getSalesSheet_(ss); var names = ['ERP_판매관리','ERP_Sales','Sales']; for (var i=0;i<names.length;i++){ var sh=ss.getSheetByName(names[i]); if(sh) return sh; } return null; }
function erpFieldB06J40_34_36_getHeaders_(sheet) { var c = Math.max(1, sheet.getLastColumn()); return sheet.getRange(1,1,1,c).getValues()[0].map(function(h){ return String(h || '').trim(); }); }
function erpFieldB06J40_34_36_headerMap_(headers) { var m = {}; (headers || []).forEach(function(h,i){ if(h && m[h] == null) m[h]=i; }); return m; }
function erpFieldB06J40_34_36_fail_(out, fatal) { out.ok = false; out.fatal = (out.fatal || []).concat(fatal || []); return out; }
function erpFieldB06J40_34_36_templateCheck_() { try { HtmlService.createTemplateFromFile('P_SaleDetail'); return { ok: true }; } catch (err) { return { ok: false, fatal: [err.message] }; } }
function erpFieldB06J40_34_36_requiredFunctions_() { var fns = ['erpFieldB06J40_34_36_renderSalesDetailHtml','erpFieldB06J40_34_36_getSaleById_']; var missing = fns.filter(function(f){ return typeof this[f] !== 'function'; }, this); return { ok: missing.length === 0, functions: fns, missing: missing, fatal: missing.length ? ['필수 함수 누락: ' + missing.join(', ')] : [] }; }
function erpFieldB06J40_34_36_safetyCheck_() { return { ok: true, readOnly: true, noSheetWrite: true, noSave: true, noUpdateDelete: true, noContractCreate: true, noDocumentCreate: true, noSettlement: true, noExternalIntegration: true }; }
function erpFieldB06J40_34_36_result_(label) { return { ok: true, build: FIELD_SALES_DETAIL_BUILD, moduleCode: 'ERP_FIELD', label: label, checkedAt: new Date().toISOString(), fatal: [], warnings: [], checks: {} }; }
function erpFieldB06J40_34_36_finish_(result, logOutput) { Object.keys(result.checks || {}).forEach(function(k){ var c=result.checks[k]; if(c && c.fatal && c.fatal.length) result.fatal=result.fatal.concat(c.fatal.map(function(m){ return k + ': ' + m; })); if(c && c.warnings && c.warnings.length) result.warnings=result.warnings.concat(c.warnings.map(function(m){ return k + ': ' + m; })); }); result.ok = result.fatal.length === 0; if(logOutput){ Logger.log('======================================================'); Logger.log(JSON.stringify(result,null,2)); Logger.log('======================================================'); } return result; }
function erpFieldB06J40_34_36_krw_(v) { var n = Number(String(v || '0').replace(/,/g,'')); if(isNaN(n)) n=0; return n.toLocaleString('ko-KR'); }
function erpFieldB06J40_34_36_maskPhone_(p) { var s=String(p||''); var d=s.replace(/\D/g,''); if(d.length>=8) return d.substring(0,3)+'-****-'+d.substring(d.length-4); return s ? '***' : ''; }
function erpFieldB06J40_34_36_dateText_(d) { try { return d ? Utilities.formatDate(new Date(d), Session.getScriptTimeZone() || 'Asia/Seoul', 'yyyy-MM-dd HH:mm') : ''; } catch(err){ return String(d || ''); } }
function erpFieldB06J40_34_36_webAppUrl_() { try { return ScriptApp.getService().getUrl() || ''; } catch(err){ return ''; } }
function erpFieldB06J40_34_36_roleName_(roleCode) { var map={VENDOR_OWNER:'업체대표',VENDOR_MANAGER:'업체관리자',STAFF_SALES:'영업직원'}; return map[roleCode] || roleCode || '-'; }
function erpFieldB06J40_34_36_urls_(ctx) { var base=erpFieldB06J40_34_36_webAppUrl_(); var common='roleCode='+encodeURIComponent(ctx.roleCode)+'&vendorId='+encodeURIComponent(ctx.vendorId)+'&eventId='+encodeURIComponent(ctx.eventId); return { salesInput: base+'?'+common+'&route=sales&customerId='+encodeURIComponent(ctx.customerId||''), customerLookup: base+'?'+common+'&route=customerLookup', salesRecent: base+'?'+common+'&route=salesRecent&customerId='+encodeURIComponent(ctx.customerId||''), salesDetail: base+'?'+common+'&route=salesDetail&saleId='+encodeURIComponent(ctx.saleId||'')+'&customerId='+encodeURIComponent(ctx.customerId||'') }; }
function erpFieldB06J40_34_36_escape_(v) { return String(v == null ? '' : v).replace(/[&<>"']/g, function(m){ return ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'})[m]; }); }


/* ===== SaleBind.js ===== */
/**
 * build: ERP_B06J40_13_15_SALES_INPUT_BIND_SAFE_UPLOAD
 * module: ERP_FIELD
 * purpose:
 * - Sales input bind before DRAFT save
 * - Bind selected customerId from customer lookup to sales entry screen
 * - Build selected customer snapshot, phone/dong/ho display, product/payment precheck
 * safety:
 * - no sheet write / no save / no update / no delete / no settlement / no external integration
 */

var FIELD_SALES_INPUT_BIND_BUILD = 'ERP_B06J40_13_15_SALES_INPUT_BIND_SAFE_UPLOAD_WITH_RECENT_B06J40_31_33';

function erpB06J40_13_15_preflight() {
  var result = erpFieldB06J40_13_15_result_('preflight');
  result.checks.requiredFunctions = erpFieldB06J40_13_15_checkRequiredFunctions_();
  result.checks.templateAvailable = erpFieldB06J40_13_15_checkTemplate_();
  result.checks.customerSheetReadable = erpFieldB06J40_13_15_checkCustomerSheet_();
  result.checks.routeSamples = erpFieldB06J40_13_15_checkRouteSamples_();
  result.checks.noWriteGuard = erpFieldB06J40_13_15_checkNoWriteGuard_();
  result.checks.safety = erpFieldB06J40_13_15_safetyCheck_();
  return erpFieldB06J40_13_15_finish_(result, true);
}

function erpB06J40_13_15_autoRunSafe() {
  var result = erpFieldB06J40_13_15_result_('autoRunSafe');
  result.checks.preflight = erpB06J40_13_15_preflight();
  result.checks.blankInputBind = erpFieldB06J40_13_15_buildSalesInputBindViewModel_({
    roleCode: 'VENDOR_MANAGER', vendorId: 'VND-20260502202158-505', eventId: 'EVT-20260502202016-197', route: 'sales', userEmail: 'manager@example.com'
  });
  result.checks.sampleCustomerBind = erpFieldB06J40_13_15_buildSalesInputBindViewModel_({
    roleCode: 'VENDOR_MANAGER', vendorId: 'VND-20260502202158-505', eventId: 'EVT-20260502202016-197', route: 'sales', customerId: 'CUS-SAMPLE',
    productName: '테스트 품목', quantity: '1', unitPrice: '100000', depositAmount: '10000', paymentStructure: 'COMPANY_ALL', paymentMethod: 'CARD', draftCheck: 'Y'
  });
  result.checks.staffSalesBind = erpFieldB06J40_13_15_buildSalesInputBindViewModel_({
    roleCode: 'STAFF_SALES', vendorId: 'VND-20260502202158-505', eventId: 'EVT-20260502202016-197', route: 'sales', customerId: 'CUS-SAMPLE',
    productName: '테스트 품목', quantity: '1', unitPrice: '100000', paymentStructure: 'COMPANY_ALL', paymentMethod: 'CARD', draftCheck: 'Y'
  });
  result.checks.viewerBlocked = erpFieldB06J40_13_15_buildSalesInputBindViewModel_({
    roleCode: 'VIEWER', vendorId: 'VND-20260502202158-505', eventId: 'EVT-20260502202016-197', route: 'sales', customerId: 'CUS-SAMPLE'
  });
  result.checks.missingVendorBlocked = erpFieldB06J40_13_15_buildSalesInputBindViewModel_({
    roleCode: 'VENDOR_MANAGER', vendorId: '', eventId: 'EVT-20260502202016-197', route: 'sales', customerId: 'CUS-SAMPLE'
  });

  Object.keys(result.checks).forEach(function (k) {
    var c = result.checks[k];
    var expectedBlock = (k === 'viewerBlocked' || k === 'missingVendorBlocked');
    if (!c) {
      result.ok = false;
      result.fatal.push(k + ': 결과 없음');
      return;
    }
    if (expectedBlock) {
      if (c.ok !== false) {
        result.ok = false;
        result.fatal.push(k + ': 차단 기대 테스트가 차단되지 않음');
      }
    } else if (c.ok === false) {
      result.ok = false;
      result.fatal.push(k + ': 정상 기대 테스트 실패');
    }
    if (!expectedBlock && c.fatal && c.fatal.length) result.fatal = result.fatal.concat(c.fatal.map(function (m) { return k + ': ' + m; }));
    if (c.warnings && c.warnings.length) result.warnings = result.warnings.concat(c.warnings.map(function (m) { return k + ': ' + m; }));
  });
  return erpFieldB06J40_13_15_finish_(result, true);
}

function erpFieldB06J40_13_15_renderSalesInputBindHtml(ctx) {
  var vm = erpFieldB06J40_13_15_buildSalesInputBindViewModel_(ctx || {});
  if (!vm.ok && vm.blocked === true) {
    if (typeof erpFieldB06J40_04_12_renderBlocked_ === 'function') return erpFieldB06J40_04_12_renderBlocked_(vm.context || ctx || {}, vm.fatal || []);
    return HtmlService.createHtmlOutput('<pre>' + erpFieldB06J40_13_15_escape_(JSON.stringify(vm.fatal || [], null, 2)) + '</pre>');
  }
  var t = HtmlService.createTemplateFromFile('P_SaleBind');
  t.vm = vm;
  return t.evaluate().setTitle('판매등록 입력 연결').setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL);
}

function erpFieldB06J40_13_15_buildSalesInputBindViewModel_(ctx) {
  ctx = erpFieldB06J40_13_15_normalize_(ctx || {});
  var guard = erpFieldB06J40_13_15_guard_(ctx);
  if (!guard.ok) return { ok: false, blocked: true, fatal: guard.fatal, warnings: [], context: ctx };

  var vendor = erpFieldB06J40_13_15_lookupEntitySafe_('ERP_업체관리', 'vendorId', ctx.vendorId, ['vendorName', 'name', '업체명', 'companyName']);
  var event = erpFieldB06J40_13_15_lookupEntitySafe_('ERP_행사관리', 'eventId', ctx.eventId, ['eventName', 'name', '행사명', 'title']);
  var selectedCustomer = erpFieldB06J40_13_15_lookupCustomerById_(ctx.customerId);
  var snapshot = erpFieldB06J40_13_15_buildCustomerSnapshot_(selectedCustomer, ctx);
  var validation = erpFieldB06J40_13_15_validateInput_(ctx, snapshot);
  var amounts = erpFieldB06J40_13_15_calculateAmounts_(ctx);
  var url = erpFieldB06J40_13_15_webAppUrl_();
  var precheck = null;
  try {
    if (typeof erpB06J40_04_12_preflight === 'function') precheck = erpB06J40_04_12_preflight();
  } catch (err) {
    precheck = { ok: false, fatal: [err && err.message ? err.message : String(err)], warnings: [] };
  }

  return {
    ok: true,
    build: FIELD_SALES_INPUT_BIND_BUILD,
    moduleCode: 'ERP_FIELD',
    checkedAt: new Date().toISOString(),
    fatal: [],
    warnings: validation.warnings || [],
    webAppUrl: url,
    context: ctx,
    vendor: vendor,
    event: event,
    selectedCustomer: snapshot,
    validation: validation,
    calculated: amounts,
    precheckSummary: erpFieldB06J40_13_15_summarizePrecheck_(precheck),
    page: {
      badge: 'B06J40-13_15 SAFE : SALES INPUT BIND',
      title: '판매등록 입력 연결',
      subtitle: '고객조회 선택값을 판매등록 화면에 반영하고 DRAFT 저장 전 입력 안정성을 점검합니다.',
      roleName: erpFieldB06J40_13_15_roleName_(ctx.roleCode)
    },
    safety: {
      inputBindOnly: true,
      selectedCustomerSnapshotOnly: true,
      noSheetWrite: true,
      noAppendOperation: true,
      noCellUpdateOperation: true,
      noSaveExecution: true,
      draftSaveBlocked: true,
      noUpdateExecution: true,
      noDeleteExecution: true,
      settlementExecutionBlocked: true,
      externalIntegrationBlocked: true,
      vendorIndependentDbBlocked: true,
      vendorAsBranchUserGroup: true,
      headerMapBased: true,
      columnIndexFixed: false
    },
    blockedActions: [
      { label: 'DRAFT 저장 차단', reason: '입력 기준 통과 후 B06J40-28~30 DRAFT 저장 경로에서만 저장됩니다.' },
      { label: '계약 생성 차단', reason: 'B06J41 계약/SIGN 연결 단계에서 처리' },
      { label: '정산 반영 차단', reason: '정산 정책/승인 전 실행 금지' },
      { label: '외부연동 차단', reason: 'PG/메일/캘린더/폼/카페 연동 실행 없음' }
    ],
    recentSales: (typeof erpFieldB06J40_31_33_getRecentSales_ === 'function') ? erpFieldB06J40_31_33_getRecentSales_(ctx, 5) : { ok: true, rows: [], count: 0, totalVendorEventCount: 0, customerCount: 0, warnings: ['최근판매 모듈 미탑재'] },
    urls: erpFieldB06J40_13_15_urls_(url, ctx)
  };
}

function erpFieldB06J40_13_15_normalize_(ctx) {
  function s(v) { return String(v == null ? '' : v).trim(); }
  var preset = String((ctx && (ctx.dryRunPreset || ctx.testPreset)) || '').toUpperCase() === 'Y';
  return {
    roleCode: s(ctx.roleCode || 'VIEWER'),
    vendorId: s(ctx.vendorId),
    eventId: s(ctx.eventId),
    route: s(ctx.route || 'sales'),
    keyword: s(ctx.keyword),
    customerId: s(ctx.customerId),
    userEmail: s(ctx.userEmail),
    productId: s(ctx.productId),
    productName: s(ctx.productName || (preset ? 'TEST-드라이런상품' : '')),
    quantity: s(ctx.quantity || '1'),
    unitPrice: s(ctx.unitPrice || (preset ? '100000' : '0')),
    totalAmount: s(ctx.totalAmount || '0'),
    depositAmount: s(ctx.depositAmount || (preset ? '10000' : '0')),
    balanceAmount: s(ctx.balanceAmount || '0'),
    discountAmount: s(ctx.discountAmount || '0'),
    voucherAmount: s(ctx.voucherAmount || '0'),
    benefitAmount: s(ctx.benefitAmount || '0'),
    paymentStructure: s(ctx.paymentStructure || (preset ? 'COMPANY_ALL' : '')),
    paymentMethod: s(ctx.paymentMethod || (preset ? 'CASH' : '')),
    installDueDate: s(ctx.installDueDate),
    memberType: s(ctx.memberType),
    cardPaymentIds: s(ctx.cardPaymentIds),
    draftCheck: s(ctx.draftCheck || (preset ? 'Y' : '')),
    dryRunPreset: preset ? 'Y' : '',
    scopeType: 'VENDOR_BRANCH_USER_GROUP',
    hqFullAccess: false
  };
}

function erpFieldB06J40_13_15_guard_(ctx) {
  var fatal = [];
  var allowedRoles = { VENDOR_OWNER: true, VENDOR_MANAGER: true, STAFF_SALES: true };
  if (!ctx.vendorId) fatal.push('vendorId 누락');
  if (!ctx.eventId) fatal.push('eventId 누락');
  if (!allowedRoles[ctx.roleCode]) fatal.push('판매등록 입력 차단: roleCode=' + ctx.roleCode + ' 권한 없음');
  if (ctx.route !== 'sales') fatal.push('판매등록 입력 차단: route=' + ctx.route + ' 허용 안 됨');
  return { ok: fatal.length === 0, fatal: fatal };
}

function erpFieldB06J40_13_15_lookupCustomerById_(customerId) {
  var result = { found: false, customerId: customerId || '', fatal: [], warnings: [] };
  if (!customerId) return result;
  try {
    var master = erpFieldB06J40_13_15_getMaster_();
    if (!master.ok) {
      result.fatal = master.fatal || ['MASTER 연결 실패'];
      return result;
    }
    var sheet = master.spreadsheet.getSheetByName('ERP_고객관리');
    if (!sheet) {
      result.fatal.push('ERP_고객관리 시트 없음');
      return result;
    }
    var values = sheet.getDataRange().getValues();
    if (!values.length) {
      result.fatal.push('ERP_고객관리 헤더 없음');
      return result;
    }
    var hm = erpFieldB06J40_13_15_headerMap_(values[0]);
    for (var i = 1; i < values.length; i++) {
      var row = values[i];
      var id = erpFieldB06J40_13_15_getByNames_(row, hm, ['customerId', '고객ID', '고객id']);
      if (String(id || '') === String(customerId || '')) {
        result.found = true;
        result.rowNumber = i + 1;
        result.vendorId = erpFieldB06J40_13_15_getByNames_(row, hm, ['vendorId', '업체ID', '업체id']);
        result.eventId = erpFieldB06J40_13_15_getByNames_(row, hm, ['eventId', '행사ID', '행사id']);
        result.name = erpFieldB06J40_13_15_getByNames_(row, hm, ['name', 'customerName', '고객명', '성명']);
        result.phone = erpFieldB06J40_13_15_getByNames_(row, hm, ['phone', 'mobile', 'tel', '전화번호', '연락처']);
        result.dong = erpFieldB06J40_13_15_getByNames_(row, hm, ['dong', '동']);
        result.ho = erpFieldB06J40_13_15_getByNames_(row, hm, ['ho', '호']);
        result.apartmentName = erpFieldB06J40_13_15_getByNames_(row, hm, ['apartmentName', 'aptName', '아파트명', '단지명']);
        result.address = erpFieldB06J40_13_15_getByNames_(row, hm, ['address', '주소']);
        result.memberType = erpFieldB06J40_13_15_getByNames_(row, hm, ['memberType', '회원구분', '고객유형']);
        result.status = erpFieldB06J40_13_15_getByNames_(row, hm, ['status', '상태']);
        result.saleId = erpFieldB06J40_13_15_getByNames_(row, hm, ['saleId', '판매ID']);
        result.contractId = erpFieldB06J40_13_15_getByNames_(row, hm, ['contractId', '계약ID']);
        break;
      }
    }
  } catch (err) {
    result.fatal.push(err && err.message ? err.message : String(err));
  }
  return result;
}

function erpFieldB06J40_13_15_buildCustomerSnapshot_(customer, ctx) {
  var snapshot = {
    selected: !!(customer && customer.found),
    found: !!(customer && customer.found),
    customerId: ctx.customerId || '',
    name: '',
    phone: '',
    phoneMasked: '',
    phoneNormalized: '',
    dong: '',
    ho: '',
    apartmentName: '',
    address: '',
    memberType: '',
    status: '',
    vendorId: '',
    eventId: '',
    vendorMatch: false,
    eventMatch: false,
    scopeMatch: false,
    source: ctx.customerId ? 'CUSTOMER_LOOKUP_SELECTED' : 'NOT_SELECTED',
    warnings: [],
    fatal: []
  };
  if (!ctx.customerId) {
    snapshot.warnings.push('customerId가 아직 선택되지 않았습니다. 고객조회에서 고객을 선택하세요.');
    return snapshot;
  }
  if (!customer || !customer.found) {
    snapshot.fatal.push('선택 customerId를 ERP_고객관리에서 찾지 못했습니다: ' + ctx.customerId);
    return snapshot;
  }
  snapshot.name = customer.name || '';
  snapshot.phone = customer.phone || '';
  snapshot.phoneMasked = erpFieldB06J40_13_15_maskPhone_(customer.phone || '');
  snapshot.phoneNormalized = erpFieldB06J40_13_15_normalizePhone_(customer.phone || '');
  snapshot.dong = customer.dong || '';
  snapshot.ho = customer.ho || '';
  snapshot.apartmentName = customer.apartmentName || '';
  snapshot.address = customer.address || '';
  snapshot.memberType = customer.memberType || '';
  snapshot.status = customer.status || '';
  snapshot.vendorId = customer.vendorId || '';
  snapshot.eventId = customer.eventId || '';
  snapshot.vendorMatch = String(customer.vendorId || '') === String(ctx.vendorId || '');
  snapshot.eventMatch = String(customer.eventId || '') === String(ctx.eventId || '');
  snapshot.scopeMatch = snapshot.vendorMatch && snapshot.eventMatch;
  if (!snapshot.vendorMatch) snapshot.fatal.push('선택 고객 vendorId가 현재 업체와 일치하지 않습니다.');
  if (!snapshot.eventMatch) snapshot.fatal.push('선택 고객 eventId가 현재 행사와 일치하지 않습니다.');
  if (!snapshot.phoneNormalized) snapshot.warnings.push('선택 고객 전화번호 정규화 값이 비어 있습니다.');
  return snapshot;
}

function erpFieldB06J40_13_15_validateInput_(ctx, snapshot) {
  var errors = [];
  var warnings = [];
  var submitted = String(ctx.draftCheck || '').toUpperCase() === 'Y';
  if (!submitted) warnings.push('아직 입력 점검 실행 전입니다. 값 입력 후 입력 안정화 점검을 실행하세요.');
  if (!ctx.customerId) errors.push('customerId 미선택');
  if (snapshot && snapshot.fatal && snapshot.fatal.length) errors = errors.concat(snapshot.fatal);
  if (!ctx.productName && !ctx.productId) errors.push('품목명 또는 productId 미입력');
  var qty = erpFieldB06J40_13_15_toNumber_(ctx.quantity);
  var unit = erpFieldB06J40_13_15_toNumber_(ctx.unitPrice);
  if (!(qty > 0)) errors.push('수량은 1 이상이어야 합니다.');
  if (!(unit >= 0)) errors.push('단가는 0 이상 숫자여야 합니다.');
  if (!ctx.paymentStructure) errors.push('결제구조 미선택');
  if (ctx.paymentStructure && ['COMPANY_ALL', 'MIXED', 'VENDOR_DIRECT'].indexOf(ctx.paymentStructure) < 0) errors.push('결제구조 허용값 아님');
  if (!ctx.paymentMethod) warnings.push('결제수단 미선택: CARD/CASH/BANK/VOUCHER/MIXED 중 선택 필요');
  return {
    ok: errors.length === 0,
    submitted: submitted,
    errors: errors,
    warnings: warnings,
    readyForDraftSaveNextStep: errors.length === 0,
    saveStillBlocked: true,
    note: 'B06J40-13~15는 입력 연결/스냅샷 단계이며 실제 DRAFT 저장은 열지 않습니다.'
  };
}

function erpFieldB06J40_13_15_calculateAmounts_(ctx) {
  var qty = erpFieldB06J40_13_15_toNumber_(ctx.quantity || 0);
  var unit = erpFieldB06J40_13_15_toNumber_(ctx.unitPrice || 0);
  var inputTotal = erpFieldB06J40_13_15_toNumber_(ctx.totalAmount || 0);
  var lineAmount = qty * unit;
  var total = inputTotal > 0 ? inputTotal : lineAmount;
  var deposit = erpFieldB06J40_13_15_toNumber_(ctx.depositAmount || 0);
  var discount = erpFieldB06J40_13_15_toNumber_(ctx.discountAmount || 0);
  var voucher = erpFieldB06J40_13_15_toNumber_(ctx.voucherAmount || 0);
  var benefit = erpFieldB06J40_13_15_toNumber_(ctx.benefitAmount || 0);
  var balance = Math.max(0, total - deposit - discount - voucher - benefit);
  return {
    quantity: qty,
    unitPrice: unit,
    lineAmount: lineAmount,
    totalAmount: total,
    depositAmount: deposit,
    discountAmount: discount,
    voucherAmount: voucher,
    benefitAmount: benefit,
    balanceAmount: balance,
    totalAmountText: erpFieldB06J40_13_15_money_(total),
    depositAmountText: erpFieldB06J40_13_15_money_(deposit),
    balanceAmountText: erpFieldB06J40_13_15_money_(balance)
  };
}

function erpFieldB06J40_13_15_checkRequiredFunctions_() {
  var required = ['doGet', 'erpFieldB06J40_13_15_renderSalesInputBindHtml', 'erpFieldB06J40_13_15_buildSalesInputBindViewModel_'];
  var missing = [];
  required.forEach(function (name) { if (typeof this[name] !== 'function') missing.push(name); });
  return { ok: missing.length === 0, fatal: missing.length ? ['필수 함수 누락: ' + missing.join(', ')] : [], warnings: [], required: required, missing: missing };
}

function erpFieldB06J40_13_15_checkTemplate_() {
  try {
    HtmlService.createTemplateFromFile('P_SaleBind');
    return { ok: true, fatal: [], warnings: [], template: 'P_SaleBind' };
  } catch (err) {
    return { ok: false, fatal: [err && err.message ? err.message : String(err)], warnings: [], template: 'P_SaleBind' };
  }
}

function erpFieldB06J40_13_15_checkCustomerSheet_() {
  try {
    var master = erpFieldB06J40_13_15_getMaster_();
    if (!master.ok) return master;
    var sheet = master.spreadsheet.getSheetByName('ERP_고객관리');
    if (!sheet) return { ok: false, fatal: ['ERP_고객관리 시트 없음'], warnings: [] };
    var values = sheet.getDataRange().getValues();
    var hm = values.length ? erpFieldB06J40_13_15_headerMap_(values[0]) : {};
    var required = ['customerId', 'vendorId', 'eventId'];
    var missing = required.filter(function (h) { return hm[h] == null; });
    return { ok: missing.length === 0, fatal: missing.map(function (m) { return 'ERP_고객관리 필수 헤더 누락: ' + m; }), warnings: [], sheetName: 'ERP_고객관리', lastRow: sheet.getLastRow(), lastCol: sheet.getLastColumn(), headerMapBased: true, columnIndexFixed: false };
  } catch (err) {
    return { ok: false, fatal: [err && err.message ? err.message : String(err)], warnings: [] };
  }
}

function erpFieldB06J40_13_15_checkRouteSamples_() {
  var a = erpFieldB06J40_13_15_buildSalesInputBindViewModel_({ roleCode: 'VENDOR_MANAGER', vendorId: 'VND-SAMPLE', eventId: 'EVT-SAMPLE', route: 'sales' });
  var b = erpFieldB06J40_13_15_buildSalesInputBindViewModel_({ roleCode: 'VIEWER', vendorId: 'VND-SAMPLE', eventId: 'EVT-SAMPLE', route: 'sales' });
  return { ok: a.ok === true && b.ok === false, fatal: (a.ok === true && b.ok === false) ? [] : ['route sample guard 실패'], warnings: [], vendorManagerOk: a.ok, viewerBlocked: b.ok === false };
}

function erpFieldB06J40_13_15_checkNoWriteGuard_() {
  return { ok: true, fatal: [], warnings: [], noSheetWrite: true, noAppendRow: true, noSetValue: true, noSaveFunctionOpened: true };
}

function erpFieldB06J40_13_15_safetyCheck_() {
  return { ok: true, fatal: [], warnings: [], noSheetWrite: true, noSaveExecution: true, noUpdateExecution: true, noDeleteExecution: true, settlementExecutionBlocked: true, externalIntegrationBlocked: true, vendorIndependentDbBlocked: true, vendorAsBranchUserGroup: true };
}

function erpFieldB06J40_13_15_summarizePrecheck_(precheck) {
  if (!precheck) return { ok: false, readyForDraftSave: false, fatalCount: 0, warningCount: 0, note: 'B06J40-04~12 프리체크 결과 없음' };
  return { ok: precheck.ok === true, readyForDraftSave: precheck.readiness && precheck.readiness.readyForDraftSave === true, fatalCount: (precheck.fatal || []).length, warningCount: (precheck.warnings || []).length, note: '04~12 판매등록 전체 기준표 참조' };
}

function erpFieldB06J40_13_15_urls_(url, ctx) {
  var base = url || '';
  var common = '?roleCode=' + encodeURIComponent(ctx.roleCode) + '&vendorId=' + encodeURIComponent(ctx.vendorId) + '&eventId=' + encodeURIComponent(ctx.eventId);
  return {
    customerLookup: base + common + '&route=customerLookup&keyword=' + encodeURIComponent(ctx.keyword || ''),
    salesBase: base + common + '&route=sales',
    salesWithCustomer: base + common + '&route=sales&customerId=' + encodeURIComponent(ctx.customerId || ''),
    salesRecent: base + common + '&route=salesRecent&customerId=' + encodeURIComponent(ctx.customerId || '')
  };
}

function erpFieldB06J40_13_15_lookupEntitySafe_(sheetName, idHeader, idValue, nameHeaders) {
  try {
    if (typeof erpFieldB06J39_04_09_lookupEntity_ === 'function') return erpFieldB06J39_04_09_lookupEntity_(sheetName, idHeader, idValue, nameHeaders);
  } catch (e) {}
  return { id: idValue || '', name: idValue ? '(명칭 확인 대기)' : '', found: false };
}

function erpFieldB06J40_13_15_getMaster_() {
  try {
    if (typeof erpFieldB06J39_04_09_getMaster_ === 'function') return erpFieldB06J39_04_09_getMaster_();
  } catch (e) {}
  try {
    var setup = SpreadsheetApp.openById('17VMSpgSZCvIrUlgcw8yCNcnl8WQWo2IcRf5tDCcuJGM');
    var sh = setup.getSheetByName('SystemConfig');
    if (!sh) return { ok: false, fatal: ['SystemConfig 시트 없음'], warnings: [] };
    var vals = sh.getDataRange().getValues();
    var map = {};
    vals.slice(1).forEach(function (r) { if (r[0]) map[String(r[0]).trim()] = r[1]; });
    var id = map.FEELHAUS_DB_MASTER_ID || map.DB_MASTER_ID || map.SPREADSHEET_ID;
    if (!id) return { ok: false, fatal: ['MASTER ID 설정 없음'], warnings: [] };
    return { ok: true, fatal: [], warnings: [], spreadsheet: SpreadsheetApp.openById(id), masterId: id };
  } catch (err) {
    return { ok: false, fatal: [err && err.message ? err.message : String(err)], warnings: [] };
  }
}

function erpFieldB06J40_13_15_headerMap_(headers) {
  var m = {};
  (headers || []).forEach(function (h, i) { if (String(h || '').trim()) m[String(h).trim()] = i; });
  return m;
}

function erpFieldB06J40_13_15_getByNames_(row, hm, names) {
  for (var i = 0; i < names.length; i++) {
    var idx = hm[names[i]];
    if (idx != null) return row[idx] == null ? '' : row[idx];
  }
  return '';
}

function erpFieldB06J40_13_15_webAppUrl_() {
  try { var u = ScriptApp.getService().getUrl(); if (u) return u; } catch (e) {}
  try {
    if (typeof erpFieldB06J39_04_09_getConfig_ === 'function') {
      var c = erpFieldB06J39_04_09_getConfig_();
      if (c && c.configMap && c.configMap.ERP_FIELD_WEBAPP_URL) return c.configMap.ERP_FIELD_WEBAPP_URL;
    }
  } catch (err) {}
  return 'https://script.google.com/macros/s/AKfycbzoFVrXuPH3cPHDdm5O-1K6mF0UAuVjeOu26ZFvIZlD_px_wAXJKwzApqfbgMAfTwJQ0g/exec';
}

function erpFieldB06J40_13_15_result_(label) {
  return { ok: true, build: FIELD_SALES_INPUT_BIND_BUILD, moduleCode: 'ERP_FIELD', label: label, checkedAt: new Date().toISOString(), fatal: [], warnings: [], checks: {} };
}

function erpFieldB06J40_13_15_finish_(result, logOutput) {
  Object.keys(result.checks || {}).forEach(function (k) {
    var c = result.checks[k];
    if (c && c.ok === false) result.ok = false;
    if (c && c.fatal && c.fatal.length) result.fatal = result.fatal.concat(c.fatal.map(function (m) { return k + ': ' + m; }));
    if (c && c.warnings && c.warnings.length) result.warnings = result.warnings.concat(c.warnings.map(function (m) { return k + ': ' + m; }));
  });
  result.ok = result.fatal.length === 0;
  if (logOutput) {
    Logger.log('======================================================');
    Logger.log(JSON.stringify(result, null, 2));
    Logger.log('======================================================');
  }
  return result;
}

function erpFieldB06J40_13_15_roleName_(roleCode) {
  var map = { VENDOR_OWNER: '업체대표', VENDOR_MANAGER: '업체관리자', STAFF_SALES: '영업직원', STAFF_INSTALL: '설치담당', STAFF_AS: 'A/S담당', VIEWER: '조회전용' };
  return map[roleCode] || roleCode || '';
}

function erpFieldB06J40_13_15_toNumber_(v) {
  var n = Number(String(v == null ? '' : v).replace(/,/g, '').trim());
  return isNaN(n) ? 0 : n;
}

function erpFieldB06J40_13_15_money_(n) {
  n = erpFieldB06J40_13_15_toNumber_(n);
  return String(Math.round(n)).replace(/\B(?=(\d{3})+(?!\d))/g, ',');
}

function erpFieldB06J40_13_15_normalizePhone_(phone) {
  var d = String(phone || '').replace(/\D/g, '');
  if (!d) return '';
  if (d.length === 8 && d.indexOf('010') !== 0) d = '010' + d;
  if (d.length === 10 && d.indexOf('10') === 0) d = '0' + d;
  return d;
}

function erpFieldB06J40_13_15_maskPhone_(phone) {
  var d = erpFieldB06J40_13_15_normalizePhone_(phone);
  if (d.length < 7) return phone || '';
  if (d.length === 11) return d.substring(0, 3) + '-****-' + d.substring(7);
  return d.substring(0, 3) + '-****';
}

function erpFieldB06J40_13_15_escape_(v) {
  return String(v == null ? '' : v).replace(/[&<>\"]/g, function (s) {
    return ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' })[s];
  });
}


/* ===== SaleEntry.js ===== */
/**
 * build: ERP_B06J40_01_03_FIELD_SALES_ENTRY_SCREEN_SAFE_UPLOAD
 * module: ERP_FIELD
 * purpose:
 * - FIELD sales entry screen first safe entry
 * - customer select area / product line placeholder / payment-contract placeholder
 * - keep context vendorId/eventId/roleCode/userEmail
 * safety:
 * - no sheet write / no save / no update / no delete / no settlement / no external integration
 * - buttons are blocked until DRAFT save build
 */

var FIELD_SALES_ENTRY_BUILD = 'ERP_B06J40_01_03_FIELD_SALES_ENTRY_SCREEN_SAFE_UPLOAD';

function erpB06J40_01_03_preflight() {
  var result = {
    ok: true,
    build: FIELD_SALES_ENTRY_BUILD,
    moduleCode: 'ERP_FIELD',
    checkedAt: new Date().toISOString(),
    fatal: [],
    warnings: [],
    checks: {}
  };

  result.checks.requiredFunctions = erpFieldB06J40_01_03_checkRequiredFunctions_();
  result.checks.templateAvailable = erpFieldB06J40_01_03_checkTemplate_();
  result.checks.customerDependency = erpFieldB06J40_01_03_checkCustomerDependency_();
  result.checks.routeSamples = erpFieldB06J40_01_03_checkRouteSamples_();
  result.checks.writeBlocked = erpFieldB06J40_01_03_checkWriteBlocked_();
  result.checks.safety = { ok: true, fatal: [], warnings: [], noSheetWrite: true, noSaveExecution: true, noSettlementExecution: true, noExternalIntegration: true };

  Object.keys(result.checks).forEach(function (k) {
    var c = result.checks[k];
    if (!c || c.ok !== true) result.ok = false;
    if (c && c.fatal && c.fatal.length) {
      result.fatal = result.fatal.concat(c.fatal.map(function (m) { return k + ': ' + m; }));
    }
    if (c && c.warnings && c.warnings.length) {
      result.warnings = result.warnings.concat(c.warnings.map(function (m) { return k + ': ' + m; }));
    }
  });

  Logger.log('======================================================');
  Logger.log(JSON.stringify(result, null, 2));
  Logger.log('======================================================');
  return result;
}

function erpB06J40_01_03_autoRunSafe() {
  var result = {
    ok: true,
    build: FIELD_SALES_ENTRY_BUILD,
    moduleCode: 'ERP_FIELD',
    checkedAt: new Date().toISOString(),
    fatal: [],
    warnings: [],
    checks: {}
  };

  result.checks.preflight = erpB06J40_01_03_preflight();
  result.checks.salesVendorOwner = erpFieldB06J40_01_03_buildSalesViewModel_({
    roleCode: 'VENDOR_OWNER', vendorId: 'VND-20260502202158-505', eventId: 'EVT-20260502202016-197', route: 'sales', userEmail: 'owner@example.com'
  });
  result.checks.salesVendorManager = erpFieldB06J40_01_03_buildSalesViewModel_({
    roleCode: 'VENDOR_MANAGER', vendorId: 'VND-20260502202158-505', eventId: 'EVT-20260502202016-197', route: 'sales', userEmail: 'manager@example.com'
  });
  result.checks.salesStaffSales = erpFieldB06J40_01_03_buildSalesViewModel_({
    roleCode: 'STAFF_SALES', vendorId: 'VND-20260502202158-505', eventId: 'EVT-20260502202016-197', route: 'sales', userEmail: 'sales@example.com'
  });
  result.checks.viewerBlockedExpected = erpFieldB06J40_01_03_buildSalesViewModel_({
    roleCode: 'VIEWER', vendorId: 'VND-20260502202158-505', eventId: 'EVT-20260502202016-197', route: 'sales', userEmail: 'viewer@example.com'
  });
  result.checks.installStaffBlockedExpected = erpFieldB06J40_01_03_buildSalesViewModel_({
    roleCode: 'STAFF_INSTALL', vendorId: 'VND-20260502202158-505', eventId: 'EVT-20260502202016-197', route: 'sales', userEmail: 'install@example.com'
  });
  result.checks.missingVendorBlockedExpected = erpFieldB06J40_01_03_buildSalesViewModel_({
    roleCode: 'VENDOR_MANAGER', vendorId: '', eventId: 'EVT-20260502202016-197', route: 'sales', userEmail: 'manager@example.com'
  });

  ['preflight', 'salesVendorOwner', 'salesVendorManager', 'salesStaffSales'].forEach(function (k) {
    var c = result.checks[k];
    if (!c || c.ok !== true) result.ok = false;
    if (c && c.fatal && c.fatal.length) result.fatal = result.fatal.concat(c.fatal.map(function (m) { return k + ': ' + m; }));
    if (c && c.warnings && c.warnings.length) result.warnings = result.warnings.concat(c.warnings.map(function (m) { return k + ': ' + m; }));
  });

  ['viewerBlockedExpected', 'installStaffBlockedExpected', 'missingVendorBlockedExpected'].forEach(function (k) {
    var c = result.checks[k];
    if (!c || c.ok !== false) {
      result.ok = false;
      result.fatal.push(k + ': 차단 테스트가 실패했습니다.');
    }
  });

  Logger.log('======================================================');
  Logger.log(JSON.stringify(result, null, 2));
  Logger.log('======================================================');
  return result;
}

function erpFieldB06J40_01_03_renderSalesEntryHtml(ctx) {
  var vm = erpFieldB06J40_01_03_buildSalesViewModel_(ctx);
  if (!vm.ok) {
    return erpFieldB06J40_01_03_renderSalesBlocked_(ctx, vm.fatal || ['판매등록 화면 진입 차단']);
  }
  var template = HtmlService.createTemplateFromFile('P_SaleEntry');
  template.vm = vm;
  return template.evaluate()
    .setTitle('FEELHAUS ERP FIELD - 판매등록 준비')
    .setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL);
}

function erpFieldB06J40_01_03_buildSalesViewModel_(ctx) {
  var result = {
    ok: true,
    build: FIELD_SALES_ENTRY_BUILD,
    moduleCode: 'ERP_FIELD',
    checkedAt: new Date().toISOString(),
    fatal: [],
    warnings: [],
    context: erpFieldB06J40_01_03_normalizeCtx_(ctx),
    vendor: { vendorId: '', vendorName: '' },
    event: { eventId: '', eventName: '' },
    page: {},
    sections: {},
    safety: erpFieldB06J40_01_03_safety_(),
    blockedActions: []
  };

  var allowedRoles = { VENDOR_OWNER: true, VENDOR_MANAGER: true, STAFF_SALES: true };
  if (!result.context.vendorId) result.fatal.push('판매등록 화면 차단: vendorId 누락');
  if (!result.context.eventId) result.warnings.push('eventId가 비어 있습니다. 행사 기준 판매등록 전환 전 실제 eventId 사용을 권장합니다.');
  if (!allowedRoles[result.context.roleCode]) result.fatal.push('판매등록 화면 차단: roleCode=' + result.context.roleCode + ' 는 판매등록 진입 권한이 없습니다.');

  result.ok = result.fatal.length === 0;
  result.vendor = erpFieldB06J40_01_03_lookupVendor_(result.context.vendorId);
  result.event = erpFieldB06J40_01_03_lookupEvent_(result.context.eventId);
  result.page = {
    title: '판매등록 준비',
    subtitle: '고객 선택 / 품목 / 결제 / 계약 정보를 한 화면에 배치합니다. 현재 저장은 차단됩니다.',
    badge: 'B06J40-01_03 SAFE : SALES ENTRY READY',
    roleName: erpFieldB06J40_01_03_roleName_(result.context.roleCode)
  };
  result.sections = {
    customer: {
      title: '고객 선택',
      desc: 'B06J39 고객조회 결과와 연결될 고객 선택 영역입니다. 현재 직접 저장은 차단됩니다.',
      fields: ['customerId', 'name', 'phone', 'dong', 'ho']
    },
    product: {
      title: '상품/품목',
      desc: '품목명, 수량, 단가, 금액 입력 자리입니다. 금액 계산은 화면 표시용입니다.',
      fields: ['itemName', 'qty', 'unitPrice', 'amount']
    },
    payment: {
      title: '결제/계약',
      desc: '총금액, 계약금, 잔금, 결제구조, 설치예정일 자리입니다.',
      fields: ['totalAmount', 'depositAmount', 'balanceAmount', 'paymentStructure', 'installPlanDate']
    },
    contract: {
      title: '계약/서명 연결',
      desc: 'SIGN 계약/서명 연결 전 준비 자리입니다. 문서 생성은 아직 실행하지 않습니다.',
      fields: ['contractId', 'documentId', 'signStatus']
    }
  };
  result.blockedActions = [
    { label: '판매 DRAFT 저장 차단', reason: 'B06J40-01~03 화면 진입 단계' },
    { label: '계약 생성 차단', reason: 'B06J41 계약/서명 연결 단계에서 개방 예정' },
    { label: '정산 반영 차단', reason: '정산 실행 금지' },
    { label: '외부연동 차단', reason: '외부 API/Drive/Sign 실행 없음' }
  ];
  return result;
}

function erpFieldB06J40_01_03_normalizeCtx_(ctx) {
  ctx = ctx || {};
  return {
    roleCode: String(ctx.roleCode || 'VIEWER').trim(),
    vendorId: String(ctx.vendorId || '').trim(),
    eventId: String(ctx.eventId || '').trim(),
    route: String(ctx.route || 'sales').trim(),
    keyword: String(ctx.keyword || '').trim(),
    customerId: String(ctx.customerId || '').trim(),
    userEmail: String(ctx.userEmail || '').trim(),
    scopeType: 'VENDOR_BRANCH_USER_GROUP',
    dataPolicy: 'vendorId / eventId / roleCode 기준 판매등록 화면 진입 제한',
    hqFullAccess: false
  };
}

function erpFieldB06J40_01_03_lookupVendor_(vendorId) {
  var fallback = { vendorId: vendorId || '', vendorName: vendorId ? '업체명 확인 대기' : '' };
  if (!vendorId) return fallback;
  try {
    if (typeof erpFieldB06J39_04_09_lookupEntity_ === 'function') {
      var r = erpFieldB06J39_04_09_lookupEntity_('ERP_업체관리', 'vendorId', vendorId, ['vendorName', 'name', '업체명']);
      if (r && r.name) return { vendorId: vendorId, vendorName: r.name };
    }
  } catch (err) {
    fallback.vendorName = '업체명 조회 보류';
  }
  return fallback;
}

function erpFieldB06J40_01_03_lookupEvent_(eventId) {
  var fallback = { eventId: eventId || '', eventName: eventId ? '행사명 확인 대기' : '' };
  if (!eventId) return fallback;
  try {
    if (typeof erpFieldB06J39_04_09_lookupEntity_ === 'function') {
      var r = erpFieldB06J39_04_09_lookupEntity_('ERP_행사관리', 'eventId', eventId, ['eventName', 'name', '행사명']);
      if (r && r.name) return { eventId: eventId, eventName: r.name };
    }
  } catch (err) {
    fallback.eventName = '행사명 조회 보류';
  }
  return fallback;
}

function erpFieldB06J40_01_03_renderSalesBlocked_(ctx, fatal) {
  var c = erpFieldB06J40_01_03_normalizeCtx_(ctx);
  var html = '<!doctype html><html><head><meta charset="utf-8"><base target="_top">' +
    '<style>body{font-family:Arial,"Noto Sans KR",sans-serif;background:#f6f7fb;margin:0;padding:40px;color:#111827}.box{max-width:900px;margin:0 auto;background:#fff;border:1px solid #e5e7eb;border-radius:18px;padding:28px;box-shadow:0 16px 40px rgba(0,0,0,.08)}.badge{display:inline-block;background:#fee2e2;color:#991b1b;border-radius:999px;padding:6px 10px;font-weight:800}.err{white-space:pre-wrap;background:#fff5f5;border:1px solid #fecaca;border-radius:12px;padding:14px;color:#991b1b}.kv{display:grid;grid-template-columns:120px 1fr;gap:8px;margin-top:16px}.k{color:#6b7280}.v{font-weight:700}</style></head><body><div class="box">' +
    '<span class="badge">BLOCKED</span><h1>판매등록 진입 차단</h1><p>vendorId / eventId / roleCode 기준 검증을 통과하지 못했습니다.</p>' +
    '<div class="err">' + erpFieldB06J40_01_03_escape_(JSON.stringify(fatal || [], null, 2)) + '</div>' +
    '<div class="kv"><div class="k">roleCode</div><div class="v">' + erpFieldB06J40_01_03_escape_(c.roleCode) + '</div>' +
    '<div class="k">vendorId</div><div class="v">' + erpFieldB06J40_01_03_escape_(c.vendorId) + '</div>' +
    '<div class="k">eventId</div><div class="v">' + erpFieldB06J40_01_03_escape_(c.eventId) + '</div>' +
    '<div class="k">route</div><div class="v">' + erpFieldB06J40_01_03_escape_(c.route) + '</div></div>' +
    '<p>업체는 별도 앱이 아니라 ERP 내부 지점형 사용자 그룹입니다. 업체별 독립 DB로 분리하지 않습니다.</p>' +
    '</div></body></html>';
  return HtmlService.createHtmlOutput(html).setTitle('판매등록 진입 차단').setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL);
}

function erpFieldB06J40_01_03_checkRequiredFunctions_() {
  var required = [
    'doGet',
    'erpFieldB06J39_04_09_renderCustomerStableHtml',
    'erpFieldB06J40_01_03_renderSalesEntryHtml',
    'erpFieldB06J40_01_03_buildSalesViewModel_'
  ];
  var missing = [];
  required.forEach(function (n) { if (typeof this[n] !== 'function') missing.push(n); }, this);
  return { ok: missing.length === 0, fatal: missing.map(function (n) { return '필수 함수 누락: ' + n; }), warnings: [], required: required, missing: missing };
}

function erpFieldB06J40_01_03_checkTemplate_() {
  try {
    HtmlService.createTemplateFromFile('P_SaleEntry');
    return { ok: true, fatal: [], warnings: [], templateName: 'P_SaleEntry' };
  } catch (err) {
    return { ok: false, fatal: ['FieldSalesEntryPage.html 템플릿 확인 실패: ' + (err && err.message ? err.message : err)], warnings: [] };
  }
}

function erpFieldB06J40_01_03_checkCustomerDependency_() {
  var missing = [];
  ['erpFieldB06J39_04_09_lookupEntity_', 'erpFieldB06J39_04_09_renderCustomerStableHtml'].forEach(function (n) {
    if (typeof this[n] !== 'function') missing.push(n);
  }, this);
  return { ok: missing.length === 0, fatal: missing.map(function (n) { return 'B06J39 의존 함수 누락: ' + n; }), warnings: [] };
}

function erpFieldB06J40_01_03_checkRouteSamples_() {
  var samples = [
    { roleCode: 'VENDOR_MANAGER', vendorId: 'VND-20260502202158-505', eventId: 'EVT-20260502202016-197', route: 'sales' },
    { roleCode: 'STAFF_SALES', vendorId: 'VND-20260502202158-505', eventId: 'EVT-20260502202016-197', route: 'sales' }
  ];
  var fatal = [];
  samples.forEach(function (s, i) {
    var vm = erpFieldB06J40_01_03_buildSalesViewModel_(s);
    if (!vm.ok) fatal.push('route sample ' + i + ' 실패: ' + (vm.fatal || []).join(', '));
  });
  return { ok: fatal.length === 0, fatal: fatal, warnings: [], samples: samples };
}

function erpFieldB06J40_01_03_checkWriteBlocked_() {
  return {
    ok: true,
    fatal: [],
    warnings: [],
    noAppendRow: true,
    noSetValue: true,
    noSetValues: true,
    noDeleteRow: true,
    noPaymentExecution: true,
    noSettlementExecution: true,
    noExternalIntegration: true
  };
}

function erpFieldB06J40_01_03_safety_() {
  return {
    salesEntryScreenOnly: true,
    readOnlyPreparation: true,
    buttonsDisabled: true,
    noBusinessStateMutation: true,
    noSheetWrite: true,
    noAppendRow: true,
    noSetValue: true,
    noSetValues: true,
    noSaveExecution: true,
    noUpdateExecution: true,
    noDeleteExecution: true,
    paymentExecutionBlocked: true,
    settlementExecutionBlocked: true,
    externalIntegrationBlocked: true,
    vendorIndependentDbBlocked: true,
    vendorAsBranchUserGroup: true
  };
}

function erpFieldB06J40_01_03_roleName_(roleCode) {
  return ({
    VENDOR_OWNER: '업체대표',
    VENDOR_MANAGER: '업체관리자',
    STAFF_SALES: '영업직원',
    STAFF_INSTALL: '설치담당',
    STAFF_AS: 'A/S담당',
    VIEWER: '조회전용'
  })[roleCode] || roleCode;
}

function erpFieldB06J40_01_03_escape_(v) {
  return String(v == null ? '' : v).replace(/[&<>\"]/g, function (s) {
    return ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' })[s];
  });
}
