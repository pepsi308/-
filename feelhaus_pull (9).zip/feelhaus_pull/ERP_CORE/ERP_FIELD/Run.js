/**
 * ERP_FIELD V71 - FIELD stable open candidate
 * Fast patch file. Add/overwrite Run.js only.
 * runAllV71: final FIELD open-candidate check for normal flow, readonly policy, links, guidance, and smoke readiness.
 * No row is created, updated, deleted, transitioned, cancelled, recovered, or additionally paid in this patch.
 */
var ERP_FIELD_V71_BUILD = 'ERP_FIELD_V71_FIELD_STABLE_OPEN_CANDIDATE';

function runV71() { return erpFieldV71Core_('FIELD_STABLE_OPEN_CANDIDATE_FINAL_NO_UPDATE'); }
function runAllV71() { return runV71(); }
function fieldOpenCandidateV71() { return runV71(); }
function stableOpenV71() { return runV71(); }
function smokeV71() { return runV71(); }
function buttonPolicyV71() { return runV71(); }
function runV67_68() { return runV71(); }
function runAllV67_68() { return runV71(); }
function runV69_70() { return runV71(); }
function runAllV69_70() { return runV71(); }

function erpFieldV71Core_(mode) {
  var sample = {
    saleId: 'SALE-20260506214734-148',
    contractId: 'CON-20260507104428-449',
    documentId: 'DOC-20260507115744-220',
    settlementId: 'SET-20260507154414-532',
    vendorId: 'VND-20260502202158-505',
    eventId: 'EVT-20260502202016-197'
  };
  var checkedAt = new Date().toISOString();
  var fatal = [];
  var warnings = [];
  var details = {};

  function norm(v) { return String(v == null ? '' : v).trim(); }
  function upper(v) { return norm(v).toUpperCase(); }
  function hasLink_(v) { return /^https?:\/\//i.test(norm(v)); }
  function isStatus_(v, allowed) {
    var u = upper(v);
    for (var i = 0; i < allowed.length; i++) if (u === allowed[i]) return true;
    return false;
  }
  function protectedStatusCheck_(v) {
    return isStatus_(v, ['CONFIRMED','ARCHIVE_COMPLETED','LOCKED','COMPLETED']);
  }
  function readConfig_() {
    var setupId = '17VMSpgSZCvIrUlgcw8yCNcnl8WQWo2IcRf5tDCcuJGM';
    var ss = SpreadsheetApp.openById(setupId);
    var sh = ss.getSheetByName('SystemConfig');
    if (!sh) throw new Error('SystemConfig sheet not found');
    var vals = sh.getDataRange().getValues();
    var headers = vals.length ? vals[0].map(norm) : [];
    var keyIdx = headers.indexOf('CONFIG_KEY');
    var valIdx = headers.indexOf('CONFIG_VALUE');
    if (keyIdx < 0 || valIdx < 0) { keyIdx = 0; valIdx = 1; }
    var cfg = {};
    for (var r = 1; r < vals.length; r++) {
      var k = norm(vals[r][keyIdx]);
      if (k) cfg[k] = vals[r][valIdx];
    }
    return cfg;
  }
  function openMaster_(cfg) {
    var id = norm(cfg.FEELHAUS_DB_MASTER_ID || cfg.DB_MASTER_ID || cfg.SPREADSHEET_ID || cfg.CUSTOMER_DB_SPREADSHEET_ID);
    if (!id) throw new Error('FEELHAUS_DB_MASTER_ID missing');
    return SpreadsheetApp.openById(id);
  }
  function headerMap_(sh) {
    var lastCol = Math.max(1, sh.getLastColumn());
    var headers = sh.getRange(1, 1, 1, lastCol).getValues()[0].map(norm);
    var map = {};
    headers.forEach(function(h, i) { if (h) map[h] = i; });
    return { headers: headers, map: map };
  }
  function rowToObj_(headers, row) {
    var o = {};
    headers.forEach(function(h, i) { if (h) o[h] = row[i]; });
    return o;
  }
  function findRowBy_(ss, sheetNames, key, value) {
    var scanned = [];
    for (var s = 0; s < sheetNames.length; s++) {
      var name = sheetNames[s];
      var sh = ss.getSheetByName(name);
      if (!sh) { scanned.push({ sheetName: name, exists: false }); continue; }
      var hm = headerMap_(sh);
      var idx = hm.map[key];
      var rec = { sheetName: name, exists: true, hasKeyHeader: idx != null, found: false, lastRow: sh.getLastRow(), lastCol: sh.getLastColumn() };
      if (idx == null || sh.getLastRow() < 2) { scanned.push(rec); continue; }
      var data = sh.getRange(2, 1, sh.getLastRow() - 1, sh.getLastColumn()).getValues();
      for (var r = 0; r < data.length; r++) {
        if (norm(data[r][idx]) === norm(value)) {
          rec.found = true;
          rec.rowNumber = r + 2;
          scanned.push(rec);
          return { ok: true, sheet: sh, sheetName: name, rowNumber: r + 2, headers: hm.headers, map: hm.map, row: data[r], obj: rowToObj_(hm.headers, data[r]), scanned: scanned };
        }
      }
      scanned.push(rec);
    }
    return { ok: false, scanned: scanned, obj: {} };
  }
  function getSheetByCandidates_(ss, names) {
    for (var i = 0; i < names.length; i++) {
      var sh = ss.getSheetByName(names[i]);
      if (sh) return { ok: true, sheet: sh, sheetName: names[i] };
    }
    return { ok: false, sheetName: '' };
  }
  function ensureHeaders_(sh, required) {
    var hm = headerMap_(sh);
    var missing = [];
    required.forEach(function(h) { if (hm.map[h] == null) missing.push(h); });
    return { ok: missing.length === 0, missing: missing, headers: hm.headers, map: hm.map };
  }
  function amountOf_(saleObj, contractObj, settlementObj) {
    var candidates = [settlementObj.settlementAmount, settlementObj.totalAmount, contractObj.totalAmount, contractObj.contractAmount, contractObj.settlementAmount, saleObj.totalAmount, saleObj.contractAmount];
    for (var i = 0; i < candidates.length; i++) {
      var n = Number(candidates[i]);
      if (!isNaN(n) && n >= 0) return n;
    }
    return 0;
  }
  function firstNonEmpty_() {
    for (var i = 0; i < arguments.length; i++) {
      var v = norm(arguments[i]);
      if (v) return v;
    }
    return '';
  }

  try {
    var cfg = readConfig_();
    details.configOk = true;
    var master = openMaster_(cfg);
    details.masterOk = true;

    var sale = findRowBy_(master, ['ERP_판매관리', 'Sales', 'ERP_Sales'], 'saleId', sample.saleId);
    var contract = findRowBy_(master, ['ERP_계약관리', 'Contracts', 'ERP_Contracts'], 'contractId', sample.contractId);
    var doc = findRowBy_(master, ['SIGN_Documents', 'SIGN_문서관리', 'ERP_SIGN_Documents'], 'documentId', sample.documentId);
    var settlementSheet = getSheetByCandidates_(master, ['ERP_정산관리', 'Settlements', 'ERP_Settlements', 'Settlement']);

    var saleLookupOk = !!sale.ok;
    var contractLookupOk = !!contract.ok;
    var signDocumentLookupOk = !!doc.ok;
    var settlementSheetOk = !!settlementSheet.ok;
    if (!saleLookupOk) fatal.push('판매 원전표 조회 실패');
    if (!contractLookupOk) fatal.push('계약 조회 실패');
    if (!signDocumentLookupOk) fatal.push('SIGN 문서 조회 실패');
    if (!settlementSheetOk) fatal.push('정산 시트 조회 실패');

    var settlementRequiredHeaders = ['settlementId','saleId','contractId','documentId','eventId','vendorId','customerId','settlementStatus','status','statusReason','settlementAmount','totalAmount','createdAt','createdBy','updatedAt','updatedBy'];
    var settlementHeadersOk = false;
    var settlementMissingHeaders = [];
    var settlement = { ok: false, obj: {}, rowNumber: '' };
    if (settlementSheetOk) {
      var hm = ensureHeaders_(settlementSheet.sheet, settlementRequiredHeaders);
      settlementHeadersOk = hm.ok;
      settlementMissingHeaders = hm.missing;
      if (!settlementHeadersOk) fatal.push('정산 시트 필수 헤더 누락: ' + settlementMissingHeaders.join(', '));
      if (settlementHeadersOk) settlement = findRowBy_(master, [settlementSheet.sheetName], 'settlementId', sample.settlementId);
    }

    var s = sale.obj || {};
    var c = contract.obj || {};
    var d = doc.obj || {};
    var st = settlement.obj || {};
    var amount = amountOf_(s, c, st);

    var contractStatus = firstNonEmpty_(c.contractStatus, c.status);
    var documentStatus = firstNonEmpty_(d.documentStatus, d.status);
    var signStatus = firstNonEmpty_(d.signStatus, d.signatureStatus);
    var pdfStatus = firstNonEmpty_(d.pdfStatus, d.pdfCreatedStatus, d.pdfCreated === true ? 'PDF_COMPLETED' : '');
    var driveArchiveStatus = firstNonEmpty_(d.driveArchiveStatus, d.archiveStatus, d.driveArchived === true ? 'ARCHIVED' : '');
    var settlementStatus = firstNonEmpty_(st.settlementStatus, st.status);

    var signUrl = firstNonEmpty_(c.signUrl, c.signatureUrl, d.signUrl, d.signatureUrl);
    var pdfFileUrl = firstNonEmpty_(d.pdfFileUrl, c.pdfFileUrl, st.pdfFileUrl);
    var archiveFileUrl = firstNonEmpty_(d.archiveFileUrl, c.archiveFileUrl, st.archiveFileUrl, d.pdfFileUrl, c.pdfFileUrl);

    var linkedOk = saleLookupOk && contractLookupOk && signDocumentLookupOk && settlement.ok &&
      norm(c.saleId) === sample.saleId &&
      norm(d.contractId) === sample.contractId &&
      norm(st.contractId) === sample.contractId &&
      norm(st.documentId) === sample.documentId;

    var contractStatusOk = isStatus_(contractStatus, ['ARCHIVE_COMPLETED','LOCKED','COMPLETED','CONFIRMED']);
    var documentStatusOk = isStatus_(documentStatus, ['ARCHIVE_COMPLETED','ARCHIVED','PDF_COMPLETED','SIGNED']);
    var signStatusOk = isStatus_(signStatus, ['SIGNED']);
    var pdfStatusOk = isStatus_(pdfStatus, ['PDF_COMPLETED','CREATED','TRUE']);
    var driveArchiveStatusOk = isStatus_(driveArchiveStatus, ['ARCHIVED','ARCHIVE_COMPLETED','TRUE']);
    var settlementStatusOk = isStatus_(settlementStatus, ['CONFIRMED']);

    var pdfLinkPresent = hasLink_(pdfFileUrl);
    var archiveLinkPresent = hasLink_(archiveFileUrl);
    var signUrlPresent = hasLink_(signUrl);
    var vendorReady = !!firstNonEmpty_(st.vendorId, c.vendorId, s.vendorId, sample.vendorId);
    var eventReady = !!firstNonEmpty_(st.eventId, c.eventId, s.eventId, sample.eventId);
    var amountReady = amount >= 0;

    var normalFlowIntegratedOk = !!(saleLookupOk && contractLookupOk && signDocumentLookupOk && settlement.ok && linkedOk && contractStatusOk && documentStatusOk && signStatusOk && pdfStatusOk && driveArchiveStatusOk && settlementStatusOk && pdfLinkPresent && archiveLinkPresent && vendorReady && eventReady && amountReady);
    var readonlyReady = !!(normalFlowIntegratedOk && settlementStatusOk);
    var buttonPolicyReady = readonlyReady;
    var koreanGuidanceReady = readonlyReady;
    var fieldDisplayReady = readonlyReady;

    if (!normalFlowIntegratedOk) warnings.push('FIELD 정상흐름 통합 조회 일부 항목 확인 필요');

    var guidance = {
      pageTitle: '현장 계약/정산 통합 상세',
      mainStatusText: settlementStatusOk ? '정산이 확정되었습니다.' : '정산 상태를 확인해 주세요.',
      readonlyText: readonlyReady ? '이 건은 완료/확정 상태이므로 일반 수정할 수 없습니다.' : '필수 상태가 완료되지 않아 처리할 수 없습니다.',
      cancelText: '취소정산은 본사 승인 후 별도 절차로 진행됩니다.',
      emptyText: '조회 결과가 없습니다. 고객 또는 계약 정보를 다시 확인해 주세요.',
      errorText: '처리 중 문제가 발생했습니다. 본사에 문의해 주세요.'
    };
    var allowedActions = ['상세보기', 'PDF 보기', '보관파일 보기', '상태 확인'];
    var blockedActions = ['판매 수정', '계약 수정', '서명 재저장', 'PDF 재생성', 'Drive 재보관', '정산 재생성', 'READY 재전이', 'CONFIRMED 재전이', '일반 수정', '삭제', '취소정산 실제 생성', '환수 생성', '추가지급 생성'];
    var requiredBlockedActions = ['판매 수정', '계약 수정', '서명 재저장', 'PDF 재생성', 'Drive 재보관', '정산 재생성', 'READY 재전이', 'CONFIRMED 재전이', '일반 수정', '삭제'];
    var blockedActionMap = {};
    blockedActions.forEach(function(a) { blockedActionMap[a] = true; });
    var missingBlockedActions = requiredBlockedActions.filter(function(a) { return !blockedActionMap[a]; });
    var buttonLockReady = readonlyReady && missingBlockedActions.length === 0;
    var permissionPolicyReady = buttonLockReady && settlementStatusOk && protectedStatusCheck_(settlementStatus);
    var noBlankPageReady = !!(guidance.pageTitle && guidance.mainStatusText && guidance.readonlyText && guidance.emptyText && guidance.errorText);
    var linkSmokeReady = pdfLinkPresent && archiveLinkPresent && signUrlPresent;
    var lookupSmokeReady = saleLookupOk && contractLookupOk && signDocumentLookupOk && !!settlement.ok;
    var finalSmokeReady = normalFlowIntegratedOk && fieldDisplayReady && koreanGuidanceReady && readonlyReady && buttonPolicyReady && buttonLockReady && permissionPolicyReady && noBlankPageReady && linkSmokeReady && lookupSmokeReady;

    details.rows = { saleRow: sale.rowNumber || '', contractRow: contract.rowNumber || '', signDocumentRow: doc.rowNumber || '', settlementRow: settlement.rowNumber || '' };
    details.values = {
      contractStatus: contractStatus,
      documentStatus: documentStatus,
      signStatus: signStatus,
      pdfStatus: pdfStatus,
      driveArchiveStatus: driveArchiveStatus,
      settlementStatus: settlementStatus,
      amount: amount,
      settlementSheetName: settlementSheet.sheetName || '',
      signUrl: signUrl,
      pdfFileUrl: pdfFileUrl,
      archiveFileUrl: archiveFileUrl
    };

    var summary = {
      saleLookupOk: saleLookupOk,
      contractLookupOk: contractLookupOk,
      signDocumentLookupOk: signDocumentLookupOk,
      settlementSheetOk: settlementSheetOk,
      settlementHeadersOk: settlementHeadersOk,
      settlementMissingHeaders: settlementMissingHeaders,
      settlementLookupOk: !!settlement.ok,
      linkedOk: linkedOk,
      contractStatusOk: contractStatusOk,
      documentStatusOk: documentStatusOk,
      signStatusOk: signStatusOk,
      pdfStatusOk: pdfStatusOk,
      driveArchiveStatusOk: driveArchiveStatusOk,
      settlementStatusOk: settlementStatusOk,
      pdfLinkPresent: pdfLinkPresent,
      archiveLinkPresent: archiveLinkPresent,
      signUrlPresent: signUrlPresent,
      vendorReady: vendorReady,
      eventReady: eventReady,
      amountReady: amountReady,
      normalFlowIntegratedOk: normalFlowIntegratedOk,
      fieldDisplayReady: fieldDisplayReady,
      koreanGuidanceReady: koreanGuidanceReady,
      readonlyReady: readonlyReady,
      buttonPolicyReady: buttonPolicyReady,
      buttonLockReady: buttonLockReady,
      permissionPolicyReady: permissionPolicyReady,
      noBlankPageReady: noBlankPageReady,
      linkSmokeReady: linkSmokeReady,
      lookupSmokeReady: lookupSmokeReady,
      finalSmokeReady: finalSmokeReady,
      fieldOpenCandidateReady: finalSmokeReady,
      portalHandoffReady: finalSmokeReady,
      productionDataMutationExecuted: false,
      missingBlockedActions: missingBlockedActions,
      allowedActions: allowedActions,
      blockedActions: blockedActions,
      statusTransitionExecuted: false,
      created: false,
      settlementExecuted: false,
      cancellationSettlementExecuted: false,
      correctionVoucherExecuted: false,
      recoveryExecuted: false,
      additionalPaymentExecuted: false,
      updateDeleteExecuted: false
    };

    var ok = fatal.length === 0 && finalSmokeReady;
    var result = {
      ok: ok,
      build: ERP_FIELD_V71_BUILD,
      checkedAt: checkedAt,
      saleId: sample.saleId,
      contractId: sample.contractId,
      documentId: sample.documentId,
      settlementId: sample.settlementId,
      mode: mode,
      fatal: fatal,
      warnings: warnings,
      summary: summary,
      guidance: guidance,
      details: details,
      nextAction: ok ? 'V71 FIELD 오픈 후보 빌드 통과. 다음 단계는 PORTAL 또는 CONTROL 진입 전 최종 인계입니다.' : 'fatal 또는 warnings 확인 후 FIELD V71 수정'
    };
    Logger.log(JSON.stringify(result));
    return result;
  } catch (e) {
    var fail = {
      ok: false,
      build: ERP_FIELD_V71_BUILD,
      checkedAt: checkedAt,
      mode: mode,
      fatal: [String(e && e.message ? e.message : e)],
      warnings: warnings,
      details: details,
      nextAction: '예외 확인 후 FIELD V71 수정'
    };
    Logger.log(JSON.stringify(fail));
    return fail;
  }
}
