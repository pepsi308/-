/* ===== CustRead.js ===== */
/**
 * build: ERP_B06J38_06_FIELD_CUSTOMER_READONLY_GUARD_SAFE
 * file: FieldCustomerRead.js
 * module: ERP_FIELD
 * purpose:
 * - ERP_FIELD 고객 조회 READ ONLY 가드
 * - vendorId / eventId / roleCode 기준 조회 범위 제한
 * - HeaderMap 기반 ERP_고객관리 조회
 * - 저장/수정/삭제/정산/외부연동 실행 없음
 *
 * run:
 * - erpB06J38_06_autoRunSafe()
 */

var FIELD_CUSTOMER_READ_BUILD = 'ERP_B06J38_06_FIELD_CUSTOMER_READONLY_GUARD_SAFE';
var FIELD_CUSTOMER_READ_SETUP_DB_ID = '17VMSpgSZCvIrUlgcw8yCNcnl8WQWo2IcRf5tDCcuJGM';
var FIELD_CUSTOMER_READ_CONFIG_SHEET_NAME = 'SystemConfig';
var FIELD_CUSTOMER_READ_CUSTOMER_SHEET = 'ERP_고객관리';

var FIELD_CUSTOMER_READ_ALLOWED_ROLES = [
  'VENDOR_OWNER',
  'VENDOR_MANAGER',
  'STAFF_SALES',
  'STAFF_INSTALL',
  'STAFF_AS',
  'VIEWER'
];

function erpB06J38_06_autoRunSafe() {
  var result = {
    ok: true,
    build: FIELD_CUSTOMER_READ_BUILD,
    moduleCode: 'ERP_FIELD',
    checkedAt: new Date().toISOString(),
    fatal: [],
    warnings: [],
    checks: {}
  };

  try {
    result.checks.config = fieldCustomerRead_getConfig_();
    if (!result.checks.config.ok) {
      result.ok = false;
      result.fatal = result.fatal.concat(result.checks.config.fatal || []);
    }

    result.checks.master = fieldCustomerRead_getMaster_(result.checks.config.configMap || {});
    if (!result.checks.master.ok) {
      result.ok = false;
      result.fatal = result.fatal.concat(result.checks.master.fatal || []);
    }

    result.checks.customerSheet = fieldCustomerRead_checkCustomerSheet_(result.checks.master.masterId);
    if (!result.checks.customerSheet.ok) {
      result.ok = false;
      result.fatal = result.fatal.concat(result.checks.customerSheet.fatal || []);
    }

    result.checks.sampleVendorOwner = erpFieldB06J38_06_searchCustomerReadonly({
      roleCode: 'VENDOR_OWNER',
      vendorId: 'VENDOR-SAMPLE',
      eventId: 'EVT-SAMPLE',
      keyword: '',
      limit: 5,
      userEmail: 'vendor.owner@example.com'
    });

    result.checks.sampleVendorManager = erpFieldB06J38_06_searchCustomerReadonly({
      roleCode: 'VENDOR_MANAGER',
      vendorId: 'VENDOR-SAMPLE',
      eventId: 'EVT-SAMPLE',
      keyword: '',
      limit: 5,
      userEmail: 'vendor.manager@example.com'
    });

    result.checks.sampleStaffSales = erpFieldB06J38_06_searchCustomerReadonly({
      roleCode: 'STAFF_SALES',
      vendorId: 'VENDOR-SAMPLE',
      eventId: 'EVT-SAMPLE',
      keyword: '',
      limit: 5,
      userEmail: 'staff.sales@example.com'
    });

    result.checks.sampleViewer = erpFieldB06J38_06_searchCustomerReadonly({
      roleCode: 'VIEWER',
      vendorId: 'VENDOR-SAMPLE',
      eventId: 'EVT-SAMPLE',
      keyword: '',
      limit: 5,
      userEmail: 'viewer@example.com'
    });

    result.checks.missingVendorBlocked = erpFieldB06J38_06_searchCustomerReadonly({
      roleCode: 'VENDOR_MANAGER',
      eventId: 'EVT-SAMPLE',
      keyword: '',
      limit: 5,
      userEmail: 'blocked@example.com'
    });

    result.checks.unknownRoleBlocked = erpFieldB06J38_06_searchCustomerReadonly({
      roleCode: 'UNKNOWN_ROLE',
      vendorId: 'VENDOR-SAMPLE',
      eventId: 'EVT-SAMPLE',
      keyword: '',
      limit: 5,
      userEmail: 'blocked@example.com'
    });

    var expectedTrue = [
      'sampleVendorOwner',
      'sampleVendorManager',
      'sampleStaffSales',
      'sampleViewer'
    ];
    for (var i = 0; i < expectedTrue.length; i++) {
      var key = expectedTrue[i];
      if (!result.checks[key] || !result.checks[key].ok) {
        result.ok = false;
        result.fatal.push(key + ': 고객 READ ONLY 조회 가드 샘플 실패');
      }
    }

    if (!result.checks.missingVendorBlocked || result.checks.missingVendorBlocked.ok !== false) {
      result.ok = false;
      result.fatal.push('missingVendorBlocked: vendorId 누락 차단 실패');
    }

    if (!result.checks.unknownRoleBlocked || result.checks.unknownRoleBlocked.ok !== false) {
      result.ok = false;
      result.fatal.push('unknownRoleBlocked: 미허용 roleCode 차단 실패');
    }
  } catch (err) {
    result.ok = false;
    result.fatal.push(String(err && err.message ? err.message : err));
  }

  Logger.log('======================================================');
  Logger.log(JSON.stringify(result, null, 2));
  Logger.log('======================================================');
  return result;
}

function erpFieldB06J38_06_searchCustomerReadonly(params) {
  var checkedAt = new Date().toISOString();
  var p = params || {};
  var roleCode = String(p.roleCode || '').trim();
  var vendorId = String(p.vendorId || '').trim();
  var eventId = String(p.eventId || '').trim();
  var keyword = String(p.keyword || '').trim();
  var limit = Number(p.limit || 20);
  if (!limit || limit < 1) limit = 20;
  if (limit > 50) limit = 50;

  var base = {
    ok: true,
    build: FIELD_CUSTOMER_READ_BUILD,
    moduleCode: 'ERP_FIELD',
    checkedAt: checkedAt,
    fatal: [],
    warnings: [],
    context: {
      roleCode: roleCode,
      vendorId: vendorId,
      eventId: eventId,
      keyword: keyword,
      limit: limit,
      userEmail: String(p.userEmail || ''),
      scopeType: 'VENDOR_BRANCH_USER_GROUP',
      dataPolicy: 'vendorId / eventId / roleCode 기준 READ ONLY 제한',
      hqFullAccess: false
    },
    rows: [],
    count: 0,
    safety: {
      readOnlyGuard: true,
      noSheetWrite: true,
      noAppendRow: true,
      noSetValue: true,
      noBusinessStateMutation: true,
      noSaveExecution: true,
      noUpdateExecution: true,
      noDeleteExecution: true,
      paymentExecutionBlocked: true,
      settlementExecutionBlocked: true,
      externalIntegrationBlocked: true,
      vendorIndependentDbBlocked: true,
      vendorAsBranchUserGroup: true
    }
  };

  if (FIELD_CUSTOMER_READ_ALLOWED_ROLES.indexOf(roleCode) < 0) {
    base.ok = false;
    base.fatal.push('FIELD 고객조회 차단: 미허용 roleCode');
    return base;
  }

  if (!vendorId) {
    base.ok = false;
    base.fatal.push('FIELD 고객조회 차단: vendorId 누락');
    return base;
  }

  try {
    var cfg = fieldCustomerRead_getConfig_();
    if (!cfg.ok) {
      base.ok = false;
      base.fatal = base.fatal.concat(cfg.fatal || []);
      return base;
    }

    var master = fieldCustomerRead_getMaster_(cfg.configMap || {});
    if (!master.ok) {
      base.ok = false;
      base.fatal = base.fatal.concat(master.fatal || []);
      return base;
    }

    var ss = SpreadsheetApp.openById(master.masterId);
    var sheet = ss.getSheetByName(FIELD_CUSTOMER_READ_CUSTOMER_SHEET);
    if (!sheet) {
      base.ok = false;
      base.fatal.push('필수 시트 없음: ' + FIELD_CUSTOMER_READ_CUSTOMER_SHEET);
      return base;
    }

    var lastRow = sheet.getLastRow();
    var lastCol = sheet.getLastColumn();
    if (lastRow < 1 || lastCol < 1) {
      base.warnings.push('고객관리 시트가 비어 있음');
      return base;
    }

    var values = sheet.getRange(1, 1, lastRow, lastCol).getValues();
    var headers = values[0];
    var hm = fieldCustomerRead_headerMap_(headers);
    var required = ['customerId', 'eventId', 'vendorId', 'name', 'phone', 'status'];
    var missing = fieldCustomerRead_missingHeaders_(hm, required);
    if (missing.length) {
      base.ok = false;
      base.fatal.push('ERP_고객관리 필수 헤더 누락: ' + missing.join(', '));
      return base;
    }

    var out = [];
    var q = keyword.toLowerCase();
    for (var r = 1; r < values.length; r++) {
      var row = values[r];
      var rowVendorId = fieldCustomerRead_cell_(row, hm, 'vendorId');
      var rowEventId = fieldCustomerRead_cell_(row, hm, 'eventId');
      var status = fieldCustomerRead_cell_(row, hm, 'status');
      var name = fieldCustomerRead_cell_(row, hm, 'name');
      var phone = fieldCustomerRead_cell_(row, hm, 'phone');
      var customerId = fieldCustomerRead_cell_(row, hm, 'customerId');

      if (String(rowVendorId) !== vendorId) continue;
      if (eventId && String(rowEventId) !== eventId) continue;
      if (String(status) === 'ARCHIVED') continue;

      if (q) {
        var hay = [customerId, name, phone, rowEventId, rowVendorId].join(' ').toLowerCase();
        if (hay.indexOf(q) < 0) continue;
      }

      out.push({
        customerId: customerId,
        eventId: rowEventId,
        vendorId: rowVendorId,
        name: name,
        phoneMasked: fieldCustomerRead_maskPhone_(phone),
        status: status,
        readonly: true,
        editable: false,
        deletable: false
      });

      if (out.length >= limit) break;
    }

    base.rows = out;
    base.count = out.length;
    base.headerPolicy = {
      headerMapBased: true,
      columnIndexFixed: false,
      requiredHeaders: required,
      missingHeaders: []
    };
    return base;
  } catch (err) {
    base.ok = false;
    base.fatal.push(String(err && err.message ? err.message : err));
    return base;
  }
}

function fieldCustomerRead_getConfig_() {
  var out = {
    ok: true,
    fatal: [],
    warnings: [],
    setupDbId: FIELD_CUSTOMER_READ_SETUP_DB_ID,
    setupDbName: '',
    configSheetName: FIELD_CUSTOMER_READ_CONFIG_SHEET_NAME,
    configCount: 0,
    configMap: {}
  };
  try {
    var ss = SpreadsheetApp.openById(FIELD_CUSTOMER_READ_SETUP_DB_ID);
    out.setupDbName = ss.getName();
    var sheet = ss.getSheetByName(FIELD_CUSTOMER_READ_CONFIG_SHEET_NAME);
    if (!sheet) {
      out.ok = false;
      out.fatal.push('SystemConfig 시트 없음');
      return out;
    }
    var values = sheet.getDataRange().getValues();
    if (!values || values.length < 2) {
      out.warnings.push('SystemConfig 데이터 부족');
      return out;
    }
    var hm = fieldCustomerRead_headerMap_(values[0]);
    var keyIdx = fieldCustomerRead_firstIndex_(hm, ['configKey', 'key', 'settingKey', 'name']);
    var valIdx = fieldCustomerRead_firstIndex_(hm, ['configValue', 'value', 'settingValue']);
    if (keyIdx < 0 || valIdx < 0) {
      out.warnings.push('SystemConfig 헤더명이 표준과 다름: configKey/configValue 확인 필요');
      keyIdx = 0;
      valIdx = 1;
    }
    for (var i = 1; i < values.length; i++) {
      var k = String(values[i][keyIdx] || '').trim();
      if (!k) continue;
      out.configMap[k] = values[i][valIdx];
      out.configCount++;
    }
    return out;
  } catch (err) {
    out.ok = false;
    out.fatal.push(String(err && err.message ? err.message : err));
    return out;
  }
}

function fieldCustomerRead_getMaster_(configMap) {
  var out = {
    ok: true,
    fatal: [],
    warnings: [],
    usedKey: '',
    masterId: '',
    masterName: '',
    masterSpreadsheetName: ''
  };
  var keys = ['FEELHAUS_DB_MASTER_ID', 'DB_MASTER_ID', 'SPREADSHEET_ID', 'CUSTOMER_DB_SPREADSHEET_ID'];
  for (var i = 0; i < keys.length; i++) {
    if (configMap && configMap[keys[i]]) {
      out.usedKey = keys[i];
      out.masterId = String(configMap[keys[i]]).trim();
      break;
    }
  }
  if (!out.masterId) {
    out.ok = false;
    out.fatal.push('FEELHAUS_DB_MASTER ID 설정 없음');
    return out;
  }
  try {
    var ss = SpreadsheetApp.openById(out.masterId);
    out.masterSpreadsheetName = ss.getName();
    out.masterName = ss.getName();
    return out;
  } catch (err) {
    out.ok = false;
    out.fatal.push(String(err && err.message ? err.message : err));
    return out;
  }
}

function fieldCustomerRead_checkCustomerSheet_(masterId) {
  var out = {
    ok: true,
    fatal: [],
    warnings: [],
    sheetName: FIELD_CUSTOMER_READ_CUSTOMER_SHEET,
    exists: false,
    lastRow: 0,
    lastCol: 0,
    headerMapBased: true,
    columnIndexFixed: false,
    missingHeaders: []
  };
  try {
    var ss = SpreadsheetApp.openById(masterId);
    var sheet = ss.getSheetByName(FIELD_CUSTOMER_READ_CUSTOMER_SHEET);
    if (!sheet) {
      out.ok = false;
      out.fatal.push('필수 시트 없음: ' + FIELD_CUSTOMER_READ_CUSTOMER_SHEET);
      return out;
    }
    out.exists = true;
    out.lastRow = sheet.getLastRow();
    out.lastCol = sheet.getLastColumn();
    var headers = out.lastCol ? sheet.getRange(1, 1, 1, out.lastCol).getValues()[0] : [];
    var hm = fieldCustomerRead_headerMap_(headers);
    out.missingHeaders = fieldCustomerRead_missingHeaders_(hm, ['customerId', 'eventId', 'vendorId', 'name', 'phone', 'status']);
    if (out.missingHeaders.length) {
      out.ok = false;
      out.fatal.push('ERP_고객관리 필수 헤더 누락: ' + out.missingHeaders.join(', '));
    }
    return out;
  } catch (err) {
    out.ok = false;
    out.fatal.push(String(err && err.message ? err.message : err));
    return out;
  }
}

function fieldCustomerRead_headerMap_(headers) {
  var map = {};
  for (var i = 0; i < headers.length; i++) {
    var h = String(headers[i] || '').trim();
    if (h && map[h] === undefined) map[h] = i;
  }
  return map;
}

function fieldCustomerRead_missingHeaders_(hm, required) {
  var missing = [];
  for (var i = 0; i < required.length; i++) {
    if (hm[required[i]] === undefined) missing.push(required[i]);
  }
  return missing;
}

function fieldCustomerRead_firstIndex_(hm, names) {
  for (var i = 0; i < names.length; i++) {
    if (hm[names[i]] !== undefined) return hm[names[i]];
  }
  return -1;
}

function fieldCustomerRead_cell_(row, hm, header) {
  var idx = hm[header];
  if (idx === undefined || idx < 0) return '';
  return row[idx];
}

function fieldCustomerRead_maskPhone_(phone) {
  var s = String(phone || '').replace(/[^0-9]/g, '');
  if (!s) return '';
  if (s.length < 8) return '***';
  return s.substring(0, 3) + '-****-' + s.substring(s.length - 4);
}


/* ===== CustLive.js ===== */
/**
 * build: ERP_B06J39_01_03_FIELD_CUSTOMER_LIVE_LOOKUP_SAFE
 * file: FieldCustomerLive.js
 * module: ERP_FIELD
 * purpose:
 * - B06J39 고객조회 실사용 전환 1차 묶음
 * - 고객 검색 입력/조회/상세 READ ONLY 화면 제공
 * - vendorId / eventId / roleCode 기준 조회 범위 제한 유지
 * - 검색은 GET 파라미터 기반, 저장/수정/삭제/정산/외부연동/시트쓰기 없음
 */

var FIELD_CUSTOMER_LIVE_BUILD = 'ERP_B06J39_01_03_FIELD_CUSTOMER_LIVE_LOOKUP_SAFE';
var FIELD_CUSTOMER_LIVE_MODULE = 'ERP_FIELD';
var FIELD_CUSTOMER_LIVE_ROUTE = 'customerLookup';
var FIELD_CUSTOMER_LIVE_ALLOWED_ROLES = ['VENDOR_OWNER', 'VENDOR_MANAGER', 'STAFF_SALES', 'STAFF_INSTALL', 'STAFF_AS', 'VIEWER'];
var FIELD_CUSTOMER_LIVE_WRITE_PARAMS = ['save', 'update', 'delete', 'remove', 'edit', 'action', 'mode', 'submitMode'];

function erpB06J39_01_03_autoRunSafe() {
  var result = {
    ok: true,
    build: FIELD_CUSTOMER_LIVE_BUILD,
    moduleCode: FIELD_CUSTOMER_LIVE_MODULE,
    checkedAt: new Date().toISOString(),
    fatal: [],
    warnings: [],
    checks: {}
  };

  try {
    result.checks.dependency = {
      ok: typeof this.erpFieldB06J38_06_searchCustomerReadonly === 'function',
      fatal: typeof this.erpFieldB06J38_06_searchCustomerReadonly === 'function' ? [] : ['B06J38-06 고객 READ ONLY 조회 함수 미탑재'],
      warnings: []
    };
    result.checks.renderFunctionAvailable = {
      ok: typeof this.erpFieldB06J39_renderCustomerHtml === 'function',
      fatal: typeof this.erpFieldB06J39_renderCustomerHtml === 'function' ? [] : ['B06J39 고객 화면 렌더 함수 미탑재'],
      warnings: []
    };
    result.checks.customerSearchVendorManager = erpFieldB06J39_getCustomerViewModel({
      roleCode: 'VENDOR_MANAGER',
      vendorId: 'VENDOR-SAMPLE',
      eventId: 'EVT-SAMPLE',
      route: 'customerLookup',
      keyword: '',
      limit: 20,
      userEmail: 'vendor.manager@example.com'
    });
    result.checks.customerKeywordSearch = erpFieldB06J39_getCustomerViewModel({
      roleCode: 'STAFF_SALES',
      vendorId: 'VENDOR-SAMPLE',
      eventId: 'EVT-SAMPLE',
      route: 'customerLookup',
      keyword: '010',
      limit: 10,
      userEmail: 'staff.sales@example.com'
    });
    result.checks.customerDetailReadonly = erpFieldB06J39_getCustomerViewModel({
      roleCode: 'VENDOR_OWNER',
      vendorId: 'VENDOR-SAMPLE',
      eventId: 'EVT-SAMPLE',
      route: 'customerLookup',
      customerId: 'CUS-SAMPLE-NOT-FOUND',
      limit: 20,
      userEmail: 'vendor.owner@example.com'
    });
    result.checks.writeParamIgnored = erpFieldB06J39_getCustomerViewModel({
      roleCode: 'VENDOR_MANAGER',
      vendorId: 'VENDOR-SAMPLE',
      eventId: 'EVT-SAMPLE',
      route: 'customerLookup',
      action: 'save',
      mode: 'edit',
      keyword: '',
      userEmail: 'vendor.manager@example.com'
    });
    result.checks.missingVendorBlocked = erpFieldB06J39_getCustomerViewModel({
      roleCode: 'VENDOR_MANAGER',
      eventId: 'EVT-SAMPLE',
      route: 'customerLookup',
      keyword: '',
      userEmail: 'missing.vendor@example.com'
    });
    result.checks.unknownRoleBlocked = erpFieldB06J39_getCustomerViewModel({
      roleCode: 'UNKNOWN_ROLE',
      vendorId: 'VENDOR-SAMPLE',
      eventId: 'EVT-SAMPLE',
      route: 'customerLookup',
      keyword: '',
      userEmail: 'unknown.role@example.com'
    });
    result.checks.unknownRouteBlocked = erpFieldB06J39_getCustomerViewModel({
      roleCode: 'VENDOR_MANAGER',
      vendorId: 'VENDOR-SAMPLE',
      eventId: 'EVT-SAMPLE',
      route: 'dangerWrite',
      keyword: '',
      userEmail: 'unknown.route@example.com'
    });

    var fatal = [];
    ['dependency', 'renderFunctionAvailable', 'customerSearchVendorManager', 'customerKeywordSearch', 'customerDetailReadonly', 'writeParamIgnored'].forEach(function (key) {
      if (!result.checks[key] || result.checks[key].ok !== true) {
        fatal = fatal.concat((result.checks[key] && result.checks[key].fatal) || [key + ' 실패']);
      }
    });
    ['missingVendorBlocked', 'unknownRoleBlocked', 'unknownRouteBlocked'].forEach(function (key) {
      if (!result.checks[key] || result.checks[key].ok !== false) fatal.push(key + ' 차단 실패');
    });
    ['customerSearchVendorManager', 'customerKeywordSearch', 'customerDetailReadonly', 'writeParamIgnored'].forEach(function (key) {
      var s = result.checks[key] && result.checks[key].safety;
      if (!s || s.customerLiveLookup !== true || s.noSheetWrite !== true || s.noSaveExecution !== true || s.noUpdateExecution !== true || s.noDeleteExecution !== true) {
        fatal.push(key + ': 안전 플래그 실패');
      }
    });

    result.fatal = fatal;
    result.ok = fatal.length === 0;
  } catch (err) {
    result.ok = false;
    result.fatal.push(String(err && err.message ? err.message : err));
  }

  Logger.log('======================================================');
  Logger.log(JSON.stringify(result, null, 2));
  Logger.log('======================================================');
  return result;
}

function erpFieldB06J39_renderCustomerHtml(context) {
  var data = erpFieldB06J39_getCustomerViewModel(context || {});
  if (!data.ok) return erpFieldB06J39_renderBlockedHtml_(data);

  try {
    var template = HtmlService.createTemplateFromFile('P_Cust');
    template.customerModelJson = JSON.stringify(data.viewModel || {}, null, 2);
    return template.evaluate()
      .setTitle('필하우스 ERP FIELD - 고객 조회')
      .setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL);
  } catch (err) {
    return erpFieldB06J39_renderInlineHtml_(data);
  }
}

function erpFieldB06J39_getCustomerViewModel(context) {
  var ctx = erpFieldB06J39_normalizeContext_(context || {});
  var fatal = [];
  var warnings = [];

  if (!ctx.vendorId) fatal.push('FIELD 고객조회 차단: vendorId 누락');
  if (FIELD_CUSTOMER_LIVE_ALLOWED_ROLES.indexOf(ctx.roleCode) < 0) fatal.push('FIELD 고객조회 차단: 미허용 roleCode');
  if (ctx.route !== FIELD_CUSTOMER_LIVE_ROUTE) fatal.push('FIELD 고객조회 차단: 허용되지 않은 route');

  var writeWarnings = erpFieldB06J39_detectWriteParams_(context || {});
  warnings = warnings.concat(writeWarnings);

  if (fatal.length) {
    return {
      ok: false,
      build: FIELD_CUSTOMER_LIVE_BUILD,
      moduleCode: FIELD_CUSTOMER_LIVE_MODULE,
      checkedAt: new Date().toISOString(),
      fatal: fatal,
      warnings: warnings,
      context: ctx,
      safety: erpFieldB06J39_safety_()
    };
  }

  if (typeof this.erpFieldB06J38_06_searchCustomerReadonly !== 'function') {
    return {
      ok: false,
      build: FIELD_CUSTOMER_LIVE_BUILD,
      moduleCode: FIELD_CUSTOMER_LIVE_MODULE,
      checkedAt: new Date().toISOString(),
      fatal: ['B06J38-06 고객 READ ONLY 조회 함수 미탑재'],
      warnings: warnings,
      context: ctx,
      safety: erpFieldB06J39_safety_()
    };
  }

  var searchResult = this.erpFieldB06J38_06_searchCustomerReadonly({
    roleCode: ctx.roleCode,
    vendorId: ctx.vendorId,
    eventId: ctx.eventId,
    keyword: ctx.keyword,
    limit: ctx.limit,
    userEmail: ctx.userEmail
  });

  if (!searchResult || searchResult.ok !== true) {
    return {
      ok: false,
      build: FIELD_CUSTOMER_LIVE_BUILD,
      moduleCode: FIELD_CUSTOMER_LIVE_MODULE,
      checkedAt: new Date().toISOString(),
      fatal: (searchResult && searchResult.fatal) || ['고객 READ ONLY 조회 실패'],
      warnings: warnings.concat((searchResult && searchResult.warnings) || []),
      context: ctx,
      safety: erpFieldB06J39_safety_()
    };
  }

  var rows = searchResult.rows || [];
  var selected = null;
  if (ctx.customerId) {
    for (var i = 0; i < rows.length; i++) {
      if (String(rows[i].customerId || '') === ctx.customerId) {
        selected = rows[i];
        break;
      }
    }
    if (!selected) warnings.push('선택 customerId가 현재 조회 범위에 없거나 검색 조건에 포함되지 않음: READ ONLY 안내만 표시');
  }

  var viewModel = {
    build: FIELD_CUSTOMER_LIVE_BUILD,
    moduleCode: FIELD_CUSTOMER_LIVE_MODULE,
    pageTitle: '고객 조회',
    pageSubtitle: 'vendorId / eventId / roleCode 기준 실사용 READ ONLY 고객 검색',
    context: ctx,
    search: {
      keyword: ctx.keyword,
      limit: ctx.limit,
      resultCount: rows.length,
      searchEnabled: true,
      searchMethod: 'GET_ONLY',
      writeBlocked: true
    },
    rows: rows,
    selectedCustomer: selected,
    detailMessage: selected ? '선택 고객 상세 READ ONLY' : (ctx.customerId ? '선택 고객을 현재 범위에서 찾을 수 없습니다.' : '목록에서 고객을 선택하면 상세 영역에 표시됩니다.'),
    columns: ['customerId', 'eventId', 'vendorId', 'name', 'phoneMasked', 'status'],
    actionButtons: erpFieldB06J39_actionButtons_(),
    notices: erpFieldB06J39_notices_(ctx, rows.length),
    footer: {
      copyright: '© 2026 FEELHAUS. All rights reserved.',
      company: '(주)필하우스',
      developer: '개발담당: 이용필',
      operator: '최고운영자: 이용필'
    },
    safety: erpFieldB06J39_safety_(),
    webAppUrl: erpFieldB06J39_getWebAppUrl_()
  };

  return {
    ok: true,
    build: FIELD_CUSTOMER_LIVE_BUILD,
    moduleCode: FIELD_CUSTOMER_LIVE_MODULE,
    checkedAt: new Date().toISOString(),
    fatal: [],
    warnings: warnings.concat(searchResult.warnings || []),
    context: ctx,
    viewModel: viewModel,
    rows: rows,
    selectedCustomer: selected,
    safety: erpFieldB06J39_safety_(),
    webAppUrl: erpFieldB06J39_getWebAppUrl_()
  };
}

function erpFieldB06J39_normalizeContext_(context) {
  var c = context || {};
  var route = String(c.route || c.page || 'customerLookup').trim();
  var roleCode = String(c.roleCode || c.role || 'VIEWER').trim().toUpperCase();
  var limit = Number(c.limit || 20);
  if (!limit || limit < 1) limit = 20;
  if (limit > 50) limit = 50;
  return {
    roleCode: roleCode,
    vendorId: String(c.vendorId || '').trim(),
    eventId: String(c.eventId || '').trim(),
    route: erpFieldB06J39_normalizeRoute_(route),
    keyword: String(c.keyword || c.q || '').trim(),
    customerId: String(c.customerId || '').trim(),
    limit: limit,
    userEmail: String(c.userEmail || erpFieldB06J39_getUserEmail_()).trim(),
    scopeType: 'VENDOR_BRANCH_USER_GROUP',
    dataPolicy: 'vendorId / eventId / roleCode 기준 READ ONLY 제한',
    hqFullAccess: false
  };
}

function erpFieldB06J39_normalizeRoute_(route) {
  var lower = String(route || 'customerLookup').trim().toLowerCase();
  var map = {
    'customerlookup': 'customerLookup',
    'customer': 'customerLookup',
    'customers': 'customerLookup',
    'lookup': 'customerLookup'
  };
  return map[lower] || String(route || 'customerLookup').trim();
}

function erpFieldB06J39_detectWriteParams_(params) {
  var warnings = [];
  var p = params || {};
  for (var i = 0; i < FIELD_CUSTOMER_LIVE_WRITE_PARAMS.length; i++) {
    var key = FIELD_CUSTOMER_LIVE_WRITE_PARAMS[i];
    if (p[key] !== undefined && String(p[key] || '').trim()) {
      warnings.push('쓰기성 파라미터 무시됨: ' + key + '=' + String(p[key]));
    }
  }
  return warnings;
}

function erpFieldB06J39_actionButtons_() {
  return [
    { code: 'SEARCH_GET', title: '검색', enabled: true, method: 'GET_ONLY', desc: '검색어로 다시 조회합니다. 저장 작업이 아닙니다.' },
    { code: 'CLEAR_SEARCH', title: '검색 초기화', enabled: true, method: 'GET_ONLY', desc: '검색어를 비우고 다시 조회합니다.' },
    { code: 'SAVE_CUSTOMER', title: '고객 저장', enabled: false, disabledReason: 'B06J39 단계: 저장 기능 미개방' },
    { code: 'EDIT_CUSTOMER', title: '고객 수정', enabled: false, disabledReason: 'B06J39 단계: 수정 기능 미개방' },
    { code: 'DELETE_CUSTOMER', title: '고객 삭제', enabled: false, disabledReason: '삭제 금지: 상태 변경/승인 기반 단계에서만 처리' }
  ];
}

function erpFieldB06J39_notices_(ctx, count) {
  return [
    'B06J39는 고객조회 실사용 1차 전환 단계입니다.',
    '검색 입력과 고객 선택은 가능하지만 저장/수정/삭제는 차단됩니다.',
    '조회 범위는 vendorId=' + ctx.vendorId + ', eventId=' + (ctx.eventId || '미지정') + ', roleCode=' + ctx.roleCode + ' 기준입니다.',
    '전화번호는 마스킹되어 표시됩니다.',
    '현재 조회 결과: ' + count + '건'
  ];
}

function erpFieldB06J39_safety_() {
  return {
    customerLiveLookup: true,
    getOnlySearch: true,
    customerDetailReadonly: true,
    phoneMasked: true,
    headerMapBased: true,
    columnIndexFixed: false,
    uiDisplayOnly: true,
    readOnlyGuard: true,
    noSheetWrite: true,
    noAppendRow: true,
    noSetValue: true,
    noBusinessStateMutation: true,
    noSaveExecution: true,
    noUpdateExecution: true,
    noDeleteExecution: true,
    paymentExecutionBlocked: true,
    settlementExecutionBlocked: true,
    externalIntegrationBlocked: true,
    fileDownloadBlocked: true,
    vendorIndependentDbBlocked: true,
    vendorAsBranchUserGroup: true
  };
}

function erpFieldB06J39_renderBlockedHtml_(data) {
  var ctx = data.context || {};
  var html = '<!doctype html><html lang="ko"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>고객조회 차단</title>' +
    '<style>body{margin:0;background:#f9fafb;font-family:Arial,\'Noto Sans KR\',sans-serif;color:#111827}.wrap{max-width:760px;margin:60px auto;padding:20px}.card{background:#fff;border:1px solid #e5e7eb;border-radius:18px;padding:24px}.fatal{color:#b91c1c;background:#fee2e2;border:1px solid #fecaca;border-radius:12px;padding:12px;margin:8px 0}.muted{color:#6b7280;font-size:13px}</style></head><body><div class="wrap"><div class="card"><h1>고객조회 차단</h1>' +
    '<p>vendorId / roleCode / route 기준 검증을 통과하지 못했습니다.</p>' +
    (data.fatal || []).map(function (f) { return '<div class="fatal">' + erpFieldB06J39_escapeHtml_(f) + '</div>'; }).join('') +
    '<p class="muted">roleCode=' + erpFieldB06J39_escapeHtml_(ctx.roleCode || '') + ' / vendorId=' + erpFieldB06J39_escapeHtml_(ctx.vendorId || '') + ' / route=' + erpFieldB06J39_escapeHtml_(ctx.route || '') + '</p>' +
    '</div></div></body></html>';
  return HtmlService.createHtmlOutput(html).setTitle('고객조회 차단');
}

function erpFieldB06J39_renderInlineHtml_(data) {
  var model = data.viewModel || {};
  var html = '<!doctype html><html lang="ko"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>고객 조회</title>' +
    '<style>body{margin:0;background:#f6f7fb;font-family:Arial,\'Noto Sans KR\',sans-serif;color:#111827}.wrap{max-width:1100px;margin:0 auto;padding:22px}.card,.panel{background:#fff;border:1px solid #e5e7eb;border-radius:18px;padding:18px;margin-bottom:14px}.muted{color:#6b7280}.btn{border:0;border-radius:12px;background:#111827;color:#fff;padding:10px 12px}table{width:100%;border-collapse:collapse}th,td{border-bottom:1px solid #e5e7eb;padding:9px;text-align:left;font-size:13px}</style></head><body><div class="wrap"><div class="card"><h1>' + erpFieldB06J39_escapeHtml_(model.pageTitle || '고객 조회') + '</h1><p class="muted">' + erpFieldB06J39_escapeHtml_(model.pageSubtitle || '') + '</p></div><div class="panel">검색 결과 ' + ((model.rows || []).length) + '건</div></div></body></html>';
  return HtmlService.createHtmlOutput(html).setTitle('고객 조회');
}


function erpFieldB06J39_getWebAppUrl_() {
  try {
    var url = ScriptApp.getService().getUrl();
    return url || '';
  } catch (err) {
    return '';
  }
}

function erpFieldB06J39_getUserEmail_() {
  try { return Session.getActiveUser().getEmail() || ''; } catch (err) { return ''; }
}

function erpFieldB06J39_escapeHtml_(value) {
  return String(value == null ? '' : value)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}


/* ===== CustStable.js ===== */
/**
 * build: ERP_B06J39_04_09_FIELD_CUSTOMER_LOOKUP_STABLE_SAFE_UPLOAD
 * module: ERP_FIELD
 * purpose:
 * - Customer live lookup stable pack
 * - Vendor/event names + diagnostics + readonly detail data
 * - HeaderMap based, no column index fixed
 */

var FIELD_CUSTOMER_STABLE_BUILD = 'ERP_B06J39_04_09_FIELD_CUSTOMER_LOOKUP_STABLE_SAFE_UPLOAD';
var FIELD_SETUP_DB_ID = '17VMSpgSZCvIrUlgcw8yCNcnl8WQWo2IcRf5tDCcuJGM';
var FIELD_CONFIG_SHEET_NAME = 'SystemConfig';
var FIELD_CUSTOMER_SHEET = 'ERP_고객관리';
var FIELD_VENDOR_SHEET = 'ERP_업체관리';
var FIELD_EVENT_SHEET = 'ERP_행사관리';

function erpB06J39_04_09_preflight() {
  var result = {
    ok: true,
    build: FIELD_CUSTOMER_STABLE_BUILD,
    moduleCode: 'ERP_FIELD',
    checkedAt: new Date().toISOString(),
    fatal: [],
    warnings: [],
    checks: {}
  };
  try {
    result.checks.requiredFunctions = erpFieldB06J39_04_09_checkRequiredFunctions_();
    result.checks.config = erpFieldB06J39_04_09_getConfig_();
    result.checks.master = erpFieldB06J39_04_09_getMaster_();
    result.checks.customerSheet = erpFieldB06J39_04_09_checkSheet_(FIELD_CUSTOMER_SHEET, ['customerId', 'vendorId', 'eventId']);
    result.checks.vendorSheet = erpFieldB06J39_04_09_checkSheet_(FIELD_VENDOR_SHEET, ['vendorId']);
    result.checks.eventSheet = erpFieldB06J39_04_09_checkSheet_(FIELD_EVENT_SHEET, ['eventId']);
    result.checks.htmlNavigation = {
      ok: true,
      fatal: [],
      warnings: [],
      formMethod: 'GET',
      actionUsesWebAppUrl: true,
      baseTargetTop: true,
      googleusercontentBlankRiskBlocked: true
    };
    result.checks.safety = erpFieldB06J39_04_09_safety_();
  } catch (err) {
    result.ok = false;
    result.fatal.push(err && err.message ? err.message : String(err));
  }
  Object.keys(result.checks).forEach(function (k) {
    var c = result.checks[k];
    if (c && c.ok === false) result.ok = false;
    if (c && c.fatal && c.fatal.length) result.fatal = result.fatal.concat(c.fatal.map(function (m) { return k + ': ' + m; }));
    if (c && c.warnings && c.warnings.length) result.warnings = result.warnings.concat(c.warnings.map(function (m) { return k + ': ' + m; }));
  });
  Logger.log('======================================================');
  Logger.log(JSON.stringify(result, null, 2));
  Logger.log('======================================================');
  return result;
}

function erpB06J39_04_09_autoRunSafe() {
  var result = erpB06J39_04_09_preflight();
  result.checks = result.checks || {};
  try {
    result.checks.renderVendorManager = erpFieldB06J39_04_09_buildCustomerViewModel_({
      roleCode: 'VENDOR_MANAGER',
      vendorId: 'VND-20260502202158-505',
      eventId: 'EVT-20260502202016-197',
      route: 'customerLookup',
      keyword: '홍길동',
      userEmail: 'vendor.manager@example.com'
    });
    result.checks.renderEmptyKeyword = erpFieldB06J39_04_09_buildCustomerViewModel_({
      roleCode: 'VENDOR_MANAGER',
      vendorId: 'VND-20260502202158-505',
      eventId: 'EVT-20260502202016-197',
      route: 'customerLookup',
      keyword: '',
      userEmail: 'vendor.manager@example.com'
    });
    result.checks.missingVendorBlocked = erpFieldB06J39_04_09_guardContext_({ roleCode: 'VENDOR_MANAGER', vendorId: '', eventId: 'EVT-SAMPLE', route: 'customerLookup' });
    result.checks.unknownRoleBlocked = erpFieldB06J39_04_09_guardContext_({ roleCode: 'BAD_ROLE', vendorId: 'VND-SAMPLE', eventId: 'EVT-SAMPLE', route: 'customerLookup' });
    result.checks.unknownRouteBlocked = erpFieldB06J39_04_09_guardContext_({ roleCode: 'VENDOR_MANAGER', vendorId: 'VND-SAMPLE', eventId: 'EVT-SAMPLE', route: 'badRoute' });

    // Block checks are expected to be ok:false. Convert to explicit pass labels.
    result.checks.missingVendorBlockedExpected = { ok: result.checks.missingVendorBlocked.ok === false, fatal: [], warnings: [], expectedBlocked: true };
    result.checks.unknownRoleBlockedExpected = { ok: result.checks.unknownRoleBlocked.ok === false, fatal: [], warnings: [], expectedBlocked: true };
    result.checks.unknownRouteBlockedExpected = { ok: result.checks.unknownRouteBlocked.ok === false, fatal: [], warnings: [], expectedBlocked: true };
  } catch (err) {
    result.ok = false;
    result.fatal.push(err && err.message ? err.message : String(err));
  }
  ['renderVendorManager', 'renderEmptyKeyword', 'missingVendorBlockedExpected', 'unknownRoleBlockedExpected', 'unknownRouteBlockedExpected'].forEach(function (k) {
    var c = result.checks[k];
    if (c && c.ok === false) {
      result.ok = false;
      if (c.fatal && c.fatal.length) result.fatal = result.fatal.concat(c.fatal.map(function (m) { return k + ': ' + m; }));
    }
  });
  Logger.log('======================================================');
  Logger.log(JSON.stringify(result, null, 2));
  Logger.log('======================================================');
  return result;
}

function erpFieldB06J39_04_09_renderCustomerStableHtml(ctx) {
  var vm = erpFieldB06J39_04_09_buildCustomerViewModel_(ctx);
  var tpl = HtmlService.createTemplateFromFile('P_CustStable');
  tpl.vm = vm;
  return tpl.evaluate().setTitle('FEELHAUS ERP_FIELD 고객조회').setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL);
}

function erpFieldB06J39_04_09_buildCustomerViewModel_(ctx) {
  ctx = ctx || {};
  var guard = erpFieldB06J39_04_09_guardContext_(ctx);
  if (!guard.ok) return { ok: false, fatal: guard.fatal, warnings: [], context: ctx };

  var config = erpFieldB06J39_04_09_getConfig_();
  var masterCheck = erpFieldB06J39_04_09_getMaster_();
  if (!masterCheck.ok) return { ok: false, fatal: masterCheck.fatal, warnings: masterCheck.warnings, context: ctx };

  var vendorInfo = erpFieldB06J39_04_09_lookupEntity_(FIELD_VENDOR_SHEET, 'vendorId', ctx.vendorId, ['vendorName', 'name', '업체명', 'companyName']);
  var eventInfo = erpFieldB06J39_04_09_lookupEntity_(FIELD_EVENT_SHEET, 'eventId', ctx.eventId, ['eventName', 'name', '행사명', 'title']);
  var lookup = erpFieldB06J39_04_09_lookupCustomers_(ctx);

  var url = '';
  try { url = ScriptApp.getService().getUrl() || ''; } catch (e) { url = ''; }
  if (!url) url = (config.configMap && config.configMap.ERP_FIELD_WEBAPP_URL) || '';

  return {
    ok: lookup.ok,
    build: FIELD_CUSTOMER_STABLE_BUILD,
    moduleCode: 'ERP_FIELD',
    checkedAt: new Date().toISOString(),
    fatal: lookup.fatal || [],
    warnings: (config.warnings || []).concat(masterCheck.warnings || []).concat(lookup.warnings || []),
    webAppUrl: url,
    context: {
      roleCode: ctx.roleCode,
      roleName: erpFieldB06J39_04_09_roleName_(ctx.roleCode),
      vendorId: ctx.vendorId,
      vendorName: vendorInfo.name || '(업체명 미확인)',
      eventId: ctx.eventId,
      eventName: eventInfo.name || '(행사명 미확인)',
      route: ctx.route,
      keyword: ctx.keyword || '',
      customerId: ctx.customerId || '',
      userEmail: ctx.userEmail || '',
      scopeType: 'VENDOR_BRANCH_USER_GROUP',
      dataPolicy: 'vendorId / eventId / roleCode 기준 READ ONLY 제한',
      hqFullAccess: false
    },
    rows: lookup.rows || [],
    selectedCustomer: erpFieldB06J39_04_09_selectCustomer_(lookup.rows || [], ctx.customerId),
    diagnostics: lookup.diagnostics,
    safety: erpFieldB06J39_04_09_safety_(),
    testUrls: erpFieldB06J39_04_09_buildTestUrls_(url, ctx)
  };
}

function erpFieldB06J39_04_09_lookupCustomers_(ctx) {
  var result = { ok: true, fatal: [], warnings: [], rows: [], diagnostics: {} };
  try {
    var master = erpFieldB06J39_04_09_getMaster_();
    var sheet = master.spreadsheet.getSheetByName(FIELD_CUSTOMER_SHEET);
    if (!sheet) throw new Error('필수 시트 없음: ' + FIELD_CUSTOMER_SHEET);
    var values = sheet.getDataRange().getValues();
    if (values.length < 1) throw new Error('고객 시트 헤더 없음: ' + FIELD_CUSTOMER_SHEET);
    var headerMap = erpFieldB06J39_04_09_headerMap_(values[0]);
    var rows = values.slice(1).filter(function (r) { return r.join('') !== ''; }).map(function (r, idx) {
      return erpFieldB06J39_04_09_customerRow_(r, headerMap, idx + 2);
    });
    var keyword = String(ctx.keyword || '').toLowerCase().trim();
    var vendorRows = rows.filter(function (r) { return String(r.vendorId || '') === String(ctx.vendorId || ''); });
    var eventRows = rows.filter(function (r) { return String(r.eventId || '') === String(ctx.eventId || ''); });
    var vendorEventRows = rows.filter(function (r) { return String(r.vendorId || '') === String(ctx.vendorId || '') && String(r.eventId || '') === String(ctx.eventId || ''); });
    var keywordRowsAll = !keyword ? rows : rows.filter(function (r) { return erpFieldB06J39_04_09_customerSearchText_(r).toLowerCase().indexOf(keyword) >= 0; });
    var finalRows = vendorEventRows.filter(function (r) {
      return !keyword || erpFieldB06J39_04_09_customerSearchText_(r).toLowerCase().indexOf(keyword) >= 0;
    });
    result.rows = finalRows.slice(0, 50).map(function (r) { return erpFieldB06J39_04_09_customerPublicRow_(r); });
    result.diagnostics = {
      totalCustomerCount: rows.length,
      vendorMatchCount: vendorRows.length,
      eventMatchCount: eventRows.length,
      vendorEventMatchCount: vendorEventRows.length,
      keywordMatchAllCount: keywordRowsAll.length,
      finalMatchCount: finalRows.length,
      resultCount: result.rows.length,
      headerMapBased: true,
      columnIndexFixed: false,
      reason: erpFieldB06J39_04_09_emptyReason_(rows.length, vendorRows.length, eventRows.length, vendorEventRows.length, keywordRowsAll.length, finalRows.length, keyword)
    };
  } catch (err) {
    result.ok = false;
    result.fatal.push(err && err.message ? err.message : String(err));
  }
  return result;
}

function erpFieldB06J39_04_09_customerRow_(r, hm, rowNumber) {
  function get(names) { return erpFieldB06J39_04_09_getByNames_(r, hm, names); }
  return {
    rowNumber: rowNumber,
    customerId: get(['customerId', '고객ID', '고객id']),
    vendorId: get(['vendorId', '업체ID', '업체id']),
    eventId: get(['eventId', '행사ID', '행사id']),
    name: get(['name', 'customerName', '고객명', '성명']),
    phone: get(['phone', 'mobile', 'tel', '전화번호', '연락처']),
    dong: get(['dong', '동']),
    ho: get(['ho', '호']),
    status: get(['status', '상태']),
    saleId: get(['saleId', '판매ID']),
    contractId: get(['contractId', '계약ID']),
    createdAt: get(['createdAt', '등록일', '생성일']),
    updatedAt: get(['updatedAt', '수정일'])
  };
}

function erpFieldB06J39_04_09_customerPublicRow_(r) {
  return {
    rowNumber: r.rowNumber,
    customerId: r.customerId,
    vendorId: r.vendorId,
    eventId: r.eventId,
    name: r.name || '(이름 없음)',
    phoneMasked: erpFieldB06J39_04_09_maskPhone_(r.phone),
    dong: r.dong,
    ho: r.ho,
    status: r.status,
    saleId: r.saleId,
    contractId: r.contractId,
    createdAt: erpFieldB06J39_04_09_dateText_(r.createdAt),
    updatedAt: erpFieldB06J39_04_09_dateText_(r.updatedAt)
  };
}

function erpFieldB06J39_04_09_selectCustomer_(rows, customerId) {
  if (!customerId) return null;
  for (var i = 0; i < rows.length; i++) if (String(rows[i].customerId) === String(customerId)) return rows[i];
  return null;
}

function erpFieldB06J39_04_09_lookupEntity_(sheetName, idHeader, idValue, nameHeaders) {
  var out = { ok: false, id: idValue, name: '', row: null };
  try {
    var master = erpFieldB06J39_04_09_getMaster_();
    var sheet = master.spreadsheet.getSheetByName(sheetName);
    if (!sheet) return out;
    var values = sheet.getDataRange().getValues();
    if (values.length < 2) return out;
    var hm = erpFieldB06J39_04_09_headerMap_(values[0]);
    for (var i = 1; i < values.length; i++) {
      var row = values[i];
      if (String(erpFieldB06J39_04_09_getByNames_(row, hm, [idHeader])) === String(idValue)) {
        out.ok = true;
        out.row = i + 1;
        out.name = erpFieldB06J39_04_09_getByNames_(row, hm, nameHeaders) || '';
        return out;
      }
    }
  } catch (err) {}
  return out;
}

function erpFieldB06J39_04_09_getConfig_() {
  var result = { ok: true, fatal: [], warnings: [], setupDbId: FIELD_SETUP_DB_ID, setupDbName: '', configSheetName: FIELD_CONFIG_SHEET_NAME, configCount: 0, configMap: {} };
  try {
    var ss = SpreadsheetApp.openById(FIELD_SETUP_DB_ID);
    result.setupDbName = ss.getName();
    var sheet = ss.getSheetByName(FIELD_CONFIG_SHEET_NAME);
    if (!sheet) throw new Error('SystemConfig 시트 없음');
    var values = sheet.getDataRange().getValues();
    if (values.length < 1) throw new Error('SystemConfig 헤더 없음');
    var hm = erpFieldB06J39_04_09_headerMap_(values[0]);
    var keyIdx = erpFieldB06J39_04_09_findIndex_(hm, ['configKey', 'key', '설정키', '항목']);
    var valIdx = erpFieldB06J39_04_09_findIndex_(hm, ['configValue', 'value', '설정값', '값']);
    if (keyIdx < 0 || valIdx < 0) {
      result.warnings.push('SystemConfig 헤더명이 표준과 다름: configKey/configValue 확인 필요');
      keyIdx = 0; valIdx = 1;
    }
    for (var i = 1; i < values.length; i++) {
      var k = String(values[i][keyIdx] || '').trim();
      if (k) result.configMap[k] = values[i][valIdx];
    }
    result.configCount = Object.keys(result.configMap).length;
  } catch (err) {
    result.ok = false;
    result.fatal.push(err && err.message ? err.message : String(err));
  }
  return result;
}

function erpFieldB06J39_04_09_getMaster_() {
  var config = erpFieldB06J39_04_09_getConfig_();
  var result = { ok: false, fatal: [], warnings: [], usedKey: '', masterId: '', masterName: '', spreadsheet: null };
  if (!config.ok) {
    result.fatal = result.fatal.concat(config.fatal);
    return result;
  }
  var keys = ['FEELHAUS_DB_MASTER_ID', 'DB_MASTER_ID', 'SPREADSHEET_ID', 'CUSTOMER_DB_SPREADSHEET_ID'];
  for (var i = 0; i < keys.length; i++) {
    var id = String(config.configMap[keys[i]] || '').trim();
    if (id) {
      try {
        var ss = SpreadsheetApp.openById(id);
        result.ok = true;
        result.usedKey = keys[i];
        result.masterId = id;
        result.masterName = ss.getName();
        result.spreadsheet = ss;
        return result;
      } catch (err) {
        result.warnings.push(keys[i] + ' open 실패: ' + (err && err.message ? err.message : err));
      }
    }
  }
  result.fatal.push('FEELHAUS_DB_MASTER_ID / DB_MASTER_ID / SPREADSHEET_ID 모두 열 수 없음');
  return result;
}

function erpFieldB06J39_04_09_checkSheet_(sheetName, requiredHeaders) {
  var result = { ok: true, fatal: [], warnings: [], sheetName: sheetName, exists: false, lastRow: 0, lastCol: 0, headerMapBased: true, columnIndexFixed: false, missingHeaders: [] };
  try {
    var master = erpFieldB06J39_04_09_getMaster_();
    if (!master.ok) throw new Error(master.fatal.join(', '));
    var sheet = master.spreadsheet.getSheetByName(sheetName);
    if (!sheet) throw new Error('시트 없음: ' + sheetName);
    result.exists = true;
    result.lastRow = sheet.getLastRow();
    result.lastCol = sheet.getLastColumn();
    var headers = result.lastCol ? sheet.getRange(1, 1, 1, result.lastCol).getValues()[0].map(String) : [];
    var hm = erpFieldB06J39_04_09_headerMap_(headers);
    (requiredHeaders || []).forEach(function (h) { if (hm[h] == null) result.missingHeaders.push(h); });
    if (result.missingHeaders.length) result.warnings.push('권장 헤더 확인 필요: ' + result.missingHeaders.join(', '));
  } catch (err) {
    result.ok = false;
    result.fatal.push(err && err.message ? err.message : String(err));
  }
  return result;
}

function erpFieldB06J39_04_09_headerMap_(headers) {
  var hm = {};
  (headers || []).forEach(function (h, idx) {
    var key = String(h || '').trim();
    if (key && hm[key] == null) hm[key] = idx;
  });
  return hm;
}

function erpFieldB06J39_04_09_findIndex_(hm, names) {
  for (var i = 0; i < names.length; i++) if (hm[names[i]] != null) return hm[names[i]];
  return -1;
}

function erpFieldB06J39_04_09_getByNames_(row, hm, names) {
  for (var i = 0; i < names.length; i++) {
    var idx = hm[names[i]];
    if (idx != null) return row[idx];
  }
  return '';
}

function erpFieldB06J39_04_09_customerSearchText_(r) {
  return [r.customerId, r.name, r.phone, r.dong, r.ho, r.saleId, r.contractId, r.status].join(' ');
}

function erpFieldB06J39_04_09_emptyReason_(total, vendor, event, vendorEvent, keywordAll, finalCount, keyword) {
  if (finalCount > 0) return '조회 성공';
  if (total === 0) return 'ERP_고객관리 시트에 고객 데이터가 없습니다.';
  if (vendor === 0) return '고객은 있으나 현재 vendorId와 일치하는 고객이 없습니다. 판매등록 시 vendorId 연결이 필요합니다.';
  if (event === 0) return '고객은 있으나 현재 eventId와 일치하는 고객이 없습니다. 판매등록 시 eventId 연결이 필요합니다.';
  if (vendorEvent === 0) return 'vendorId와 eventId를 동시에 만족하는 고객이 없습니다.';
  if (keyword && keywordAll === 0) return '전체 고객 중 검색어와 일치하는 고객이 없습니다.';
  if (keyword) return 'vendorId/eventId 범위 안에서 검색어와 일치하는 고객이 없습니다.';
  return '현재 조건에 표시할 고객이 없습니다.';
}

function erpFieldB06J39_04_09_maskPhone_(phone) {
  var s = String(phone || '').replace(/[^0-9]/g, '');
  if (s.length < 7) return phone ? '***' : '';
  return s.substring(0, 3) + '-****-' + s.substring(s.length - 4);
}

function erpFieldB06J39_04_09_dateText_(v) {
  if (!v) return '';
  if (Object.prototype.toString.call(v) === '[object Date]' && !isNaN(v.getTime())) {
    return Utilities.formatDate(v, 'Asia/Seoul', 'yyyy-MM-dd HH:mm');
  }
  return String(v);
}

function erpFieldB06J39_04_09_roleName_(roleCode) {
  return ({
    VENDOR_OWNER: '업체대표', VENDOR_MANAGER: '업체관리자', STAFF_SALES: '영업직원',
    STAFF_INSTALL: '설치담당', STAFF_AS: 'A/S담당', VIEWER: '조회전용'
  })[roleCode] || roleCode;
}

function erpFieldB06J39_04_09_safety_() {
  return {
    ok: true,
    fatal: [],
    warnings: [],
    customerLookupLive: true,
    readOnly: true,
    headerMapBased: true,
    columnIndexFixed: false,
    buttonsSearchOnly: true,
    noSheetWrite: true,
    noSaveExecution: true,
    noUpdateExecution: true,
    noDeleteExecution: true,
    settlementExecutionBlocked: true,
    paymentExecutionBlocked: true,
    externalIntegrationBlocked: true,
    vendorIndependentDbBlocked: true,
    vendorAsBranchUserGroup: true
  };
}

function erpFieldB06J39_04_09_buildTestUrls_(baseUrl, ctx) {
  if (!baseUrl) return [];
  var q = '?roleCode=' + encodeURIComponent(ctx.roleCode) + '&vendorId=' + encodeURIComponent(ctx.vendorId) + '&eventId=' + encodeURIComponent(ctx.eventId) + '&route=customerLookup';
  return [baseUrl + q, baseUrl + q + '&keyword=' + encodeURIComponent(ctx.keyword || '010')];
}

function erpFieldB06J39_04_09_checkRequiredFunctions_() {
  var names = [
    'doGet',
    'erpFieldB06J39_04_09_renderCustomerStableHtml',
    'erpFieldB06J39_04_09_buildCustomerViewModel_',
    'erpFieldB06J39_04_09_lookupCustomers_',
    'erpFieldB06J39_04_09_guardContext_'
  ];
  var missing = [];
  names.forEach(function (n) { if (typeof this[n] !== 'function') missing.push(n); }, this);
  return { ok: missing.length === 0, fatal: missing.length ? ['필수 함수 누락: ' + missing.join(', ')] : [], warnings: [], checked: names };
}


/* ===== CustTest.js ===== */
/**
 * build: ERP_B06J40_25_26_TEST_CUSTOMER_LINK_SAFE_UPLOAD
 * module: ERP_FIELD
 * purpose:
 *  - A안: DRAFT 저장 전, 현재 vendorId/eventId에 연결된 테스트 고객 1건을 안전 생성/확인
 *  - ERP_고객관리 HeaderMap 기반 append
 *  - TEST 데이터만 생성, 판매/계약/정산/외부연동 실행 없음
 * functions:
 *  - erpB06J40_25_26_preflight()
 *  - erpB06J40_25_26_autoRunSafe()
 *  - erpB06J40_25_26_confirmedCreateTestCustomer()
 */

var FIELD_TEST_CUSTOMER_BUILD = 'ERP_B06J40_25_26_TEST_CUSTOMER_LINK_SAFE_UPLOAD';
var FIELD_TEST_CUSTOMER_SETUP_DB_ID = '17VMSpgSZCvIrUlgcw8yCNcnl8WQWo2IcRf5tDCcuJGM';
var FIELD_TEST_CUSTOMER_CONFIG_SHEET = 'SystemConfig';
var FIELD_TEST_CUSTOMER_SHEET = 'ERP_고객관리';
var FIELD_TEST_CUSTOMER_DEFAULT_VENDOR_ID = 'VND-20260502202158-505';
var FIELD_TEST_CUSTOMER_DEFAULT_EVENT_ID = 'EVT-20260502202016-197';

function erpB06J40_25_26_preflight() {
  return erpFieldTestCustomer_run_(false, 'preflight');
}

function erpB06J40_25_26_autoRunSafe() {
  return erpFieldTestCustomer_run_(false, 'autoRunSafe');
}

function erpB06J40_25_26_confirmedCreateTestCustomer() {
  return erpFieldTestCustomer_run_(true, 'confirmedCreateTestCustomer');
}

function erpFieldTestCustomer_run_(confirmed, label) {
  var result = erpFieldTestCustomer_result_(label);
  try {
    var setup = erpFieldTestCustomer_readConfig_();
    result.checks.config = setup;
    if (!setup.ok) return erpFieldTestCustomer_finish_(result);

    var master = erpFieldTestCustomer_openMaster_(setup.configMap);
    result.checks.master = master;
    if (!master.ok) return erpFieldTestCustomer_finish_(result);

    var sheetCheck = erpFieldTestCustomer_checkCustomerSheet_(master.ss);
    result.checks.customerSheet = sheetCheck;
    if (!sheetCheck.ok) return erpFieldTestCustomer_finish_(result);

    var ctx = erpFieldTestCustomer_defaultContext_();
    result.context = ctx;

    var existing = erpFieldTestCustomer_findExisting_(sheetCheck.sheet, sheetCheck.headerMap, ctx);
    result.checks.duplicateCheck = existing;

    result.safety = {
      testDataOnly: true,
      headerMapBased: true,
      columnIndexFixed: false,
      noSalesWrite: true,
      noContractWrite: true,
      noSettlementWrite: true,
      noExternalIntegration: true,
      vendorIndependentDbBlocked: true,
      vendorAsBranchUserGroup: true
    };

    if (existing.exists) {
      result.created = false;
      result.customerId = existing.customerId;
      result.message = '이미 동일 vendorId/eventId/phone 기준 TEST 고객이 있어 재사용합니다.';
      result.urls = erpFieldTestCustomer_urls_(ctx, existing.customerId);
      return erpFieldTestCustomer_finish_(result);
    }

    if (!confirmed) {
      result.created = false;
      result.customerIdPreview = erpFieldTestCustomer_generateId_('CUS');
      result.message = 'preflight/autoRunSafe 단계입니다. 실제 생성은 confirmedCreateTestCustomer 실행 시에만 수행합니다.';
      result.readyForConfirmedCreate = true;
      return erpFieldTestCustomer_finish_(result);
    }

    var created = erpFieldTestCustomer_appendCustomer_(sheetCheck.sheet, sheetCheck.headerMap, ctx);
    result.checks.append = created;
    result.created = created.ok;
    result.customerId = created.customerId || '';
    result.urls = erpFieldTestCustomer_urls_(ctx, created.customerId || '');
    return erpFieldTestCustomer_finish_(result);
  } catch (err) {
    result.ok = false;
    result.fatal.push(String(err && err.message ? err.message : err));
    return erpFieldTestCustomer_finish_(result);
  }
}

function erpFieldTestCustomer_defaultContext_() {
  return {
    roleCode: 'VENDOR_MANAGER',
    vendorId: FIELD_TEST_CUSTOMER_DEFAULT_VENDOR_ID,
    eventId: FIELD_TEST_CUSTOMER_DEFAULT_EVENT_ID,
    name: 'TEST-판매저장고객',
    phone: '010-4025-0001',
    apartmentName: 'TEST-필하우스행사A02',
    dong: '101',
    ho: '1203',
    memberType: 'TEST',
    status: 'ACTIVE',
    statusReason: 'B06J40 판매 DRAFT 저장 테스트용 고객',
    createdBy: erpFieldTestCustomer_user_()
  };
}

function erpFieldTestCustomer_readConfig_() {
  var out = erpFieldTestCustomer_check_();
  try {
    var ss = SpreadsheetApp.openById(FIELD_TEST_CUSTOMER_SETUP_DB_ID);
    var sh = ss.getSheetByName(FIELD_TEST_CUSTOMER_CONFIG_SHEET);
    if (!sh) {
      out.fatal.push('SystemConfig 시트 없음');
      return erpFieldTestCustomer_mark_(out);
    }
    var values = sh.getDataRange().getValues();
    var configMap = {};
    if (values.length < 2) {
      out.fatal.push('SystemConfig 데이터 없음');
      return erpFieldTestCustomer_mark_(out);
    }
    var headers = values[0].map(function (h) { return String(h || '').trim(); });
    var keyIdx = headers.indexOf('configKey');
    var valIdx = headers.indexOf('configValue');
    if (keyIdx < 0 || valIdx < 0) {
      keyIdx = 0;
      valIdx = 1;
      out.warnings.push('SystemConfig 헤더명이 표준과 다름: 첫 2열을 key/value로 해석');
    }
    for (var r = 1; r < values.length; r++) {
      var k = String(values[r][keyIdx] || '').trim();
      if (k) configMap[k] = values[r][valIdx];
    }
    out.setupDbId = FIELD_TEST_CUSTOMER_SETUP_DB_ID;
    out.setupDbName = ss.getName();
    out.configSheetName = FIELD_TEST_CUSTOMER_CONFIG_SHEET;
    out.configCount = Object.keys(configMap).length;
    out.configMap = configMap;
    return erpFieldTestCustomer_mark_(out);
  } catch (err) {
    out.fatal.push('SystemConfig 읽기 실패: ' + err.message);
    return erpFieldTestCustomer_mark_(out);
  }
}

function erpFieldTestCustomer_openMaster_(configMap) {
  var out = erpFieldTestCustomer_check_();
  var keys = ['FEELHAUS_DB_MASTER_ID', 'DB_MASTER_ID', 'SPREADSHEET_ID', 'CUSTOMER_DB_SPREADSHEET_ID'];
  var id = '';
  var usedKey = '';
  for (var i = 0; i < keys.length; i++) {
    if (configMap[keys[i]]) {
      id = String(configMap[keys[i]]).trim();
      usedKey = keys[i];
      break;
    }
  }
  if (!id) {
    out.fatal.push('MASTER ID 없음');
    return erpFieldTestCustomer_mark_(out);
  }
  try {
    var ss = SpreadsheetApp.openById(id);
    out.masterId = id;
    out.usedKey = usedKey;
    out.masterSpreadsheetName = ss.getName();
    out.ss = ss;
    return erpFieldTestCustomer_mark_(out);
  } catch (err) {
    out.fatal.push('MASTER 열기 실패: ' + err.message);
    return erpFieldTestCustomer_mark_(out);
  }
}

function erpFieldTestCustomer_checkCustomerSheet_(ss) {
  var out = erpFieldTestCustomer_check_();
  var sh = ss.getSheetByName(FIELD_TEST_CUSTOMER_SHEET);
  if (!sh) {
    out.fatal.push(FIELD_TEST_CUSTOMER_SHEET + ' 시트 없음');
    return erpFieldTestCustomer_mark_(out);
  }
  var headerMap = erpFieldTestCustomer_headerMap_(sh);
  var required = ['customerId', 'eventId', 'vendorId', 'name', 'phone', 'status', 'createdAt', 'createdBy', 'updatedAt', 'updatedBy'];
  var missing = required.filter(function (h) { return !headerMap[h]; });
  out.sheetName = FIELD_TEST_CUSTOMER_SHEET;
  out.lastRow = sh.getLastRow();
  out.lastCol = sh.getLastColumn();
  out.headerMapBased = true;
  out.columnIndexFixed = false;
  out.missingHeaders = missing;
  if (missing.length) out.fatal.push('ERP_고객관리 필수 헤더 누락: ' + missing.join(', '));
  out.sheet = sh;
  out.headerMap = headerMap;
  return erpFieldTestCustomer_mark_(out);
}

function erpFieldTestCustomer_findExisting_(sheet, map, ctx) {
  var out = erpFieldTestCustomer_check_();
  out.exists = false;
  out.criteria = 'vendorId + eventId + phone';
  var values = sheet.getDataRange().getValues();
  for (var r = 1; r < values.length; r++) {
    var vendorId = erpFieldTestCustomer_get_(values[r], map, 'vendorId');
    var eventId = erpFieldTestCustomer_get_(values[r], map, 'eventId');
    var phone = erpFieldTestCustomer_get_(values[r], map, 'phone');
    if (vendorId === ctx.vendorId && eventId === ctx.eventId && phone === ctx.phone) {
      out.exists = true;
      out.row = r + 1;
      out.customerId = erpFieldTestCustomer_get_(values[r], map, 'customerId');
      break;
    }
  }
  return erpFieldTestCustomer_mark_(out);
}

function erpFieldTestCustomer_appendCustomer_(sheet, map, ctx) {
  var out = erpFieldTestCustomer_check_();
  var customerId = erpFieldTestCustomer_generateId_('CUS');
  var now = new Date();
  var lastCol = sheet.getLastColumn();
  var row = new Array(lastCol);
  for (var i = 0; i < lastCol; i++) row[i] = '';
  var data = {
    customerId: customerId,
    eventId: ctx.eventId,
    vendorId: ctx.vendorId,
    name: ctx.name,
    customerName: ctx.name,
    phone: ctx.phone,
    apartmentName: ctx.apartmentName,
    dong: ctx.dong,
    ho: ctx.ho,
    memberType: ctx.memberType,
    customerType: ctx.memberType,
    status: ctx.status,
    statusReason: ctx.statusReason,
    source: 'ERP_FIELD_B06J40_TEST',
    sourceType: 'TEST_DATA',
    memo: 'TEST- B06J40 판매 DRAFT 저장 전 검증용 고객. 운영 전 정리 대상.',
    notes: 'TEST- B06J40 판매 DRAFT 저장 전 검증용 고객. 운영 전 정리 대상.',
    createdAt: now,
    createdBy: ctx.createdBy,
    updatedAt: now,
    updatedBy: ctx.createdBy
  };
  Object.keys(data).forEach(function (key) {
    if (map[key]) row[map[key] - 1] = data[key];
  });
  sheet.appendRow(row);
  out.customerId = customerId;
  out.appendedRow = sheet.getLastRow();
  out.message = 'TEST 고객 생성 완료';
  return erpFieldTestCustomer_mark_(out);
}

function erpFieldTestCustomer_urls_(ctx, customerId) {
  var base = erpFieldTestCustomer_webAppUrl_();
  var common = 'roleCode=' + encodeURIComponent(ctx.roleCode) + '&vendorId=' + encodeURIComponent(ctx.vendorId) + '&eventId=' + encodeURIComponent(ctx.eventId);
  return {
    customerLookup: base ? base + '?' + common + '&route=customerLookup&keyword=' + encodeURIComponent(ctx.name) : '',
    salesWithCustomer: base ? base + '?' + common + '&route=sales&customerId=' + encodeURIComponent(customerId || '') : ''
  };
}

function erpFieldTestCustomer_webAppUrl_() {
  try { return ScriptApp.getService().getUrl() || ''; } catch (err) { return ''; }
}

function erpFieldTestCustomer_headerMap_(sheet) {
  var lastCol = sheet.getLastColumn();
  if (lastCol < 1) return {};
  var headers = sheet.getRange(1, 1, 1, lastCol).getValues()[0];
  var map = {};
  for (var i = 0; i < headers.length; i++) {
    var h = String(headers[i] || '').trim();
    if (h) map[h] = i + 1;
  }
  return map;
}

function erpFieldTestCustomer_get_(row, map, key) {
  return map[key] ? String(row[map[key] - 1] || '').trim() : '';
}

function erpFieldTestCustomer_generateId_(prefix) {
  var d = new Date();
  var s = Utilities.formatDate(d, 'Asia/Seoul', 'yyyyMMddHHmmss');
  var n = Math.floor(Math.random() * 900) + 100;
  return prefix + '-' + s + '-' + n;
}

function erpFieldTestCustomer_user_() {
  try { return Session.getActiveUser().getEmail() || 'UNKNOWN_USER'; } catch (err) { return 'UNKNOWN_USER'; }
}

function erpFieldTestCustomer_result_(label) {
  return {
    ok: true,
    build: FIELD_TEST_CUSTOMER_BUILD,
    moduleCode: 'ERP_FIELD',
    label: label,
    checkedAt: new Date().toISOString(),
    fatal: [],
    warnings: [],
    checks: {}
  };
}

function erpFieldTestCustomer_check_() {
  return { ok: true, fatal: [], warnings: [] };
}

function erpFieldTestCustomer_mark_(obj) {
  obj.ok = !obj.fatal || obj.fatal.length === 0;
  return obj;
}

function erpFieldTestCustomer_finish_(result) {
  Object.keys(result.checks || {}).forEach(function (k) {
    var c = result.checks[k];
    if (c && c.fatal && c.fatal.length) {
      result.fatal = result.fatal.concat(c.fatal.map(function (m) { return k + ': ' + m; }));
    }
    if (c && c.warnings && c.warnings.length) {
      result.warnings = result.warnings.concat(c.warnings.map(function (m) { return k + ': ' + m; }));
    }
  });
  result.ok = result.fatal.length === 0;
  Logger.log('======================================================');
  Logger.log(JSON.stringify(result, null, 2));
  Logger.log('======================================================');
  return result;
}


/* ===== ReadPack.js ===== */
/**
 * build: ERP_B06J38_07_09_FIELD_READONLY_SCREEN_PACK_SAFE
 * file: FieldReadPack.js
 * module: ERP_FIELD
 * purpose:
 * - B06J38-07 고객조회 화면 연결
 * - B06J38-08 판매/계약 READ ONLY 자리
 * - B06J38-09 설치/A/S READ ONLY 자리
 * - 모든 버튼 비활성, 저장/수정/삭제/정산/외부연동/시트쓰기 없음
 */

var FIELD_READ_PACK_BUILD = 'ERP_B06J38_07_09_FIELD_READONLY_SCREEN_PACK_SAFE';
var FIELD_READ_PACK_MODULE = 'ERP_FIELD';
var FIELD_READ_PACK_ROUTES = ['customerLookup', 'sales', 'contract', 'install', 'as'];

function erpB06J38_07_09_autoRunSafe() {
  var result = {
    ok: true,
    build: FIELD_READ_PACK_BUILD,
    moduleCode: FIELD_READ_PACK_MODULE,
    checkedAt: new Date().toISOString(),
    fatal: [],
    warnings: [],
    checks: {}
  };

  try {
    result.checks.config = erpFieldB06J38_07_09_getConfigCheck_();
    result.checks.renderFunctionAvailable = {
      ok: typeof this.erpFieldB06J38_07_09_renderScreenPackHtml === 'function',
      fatal: typeof this.erpFieldB06J38_07_09_renderScreenPackHtml === 'function' ? [] : ['B06J38-07_09 화면 렌더 함수 미탑재'],
      warnings: []
    };
    result.checks.customerLookupScreen = erpFieldB06J38_07_09_getScreenPackData({
      roleCode: 'VENDOR_MANAGER',
      vendorId: 'VENDOR-SAMPLE',
      eventId: 'EVT-SAMPLE',
      route: 'customerLookup',
      keyword: '',
      userEmail: 'vendor.manager@example.com'
    });
    result.checks.salesReadonlyScreen = erpFieldB06J38_07_09_getScreenPackData({
      roleCode: 'VENDOR_MANAGER',
      vendorId: 'VENDOR-SAMPLE',
      eventId: 'EVT-SAMPLE',
      route: 'sales',
      userEmail: 'vendor.manager@example.com'
    });
    result.checks.contractReadonlyScreen = erpFieldB06J38_07_09_getScreenPackData({
      roleCode: 'STAFF_SALES',
      vendorId: 'VENDOR-SAMPLE',
      eventId: 'EVT-SAMPLE',
      route: 'contract',
      userEmail: 'staff.sales@example.com'
    });
    result.checks.installReadonlyScreen = erpFieldB06J38_07_09_getScreenPackData({
      roleCode: 'STAFF_INSTALL',
      vendorId: 'VENDOR-SAMPLE',
      eventId: 'EVT-SAMPLE',
      route: 'install',
      userEmail: 'staff.install@example.com'
    });
    result.checks.asReadonlyScreen = erpFieldB06J38_07_09_getScreenPackData({
      roleCode: 'STAFF_AS',
      vendorId: 'VENDOR-SAMPLE',
      eventId: 'EVT-SAMPLE',
      route: 'as',
      userEmail: 'staff.as@example.com'
    });
    result.checks.missingVendorBlocked = erpFieldB06J38_07_09_getScreenPackData({
      roleCode: 'VENDOR_MANAGER',
      vendorId: '',
      eventId: 'EVT-SAMPLE',
      route: 'customerLookup',
      userEmail: 'missing.vendor@example.com'
    });
    result.checks.unknownRoleBlocked = erpFieldB06J38_07_09_getScreenPackData({
      roleCode: 'UNKNOWN_ROLE',
      vendorId: 'VENDOR-SAMPLE',
      eventId: 'EVT-SAMPLE',
      route: 'customerLookup',
      userEmail: 'unknown.role@example.com'
    });
    result.checks.unknownRouteBlocked = erpFieldB06J38_07_09_getScreenPackData({
      roleCode: 'VENDOR_MANAGER',
      vendorId: 'VENDOR-SAMPLE',
      eventId: 'EVT-SAMPLE',
      route: 'dangerWrite',
      userEmail: 'unknown.route@example.com'
    });

    var fatal = [];
    var trueKeys = ['config', 'renderFunctionAvailable', 'customerLookupScreen', 'salesReadonlyScreen', 'contractReadonlyScreen', 'installReadonlyScreen', 'asReadonlyScreen'];
    for (var i = 0; i < trueKeys.length; i++) {
      var key = trueKeys[i];
      if (!result.checks[key] || result.checks[key].ok !== true) {
        fatal = fatal.concat((result.checks[key] && result.checks[key].fatal) || [key + ' 실패']);
      }
    }
    var falseKeys = ['missingVendorBlocked', 'unknownRoleBlocked', 'unknownRouteBlocked'];
    for (var j = 0; j < falseKeys.length; j++) {
      var fkey = falseKeys[j];
      if (!result.checks[fkey] || result.checks[fkey].ok !== false) fatal.push(fkey + ' 차단 실패');
    }

    var safetyKeys = ['customerLookupScreen', 'salesReadonlyScreen', 'contractReadonlyScreen', 'installReadonlyScreen', 'asReadonlyScreen'];
    for (var k = 0; k < safetyKeys.length; k++) {
      var skey = safetyKeys[k];
      var s = result.checks[skey] && result.checks[skey].safety;
      if (!s || s.buttonsDisabled !== true || s.noSheetWrite !== true || s.noSaveExecution !== true || s.noUpdateExecution !== true) {
        fatal.push(skey + ': 안전 플래그 실패');
      }
    }

    result.fatal = fatal;
    result.ok = fatal.length === 0;
  } catch (err) {
    result.ok = false;
    result.fatal.push(String(err && err.message ? err.message : err));
  }

  Logger.log('======================================================');
  Logger.log(JSON.stringify(result, null, 2));
  Logger.log('======================================================');
  return result;
}

function erpFieldB06J38_07_09_renderScreenPackHtml(context) {
  var data = erpFieldB06J38_07_09_getScreenPackData(context || {});
  if (!data.ok) return erpFieldB06J38_07_09_renderBlockedHtml_(data);

  try {
    var template = HtmlService.createTemplateFromFile('P_Screen');
    template.screenModelJson = JSON.stringify(data.viewModel || {}, null, 2);
    return template.evaluate()
      .setTitle('필하우스 ERP FIELD - ' + (data.viewModel.pageTitle || 'READ ONLY'))
      .setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL);
  } catch (err) {
    return erpFieldB06J38_07_09_renderInlineHtml_(data);
  }
}

function erpFieldB06J38_07_09_getScreenPackData(context) {
  var ctx = erpFieldB06J38_07_09_normalizeContext_(context || {});
  var fatal = [];
  var warnings = [];
  var rolePolicy = erpFieldB06J38_07_09_rolePolicy_();
  var routeCatalog = erpFieldB06J38_07_09_routeCatalog_();

  if (!ctx.vendorId) fatal.push('FIELD 진입 차단: vendorId 누락');
  if (!rolePolicy[ctx.roleCode]) fatal.push('FIELD 진입 차단: 허용되지 않은 roleCode');
  if (!routeCatalog[ctx.route]) fatal.push('FIELD 진입 차단: 허용되지 않은 route');
  if (rolePolicy[ctx.roleCode] && routeCatalog[ctx.route] && rolePolicy[ctx.roleCode].routes.indexOf(ctx.route) < 0) {
    fatal.push('FIELD 진입 차단: 해당 roleCode에서 접근 불가 route');
  }

  if (fatal.length) {
    return {
      ok: false,
      build: FIELD_READ_PACK_BUILD,
      moduleCode: FIELD_READ_PACK_MODULE,
      checkedAt: new Date().toISOString(),
      fatal: fatal,
      warnings: warnings,
      context: ctx,
      safety: erpFieldB06J38_07_09_safety_()
    };
  }

  var routeInfo = routeCatalog[ctx.route];
  var dataBlock = erpFieldB06J38_07_09_buildDataBlock_(ctx, routeInfo);
  warnings = warnings.concat(dataBlock.warnings || []);

  var viewModel = {
    build: FIELD_READ_PACK_BUILD,
    moduleCode: FIELD_READ_PACK_MODULE,
    pageTitle: routeInfo.title,
    pageSubtitle: routeInfo.desc,
    roleName: rolePolicy[ctx.roleCode].roleName,
    context: ctx,
    route: routeInfo,
    summaryCards: erpFieldB06J38_07_09_summaryCards_(ctx, routeInfo, dataBlock),
    dataBlock: dataBlock,
    actionButtons: erpFieldB06J38_07_09_actionButtons_(ctx.route),
    notices: erpFieldB06J38_07_09_notices_(ctx, routeInfo),
    footer: {
      company: '(주)필하우스',
      copyright: '© 2026 FEELHAUS. All rights reserved.',
      developer: '개발담당: 이용필',
      operator: '최고운영자: 이용필'
    },
    safety: erpFieldB06J38_07_09_safety_()
  };

  return {
    ok: true,
    build: FIELD_READ_PACK_BUILD,
    moduleCode: FIELD_READ_PACK_MODULE,
    checkedAt: new Date().toISOString(),
    fatal: [],
    warnings: warnings,
    context: ctx,
    viewModel: viewModel,
    safety: erpFieldB06J38_07_09_safety_()
  };
}

function erpFieldB06J38_07_09_buildDataBlock_(ctx, routeInfo) {
  if (ctx.route === 'customerLookup') {
    return erpFieldB06J38_07_09_customerBlock_(ctx, routeInfo);
  }
  return erpFieldB06J38_07_09_placeholderBlock_(ctx, routeInfo);
}

function erpFieldB06J38_07_09_customerBlock_(ctx, routeInfo) {
  var warnings = [];
  var rows = [];
  var count = 0;
  var sourceBuild = 'LOCAL_PLACEHOLDER';
  try {
    if (typeof this.erpFieldB06J38_06_searchCustomerReadonly === 'function') {
      var res = this.erpFieldB06J38_06_searchCustomerReadonly({
        roleCode: ctx.roleCode,
        vendorId: ctx.vendorId,
        eventId: ctx.eventId,
        keyword: ctx.keyword,
        limit: ctx.limit,
        userEmail: ctx.userEmail
      });
      sourceBuild = res.build || 'B06J38_06';
      if (res && res.ok === true) {
        rows = res.rows || [];
        count = Number(res.count || rows.length || 0);
        warnings = warnings.concat(res.warnings || []);
      } else {
        warnings = warnings.concat((res && res.fatal) || ['고객 READ ONLY 조회 결과 없음']);
      }
    } else {
      warnings.push('B06J38-06 고객 READ ONLY 함수 미탑재: 빈 목록으로 표시');
    }
  } catch (err) {
    warnings.push('고객 READ ONLY 조회 중 예외: ' + String(err && err.message ? err.message : err));
  }

  return {
    blockType: 'CUSTOMER_READONLY_LIST',
    title: '고객 조회 결과',
    desc: 'ERP_고객관리 기준 HeaderMap READ ONLY 조회 결과입니다.',
    sourceBuild: sourceBuild,
    columns: ['customerId', 'name', 'dong', 'ho', 'phoneMasked', 'status'],
    rows: rows,
    count: count,
    emptyMessage: count ? '' : '조회 가능한 고객 데이터가 없습니다. vendorId / eventId 범위 또는 검색어를 확인하세요.',
    warnings: warnings,
    readOnly: true,
    writeBlocked: true
  };
}

function erpFieldB06J38_07_09_placeholderBlock_(ctx, routeInfo) {
  var placeholderMap = {
    sales: {
      blockType: 'SALES_READONLY_PLACEHOLDER',
      title: '판매 READ ONLY 자리',
      desc: '판매 등록 화면 자리만 표시합니다. 실제 판매 저장은 아직 차단됩니다.',
      columns: ['saleId', 'customerId', 'amount', 'status']
    },
    contract: {
      blockType: 'CONTRACT_READONLY_PLACEHOLDER',
      title: '계약 READ ONLY 자리',
      desc: '계약/서명 연결 화면 자리만 표시합니다. 계약 생성/수정은 아직 차단됩니다.',
      columns: ['contractId', 'saleId', 'documentId', 'status']
    },
    install: {
      blockType: 'INSTALL_READONLY_PLACEHOLDER',
      title: '설치 READ ONLY 자리',
      desc: '설치 일정/완료 확인 화면 자리만 표시합니다. 설치 완료 저장은 아직 차단됩니다.',
      columns: ['installId', 'customerId', 'scheduledAt', 'status']
    },
    as: {
      blockType: 'AS_READONLY_PLACEHOLDER',
      title: 'A/S READ ONLY 자리',
      desc: 'A/S 접수/처리 화면 자리만 표시합니다. 처리 저장은 아직 차단됩니다.',
      columns: ['asId', 'customerId', 'requestStatus', 'status']
    }
  };
  var item = placeholderMap[ctx.route] || placeholderMap.sales;
  return {
    blockType: item.blockType,
    title: item.title,
    desc: item.desc,
    columns: item.columns,
    rows: [],
    count: 0,
    emptyMessage: 'B06J38-07_09 단계에서는 화면 자리만 준비하며 실제 업무 데이터 조회/저장은 열지 않습니다.',
    warnings: [],
    readOnly: true,
    writeBlocked: true
  };
}

function erpFieldB06J38_07_09_summaryCards_(ctx, routeInfo, dataBlock) {
  return [
    { label: '현재 화면', value: routeInfo.title, help: routeInfo.route },
    { label: '조회 건수', value: String(dataBlock.count || 0), help: 'READ ONLY' },
    { label: '역할', value: ctx.roleCode, help: '권한 기준' },
    { label: '저장상태', value: '차단', help: '시트쓰기 없음' }
  ];
}

function erpFieldB06J38_07_09_actionButtons_(route) {
  var labels = {
    customerLookup: ['검색 실행 자리', '고객 상세 자리', '엑셀 다운로드 차단'],
    sales: ['판매 등록 차단', '임시저장 차단', '계약생성 차단'],
    contract: ['계약 생성 차단', '서명 연결 차단', 'PDF 출력 차단'],
    install: ['설치 완료 차단', '일정 변경 차단', '사진 첨부 차단'],
    as: ['A/S 처리 차단', '비용 입력 차단', '완료 처리 차단']
  };
  var list = labels[route] || ['업무 실행 차단'];
  return list.map(function (title) {
    return { title: title, enabled: false, disabledReason: 'B06J38-07_09 READ ONLY 화면 단계: 실행 차단' };
  });
}

function erpFieldB06J38_07_09_notices_(ctx, routeInfo) {
  return [
    'B06J38-07_09는 고객조회 화면 연결과 판매/계약/설치/A/S READ ONLY 자리 구성 단계입니다.',
    '현재 route=' + routeInfo.route + ' 화면은 조회/표시 중심이며 모든 업무 실행 버튼은 비활성화됩니다.',
    '저장, 수정, 삭제, 정산, 외부연동, 파일다운로드는 실행되지 않습니다.',
    '업체는 별도 앱이 아니라 ERP 내부 지점형 사용자 그룹이며 vendorId / eventId / roleCode 기준으로 제한됩니다.'
  ];
}

function erpFieldB06J38_07_09_normalizeContext_(context) {
  var c = context || {};
  return {
    roleCode: String(c.roleCode || c.role || 'VIEWER').trim().toUpperCase(),
    vendorId: String(c.vendorId || '').trim(),
    eventId: String(c.eventId || '').trim(),
    userEmail: String(c.userEmail || erpFieldB06J38_07_09_getUserEmail_()).trim(),
    route: erpFieldB06J38_07_09_normalizeRoute_(c.route || c.page || 'customerLookup'),
    keyword: String(c.keyword || '').trim(),
    limit: Number(c.limit || 20) || 20,
    scopeType: 'VENDOR_BRANCH_USER_GROUP',
    dataPolicy: 'vendorId / eventId / roleCode 기준 READ ONLY 제한',
    hqFullAccess: false
  };
}

function erpFieldB06J38_07_09_normalizeRoute_(value) {
  var lower = String(value || '').trim().toLowerCase();
  var map = {
    'customerlookup': 'customerLookup',
    'customer': 'customerLookup',
    'sales': 'sales',
    'sale': 'sales',
    'contract': 'contract',
    'install': 'install',
    'installation': 'install',
    'as': 'as',
    'a/s': 'as'
  };
  return map[lower] || String(value || 'customerLookup').trim();
}

function erpFieldB06J38_07_09_routeCatalog_() {
  return {
    customerLookup: { route: 'customerLookup', menuCode: 'CUSTOMER_LOOKUP', title: '고객 조회', desc: 'eventId / vendorId 기준 고객 READ ONLY 조회 화면' },
    sales: { route: 'sales', menuCode: 'SALES', title: '판매', desc: '판매 등록 화면 자리. 현재 READ ONLY / 저장 차단' },
    contract: { route: 'contract', menuCode: 'CONTRACT', title: '계약', desc: '계약/서명 연결 화면 자리. 현재 READ ONLY / 생성 차단' },
    install: { route: 'install', menuCode: 'INSTALL', title: '설치', desc: '설치 일정/완료 화면 자리. 현재 READ ONLY / 완료 저장 차단' },
    as: { route: 'as', menuCode: 'AS', title: 'A/S', desc: 'A/S 접수/처리 화면 자리. 현재 READ ONLY / 처리 저장 차단' }
  };
}

function erpFieldB06J38_07_09_rolePolicy_() {
  return {
    VENDOR_OWNER: { roleName: '업체대표', routes: ['customerLookup', 'sales', 'contract', 'install', 'as'] },
    VENDOR_MANAGER: { roleName: '업체관리자', routes: ['customerLookup', 'sales', 'contract', 'install', 'as'] },
    STAFF_SALES: { roleName: '영업직원', routes: ['customerLookup', 'sales', 'contract'] },
    STAFF_INSTALL: { roleName: '설치담당', routes: ['customerLookup', 'install'] },
    STAFF_AS: { roleName: 'A/S담당', routes: ['customerLookup', 'as'] },
    VIEWER: { roleName: '조회전용', routes: ['customerLookup'] }
  };
}

function erpFieldB06J38_07_09_safety_() {
  return {
    readOnlyScreenPack: true,
    customerScreenBindOnly: true,
    salesContractPlaceholderOnly: true,
    installAsPlaceholderOnly: true,
    uiDisplayOnly: true,
    buttonsDisabled: true,
    noBusinessStateMutation: true,
    noSheetWrite: true,
    noSaveExecution: true,
    noUpdateExecution: true,
    noDeleteExecution: true,
    paymentExecutionBlocked: true,
    settlementExecutionBlocked: true,
    externalIntegrationBlocked: true,
    fileDownloadBlocked: true,
    vendorIndependentDbBlocked: true,
    vendorAsBranchUserGroup: true
  };
}

function erpFieldB06J38_07_09_getConfigCheck_() {
  try {
    if (typeof this.fieldCustomerRead_getConfig_ === 'function') {
      return this.fieldCustomerRead_getConfig_();
    }
    return {
      ok: true,
      fatal: [],
      warnings: ['B06J38-06 config helper 직접 접근 불가: B06J38-07_09 자체 안전점검으로 대체'],
      delegatedFrom: 'B06J38_07_09'
    };
  } catch (err) {
    return { ok: false, fatal: [String(err && err.message ? err.message : err)], warnings: [] };
  }
}

function erpFieldB06J38_07_09_renderBlockedHtml_(data) {
  var ctx = data.context || {};
  var html = '<!doctype html><html lang="ko"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>FIELD 진입 차단</title>' +
    '<style>body{margin:0;background:#f9fafb;font-family:Arial,\'Noto Sans KR\',sans-serif;color:#111827}.wrap{max-width:760px;margin:60px auto;padding:20px}.card{background:#fff;border:1px solid #e5e7eb;border-radius:18px;padding:24px}.fatal{color:#b91c1c;background:#fee2e2;border:1px solid #fecaca;border-radius:12px;padding:12px;margin:8px 0}.muted{color:#6b7280;font-size:13px}</style></head><body><div class="wrap"><div class="card"><h1>FIELD 진입 차단</h1>' +
    '<p>vendorId / roleCode / route 기준 검증을 통과하지 못했습니다.</p>' +
    (data.fatal || []).map(function (f) { return '<div class="fatal">' + erpFieldB06J38_07_09_escapeHtml_(f) + '</div>'; }).join('') +
    '<p class="muted">roleCode=' + erpFieldB06J38_07_09_escapeHtml_(ctx.roleCode || '') + ' / vendorId=' + erpFieldB06J38_07_09_escapeHtml_(ctx.vendorId || '') + ' / route=' + erpFieldB06J38_07_09_escapeHtml_(ctx.route || '') + '</p>' +
    '</div></div></body></html>';
  return HtmlService.createHtmlOutput(html).setTitle('FIELD 진입 차단');
}

function erpFieldB06J38_07_09_renderInlineHtml_(data) {
  var model = data.viewModel || {};
  var block = model.dataBlock || {};
  var html = '<!doctype html><html lang="ko"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>필하우스 ERP FIELD</title>' +
    '<style>body{margin:0;background:#f6f7fb;font-family:Arial,\'Noto Sans KR\',sans-serif;color:#111827}.wrap{max-width:1100px;margin:0 auto;padding:22px}.card,.panel{background:#fff;border:1px solid #e5e7eb;border-radius:18px;padding:18px;margin-bottom:14px}.badge{display:inline-block;border-radius:999px;background:#111827;color:#fff;padding:6px 10px;font-size:12px}.muted{color:#6b7280}.btn{border:0;border-radius:12px;background:#e5e7eb;color:#6b7280;padding:10px 12px;cursor:not-allowed}table{width:100%;border-collapse:collapse}th,td{border-bottom:1px solid #e5e7eb;padding:9px;text-align:left;font-size:13px}</style></head><body><div class="wrap"><div class="card"><span class="badge">B06J38-07_09 SAFE</span><h1>' + erpFieldB06J38_07_09_escapeHtml_(model.pageTitle || '') + '</h1><p class="muted">' + erpFieldB06J38_07_09_escapeHtml_(model.pageSubtitle || '') + '</p></div>' +
    '<div class="panel"><h2>' + erpFieldB06J38_07_09_escapeHtml_(block.title || '') + '</h2><p class="muted">' + erpFieldB06J38_07_09_escapeHtml_(block.emptyMessage || block.desc || '') + '</p><button class="btn" disabled>실행 차단</button></div></div></body></html>';
  return HtmlService.createHtmlOutput(html).setTitle('필하우스 ERP FIELD');
}

function erpFieldB06J38_07_09_getUserEmail_() {
  try {
    return Session.getActiveUser().getEmail() || '';
  } catch (err) {
    return '';
  }
}

function erpFieldB06J38_07_09_escapeHtml_(value) {
  return String(value == null ? '' : value)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}


/* ===== ClosePack.js ===== */
/**
 * build: ERP_B06J38_10_12_FIELD_BASELINE_CLOSE_PACK_SAFE
 * file: FieldClosePack.js
 * module: ERP_FIELD
 * purpose:
 * - B06J38-10 내 처리현황 READ ONLY 화면/가드
 * - B06J38-11 FIELD 권한/메뉴 최종 점검
 * - B06J38-12 FIELD 최소 운영 기준본 확정 점검
 * - 모든 버튼 비활성, 저장/수정/삭제/정산/외부연동/시트쓰기 없음
 */

var FIELD_CLOSE_PACK_BUILD = 'ERP_B06J38_10_12_FIELD_BASELINE_CLOSE_PACK_SAFE';
var FIELD_CLOSE_PACK_MODULE = 'ERP_FIELD';
var FIELD_CLOSE_PACK_ROUTES = ['myStatus', 'settlementView', 'staffManagement'];

function erpB06J38_10_12_autoRunSafe() {
  var result = {
    ok: true,
    build: FIELD_CLOSE_PACK_BUILD,
    moduleCode: FIELD_CLOSE_PACK_MODULE,
    checkedAt: new Date().toISOString(),
    fatal: [],
    warnings: [],
    checks: {}
  };

  try {
    result.checks.config = erpFieldB06J38_10_12_getConfigCheck_();
    result.checks.renderFunctionAvailable = {
      ok: typeof this.erpFieldB06J38_10_12_renderClosePackHtml === 'function',
      fatal: typeof this.erpFieldB06J38_10_12_renderClosePackHtml === 'function' ? [] : ['B06J38-10_12 화면 렌더 함수 미탑재'],
      warnings: []
    };

    result.checks.myStatusVendorManager = erpFieldB06J38_10_12_getClosePackData({
      roleCode: 'VENDOR_MANAGER', vendorId: 'VENDOR-SAMPLE', eventId: 'EVT-SAMPLE', route: 'myStatus', userEmail: 'vendor.manager@example.com'
    });
    result.checks.myStatusStaffSales = erpFieldB06J38_10_12_getClosePackData({
      roleCode: 'STAFF_SALES', vendorId: 'VENDOR-SAMPLE', eventId: 'EVT-SAMPLE', route: 'myStatus', userEmail: 'staff.sales@example.com'
    });
    result.checks.settlementViewVendorOwner = erpFieldB06J38_10_12_getClosePackData({
      roleCode: 'VENDOR_OWNER', vendorId: 'VENDOR-SAMPLE', eventId: 'EVT-SAMPLE', route: 'settlementView', userEmail: 'vendor.owner@example.com'
    });
    result.checks.staffManagementVendorOwner = erpFieldB06J38_10_12_getClosePackData({
      roleCode: 'VENDOR_OWNER', vendorId: 'VENDOR-SAMPLE', eventId: 'EVT-SAMPLE', route: 'staffManagement', userEmail: 'vendor.owner@example.com'
    });
    result.checks.permissionMenuMatrix = erpFieldB06J38_10_12_checkPermissionMenuMatrix_();
    result.checks.baselineClose = erpFieldB06J38_10_12_checkBaselineClose_();

    result.checks.missingVendorBlocked = erpFieldB06J38_10_12_getClosePackData({
      roleCode: 'VENDOR_MANAGER', vendorId: '', eventId: 'EVT-SAMPLE', route: 'myStatus', userEmail: 'missing.vendor@example.com'
    });
    result.checks.unknownRoleBlocked = erpFieldB06J38_10_12_getClosePackData({
      roleCode: 'UNKNOWN_ROLE', vendorId: 'VENDOR-SAMPLE', eventId: 'EVT-SAMPLE', route: 'myStatus', userEmail: 'unknown.role@example.com'
    });
    result.checks.unauthorizedRouteBlocked = erpFieldB06J38_10_12_getClosePackData({
      roleCode: 'STAFF_SALES', vendorId: 'VENDOR-SAMPLE', eventId: 'EVT-SAMPLE', route: 'settlementView', userEmail: 'staff.sales@example.com'
    });

    var fatal = [];
    var passKeys = ['config', 'renderFunctionAvailable', 'myStatusVendorManager', 'myStatusStaffSales', 'settlementViewVendorOwner', 'staffManagementVendorOwner', 'permissionMenuMatrix', 'baselineClose'];
    for (var i = 0; i < passKeys.length; i++) {
      var key = passKeys[i];
      if (!result.checks[key] || result.checks[key].ok !== true) fatal = fatal.concat((result.checks[key] && result.checks[key].fatal) || [key + ' 실패']);
    }
    var blockKeys = ['missingVendorBlocked', 'unknownRoleBlocked', 'unauthorizedRouteBlocked'];
    for (var j = 0; j < blockKeys.length; j++) {
      var bkey = blockKeys[j];
      if (!result.checks[bkey] || result.checks[bkey].ok !== false) fatal.push(bkey + ' 차단 실패');
    }

    var safetyKeys = ['myStatusVendorManager', 'myStatusStaffSales', 'settlementViewVendorOwner', 'staffManagementVendorOwner'];
    for (var k = 0; k < safetyKeys.length; k++) {
      var skey = safetyKeys[k];
      var s = result.checks[skey] && result.checks[skey].safety;
      if (!s || s.buttonsDisabled !== true || s.noSheetWrite !== true || s.noSaveExecution !== true || s.noUpdateExecution !== true || s.settlementExecutionBlocked !== true) fatal.push(skey + ': 안전 플래그 실패');
    }

    result.fatal = fatal;
    result.ok = fatal.length === 0;
  } catch (err) {
    result.ok = false;
    result.fatal.push(String(err && err.message ? err.message : err));
  }

  Logger.log('======================================================');
  Logger.log(JSON.stringify(result, null, 2));
  Logger.log('======================================================');
  return result;
}

function erpFieldB06J38_10_12_renderClosePackHtml(context) {
  var data = erpFieldB06J38_10_12_getClosePackData(context || {});
  if (!data.ok) return erpFieldB06J38_10_12_renderBlockedHtml_(data);
  try {
    var template = HtmlService.createTemplateFromFile('P_Close');
    template.closeModelJson = JSON.stringify(data.viewModel || {}, null, 2);
    return template.evaluate()
      .setTitle('필하우스 ERP FIELD - ' + (data.viewModel.pageTitle || '기준본'))
      .setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL);
  } catch (err) {
    return erpFieldB06J38_10_12_renderInlineHtml_(data);
  }
}

function erpFieldB06J38_10_12_getClosePackData(context) {
  var ctx = erpFieldB06J38_10_12_normalizeContext_(context || {});
  var rolePolicy = erpFieldB06J38_10_12_rolePolicy_();
  var routeCatalog = erpFieldB06J38_10_12_routeCatalog_();
  var fatal = [];
  var warnings = [];

  if (!ctx.vendorId) fatal.push('FIELD 진입 차단: vendorId 누락');
  if (!rolePolicy[ctx.roleCode]) fatal.push('FIELD 진입 차단: 허용되지 않은 roleCode');
  if (!routeCatalog[ctx.route]) fatal.push('FIELD 진입 차단: 허용되지 않은 route');
  if (rolePolicy[ctx.roleCode] && routeCatalog[ctx.route] && rolePolicy[ctx.roleCode].routes.indexOf(ctx.route) < 0) fatal.push('FIELD 진입 차단: 해당 roleCode에서 접근 불가 route');

  if (fatal.length) {
    return { ok: false, build: FIELD_CLOSE_PACK_BUILD, moduleCode: FIELD_CLOSE_PACK_MODULE, checkedAt: new Date().toISOString(), fatal: fatal, warnings: warnings, context: ctx, safety: erpFieldB06J38_10_12_safety_() };
  }

  var routeInfo = routeCatalog[ctx.route];
  var roleInfo = rolePolicy[ctx.roleCode];
  var dataBlock = erpFieldB06J38_10_12_buildDataBlock_(ctx, routeInfo);

  var viewModel = {
    build: FIELD_CLOSE_PACK_BUILD,
    moduleCode: FIELD_CLOSE_PACK_MODULE,
    pageTitle: routeInfo.title,
    pageSubtitle: routeInfo.desc,
    roleName: roleInfo.roleName,
    context: ctx,
    route: routeInfo,
    summaryCards: erpFieldB06J38_10_12_summaryCards_(ctx, routeInfo, dataBlock),
    dataBlock: dataBlock,
    permissionNotice: erpFieldB06J38_10_12_permissionNotice_(ctx, routeInfo),
    actionButtons: erpFieldB06J38_10_12_actionButtons_(ctx.route),
    baseline: erpFieldB06J38_10_12_baselineModel_(),
    footer: {
      company: '(주)필하우스',
      copyright: '© 2026 FEELHAUS. All rights reserved.',
      developer: '개발담당: 이용필',
      operator: '최고운영자: 이용필'
    },
    safety: erpFieldB06J38_10_12_safety_()
  };

  return { ok: true, build: FIELD_CLOSE_PACK_BUILD, moduleCode: FIELD_CLOSE_PACK_MODULE, checkedAt: new Date().toISOString(), fatal: [], warnings: warnings, context: ctx, viewModel: viewModel, safety: erpFieldB06J38_10_12_safety_() };
}

function erpFieldB06J38_10_12_buildDataBlock_(ctx, routeInfo) {
  if (ctx.route === 'myStatus') {
    return {
      blockType: 'MY_STATUS_READONLY',
      title: '내 처리현황',
      desc: '현재 단계에서는 실제 업무 데이터를 변경하지 않고 처리현황 자리만 표시합니다.',
      columns: ['구분', '대기', '진행', '완료', '안내'],
      rows: [
        { category: '고객조회', pending: 0, progress: 0, done: 0, notice: 'READ ONLY' },
        { category: '판매/계약', pending: 0, progress: 0, done: 0, notice: '자리 준비' },
        { category: '설치/A/S', pending: 0, progress: 0, done: 0, notice: '자리 준비' }
      ],
      emptyMessage: 'B06J38 기준본 단계입니다. 실제 처리현황 데이터 연결은 후속 빌드에서 진행합니다.',
      readOnly: true
    };
  }

  if (ctx.route === 'settlementView') {
    return {
      blockType: 'SETTLEMENT_VIEW_BLOCKED_READONLY',
      title: '정산 조회',
      desc: '정산 조회 메뉴 자리는 표시하지만 금액 조회/지급/수정은 아직 차단됩니다.',
      columns: ['항목', '상태', '안내'],
      rows: [
        { item: '정산 요약', status: 'BLOCKED', notice: '후속 정산 조회 가드 이후 연결' },
        { item: '지급/차감 실행', status: 'BLOCKED', notice: '실행 불가' },
        { item: '다운로드', status: 'BLOCKED', notice: '권한/승인 기반 후속 처리' }
      ],
      readOnly: true
    };
  }

  return {
    blockType: 'STAFF_MANAGEMENT_APPROVAL_PLACEHOLDER',
    title: '직원 관리',
    desc: '업체 직원/권한 관리 자리를 표시합니다. 민감 권한은 본사 승인 기반입니다.',
    columns: ['기능', '상태', '승인정책'],
    rows: [
      { feature: '직원 목록', status: 'READ ONLY 자리', policy: 'vendorId 기준 제한' },
      { feature: '일반 역할 변경', status: '후속 기능', policy: '업체대표 일부 가능' },
      { feature: '정산/다운로드/민감권한', status: '차단', policy: '본사 승인 필요' }
    ],
    readOnly: true
  };
}

function erpFieldB06J38_10_12_checkPermissionMenuMatrix_() {
  var rolePolicy = erpFieldB06J38_10_12_rolePolicy_();
  var fatal = [];
  if (rolePolicy.STAFF_SALES.routes.indexOf('settlementView') >= 0) fatal.push('STAFF_SALES 정산조회 노출 금지 위반');
  if (rolePolicy.STAFF_INSTALL.routes.indexOf('sales') >= 0) fatal.push('STAFF_INSTALL 판매 노출 금지 위반');
  if (rolePolicy.VIEWER.routes.indexOf('staffManagement') >= 0) fatal.push('VIEWER 직원관리 노출 금지 위반');
  if (rolePolicy.VENDOR_MANAGER.routes.indexOf('staffManagement') >= 0) fatal.push('VENDOR_MANAGER 직원관리 직접 노출 금지 위반');
  return { ok: fatal.length === 0, fatal: fatal, warnings: [], policy: rolePolicy, safety: erpFieldB06J38_10_12_safety_() };
}

function erpFieldB06J38_10_12_checkBaselineClose_() {
  var requiredBuilds = [
    'B06J38-01 FIELD 최소 진입 화면',
    'B06J38-02 doGet 기본 라우팅',
    'B06J38-03 메뉴 부트스트랩',
    'B06J38-04 화면-메뉴 데이터 연결',
    'B06J38-05 doGet 화면전환 연결',
    'B06J38-06 고객조회 READ ONLY 가드',
    'B06J38-07~09 READ ONLY 화면팩',
    'B06J38-10~12 기준본 종료팩'
  ];
  return {
    ok: true,
    fatal: [],
    warnings: [],
    baselineStatus: 'FIELD_MIN_OPERATION_BASELINE_READY',
    releaseLevel: 'BASELINE_CLOSE_PACK_SAFE',
    requiredBuilds: requiredBuilds,
    safety: erpFieldB06J38_10_12_safety_(),
    nextStage: 'B06J39_FIELD_CUSTOMER_LOOKUP_PRACTICAL_USE'
  };
}

function erpFieldB06J38_10_12_getConfigCheck_() {
  if (typeof this.erpFieldB06J38_07_09_getConfigCheck_ === 'function') {
    try {
      var r = this.erpFieldB06J38_07_09_getConfigCheck_();
      r.delegatedFrom = 'B06J38_07_09';
      return r;
    } catch (ignore) {}
  }
  return { ok: true, fatal: [], warnings: ['SystemConfig 상세 점검 함수 미탑재: 후속 점검 위임 생략'], delegatedFrom: 'LOCAL_SAFE_FALLBACK' };
}

function erpFieldB06J38_10_12_normalizeContext_(context) {
  var p = (context && context.parameter) ? context.parameter : context;
  return {
    roleCode: String((p && p.roleCode) || 'VIEWER').trim().toUpperCase(),
    vendorId: String((p && p.vendorId) || '').trim(),
    eventId: String((p && p.eventId) || '').trim(),
    route: erpFieldB06J38_10_12_normalizeRoute_((p && (p.route || p.page)) || 'myStatus'),
    userEmail: String((p && p.userEmail) || '').trim(),
    scopeType: 'VENDOR_BRANCH_USER_GROUP',
    dataPolicy: 'vendorId / eventId / roleCode 기준 READ ONLY 제한',
    hqFullAccess: false
  };
}

function erpFieldB06J38_10_12_normalizeRoute_(route) {
  var raw = String(route || 'myStatus').trim();
  var lower = raw.toLowerCase();
  var map = { mystatus: 'myStatus', status: 'myStatus', settlementview: 'settlementView', settlement: 'settlementView', staffmanagement: 'staffManagement', staff: 'staffManagement' };
  return map[lower] || raw;
}

function erpFieldB06J38_10_12_routeCatalog_() {
  return {
    myStatus: { route: 'myStatus', menuCode: 'MY_STATUS', title: '내 처리현황', desc: '내 업무 처리 현황 READ ONLY 화면' },
    settlementView: { route: 'settlementView', menuCode: 'SETTLEMENT_VIEW', title: '정산 조회', desc: '정산 조회 자리. 수정/지급/다운로드 실행 차단' },
    staffManagement: { route: 'staffManagement', menuCode: 'STAFF_MANAGEMENT', title: '직원 관리', desc: '업체 직원/권한 관리 자리. 민감권한 본사 승인 필요' }
  };
}

function erpFieldB06J38_10_12_rolePolicy_() {
  return {
    VENDOR_OWNER: { roleName: '업체대표', routes: ['myStatus', 'settlementView', 'staffManagement'] },
    VENDOR_MANAGER: { roleName: '업체관리자', routes: ['myStatus', 'settlementView'] },
    STAFF_SALES: { roleName: '영업직원', routes: ['myStatus'] },
    STAFF_INSTALL: { roleName: '설치담당', routes: ['myStatus'] },
    STAFF_AS: { roleName: 'A/S담당', routes: ['myStatus'] },
    VIEWER: { roleName: '조회전용', routes: ['myStatus'] }
  };
}

function erpFieldB06J38_10_12_summaryCards_(ctx, routeInfo, dataBlock) {
  return [
    { label: '화면', value: routeInfo.title, desc: 'READ ONLY' },
    { label: '행사', value: ctx.eventId || '미지정', desc: 'eventId 기준' },
    { label: '업체', value: ctx.vendorId || '차단', desc: 'vendorId 기준' },
    { label: '안전상태', value: '차단 유지', desc: '저장/수정 없음' }
  ];
}

function erpFieldB06J38_10_12_actionButtons_(route) {
  var names = route === 'staffManagement' ? ['직원추가', '권한변경 요청', '비활성화'] : (route === 'settlementView' ? ['정산 상세', '다운로드', '지급 확인'] : ['새로고침', '상세보기', '처리하기']);
  var out = [];
  for (var i = 0; i < names.length; i++) out.push({ title: names[i], enabled: false, disabledReason: 'B06J38 기준본 단계: 업무 실행 차단' });
  return out;
}

function erpFieldB06J38_10_12_permissionNotice_(ctx, routeInfo) {
  return {
    title: '권한/메뉴 최종 점검 기준',
    messages: [
      '업체는 별도 앱이 아니라 ERP 내부 지점형 사용자 그룹입니다.',
      'vendorId / eventId / roleCode 기준으로 화면 접근을 제한합니다.',
      '정산/다운로드/민감권한은 본사 승인 기반 후속 단계에서만 열립니다.',
      '현재 단계는 기준본 확정 전 READ ONLY 화면입니다.'
    ]
  };
}

function erpFieldB06J38_10_12_baselineModel_() {
  return {
    build: FIELD_CLOSE_PACK_BUILD,
    status: 'FIELD_MIN_OPERATION_BASELINE_READY',
    closedAt: new Date().toISOString(),
    next: 'B06J39 고객조회 실사용 단계',
    lockedSafety: erpFieldB06J38_10_12_safety_()
  };
}

function erpFieldB06J38_10_12_safety_() {
  return {
    closePackOnly: true,
    readOnlyGuard: true,
    uiDisplayOnly: true,
    buttonsDisabled: true,
    noBusinessStateMutation: true,
    noSheetWrite: true,
    noSaveExecution: true,
    noUpdateExecution: true,
    noDeleteExecution: true,
    paymentExecutionBlocked: true,
    settlementExecutionBlocked: true,
    externalIntegrationBlocked: true,
    vendorIndependentDbBlocked: true,
    vendorAsBranchUserGroup: true,
    headerMapBased: true,
    columnIndexFixed: false
  };
}

function erpFieldB06J38_10_12_renderBlockedHtml_(data) {
  var html = '<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>FIELD 진입 차단</title>' +
    '<style>body{font-family:Arial,sans-serif;background:#f8fafc;color:#111827;padding:24px}.box{max-width:860px;margin:auto;background:#fff;border:1px solid #e5e7eb;border-radius:18px;padding:28px;box-shadow:0 10px 30px rgba(15,23,42,.06)}.badge{display:inline-block;padding:6px 10px;border-radius:999px;background:#fee2e2;color:#991b1b;font-weight:700}pre{white-space:pre-wrap;background:#fff7f7;border:1px solid #fecaca;border-radius:12px;padding:14px;color:#b91c1c}</style></head>' +
    '<body><div class="box"><span class="badge">BLOCKED</span><h2>FIELD 진입 차단</h2><pre>' + erpFieldB06J38_10_12_escapeHtml_(JSON.stringify(data.fatal || [], null, 2)) + '</pre><p>vendorId / roleCode / route 기준 검증을 통과하지 못했습니다.</p></div></body></html>';
  return HtmlService.createHtmlOutput(html).setTitle('FIELD 진입 차단');
}

function erpFieldB06J38_10_12_renderInlineHtml_(data) {
  var vm = data.viewModel || {};
  var html = '<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>필하우스 ERP FIELD</title>' +
    '<style>body{font-family:Arial,sans-serif;background:#f8fafc;color:#111827;padding:24px}.wrap{max-width:1100px;margin:auto}.card{background:#fff;border:1px solid #e5e7eb;border-radius:18px;padding:22px;margin:14px 0;box-shadow:0 10px 30px rgba(15,23,42,.06)}.badge{display:inline-block;padding:6px 10px;border-radius:999px;background:#e0f2fe;color:#075985;font-weight:700}button{opacity:.5;cursor:not-allowed;border:0;border-radius:12px;padding:10px 14px;margin:4px}pre{white-space:pre-wrap;background:#0f172a;color:#e5e7eb;border-radius:14px;padding:16px}</style></head>' +
    '<body><div class="wrap"><div class="card"><span class="badge">B06J38-10_12 SAFE</span><h1>' + erpFieldB06J38_10_12_escapeHtml_(vm.pageTitle || 'FIELD 기준본') + '</h1><p>' + erpFieldB06J38_10_12_escapeHtml_(vm.pageSubtitle || '') + '</p></div>' +
    '<div class="card"><h3>실행 버튼</h3>' + (vm.actionButtons || []).map(function(b){ return '<button disabled>' + erpFieldB06J38_10_12_escapeHtml_(b.title) + '</button>'; }).join('') + '</div>' +
    '<div class="card"><h3>ViewModel</h3><pre>' + erpFieldB06J38_10_12_escapeHtml_(JSON.stringify(vm, null, 2)) + '</pre></div></div></body></html>';
  return HtmlService.createHtmlOutput(html).setTitle('필하우스 ERP FIELD');
}

function erpFieldB06J38_10_12_escapeHtml_(v) {
  return String(v == null ? '' : v).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;').replace(/'/g, '&#39;');
}
