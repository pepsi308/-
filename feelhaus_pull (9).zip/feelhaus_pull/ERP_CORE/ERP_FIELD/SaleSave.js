/* ===== SaleSave.js ===== */
/**
 * build: ERP_B06J40_28_30_SALES_DRAFT_SAVE_OPEN_SAFE_UPLOAD_FIX1
 * module: ERP_FIELD
 * purpose:
 * - B06J40-28 actual DRAFT save open for sales
 * - B06J40-29 HeaderMap-based append to Sales sheet
 * - B06J40-30 ERP_CoreLog save log record
 * safety:
 * - saves only status=DRAFT sales rows
 * - no contract creation / no settlement execution / no external integration / no update/delete
 */

var FIELD_SALES_DRAFT_SAVE_BUILD = 'ERP_FIELD_V35_DRAFT_SAVE_STABLE';

function erpB06J40_28_30_preflight() {
  var result = erpFieldB06J40_28_30_result_('preflight');
  result.checks.requiredFunctions = erpFieldB06J40_28_30_requiredFunctions_();
  result.checks.templateAvailable = erpFieldB06J40_28_30_templateCheck_();
  result.checks.salesSchema = erpFieldB06J40_28_30_checkSalesSchema_();
  result.checks.logTarget = erpFieldB06J40_28_30_checkCoreLog_();
  result.checks.safety = erpFieldB06J40_28_30_safetyCheck_();
  return erpFieldB06J40_28_30_finish_(result, true);
}

function erpB06J40_28_30_autoRunSafe() {
  var result = erpFieldB06J40_28_30_result_('autoRunSafe');
  result.checks.preflight = erpB06J40_28_30_preflight();
  result.checks.noConfirmDoesNotWrite = erpFieldB06J40_28_30_buildSaveViewModel_({
    roleCode: 'VENDOR_MANAGER', vendorId: 'VND-20260502202158-505', eventId: 'EVT-20260502202016-197', route: 'salesSave',
    customerId: 'CUS-SAMPLE', productName: '테스트상품', quantity: '1', unitPrice: '100000', paymentStructure: 'COMPANY_ALL', paymentMethod: 'CASH'
  }, false);
  result.checks.viewerBlocked = erpFieldB06J40_28_30_buildSaveViewModel_({
    roleCode: 'VIEWER', vendorId: 'VND-20260502202158-505', eventId: 'EVT-20260502202016-197', route: 'salesSave'
  }, false);
  result.checks.missingVendorBlocked = erpFieldB06J40_28_30_buildSaveViewModel_({
    roleCode: 'VENDOR_MANAGER', vendorId: '', eventId: 'EVT-20260502202016-197', route: 'salesSave'
  }, false);

  Object.keys(result.checks).forEach(function (k) {
    var c = result.checks[k];
    var expectedBlock = (k === 'viewerBlocked' || k === 'missingVendorBlocked');
    if (!c) {
      result.fatal.push(k + ': 결과 없음');
      return;
    }
    if (expectedBlock && c.ok !== false) result.fatal.push(k + ': 차단 기대 테스트가 차단되지 않음');
    if (!expectedBlock && c.ok === false && k !== 'noConfirmDoesNotWrite') result.fatal.push(k + ': 정상 기대 테스트 실패');
    if (c.warnings && c.warnings.length) result.warnings = result.warnings.concat(c.warnings.map(function (m) { return k + ': ' + m; }));
  });
  return erpFieldB06J40_28_30_finish_(result, true);
}

function erpFieldB06J40_28_30_renderSalesDraftSaveHtml(ctx) {
  var requestedConfirm = String((ctx && (ctx.saveConfirm || ctx.confirmSave || ctx.saveExecute)) || '').toUpperCase() === 'Y';
  var draftSaveOpen = String((ctx && (ctx.draftSaveOpen || ctx.draftOpen)) || '').toUpperCase() === 'Y';
  var confirmed = requestedConfirm && draftSaveOpen; // V32: actual DRAFT save only when both explicit flags are present
  var vm = erpFieldB06J40_28_30_buildSaveViewModel_(ctx || {}, confirmed);
  if (!vm.ok && vm.blocked === true) {
    if (typeof erpFieldB06J40_04_12_renderBlocked_ === 'function') return erpFieldB06J40_04_12_renderBlocked_(vm.context || ctx || {}, vm.fatal || []);
    return HtmlService.createHtmlOutput('<pre>' + erpFieldB06J40_28_30_escape_(JSON.stringify(vm.fatal || [], null, 2)) + '</pre>');
  }
  var t = HtmlService.createTemplateFromFile('P_SaleSave');
  t.vm = vm;
  return t.evaluate().setTitle('판매 DRAFT 저장 결과').setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL);
}

function erpFieldB06J40_28_30_buildSaveViewModel_(ctx, confirmed) {
  ctx = erpFieldB06J40_28_30_normalize_(ctx || {});
  var guard = erpFieldB06J40_28_30_guard_(ctx);
  if (!guard.ok) return { ok: false, blocked: true, fatal: guard.fatal, warnings: [], context: ctx };

  var inputVm = erpFieldB06J40_28_30_buildInputVm_(ctx);
  var schema = erpFieldB06J40_28_30_checkSalesSchema_();
  var logTarget = erpFieldB06J40_28_30_checkCoreLog_();
  var validation = erpFieldB06J40_28_30_validateReady_(ctx, inputVm, schema);
  var savePipelineOrder = ['requiredValueCheck','formatCheck','permissionCheck','duplicateCheck','stateTransitionCheck','save','auditLog'];
  var saveResult = { attempted: false, saved: false, duplicateBlocked: false, saleId: '', rowNumber: '', fatal: [], warnings: [] };

  if (confirmed) {
    saveResult.attempted = true;
    if (!schema || schema.ok !== true) {
      saveResult.fatal.push('Sales 저장 스키마 미준비');
    }
    if (!validation.ok) {
      saveResult.fatal = saveResult.fatal.concat(validation.errors || []);
    }
    if (saveResult.fatal.length === 0) {
      saveResult = erpFieldB06J40_28_30_saveDraft_(ctx, inputVm, schema, logTarget);
    }
  }

  return {
    ok: validation.ok && (!confirmed || saveResult.saved || saveResult.duplicateBlocked),
    build: FIELD_SALES_DRAFT_SAVE_BUILD,
    moduleCode: 'ERP_FIELD',
    checkedAt: new Date().toISOString(),
    fatal: confirmed && saveResult.fatal && saveResult.fatal.length ? saveResult.fatal : [],
    warnings: validation.warnings.concat(saveResult.warnings || []),
    confirmed: confirmed,
    context: ctx,
    inputVm: inputVm,
    schema: schema,
    logTarget: logTarget,
    validation: validation,
    savePipelineOrder: savePipelineOrder,
    saveResult: saveResult,
    page: {
      badge: confirmed ? 'V35 STABLE OPEN : DRAFT SAVE' : 'V35 STABLE OPEN : DRY RUN',
      title: confirmed ? '판매 DRAFT 저장 결과' : '판매 DRAFT 드라이런 결과',
      subtitle: confirmed ? 'HeaderMap 기반으로 Sales DRAFT 저장과 ERP_CoreLog 기록을 제한 실행합니다.' : 'HeaderMap 기반 저장 전 검증만 수행합니다. 실제 Sales 저장과 ERP_CoreLog 기록은 차단됩니다.',
      roleName: erpFieldB06J40_28_30_roleName_(ctx.roleCode)
    },
    safety: {
      draftOnly: true,
      dryRunOnly: !confirmed,
      actualSaveBlocked: !confirmed,
      statusFixedDraft: true,
      headerMapBased: true,
      noColumnIndexFixed: true,
      noContractCreate: true,
      noSettlementExecution: true,
      noExternalIntegration: true,
      noUpdateExecution: true,
      noDeleteExecution: true,
      vendorIndependentDbBlocked: true,
      vendorAsBranchUserGroup: true
    },
    urls: erpFieldB06J40_28_30_urls_(ctx, saveResult)
  };
}

function erpFieldB06J40_28_30_saveDraft_(ctx, inputVm, schema, logTarget) {
  var lock = null;
  var result = { attempted: true, saved: false, duplicateBlocked: false, saleId: '', rowNumber: '', fatal: [], warnings: [] };
  try {
    lock = LockService.getScriptLock();
    lock.waitLock(30000);
  } catch (lockErr) {
    result.warnings.push('LockService 대기 실패 또는 생략: ' + (lockErr && lockErr.message ? lockErr.message : lockErr));
  }

  try {
    var master = erpFieldB06J40_28_30_openMaster_();
    if (!master.ok) {
      result.fatal = master.fatal || ['MASTER 연결 실패'];
      return result;
    }
    var sheet = erpFieldB06J40_28_30_getSalesSheet_(master.spreadsheet);
    if (!sheet) {
      result.fatal.push('Sales 저장 대상 시트 없음');
      return result;
    }
    var headers = erpFieldB06J40_28_30_getHeaders_(sheet);
    var hm = erpFieldB06J40_28_30_headerMap_(headers);
    var amount = erpFieldB06J40_28_30_amounts_(ctx);
    var dup = erpFieldB06J40_28_30_findDuplicateDraft_(sheet, hm, ctx, amount);
    if (dup.found) {
      result.duplicateBlocked = true;
      result.saleId = dup.saleId;
      result.rowNumber = dup.rowNumber;
      result.warnings.push('동일 조건 DRAFT 판매전표가 이미 있어 중복 저장을 차단했습니다.');
      return result;
    }

    var stateCheck = erpFieldB06J40_28_30_stateTransitionCheck_('', 'DRAFT', ctx);
    if (!stateCheck.ok) {
      result.fatal = stateCheck.fatal.slice();
      return result;
    }

    var saleId = erpFieldB06J40_28_30_generateId_('SALE');
    var logId = erpFieldB06J40_28_30_generateId_('LOG');
    var now = new Date();
    var userEmail = ctx.userEmail || erpFieldB06J40_28_30_activeUser_();
    var customer = inputVm && inputVm.selectedCustomer ? inputVm.selectedCustomer : {};
    var row = new Array(headers.length).fill('');
    function set(name, value) {
      var idx = hm[String(name || '').trim()];
      if (idx != null && idx >= 0) row[idx] = value;
    }

    set('saleId', saleId);
    set('eventId', ctx.eventId);
    set('vendorId', ctx.vendorId);
    set('customerId', ctx.customerId);
    set('customerName', customer.name || '');
    set('phone', customer.phoneMasked || '');
    set('phoneNormalized', customer.phoneNormalized || '');
    set('dong', customer.dong || '');
    set('ho', customer.ho || '');
    set('apartmentName', customer.apartmentName || '');
    set('memberType', customer.memberType || '');
    set('productId', ctx.productId || '');
    set('productName', ctx.productName || '');
    set('quantity', amount.quantity);
    set('unitPrice', amount.unitPrice);
    set('totalAmount', amount.totalAmount);
    set('depositAmount', amount.depositAmount);
    set('balanceAmount', amount.balanceAmount);
    set('discountAmount', amount.discountAmount);
    set('voucherAmount', amount.voucherAmount);
    set('benefitAmount', amount.benefitAmount);
    set('paidAmount', amount.depositAmount);
    set('unpaidAmount', amount.balanceAmount);
    set('paymentStructure', ctx.paymentStructure);
    set('paymentMethod', ctx.paymentMethod);
    set('cardPaymentIds', ctx.cardPaymentIds || '');
    set('cardMatchStatus', ctx.cardPaymentIds ? 'PENDING_MATCH' : 'NONE');
    set('installDueDate', ctx.installDueDate || '');
    set('signStatus', 'NOT_STARTED');
    set('pdfStatus', 'NOT_CREATED');
    set('settlementStatus', 'NOT_READY');
    set('settlementDirection', 'NO_ACTION');
    set('approvalStatus', 'NOT_REQUIRED');
    set('status', 'DRAFT');
    set('statusReason', 'FIELD_DRAFT_SAVE');
    set('contractId', '');
    set('documentId', '');
    set('installId', '');
    set('asId', '');
    set('settlementId', '');
    set('logId', logId);
    set('memo', 'B06J40 FIELD DRAFT 판매 저장');
    set('createdAt', now);
    set('createdBy', userEmail || 'FIELD_USER');
    set('updatedAt', now);
    set('updatedBy', userEmail || 'FIELD_USER');

    sheet.appendRow(row);
    result.saved = true;
    result.saleId = saleId;
    result.rowNumber = sheet.getLastRow();
    erpFieldB06J40_28_30_log_(master.spreadsheet, logTarget, {
      logId: logId,
      targetId: saleId,
      targetSheet: sheet.getName(),
      action: 'FIELD_SALES_DRAFT_SAVE',
      actor: userEmail || 'FIELD_USER',
      message: 'FIELD 판매 DRAFT 저장 완료',
      build: FIELD_SALES_DRAFT_SAVE_BUILD,
      eventId: ctx.eventId,
      vendorId: ctx.vendorId,
      customerId: ctx.customerId
    });
    return result;
  } catch (err) {
    result.fatal.push(err && err.message ? err.message : String(err));
    return result;
  } finally {
    try { if (lock) lock.releaseLock(); } catch (releaseErr) {}
  }
}

function erpFieldB06J40_28_30_validateReady_(ctx, inputVm, schema) {
  var errors = [];
  var warnings = [];
  var customer = inputVm && inputVm.selectedCustomer ? inputVm.selectedCustomer : {};
  var dryRunPreset = String((ctx && ctx.dryRunPreset) || '').toUpperCase() === 'Y';
  if (!schema || schema.ok !== true) {
    if (dryRunPreset) {
      warnings.push('DRY RUN 프리셋: Sales 저장 스키마 미준비는 실제 저장 전 점검 항목으로 유지하고 검증 차단에서는 제외합니다.');
    } else {
      errors.push('Sales 저장 스키마 미준비');
    }
  }
  if (!ctx.customerId) errors.push('customerId 미선택');
  if (!customer.selected) errors.push('선택 고객 스냅샷 없음');
  if (customer.selected && !customer.scopeMatch) errors.push('선택 고객 vendorId/eventId 범위 불일치');
  if (!ctx.productName && !ctx.productId) errors.push('품목명 또는 productId 미입력');
  var amount = erpFieldB06J40_28_30_amounts_(ctx);
  if (amount.quantity <= 0) errors.push('수량은 1 이상이어야 합니다');
  if (amount.totalAmount <= 0) errors.push('총금액 0원 이하');
  if (['COMPANY_ALL', 'MIXED', 'VENDOR_DIRECT'].indexOf(ctx.paymentStructure) < 0) errors.push('결제구조 미선택 또는 미허용 값');
  if (['CARD', 'CASH', 'BANK', 'VOUCHER', 'MIXED'].indexOf(ctx.paymentMethod) < 0) errors.push('결제수단 미선택 또는 미허용 값');
  if (ctx.paymentMethod === 'CARD' && !ctx.cardPaymentIds) warnings.push('카드결제 선택 시 cardPaymentIds는 후속 카드매칭에서 보강 필요');
  return { ok: errors.length === 0, errors: errors, warnings: warnings, amounts: amount };
}

function erpFieldB06J40_28_30_stateTransitionCheck_(fromStatus, toStatus, ctx) {
  var fatal = [];
  var locked = { LOCKED:true, CLOSED:true, ARCHIVED:true, COMPLETED:true, SETTLED:true };
  var from = String(fromStatus || '').trim();
  var to = String(toStatus || '').trim();
  if (locked[from] && !(ctx && ctx.approvalId)) fatal.push('완료/잠금/종료 상태 재오픈 승인 없이 DRAFT 저장 불가');
  if (to !== 'DRAFT') fatal.push('FIELD 판매 신규 저장은 DRAFT 상태만 허용');
  return { ok: fatal.length === 0, fromStatus: from || 'NEW', toStatus: to, approvalRequired: !!locked[from], fatal: fatal, actualStateMutation: false };
}

function erpFieldB06J40_28_30_findDuplicateDraft_(sheet, hm, ctx, amount) {
  var out = { found: false, saleId: '', rowNumber: '' };
  var lastRow = sheet.getLastRow();
  if (lastRow < 2) return out;
  var vals = sheet.getRange(2, 1, lastRow - 1, sheet.getLastColumn()).getValues();
  function get(row, name) { var i = hm[name]; return i == null ? '' : row[i]; }
  for (var r = 0; r < vals.length; r++) {
    var row = vals[r];
    if (String(get(row, 'status')) !== 'DRAFT') continue;
    if (String(get(row, 'eventId')) !== ctx.eventId) continue;
    if (String(get(row, 'vendorId')) !== ctx.vendorId) continue;
    if (String(get(row, 'customerId')) !== ctx.customerId) continue;
    if (String(get(row, 'productName')) !== ctx.productName) continue;
    if (Number(get(row, 'totalAmount') || 0) !== Number(amount.totalAmount || 0)) continue;
    if (String(get(row, 'paymentStructure')) !== ctx.paymentStructure) continue;
    if (String(get(row, 'paymentMethod')) !== ctx.paymentMethod) continue;
    out.found = true;
    out.saleId = String(get(row, 'saleId') || '');
    out.rowNumber = r + 2;
    return out;
  }
  return out;
}

function erpFieldB06J40_28_30_buildInputVm_(ctx) {
  try {
    if (typeof erpFieldB06J40_13_15_buildSalesInputBindViewModel_ === 'function') {
      // B06J40-13~15 input-bind view model only accepts route=sales.
      // salesSave is the submit route, so convert only for customer snapshot/input validation reuse.
      var salesCtx = {};
      Object.keys(ctx || {}).forEach(function (k) { salesCtx[k] = ctx[k]; });
      salesCtx.route = 'sales';
      var vm = erpFieldB06J40_13_15_buildSalesInputBindViewModel_(salesCtx);
      if (!vm) vm = {};
      if (!vm.selectedCustomer) vm.selectedCustomer = { selected: false, name: '', dong: '', ho: '', phoneMasked: '', phoneNormalized: '' };
      return vm;
    }
  } catch (err) {
    return { ok: false, fatal: [err && err.message ? err.message : String(err)], selectedCustomer: { selected: false, name: '', dong: '', ho: '', phoneMasked: '', phoneNormalized: '' } };
  }
  return { ok: false, fatal: ['B06J40-13~15 입력 연결 함수 없음'], selectedCustomer: { selected: false, name: '', dong: '', ho: '', phoneMasked: '', phoneNormalized: '' } };
}

function erpFieldB06J40_28_30_checkSalesSchema_() {
  try {
    if (typeof erpFieldB06J40_21_24_checkSalesSchema_ === 'function') return erpFieldB06J40_21_24_checkSalesSchema_(false);
  } catch (err) {
    return { ok: false, fatal: [err && err.message ? err.message : String(err)] };
  }
  var master = erpFieldB06J40_28_30_openMaster_();
  if (!master.ok) return { ok: false, fatal: master.fatal || ['MASTER 연결 실패'] };
  var sh = erpFieldB06J40_28_30_getSalesSheet_(master.spreadsheet);
  if (!sh) return { ok: false, fatal: ['Sales 저장 대상 시트 없음'] };
  var headers = erpFieldB06J40_28_30_getHeaders_(sh);
  var hm = erpFieldB06J40_28_30_headerMap_(headers);
  var required = ['saleId','eventId','vendorId','customerId','status','statusReason','createdAt','createdBy','updatedAt','updatedBy','productName','quantity','unitPrice','totalAmount','depositAmount','balanceAmount','paymentStructure','paymentMethod'];
  var missing = required.filter(function (h) { return hm[h] == null; });
  return { ok: missing.length === 0, sheetName: sh.getName(), headers: headers, missingHeaders: missing };
}

function erpFieldB06J40_28_30_checkCoreLog_() {
  try {
    var master = erpFieldB06J40_28_30_openMaster_();
    if (!master.ok) return { ok: false, fatal: master.fatal || [] };
    var sh = master.spreadsheet.getSheetByName('ERP_CoreLog');
    return { ok: !!sh, sheetName: sh ? sh.getName() : '', warnings: sh ? [] : ['ERP_CoreLog 없음: 저장은 가능하나 로그 기록 제한'] };
  } catch (err) {
    return { ok: false, fatal: [err && err.message ? err.message : String(err)] };
  }
}

function erpFieldB06J40_28_30_log_(ss, logTarget, data) {
  try {
    var sh = ss.getSheetByName('ERP_CoreLog');
    if (!sh) return false;
    if (sh.getLastRow() < 1 || sh.getLastColumn() < 1) {
      sh.appendRow(['logId','createdAt','createdBy','moduleCode','functionName','targetSheet','targetId','action','status','message','eventId','vendorId','customerId','build']);
    }
    var headers = erpFieldB06J40_28_30_getHeaders_(sh);
    var hm = erpFieldB06J40_28_30_headerMap_(headers);
    var row = new Array(headers.length).fill('');
    function set(name, value) { var i = hm[name]; if (i != null) row[i] = value; }
    set('logId', data.logId);
    set('createdAt', new Date());
    set('createdBy', data.actor || 'FIELD_USER');
    set('moduleCode', 'ERP_FIELD');
    set('functionName', 'erpFieldB06J40_28_30_saveDraft_');
    set('targetSheet', data.targetSheet);
    set('targetId', data.targetId);
    set('action', data.action);
    set('status', 'SUCCESS');
    set('message', data.message);
    set('eventId', data.eventId);
    set('vendorId', data.vendorId);
    set('customerId', data.customerId);
    set('build', data.build);
    sh.appendRow(row);
    return true;
  } catch (err) {
    return false;
  }
}

function erpFieldB06J40_28_30_getSalesSheet_(ss) {
  var candidates = ['ERP_판매관리', 'ERP_Sales', 'Sales'];
  for (var i = 0; i < candidates.length; i++) {
    var sh = ss.getSheetByName(candidates[i]);
    if (sh) return sh;
  }
  return null;
}

function erpFieldB06J40_28_30_openMaster_() {
  try {
    var config = (typeof erpFieldB06J40_21_24_readConfig_ === 'function') ? erpFieldB06J40_21_24_readConfig_() : null;
    if (config && typeof erpFieldB06J40_21_24_openMaster_ === 'function') return erpFieldB06J40_21_24_openMaster_(config);
  } catch (err) {}
  try {
    var setup = SpreadsheetApp.openById('17VMSpgSZCvIrUlgcw8yCNcnl8WQWo2IcRf5tDCcuJGM');
    var sh = setup.getSheetByName('SystemConfig');
    var vals = sh.getDataRange().getValues();
    var id = '';
    for (var r = 1; r < vals.length; r++) {
      if (String(vals[r][0]) === 'FEELHAUS_DB_MASTER_ID' || String(vals[r][0]) === 'DB_MASTER_ID' || String(vals[r][0]) === 'SPREADSHEET_ID') {
        id = String(vals[r][1] || '').trim();
        if (id) break;
      }
    }
    if (!id) return { ok: false, fatal: ['MASTER ID 설정값 없음'] };
    return { ok: true, spreadsheet: SpreadsheetApp.openById(id), masterId: id };
  } catch (err2) {
    return { ok: false, fatal: [err2 && err2.message ? err2.message : String(err2)] };
  }
}

function erpFieldB06J40_28_30_getHeaders_(sheet) {
  var lastCol = Math.max(1, sheet.getLastColumn());
  return sheet.getRange(1, 1, 1, lastCol).getValues()[0].map(function (h) { return String(h || '').trim(); });
}

function erpFieldB06J40_28_30_headerMap_(headers) {
  var m = {};
  (headers || []).forEach(function (h, i) { if (h && m[h] == null) m[h] = i; });
  return m;
}

function erpFieldB06J40_28_30_amounts_(ctx) {
  function n(v) { var x = Number(String(v || '0').replace(/,/g, '')); return isNaN(x) ? 0 : x; }
  var q = n(ctx.quantity || 1);
  var unit = n(ctx.unitPrice);
  var discount = n(ctx.discountAmount);
  var voucher = n(ctx.voucherAmount);
  var benefit = n(ctx.benefitAmount);
  var total = n(ctx.totalAmount) || Math.max(0, (q * unit) - discount - voucher - benefit);
  var deposit = n(ctx.depositAmount);
  var balance = Math.max(0, total - deposit);
  return { quantity: q, unitPrice: unit, discountAmount: discount, voucherAmount: voucher, benefitAmount: benefit, totalAmount: total, depositAmount: deposit, balanceAmount: balance };
}

function erpFieldB06J40_28_30_normalize_(ctx) {
  function s(v) { return String(v == null ? '' : v).trim(); }
  var preset = String((ctx && (ctx.dryRunPreset || ctx.testPreset)) || '').toUpperCase() === 'Y';
  return {
    roleCode: s(ctx.roleCode || 'VIEWER'), vendorId: s(ctx.vendorId), eventId: s(ctx.eventId), route: s(ctx.route || 'salesSave'), keyword: s(ctx.keyword),
    customerId: s(ctx.customerId), userEmail: s(ctx.userEmail), productId: s(ctx.productId), productName: s(ctx.productName || (preset ? 'TEST-드라이런상품' : '')), quantity: s(ctx.quantity || '1'), unitPrice: s(ctx.unitPrice || (preset ? '100000' : '0')),
    totalAmount: s(ctx.totalAmount || '0'), depositAmount: s(ctx.depositAmount || (preset ? '10000' : '0')), balanceAmount: s(ctx.balanceAmount || '0'), discountAmount: s(ctx.discountAmount || '0'), voucherAmount: s(ctx.voucherAmount || '0'), benefitAmount: s(ctx.benefitAmount || '0'),
    paymentStructure: s(ctx.paymentStructure || (preset ? 'COMPANY_ALL' : '')), paymentMethod: s(ctx.paymentMethod || (preset ? 'CASH' : '')), installDueDate: s(ctx.installDueDate), memberType: s(ctx.memberType), cardPaymentIds: s(ctx.cardPaymentIds), saveConfirm: s(ctx.saveConfirm || ctx.confirmSave || ctx.saveExecute), draftSaveOpen: s(ctx.draftSaveOpen || ctx.draftOpen), dryRunPreset: preset ? 'Y' : '', scopeType: 'VENDOR_BRANCH_USER_GROUP', hqFullAccess: false
  };
}

function erpFieldB06J40_28_30_guard_(ctx) {
  var fatal = [];
  var allowedRoles = { VENDOR_OWNER: true, VENDOR_MANAGER: true, STAFF_SALES: true };
  if (!ctx.vendorId) fatal.push('vendorId 누락');
  if (!ctx.eventId) fatal.push('eventId 누락');
  if (!allowedRoles[ctx.roleCode]) fatal.push('판매 DRAFT 저장 차단: roleCode=' + ctx.roleCode + ' 권한 없음');
  if (ctx.route !== 'salesSave') fatal.push('판매 DRAFT 저장 차단: route=' + ctx.route + ' 허용 안 됨');
  return { ok: fatal.length === 0, fatal: fatal };
}

function erpFieldB06J40_28_30_urls_(ctx, saveResult) {
  var base = erpFieldB06J40_28_30_webAppUrl_();
  var common = 'roleCode=' + encodeURIComponent(ctx.roleCode) + '&vendorId=' + encodeURIComponent(ctx.vendorId) + '&eventId=' + encodeURIComponent(ctx.eventId) + '&customerId=' + encodeURIComponent(ctx.customerId || '');
  var input = ['productId','productName','quantity','unitPrice','depositAmount','discountAmount','voucherAmount','benefitAmount','paymentStructure','paymentMethod','installDueDate','cardPaymentIds','dryRunPreset','saveConfirm','draftSaveOpen'].map(function (k) {
    return k + '=' + encodeURIComponent(ctx[k] || '');
  }).join('&');
  var saleId = saveResult && saveResult.saleId ? String(saveResult.saleId) : String(ctx.saleId || '');
  var baseCommon = 'roleCode=' + encodeURIComponent(ctx.roleCode) + '&vendorId=' + encodeURIComponent(ctx.vendorId) + '&eventId=' + encodeURIComponent(ctx.eventId);
  return {
    salesInput: base + '?' + common + '&route=sales&' + input,
    customerLookup: base + '?' + baseCommon + '&route=customerLookup',
    salesRecent: base + '?' + baseCommon + '&route=salesRecent&customerId=' + encodeURIComponent(ctx.customerId || ''),
    salesDetail: base + '?' + baseCommon + '&route=salesDetail&saleId=' + encodeURIComponent(saleId) + '&customerId=' + encodeURIComponent(ctx.customerId || '')
  };
}

function erpFieldB06J40_28_30_requiredFunctions_() {
  var fns = ['erpFieldB06J40_13_15_buildSalesInputBindViewModel_', 'erpFieldB06J40_21_24_checkSalesSchema_'];
  return { ok: fns.every(function (f) { return typeof this[f] === 'function'; }, this), functions: fns, missing: fns.filter(function (f) { return typeof this[f] !== 'function'; }, this) };
}
function erpFieldB06J40_28_30_templateCheck_() { try { HtmlService.createTemplateFromFile('P_SaleSave'); return { ok: true }; } catch (err) { return { ok: false, fatal: [err.message] }; } }
function erpFieldB06J40_28_30_safetyCheck_() { return { ok: true, noContractCreate: true, noSettlementExecution: true, noExternalIntegration: true, noUpdateDelete: true, draftOnly: true }; }
function erpFieldB06J40_28_30_result_(label) { return { ok: true, build: FIELD_SALES_DRAFT_SAVE_BUILD, moduleCode: 'ERP_FIELD', label: label, checkedAt: new Date().toISOString(), fatal: [], warnings: [], checks: {} }; }
function erpFieldB06J40_28_30_finish_(result, logOutput) { Object.keys(result.checks || {}).forEach(function (k) { var c = result.checks[k]; if (c && c.fatal && c.fatal.length) result.fatal = result.fatal.concat(c.fatal.map(function (m) { return k + ': ' + m; })); if (c && c.warnings && c.warnings.length) result.warnings = result.warnings.concat(c.warnings.map(function (m) { return k + ': ' + m; })); }); result.ok = result.fatal.length === 0; if (logOutput) { Logger.log('======================================================'); Logger.log(JSON.stringify(result, null, 2)); Logger.log('======================================================'); } return result; }
function erpFieldB06J40_28_30_generateId_(prefix) { var tz = Session.getScriptTimeZone() || 'Asia/Seoul'; return prefix + '-' + Utilities.formatDate(new Date(), tz, 'yyyyMMddHHmmss') + '-' + Math.floor(Math.random() * 900 + 100); }
function erpFieldB06J40_28_30_activeUser_() { try { return Session.getActiveUser().getEmail() || 'FIELD_USER'; } catch (err) { return 'FIELD_USER'; } }
function erpFieldB06J40_28_30_roleName_(roleCode) { var map = { VENDOR_OWNER: '업체대표', VENDOR_MANAGER: '업체관리자', STAFF_SALES: '영업직원' }; return map[roleCode] || roleCode || '-'; }
function erpFieldB06J40_28_30_webAppUrl_() { try { return ScriptApp.getService().getUrl() || ''; } catch (err) { return ''; } }
function erpFieldB06J40_28_30_escape_(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (m) { return ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[m]; }); }
