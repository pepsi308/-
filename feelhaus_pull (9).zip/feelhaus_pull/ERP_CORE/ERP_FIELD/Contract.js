/* ===== ContSchema.js ===== */
/**
 * build: ERP_B06J41_06_09_CONTRACT_SIGN_SCHEMA_FIX_SAFE_UPLOAD
 * module: ERP_FIELD
 * purpose:
 * - Contracts / ERP_CoreLog schema preflight
 * - missing contract/SIGN bridge headers safe append only when confirmed function is executed
 * - NO contract creation / NO documentId creation / NO SIGN execution / NO settlement execution
 *
 * executable functions:
 * - erpB06J41_06_09_preflight()
 * - erpB06J41_06_09_autoRunSafe()
 * - erpB06J41_06_09_confirmedSchemaFix()
 */

var FIELD_CONTRACT_SCHEMA_BUILD = 'ERP_B06J41_06_09_CONTRACT_SIGN_SCHEMA_FIX_SAFE_UPLOAD';
var FIELD_CONTRACT_SCHEMA_SETUP_DB_ID = '17VMSpgSZCvIrUlgcw8yCNcnl8WQWo2IcRf5tDCcuJGM';
var FIELD_CONTRACT_SCHEMA_CONFIG_SHEET = 'SystemConfig';

var FIELD_CONTRACT_REQUIRED_HEADERS = [
  'contractId', 'saleId', 'eventId', 'vendorId', 'customerId', 'documentId',
  'status', 'statusReason', 'contractStatus', 'signStatus', 'pdfStatus',
  'contractAmount', 'totalAmount', 'depositAmount', 'balanceAmount',
  'paymentStructure', 'paymentMethod', 'createdAt', 'createdBy', 'updatedAt', 'updatedBy'
];

var FIELD_CONTRACT_RECOMMENDED_HEADERS = [
  'customerName', 'phone', 'phoneNormalized', 'dong', 'ho', 'apartmentName',
  'productId', 'productName', 'quantity', 'unitPrice',
  'discountAmount', 'voucherAmount', 'benefitAmount', 'paidAmount', 'unpaidAmount',
  'originalSaleId', 'correctionSaleId', 'cancelRequestId', 'cancellationReason',
  'settlementId', 'settlementStatus', 'settlementDirection', 'installId', 'installStatus',
  'asId', 'approvalId', 'approvalStatus', 'logId', 'memo'
];

var FIELD_CORE_LOG_HEADERS = [
  'logId', 'build', 'moduleCode', 'functionName', 'actionType', 'targetSheet',
  'targetId', 'eventId', 'vendorId', 'customerId', 'saleId', 'contractId', 'documentId',
  'status', 'statusReason', 'createdAt', 'createdBy', 'payloadJson'
];

function erpB06J41_06_09_preflight() {
  return erpFieldB06J41_06_09_run_(false, false);
}

function erpB06J41_06_09_autoRunSafe() {
  var result = erpFieldB06J41_06_09_run_(false, true);
  erpFieldB06J41_06_09_logResult_(result);
  return result;
}

function erpB06J41_06_09_confirmedSchemaFix() {
  var result = erpFieldB06J41_06_09_run_(true, true);
  erpFieldB06J41_06_09_logResult_(result);
  return result;
}

function erpFieldB06J41_06_09_run_(confirmed, logOutput) {
  var result = erpFieldB06J41_06_09_baseResult_();
  result.confirmed = confirmed === true;
  try {
    result.checks.config = erpFieldB06J41_06_09_getConfig_();
    if (!result.checks.config.ok) return erpFieldB06J41_06_09_finish_(result, logOutput);

    result.checks.master = erpFieldB06J41_06_09_getMaster_(result.checks.config.configMap);
    if (!result.checks.master.ok) return erpFieldB06J41_06_09_finish_(result, logOutput);

    var master = result.checks.master.spreadsheet;
    result.checks.salesSheet = erpFieldB06J41_06_09_checkSales_(master);
    result.checks.contractSheet = erpFieldB06J41_06_09_checkSheet_(master, ['ERP_계약관리', 'Contracts'], 'Contracts', FIELD_CONTRACT_REQUIRED_HEADERS, FIELD_CONTRACT_RECOMMENDED_HEADERS, confirmed);
    result.checks.coreLog = erpFieldB06J41_06_09_checkSheet_(master, ['ERP_CoreLog'], 'ERP_CoreLog', FIELD_CORE_LOG_HEADERS, [], confirmed);
    result.checks.signBridge = erpFieldB06J41_06_09_checkSignBridge_(result.checks.contractSheet);
    result.checks.safety = erpFieldB06J41_06_09_safety_();

    if (confirmed && result.checks.contractSheet.ok && result.checks.coreLog.ok) {
      result.checks.schemaFixLog = erpFieldB06J41_06_09_writeLog_(master, result);
    }

    result.readiness = erpFieldB06J41_06_09_readiness_(result);
  } catch (err) {
    result.fatal.push('B06J41-06~09 schema fix fatal: ' + (err && err.message ? err.message : err));
  }
  return erpFieldB06J41_06_09_finish_(result, logOutput);
}

function erpFieldB06J41_06_09_baseResult_() {
  return {
    ok: false,
    build: FIELD_CONTRACT_SCHEMA_BUILD,
    moduleCode: 'ERP_FIELD',
    checkedAt: new Date().toISOString(),
    fatal: [],
    warnings: [],
    confirmed: false,
    checks: {},
    readiness: {
      readyForContractDraftCreate: false,
      blockingIssues: [],
      nextBuild: 'ERP_B06J41_10_14_CONTRACT_DRAFT_CREATE_SAFE_UPLOAD'
    },
    safety: {
      noContractCreation: true,
      noDocumentIdCreation: true,
      noSignExecution: true,
      noPdfCreation: true,
      noSettlementExecution: true,
      noExternalIntegration: true,
      noBusinessStateMutation: true,
      headerAppendOnlyWhenConfirmed: true
    }
  };
}

function erpFieldB06J41_06_09_getConfig_() {
  var out = { ok: false, fatal: [], warnings: [], setupDbId: FIELD_CONTRACT_SCHEMA_SETUP_DB_ID, configSheetName: FIELD_CONTRACT_SCHEMA_CONFIG_SHEET, configMap: {} };
  try {
    var ss = SpreadsheetApp.openById(FIELD_CONTRACT_SCHEMA_SETUP_DB_ID);
    out.setupDbName = ss.getName();
    var sh = ss.getSheetByName(FIELD_CONTRACT_SCHEMA_CONFIG_SHEET);
    if (!sh) {
      out.fatal.push('SystemConfig 시트 없음');
      return out;
    }
    var values = sh.getDataRange().getValues();
    if (!values || values.length < 2) {
      out.fatal.push('SystemConfig 데이터 없음');
      return out;
    }
    var header = values[0].map(function (v) { return String(v || '').trim(); });
    var keyCol = erpFieldB06J41_06_09_firstIndex_(header, ['configKey', 'key', 'name', 'CONFIG_KEY']);
    var valCol = erpFieldB06J41_06_09_firstIndex_(header, ['configValue', 'value', 'CONFIG_VALUE']);
    if (keyCol < 0 || valCol < 0) {
      keyCol = 0; valCol = 1;
      out.warnings.push('SystemConfig 헤더명이 표준과 다름: configKey/configValue 확인 필요');
    }
    for (var r = 1; r < values.length; r++) {
      var k = String(values[r][keyCol] || '').trim();
      if (k) out.configMap[k] = values[r][valCol];
    }
    out.configCount = Object.keys(out.configMap).length;
    out.ok = true;
  } catch (err) {
    out.fatal.push('SystemConfig 읽기 실패: ' + (err && err.message ? err.message : err));
  }
  return out;
}

function erpFieldB06J41_06_09_getMaster_(configMap) {
  var out = { ok: false, fatal: [], warnings: [], usedKey: '', masterId: '', masterName: '' };
  try {
    var keys = ['FEELHAUS_DB_MASTER_ID', 'DB_MASTER_ID', 'SPREADSHEET_ID', 'CUSTOMER_DB_SPREADSHEET_ID'];
    for (var i = 0; i < keys.length; i++) {
      var v = String(configMap[keys[i]] || '').trim();
      if (v) { out.usedKey = keys[i]; out.masterId = v; break; }
    }
    if (!out.masterId) {
      out.fatal.push('FEELHAUS_DB_MASTER_ID / DB_MASTER_ID 누락');
      return out;
    }
    out.spreadsheet = SpreadsheetApp.openById(out.masterId);
    out.masterSpreadsheetName = out.spreadsheet.getName();
    out.masterName = out.masterSpreadsheetName;
    out.ok = true;
  } catch (err) {
    out.fatal.push('MASTER 연결 실패: ' + (err && err.message ? err.message : err));
  }
  return out;
}

function erpFieldB06J41_06_09_checkSales_(master) {
  var out = { ok: false, fatal: [], warnings: [], sheetName: 'Sales', exists: false, draftRows: 0 };
  try {
    var sh = master.getSheetByName('Sales');
    if (!sh) {
      out.fatal.push('Sales 시트 없음');
      return out;
    }
    out.exists = true;
    out.lastRow = sh.getLastRow();
    out.lastCol = sh.getLastColumn();
    out.headerMap = erpFieldB06J41_06_09_headerMap_(sh);
    var needed = ['saleId', 'eventId', 'vendorId', 'customerId', 'status', 'totalAmount'];
    out.missingHeaders = erpFieldB06J41_06_09_missing_(out.headerMap, needed);
    if (out.missingHeaders.length) {
      out.fatal.push('Sales 필수 헤더 누락: ' + out.missingHeaders.join(', '));
      return out;
    }
    if (out.lastRow > 1) {
      var statusCol = out.headerMap.status;
      var values = sh.getRange(2, 1, out.lastRow - 1, out.lastCol).getValues();
      for (var r = 0; r < values.length; r++) {
        if (String(values[r][statusCol - 1] || '').trim() === 'DRAFT') out.draftRows++;
      }
    }
    out.ok = true;
  } catch (err) {
    out.fatal.push('Sales 점검 실패: ' + (err && err.message ? err.message : err));
  }
  return out;
}

function erpFieldB06J41_06_09_checkSheet_(master, candidates, defaultName, requiredHeaders, recommendedHeaders, confirmed) {
  var out = { ok: false, fatal: [], warnings: [], candidates: candidates, sheetName: '', exists: false, missingRequired: [], missingRecommended: [], appendedHeaders: [], headerMapBased: true, columnIndexFixed: false };
  try {
    var sh = null;
    for (var i = 0; i < candidates.length; i++) {
      sh = master.getSheetByName(candidates[i]);
      if (sh) break;
    }
    if (!sh && confirmed) {
      sh = master.insertSheet(defaultName);
      sh.getRange(1, 1, 1, requiredHeaders.length).setValues([requiredHeaders]);
      out.created = true;
    }
    if (!sh) {
      out.fatal.push(defaultName + ' 시트 없음');
      return out;
    }
    out.exists = true;
    out.sheetName = sh.getName();
    var map = erpFieldB06J41_06_09_headerMap_(sh);
    out.missingRequired = erpFieldB06J41_06_09_missing_(map, requiredHeaders);
    out.missingRecommended = erpFieldB06J41_06_09_missing_(map, recommendedHeaders || []);
    if (confirmed && out.missingRequired.length) {
      erpFieldB06J41_06_09_appendHeaders_(sh, out.missingRequired);
      out.appendedHeaders = out.appendedHeaders.concat(out.missingRequired);
      map = erpFieldB06J41_06_09_headerMap_(sh);
      out.missingRequired = erpFieldB06J41_06_09_missing_(map, requiredHeaders);
    }
    if (confirmed && out.missingRecommended.length) {
      erpFieldB06J41_06_09_appendHeaders_(sh, out.missingRecommended);
      out.appendedHeaders = out.appendedHeaders.concat(out.missingRecommended);
      map = erpFieldB06J41_06_09_headerMap_(sh);
      out.missingRecommended = erpFieldB06J41_06_09_missing_(map, recommendedHeaders || []);
    }
    out.lastRow = sh.getLastRow();
    out.lastCol = sh.getLastColumn();
    out.ok = out.missingRequired.length === 0;
    if (!out.ok) out.fatal.push(out.sheetName + ' 필수 헤더 누락: ' + out.missingRequired.join(', '));
  } catch (err) {
    out.fatal.push(defaultName + ' 점검 실패: ' + (err && err.message ? err.message : err));
  }
  return out;
}

function erpFieldB06J41_06_09_checkSignBridge_(contractSheetCheck) {
  var out = { ok: false, fatal: [], warnings: [], checks: {} };
  try {
    var missing = (contractSheetCheck && contractSheetCheck.missingRequired) ? contractSheetCheck.missingRequired : [];
    out.checks.documentId = missing.indexOf('documentId') < 0;
    out.checks.signStatus = missing.indexOf('signStatus') < 0;
    out.checks.pdfStatus = missing.indexOf('pdfStatus') < 0;
    out.checks.contractId = missing.indexOf('contractId') < 0;
    out.ok = out.checks.documentId && out.checks.signStatus && out.checks.pdfStatus && out.checks.contractId;
    if (!out.ok) out.fatal.push('SIGN 연결용 필수 헤더 보완 필요: contractId/documentId/signStatus/pdfStatus');
    out.note = '이번 빌드는 SIGN 문서 생성 없이 계약 시트의 연결 키만 점검/보정합니다.';
  } catch (err) {
    out.fatal.push('SIGN bridge 점검 실패: ' + (err && err.message ? err.message : err));
  }
  return out;
}

function erpFieldB06J41_06_09_safety_() {
  return {
    ok: true,
    noContractCreation: true,
    noDocumentIdCreation: true,
    noSignExecution: true,
    noPdfCreation: true,
    noSettlementExecution: true,
    noExternalIntegration: true,
    noSalesMutation: true,
    headerAppendOnlyWhenConfirmed: true,
    vendorAsBranchUserGroup: true,
    vendorIndependentDbBlocked: true
  };
}

function erpFieldB06J41_06_09_readiness_(result) {
  var out = { readyForContractDraftCreate: false, blockingIssues: [], nextBuild: 'ERP_B06J41_10_14_CONTRACT_DRAFT_CREATE_SAFE_UPLOAD' };
  if (!result.checks.salesSheet || !result.checks.salesSheet.ok) out.blockingIssues.push('Sales 시트/헤더 점검 미통과');
  if (!result.checks.contractSheet || !result.checks.contractSheet.ok) out.blockingIssues.push('Contracts/ERP_계약관리 시트 필수 헤더 미통과');
  if (!result.checks.signBridge || !result.checks.signBridge.ok) out.blockingIssues.push('SIGN 연결 키 미통과');
  if (!result.checks.coreLog || !result.checks.coreLog.ok) out.blockingIssues.push('ERP_CoreLog 헤더 미통과');
  out.readyForContractDraftCreate = out.blockingIssues.length === 0;
  return out;
}

function erpFieldB06J41_06_09_writeLog_(master, result) {
  var out = { ok: false, fatal: [], warnings: [] };
  try {
    var sh = master.getSheetByName('ERP_CoreLog');
    if (!sh) {
      out.warnings.push('ERP_CoreLog 없음: 로그 기록 생략');
      out.ok = true;
      return out;
    }
    var map = erpFieldB06J41_06_09_headerMap_(sh);
    var rowObj = {
      logId: 'LOG-' + Utilities.formatDate(new Date(), Session.getScriptTimeZone() || 'Asia/Seoul', 'yyyyMMddHHmmss') + '-' + Math.floor(Math.random() * 900 + 100),
      build: FIELD_CONTRACT_SCHEMA_BUILD,
      moduleCode: 'ERP_FIELD',
      functionName: 'erpB06J41_06_09_confirmedSchemaFix',
      actionType: 'CONTRACT_SCHEMA_FIX',
      targetSheet: result.checks.contractSheet ? result.checks.contractSheet.sheetName : 'Contracts',
      status: result.ok ? 'OK' : 'CHECK',
      statusReason: result.readiness && result.readiness.readyForContractDraftCreate ? 'CONTRACT_SCHEMA_READY' : 'CONTRACT_SCHEMA_NEEDS_CHECK',
      createdAt: new Date().toISOString(),
      createdBy: Session.getActiveUser().getEmail() || 'FIELD_USER',
      payloadJson: JSON.stringify({ appendedHeaders: result.checks.contractSheet ? result.checks.contractSheet.appendedHeaders : [] })
    };
    var row = [];
    var lastCol = sh.getLastColumn();
    for (var c = 1; c <= lastCol; c++) row.push('');
    Object.keys(rowObj).forEach(function (k) {
      if (map[k]) row[map[k] - 1] = rowObj[k];
    });
    sh.appendRow(row);
    out.ok = true;
  } catch (err) {
    out.fatal.push('Schema fix log 기록 실패: ' + (err && err.message ? err.message : err));
  }
  return out;
}

function erpFieldB06J41_06_09_finish_(result, logOutput) {
  Object.keys(result.checks || {}).forEach(function (k) {
    var c = result.checks[k];
    if (c && c.fatal && c.fatal.length) {
      c.fatal.forEach(function (m) { result.fatal.push(k + ': ' + m); });
    }
    if (c && c.warnings && c.warnings.length) {
      c.warnings.forEach(function (m) { result.warnings.push(k + ': ' + m); });
    }
  });
  result.ok = result.fatal.length === 0;
  if (logOutput) erpFieldB06J41_06_09_logResult_(result);
  return result;
}

function erpFieldB06J41_06_09_logResult_(result) {
  try {
    Logger.log('======================================================');
    Logger.log('[' + FIELD_CONTRACT_SCHEMA_BUILD + '] RESULT');
    Logger.log(JSON.stringify(erpFieldB06J41_06_09_publicResult_(result), null, 2));
    Logger.log('======================================================');
  } catch (err) {}
}

function erpFieldB06J41_06_09_publicResult_(result) {
  var copy = JSON.parse(JSON.stringify(result));
  if (copy.checks && copy.checks.master && copy.checks.master.spreadsheet) delete copy.checks.master.spreadsheet;
  return copy;
}

function erpFieldB06J41_06_09_headerMap_(sh) {
  var map = {};
  var lastCol = Math.max(sh.getLastColumn(), 1);
  var values = sh.getRange(1, 1, 1, lastCol).getValues()[0];
  for (var i = 0; i < values.length; i++) {
    var h = String(values[i] || '').trim();
    if (h && !map[h]) map[h] = i + 1;
  }
  return map;
}

function erpFieldB06J41_06_09_missing_(map, headers) {
  var missing = [];
  for (var i = 0; i < headers.length; i++) {
    if (!map[headers[i]]) missing.push(headers[i]);
  }
  return missing;
}

function erpFieldB06J41_06_09_appendHeaders_(sh, headers) {
  if (!headers || !headers.length) return;
  var startCol = sh.getLastColumn() + 1;
  sh.getRange(1, startCol, 1, headers.length).setValues([headers]);
}

function erpFieldB06J41_06_09_firstIndex_(arr, names) {
  for (var i = 0; i < names.length; i++) {
    var idx = arr.indexOf(names[i]);
    if (idx >= 0) return idx;
  }
  return -1;
}


/* ===== ContSignChk.js ===== */
/**
 * build: ERP_B06J41_01_05_CONTRACT_SIGN_LINK_PRECHECK_SAFE_UPLOAD
 * module: ERP_FIELD
 * purpose:
 * - B06J41-01 계약 대상 saleId 검증
 * - B06J41-02 DRAFT 판매만 계약 후보 허용
 * - B06J41-03 계약관리 시트/헤더 점검
 * - B06J41-04 contractId/documentId 생성 시뮬레이션
 * - B06J41-05 SIGN 연결 전 안전조건 확인
 * safety:
 * - READ ONLY only
 * - no sheet write / no contract create / no document create / no SIGN call / no settlement / no external integration
 */

var B06J41_01_05_BUILD = 'ERP_B06J41_01_05_CONTRACT_SIGN_LINK_PRECHECK_SAFE_UPLOAD';
var B06J41_01_05_SETUP_DB_ID = '17VMSpgSZCvIrUlgcw8yCNcnl8WQWo2IcRf5tDCcuJGM';
var B06J41_01_05_CONFIG_SHEET_NAME = 'SystemConfig';

function erpB06J41_01_05_preflight() {
  return erpFieldB06J41_01_05_finish_(erpFieldB06J41_01_05_buildCheck_({
    roleCode: 'VENDOR_MANAGER',
    vendorId: 'VND-20260502202158-505',
    eventId: 'EVT-20260502202016-197',
    customerId: 'CUS-20260504002306-615',
    saleId: 'SALE-20260504005028-991',
    route: 'contractPrecheck'
  }), true);
}

function erpB06J41_01_05_autoRunSafe() {
  var samples = {
    draftCandidate: erpFieldB06J41_01_05_buildCheck_({
      roleCode: 'VENDOR_MANAGER',
      vendorId: 'VND-20260502202158-505',
      eventId: 'EVT-20260502202016-197',
      customerId: 'CUS-20260504002306-615',
      saleId: 'SALE-20260504005028-991',
      route: 'contractPrecheck'
    }),
    missingSaleBlocked: erpFieldB06J41_01_05_buildCheck_({
      roleCode: 'VENDOR_MANAGER',
      vendorId: 'VND-20260502202158-505',
      eventId: 'EVT-20260502202016-197',
      customerId: 'CUS-20260504002306-615',
      saleId: '',
      route: 'contractPrecheck'
    }),
    missingVendorBlocked: erpFieldB06J41_01_05_buildCheck_({
      roleCode: 'VENDOR_MANAGER',
      vendorId: '',
      eventId: 'EVT-20260502202016-197',
      saleId: 'SALE-20260504005028-991',
      route: 'contractPrecheck'
    })
  };
  var result = erpFieldB06J41_01_05_result_('autoRunSafe');
  result.checks = samples;
  Object.keys(samples).forEach(function (k) {
    var c = samples[k];
    if (c.fatal && c.fatal.length) {
      if (k === 'missingSaleBlocked' || k === 'missingVendorBlocked') {
        result.expectedBlocks.push(k);
      } else {
        result.fatal = result.fatal.concat(c.fatal.map(function (m) { return k + ': ' + m; }));
      }
    }
  });
  result.ok = result.fatal.length === 0;
  return erpFieldB06J41_01_05_finish_(result, true);
}

function erpFieldB06J41_01_05_renderContractSignPrecheckHtml(ctx) {
  ctx = erpFieldB06J41_01_05_normalize_(ctx || {});
  var vm = erpFieldB06J41_01_05_buildCheck_(ctx);
  var t = HtmlService.createTemplateFromFile('P_ContSign');
  t.vm = vm;
  t.json = JSON.stringify(vm, null, 2);
  return t.evaluate()
    .setTitle('B06J41 계약/SIGN 연결 프리체크')
    .setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL);
}

function erpFieldB06J41_01_05_buildCheck_(ctx) {
  ctx = erpFieldB06J41_01_05_normalize_(ctx || {});
  var result = erpFieldB06J41_01_05_result_('contractSignPrecheck');
  result.context = ctx;
  result.safety = {
    readOnlyOnly: true,
    noSheetWrite: true,
    noContractCreate: true,
    noDocumentCreate: true,
    noSignCall: true,
    noSettlement: true,
    noExternalIntegration: true,
    vendorIndependentDbBlocked: true,
    vendorAsBranchUserGroup: true
  };
  result.checks.config = erpFieldB06J41_01_05_loadConfig_();
  if (!ctx.vendorId) result.fatal.push('vendorId 누락');
  if (!ctx.eventId) result.fatal.push('eventId 누락');
  if (!ctx.saleId) result.fatal.push('saleId 누락: 계약 전환 대상 판매 DRAFT를 지정해야 합니다.');
  if (['VENDOR_OWNER', 'VENDOR_MANAGER', 'STAFF_SALES'].indexOf(ctx.roleCode) < 0) {
    result.fatal.push('계약전환 프리체크 미허용 roleCode=' + ctx.roleCode);
  }

  var master = erpFieldB06J41_01_05_openMaster_(result.checks.config);
  result.checks.master = master.meta;
  if (!master.ss) {
    result.fatal.push('FEELHAUS_DB_MASTER 연결 실패');
    result.ok = false;
    return erpFieldB06J41_01_05_finalizeReadiness_(result);
  }

  result.checks.sales = erpFieldB06J41_01_05_findSheet_(master.ss, ['Sales', 'ERP_판매관리', 'ERP_Sales']);
  result.checks.contract = erpFieldB06J41_01_05_findSheet_(master.ss, ['ERP_계약관리', 'Contracts', 'ERP_Contract']);
  result.checks.sign = erpFieldB06J41_01_05_findSheet_(master.ss, ['SIGN_DocumentMaster', 'SIGN_문서관리', 'ERP_SIGN_DOCUMENTS', 'SIGN_QR_Document']);
  result.checks.coreLog = erpFieldB06J41_01_05_findSheet_(master.ss, ['ERP_CoreLog', 'ERP_Log', 'ERP_SalesLog']);

  result.sale = erpFieldB06J41_01_05_lookupSale_(result.checks.sales, ctx);
  if (!result.sale.found) {
    result.fatal.push('saleId에 해당하는 Sales DRAFT를 찾지 못했습니다.');
  } else {
    if (String(result.sale.row.status || '').toUpperCase() !== 'DRAFT') {
      result.fatal.push('DRAFT 상태 판매만 계약 전환 후보입니다. 현재 status=' + result.sale.row.status);
    }
    if (String(result.sale.row.vendorId || '') !== ctx.vendorId) result.fatal.push('sale.vendorId 불일치');
    if (String(result.sale.row.eventId || '') !== ctx.eventId) result.fatal.push('sale.eventId 불일치');
    if (ctx.customerId && String(result.sale.row.customerId || '') !== ctx.customerId) result.warnings.push('ctx.customerId와 sale.customerId가 다릅니다. sale 기준으로 후속 처리해야 합니다.');
  }

  result.simulation = erpFieldB06J41_01_05_simulateIds_(ctx, result.sale);
  result.requirementMatrix = erpFieldB06J41_01_05_requirementMatrix_(result);
  result = erpFieldB06J41_01_05_finalizeReadiness_(result);
  return result;
}

function erpFieldB06J41_01_05_finalizeReadiness_(result) {
  var blockers = [];
  if (result.fatal && result.fatal.length) blockers = blockers.concat(result.fatal);
  if (!result.checks.contract || !result.checks.contract.exists) blockers.push('계약관리 시트 없음: ERP_계약관리 후보 필요');
  if (!result.checks.contract || (result.checks.contract.missingRequiredHeaders || []).length) blockers.push('계약관리 필수 헤더 누락');
  if (!result.checks.sign || !result.checks.sign.exists) blockers.push('SIGN 문서관리 시트 없음 또는 후속 SIGN 연결 후보 필요');
  result.readiness = {
    readyForB06J41ContractCreate: blockers.length === 0,
    blockers: blockers,
    nextBuild: 'ERP_B06J41_06_10_CONTRACT_DRAFT_CREATE_SAFE_UPLOAD',
    currentBuildDoesNotCreate: true
  };
  result.ok = (result.fatal || []).length === 0;
  return result;
}

function erpFieldB06J41_01_05_lookupSale_(sheetCheck, ctx) {
  var out = { found: false, rowNumber: 0, row: {}, fatal: [], warnings: [], sheetName: '', scannedSheets: [] };
  var targetSaleId = String((ctx && ctx.saleId) || '').trim();
  if (!targetSaleId) {
    out.fatal.push('saleId 누락');
    return out;
  }

  function scanOne_(sheet, reason) {
    if (!sheet || out.found) return;
    var name = sheet.getName();
    var lastRow = sheet.getLastRow();
    var lastCol = sheet.getLastColumn();
    var scanMeta = { sheetName: name, reason: reason || '', lastRow: lastRow, lastCol: lastCol, hasSaleIdHeader: false, found: false };
    out.scannedSheets.push(scanMeta);
    if (!lastRow || !lastCol || lastRow < 2) return;
    var values = sheet.getRange(1, 1, lastRow, lastCol).getValues();
    var map = erpFieldB06J41_01_05_headerMap_(values[0]);
    if (map.saleId == null) return;
    scanMeta.hasSaleIdHeader = true;
    for (var r = 1; r < values.length; r++) {
      if (String(values[r][map.saleId] || '').trim() === targetSaleId) {
        out.found = true;
        out.rowNumber = r + 1;
        out.sheetName = name;
        scanMeta.found = true;
        scanMeta.rowNumber = out.rowNumber;
        Object.keys(map).forEach(function (k) { out.row[k] = values[r][map[k]]; });
        break;
      }
    }
  }

  if (sheetCheck && sheetCheck.sheet) {
    scanOne_(sheetCheck.sheet, 'primarySalesCandidate');
  }

  if (!out.found) {
    try {
      var ss = sheetCheck && sheetCheck.sheet ? sheetCheck.sheet.getParent() : null;
      if (ss) {
        ['ERP_판매관리', 'Sales', 'ERP_Sales'].forEach(function (name) {
          if (out.found) return;
          var sh = ss.getSheetByName(name);
          if (sh && (!sheetCheck || !sheetCheck.sheet || sh.getSheetId() !== sheetCheck.sheet.getSheetId())) {
            scanOne_(sh, 'salesCandidateFallback');
          }
        });
        if (!out.found) {
          ss.getSheets().forEach(function (sh) {
            if (out.found) return;
            scanOne_(sh, 'allSheetsSaleIdFallback');
          });
        }
      }
    } catch (e) {
      out.warnings.push('Sales fallback scan failed: ' + e.message);
    }
  }

  if (!out.found && (!sheetCheck || !sheetCheck.sheet)) {
    out.fatal.push('Sales 시트 없음');
  }
  if (!out.found) {
    out.warnings.push('saleId 미발견: ' + targetSaleId);
  }
  return out;
}

function erpFieldB06J41_01_05_simulateIds_(ctx, sale) {
  var stamp = Utilities.formatDate(new Date(), 'Asia/Seoul', 'yyyyMMddHHmmss');
  var suffix = String(Math.floor(Math.random() * 900) + 100);
  return {
    contractIdPreview: 'CON-' + stamp + '-' + suffix,
    documentIdPreview: 'DOC-' + stamp + '-' + suffix,
    sourceSaleId: ctx.saleId,
    sourceCustomerId: (sale && sale.row && sale.row.customerId) ? sale.row.customerId : ctx.customerId,
    contractStatusPreview: 'DRAFT',
    signStatusPreview: 'NOT_STARTED',
    pdfStatusPreview: 'NOT_CREATED',
    createBlockedThisBuild: true
  };
}

function erpFieldB06J41_01_05_requirementMatrix_(result) {
  var saleFound = !!(result.sale && result.sale.found);
  var isDraft = saleFound && String(result.sale.row.status || '').toUpperCase() === 'DRAFT';
  return [
    { axis: '판매 원전표', status: saleFound ? 'READY' : 'BLOCKED', note: 'saleId 기준 Sales 조회' },
    { axis: 'DRAFT 상태', status: isDraft ? 'READY' : 'BLOCKED', note: 'DRAFT 판매만 계약전환 후보' },
    { axis: '계약관리 시트', status: result.checks.contract && result.checks.contract.exists ? 'READY' : 'STRUCTURE_REQUIRED', note: 'ERP_계약관리 후보 점검' },
    { axis: '계약 필수 헤더', status: result.checks.contract && !(result.checks.contract.missingRequiredHeaders || []).length ? 'READY' : 'STRUCTURE_REQUIRED', note: 'contractId/saleId/customerId/status 등' },
    { axis: 'SIGN 문서관리', status: result.checks.sign && result.checks.sign.exists ? 'READY' : 'STRUCTURE_REQUIRED', note: 'documentId 후속 연결 후보' },
    { axis: 'ID 시뮬레이션', status: 'READY', note: 'contractId/documentId 미리보기만 생성' },
    { axis: '저장/외부연동', status: 'BLOCKED_SAFE', note: '이번 빌드는 생성/저장 없음' }
  ];
}

function erpFieldB06J41_01_05_findSheet_(ss, names) {
  var required = ['eventId', 'vendorId', 'customerId', 'status', 'statusReason', 'createdAt', 'createdBy', 'updatedAt', 'updatedBy'];
  var out = { ok: false, exists: false, sheetName: '', candidates: names, lastRow: 0, lastCol: 0, headers: [], missingRequiredHeaders: [], sheet: null };
  for (var i = 0; i < names.length; i++) {
    var sh = ss.getSheetByName(names[i]);
    if (sh) {
      out.exists = true;
      out.ok = true;
      out.sheetName = names[i];
      out.lastRow = sh.getLastRow();
      out.lastCol = sh.getLastColumn();
      out.sheet = sh;
      out.headers = out.lastCol ? sh.getRange(1, 1, 1, out.lastCol).getValues()[0].map(function (v) { return String(v || '').trim(); }) : [];
      var map = erpFieldB06J41_01_05_headerMap_(out.headers);
      out.missingRequiredHeaders = required.filter(function (h) { return map[h] == null; });
      if (names[i] === 'Sales' || names[i] === 'ERP_판매관리' || names[i] === 'ERP_Sales') {
        ['saleId', 'productName', 'quantity', 'unitPrice', 'totalAmount', 'paymentStructure', 'paymentMethod'].forEach(function (h) {
          if (map[h] == null && out.missingRequiredHeaders.indexOf(h) < 0) out.missingRequiredHeaders.push(h);
        });
      }
      if (names[i] === 'ERP_계약관리' || names[i] === 'Contracts' || names[i] === 'ERP_Contract') {
        ['contractId', 'saleId', 'documentId'].forEach(function (h) {
          if (map[h] == null && out.missingRequiredHeaders.indexOf(h) < 0) out.missingRequiredHeaders.push(h);
        });
      }
      break;
    }
  }
  return out;
}

function erpFieldB06J41_01_05_loadConfig_() {
  var out = { ok: false, fatal: [], warnings: [], setupDbId: B06J41_01_05_SETUP_DB_ID, configSheetName: B06J41_01_05_CONFIG_SHEET_NAME, configCount: 0, configMap: {}, masterId: '', masterName: '' };
  try {
    var ss = SpreadsheetApp.openById(B06J41_01_05_SETUP_DB_ID);
    var sh = ss.getSheetByName(B06J41_01_05_CONFIG_SHEET_NAME);
    if (!sh) throw new Error('SystemConfig 시트 없음');
    var values = sh.getDataRange().getValues();
    if (!values || values.length < 2) throw new Error('SystemConfig 데이터 없음');
    var header = erpFieldB06J41_01_05_headerMap_(values[0]);
    var keyCol = header.configKey != null ? header.configKey : (header.key != null ? header.key : 0);
    var valCol = header.configValue != null ? header.configValue : (header.value != null ? header.value : 1);
    if (header.configKey == null || header.configValue == null) out.warnings.push('SystemConfig 헤더명이 표준과 다름: configKey/configValue 확인 필요');
    for (var r = 1; r < values.length; r++) {
      var k = String(values[r][keyCol] || '').trim();
      if (k) out.configMap[k] = values[r][valCol];
    }
    out.configCount = Object.keys(out.configMap).length;
    out.masterId = String(out.configMap.FEELHAUS_DB_MASTER_ID || out.configMap.DB_MASTER_ID || out.configMap.SPREADSHEET_ID || '').trim();
    out.masterName = 'FEELHAUS_DB_MASTER';
    out.ok = !!out.masterId;
    if (!out.ok) out.fatal.push('FEELHAUS_DB_MASTER_ID 누락');
  } catch (err) {
    out.fatal.push(err && err.message ? err.message : String(err));
  }
  return out;
}

function erpFieldB06J41_01_05_openMaster_(config) {
  var meta = { ok: false, fatal: [], warnings: [], masterId: config.masterId || '', masterName: 'FEELHAUS_DB_MASTER' };
  try {
    if (!config.masterId) throw new Error('masterId 없음');
    var ss = SpreadsheetApp.openById(config.masterId);
    meta.ok = true;
    meta.masterSpreadsheetName = ss.getName();
    return { ss: ss, meta: meta };
  } catch (err) {
    meta.fatal.push(err && err.message ? err.message : String(err));
    return { ss: null, meta: meta };
  }
}

function erpFieldB06J41_01_05_headerMap_(headerRow) {
  var map = {};
  (headerRow || []).forEach(function (h, i) {
    var key = String(h || '').trim();
    if (key && map[key] == null) map[key] = i;
  });
  return map;
}

function erpFieldB06J41_01_05_normalize_(ctx) {
  return {
    roleCode: String(ctx.roleCode || 'VIEWER').trim(),
    vendorId: String(ctx.vendorId || '').trim(),
    eventId: String(ctx.eventId || '').trim(),
    customerId: String(ctx.customerId || '').trim(),
    saleId: String(ctx.saleId || '').trim(),
    route: String(ctx.route || 'contractPrecheck').trim(),
    userEmail: String(ctx.userEmail || '').trim(),
    scopeType: 'VENDOR_BRANCH_USER_GROUP',
    hqFullAccess: false
  };
}

function erpFieldB06J41_01_05_result_(label) {
  return {
    ok: true,
    build: B06J41_01_05_BUILD,
    moduleCode: 'ERP_FIELD',
    label: label,
    checkedAt: new Date().toISOString(),
    fatal: [],
    warnings: [],
    expectedBlocks: [],
    checks: {}
  };
}

function erpFieldB06J41_01_05_finish_(result, logOutput) {
  result.ok = (result.fatal || []).length === 0;
  if (logOutput) {
    Logger.log('======================================================');
    Logger.log(JSON.stringify(result, null, 2));
    Logger.log('======================================================');
  }
  return result;
}

function erpFieldB06J41_01_05_escape_(v) {
  return String(v == null ? '' : v).replace(/[&<>\"]/g, function (s) {
    return ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' })[s];
  });
}

function erpFieldB06J41_01_05_money_(v) {
  var n = Number(String(v == null ? 0 : v).replace(/,/g, ''));
  if (!isFinite(n)) n = 0;
  return n.toLocaleString('ko-KR');
}


/* ===== ContLookup.js ===== */
/**
 * build: ERP_B06J41_15_17_CONTRACT_DRAFT_LOOKUP_SAFE_UPLOAD
 * module: ERP_FIELD
 * purpose:
 * - B06J41-15 contractId / saleId 기준 Contracts DRAFT READ ONLY 조회
 * - B06J41-16 같은 saleId 계약 중복 생성 차단 상태 확인
 * - B06J41-17 판매 상세/계약 상세 연결 상태 표시
 * safety:
 * - no contract creation / no SIGN document creation / no PDF / no settlement / no external integration / no delete
 * - SystemConfig standard header: CONFIG_KEY / VALUE first
 */

var FIELD_B06J41_15_17_BUILD = 'ERP_B06J41_15_17_CONTRACT_DRAFT_LOOKUP_SAFE_UPLOAD';
var FIELD_B06J41_15_17_SETUP_DB_ID = '17VMSpgSZCvIrUlgcw8yCNcnl8WQWo2IcRf5tDCcuJGM';
var FIELD_B06J41_15_17_CONFIG_SHEET_NAME = 'SystemConfig';

function erpB06J41_15_17_preflight() {
  var r = erpFieldB06J41_15_17_result_('preflight');
  r.checks.config = erpFieldB06J41_15_17_loadConfig_();
  var master = erpFieldB06J41_15_17_openMaster_(r.checks.config);
  r.checks.master = master.meta;
  if (!master.ss) {
    r.fatal.push('FEELHAUS_DB_MASTER 연결 실패');
    r.ok = false;
    return erpFieldB06J41_15_17_finish_(r, true);
  }
  r.checks.salesSheet = erpFieldB06J41_15_17_findSheet_(master.ss, ['Sales', 'ERP_판매관리', 'ERP_Sales'], erpFieldB06J41_15_17_salesRequired_());
  r.checks.contractSheet = erpFieldB06J41_15_17_findSheet_(master.ss, ['ERP_계약관리', 'Contracts', 'ERP_Contract'], erpFieldB06J41_15_17_contractRequired_());
  r.checks.coreLog = erpFieldB06J41_15_17_findSheet_(master.ss, ['ERP_CoreLog', 'ERP_Log', 'ERP_SalesLog'], []);
  if (!r.checks.contractSheet.exists) r.fatal.push('계약관리 시트 없음: ERP_계약관리 또는 Contracts 필요');
  if ((r.checks.contractSheet.missingRequiredHeaders || []).length) r.fatal.push('계약관리 필수 헤더 누락: ' + r.checks.contractSheet.missingRequiredHeaders.join(', '));
  if (!r.checks.salesSheet.exists) r.fatal.push('Sales 시트 없음');
  if ((r.checks.salesSheet.missingRequiredHeaders || []).length) r.fatal.push('Sales 필수 헤더 누락: ' + r.checks.salesSheet.missingRequiredHeaders.join(', '));
  r.ok = r.fatal.length === 0;
  return erpFieldB06J41_15_17_finish_(r, true);
}

function erpB06J41_15_17_autoRunSafe() {
  var r = erpFieldB06J41_15_17_result_('autoRunSafe');
  r.checks.preflight = erpB06J41_15_17_preflight();
  r.checks.sampleDetailBySale = erpFieldB06J41_15_17_buildVm_({
    roleCode: 'VENDOR_MANAGER', vendorId: 'VND-20260502202158-505', eventId: 'EVT-20260502202016-197',
    customerId: 'CUS-20260504002306-615', saleId: 'SALE-20260504005028-991', route: 'contractDetail'
  });
  r.checks.sampleRecent = erpFieldB06J41_15_17_buildVm_({
    roleCode: 'VENDOR_MANAGER', vendorId: 'VND-20260502202158-505', eventId: 'EVT-20260502202016-197',
    route: 'contractRecent'
  });
  r.checks.missingVendorBlocked = erpFieldB06J41_15_17_buildVm_({ roleCode: 'VENDOR_MANAGER', vendorId: '', eventId: 'EVT-SAMPLE', route: 'contractRecent' });
  Object.keys(r.checks).forEach(function (k) {
    var c = r.checks[k];
    if (!c) r.fatal.push(k + ': 결과 없음');
    if (k === 'missingVendorBlocked') {
      if (c.ok !== false) r.fatal.push(k + ': 차단 기대 테스트가 차단되지 않음');
    } else if (c.ok === false && k !== 'sampleDetailBySale') {
      r.fatal.push(k + ': 정상 기대 테스트 실패');
    }
  });
  r.ok = r.fatal.length === 0;
  return erpFieldB06J41_15_17_finish_(r, true);
}

function erpFieldB06J41_15_17_renderContractLookupHtml(ctx) {
  var vm = erpFieldB06J41_15_17_buildVm_(ctx || {});
  var t = HtmlService.createTemplateFromFile('P_ContLookup');
  t.vm = vm;
  t.json = JSON.stringify(vm, null, 2);
  return t.evaluate()
    .setTitle('계약 DRAFT 조회')
    .setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL);
}

function erpFieldB06J41_15_17_buildVm_(ctx) {
  ctx = erpFieldB06J41_15_17_normalize_(ctx || {});
  var r = erpFieldB06J41_15_17_result_(ctx.route === 'contractRecent' ? 'contractRecentLookup' : 'contractDetailLookup');
  r.context = ctx;
  r.page = {
    badge: 'B06J41-15_17 SAFE : CONTRACT DRAFT LOOKUP',
    title: '계약 DRAFT 조회 / 중복차단 확인',
    subtitle: 'Contracts 계약 DRAFT를 READ ONLY로 조회하고 saleId 기준 중복 생성 차단 상태를 확인합니다.',
    roleName: erpFieldB06J41_15_17_roleName_(ctx.roleCode)
  };
  r.safety = {
    readOnly: true,
    noContractCreate: true,
    noSignDocumentCreate: true,
    noPdfCreate: true,
    noSettlementExecution: true,
    noExternalIntegration: true,
    noDeleteExecution: true,
    configHeaderStandard: 'CONFIG_KEY/VALUE'
  };
  var guard = erpFieldB06J41_15_17_guard_(ctx);
  if (!guard.ok) {
    r.fatal = r.fatal.concat(guard.fatal);
    r.ok = false;
    r.blocked = true;
    return r;
  }
  r.checks.config = erpFieldB06J41_15_17_loadConfig_();
  var master = erpFieldB06J41_15_17_openMaster_(r.checks.config);
  r.checks.master = master.meta;
  if (!master.ss) {
    r.fatal.push('FEELHAUS_DB_MASTER 연결 실패');
    r.ok = false;
    return r;
  }
  r.checks.salesSheet = erpFieldB06J41_15_17_findSheet_(master.ss, ['Sales', 'ERP_판매관리', 'ERP_Sales'], erpFieldB06J41_15_17_salesRequired_());
  r.checks.contractSheet = erpFieldB06J41_15_17_findSheet_(master.ss, ['ERP_계약관리', 'Contracts', 'ERP_Contract'], erpFieldB06J41_15_17_contractRequired_());
  r.sale = erpFieldB06J41_15_17_lookupSale_(r.checks.salesSheet, ctx);
  r.contract = erpFieldB06J41_15_17_lookupContract_(r.checks.contractSheet, ctx);
  r.contracts = erpFieldB06J41_15_17_recentContracts_(r.checks.contractSheet, ctx, 10);
  r.duplicate = {
    saleId: ctx.saleId || (r.contract.row && r.contract.row.saleId) || '',
    existingContractFound: !!(r.contract && r.contract.found),
    duplicateCreateBlocked: !!(r.contract && r.contract.found),
    message: (r.contract && r.contract.found) ? '이 saleId는 이미 계약 DRAFT가 있어 추가 계약 생성은 차단 대상입니다.' : 'saleId 기준 기존 계약이 없습니다.'
  };
  r.urls = erpFieldB06J41_15_17_urls_(ctx, r);
  r.ok = r.fatal.length === 0;
  return r;
}

function erpFieldB06J41_15_17_guard_(ctx) {
  var fatal = [];
  var allowed = { VENDOR_OWNER: true, VENDOR_MANAGER: true, STAFF_SALES: true, VIEWER: true };
  if (!ctx.vendorId) fatal.push('vendorId 누락');
  if (!ctx.eventId) fatal.push('eventId 누락');
  if (!allowed[ctx.roleCode]) fatal.push('미허용 roleCode=' + ctx.roleCode);
  return { ok: fatal.length === 0, fatal: fatal };
}

function erpFieldB06J41_15_17_lookupSale_(check, ctx) {
  var out = { found: false, rowNumber: '', row: {}, warnings: [] };
  if (!check || !check.sheet || !ctx.saleId) return out;
  var values = check.sheet.getDataRange().getValues();
  var hm = check.headerMap || {};
  var si = hm.saleId;
  for (var r = 1; r < values.length; r++) {
    if (String(values[r][si] || '') === ctx.saleId) {
      out.found = true;
      out.rowNumber = r + 1;
      out.row = erpFieldB06J41_15_17_rowObj_(values[r], check.headers);
      return out;
    }
  }
  return out;
}

function erpFieldB06J41_15_17_lookupContract_(check, ctx) {
  var out = { found: false, rowNumber: '', row: {}, by: '', warnings: [] };
  if (!check || !check.sheet) return out;
  var values = check.sheet.getDataRange().getValues();
  var hm = check.headerMap || {};
  var cid = hm.contractId, sid = hm.saleId;
  for (var r = 1; r < values.length; r++) {
    if (ctx.contractId && cid != null && String(values[r][cid] || '') === ctx.contractId) {
      out.found = true; out.rowNumber = r + 1; out.row = erpFieldB06J41_15_17_rowObj_(values[r], check.headers); out.by = 'contractId'; return out;
    }
  }
  for (var i = 1; i < values.length; i++) {
    if (ctx.saleId && sid != null && String(values[i][sid] || '') === ctx.saleId) {
      var row = erpFieldB06J41_15_17_rowObj_(values[i], check.headers);
      if (String(row.vendorId || '') === ctx.vendorId && String(row.eventId || '') === ctx.eventId) {
        out.found = true; out.rowNumber = i + 1; out.row = row; out.by = 'saleId'; return out;
      }
    }
  }
  return out;
}

function erpFieldB06J41_15_17_recentContracts_(check, ctx, limit) {
  var list = [];
  if (!check || !check.sheet) return list;
  var values = check.sheet.getDataRange().getValues();
  var hm = check.headerMap || {};
  for (var r = values.length - 1; r >= 1; r--) {
    var row = erpFieldB06J41_15_17_rowObj_(values[r], check.headers);
    if (String(row.vendorId || '') !== ctx.vendorId) continue;
    if (String(row.eventId || '') !== ctx.eventId) continue;
    if (ctx.customerId && String(row.customerId || '') !== ctx.customerId) continue;
    list.push({ rowNumber: r + 1, row: row });
    if (list.length >= (limit || 10)) break;
  }
  return list;
}

function erpFieldB06J41_15_17_urls_(ctx, vm) {
  var base = erpFieldB06J41_15_17_webAppUrl_();
  var common = '?roleCode=' + encodeURIComponent(ctx.roleCode) + '&vendorId=' + encodeURIComponent(ctx.vendorId) + '&eventId=' + encodeURIComponent(ctx.eventId);
  var saleId = ctx.saleId || (vm.contract && vm.contract.row && vm.contract.row.saleId) || '';
  var customerId = ctx.customerId || (vm.contract && vm.contract.row && vm.contract.row.customerId) || '';
  var contractId = ctx.contractId || (vm.contract && vm.contract.row && vm.contract.row.contractId) || '';
  return {
    salesDetail: base + common + '&route=salesDetail&saleId=' + encodeURIComponent(saleId) + '&customerId=' + encodeURIComponent(customerId),
    contractRecent: base + common + '&route=contractRecent' + (customerId ? '&customerId=' + encodeURIComponent(customerId) : ''),
    contractDetail: base + common + '&route=contractDetail&saleId=' + encodeURIComponent(saleId) + '&contractId=' + encodeURIComponent(contractId) + '&customerId=' + encodeURIComponent(customerId),
    contractCreate: base + common + '&route=contractCreate&saleId=' + encodeURIComponent(saleId) + '&customerId=' + encodeURIComponent(customerId),
    customerLookup: base + common + '&route=customerLookup'
  };
}

function erpFieldB06J41_15_17_loadConfig_() {
  var out = { ok: true, fatal: [], warnings: [], headerPolicy: 'CONFIG_KEY/VALUE first', usedHeaderPair: '', configMap: {}, setupDbId: FIELD_B06J41_15_17_SETUP_DB_ID, configSheetName: FIELD_B06J41_15_17_CONFIG_SHEET_NAME };
  try {
    var ss = SpreadsheetApp.openById(FIELD_B06J41_15_17_SETUP_DB_ID);
    var sh = ss.getSheetByName(FIELD_B06J41_15_17_CONFIG_SHEET_NAME);
    if (!sh) { out.fatal.push('SystemConfig 시트 없음'); out.ok = false; return out; }
    var values = sh.getDataRange().getValues();
    if (values.length < 1) { out.fatal.push('SystemConfig 비어 있음'); out.ok = false; return out; }
    var headers = values[0].map(function (h) { return String(h || '').trim(); });
    var hm = erpFieldB06J41_15_17_headerMap_(headers);
    var pairs = [ ['CONFIG_KEY', 'VALUE'], ['configKey', 'configValue'], ['key', 'value'] ];
    var ki = -1, vi = -1;
    for (var i = 0; i < pairs.length; i++) {
      if (hm[pairs[i][0]] != null && hm[pairs[i][1]] != null) { ki = hm[pairs[i][0]]; vi = hm[pairs[i][1]]; out.usedHeaderPair = pairs[i][0] + '/' + pairs[i][1]; break; }
    }
    if (ki < 0) { out.fatal.push('SystemConfig 표준 헤더 없음: CONFIG_KEY/VALUE'); out.ok = false; return out; }
    for (var r = 1; r < values.length; r++) {
      var k = String(values[r][ki] || '').trim();
      if (k) out.configMap[k] = values[r][vi];
    }
    out.masterId = out.configMap.FEELHAUS_DB_MASTER_ID || out.configMap.DB_MASTER_ID || out.configMap.SPREADSHEET_ID;
    out.setupDbName = 'FEELHAUS_SETUP_DB';
    out.configCount = Object.keys(out.configMap).length;
  } catch (err) {
    out.ok = false; out.fatal.push('SystemConfig 읽기 실패: ' + (err && err.message ? err.message : err));
  }
  return out;
}

function erpFieldB06J41_15_17_openMaster_(cfg) {
  var meta = { ok: false, fatal: [], warnings: [], usedKey: '', masterId: '', masterName: 'FEELHAUS_DB_MASTER' };
  try {
    var map = (cfg && cfg.configMap) || {};
    var id = map.FEELHAUS_DB_MASTER_ID || map.DB_MASTER_ID || map.SPREADSHEET_ID;
    meta.masterId = id;
    meta.usedKey = map.FEELHAUS_DB_MASTER_ID ? 'FEELHAUS_DB_MASTER_ID' : (map.DB_MASTER_ID ? 'DB_MASTER_ID' : 'SPREADSHEET_ID');
    if (!id) { meta.fatal.push('FEELHAUS_DB_MASTER_ID 없음'); return { ss: null, meta: meta }; }
    var ss = SpreadsheetApp.openById(id);
    meta.ok = true; meta.masterSpreadsheetName = ss.getName();
    return { ss: ss, meta: meta };
  } catch (err) {
    meta.fatal.push('마스터 열기 실패: ' + (err && err.message ? err.message : err));
    return { ss: null, meta: meta };
  }
}

function erpFieldB06J41_15_17_findSheet_(ss, names, required) {
  var out = { ok: false, exists: false, sheetName: '', candidates: names, headers: [], headerMap: {}, missingRequiredHeaders: [], sheet: null, lastRow: 0, lastCol: 0 };
  for (var i = 0; i < names.length; i++) {
    var sh = ss.getSheetByName(names[i]);
    if (sh) { out.sheet = sh; out.sheetName = names[i]; out.exists = true; break; }
  }
  if (!out.sheet) { out.missingRequiredHeaders = required || []; return out; }
  out.lastRow = out.sheet.getLastRow(); out.lastCol = out.sheet.getLastColumn();
  out.headers = erpFieldB06J41_15_17_getHeaders_(out.sheet);
  out.headerMap = erpFieldB06J41_15_17_headerMap_(out.headers);
  (required || []).forEach(function (h) { if (out.headerMap[h] == null) out.missingRequiredHeaders.push(h); });
  out.ok = out.missingRequiredHeaders.length === 0;
  return out;
}

function erpFieldB06J41_15_17_salesRequired_() { return ['saleId', 'eventId', 'vendorId', 'customerId', 'status', 'contractId']; }
function erpFieldB06J41_15_17_contractRequired_() { return ['contractId', 'saleId', 'eventId', 'vendorId', 'customerId', 'contractStatus', 'signStatus', 'pdfStatus', 'status', 'createdAt', 'createdBy']; }

function erpFieldB06J41_15_17_getHeaders_(sh) { return sh.getLastColumn() ? sh.getRange(1, 1, 1, sh.getLastColumn()).getValues()[0].map(function (h) { return String(h || '').trim(); }) : []; }
function erpFieldB06J41_15_17_headerMap_(headers) { var m = {}; (headers || []).forEach(function (h, i) { if (h && m[h] == null) m[h] = i; }); return m; }
function erpFieldB06J41_15_17_rowObj_(row, headers) { var o = {}; (headers || []).forEach(function (h, i) { if (h) o[h] = row[i]; }); return o; }
function erpFieldB06J41_15_17_normalize_(ctx) {
  return {
    roleCode: String(ctx.roleCode || 'VIEWER').trim(), vendorId: String(ctx.vendorId || '').trim(), eventId: String(ctx.eventId || '').trim(),
    customerId: String(ctx.customerId || '').trim(), saleId: String(ctx.saleId || '').trim(), contractId: String(ctx.contractId || '').trim(),
    route: String(ctx.route || 'contractRecent').trim(), userEmail: String(ctx.userEmail || '').trim(), scopeType: 'VENDOR_BRANCH_USER_GROUP', hqFullAccess: false
  };
}
function erpFieldB06J41_15_17_webAppUrl_() { try { return ScriptApp.getService().getUrl() || ''; } catch (err) { return ''; } }
function erpFieldB06J41_15_17_roleName_(role) { var map = { VENDOR_OWNER: '업체대표', VENDOR_MANAGER: '업체관리자', STAFF_SALES: '영업직원', VIEWER: '조회전용' }; return (map[role] || role); }
function erpFieldB06J41_15_17_result_(label) { return { ok: true, label: label, build: FIELD_B06J41_15_17_BUILD, moduleCode: 'ERP_FIELD', checkedAt: new Date().toISOString(), fatal: [], warnings: [], checks: {} }; }
function erpFieldB06J41_15_17_finish_(result, logOutput) { result.ok = result.fatal.length === 0; if (logOutput) { Logger.log('======================================================'); Logger.log('[' + FIELD_B06J41_15_17_BUILD + '] RESULT'); Logger.log(JSON.stringify(result, null, 2)); Logger.log('======================================================'); } return result; }
function erpFieldB06J41_15_17_money_(v) { var n = Number(String(v || '0').replace(/,/g, '')); if (!isFinite(n)) n = 0; return String(Math.round(n)).replace(/\B(?=(\d{3})+(?!\d))/g, ','); }
function erpFieldB06J41_15_17_escape_(v) { return String(v == null ? '' : v).replace(/[&<>'"]/g, function (c) { return ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', "'": '&#39;', '"': '&quot;' })[c]; }); }


/* ===== ContCreate.js ===== */
/**
 * build: ERP_B06J41_10_14_CONTRACT_DRAFT_CREATE_SAFE_UPLOAD
 * module: ERP_FIELD
 * purpose:
 * - B06J41-10 contractId 생성
 * - B06J41-11 Contracts / ERP_계약관리 DRAFT 저장
 * - B06J41-12 Sales 원전표에 contractId 안전 연결
 * - B06J41-13 ERP_CoreLog 계약 생성 로그 기록
 * - B06J41-14 SIGN/documentId는 생성하지 않고 NOT_STARTED/NOT_CREATED 상태만 유지
 * safety:
 * - DRAFT sales only
 * - no SIGN call / no PDF / no settlement / no external integration / no delete
 */

var B06J41_10_14_BUILD = 'ERP_B06J41_10_14_CONTRACT_DRAFT_CREATE_SAFE_UPLOAD';
var B06J41_10_14_SETUP_DB_ID = '17VMSpgSZCvIrUlgcw8yCNcnl8WQWo2IcRf5tDCcuJGM';
var B06J41_10_14_CONFIG_SHEET_NAME = 'SystemConfig';

function erpB06J41_10_14_preflight() {
  var result = erpFieldB06J41_10_14_buildVm_({
    roleCode: 'VENDOR_MANAGER',
    vendorId: 'VND-20260502202158-505',
    eventId: 'EVT-20260502202016-197',
    customerId: 'CUS-20260504002306-615',
    saleId: 'SALE-20260504005028-991',
    route: 'contractCreate'
  }, false);
  return erpFieldB06J41_10_14_finish_(result, true);
}

function erpB06J41_10_14_autoRunSafe() {
  var result = erpFieldB06J41_10_14_result_('autoRunSafe');
  result.checks.preflight = erpB06J41_10_14_preflight();
  result.checks.noConfirmNoWrite = erpFieldB06J41_10_14_buildVm_({
    roleCode: 'VENDOR_MANAGER', vendorId: 'VND-20260502202158-505', eventId: 'EVT-20260502202016-197', customerId: 'CUS-20260504002306-615', saleId: 'SALE-20260504005028-991', route: 'contractCreate'
  }, false);
  result.checks.viewerBlocked = erpFieldB06J41_10_14_buildVm_({
    roleCode: 'VIEWER', vendorId: 'VND-20260502202158-505', eventId: 'EVT-20260502202016-197', saleId: 'SALE-20260504005028-991', route: 'contractCreate'
  }, false);
  result.checks.missingSaleBlocked = erpFieldB06J41_10_14_buildVm_({
    roleCode: 'VENDOR_MANAGER', vendorId: 'VND-20260502202158-505', eventId: 'EVT-20260502202016-197', saleId: '', route: 'contractCreate'
  }, false);
  Object.keys(result.checks).forEach(function (k) {
    var c = result.checks[k];
    var expectedBlock = k === 'viewerBlocked' || k === 'missingSaleBlocked';
    if (!c) result.fatal.push(k + ': 결과 없음');
    else if (expectedBlock && c.ok !== false) result.fatal.push(k + ': 차단 기대 테스트가 차단되지 않음');
    else if (!expectedBlock && c.ok === false && k !== 'noConfirmNoWrite') result.fatal.push(k + ': 정상 기대 테스트 실패');
  });
  result.ok = result.fatal.length === 0;
  return erpFieldB06J41_10_14_finish_(result, true);
}

function erpFieldB06J41_10_14_renderContractDraftCreateHtml(ctx) {
  var confirmed = String((ctx && ctx.contractConfirm) || '').toUpperCase() === 'Y';
  var vm = erpFieldB06J41_10_14_buildVm_(ctx || {}, confirmed);
  var t = HtmlService.createTemplateFromFile('P_ContCreate');
  t.vm = vm;
  t.json = JSON.stringify(vm, null, 2);
  return t.evaluate()
    .setTitle('계약 DRAFT 생성')
    .setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL);
}

function erpFieldB06J41_10_14_buildVm_(ctx, confirmed) {
  ctx = erpFieldB06J41_10_14_normalize_(ctx || {});
  var result = erpFieldB06J41_10_14_result_('contractDraftCreate');
  result.confirmed = !!confirmed;
  result.context = ctx;
  result.page = {
    badge: 'B06J41-10_14 SAFE : CONTRACT DRAFT CREATE',
    title: '계약 DRAFT 생성',
    subtitle: 'DRAFT 판매 전표를 계약 DRAFT로 연결합니다. SIGN 문서/PDF/정산은 아직 생성하지 않습니다.',
    roleName: erpFieldB06J41_10_14_roleName_(ctx.roleCode)
  };
  result.safety = {
    draftSalesOnly: true,
    contractDraftOnly: true,
    headerMapBased: true,
    noColumnIndexFixed: true,
    noSignDocumentCreate: true,
    noPdfCreate: true,
    noSettlementExecution: true,
    noExternalIntegration: true,
    noDeleteExecution: true,
    vendorIndependentDbBlocked: true,
    vendorAsBranchUserGroup: true,
    configHeaderStandard: 'CONFIG_KEY/VALUE'
  };

  var guard = erpFieldB06J41_10_14_guard_(ctx);
  if (!guard.ok) {
    result.fatal = result.fatal.concat(guard.fatal);
    result.ok = false;
    result.blocked = true;
    return result;
  }

  result.checks.config = erpFieldB06J41_10_14_loadConfig_();
  var master = erpFieldB06J41_10_14_openMaster_(result.checks.config);
  result.checks.master = master.meta;
  if (!master.ss) {
    result.fatal.push('FEELHAUS_DB_MASTER 연결 실패');
    result.ok = false;
    return result;
  }

  result.checks.salesSheet = erpFieldB06J41_10_14_findSheet_(master.ss, ['Sales', 'ERP_판매관리', 'ERP_Sales'], erpFieldB06J41_10_14_salesRequired_());
  result.checks.contractSheet = erpFieldB06J41_10_14_findSheet_(master.ss, ['ERP_계약관리', 'Contracts', 'ERP_Contract'], erpFieldB06J41_10_14_contractRequired_());
  result.checks.coreLog = erpFieldB06J41_10_14_findSheet_(master.ss, ['ERP_CoreLog', 'ERP_Log', 'ERP_SalesLog'], erpFieldB06J41_10_14_logRequired_());

  result.sale = erpFieldB06J41_10_14_lookupSale_(result.checks.salesSheet, ctx);
  result.existingContract = erpFieldB06J41_10_14_findContractBySale_(result.checks.contractSheet, ctx.saleId);
  result.validation = erpFieldB06J41_10_14_validate_(ctx, result);
  result.preview = erpFieldB06J41_10_14_preview_(ctx, result.sale);
  result.createResult = { attempted: false, created: false, duplicateBlocked: false, contractId: '', rowNumber: '', salesUpdated: false, fatal: [], warnings: [] };

  if (confirmed) {
    if (result.validation.ok) {
      result.createResult = erpFieldB06J41_10_14_createContract_(ctx, result, master.ss);
    } else {
      result.createResult.attempted = true;
      result.createResult.fatal = result.validation.errors.slice();
    }
  }

  result.ok = result.validation.ok && (!confirmed || result.createResult.created || result.createResult.duplicateBlocked);
  result.fatal = confirmed && result.createResult.fatal.length ? result.createResult.fatal : result.fatal;
  result.urls = erpFieldB06J41_10_14_urls_(ctx, result);
  return result;
}

function erpFieldB06J41_10_14_validate_(ctx, vm) {
  var errors = [];
  var warnings = [];
  if (!vm.checks.salesSheet.exists) errors.push('Sales 시트 없음');
  if ((vm.checks.salesSheet.missingRequiredHeaders || []).length) errors.push('Sales 필수 헤더 누락: ' + vm.checks.salesSheet.missingRequiredHeaders.join(', '));
  if (!vm.checks.contractSheet.exists) errors.push('계약관리 시트 없음: ERP_계약관리 또는 Contracts 필요');
  if ((vm.checks.contractSheet.missingRequiredHeaders || []).length) errors.push('계약관리 필수 헤더 누락: ' + vm.checks.contractSheet.missingRequiredHeaders.join(', '));
  if (!vm.checks.coreLog.exists) warnings.push('ERP_CoreLog 없음 또는 후보 미확인: 계약 생성 자체는 가능하나 로그 기록이 제한됩니다.');
  if (!vm.sale.found) errors.push('saleId에 해당하는 판매 DRAFT가 없습니다.');
  if (vm.sale.found) {
    if (String(vm.sale.row.status || '').toUpperCase() !== 'DRAFT') errors.push('DRAFT 상태 판매만 계약 DRAFT 생성 가능. 현재 status=' + vm.sale.row.status);
    if (String(vm.sale.row.vendorId || '') !== ctx.vendorId) errors.push('sale.vendorId 불일치');
    if (String(vm.sale.row.eventId || '') !== ctx.eventId) errors.push('sale.eventId 불일치');
    if (ctx.customerId && String(vm.sale.row.customerId || '') !== ctx.customerId) warnings.push('ctx.customerId와 sale.customerId가 달라 sale 기준으로 계약을 생성합니다.');
  }
  if (vm.existingContract && vm.existingContract.found) warnings.push('이미 saleId에 연결된 계약 DRAFT가 있어 신규 생성은 중복 차단됩니다.');
  if (['VENDOR_OWNER', 'VENDOR_MANAGER', 'STAFF_SALES'].indexOf(ctx.roleCode) < 0) errors.push('계약 DRAFT 생성 미허용 roleCode=' + ctx.roleCode);
  return { ok: errors.length === 0, errors: errors, warnings: warnings, readyForContractDraftCreate: errors.length === 0 };
}

function erpFieldB06J41_10_14_createContract_(ctx, vm, ss) {
  if (!erpFieldB06J41_10_14_v44Approved_(ctx)) {
    return {
      attempted: false,
      created: false,
      duplicateBlocked: false,
      contractId: '',
      rowNumber: '',
      salesUpdated: false,
      fatal: ['FIELD V44 SAFETY: 계약 DRAFT 실제 생성은 승인코드가 있을 때만 1건 제한 허용. approvalCode=FIELD_V44_APPROVED_CONTRACT_DRAFT_ONLY 필요.'],
      warnings: []
    };
  }
  var out = { attempted: true, created: false, duplicateBlocked: false, contractId: '', rowNumber: '', salesUpdated: false, fatal: [], warnings: [] };
  var lock = null;
  try {
    lock = LockService.getScriptLock();
    lock.waitLock(30000);
  } catch (e) {
    out.warnings.push('LockService 대기 실패 또는 생략: ' + (e && e.message ? e.message : e));
  }
  try {
    var salesCheck = erpFieldB06J41_10_14_findSheet_(ss, ['Sales', 'ERP_판매관리', 'ERP_Sales'], erpFieldB06J41_10_14_salesRequired_());
    var contractCheck = erpFieldB06J41_10_14_findSheet_(ss, ['ERP_계약관리', 'Contracts', 'ERP_Contract'], erpFieldB06J41_10_14_contractRequired_());
    var coreLogCheck = erpFieldB06J41_10_14_findSheet_(ss, ['ERP_CoreLog', 'ERP_Log', 'ERP_SalesLog'], erpFieldB06J41_10_14_logRequired_());
    var sale = erpFieldB06J41_10_14_lookupSale_(salesCheck, ctx);
    if (!sale.found) { out.fatal.push('저장 직전 saleId 재조회 실패'); return out; }
    if (String(sale.row.status || '').toUpperCase() !== 'DRAFT') { out.fatal.push('저장 직전 DRAFT 상태 아님'); return out; }
    var existing = erpFieldB06J41_10_14_findContractBySale_(contractCheck, ctx.saleId);
    if (existing.found) {
      out.duplicateBlocked = true;
      out.contractId = existing.row.contractId || '';
      out.rowNumber = existing.rowNumber;
      out.warnings.push('이미 이 saleId에 연결된 계약이 있어 중복 생성을 차단했습니다.');
      return out;
    }
    var sh = contractCheck.sheet;
    if (!sh) { out.fatal.push('계약관리 시트 없음'); return out; }
    var headers = erpFieldB06J41_10_14_getHeaders_(sh);
    var hm = erpFieldB06J41_10_14_headerMap_(headers);
    var now = new Date();
    var userEmail = ctx.userEmail || erpFieldB06J41_10_14_activeUser_();
    var contractId = erpFieldB06J41_10_14_generateId_('CON');
    var logId = erpFieldB06J41_10_14_generateId_('LOG');
    var row = new Array(headers.length).fill('');
    function set(name, value) { var idx = hm[String(name || '').trim()]; if (idx != null && idx >= 0) row[idx] = value; }
    set('contractId', contractId);
    set('documentId', '');
    set('saleId', ctx.saleId);
    set('eventId', ctx.eventId);
    set('vendorId', ctx.vendorId);
    set('customerId', sale.row.customerId || ctx.customerId);
    set('customerName', sale.row.customerName || '');
    set('phone', sale.row.phone || '');
    set('dong', sale.row.dong || '');
    set('ho', sale.row.ho || '');
    set('productSummary', sale.row.productSummary || sale.row.productName || '');
    set('contractAmount', erpFieldB06J41_10_14_num_(sale.row.totalAmount));
    set('totalAmount', erpFieldB06J41_10_14_num_(sale.row.totalAmount));
    set('depositAmount', erpFieldB06J41_10_14_num_(sale.row.depositAmount));
    set('balanceAmount', erpFieldB06J41_10_14_num_(sale.row.balanceAmount));
    set('paymentStructure', sale.row.paymentStructure || '');
    set('paymentMethod', sale.row.paymentMethod || '');
    set('contractStatus', 'DRAFT');
    set('signStatus', 'NOT_STARTED');
    set('pdfStatus', 'NOT_CREATED');
    set('status', 'DRAFT');
    set('statusReason', 'FIELD_CONTRACT_DRAFT_CREATE');
    set('logId', logId);
    set('memo', 'B06J41 FIELD 계약 DRAFT 생성. SIGN/documentId/PDF는 후속 단계에서 처리');
    set('createdAt', now);
    set('createdBy', userEmail || 'FIELD_USER');
    set('updatedAt', now);
    set('updatedBy', userEmail || 'FIELD_USER');
    sh.appendRow(row);
    out.created = true;
    out.contractId = contractId;
    out.rowNumber = sh.getLastRow();
    out.salesUpdated = false;
    out.warnings.push('FIELD V44 LIMITED: Sales 원전표 contractId 직접 수정은 보류했습니다. 계약관리 row의 saleId로 연결 추적합니다.');
    erpFieldB06J41_10_14_log_(ss, coreLogCheck, {
      logId: logId,
      functionName: 'erpFieldB06J41_10_14_createContract_',
      actionType: 'FIELD_CONTRACT_DRAFT_CREATE',
      eventId: ctx.eventId,
      vendorId: ctx.vendorId,
      customerId: sale.row.customerId || ctx.customerId,
      saleId: ctx.saleId,
      contractId: contractId,
      documentId: '',
      payloadJson: JSON.stringify({ build: B06J41_10_14_BUILD, saleId: ctx.saleId, contractId: contractId })
    });
    return out;
  } catch (err) {
    out.fatal.push(err && err.message ? err.message : String(err));
    return out;
  } finally {
    try { if (lock) lock.releaseLock(); } catch (releaseErr) {}
  }
}

function erpFieldB06J41_10_14_updateSalesContractId_(salesCheck, rowNumber, contractId, userEmail) {
  if (!salesCheck || !salesCheck.sheet || !rowNumber) return false;
  var sh = salesCheck.sheet;
  var headers = erpFieldB06J41_10_14_getHeaders_(sh);
  var hm = erpFieldB06J41_10_14_headerMap_(headers);
  if (hm.contractId == null) return false;
  var existing = String(sh.getRange(rowNumber, hm.contractId + 1).getValue() || '').trim();
  if (existing) return false;
  sh.getRange(rowNumber, hm.contractId + 1).setValue(contractId);
  if (hm.updatedAt != null) sh.getRange(rowNumber, hm.updatedAt + 1).setValue(new Date());
  if (hm.updatedBy != null) sh.getRange(rowNumber, hm.updatedBy + 1).setValue(userEmail || 'FIELD_USER');
  return true;
}

function erpFieldB06J41_10_14_lookupSale_(sheetCheck, ctx) {
  var out = { found: false, rowNumber: 0, row: {}, fatal: [], warnings: [], sheetName: '', scannedSheets: [] };
  var targetSaleId = String((ctx && ctx.saleId) || '').trim();
  if (!targetSaleId) {
    out.fatal.push('saleId 누락');
    return out;
  }

  function scanOne_(sheet, reason) {
    if (!sheet || out.found) return;
    var name = sheet.getName();
    var lastRow = sheet.getLastRow();
    var lastCol = sheet.getLastColumn();
    var scanMeta = { sheetName: name, reason: reason || '', lastRow: lastRow, lastCol: lastCol, hasSaleIdHeader: false, found: false };
    out.scannedSheets.push(scanMeta);
    if (!lastRow || !lastCol || lastRow < 2) return;
    var values = sheet.getRange(1, 1, lastRow, lastCol).getValues();
    var hm = erpFieldB06J41_10_14_headerMap_(values[0]);
    if (hm.saleId == null) return;
    scanMeta.hasSaleIdHeader = true;
    for (var r = 1; r < values.length; r++) {
      if (String(values[r][hm.saleId] || '').trim() === targetSaleId) {
        out.found = true;
        out.rowNumber = r + 1;
        out.sheetName = name;
        scanMeta.found = true;
        scanMeta.rowNumber = out.rowNumber;
        Object.keys(hm).forEach(function (k) { out.row[k] = values[r][hm[k]]; });
        break;
      }
    }
  }

  if (sheetCheck && sheetCheck.sheet) {
    scanOne_(sheetCheck.sheet, 'primarySalesCandidate');
  }

  if (!out.found) {
    try {
      var ss = sheetCheck && sheetCheck.sheet ? sheetCheck.sheet.getParent() : null;
      if (ss) {
        ['ERP_판매관리', 'Sales', 'ERP_Sales'].forEach(function (name) {
          if (out.found) return;
          var sh = ss.getSheetByName(name);
          if (sh && (!sheetCheck || !sheetCheck.sheet || sh.getSheetId() !== sheetCheck.sheet.getSheetId())) {
            scanOne_(sh, 'salesCandidateFallback');
          }
        });
        if (!out.found) {
          ss.getSheets().forEach(function (sh) {
            if (out.found) return;
            scanOne_(sh, 'allSheetsSaleIdFallback');
          });
        }
      }
    } catch (e) {
      out.warnings.push('Sales fallback scan failed: ' + (e && e.message ? e.message : e));
    }
  }

  if (!out.found && (!sheetCheck || !sheetCheck.sheet)) {
    out.fatal.push('Sales 시트 없음');
  }
  if (!out.found) {
    out.warnings.push('saleId 미발견: ' + targetSaleId);
  }
  return out;
}

function erpFieldB06J41_10_14_findContractBySale_(contractCheck, saleId) {
  var out = { found: false, rowNumber: 0, row: {} };
  if (!contractCheck || !contractCheck.sheet || !saleId) return out;
  var sh = contractCheck.sheet;
  var values = sh.getDataRange().getValues();
  if (!values || values.length < 2) return out;
  var hm = erpFieldB06J41_10_14_headerMap_(values[0]);
  if (hm.saleId == null) return out;
  for (var r = 1; r < values.length; r++) {
    if (String(values[r][hm.saleId] || '') === saleId) {
      out.found = true;
      out.rowNumber = r + 1;
      Object.keys(hm).forEach(function (k) { out.row[k] = values[r][hm[k]]; });
      break;
    }
  }
  return out;
}

function erpFieldB06J41_10_14_preview_(ctx, sale) {
  return {
    contractIdPreview: erpFieldB06J41_10_14_generateId_('CON'),
    documentIdPolicy: 'NOT_CREATED_THIS_BUILD',
    signStatusPreview: 'NOT_STARTED',
    pdfStatusPreview: 'NOT_CREATED',
    sourceSaleId: ctx.saleId,
    sourceCustomerId: sale && sale.row ? (sale.row.customerId || ctx.customerId) : ctx.customerId
  };
}

function erpFieldB06J41_10_14_guard_(ctx) {
  var fatal = [];
  var roles = { VENDOR_OWNER: true, VENDOR_MANAGER: true, STAFF_SALES: true };
  if (!ctx.vendorId) fatal.push('vendorId 누락');
  if (!ctx.eventId) fatal.push('eventId 누락');
  if (!ctx.saleId) fatal.push('saleId 누락');
  if (!roles[ctx.roleCode]) fatal.push('계약 DRAFT 생성 미허용 roleCode=' + ctx.roleCode);
  return { ok: fatal.length === 0, fatal: fatal };
}

function erpFieldB06J41_10_14_normalize_(p) {
  return {
    roleCode: String(p.roleCode || 'VIEWER').trim(),
    vendorId: String(p.vendorId || '').trim(),
    eventId: String(p.eventId || '').trim(),
    customerId: String(p.customerId || '').trim(),
    saleId: String(p.saleId || '').trim(),
    route: String(p.route || 'contractCreate').trim(),
    contractConfirm: String(p.contractConfirm || '').trim(),
    approvalCode: String(p.approvalCode || p.v44ApprovalCode || '').trim(),
    userEmail: String(p.userEmail || '').trim(),
    scopeType: 'VENDOR_BRANCH_USER_GROUP',
    hqFullAccess: false
  };
}

function erpFieldB06J41_10_14_v44Approved_(ctx) {
  return String((ctx && ctx.contractConfirm) || '').toUpperCase() === 'Y'
    && String((ctx && ctx.approvalCode) || '') === 'FIELD_V44_APPROVED_CONTRACT_DRAFT_ONLY';
}

function erpFieldB06J41_10_14_salesRequired_() {
  return ['saleId', 'eventId', 'vendorId', 'customerId', 'status', 'contractId', 'totalAmount', 'depositAmount', 'balanceAmount', 'paymentStructure', 'paymentMethod', 'createdAt', 'createdBy', 'updatedAt', 'updatedBy'];
}
function erpFieldB06J41_10_14_contractRequired_() {
  return ['contractId', 'documentId', 'saleId', 'eventId', 'vendorId', 'customerId', 'status', 'statusReason', 'contractStatus', 'signStatus', 'pdfStatus', 'contractAmount', 'totalAmount', 'depositAmount', 'balanceAmount', 'paymentStructure', 'paymentMethod', 'createdAt', 'createdBy', 'updatedAt', 'updatedBy'];
}
function erpFieldB06J41_10_14_logRequired_() {
  return ['logId', 'functionName', 'actionType', 'eventId', 'vendorId', 'customerId', 'saleId', 'contractId', 'documentId', 'payloadJson', 'createdAt', 'createdBy'];
}

function erpFieldB06J41_10_14_findSheet_(ss, names, required) {
  var out = { ok: false, exists: false, sheetName: '', candidates: names, lastRow: 0, lastCol: 0, headers: [], missingRequiredHeaders: [], sheet: null };
  for (var i = 0; i < names.length; i++) {
    var sh = ss.getSheetByName(names[i]);
    if (sh) {
      out.exists = true; out.ok = true; out.sheetName = names[i]; out.sheet = sh;
      out.lastRow = sh.getLastRow(); out.lastCol = sh.getLastColumn();
      out.headers = erpFieldB06J41_10_14_getHeaders_(sh);
      var hm = erpFieldB06J41_10_14_headerMap_(out.headers);
      (required || []).forEach(function (h) { if (hm[h] == null) out.missingRequiredHeaders.push(h); });
      break;
    }
  }
  return out;
}

function erpFieldB06J41_10_14_loadConfig_() {
  var out = { ok: true, fatal: [], warnings: [], setupDbId: B06J41_10_14_SETUP_DB_ID, configSheetName: B06J41_10_14_CONFIG_SHEET_NAME, headerPolicy: 'CONFIG_KEY/VALUE first', usedHeaderPair: '', configMap: {} };
  try {
    var ss = SpreadsheetApp.openById(B06J41_10_14_SETUP_DB_ID);
    var sh = ss.getSheetByName(B06J41_10_14_CONFIG_SHEET_NAME);
    if (!sh) { out.ok = false; out.fatal.push('SystemConfig 시트 없음'); return out; }
    var values = sh.getDataRange().getValues();
    if (!values || values.length < 2) return out;
    var headers = values[0].map(function (v) { return String(v || '').trim(); });
    var hm = erpFieldB06J41_10_14_headerMap_(headers);
    var keyIdx = hm.CONFIG_KEY != null ? hm.CONFIG_KEY : (hm.configKey != null ? hm.configKey : hm.key);
    var valIdx = hm.VALUE != null ? hm.VALUE : (hm.configValue != null ? hm.configValue : hm.value);
    if (hm.CONFIG_KEY != null && hm.VALUE != null) out.usedHeaderPair = 'CONFIG_KEY/VALUE';
    else if (hm.configKey != null && hm.configValue != null) out.usedHeaderPair = 'configKey/configValue';
    else if (hm.key != null && hm.value != null) out.usedHeaderPair = 'key/value';
    else { out.ok = false; out.fatal.push('SystemConfig 키/값 헤더 없음'); return out; }
    for (var r = 1; r < values.length; r++) {
      var k = String(values[r][keyIdx] || '').trim();
      if (k) out.configMap[k] = values[r][valIdx];
    }
    out.masterId = String(out.configMap.FEELHAUS_DB_MASTER_ID || out.configMap.DB_MASTER_ID || out.configMap.SPREADSHEET_ID || '').trim();
    out.setupDbName = 'FEELHAUS_SETUP_DB';
    out.configCount = Object.keys(out.configMap).length;
  } catch (err) {
    out.ok = false; out.fatal.push(err && err.message ? err.message : String(err));
  }
  return out;
}

function erpFieldB06J41_10_14_openMaster_(config) {
  var out = { ss: null, meta: { ok: false, fatal: [], warnings: [], usedKey: '', masterId: '', masterName: 'FEELHAUS_DB_MASTER' } };
  try {
    var map = (config && config.configMap) || {};
    var masterId = String(map.FEELHAUS_DB_MASTER_ID || map.DB_MASTER_ID || map.SPREADSHEET_ID || '').trim();
    out.meta.masterId = masterId;
    out.meta.usedKey = map.FEELHAUS_DB_MASTER_ID ? 'FEELHAUS_DB_MASTER_ID' : (map.DB_MASTER_ID ? 'DB_MASTER_ID' : 'SPREADSHEET_ID');
    if (!masterId) { out.meta.fatal.push('MASTER ID 없음'); return out; }
    out.ss = SpreadsheetApp.openById(masterId);
    out.meta.ok = true;
    out.meta.masterSpreadsheetName = out.ss.getName();
  } catch (err) {
    out.meta.fatal.push(err && err.message ? err.message : String(err));
  }
  return out;
}

function erpFieldB06J41_10_14_getHeaders_(sheet) {
  if (!sheet || sheet.getLastColumn() < 1) return [];
  return sheet.getRange(1, 1, 1, sheet.getLastColumn()).getValues()[0].map(function (v) { return String(v || '').trim(); });
}
function erpFieldB06J41_10_14_headerMap_(headers) {
  var map = {};
  (headers || []).forEach(function (h, i) { if (String(h || '').trim()) map[String(h).trim()] = i; });
  return map;
}
function erpFieldB06J41_10_14_generateId_(prefix) {
  var stamp = Utilities.formatDate(new Date(), 'Asia/Seoul', 'yyyyMMddHHmmss');
  var suffix = String(Math.floor(Math.random() * 900) + 100);
  return prefix + '-' + stamp + '-' + suffix;
}
function erpFieldB06J41_10_14_num_(v) {
  var n = Number(String(v == null ? '' : v).replace(/[^0-9.-]/g, ''));
  return isNaN(n) ? 0 : n;
}
function erpFieldB06J41_10_14_activeUser_() {
  try { return Session.getActiveUser().getEmail() || ''; } catch (e) { return ''; }
}
function erpFieldB06J41_10_14_log_(ss, logCheck, data) {
  try {
    if (!logCheck || !logCheck.sheet) return false;
    var sh = logCheck.sheet;
    var headers = erpFieldB06J41_10_14_getHeaders_(sh);
    var hm = erpFieldB06J41_10_14_headerMap_(headers);
    var row = new Array(headers.length).fill('');
    function set(n, v) { var idx = hm[n]; if (idx != null) row[idx] = v; }
    Object.keys(data || {}).forEach(function (k) { set(k, data[k]); });
    set('createdAt', new Date());
    set('createdBy', erpFieldB06J41_10_14_activeUser_() || 'FIELD_USER');
    sh.appendRow(row);
    return true;
  } catch (e) { return false; }
}
function erpFieldB06J41_10_14_urls_(ctx, vm) {
  var base = '';
  try { base = ScriptApp.getService().getUrl(); } catch (e) {}
  var q = 'roleCode=' + encodeURIComponent(ctx.roleCode) + '&vendorId=' + encodeURIComponent(ctx.vendorId) + '&eventId=' + encodeURIComponent(ctx.eventId) + '&customerId=' + encodeURIComponent(ctx.customerId || (vm.sale && vm.sale.row && vm.sale.row.customerId) || '') + '&saleId=' + encodeURIComponent(ctx.saleId);
  return {
    contractCreate: base + '?' + q + '&route=contractCreate',
    contractCreateConfirm: base + '?' + q + '&route=contractCreate&contractConfirm=Y',
    salesDetail: base + '?' + q + '&route=salesDetail'
  };
}
function erpFieldB06J41_10_14_roleName_(roleCode) {
  return ({ VENDOR_OWNER: '업체대표', VENDOR_MANAGER: '업체관리자', STAFF_SALES: '영업직원', VIEWER: '조회전용' })[roleCode] || roleCode;
}
function erpFieldB06J41_10_14_result_(label) {
  return { ok: true, label: label, build: B06J41_10_14_BUILD, moduleCode: 'ERP_FIELD', checkedAt: new Date().toISOString(), fatal: [], warnings: [], checks: {} };
}
function erpFieldB06J41_10_14_finish_(result, logIt) {
  result.ok = !(result.fatal && result.fatal.length);
  if (logIt) {
    Logger.log('======================================================');
    Logger.log('[' + B06J41_10_14_BUILD + '] RESULT');
    Logger.log(JSON.stringify(result, null, 2));
    Logger.log('======================================================');
  }
  return result;
}

/**
 * FIX1: Sales 원전표 contractId 연결 헤더 안전 보정
 * - 판매 행 저장/계약 생성 없음
 * - Sales 1행 끝에 contractId 헤더만 누락 시 추가
 */
function erpB06J41_10_14_confirmedSalesContractLinkHeaderFix() {
  var result = erpFieldB06J41_10_14_result_('confirmedSalesContractLinkHeaderFix');
  result.confirmed = true;
  result.action = 'ADD_MISSING_SALES_CONTRACT_ID_HEADER_ONLY';
  result.createdContract = false;
  result.createdDocument = false;
  result.createdPdf = false;
  result.updatedSettlement = false;
  result.appendedHeaders = [];
  try {
    result.checks.config = erpFieldB06J41_10_14_loadConfig_();
    var master = erpFieldB06J41_10_14_openMaster_(result.checks.config);
    result.checks.master = master.meta;
    if (!master.ss) {
      result.fatal.push('FEELHAUS_DB_MASTER 연결 실패');
      return erpFieldB06J41_10_14_finish_(result, true);
    }
    var salesCheck = erpFieldB06J41_10_14_findSheet_(master.ss, ['Sales', 'ERP_판매관리', 'ERP_Sales'], ['saleId', 'eventId', 'vendorId', 'customerId', 'status']);
    result.checks.salesSheetBefore = salesCheck;
    if (!salesCheck || !salesCheck.sheet) {
      result.fatal.push('Sales 시트 없음');
      return erpFieldB06J41_10_14_finish_(result, true);
    }
    var sh = salesCheck.sheet;
    var headers = erpFieldB06J41_10_14_getHeaders_(sh);
    var hm = erpFieldB06J41_10_14_headerMap_(headers);
    if (hm.contractId == null) {
      sh.getRange(1, sh.getLastColumn() + 1).setValue('contractId');
      result.appendedHeaders.push('contractId');
    }
    result.checks.salesSheetAfter = erpFieldB06J41_10_14_findSheet_(master.ss, ['Sales', 'ERP_판매관리', 'ERP_Sales'], erpFieldB06J41_10_14_salesRequired_());
    result.ok = !(result.fatal && result.fatal.length) && ((result.checks.salesSheetAfter.missingRequiredHeaders || []).length === 0);
    if (!result.ok) {
      result.fatal.push('Sales 필수 헤더 보정 후에도 누락: ' + (result.checks.salesSheetAfter.missingRequiredHeaders || []).join(', '));
    }
  } catch (err) {
    result.fatal.push(err && err.message ? err.message : String(err));
    result.ok = false;
  }
  return erpFieldB06J41_10_14_finish_(result, true);
}
