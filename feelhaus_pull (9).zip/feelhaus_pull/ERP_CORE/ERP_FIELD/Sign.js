/* ===== SigFolder.js ===== */
/**
 * build: ERP_B06J41_91_95C_SIGNATURE_FOLDER_ID_EXTRACT_FIX_SAFE_UPLOAD
 * purpose:
 * - SystemConfig CONFIG_KEY/VALUE 기준 서명 이미지 저장 폴더 우선순위 점검
 * - SIGN_IMAGE_FOLDER_ID 1순위 고정 확인
 * - 폴더명 정책값(SIGN_SIGNATURE_FOLDER)은 ID로 오인하지 않는지 확인
 * safety:
 * - folder resolve check only
 * - no signature save / no sign complete / no PDF / no Drive archive / no settlement / no external integration
 */
function erpB06J41_91_95C_signatureFolderIdExtractSelfTest() {
  var result = {
    ok: true,
    build: 'ERP_B06J41_91_95C_SIGNATURE_FOLDER_ID_EXTRACT_FIX_SAFE_UPLOAD',
    moduleCode: 'ERP_FIELD',
    checkedAt: new Date().toISOString(),
    fatal: [],
    warnings: [],
    expectedPriority: [
      '1:SIGN_IMAGE_FOLDER_ID',
      '2:SIGN_IMAGE_FOLDER_URL',
      '3:SIGN_IMAGES_FOLDER_ID',
      '4:SIGN_IMAGES_FOLDER_URL',
      '5:SIGNATURE_FOLDER_ID',
      '6:SIGNATURE_FOLDER_URL',
      '7:SIGN_FOLDER_ID',
      '8:SIGN_FOLDER_URL',
      '9:ROOT_FOLDER_ID + SIGN_SIGNATURE_FOLDER lookup only'
    ],
    noSignInputSave: true,
    noSignComplete: true,
    noPdf: true,
    noDriveArchive: true,
    noSettlement: true,
    noExternalIntegration: true,
    noRowCreation: true,
    noHeaderAppend: true
  };
  try {
    if (typeof erpFieldB06J41_37_40_loadConfig_ !== 'function') {
      result.fatal.push('설정 로더 누락: erpFieldB06J41_37_40_loadConfig_');
    } else if (typeof erpFieldB06J41_91_95_resolveSignatureFolder_ !== 'function') {
      result.fatal.push('폴더 해석 함수 누락: erpFieldB06J41_91_95_resolveSignatureFolder_');
    } else {
      var config = erpFieldB06J41_37_40_loadConfig_();
      result.config = {
        ok: !!config.ok,
        usedHeaderPair: config.usedHeaderPair || (config.headerPolicy || 'CONFIG_KEY/VALUE first'),
        setupDbName: config.setupDbName || '',
        configSheetName: config.configSheetName || '',
        masterId: config.masterId || ''
      };
      if (!config.ok) {
        result.fatal = result.fatal.concat(config.fatal || ['SystemConfig 로드 실패']);
      } else {
        var cm = config.configMap || {};
        result.folderConfigValues = {
          SIGN_IMAGE_FOLDER_ID: String(cm.SIGN_IMAGE_FOLDER_ID || ''),
          SIGN_IMAGE_FOLDER_URL: String(cm.SIGN_IMAGE_FOLDER_URL || ''),
          SIGN_IMAGES_FOLDER_ID: String(cm.SIGN_IMAGES_FOLDER_ID || ''),
          SIGN_IMAGES_FOLDER_URL: String(cm.SIGN_IMAGES_FOLDER_URL || ''),
          SIGNATURE_FOLDER_ID: String(cm.SIGNATURE_FOLDER_ID || ''),
          SIGNATURE_FOLDER_URL: String(cm.SIGNATURE_FOLDER_URL || ''),
          SIGN_FOLDER_ID: String(cm.SIGN_FOLDER_ID || ''),
          SIGN_FOLDER_URL: String(cm.SIGN_FOLDER_URL || ''),
          ROOT_FOLDER_ID: String(cm.ROOT_FOLDER_ID || ''),
          SIGN_SIGNATURE_FOLDER: String(cm.SIGN_SIGNATURE_FOLDER || '')
        };
        result.primaryConfigured = !!String(cm.SIGN_IMAGE_FOLDER_ID || '').trim();
        result.folderNamePolicyIsNameOnly = !!String(cm.SIGN_SIGNATURE_FOLDER || '').trim();
        var folder = erpFieldB06J41_91_95_resolveSignatureFolder_(cm);
        result.signatureFolder = folder.meta || {};
        result.resolveWarnings = folder.warnings || [];
        if (!folder.ok) result.fatal = result.fatal.concat(folder.fatal || []);
        result.signatureFolderResolveReady = !!folder.ok;
        result.usedKey = result.signatureFolder.usedKey || '';
        result.usedPriority = result.signatureFolder.usedPriority || 0;
        result.usedFolderId = result.signatureFolder.folderId || '';
        result.usedFolderName = result.signatureFolder.folderName || '';
        result.configFirstApplied = result.usedKey === 'SIGN_IMAGE_FOLDER_ID' || result.usedPriority >= 1;
        result.signImageFolderIdFirst = result.expectedPriority[0] === '1:SIGN_IMAGE_FOLDER_ID';
      }
    }
  } catch (err) {
    result.fatal.push('B06J41-91~95B folder config-first selftest fatal: ' + (err && err.message ? err.message : err));
  }
  result.ok = result.fatal.length === 0;
  Logger.log('======================================================');
  Logger.log('[ERP_B06J41_91_95C_SIGNATURE_FOLDER_ID_EXTRACT_FIX_SAFE_UPLOAD] RESULT');
  Logger.log(JSON.stringify(result, null, 2));
  Logger.log('======================================================');
  return result;
}

function erpB06J41_91_95B_signatureFolderConfigFirstSelfTest() {
  return erpB06J41_91_95C_signatureFolderIdExtractSelfTest();
}


/* ===== SigHandoff.js ===== */
/**
 * build: ERP_B06J41_91_95D_SIGNATURE_SAVE_HANDOFF_TO_SIGN_SAFE_UPLOAD
 * file: FieldSignatureSaveHandoffCheck.js
 * purpose: SIGN 저장 인계 구조 selfTest
 */
function erpB06J41_91_95D_signatureSaveHandoffSelfTest_Log() {
  return erpB06J41_91_95D_signatureSaveHandoffSelfTest();
}


/* ===== SigSchema.js ===== */
/**
 * build: ERP_B06J41_76_80_SIGNATURE_SAVE_SCHEMA_FIX_SAFE_UPLOAD
 * module: ERP_FIELD
 * purpose:
 * - SIGN_Documents 서명 저장 확장 헤더 보정
 * - signaturePath / signatureFileId / signatureDataHash / signatureSavedAt / signatureSavedBy 추가
 * safety:
 * - header append only on SIGN_Documents row 1
 * - no sign image save / no sign complete / no PDF / no Drive / no settlement / no external integration
 * - no row creation / no status change / no delete
 * - SystemConfig standard header: CONFIG_KEY / VALUE first
 */

var FIELD_B06J41_76_80_BUILD = 'ERP_B06J41_76_80_SIGNATURE_SAVE_SCHEMA_FIX_SAFE_UPLOAD';
var FIELD_B06J41_76_80_DEFAULT_CTX = {
  roleCode: 'VENDOR_MANAGER',
  vendorId: 'VND-20260502202158-505',
  eventId: 'EVT-20260502202016-197',
  customerId: 'CUS-20260504002306-615',
  saleId: 'SALE-20260504005028-991',
  contractId: 'CON-20260504021423-908',
  documentId: 'DOC-20260504175000-946',
  route: 'signatureSchemaFix'
};
var FIELD_B06J41_76_80_SIGNATURE_HEADERS = ['signaturePath','signatureFileId','signatureDataHash','signatureSavedAt','signatureSavedBy'];

function erpB06J41_76_80_preflight() {
  return erpFieldB06J41_76_80_run_(FIELD_B06J41_76_80_DEFAULT_CTX, false, true);
}

function erpB06J41_76_80_autoRunSafe() {
  return erpFieldB06J41_76_80_run_(FIELD_B06J41_76_80_DEFAULT_CTX, true, true);
}

function erpB06J41_76_80_signatureSaveSchemaFixSafe() {
  return erpFieldB06J41_76_80_run_(FIELD_B06J41_76_80_DEFAULT_CTX, true, true);
}

function erpFieldB06J41_76_80_renderSignatureSaveSchemaFixHtml(ctx) {
  var shouldFix = String((ctx && (ctx.confirmFix || ctx.action)) || '').toLowerCase();
  var allowFix = shouldFix === '1' || shouldFix === 'fix' || shouldFix === 'schemafix';
  var vm = erpFieldB06J41_76_80_buildVm_(ctx || {}, allowFix);
  var t = HtmlService.createTemplateFromFile('P_SigSchema');
  t.vm = vm;
  t.json = JSON.stringify(vm, null, 2);
  return t.evaluate().setTitle('SIGN 서명 저장 헤더 보정').setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL);
}

function erpFieldB06J41_76_80_buildVm_(ctx, allowFix) {
  ctx = erpFieldB06J41_76_80_normalize_(ctx || {});
  var result = erpFieldB06J41_76_80_run_(ctx, allowFix, false);
  result.context = ctx;
  result.page = {
    badge: 'B06J41-76_80 SAFE : SIGNATURE SAVE SCHEMA FIX',
    title: 'SIGN 서명 저장 헤더 보정',
    subtitle: 'SIGN_Documents에 서명 저장용 확장 헤더만 보정합니다. 서명저장·완료·PDF·Drive·정산은 계속 차단합니다.',
    roleName: (typeof erpFieldB06J41_37_40_roleName_ === 'function') ? erpFieldB06J41_37_40_roleName_(ctx.roleCode) : ctx.roleCode
  };
  result.urls = erpFieldB06J41_76_80_urls_(ctx);
  return result;
}

function erpFieldB06J41_76_80_run_(ctx, executeFix, logOutput) {
  ctx = erpFieldB06J41_76_80_normalize_(ctx || {});
  var result = erpFieldB06J41_76_80_result_('signatureSaveSchemaFix');
  result.contextSummary = {
    eventId: ctx.eventId,
    vendorId: ctx.vendorId,
    customerId: ctx.customerId,
    saleId: ctx.saleId,
    contractId: ctx.contractId,
    documentId: ctx.documentId
  };
  result.executeFix = !!executeFix;
  try {
    if (typeof erpFieldB06J41_71_75_run_ !== 'function') {
      result.fatal.push('B06J41-71~75 서명 저장 DryRun 엔진 누락: FieldSignatureSaveDryRun.js 필요');
      return erpFieldB06J41_76_80_finish_(result, logOutput);
    }

    var before = erpFieldB06J41_71_75_run_(erpFieldB06J41_76_80_cloneCtxForDryRun_(ctx), false);
    result.checks.beforeDryRun = erpFieldB06J41_76_80_compactDryRun_(before);
    result.document = erpFieldB06J41_76_80_copy_(before.document || {});
    result.contract = erpFieldB06J41_76_80_copy_(before.contract || {});
    result.sale = erpFieldB06J41_76_80_copy_(before.sale || {});

    var schema = before.checks && before.checks.schema ? before.checks.schema : {};
    result.schemaBefore = {
      signSheetName: schema.signSheetName || 'SIGN_Documents',
      signSheetExists: !!schema.signSheetExists,
      lastColBefore: schema.lastCol || 0,
      lastRow: schema.lastRow || 0,
      missingStorageHeaderGroups: schema.missingStorageHeaderGroups || [],
      addHeaderPlan: schema.addHeaderPlan || [],
      resolvedHeaders: schema.resolvedHeaders || {}
    };

    if (!before.ok && before.fatal && before.fatal.length) {
      result.fatal = result.fatal.concat(before.fatal.map(function (m) { return 'beforeDryRun: ' + m; }));
    }
    if (!result.schemaBefore.signSheetExists) {
      result.fatal.push('SIGN_Documents 시트 없음');
      return erpFieldB06J41_76_80_finish_(result, logOutput);
    }

    result.headerFix = erpFieldB06J41_76_80_appendMissingHeaders_(result.schemaBefore.addHeaderPlan, executeFix);

    var after = erpFieldB06J41_71_75_run_(erpFieldB06J41_76_80_cloneCtxForDryRun_(ctx), false);
    var afterSchema = after.checks && after.checks.schema ? after.checks.schema : {};
    result.checks.afterDryRun = erpFieldB06J41_76_80_compactDryRun_(after);
    result.schemaAfter = {
      signSheetName: afterSchema.signSheetName || 'SIGN_Documents',
      lastColAfter: afterSchema.lastCol || 0,
      missingStorageHeaderGroups: afterSchema.missingStorageHeaderGroups || [],
      resolvedHeaders: afterSchema.resolvedHeaders || {},
      addHeaderPlan: afterSchema.addHeaderPlan || []
    };

    if ((result.schemaAfter.missingStorageHeaderGroups || []).length) {
      result.fatal.push('서명 저장 확장 헤더 보정 후에도 누락: ' + result.schemaAfter.missingStorageHeaderGroups.join(', '));
    }
  } catch (err) {
    result.fatal.push('B06J41-76~80 signature schema fix fatal: ' + (err && err.message ? err.message : err));
  }
  return erpFieldB06J41_76_80_finish_(result, logOutput);
}

function erpFieldB06J41_76_80_appendMissingHeaders_(plannedHeaders, executeFix) {
  var out = {
    ok: true,
    fatal: [],
    warnings: [],
    mode: executeFix ? 'HEADER_APPEND_ONLY' : 'PREVIEW_ONLY',
    plannedHeaders: plannedHeaders || [],
    addedHeaders: [],
    alreadyExists: [],
    targetSheet: 'SIGN_Documents',
    targetRow: 1,
    noRowCreation: true,
    noStatusChange: true,
    noSignInputSave: true,
    noSignComplete: true,
    noPdf: true,
    noDriveSave: true,
    noSettlement: true,
    noExternalIntegration: true
  };
  try {
    var cfg = erpFieldB06J41_37_40_loadConfig_();
    if (!cfg.ok) {
      out.fatal = out.fatal.concat(cfg.fatal || []);
      out.ok = false;
      return out;
    }
    var master = erpFieldB06J41_37_40_openMaster_(cfg);
    if (!master.ss) {
      out.fatal.push('FEELHAUS_DB_MASTER 연결 실패');
      out.ok = false;
      return out;
    }
    var signSheetCheck = erpFieldB06J41_37_40_findSheet_(master.ss, FIELD_B06J41_37_40_SIGN_CANDIDATES, ['documentId','eventId','vendorId','customerId','saleId','contractId','status','signStatus','pdfStatus','signUrl','qrUrl','signedAt','signedBy']);
    if (!signSheetCheck.exists || !signSheetCheck.sheet) {
      out.fatal.push('SIGN_Documents 시트 없음');
      out.ok = false;
      return out;
    }
    var sheet = signSheetCheck.sheet;
    out.targetSheet = signSheetCheck.sheetName || sheet.getName();
    var headerMap = signSheetCheck.headerMap || {};
    var lastCol = sheet.getLastColumn();
    out.lastColBefore = lastCol;
    var toAdd = [];
    FIELD_B06J41_76_80_SIGNATURE_HEADERS.forEach(function (h) {
      if (headerMap[h]) {
        out.alreadyExists.push(h);
      } else if ((plannedHeaders || []).indexOf(h) >= 0 || (plannedHeaders || []).length === 0) {
        toAdd.push(h);
      }
    });
    out.plannedHeaders = toAdd;
    if (!executeFix) {
      out.warnings.push('미리보기 모드: 헤더를 실제 추가하지 않음');
      return out;
    }
    if (!toAdd.length) {
      out.message = '추가할 서명 저장 확장 헤더 없음';
      out.lastColAfter = lastCol;
      return out;
    }
    sheet.getRange(1, lastCol + 1, 1, toAdd.length).setValues([toAdd]);
    SpreadsheetApp.flush();
    out.addedHeaders = toAdd;
    out.lastColAfter = lastCol + toAdd.length;
    out.message = 'SIGN_Documents 서명 저장 확장 헤더 보정 완료';
  } catch (err) {
    out.fatal.push('헤더 보정 실패: ' + (err && err.message ? err.message : err));
    out.ok = false;
  }
  return out;
}

function erpFieldB06J41_76_80_compactDryRun_(run) {
  run = run || {};
  return {
    ok: !!run.ok,
    fatal: run.fatal || [],
    warnings: run.warnings || [],
    signatureSaveSchemaDryRunReady: !!run.signatureSaveSchemaDryRunReady,
    signatureSchemaChecked: !!run.signatureSchemaChecked,
    signatureDryRunReady: !!run.signatureDryRunReady,
    missingStorageHeaderGroups: run.checks && run.checks.schema ? (run.checks.schema.missingStorageHeaderGroups || []) : [],
    addHeaderPlan: run.checks && run.checks.schema ? (run.checks.schema.addHeaderPlan || []) : [],
    noWrite: !!run.noWrite,
    noRowCreation: !!run.noRowCreation,
    build: run.build || ''
  };
}

function erpFieldB06J41_76_80_urls_(ctx) {
  var base = '';
  try {
    var cfg = erpFieldB06J41_37_40_loadConfig_();
    base = String((cfg.configMap || {}).ERP_FIELD_WEBAPP_URL || '').trim();
  } catch (ignore) {}
  var q = 'roleCode=' + encodeURIComponent(ctx.roleCode) + '&vendorId=' + encodeURIComponent(ctx.vendorId) + '&eventId=' + encodeURIComponent(ctx.eventId) + '&saleId=' + encodeURIComponent(ctx.saleId || '') + '&contractId=' + encodeURIComponent(ctx.contractId || '') + '&customerId=' + encodeURIComponent(ctx.customerId || '') + '&documentId=' + encodeURIComponent(ctx.documentId || '');
  return {
    schemaFixPreview: base ? base + '?' + q + '&route=signatureSchemaFix' : '',
    schemaFixExecute: base ? base + '?' + q + '&route=signatureSchemaFix&confirmFix=1' : '',
    signatureSaveDryRun: base ? base + '?' + q + '&route=signatureSaveDryRun' : '',
    signatureSavePrecheck: base ? base + '?' + q + '&route=signatureSavePrecheck' : ''
  };
}

function erpFieldB06J41_76_80_finish_(result, logOutput) {
  Object.keys(result.checks || {}).forEach(function (k) {
    var c = result.checks[k];
    if (c && c.fatal && c.fatal.length) result.fatal = result.fatal.concat(c.fatal.map(function (m) { return k + ': ' + m; }));
    if (c && c.warnings && c.warnings.length) result.warnings = result.warnings.concat(c.warnings.map(function (m) { return k + ': ' + m; }));
  });
  if (result.headerFix && result.headerFix.fatal && result.headerFix.fatal.length) result.fatal = result.fatal.concat(result.headerFix.fatal.map(function (m) { return 'headerFix: ' + m; }));
  if (result.headerFix && result.headerFix.warnings && result.headerFix.warnings.length) result.warnings = result.warnings.concat(result.headerFix.warnings.map(function (m) { return 'headerFix: ' + m; }));
  result.ok = result.fatal.length === 0;
  result.signatureSaveSchemaFixReady = result.ok && !!(result.schemaAfter && !(result.schemaAfter.missingStorageHeaderGroups || []).length);
  result.headerAppendOnly = true;
  result.noSignInputSave = true;
  result.noSignComplete = true;
  result.noPdf = true;
  result.noDriveSave = true;
  result.noSettlement = true;
  result.noExternalIntegration = true;
  result.noStatusChange = true;
  result.noRowCreation = true;
  result.message = result.ok ? 'SIGN 서명 저장 확장 헤더 보정 정상' : 'SIGN 서명 저장 확장 헤더 보정 오류';
  if (logOutput) {
    Logger.log('======================================================');
    Logger.log('[' + FIELD_B06J41_76_80_BUILD + '] RESULT');
    Logger.log(JSON.stringify(result, null, 2));
    Logger.log('======================================================');
  }
  return result;
}

function erpFieldB06J41_76_80_result_(label) {
  return { ok: true, label: label, build: FIELD_B06J41_76_80_BUILD, moduleCode: 'ERP_FIELD', checkedAt: new Date().toISOString(), fatal: [], warnings: [], checks: {}, document: {}, contract: {}, sale: {}, schemaBefore: {}, schemaAfter: {}, headerFix: {} };
}

function erpFieldB06J41_76_80_normalize_(ctx) {
  if (typeof erpFieldB06J41_71_75_normalize_ === 'function') {
    ctx = erpFieldB06J41_71_75_normalize_(ctx || {});
  } else if (typeof erpFieldB06J40_04_12_normalizeContext_ === 'function') {
    ctx = erpFieldB06J40_04_12_normalizeContext_(ctx || {});
  }
  ctx.route = String((arguments[0] || {}).route || ctx.route || 'signatureSchemaFix').trim();
  ctx.roleCode = ctx.roleCode || FIELD_B06J41_76_80_DEFAULT_CTX.roleCode;
  ctx.vendorId = ctx.vendorId || FIELD_B06J41_76_80_DEFAULT_CTX.vendorId;
  ctx.eventId = ctx.eventId || FIELD_B06J41_76_80_DEFAULT_CTX.eventId;
  ctx.customerId = ctx.customerId || FIELD_B06J41_76_80_DEFAULT_CTX.customerId;
  ctx.saleId = ctx.saleId || FIELD_B06J41_76_80_DEFAULT_CTX.saleId;
  ctx.contractId = ctx.contractId || FIELD_B06J41_76_80_DEFAULT_CTX.contractId;
  ctx.documentId = ctx.documentId || FIELD_B06J41_76_80_DEFAULT_CTX.documentId;
  return ctx;
}

function erpFieldB06J41_76_80_cloneCtxForDryRun_(ctx) {
  var out = erpFieldB06J41_76_80_copy_(ctx || {});
  out.route = 'signatureSaveDryRun';
  return out;
}

function erpFieldB06J41_76_80_copy_(obj) {
  var out = {};
  obj = obj || {};
  Object.keys(obj).forEach(function (k) { out[k] = obj[k]; });
  return out;
}


/* ===== SigSchemaChk.js ===== */
/**
 * build: ERP_B06J41_76_80_SIGNATURE_SAVE_SCHEMA_FIX_SAFE_UPLOAD
 * self test entry
 */
function erpB06J41_76_80_signatureSaveSchemaFixSelfTest() {
  return erpB06J41_76_80_signatureSaveSchemaFixSafe();
}


/* ===== SigPre.js ===== */
/**
 * build: ERP_B06J41_66_70_SIGNATURE_SAVE_PRECHECK_SAFE_UPLOAD
 * module: ERP_FIELD
 * purpose:
 * - SIGN 서명 데이터 저장 전 프리체크
 * - B06J41-61~65 서명 패드 활성화 미리보기 정상 결과를 기준으로 저장 후보 조건만 확인
 * - 브라우저 로컬 서명 데이터 생성 여부를 화면에서 확인하되 서버 저장은 계속 차단
 * safety:
 * - PRECHECK only
 * - no sign input save / no sign complete / no PDF / no Drive / no settlement / no external integration
 * - no server write / no update / no delete / no row creation
 * - SystemConfig standard header: CONFIG_KEY / VALUE first
 */

var FIELD_B06J41_66_70_BUILD = 'ERP_B06J41_66_70_SIGNATURE_SAVE_PRECHECK_SAFE_UPLOAD';
var FIELD_B06J41_66_70_DEFAULT_CTX = {
  roleCode: 'VENDOR_MANAGER',
  vendorId: 'VND-20260502202158-505',
  eventId: 'EVT-20260502202016-197',
  customerId: 'CUS-20260504002306-615',
  saleId: 'SALE-20260504005028-991',
  contractId: 'CON-20260504021423-908',
  documentId: 'DOC-20260504175000-946',
  route: 'signatureSavePrecheck'
};

function erpB06J41_66_70_preflight() {
  return erpFieldB06J41_66_70_run_(FIELD_B06J41_66_70_DEFAULT_CTX, true);
}

function erpB06J41_66_70_autoRunSafe() {
  return erpFieldB06J41_66_70_run_(FIELD_B06J41_66_70_DEFAULT_CTX, true);
}

function erpFieldB06J41_66_70_renderSignatureSavePrecheckHtml(ctx) {
  var vm = erpFieldB06J41_66_70_buildVm_(ctx || {});
  var t = HtmlService.createTemplateFromFile('P_SigPre');
  t.vm = vm;
  t.json = JSON.stringify(vm, null, 2);
  return t.evaluate().setTitle('SIGN 서명 저장 전 프리체크').setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL);
}

function erpFieldB06J41_66_70_buildVm_(ctx) {
  ctx = erpFieldB06J41_66_70_normalize_(ctx || {});
  var result = erpFieldB06J41_66_70_run_(ctx, false);
  result.context = ctx;
  result.page = {
    badge: 'B06J41-66_70 SAFE : SIGNATURE SAVE PRECHECK',
    title: 'SIGN 서명 저장 전 프리체크',
    subtitle: '서명 이미지 데이터 생성 여부와 저장 후보 조건만 확인합니다. 실제 저장·서명완료·PDF·Drive·정산은 계속 차단합니다.',
    roleName: erpFieldB06J41_37_40_roleName_(ctx.roleCode)
  };
  result.urls = erpFieldB06J41_66_70_urls_(ctx, result);
  return result;
}

function erpFieldB06J41_66_70_run_(ctx, logOutput) {
  ctx = erpFieldB06J41_66_70_normalize_(ctx || {});
  var result = erpFieldB06J41_66_70_result_('signatureSavePrecheck');
  result.contextSummary = {
    eventId: ctx.eventId,
    vendorId: ctx.vendorId,
    customerId: ctx.customerId,
    saleId: ctx.saleId,
    contractId: ctx.contractId,
    documentId: ctx.documentId
  };
  try {
    if (typeof erpFieldB06J41_61_65_run_ !== 'function') {
      result.fatal.push('B06J41-61~65 서명 패드 미리보기 엔진 누락: FieldSignaturePadPreview.js 필요');
      return erpFieldB06J41_66_70_finish_(result, logOutput);
    }
    var base = erpFieldB06J41_61_65_run_(ctx, false);
    result.checks.signaturePadPreviewBase = erpFieldB06J41_66_70_compactPadPreview_(base);
    result.checks.safety = erpFieldB06J41_66_70_safety_();
    result.document = erpFieldB06J41_66_70_copy_(base.document || {});
    result.contract = erpFieldB06J41_66_70_copy_(base.contract || {});
    result.sale = erpFieldB06J41_66_70_copy_(base.sale || {});
    result.stored = erpFieldB06J41_66_70_copy_(base.stored || {});
    result.savePrecheck = erpFieldB06J41_66_70_savePrecheck_(base);

    if (!base.ok) result.fatal = result.fatal.concat((base.fatal || []).map(function (m) { return 'signaturePadPreviewBase: ' + m; }));
    if ((base.warnings || []).length) result.warnings = result.warnings.concat((base.warnings || []).map(function (m) { return 'signaturePadPreviewBase: ' + m; }));
    if (result.savePrecheck && result.savePrecheck.fatal && result.savePrecheck.fatal.length) result.fatal = result.fatal.concat(result.savePrecheck.fatal.map(function (m) { return 'savePrecheck: ' + m; }));
  } catch (err) {
    result.fatal.push('B06J41-66~70 signature save precheck fatal: ' + (err && err.message ? err.message : err));
  }
  return erpFieldB06J41_66_70_finish_(result, logOutput);
}

function erpFieldB06J41_66_70_savePrecheck_(base) {
  base = base || {};
  var fatal = [];
  var d = base.document || {};
  var c = base.contract || {};
  var s = base.sale || {};
  var stored = base.stored || {};
  var pad = base.padPreview || {};

  if (!base.signaturePadActivePreviewReady) fatal.push('서명 패드 활성화 미리보기 기준 미통과');
  if (!pad.signaturePadVisible) fatal.push('서명 패드 표시 조건 부족');
  if (!pad.signaturePadActive) fatal.push('서명 패드 활성 조건 부족');
  if (!d.found) fatal.push('SIGN_Documents 문서 없음');
  if (!c.found) fatal.push('연결 Contracts 없음');
  if (!s.found) fatal.push('연결 Sales 없음');
  if (String(d.signStatus || '') !== 'SIGN_URL_READY') fatal.push('문서 signStatus가 SIGN_URL_READY가 아님');
  if (String(c.signStatus || '') !== 'SIGN_URL_READY') fatal.push('계약 signStatus가 SIGN_URL_READY가 아님');
  if (String(d.pdfStatus || 'NOT_CREATED') !== 'NOT_CREATED') fatal.push('PDF 상태가 NOT_CREATED가 아님');
  if (!String(stored.documentSignUrl || '').trim()) fatal.push('저장된 signUrl 없음');
  if (!String(stored.documentQrUrl || '').trim()) fatal.push('저장된 qrUrl 없음');

  return {
    ready: fatal.length === 0,
    fatal: fatal,
    mode: 'SAVE_PRECHECK_ONLY',
    requiredDocumentInfoOk: !!d.found,
    requiredContractInfoOk: !!c.found,
    requiredSaleInfoOk: !!s.found,
    requiredStatusOk: String(d.signStatus || '') === 'SIGN_URL_READY' && String(c.signStatus || '') === 'SIGN_URL_READY',
    requiredPdfNotCreatedOk: String(d.pdfStatus || 'NOT_CREATED') === 'NOT_CREATED',
    requiredUrlOk: !!String(stored.documentSignUrl || '').trim() && !!String(stored.documentQrUrl || '').trim(),
    signaturePadVisible: !!pad.signaturePadVisible,
    signaturePadActive: !!pad.signaturePadActive,
    signatureDataCandidateRequired: true,
    signatureDataGeneratedOnClientOnly: true,
    clientDataUrlCheckOnly: true,
    minInkCheckPreviewOnly: true,
    saveCandidateVisible: true,
    saveButtonBlocked: true,
    completeButtonBlocked: true,
    serverSaveBlocked: true,
    signCompleteBlocked: true,
    pdfStillBlocked: true,
    driveSaveBlocked: true,
    settlementStillBlocked: true,
    externalIntegrationStillBlocked: true,
    writeBlocked: true,
    rowCreationBlocked: true,
    message: fatal.length ? '서명 저장 후보 기준 미충족' : '서명 저장 전 프리체크 가능'
  };
}

function erpFieldB06J41_66_70_compactPadPreview_(base) {
  base = base || {};
  return {
    ok: !!base.ok,
    fatal: base.fatal || [],
    warnings: base.warnings || [],
    documentFound: !!(base.document && base.document.found),
    contractFound: !!(base.contract && base.contract.found),
    saleFound: !!(base.sale && base.sale.found),
    signaturePadActivePreviewReady: !!base.signaturePadActivePreviewReady,
    signaturePadVisible: !!base.signaturePadVisible,
    signaturePadActive: !!base.signaturePadActive,
    noSignInputSave: !!base.noSignInputSave,
    noSignComplete: !!base.noSignComplete,
    build: base.build || ''
  };
}

function erpFieldB06J41_66_70_safety_() {
  return {
    precheckOnly: true,
    clientSideSignatureDataCheckOnly: true,
    noGoogleScriptRun: true,
    noServerWrite: true,
    noSignInputSave: true,
    noSignComplete: true,
    noPdfCreate: true,
    noDriveSave: true,
    noSettlementExecution: true,
    noExternalIntegration: true,
    noDelete: true,
    noRowCreation: true,
    noStatusChange: true,
    systemConfigHeaderStandard: 'CONFIG_KEY/VALUE first'
  };
}

function erpFieldB06J41_66_70_urls_(ctx, result) {
  var base = '';
  try {
    var cfg = erpFieldB06J41_37_40_loadConfig_();
    base = String((cfg.configMap || {}).ERP_FIELD_WEBAPP_URL || '').trim();
  } catch (ignore) {}
  var q = 'roleCode=' + encodeURIComponent(ctx.roleCode) + '&vendorId=' + encodeURIComponent(ctx.vendorId) + '&eventId=' + encodeURIComponent(ctx.eventId) + '&saleId=' + encodeURIComponent(ctx.saleId || '') + '&contractId=' + encodeURIComponent(ctx.contractId || '') + '&customerId=' + encodeURIComponent(ctx.customerId || '') + '&documentId=' + encodeURIComponent(ctx.documentId || '');
  return {
    signatureSavePrecheck: base ? base + '?' + q + '&route=signatureSavePrecheck' : '',
    signaturePadPreview: base ? base + '?' + q + '&route=signaturePadPreview' : '',
    signInputPrecheck: base ? base + '?' + q + '&route=signInputPrecheck' : '',
    signEntryReadOnly: base ? base + '?' + q + '&route=signEntry' : '',
    signUrlVerify: base ? base + '?' + q + '&route=signUrlVerify' : '',
    signUrl: String((result.stored && result.stored.documentSignUrl) || '').trim(),
    qrUrl: String((result.stored && result.stored.documentQrUrl) || '').trim()
  };
}

function erpFieldB06J41_66_70_result_(label) {
  return { ok: true, label: label, build: FIELD_B06J41_66_70_BUILD, moduleCode: 'ERP_FIELD', checkedAt: new Date().toISOString(), fatal: [], warnings: [], checks: {}, document: {}, contract: {}, sale: {}, stored: {}, savePrecheck: {} };
}

function erpFieldB06J41_66_70_finish_(result, logOutput) {
  Object.keys(result.checks || {}).forEach(function (k) {
    var c = result.checks[k];
    if (c && c.fatal && c.fatal.length) result.fatal = result.fatal.concat(c.fatal.map(function (m) { return k + ': ' + m; }));
    if (c && c.warnings && c.warnings.length) result.warnings = result.warnings.concat(c.warnings.map(function (m) { return k + ': ' + m; }));
  });
  result.ok = result.fatal.length === 0;
  result.signatureSavePrecheckReady = !!(result.savePrecheck && result.savePrecheck.ready) && result.ok;
  result.signaturePadVisible = !!(result.savePrecheck && result.savePrecheck.signaturePadVisible) && result.ok;
  result.signaturePadActive = !!(result.savePrecheck && result.savePrecheck.signaturePadActive) && result.ok;
  result.signatureDataCandidateCheck = true;
  result.noSignInputSave = true;
  result.noSignComplete = true;
  result.noPdf = true;
  result.noDriveSave = true;
  result.noSettlement = true;
  result.noExternalIntegration = true;
  result.noWrite = true;
  result.noRowCreation = true;
  if (logOutput) {
    Logger.log('======================================================');
    Logger.log('[' + FIELD_B06J41_66_70_BUILD + '] RESULT');
    Logger.log(JSON.stringify(result, null, 2));
    Logger.log('======================================================');
  }
  return result;
}

function erpFieldB06J41_66_70_normalize_(ctx) {
  ctx = erpFieldB06J41_61_65_normalize_(ctx || {});
  ctx.route = String((arguments[0] || {}).route || ctx.route || 'signatureSavePrecheck').trim();
  return ctx;
}

function erpFieldB06J41_66_70_copy_(obj) {
  var out = {};
  obj = obj || {};
  Object.keys(obj).forEach(function (k) { out[k] = obj[k]; });
  return out;
}


/* ===== SigPreChk.js ===== */
/**
 * build: ERP_B06J41_66_70_SIGNATURE_SAVE_PRECHECK_SAFE_UPLOAD
 * purpose: B06J41-66~70 signature save precheck self test
 */

function erpB06J41_66_70_signatureSavePrecheckSelfTest() {
  var ctx = {
    roleCode: 'VENDOR_MANAGER',
    vendorId: 'VND-20260502202158-505',
    eventId: 'EVT-20260502202016-197',
    customerId: 'CUS-20260504002306-615',
    saleId: 'SALE-20260504005028-991',
    contractId: 'CON-20260504021423-908',
    documentId: 'DOC-20260504175000-946',
    route: 'signatureSavePrecheck'
  };
  var result = erpFieldB06J41_66_70_run_(ctx, false);
  var out = {
    ok: result.ok,
    build: FIELD_B06J41_66_70_BUILD,
    routeSignatureSavePrecheck: 'signatureSavePrecheck',
    routeAlias: ['signSavePrecheck', 'signatureDataPrecheck'],
    context: ctx,
    fatal: result.fatal || [],
    warnings: result.warnings || [],
    signatureSavePrecheckReady: !!result.signatureSavePrecheckReady,
    signaturePadVisible: !!result.signaturePadVisible,
    signaturePadActive: !!result.signaturePadActive,
    signatureDataCandidateCheck: true,
    clientDataUrlCheckOnly: true,
    minInkCheckPreviewOnly: true,
    saveCandidateVisible: !!(result.savePrecheck && result.savePrecheck.saveCandidateVisible),
    noGoogleScriptRun: true,
    noSignInputSave: true,
    noSignComplete: true,
    noPdf: true,
    noDriveSave: true,
    noSettlement: true,
    noExternalIntegration: true,
    noWrite: true,
    noRowCreation: true,
    message: result.ok ? 'SIGN 서명 저장 전 프리체크 정상' : 'SIGN 서명 저장 전 프리체크 실패'
  };
  Logger.log('======================================================');
  Logger.log('[' + FIELD_B06J41_66_70_BUILD + '] RESULT');
  Logger.log(JSON.stringify(out, null, 2));
  Logger.log('======================================================');
  return out;
}


/* ===== SigPad.js ===== */
/**
 * build: ERP_B06J41_61_65_SIGNATURE_PAD_ACTIVE_PREVIEW_SAFE_UPLOAD
 * module: ERP_FIELD
 * purpose:
 * - SIGN 서명 패드 활성화 미리보기
 * - B06J41-56~60 서명 입력 UI 프리체크 정상 결과를 기준으로 client-side canvas 서명 입력 UI 표시
 * - 지우기/미리보기만 제공하고 서버 저장, 서명완료, PDF, Drive, 정산, 외부연동은 계속 차단
 * safety:
 * - PREVIEW only
 * - no sign input save / no sign complete / no PDF / no Drive / no settlement / no external integration
 * - no server write / no update / no delete / no row creation
 * - SystemConfig standard header: CONFIG_KEY / VALUE first
 */

var FIELD_B06J41_61_65_BUILD = 'ERP_B06J41_61_65_SIGNATURE_PAD_ACTIVE_PREVIEW_SAFE_UPLOAD';
var FIELD_B06J41_61_65_DEFAULT_CTX = {
  roleCode: 'VENDOR_MANAGER',
  vendorId: 'VND-20260502202158-505',
  eventId: 'EVT-20260502202016-197',
  customerId: 'CUS-20260504002306-615',
  saleId: 'SALE-20260504005028-991',
  contractId: 'CON-20260504021423-908',
  documentId: 'DOC-20260504175000-946',
  route: 'signaturePadPreview'
};

function erpB06J41_61_65_preflight() {
  return erpFieldB06J41_61_65_run_(FIELD_B06J41_61_65_DEFAULT_CTX, true);
}

function erpB06J41_61_65_autoRunSafe() {
  return erpFieldB06J41_61_65_run_(FIELD_B06J41_61_65_DEFAULT_CTX, true);
}

function erpFieldB06J41_61_65_renderSignaturePadPreviewHtml(ctx) {
  var vm = erpFieldB06J41_61_65_buildVm_(ctx || {});
  var t = HtmlService.createTemplateFromFile('P_SigPad');
  t.vm = vm;
  t.json = JSON.stringify(vm, null, 2);
  return t.evaluate().setTitle('SIGN 서명 패드 활성화 미리보기').setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL);
}

function erpFieldB06J41_61_65_buildVm_(ctx) {
  ctx = erpFieldB06J41_61_65_normalize_(ctx || {});
  var result = erpFieldB06J41_61_65_run_(ctx, false);
  result.context = ctx;
  result.page = {
    badge: 'B06J41-61_65 SAFE : SIGNATURE PAD ACTIVE PREVIEW',
    title: 'SIGN 서명 패드 활성화 미리보기',
    subtitle: '마우스/터치 서명 패드 UI를 활성화하여 입력감만 확인합니다. 서버 저장·서명완료·PDF·Drive·정산은 계속 차단합니다.',
    roleName: erpFieldB06J41_37_40_roleName_(ctx.roleCode)
  };
  result.urls = erpFieldB06J41_61_65_urls_(ctx, result);
  return result;
}

function erpFieldB06J41_61_65_run_(ctx, logOutput) {
  ctx = erpFieldB06J41_61_65_normalize_(ctx || {});
  var result = erpFieldB06J41_61_65_result_('signaturePadPreview');
  result.contextSummary = {
    eventId: ctx.eventId,
    vendorId: ctx.vendorId,
    customerId: ctx.customerId,
    saleId: ctx.saleId,
    contractId: ctx.contractId,
    documentId: ctx.documentId
  };
  try {
    if (typeof erpFieldB06J41_56_60_run_ !== 'function') {
      result.fatal.push('B06J41-56~60 서명 입력 UI 프리체크 엔진 누락: FieldSignInputPrecheck.js 필요');
      return erpFieldB06J41_61_65_finish_(result, logOutput);
    }
    var base = erpFieldB06J41_56_60_run_(ctx, false);
    result.checks.inputPrecheckBase = erpFieldB06J41_61_65_compactInputPrecheck_(base);
    result.checks.safety = erpFieldB06J41_61_65_safety_();
    result.document = erpFieldB06J41_61_65_copy_(base.document || {});
    result.contract = erpFieldB06J41_61_65_copy_(base.contract || {});
    result.sale = erpFieldB06J41_61_65_copy_(base.sale || {});
    result.stored = erpFieldB06J41_61_65_copy_(base.stored || {});
    result.padPreview = erpFieldB06J41_61_65_preview_(base);

    if (!base.ok) result.fatal = result.fatal.concat((base.fatal || []).map(function (m) { return 'inputPrecheckBase: ' + m; }));
    if ((base.warnings || []).length) result.warnings = result.warnings.concat((base.warnings || []).map(function (m) { return 'inputPrecheckBase: ' + m; }));
    if (result.padPreview && result.padPreview.fatal && result.padPreview.fatal.length) result.fatal = result.fatal.concat(result.padPreview.fatal.map(function (m) { return 'padPreview: ' + m; }));
  } catch (err) {
    result.fatal.push('B06J41-61~65 signature pad preview fatal: ' + (err && err.message ? err.message : err));
  }
  return erpFieldB06J41_61_65_finish_(result, logOutput);
}

function erpFieldB06J41_61_65_preview_(base) {
  base = base || {};
  var fatal = [];
  var ui = base.uiPrecheck || {};
  var d = base.document || {};
  var c = base.contract || {};
  var stored = base.stored || {};

  if (!base.signInputUiPrecheckReady) fatal.push('서명 입력 UI 프리체크 기준 미통과');
  if (!ui.requiredDocumentInfoOk) fatal.push('문서 필수 정보 부족');
  if (!ui.requiredLinkInfoOk) fatal.push('계약/판매 연결 정보 부족');
  if (!ui.requiredStatusOk) fatal.push('SIGN_URL_READY 상태 조건 미충족');
  if (!ui.requiredUrlOk) fatal.push('SIGN URL / QR URL 저장 상태 부족');
  if (String(d.signStatus || '') !== 'SIGN_URL_READY') fatal.push('문서 signStatus가 SIGN_URL_READY가 아님');
  if (String(c.signStatus || '') !== 'SIGN_URL_READY') fatal.push('계약 signStatus가 SIGN_URL_READY가 아님');
  if (!String(stored.documentSignUrl || '').trim()) fatal.push('저장된 signUrl 없음');
  if (!String(stored.documentQrUrl || '').trim()) fatal.push('저장된 qrUrl 없음');

  return {
    ready: fatal.length === 0,
    fatal: fatal,
    mode: 'ACTIVE_PREVIEW_ONLY',
    signaturePadVisible: true,
    signaturePadActive: fatal.length === 0,
    mouseInputPreview: fatal.length === 0,
    touchInputPreview: fatal.length === 0,
    clearButtonVisible: true,
    localDataUrlPreviewOnly: true,
    noGoogleScriptRun: true,
    saveButtonBlocked: true,
    completeButtonBlocked: true,
    serverSaveBlocked: true,
    signCompleteBlocked: true,
    pdfStillBlocked: true,
    driveSaveBlocked: true,
    settlementStillBlocked: true,
    externalIntegrationStillBlocked: true,
    writeBlocked: true,
    rowCreationBlocked: true,
    message: fatal.length ? '서명 패드 미리보기 기준 미충족' : '서명 패드 활성화 미리보기 가능'
  };
}

function erpFieldB06J41_61_65_compactInputPrecheck_(base) {
  base = base || {};
  return {
    ok: !!base.ok,
    fatal: base.fatal || [],
    warnings: base.warnings || [],
    documentFound: !!(base.document && base.document.found),
    contractFound: !!(base.contract && base.contract.found),
    saleFound: !!(base.sale && base.sale.found),
    signInputUiPrecheckReady: !!base.signInputUiPrecheckReady,
    signaturePadCandidateVisible: !!(base.uiPrecheck && base.uiPrecheck.signaturePadCandidateVisible),
    signaturePadActivePreviousStep: !!(base.uiPrecheck && base.uiPrecheck.signaturePadActive),
    noSignInputSave: !!base.noSignInputSave,
    noSignComplete: !!base.noSignComplete,
    build: base.build || ''
  };
}

function erpFieldB06J41_61_65_safety_() {
  return {
    previewOnly: true,
    clientSideCanvasOnly: true,
    noGoogleScriptRun: true,
    noServerWrite: true,
    noSignInputSave: true,
    noSignComplete: true,
    noPdfCreate: true,
    noDriveSave: true,
    noSettlementExecution: true,
    noExternalIntegration: true,
    noDelete: true,
    noRowCreation: true,
    noStatusChange: true,
    systemConfigHeaderStandard: 'CONFIG_KEY/VALUE first'
  };
}

function erpFieldB06J41_61_65_urls_(ctx, result) {
  var base = '';
  try {
    var cfg = erpFieldB06J41_37_40_loadConfig_();
    base = String((cfg.configMap || {}).ERP_FIELD_WEBAPP_URL || '').trim();
  } catch (ignore) {}
  var q = 'roleCode=' + encodeURIComponent(ctx.roleCode) + '&vendorId=' + encodeURIComponent(ctx.vendorId) + '&eventId=' + encodeURIComponent(ctx.eventId) + '&saleId=' + encodeURIComponent(ctx.saleId || '') + '&contractId=' + encodeURIComponent(ctx.contractId || '') + '&customerId=' + encodeURIComponent(ctx.customerId || '') + '&documentId=' + encodeURIComponent(ctx.documentId || '');
  return {
    signaturePadPreview: base ? base + '?' + q + '&route=signaturePadPreview' : '',
    signInputPrecheck: base ? base + '?' + q + '&route=signInputPrecheck' : '',
    signEntryReadOnly: base ? base + '?' + q + '&route=signEntry' : '',
    signUrlVerify: base ? base + '?' + q + '&route=signUrlVerify' : '',
    signUrl: String((result.stored && result.stored.documentSignUrl) || '').trim(),
    qrUrl: String((result.stored && result.stored.documentQrUrl) || '').trim()
  };
}

function erpFieldB06J41_61_65_result_(label) {
  return { ok: true, label: label, build: FIELD_B06J41_61_65_BUILD, moduleCode: 'ERP_FIELD', checkedAt: new Date().toISOString(), fatal: [], warnings: [], checks: {}, document: {}, contract: {}, sale: {}, stored: {}, padPreview: {} };
}

function erpFieldB06J41_61_65_finish_(result, logOutput) {
  Object.keys(result.checks || {}).forEach(function (k) {
    var c = result.checks[k];
    if (c && c.fatal && c.fatal.length) result.fatal = result.fatal.concat(c.fatal.map(function (m) { return k + ': ' + m; }));
    if (c && c.warnings && c.warnings.length) result.warnings = result.warnings.concat(c.warnings.map(function (m) { return k + ': ' + m; }));
  });
  result.ok = result.fatal.length === 0;
  result.signaturePadActivePreviewReady = !!(result.padPreview && result.padPreview.ready) && result.ok;
  result.signaturePadVisible = true;
  result.signaturePadActive = !!(result.padPreview && result.padPreview.signaturePadActive) && result.ok;
  result.noSignInputSave = true;
  result.noSignComplete = true;
  result.noPdf = true;
  result.noDriveSave = true;
  result.noSettlement = true;
  result.noExternalIntegration = true;
  result.noWrite = true;
  result.noRowCreation = true;
  if (logOutput) {
    Logger.log('======================================================');
    Logger.log('[' + FIELD_B06J41_61_65_BUILD + '] RESULT');
    Logger.log(JSON.stringify(result, null, 2));
    Logger.log('======================================================');
  }
  return result;
}

function erpFieldB06J41_61_65_normalize_(ctx) {
  ctx = erpFieldB06J41_56_60_normalize_(ctx || {});
  ctx.route = String((arguments[0] || {}).route || ctx.route || 'signaturePadPreview').trim();
  return ctx;
}

function erpFieldB06J41_61_65_copy_(obj) {
  var out = {};
  obj = obj || {};
  Object.keys(obj).forEach(function (k) { out[k] = obj[k]; });
  return out;
}


/* ===== SigPadChk.js ===== */
/**
 * build: ERP_B06J41_61_65_SIGNATURE_PAD_ACTIVE_PREVIEW_SAFE_UPLOAD
 * purpose: B06J41-61~65 signature pad active preview self test
 */

function erpB06J41_61_65_signaturePadActivePreviewSelfTest() {
  var ctx = {
    roleCode: 'VENDOR_MANAGER',
    vendorId: 'VND-20260502202158-505',
    eventId: 'EVT-20260502202016-197',
    customerId: 'CUS-20260504002306-615',
    saleId: 'SALE-20260504005028-991',
    contractId: 'CON-20260504021423-908',
    documentId: 'DOC-20260504175000-946',
    route: 'signaturePadPreview'
  };
  var result = erpFieldB06J41_61_65_run_(ctx, false);
  var out = {
    ok: result.ok,
    build: FIELD_B06J41_61_65_BUILD,
    routeSignaturePadPreview: 'signaturePadPreview',
    routeAlias: ['signPadPreview', 'signaturePadActivePreview'],
    context: ctx,
    fatal: result.fatal || [],
    warnings: result.warnings || [],
    signaturePadActivePreviewReady: !!result.signaturePadActivePreviewReady,
    signaturePadVisible: !!result.signaturePadVisible,
    signaturePadActive: !!result.signaturePadActive,
    mouseInputPreview: !!(result.padPreview && result.padPreview.mouseInputPreview),
    touchInputPreview: !!(result.padPreview && result.padPreview.touchInputPreview),
    clearButtonVisible: !!(result.padPreview && result.padPreview.clearButtonVisible),
    localDataUrlPreviewOnly: true,
    noGoogleScriptRun: true,
    noSignInputSave: true,
    noSignComplete: true,
    noPdf: true,
    noDriveSave: true,
    noSettlement: true,
    noExternalIntegration: true,
    noWrite: true,
    noRowCreation: true,
    message: result.ok ? 'SIGN 서명 패드 활성화 미리보기 정상' : 'SIGN 서명 패드 활성화 미리보기 실패'
  };
  Logger.log('======================================================');
  Logger.log('[' + FIELD_B06J41_61_65_BUILD + '] RESULT');
  Logger.log(JSON.stringify(out, null, 2));
  Logger.log('======================================================');
  return out;
}


/* ===== SigConfirm.js ===== */
/**
 * build: ERP_B06J41_86_90_SIGNATURE_SAVE_CONFIRM_PREP_SAFE_UPLOAD
 * module: ERP_FIELD
 * purpose:
 * - 실제 서명 저장 직전 확인 화면
 * - 저장 대상 SIGN_Documents row / documentId 재확인
 * - 저장 예정 컬럼값 최종 미리보기
 * - 중복 저장 차단 조건 표시
 * safety:
 * - CONFIRM PREP only
 * - no sign input save / no sign complete / no PDF / no Drive / no settlement / no external integration
 * - no server write / no status change / no update / no delete / no row creation / no header append
 * - SystemConfig standard header: CONFIG_KEY / VALUE first
 */

var FIELD_B06J41_86_90_BUILD = 'ERP_B06J41_86_90_SIGNATURE_SAVE_CONFIRM_PREP_SAFE_UPLOAD';
var FIELD_B06J41_86_90_DEFAULT_CTX = {
  roleCode: 'VENDOR_MANAGER',
  vendorId: 'VND-20260502202158-505',
  eventId: 'EVT-20260502202016-197',
  customerId: 'CUS-20260504002306-615',
  saleId: 'SALE-20260504005028-991',
  contractId: 'CON-20260504021423-908',
  documentId: 'DOC-20260504175000-946',
  route: 'signatureSaveConfirmPrep'
};

function erpB06J41_86_90_preflight() {
  return erpFieldB06J41_86_90_run_(FIELD_B06J41_86_90_DEFAULT_CTX, true);
}

function erpB06J41_86_90_autoRunSafe() {
  return erpFieldB06J41_86_90_run_(FIELD_B06J41_86_90_DEFAULT_CTX, true);
}

function erpFieldB06J41_86_90_renderSignatureSaveConfirmPrepHtml(ctx) {
  var vm = erpFieldB06J41_86_90_buildVm_(ctx || {});
  var t = HtmlService.createTemplateFromFile('P_SigConfirm');
  t.vm = vm;
  t.json = JSON.stringify(vm, null, 2);
  return t.evaluate().setTitle('SIGN 서명 저장 직전 확인').setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL);
}

function erpFieldB06J41_86_90_buildVm_(ctx) {
  ctx = erpFieldB06J41_86_90_normalize_(ctx || {});
  var result = erpFieldB06J41_86_90_run_(ctx, false);
  result.context = ctx;
  result.page = {
    badge: 'B06J41-86_90 SAFE : SIGNATURE SAVE CONFIRM PREP',
    title: 'SIGN 서명 저장 직전 확인',
    subtitle: '실제 저장을 열기 전 대상 row, documentId, 저장 예정 컬럼, 중복 저장 차단 조건만 최종 확인합니다. 아직 서버 저장은 실행하지 않습니다.',
    roleName: (typeof erpFieldB06J41_37_40_roleName_ === 'function') ? erpFieldB06J41_37_40_roleName_(ctx.roleCode) : ctx.roleCode
  };
  result.urls = erpFieldB06J41_86_90_urls_(ctx);
  return result;
}

function erpFieldB06J41_86_90_run_(ctx, logOutput) {
  ctx = erpFieldB06J41_86_90_normalize_(ctx || {});
  var result = erpFieldB06J41_86_90_result_('signatureSaveConfirmPrep');
  result.contextSummary = {
    eventId: ctx.eventId,
    vendorId: ctx.vendorId,
    customerId: ctx.customerId,
    saleId: ctx.saleId,
    contractId: ctx.contractId,
    documentId: ctx.documentId
  };

  try {
    if (typeof erpFieldB06J41_81_85_run_ !== 'function') {
      result.fatal.push('B06J41-81~85 DryRun after schema 엔진 누락: FieldSignatureSaveDryRunAfterSchema.js 필요');
      return erpFieldB06J41_86_90_finish_(result, logOutput);
    }

    var dry = erpFieldB06J41_81_85_run_(ctx, false);
    result.checks.baseDryRunAfterSchema = erpFieldB06J41_86_90_compactDryRun_(dry);
    result.document = erpFieldB06J41_86_90_copy_(dry.document || {});
    result.contract = erpFieldB06J41_86_90_copy_(dry.contract || {});
    result.sale = erpFieldB06J41_86_90_copy_(dry.sale || {});
    result.stored = erpFieldB06J41_86_90_copy_(dry.stored || {});
    result.schema = erpFieldB06J41_86_90_copy_(dry.schema || {});
    result.headerResolution = erpFieldB06J41_86_90_copy_(dry.headerResolution || {});
    result.plannedWriteMapping = erpFieldB06J41_86_90_copy_(dry.plannedWriteMapping || {});
    result.confirmPrep = erpFieldB06J41_86_90_confirmPrep_(ctx, result.document, result.contract, result.sale, result.plannedWriteMapping, result.headerResolution);
    result.duplicateGuard = erpFieldB06J41_86_90_duplicateGuard_(result.document);
    result.checks.safety = erpFieldB06J41_86_90_safety_();

    if (!dry.ok) result.fatal = result.fatal.concat((dry.fatal || []).map(function (m) { return 'baseDryRunAfterSchema: ' + m; }));
    if (!result.document.found || String(result.document.documentId || '') !== String(ctx.documentId || '')) result.fatal.push('저장 대상 documentId 확인 실패');
    if (!result.confirmPrep.targetReady) result.fatal.push('서명 저장 직전 대상 준비 실패');
    if (!result.confirmPrep.writeMappingReady) result.fatal.push('서명 저장 예정 컬럼 매핑 미완료');
    if (result.duplicateGuard.alreadySignatureSaved) result.fatal.push('중복 저장 차단: 이미 signaturePath 또는 signatureFileId 값 존재');
  } catch (err) {
    result.fatal.push('B06J41-86~90 signature save confirm prep fatal: ' + (err && err.message ? err.message : err));
  }

  return erpFieldB06J41_86_90_finish_(result, logOutput);
}

function erpFieldB06J41_86_90_confirmPrep_(ctx, doc, contract, sale, mapping, headerResolution) {
  doc = doc || {};
  contract = contract || {};
  sale = sale || {};
  mapping = mapping || {};
  headerResolution = headerResolution || {};
  var planned = mapping.plannedWriteValues || {};
  var mapped = mapping.mappedHeaders || {};
  var targetRow = mapping.targetRow || doc.row || '';
  var targetSheet = mapping.targetSheet || 'SIGN_Documents';
  return {
    mode: 'CONFIRM_PREP_ONLY',
    targetReady: !!(targetSheet && targetRow && doc.documentId && contract.contractId && sale.saleId),
    targetSheet: targetSheet,
    targetRow: targetRow,
    targetDocumentId: doc.documentId || ctx.documentId,
    expectedDocumentId: ctx.documentId,
    documentIdMatched: String(doc.documentId || '') === String(ctx.documentId || ''),
    writeMappingReady: !!(headerResolution.schemaFixed && mapped.signaturePath && mapped.signatureFileId && mapped.signatureDataHash && mapped.signatureSavedAt && mapped.signatureSavedBy),
    mappedHeaders: mapped,
    plannedWriteValues: {
      signaturePath: planned.signaturePath || 'SIGNATURE_IMAGE_PATH_CANDIDATE_NOT_SAVED',
      signatureFileId: planned.signatureFileId || 'SIGNATURE_FILE_ID_CANDIDATE_NOT_SAVED',
      signatureDataHash: planned.signatureDataHash || 'SIGNATURE_HASH_CANDIDATE_NOT_SAVED',
      signatureSavedAt: planned.signatureSavedAt || 'CONFIRM_PREP_ONLY_NOT_APPLIED',
      signatureSavedBy: planned.signatureSavedBy || ctx.userEmail || 'FIELD_USER',
      signedAt: planned.signedAt || 'CONFIRM_PREP_ONLY_NOT_APPLIED',
      signedBy: planned.signedBy || ctx.userEmail || 'FIELD_USER',
      signStatus: 'SIGN_SAVED_CANDIDATE_NOT_APPLIED'
    },
    confirmButtonVisible: true,
    confirmButtonDisabled: true,
    actualSaveRouteNext: 'signatureSaveExecute',
    actualSaveStillBlockedThisBuild: true
  };
}

function erpFieldB06J41_86_90_duplicateGuard_(doc) {
  doc = doc || {};
  var signaturePath = String(doc.signaturePath || '').trim();
  var signatureFileId = String(doc.signatureFileId || '').trim();
  var signatureDataHash = String(doc.signatureDataHash || '').trim();
  var signedAt = String(doc.signedAt || '').trim();
  var signedBy = String(doc.signedBy || '').trim();
  return {
    checks: ['documentId unique row', 'signaturePath empty', 'signatureFileId empty', 'signatureDataHash empty', 'signedAt empty', 'signedBy empty', 'signStatus not completed'],
    alreadySignatureSaved: !!(signaturePath || signatureFileId || signatureDataHash || signedAt || signedBy),
    signaturePathEmpty: !signaturePath,
    signatureFileIdEmpty: !signatureFileId,
    signatureDataHashEmpty: !signatureDataHash,
    signedAtEmpty: !signedAt,
    signedByEmpty: !signedBy,
    statusAllowsSaveCandidate: String(doc.signStatus || '') === 'SIGN_URL_READY',
    duplicateSaveBlocked: true,
    reSaveRequiresApprovalFuture: true
  };
}

function erpFieldB06J41_86_90_compactDryRun_(dry) {
  dry = dry || {};
  return {
    ok: !!dry.ok,
    fatal: dry.fatal || [],
    warnings: dry.warnings || [],
    signatureSaveDryRunAfterSchemaReady: !!dry.signatureSaveDryRunAfterSchemaReady,
    signatureStorageHeadersResolved: !!dry.signatureStorageHeadersResolved,
    signatureWriteMappingReady: !!dry.signatureWriteMappingReady,
    noWrite: !!dry.noWrite,
    noRowCreation: !!dry.noRowCreation,
    build: dry.build || ''
  };
}

function erpFieldB06J41_86_90_safety_() {
  return {
    confirmPrepOnly: true,
    noGoogleScriptRun: true,
    noServerWrite: true,
    noSignInputSave: true,
    noSignComplete: true,
    noPdfCreate: true,
    noDriveSave: true,
    noSettlementExecution: true,
    noExternalIntegration: true,
    noDelete: true,
    noRowCreation: true,
    noStatusChange: true,
    noHeaderAppend: true,
    systemConfigHeaderStandard: 'CONFIG_KEY/VALUE first'
  };
}

function erpFieldB06J41_86_90_urls_(ctx) {
  var base = '';
  try {
    var cfg = erpFieldB06J41_37_40_loadConfig_();
    base = String((cfg.configMap || {}).ERP_FIELD_WEBAPP_URL || '').trim();
  } catch (ignore) {}
  var q = 'roleCode=' + encodeURIComponent(ctx.roleCode) + '&vendorId=' + encodeURIComponent(ctx.vendorId) + '&eventId=' + encodeURIComponent(ctx.eventId) + '&saleId=' + encodeURIComponent(ctx.saleId || '') + '&contractId=' + encodeURIComponent(ctx.contractId || '') + '&customerId=' + encodeURIComponent(ctx.customerId || '') + '&documentId=' + encodeURIComponent(ctx.documentId || '');
  return {
    signatureSaveConfirmPrep: base ? base + '?' + q + '&route=signatureSaveConfirmPrep' : '',
    signatureDryRunAfterSchema: base ? base + '?' + q + '&route=signatureDryRunAfterSchema' : '',
    signatureSavePrecheck: base ? base + '?' + q + '&route=signatureSavePrecheck' : '',
    signEntry: base ? base + '?' + q + '&route=signEntry' : ''
  };
}

function erpFieldB06J41_86_90_result_(label) {
  return { ok: true, label: label, build: FIELD_B06J41_86_90_BUILD, moduleCode: 'ERP_FIELD', checkedAt: new Date().toISOString(), fatal: [], warnings: [], checks: {}, document: {}, contract: {}, sale: {}, stored: {}, schema: {}, headerResolution: {}, plannedWriteMapping: {}, confirmPrep: {}, duplicateGuard: {} };
}

function erpFieldB06J41_86_90_finish_(result, logOutput) {
  Object.keys(result.checks || {}).forEach(function (k) {
    var c = result.checks[k];
    if (c && c.fatal && c.fatal.length) result.fatal = result.fatal.concat(c.fatal.map(function (m) { return k + ': ' + m; }));
    if (c && c.warnings && c.warnings.length) result.warnings = result.warnings.concat(c.warnings.map(function (m) { return k + ': ' + m; }));
  });
  result.ok = result.fatal.length === 0;
  result.signatureSaveConfirmPrepReady = result.ok && !!(result.confirmPrep && result.confirmPrep.targetReady) && !!(result.confirmPrep && result.confirmPrep.writeMappingReady);
  result.targetRowConfirmed = !!(result.confirmPrep && result.confirmPrep.targetRow);
  result.documentIdConfirmed = !!(result.confirmPrep && result.confirmPrep.documentIdMatched);
  result.writeValuesPreviewReady = !!(result.confirmPrep && result.confirmPrep.writeMappingReady);
  result.duplicateGuardReady = !!(result.duplicateGuard && result.duplicateGuard.duplicateSaveBlocked);
  result.noGoogleScriptRun = true;
  result.noSignInputSave = true;
  result.noSignComplete = true;
  result.noPdf = true;
  result.noDriveSave = true;
  result.noSettlement = true;
  result.noExternalIntegration = true;
  result.noWrite = true;
  result.noRowCreation = true;
  result.noHeaderAppend = true;
  if (logOutput) {
    Logger.log('======================================================');
    Logger.log('[' + FIELD_B06J41_86_90_BUILD + '] RESULT');
    Logger.log(JSON.stringify(result, null, 2));
    Logger.log('======================================================');
  }
  return result;
}

function erpFieldB06J41_86_90_normalize_(ctx) {
  if (typeof erpFieldB06J41_81_85_normalize_ === 'function') {
    ctx = erpFieldB06J41_81_85_normalize_(ctx || {});
  } else if (typeof erpFieldB06J41_71_75_normalize_ === 'function') {
    ctx = erpFieldB06J41_71_75_normalize_(ctx || {});
  } else {
    ctx = ctx || {};
  }
  ctx.route = String((arguments[0] || {}).route || ctx.route || 'signatureSaveConfirmPrep').trim();
  return ctx;
}

function erpFieldB06J41_86_90_copy_(obj) {
  var out = {};
  obj = obj || {};
  Object.keys(obj).forEach(function (k) { out[k] = obj[k]; });
  return out;
}


/* ===== SigConfirmChk.js ===== */
/**
 * build: ERP_B06J41_86_90_SIGNATURE_SAVE_CONFIRM_PREP_SAFE_UPLOAD
 * self test entry
 */
function erpB06J41_86_90_signatureSaveConfirmPrepSelfTest() {
  return erpB06J41_86_90_autoRunSafe();
}


/* ===== SigDrySchema.js ===== */
/**
 * build: ERP_B06J41_81_85_SIGNATURE_SAVE_DRYRUN_AFTER_SCHEMA_SAFE_UPLOAD
 * module: ERP_FIELD
 * purpose:
 * - B06J41-76~80에서 보정된 SIGN_Documents 서명 저장 확장 헤더 재인식
 * - signaturePath/signatureFileId/signatureDataHash/signatureSavedAt/signatureSavedBy 매핑 확인
 * - 서명 저장 후보값 DryRun 재검증
 * safety:
 * - DRYRUN only
 * - no sign input save / no sign complete / no PDF / no Drive / no settlement / no external integration
 * - no server write / no update / no delete / no row creation / no header append
 * - SystemConfig standard header: CONFIG_KEY / VALUE first
 */

var FIELD_B06J41_81_85_BUILD = 'ERP_B06J41_81_85_SIGNATURE_SAVE_DRYRUN_AFTER_SCHEMA_SAFE_UPLOAD';
var FIELD_B06J41_81_85_DEFAULT_CTX = {
  roleCode: 'VENDOR_MANAGER',
  vendorId: 'VND-20260502202158-505',
  eventId: 'EVT-20260502202016-197',
  customerId: 'CUS-20260504002306-615',
  saleId: 'SALE-20260504005028-991',
  contractId: 'CON-20260504021423-908',
  documentId: 'DOC-20260504175000-946',
  route: 'signatureDryRunAfterSchema'
};

function erpB06J41_81_85_preflight() {
  return erpFieldB06J41_81_85_run_(FIELD_B06J41_81_85_DEFAULT_CTX, true);
}

function erpB06J41_81_85_autoRunSafe() {
  return erpFieldB06J41_81_85_run_(FIELD_B06J41_81_85_DEFAULT_CTX, true);
}

function erpFieldB06J41_81_85_renderSignatureSaveDryRunAfterSchemaHtml(ctx) {
  var vm = erpFieldB06J41_81_85_buildVm_(ctx || {});
  var t = HtmlService.createTemplateFromFile('P_SigDrySchema');
  t.vm = vm;
  t.json = JSON.stringify(vm, null, 2);
  return t.evaluate().setTitle('SIGN 서명 저장 DryRun 재검증').setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL);
}

function erpFieldB06J41_81_85_buildVm_(ctx) {
  ctx = erpFieldB06J41_81_85_normalize_(ctx || {});
  var result = erpFieldB06J41_81_85_run_(ctx, false);
  result.context = ctx;
  result.page = {
    badge: 'B06J41-81_85 SAFE : SIGNATURE SAVE DRYRUN AFTER SCHEMA',
    title: 'SIGN 서명 저장 DryRun 재검증',
    subtitle: '보정된 서명 저장 헤더를 기준으로 저장 후보값 매핑만 재검증합니다. 실제 저장·서명완료·PDF·Drive·정산은 계속 차단합니다.',
    roleName: (typeof erpFieldB06J41_37_40_roleName_ === 'function') ? erpFieldB06J41_37_40_roleName_(ctx.roleCode) : ctx.roleCode
  };
  result.urls = erpFieldB06J41_81_85_urls_(ctx);
  return result;
}

function erpFieldB06J41_81_85_run_(ctx, logOutput) {
  ctx = erpFieldB06J41_81_85_normalize_(ctx || {});
  var result = erpFieldB06J41_81_85_result_('signatureSaveDryRunAfterSchema');
  result.contextSummary = {
    eventId: ctx.eventId,
    vendorId: ctx.vendorId,
    customerId: ctx.customerId,
    saleId: ctx.saleId,
    contractId: ctx.contractId,
    documentId: ctx.documentId
  };

  try {
    if (typeof erpFieldB06J41_71_75_run_ !== 'function') {
      result.fatal.push('B06J41-71~75 서명 저장 DryRun 엔진 누락: FieldSignatureSaveDryRun.js 필요');
      return erpFieldB06J41_81_85_finish_(result, logOutput);
    }

    var dry = erpFieldB06J41_71_75_run_(ctx, false);
    result.checks.baseDryRunAfterSchema = erpFieldB06J41_81_85_compactDryRun_(dry);
    result.document = erpFieldB06J41_81_85_copy_(dry.document || {});
    result.contract = erpFieldB06J41_81_85_copy_(dry.contract || {});
    result.sale = erpFieldB06J41_81_85_copy_(dry.sale || {});
    result.stored = erpFieldB06J41_81_85_copy_(dry.stored || {});
    result.schema = erpFieldB06J41_81_85_copy_(dry.checks && dry.checks.schema ? dry.checks.schema : {});
    result.dryRun = erpFieldB06J41_81_85_copy_(dry.dryRun || {});
    result.headerResolution = erpFieldB06J41_81_85_headerResolution_(result.schema);
    result.plannedWriteMapping = erpFieldB06J41_81_85_plannedMapping_(ctx, result.document, result.schema, result.dryRun);
    result.checks.safety = erpFieldB06J41_81_85_safety_();

    if (!dry.ok) result.fatal = result.fatal.concat((dry.fatal || []).map(function (m) { return 'baseDryRunAfterSchema: ' + m; }));
    if ((dry.checks && dry.checks.schema && (dry.checks.schema.missingStorageHeaderGroups || []).length)) {
      result.fatal.push('보정 후에도 서명 저장 확장 헤더 누락: ' + dry.checks.schema.missingStorageHeaderGroups.join(', '));
    }
    if (dry.dryRun && dry.dryRun.ready !== true) {
      result.fatal.push('보정 후 DryRun ready 아님');
    }
  } catch (err) {
    result.fatal.push('B06J41-81~85 signature save dryrun after schema fatal: ' + (err && err.message ? err.message : err));
  }

  return erpFieldB06J41_81_85_finish_(result, logOutput);
}

function erpFieldB06J41_81_85_headerResolution_(schema) {
  schema = schema || {};
  var required = ['signaturePath','signatureFileId','signatureDataHash','signatureSavedAt','signatureSavedBy'];
  var resolved = schema.resolvedHeaders || {};
  var missing = [];
  required.forEach(function (k) {
    if (!resolved[k]) missing.push(k);
  });
  return {
    requiredStorageHeaderGroups: required,
    resolvedHeaders: resolved,
    missingStorageHeaderGroups: missing,
    headerMapBased: true,
    schemaFixed: missing.length === 0,
    noHeaderAppend: true
  };
}

function erpFieldB06J41_81_85_plannedMapping_(ctx, doc, schema, dryRun) {
  doc = doc || {};
  schema = schema || {};
  dryRun = dryRun || {};
  var h = schema.resolvedHeaders || {};
  return {
    mode: 'DRYRUN_ONLY_AFTER_SCHEMA_FIX',
    targetSheet: schema.signSheetName || 'SIGN_Documents',
    targetRow: doc.row || schema.signRow || '',
    targetDocumentId: doc.documentId || ctx.documentId,
    mappedHeaders: {
      signaturePath: h.signaturePath || '',
      signatureFileId: h.signatureFileId || '',
      signatureDataHash: h.signatureDataHash || '',
      signatureSavedAt: h.signatureSavedAt || '',
      signatureSavedBy: h.signatureSavedBy || '',
      signedAt: 'signedAt',
      signedBy: 'signedBy',
      signStatus: 'signStatus'
    },
    plannedWriteValues: {
      signaturePath: 'DRYRUN_SIGNATURE_IMAGE_PATH_NOT_SAVED',
      signatureFileId: 'DRYRUN_SIGNATURE_FILE_ID_NOT_SAVED',
      signatureDataHash: 'DRYRUN_SIGNATURE_HASH_NOT_SAVED',
      signatureSavedAt: 'DRYRUN_ONLY_NOT_APPLIED',
      signatureSavedBy: ctx.userEmail || 'FIELD_USER',
      signedAt: 'DRYRUN_ONLY_NOT_APPLIED',
      signedBy: ctx.userEmail || 'FIELD_USER',
      signStatus: 'SIGN_SAVED_CANDIDATE_NOT_APPLIED'
    },
    sourceDryRunReady: !!dryRun.ready,
    serverSaveBlocked: true,
    signCompleteBlocked: true,
    pdfStillBlocked: true,
    driveSaveBlocked: true,
    settlementStillBlocked: true,
    externalIntegrationStillBlocked: true,
    writeBlocked: true,
    rowCreationBlocked: true
  };
}

function erpFieldB06J41_81_85_compactDryRun_(dry) {
  dry = dry || {};
  var schema = dry.checks && dry.checks.schema ? dry.checks.schema : {};
  return {
    ok: !!dry.ok,
    fatal: dry.fatal || [],
    warnings: dry.warnings || [],
    signatureSaveSchemaDryRunReady: !!dry.signatureSaveSchemaDryRunReady,
    signatureSchemaChecked: !!dry.signatureSchemaChecked,
    signatureDryRunReady: !!dry.signatureDryRunReady,
    missingStorageHeaderGroups: schema.missingStorageHeaderGroups || [],
    resolvedHeaders: schema.resolvedHeaders || {},
    dryRunReady: !!(dry.dryRun && dry.dryRun.ready),
    noWrite: !!dry.noWrite,
    noRowCreation: !!dry.noRowCreation,
    build: dry.build || ''
  };
}

function erpFieldB06J41_81_85_safety_() {
  return {
    dryRunOnly: true,
    afterSchemaFixCheckOnly: true,
    noHeaderAppend: true,
    noGoogleScriptRun: true,
    noServerWrite: true,
    noSignInputSave: true,
    noSignComplete: true,
    noPdfCreate: true,
    noDriveSave: true,
    noSettlementExecution: true,
    noExternalIntegration: true,
    noDelete: true,
    noRowCreation: true,
    noStatusChange: true,
    systemConfigHeaderStandard: 'CONFIG_KEY/VALUE first'
  };
}

function erpFieldB06J41_81_85_urls_(ctx) {
  var base = '';
  try {
    var cfg = erpFieldB06J41_37_40_loadConfig_();
    base = String((cfg.configMap || {}).ERP_FIELD_WEBAPP_URL || '').trim();
  } catch (ignore) {}
  var q = 'roleCode=' + encodeURIComponent(ctx.roleCode) + '&vendorId=' + encodeURIComponent(ctx.vendorId) + '&eventId=' + encodeURIComponent(ctx.eventId) + '&saleId=' + encodeURIComponent(ctx.saleId || '') + '&contractId=' + encodeURIComponent(ctx.contractId || '') + '&customerId=' + encodeURIComponent(ctx.customerId || '') + '&documentId=' + encodeURIComponent(ctx.documentId || '');
  return {
    signatureDryRunAfterSchema: base ? base + '?' + q + '&route=signatureDryRunAfterSchema' : '',
    signatureSaveDryRun: base ? base + '?' + q + '&route=signatureSaveDryRun' : '',
    signatureSchemaFix: base ? base + '?' + q + '&route=signatureSchemaFix' : '',
    signatureSavePrecheck: base ? base + '?' + q + '&route=signatureSavePrecheck' : ''
  };
}

function erpFieldB06J41_81_85_result_(label) {
  return { ok: true, label: label, build: FIELD_B06J41_81_85_BUILD, moduleCode: 'ERP_FIELD', checkedAt: new Date().toISOString(), fatal: [], warnings: [], checks: {}, document: {}, contract: {}, sale: {}, stored: {}, schema: {}, dryRun: {}, headerResolution: {}, plannedWriteMapping: {} };
}

function erpFieldB06J41_81_85_finish_(result, logOutput) {
  Object.keys(result.checks || {}).forEach(function (k) {
    var c = result.checks[k];
    if (c && c.fatal && c.fatal.length) result.fatal = result.fatal.concat(c.fatal.map(function (m) { return k + ': ' + m; }));
    if (c && c.warnings && c.warnings.length) result.warnings = result.warnings.concat(c.warnings.map(function (m) { return k + ': ' + m; }));
  });
  result.ok = result.fatal.length === 0;
  result.signatureSaveDryRunAfterSchemaReady = result.ok && !!(result.dryRun && result.dryRun.ready) && !!(result.headerResolution && result.headerResolution.schemaFixed);
  result.signatureStorageHeadersResolved = !!(result.headerResolution && result.headerResolution.schemaFixed);
  result.signatureWriteMappingReady = result.signatureSaveDryRunAfterSchemaReady;
  result.noHeaderAppend = true;
  result.noGoogleScriptRun = true;
  result.noSignInputSave = true;
  result.noSignComplete = true;
  result.noPdf = true;
  result.noDriveSave = true;
  result.noSettlement = true;
  result.noExternalIntegration = true;
  result.noWrite = true;
  result.noRowCreation = true;
  if (logOutput) {
    Logger.log('======================================================');
    Logger.log('[' + FIELD_B06J41_81_85_BUILD + '] RESULT');
    Logger.log(JSON.stringify(result, null, 2));
    Logger.log('======================================================');
  }
  return result;
}

function erpFieldB06J41_81_85_normalize_(ctx) {
  if (typeof erpFieldB06J41_71_75_normalize_ === 'function') {
    ctx = erpFieldB06J41_71_75_normalize_(ctx || {});
  } else if (typeof erpFieldB06J41_66_70_normalize_ === 'function') {
    ctx = erpFieldB06J41_66_70_normalize_(ctx || {});
  } else {
    ctx = ctx || {};
  }
  ctx.route = String((arguments[0] || {}).route || ctx.route || 'signatureDryRunAfterSchema').trim();
  return ctx;
}

function erpFieldB06J41_81_85_copy_(obj) {
  var out = {};
  obj = obj || {};
  Object.keys(obj).forEach(function (k) { out[k] = obj[k]; });
  return out;
}


/* ===== SigDryScChk.js ===== */
/**
 * build: ERP_B06J41_81_85_SIGNATURE_SAVE_DRYRUN_AFTER_SCHEMA_SAFE_UPLOAD
 * self test entry
 */
function erpB06J41_81_85_signatureSaveDryRunAfterSchemaSelfTest() {
  return erpB06J41_81_85_autoRunSafe();
}


/* ===== SigDry.js ===== */
/**
 * build: ERP_B06J41_71_75_SIGNATURE_SAVE_SCHEMA_AND_DRYRUN_SAFE_UPLOAD
 * module: ERP_FIELD
 * purpose:
 * - SIGN 서명 저장용 스키마 점검
 * - 서명 이미지 저장 후보 구조 DryRun
 * - 실제 서명 저장/상태변경/PDF/Drive/정산/외부연동은 계속 차단
 * safety:
 * - DRYRUN only
 * - no sign input save / no sign complete / no PDF / no Drive / no settlement / no external integration
 * - no server write / no update / no delete / no row creation
 * - SystemConfig standard header: CONFIG_KEY / VALUE first
 */

var FIELD_B06J41_71_75_BUILD = 'ERP_B06J41_71_75_SIGNATURE_SAVE_SCHEMA_AND_DRYRUN_SAFE_UPLOAD';
var FIELD_B06J41_71_75_DEFAULT_CTX = {
  roleCode: 'VENDOR_MANAGER',
  vendorId: 'VND-20260502202158-505',
  eventId: 'EVT-20260502202016-197',
  customerId: 'CUS-20260504002306-615',
  saleId: 'SALE-20260504005028-991',
  contractId: 'CON-20260504021423-908',
  documentId: 'DOC-20260504175000-946',
  route: 'signatureSaveDryRun'
};

function erpB06J41_71_75_preflight() {
  return erpFieldB06J41_71_75_run_(FIELD_B06J41_71_75_DEFAULT_CTX, true);
}

function erpB06J41_71_75_autoRunSafe() {
  return erpFieldB06J41_71_75_run_(FIELD_B06J41_71_75_DEFAULT_CTX, true);
}

function erpFieldB06J41_71_75_renderSignatureSaveDryRunHtml(ctx) {
  var vm = erpFieldB06J41_71_75_buildVm_(ctx || {});
  var t = HtmlService.createTemplateFromFile('P_SigDry');
  t.vm = vm;
  t.json = JSON.stringify(vm, null, 2);
  return t.evaluate().setTitle('SIGN 서명 저장 스키마 / DryRun').setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL);
}

function erpFieldB06J41_71_75_buildVm_(ctx) {
  ctx = erpFieldB06J41_71_75_normalize_(ctx || {});
  var result = erpFieldB06J41_71_75_run_(ctx, false);
  result.context = ctx;
  result.page = {
    badge: 'B06J41-71_75 SAFE : SIGNATURE SAVE SCHEMA + DRYRUN',
    title: 'SIGN 서명 저장 스키마 / DryRun',
    subtitle: '서명 저장에 필요한 헤더와 저장 후보값만 점검합니다. 실제 저장·서명완료·PDF·Drive·정산은 계속 차단합니다.',
    roleName: erpFieldB06J41_37_40_roleName_(ctx.roleCode)
  };
  result.urls = erpFieldB06J41_71_75_urls_(ctx, result);
  return result;
}

function erpFieldB06J41_71_75_run_(ctx, logOutput) {
  ctx = erpFieldB06J41_71_75_normalize_(ctx || {});
  var result = erpFieldB06J41_71_75_result_('signatureSaveSchemaDryRun');
  result.contextSummary = {
    eventId: ctx.eventId,
    vendorId: ctx.vendorId,
    customerId: ctx.customerId,
    saleId: ctx.saleId,
    contractId: ctx.contractId,
    documentId: ctx.documentId
  };
  try {
    if (typeof erpFieldB06J41_66_70_run_ !== 'function') {
      result.fatal.push('B06J41-66~70 서명 저장 전 프리체크 엔진 누락: FieldSignatureSavePrecheck.js 필요');
      return erpFieldB06J41_71_75_finish_(result, logOutput);
    }
    var base = erpFieldB06J41_66_70_run_(ctx, false);
    result.checks.signatureSavePrecheckBase = erpFieldB06J41_71_75_compactPrecheck_(base);
    result.document = erpFieldB06J41_71_75_copy_(base.document || {});
    result.contract = erpFieldB06J41_71_75_copy_(base.contract || {});
    result.sale = erpFieldB06J41_71_75_copy_(base.sale || {});
    result.stored = erpFieldB06J41_71_75_copy_(base.stored || {});
    result.checks.schema = erpFieldB06J41_71_75_schemaCheck_(base);
    result.checks.safety = erpFieldB06J41_71_75_safety_();
    result.dryRun = erpFieldB06J41_71_75_dryRun_(ctx, base, result.checks.schema);

    if (!base.ok) result.fatal = result.fatal.concat((base.fatal || []).map(function (m) { return 'signatureSavePrecheckBase: ' + m; }));
    if ((base.warnings || []).length) result.warnings = result.warnings.concat((base.warnings || []).map(function (m) { return 'signatureSavePrecheckBase: ' + m; }));
    if (result.dryRun && result.dryRun.fatal && result.dryRun.fatal.length) result.fatal = result.fatal.concat(result.dryRun.fatal.map(function (m) { return 'dryRun: ' + m; }));
  } catch (err) {
    result.fatal.push('B06J41-71~75 signature save schema dryrun fatal: ' + (err && err.message ? err.message : err));
  }
  return erpFieldB06J41_71_75_finish_(result, logOutput);
}

function erpFieldB06J41_71_75_schemaCheck_(base) {
  var out = {
    ok: true,
    fatal: [],
    warnings: [],
    signSheetName: '',
    signRow: '',
    headerPolicy: 'headerMap based',
    requiredCoreHeaders: ['documentId','eventId','vendorId','customerId','saleId','contractId','status','signStatus','pdfStatus','signUrl','qrUrl','signedAt','signedBy'],
    signatureStorageHeaderCandidates: {
      signaturePath: ['signaturePath','signatureFileUrl','signatureImageUrl','signatureUrl','signImageUrl'],
      signatureFileId: ['signatureFileId','signImageFileId','signatureImageFileId'],
      signatureDataHash: ['signatureDataHash','signDataHash','signatureHash'],
      signatureSavedAt: ['signatureSavedAt','signSavedAt','signatureStoredAt'],
      signatureSavedBy: ['signatureSavedBy','signSavedBy','signatureStoredBy']
    },
    resolvedHeaders: {},
    missingCoreHeaders: [],
    missingStorageHeaderGroups: [],
    addHeaderPlan: [],
    noAutoHeaderAppend: true
  };
  try {
    var signSheetCheck = base && base.checks && base.checks.signaturePadPreviewBase && base.checks.signaturePadPreviewBase.checks ? null : null;
    var cfg = erpFieldB06J41_37_40_loadConfig_();
    if (!cfg.ok) {
      out.fatal = out.fatal.concat(cfg.fatal || []);
      out.ok = false;
      return out;
    }
    var master = erpFieldB06J41_37_40_openMaster_(cfg);
    if (!master.ss) {
      out.fatal.push('FEELHAUS_DB_MASTER 연결 실패');
      out.ok = false;
      return out;
    }
    var signSheet = erpFieldB06J41_37_40_findSheet_(master.ss, FIELD_B06J41_37_40_SIGN_CANDIDATES, ['documentId','eventId','vendorId','customerId','saleId','contractId','status','signStatus','pdfStatus','signUrl','qrUrl','signedAt','signedBy']);
    out.signSheetName = signSheet.sheetName || '';
    out.signRow = (base && base.document && base.document.row) || '';
    out.signSheetExists = !!signSheet.exists;
    out.lastCol = signSheet.lastCol || 0;
    out.lastRow = signSheet.lastRow || 0;
    out.missingCoreHeaders = signSheet.missingRequiredHeaders || [];
    out.headersSample = (signSheet.headers || []).slice(0, 80);
    if (!signSheet.exists) out.fatal.push('SIGN_Documents 시트 없음');
    if (out.missingCoreHeaders.length) out.fatal.push('SIGN_Documents 핵심 서명 저장 헤더 누락: ' + out.missingCoreHeaders.join(', '));
    var map = signSheet.headerMap || {};
    Object.keys(out.signatureStorageHeaderCandidates).forEach(function (group) {
      var found = '';
      var candidates = out.signatureStorageHeaderCandidates[group];
      for (var i = 0; i < candidates.length; i++) {
        if (map[candidates[i]]) {
          found = candidates[i];
          break;
        }
      }
      out.resolvedHeaders[group] = found;
      if (!found) {
        out.missingStorageHeaderGroups.push(group);
        out.addHeaderPlan.push(candidates[0]);
      }
    });
    if (out.missingStorageHeaderGroups.length) {
      out.warnings.push('서명 이미지 저장 확장 헤더 후보 누락: ' + out.addHeaderPlan.join(', ') + ' (이번 빌드는 DryRun이므로 자동 추가하지 않음)');
    }
    out.ok = out.fatal.length === 0;
  } catch (err) {
    out.fatal.push('스키마 점검 실패: ' + (err && err.message ? err.message : err));
    out.ok = false;
  }
  return out;
}

function erpFieldB06J41_71_75_dryRun_(ctx, base, schema) {
  base = base || {};
  schema = schema || {};
  var fatal = [];
  var warnings = [];
  var d = base.document || {};
  var c = base.contract || {};
  var s = base.sale || {};
  var savePrecheck = base.savePrecheck || {};
  if (!base.signatureSavePrecheckReady) fatal.push('서명 저장 전 프리체크 미통과');
  if (!d.found) fatal.push('SIGN_Documents 문서 없음');
  if (!c.found) fatal.push('연결 Contracts 없음');
  if (!s.found) fatal.push('연결 Sales 없음');
  if (!schema.ok) fatal.push('핵심 저장 스키마 미충족');
  if ((schema.missingStorageHeaderGroups || []).length) warnings.push('실제 저장 전 확장 저장 헤더 보정 필요: ' + (schema.addHeaderPlan || []).join(', '));
  return {
    ready: fatal.length === 0,
    fatal: fatal,
    warnings: warnings,
    mode: 'DRYRUN_ONLY',
    targetSheet: schema.signSheetName || 'SIGN_Documents',
    targetRow: d.row || schema.signRow || '',
    targetDocumentId: d.documentId || ctx.documentId,
    plannedWriteValues: {
      signStatus: 'SIGN_SAVED_CANDIDATE_NOT_APPLIED',
      signedAt: 'DRYRUN_ONLY_NOT_APPLIED',
      signedBy: ctx.userEmail || 'FIELD_USER',
      signatureStorage: 'LOCAL_DATA_URL_CANDIDATE_NOT_SAVED'
    },
    plannedHeaderUse: schema.resolvedHeaders || {},
    plannedHeaderAddNext: schema.addHeaderPlan || [],
    dryRunMessage: fatal.length ? '서명 저장 DryRun 조건 미충족' : '서명 저장 DryRun 가능 - 실제 쓰기는 차단됨',
    serverSaveBlocked: true,
    statusChangeBlocked: true,
    signCompleteBlocked: true,
    pdfStillBlocked: true,
    driveSaveBlocked: true,
    settlementStillBlocked: true,
    externalIntegrationStillBlocked: true,
    writeBlocked: true,
    rowCreationBlocked: true,
    noActualMutation: true
  };
}

function erpFieldB06J41_71_75_compactPrecheck_(base) {
  base = base || {};
  return {
    ok: !!base.ok,
    fatal: base.fatal || [],
    warnings: base.warnings || [],
    documentFound: !!(base.document && base.document.found),
    contractFound: !!(base.contract && base.contract.found),
    saleFound: !!(base.sale && base.sale.found),
    signatureSavePrecheckReady: !!base.signatureSavePrecheckReady,
    signaturePadVisible: !!base.signaturePadVisible,
    signaturePadActive: !!base.signaturePadActive,
    noSignInputSave: !!base.noSignInputSave,
    noSignComplete: !!base.noSignComplete,
    build: base.build || ''
  };
}

function erpFieldB06J41_71_75_safety_() {
  return {
    dryRunOnly: true,
    schemaCheckOnly: true,
    noAutoHeaderAppend: true,
    noGoogleScriptRun: true,
    noServerWrite: true,
    noSignInputSave: true,
    noSignComplete: true,
    noPdfCreate: true,
    noDriveSave: true,
    noSettlementExecution: true,
    noExternalIntegration: true,
    noDelete: true,
    noRowCreation: true,
    noStatusChange: true,
    systemConfigHeaderStandard: 'CONFIG_KEY/VALUE first'
  };
}

function erpFieldB06J41_71_75_urls_(ctx, result) {
  var base = '';
  try {
    var cfg = erpFieldB06J41_37_40_loadConfig_();
    base = String((cfg.configMap || {}).ERP_FIELD_WEBAPP_URL || '').trim();
  } catch (ignore) {}
  var q = 'roleCode=' + encodeURIComponent(ctx.roleCode) + '&vendorId=' + encodeURIComponent(ctx.vendorId) + '&eventId=' + encodeURIComponent(ctx.eventId) + '&saleId=' + encodeURIComponent(ctx.saleId || '') + '&contractId=' + encodeURIComponent(ctx.contractId || '') + '&customerId=' + encodeURIComponent(ctx.customerId || '') + '&documentId=' + encodeURIComponent(ctx.documentId || '');
  return {
    signatureSaveDryRun: base ? base + '?' + q + '&route=signatureSaveDryRun' : '',
    signatureSavePrecheck: base ? base + '?' + q + '&route=signatureSavePrecheck' : '',
    signaturePadPreview: base ? base + '?' + q + '&route=signaturePadPreview' : '',
    signInputPrecheck: base ? base + '?' + q + '&route=signInputPrecheck' : '',
    signEntryReadOnly: base ? base + '?' + q + '&route=signEntry' : ''
  };
}

function erpFieldB06J41_71_75_result_(label) {
  return { ok: true, label: label, build: FIELD_B06J41_71_75_BUILD, moduleCode: 'ERP_FIELD', checkedAt: new Date().toISOString(), fatal: [], warnings: [], checks: {}, document: {}, contract: {}, sale: {}, stored: {}, dryRun: {} };
}

function erpFieldB06J41_71_75_finish_(result, logOutput) {
  Object.keys(result.checks || {}).forEach(function (k) {
    var c = result.checks[k];
    if (c && c.fatal && c.fatal.length) result.fatal = result.fatal.concat(c.fatal.map(function (m) { return k + ': ' + m; }));
    if (c && c.warnings && c.warnings.length) result.warnings = result.warnings.concat(c.warnings.map(function (m) { return k + ': ' + m; }));
  });
  if (result.dryRun && result.dryRun.warnings && result.dryRun.warnings.length) result.warnings = result.warnings.concat(result.dryRun.warnings.map(function (m) { return 'dryRun: ' + m; }));
  result.ok = result.fatal.length === 0;
  result.signatureSaveSchemaDryRunReady = !!(result.dryRun && result.dryRun.ready) && result.ok;
  result.signatureSchemaChecked = true;
  result.signatureDryRunReady = !!(result.dryRun && result.dryRun.ready) && result.ok;
  result.noAutoHeaderAppend = true;
  result.noGoogleScriptRun = true;
  result.noSignInputSave = true;
  result.noSignComplete = true;
  result.noPdf = true;
  result.noDriveSave = true;
  result.noSettlement = true;
  result.noExternalIntegration = true;
  result.noWrite = true;
  result.noRowCreation = true;
  if (logOutput) {
    Logger.log('======================================================');
    Logger.log('[' + FIELD_B06J41_71_75_BUILD + '] RESULT');
    Logger.log(JSON.stringify(result, null, 2));
    Logger.log('======================================================');
  }
  return result;
}

function erpFieldB06J41_71_75_normalize_(ctx) {
  ctx = erpFieldB06J41_66_70_normalize_(ctx || {});
  ctx.route = String((arguments[0] || {}).route || ctx.route || 'signatureSaveDryRun').trim();
  return ctx;
}

function erpFieldB06J41_71_75_copy_(obj) {
  var out = {};
  obj = obj || {};
  Object.keys(obj).forEach(function (k) { out[k] = obj[k]; });
  return out;
}


/* ===== SigDryChk.js ===== */
/**
 * build: ERP_B06J41_71_75_SIGNATURE_SAVE_SCHEMA_AND_DRYRUN_SAFE_UPLOAD
 * self test entry file
 */
function erpB06J41_71_75_signatureSaveSchemaDryRunSelfTest() {
  var result = erpFieldB06J41_71_75_run_(FIELD_B06J41_71_75_DEFAULT_CTX, true);
  var summary = {
    ok: !!result.ok,
    build: FIELD_B06J41_71_75_BUILD,
    routeSignatureSaveDryRun: 'signatureSaveDryRun',
    routeAlias: ['signSaveDryRun', 'signatureSchemaDryRun'],
    context: FIELD_B06J41_71_75_DEFAULT_CTX,
    fatal: result.fatal || [],
    warnings: result.warnings || [],
    signatureSaveSchemaDryRunReady: !!result.signatureSaveSchemaDryRunReady,
    signatureSchemaChecked: true,
    signatureDryRunReady: !!result.signatureDryRunReady,
    noAutoHeaderAppend: true,
    noGoogleScriptRun: true,
    noSignInputSave: true,
    noSignComplete: true,
    noPdf: true,
    noDriveSave: true,
    noSettlement: true,
    noExternalIntegration: true,
    noWrite: true,
    noRowCreation: true,
    message: result.ok ? 'SIGN 서명 저장 스키마 / DryRun 정상' : 'SIGN 서명 저장 스키마 / DryRun 점검 필요'
  };
  Logger.log('======================================================');
  Logger.log('[' + FIELD_B06J41_71_75_BUILD + '] RESULT');
  Logger.log(JSON.stringify(summary, null, 2));
  Logger.log('======================================================');
  return summary;
}


/* ===== SigSave.js ===== */
/**
 * build: ERP_B06J41_91_95D_SIGNATURE_SAVE_HANDOFF_TO_SIGN_SAFE_UPLOAD
 * module: ERP_FIELD
 * purpose:
 * - ERP_FIELD에서 DriveApp 직접 저장 중지
 * - 서명 입력/검증 후 SIGN_WEBAPP_URL로 서명 저장 인계
 * - documentId/contractId/saleId/customerId 기준 handoff payload 구성
 * - SIGN이 Drive 저장 및 SIGN_Documents 반영을 담당하도록 분리
 * safety:
 * - no DriveApp usage in ERP_FIELD signature save flow
 * - SIGN handoff only allowed external integration
 * - no sign complete / no PDF / no document Drive archive / no settlement
 * - no row creation / no header append / no delete
 * - SystemConfig standard header: CONFIG_KEY / VALUE first
 */

var FIELD_B06J41_91_95D_BUILD = 'ERP_B06J41_91_95D_SIGNATURE_SAVE_HANDOFF_TO_SIGN_SAFE_UPLOAD';
var FIELD_B06J41_91_95_BUILD = FIELD_B06J41_91_95D_BUILD;
var FIELD_B06J41_91_95_DEFAULT_CTX = {
  roleCode: 'VENDOR_MANAGER',
  vendorId: 'VND-20260502202158-505',
  eventId: 'EVT-20260502202016-197',
  customerId: 'CUS-20260504002306-615',
  saleId: 'SALE-20260504005028-991',
  contractId: 'CON-20260504021423-908',
  documentId: 'DOC-20260504175000-946',
  route: 'signatureSaveExecute'
};

function erpB06J41_91_95D_signatureSaveHandoffSelfTest() {
  return erpFieldB06J41_91_95D_run_(FIELD_B06J41_91_95_DEFAULT_CTX, true);
}
function erpB06J41_91_95_signatureSaveExecuteSelfTest() {
  return erpB06J41_91_95D_signatureSaveHandoffSelfTest();
}
function erpB06J41_91_95_preflight() {
  return erpB06J41_91_95D_signatureSaveHandoffSelfTest();
}
function erpB06J41_91_95_autoRunSafe() {
  return erpB06J41_91_95D_signatureSaveHandoffSelfTest();
}

function erpFieldB06J41_91_95D_renderSignatureSaveHandoffHtml(ctx) {
  var vm = erpFieldB06J41_91_95D_buildVm_(ctx || {});
  var t = HtmlService.createTemplateFromFile('P_SigSave');
  t.vm = vm;
  t.json = JSON.stringify(vm, null, 2);
  return t.evaluate().setTitle('SIGN 서명 저장 인계').setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL);
}
function erpFieldB06J41_91_95_renderSignatureSaveExecuteHtml(ctx) {
  return erpFieldB06J41_91_95D_renderSignatureSaveHandoffHtml(ctx);
}

function erpFieldB06J41_91_95D_buildVm_(ctx) {
  ctx = erpFieldB06J41_91_95D_normalize_(ctx || {});
  var result = erpFieldB06J41_91_95D_run_(ctx, false);
  result.context = ctx;
  result.contextJson = JSON.stringify(ctx);
  result.page = {
    badge: 'B06J41-91_95D SAFE : SIGNATURE HANDOFF TO SIGN',
    title: 'SIGN 서명 저장 인계',
    subtitle: 'ERP_FIELD는 서명 입력과 검증만 수행하고, 서명 이미지 Drive 저장은 SIGN_WEBAPP_URL로 인계합니다.',
    roleName: (typeof erpFieldB06J41_37_40_roleName_ === 'function') ? erpFieldB06J41_37_40_roleName_(ctx.roleCode) : ctx.roleCode
  };
  result.urls = erpFieldB06J41_91_95D_urls_(ctx);
  return result;
}

function erpFieldB06J41_91_95D_run_(ctx, logOutput) {
  ctx = erpFieldB06J41_91_95D_normalize_(ctx || {});
  var blocked = erpFieldB06J41_91_95D_result_('blockedByFieldV37');
  blocked.contextSummary = erpFieldB06J41_91_95D_contextSummary_(ctx);
  blocked.fatal.push('FIELD V37 SAFETY: SIGN 서명 저장/외부연동 실제 실행 금지. READ ONLY precheck만 허용.');
  return erpFieldB06J41_91_95D_finish_(blocked, logOutput);
  ctx = erpFieldB06J41_91_95D_normalize_(ctx || {});
  var result = erpFieldB06J41_91_95D_result_('signatureSaveHandoffPrep');
  result.contextSummary = erpFieldB06J41_91_95D_contextSummary_(ctx);
  try {
    if (typeof erpFieldB06J41_86_90_run_ !== 'function') {
      result.fatal.push('B06J41-86~90 저장 직전 확인 엔진 누락: FieldSignatureSaveConfirmPrep.js 필요');
      return erpFieldB06J41_91_95D_finish_(result, logOutput);
    }
    var prep = erpFieldB06J41_86_90_run_(ctx, false);
    result.checks.confirmPrep = erpFieldB06J41_91_95D_compactPrep_(prep);
    result.document = erpFieldB06J41_91_95D_copy_(prep.document || {});
    result.contract = erpFieldB06J41_91_95D_copy_(prep.contract || {});
    result.sale = erpFieldB06J41_91_95D_copy_(prep.sale || {});
    result.schema = erpFieldB06J41_91_95D_copy_(prep.schema || {});
    result.headerResolution = erpFieldB06J41_91_95D_copy_(prep.headerResolution || {});
    result.confirmPrep = erpFieldB06J41_91_95D_copy_(prep.confirmPrep || {});
    result.duplicateGuard = erpFieldB06J41_91_95D_copy_(prep.duplicateGuard || {});
    if (!prep.ok) result.fatal = result.fatal.concat((prep.fatal || []).map(function (m) { return 'confirmPrep: ' + m; }));

    var config = (typeof erpFieldB06J41_37_40_loadConfig_ === 'function') ? erpFieldB06J41_37_40_loadConfig_() : { ok: false, fatal: ['공통 config loader 누락'] };
    result.checks.config = erpFieldB06J41_91_95D_compactConfig_(config);
    if (!config.ok) result.fatal = result.fatal.concat(config.fatal || ['SystemConfig 읽기 실패']);

    var signUrl = String((config.configMap || {}).SIGN_WEBAPP_URL || '').trim();
    result.handoff = erpFieldB06J41_91_95D_handoffPolicy_(ctx, signUrl, result.document, result.duplicateGuard);
    result.checks.safety = erpFieldB06J41_91_95D_safety_();
    if (!signUrl) result.fatal.push('SIGN_WEBAPP_URL 설정 누락');
    if (result.duplicateGuard && result.duplicateGuard.alreadySignatureSaved) result.fatal.push('중복 저장 차단: 이미 서명 저장값 존재');
    if (!result.handoff.ready) result.fatal.push('SIGN 저장 인계 준비 실패');
  } catch (err) {
    result.fatal.push('B06J41-91~95D signature save handoff prep fatal: ' + (err && err.message ? err.message : err));
  }
  return erpFieldB06J41_91_95D_finish_(result, logOutput);
}

function erpB06J41_91_95_signatureSaveFromClient(payload) {
  return erpFieldB06J41_91_95D_handoffSignatureFromClient_(payload || {});
}
function erpB06J41_91_95D_signatureHandoffFromClient(payload) {
  return erpFieldB06J41_91_95D_handoffSignatureFromClient_(payload || {});
}

function erpFieldB06J41_91_95D_handoffSignatureFromClient_(payload) {
  var result = erpFieldB06J41_91_95D_result_('signatureSaveHandoffExecute');
  result.executeHandoff = true;
  result.signHandoffOnly = true;
  result.noDriveAppInErpField = true;
  result.noSignComplete = true;
  result.noPdf = true;
  result.noDriveArchive = true;
  result.noSettlement = true;
  result.externalIntegrationAllowed = 'SIGN_WEBAPP_URL_ONLY';
  result.noRowCreation = true;
  result.noHeaderAppend = true;
  try {
    var ctx = erpFieldB06J41_91_95D_normalize_(payload.context || payload || {});
    var dataUrl = String(payload.signatureDataUrl || '').trim();
    result.contextSummary = erpFieldB06J41_91_95D_contextSummary_(ctx);

    var prep = erpFieldB06J41_91_95D_run_(ctx, false);
    result.checks.prep = erpFieldB06J41_91_95D_compactPrep_(prep);
    result.document = erpFieldB06J41_91_95D_copy_(prep.document || {});
    result.contract = erpFieldB06J41_91_95D_copy_(prep.contract || {});
    result.sale = erpFieldB06J41_91_95D_copy_(prep.sale || {});
    if (!prep.ok) result.fatal = result.fatal.concat((prep.fatal || []).map(function (m) { return 'prep: ' + m; }));

    var parsed = erpFieldB06J41_91_95D_parseSignatureDataUrl_(dataUrl);
    result.signatureData = parsed.meta;
    if (!parsed.ok) result.fatal = result.fatal.concat(parsed.fatal);
    if (result.fatal.length) return erpFieldB06J41_91_95D_finish_(result, false);

    var config = erpFieldB06J41_37_40_loadConfig_();
    result.checks.config = erpFieldB06J41_91_95D_compactConfig_(config);
    if (!config.ok) {
      result.fatal = result.fatal.concat(config.fatal || ['SystemConfig 읽기 실패']);
      return erpFieldB06J41_91_95D_finish_(result, false);
    }
    var signWebappUrl = String((config.configMap || {}).SIGN_WEBAPP_URL || '').trim();
    if (!signWebappUrl) {
      result.fatal.push('SIGN_WEBAPP_URL 설정 누락');
      return erpFieldB06J41_91_95D_finish_(result, false);
    }

    var hash = erpFieldB06J41_91_95D_sha256Hex_(parsed.bytes);
    var requestedBy = String(ctx.userEmail || Session.getActiveUser().getEmail() || 'FIELD_USER').trim() || 'FIELD_USER';
    var handoffPayload = {
      action: 'FIELD_SIGNATURE_SAVE_HANDOFF',
      moduleCode: 'ERP_FIELD',
      build: FIELD_B06J41_91_95D_BUILD,
      requestedAt: Utilities.formatDate(new Date(), 'Asia/Seoul', 'yyyy-MM-dd HH:mm:ss'),
      requestedBy: requestedBy,
      context: erpFieldB06J41_91_95D_contextSummary_(ctx),
      document: {
        documentId: ctx.documentId,
        documentType: result.document.documentType || 'CONTRACT',
        signStatus: result.document.signStatus || '',
        pdfStatus: result.document.pdfStatus || ''
      },
      signature: {
        dataUrl: dataUrl,
        dataHash: hash,
        bytesLength: parsed.meta.bytesLength,
        mimeType: parsed.meta.mimeType,
        nextSignStatus: 'SIGN_SAVED'
      },
      safety: {
        signImageSaveOnly: true,
        noPdf: true,
        noDocumentDriveArchive: true,
        noSettlement: true,
        noExternalIntegrationExceptSign: true,
        noRowCreationRequested: true
      }
    };
    result.handoffPayloadSummary = erpFieldB06J41_91_95D_handoffPayloadSummary_(handoffPayload);

    var endpoint = erpFieldB06J41_91_95D_appendQuery_(signWebappUrl, { action: 'FIELD_SIGNATURE_SAVE_HANDOFF' });
    var response = UrlFetchApp.fetch(endpoint, {
      method: 'post',
      contentType: 'application/json',
      payload: JSON.stringify(handoffPayload),
      muteHttpExceptions: true,
      followRedirects: true
    });
    var code = response.getResponseCode();
    var text = response.getContentText() || '';
    result.signHandoff = {
      ok: code >= 200 && code < 300,
      endpoint: endpoint,
      responseCode: code,
      responseTextSample: text.slice(0, 1200),
      dataHash: hash,
      bytesLength: parsed.meta.bytesLength
    };
    if (!result.signHandoff.ok) {
      result.fatal.push('SIGN 저장 인계 실패: responseCode=' + code + ', response=' + text.slice(0, 300));
    }
  } catch (err) {
    result.fatal.push('B06J41-91~95D SIGN handoff fatal: ' + (err && err.message ? err.message : err));
  }
  return erpFieldB06J41_91_95D_finish_(result, false);
}

function erpFieldB06J41_91_95D_handoffPolicy_(ctx, signWebappUrl, document, duplicateGuard) {
  var ready = !!(ctx.documentId && ctx.contractId && ctx.saleId && ctx.customerId && signWebappUrl);
  if (document && document.signStatus && String(document.signStatus) !== 'SIGN_URL_READY') ready = false;
  if (duplicateGuard && duplicateGuard.alreadySignatureSaved) ready = false;
  return {
    ready: ready,
    mode: 'ERP_FIELD_TO_SIGN_WEBAPP_HANDOFF',
    signWebappUrlConfigured: !!signWebappUrl,
    targetDocumentId: ctx.documentId,
    targetContractId: ctx.contractId,
    targetSaleId: ctx.saleId,
    targetCustomerId: ctx.customerId,
    nextSignStatus: 'SIGN_SAVED_BY_SIGN',
    erpFieldDriveAppDirectSave: false,
    signOwnsDriveSave: true,
    signHandoffOnly: true,
    endpointAction: 'FIELD_SIGNATURE_SAVE_HANDOFF'
  };
}

function erpFieldB06J41_91_95D_parseSignatureDataUrl_(dataUrl) {
  var result = { ok: false, fatal: [], bytes: null, meta: {} };
  if (!dataUrl) {
    result.fatal.push('서명 데이터 누락');
    return result;
  }
  var m = /^data:(image\/png|image\/jpeg);base64,([A-Za-z0-9+/=]+)$/.exec(dataUrl);
  if (!m) {
    result.fatal.push('서명 데이터 형식 오류: PNG/JPEG dataURL 필요');
    return result;
  }
  var bytes = Utilities.base64Decode(m[2]);
  result.bytes = bytes;
  result.meta = { mimeType: m[1], bytesLength: bytes.length, dataUrlLength: dataUrl.length, minInkCheck: bytes.length > 300 };
  if (bytes.length <= 300) result.fatal.push('서명 데이터가 너무 작음: 실제 서명 입력 필요');
  result.ok = result.fatal.length === 0;
  return result;
}

function erpFieldB06J41_91_95D_sha256Hex_(bytes) {
  var digest = Utilities.computeDigest(Utilities.DigestAlgorithm.SHA_256, bytes);
  return digest.map(function (b) {
    var v = (b < 0 ? b + 256 : b).toString(16);
    return v.length === 1 ? '0' + v : v;
  }).join('');
}
function erpFieldB06J41_91_95D_appendQuery_(url, params) {
  var q = Object.keys(params || {}).map(function (k) { return encodeURIComponent(k) + '=' + encodeURIComponent(params[k]); }).join('&');
  if (!q) return url;
  return url + (url.indexOf('?') >= 0 ? '&' : '?') + q;
}
function erpFieldB06J41_91_95D_handoffPayloadSummary_(p) {
  return {
    action: p.action,
    moduleCode: p.moduleCode,
    documentId: p.context.documentId,
    contractId: p.context.contractId,
    saleId: p.context.saleId,
    customerId: p.context.customerId,
    dataHash: p.signature.dataHash,
    bytesLength: p.signature.bytesLength,
    nextSignStatus: p.signature.nextSignStatus,
    noPdf: p.safety.noPdf,
    noSettlement: p.safety.noSettlement
  };
}
function erpFieldB06J41_91_95D_urls_(ctx) {
  var base = 'https://script.google.com/macros/s/AKfycbzoFVrXuPH3cPHDdm5O-1K6mF0UAuVjeOu26ZFvIZlD_px_wAXJKwzApqfbgMAfTwJQ0g/exec';
  var q = 'roleCode=' + encodeURIComponent(ctx.roleCode || '') + '&vendorId=' + encodeURIComponent(ctx.vendorId || '') + '&eventId=' + encodeURIComponent(ctx.eventId || '') + '&saleId=' + encodeURIComponent(ctx.saleId || '') + '&contractId=' + encodeURIComponent(ctx.contractId || '') + '&customerId=' + encodeURIComponent(ctx.customerId || '') + '&documentId=' + encodeURIComponent(ctx.documentId || '');
  return {
    self: base + '?route=signatureSaveExecute&' + q,
    confirmPrep: base + '?route=signatureSaveConfirmPrep&' + q,
    signaturePadPreview: base + '?route=signaturePadPreview&' + q,
    signUrlVerify: base + '?route=signUrlVerify&' + q
  };
}
function erpFieldB06J41_91_95D_safety_() {
  return {
    erpFieldDriveAppDirectSave: false,
    signWebappHandoffOnly: true,
    noSignComplete: true,
    noPdfCreate: true,
    noDocumentDriveArchive: true,
    noSettlementExecution: true,
    noExternalIntegrationExceptSign: true,
    noDelete: true,
    noRowCreation: true,
    noHeaderAppend: true,
    systemConfigHeaderStandard: 'CONFIG_KEY/VALUE first'
  };
}
function erpFieldB06J41_91_95D_result_(label) {
  return {
    ok: false,
    label: label,
    build: FIELD_B06J41_91_95D_BUILD,
    moduleCode: 'ERP_FIELD',
    checkedAt: new Date().toISOString(),
    fatal: [],
    warnings: [],
    checks: {},
    noDriveAppInErpField: true,
    signHandoffOnly: true,
    noSignComplete: true,
    noPdf: true,
    noDriveArchive: true,
    noSettlement: true,
    noExternalIntegrationExceptSign: true,
    noRowCreation: true,
    noHeaderAppend: true
  };
}
function erpFieldB06J41_91_95D_finish_(result, logOutput) {
  result.signatureSaveHandoffReady = !!(result.handoff && result.handoff.ready) && result.fatal.length === 0;
  result.ok = result.fatal.length === 0;
  if (logOutput) {
    Logger.log('======================================================');
    Logger.log('[' + FIELD_B06J41_91_95D_BUILD + '] RESULT');
    Logger.log(JSON.stringify(result, null, 2));
    Logger.log('======================================================');
  }
  return result;
}
function erpFieldB06J41_91_95D_normalize_(ctx) {
  ctx = ctx || {};
  return {
    roleCode: String(ctx.roleCode || FIELD_B06J41_91_95_DEFAULT_CTX.roleCode).trim(),
    vendorId: String(ctx.vendorId || FIELD_B06J41_91_95_DEFAULT_CTX.vendorId).trim(),
    eventId: String(ctx.eventId || FIELD_B06J41_91_95_DEFAULT_CTX.eventId).trim(),
    customerId: String(ctx.customerId || FIELD_B06J41_91_95_DEFAULT_CTX.customerId).trim(),
    saleId: String(ctx.saleId || FIELD_B06J41_91_95_DEFAULT_CTX.saleId).trim(),
    contractId: String(ctx.contractId || FIELD_B06J41_91_95_DEFAULT_CTX.contractId).trim(),
    documentId: String(ctx.documentId || FIELD_B06J41_91_95_DEFAULT_CTX.documentId).trim(),
    route: String(ctx.route || 'signatureSaveExecute').trim(),
    userEmail: String(ctx.userEmail || '').trim()
  };
}
function erpFieldB06J41_91_95D_contextSummary_(ctx) {
  return { eventId: ctx.eventId, vendorId: ctx.vendorId, customerId: ctx.customerId, saleId: ctx.saleId, contractId: ctx.contractId, documentId: ctx.documentId, roleCode: ctx.roleCode };
}
function erpFieldB06J41_91_95D_compactPrep_(r) {
  return {
    ok: !!(r && r.ok),
    fatal: (r && r.fatal) || [],
    warnings: (r && r.warnings) || [],
    signatureSaveConfirmPrepReady: !!(r && r.signatureSaveConfirmPrepReady),
    targetRowConfirmed: !!(r && r.targetRowConfirmed),
    documentIdConfirmed: !!(r && r.documentIdConfirmed),
    duplicateGuardReady: !!(r && r.duplicateGuardReady),
    noWrite: !!(r && r.noWrite),
    noRowCreation: !!(r && r.noRowCreation),
    build: r && r.build
  };
}
function erpFieldB06J41_91_95D_compactConfig_(c) {
  return { ok: !!(c && c.ok), fatal: (c && c.fatal) || [], warnings: (c && c.warnings) || [], usedHeaderPair: c && c.usedHeaderPair, setupDbName: c && c.setupDbName, signWebappUrlConfigured: !!(c && c.configMap && c.configMap.SIGN_WEBAPP_URL) };
}
function erpFieldB06J41_91_95D_copy_(obj) {
  return JSON.parse(JSON.stringify(obj || {}));
}


/* ===== SigSaveChk.js ===== */
/**
 * SelfTest for ERP_B06J41_91_95_SIGNATURE_SAVE_EXECUTE_SAFE_UPLOAD
 * 실행 함수 위치: FieldSignatureSaveExecuteCheck.js
 */
function erpB06J41_91_95_signatureSaveExecuteSelfTest() {
  var result = erpFieldB06J41_91_95_run_(FIELD_B06J41_91_95_DEFAULT_CTX, true);
  Logger.log('======================================================');
  Logger.log('[ERP_B06J41_91_95_SIGNATURE_SAVE_EXECUTE_SAFE_UPLOAD] SELFTEST SUMMARY');
  Logger.log(JSON.stringify({
    ok: result.ok,
    build: result.build,
    routeSignatureSaveExecute: 'signatureSaveExecute',
    routeAlias: ['signatureSave','signSaveExecute'],
    context: FIELD_B06J41_91_95_DEFAULT_CTX,
    fatal: result.fatal,
    warnings: result.warnings,
    signatureSaveExecuteReady: result.signatureSaveExecuteReady,
    signatureImageSaveAllowed: result.signatureImageSaveAllowed,
    noSignComplete: result.noSignComplete,
    noPdf: result.noPdf,
    noDriveArchive: result.noDriveArchive,
    noSettlement: result.noSettlement,
    noExternalIntegration: result.noExternalIntegration,
    noRowCreation: result.noRowCreation,
    noHeaderAppend: result.noHeaderAppend,
    message: 'SIGN 서명 이미지 저장 실행 준비 정상 - 실제 저장은 화면 버튼에서만 실행'
  }, null, 2));
  Logger.log('======================================================');
  return result;
}


/* ===== SignEntryChk.js ===== */
/**
 * build: ERP_B06J41_51_55_SIGN_ENTRY_READONLY_SAFE_UPLOAD
 * purpose: B06J41-51~55 SIGN entry READ ONLY self test
 */

function erpB06J41_51_55_signEntryReadOnlySelfTest() {
  var ctx = {
    roleCode: 'VENDOR_MANAGER',
    vendorId: 'VND-20260502202158-505',
    eventId: 'EVT-20260502202016-197',
    customerId: 'CUS-20260504002306-615',
    saleId: 'SALE-20260504005028-991',
    contractId: 'CON-20260504021423-908',
    documentId: 'DOC-20260504175000-946',
    route: 'signEntry'
  };
  var result = erpFieldB06J41_51_55_run_(ctx, false);
  var out = {
    ok: result.ok,
    build: FIELD_B06J41_51_55_BUILD,
    routeEntry: 'signEntry',
    routeAlias: ['signEntryReadOnly', 'signEntryReadonly'],
    context: ctx,
    fatal: result.fatal || [],
    warnings: result.warnings || [],
    signEntryReadOnlyReady: !!result.signEntryReadOnlyReady,
    noSignInputSave: true,
    noSignComplete: true,
    noPdf: true,
    noDriveSave: true,
    noSettlement: true,
    noExternalIntegration: true,
    noWrite: true,
    noRowCreation: true,
    message: result.ok ? 'SIGN 서명 화면 READ ONLY 진입 정상' : 'SIGN 서명 화면 READ ONLY 진입 점검 실패'
  };
  Logger.log('======================================================');
  Logger.log('[' + FIELD_B06J41_51_55_BUILD + '] RESULT');
  Logger.log(JSON.stringify(out, null, 2));
  Logger.log('======================================================');
  return out;
}


/* ===== SignEntryRO.js ===== */
/**
 * build: ERP_B06J41_51_55_SIGN_ENTRY_READONLY_SAFE_UPLOAD
 * module: ERP_FIELD
 * purpose:
 * - SIGN URL_READY 문서 기준 서명 화면 READ ONLY 진입
 * - documentId 기준 문서/계약/판매/고객 연결 정보 표시
 * - 서명 입력/저장/완료/PDF/Drive/정산/외부연동은 계속 차단
 * safety:
 * - READ ONLY only
 * - no sign input save / no sign complete / no PDF / no Drive / no settlement / no external integration
 * - no write / no update / no delete / no row creation
 * - SystemConfig standard header: CONFIG_KEY / VALUE first
 */

var FIELD_B06J41_51_55_BUILD = 'ERP_B06J41_51_55_SIGN_ENTRY_READONLY_SAFE_UPLOAD';
var FIELD_B06J41_51_55_EXPECTED_STATUS = 'SIGN_URL_READY';
var FIELD_B06J41_51_55_DEFAULT_CTX = {
  roleCode: 'VENDOR_MANAGER',
  vendorId: 'VND-20260502202158-505',
  eventId: 'EVT-20260502202016-197',
  customerId: 'CUS-20260504002306-615',
  saleId: 'SALE-20260504005028-991',
  contractId: 'CON-20260504021423-908',
  documentId: 'DOC-20260504175000-946',
  route: 'signEntry'
};

function erpB06J41_51_55_preflight() {
  return erpFieldB06J41_51_55_run_(FIELD_B06J41_51_55_DEFAULT_CTX, true);
}

function erpB06J41_51_55_autoRunSafe() {
  return erpFieldB06J41_51_55_run_(FIELD_B06J41_51_55_DEFAULT_CTX, true);
}

function erpFieldB06J41_51_55_renderSignEntryReadOnlyHtml(ctx) {
  var vm = erpFieldB06J41_51_55_buildVm_(ctx || {});
  var t = HtmlService.createTemplateFromFile('P_SignEntry');
  t.vm = vm;
  t.json = JSON.stringify(vm, null, 2);
  return t.evaluate().setTitle('SIGN 서명 READ ONLY').setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL);
}

function erpFieldB06J41_51_55_buildVm_(ctx) {
  ctx = erpFieldB06J41_51_55_normalize_(ctx || {});
  var result = erpFieldB06J41_51_55_run_(ctx, false);
  result.context = ctx;
  result.page = {
    badge: 'B06J41-51_55 SAFE : SIGN ENTRY READ ONLY',
    title: 'SIGN 문서 서명 화면 READ ONLY',
    subtitle: 'documentId 기준으로 문서/계약/판매 연결 정보를 표시합니다. 서명 입력·저장·완료·PDF·Drive·정산은 아직 차단합니다.',
    roleName: erpFieldB06J41_37_40_roleName_(ctx.roleCode)
  };
  result.urls = erpFieldB06J41_51_55_urls_(ctx, result);
  return result;
}

function erpFieldB06J41_51_55_run_(ctx, logOutput) {
  ctx = erpFieldB06J41_51_55_normalize_(ctx || {});
  var result = erpFieldB06J41_51_55_result_('signEntryReadOnly');
  result.contextSummary = {
    eventId: ctx.eventId,
    vendorId: ctx.vendorId,
    customerId: ctx.customerId,
    saleId: ctx.saleId,
    contractId: ctx.contractId,
    documentId: ctx.documentId
  };
  try {
    if (typeof erpFieldB06J41_46_50_run_ !== 'function') {
      result.fatal.push('B06J41-46~50 검증 엔진 누락: FieldSignUrlVerify.js 필요');
      return erpFieldB06J41_51_55_finish_(result, logOutput);
    }

    var verify = erpFieldB06J41_46_50_run_(ctx, false);
    result.checks.verifyBase = erpFieldB06J41_51_55_compactVerify_(verify);
    result.checks.safety = erpFieldB06J41_51_55_safety_();
    result.document = erpFieldB06J41_51_55_pickDocument_(verify.document);
    result.contract = erpFieldB06J41_51_55_pickContract_(verify.contract);
    result.sale = erpFieldB06J41_51_55_pickSale_(verify.sale);
    result.stored = verify.stored || {};
    result.entry = erpFieldB06J41_51_55_entry_(verify);

    if (!verify.ok) result.fatal = result.fatal.concat((verify.fatal || []).map(function (m) { return 'verifyBase: ' + m; }));
    if ((verify.warnings || []).length) result.warnings = result.warnings.concat((verify.warnings || []).map(function (m) { return 'verifyBase: ' + m; }));
    if (result.entry && result.entry.fatal && result.entry.fatal.length) result.fatal = result.fatal.concat(result.entry.fatal.map(function (m) { return 'entry: ' + m; }));
  } catch (err) {
    result.fatal.push('B06J41-51~55 SIGN entry READ ONLY fatal: ' + (err && err.message ? err.message : err));
  }
  return erpFieldB06J41_51_55_finish_(result, logOutput);
}

function erpFieldB06J41_51_55_entry_(verify) {
  var fatal = [];
  var s = verify.stored || {};
  var d = verify.document || {};
  var c = verify.contract || {};
  var sale = verify.sale || {};

  if (!d.found) fatal.push('SIGN_Documents 문서 없음');
  if (!c.found) fatal.push('연결 계약 없음');
  if (!sale.found) fatal.push('연결 판매 원전표 없음');
  if (String(s.documentSignStatus || '') !== FIELD_B06J41_51_55_EXPECTED_STATUS) fatal.push('문서 signStatus가 SIGN_URL_READY가 아님');
  if (String(s.contractSignStatus || '') !== FIELD_B06J41_51_55_EXPECTED_STATUS) fatal.push('계약 signStatus가 SIGN_URL_READY가 아님');
  if (!String(s.documentSignUrl || '').trim()) fatal.push('서명 URL 없음');
  if (!String(s.documentQrUrl || '').trim()) fatal.push('QR URL 없음');

  return {
    ready: fatal.length === 0,
    fatal: fatal,
    mode: 'READ_ONLY',
    canShowSignaturePad: true,
    signatureInputDisabled: true,
    signSaveBlocked: true,
    signCompleteBlocked: true,
    pdfStillBlocked: true,
    driveSaveBlocked: true,
    settlementStillBlocked: true,
    externalIntegrationStillBlocked: true,
    writeBlocked: true,
    rowCreationBlocked: true,
    deleteBlocked: true,
    message: fatal.length ? '서명 READ ONLY 진입 차단' : '서명 READ ONLY 진입 가능'
  };
}

function erpFieldB06J41_51_55_pickDocument_(doc) {
  doc = doc || {};
  var r = doc.raw || {};
  return {
    found: !!doc.found,
    row: doc.row || '',
    documentId: doc.documentId || r.documentId || '',
    documentNo: r.documentNo || '',
    documentType: r.documentType || '',
    title: r.title || '',
    status: doc.status || r.status || '',
    signStatus: doc.signStatus || r.signStatus || '',
    pdfStatus: doc.pdfStatus || r.pdfStatus || '',
    eventId: doc.eventId || r.eventId || '',
    vendorId: doc.vendorId || r.vendorId || '',
    customerId: doc.customerId || r.customerId || '',
    saleId: doc.saleId || r.saleId || '',
    contractId: doc.contractId || r.contractId || '',
    signMethod: r.signMethod || '',
    templateCode: r.templateCode || '',
    signedAt: r.signedAt || '',
    signedBy: r.signedBy || ''
  };
}

function erpFieldB06J41_51_55_pickContract_(contract) {
  contract = contract || {};
  var r = contract.raw || {};
  return {
    found: !!contract.found,
    row: contract.row || '',
    contractId: contract.contractId || r.contractId || '',
    saleId: contract.saleId || r.saleId || '',
    customerId: contract.customerId || r.customerId || '',
    eventId: contract.eventId || r.eventId || '',
    vendorId: contract.vendorId || r.vendorId || '',
    documentId: contract.documentId || r.documentId || '',
    status: contract.status || r.status || '',
    signStatus: contract.signStatus || r.signStatus || '',
    pdfStatus: contract.pdfStatus || r.pdfStatus || '',
    contractDate: r.contractDate || '',
    totalAmount: r.totalAmount || r.contractAmount || ''
  };
}

function erpFieldB06J41_51_55_pickSale_(sale) {
  sale = sale || {};
  var r = sale.raw || {};
  return {
    found: !!sale.found,
    row: sale.row || '',
    saleId: sale.saleId || r.saleId || '',
    customerId: sale.customerId || r.customerId || '',
    eventId: sale.eventId || r.eventId || '',
    vendorId: sale.vendorId || r.vendorId || '',
    contractId: sale.contractId || r.contractId || '',
    status: sale.status || r.status || '',
    productName: r.productName || r.itemName || r.product || '',
    quantity: r.quantity || r.qty || '',
    unitPrice: r.unitPrice || '',
    totalAmount: r.totalAmount || r.amount || '',
    paymentStructure: r.paymentStructure || '',
    paymentMethod: r.paymentMethod || ''
  };
}

function erpFieldB06J41_51_55_compactVerify_(verify) {
  verify = verify || {};
  return {
    ok: !!verify.ok,
    fatal: verify.fatal || [],
    warnings: verify.warnings || [],
    documentFound: !!(verify.document && verify.document.found),
    contractFound: !!(verify.contract && verify.contract.found),
    saleFound: !!(verify.sale && verify.sale.found),
    signEntryReady: !!(verify.verify && verify.verify.signEntryReady),
    build: verify.build || ''
  };
}

function erpFieldB06J41_51_55_safety_() {
  return {
    readOnly: true,
    noWrite: true,
    noSignInputSave: true,
    noSignComplete: true,
    noPdfCreate: true,
    noDriveSave: true,
    noSettlementExecution: true,
    noExternalIntegration: true,
    noDelete: true,
    noRowCreation: true,
    noStatusChange: true,
    signEntryReadOnlyOnly: true,
    systemConfigHeaderStandard: 'CONFIG_KEY/VALUE first'
  };
}

function erpFieldB06J41_51_55_urls_(ctx, result) {
  var configMap = (result.checks && result.checks.verifyBase && result.checks.verifyBase.configMap) || {};
  // Prefer the persisted SIGN URL from B06J41-41~45. The ERP_FIELD fallback is deliberately read-only.
  var verifyBase = (result.checks && result.checks.verifyBase) || {};
  var base = '';
  try {
    var cfg = erpFieldB06J41_37_40_loadConfig_();
    base = String((cfg.configMap || {}).ERP_FIELD_WEBAPP_URL || '').trim();
  } catch (ignore) {}
  var q = 'roleCode=' + encodeURIComponent(ctx.roleCode) + '&vendorId=' + encodeURIComponent(ctx.vendorId) + '&eventId=' + encodeURIComponent(ctx.eventId) + '&saleId=' + encodeURIComponent(ctx.saleId || (result.sale && result.sale.saleId) || '') + '&contractId=' + encodeURIComponent(ctx.contractId || (result.contract && result.contract.contractId) || '') + '&customerId=' + encodeURIComponent(ctx.customerId || (result.document && result.document.customerId) || '') + '&documentId=' + encodeURIComponent(ctx.documentId || (result.document && result.document.documentId) || '');
  return {
    signEntryReadOnly: base ? base + '?' + q + '&route=signEntry' : '',
    signUrlVerify: base ? base + '?' + q + '&route=signUrlVerify' : '',
    signDocumentDetail: base ? base + '?' + q + '&route=signDocumentDetail' : '',
    contractDetail: base ? base + '?' + q + '&route=contractDetail' : '',
    signUrl: String((result.stored && result.stored.documentSignUrl) || '').trim(),
    qrUrl: String((result.stored && result.stored.documentQrUrl) || '').trim()
  };
}

function erpFieldB06J41_51_55_result_(label) {
  return { ok: true, label: label, build: FIELD_B06J41_51_55_BUILD, moduleCode: 'ERP_FIELD', checkedAt: new Date().toISOString(), fatal: [], warnings: [], checks: {}, document: {}, contract: {}, sale: {}, stored: {}, entry: {} };
}

function erpFieldB06J41_51_55_finish_(result, logOutput) {
  Object.keys(result.checks || {}).forEach(function (k) {
    var c = result.checks[k];
    if (c && c.fatal && c.fatal.length) result.fatal = result.fatal.concat(c.fatal.map(function (m) { return k + ': ' + m; }));
    if (c && c.warnings && c.warnings.length) result.warnings = result.warnings.concat(c.warnings.map(function (m) { return k + ': ' + m; }));
  });
  result.ok = result.fatal.length === 0;
  result.signEntryReadOnlyReady = !!(result.entry && result.entry.ready) && result.ok;
  result.noSignInputSave = true;
  result.noSignComplete = true;
  result.noPdf = true;
  result.noDriveSave = true;
  result.noSettlement = true;
  result.noExternalIntegration = true;
  result.noWrite = true;
  result.noRowCreation = true;
  if (logOutput) {
    Logger.log('======================================================');
    Logger.log('[' + FIELD_B06J41_51_55_BUILD + '] RESULT');
    Logger.log(JSON.stringify(result, null, 2));
    Logger.log('======================================================');
  }
  return result;
}

function erpFieldB06J41_51_55_normalize_(ctx) {
  ctx = erpFieldB06J41_46_50_normalize_(ctx || {});
  ctx.route = String((arguments[0] || {}).route || ctx.route || 'signEntry').trim();
  return ctx;
}


/* ===== SignEntryVer.js ===== */
/**
 * build: ERP_B06J41_46_50_SIGN_URL_VERIFY_AND_SIGN_ENTRY_SAFE_UPLOAD
 * module: ERP_FIELD
 * purpose: deployment self test for signUrlVerify / signEntryReady route and safety boundaries
 */
function erpB06J41_46_50_signEntryVerifySelfTest() {
  var result = erpFieldB06J41_46_50_run_(FIELD_B06J41_46_50_DEFAULT_CTX, true);
  var routeOk = erpFieldB06J40_04_12_guardContext_({
    roleCode: FIELD_B06J41_46_50_DEFAULT_CTX.roleCode,
    vendorId: FIELD_B06J41_46_50_DEFAULT_CTX.vendorId,
    eventId: FIELD_B06J41_46_50_DEFAULT_CTX.eventId,
    route: 'signUrlVerify'
  });
  var routeOk2 = erpFieldB06J40_04_12_guardContext_({
    roleCode: FIELD_B06J41_46_50_DEFAULT_CTX.roleCode,
    vendorId: FIELD_B06J41_46_50_DEFAULT_CTX.vendorId,
    eventId: FIELD_B06J41_46_50_DEFAULT_CTX.eventId,
    route: 'signEntryReady'
  });
  var out = {
    ok: result.ok && routeOk.ok && routeOk2.ok,
    build: FIELD_B06J41_46_50_BUILD,
    routeVerify: 'signUrlVerify',
    routeEntryReady: 'signEntryReady',
    context: FIELD_B06J41_46_50_DEFAULT_CTX,
    fatal: [].concat(result.fatal || [], routeOk.fatal || [], routeOk2.fatal || []),
    warnings: result.warnings || [],
    signEntryReady: result.verify && result.verify.signEntryReady === true,
    noSignComplete: true,
    noPdf: true,
    noDriveSave: true,
    noSettlement: true,
    noExternalIntegration: true,
    noWrite: true,
    noRowCreation: true,
    message: result.ok ? 'SIGN URL 저장 검증 및 서명 진입 준비 정상' : 'SIGN URL 저장 검증 확인 필요'
  };
  Logger.log('======================================================');
  Logger.log('[' + FIELD_B06J41_46_50_BUILD + '] RESULT');
  Logger.log(JSON.stringify(out, null, 2));
  Logger.log('======================================================');
  return out;
}


/* ===== SignInput.js ===== */
/**
 * build: ERP_B06J41_56_60_SIGN_INPUT_UI_PRECHECK_SAFE_UPLOAD
 * module: ERP_FIELD
 * purpose:
 * - SIGN 서명 입력 UI 표시 전 사전검증
 * - documentId 기준 문서/계약/판매 연결 및 SIGN_URL_READY 상태 확인
 * - 서명 패드 UI 후보를 표시하되 실제 서명 입력 저장/완료/PDF/Drive/정산/외부연동은 차단
 * safety:
 * - PRECHECK only
 * - no sign input save / no sign complete / no PDF / no Drive / no settlement / no external integration
 * - no write / no update / no delete / no row creation
 * - SystemConfig standard header: CONFIG_KEY / VALUE first
 */

var FIELD_B06J41_56_60_BUILD = 'ERP_B06J41_56_60_SIGN_INPUT_UI_PRECHECK_SAFE_UPLOAD';
var FIELD_B06J41_56_60_EXPECTED_STATUS = 'SIGN_URL_READY';
var FIELD_B06J41_56_60_DEFAULT_CTX = {
  roleCode: 'VENDOR_MANAGER',
  vendorId: 'VND-20260502202158-505',
  eventId: 'EVT-20260502202016-197',
  customerId: 'CUS-20260504002306-615',
  saleId: 'SALE-20260504005028-991',
  contractId: 'CON-20260504021423-908',
  documentId: 'DOC-20260504175000-946',
  route: 'signInputPrecheck'
};

function erpB06J41_56_60_preflight() {
  return erpFieldB06J41_56_60_run_(FIELD_B06J41_56_60_DEFAULT_CTX, true);
}

function erpB06J41_56_60_autoRunSafe() {
  return erpFieldB06J41_56_60_run_(FIELD_B06J41_56_60_DEFAULT_CTX, true);
}

function erpFieldB06J41_56_60_renderSignInputPrecheckHtml(ctx) {
  var vm = erpFieldB06J41_56_60_buildVm_(ctx || {});
  var t = HtmlService.createTemplateFromFile('P_SignInput');
  t.vm = vm;
  t.json = JSON.stringify(vm, null, 2);
  return t.evaluate().setTitle('SIGN 서명 입력 UI 프리체크').setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL);
}

function erpFieldB06J41_56_60_buildVm_(ctx) {
  ctx = erpFieldB06J41_56_60_normalize_(ctx || {});
  var result = erpFieldB06J41_56_60_run_(ctx, false);
  result.context = ctx;
  result.page = {
    badge: 'B06J41-56_60 SAFE : SIGN INPUT UI PRECHECK',
    title: 'SIGN 서명 입력 UI 프리체크',
    subtitle: '서명 패드 활성화 전 필수 연결과 문서 정보를 확인합니다. 실제 서명 저장·완료·PDF·Drive·정산은 아직 차단합니다.',
    roleName: erpFieldB06J41_37_40_roleName_(ctx.roleCode)
  };
  result.urls = erpFieldB06J41_56_60_urls_(ctx, result);
  return result;
}

function erpFieldB06J41_56_60_run_(ctx, logOutput) {
  ctx = erpFieldB06J41_56_60_normalize_(ctx || {});
  var result = erpFieldB06J41_56_60_result_('signInputPrecheck');
  result.contextSummary = {
    eventId: ctx.eventId,
    vendorId: ctx.vendorId,
    customerId: ctx.customerId,
    saleId: ctx.saleId,
    contractId: ctx.contractId,
    documentId: ctx.documentId
  };
  try {
    if (typeof erpFieldB06J41_51_55_run_ !== 'function') {
      result.fatal.push('B06J41-51~55 READ ONLY 엔진 누락: FieldSignEntryReadOnly.js 필요');
      return erpFieldB06J41_56_60_finish_(result, logOutput);
    }

    var base = erpFieldB06J41_51_55_run_(ctx, false);
    result.checks.readOnlyBase = erpFieldB06J41_56_60_compactReadOnly_(base);
    result.checks.safety = erpFieldB06J41_56_60_safety_();
    result.document = erpFieldB06J41_56_60_copy_(base.document || {});
    result.contract = erpFieldB06J41_56_60_copy_(base.contract || {});
    result.sale = erpFieldB06J41_56_60_copy_(base.sale || {});
    result.stored = erpFieldB06J41_56_60_copy_(base.stored || {});
    result.uiPrecheck = erpFieldB06J41_56_60_precheck_(base);

    if (!base.ok) result.fatal = result.fatal.concat((base.fatal || []).map(function (m) { return 'readOnlyBase: ' + m; }));
    if ((base.warnings || []).length) result.warnings = result.warnings.concat((base.warnings || []).map(function (m) { return 'readOnlyBase: ' + m; }));
    if (result.uiPrecheck && result.uiPrecheck.fatal && result.uiPrecheck.fatal.length) result.fatal = result.fatal.concat(result.uiPrecheck.fatal.map(function (m) { return 'uiPrecheck: ' + m; }));
  } catch (err) {
    result.fatal.push('B06J41-56~60 SIGN input UI precheck fatal: ' + (err && err.message ? err.message : err));
  }
  return erpFieldB06J41_56_60_finish_(result, logOutput);
}

function erpFieldB06J41_56_60_precheck_(base) {
  base = base || {};
  var fatal = [];
  var d = base.document || {};
  var c = base.contract || {};
  var s = base.sale || {};
  var stored = base.stored || {};

  if (!base.signEntryReadOnlyReady) fatal.push('READ ONLY 서명 진입 기준 미통과');
  if (!d.found) fatal.push('SIGN_Documents 문서 없음');
  if (!c.found) fatal.push('연결 계약 없음');
  if (!s.found) fatal.push('연결 판매 원전표 없음');
  if (String(d.signStatus || '') !== FIELD_B06J41_56_60_EXPECTED_STATUS) fatal.push('문서 signStatus가 SIGN_URL_READY가 아님');
  if (String(c.signStatus || '') !== FIELD_B06J41_56_60_EXPECTED_STATUS) fatal.push('계약 signStatus가 SIGN_URL_READY가 아님');
  if (!String(stored.documentSignUrl || '').trim()) fatal.push('저장된 signUrl 없음');
  if (!String(stored.documentQrUrl || '').trim()) fatal.push('저장된 qrUrl 없음');

  return {
    ready: fatal.length === 0,
    fatal: fatal,
    mode: 'PRECHECK_ONLY',
    signaturePadCandidateVisible: true,
    signaturePadActive: false,
    signaturePadSaveBlocked: true,
    requiredDocumentInfoOk: !!(d.found && d.documentId && d.documentType),
    requiredLinkInfoOk: !!(d.found && c.found && s.found),
    requiredStatusOk: String(d.signStatus || '') === FIELD_B06J41_56_60_EXPECTED_STATUS && String(c.signStatus || '') === FIELD_B06J41_56_60_EXPECTED_STATUS,
    requiredUrlOk: !!(String(stored.documentSignUrl || '').trim() && String(stored.documentQrUrl || '').trim()),
    consentPreviewVisible: true,
    consentSaveBlocked: true,
    signCompleteBlocked: true,
    pdfStillBlocked: true,
    driveSaveBlocked: true,
    settlementStillBlocked: true,
    externalIntegrationStillBlocked: true,
    writeBlocked: true,
    rowCreationBlocked: true,
    message: fatal.length ? '서명 입력 UI 프리체크 실패' : '서명 입력 UI 표시 준비 완료'
  };
}

function erpFieldB06J41_56_60_compactReadOnly_(base) {
  base = base || {};
  return {
    ok: !!base.ok,
    fatal: base.fatal || [],
    warnings: base.warnings || [],
    documentFound: !!(base.document && base.document.found),
    contractFound: !!(base.contract && base.contract.found),
    saleFound: !!(base.sale && base.sale.found),
    signEntryReadOnlyReady: !!base.signEntryReadOnlyReady,
    noSignInputSave: !!base.noSignInputSave,
    noSignComplete: !!base.noSignComplete,
    build: base.build || ''
  };
}

function erpFieldB06J41_56_60_safety_() {
  return {
    precheckOnly: true,
    noWrite: true,
    noSignInputSave: true,
    noSignComplete: true,
    noPdfCreate: true,
    noDriveSave: true,
    noSettlementExecution: true,
    noExternalIntegration: true,
    noDelete: true,
    noRowCreation: true,
    noStatusChange: true,
    systemConfigHeaderStandard: 'CONFIG_KEY/VALUE first'
  };
}

function erpFieldB06J41_56_60_urls_(ctx, result) {
  var base = '';
  try {
    var cfg = erpFieldB06J41_37_40_loadConfig_();
    base = String((cfg.configMap || {}).ERP_FIELD_WEBAPP_URL || '').trim();
  } catch (ignore) {}
  var q = 'roleCode=' + encodeURIComponent(ctx.roleCode) + '&vendorId=' + encodeURIComponent(ctx.vendorId) + '&eventId=' + encodeURIComponent(ctx.eventId) + '&saleId=' + encodeURIComponent(ctx.saleId || '') + '&contractId=' + encodeURIComponent(ctx.contractId || '') + '&customerId=' + encodeURIComponent(ctx.customerId || '') + '&documentId=' + encodeURIComponent(ctx.documentId || '');
  return {
    signInputPrecheck: base ? base + '?' + q + '&route=signInputPrecheck' : '',
    signEntryReadOnly: base ? base + '?' + q + '&route=signEntry' : '',
    signUrlVerify: base ? base + '?' + q + '&route=signUrlVerify' : '',
    signDocumentDetail: base ? base + '?' + q + '&route=signDocumentDetail' : '',
    signUrl: String((result.stored && result.stored.documentSignUrl) || '').trim(),
    qrUrl: String((result.stored && result.stored.documentQrUrl) || '').trim()
  };
}

function erpFieldB06J41_56_60_result_(label) {
  return { ok: true, label: label, build: FIELD_B06J41_56_60_BUILD, moduleCode: 'ERP_FIELD', checkedAt: new Date().toISOString(), fatal: [], warnings: [], checks: {}, document: {}, contract: {}, sale: {}, stored: {}, uiPrecheck: {} };
}

function erpFieldB06J41_56_60_finish_(result, logOutput) {
  Object.keys(result.checks || {}).forEach(function (k) {
    var c = result.checks[k];
    if (c && c.fatal && c.fatal.length) result.fatal = result.fatal.concat(c.fatal.map(function (m) { return k + ': ' + m; }));
    if (c && c.warnings && c.warnings.length) result.warnings = result.warnings.concat(c.warnings.map(function (m) { return k + ': ' + m; }));
  });
  result.ok = result.fatal.length === 0;
  result.signInputUiPrecheckReady = !!(result.uiPrecheck && result.uiPrecheck.ready) && result.ok;
  result.noSignInputSave = true;
  result.noSignComplete = true;
  result.noPdf = true;
  result.noDriveSave = true;
  result.noSettlement = true;
  result.noExternalIntegration = true;
  result.noWrite = true;
  result.noRowCreation = true;
  if (logOutput) {
    Logger.log('======================================================');
    Logger.log('[' + FIELD_B06J41_56_60_BUILD + '] RESULT');
    Logger.log(JSON.stringify(result, null, 2));
    Logger.log('======================================================');
  }
  return result;
}

function erpFieldB06J41_56_60_normalize_(ctx) {
  ctx = erpFieldB06J41_51_55_normalize_(ctx || {});
  ctx.route = String((arguments[0] || {}).route || ctx.route || 'signInputPrecheck').trim();
  return ctx;
}

function erpFieldB06J41_56_60_copy_(obj) {
  var out = {};
  obj = obj || {};
  Object.keys(obj).forEach(function (k) { out[k] = obj[k]; });
  return out;
}


/* ===== SignInputChk.js ===== */
/**
 * build: ERP_B06J41_56_60_SIGN_INPUT_UI_PRECHECK_SAFE_UPLOAD
 * purpose: B06J41-56~60 SIGN input UI precheck self test
 */

function erpB06J41_56_60_signInputUiPrecheckSelfTest() {
  var ctx = {
    roleCode: 'VENDOR_MANAGER',
    vendorId: 'VND-20260502202158-505',
    eventId: 'EVT-20260502202016-197',
    customerId: 'CUS-20260504002306-615',
    saleId: 'SALE-20260504005028-991',
    contractId: 'CON-20260504021423-908',
    documentId: 'DOC-20260504175000-946',
    route: 'signInputPrecheck'
  };
  var result = erpFieldB06J41_56_60_run_(ctx, false);
  var out = {
    ok: result.ok,
    build: FIELD_B06J41_56_60_BUILD,
    routeInputPrecheck: 'signInputPrecheck',
    routeAlias: ['signInputReady'],
    context: ctx,
    fatal: result.fatal || [],
    warnings: result.warnings || [],
    signInputUiPrecheckReady: !!result.signInputUiPrecheckReady,
    signaturePadCandidateVisible: !!(result.uiPrecheck && result.uiPrecheck.signaturePadCandidateVisible),
    signaturePadActive: false,
    noSignInputSave: true,
    noSignComplete: true,
    noPdf: true,
    noDriveSave: true,
    noSettlement: true,
    noExternalIntegration: true,
    noWrite: true,
    noRowCreation: true,
    message: result.ok ? 'SIGN 서명 입력 UI 프리체크 정상' : 'SIGN 서명 입력 UI 프리체크 실패'
  };
  Logger.log('======================================================');
  Logger.log('[' + FIELD_B06J41_56_60_BUILD + '] RESULT');
  Logger.log(JSON.stringify(out, null, 2));
  Logger.log('======================================================');
  return out;
}


/* ===== SignStatus.js ===== */
/**
 * build: ERP_SIGN_B06J41_001_080_DOCUMENT_REOPEN_SETTLEMENT_CONTROL_SAFE_UPLOAD
 * module: ERP_FIELD
 * purpose:
 * - Sales / Contracts / SIGN_Documents 상태를 FIELD 실무 화면에서 조회 표시
 * - 재오픈 / 정산 / 외부연동 / 지급·환수·차감 실행은 차단 유지
 * safety:
 * - READ ONLY only
 * - no sheet write / no append / no update / no delete
 * - no header auto-create
 * - no settlement execution
 * - no external integration
 */

var ERP_SIGN_B06J41_001_080_BUILD = 'ERP_SIGN_B06J41_001_080_DOCUMENT_REOPEN_SETTLEMENT_CONTROL_SAFE_UPLOAD';
var ERP_SIGN_B06J41_001_080_SETUP_DB_ID = '17VMSpgSZCvIrUlgcw8yCNcnl8WQWo2IcRf5tDCcuJGM';
var ERP_SIGN_B06J41_001_080_CONFIG_SHEET_NAME = 'SystemConfig';

function erpFieldB06J41_001_080_renderSignStatusLinkHtml(ctx) {
  var vm = erpFieldB06J41_001_080_buildViewModel_(ctx || {});
  var tpl = HtmlService.createTemplateFromFile('P_SignStatus');
  tpl.vm = vm;
  return tpl.evaluate()
    .setTitle('ERP FIELD SIGN 상태 연계')
    .setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL);
}

function erpFieldB06J41_001_080_buildViewModel_(ctx) {
  ctx = erpFieldB06J41_001_080_normalizeCtx_(ctx || {});
  var vm = {
    ok: true,
    build: ERP_SIGN_B06J41_001_080_BUILD,
    mode: 'READ_ONLY_SAFE',
    pageTitle: 'SIGN 문서 상태',
    pageSubtitle: '판매 / 계약 / 문서 상태 조회 전용. 실제 재오픈·정산·외부연동은 차단됩니다.',
    ctx: ctx,
    fatal: [],
    warnings: [],
    sheets: {},
    sale: null,
    contract: null,
    document: null,
    queue: null,
    control: null,
    statusCards: [],
    links: [],
    locks: [],
    actionBlocks: erpFieldB06J41_001_080_actionBlocks_(),
    tests: {}
  };

  var config = erpFieldB06J41_001_080_readSystemConfig_();
  vm.tests.systemConfig = erpFieldB06J41_001_080_pickMeta_(config);
  if (!config.ok) return erpFieldB06J41_001_080_failVm_(vm, config.fatal);

  var master = erpFieldB06J41_001_080_openMaster_(config.configMap || {});
  vm.tests.master = erpFieldB06J41_001_080_pickMeta_(master);
  if (!master.ok) return erpFieldB06J41_001_080_failVm_(vm, master.fatal);

  var ss = master.spreadsheet;
  var salesPack = erpFieldB06J41_001_080_readSheet_(ss, ['ERP_판매관리','ERP_Sales','Sales']);
  var contractPack = erpFieldB06J41_001_080_readSheet_(ss, ['ERP_계약관리','ERP_Contracts','Contracts']);
  var signPack = erpFieldB06J41_001_080_readSheet_(ss, ['SIGN_Documents','SIGN_문서관리','ERP_SIGN_Documents']);
  var queuePack = erpFieldB06J41_001_080_readSheet_(ss, ['SIGN_SettlementHandoffQueue','ERP_SettlementHandoffQueue','SettlementHandoffQueue']);
  var controlPack = erpFieldB06J41_001_080_readSheet_(ss, ['CONTROL_CheckReport','CheckReport','CONTROL_DeployLog','DeployLog']);

  vm.sheets.sales = salesPack.meta;
  vm.sheets.contracts = contractPack.meta;
  vm.sheets.signDocuments = signPack.meta;
  vm.sheets.settlementQueue = queuePack.meta;
  vm.sheets.control = controlPack.meta;

  if (!salesPack.ok) vm.warnings.push('Sales 시트 조회 불가: ' + salesPack.fatal.join(', '));
  if (!contractPack.ok) vm.warnings.push('Contracts 시트 조회 불가: ' + contractPack.fatal.join(', '));
  if (!signPack.ok) vm.warnings.push('SIGN_Documents 시트 조회 불가: ' + signPack.fatal.join(', '));

  vm.sale = salesPack.ok ? erpFieldB06J41_001_080_findSale_(salesPack, ctx) : null;
  vm.contract = contractPack.ok ? erpFieldB06J41_001_080_findContract_(contractPack, ctx, vm.sale) : null;
  vm.document = signPack.ok ? erpFieldB06J41_001_080_findDocument_(signPack, ctx, vm.sale, vm.contract) : null;
  vm.queue = queuePack.ok ? erpFieldB06J41_001_080_findQueue_(queuePack, ctx, vm.sale, vm.contract, vm.document) : null;
  vm.control = controlPack.ok ? erpFieldB06J41_001_080_latestRow_(controlPack) : null;

  vm = erpFieldB06J41_001_080_applyVendorScope_(vm, ctx);
  vm.statusCards = erpFieldB06J41_001_080_buildStatusCards_(vm);
  vm.links = erpFieldB06J41_001_080_buildLinks_(vm);
  vm.locks = erpFieldB06J41_001_080_buildLocks_(vm);
  vm.emptyMessage = erpFieldB06J41_001_080_emptyMessage_(vm);
  vm.tests.safety = erpFieldB06J41_001_080_safetyCheck_();
  vm.ok = vm.fatal.length === 0;
  return vm;
}

function erpFieldB06J41_001_080_normalizeCtx_(ctx) {
  return {
    route: String(ctx.route || 'signStatusLink').trim(),
    roleCode: String(ctx.roleCode || 'VIEWER').trim(),
    vendorId: String(ctx.vendorId || '').trim(),
    eventId: String(ctx.eventId || '').trim(),
    customerId: String(ctx.customerId || '').trim(),
    saleId: String(ctx.saleId || '').trim(),
    contractId: String(ctx.contractId || '').trim(),
    documentId: String(ctx.documentId || '').trim(),
    userEmail: String(ctx.userEmail || '').trim(),
    scopeType: 'VENDOR_BRANCH_USER_GROUP'
  };
}

function erpFieldB06J41_001_080_readSystemConfig_() {
  var out = { ok: true, fatal: [], warnings: [], setupDbId: ERP_SIGN_B06J41_001_080_SETUP_DB_ID, configSheetName: ERP_SIGN_B06J41_001_080_CONFIG_SHEET_NAME, usedHeaderPair: '', configMap: {}, keyCount: 0 };
  try {
    var ss = SpreadsheetApp.openById(ERP_SIGN_B06J41_001_080_SETUP_DB_ID);
    var sh = ss.getSheetByName(ERP_SIGN_B06J41_001_080_CONFIG_SHEET_NAME);
    if (!sh) return erpFieldB06J41_001_080_fail_(out, ['SystemConfig 시트 없음']);
    var values = sh.getDataRange().getValues();
    if (!values || values.length < 2) return erpFieldB06J41_001_080_fail_(out, ['SystemConfig 데이터 없음']);
    var headers = values[0].map(function(h){ return String(h || '').trim(); });
    var hm = erpFieldB06J41_001_080_headerMap_(headers);
    var keyCol = hm.CONFIG_KEY;
    var valCol = hm.VALUE;
    if (keyCol == null || valCol == null) {
      keyCol = hm.configKey != null ? hm.configKey : hm.key;
      valCol = hm.configValue != null ? hm.configValue : hm.value;
      out.warnings.push('SystemConfig 표준 헤더 CONFIG_KEY/VALUE 외 호환 헤더 사용');
    } else {
      out.usedHeaderPair = 'CONFIG_KEY/VALUE';
    }
    if (keyCol == null || valCol == null) return erpFieldB06J41_001_080_fail_(out, ['SystemConfig 키/값 헤더 없음']);
    for (var r = 1; r < values.length; r++) {
      var k = String(values[r][keyCol] || '').trim();
      if (!k) continue;
      out.configMap[k] = values[r][valCol];
    }
    out.keyCount = Object.keys(out.configMap).length;
    return out;
  } catch (err) {
    return erpFieldB06J41_001_080_fail_(out, ['SystemConfig 읽기 실패: ' + erpFieldB06J41_001_080_err_(err)]);
  }
}

function erpFieldB06J41_001_080_openMaster_(configMap) {
  var out = { ok: true, fatal: [], warnings: [], usedKey: '', masterId: '', spreadsheet: null, masterName: 'FEELHAUS_DB_MASTER' };
  try {
    var keys = ['FEELHAUS_DB_MASTER_ID', 'FEELHAUS_DB_MASTER', 'MASTER_DB_ID', 'DB_MASTER_ID', 'SPREADSHEET_ID', 'CUSTOMER_DB_SPREADSHEET_ID'];
    for (var i = 0; i < keys.length; i++) {
      var v = String(configMap[keys[i]] || '').trim();
      if (v) { out.masterId = v; out.usedKey = keys[i]; break; }
    }
    if (!out.masterId) return erpFieldB06J41_001_080_fail_(out, ['FEELHAUS_DB_MASTER ID 설정 없음']);
    out.spreadsheet = SpreadsheetApp.openById(out.masterId);
    out.spreadsheetName = out.spreadsheet.getName();
    return out;
  } catch (err) {
    return erpFieldB06J41_001_080_fail_(out, ['FEELHAUS_DB_MASTER 연결 실패: ' + erpFieldB06J41_001_080_err_(err)]);
  }
}

function erpFieldB06J41_001_080_readSheet_(ss, names) {
  var out = { ok: true, fatal: [], warnings: [], meta: { ok: false, sheetName: '', requested: names || [], lastRow: 0, lastColumn: 0, headers: [], missingHeaders: [] }, headers: [], hm: {}, rows: [] };
  try {
    var sh = null;
    for (var i = 0; i < names.length; i++) {
      sh = ss.getSheetByName(names[i]);
      if (sh) break;
    }
    if (!sh) return erpFieldB06J41_001_080_fail_(out, ['시트 없음: ' + names.join(' / ')]);
    out.meta.sheetName = sh.getName();
    out.meta.lastRow = sh.getLastRow();
    out.meta.lastColumn = sh.getLastColumn();
    if (sh.getLastRow() < 1 || sh.getLastColumn() < 1) return erpFieldB06J41_001_080_fail_(out, ['시트 헤더 없음: ' + sh.getName()]);
    var values = sh.getDataRange().getValues();
    out.headers = values[0].map(function(h){ return String(h || '').trim(); });
    out.hm = erpFieldB06J41_001_080_headerMap_(out.headers);
    out.meta.headers = out.headers;
    for (var r = 1; r < values.length; r++) {
      var row = erpFieldB06J41_001_080_rowObject_(out.headers, values[r]);
      row.__rowNumber = r + 1;
      out.rows.push(row);
    }
    out.meta.ok = true;
    return out;
  } catch (err) {
    return erpFieldB06J41_001_080_fail_(out, ['시트 읽기 실패: ' + erpFieldB06J41_001_080_err_(err)]);
  }
}

function erpFieldB06J41_001_080_findSale_(pack, ctx) {
  if (ctx.saleId) return erpFieldB06J41_001_080_first_(pack.rows, function(r){ return erpFieldB06J41_001_080_eq_(r.saleId, ctx.saleId); });
  return erpFieldB06J41_001_080_first_(pack.rows, function(r){
    return (!ctx.customerId || erpFieldB06J41_001_080_eq_(r.customerId, ctx.customerId)) &&
           (!ctx.eventId || erpFieldB06J41_001_080_eq_(r.eventId, ctx.eventId)) &&
           (!ctx.vendorId || erpFieldB06J41_001_080_eq_(r.vendorId, ctx.vendorId));
  });
}

function erpFieldB06J41_001_080_findContract_(pack, ctx, sale) {
  if (ctx.contractId) return erpFieldB06J41_001_080_first_(pack.rows, function(r){ return erpFieldB06J41_001_080_eq_(r.contractId, ctx.contractId); });
  var saleId = ctx.saleId || (sale && sale.saleId) || '';
  if (saleId) return erpFieldB06J41_001_080_first_(pack.rows, function(r){ return erpFieldB06J41_001_080_eq_(r.saleId, saleId); });
  return erpFieldB06J41_001_080_first_(pack.rows, function(r){
    return (!ctx.customerId || erpFieldB06J41_001_080_eq_(r.customerId, ctx.customerId)) &&
           (!ctx.eventId || erpFieldB06J41_001_080_eq_(r.eventId, ctx.eventId)) &&
           (!ctx.vendorId || erpFieldB06J41_001_080_eq_(r.vendorId, ctx.vendorId));
  });
}

function erpFieldB06J41_001_080_findDocument_(pack, ctx, sale, contract) {
  if (ctx.documentId) return erpFieldB06J41_001_080_first_(pack.rows, function(r){ return erpFieldB06J41_001_080_eq_(r.documentId, ctx.documentId); });
  var contractId = ctx.contractId || (contract && contract.contractId) || '';
  if (contractId) return erpFieldB06J41_001_080_first_(pack.rows, function(r){ return erpFieldB06J41_001_080_eq_(r.contractId, contractId); });
  var saleId = ctx.saleId || (sale && sale.saleId) || '';
  if (saleId) return erpFieldB06J41_001_080_first_(pack.rows, function(r){ return erpFieldB06J41_001_080_eq_(r.saleId, saleId); });
  return erpFieldB06J41_001_080_first_(pack.rows, function(r){
    return (!ctx.customerId || erpFieldB06J41_001_080_eq_(r.customerId, ctx.customerId)) &&
           (!ctx.eventId || erpFieldB06J41_001_080_eq_(r.eventId, ctx.eventId)) &&
           (!ctx.vendorId || erpFieldB06J41_001_080_eq_(r.vendorId, ctx.vendorId));
  });
}

function erpFieldB06J41_001_080_findQueue_(pack, ctx, sale, contract, doc) {
  var documentId = ctx.documentId || (doc && doc.documentId) || '';
  var contractId = ctx.contractId || (contract && contract.contractId) || '';
  var saleId = ctx.saleId || (sale && sale.saleId) || '';
  return erpFieldB06J41_001_080_first_(pack.rows, function(r){
    return (documentId && erpFieldB06J41_001_080_eq_(r.documentId, documentId)) ||
           (contractId && erpFieldB06J41_001_080_eq_(r.contractId, contractId)) ||
           (saleId && erpFieldB06J41_001_080_eq_(r.saleId, saleId));
  });
}

function erpFieldB06J41_001_080_applyVendorScope_(vm, ctx) {
  if (!ctx.vendorId) {
    vm.fatal.push('vendorId 누락: ERP_FIELD는 업체/직원 지점형 화면이므로 vendorId가 필요합니다.');
    return vm;
  }
  var targets = ['sale', 'contract', 'document', 'queue'];
  for (var i = 0; i < targets.length; i++) {
    var key = targets[i];
    var row = vm[key];
    if (row && row.vendorId && !erpFieldB06J41_001_080_eq_(row.vendorId, ctx.vendorId)) {
      vm[key] = null;
      vm.warnings.push(key + ' vendorId 불일치로 표시 제외');
    }
  }
  return vm;
}

function erpFieldB06J41_001_080_buildStatusCards_(vm) {
  var d = vm.document || {};
  var c = vm.contract || {};
  var s = vm.sale || {};
  var q = vm.queue || {};
  return [
    { label: '서명상태', value: d.signStatus || c.signStatus || '문서 없음', tone: erpFieldB06J41_001_080_tone_(d.signStatus || c.signStatus) },
    { label: 'PDF상태', value: d.pdfStatus || c.pdfStatus || '문서 없음', tone: erpFieldB06J41_001_080_tone_(d.pdfStatus || c.pdfStatus) },
    { label: '보관상태', value: d.archiveStatus || c.archiveStatus || '문서 없음', tone: erpFieldB06J41_001_080_tone_(d.archiveStatus || c.archiveStatus) },
    { label: '판매상태', value: s.status || '판매 없음', tone: erpFieldB06J41_001_080_tone_(s.status) },
    { label: '계약상태', value: c.status || '계약 없음', tone: erpFieldB06J41_001_080_tone_(c.status) },
    { label: '정산후보', value: q.status || q.queueStatus || q.handoffStatus || '후보 없음', tone: erpFieldB06J41_001_080_tone_(q.status || q.queueStatus || q.handoffStatus) }
  ];
}

function erpFieldB06J41_001_080_buildLinks_(vm) {
  var d = vm.document || {};
  var c = vm.contract || {};
  var links = [];
  var signUrl = d.signUrl || d.signWebAppUrl || c.signUrl || c.signWebAppUrl || '';
  var qrUrl = d.qrUrl || c.qrUrl || '';
  var pdfUrl = d.pdfUrl || d.pdfFileUrl || c.pdfUrl || c.pdfFileUrl || '';
  if (signUrl) links.push({ label: 'SIGN URL', url: signUrl });
  if (qrUrl) links.push({ label: 'QR URL', url: qrUrl });
  if (pdfUrl) links.push({ label: 'PDF 파일', url: pdfUrl });
  return links;
}

function erpFieldB06J41_001_080_buildLocks_(vm) {
  var d = vm.document || {};
  var c = vm.contract || {};
  var archiveStatus = String(d.archiveStatus || c.archiveStatus || '').toUpperCase();
  var locked = archiveStatus === 'ARCHIVED' || archiveStatus === 'ARCHIVE_DONE' || archiveStatus === '보관완료';
  var arr = [];
  if (locked) arr.push('보관완료 문서는 일반 수정이 차단됩니다. 재오픈은 본사 승인 필요 상태로만 안내합니다.');
  arr.push('실제 재오픈 실행은 이번 ERP_FIELD 패치에서 차단되어 있습니다.');
  arr.push('실제 정산 실행, 지급, 환수, 차감은 이번 ERP_FIELD 패치에서 차단되어 있습니다.');
  arr.push('외부연동 실행과 헤더 자동 추가는 차단되어 있습니다.');
  return arr;
}

function erpFieldB06J41_001_080_actionBlocks_() {
  return [
    { action: 'REOPEN_EXECUTE', blocked: true, message: '재오픈 실행 차단: 본사 승인/CONTROL 기준 필요' },
    { action: 'SETTLEMENT_EXECUTE', blocked: true, message: '정산 실행 차단: 후보 상태 조회만 허용' },
    { action: 'PAYMENT_RECOVERY_OFFSET', blocked: true, message: '지급/환수/차감 실행 차단' },
    { action: 'EXTERNAL_INTEGRATION', blocked: true, message: '외부연동 실행 차단' },
    { action: 'HEADER_AUTO_CREATE', blocked: true, message: '헤더 자동 추가 차단' }
  ];
}

function erpFieldB06J41_001_080_blockReopenExecution_() {
  return { ok: false, blocked: true, action: 'REOPEN_EXECUTE', message: '재오픈 실행은 ERP_FIELD에서 차단됩니다. 승인 요청/안내만 가능합니다.' };
}

function erpFieldB06J41_001_080_blockSettlementExecution_() {
  return { ok: false, blocked: true, action: 'SETTLEMENT_EXECUTE', message: '정산 실행은 ERP_FIELD에서 차단됩니다. 후보 큐 상태 조회만 가능합니다.' };
}

function erpFieldB06J41_001_080_blockExternalIntegration_() {
  return { ok: false, blocked: true, action: 'EXTERNAL_INTEGRATION', message: '외부연동 실행은 ERP_FIELD에서 차단됩니다.' };
}

function erpFieldB06J41_001_080_safetyCheck_() {
  return {
    ok: true,
    readOnly: true,
    noSheetWrite: true,
    noAppendRow: true,
    noSetValue: true,
    noUpdateDelete: true,
    noHeaderAutoCreate: true,
    noReopenExecution: true,
    noSettlementExecution: true,
    noPaymentRecoveryOffset: true,
    noExternalIntegration: true,
    vendorBranchUserGroup: true
  };
}

function erpFieldB06J41_001_080_selfTest() {
  var result = { ok: true, build: ERP_SIGN_B06J41_001_080_BUILD, fatal: [], warnings: [], checks: {} };
  var required = [
    'erpFieldB06J41_001_080_renderSignStatusLinkHtml',
    'erpFieldB06J41_001_080_buildViewModel_',
    'erpFieldB06J41_001_080_readSystemConfig_',
    'erpFieldB06J41_001_080_openMaster_',
    'erpFieldB06J41_001_080_blockReopenExecution_',
    'erpFieldB06J41_001_080_blockSettlementExecution_',
    'erpFieldB06J41_001_080_blockExternalIntegration_'
  ];
  var missing = [];
  for (var i = 0; i < required.length; i++) {
    if (typeof this[required[i]] !== 'function') missing.push(required[i]);
  }
  result.checks.requiredFunctions = { ok: missing.length === 0, missing: missing };
  if (missing.length) result.fatal.push('필수 함수 누락: ' + missing.join(', '));
  result.checks.safety = erpFieldB06J41_001_080_safetyCheck_();
  result.checks.blocks = {
    reopen: erpFieldB06J41_001_080_blockReopenExecution_(),
    settlement: erpFieldB06J41_001_080_blockSettlementExecution_(),
    external: erpFieldB06J41_001_080_blockExternalIntegration_()
  };
  result.ok = result.fatal.length === 0;
  Logger.log(JSON.stringify(result, null, 2));
  return result;
}

function erpFieldB06J41_001_080_emptyMessage_(vm) {
  if (vm.document || vm.contract || vm.sale) return '';
  return '조회된 판매/계약/SIGN 문서가 없습니다. saleId, contractId, documentId 중 하나를 포함해 다시 조회하세요.';
}

function erpFieldB06J41_001_080_latestRow_(pack) {
  if (!pack || !pack.rows || !pack.rows.length) return null;
  return pack.rows[pack.rows.length - 1];
}

function erpFieldB06J41_001_080_first_(arr, predicate) {
  arr = arr || [];
  for (var i = 0; i < arr.length; i++) if (predicate(arr[i])) return arr[i];
  return null;
}

function erpFieldB06J41_001_080_eq_(a, b) {
  return String(a == null ? '' : a).trim() === String(b == null ? '' : b).trim();
}

function erpFieldB06J41_001_080_headerMap_(headers) {
  var m = {};
  for (var i = 0; i < headers.length; i++) {
    var h = String(headers[i] || '').trim();
    if (h && m[h] == null) m[h] = i;
  }
  return m;
}

function erpFieldB06J41_001_080_rowObject_(headers, row) {
  var obj = {};
  for (var i = 0; i < headers.length; i++) {
    var h = String(headers[i] || '').trim();
    if (h) obj[h] = row[i];
  }
  return obj;
}

function erpFieldB06J41_001_080_pickMeta_(o) {
  var c = {};
  o = o || {};
  ['ok','fatal','warnings','setupDbId','configSheetName','usedHeaderPair','keyCount','usedKey','masterId','masterName','spreadsheetName'].forEach(function(k){ if (o[k] != null) c[k] = o[k]; });
  return c;
}

function erpFieldB06J41_001_080_fail_(out, fatal) {
  out.ok = false;
  out.fatal = (out.fatal || []).concat(fatal || []);
  if (out.meta) out.meta.ok = false;
  return out;
}

function erpFieldB06J41_001_080_failVm_(vm, fatal) {
  vm.ok = false;
  vm.fatal = (vm.fatal || []).concat(fatal || []);
  return vm;
}

function erpFieldB06J41_001_080_tone_(v) {
  var s = String(v || '').toUpperCase();
  if (!s) return 'gray';
  if (s.indexOf('COMPLETE') >= 0 || s.indexOf('DONE') >= 0 || s.indexOf('ARCHIVED') >= 0 || s === 'CLOSED' || s === '완료' || s === '보관완료') return 'green';
  if (s.indexOf('WAIT') >= 0 || s.indexOf('PENDING') >= 0 || s === 'DRAFT') return 'yellow';
  if (s.indexOf('HOLD') >= 0 || s.indexOf('BLOCK') >= 0 || s.indexOf('CANCEL') >= 0) return 'red';
  return 'blue';
}

function erpFieldB06J41_001_080_err_(err) {
  return err && err.message ? err.message : String(err);
}

function erpFieldB06J41_001_080_json_(v) {
  return JSON.stringify(v == null ? '' : v, function(k, value) {
    if (value instanceof Date) return Utilities.formatDate(value, Session.getScriptTimeZone(), 'yyyy-MM-dd HH:mm:ss');
    return value;
  });
}


/* ===== SignDocSchema.js ===== */
/**
 * build: ERP_B06J41_23_27_SIGN_DOCUMENT_SCHEMA_FIX_SAFE_UPLOAD
 * module: ERP_FIELD
 * purpose:
 * - B06J41-23 SIGN_Documents 필수 헤더 점검
 * - B06J41-24 signStatus / pdfStatus 누락 헤더 보정
 * - B06J41-25 documentId 저장 전 최종 시뮬레이션
 * - B06J41-26 계약/Sales와 documentId 연결 가능성 확인
 * - B06J41-27 PDF 생성 차단 유지
 * safety:
 * - confirmedSchemaFix() only appends missing headers to SIGN_Documents header row
 * - no document row creation / no documentId write / no QR URL / no PDF / no settlement / no external integration
 * - SystemConfig standard header: CONFIG_KEY / VALUE first
 */

var FIELD_B06J41_23_27_BUILD = 'ERP_B06J41_23_27_SIGN_DOCUMENT_SCHEMA_FIX_SAFE_UPLOAD';
var FIELD_B06J41_23_27_SETUP_DB_ID = '17VMSpgSZCvIrUlgcw8yCNcnl8WQWo2IcRf5tDCcuJGM';
var FIELD_B06J41_23_27_CONFIG_SHEET_NAME = 'SystemConfig';

var FIELD_B06J41_23_27_SIGN_CANDIDATES = ['SIGN_Documents', 'SIGN_DocumentMaster', 'SIGN_문서관리', 'ERP_SIGN_Documents', 'SIGN_Document'];
var FIELD_B06J41_23_27_SIGN_REQUIRED_HEADERS = [
  'documentId', 'contractId', 'saleId', 'eventId', 'vendorId', 'customerId',
  'signStatus', 'pdfStatus', 'status', 'statusReason', 'createdAt', 'createdBy', 'updatedAt', 'updatedBy'
];
var FIELD_B06J41_23_27_SIGN_RECOMMENDED_HEADERS = [
  'documentType', 'templateId', 'qrUrl', 'signUrl', 'signerName', 'phone', 'phoneNormalized',
  'signedAt', 'signaturePath', 'signatureFileId', 'pdfUrl', 'pdfFileId', 'driveFolderId',
  'contractAmount', 'totalAmount', 'paymentStructure', 'paymentMethod',
  'sourceProject', 'sourceModule', 'lockedAt', 'lockedBy', 'logId', 'memo'
];

function erpB06J41_23_27_preflight() {
  return erpFieldB06J41_23_27_run_(false, false);
}

function erpB06J41_23_27_autoRunSafe() {
  var result = erpFieldB06J41_23_27_run_(false, true);
  return result;
}

function erpB06J41_23_27_confirmedSchemaFix() {
  var result = erpFieldB06J41_23_27_run_(true, true);
  return result;
}

function erpFieldB06J41_23_27_renderSignDocumentSchemaHtml(ctx) {
  var vm = erpFieldB06J41_23_27_buildVm_(ctx || {});
  var t = HtmlService.createTemplateFromFile('P_SignDocSchema');
  t.vm = vm;
  t.json = JSON.stringify(vm, null, 2);
  return t.evaluate()
    .setTitle('SIGN 문서 스키마 보정')
    .setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL);
}

function erpFieldB06J41_23_27_buildVm_(ctx) {
  ctx = erpFieldB06J41_23_27_normalize_(ctx || {});
  var result = erpFieldB06J41_23_27_run_(false, false);
  result.context = ctx;
  result.page = {
    badge: 'B06J41-23_27 SAFE : SIGN DOCUMENT SCHEMA FIX',
    title: 'SIGN 문서 스키마 보정',
    subtitle: 'SIGN_Documents 헤더를 점검합니다. 문서 생성/PDF/QR/서명 실행은 아직 하지 않습니다.',
    roleName: erpFieldB06J41_23_27_roleName_(ctx.roleCode)
  };
  result.documentPreview = erpFieldB06J41_23_27_generateId_('DOC');
  result.urls = erpFieldB06J41_23_27_urls_(ctx, result);
  result.safety = erpFieldB06J41_23_27_safety_();
  return result;
}

function erpFieldB06J41_23_27_run_(confirmed, logOutput) {
  var result = erpFieldB06J41_23_27_result_(confirmed ? 'confirmedSchemaFix' : 'preflight');
  result.confirmed = confirmed === true;
  try {
    result.checks.config = erpFieldB06J41_23_27_loadConfig_();
    if (!result.checks.config.ok) return erpFieldB06J41_23_27_finish_(result, logOutput);

    var master = erpFieldB06J41_23_27_openMaster_(result.checks.config);
    result.checks.master = master.meta;
    if (!master.ss) {
      result.fatal.push('FEELHAUS_DB_MASTER 연결 실패');
      return erpFieldB06J41_23_27_finish_(result, logOutput);
    }

    result.checks.salesSheet = erpFieldB06J41_23_27_findSheet_(master.ss, ['Sales', 'ERP_판매관리', 'ERP_Sales'], ['saleId', 'eventId', 'vendorId', 'customerId', 'contractId', 'status']);
    result.checks.contractSheet = erpFieldB06J41_23_27_findSheet_(master.ss, ['ERP_계약관리', 'Contracts', 'ERP_Contract'], ['contractId', 'saleId', 'eventId', 'vendorId', 'customerId', 'documentId', 'status', 'signStatus', 'pdfStatus']);
    result.checks.signSheet = erpFieldB06J41_23_27_checkSignSheet_(master.ss, confirmed);
    result.checks.coreLog = erpFieldB06J41_23_27_findSheet_(master.ss, ['ERP_CoreLog', 'ERP_Log'], ['logId', 'build', 'moduleCode', 'functionName', 'actionType', 'eventId', 'vendorId', 'customerId', 'saleId', 'contractId', 'documentId', 'createdAt', 'createdBy']);
    result.checks.safety = erpFieldB06J41_23_27_safety_();

    if (!result.checks.salesSheet.exists) result.fatal.push('Sales 시트 없음');
    if (!result.checks.contractSheet.exists) result.fatal.push('Contracts / ERP_계약관리 시트 없음');
    if (!result.checks.signSheet.exists) result.fatal.push('SIGN_Documents 시트 없음');
    if ((result.checks.salesSheet.missingRequiredHeaders || []).length) result.fatal.push('Sales 필수 헤더 누락: ' + result.checks.salesSheet.missingRequiredHeaders.join(', '));
    if ((result.checks.contractSheet.missingRequiredHeaders || []).length) result.fatal.push('계약관리 필수 헤더 누락: ' + result.checks.contractSheet.missingRequiredHeaders.join(', '));
    if ((result.checks.signSheet.missingRequiredHeaders || []).length) result.fatal.push('SIGN_Documents 필수 헤더 누락: ' + result.checks.signSheet.missingRequiredHeaders.join(', '));
    if ((result.checks.coreLog.missingRequiredHeaders || []).length) result.warnings.push('ERP_CoreLog 권장 헤더 보완 필요: ' + result.checks.coreLog.missingRequiredHeaders.join(', '));

    result.readiness = erpFieldB06J41_23_27_readiness_(result);
  } catch (err) {
    result.fatal.push('B06J41-23~27 SIGN schema fix fatal: ' + (err && err.message ? err.message : err));
  }
  return erpFieldB06J41_23_27_finish_(result, logOutput);
}

function erpFieldB06J41_23_27_checkSignSheet_(ss, confirmed) {
  var out = { ok: false, exists: false, sheetName: '', candidates: FIELD_B06J41_23_27_SIGN_CANDIDATES.slice(), lastRow: 0, lastCol: 0, headers: [], headerMap: {}, missingRequiredHeaders: [], missingRecommendedHeaders: [], appendedHeaders: [], created: false, sheet: null };
  try {
    var sh = null;
    for (var i = 0; i < FIELD_B06J41_23_27_SIGN_CANDIDATES.length; i++) {
      sh = ss.getSheetByName(FIELD_B06J41_23_27_SIGN_CANDIDATES[i]);
      if (sh) break;
    }
    if (!sh && confirmed) {
      sh = ss.insertSheet('SIGN_Documents');
      sh.getRange(1, 1, 1, FIELD_B06J41_23_27_SIGN_REQUIRED_HEADERS.length).setValues([FIELD_B06J41_23_27_SIGN_REQUIRED_HEADERS]);
      out.created = true;
    }
    if (!sh) return out;

    out.exists = true;
    out.sheet = sh;
    out.sheetName = sh.getName();
    out.headers = erpFieldB06J41_23_27_headers_(sh);
    out.headerMap = erpFieldB06J41_23_27_headerMap_(out.headers);
    out.missingRequiredHeaders = erpFieldB06J41_23_27_missing_(out.headerMap, FIELD_B06J41_23_27_SIGN_REQUIRED_HEADERS);
    out.missingRecommendedHeaders = erpFieldB06J41_23_27_missing_(out.headerMap, FIELD_B06J41_23_27_SIGN_RECOMMENDED_HEADERS);

    if (confirmed && out.missingRequiredHeaders.length) {
      erpFieldB06J41_23_27_appendHeaders_(sh, out.missingRequiredHeaders);
      out.appendedHeaders = out.appendedHeaders.concat(out.missingRequiredHeaders);
      out.headers = erpFieldB06J41_23_27_headers_(sh);
      out.headerMap = erpFieldB06J41_23_27_headerMap_(out.headers);
      out.missingRequiredHeaders = erpFieldB06J41_23_27_missing_(out.headerMap, FIELD_B06J41_23_27_SIGN_REQUIRED_HEADERS);
      out.missingRecommendedHeaders = erpFieldB06J41_23_27_missing_(out.headerMap, FIELD_B06J41_23_27_SIGN_RECOMMENDED_HEADERS);
    }

    out.lastRow = sh.getLastRow();
    out.lastCol = sh.getLastColumn();
    out.ok = out.missingRequiredHeaders.length === 0;
  } catch (err) {
    out.fatal = [String(err && err.message ? err.message : err)];
  }
  return out;
}

function erpFieldB06J41_23_27_findSheet_(ss, candidates, requiredHeaders) {
  var out = { ok: false, exists: false, sheetName: '', candidates: candidates, lastRow: 0, lastCol: 0, headers: [], headerMap: {}, missingRequiredHeaders: [], sheet: null };
  if (!ss) return out;
  for (var i = 0; i < candidates.length; i++) {
    var sh = ss.getSheetByName(candidates[i]);
    if (!sh) continue;
    out.exists = true;
    out.sheet = sh;
    out.sheetName = sh.getName();
    out.lastRow = sh.getLastRow();
    out.lastCol = sh.getLastColumn();
    out.headers = erpFieldB06J41_23_27_headers_(sh);
    out.headerMap = erpFieldB06J41_23_27_headerMap_(out.headers);
    out.missingRequiredHeaders = erpFieldB06J41_23_27_missing_(out.headerMap, requiredHeaders || []);
    out.ok = out.missingRequiredHeaders.length === 0;
    return out;
  }
  out.missingRequiredHeaders = (requiredHeaders || []).slice();
  return out;
}

function erpFieldB06J41_23_27_readiness_(result) {
  var issues = [];
  if (!result.checks.signSheet.exists) issues.push('SIGN_Documents 시트 없음');
  if ((result.checks.signSheet.missingRequiredHeaders || []).length) issues.push('SIGN_Documents 필수 헤더 누락: ' + result.checks.signSheet.missingRequiredHeaders.join(', '));
  if ((result.checks.contractSheet.missingRequiredHeaders || []).length) issues.push('계약관리 연결 헤더 누락');
  if ((result.checks.salesSheet.missingRequiredHeaders || []).length) issues.push('Sales 연결 헤더 누락');
  return {
    readyForSignDocumentCreate: issues.length === 0,
    blockingIssues: issues,
    nextBuild: 'ERP_B06J41_28_32_SIGN_DOCUMENT_DRAFT_CREATE_SAFE_UPLOAD',
    pdfStillBlocked: true,
    documentIdWriteBlockedInThisBuild: true,
    signUrlBlockedInThisBuild: true
  };
}

function erpFieldB06J41_23_27_safety_() {
  return {
    noDocumentRowCreate: true,
    noDocumentIdWrite: true,
    noSignUrlCreate: true,
    noQrUrlCreate: true,
    noPdfCreate: true,
    noSettlementExecution: true,
    noExternalIntegration: true,
    noUpdateDelete: true,
    headerAppendOnlyWhenConfirmed: true,
    systemConfigHeaderStandard: 'CONFIG_KEY/VALUE first'
  };
}

function erpFieldB06J41_23_27_loadConfig_() {
  var out = { ok: true, fatal: [], warnings: [], setupDbId: FIELD_B06J41_23_27_SETUP_DB_ID, configSheetName: FIELD_B06J41_23_27_CONFIG_SHEET_NAME, headerPolicy: 'CONFIG_KEY/VALUE first', usedHeaderPair: '', configMap: {} };
  try {
    var ss = SpreadsheetApp.openById(FIELD_B06J41_23_27_SETUP_DB_ID);
    out.setupDbName = ss.getName();
    var sh = ss.getSheetByName(FIELD_B06J41_23_27_CONFIG_SHEET_NAME);
    if (!sh) throw new Error('SystemConfig 시트 없음');
    var values = sh.getDataRange().getValues();
    if (values.length < 2) throw new Error('SystemConfig 데이터 없음');
    var headerMap = erpFieldB06J41_23_27_headerMap_(values[0]);
    var keyCol = 0;
    var valCol = 0;
    if (headerMap.CONFIG_KEY && headerMap.VALUE) { keyCol = headerMap.CONFIG_KEY; valCol = headerMap.VALUE; out.usedHeaderPair = 'CONFIG_KEY/VALUE'; }
    else if (headerMap.configKey && headerMap.configValue) { keyCol = headerMap.configKey; valCol = headerMap.configValue; out.usedHeaderPair = 'configKey/configValue'; }
    else if (headerMap.key && headerMap.value) { keyCol = headerMap.key; valCol = headerMap.value; out.usedHeaderPair = 'key/value'; }
    else throw new Error('SystemConfig CONFIG_KEY/VALUE 헤더 없음');
    for (var r = 1; r < values.length; r++) {
      var k = String(values[r][keyCol - 1] || '').trim();
      if (k) out.configMap[k] = values[r][valCol - 1];
    }
    out.configCount = Object.keys(out.configMap).length;
  } catch (err) {
    out.ok = false;
    out.fatal.push(String(err && err.message ? err.message : err));
  }
  return out;
}

function erpFieldB06J41_23_27_openMaster_(config) {
  var meta = { ok: false, fatal: [], warnings: [], usedKey: '', masterId: '', masterName: 'FEELHAUS_DB_MASTER', masterSpreadsheetName: '' };
  try {
    var cm = (config && config.configMap) || {};
    var id = String(cm.FEELHAUS_DB_MASTER_ID || cm.DB_MASTER_ID || cm.SPREADSHEET_ID || '').trim();
    meta.usedKey = cm.FEELHAUS_DB_MASTER_ID ? 'FEELHAUS_DB_MASTER_ID' : (cm.DB_MASTER_ID ? 'DB_MASTER_ID' : 'SPREADSHEET_ID');
    meta.masterId = id;
    if (!id) throw new Error('마스터 ID 없음');
    var ss = SpreadsheetApp.openById(id);
    meta.masterSpreadsheetName = ss.getName();
    meta.ok = true;
    return { ss: ss, meta: meta };
  } catch (err) {
    meta.fatal.push(String(err && err.message ? err.message : err));
    return { ss: null, meta: meta };
  }
}

function erpFieldB06J41_23_27_headers_(sh) {
  if (!sh || sh.getLastColumn() < 1) return [];
  return sh.getRange(1, 1, 1, sh.getLastColumn()).getValues()[0].map(function (v) { return String(v || '').trim(); });
}

function erpFieldB06J41_23_27_headerMap_(headers) {
  var m = {};
  (headers || []).forEach(function (h, i) { if (String(h || '').trim() !== '') m[String(h).trim()] = i + 1; });
  return m;
}

function erpFieldB06J41_23_27_missing_(map, headers) {
  var out = [];
  (headers || []).forEach(function (h) { if (!map[h]) out.push(h); });
  return out;
}

function erpFieldB06J41_23_27_appendHeaders_(sh, headers) {
  if (!headers || !headers.length) return;
  var startCol = Math.max(sh.getLastColumn(), 1) + 1;
  sh.getRange(1, startCol, 1, headers.length).setValues([headers]);
}

function erpFieldB06J41_23_27_normalize_(ctx) {
  return {
    roleCode: String(ctx.roleCode || 'VIEWER').trim(),
    vendorId: String(ctx.vendorId || '').trim(),
    eventId: String(ctx.eventId || '').trim(),
    route: String(ctx.route || 'signSchema').trim(),
    customerId: String(ctx.customerId || '').trim(),
    saleId: String(ctx.saleId || '').trim(),
    contractId: String(ctx.contractId || '').trim(),
    documentId: String(ctx.documentId || '').trim(),
    userEmail: String(ctx.userEmail || '').trim(),
    scopeType: 'VENDOR_BRANCH_USER_GROUP'
  };
}

function erpFieldB06J41_23_27_urls_(ctx, result) {
  var base = erpFieldB06J41_23_27_webAppUrl_();
  var params = 'roleCode=' + encodeURIComponent(ctx.roleCode) + '&vendorId=' + encodeURIComponent(ctx.vendorId) + '&eventId=' + encodeURIComponent(ctx.eventId) + '&customerId=' + encodeURIComponent(ctx.customerId) + '&saleId=' + encodeURIComponent(ctx.saleId) + '&contractId=' + encodeURIComponent(ctx.contractId);
  return {
    signPrecheck: base + '?' + params + '&route=signPrecheck',
    contractDetail: base + '?' + params + '&route=contractDetail',
    signSchema: base + '?' + params + '&route=signSchema'
  };
}

function erpFieldB06J41_23_27_generateId_(prefix) {
  var d = new Date();
  var pad = function (n) { return String(n).padStart(2, '0'); };
  var ts = d.getFullYear() + pad(d.getMonth() + 1) + pad(d.getDate()) + pad(d.getHours()) + pad(d.getMinutes()) + pad(d.getSeconds());
  return prefix + '-' + ts + '-' + Math.floor(100 + Math.random() * 900);
}
function erpFieldB06J41_23_27_webAppUrl_() { try { return ScriptApp.getService().getUrl() || ''; } catch (err) { return ''; } }
function erpFieldB06J41_23_27_roleName_(roleCode) { var map = { VENDOR_OWNER: '업체대표', VENDOR_MANAGER: '업체관리자', STAFF_SALES: '영업직원', VIEWER: '조회전용' }; return map[roleCode] || roleCode || '-'; }
function erpFieldB06J41_23_27_escape_(v) { return String(v == null ? '' : v).replace(/[&<>"']/g, function (c) { return ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]; }); }
function erpFieldB06J41_23_27_result_(label) { return { ok: true, label: label, build: FIELD_B06J41_23_27_BUILD, moduleCode: 'ERP_FIELD', checkedAt: new Date().toISOString(), fatal: [], warnings: [], checks: {}, readiness: {} }; }
function erpFieldB06J41_23_27_finish_(result, logOutput) {
  result.ok = (result.fatal || []).length === 0;
  if (logOutput) {
    Logger.log('======================================================');
    Logger.log('[' + FIELD_B06J41_23_27_BUILD + '] RESULT');
    Logger.log(JSON.stringify(result, null, 2));
    Logger.log('======================================================');
  }
  return result;
}


/* ===== SignDocChk.js ===== */
/**
 * build: ERP_B06J41_18_22_SIGN_DOCUMENT_LINK_PRECHECK_SAFE_UPLOAD
 * module: ERP_FIELD
 * purpose:
 * - B06J41-18 계약 DRAFT 기준 SIGN 연결 후보 검증
 * - B06J41-19 documentId 생성 시뮬레이션
 * - B06J41-20 SIGN 문서 시트/헤더 점검
 * - B06J41-21 QR/서명 URL 생성 전 안전조건 확인
 * - B06J41-22 PDF 생성 차단 유지
 * safety:
 * - no documentId write / no SIGN document creation / no PDF / no settlement / no external integration / no delete
 * - SystemConfig standard header: CONFIG_KEY / VALUE first
 */

var FIELD_B06J41_18_22_BUILD = 'ERP_B06J41_18_22_SIGN_DOCUMENT_LINK_PRECHECK_SAFE_UPLOAD';
var FIELD_B06J41_18_22_SETUP_DB_ID = '17VMSpgSZCvIrUlgcw8yCNcnl8WQWo2IcRf5tDCcuJGM';
var FIELD_B06J41_18_22_CONFIG_SHEET_NAME = 'SystemConfig';

function erpB06J41_18_22_preflight() {
  var r = erpFieldB06J41_18_22_result_('preflight');
  r.checks.config = erpFieldB06J41_18_22_loadConfig_();
  var master = erpFieldB06J41_18_22_openMaster_(r.checks.config);
  r.checks.master = master.meta;
  if (!master.ss) {
    r.fatal.push('FEELHAUS_DB_MASTER 연결 실패');
    r.ok = false;
    return erpFieldB06J41_18_22_finish_(r, true);
  }
  r.checks.salesSheet = erpFieldB06J41_18_22_findSheet_(master.ss, ['Sales', 'ERP_판매관리', 'ERP_Sales'], erpFieldB06J41_18_22_salesRequired_());
  r.checks.contractSheet = erpFieldB06J41_18_22_findSheet_(master.ss, ['ERP_계약관리', 'Contracts', 'ERP_Contract'], erpFieldB06J41_18_22_contractRequired_());
  r.checks.signSheet = erpFieldB06J41_18_22_findSheet_(master.ss, ['SIGN_DocumentMaster', 'SIGN_Documents', 'SIGN_문서관리', 'ERP_SIGN_Documents', 'SIGN_Document'], erpFieldB06J41_18_22_signRequired_());
  r.checks.coreLog = erpFieldB06J41_18_22_findSheet_(master.ss, ['ERP_CoreLog', 'ERP_Log', 'ERP_SalesLog'], erpFieldB06J41_18_22_logRecommended_());

  if (!r.checks.salesSheet.exists) r.fatal.push('Sales 시트 없음');
  if (!r.checks.contractSheet.exists) r.fatal.push('계약관리 시트 없음: ERP_계약관리 또는 Contracts 필요');
  if ((r.checks.salesSheet.missingRequiredHeaders || []).length) r.fatal.push('Sales 필수 헤더 누락: ' + r.checks.salesSheet.missingRequiredHeaders.join(', '));
  if ((r.checks.contractSheet.missingRequiredHeaders || []).length) r.fatal.push('계약관리 필수 헤더 누락: ' + r.checks.contractSheet.missingRequiredHeaders.join(', '));
  if (!r.checks.signSheet.exists) {
    r.warnings.push('SIGN 문서 시트 없음: SIGN_DocumentMaster 또는 SIGN_Documents 후보 필요. 다음 B06J41-23~27에서 보정 가능');
  } else if ((r.checks.signSheet.missingRequiredHeaders || []).length) {
    r.warnings.push('SIGN 문서 필수 헤더 보완 필요: ' + r.checks.signSheet.missingRequiredHeaders.join(', '));
  }
  if (r.checks.coreLog.exists && (r.checks.coreLog.missingRequiredHeaders || []).length) {
    r.warnings.push('ERP_CoreLog 권장 헤더 보완 필요: ' + r.checks.coreLog.missingRequiredHeaders.join(', '));
  }
  r.ok = r.fatal.length === 0;
  return erpFieldB06J41_18_22_finish_(r, true);
}

function erpB06J41_18_22_autoRunSafe() {
  var r = erpFieldB06J41_18_22_result_('autoRunSafe');
  r.checks.preflight = erpB06J41_18_22_preflight();
  r.checks.sample = erpFieldB06J41_18_22_buildVm_({
    roleCode: 'VENDOR_MANAGER',
    vendorId: 'VND-20260502202158-505',
    eventId: 'EVT-20260502202016-197',
    customerId: 'CUS-20260504002306-615',
    saleId: 'SALE-20260504005028-991',
    contractId: 'CON-20260504021423-908',
    route: 'signPrecheck'
  });
  r.checks.missingVendorBlocked = erpFieldB06J41_18_22_buildVm_({ roleCode: 'VENDOR_MANAGER', vendorId: '', eventId: 'EVT-SAMPLE', route: 'signPrecheck' });
  if (!r.checks.preflight.ok) r.fatal.push('preflight 미통과');
  if (r.checks.sample.ok === false && (r.checks.sample.fatal || []).length) r.fatal.push('sample SIGN 프리체크 실패: ' + r.checks.sample.fatal.join(', '));
  if (r.checks.missingVendorBlocked.ok !== false) r.fatal.push('missingVendorBlocked 차단 기대 테스트 실패');
  r.ok = r.fatal.length === 0;
  return erpFieldB06J41_18_22_finish_(r, true);
}

function erpFieldB06J41_18_22_renderSignDocumentPrecheckHtml(ctx) {
  var vm = erpFieldB06J41_18_22_buildVm_(ctx || {});
  var t = HtmlService.createTemplateFromFile('P_SignDocChk');
  t.vm = vm;
  t.json = JSON.stringify(vm, null, 2);
  return t.evaluate()
    .setTitle('SIGN 연결 프리체크')
    .setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL);
}

function erpFieldB06J41_18_22_buildVm_(ctx) {
  ctx = erpFieldB06J41_18_22_normalize_(ctx || {});
  var r = erpFieldB06J41_18_22_result_('signDocumentPrecheck');
  r.context = ctx;
  r.page = {
    badge: 'B06J41-18_22 SAFE : SIGN DOCUMENT LINK PRECHECK',
    title: 'SIGN/documentId 연결 프리체크',
    subtitle: '계약 DRAFT를 기준으로 SIGN 문서 연결 후보를 검증합니다. documentId/PDF는 아직 생성하지 않습니다.',
    roleName: erpFieldB06J41_18_22_roleName_(ctx.roleCode)
  };
  r.safety = {
    readOnly: true,
    noDocumentIdCreate: true,
    noSignDocumentCreate: true,
    noPdfCreate: true,
    noQrUrlCreate: true,
    noSettlementExecution: true,
    noExternalIntegration: true,
    noUpdateDelete: true,
    configHeaderStandard: 'CONFIG_KEY/VALUE'
  };
  var guard = erpFieldB06J41_18_22_guard_(ctx);
  if (!guard.ok) {
    r.fatal = r.fatal.concat(guard.fatal);
    r.ok = false;
    r.blocked = true;
    return r;
  }
  r.checks.config = erpFieldB06J41_18_22_loadConfig_();
  var master = erpFieldB06J41_18_22_openMaster_(r.checks.config);
  r.checks.master = master.meta;
  if (!master.ss) {
    r.fatal.push('FEELHAUS_DB_MASTER 연결 실패');
    r.ok = false;
    return r;
  }
  r.checks.salesSheet = erpFieldB06J41_18_22_findSheet_(master.ss, ['Sales', 'ERP_판매관리', 'ERP_Sales'], erpFieldB06J41_18_22_salesRequired_());
  r.checks.contractSheet = erpFieldB06J41_18_22_findSheet_(master.ss, ['ERP_계약관리', 'Contracts', 'ERP_Contract'], erpFieldB06J41_18_22_contractRequired_());
  r.checks.signSheet = erpFieldB06J41_18_22_findSheet_(master.ss, ['SIGN_DocumentMaster', 'SIGN_Documents', 'SIGN_문서관리', 'ERP_SIGN_Documents', 'SIGN_Document'], erpFieldB06J41_18_22_signRequired_());
  r.sale = erpFieldB06J41_18_22_lookupRow_(r.checks.salesSheet, ctx.saleId ? { saleId: ctx.saleId } : { contractId: ctx.contractId });
  r.contract = erpFieldB06J41_18_22_lookupRow_(r.checks.contractSheet, ctx.contractId ? { contractId: ctx.contractId } : { saleId: ctx.saleId });
  r.documentIdPreview = erpFieldB06J41_18_22_generateId_('DOC');
  r.sign = erpFieldB06J41_18_22_signReadiness_(r, ctx);
  r.urls = erpFieldB06J41_18_22_urls_(ctx, r);
  r.ok = r.fatal.length === 0;
  return r;
}

function erpFieldB06J41_18_22_signReadiness_(r, ctx) {
  var issues = [];
  var warnings = [];
  if (!r.contract || !r.contract.found) issues.push('계약 DRAFT를 찾지 못했습니다. contractId 또는 saleId 확인 필요');
  if (r.contract && r.contract.found && String(r.contract.row.status || r.contract.row.contractStatus || '').toUpperCase() !== 'DRAFT') issues.push('계약 상태가 DRAFT가 아닙니다');
  if (!r.sale || !r.sale.found) warnings.push('Sales 원전표를 찾지 못했습니다. SIGN 연결 전 saleId 역추적 확인 필요');
  if (!r.checks.signSheet.exists) warnings.push('SIGN 문서 시트가 아직 없습니다. 다음 단계에서 스키마 보정 필요');
  if (r.checks.signSheet.exists && (r.checks.signSheet.missingRequiredHeaders || []).length) warnings.push('SIGN 문서 헤더 보완 필요: ' + r.checks.signSheet.missingRequiredHeaders.join(', '));
  var alreadyLinked = false;
  if (r.contract && r.contract.found) {
    alreadyLinked = !!(r.contract.row.documentId || r.contract.row.signStatus === 'READY' || r.contract.row.signStatus === 'SIGNED');
  }
  if (alreadyLinked) warnings.push('이미 documentId 또는 SIGN 상태가 연결되어 있습니다. 중복 생성 금지 대상');
  return {
    readyForDocumentSchemaFix: issues.length === 0,
    readyForDocumentCreate: issues.length === 0 && r.checks.signSheet.exists && (r.checks.signSheet.missingRequiredHeaders || []).length === 0 && !alreadyLinked,
    issues: issues,
    warnings: warnings,
    contractDraftOk: issues.length === 0,
    documentIdPreview: r.documentIdPreview,
    signStatusPreview: 'NOT_STARTED',
    pdfStatusPreview: 'NOT_CREATED',
    nextBuild: 'B06J41_23_27_SIGN_DOCUMENT_SCHEMA_FIX_SAFE'
  };
}

function erpFieldB06J41_18_22_lookupRow_(sheetCheck, criteria) {
  var out = { found: false, row: {}, rowNumber: 0, criteria: criteria || {} };
  if (!sheetCheck || !sheetCheck.sheet) return out;
  var sh = sheetCheck.sheet;
  var values = sh.getDataRange().getValues();
  if (values.length < 2) return out;
  var map = sheetCheck.headerMap || erpFieldB06J41_18_22_headerMap_(values[0]);
  for (var r = 1; r < values.length; r++) {
    var match = true;
    Object.keys(criteria || {}).forEach(function (k) {
      if (!criteria[k]) return;
      if (!map[k]) { match = false; return; }
      if (String(values[r][map[k] - 1] || '') !== String(criteria[k])) match = false;
    });
    if (match) {
      out.found = true;
      out.rowNumber = r + 1;
      Object.keys(map).forEach(function (h) { out.row[h] = values[r][map[h] - 1]; });
      return out;
    }
  }
  return out;
}

function erpFieldB06J41_18_22_findSheet_(ss, candidates, requiredHeaders) {
  var out = { ok: true, exists: false, sheetName: '', candidates: candidates, lastRow: 0, lastCol: 0, headers: [], headerMap: {}, missingRequiredHeaders: [], sheet: null };
  if (!ss) { out.ok = false; return out; }
  for (var i = 0; i < candidates.length; i++) {
    var sh = ss.getSheetByName(candidates[i]);
    if (sh) {
      out.exists = true;
      out.sheet = sh;
      out.sheetName = candidates[i];
      out.lastRow = sh.getLastRow();
      out.lastCol = sh.getLastColumn();
      if (out.lastRow >= 1 && out.lastCol >= 1) out.headers = sh.getRange(1, 1, 1, out.lastCol).getValues()[0].map(function (v) { return String(v || '').trim(); });
      out.headerMap = erpFieldB06J41_18_22_headerMap_(out.headers);
      requiredHeaders.forEach(function (h) { if (!out.headerMap[h]) out.missingRequiredHeaders.push(h); });
      out.ok = out.missingRequiredHeaders.length === 0;
      return out;
    }
  }
  out.ok = false;
  out.missingRequiredHeaders = requiredHeaders.slice();
  return out;
}

function erpFieldB06J41_18_22_salesRequired_() {
  return ['saleId', 'eventId', 'vendorId', 'customerId', 'status', 'contractId', 'totalAmount', 'paymentStructure', 'paymentMethod'];
}
function erpFieldB06J41_18_22_contractRequired_() {
  return ['contractId', 'saleId', 'eventId', 'vendorId', 'customerId', 'status', 'documentId', 'signStatus', 'pdfStatus', 'totalAmount', 'paymentStructure', 'paymentMethod', 'createdAt', 'createdBy', 'updatedAt', 'updatedBy'];
}
function erpFieldB06J41_18_22_signRequired_() {
  return ['documentId', 'contractId', 'saleId', 'eventId', 'vendorId', 'customerId', 'signStatus', 'pdfStatus', 'status', 'createdAt', 'createdBy', 'updatedAt', 'updatedBy'];
}
function erpFieldB06J41_18_22_logRecommended_() {
  return ['logId', 'functionName', 'actionType', 'eventId', 'vendorId', 'customerId', 'saleId', 'contractId', 'documentId', 'payloadJson', 'createdAt', 'createdBy'];
}

function erpFieldB06J41_18_22_loadConfig_() {
  var out = { ok: true, fatal: [], warnings: [], setupDbId: FIELD_B06J41_18_22_SETUP_DB_ID, configSheetName: FIELD_B06J41_18_22_CONFIG_SHEET_NAME, headerPolicy: 'CONFIG_KEY/VALUE first', usedHeaderPair: '', configMap: {}, masterId: '' };
  try {
    var ss = SpreadsheetApp.openById(FIELD_B06J41_18_22_SETUP_DB_ID);
    var sh = ss.getSheetByName(FIELD_B06J41_18_22_CONFIG_SHEET_NAME);
    if (!sh) throw new Error('SystemConfig 시트 없음');
    var values = sh.getDataRange().getValues();
    if (values.length < 2) throw new Error('SystemConfig 데이터 없음');
    var headers = values[0].map(function (v) { return String(v || '').trim(); });
    var map = erpFieldB06J41_18_22_headerMap_(headers);
    var keyCol = map.CONFIG_KEY || map.configKey || map.key;
    var valCol = map.VALUE || map.configValue || map.value;
    if (map.CONFIG_KEY && map.VALUE) out.usedHeaderPair = 'CONFIG_KEY/VALUE';
    else if (map.configKey && map.configValue) out.usedHeaderPair = 'configKey/configValue';
    else if (map.key && map.value) out.usedHeaderPair = 'key/value';
    if (!keyCol || !valCol) throw new Error('SystemConfig CONFIG_KEY/VALUE 헤더 없음');
    for (var r = 1; r < values.length; r++) {
      var k = String(values[r][keyCol - 1] || '').trim();
      if (!k) continue;
      out.configMap[k] = values[r][valCol - 1];
    }
    out.masterId = String(out.configMap.FEELHAUS_DB_MASTER_ID || out.configMap.DB_MASTER_ID || out.configMap.SPREADSHEET_ID || '').trim();
    if (!out.masterId) throw new Error('FEELHAUS_DB_MASTER_ID 누락');
  } catch (err) {
    out.ok = false;
    out.fatal.push(String(err && err.message ? err.message : err));
  }
  return out;
}

function erpFieldB06J41_18_22_openMaster_(config) {
  var meta = { ok: false, fatal: [], warnings: [], usedKey: '', masterId: '', masterName: 'FEELHAUS_DB_MASTER', masterSpreadsheetName: '' };
  try {
    var cm = (config && config.configMap) || {};
    var id = String(cm.FEELHAUS_DB_MASTER_ID || cm.DB_MASTER_ID || cm.SPREADSHEET_ID || '').trim();
    meta.usedKey = cm.FEELHAUS_DB_MASTER_ID ? 'FEELHAUS_DB_MASTER_ID' : (cm.DB_MASTER_ID ? 'DB_MASTER_ID' : 'SPREADSHEET_ID');
    meta.masterId = id;
    if (!id) throw new Error('마스터 ID 없음');
    var ss = SpreadsheetApp.openById(id);
    meta.masterSpreadsheetName = ss.getName();
    meta.ok = true;
    return { ss: ss, meta: meta };
  } catch (err) {
    meta.fatal.push(String(err && err.message ? err.message : err));
    return { ss: null, meta: meta };
  }
}

function erpFieldB06J41_18_22_normalize_(ctx) {
  return {
    roleCode: String(ctx.roleCode || 'VIEWER').trim(),
    vendorId: String(ctx.vendorId || '').trim(),
    eventId: String(ctx.eventId || '').trim(),
    route: String(ctx.route || 'signPrecheck').trim(),
    customerId: String(ctx.customerId || '').trim(),
    saleId: String(ctx.saleId || '').trim(),
    contractId: String(ctx.contractId || '').trim(),
    documentId: String(ctx.documentId || '').trim(),
    userEmail: String(ctx.userEmail || '').trim(),
    scopeType: 'VENDOR_BRANCH_USER_GROUP'
  };
}

function erpFieldB06J41_18_22_guard_(ctx) {
  var fatal = [];
  var roles = { VENDOR_OWNER: true, VENDOR_MANAGER: true, STAFF_SALES: true, VIEWER: true };
  if (!ctx.vendorId) fatal.push('vendorId 누락');
  if (!ctx.eventId) fatal.push('eventId 누락');
  if (!roles[ctx.roleCode]) fatal.push('미허용 roleCode: ' + ctx.roleCode);
  if (!ctx.contractId && !ctx.saleId) fatal.push('contractId 또는 saleId 필요');
  return { ok: fatal.length === 0, fatal: fatal };
}

function erpFieldB06J41_18_22_urls_(ctx, r) {
  var base = erpFieldB06J41_18_22_webAppUrl_();
  var params = 'roleCode=' + encodeURIComponent(ctx.roleCode) + '&vendorId=' + encodeURIComponent(ctx.vendorId) + '&eventId=' + encodeURIComponent(ctx.eventId) + '&customerId=' + encodeURIComponent(ctx.customerId || (r.contract && r.contract.row.customerId) || '') + '&saleId=' + encodeURIComponent(ctx.saleId || (r.contract && r.contract.row.saleId) || '') + '&contractId=' + encodeURIComponent(ctx.contractId || (r.contract && r.contract.row.contractId) || '');
  return {
    contractDetail: base + '?' + params + '&route=contractDetail',
    salesDetail: base + '?' + params + '&route=salesDetail',
    signPrecheck: base + '?' + params + '&route=signPrecheck'
  };
}

function erpFieldB06J41_18_22_result_(label) {
  return { ok: true, label: label, build: FIELD_B06J41_18_22_BUILD, moduleCode: 'ERP_FIELD', checkedAt: new Date().toISOString(), fatal: [], warnings: [], checks: {} };
}
function erpFieldB06J41_18_22_finish_(result, logOutput) {
  result.ok = (result.fatal || []).length === 0;
  if (logOutput) {
    Logger.log('======================================================');
    Logger.log('[' + FIELD_B06J41_18_22_BUILD + '] RESULT');
    Logger.log(JSON.stringify(result, null, 2));
    Logger.log('======================================================');
  }
  return result;
}
function erpFieldB06J41_18_22_headerMap_(headers) {
  var m = {};
  (headers || []).forEach(function (h, i) { if (h !== '') m[String(h).trim()] = i + 1; });
  return m;
}
function erpFieldB06J41_18_22_generateId_(prefix) {
  var d = new Date();
  var pad = function (n) { return String(n).padStart(2, '0'); };
  var ts = d.getFullYear() + pad(d.getMonth() + 1) + pad(d.getDate()) + pad(d.getHours()) + pad(d.getMinutes()) + pad(d.getSeconds());
  return prefix + '-' + ts + '-' + Math.floor(100 + Math.random() * 900);
}
function erpFieldB06J41_18_22_webAppUrl_() {
  try { return ScriptApp.getService().getUrl() || ''; } catch (err) { return ''; }
}
function erpFieldB06J41_18_22_roleName_(roleCode) {
  var map = { VENDOR_OWNER: '업체대표', VENDOR_MANAGER: '업체관리자', STAFF_SALES: '영업직원', VIEWER: '조회전용' };
  return map[roleCode] || roleCode || '-';
}
function erpFieldB06J41_18_22_escape_(v) {
  return String(v == null ? '' : v).replace(/[&<>"']/g, function (c) { return ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]; });
}


/* ===== SignDocFind.js ===== */
/**
 * build: ERP_B06J41_33_36_SIGN_DOCUMENT_DRAFT_LOOKUP_SAFE_UPLOAD
 * module: ERP_FIELD
 * purpose:
 * - B06J41-33 documentId 기준 SIGN_Documents DRAFT READ ONLY 조회
 * - B06J41-34 contractId 기준 기존 documentId 확인
 * - B06J41-35 같은 contractId 문서 중복 생성 차단 상태 확인
 * - B06J41-36 계약 상세 / SIGN 문서 상세 연결 표시
 * safety:
 * - READ ONLY only
 * - no document creation / no SIGN URL / no QR URL / no PDF / no settlement / no external integration / no update/delete
 * - SystemConfig standard header: CONFIG_KEY / VALUE first
 */

var FIELD_B06J41_33_36_BUILD = 'ERP_B06J41_33_36_SIGN_DOCUMENT_DRAFT_LOOKUP_SAFE_UPLOAD';
var FIELD_B06J41_33_36_SETUP_DB_ID = '17VMSpgSZCvIrUlgcw8yCNcnl8WQWo2IcRf5tDCcuJGM';
var FIELD_B06J41_33_36_CONFIG_SHEET_NAME = 'SystemConfig';
var FIELD_B06J41_33_36_SIGN_CANDIDATES = ['SIGN_Documents', 'SIGN_DocumentMaster', 'SIGN_문서관리', 'ERP_SIGN_Documents', 'SIGN_Document'];
var FIELD_B06J41_33_36_CONTRACT_CANDIDATES = ['ERP_계약관리', 'Contracts', 'ERP_Contract'];
var FIELD_B06J41_33_36_SALES_CANDIDATES = ['Sales', 'ERP_판매관리', 'ERP_Sales'];

var FIELD_B06J41_33_36_SIGN_HEADERS = ['documentId','contractId','saleId','eventId','vendorId','customerId','signStatus','pdfStatus','status','statusReason','createdAt','createdBy','updatedAt','updatedBy'];
var FIELD_B06J41_33_36_CONTRACT_HEADERS = ['contractId','saleId','eventId','vendorId','customerId','documentId','status','contractStatus','signStatus','pdfStatus','createdAt','createdBy','updatedAt','updatedBy'];
var FIELD_B06J41_33_36_SALES_HEADERS = ['saleId','eventId','vendorId','customerId','contractId','status'];

function erpB06J41_33_36_preflight() {
  return erpFieldB06J41_33_36_run_({}, true);
}

function erpB06J41_33_36_autoRunSafe() {
  return erpFieldB06J41_33_36_run_({}, true);
}

function erpFieldB06J41_33_36_renderSignDocumentLookupHtml(ctx) {
  var vm = erpFieldB06J41_33_36_buildVm_(ctx || {});
  var t = HtmlService.createTemplateFromFile('P_SignDocFind');
  t.vm = vm;
  t.json = JSON.stringify(vm, null, 2);
  return t.evaluate()
    .setTitle('SIGN 문서 DRAFT 조회')
    .setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL);
}

function erpFieldB06J41_33_36_buildVm_(ctx) {
  ctx = erpFieldB06J41_33_36_normalize_(ctx || {});
  var result = erpFieldB06J41_33_36_run_(ctx, false);
  result.context = ctx;
  result.page = {
    badge: 'B06J41-33_36 SAFE : SIGN DOCUMENT DRAFT LOOKUP',
    title: 'SIGN 문서 DRAFT 조회 / 중복차단 확인',
    subtitle: 'SIGN_Documents DRAFT 문서를 READ ONLY로 조회하고 contractId 기준 중복 문서 생성 차단 상태를 확인합니다.',
    roleName: erpFieldB06J41_33_36_roleName_(ctx.roleCode)
  };
  result.urls = erpFieldB06J41_33_36_urls_(ctx, result);
  return result;
}

function erpFieldB06J41_33_36_run_(ctx, logOutput) {
  ctx = erpFieldB06J41_33_36_normalize_(ctx || {});
  var result = erpFieldB06J41_33_36_result_('signDocumentLookup');
  result.contextSummary = { eventId: ctx.eventId, vendorId: ctx.vendorId, customerId: ctx.customerId, saleId: ctx.saleId, contractId: ctx.contractId, documentId: ctx.documentId };
  try {
    result.checks.config = erpFieldB06J41_33_36_loadConfig_();
    if (!result.checks.config.ok) return erpFieldB06J41_33_36_finish_(result, logOutput);
    var master = erpFieldB06J41_33_36_openMaster_(result.checks.config);
    result.checks.master = master.meta;
    if (!master.ss) {
      result.fatal.push('FEELHAUS_DB_MASTER 연결 실패');
      return erpFieldB06J41_33_36_finish_(result, logOutput);
    }
    var ss = master.ss;
    result.checks.signSheet = erpFieldB06J41_33_36_findSheet_(ss, FIELD_B06J41_33_36_SIGN_CANDIDATES, FIELD_B06J41_33_36_SIGN_HEADERS);
    result.checks.contractSheet = erpFieldB06J41_33_36_findSheet_(ss, FIELD_B06J41_33_36_CONTRACT_CANDIDATES, FIELD_B06J41_33_36_CONTRACT_HEADERS);
    result.checks.salesSheet = erpFieldB06J41_33_36_findSheet_(ss, FIELD_B06J41_33_36_SALES_CANDIDATES, FIELD_B06J41_33_36_SALES_HEADERS);
    if (!result.checks.signSheet.exists) result.fatal.push('SIGN_Documents 시트 없음');
    if (!result.checks.contractSheet.exists) result.fatal.push('Contracts / ERP_계약관리 시트 없음');
    if (!result.checks.salesSheet.exists) result.fatal.push('Sales 시트 없음');
    if ((result.checks.signSheet.missingRequiredHeaders || []).length) result.fatal.push('SIGN_Documents 필수 헤더 누락: ' + result.checks.signSheet.missingRequiredHeaders.join(', '));
    if ((result.checks.contractSheet.missingRequiredHeaders || []).length) result.fatal.push('계약관리 필수 헤더 누락: ' + result.checks.contractSheet.missingRequiredHeaders.join(', '));
    if ((result.checks.salesSheet.missingRequiredHeaders || []).length) result.fatal.push('Sales 필수 헤더 누락: ' + result.checks.salesSheet.missingRequiredHeaders.join(', '));

    result.document = erpFieldB06J41_33_36_findDocument_(result.checks.signSheet.sheet, result.checks.signSheet.headerMap, ctx);
    result.contract = erpFieldB06J41_33_36_findContract_(result.checks.contractSheet.sheet, result.checks.contractSheet.headerMap, ctx, result.document);
    result.sale = erpFieldB06J41_33_36_findSale_(result.checks.salesSheet.sheet, result.checks.salesSheet.headerMap, ctx, result.document, result.contract);
    result.recentDocuments = erpFieldB06J41_33_36_recentDocuments_(result.checks.signSheet.sheet, result.checks.signSheet.headerMap, ctx, 10);
    result.duplicateState = erpFieldB06J41_33_36_duplicateState_(result, ctx);
  } catch (err) {
    result.fatal.push('B06J41-33~36 SIGN document lookup fatal: ' + (err && err.message ? err.message : err));
  }
  return erpFieldB06J41_33_36_finish_(result, logOutput);
}

function erpFieldB06J41_33_36_findDocument_(sheet, map, ctx) {
  var out = { found: false, row: 0, documentId: '', contractId: '', saleId: '', eventId: '', vendorId: '', customerId: '', status: '', signStatus: '', pdfStatus: '', raw: {} };
  if (!sheet || !map) return out;
  var values = sheet.getDataRange().getValues();
  for (var r = 1; r < values.length; r++) {
    var documentId = erpFieldB06J41_33_36_cell_(values[r], map.documentId);
    var contractId = erpFieldB06J41_33_36_cell_(values[r], map.contractId);
    var saleId = erpFieldB06J41_33_36_cell_(values[r], map.saleId);
    var ok = false;
    if (ctx.documentId && documentId === ctx.documentId) ok = true;
    if (!ctx.documentId && ctx.contractId && contractId === ctx.contractId) ok = true;
    if (!ctx.documentId && !ctx.contractId && ctx.saleId && saleId === ctx.saleId) ok = true;
    if (ok) {
      out.found = true;
      out.row = r + 1;
      out.documentId = documentId;
      out.contractId = contractId;
      out.saleId = saleId;
      out.eventId = erpFieldB06J41_33_36_cell_(values[r], map.eventId);
      out.vendorId = erpFieldB06J41_33_36_cell_(values[r], map.vendorId);
      out.customerId = erpFieldB06J41_33_36_cell_(values[r], map.customerId);
      out.status = erpFieldB06J41_33_36_cell_(values[r], map.status);
      out.signStatus = erpFieldB06J41_33_36_cell_(values[r], map.signStatus) || 'NOT_STARTED';
      out.pdfStatus = erpFieldB06J41_33_36_cell_(values[r], map.pdfStatus) || 'NOT_CREATED';
      out.raw = erpFieldB06J41_33_36_rowObject_(values[r], map);
      return out;
    }
  }
  return out;
}

function erpFieldB06J41_33_36_findContract_(sheet, map, ctx, doc) {
  var out = { found: false, row: 0, contractId: '', saleId: '', documentId: '', status: '', signStatus: '', pdfStatus: '', raw: {} };
  if (!sheet || !map) return out;
  var targetContractId = ctx.contractId || (doc && doc.contractId) || '';
  var targetSaleId = ctx.saleId || (doc && doc.saleId) || '';
  var values = sheet.getDataRange().getValues();
  for (var r = 1; r < values.length; r++) {
    var contractId = erpFieldB06J41_33_36_cell_(values[r], map.contractId);
    var saleId = erpFieldB06J41_33_36_cell_(values[r], map.saleId);
    if ((targetContractId && contractId === targetContractId) || (!targetContractId && targetSaleId && saleId === targetSaleId)) {
      out.found = true;
      out.row = r + 1;
      out.contractId = contractId;
      out.saleId = saleId;
      out.documentId = erpFieldB06J41_33_36_cell_(values[r], map.documentId);
      out.status = erpFieldB06J41_33_36_cell_(values[r], map.status) || erpFieldB06J41_33_36_cell_(values[r], map.contractStatus);
      out.signStatus = erpFieldB06J41_33_36_cell_(values[r], map.signStatus) || 'NOT_STARTED';
      out.pdfStatus = erpFieldB06J41_33_36_cell_(values[r], map.pdfStatus) || 'NOT_CREATED';
      out.raw = erpFieldB06J41_33_36_rowObject_(values[r], map);
      return out;
    }
  }
  return out;
}

function erpFieldB06J41_33_36_findSale_(sheet, map, ctx, doc, contract) {
  var out = { found: false, row: 0, saleId: '', contractId: '', status: '', raw: {} };
  if (!sheet || !map) return out;
  var targetSaleId = ctx.saleId || (doc && doc.saleId) || (contract && contract.saleId) || '';
  if (!targetSaleId) return out;
  var values = sheet.getDataRange().getValues();
  for (var r = 1; r < values.length; r++) {
    var saleId = erpFieldB06J41_33_36_cell_(values[r], map.saleId);
    if (saleId === targetSaleId) {
      out.found = true;
      out.row = r + 1;
      out.saleId = saleId;
      out.contractId = erpFieldB06J41_33_36_cell_(values[r], map.contractId);
      out.status = erpFieldB06J41_33_36_cell_(values[r], map.status);
      out.raw = erpFieldB06J41_33_36_rowObject_(values[r], map);
      return out;
    }
  }
  return out;
}

function erpFieldB06J41_33_36_recentDocuments_(sheet, map, ctx, limit) {
  var list = [];
  if (!sheet || !map) return list;
  var values = sheet.getDataRange().getValues();
  for (var r = values.length - 1; r >= 1 && list.length < limit; r--) {
    var eventId = erpFieldB06J41_33_36_cell_(values[r], map.eventId);
    var vendorId = erpFieldB06J41_33_36_cell_(values[r], map.vendorId);
    var customerId = erpFieldB06J41_33_36_cell_(values[r], map.customerId);
    if (ctx.vendorId && vendorId && vendorId !== ctx.vendorId) continue;
    if (ctx.eventId && eventId && eventId !== ctx.eventId) continue;
    if (ctx.customerId && customerId && customerId !== ctx.customerId) continue;
    list.push({
      row: r + 1,
      documentId: erpFieldB06J41_33_36_cell_(values[r], map.documentId),
      contractId: erpFieldB06J41_33_36_cell_(values[r], map.contractId),
      saleId: erpFieldB06J41_33_36_cell_(values[r], map.saleId),
      customerId: customerId,
      status: erpFieldB06J41_33_36_cell_(values[r], map.status),
      signStatus: erpFieldB06J41_33_36_cell_(values[r], map.signStatus) || 'NOT_STARTED',
      pdfStatus: erpFieldB06J41_33_36_cell_(values[r], map.pdfStatus) || 'NOT_CREATED',
      createdAt: erpFieldB06J41_33_36_cell_(values[r], map.createdAt)
    });
  }
  return list;
}

function erpFieldB06J41_33_36_duplicateState_(result, ctx) {
  var existingByContract = result.document.found || (result.contract.found && !!result.contract.documentId);
  var label = existingByContract ? '차단' : '가능후보';
  var reasons = [];
  if (existingByContract) reasons.push('이 contractId에는 이미 SIGN documentId가 존재합니다.');
  if (result.document.found) reasons.push('documentId=' + result.document.documentId + ' / row ' + result.document.row);
  if (result.contract.found && result.contract.documentId) reasons.push('Contracts.documentId=' + result.contract.documentId);
  if (!existingByContract) reasons.push('기존 documentId가 없으면 다음 생성 단계의 후보입니다.');
  return { duplicateCreateBlocked: existingByContract, label: label, reasons: reasons };
}

function erpFieldB06J41_33_36_loadConfig_() {
  var out = { ok: true, fatal: [], warnings: [], setupDbId: FIELD_B06J41_33_36_SETUP_DB_ID, configSheetName: FIELD_B06J41_33_36_CONFIG_SHEET_NAME, headerPolicy: 'CONFIG_KEY/VALUE first', usedHeaderPair: '', configMap: {}, masterId: '', setupDbName: '' };
  try {
    var ss = SpreadsheetApp.openById(FIELD_B06J41_33_36_SETUP_DB_ID);
    out.setupDbName = ss.getName();
    var sh = ss.getSheetByName(FIELD_B06J41_33_36_CONFIG_SHEET_NAME);
    if (!sh) { out.ok = false; out.fatal.push('SystemConfig 시트 없음'); return out; }
    var values = sh.getDataRange().getValues();
    if (values.length < 1) { out.ok = false; out.fatal.push('SystemConfig 데이터 없음'); return out; }
    var headers = values[0].map(function (h) { return String(h || '').trim(); });
    var keyIdx = headers.indexOf('CONFIG_KEY');
    var valIdx = headers.indexOf('VALUE');
    if (keyIdx >= 0 && valIdx >= 0) {
      out.usedHeaderPair = 'CONFIG_KEY/VALUE';
    } else {
      keyIdx = headers.indexOf('configKey');
      valIdx = headers.indexOf('configValue');
      if (keyIdx >= 0 && valIdx >= 0) out.usedHeaderPair = 'configKey/configValue';
    }
    if (keyIdx < 0 || valIdx < 0) {
      keyIdx = headers.indexOf('key');
      valIdx = headers.indexOf('value');
      if (keyIdx >= 0 && valIdx >= 0) out.usedHeaderPair = 'key/value';
    }
    if (keyIdx < 0 || valIdx < 0) { out.ok = false; out.fatal.push('SystemConfig CONFIG_KEY/VALUE 헤더 없음'); return out; }
    for (var r = 1; r < values.length; r++) {
      var k = String(values[r][keyIdx] || '').trim();
      if (!k) continue;
      out.configMap[k] = values[r][valIdx];
    }
    out.masterId = String(out.configMap.FEELHAUS_DB_MASTER_ID || out.configMap.DB_MASTER_ID || out.configMap.SPREADSHEET_ID || '').trim();
    if (!out.masterId) { out.ok = false; out.fatal.push('FEELHAUS_DB_MASTER_ID 설정 없음'); }
  } catch (err) {
    out.ok = false;
    out.fatal.push('SystemConfig 읽기 실패: ' + (err && err.message ? err.message : err));
  }
  return out;
}

function erpFieldB06J41_33_36_openMaster_(config) {
  var meta = { ok: true, fatal: [], warnings: [], usedKey: 'FEELHAUS_DB_MASTER_ID', masterId: config.masterId || '', masterName: 'FEELHAUS_DB_MASTER', masterSpreadsheetName: '' };
  try {
    var ss = SpreadsheetApp.openById(meta.masterId);
    meta.masterSpreadsheetName = ss.getName();
    return { ss: ss, meta: meta };
  } catch (err) {
    meta.ok = false;
    meta.fatal.push('마스터 DB 열기 실패: ' + (err && err.message ? err.message : err));
    return { ss: null, meta: meta };
  }
}

function erpFieldB06J41_33_36_findSheet_(ss, candidates, requiredHeaders) {
  var out = { ok: true, exists: false, sheetName: '', candidates: candidates, lastRow: 0, lastCol: 0, headers: [], headerMap: {}, missingRequiredHeaders: [], sheet: null };
  for (var i = 0; i < candidates.length; i++) {
    var sh = ss.getSheetByName(candidates[i]);
    if (sh) { out.exists = true; out.sheet = sh; out.sheetName = candidates[i]; break; }
  }
  if (!out.exists) { out.ok = false; out.missingRequiredHeaders = requiredHeaders.slice(); return out; }
  out.lastRow = out.sheet.getLastRow();
  out.lastCol = out.sheet.getLastColumn();
  if (out.lastRow < 1 || out.lastCol < 1) { out.ok = false; out.missingRequiredHeaders = requiredHeaders.slice(); return out; }
  out.headers = out.sheet.getRange(1, 1, 1, out.lastCol).getValues()[0].map(function (h) { return String(h || '').trim(); });
  for (var c = 0; c < out.headers.length; c++) if (out.headers[c]) out.headerMap[out.headers[c]] = c + 1;
  for (var j = 0; j < requiredHeaders.length; j++) if (!out.headerMap[requiredHeaders[j]]) out.missingRequiredHeaders.push(requiredHeaders[j]);
  out.ok = out.missingRequiredHeaders.length === 0;
  return out;
}

function erpFieldB06J41_33_36_result_(label) {
  return { ok: true, label: label, build: FIELD_B06J41_33_36_BUILD, moduleCode: 'ERP_FIELD', checkedAt: new Date().toISOString(), fatal: [], warnings: [], checks: {}, document: {}, contract: {}, sale: {}, recentDocuments: [], duplicateState: {} };
}

function erpFieldB06J41_33_36_finish_(result, logOutput) {
  Object.keys(result.checks || {}).forEach(function (k) {
    var c = result.checks[k];
    if (c && c.fatal && c.fatal.length) result.fatal = result.fatal.concat(c.fatal.map(function (m) { return k + ': ' + m; }));
    if (c && c.warnings && c.warnings.length) result.warnings = result.warnings.concat(c.warnings.map(function (m) { return k + ': ' + m; }));
  });
  result.ok = result.fatal.length === 0;
  if (logOutput) {
    Logger.log('======================================================');
    Logger.log('[' + FIELD_B06J41_33_36_BUILD + '] RESULT');
    Logger.log(JSON.stringify(result, null, 2));
    Logger.log('======================================================');
  }
  return result;
}

function erpFieldB06J41_33_36_normalize_(ctx) {
  ctx = ctx || {};
  return {
    roleCode: String(ctx.roleCode || 'VIEWER').trim(),
    vendorId: String(ctx.vendorId || '').trim(),
    eventId: String(ctx.eventId || '').trim(),
    route: String(ctx.route || 'signDocumentDetail').trim(),
    keyword: String(ctx.keyword || '').trim(),
    customerId: String(ctx.customerId || '').trim(),
    saleId: String(ctx.saleId || '').trim(),
    contractId: String(ctx.contractId || '').trim(),
    documentId: String(ctx.documentId || '').trim(),
    userEmail: String(ctx.userEmail || '').trim(),
    scopeType: 'VENDOR_BRANCH_USER_GROUP',
    hqFullAccess: false
  };
}

function erpFieldB06J41_33_36_urls_(ctx, result) {
  var base = erpFieldB06J41_33_36_webAppUrl_();
  var q = 'roleCode=' + encodeURIComponent(ctx.roleCode) + '&vendorId=' + encodeURIComponent(ctx.vendorId) + '&eventId=' + encodeURIComponent(ctx.eventId) + '&customerId=' + encodeURIComponent(ctx.customerId || (result.document && result.document.customerId) || '') + '&saleId=' + encodeURIComponent(ctx.saleId || (result.document && result.document.saleId) || '') + '&contractId=' + encodeURIComponent(ctx.contractId || (result.document && result.document.contractId) || '') + '&documentId=' + encodeURIComponent(ctx.documentId || (result.document && result.document.documentId) || '');
  return {
    contractDetail: base + '?route=contractDetail&' + q,
    signPrecheck: base + '?route=signPrecheck&' + q,
    signDocumentCreate: base + '?route=signDocumentCreate&' + q,
    salesDetail: base + '?route=salesDetail&' + q,
    customerLookup: base + '?route=customerLookup&roleCode=' + encodeURIComponent(ctx.roleCode) + '&vendorId=' + encodeURIComponent(ctx.vendorId) + '&eventId=' + encodeURIComponent(ctx.eventId)
  };
}

function erpFieldB06J41_33_36_webAppUrl_() {
  try { return ScriptApp.getService().getUrl() || ''; } catch (err) { return ''; }
}

function erpFieldB06J41_33_36_roleName_(roleCode) {
  var map = { VENDOR_OWNER: '업체대표', VENDOR_MANAGER: '업체관리자', STAFF_SALES: '영업직원', STAFF_INSTALL: '설치담당', STAFF_AS: 'A/S담당', VIEWER: '조회전용' };
  return map[roleCode] || roleCode || '-';
}

function erpFieldB06J41_33_36_cell_(row, index) {
  if (!index) return '';
  var v = row[index - 1];
  return v == null ? '' : String(v).trim();
}

function erpFieldB06J41_33_36_rowObject_(row, map) {
  var o = {};
  Object.keys(map || {}).forEach(function (k) { o[k] = row[map[k] - 1]; });
  return o;
}

function erpFieldB06J41_33_36_escape_(v) {
  return String(v == null ? '' : v).replace(/[&<>\"]/g, function (s) {
    return ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' })[s];
  });
}


/* ===== SignDocNew.js ===== */
/**
 * build: ERP_B06J41_28_32_SIGN_DOCUMENT_DRAFT_CREATE_SAFE_UPLOAD
 * module: ERP_FIELD
 * purpose:
 * - B06J41-28 documentId 생성
 * - B06J41-29 SIGN_Documents DRAFT 행 생성
 * - B06J41-30 Contracts에 documentId / signStatus / pdfStatus 안전 연결
 * - B06J41-31 Sales documentId 연결은 보류하고 안전 확인만 수행
 * - B06J41-32 SIGN URL/PDF 생성은 차단 유지
 * safety:
 * - document row creation only when documentConfirm=Y
 * - no signUrl / qrUrl / PDF generation / settlement / external integration / delete
 * - SystemConfig standard header: CONFIG_KEY / VALUE first
 */

var FIELD_B06J41_28_32_BUILD = 'ERP_B06J41_28_32_SIGN_DOCUMENT_DRAFT_CREATE_SAFE_UPLOAD';
var FIELD_B06J41_28_32_SETUP_DB_ID = '17VMSpgSZCvIrUlgcw8yCNcnl8WQWo2IcRf5tDCcuJGM';
var FIELD_B06J41_28_32_CONFIG_SHEET_NAME = 'SystemConfig';

var FIELD_B06J41_28_32_SIGN_CANDIDATES = ['SIGN_Documents', 'SIGN_DocumentMaster', 'SIGN_문서관리', 'ERP_SIGN_Documents', 'SIGN_Document'];
var FIELD_B06J41_28_32_CONTRACT_CANDIDATES = ['ERP_계약관리', 'Contracts', 'ERP_Contract'];
var FIELD_B06J41_28_32_SALES_CANDIDATES = ['Sales', 'ERP_판매관리', 'ERP_Sales'];

var FIELD_B06J41_28_32_SIGN_HEADERS = [
  'documentId', 'contractId', 'saleId', 'eventId', 'vendorId', 'customerId',
  'signStatus', 'pdfStatus', 'status', 'statusReason', 'createdAt', 'createdBy', 'updatedAt', 'updatedBy'
];
var FIELD_B06J41_28_32_CONTRACT_HEADERS = [
  'contractId', 'saleId', 'eventId', 'vendorId', 'customerId', 'documentId', 'status', 'contractStatus', 'signStatus', 'pdfStatus', 'createdAt', 'createdBy', 'updatedAt', 'updatedBy'
];
var FIELD_B06J41_28_32_SALES_HEADERS = ['saleId', 'eventId', 'vendorId', 'customerId', 'contractId', 'status'];

function erpB06J41_28_32_preflight() {
  return erpFieldB06J41_28_32_run_({}, false, true);
}

function erpB06J41_28_32_autoRunSafe() {
  var result = erpFieldB06J41_28_32_run_({}, false, true);
  return result;
}

function erpFieldB06J41_28_32_renderSignDocumentDraftCreateHtml(ctx) {
  var vm = erpFieldB06J41_28_32_buildVm_(ctx || {});
  var t = HtmlService.createTemplateFromFile('P_SignDocNew');
  t.vm = vm;
  t.json = JSON.stringify(vm, null, 2);
  return t.evaluate()
    .setTitle('SIGN 문서 DRAFT 생성')
    .setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL);
}

function erpFieldB06J41_28_32_buildVm_(ctx) {
  ctx = erpFieldB06J41_28_32_normalize_(ctx || {});
  var confirmed = String(ctx.documentConfirm || '').toUpperCase() === 'Y';
  var result = erpFieldB06J41_28_32_run_(ctx, confirmed, false);
  result.context = ctx;
  result.page = {
    badge: 'B06J41-28_32 SAFE : SIGN DOCUMENT DRAFT CREATE',
    title: 'SIGN 문서 DRAFT 생성',
    subtitle: '계약 DRAFT 기준 SIGN_Documents에 documentId DRAFT 행을 생성합니다. 서명 URL/PDF/정산은 실행하지 않습니다.',
    roleName: erpFieldB06J41_28_32_roleName_(ctx.roleCode)
  };
  result.urls = erpFieldB06J41_28_32_urls_(ctx, result);
  return result;
}


/**
 * V49 approval guard: only the V49 approved wrapper may create one SIGN_Documents DRAFT row.
 * Direct UI/route calls with documentConfirm=Y remain blocked without this explicit code.
 */
function erpFieldB06J41_28_32_isV49DocumentCreateApproved_(ctx) {
  ctx = ctx || {};
  return String(ctx.approvalCode || ctx.documentApprovalCode || '').trim() === 'FEELHAUS_V49_SIGN_DOCUMENT_CREATE_ONE'
    && String(ctx.documentConfirm || '').toUpperCase() === 'Y'
    && String(ctx.route || '') === 'signDocumentCreate'
    && String(ctx.contractId || '').trim() === 'CON-20260507104428-449'
    && String(ctx.saleId || '').trim() === 'SALE-20260506214734-148';
}

function erpFieldB06J41_28_32_run_(ctx, confirmed, logOutput) {
  ctx = erpFieldB06J41_28_32_normalize_(ctx || {});
  var v49Approved = erpFieldB06J41_28_32_isV49DocumentCreateApproved_(ctx);
  if (confirmed === true && !v49Approved) {
    var blockedDoc = erpFieldB06J41_28_32_result_('blockedByFieldV37');
    blockedDoc.confirmed = true;
    blockedDoc.contextSummary = { eventId: ctx.eventId, vendorId: ctx.vendorId, customerId: ctx.customerId, saleId: ctx.saleId, contractId: ctx.contractId, documentId: ctx.documentId || '' };
    blockedDoc.fatal.push('FIELD SAFETY: SIGN documentId/DRAFT 문서 실제 생성 금지. V49 승인 함수에서 approvalCode 확인 후 1건 제한 생성만 허용.');
    blockedDoc.createResult = { executed: false, status: 'SAFETY_BLOCKED', message: 'V49 승인코드 없는 SIGN documentId 생성 차단' };
    return erpFieldB06J41_28_32_finish_(blockedDoc, logOutput);
  }
  var result = erpFieldB06J41_28_32_result_(confirmed ? 'signDocumentDraftCreate' : 'preflight');
  result.confirmed = confirmed === true;
  result.contextSummary = { eventId: ctx.eventId, vendorId: ctx.vendorId, customerId: ctx.customerId, saleId: ctx.saleId, contractId: ctx.contractId, documentId: ctx.documentId || '' };
  try {
    result.checks.config = erpFieldB06J41_28_32_loadConfig_();
    if (!result.checks.config.ok) return erpFieldB06J41_28_32_finish_(result, logOutput);

    var master = erpFieldB06J41_28_32_openMaster_(result.checks.config);
    result.checks.master = master.meta;
    if (!master.ss) {
      result.fatal.push('FEELHAUS_DB_MASTER 연결 실패');
      return erpFieldB06J41_28_32_finish_(result, logOutput);
    }

    var ss = master.ss;
    result.checks.salesSheet = erpFieldB06J41_28_32_findSheet_(ss, FIELD_B06J41_28_32_SALES_CANDIDATES, FIELD_B06J41_28_32_SALES_HEADERS);
    result.checks.contractSheet = erpFieldB06J41_28_32_findSheet_(ss, FIELD_B06J41_28_32_CONTRACT_CANDIDATES, FIELD_B06J41_28_32_CONTRACT_HEADERS);
    result.checks.signSheet = erpFieldB06J41_28_32_findSheet_(ss, FIELD_B06J41_28_32_SIGN_CANDIDATES, FIELD_B06J41_28_32_SIGN_HEADERS);
    result.checks.coreLog = erpFieldB06J41_28_32_findSheet_(ss, ['ERP_CoreLog', 'ERP_Log'], ['logId', 'build', 'moduleCode', 'functionName', 'actionType', 'eventId', 'vendorId', 'customerId', 'saleId', 'contractId', 'documentId', 'payloadJson', 'createdAt', 'createdBy']);

    if (!result.checks.salesSheet.exists) result.fatal.push('Sales 시트 없음');
    if (!result.checks.contractSheet.exists) result.fatal.push('Contracts / ERP_계약관리 시트 없음');
    if (!result.checks.signSheet.exists) result.fatal.push('SIGN_Documents 시트 없음');
    if ((result.checks.salesSheet.missingRequiredHeaders || []).length) result.fatal.push('Sales 필수 헤더 누락: ' + result.checks.salesSheet.missingRequiredHeaders.join(', '));
    if ((result.checks.contractSheet.missingRequiredHeaders || []).length) result.fatal.push('계약관리 필수 헤더 누락: ' + result.checks.contractSheet.missingRequiredHeaders.join(', '));
    if ((result.checks.signSheet.missingRequiredHeaders || []).length) result.fatal.push('SIGN_Documents 필수 헤더 누락: ' + result.checks.signSheet.missingRequiredHeaders.join(', '));

    result.contract = erpFieldB06J41_28_32_findContract_(result.checks.contractSheet.sheet, result.checks.contractSheet.headerMap, ctx);
    result.sale = erpFieldB06J41_28_32_findSaleAny_(ss, result.checks.salesSheet, ctx);
    result.existingDocument = erpFieldB06J41_28_32_findExistingDocument_(result.checks.signSheet.sheet, result.checks.signSheet.headerMap, ctx, result.contract);

    result.plannedDocumentId = ctx.documentId || (result.contract.documentId || '') || (result.existingDocument.documentId || '') || erpFieldB06J41_28_32_generateId_('DOC');
    result.readiness = erpFieldB06J41_28_32_readiness_(result, ctx);

    if (confirmed && result.readiness.readyForDocumentDraftCreate) {
      result.createResult = erpFieldB06J41_28_32_createDocumentDraft_(ss, result, ctx);
    } else if (confirmed && !result.readiness.readyForDocumentDraftCreate) {
      result.createResult = { executed: false, status: 'BLOCKED', message: 'SIGN 문서 DRAFT 생성 조건 미충족', issues: result.readiness.blockingIssues };
    } else {
      result.createResult = { executed: false, status: 'READY_CHECK_ONLY', message: 'documentConfirm=Y일 때만 SIGN 문서 DRAFT를 생성합니다.' };
    }
  } catch (err) {
    result.fatal.push('B06J41-28~32 SIGN document draft fatal: ' + (err && err.message ? err.message : err));
  }
  return erpFieldB06J41_28_32_finish_(result, logOutput);
}

function erpFieldB06J41_28_32_findContract_(sheet, map, ctx) {
  var out = { found: false, row: 0, contractId: '', saleId: '', customerId: '', eventId: '', vendorId: '', status: '', documentId: '', signStatus: '', pdfStatus: '', amount: 0, raw: {} };
  if (!sheet || !map) return out;
  var values = sheet.getDataRange().getValues();
  for (var r = 1; r < values.length; r++) {
    var contractId = erpFieldB06J41_28_32_cell_(values[r], map.contractId);
    var saleId = erpFieldB06J41_28_32_cell_(values[r], map.saleId);
    if ((ctx.contractId && contractId === ctx.contractId) || (!ctx.contractId && ctx.saleId && saleId === ctx.saleId)) {
      out.found = true;
      out.row = r + 1;
      out.contractId = contractId;
      out.saleId = saleId;
      out.customerId = erpFieldB06J41_28_32_cell_(values[r], map.customerId);
      out.eventId = erpFieldB06J41_28_32_cell_(values[r], map.eventId);
      out.vendorId = erpFieldB06J41_28_32_cell_(values[r], map.vendorId);
      out.status = erpFieldB06J41_28_32_cell_(values[r], map.status) || erpFieldB06J41_28_32_cell_(values[r], map.contractStatus);
      out.documentId = erpFieldB06J41_28_32_cell_(values[r], map.documentId);
      out.signStatus = erpFieldB06J41_28_32_cell_(values[r], map.signStatus) || 'NOT_STARTED';
      out.pdfStatus = erpFieldB06J41_28_32_cell_(values[r], map.pdfStatus) || 'NOT_CREATED';
      out.amount = Number(erpFieldB06J41_28_32_cell_(values[r], map.contractAmount) || erpFieldB06J41_28_32_cell_(values[r], map.totalAmount) || 0);
      out.raw = erpFieldB06J41_28_32_rowObject_(values[r], map);
      return out;
    }
  }
  return out;
}

function erpFieldB06J41_28_32_findSale_(sheet, map, ctx) {
  var out = { found: false, row: 0, saleId: '', contractId: '', documentId: '', status: '', raw: {} };
  if (!sheet || !map || !ctx.saleId) return out;
  var values = sheet.getDataRange().getValues();
  for (var r = 1; r < values.length; r++) {
    var saleId = erpFieldB06J41_28_32_cell_(values[r], map.saleId);
    if (saleId === ctx.saleId) {
      out.found = true;
      out.row = r + 1;
      out.saleId = saleId;
      out.contractId = erpFieldB06J41_28_32_cell_(values[r], map.contractId);
      out.documentId = erpFieldB06J41_28_32_cell_(values[r], map.documentId);
      out.status = erpFieldB06J41_28_32_cell_(values[r], map.status);
      out.raw = erpFieldB06J41_28_32_rowObject_(values[r], map);
      return out;
    }
  }
  return out;
}


/**
 * V48 helper: sale lookup must not be locked to the first Sales candidate.
 * FIELD DRAFT source currently lives in ERP_판매관리 while legacy Sales can exist first.
 * This scans every candidate by header map and returns the matching saleId without writing.
 */
function erpFieldB06J41_28_32_findSaleAny_(ss, primaryInfo, ctx) {
  var base = { found: false, row: 0, saleId: '', contractId: '', documentId: '', status: '', raw: {}, sheetName: '', scannedSheets: [] };
  if (!ss || !ctx || !ctx.saleId) return base;

  // V52 fix: do not accept the first legacy Sales hit blindly.
  // Prefer the FIELD source sheet (ERP_판매관리) and/or a row that matches the target contractId.
  // Older Sales rows can share saleId but may have a different/blank contract bridge and caused readiness=false.
  var candidates = ['ERP_판매관리', 'Sales', 'ERP_Sales'];
  var seen = {};
  var firstHit = null;
  var preferredHit = null;
  var targetSaleId = String(ctx.saleId || '').trim();
  var targetContractId = String(ctx.contractId || '').trim();

  for (var i = 0; i < candidates.length; i++) {
    var name = candidates[i];
    if (!name || seen[name]) continue;
    seen[name] = true;
    var sheet = ss.getSheetByName(name);
    if (!sheet) {
      base.scannedSheets.push({ sheetName: name, exists: false, found: false });
      continue;
    }
    var values = sheet.getDataRange().getValues();
    var headers = values.length ? values[0] : [];
    var map = {};
    for (var h = 0; h < headers.length; h++) {
      if (headers[h] !== '' && headers[h] != null) map[String(headers[h]).trim()] = h + 1;
    }
    if (!map.saleId) {
      base.scannedSheets.push({ sheetName: name, exists: true, hasSaleIdHeader: false, found: false });
      continue;
    }
    var sheetFound = false;
    for (var r = 1; r < values.length; r++) {
      var saleId = erpFieldB06J41_28_32_cell_(values[r], map.saleId);
      if (String(saleId || '').trim() !== targetSaleId) continue;
      sheetFound = true;
      var contractId = erpFieldB06J41_28_32_cell_(values[r], map.contractId);
      var hit = {
        found: true,
        row: r + 1,
        saleId: saleId,
        contractId: contractId,
        documentId: erpFieldB06J41_28_32_cell_(values[r], map.documentId),
        status: erpFieldB06J41_28_32_cell_(values[r], map.status),
        raw: erpFieldB06J41_28_32_rowObject_(values[r], map),
        sheetName: name,
        scannedSheets: base.scannedSheets.concat([{ sheetName: name, exists: true, hasSaleIdHeader: true, found: true, rowNumber: r + 1, contractId: contractId }])
      };
      if (!firstHit) firstHit = hit;
      if (targetContractId && contractId === targetContractId) return hit;
      if (name === 'ERP_판매관리' && (!contractId || !targetContractId || contractId === targetContractId)) preferredHit = hit;
    }
    base.scannedSheets.push({ sheetName: name, exists: true, hasSaleIdHeader: true, found: sheetFound, lastRow: values.length });
  }
  if (preferredHit) return preferredHit;
  if (firstHit) return firstHit;
  return base;
}

function erpFieldB06J41_28_32_findExistingDocument_(sheet, map, ctx, contract) {
  var out = { found: false, row: 0, documentId: '', contractId: '', saleId: '', status: '', signStatus: '', pdfStatus: '', raw: {} };
  if (!sheet || !map) return out;
  var targetContractId = ctx.contractId || (contract && contract.contractId) || '';
  var targetSaleId = ctx.saleId || (contract && contract.saleId) || '';
  var values = sheet.getDataRange().getValues();
  for (var r = 1; r < values.length; r++) {
    var documentId = erpFieldB06J41_28_32_cell_(values[r], map.documentId);
    var contractId = erpFieldB06J41_28_32_cell_(values[r], map.contractId);
    var saleId = erpFieldB06J41_28_32_cell_(values[r], map.saleId);
    if ((targetContractId && contractId === targetContractId) || (targetSaleId && saleId === targetSaleId) || (ctx.documentId && documentId === ctx.documentId)) {
      out.found = true;
      out.row = r + 1;
      out.documentId = documentId;
      out.contractId = contractId;
      out.saleId = saleId;
      out.status = erpFieldB06J41_28_32_cell_(values[r], map.status);
      out.signStatus = erpFieldB06J41_28_32_cell_(values[r], map.signStatus);
      out.pdfStatus = erpFieldB06J41_28_32_cell_(values[r], map.pdfStatus);
      out.raw = erpFieldB06J41_28_32_rowObject_(values[r], map);
      return out;
    }
  }
  return out;
}

function erpFieldB06J41_28_32_readiness_(result, ctx) {
  var issues = [];
  if (!ctx.vendorId) issues.push('vendorId 누락');
  if (!ctx.eventId) issues.push('eventId 누락');
  if (!ctx.saleId) issues.push('saleId 누락');
  if (!ctx.contractId && !(result.contract && result.contract.contractId)) issues.push('contractId 누락');
  if (!result.contract.found) issues.push('계약 DRAFT를 찾지 못함');
  if (result.contract.found && String(result.contract.status || '').toUpperCase() !== 'DRAFT') issues.push('계약 상태가 DRAFT가 아님: ' + result.contract.status);
  if (!result.sale.found) issues.push('Sales 원전표를 찾지 못함');
  if (result.sale.found && result.sale.contractId && result.contract.found && result.sale.contractId !== result.contract.contractId) issues.push('Sales contractId와 계약 contractId 불일치');
  if (result.existingDocument.found || (result.contract && result.contract.documentId)) issues.push('이미 documentId가 존재하여 중복 생성 차단');
  return {
    readyForDocumentDraftCreate: issues.length === 0,
    blockingIssues: issues,
    plannedDocumentId: result.plannedDocumentId,
    noSignUrlInThisBuild: true,
    noPdfInThisBuild: true,
    salesDocumentIdUpdatePolicy: 'CHECK_ONLY'
  };
}

function erpFieldB06J41_28_32_createDocumentDraft_(ss, result, ctx) {
  var signSheetInfo = result.checks.signSheet;
  var contractSheetInfo = result.checks.contractSheet;
  var logSheetInfo = result.checks.coreLog;
  var now = new Date();
  var user = ctx.userEmail || 'FIELD_USER';
  var documentId = result.plannedDocumentId;
  var docRow = {
    documentId: documentId,
    contractId: result.contract.contractId,
    saleId: result.contract.saleId || ctx.saleId,
    eventId: ctx.eventId || result.contract.eventId,
    vendorId: ctx.vendorId || result.contract.vendorId,
    customerId: ctx.customerId || result.contract.customerId,
    signStatus: 'NOT_STARTED',
    pdfStatus: 'NOT_CREATED',
    status: 'DRAFT',
    statusReason: 'FIELD_SIGN_DOCUMENT_DRAFT_CREATED',
    createdAt: now,
    createdBy: user,
    updatedAt: now,
    updatedBy: user,
    documentType: 'CONTRACT',
    sourceProject: 'ERP_FIELD',
    sourceModule: 'B06J41_28_32'
  };
  erpFieldB06J41_28_32_appendObjectRow_(signSheetInfo.sheet, signSheetInfo.headerMap, docRow);

  var contractUpdates = {
    documentId: documentId,
    signStatus: 'NOT_STARTED',
    pdfStatus: 'NOT_CREATED',
    updatedAt: now,
    updatedBy: user
  };
  erpFieldB06J41_28_32_updateRow_(contractSheetInfo.sheet, contractSheetInfo.headerMap, result.contract.row, contractUpdates);

  var logResult = erpFieldB06J41_28_32_log_(logSheetInfo, {
    logId: erpFieldB06J41_28_32_generateId_('LOG'),
    build: FIELD_B06J41_28_32_BUILD,
    moduleCode: 'ERP_FIELD',
    functionName: 'erpFieldB06J41_28_32_createDocumentDraft_',
    actionType: 'SIGN_DOCUMENT_DRAFT_CREATE',
    eventId: ctx.eventId,
    vendorId: ctx.vendorId,
    customerId: ctx.customerId || result.contract.customerId,
    saleId: ctx.saleId || result.contract.saleId,
    contractId: result.contract.contractId,
    documentId: documentId,
    payloadJson: JSON.stringify({ noSignUrl: true, noPdf: true, noExternalIntegration: true }),
    createdAt: now,
    createdBy: user
  });

  return {
    executed: true,
    status: 'CREATED',
    message: 'SIGN 문서 DRAFT가 생성되었습니다.',
    documentId: documentId,
    signStatus: 'NOT_STARTED',
    pdfStatus: 'NOT_CREATED',
    signRowAppended: true,
    contractUpdated: true,
    salesUpdated: false,
    salesUpdatePolicy: 'CHECK_ONLY',
    log: logResult
  };
}

function erpFieldB06J41_28_32_appendObjectRow_(sheet, map, obj) {
  var lastCol = sheet.getLastColumn();
  var row = [];
  for (var c = 1; c <= lastCol; c++) row.push('');
  Object.keys(obj).forEach(function (k) {
    if (map[k]) row[map[k] - 1] = obj[k];
  });
  sheet.appendRow(row);
}

function erpFieldB06J41_28_32_updateRow_(sheet, map, rowNum, obj) {
  Object.keys(obj).forEach(function (k) {
    if (map[k]) sheet.getRange(rowNum, map[k]).setValue(obj[k]);
  });
}

function erpFieldB06J41_28_32_log_(logInfo, obj) {
  try {
    if (!logInfo || !logInfo.sheet || !logInfo.headerMap) return { ok: false, reason: 'ERP_CoreLog 없음' };
    erpFieldB06J41_28_32_appendObjectRow_(logInfo.sheet, logInfo.headerMap, obj);
    return { ok: true, logId: obj.logId };
  } catch (err) {
    return { ok: false, reason: String(err && err.message ? err.message : err) };
  }
}

function erpFieldB06J41_28_32_findSheet_(ss, candidates, requiredHeaders) {
  var out = { ok: false, exists: false, sheetName: '', candidates: candidates, lastRow: 0, lastCol: 0, headers: [], headerMap: {}, missingRequiredHeaders: [], sheet: null };
  if (!ss) return out;
  for (var i = 0; i < candidates.length; i++) {
    var sh = ss.getSheetByName(candidates[i]);
    if (!sh) continue;
    out.exists = true;
    out.sheet = sh;
    out.sheetName = sh.getName();
    out.lastRow = sh.getLastRow();
    out.lastCol = sh.getLastColumn();
    out.headers = erpFieldB06J41_28_32_headers_(sh);
    out.headerMap = erpFieldB06J41_28_32_headerMap_(out.headers);
    out.missingRequiredHeaders = erpFieldB06J41_28_32_missing_(out.headerMap, requiredHeaders || []);
    out.ok = out.missingRequiredHeaders.length === 0;
    return out;
  }
  out.missingRequiredHeaders = (requiredHeaders || []).slice();
  return out;
}

function erpFieldB06J41_28_32_loadConfig_() {
  var out = { ok: true, fatal: [], warnings: [], setupDbId: FIELD_B06J41_28_32_SETUP_DB_ID, configSheetName: FIELD_B06J41_28_32_CONFIG_SHEET_NAME, headerPolicy: 'CONFIG_KEY/VALUE first', usedHeaderPair: '', configMap: {} };
  try {
    var ss = SpreadsheetApp.openById(FIELD_B06J41_28_32_SETUP_DB_ID);
    out.setupDbName = ss.getName();
    var sh = ss.getSheetByName(FIELD_B06J41_28_32_CONFIG_SHEET_NAME);
    if (!sh) throw new Error('SystemConfig 시트 없음');
    var values = sh.getDataRange().getValues();
    if (values.length < 2) throw new Error('SystemConfig 데이터 없음');
    var headerMap = erpFieldB06J41_28_32_headerMap_(values[0]);
    var keyCol = 0;
    var valCol = 0;
    if (headerMap.CONFIG_KEY && headerMap.VALUE) { keyCol = headerMap.CONFIG_KEY; valCol = headerMap.VALUE; out.usedHeaderPair = 'CONFIG_KEY/VALUE'; }
    else if (headerMap.configKey && headerMap.configValue) { keyCol = headerMap.configKey; valCol = headerMap.configValue; out.usedHeaderPair = 'configKey/configValue'; }
    else if (headerMap.key && headerMap.value) { keyCol = headerMap.key; valCol = headerMap.value; out.usedHeaderPair = 'key/value'; }
    else throw new Error('SystemConfig CONFIG_KEY/VALUE 헤더 없음');
    for (var r = 1; r < values.length; r++) {
      var k = String(values[r][keyCol - 1] || '').trim();
      if (k) out.configMap[k] = values[r][valCol - 1];
    }
    out.configCount = Object.keys(out.configMap).length;
    out.masterId = String(out.configMap.FEELHAUS_DB_MASTER_ID || out.configMap.DB_MASTER_ID || out.configMap.SPREADSHEET_ID || '').trim();
  } catch (err) {
    out.ok = false;
    out.fatal.push(String(err && err.message ? err.message : err));
  }
  return out;
}

function erpFieldB06J41_28_32_openMaster_(config) {
  var meta = { ok: false, fatal: [], warnings: [], usedKey: '', masterId: '', masterName: 'FEELHAUS_DB_MASTER', masterSpreadsheetName: '' };
  try {
    var cm = (config && config.configMap) || {};
    var id = String(cm.FEELHAUS_DB_MASTER_ID || cm.DB_MASTER_ID || cm.SPREADSHEET_ID || '').trim();
    meta.usedKey = cm.FEELHAUS_DB_MASTER_ID ? 'FEELHAUS_DB_MASTER_ID' : (cm.DB_MASTER_ID ? 'DB_MASTER_ID' : 'SPREADSHEET_ID');
    meta.masterId = id;
    if (!id) throw new Error('마스터 ID 없음');
    var ss = SpreadsheetApp.openById(id);
    meta.masterSpreadsheetName = ss.getName();
    meta.ok = true;
    return { ss: ss, meta: meta };
  } catch (err) {
    meta.fatal.push(String(err && err.message ? err.message : err));
    return { ss: null, meta: meta };
  }
}

function erpFieldB06J41_28_32_normalize_(ctx) {
  ctx = ctx || {};
  return {
    roleCode: String(ctx.roleCode || 'VIEWER').trim(),
    vendorId: String(ctx.vendorId || '').trim(),
    eventId: String(ctx.eventId || '').trim(),
    route: String(ctx.route || 'signDocumentCreate').trim(),
    customerId: String(ctx.customerId || '').trim(),
    saleId: String(ctx.saleId || '').trim(),
    contractId: String(ctx.contractId || '').trim(),
    documentId: String(ctx.documentId || '').trim(),
    documentConfirm: String(ctx.documentConfirm || ctx.signDocumentConfirm || '').trim(),
    approvalCode: String(ctx.approvalCode || ctx.documentApprovalCode || '').trim(),
    documentApprovalCode: String(ctx.documentApprovalCode || ctx.approvalCode || '').trim(),
    userEmail: String(ctx.userEmail || '').trim(),
    scopeType: 'VENDOR_BRANCH_USER_GROUP',
    hqFullAccess: false
  };
}

function erpFieldB06J41_28_32_result_(label) {
  return {
    ok: true,
    label: label,
    build: FIELD_B06J41_28_32_BUILD,
    moduleCode: 'ERP_FIELD',
    checkedAt: new Date().toISOString(),
    fatal: [],
    warnings: [],
    checks: {},
    safety: {
      documentDraftCreateOnlyWhenConfirmed: true,
      noSignUrlCreate: true,
      noQrUrlCreate: true,
      noPdfCreate: true,
      noSettlementExecution: true,
      noExternalIntegration: true,
      noUpdateDelete: true,
      systemConfigHeaderStandard: 'CONFIG_KEY/VALUE first'
    }
  };
}

function erpFieldB06J41_28_32_finish_(result, logOutput) {
  Object.keys(result.checks || {}).forEach(function (k) {
    var c = result.checks[k];
    if (c && c.fatal && c.fatal.length) result.fatal = result.fatal.concat(c.fatal.map(function (m) { return k + ': ' + m; }));
    if (c && c.warnings && c.warnings.length) result.warnings = result.warnings.concat(c.warnings.map(function (m) { return k + ': ' + m; }));
  });
  result.ok = result.fatal.length === 0;
  if (logOutput) {
    Logger.log('======================================================');
    Logger.log('[' + FIELD_B06J41_28_32_BUILD + '] RESULT');
    Logger.log(JSON.stringify(result, null, 2));
    Logger.log('======================================================');
  }
  return result;
}

function erpFieldB06J41_28_32_headers_(sheet) {
  if (!sheet || sheet.getLastColumn() < 1) return [];
  return sheet.getRange(1, 1, 1, sheet.getLastColumn()).getValues()[0].map(function (h) { return String(h || '').trim(); });
}

function erpFieldB06J41_28_32_headerMap_(headers) {
  var map = {};
  (headers || []).forEach(function (h, i) { if (h && !map[h]) map[h] = i + 1; });
  return map;
}

function erpFieldB06J41_28_32_missing_(map, headers) {
  var missing = [];
  (headers || []).forEach(function (h) { if (!map[h]) missing.push(h); });
  return missing;
}

function erpFieldB06J41_28_32_cell_(row, col) {
  if (!col) return '';
  return String(row[col - 1] == null ? '' : row[col - 1]).trim();
}

function erpFieldB06J41_28_32_rowObject_(row, map) {
  var out = {};
  Object.keys(map || {}).forEach(function (k) { out[k] = row[map[k] - 1]; });
  return out;
}

function erpFieldB06J41_28_32_generateId_(prefix) {
  var tz = Session.getScriptTimeZone ? Session.getScriptTimeZone() : 'Asia/Seoul';
  var stamp = Utilities.formatDate(new Date(), tz || 'Asia/Seoul', 'yyyyMMddHHmmss');
  var rand = Math.floor(Math.random() * 900) + 100;
  return prefix + '-' + stamp + '-' + rand;
}

function erpFieldB06J41_28_32_urls_(ctx, result) {
  var base = '';
  try { base = ScriptApp.getService().getUrl() || ''; } catch (err) { base = ''; }
  var q = 'roleCode=' + encodeURIComponent(ctx.roleCode) +
    '&vendorId=' + encodeURIComponent(ctx.vendorId) +
    '&eventId=' + encodeURIComponent(ctx.eventId) +
    '&saleId=' + encodeURIComponent(ctx.saleId) +
    '&contractId=' + encodeURIComponent(ctx.contractId || (result.contract && result.contract.contractId) || '') +
    '&customerId=' + encodeURIComponent(ctx.customerId || (result.contract && result.contract.customerId) || '');
  return {
    base: base,
    self: base + '?route=signDocumentCreate&' + q,
    confirmed: base + '?route=signDocumentCreate&documentConfirm=Y&' + q,
    contractDetail: base + '?route=contractDetail&' + q,
    signPrecheck: base + '?route=signPrecheck&' + q
  };
}

function erpFieldB06J41_28_32_roleName_(roleCode) {
  var map = { VENDOR_OWNER: '업체대표', VENDOR_MANAGER: '업체관리자', STAFF_SALES: '영업직원', STAFF_INSTALL: '설치담당', STAFF_AS: 'A/S담당', VIEWER: '조회전용' };
  return map[roleCode] || roleCode || '';
}


/* ===== SignUrlChk.js ===== */
/**
 * build: ERP_B06J41_37_40_SIGN_URL_PRECHECK_SAFE_UPLOAD
 * module: ERP_FIELD
 * purpose:
 * - B06J41-37 SIGN 문서 DRAFT 기준 URL 생성 후보 검증
 * - B06J41-38 SIGN_WEBAPP_URL / ERP_FIELD_WEBAPP_URL 설정 확인
 * - B06J41-39 QR/서명 URL 미리보기
 * - B06J41-40 URL 저장 차단 유지
 * safety:
 * - READ ONLY only
 * - no signUrl save / no qrUrl save / no PDF / no external integration / no update/delete
 * - SystemConfig standard header: CONFIG_KEY / VALUE first
 */

var FIELD_B06J41_37_40_BUILD = 'ERP_B06J41_37_40_SIGN_URL_PRECHECK_SAFE_UPLOAD';
var FIELD_B06J41_37_40_SETUP_DB_ID = '17VMSpgSZCvIrUlgcw8yCNcnl8WQWo2IcRf5tDCcuJGM';
var FIELD_B06J41_37_40_CONFIG_SHEET_NAME = 'SystemConfig';
var FIELD_B06J41_37_40_SIGN_CANDIDATES = ['SIGN_Documents', 'SIGN_DocumentMaster', 'SIGN_문서관리', 'ERP_SIGN_Documents', 'SIGN_Document'];
var FIELD_B06J41_37_40_CONTRACT_CANDIDATES = ['ERP_계약관리', 'Contracts', 'ERP_Contract'];
var FIELD_B06J41_37_40_SALES_CANDIDATES = ['Sales', 'ERP_판매관리', 'ERP_Sales'];

function erpB06J41_37_40_preflight() {
  return erpFieldB06J41_37_40_run_({}, true);
}

function erpB06J41_37_40_autoRunSafe() {
  return erpFieldB06J41_37_40_run_({}, true);
}

function erpFieldB06J41_37_40_renderSignUrlPrecheckHtml(ctx) {
  var vm = erpFieldB06J41_37_40_buildVm_(ctx || {});
  var t = HtmlService.createTemplateFromFile('P_SignUrlChk');
  t.vm = vm;
  t.json = JSON.stringify(vm, null, 2);
  return t.evaluate().setTitle('SIGN URL 프리체크').setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL);
}

function erpFieldB06J41_37_40_buildVm_(ctx) {
  ctx = erpFieldB06J41_37_40_normalize_(ctx || {});
  var result = erpFieldB06J41_37_40_run_(ctx, false);
  result.context = ctx;
  result.page = {
    badge: 'B06J41-37_40 SAFE : SIGN URL PRECHECK',
    title: 'SIGN URL / QR URL 생성 프리체크',
    subtitle: 'SIGN 문서 DRAFT를 기준으로 서명 URL/QR URL 생성 가능성을 READ ONLY로 확인합니다. URL 저장/PDF 생성은 아직 실행하지 않습니다.',
    roleName: erpFieldB06J41_37_40_roleName_(ctx.roleCode)
  };
  result.urls = erpFieldB06J41_37_40_urls_(ctx, result);
  return result;
}

function erpFieldB06J41_37_40_run_(ctx, logOutput) {
  ctx = erpFieldB06J41_37_40_normalize_(ctx || {});
  var result = erpFieldB06J41_37_40_result_('signUrlPrecheck');
  result.contextSummary = { eventId: ctx.eventId, vendorId: ctx.vendorId, customerId: ctx.customerId, saleId: ctx.saleId, contractId: ctx.contractId, documentId: ctx.documentId };
  try {
    result.checks.config = erpFieldB06J41_37_40_loadConfig_();
    if (!result.checks.config.ok) return erpFieldB06J41_37_40_finish_(result, logOutput);
    var master = erpFieldB06J41_37_40_openMaster_(result.checks.config);
    result.checks.master = master.meta;
    if (!master.ss) {
      result.fatal.push('FEELHAUS_DB_MASTER 연결 실패');
      return erpFieldB06J41_37_40_finish_(result, logOutput);
    }
    var ss = master.ss;
    result.checks.signSheet = erpFieldB06J41_37_40_findSheet_(ss, FIELD_B06J41_37_40_SIGN_CANDIDATES, ['documentId','contractId','saleId','eventId','vendorId','customerId','status','signStatus','pdfStatus','createdAt','createdBy','updatedAt','updatedBy']);
    result.checks.contractSheet = erpFieldB06J41_37_40_findSheet_(ss, FIELD_B06J41_37_40_CONTRACT_CANDIDATES, ['contractId','saleId','eventId','vendorId','customerId','documentId','status','signStatus','pdfStatus']);
    result.checks.salesSheet = erpFieldB06J41_37_40_findSheet_(ss, FIELD_B06J41_37_40_SALES_CANDIDATES, ['saleId','eventId','vendorId','customerId','contractId','status']);
    if (!result.checks.signSheet.exists) result.fatal.push('SIGN_Documents 시트 없음');
    if (!result.checks.contractSheet.exists) result.fatal.push('Contracts / ERP_계약관리 시트 없음');
    if (!result.checks.salesSheet.exists) result.fatal.push('Sales 시트 없음');
    if ((result.checks.signSheet.missingRequiredHeaders || []).length) result.fatal.push('SIGN_Documents 필수 헤더 누락: ' + result.checks.signSheet.missingRequiredHeaders.join(', '));

    result.document = erpFieldB06J41_37_40_findDocument_(result.checks.signSheet.sheet, result.checks.signSheet.headerMap, ctx);
    result.contract = erpFieldB06J41_37_40_findContract_(result.checks.contractSheet.sheet, result.checks.contractSheet.headerMap, ctx, result.document);
    result.sale = erpFieldB06J41_37_40_findSale_(result.checks.salesSheet.sheet, result.checks.salesSheet.headerMap, ctx, result.document, result.contract);
    result.urlPolicy = erpFieldB06J41_37_40_urlPolicy_(result.checks.config, ctx, result);
    result.readiness = erpFieldB06J41_37_40_readiness_(result, ctx);
  } catch (err) {
    result.fatal.push('B06J41-37~40 SIGN URL precheck fatal: ' + (err && err.message ? err.message : err));
  }
  return erpFieldB06J41_37_40_finish_(result, logOutput);
}

function erpFieldB06J41_37_40_findDocument_(sheet, map, ctx) {
  var out = { found: false, row: 0, documentId: '', contractId: '', saleId: '', eventId: '', vendorId: '', customerId: '', status: '', signStatus: '', pdfStatus: '', raw: {} };
  if (!sheet || !map) return out;
  var values = sheet.getDataRange().getValues();
  for (var r = 1; r < values.length; r++) {
    var documentId = erpFieldB06J41_37_40_cell_(values[r], map.documentId);
    var contractId = erpFieldB06J41_37_40_cell_(values[r], map.contractId);
    var saleId = erpFieldB06J41_37_40_cell_(values[r], map.saleId);
    var ok = false;
    if (ctx.documentId && documentId === ctx.documentId) ok = true;
    if (!ctx.documentId && ctx.contractId && contractId === ctx.contractId) ok = true;
    if (!ctx.documentId && !ctx.contractId && ctx.saleId && saleId === ctx.saleId) ok = true;
    if (ok) {
      out.found = true;
      out.row = r + 1;
      out.documentId = documentId;
      out.contractId = contractId;
      out.saleId = saleId;
      out.eventId = erpFieldB06J41_37_40_cell_(values[r], map.eventId);
      out.vendorId = erpFieldB06J41_37_40_cell_(values[r], map.vendorId);
      out.customerId = erpFieldB06J41_37_40_cell_(values[r], map.customerId);
      out.status = erpFieldB06J41_37_40_cell_(values[r], map.status) || 'DRAFT';
      out.signStatus = erpFieldB06J41_37_40_cell_(values[r], map.signStatus) || 'NOT_STARTED';
      out.pdfStatus = erpFieldB06J41_37_40_cell_(values[r], map.pdfStatus) || 'NOT_CREATED';
      out.raw = erpFieldB06J41_37_40_rowObject_(values[r], map);
      return out;
    }
  }
  return out;
}

function erpFieldB06J41_37_40_findContract_(sheet, map, ctx, doc) {
  var out = { found: false, row: 0, contractId: '', saleId: '', documentId: '', status: '', signStatus: '', pdfStatus: '', raw: {} };
  if (!sheet || !map) return out;
  var targetContractId = ctx.contractId || (doc && doc.contractId) || '';
  var targetSaleId = ctx.saleId || (doc && doc.saleId) || '';
  var values = sheet.getDataRange().getValues();
  for (var r = 1; r < values.length; r++) {
    var contractId = erpFieldB06J41_37_40_cell_(values[r], map.contractId);
    var saleId = erpFieldB06J41_37_40_cell_(values[r], map.saleId);
    if ((targetContractId && contractId === targetContractId) || (!targetContractId && targetSaleId && saleId === targetSaleId)) {
      out.found = true;
      out.row = r + 1;
      out.contractId = contractId;
      out.saleId = saleId;
      out.documentId = erpFieldB06J41_37_40_cell_(values[r], map.documentId);
      out.status = erpFieldB06J41_37_40_cell_(values[r], map.status) || 'DRAFT';
      out.signStatus = erpFieldB06J41_37_40_cell_(values[r], map.signStatus) || 'NOT_STARTED';
      out.pdfStatus = erpFieldB06J41_37_40_cell_(values[r], map.pdfStatus) || 'NOT_CREATED';
      out.raw = erpFieldB06J41_37_40_rowObject_(values[r], map);
      return out;
    }
  }
  return out;
}

function erpFieldB06J41_37_40_findSale_(sheet, map, ctx, doc, contract) {
  var out = { found: false, row: 0, saleId: '', contractId: '', status: '', raw: {} };
  if (!sheet || !map) return out;
  var targetSaleId = ctx.saleId || (doc && doc.saleId) || (contract && contract.saleId) || '';
  if (!targetSaleId) return out;
  var values = sheet.getDataRange().getValues();
  for (var r = 1; r < values.length; r++) {
    var saleId = erpFieldB06J41_37_40_cell_(values[r], map.saleId);
    if (saleId === targetSaleId) {
      out.found = true;
      out.row = r + 1;
      out.saleId = saleId;
      out.contractId = erpFieldB06J41_37_40_cell_(values[r], map.contractId);
      out.status = erpFieldB06J41_37_40_cell_(values[r], map.status);
      out.raw = erpFieldB06J41_37_40_rowObject_(values[r], map);
      return out;
    }
  }
  return out;
}

function erpFieldB06J41_37_40_urlPolicy_(config, ctx, result) {
  var configMap = (config && config.configMap) || {};
  var signWebappUrl = String(configMap.SIGN_WEBAPP_URL || '').trim();
  var fieldWebappUrl = String(configMap.ERP_FIELD_WEBAPP_URL || '').trim();
  var documentId = (result.document && result.document.documentId) || ctx.documentId || '';
  var contractId = (result.contract && result.contract.contractId) || ctx.contractId || '';
  var saleId = (result.sale && result.sale.saleId) || ctx.saleId || '';
  var customerId = (result.document && result.document.customerId) || ctx.customerId || '';
  var signUrl = '';
  var qrUrl = '';
  if (signWebappUrl && documentId) {
    signUrl = signWebappUrl + '?documentId=' + encodeURIComponent(documentId) + '&contractId=' + encodeURIComponent(contractId) + '&saleId=' + encodeURIComponent(saleId) + '&customerId=' + encodeURIComponent(customerId);
  }
  if (fieldWebappUrl && documentId) {
    qrUrl = fieldWebappUrl + '?roleCode=' + encodeURIComponent(ctx.roleCode || 'VENDOR_MANAGER') + '&vendorId=' + encodeURIComponent(ctx.vendorId) + '&eventId=' + encodeURIComponent(ctx.eventId) + '&route=signUrlPrecheck&documentId=' + encodeURIComponent(documentId) + '&contractId=' + encodeURIComponent(contractId) + '&saleId=' + encodeURIComponent(saleId) + '&customerId=' + encodeURIComponent(customerId);
  }
  return {
    signWebappUrl: signWebappUrl,
    fieldWebappUrl: fieldWebappUrl,
    signUrlPreview: signUrl,
    qrUrlPreview: qrUrl,
    savePolicy: 'BLOCKED_THIS_BUILD',
    pdfPolicy: 'BLOCKED_THIS_BUILD'
  };
}

function erpFieldB06J41_37_40_readiness_(result, ctx) {
  var fatal = [];
  var warnings = [];
  if (!result.document || !result.document.found) fatal.push('SIGN_Documents DRAFT 문서 없음');
  if (result.document && result.document.status && result.document.status !== 'DRAFT') warnings.push('문서 상태가 DRAFT가 아님: ' + result.document.status);
  if (result.document && result.document.signStatus && result.document.signStatus !== 'NOT_STARTED') warnings.push('서명 상태가 NOT_STARTED가 아님: ' + result.document.signStatus);
  if (!result.contract || !result.contract.found) fatal.push('연결 계약 DRAFT 없음');
  if (!result.sale || !result.sale.found) fatal.push('연결 판매 원전표 없음');
  if (!result.urlPolicy.signWebappUrl) fatal.push('SystemConfig SIGN_WEBAPP_URL 누락');
  if (!result.urlPolicy.fieldWebappUrl) warnings.push('SystemConfig ERP_FIELD_WEBAPP_URL 누락 또는 비어 있음');
  if (!result.urlPolicy.signUrlPreview) fatal.push('SIGN URL 미리보기 생성 불가');
  return { readyForNextUrlSave: fatal.length === 0, fatal: fatal, warnings: warnings, label: fatal.length ? '차단' : '가능' };
}

function erpFieldB06J41_37_40_loadConfig_() {
  var out = { ok: true, fatal: [], warnings: [], setupDbId: FIELD_B06J41_37_40_SETUP_DB_ID, configSheetName: FIELD_B06J41_37_40_CONFIG_SHEET_NAME, headerPolicy: 'CONFIG_KEY/VALUE first', usedHeaderPair: '', configMap: {}, masterId: '', setupDbName: '' };
  try {
    var ss = SpreadsheetApp.openById(FIELD_B06J41_37_40_SETUP_DB_ID);
    out.setupDbName = ss.getName();
    var sh = ss.getSheetByName(FIELD_B06J41_37_40_CONFIG_SHEET_NAME);
    if (!sh) { out.ok = false; out.fatal.push('SystemConfig 시트 없음'); return out; }
    var values = sh.getDataRange().getValues();
    if (values.length < 1) { out.ok = false; out.fatal.push('SystemConfig 데이터 없음'); return out; }
    var headers = values[0].map(function (h) { return String(h || '').trim(); });
    var keyIdx = headers.indexOf('CONFIG_KEY');
    var valIdx = headers.indexOf('VALUE');
    if (keyIdx >= 0 && valIdx >= 0) out.usedHeaderPair = 'CONFIG_KEY/VALUE';
    else {
      keyIdx = headers.indexOf('configKey'); valIdx = headers.indexOf('configValue');
      if (keyIdx >= 0 && valIdx >= 0) out.usedHeaderPair = 'configKey/configValue';
      else { keyIdx = headers.indexOf('key'); valIdx = headers.indexOf('value'); if (keyIdx >= 0 && valIdx >= 0) out.usedHeaderPair = 'key/value'; }
    }
    if (keyIdx < 0 || valIdx < 0) { out.ok = false; out.fatal.push('SystemConfig CONFIG_KEY/VALUE 헤더 없음'); return out; }
    for (var r = 1; r < values.length; r++) {
      var k = String(values[r][keyIdx] || '').trim();
      if (k) out.configMap[k] = values[r][valIdx];
    }
    out.masterId = String(out.configMap.FEELHAUS_DB_MASTER_ID || out.configMap.DB_MASTER_ID || out.configMap.SPREADSHEET_ID || '').trim();
    if (!out.masterId) { out.ok = false; out.fatal.push('FEELHAUS_DB_MASTER_ID / DB_MASTER_ID 누락'); }
    return out;
  } catch (err) {
    out.ok = false; out.fatal.push('SystemConfig 읽기 실패: ' + (err && err.message ? err.message : err)); return out;
  }
}

function erpFieldB06J41_37_40_openMaster_(config) {
  var meta = { ok: true, fatal: [], warnings: [], usedKey: 'FEELHAUS_DB_MASTER_ID', masterId: config.masterId, masterName: 'FEELHAUS_DB_MASTER', masterSpreadsheetName: '' };
  try {
    var ss = SpreadsheetApp.openById(config.masterId);
    meta.masterSpreadsheetName = ss.getName();
    return { ss: ss, meta: meta };
  } catch (err) {
    meta.ok = false; meta.fatal.push('마스터 열기 실패: ' + (err && err.message ? err.message : err));
    return { ss: null, meta: meta };
  }
}

function erpFieldB06J41_37_40_findSheet_(ss, candidates, requiredHeaders) {
  var out = { ok: true, exists: false, sheetName: '', candidates: candidates, lastRow: 0, lastCol: 0, headers: [], headerMap: {}, missingRequiredHeaders: [], sheet: null };
  for (var i = 0; i < candidates.length; i++) {
    var sh = ss.getSheetByName(candidates[i]);
    if (sh) { out.exists = true; out.sheetName = candidates[i]; out.sheet = sh; break; }
  }
  if (!out.exists) { out.ok = false; return out; }
  out.lastRow = out.sheet.getLastRow();
  out.lastCol = out.sheet.getLastColumn();
  out.headers = out.lastCol ? out.sheet.getRange(1, 1, 1, out.lastCol).getValues()[0].map(function (h) { return String(h || '').trim(); }) : [];
  for (var c = 0; c < out.headers.length; c++) if (out.headers[c]) out.headerMap[out.headers[c]] = c + 1;
  (requiredHeaders || []).forEach(function (h) { if (!out.headerMap[h]) out.missingRequiredHeaders.push(h); });
  out.ok = out.missingRequiredHeaders.length === 0;
  return out;
}

function erpFieldB06J41_37_40_normalize_(ctx) {
  ctx = ctx || {};
  return {
    roleCode: String(ctx.roleCode || 'VENDOR_MANAGER').trim(),
    vendorId: String(ctx.vendorId || '').trim(),
    eventId: String(ctx.eventId || '').trim(),
    route: String(ctx.route || 'signUrlPrecheck').trim(),
    customerId: String(ctx.customerId || '').trim(),
    saleId: String(ctx.saleId || '').trim(),
    contractId: String(ctx.contractId || '').trim(),
    documentId: String(ctx.documentId || '').trim(),
    userEmail: String(ctx.userEmail || 'FIELD_USER').trim()
  };
}

function erpFieldB06J41_37_40_result_(label) {
  return { ok: true, label: label, build: FIELD_B06J41_37_40_BUILD, moduleCode: 'ERP_FIELD', checkedAt: new Date().toISOString(), fatal: [], warnings: [], checks: {}, document: {}, contract: {}, sale: {}, urlPolicy: {}, readiness: {} };
}

function erpFieldB06J41_37_40_finish_(result, logOutput) {
  Object.keys(result.checks || {}).forEach(function (k) {
    var c = result.checks[k];
    if (c && c.fatal && c.fatal.length) result.fatal = result.fatal.concat(c.fatal.map(function (m) { return k + ': ' + m; }));
    if (c && c.warnings && c.warnings.length) result.warnings = result.warnings.concat(c.warnings.map(function (m) { return k + ': ' + m; }));
  });
  if (result.readiness && result.readiness.fatal && result.readiness.fatal.length) result.fatal = result.fatal.concat(result.readiness.fatal.map(function (m) { return 'readiness: ' + m; }));
  if (result.readiness && result.readiness.warnings && result.readiness.warnings.length) result.warnings = result.warnings.concat(result.readiness.warnings.map(function (m) { return 'readiness: ' + m; }));
  result.ok = result.fatal.length === 0;
  if (logOutput) {
    Logger.log('======================================================');
    Logger.log('[' + FIELD_B06J41_37_40_BUILD + '] RESULT');
    Logger.log(JSON.stringify(result, null, 2));
    Logger.log('======================================================');
  }
  return result;
}

function erpFieldB06J41_37_40_cell_(row, col) {
  if (!col) return '';
  var v = row[col - 1];
  if (v instanceof Date) return Utilities.formatDate(v, 'Asia/Seoul', 'yyyy-MM-dd HH:mm:ss');
  return String(v == null ? '' : v).trim();
}
function erpFieldB06J41_37_40_rowObject_(row, map) { var o = {}; Object.keys(map || {}).forEach(function (k) { o[k] = erpFieldB06J41_37_40_cell_(row, map[k]); }); return o; }
function erpFieldB06J41_37_40_roleName_(roleCode) { var m = { VENDOR_OWNER: '업체대표', VENDOR_MANAGER: '업체관리자', STAFF_SALES: '영업직원', STAFF_INSTALL: '설치담당', STAFF_AS: 'A/S담당', VIEWER: '조회전용' }; return m[roleCode] || roleCode; }
function erpFieldB06J41_37_40_escape_(v) { return String(v == null ? '' : v).replace(/[&<>\"]/g, function (s) { return ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' })[s]; }); }
function erpFieldB06J41_37_40_money_(v) { var n = Number(String(v || '0').replace(/,/g, '')); if (!isFinite(n)) n = 0; return n.toLocaleString('ko-KR'); }

function erpFieldB06J41_37_40_urls_(ctx, result) {
  var base = (result.checks && result.checks.config && result.checks.config.configMap && result.checks.config.configMap.ERP_FIELD_WEBAPP_URL) || '';
  var q = 'roleCode=' + encodeURIComponent(ctx.roleCode) + '&vendorId=' + encodeURIComponent(ctx.vendorId) + '&eventId=' + encodeURIComponent(ctx.eventId) + '&saleId=' + encodeURIComponent(ctx.saleId || (result.document && result.document.saleId) || '') + '&contractId=' + encodeURIComponent(ctx.contractId || (result.document && result.document.contractId) || '') + '&customerId=' + encodeURIComponent(ctx.customerId || (result.document && result.document.customerId) || '') + '&documentId=' + encodeURIComponent(ctx.documentId || (result.document && result.document.documentId) || '');
  return {
    signUrlSave: base ? base + '?' + q + '&route=signUrlSave' : '',
    signDocumentDetail: base ? base + '?' + q + '&route=signDocumentDetail' : '',
    contractDetail: base ? base + '?' + q + '&route=contractDetail' : '',
    salesDetail: base ? base + '?' + q + '&route=salesDetail' : ''
  };
}


/* ===== SignUrlForce.js ===== */
/**
 * build: ERP_B06J41_41_45C_SIGN_URL_CONFIRM_FORCE_FIX_SAFE_UPLOAD
 * purpose: signUrlSaveNow 강제 저장 라우트 허용/차단범위 자체점검
 */
function erpB06J41_41_45C_confirmForceSelfTest() {
  var result = {
    ok: true,
    build: 'ERP_B06J41_41_45C_SIGN_URL_CONFIRM_FORCE_FIX_SAFE_UPLOAD',
    routePreview: 'signUrlSave',
    routeConfirmed: 'signUrlSaveNow',
    roleCode: 'VENDOR_MANAGER',
    vendorId: 'VND-20260502202158-505',
    eventId: 'EVT-20260502202016-197',
    fatal: [],
    noPdf: true,
    noSettlement: true,
    noExternalIntegration: true,
    noRowCreation: true,
    message: 'signUrlSaveNow confirmSave 강제 라우트 준비 정상'
  };
  try {
    if (typeof erpFieldB06J40_04_12_guardContext_ !== 'function') {
      result.fatal.push('guard 함수 없음: erpFieldB06J40_04_12_guardContext_');
    } else {
      var guard = erpFieldB06J40_04_12_guardContext_({
        roleCode: 'VENDOR_MANAGER',
        vendorId: 'VND-20260502202158-505',
        eventId: 'EVT-20260502202016-197',
        route: 'signUrlSaveNow'
      });
      if (!guard.ok) result.fatal = result.fatal.concat(guard.fatal || []);
    }
    if (typeof erpFieldB06J41_41_45_renderSignUrlSaveHtml !== 'function') {
      result.fatal.push('SIGN URL 저장 렌더 함수 없음');
    }
  } catch (err) {
    result.fatal.push('confirm force self test fatal: ' + (err && err.message ? err.message : err));
  }
  result.ok = result.fatal.length === 0;
  Logger.log('======================================================');
  Logger.log('[ERP_B06J41_41_45C_SIGN_URL_CONFIRM_FORCE_FIX_SAFE_UPLOAD] RESULT');
  Logger.log(JSON.stringify(result, null, 2));
  Logger.log('======================================================');
  return result;
}


/* ===== SignUrlRoute.js ===== */
/**
 * build: ERP_B06J41_41_45B_SIGN_URL_ROUTE_ALLOW_FIX_SAFE_UPLOAD
 * module: ERP_FIELD
 * purpose:
 * - Verify signUrlSave/signUrlReady routes are allowed by FIELD guard.
 * - No sheet write / no PDF / no settlement / no external integration.
 */
var ERP_B06J41_41_45B_ROUTE_BUILD = 'ERP_B06J41_41_45B_SIGN_URL_ROUTE_ALLOW_FIX_SAFE_UPLOAD';

function erpB06J41_41_45B_routeAllowSelfTest() {
  var ctx = erpFieldB06J40_04_12_normalizeContext_({
    roleCode: 'VENDOR_MANAGER',
    vendorId: 'VND-20260502202158-505',
    eventId: 'EVT-20260502202016-197',
    route: 'signUrlSave'
  });
  var guard = erpFieldB06J40_04_12_guardContext_(ctx);
  var result = {
    ok: guard && guard.ok === true,
    build: ERP_B06J41_41_45B_ROUTE_BUILD,
    route: ctx.route,
    roleCode: ctx.roleCode,
    vendorId: ctx.vendorId,
    eventId: ctx.eventId,
    fatal: guard && guard.fatal ? guard.fatal : [],
    noPdf: true,
    noSettlement: true,
    noExternalIntegration: true,
    message: guard && guard.ok ? 'signUrlSave route 허용 정상' : 'signUrlSave route 차단 상태'
  };
  Logger.log('======================================================');
  Logger.log('[%s] RESULT\n%s', ERP_B06J41_41_45B_ROUTE_BUILD, JSON.stringify(result, null, 2));
  Logger.log('======================================================');
  return result;
}


/* ===== SignUrlSave.js ===== */
/**
 * build: ERP_B06J41_41_45_SIGN_URL_SCHEMA_AND_SAVE_SAFE_UPLOAD
 * module: ERP_FIELD
 * purpose:
 * - B06J41-41 SIGN_Documents URL 저장용 헤더 점검/보정
 * - B06J41-42 Contracts URL 연결 헤더 점검/보정
 * - B06J41-43 signUrl / qrUrl 저장 개방
 * - B06J41-44 signStatus = SIGN_URL_READY 반영
 * - B06J41-45 PDF 생성 차단 유지
 * safety:
 * - only SIGN_Documents / Contracts URL bridge cells are updated when confirmSave=1
 * - no PDF creation / no settlement / no external integration / no delete / no row creation
 * - SystemConfig standard header: CONFIG_KEY / VALUE first
 */

var FIELD_B06J41_41_45_BUILD = 'ERP_B06J41_41_45D_SIGN_URL_V50_LIMITED_SAVE_SAFE_UPLOAD';
var FIELD_B06J41_41_45_STATUS = 'SIGN_URL_READY';
var FIELD_B06J41_41_45_SIGN_HEADERS = ['documentId','contractId','saleId','eventId','vendorId','customerId','status','statusReason','signStatus','pdfStatus','signUrl','qrUrl','urlReadyAt','urlReadyBy','updatedAt','updatedBy'];
var FIELD_B06J41_41_45_CONTRACT_HEADERS = ['contractId','saleId','eventId','vendorId','customerId','documentId','status','statusReason','contractStatus','signStatus','pdfStatus','signUrl','qrUrl','updatedAt','updatedBy'];

function erpB06J41_41_45_preflight() {
  return erpFieldB06J41_41_45_run_({}, false, true);
}

function erpB06J41_41_45_autoRunSafe() {
  return erpFieldB06J41_41_45_run_({}, false, true);
}

function erpB06J41_41_45_confirmedSave() {
  return erpFieldB06J41_41_45_run_({}, true, true);
}

function erpFieldB06J41_41_45_renderSignUrlSaveHtml(ctx) {
  var vm = erpFieldB06J41_41_45_buildVm_(ctx || {});
  var t = HtmlService.createTemplateFromFile('P_SignUrlSave');
  t.vm = vm;
  t.json = JSON.stringify(vm, null, 2);
  return t.evaluate().setTitle('SIGN URL 저장').setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL);
}

function erpFieldB06J41_41_45_buildVm_(ctx) {
  ctx = erpFieldB06J41_41_45_normalize_(ctx || {});
  var confirmed = String(ctx.confirmSave || '').trim() === '1' || String(ctx.action || '').trim() === 'save' || String(ctx.route || '').trim() === 'signUrlSaveNow';
  var result = erpFieldB06J41_41_45_run_(ctx, confirmed, false);
  result.context = ctx;
  result.page = {
    badge: 'B06J41-41_45 SAFE : SIGN URL SAVE',
    title: 'SIGN URL / QR URL 저장',
    subtitle: 'SIGN_Documents와 Contracts에 URL 연결값만 저장합니다. PDF/정산/외부연동은 계속 차단합니다.',
    roleName: erpFieldB06J41_37_40_roleName_(ctx.roleCode)
  };
  result.urls = erpFieldB06J41_41_45_urls_(ctx, result);
  return result;
}

function erpFieldB06J41_41_45_run_(ctx, confirmed, logOutput) {
  ctx = erpFieldB06J41_41_45_normalize_(ctx || {});
  if (confirmed === true && String(ctx.approvalCode || '').trim() !== 'FEELHAUS_V50_SIGN_URL_SAVE_ONE') {
    var blockedUrl = erpFieldB06J41_41_45_result_('blockedByFieldV50');
    blockedUrl.confirmed = true;
    blockedUrl.contextSummary = { eventId: ctx.eventId, vendorId: ctx.vendorId, customerId: ctx.customerId, saleId: ctx.saleId, contractId: ctx.contractId, documentId: ctx.documentId };
    blockedUrl.fatal.push('FIELD V50 SAFETY: SIGN URL 저장은 V50 승인코드 없이는 실제 실행 금지. signUrlPrecheck/signUrlVerify READ ONLY만 허용.');
    return erpFieldB06J41_41_45_finish_(blockedUrl, logOutput);
  }
  var result = erpFieldB06J41_41_45_result_(confirmed ? 'confirmedSave' : 'preflight');
  result.confirmed = confirmed === true;
  result.contextSummary = { eventId: ctx.eventId, vendorId: ctx.vendorId, customerId: ctx.customerId, saleId: ctx.saleId, contractId: ctx.contractId, documentId: ctx.documentId };
  try {
    result.checks.config = erpFieldB06J41_37_40_loadConfig_();
    if (!result.checks.config.ok) return erpFieldB06J41_41_45_finish_(result, logOutput);
    var master = erpFieldB06J41_37_40_openMaster_(result.checks.config);
    result.checks.master = master.meta;
    if (!master.ss) {
      result.fatal.push('FEELHAUS_DB_MASTER 연결 실패');
      return erpFieldB06J41_41_45_finish_(result, logOutput);
    }

    var ss = master.ss;
    result.checks.signSheet = erpFieldB06J41_41_45_checkSheet_(ss, FIELD_B06J41_37_40_SIGN_CANDIDATES, FIELD_B06J41_41_45_SIGN_HEADERS, confirmed, 'SIGN_Documents');
    result.checks.contractSheet = erpFieldB06J41_41_45_checkSheet_(ss, FIELD_B06J41_37_40_CONTRACT_CANDIDATES, FIELD_B06J41_41_45_CONTRACT_HEADERS, confirmed, 'Contracts');
    result.checks.salesSheet = erpFieldB06J41_37_40_findSheet_(ss, FIELD_B06J41_37_40_SALES_CANDIDATES, ['saleId','eventId','vendorId','customerId','contractId','status']);
    result.checks.safety = erpFieldB06J41_41_45_safety_();

    if (!result.checks.signSheet.exists) result.fatal.push('SIGN_Documents 시트 없음');
    if (!result.checks.contractSheet.exists) result.fatal.push('Contracts / ERP_계약관리 시트 없음');
    if (!result.checks.salesSheet.exists) result.fatal.push('Sales 시트 없음');
    if ((result.checks.signSheet.missingRequiredHeaders || []).length) result.fatal.push('SIGN_Documents URL 저장 헤더 누락: ' + result.checks.signSheet.missingRequiredHeaders.join(', '));
    if ((result.checks.contractSheet.missingRequiredHeaders || []).length) result.fatal.push('Contracts URL 연결 헤더 누락: ' + result.checks.contractSheet.missingRequiredHeaders.join(', '));

    if (result.fatal.length) return erpFieldB06J41_41_45_finish_(result, logOutput);

    result.document = erpFieldB06J41_37_40_findDocument_(result.checks.signSheet.sheet, result.checks.signSheet.headerMap, ctx);
    result.contract = erpFieldB06J41_37_40_findContract_(result.checks.contractSheet.sheet, result.checks.contractSheet.headerMap, ctx, result.document);
    result.sale = erpFieldB06J41_37_40_findSale_(result.checks.salesSheet.sheet, result.checks.salesSheet.headerMap, ctx, result.document, result.contract);
    result.urlPolicy = erpFieldB06J41_37_40_urlPolicy_(result.checks.config, ctx, result);
    result.readiness = erpFieldB06J41_41_45_readiness_(result);

    if (confirmed && result.readiness.readyForUrlSave) {
      result.saveResult = erpFieldB06J41_41_45_saveUrls_(result, ctx);
    } else {
      result.saveResult = { executed: false, reason: confirmed ? 'readiness 차단' : 'confirmSave=1 전까지 저장 안 함' };
    }
  } catch (err) {
    result.fatal.push('B06J41-41~45 SIGN URL save fatal: ' + (err && err.message ? err.message : err));
  }
  return erpFieldB06J41_41_45_finish_(result, logOutput);
}

function erpFieldB06J41_41_45_checkSheet_(ss, candidates, requiredHeaders, confirmed, defaultName) {
  var out = erpFieldB06J41_37_40_findSheet_(ss, candidates, requiredHeaders);
  out.appendedHeaders = [];
  if (!out.exists) return out;
  if (confirmed && out.missingRequiredHeaders && out.missingRequiredHeaders.length) {
    var appended = out.missingRequiredHeaders.slice();
    erpFieldB06J41_41_45_appendHeaders_(out.sheet, appended);
    out = erpFieldB06J41_37_40_findSheet_(ss, candidates, requiredHeaders);
    out.appendedHeaders = appended;
  }
  out.defaultName = defaultName;
  return out;
}

function erpFieldB06J41_41_45_readiness_(result) {
  var fatal = [];
  var warnings = [];
  if (!result.document || !result.document.found) fatal.push('SIGN_Documents DRAFT 문서 없음');
  if (!result.contract || !result.contract.found) fatal.push('연결 계약 DRAFT 없음');
  if (!result.sale || !result.sale.found) fatal.push('연결 판매 원전표 없음');
  if (result.document && result.contract && result.document.contractId && result.contract.contractId && result.document.contractId !== result.contract.contractId) fatal.push('document.contractId 와 contract.contractId 불일치');
  if (result.document && result.document.pdfStatus && result.document.pdfStatus !== 'NOT_CREATED') warnings.push('PDF 상태가 NOT_CREATED가 아님: ' + result.document.pdfStatus);
  if (result.document && result.document.signStatus && ['NOT_STARTED','URL_READY','SIGN_URL_READY'].indexOf(result.document.signStatus) < 0) warnings.push('기존 signStatus 확인 필요: ' + result.document.signStatus);
  if (!result.urlPolicy || !result.urlPolicy.signUrlPreview) fatal.push('SIGN URL 생성 불가');
  return {
    readyForUrlSave: fatal.length === 0,
    fatal: fatal,
    warnings: warnings,
    label: fatal.length ? '차단' : '저장 가능',
    pdfStillBlocked: true,
    settlementStillBlocked: true,
    externalIntegrationStillBlocked: true
  };
}

function erpFieldB06J41_41_45_saveUrls_(result, ctx) {
  var now = new Date();
  var user = String(ctx.userEmail || Session.getActiveUser().getEmail() || 'FIELD_USER').trim();
  var signUrl = result.urlPolicy.signUrlPreview;
  var qrUrl = result.urlPolicy.qrUrlPreview || signUrl;
  var saved = { executed: true, signDocumentUpdated: false, contractUpdated: false, signDocumentRow: 0, contractRow: 0, signStatus: FIELD_B06J41_41_45_STATUS, pdfBlocked: true, settlementBlocked: true, externalIntegrationBlocked: true };

  erpFieldB06J41_41_45_setByHeader_(result.checks.signSheet.sheet, result.checks.signSheet.headerMap, result.document.row, {
    signUrl: signUrl,
    qrUrl: qrUrl,
    signStatus: FIELD_B06J41_41_45_STATUS,
    statusReason: 'SIGN URL READY - PDF BLOCKED',
    urlReadyAt: now,
    urlReadyBy: user,
    updatedAt: now,
    updatedBy: user
  });
  saved.signDocumentUpdated = true;
  saved.signDocumentRow = result.document.row;

  erpFieldB06J41_41_45_setByHeader_(result.checks.contractSheet.sheet, result.checks.contractSheet.headerMap, result.contract.row, {
    signUrl: signUrl,
    qrUrl: qrUrl,
    signStatus: FIELD_B06J41_41_45_STATUS,
    statusReason: 'SIGN URL READY - PDF BLOCKED',
    updatedAt: now,
    updatedBy: user
  });
  saved.contractUpdated = true;
  saved.contractRow = result.contract.row;
  return saved;
}

function erpFieldB06J41_41_45_setByHeader_(sheet, map, row, values) {
  Object.keys(values || {}).forEach(function (key) {
    if (map[key]) sheet.getRange(row, map[key]).setValue(values[key]);
  });
}

function erpFieldB06J41_41_45_appendHeaders_(sheet, headers) {
  if (!headers || !headers.length) return;
  var start = Math.max(sheet.getLastColumn(), 1) + 1;
  sheet.getRange(1, start, 1, headers.length).setValues([headers]);
}

function erpFieldB06J41_41_45_safety_() {
  return {
    noPdfCreate: true,
    noSettlementExecution: true,
    noExternalIntegration: true,
    noDelete: true,
    noRowCreation: true,
    updateScope: 'SIGN_Documents.signUrl/qrUrl/signStatus + Contracts.signUrl/qrUrl/signStatus only',
    headerAppendOnlyWhenConfirmed: true,
    systemConfigHeaderStandard: 'CONFIG_KEY/VALUE first'
  };
}

function erpFieldB06J41_41_45_result_(label) {
  return { ok: true, label: label, build: FIELD_B06J41_41_45_BUILD, moduleCode: 'ERP_FIELD', checkedAt: new Date().toISOString(), fatal: [], warnings: [], checks: {}, document: {}, contract: {}, sale: {}, urlPolicy: {}, readiness: {}, saveResult: {} };
}

function erpFieldB06J41_41_45_finish_(result, logOutput) {
  Object.keys(result.checks || {}).forEach(function (k) {
    var c = result.checks[k];
    if (c && c.fatal && c.fatal.length) result.fatal = result.fatal.concat(c.fatal.map(function (m) { return k + ': ' + m; }));
    if (c && c.warnings && c.warnings.length) result.warnings = result.warnings.concat(c.warnings.map(function (m) { return k + ': ' + m; }));
  });
  if (result.readiness && result.readiness.fatal && result.readiness.fatal.length) result.fatal = result.fatal.concat(result.readiness.fatal.map(function (m) { return 'readiness: ' + m; }));
  if (result.readiness && result.readiness.warnings && result.readiness.warnings.length) result.warnings = result.warnings.concat(result.readiness.warnings.map(function (m) { return 'readiness: ' + m; }));
  result.ok = result.fatal.length === 0;
  if (logOutput) {
    Logger.log('======================================================');
    Logger.log('[' + FIELD_B06J41_41_45_BUILD + '] RESULT');
    Logger.log(JSON.stringify(result, null, 2));
    Logger.log('======================================================');
  }
  return result;
}

function erpFieldB06J41_41_45_normalize_(ctx) {
  ctx = erpFieldB06J41_37_40_normalize_(ctx || {});
  ctx.confirmSave = String((arguments[0] || {}).confirmSave || '').trim();
  ctx.action = String((arguments[0] || {}).action || '').trim();
  return ctx;
}

function erpFieldB06J41_41_45_urls_(ctx, result) {
  var base = (result.checks && result.checks.config && result.checks.config.configMap && result.checks.config.configMap.ERP_FIELD_WEBAPP_URL) || '';
  var q = 'roleCode=' + encodeURIComponent(ctx.roleCode) + '&vendorId=' + encodeURIComponent(ctx.vendorId) + '&eventId=' + encodeURIComponent(ctx.eventId) + '&saleId=' + encodeURIComponent(ctx.saleId || (result.document && result.document.saleId) || '') + '&contractId=' + encodeURIComponent(ctx.contractId || (result.document && result.document.contractId) || '') + '&customerId=' + encodeURIComponent(ctx.customerId || (result.document && result.document.customerId) || '') + '&documentId=' + encodeURIComponent(ctx.documentId || (result.document && result.document.documentId) || '');
  return {
    savePreview: base ? base + '?' + q + '&route=signUrlSave' : '',
    confirmedSave: base ? base + '?' + q + '&route=signUrlSaveNow&confirmSave=1&action=save' : '',
    signDocumentDetail: base ? base + '?' + q + '&route=signDocumentDetail' : '',
    contractDetail: base ? base + '?' + q + '&route=contractDetail' : '',
    signUrlPrecheck: base ? base + '?' + q + '&route=signUrlPrecheck' : ''
  };
}


/* ===== SignUrlVer.js ===== */
/**
 * build: ERP_B06J41_46_50_SIGN_URL_VERIFY_AND_SIGN_ENTRY_SAFE_UPLOAD
 * module: ERP_FIELD
 * purpose:
 * - B06J41-46 saved signUrl / qrUrl re-read
 * - B06J41-47 SIGN_Documents <-> Contracts URL linkage verify
 * - B06J41-48 SIGN_URL_READY status verify
 * - B06J41-49 show SIGN entry button
 * - B06J41-50 prepare SIGN entry only
 * safety:
 * - READ ONLY only
 * - no sign complete / no PDF creation / no Drive save / no settlement / no external integration
 * - no write / no update / no delete / no row creation
 * - SystemConfig standard header: CONFIG_KEY / VALUE first
 */

var FIELD_B06J41_46_50_BUILD = 'ERP_B06J41_46_50_SIGN_URL_VERIFY_AND_SIGN_ENTRY_SAFE_UPLOAD';
var FIELD_B06J41_46_50_EXPECTED_STATUS = 'SIGN_URL_READY';
var FIELD_B06J41_46_50_DEFAULT_CTX = {
  roleCode: 'VENDOR_MANAGER',
  vendorId: 'VND-20260502202158-505',
  eventId: 'EVT-20260502202016-197',
  customerId: 'CUS-20260504002306-615',
  saleId: 'SALE-20260504005028-991',
  contractId: 'CON-20260504021423-908',
  documentId: 'DOC-20260504175000-946',
  route: 'signUrlVerify'
};

function erpB06J41_46_50_preflight() {
  return erpFieldB06J41_46_50_run_(FIELD_B06J41_46_50_DEFAULT_CTX, true);
}

function erpB06J41_46_50_autoRunSafe() {
  return erpFieldB06J41_46_50_run_(FIELD_B06J41_46_50_DEFAULT_CTX, true);
}

function erpFieldB06J41_46_50_renderSignUrlVerifyHtml(ctx) {
  var vm = erpFieldB06J41_46_50_buildVm_(ctx || {});
  var t = HtmlService.createTemplateFromFile('P_SignUrlVer');
  t.vm = vm;
  t.json = JSON.stringify(vm, null, 2);
  return t.evaluate().setTitle('SIGN URL 검증 / 서명진입').setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL);
}

function erpFieldB06J41_46_50_buildVm_(ctx) {
  ctx = erpFieldB06J41_46_50_normalize_(ctx || {});
  var result = erpFieldB06J41_46_50_run_(ctx, false);
  result.context = ctx;
  result.page = {
    badge: 'B06J41-46_50 SAFE : SIGN ENTRY READY',
    title: 'SIGN URL 저장 검증 / 서명 진입 준비',
    subtitle: '저장된 SIGN URL / QR URL을 재조회하고 서명 화면 진입 버튼만 표시합니다. 서명완료/PDF/Drive/정산은 계속 차단합니다.',
    roleName: erpFieldB06J41_37_40_roleName_(ctx.roleCode)
  };
  result.urls = erpFieldB06J41_46_50_urls_(ctx, result);
  return result;
}

function erpFieldB06J41_46_50_run_(ctx, logOutput) {
  ctx = erpFieldB06J41_46_50_normalize_(ctx || {});
  var result = erpFieldB06J41_46_50_result_('signUrlVerify');
  result.contextSummary = {
    eventId: ctx.eventId,
    vendorId: ctx.vendorId,
    customerId: ctx.customerId,
    saleId: ctx.saleId,
    contractId: ctx.contractId,
    documentId: ctx.documentId
  };
  try {
    result.checks.config = erpFieldB06J41_37_40_loadConfig_();
    if (!result.checks.config.ok) return erpFieldB06J41_46_50_finish_(result, logOutput);

    var master = erpFieldB06J41_37_40_openMaster_(result.checks.config);
    result.checks.master = master.meta;
    if (!master.ss) {
      result.fatal.push('FEELHAUS_DB_MASTER 연결 실패');
      return erpFieldB06J41_46_50_finish_(result, logOutput);
    }

    var ss = master.ss;
    result.checks.signSheet = erpFieldB06J41_37_40_findSheet_(ss, FIELD_B06J41_37_40_SIGN_CANDIDATES, ['documentId','contractId','saleId','eventId','vendorId','customerId','status','signStatus','pdfStatus','signUrl','qrUrl','urlReadyAt','urlReadyBy']);
    result.checks.contractSheet = erpFieldB06J41_37_40_findSheet_(ss, FIELD_B06J41_37_40_CONTRACT_CANDIDATES, ['contractId','saleId','eventId','vendorId','customerId','documentId','status','signStatus','pdfStatus','signUrl','qrUrl']);
    result.checks.salesSheet = erpFieldB06J41_37_40_findSheet_(ss, FIELD_B06J41_37_40_SALES_CANDIDATES, ['saleId','eventId','vendorId','customerId','contractId','status']);
    result.checks.safety = erpFieldB06J41_46_50_safety_();

    if (!result.checks.signSheet.exists) result.fatal.push('SIGN_Documents 시트 없음');
    if (!result.checks.contractSheet.exists) result.fatal.push('Contracts / ERP_계약관리 시트 없음');
    if (!result.checks.salesSheet.exists) result.fatal.push('Sales 시트 없음');
    if ((result.checks.signSheet.missingRequiredHeaders || []).length) result.fatal.push('SIGN_Documents URL 검증 헤더 누락: ' + result.checks.signSheet.missingRequiredHeaders.join(', '));
    if ((result.checks.contractSheet.missingRequiredHeaders || []).length) result.fatal.push('Contracts URL 검증 헤더 누락: ' + result.checks.contractSheet.missingRequiredHeaders.join(', '));
    if (result.fatal.length) return erpFieldB06J41_46_50_finish_(result, logOutput);

    result.document = erpFieldB06J41_37_40_findDocument_(result.checks.signSheet.sheet, result.checks.signSheet.headerMap, ctx);
    result.contract = erpFieldB06J41_37_40_findContract_(result.checks.contractSheet.sheet, result.checks.contractSheet.headerMap, ctx, result.document);
    result.sale = erpFieldB06J41_37_40_findSale_(result.checks.salesSheet.sheet, result.checks.salesSheet.headerMap, ctx, result.document, result.contract);
    result.stored = erpFieldB06J41_46_50_stored_(result);
    result.verify = erpFieldB06J41_46_50_verify_(result);
  } catch (err) {
    result.fatal.push('B06J41-46~50 SIGN URL verify fatal: ' + (err && err.message ? err.message : err));
  }
  return erpFieldB06J41_46_50_finish_(result, logOutput);
}

function erpFieldB06J41_46_50_stored_(result) {
  var docRaw = (result.document && result.document.raw) || {};
  var conRaw = (result.contract && result.contract.raw) || {};
  return {
    documentSignUrl: String(docRaw.signUrl || '').trim(),
    documentQrUrl: String(docRaw.qrUrl || '').trim(),
    documentSignStatus: String(result.document.signStatus || docRaw.signStatus || '').trim(),
    documentPdfStatus: String(result.document.pdfStatus || docRaw.pdfStatus || '').trim(),
    urlReadyAt: String(docRaw.urlReadyAt || '').trim(),
    urlReadyBy: String(docRaw.urlReadyBy || '').trim(),
    contractSignUrl: String(conRaw.signUrl || '').trim(),
    contractQrUrl: String(conRaw.qrUrl || '').trim(),
    contractSignStatus: String(result.contract.signStatus || conRaw.signStatus || '').trim(),
    contractPdfStatus: String(result.contract.pdfStatus || conRaw.pdfStatus || '').trim()
  };
}

function erpFieldB06J41_46_50_verify_(result) {
  var fatal = [];
  var warnings = [];
  var s = result.stored || {};

  if (!result.document || !result.document.found) fatal.push('SIGN_Documents 문서 없음');
  if (!result.contract || !result.contract.found) fatal.push('연결 계약 없음');
  if (!result.sale || !result.sale.found) fatal.push('연결 판매 원전표 없음');

  if (result.document && result.contract && result.document.contractId && result.contract.contractId && result.document.contractId !== result.contract.contractId) fatal.push('document.contractId 와 contract.contractId 불일치');
  if (result.document && result.sale && result.document.saleId && result.sale.saleId && result.document.saleId !== result.sale.saleId) fatal.push('document.saleId 와 sale.saleId 불일치');
  if (result.contract && result.sale && result.contract.saleId && result.sale.saleId && result.contract.saleId !== result.sale.saleId) fatal.push('contract.saleId 와 sale.saleId 불일치');

  if (!s.documentSignUrl) fatal.push('SIGN_Documents signUrl 미저장');
  if (!s.documentQrUrl) fatal.push('SIGN_Documents qrUrl 미저장');
  if (!s.contractSignUrl) fatal.push('Contracts signUrl 미저장');
  if (!s.contractQrUrl) fatal.push('Contracts qrUrl 미저장');

  if (s.documentSignUrl && s.contractSignUrl && s.documentSignUrl !== s.contractSignUrl) fatal.push('SIGN_Documents signUrl 과 Contracts signUrl 불일치');
  if (s.documentQrUrl && s.contractQrUrl && s.documentQrUrl !== s.contractQrUrl) fatal.push('SIGN_Documents qrUrl 과 Contracts qrUrl 불일치');

  if (s.documentSignStatus !== FIELD_B06J41_46_50_EXPECTED_STATUS) fatal.push('SIGN_Documents signStatus가 SIGN_URL_READY가 아님: ' + s.documentSignStatus);
  if (s.contractSignStatus !== FIELD_B06J41_46_50_EXPECTED_STATUS) fatal.push('Contracts signStatus가 SIGN_URL_READY가 아님: ' + s.contractSignStatus);

  if (s.documentPdfStatus && s.documentPdfStatus !== 'NOT_CREATED') warnings.push('SIGN_Documents pdfStatus 확인 필요: ' + s.documentPdfStatus);
  if (s.contractPdfStatus && s.contractPdfStatus !== 'NOT_CREATED') warnings.push('Contracts pdfStatus 확인 필요: ' + s.contractPdfStatus);
  if (!s.urlReadyAt) warnings.push('urlReadyAt 비어 있음');
  if (!s.urlReadyBy) warnings.push('urlReadyBy 비어 있음');

  return {
    signEntryReady: fatal.length === 0,
    fatal: fatal,
    warnings: warnings,
    label: fatal.length ? '차단' : '서명 진입 가능',
    signCompleteBlocked: true,
    pdfStillBlocked: true,
    driveSaveBlocked: true,
    settlementStillBlocked: true,
    externalIntegrationStillBlocked: true,
    writeBlocked: true
  };
}

function erpFieldB06J41_46_50_safety_() {
  return {
    readOnly: true,
    noWrite: true,
    noSignComplete: true,
    noPdfCreate: true,
    noDriveSave: true,
    noSettlementExecution: true,
    noExternalIntegration: true,
    noDelete: true,
    noRowCreation: true,
    signEntryOnly: true,
    systemConfigHeaderStandard: 'CONFIG_KEY/VALUE first'
  };
}

function erpFieldB06J41_46_50_result_(label) {
  return { ok: true, label: label, build: FIELD_B06J41_46_50_BUILD, moduleCode: 'ERP_FIELD', checkedAt: new Date().toISOString(), fatal: [], warnings: [], checks: {}, document: {}, contract: {}, sale: {}, stored: {}, verify: {} };
}

function erpFieldB06J41_46_50_finish_(result, logOutput) {
  Object.keys(result.checks || {}).forEach(function (k) {
    var c = result.checks[k];
    if (c && c.fatal && c.fatal.length) result.fatal = result.fatal.concat(c.fatal.map(function (m) { return k + ': ' + m; }));
    if (c && c.warnings && c.warnings.length) result.warnings = result.warnings.concat(c.warnings.map(function (m) { return k + ': ' + m; }));
  });
  if (result.verify && result.verify.fatal && result.verify.fatal.length) result.fatal = result.fatal.concat(result.verify.fatal.map(function (m) { return 'verify: ' + m; }));
  if (result.verify && result.verify.warnings && result.verify.warnings.length) result.warnings = result.warnings.concat(result.verify.warnings.map(function (m) { return 'verify: ' + m; }));
  result.ok = result.fatal.length === 0;
  if (logOutput) {
    Logger.log('======================================================');
    Logger.log('[' + FIELD_B06J41_46_50_BUILD + '] RESULT');
    Logger.log(JSON.stringify(result, null, 2));
    Logger.log('======================================================');
  }
  return result;
}

function erpFieldB06J41_46_50_normalize_(ctx) {
  ctx = erpFieldB06J41_37_40_normalize_(ctx || {});
  ctx.route = String((arguments[0] || {}).route || ctx.route || 'signUrlVerify').trim();
  return ctx;
}

function erpFieldB06J41_46_50_urls_(ctx, result) {
  var configMap = (result.checks && result.checks.config && result.checks.config.configMap) || {};
  var base = String(configMap.ERP_FIELD_WEBAPP_URL || '').trim();
  var signEntryUrl = String((result.stored && result.stored.documentSignUrl) || '').trim();
  var q = 'roleCode=' + encodeURIComponent(ctx.roleCode) + '&vendorId=' + encodeURIComponent(ctx.vendorId) + '&eventId=' + encodeURIComponent(ctx.eventId) + '&saleId=' + encodeURIComponent(ctx.saleId || (result.document && result.document.saleId) || '') + '&contractId=' + encodeURIComponent(ctx.contractId || (result.document && result.document.contractId) || '') + '&customerId=' + encodeURIComponent(ctx.customerId || (result.document && result.document.customerId) || '') + '&documentId=' + encodeURIComponent(ctx.documentId || (result.document && result.document.documentId) || '');
  return {
    signEntry: signEntryUrl,
    qrUrl: String((result.stored && result.stored.documentQrUrl) || '').trim(),
    verify: base ? base + '?' + q + '&route=signUrlVerify' : '',
    signUrlSave: base ? base + '?' + q + '&route=signUrlSave' : '',
    signDocumentDetail: base ? base + '?' + q + '&route=signDocumentDetail' : '',
    contractDetail: base ? base + '?' + q + '&route=contractDetail' : ''
  };
}
