/* ===== Base.js ===== */
/**
 * FEELHAUS ERP_FIELD B06J38-02
 * Build: ERP_B06J38_02_FIELD_DOGET_ROUTING_SAFE
 * Purpose:
 *  - ERP_FIELD 웹앱 doGet 라우팅 연결
 *  - FieldEntryPage 최소 진입 화면 연결
 *  - roleCode / vendorId / eventId 파라미터 수신
 *  - vendorId 없는 FIELD 진입 차단 안내
 *  - 저장 / 수정 / 정산 / 외부연동 실행 없음
 *
 * Safety:
 *  - UI routing only
 *  - no business data mutation
 *  - no settlement execution
 *  - no vendor independent DB creation
 */

var ERP_B06J38_02_BUILD = 'ERP_B06J38_02_FIELD_DOGET_ROUTING_SAFE';
var ERP_B06J38_02_MODULE = 'ERP_FIELD';
var ERP_B06J38_02_SETUP_DB_ID = '17VMSpgSZCvIrUlgcw8yCNcnl8WQWo2IcRf5tDCcuJGM';
var ERP_B06J38_02_CONFIG_SHEET_NAME = 'SystemConfig';

/**
 * Apps Script WebApp entry.
 * 이미 ERP_FIELD에 doGet이 있으면 기존 doGet을 이 함수 내용으로 교체한다.
 */
function doGet_B06J38_02_legacy(e) {
  return erpB06J38_02_doGet(e);
}

function erpB06J38_02_doGet(e) {
  var route = erpB06J38_02_parseRoute_(e);
  var validation = erpB06J38_02_validateFieldEntry_(route);

  if (!validation.ok) {
    return erpB06J38_02_htmlOutput_(erpB06J38_02_blockHtml_(route, validation), 'ERP FIELD 진입 차단');
  }

  var html = erpB06J38_02_renderFieldEntry_(route);
  return erpB06J38_02_htmlOutput_(html, 'FEELHAUS ERP FIELD');
}

function erpB06J38_02_parseRoute_(e) {
  var p = (e && e.parameter) ? e.parameter : {};
  var roleCode = erpB06J38_02_clean_(p.roleCode || p.role || 'VIEWER');
  var vendorId = erpB06J38_02_clean_(p.vendorId || p.vendor || '');
  var eventId = erpB06J38_02_clean_(p.eventId || p.event || '');
  var menu = erpB06J38_02_clean_(p.menu || 'FIELD_ENTRY');

  return {
    build: ERP_B06J38_02_BUILD,
    moduleCode: ERP_B06J38_02_MODULE,
    roleCode: roleCode,
    vendorId: vendorId,
    eventId: eventId,
    menu: menu,
    checkedAt: new Date().toISOString(),
    source: 'doGet'
  };
}

function erpB06J38_02_validateFieldEntry_(route) {
  var fatal = [];
  var warnings = [];

  if (!route.roleCode) fatal.push('roleCode 누락');
  if (!route.vendorId) fatal.push('FIELD 진입 차단: vendorId 누락');
  if (!route.eventId) warnings.push('eventId 미지정: 행사 선택 전 안내 상태로 표시');

  return {
    ok: fatal.length === 0,
    fatal: fatal,
    warnings: warnings,
    safety: erpB06J38_02_safetyPolicy_()
  };
}

function erpB06J38_02_renderFieldEntry_(route) {
  var payload = {
    roleCode: route.roleCode,
    vendorId: route.vendorId,
    eventId: route.eventId,
    menu: route.menu,
    build: ERP_B06J38_02_BUILD,
    routedBy: 'erpB06J38_02_doGet'
  };

  // B06J38-01 화면 렌더러가 있으면 우선 연결한다.
  if (typeof erpFieldB06J38_01_renderEntryHtml === 'function') {
    var rendered = erpFieldB06J38_01_renderEntryHtml(payload);
    if (rendered && typeof rendered.getContent === 'function') return rendered.getContent();
    if (rendered && typeof rendered.html === 'string') return rendered.html;
    if (typeof rendered === 'string') return rendered;
  }

  // 렌더러가 없거나 반환 형식이 다를 때도 빈페이지가 나오지 않도록 안전 안내 화면을 반환한다.
  return erpB06J38_02_fallbackEntryHtml_(payload);
}

function erpB06J38_02_htmlOutput_(html, title) {
  return HtmlService
    .createHtmlOutput(html)
    .setTitle(title || 'FEELHAUS ERP FIELD')
    .setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL);
}

function erpB06J38_02_blockHtml_(route, validation) {
  var fatal = validation.fatal.map(function (v) { return '<li>' + erpB06J38_02_escape_(v) + '</li>'; }).join('');
  var warnings = validation.warnings.map(function (v) { return '<li>' + erpB06J38_02_escape_(v) + '</li>'; }).join('');

  return '<!doctype html><html><head><meta charset="utf-8">'
    + '<meta name="viewport" content="width=device-width, initial-scale=1">'
    + '<style>' + erpB06J38_02_baseCss_() + '</style></head><body>'
    + '<main class="wrap">'
    + '<section class="card danger">'
    + '<div class="eyebrow">FEELHAUS ERP_FIELD</div>'
    + '<h1>현장/업체 화면 진입이 차단되었습니다.</h1>'
    + '<p>ERP_FIELD는 업체가 ERP 안에서 지점형 사용자 그룹으로 사용하는 화면입니다. vendorId 없이 독립 진입할 수 없습니다.</p>'
    + '<h2>차단 사유</h2><ul>' + fatal + '</ul>'
    + (warnings ? '<h2>안내</h2><ul>' + warnings + '</ul>' : '')
    + '<div class="meta">roleCode: ' + erpB06J38_02_escape_(route.roleCode || '') + '</div>'
    + '<div class="meta">eventId: ' + erpB06J38_02_escape_(route.eventId || '') + '</div>'
    + '<div class="meta">build: ' + ERP_B06J38_02_BUILD + '</div>'
    + '<div class="footer">© 2026 FEELHAUS. All rights reserved. · (주)필하우스 · 개발담당: 이용필 · 최고운영자: 이용필</div>'
    + '</section></main></body></html>';
}

function erpB06J38_02_fallbackEntryHtml_(data) {
  var menus = [
    ['CUSTOMER_LOOKUP', '고객 조회', 'eventId / vendorId 기준 고객 조회 화면 준비'],
    ['SALES', '판매', '판매등록 화면 준비'],
    ['CONTRACT', '계약', '계약/전자서명 연결 준비'],
    ['INSTALL', '설치', '설치 일정/완료 처리 화면 준비'],
    ['AS', 'A/S', 'A/S 접수/처리 화면 준비'],
    ['MY_STATUS', '내 처리현황', '직원별 처리현황 화면 준비']
  ];

  var menuHtml = menus.map(function (m) {
    return '<article class="menu"><div class="menuCode">' + m[0] + '</div><h3>' + m[1] + '</h3><p>' + m[2] + '</p><button disabled>준비중</button></article>';
  }).join('');

  return '<!doctype html><html><head><meta charset="utf-8">'
    + '<meta name="viewport" content="width=device-width, initial-scale=1">'
    + '<style>' + erpB06J38_02_baseCss_() + '</style></head><body>'
    + '<main class="wrap">'
    + '<section class="card">'
    + '<div class="eyebrow">FEELHAUS ERP_FIELD</div>'
    + '<h1>현장/업체/직원 최소 진입 화면</h1>'
    + '<p>이 화면은 ERP_FIELD 최소 라우팅 기준입니다. 업무 버튼은 아직 실행되지 않으며, 저장/수정/정산 기능은 차단되어 있습니다.</p>'
    + '<div class="grid metaGrid">'
    + '<div><b>roleCode</b><span>' + erpB06J38_02_escape_(data.roleCode) + '</span></div>'
    + '<div><b>vendorId</b><span>' + erpB06J38_02_escape_(data.vendorId) + '</span></div>'
    + '<div><b>eventId</b><span>' + erpB06J38_02_escape_(data.eventId || '행사 선택 전') + '</span></div>'
    + '</div>'
    + '</section>'
    + '<section class="grid menus">' + menuHtml + '</section>'
    + '<section class="card note"><b>안전 정책</b><br>업체는 별도 앱이 아니며 ERP 안의 지점형 사용자 그룹입니다. 모든 데이터는 vendorId / eventId / roleCode 기준으로 제한됩니다.</section>'
    + '<div class="footer">© 2026 FEELHAUS. All rights reserved. · (주)필하우스 · 개발담당: 이용필 · 최고운영자: 이용필</div>'
    + '</main></body></html>';
}

function erpB06J38_02_baseCss_() {
  return 'body{margin:0;background:#f5f7fb;color:#172033;font-family:Arial,"Noto Sans KR",sans-serif}'
    + '.wrap{max-width:1120px;margin:0 auto;padding:28px}'
    + '.card{background:#fff;border:1px solid #e6eaf2;border-radius:18px;padding:24px;box-shadow:0 10px 30px rgba(20,32,51,.07);margin-bottom:18px}'
    + '.danger{border-color:#ffd5d5;background:#fffafa}'
    + '.eyebrow{font-size:12px;font-weight:700;letter-spacing:.08em;color:#61708a;margin-bottom:8px}'
    + 'h1{font-size:26px;margin:0 0 10px}h2{font-size:16px;margin:18px 0 8px}p{line-height:1.65;color:#4a5568}'
    + '.grid{display:grid;gap:14px}.metaGrid{grid-template-columns:repeat(3,minmax(0,1fr))}.metaGrid div{background:#f8fafc;border-radius:14px;padding:14px}.metaGrid b{display:block;font-size:12px;color:#64748b}.metaGrid span{display:block;margin-top:6px;font-weight:700}'
    + '.menus{grid-template-columns:repeat(3,minmax(0,1fr));margin-bottom:18px}.menu{background:#fff;border:1px solid #e6eaf2;border-radius:18px;padding:18px;min-height:160px}.menuCode{font-size:11px;color:#64748b;font-weight:700}.menu h3{margin:8px 0;font-size:20px}.menu p{min-height:46px}.menu button{border:0;border-radius:12px;padding:10px 16px;background:#d7dde8;color:#637083;font-weight:700;cursor:not-allowed}'
    + '.note{background:#f8fafc}.meta{font-size:13px;color:#64748b;margin-top:6px}.footer{font-size:12px;color:#7a8496;text-align:center;margin:20px 0 4px}'
    + '@media(max-width:760px){.wrap{padding:16px}.metaGrid,.menus{grid-template-columns:1fr}}';
}

function erpB06J38_02_safetyPolicy_() {
  return {
    uiRoutingOnly: true,
    noBusinessStateMutation: true,
    paymentExecutionBlocked: true,
    settlementExecutionBlocked: true,
    vendorIndependentDbBlocked: true,
    vendorAsBranchUserGroup: true,
    buttonsDisabled: true
  };
}

function erpB06J38_02_clean_(v) {
  return String(v == null ? '' : v).trim();
}

function erpB06J38_02_escape_(v) {
  return String(v == null ? '' : v)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

function erpB06J38_02_checkConfig_() {
  var fatal = [];
  var warnings = [];
  var setupDbName = '';
  var configCount = 0;
  var masterId = '';
  var masterName = '';

  try {
    var setupSs = SpreadsheetApp.openById(ERP_B06J38_02_SETUP_DB_ID);
    setupDbName = setupSs.getName();
    var sheet = setupSs.getSheetByName(ERP_B06J38_02_CONFIG_SHEET_NAME);
    if (!sheet) {
      fatal.push('SystemConfig 시트 없음');
    } else {
      var values = sheet.getDataRange().getValues();
      configCount = Math.max(values.length - 1, 0);
      var map = {};
      for (var r = 1; r < values.length; r++) {
        var key = values[r][0];
        var val = values[r][1];
        if (key) map[String(key).trim()] = val;
      }
      masterId = map.FEELHAUS_DB_MASTER_ID || map.DB_MASTER_ID || map.SPREADSHEET_ID || '';
      if (!masterId) {
        fatal.push('FEELHAUS_DB_MASTER_ID 누락');
      } else {
        var masterSs = SpreadsheetApp.openById(masterId);
        masterName = masterSs.getName();
      }
    }
  } catch (err) {
    fatal.push(String(err && err.message ? err.message : err));
  }

  return {
    ok: fatal.length === 0,
    fatal: fatal,
    warnings: warnings,
    setupDbId: ERP_B06J38_02_SETUP_DB_ID,
    setupDbName: setupDbName,
    configSheetName: ERP_B06J38_02_CONFIG_SHEET_NAME,
    configCount: configCount,
    masterId: masterId,
    masterName: masterName
  };
}

function erpB06J38_02_autoRunSafe() {
  var result = {
    ok: true,
    build: ERP_B06J38_02_BUILD,
    moduleCode: ERP_B06J38_02_MODULE,
    checkedAt: new Date().toISOString(),
    fatal: [],
    warnings: [],
    checks: {},
    safety: erpB06J38_02_safetyPolicy_()
  };

  result.checks.config = erpB06J38_02_checkConfig_();
  result.checks.routeSampleVendor = erpB06J38_02_validateFieldEntry_({ roleCode: 'VENDOR_MANAGER', vendorId: 'VENDOR-SAMPLE', eventId: 'EVT-SAMPLE' });
  result.checks.routeSampleStaff = erpB06J38_02_validateFieldEntry_({ roleCode: 'STAFF_SALES', vendorId: 'VENDOR-SAMPLE', eventId: 'EVT-SAMPLE' });
  result.checks.routeMissingVendorBlocked = erpB06J38_02_validateFieldEntry_({ roleCode: 'VENDOR_MANAGER', vendorId: '', eventId: 'EVT-SAMPLE' });
  result.checks.renderFunctionAvailable = { ok: typeof erpFieldB06J38_01_renderEntryHtml === 'function', name: 'erpFieldB06J38_01_renderEntryHtml' };

  if (!result.checks.config.ok) result.fatal = result.fatal.concat(result.checks.config.fatal);
  if (!result.checks.routeSampleVendor.ok) result.fatal.push('VENDOR_MANAGER route validation failed');
  if (!result.checks.routeSampleStaff.ok) result.fatal.push('STAFF_SALES route validation failed');
  if (result.checks.routeMissingVendorBlocked.ok) result.fatal.push('vendorId 누락 차단 실패');
  if (!result.checks.renderFunctionAvailable.ok) result.warnings.push('B06J38-01 렌더 함수 미탑재: fallback 화면으로 대체 가능');

  result.ok = result.fatal.length === 0;
  Logger.log('======================================================');
  Logger.log('[B06J38-02 FIELD DOGET ROUTING] RESULT');
  Logger.log(JSON.stringify(result, null, 2));
  return result;
}

function erpB06J38_02_simulateDoGetVendor() {
  return erpB06J38_02_doGet({ parameter: { roleCode: 'VENDOR_MANAGER', vendorId: 'VENDOR-SAMPLE', eventId: 'EVT-SAMPLE' } }).getContent();
}

function erpB06J38_02_simulateDoGetMissingVendor() {
  return erpB06J38_02_doGet({ parameter: { roleCode: 'VENDOR_MANAGER', eventId: 'EVT-SAMPLE' } }).getContent();
}


/* ===== CoreLink.js ===== */
/**
 * build: ERP_B06J37_05_FIELD_CORE_LINK_CHECK_SAFE
 * role:
 *  - ERP_FIELD ↔ ERP_CORE 기준 연결 점검
 *
 * purpose:
 *  - ERP_FIELD가 CORE 기준 설정/MASTER/공통 시트/권한/상태 체계와 맞는지 점검
 *  - 업체/직원/현장 화면이 vendorId/eventId/roleCode 기준으로 분리될 준비가 되었는지 확인
 *  - 업체 독립 DB/독립 앱 구조 차단
 *
 * apply:
 *  - ERP_FIELD 폴더에 새 파일로 추가
 *  - 권장 파일명: ERP_FieldCoreLink_B06J37_05.js
 *
 * functions:
 *  - erpB06J37_05_autoRunSafe()
 */

var ERP_B06J37_05_BUILD = 'ERP_B06J37_05_FIELD_CORE_LINK_CHECK_SAFE';
var ERP_B06J37_05_SETUP_DB_ID = '17VMSpgSZCvIrUlgcw8yCNcnl8WQWo2IcRf5tDCcuJGM';
var ERP_B06J37_05_CONFIG_SHEET_NAME = 'SystemConfig';

var ERP_B06J37_05_FIELD_REQUIRED_FUNCTIONS = [
  'doGet'
];

var ERP_B06J37_05_FIELD_OPTIONAL_FUNCTIONS = [
  'include',
  'getEventVendorBootstrap',
  'searchEventVendorData',
  'getEventVendorDetail',
  'getEventVendorCustomerDetail',
  'saveEventVendorEvent',
  'saveEventVendorVendor',
  'saveEventVendorLink'
];

var ERP_B06J37_05_CORE_OPTIONAL_FUNCTIONS = [
  'erpCore_getConfig',
  'erpCore_getMasterInfo',
  'erpCore_getHeaderMap',
  'erpCore_generateId',
  'erpCore_validateStatus',
  'erpCore_getDataScope',
  'erpCore_log'
];

var ERP_B06J37_05_CORE_SHEETS = [
  {
    sheetName: 'ERP_행사관리',
    requiredHeaders: ['eventId','status','statusReason','createdAt','createdBy','updatedAt','updatedBy']
  },
  {
    sheetName: 'ERP_업체관리',
    requiredHeaders: ['vendorId','status','statusReason','createdAt','createdBy','updatedAt','updatedBy']
  },
  {
    sheetName: 'ERP_고객관리',
    requiredHeaders: ['customerId','eventId','vendorId','status','statusReason','createdAt','createdBy','updatedAt','updatedBy']
  },
  {
    sheetName: 'ERP_행사업체연결',
    requiredHeaders: ['eventVendorId','eventId','vendorId','status','statusReason','createdAt','createdBy','updatedAt','updatedBy']
  },
  {
    sheetName: 'ERP_CoreLog',
    requiredHeaders: ['logId','build','moduleCode','actionCode','targetSheet','targetId','actor','actedAt','snapshot','status','statusReason','createdAt','createdBy']
  }
];

function erpB06J37_05_autoRunSafe() {
  var result = {
    ok: true,
    build: ERP_B06J37_05_BUILD,
    moduleCode: 'ERP_FIELD',
    checkedAt: new Date().toISOString(),
    fatal: [],
    warnings: [],
    checks: {},
    safety: {
      fieldCoreLinkCheckOnly: true,
      noSheetMutation: true,
      noBusinessDataMutation: true,
      noUiMutation: true,
      noPaymentExecution: true,
      noRecoveryExecution: true,
      noAutoRecalculation: true,
      noExternalAccountingTransfer: true,
      independentVendorDbBlocked: true,
      vendorIsBranchUserGroupInsideErp: true
    }
  };

  console.log('======================================================');
  console.log('[B06J37-05 FIELD CORE LINK CHECK] START');

  try {
    result.checks.setup = erpB06J37_05_checkSetup_();
    erpB06J37_05_collect_(result, 'setup', result.checks.setup);

    result.checks.master = erpB06J37_05_checkMaster_(result.checks.setup.configMap);
    erpB06J37_05_collect_(result, 'master', result.checks.master);

    result.checks.coreSheets = erpB06J37_05_checkCoreSheets_(result.checks.master.masterSpreadsheet);
    erpB06J37_05_collect_(result, 'coreSheets', result.checks.coreSheets);

    result.checks.fieldRequiredFunctions = erpB06J37_05_checkFunctions_(
      'fieldRequiredFunctions',
      ERP_B06J37_05_FIELD_REQUIRED_FUNCTIONS,
      false
    );
    erpB06J37_05_collect_(result, 'fieldRequiredFunctions', result.checks.fieldRequiredFunctions);

    result.checks.fieldOptionalFunctions = erpB06J37_05_checkFunctions_(
      'fieldOptionalFunctions',
      ERP_B06J37_05_FIELD_OPTIONAL_FUNCTIONS,
      TrueSafe_()
    );
    erpB06J37_05_collect_(result, 'fieldOptionalFunctions', result.checks.fieldOptionalFunctions);

    result.checks.coreFunctionsLocal = erpB06J37_05_checkFunctions_(
      'coreOptionalFunctionsLocal',
      ERP_B06J37_05_CORE_OPTIONAL_FUNCTIONS,
      true
    );
    erpB06J37_05_collect_(result, 'coreFunctionsLocal', result.checks.coreFunctionsLocal);

    result.checks.configGuard = erpB06J37_05_checkConfigGuard_(result.checks.setup.configMap);
    erpB06J37_05_collect_(result, 'configGuard', result.checks.configGuard);

    result.checks.fieldScopePolicy = erpB06J37_05_fieldScopePolicy_();
    erpB06J37_05_collect_(result, 'fieldScopePolicy', result.checks.fieldScopePolicy);

    result.checks.scopeSamples = erpB06J37_05_scopeSampleCheck_();
    erpB06J37_05_collect_(result, 'scopeSamples', result.checks.scopeSamples);

  } catch (e) {
    result.fatal.push('B06J37-05 점검 예외: ' + String(e && e.message ? e.message : e));
    result.exceptionStack = String(e && e.stack ? e.stack : '');
  }

  result.fatalCount = result.fatal.length;
  result.warningCount = result.warnings.length;
  result.ok = result.fatalCount === 0;

  if (result.checks.master && result.checks.master.masterSpreadsheet) {
    result.checks.master.masterSpreadsheetName = result.checks.master.masterSpreadsheet.getName();
    delete result.checks.master.masterSpreadsheet;
  }

  console.log('[B06J37-05 FIELD CORE LINK CHECK] RESULT');
  console.log(JSON.stringify(result, null, 2));
  console.log('======================================================');

  return result;
}

function TrueSafe_() {
  return true;
}

function erpB06J37_05_checkSetup_() {
  var ss = SpreadsheetApp.openById(ERP_B06J37_05_SETUP_DB_ID);
  var sh = ss.getSheetByName(ERP_B06J37_05_CONFIG_SHEET_NAME);
  var fatal = [];
  var warnings = [];
  var configMap = {};

  if (!sh) {
    fatal.push('SystemConfig 시트를 찾지 못했습니다.');
    return { ok:false, fatal:fatal, warnings:warnings, configMap:configMap };
  }

  var values = sh.getDataRange().getValues();
  if (!values || values.length < 2) {
    fatal.push('SystemConfig 데이터가 비어 있습니다.');
    return { ok:false, fatal:fatal, warnings:warnings, configMap:configMap };
  }

  var headers = values[0].map(function(h){ return String(h || '').trim(); });
  var lower = headers.map(function(h){ return h.toLowerCase(); });

  var keyIdx = lower.indexOf('key');
  if (keyIdx < 0) keyIdx = lower.indexOf('configkey');
  if (keyIdx < 0) keyIdx = lower.indexOf('name');
  if (keyIdx < 0) keyIdx = 0;

  var valIdx = lower.indexOf('value');
  if (valIdx < 0) valIdx = lower.indexOf('configvalue');
  if (valIdx < 0) valIdx = lower.indexOf('spreadsheetid');
  if (valIdx < 0) valIdx = 1;

  for (var r = 1; r < values.length; r++) {
    var k = String(values[r][keyIdx] || '').trim();
    var v = String(values[r][valIdx] || '').trim();
    if (k) configMap[k] = v;
  }

  return {
    ok: true,
    fatal: fatal,
    warnings: warnings,
    setupDbId: ERP_B06J37_05_SETUP_DB_ID,
    setupDbName: ss.getName(),
    configSheetName: ERP_B06J37_05_CONFIG_SHEET_NAME,
    configCount: Object.keys(configMap).length,
    configMap: configMap
  };
}

function erpB06J37_05_checkMaster_(configMap) {
  var fatal = [];
  var warnings = [];
  var keys = ['FEELHAUS_DB_MASTER_ID','FEELHAUS_DB_MASTER','MASTER_SPREADSHEET_ID','MASTER_DB_ID','DB_MASTER_ID','SPREADSHEET_ID'];
  var raw = '';
  var usedKey = '';

  for (var i = 0; i < keys.length; i++) {
    if (configMap && configMap[keys[i]]) {
      raw = String(configMap[keys[i]]).trim();
      usedKey = keys[i];
      break;
    }
  }

  if (!raw) {
    fatal.push('MASTER ID를 SystemConfig에서 찾지 못했습니다.');
    return { ok:false, fatal:fatal, warnings:warnings, usedKey:usedKey, masterId:'' };
  }

  var masterId = erpB06J37_05_extractSpreadsheetId_(raw);
  var master = SpreadsheetApp.openById(masterId);

  return {
    ok: true,
    fatal: fatal,
    warnings: warnings,
    usedKey: usedKey,
    masterId: masterId,
    masterName: master.getName(),
    masterSpreadsheet: master
  };
}

function erpB06J37_05_checkCoreSheets_(master) {
  var fatal = [];
  var warnings = [];
  var sheets = [];

  ERP_B06J37_05_CORE_SHEETS.forEach(function(spec) {
    var sh = master.getSheetByName(spec.sheetName);
    if (!sh) {
      fatal.push('필수 시트 없음: ' + spec.sheetName);
      sheets.push({ sheetName: spec.sheetName, exists:false, missingHeaders:spec.requiredHeaders });
      return;
    }

    var headers = erpB06J37_05_getHeaders_(sh);
    var missing = spec.requiredHeaders.filter(function(h){ return headers.indexOf(h) < 0; });

    if (missing.length) {
      fatal.push(spec.sheetName + ' 누락 헤더: ' + missing.join(', '));
    }

    sheets.push({
      sheetName: spec.sheetName,
      exists: true,
      lastRow: sh.getLastRow(),
      lastCol: sh.getLastColumn(),
      missingHeaders: missing
    });
  });

  return {
    ok: fatal.length === 0,
    fatal: fatal,
    warnings: warnings,
    sheets: sheets
  };
}

function erpB06J37_05_checkFunctions_(groupName, names, optional) {
  var fatal = [];
  var warnings = [];
  var exists = [];
  var missing = [];

  names.forEach(function(name) {
    var ok = false;
    try {
      ok = typeof this[name] === 'function';
    } catch(e) {
      ok = false;
    }

    if (ok) exists.push(name);
    else missing.push(name);
  });

  if (missing.length) {
    if (optional) {
      warnings.push(groupName + ' 선택/후속 함수 미탑재: ' + missing.join(', '));
    } else {
      fatal.push(groupName + ' 필수 함수 누락: ' + missing.join(', '));
    }
  }

  return {
    ok: fatal.length === 0,
    fatal: fatal,
    warnings: warnings,
    groupName: groupName,
    total: names.length,
    existsCount: exists.length,
    missingCount: missing.length,
    exists: exists,
    missing: missing,
    optional: optional === true
  };
}

function erpB06J37_05_checkConfigGuard_(configMap) {
  var fatal = [];
  var warnings = [];
  var suspicious = [];

  Object.keys(configMap || {}).forEach(function(k) {
    var u = String(k || '').toUpperCase();
    if (
      u.indexOf('VENDOR_DB') >= 0 ||
      u.indexOf('VENDOR_SPREADSHEET') >= 0 ||
      u.indexOf('PARTNER_DB') >= 0 ||
      u.indexOf('BRANCH_DB') >= 0
    ) {
      suspicious.push({ key:k, value:configMap[k] });
    }
  });

  if (suspicious.length) {
    warnings.push('업체 독립 DB로 오해될 수 있는 설정 키가 있습니다. 운영 연결 사용 여부 확인 필요.');
  }

  return {
    ok: true,
    fatal: fatal,
    warnings: warnings,
    suspiciousConfigKeys: suspicious,
    independentVendorDbBlocked: true
  };
}

function erpB06J37_05_fieldScopePolicy_() {
  return {
    ok: true,
    fatal: [],
    warnings: [],
    moduleCode: 'ERP_FIELD',
    allowedRoleScope: ['VENDOR_OWNER','VENDOR_MANAGER','STAFF_SALES','STAFF_INSTALL','STAFF_AS','VIEWER'],
    dataScope: 'FIELD 화면은 vendorId/eventId/roleCode 기준으로 제한되어야 합니다.',
    vendorPolicy: '업체는 별도 앱이 아니라 ERP 내부 지점형 사용자 그룹입니다.',
    dbPolicy: 'FEELHAUS_DB_MASTER 단일 실무 허브를 사용합니다.',
    uiPolicy: '본사/업체/직원 화면은 ERP 하나 안에서 권한과 vendorId 기준으로 분리합니다.'
  };
}

function erpB06J37_05_scopeSampleCheck_() {
  var samples = [
    {
      roleCode: 'VENDOR_OWNER',
      vendorId: 'VENDOR-SAMPLE',
      eventId: '',
      expectedScopeType: 'VENDOR'
    },
    {
      roleCode: 'STAFF_SALES',
      vendorId: 'VENDOR-SAMPLE',
      eventId: 'EVT-SAMPLE',
      expectedScopeType: 'STAFF'
    },
    {
      roleCode: 'VIEWER',
      vendorId: 'VENDOR-SAMPLE',
      eventId: '',
      expectedScopeType: 'STAFF'
    }
  ];

  return {
    ok: true,
    fatal: [],
    warnings: [],
    samples: samples,
    message: 'FIELD 권한은 vendorId 누락 시 운영 데이터 조회를 차단해야 합니다.'
  };
}

function erpB06J37_05_extractSpreadsheetId_(raw) {
  var s = String(raw || '').trim();
  var m = s.match(/\/d\/([a-zA-Z0-9-_]+)/);
  return m && m[1] ? m[1] : s;
}

function erpB06J37_05_getHeaders_(sh) {
  if (!sh || sh.getLastRow() < 1 || sh.getLastColumn() < 1) return [];
  return sh.getRange(1, 1, 1, sh.getLastColumn()).getValues()[0].map(function(h) {
    return String(h || '').trim();
  });
}

function erpB06J37_05_collect_(result, label, check) {
  if (!check) return;
  if (check.fatal && check.fatal.length) {
    result.fatal = result.fatal.concat(check.fatal.map(function(x){ return label + ': ' + x; }));
  }
  if (check.warnings && check.warnings.length) {
    result.warnings = result.warnings.concat(check.warnings.map(function(x){ return label + ': ' + x; }));
  }
}


/* ===== App.js ===== */
/**
 * FEELHAUS ERP_FIELD
 * Build: v64-B06J36-8
 * Purpose: 현장 QR / 빠른 고객등록 / QR_SIGN 1건 생성 전용 분리 앱 골격
 * Principle: FEELHAUS_SETUP_DB > SystemConfig 자동 읽기 → FEELHAUS_DB_MASTER 자동 연결
 */

var FIELD_BUILD_NO = 'v64-B06J36-8';
var FIELD_BUILD_NAME = 'ERP_FIELD_v64_B06J36_8_QR_SIGN_LIMITED_CREATE_SAFE';
var FIELD_BUILD_TITLE = 'ERP_FIELD v64-B06J36-8 현장앱 골격 후보 / ERP 본체 무수정';
var FIELD_SETUP_DB_ID = '17VMSpgSZCvIrUlgcw8yCNcnl8WQWo2IcRf5tDCcuJGM';
var FIELD_CONFIG_SHEET_NAME = 'SystemConfig';

function doGet_B06J36_legacy(e) {
  var t = HtmlService.createTemplateFromFile('P_Index');
  t.buildNo = FIELD_BUILD_NO;
  t.buildTitle = FIELD_BUILD_TITLE;
  return t.evaluate()
    .setTitle('FEELHAUS ERP_FIELD')
    .setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL);
}

function fieldInclude(filename) {
  return HtmlService.createHtmlOutputFromFile(filename).getContent();
}

function erpFieldB06J36_8_fullCheck_20260501_log() {
  var result = fieldB06J36_8_fullCheck_();
  Logger.log('==============================');
  Logger.log("[ERP_FIELD FULL CHECK] fieldBuildSummary('B06J36-8')");
  Logger.log(JSON.stringify(result, null, 2));
  Logger.log('==============================');
  return result;
}

function fieldB06J36_8_fullCheck_() {
  var checks = [];
  var fatal = 0;
  function add(name, ok, detail) {
    if (!ok) fatal++;
    checks.push({ name: name, ok: !!ok, detail: detail || '' });
  }

  var config = fieldGetSystemConfigSafe_();
  add('SystemConfig read', config.ok, config.message);
  add('Code BUILD_NO B06J36-8', FIELD_BUILD_NO === 'v64-B06J36-8', FIELD_BUILD_NO);
  add('fieldGetBuildInfo exists', typeof fieldGetBuildInfo === 'function', 'FIELD build info');
  add('fieldSearchCustomers exists', typeof fieldSearchCustomers === 'function', 'read-only customer search wrapper');
  add('fieldCreatePublicEntryQrLink exists', typeof fieldCreatePublicEntryQrLink === 'function', 'public QR link builder');
  add('fieldCreateQrSignDocumentForCustomer limited create exists', typeof fieldCreateQrSignDocumentForCustomer === 'function', 'limited real create with policy guard');
  add('fieldSimulateQrSignDocumentForCustomer exists', typeof fieldSimulateQrSignDocumentForCustomer === 'function', 'QR_SIGN simulation only');
  add('fieldRequestQrSignReissueApproval guarded', typeof fieldRequestQrSignReissueApproval === 'function', 'approval request guarded in skeleton');

  var master = fieldOpenMasterDbSafe_();
  add('FEELHAUS_DB_MASTER connect', master.ok, master.message);

  var customerProbe = { ok: true, message: 'MASTER 미연결 상태에서는 검색 시뮬레이션만 수행', data: { rows: [] } };
  if (master.ok) {
    try {
      customerProbe = fieldSearchCustomers({ keyword: '', limit: 3 });
      add('customer read probe', customerProbe.ok, 'rows=' + ((customerProbe.data && customerProbe.data.rows) ? customerProbe.data.rows.length : 0));
    } catch (err) {
      add('customer read probe', false, fieldErr_(err));
    }
  } else {
    add('customer read probe skipped', true, 'MASTER 설정 확인 후 실제 조회 가능');
  }

  return fieldResponse_(fatal === 0, fatal === 0 ? 'B06J36-8 ERP_FIELD fullCheck 통과' : 'B06J36-8 ERP_FIELD fullCheck 점검 필요', {
    build: FIELD_BUILD_NO,
    title: FIELD_BUILD_TITLE,
    fatal: fatal,
    checks: checks,
    configKeyCount: config.keyCount || 0,
    masterConnected: master.ok,
    customerProbe: customerProbe.data || {}
  }, fatal ? 'FIELD_FULLCHECK_FAILED' : '');
}

function fieldGetBuildInfo() {
  return fieldResponse_(true, 'ERP_FIELD build info', {
    build: FIELD_BUILD_NO,
    buildName: FIELD_BUILD_NAME,
    title: FIELD_BUILD_TITLE,
    role: 'ERP_FIELD',
    sourceDb: 'FEELHAUS_SETUP_DB > SystemConfig',
    masterHub: 'FEELHAUS_DB_MASTER',
    mode: 'SKELETON_CANDIDATE',
    writePolicy: 'Phase 2 후보: QR_SIGN 1건 생성은 제한적 실생성, 재서명 승인요청은 guard 상태'
  });
}

function fieldSearchCustomers(payload) {
  payload = payload || {};
  var keyword = fieldS_(payload.keyword || payload.query || '').toLowerCase();
  var eventId = fieldS_(payload.eventId || '');
  var limit = Math.min(Math.max(Number(payload.limit || 20), 1), 100);
  var master = fieldOpenMasterDbSafe_();
  if (!master.ok) return fieldResponse_(false, master.message, { rows: [] }, 'MASTER_NOT_CONNECTED');

  var sheetNames = ['ERP_고객관리', 'Customers', 'ERP_Customers', 'SIGN_Customers', 'SIGN_QR_Customers', 'QR_Customers', 'RegularMembers'];
  var rows = [];
  for (var i = 0; i < sheetNames.length && rows.length < limit; i++) {
    var sh = master.ss.getSheetByName(sheetNames[i]);
    if (!sh) continue;
    var table = fieldReadTable_(sh);
    for (var r = 0; r < table.rows.length && rows.length < limit; r++) {
      var obj = table.rows[r];
      var hay = [obj.customerId, obj.name, obj.customerName, obj.phone, obj.dong, obj.hosu, obj.ho, obj.eventId, obj.memberType, obj.regularCheck].map(fieldS_).join(' ').toLowerCase();
      if (eventId && fieldS_(obj.eventId) !== eventId) continue;
      if (keyword && hay.indexOf(keyword) === -1) continue;
      rows.push({
        sourceSheet: sheetNames[i],
        customerId: fieldS_(obj.customerId || obj.memberId || obj.id),
        eventId: fieldS_(obj.eventId),
        name: fieldS_(obj.name || obj.customerName),
        phone: fieldS_(obj.phone || obj.mobile),
        dong: fieldS_(obj.dong),
        hosu: fieldS_(obj.hosu || obj.ho),
        memberType: fieldS_(obj.memberType),
        regularCheck: fieldS_(obj.regularCheck || obj.memberStatus || obj.status)
      });
    }
  }
  return fieldResponse_(true, '고객 검색 완료', { rows: rows, count: rows.length });
}

function fieldGetCustomerDetail(payload) {
  payload = payload || {};
  var id = fieldS_(payload.customerId || payload.id);
  if (!id) return fieldResponse_(false, 'customerId가 필요합니다.', {}, 'MISSING_CUSTOMER_ID');
  var found = fieldSearchCustomers({ keyword: id, limit: 1 });
  if (!found.ok || !found.data.rows.length) return fieldResponse_(false, '고객을 찾을 수 없습니다.', {}, 'CUSTOMER_NOT_FOUND');
  return fieldResponse_(true, '고객 상세 조회 완료', found.data.rows[0]);
}

function fieldCreatePublicEntryQrLink(payload) {
  payload = payload || {};
  var eventId = fieldS_(payload.eventId || payload.fieldEventId);
  var eventName = fieldS_(payload.eventName || payload.eventTitle || '');
  var boothHint = fieldS_(payload.boothHint || payload.booth || '');
  if (!eventId) return fieldResponse_(false, 'eventId가 필요합니다.', {}, 'MISSING_EVENT_ID');

  var base = fieldGetSignWebAppUrl_();
  if (!base) return fieldResponse_(false, 'SIGN_WEBAPP_URL 설정이 필요합니다.', {}, 'SIGN_URL_NOT_CONFIGURED');
  var params = {
    mode: 'qr',
    fieldMode: 'QR',
    qrEntry: 'Y',
    entryType: 'PUBLIC',
    eventId: eventId,
    eventName: eventName,
    boothHint: boothHint
  };
  var url = base + (base.indexOf('?') >= 0 ? '&' : '?') + fieldQuery_(params);
  return fieldResponse_(true, '행사 공용입장 QR 링크 생성 완료', {
    linkOnly: true,
    isPublicEntry: true,
    documentId: '',
    customerId: '',
    status: 'PUBLIC_ENTRY_LINK',
    qrType: 'PUBLIC',
    entryType: 'PUBLIC',
    mode: 'qr',
    eventId: eventId,
    eventName: eventName,
    boothHint: boothHint,
    qrUrl: url,
    signUrl: url,
    qrImageUrl: 'https://quickchart.io/qr?size=360&text=' + encodeURIComponent(url),
    createdAt: new Date().toISOString(),
    buildNo: FIELD_BUILD_NO
  });
}

function fieldCreateQrSignDocumentForCustomer(payload) {
  payload = payload || {};
  var customerId = fieldS_(payload.customerId || payload.id);
  var createdBy = fieldS_(payload.createdBy || Session.getActiveUser().getEmail() || 'ERP_FIELD');
  if (!customerId) return fieldResponse_(false, 'customerId가 필요합니다.', {}, 'MISSING_CUSTOMER_ID');

  var sim = fieldSimulateQrSignDocumentForCustomer(payload);
  if (!sim.ok) return sim;
  var d = sim.data || {};

  if (d.decision === 'WOULD_REUSE_READY_TO_SIGN' && d.targetDocumentId) {
    return fieldResponse_(true, '기존 READY_TO_SIGN QR_SIGN 문서를 재사용합니다.', {
      reused: true,
      created: false,
      documentId: d.targetDocumentId,
      signUrl: d.targetSignUrl || '',
      qrUrl: d.targetQrUrl || d.targetSignUrl || '',
      status: 'READY_TO_SIGN',
      customerId: customerId,
      eventId: d.eventId,
      policyDecision: d.decision,
      writeExecuted: false
    });
  }

  if (d.decision === 'BLOCKED_ARCHIVED_REISSUE_REQUIRED') {
    return fieldResponse_(false, d.message || '보관완료/서명완료 문서가 있어 자동 생성이 차단됩니다.', d, 'FIELD_REISSUE_APPROVAL_REQUIRED');
  }

  if (d.decision !== 'WOULD_CREATE_READY_TO_SIGN' || !d.canCreate) {
    return fieldResponse_(false, 'QR_SIGN 문서 생성 조건을 만족하지 않습니다.', d, 'FIELD_CREATE_NOT_ALLOWED');
  }

  if (payload.dryRun === true || payload.simulationOnly === true) {
    d.writeExecuted = false;
    d.simulationOnly = true;
    return fieldResponse_(true, 'QR_SIGN 신규 생성 가능 dryRun 통과', d);
  }

  var master = fieldOpenMasterDbSafe_();
  if (!master.ok) return fieldResponse_(false, master.message, { customerId: customerId }, 'MASTER_NOT_CONNECTED');
  var ss = master.ss;
  var customer = d.customer || fieldFindCustomerById_(ss, customerId).data || {};
  var eventId = fieldS_(payload.eventId || d.eventId || customer.eventId);
  if (!eventId) return fieldResponse_(false, 'eventId가 필요합니다.', d, 'MISSING_EVENT_ID');

  var headers = [
    'documentId','documentNo','documentType','status','statusReason','eventId','vendorId','customerId',
    'saleId','contractId','installId','settlementId','approvalId','title','templateCode','signMethod',
    'signUrl','qrUrl','createdAt','createdBy','updatedAt','updatedBy','notes','sourceApp','buildNo'
  ];
  var sh = fieldEnsureSheet_(ss, 'SIGN_Documents', headers);
  var now = new Date().toISOString();
  var documentId = 'DOC_' + Utilities.getUuid().replace(/-/g, '').substring(0, 12).toUpperCase();
  var documentNo = 'DOC-' + Utilities.formatDate(new Date(), Session.getScriptTimeZone() || 'Asia/Seoul', 'yyyyMMdd') + '-' + Utilities.formatString('%03d', Math.max(1, sh.getLastRow()));
  var base = fieldGetSignWebAppUrl_();
  if (!base) return fieldResponse_(false, 'SIGN_WEBAPP_URL 설정이 필요합니다.', d, 'SIGN_URL_NOT_CONFIGURED');
  base = String(base).split('?')[0];
  var boothHint = fieldS_(payload.boothHint) || (fieldS_(customer.dong) + '동 ' + fieldS_(customer.hosu || customer.ho) + '호');
  var eventName = fieldS_(payload.eventName || customer.eventName || customer.eventType || '입주박람회');
  var signUrl = base + '?mode=sign&documentId=' + encodeURIComponent(documentId) + '&fieldMode=QR&eventName=' + encodeURIComponent(eventName) + '&boothHint=' + encodeURIComponent(boothHint);

  var rowObj = {
    documentId: documentId,
    documentNo: documentNo,
    documentType: 'QR_SIGN',
    status: 'READY_TO_SIGN',
    statusReason: 'ERP_FIELD QR_SIGN 1건 제한 생성',
    eventId: eventId,
    vendorId: fieldS_(payload.vendorId || customer.vendorId),
    customerId: customerId,
    saleId: '',
    contractId: '',
    installId: '',
    settlementId: '',
    approvalId: '',
    title: 'QR 서명확인서',
    templateCode: 'PDF_QR_SIGN',
    signMethod: 'QR',
    signUrl: signUrl,
    qrUrl: signUrl,
    createdAt: now,
    createdBy: createdBy,
    updatedAt: now,
    updatedBy: createdBy,
    notes: 'ERP_FIELD B06J36-8 QR_SIGN limited create / dong=' + fieldS_(customer.dong) + ' hosu=' + fieldS_(customer.hosu || customer.ho),
    sourceApp: 'ERP_FIELD',
    buildNo: FIELD_BUILD_NO
  };
  fieldAppendObjectByHeader_(sh, rowObj);

  try {
    var logHeaders = ['logId','documentId','actionType','fromStatus','toStatus','actor','reason','createdAt','buildNo','sourceApp'];
    var logSh = fieldEnsureSheet_(ss, 'SIGN_Document_Logs', logHeaders);
    fieldAppendObjectByHeader_(logSh, {
      logId: 'LOG-' + Utilities.getUuid().replace(/-/g, '').substring(0, 12).toUpperCase(),
      documentId: documentId,
      actionType: 'CREATE_QR_SIGN_FROM_ERP_FIELD',
      fromStatus: '',
      toStatus: 'READY_TO_SIGN',
      actor: createdBy,
      reason: 'ERP_FIELD QR_SIGN 1건 제한 생성',
      createdAt: now,
      buildNo: FIELD_BUILD_NO,
      sourceApp: 'ERP_FIELD'
    });
  } catch (logErr) {}

  return fieldResponse_(true, 'QR_SIGN 문서 생성 완료', {
    reused: false,
    created: true,
    documentId: documentId,
    documentNo: documentNo,
    status: 'READY_TO_SIGN',
    signUrl: signUrl,
    qrUrl: signUrl,
    customerId: customerId,
    eventId: eventId,
    dong: fieldS_(customer.dong),
    hosu: fieldS_(customer.hosu || customer.ho),
    writeExecuted: true,
    simulationBeforeWrite: d
  });
}

function fieldSimulateQrSignDocumentForCustomer(payload) {
  payload = payload || {};
  var customerId = fieldS_(payload.customerId || payload.id);
  var eventId = fieldS_(payload.eventId || '');
  if (!customerId) return fieldResponse_(false, 'customerId가 필요합니다.', {}, 'MISSING_CUSTOMER_ID');

  var master = fieldOpenMasterDbSafe_();
  if (!master.ok) return fieldResponse_(false, master.message, { customerId: customerId }, 'MASTER_NOT_CONNECTED');

  var customer = fieldFindCustomerById_(master.ss, customerId);
  if (!customer.ok) return fieldResponse_(false, customer.message, { customerId: customerId }, customer.errorCode || 'CUSTOMER_NOT_FOUND');
  if (!eventId) eventId = fieldS_(customer.data.eventId);

  var docs = fieldFindQrSignDocuments_(master.ss, customerId, eventId);
  var ready = [];
  var locked = [];
  var other = [];
  for (var i = 0; i < docs.length; i++) {
    var st = fieldS_(docs[i].status || docs[i].documentStatus).toUpperCase();
    if (fieldIsReadyToSignStatus_(st)) ready.push(docs[i]);
    else if (fieldIsLockedDocStatus_(st)) locked.push(docs[i]);
    else other.push(docs[i]);
  }

  var decision = 'WOULD_CREATE_READY_TO_SIGN';
  var canCreate = true;
  var canReuse = false;
  var requiresApproval = false;
  var message = '기존 QR_SIGN 문서가 없어 새 READY_TO_SIGN 문서 생성 대상입니다.';
  var targetDocumentId = '';
  if (ready.length) {
    decision = 'WOULD_REUSE_READY_TO_SIGN';
    canCreate = false;
    canReuse = true;
    message = '기존 READY_TO_SIGN QR_SIGN 문서를 재사용해야 합니다.';
    targetDocumentId = fieldS_(ready[0].documentId || ready[0].documentNo);
    var targetSignUrl = fieldS_(ready[0].signUrl || ready[0].qrUrl);
    var targetQrUrl = fieldS_(ready[0].qrUrl || ready[0].signUrl);
  } else if (locked.length) {
    decision = 'BLOCKED_ARCHIVED_REISSUE_REQUIRED';
    canCreate = false;
    requiresApproval = true;
    message = '보관완료/서명완료 QR_SIGN 문서가 있어 자동 신규 생성이 차단됩니다. 재서명 승인요청이 필요합니다.';
    targetDocumentId = fieldS_(locked[0].documentId || locked[0].documentNo);
  }

  return fieldResponse_(true, 'QR_SIGN 1건 생성 시뮬레이션 완료', {
    simulationOnly: true,
    writeExecuted: false,
    customer: customer.data,
    customerId: customerId,
    eventId: eventId,
    decision: decision,
    canCreate: canCreate,
    canReuse: canReuse,
    requiresApproval: requiresApproval,
    message: message,
    targetDocumentId: targetDocumentId,
    targetSignUrl: (typeof targetSignUrl !== 'undefined' ? targetSignUrl : ''),
    targetQrUrl: (typeof targetQrUrl !== 'undefined' ? targetQrUrl : ''),
    existing: {
      readyToSignCount: ready.length,
      lockedCount: locked.length,
      otherCount: other.length,
      allCount: docs.length
    },
    policy: {
      readyToSign: '재사용',
      archivedOrCompleted: '자동생성 차단 후 승인요청',
      none: '다음 단계에서 새 READY_TO_SIGN 생성 가능'
    }
  });
}

function fieldFindCustomerById_(ss, customerId) {
  var sheetNames = ['ERP_고객관리', 'Customers', 'ERP_Customers', 'SIGN_Customers', 'SIGN_QR_Customers', 'QR_Customers', 'RegularMembers'];
  for (var i = 0; i < sheetNames.length; i++) {
    var sh = ss.getSheetByName(sheetNames[i]);
    if (!sh) continue;
    var table = fieldReadTable_(sh);
    for (var r = 0; r < table.rows.length; r++) {
      var obj = table.rows[r];
      var id = fieldS_(obj.customerId || obj.memberId || obj.id);
      if (id === customerId) {
        return { ok: true, message: '고객 조회 완료', data: {
          sourceSheet: sheetNames[i],
          rowNumber: r + 2,
          customerId: id,
          eventId: fieldS_(obj.eventId),
          name: fieldS_(obj.name || obj.customerName),
          phone: fieldS_(obj.phone || obj.mobile),
          dong: fieldS_(obj.dong),
          hosu: fieldS_(obj.hosu || obj.ho),
          memberType: fieldS_(obj.memberType),
          regularCheck: fieldS_(obj.regularCheck || obj.memberStatus || obj.status)
        }};
      }
    }
  }
  return { ok: false, message: '고객을 찾을 수 없습니다.', errorCode: 'CUSTOMER_NOT_FOUND' };
}

function fieldFindQrSignDocuments_(ss, customerId, eventId) {
  var sheetNames = ['SIGN_Documents', 'Documents', 'SIGN_DOCUMENTS', 'QR_SIGN_Documents', 'ERP_문서관리'];
  var out = [];
  for (var i = 0; i < sheetNames.length; i++) {
    var sh = ss.getSheetByName(sheetNames[i]);
    if (!sh) continue;
    var table = fieldReadTable_(sh);
    for (var r = 0; r < table.rows.length; r++) {
      var obj = table.rows[r];
      var cid = fieldS_(obj.customerId || obj.memberId);
      if (cid !== customerId) continue;
      var ev = fieldS_(obj.eventId);
      if (eventId && ev && ev !== eventId) continue;
      var typeText = [obj.documentType, obj.type, obj.docType, obj.qrType, obj.sourceType, obj.category].map(fieldS_).join(' ').toUpperCase();
      var idText = [obj.documentId, obj.documentNo, obj.formType].map(fieldS_).join(' ').toUpperCase();
      if (typeText.indexOf('QR_SIGN') === -1 && idText.indexOf('QR_SIGN') === -1) continue;
      out.push({
        sourceSheet: sheetNames[i],
        rowNumber: r + 2,
        documentId: fieldS_(obj.documentId || obj.id),
        documentNo: fieldS_(obj.documentNo),
        customerId: cid,
        eventId: ev,
        status: fieldS_(obj.status || obj.documentStatus || obj.signStatus),
        documentType: fieldS_(obj.documentType || obj.type || obj.docType),
        signUrl: fieldS_(obj.signUrl || obj.qrUrl || obj.url),
        createdAt: fieldS_(obj.createdAt),
        updatedAt: fieldS_(obj.updatedAt)
      });
    }
  }
  return out;
}

function fieldIsReadyToSignStatus_(status) {
  status = fieldS_(status).toUpperCase();
  return ['READY_TO_SIGN', 'PENDING_SIGN', 'SIGN_WAITING', 'ACTIVE'].indexOf(status) >= 0;
}

function fieldIsLockedDocStatus_(status) {
  status = fieldS_(status).toUpperCase();
  return ['ARCHIVED', 'SIGN_COMPLETED', 'PDF_COMPLETED', 'LOCKED', 'COMPLETED'].indexOf(status) >= 0;
}

function fieldRequestQrSignReissueApproval(payload) {
  return fieldResponse_(false, 'ERP_FIELD Phase 1 골격에서는 재서명 승인요청 쓰기 작업을 비활성화했습니다. 기존 ERP 기준본에서 처리하세요.', {
    requestedPayload: payload || {},
    policy: 'APPROVAL_WRITE_GUARDED_IN_SKELETON',
    nextPhase: 'ERP_ADMIN 승인센터 분리 후 연결'
  }, 'FIELD_APPROVAL_WRITE_GUARDED');
}

function fieldEnsureSheet_(ss, sheetName, headers) {
  var sh = ss.getSheetByName(sheetName);
  if (!sh) sh = ss.insertSheet(sheetName);
  var lastCol = Math.max(sh.getLastColumn(), 1);
  var existing = sh.getLastRow() ? sh.getRange(1, 1, 1, lastCol).getDisplayValues()[0].map(fieldS_) : [];
  if (!existing.length || existing.every(function(v){ return !v; })) {
    sh.getRange(1, 1, 1, headers.length).setValues([headers]);
    return sh;
  }
  var needAdd = [];
  headers.forEach(function(h){ if (existing.indexOf(h) < 0) needAdd.push(h); });
  if (needAdd.length) {
    sh.getRange(1, existing.length + 1, 1, needAdd.length).setValues([needAdd]);
  }
  return sh;
}

function fieldAppendObjectByHeader_(sh, obj) {
  var lastCol = Math.max(sh.getLastColumn(), 1);
  var headers = sh.getRange(1, 1, 1, lastCol).getDisplayValues()[0].map(fieldS_);
  var row = headers.map(function(h){ return obj[h] === undefined ? '' : obj[h]; });
  sh.appendRow(row);
}

function fieldGetSystemConfigSafe_() {
  try {
    var ss = SpreadsheetApp.openById(FIELD_SETUP_DB_ID);
    var sh = ss.getSheetByName(FIELD_CONFIG_SHEET_NAME);
    if (!sh) return { ok: false, message: 'SystemConfig 시트를 찾을 수 없습니다.', map: {}, keyCount: 0 };
    var values = sh.getDataRange().getValues();
    if (!values.length) return { ok: false, message: 'SystemConfig가 비어 있습니다.', map: {}, keyCount: 0 };
    var headers = values[0].map(fieldS_);
    var keyIdx = fieldFindHeader_(headers, ['configKey', 'key', 'name', 'settingKey', '항목', '키']);
    var valIdx = fieldFindHeader_(headers, ['configValue', 'value', 'settingValue', '값']);
    if (keyIdx < 0) keyIdx = 0;
    if (valIdx < 0) valIdx = 1;
    var map = {};
    for (var i = 1; i < values.length; i++) {
      var k = fieldS_(values[i][keyIdx]);
      if (!k) continue;
      map[k] = values[i][valIdx];
    }
    return { ok: true, message: 'SystemConfig 자동 읽기 정상', map: map, keyCount: Object.keys(map).length };
  } catch (err) {
    return { ok: false, message: fieldErr_(err), map: {}, keyCount: 0 };
  }
}

function fieldOpenMasterDbSafe_() {
  var cfg = fieldGetSystemConfigSafe_();
  if (!cfg.ok) return { ok: false, message: cfg.message };
  var keys = ['FEELHAUS_DB_MASTER_ID', 'FEELHAUS_DB_MASTER', 'MASTER_DB_ID', 'DB_MASTER_ID', 'ERP_DB_ID', 'FEELHAUS_MASTER_DB_ID'];
  var id = '';
  for (var i = 0; i < keys.length; i++) {
    if (cfg.map[keys[i]]) { id = fieldExtractId_(cfg.map[keys[i]]); break; }
  }
  if (!id) return { ok: false, message: 'FEELHAUS_DB_MASTER ID 설정을 찾지 못했습니다.' };
  try {
    return { ok: true, message: 'FEELHAUS_DB_MASTER 연결 정상', ss: SpreadsheetApp.openById(id), id: id };
  } catch (err) {
    return { ok: false, message: 'FEELHAUS_DB_MASTER 연결 실패: ' + fieldErr_(err), id: id };
  }
}

function fieldGetSignWebAppUrl_() {
  var cfg = fieldGetSystemConfigSafe_();
  if (!cfg.ok) return '';
  var keys = ['SIGN_WEBAPP_URL', 'SIGN_URL', 'SIGN_APP_URL', 'FEELHAUS_SIGN_URL', 'SIGN_DEPLOY_URL'];
  for (var i = 0; i < keys.length; i++) {
    var v = fieldS_(cfg.map[keys[i]]);
    if (v) return v;
  }
  return '';
}

function fieldReadTable_(sh) {
  var values = sh.getDataRange().getValues();
  if (!values.length) return { headers: [], rows: [] };
  var headers = values[0].map(fieldS_);
  var rows = [];
  for (var i = 1; i < values.length; i++) {
    var obj = {};
    for (var c = 0; c < headers.length; c++) {
      if (headers[c]) obj[headers[c]] = values[i][c];
    }
    rows.push(obj);
  }
  return { headers: headers, rows: rows };
}

function fieldFindHeader_(headers, aliases) {
  var lower = headers.map(function(h) { return fieldS_(h).toLowerCase(); });
  for (var i = 0; i < aliases.length; i++) {
    var idx = lower.indexOf(fieldS_(aliases[i]).toLowerCase());
    if (idx >= 0) return idx;
  }
  return -1;
}

function fieldResponse_(ok, message, data, errorCode) {
  return { ok: !!ok, message: message || '', data: data || {}, errorCode: errorCode || '', meta: { build: FIELD_BUILD_NO, generatedAt: new Date().toISOString() } };
}

function fieldS_(v) { return v === null || v === undefined ? '' : String(v).trim(); }
function fieldErr_(err) { return err && err.stack ? String(err.stack) : String(err); }
function fieldExtractId_(v) {
  var s = fieldS_(v);
  var m = s.match(/[-\w]{25,}/);
  return m ? m[0] : s;
}
function fieldQuery_(obj) {
  var parts = [];
  Object.keys(obj || {}).forEach(function(k) {
    var v = fieldS_(obj[k]);
    if (v !== '') parts.push(encodeURIComponent(k) + '=' + encodeURIComponent(v));
  });
  return parts.join('&');
}


/* ===== Route.js ===== */
/**
 * build: ERP_B06J40_16_20_SALES_DRAFT_FINAL_PREP_SAFE_UPLOAD
 * module: ERP_FIELD
 * purpose:
 * - FIELD doGet single entry point
 * - customerLookup route -> B06J39 stable live lookup with diagnostics
 * - sales route -> B06J40 sales schema fix/final prep screen
 * - non-open routes remain READ ONLY placeholders
 * safety:
 * - no sheet write / no save / no update / no delete / no settlement / no external integration
 */

var FIELD_ROUTE_BUILD = 'ERP_SIGN_B06J41_001_080_DOCUMENT_REOPEN_SETTLEMENT_CONTROL_SAFE_UPLOAD';

function doGet(e) {
  try {
    var p = (e && e.parameter) ? e.parameter : {};
    var ctx = erpFieldB06J40_04_12_normalizeContext_(p);
    var guard = erpFieldB06J40_04_12_guardContext_(ctx);
    if (!guard.ok) return erpFieldB06J40_04_12_renderBlocked_(ctx, guard.fatal);

    if (ctx.route === 'customerLookup') {
      return erpFieldB06J39_04_09_renderCustomerStableHtml(ctx);
    }

    if (ctx.route === 'sales') {
      // Normal sales route must show the sales input/customer binding screen.
      // Schema/final-prep screens are kept behind explicit routes to avoid
      // customer lookup [판매등록] links being swallowed by schema diagnostics.
      if (typeof erpFieldB06J40_13_15_renderSalesInputBindHtml === 'function') {
        return erpFieldB06J40_13_15_renderSalesInputBindHtml(ctx);
      }
      if (typeof erpFieldB06J40_16_20_renderSalesDraftPrepHtml === 'function') {
        return erpFieldB06J40_16_20_renderSalesDraftPrepHtml(ctx);
      }
      return erpFieldB06J40_04_12_renderSalesFullPrecheckHtml(ctx);
    }


    if (ctx.route === 'salesSave') {
      if (typeof erpFieldB06J40_28_30_renderSalesDraftSaveHtml === 'function') {
        return erpFieldB06J40_28_30_renderSalesDraftSaveHtml(ctx);
      }
      return erpFieldB06J40_13_15_renderSalesInputBindHtml(ctx);
    }


    if (ctx.route === 'salesRecent') {
      if (typeof erpFieldB06J40_31_33_renderSalesRecentHtml === 'function') {
        return erpFieldB06J40_31_33_renderSalesRecentHtml(ctx);
      }
      return erpFieldB06J40_13_15_renderSalesInputBindHtml(ctx);
    }



    if (ctx.route === 'salesDetail') {
      if (typeof erpFieldB06J40_34_36_renderSalesDetailHtml === 'function') {
        return erpFieldB06J40_34_36_renderSalesDetailHtml(ctx);
      }
      if (typeof erpFieldB06J40_31_33_renderSalesRecentHtml === 'function') {
        return erpFieldB06J40_31_33_renderSalesRecentHtml(ctx);
      }
      return erpFieldB06J40_13_15_renderSalesInputBindHtml(ctx);
    }



















    if (ctx.route === 'signStatusLink' || ctx.route === 'signStatus' || ctx.route === 'salesSignStatus' || ctx.route === 'contractSignStatus') {
      if (typeof erpFieldB06J41_001_080_renderSignStatusLinkHtml === 'function') {
        return erpFieldB06J41_001_080_renderSignStatusLinkHtml(ctx);
      }
      return erpFieldB06J40_04_12_renderReadonlyRoute_(ctx);
    }

    if (ctx.route === 'signatureSaveExecute' || ctx.route === 'signatureSave' || ctx.route === 'signSaveExecute' || ctx.route === 'signatureSaveHandoff' || ctx.route === 'signatureHandoffToSign') {
      return erpFieldB06J40_04_12_renderBlocked_(ctx, ['FIELD V37 차단: SIGN 서명 저장/외부연동 실제 실행 금지', '허용 route: signatureSavePrecheck / signatureSaveDryRun / signatureSaveConfirmPrep']);
    }

    if (ctx.route === 'signatureSaveConfirmPrep' || ctx.route === 'signatureConfirmPrep' || ctx.route === 'signSaveConfirmPrep') {
      if (typeof erpFieldB06J41_86_90_renderSignatureSaveConfirmPrepHtml === 'function') {
        return erpFieldB06J41_86_90_renderSignatureSaveConfirmPrepHtml(ctx);
      }
      if (typeof erpFieldB06J41_81_85_renderSignatureSaveDryRunAfterSchemaHtml === 'function') {
        return erpFieldB06J41_81_85_renderSignatureSaveDryRunAfterSchemaHtml(ctx);
      }
      return erpFieldB06J40_04_12_renderReadonlyRoute_(ctx);
    }

    if (ctx.route === 'signatureDryRunAfterSchema' || ctx.route === 'signatureSaveDryRunAfterSchema' || ctx.route === 'signatureSchemaFixedDryRun') {
      if (typeof erpFieldB06J41_81_85_renderSignatureSaveDryRunAfterSchemaHtml === 'function') {
        return erpFieldB06J41_81_85_renderSignatureSaveDryRunAfterSchemaHtml(ctx);
      }
      if (typeof erpFieldB06J41_71_75_renderSignatureSaveDryRunHtml === 'function') {
        return erpFieldB06J41_71_75_renderSignatureSaveDryRunHtml(ctx);
      }
      return erpFieldB06J40_04_12_renderReadonlyRoute_(ctx);
    }


    if (ctx.route === 'signatureSchemaFix' || ctx.route === 'signatureSaveSchemaFix' || ctx.route === 'signatureHeaderFix') {
      if (typeof erpFieldB06J41_76_80_renderSignatureSaveSchemaFixHtml === 'function') {
        return erpFieldB06J41_76_80_renderSignatureSaveSchemaFixHtml(ctx);
      }
      if (typeof erpFieldB06J41_71_75_renderSignatureSaveDryRunHtml === 'function') {
        return erpFieldB06J41_71_75_renderSignatureSaveDryRunHtml(ctx);
      }
      return erpFieldB06J40_04_12_renderReadonlyRoute_(ctx);
    }

    if (ctx.route === 'signatureSaveDryRun' || ctx.route === 'signSaveDryRun' || ctx.route === 'signatureSchemaDryRun') {
      if (typeof erpFieldB06J41_71_75_renderSignatureSaveDryRunHtml === 'function') {
        return erpFieldB06J41_71_75_renderSignatureSaveDryRunHtml(ctx);
      }
      if (typeof erpFieldB06J41_66_70_renderSignatureSavePrecheckHtml === 'function') {
        return erpFieldB06J41_66_70_renderSignatureSavePrecheckHtml(ctx);
      }
      return erpFieldB06J40_04_12_renderReadonlyRoute_(ctx);
    }

    if (ctx.route === 'signatureSavePrecheck' || ctx.route === 'signSavePrecheck' || ctx.route === 'signatureDataPrecheck') {
      if (typeof erpFieldB06J41_66_70_renderSignatureSavePrecheckHtml === 'function') {
        return erpFieldB06J41_66_70_renderSignatureSavePrecheckHtml(ctx);
      }
      if (typeof erpFieldB06J41_61_65_renderSignaturePadPreviewHtml === 'function') {
        return erpFieldB06J41_61_65_renderSignaturePadPreviewHtml(ctx);
      }
      return erpFieldB06J40_04_12_renderReadonlyRoute_(ctx);
    }

    if (ctx.route === 'signaturePadPreview' || ctx.route === 'signPadPreview' || ctx.route === 'signaturePadActivePreview') {
      if (typeof erpFieldB06J41_61_65_renderSignaturePadPreviewHtml === 'function') {
        return erpFieldB06J41_61_65_renderSignaturePadPreviewHtml(ctx);
      }
      if (typeof erpFieldB06J41_56_60_renderSignInputPrecheckHtml === 'function') {
        return erpFieldB06J41_56_60_renderSignInputPrecheckHtml(ctx);
      }
      return erpFieldB06J40_04_12_renderReadonlyRoute_(ctx);
    }

    if (ctx.route === 'signInputPrecheck' || ctx.route === 'signInputReady') {
      if (typeof erpFieldB06J41_56_60_renderSignInputPrecheckHtml === 'function') {
        return erpFieldB06J41_56_60_renderSignInputPrecheckHtml(ctx);
      }
      if (typeof erpFieldB06J41_51_55_renderSignEntryReadOnlyHtml === 'function') {
        return erpFieldB06J41_51_55_renderSignEntryReadOnlyHtml(ctx);
      }
      return erpFieldB06J40_04_12_renderReadonlyRoute_(ctx);
    }

    if (ctx.route === 'signEntry' || ctx.route === 'signEntryReadOnly' || ctx.route === 'signEntryReadonly') {
      if (typeof erpFieldB06J41_51_55_renderSignEntryReadOnlyHtml === 'function') {
        return erpFieldB06J41_51_55_renderSignEntryReadOnlyHtml(ctx);
      }
      if (typeof erpFieldB06J41_46_50_renderSignUrlVerifyHtml === 'function') {
        return erpFieldB06J41_46_50_renderSignUrlVerifyHtml(ctx);
      }
      return erpFieldB06J40_04_12_renderReadonlyRoute_(ctx);
    }

    if (ctx.route === 'signUrlVerify' || ctx.route === 'signEntryReady') {
      if (typeof erpFieldB06J41_46_50_renderSignUrlVerifyHtml === 'function') {
        return erpFieldB06J41_46_50_renderSignUrlVerifyHtml(ctx);
      }
      if (typeof erpFieldB06J41_41_45_renderSignUrlSaveHtml === 'function') {
        return erpFieldB06J41_41_45_renderSignUrlSaveHtml(ctx);
      }
      return erpFieldB06J40_04_12_renderReadonlyRoute_(ctx);
    }

    if (ctx.route === 'signUrlSaveNow') {
      return erpFieldB06J40_04_12_renderBlocked_(ctx, ['FIELD V37 차단: SIGN URL 저장 실제 실행 금지', '허용 route: signUrlPrecheck / signUrlVerify / signUrlSave(미확정 화면)']);
    }

    if (ctx.route === 'signUrlSave' || ctx.route === 'signUrlReady') {
      if (typeof erpFieldB06J41_41_45_renderSignUrlSaveHtml === 'function') {
        return erpFieldB06J41_41_45_renderSignUrlSaveHtml(ctx);
      }
      if (typeof erpFieldB06J41_37_40_renderSignUrlPrecheckHtml === 'function') {
        return erpFieldB06J41_37_40_renderSignUrlPrecheckHtml(ctx);
      }
      return erpFieldB06J40_04_12_renderReadonlyRoute_(ctx);
    }

    if (ctx.route === 'signUrlPrecheck' || ctx.route === 'signUrlPreview' || ctx.route === 'signQrPrecheck') {
      if (typeof erpFieldB06J41_37_40_renderSignUrlPrecheckHtml === 'function') {
        return erpFieldB06J41_37_40_renderSignUrlPrecheckHtml(ctx);
      }
      if (typeof erpFieldB06J41_33_36_renderSignDocumentLookupHtml === 'function') {
        return erpFieldB06J41_33_36_renderSignDocumentLookupHtml(ctx);
      }
      return erpFieldB06J40_04_12_renderReadonlyRoute_(ctx);
    }

    if (ctx.route === 'signDocumentDetail' || ctx.route === 'signDocumentRecent' || ctx.route === 'signDocumentLookup') {
      if (typeof erpFieldB06J41_33_36_renderSignDocumentLookupHtml === 'function') {
        return erpFieldB06J41_33_36_renderSignDocumentLookupHtml(ctx);
      }
      if (typeof erpFieldB06J41_28_32_renderSignDocumentDraftCreateHtml === 'function') {
        return erpFieldB06J41_28_32_renderSignDocumentDraftCreateHtml(ctx);
      }
      return erpFieldB06J40_04_12_renderReadonlyRoute_(ctx);
    }

    if (ctx.route === 'signDocumentCreate' || ctx.route === 'signDocumentDraft' || ctx.route === 'signDocumentCreateResult') {
      if (typeof erpFieldB06J41_18_22_renderSignDocumentPrecheckHtml === 'function') {
        return erpFieldB06J41_18_22_renderSignDocumentPrecheckHtml(ctx);
      }
      return erpFieldB06J40_04_12_renderBlocked_(ctx, ['FIELD V37 차단: SIGN documentId/DRAFT 문서 실제 생성 금지', '허용 route: signDocumentPrecheck / signDocumentLookup']);
    }

    if (ctx.route === 'signSchema' || ctx.route === 'signDocumentSchema' || ctx.route === 'signDocumentSchemaFix') {
      if (typeof erpFieldB06J41_23_27_renderSignDocumentSchemaHtml === 'function') {
        return erpFieldB06J41_23_27_renderSignDocumentSchemaHtml(ctx);
      }
      return erpFieldB06J40_04_12_renderReadonlyRoute_(ctx);
    }

    if (ctx.route === 'signPrecheck' || ctx.route === 'signDocumentPrecheck' || ctx.route === 'signLinkPrecheck') {
      if (typeof erpFieldB06J41_18_22_renderSignDocumentPrecheckHtml === 'function') {
        return erpFieldB06J41_18_22_renderSignDocumentPrecheckHtml(ctx);
      }
      return erpFieldB06J40_04_12_renderReadonlyRoute_(ctx);
    }

    if (ctx.route === 'contractRecent' || ctx.route === 'contractDetail') {
      if (typeof erpFieldB06J41_15_17_renderContractLookupHtml === 'function') {
        return erpFieldB06J41_15_17_renderContractLookupHtml(ctx);
      }
      if (typeof erpFieldB06J41_10_14_renderContractDraftCreateHtml === 'function') {
        return erpFieldB06J41_10_14_renderContractDraftCreateHtml(ctx);
      }
      return erpFieldB06J40_04_12_renderReadonlyRoute_(ctx);
    }

    if (ctx.route === 'contractCreate' || ctx.route === 'contractDraft') {
      if (typeof erpFieldB06J41_01_05_renderContractSignPrecheckHtml === 'function') {
        return erpFieldB06J41_01_05_renderContractSignPrecheckHtml(ctx);
      }
      return erpFieldB06J40_04_12_renderBlocked_(ctx, ['FIELD V37 차단: 계약 DRAFT 실제 생성 금지', '허용 route: contractPrecheck / contractDetail / contractRecent']);
    }

    if (ctx.route === 'contractPrecheck' || (ctx.route === 'contract' && ctx.saleId)) {
      if (typeof erpFieldB06J41_01_05_renderContractSignPrecheckHtml === 'function') {
        return erpFieldB06J41_01_05_renderContractSignPrecheckHtml(ctx);
      }
      return erpFieldB06J40_04_12_renderReadonlyRoute_(ctx);
    }

    if (ctx.route === 'salesSchema') {
      if (typeof erpFieldB06J40_21_24_renderSalesSchemaFixHtml === 'function') {
        return erpFieldB06J40_21_24_renderSalesSchemaFixHtml(ctx);
      }
      return erpFieldB06J40_04_12_renderSalesFullPrecheckHtml(ctx);
    }

    if (ctx.route === 'salesPrep') {
      if (typeof erpFieldB06J40_16_20_renderSalesDraftPrepHtml === 'function') {
        return erpFieldB06J40_16_20_renderSalesDraftPrepHtml(ctx);
      }
      return erpFieldB06J40_04_12_renderSalesFullPrecheckHtml(ctx);
    }

    return erpFieldB06J40_04_12_renderReadonlyRoute_(ctx);
  } catch (err) {
    var fallback = { roleCode: 'UNKNOWN', vendorId: '', eventId: '', route: 'error', keyword: '', userEmail: '' };
    return erpFieldB06J40_04_12_renderBlocked_(fallback, ['FIELD 화면 렌더 실패: ' + (err && err.message ? err.message : err)]);
  }
}

function erpFieldB06J40_04_12_normalizeContext_(p) {
  return {
    roleCode: String(p.roleCode || 'VIEWER').trim(),
    vendorId: String(p.vendorId || '').trim(),
    eventId: String(p.eventId || '').trim(),
    route: String(p.route || p.page || 'entry').trim(),
    keyword: String(p.keyword || '').trim(),
    customerId: String(p.customerId || '').trim(),
    saleId: String(p.saleId || '').trim(),
    userEmail: String(p.userEmail || '').trim(),
    productName: String(p.productName || '').trim(),
    quantity: String(p.quantity || '').trim(),
    unitPrice: String(p.unitPrice || '').trim(),
    totalAmount: String(p.totalAmount || '').trim(),
    depositAmount: String(p.depositAmount || '').trim(),
    balanceAmount: String(p.balanceAmount || '').trim(),
    discountAmount: String(p.discountAmount || '').trim(),
    voucherAmount: String(p.voucherAmount || '').trim(),
    benefitAmount: String(p.benefitAmount || '').trim(),
    paymentStructure: String(p.paymentStructure || '').trim(),
    paymentMethod: String(p.paymentMethod || '').trim(),
    installDueDate: String(p.installDueDate || '').trim(),
    memberType: String(p.memberType || '').trim(),
    cardPaymentIds: String(p.cardPaymentIds || '').trim(),
    saveConfirm: String(p.saveConfirm || p.confirmSave || p.saveExecute || '').trim(),
    draftSaveOpen: String(p.draftSaveOpen || p.draftOpen || '').trim(),
    saveExecute: String(p.saveExecute || '').trim(),
    contractConfirm: String(p.contractConfirm || '').trim(),
    documentConfirm: String(p.documentConfirm || p.signDocumentConfirm || '').trim(),
    confirmSave: String(p.confirmSave || '').trim(),
    action: String(p.action || '').trim(),
    contractId: String(p.contractId || '').trim(),
    documentId: String(p.documentId || '').trim(),
    productId: String(p.productId || '').trim(),
    productPolicyId: String(p.productPolicyId || '').trim(),
    settlementPolicyId: String(p.settlementPolicyId || '').trim(),
    draftCheck: String(p.draftCheck || '').trim(),
    dryRunPreset: String(p.dryRunPreset || p.testPreset || '').trim(),
    testPreset: String(p.testPreset || p.dryRunPreset || '').trim(),
    scopeType: 'VENDOR_BRANCH_USER_GROUP',
    hqFullAccess: false
  };
}

function erpFieldB06J40_04_12_guardContext_(ctx) {
  var fatal = [];
  var allowedRoles = {
    VENDOR_OWNER: true,
    VENDOR_MANAGER: true,
    STAFF_SALES: true,
    STAFF_INSTALL: true,
    STAFF_AS: true,
    VIEWER: true
  };
  var allowedRoutes = {
    entry: true,
    customerLookup: true,
    sales: true,
    salesSchema: true,
    salesPrep: true,
    salesSave: true,
    salesRecent: true,
    salesDetail: true,
    signStatusLink: true,
    signStatus: true,
    salesSignStatus: true,
    contractSignStatus: true,
    contractPrecheck: true,
    contractCreate: true,
    contractDraft: true,
    contractRecent: true,
    contractDetail: true,
    signPrecheck: true,
    signDocumentPrecheck: true,
    signLinkPrecheck: true,
    signSchema: true,
    signDocumentSchema: true,
    signDocumentSchemaFix: true,
    signDocumentCreate: true,
    signDocumentDraft: true,
    signDocumentCreateResult: true,
    signDocumentDetail: true,
    signDocumentRecent: true,
    signDocumentLookup: true,
    signUrlPrecheck: true,
    signUrlPreview: true,
    signQrPrecheck: true,
    signUrlSave: true,
    signUrlSaveNow: true,
    signUrlReady: true,
    signUrlVerify: true,
    signEntryReady: true,
    signEntry: true,
    signEntryReadOnly: true,
    signEntryReadonly: true,
    signInputPrecheck: true,
    signInputReady: true,
    signaturePadPreview: true,
    signPadPreview: true,
    signaturePadActivePreview: true,
    signatureSaveExecute: true,
    signatureSave: true,
    signSaveExecute: true,
    signatureSaveHandoff: true,
    signatureHandoffToSign: true,
    signatureSaveConfirmPrep: true,
    signatureConfirmPrep: true,
    signSaveConfirmPrep: true,
    signatureSchemaFix: true,
    signatureSaveSchemaFix: true,
    signatureHeaderFix: true,
    signatureSaveDryRun: true,
    signSaveDryRun: true,
    signatureSchemaDryRun: true,
    signatureSavePrecheck: true,
    signSavePrecheck: true,
    signatureDataPrecheck: true,
    contract: true,
    install: true,
    as: true,
    myStatus: true,
    settlementView: true,
    staffManagement: true
  };
  if (!ctx.vendorId) fatal.push('FIELD 진입 차단: vendorId 누락');
  if (!allowedRoles[ctx.roleCode]) fatal.push('FIELD 진입 차단: 미허용 roleCode=' + ctx.roleCode);
  if (!allowedRoutes[ctx.route]) fatal.push('FIELD 진입 차단: 미허용 route=' + ctx.route);
  return { ok: fatal.length === 0, fatal: fatal };
}


/**
 * Compatibility guard for B06J39 customer stable module.
 * B06J39 customer lookup was split from the route file in B06J40,
 * so keep this alias to prevent customerLookup render failure.
 */
function erpFieldB06J39_04_09_guardContext_(ctx) {
  ctx = ctx || {};
  var normalized = erpFieldB06J40_04_12_normalizeContext_(ctx);
  normalized.roleCode = ctx.roleCode || normalized.roleCode;
  normalized.vendorId = ctx.vendorId || normalized.vendorId;
  normalized.eventId = ctx.eventId || normalized.eventId;
  normalized.route = ctx.route || normalized.route;
  return erpFieldB06J40_04_12_guardContext_(normalized);
}

function erpFieldB06J40_04_12_renderBlocked_(ctx, fatal) {
  var html = '<!doctype html><html><head><meta charset="utf-8"><base target="_top">' +
    '<style>body{font-family:Arial,"Noto Sans KR",sans-serif;background:#f6f7fb;margin:0;padding:40px;color:#111827}.box{max-width:900px;margin:0 auto;background:#fff;border:1px solid #e5e7eb;border-radius:18px;padding:28px;box-shadow:0 16px 40px rgba(0,0,0,.08)}.badge{display:inline-block;background:#fee2e2;color:#991b1b;border-radius:999px;padding:6px 10px;font-weight:800}.err{white-space:pre-wrap;background:#fff5f5;border:1px solid #fecaca;border-radius:12px;padding:14px;color:#991b1b}.kv{display:grid;grid-template-columns:120px 1fr;gap:8px;margin-top:16px}.k{color:#6b7280}.v{font-weight:700}</style></head><body><div class="box">' +
    '<span class="badge">BLOCKED</span><h1>FIELD 진입 차단</h1><p>vendorId / roleCode / route 기준 검증을 통과하지 못했습니다.</p>' +
    '<div class="err">' + erpFieldB06J40_04_12_escape_(JSON.stringify(fatal || [], null, 2)) + '</div>' +
    '<div class="kv"><div class="k">roleCode</div><div class="v">' + erpFieldB06J40_04_12_escape_(ctx.roleCode) + '</div>' +
    '<div class="k">vendorId</div><div class="v">' + erpFieldB06J40_04_12_escape_(ctx.vendorId) + '</div>' +
    '<div class="k">eventId</div><div class="v">' + erpFieldB06J40_04_12_escape_(ctx.eventId) + '</div>' +
    '<div class="k">route</div><div class="v">' + erpFieldB06J40_04_12_escape_(ctx.route) + '</div></div>' +
    '<p>업체는 별도 앱이 아니라 ERP 내부 지점형 사용자 그룹입니다. 업체별 독립 DB로 분리하지 않습니다.</p>' +
    '</div></body></html>';
  return HtmlService.createHtmlOutput(html).setTitle('FIELD 진입 차단').setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL);
}

function erpFieldB06J40_04_12_renderReadonlyRoute_(ctx) {
  var routeTitleMap = {
    entry: 'FIELD 진입', sales: '판매', contract: '계약', install: '설치', as: 'A/S',
    myStatus: '내 처리현황', settlementView: '정산 조회', staffManagement: '직원 관리'
  };
  var title = routeTitleMap[ctx.route] || ctx.route;
  var html = '<!doctype html><html><head><meta charset="utf-8"><base target="_top">' +
    '<style>body{font-family:Arial,"Noto Sans KR",sans-serif;background:#f6f7fb;margin:0;padding:28px;color:#111827}.wrap{max-width:1100px;margin:0 auto}.hero{background:#111827;color:white;border-radius:18px;padding:28px}.badge{display:inline-block;background:#1f2937;border:1px solid #374151;border-radius:999px;padding:6px 10px;font-size:12px;font-weight:800}.grid{display:grid;grid-template-columns:repeat(4,1fr);gap:14px;margin-top:18px}.card{background:white;border:1px solid #e5e7eb;border-radius:16px;padding:18px}.muted{color:#6b7280}.btn{border:0;border-radius:12px;background:#e5e7eb;color:#6b7280;padding:12px 16px;font-weight:800}</style></head><body><div class="wrap">' +
    '<section class="hero"><span class="badge">B06J40 SAFE : READ ONLY</span><h1>' + erpFieldB06J40_04_12_escape_(title) + '</h1><p>현재 route=' + erpFieldB06J40_04_12_escape_(ctx.route) + ' 화면은 READ ONLY 자리입니다.</p></section>' +
    '<section class="grid"><div class="card"><div class="muted">역할</div><h3>' + erpFieldB06J40_04_12_escape_(ctx.roleCode) + '</h3></div><div class="card"><div class="muted">vendorId</div><h3>' + erpFieldB06J40_04_12_escape_(ctx.vendorId) + '</h3></div><div class="card"><div class="muted">eventId</div><h3>' + erpFieldB06J40_04_12_escape_(ctx.eventId) + '</h3></div><div class="card"><div class="muted">저장상태</div><h3>차단</h3></div></section>' +
    '<section class="card" style="margin-top:18px"><h2>안내</h2><p>저장, 수정, 삭제, 정산, 외부연동은 실행되지 않습니다.</p><button class="btn" disabled>실행 차단</button></section>' +
    '</div></body></html>';
  return HtmlService.createHtmlOutput(html).setTitle('FIELD READ ONLY').setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL);
}

function erpFieldB06J40_04_12_escape_(v) {
  return String(v == null ? '' : v).replace(/[&<>\"]/g, function (s) {
    return ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' })[s];
  });
}


/* ===== View.js ===== */
/**
 * FEELHAUS ERP_FIELD B06J38-04
 * FIELD screen-menu data binding safe build.
 *
 * 목적:
 * - B06J38-03 메뉴 부트스트랩 결과를 FIELD 진입 화면 표시용 ViewModel로 연결한다.
 * - roleCode / vendorId / eventId 기준 화면 컨텍스트와 메뉴 표시 데이터를 구성한다.
 * - 버튼은 계속 비활성화한다.
 * - 저장/수정/정산/외부연동/시트쓰기 없음.
 *
 * 주의:
 * - 업체는 독립 앱이 아니라 ERP 내부 지점형 사용자 그룹이다.
 * - 모든 데이터 범위는 vendorId / eventId / roleCode 기준으로 제한한다.
 */

var ERP_B06J38_04_BUILD = 'ERP_B06J38_04_FIELD_SCREEN_MENU_BIND_SAFE';
var ERP_B06J38_04_MODULE = 'ERP_FIELD';
var ERP_B06J38_04_SETUP_DB_ID = '17VMSpgSZCvIrUlgcw8yCNcnl8WQWo2IcRf5tDCcuJGM';
var ERP_B06J38_04_CONFIG_SHEET_NAME = 'SystemConfig';

function erpB06J38_04_autoRunSafe() {
  var result = {
    ok: true,
    build: ERP_B06J38_04_BUILD,
    moduleCode: ERP_B06J38_04_MODULE,
    checkedAt: new Date().toISOString(),
    fatal: [],
    warnings: [],
    checks: {}
  };

  result.checks.config = erpFieldB06J38_04_checkConfig_();
  result.checks.sampleVendorOwner = erpFieldB06J38_04_getScreenMenuData({
    roleCode: 'VENDOR_OWNER',
    vendorId: 'VENDOR-SAMPLE',
    eventId: 'EVT-SAMPLE',
    userEmail: 'vendor.owner@example.com'
  });
  result.checks.sampleVendorManager = erpFieldB06J38_04_getScreenMenuData({
    roleCode: 'VENDOR_MANAGER',
    vendorId: 'VENDOR-SAMPLE',
    eventId: 'EVT-SAMPLE',
    userEmail: 'vendor.manager@example.com'
  });
  result.checks.sampleStaffSales = erpFieldB06J38_04_getScreenMenuData({
    roleCode: 'STAFF_SALES',
    vendorId: 'VENDOR-SAMPLE',
    eventId: 'EVT-SAMPLE',
    userEmail: 'staff.sales@example.com'
  });
  result.checks.sampleStaffInstall = erpFieldB06J38_04_getScreenMenuData({
    roleCode: 'STAFF_INSTALL',
    vendorId: 'VENDOR-SAMPLE',
    eventId: 'EVT-SAMPLE',
    userEmail: 'staff.install@example.com'
  });
  result.checks.sampleStaffAs = erpFieldB06J38_04_getScreenMenuData({
    roleCode: 'STAFF_AS',
    vendorId: 'VENDOR-SAMPLE',
    eventId: 'EVT-SAMPLE',
    userEmail: 'staff.as@example.com'
  });
  result.checks.sampleViewer = erpFieldB06J38_04_getScreenMenuData({
    roleCode: 'VIEWER',
    vendorId: 'VENDOR-SAMPLE',
    eventId: 'EVT-SAMPLE',
    userEmail: 'viewer@example.com'
  });
  result.checks.missingVendorBlocked = erpFieldB06J38_04_getScreenMenuData({
    roleCode: 'VENDOR_MANAGER',
    vendorId: '',
    eventId: 'EVT-SAMPLE',
    userEmail: 'missing.vendor@example.com'
  });
  result.checks.unknownRoleBlocked = erpFieldB06J38_04_getScreenMenuData({
    roleCode: 'UNKNOWN_ROLE',
    vendorId: 'VENDOR-SAMPLE',
    eventId: 'EVT-SAMPLE',
    userEmail: 'unknown.role@example.com'
  });

  var fatal = [];
  Object.keys(result.checks).forEach(function (key) {
    var check = result.checks[key];
    if (!check) {
      fatal.push(key + ' 결과 없음');
      return;
    }
    if (key === 'missingVendorBlocked' || key === 'unknownRoleBlocked') {
      if (check.ok !== false) fatal.push(key + ' 차단 실패');
      return;
    }
    if (check.ok !== true) {
      fatal = fatal.concat(check.fatal || [key + ' 실패']);
    }
  });

  result.fatal = fatal;
  result.ok = fatal.length === 0;

  Logger.log('======================================================');
  Logger.log(JSON.stringify(result, null, 2));
  Logger.log('======================================================');
  return result;
}

function erpFieldB06J38_04_renderMenuConnectedHtml(context) {
  var data = erpFieldB06J38_04_getScreenMenuData(context || {});
  if (!data.ok) {
    return erpFieldB06J38_04_renderBlockedHtml_(data);
  }

  var html;
  try {
    var template = HtmlService.createTemplateFromFile('P_Main');
    template.viewModelJson = JSON.stringify(data.viewModel || {}, null, 2);
    html = template.evaluate()
      .setTitle('필하우스 ERP FIELD')
      .setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL);
    return html;
  } catch (err) {
    return erpFieldB06J38_04_renderInlineHtml_(data);
  }
}

function erpFieldB06J38_04_getScreenMenuData(context) {
  var fatal = [];
  var warnings = [];
  var ctx = erpFieldB06J38_04_normalizeContext_(context || {});
  var rolePolicy = erpFieldB06J38_04_rolePolicy_();

  if (!ctx.vendorId) fatal.push('FIELD 진입 차단: vendorId 누락');
  if (!rolePolicy[ctx.roleCode]) fatal.push('FIELD 진입 차단: 허용되지 않은 roleCode');

  if (fatal.length) {
    return {
      ok: false,
      build: ERP_B06J38_04_BUILD,
      moduleCode: ERP_B06J38_04_MODULE,
      checkedAt: new Date().toISOString(),
      fatal: fatal,
      warnings: warnings,
      context: ctx,
      safety: erpFieldB06J38_04_safety_()
    };
  }

  var bootstrap = erpFieldB06J38_04_getBootstrapCompat_(ctx);
  if (!bootstrap || bootstrap.ok !== true) {
    warnings.push('B06J38-03 부트스트랩 함수 미탑재 또는 실패: B06J38-04 내부 안전 메뉴정책으로 대체');
    bootstrap = erpFieldB06J38_04_buildLocalBootstrap_(ctx);
  }

  var visibleMenus = erpFieldB06J38_04_normalizeMenus_(bootstrap.visibleMenus || []);
  var quickActions = erpFieldB06J38_04_buildQuickActions_(visibleMenus);
  var viewModel = {
    build: ERP_B06J38_04_BUILD,
    moduleCode: ERP_B06J38_04_MODULE,
    pageTitle: 'ERP FIELD 현장/업체/직원 진입',
    pageSubtitle: '현재 단계는 메뉴 표시 연결만 수행하며 업무 실행은 차단됩니다.',
    roleName: rolePolicy[ctx.roleCode].roleName,
    context: ctx,
    summaryCards: erpFieldB06J38_04_buildSummaryCards_(visibleMenus, quickActions),
    quickActions: quickActions,
    visibleMenus: visibleMenus,
    hiddenMenus: bootstrap.hiddenMenus || [],
    notices: erpFieldB06J38_04_notices_(ctx),
    footer: {
      company: '(주)필하우스',
      copyright: '© 2026 FEELHAUS. All rights reserved.',
      developer: '개발담당: 이용필',
      operator: '최고운영자: 이용필'
    },
    safety: erpFieldB06J38_04_safety_()
  };

  return {
    ok: true,
    build: ERP_B06J38_04_BUILD,
    moduleCode: ERP_B06J38_04_MODULE,
    checkedAt: new Date().toISOString(),
    fatal: [],
    warnings: warnings.concat(bootstrap.warnings || []),
    context: ctx,
    bootstrapBuild: bootstrap.build || 'LOCAL_FALLBACK',
    viewModel: viewModel,
    safety: erpFieldB06J38_04_safety_()
  };
}

function erpFieldB06J38_04_getBootstrapCompat_(ctx) {
  var candidates = [
    'erpFieldB06J38_03_getMenuBootstrap',
    'erpB06J38_03_getMenuBootstrap',
    'erpField_getMenuBootstrapB06J38_03',
    'erpFieldB06J38_03_buildMenuBootstrap'
  ];
  for (var i = 0; i < candidates.length; i++) {
    var fnName = candidates[i];
    try {
      if (typeof this[fnName] === 'function') {
        return this[fnName](ctx);
      }
    } catch (err) {
      return { ok: false, fatal: [String(err && err.message ? err.message : err)] };
    }
  }
  return null;
}

function erpFieldB06J38_04_buildLocalBootstrap_(ctx) {
  var rolePolicy = erpFieldB06J38_04_rolePolicy_()[ctx.roleCode];
  var allMenus = erpFieldB06J38_04_menuCatalog_();
  var allowed = rolePolicy.menuCodes;
  var visibleMenus = [];
  var hiddenMenus = [];

  allMenus.forEach(function (menu) {
    var copy = erpFieldB06J38_04_clone_(menu);
    copy.executionBlocked = true;
    copy.buttonEnabled = false;
    copy.status = 'READY_PLACEHOLDER';
    if (allowed.indexOf(menu.menuCode) >= 0) {
      visibleMenus.push(copy);
    } else {
      hiddenMenus.push({ menuCode: menu.menuCode, title: menu.title, reason: 'roleCode 기준 숨김' });
    }
  });

  visibleMenus.sort(function (a, b) { return a.sortOrder - b.sortOrder; });

  return {
    ok: true,
    build: ERP_B06J38_04_BUILD + '_LOCAL_BOOTSTRAP',
    moduleCode: ERP_B06J38_04_MODULE,
    context: ctx,
    visibleMenus: visibleMenus,
    hiddenMenus: hiddenMenus,
    warnings: []
  };
}

function erpFieldB06J38_04_normalizeContext_(context) {
  return {
    roleCode: String(context.roleCode || 'VIEWER').trim().toUpperCase(),
    vendorId: String(context.vendorId || '').trim(),
    eventId: String(context.eventId || '').trim(),
    userEmail: String(context.userEmail || erpFieldB06J38_04_getUserEmail_()).trim(),
    scopeType: 'VENDOR_BRANCH_USER_GROUP',
    dataPolicy: 'vendorId / eventId / roleCode 기준 제한',
    hqFullAccess: false
  };
}

function erpFieldB06J38_04_rolePolicy_() {
  return {
    VENDOR_OWNER: {
      roleName: '업체대표',
      menuCodes: ['CUSTOMER_LOOKUP', 'SALES', 'CONTRACT', 'INSTALL', 'AS', 'MY_STATUS', 'SETTLEMENT_VIEW', 'STAFF_MANAGEMENT']
    },
    VENDOR_MANAGER: {
      roleName: '업체관리자',
      menuCodes: ['CUSTOMER_LOOKUP', 'SALES', 'CONTRACT', 'INSTALL', 'AS', 'MY_STATUS', 'SETTLEMENT_VIEW']
    },
    STAFF_SALES: {
      roleName: '영업직원',
      menuCodes: ['CUSTOMER_LOOKUP', 'SALES', 'CONTRACT', 'MY_STATUS']
    },
    STAFF_INSTALL: {
      roleName: '설치담당',
      menuCodes: ['CUSTOMER_LOOKUP', 'INSTALL', 'MY_STATUS']
    },
    STAFF_AS: {
      roleName: 'A/S담당',
      menuCodes: ['CUSTOMER_LOOKUP', 'AS', 'MY_STATUS']
    },
    VIEWER: {
      roleName: '조회전용',
      menuCodes: ['CUSTOMER_LOOKUP', 'MY_STATUS']
    }
  };
}

function erpFieldB06J38_04_menuCatalog_() {
  return [
    { menuCode: 'CUSTOMER_LOOKUP', title: '고객 조회', desc: 'eventId / vendorId 기준 고객 조회 화면 준비', route: 'customerLookup', icon: 'search', sortOrder: 10 },
    { menuCode: 'SALES', title: '판매', desc: '판매 등록 화면 자리 준비. 현재 실행 차단', route: 'sales', icon: 'receipt', sortOrder: 20 },
    { menuCode: 'CONTRACT', title: '계약', desc: '계약/서명 연결 화면 자리 준비. 현재 실행 차단', route: 'contract', icon: 'document', sortOrder: 30 },
    { menuCode: 'INSTALL', title: '설치', desc: '설치 일정/완료 화면 자리 준비. 현재 실행 차단', route: 'install', icon: 'tools', sortOrder: 40 },
    { menuCode: 'AS', title: 'A/S', desc: 'A/S 접수/처리 화면 자리 준비. 현재 실행 차단', route: 'as', icon: 'support', sortOrder: 50 },
    { menuCode: 'MY_STATUS', title: '내 처리현황', desc: '내 업무 처리 현황 화면 자리 준비', route: 'myStatus', icon: 'checklist', sortOrder: 60 },
    { menuCode: 'SETTLEMENT_VIEW', title: '정산 조회', desc: '업체 정산 조회 화면 자리 준비. 수정/지급 실행 차단', route: 'settlementView', icon: 'money', sortOrder: 70 },
    { menuCode: 'STAFF_MANAGEMENT', title: '직원 관리', desc: '업체 직원/권한 관리 화면 자리 준비. 민감권한은 본사 승인 필요', route: 'staffManagement', icon: 'users', sortOrder: 80 }
  ];
}

function erpFieldB06J38_04_normalizeMenus_(menus) {
  return menus.map(function (menu) {
    return {
      menuCode: String(menu.menuCode || ''),
      title: String(menu.title || ''),
      desc: String(menu.desc || ''),
      route: String(menu.route || ''),
      icon: String(menu.icon || 'menu'),
      sortOrder: Number(menu.sortOrder || 999),
      executionBlocked: true,
      buttonEnabled: false,
      status: String(menu.status || 'READY_PLACEHOLDER')
    };
  }).sort(function (a, b) { return a.sortOrder - b.sortOrder; });
}

function erpFieldB06J38_04_buildQuickActions_(visibleMenus) {
  return visibleMenus.map(function (menu) {
    var titleMap = {
      CUSTOMER_LOOKUP: '고객 조회',
      SALES: '판매 등록',
      CONTRACT: '계약 조회',
      INSTALL: '설치 확인',
      AS: 'A/S 확인',
      MY_STATUS: '내 처리현황',
      SETTLEMENT_VIEW: '정산 조회',
      STAFF_MANAGEMENT: '직원 관리'
    };
    return {
      menuCode: menu.menuCode,
      title: titleMap[menu.menuCode] || menu.title,
      route: menu.route,
      enabled: false,
      disabledReason: 'B06J38 FIELD 화면-메뉴 연결 단계: 업무 실행 차단'
    };
  });
}

function erpFieldB06J38_04_buildSummaryCards_(visibleMenus, quickActions) {
  return [
    { label: '표시 메뉴', value: String(visibleMenus.length), help: 'roleCode 기준 표시' },
    { label: '빠른 실행', value: String(quickActions.length), help: '현재 비활성화' },
    { label: '실행 차단', value: 'ON', help: '저장/정산/외부연동 차단' },
    { label: '데이터 범위', value: 'vendorId', help: '업체 지점형 사용자 그룹' }
  ];
}

function erpFieldB06J38_04_notices_(ctx) {
  return [
    '현재 화면은 B06J38 FIELD 최소 화면 단계입니다.',
    '모든 버튼은 비활성화되어 있으며 저장/수정/정산은 실행되지 않습니다.',
    '데이터 범위는 vendorId / eventId / roleCode 기준으로 제한됩니다.',
    '업체는 별도 앱이 아니라 ERP 안의 지점형 사용자 그룹입니다.'
  ];
}

function erpFieldB06J38_04_safety_() {
  return {
    screenMenuBindingOnly: true,
    uiDisplayOnly: true,
    buttonsDisabled: true,
    noBusinessStateMutation: true,
    noSheetWrite: true,
    paymentExecutionBlocked: true,
    settlementExecutionBlocked: true,
    externalIntegrationBlocked: true,
    vendorIndependentDbBlocked: true,
    vendorAsBranchUserGroup: true
  };
}

function erpFieldB06J38_04_checkConfig_() {
  var fatal = [];
  var warnings = [];
  var data = {
    setupDbId: ERP_B06J38_04_SETUP_DB_ID,
    setupDbName: '',
    configSheetName: ERP_B06J38_04_CONFIG_SHEET_NAME,
    configCount: 0,
    masterId: '',
    masterName: ''
  };

  try {
    var ss = SpreadsheetApp.openById(ERP_B06J38_04_SETUP_DB_ID);
    data.setupDbName = ss.getName();
    var sh = ss.getSheetByName(ERP_B06J38_04_CONFIG_SHEET_NAME);
    if (!sh) {
      fatal.push('SystemConfig 시트 없음');
    } else {
      var values = sh.getDataRange().getValues();
      data.configCount = Math.max(values.length - 1, 0);
      var header = values.length ? values[0].map(function (v) { return String(v || '').trim(); }) : [];
      var keyIdx = erpFieldB06J38_04_findHeaderIndex_(header, ['configKey', 'key', 'name']);
      var valIdx = erpFieldB06J38_04_findHeaderIndex_(header, ['configValue', 'value']);
      if (keyIdx >= 0 && valIdx >= 0) {
        for (var i = 1; i < values.length; i++) {
          var key = String(values[i][keyIdx] || '').trim();
          var val = String(values[i][valIdx] || '').trim();
          if (key === 'MASTER_DB_ID' || key === 'FEELHAUS_DB_MASTER_ID' || key === 'MASTER_SPREADSHEET_ID') data.masterId = val;
          if (key === 'MASTER_DB_NAME' || key === 'FEELHAUS_DB_MASTER_NAME') data.masterName = val;
        }
      } else {
        warnings.push('SystemConfig 헤더명이 표준과 다름: configKey/configValue 확인 필요');
      }
    }
  } catch (err) {
    fatal.push('SystemConfig 읽기 실패: ' + String(err && err.message ? err.message : err));
  }

  return {
    ok: fatal.length === 0,
    fatal: fatal,
    warnings: warnings,
    setupDbId: data.setupDbId,
    setupDbName: data.setupDbName,
    configSheetName: data.configSheetName,
    configCount: data.configCount,
    masterId: data.masterId,
    masterName: data.masterName
  };
}

function erpFieldB06J38_04_renderInlineHtml_(data) {
  var html = '<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">' +
    '<title>필하우스 ERP FIELD</title></head><body>' +
    '<pre style="white-space:pre-wrap;font-family:monospace">' +
    erpFieldB06J38_04_escapeHtml_(JSON.stringify(data.viewModel || data, null, 2)) +
    '</pre></body></html>';
  return HtmlService.createHtmlOutput(html).setTitle('필하우스 ERP FIELD');
}

function erpFieldB06J38_04_renderBlockedHtml_(data) {
  var html = '<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">' +
    '<title>FIELD 진입 차단</title><style>body{font-family:Arial,sans-serif;padding:24px;background:#f8fafc;color:#111827}.box{max-width:760px;margin:auto;background:white;border:1px solid #e5e7eb;border-radius:16px;padding:24px}.fatal{color:#b91c1c;font-weight:700}</style></head><body><div class="box">' +
    '<h2>FIELD 진입 차단</h2><p>vendorId / roleCode 기준 검증을 통과하지 못했습니다.</p>' +
    '<pre class="fatal">' + erpFieldB06J38_04_escapeHtml_(JSON.stringify(data.fatal || [], null, 2)) + '</pre>' +
    '<p>업체는 ERP 내부 지점형 사용자 그룹이며, 업체별 독립 DB로 분리하지 않습니다.</p>' +
    '</div></body></html>';
  return HtmlService.createHtmlOutput(html).setTitle('FIELD 진입 차단');
}

function erpFieldB06J38_04_findHeaderIndex_(header, names) {
  for (var i = 0; i < names.length; i++) {
    var idx = header.indexOf(names[i]);
    if (idx >= 0) return idx;
  }
  return -1;
}

function erpFieldB06J38_04_getUserEmail_() {
  try {
    return Session.getActiveUser().getEmail() || '';
  } catch (err) {
    return '';
  }
}

function erpFieldB06J38_04_clone_(obj) {
  return JSON.parse(JSON.stringify(obj || {}));
}

function erpFieldB06J38_04_escapeHtml_(value) {
  return String(value || '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}


/* ===== Menu.js ===== */
/**
 * FEELHAUS ERP_FIELD B06J38-03
 * Build: ERP_B06J38_03_FIELD_MENU_BOOTSTRAP_SAFE
 * Purpose:
 * - ERP_FIELD 최소 진입 화면의 메뉴 부트스트랩 데이터 생성
 * - roleCode / vendorId / eventId 기준 메뉴 노출 정책 준비
 * - 모든 버튼/업무 실행은 계속 차단
 * - 저장/수정/정산/외부연동 실행 없음
 *
 * Required previous build:
 * - ERP_B06J38_01_FIELD_MIN_ENTRY_SCREEN_SAFE
 * - ERP_B06J38_02_FIELD_DOGET_ROUTING_SAFE
 */

var ERP_B06J38_03_BUILD = 'ERP_B06J38_03_FIELD_MENU_BOOTSTRAP_SAFE';
var ERP_B06J38_03_MODULE = 'ERP_FIELD';
var ERP_B06J38_03_SETUP_DB_ID = '17VMSpgSZCvIrUlgcw8yCNcnl8WQWo2IcRf5tDCcuJGM';
var ERP_B06J38_03_CONFIG_SHEET_NAME = 'SystemConfig';

function erpB06J38_03_autoRunSafe() {
  var result = erpB06J38_03_selfTest_();
  Logger.log('======================================================');
  Logger.log(JSON.stringify(result, null, 2));
  Logger.log('======================================================');
  return result;
}

function erpFieldB06J38_03_getMenuBootstrap(params) {
  params = params || {};
  var roleCode = String(params.roleCode || '').trim();
  var vendorId = String(params.vendorId || '').trim();
  var eventId = String(params.eventId || '').trim();
  var userEmail = String(params.userEmail || erpB06J38_03_getActiveEmail_() || '').trim();

  var safety = erpB06J38_03_safety_();
  var fatal = [];
  var warnings = [];

  if (!roleCode) fatal.push('FIELD 메뉴 부트스트랩 차단: roleCode 누락');
  if (!vendorId) fatal.push('FIELD 메뉴 부트스트랩 차단: vendorId 누락');
  if (!eventId) warnings.push('eventId 누락: 행사 미선택 안내 모드로만 진입');

  var policy = erpB06J38_03_getRoleMenuPolicy_(roleCode);
  if (!policy.ok) {
    fatal.push('FIELD 메뉴 부트스트랩 차단: 허용되지 않은 roleCode - ' + roleCode);
  }

  if (fatal.length) {
    return {
      ok: false,
      build: ERP_B06J38_03_BUILD,
      moduleCode: ERP_B06J38_03_MODULE,
      checkedAt: new Date().toISOString(),
      fatal: fatal,
      warnings: warnings,
      context: {
        roleCode: roleCode,
        vendorId: vendorId,
        eventId: eventId,
        userEmail: userEmail,
        scopeType: 'BLOCKED'
      },
      visibleMenus: [],
      hiddenMenus: [],
      safety: safety
    };
  }

  var allMenus = erpB06J38_03_allFieldMenus_();
  var visibleMenus = [];
  var hiddenMenus = [];
  var allowed = policy.allowedMenuCodes;

  for (var i = 0; i < allMenus.length; i++) {
    var menu = allMenus[i];
    var item = erpB06J38_03_copy_(menu);
    item.executionBlocked = true;
    item.buttonEnabled = false;
    item.status = 'READY_PLACEHOLDER';

    if (allowed.indexOf(menu.menuCode) >= 0) {
      visibleMenus.push(item);
    } else {
      hiddenMenus.push({
        menuCode: menu.menuCode,
        title: menu.title,
        reason: 'ROLE_NOT_ALLOWED'
      });
    }
  }

  return {
    ok: true,
    build: ERP_B06J38_03_BUILD,
    moduleCode: ERP_B06J38_03_MODULE,
    checkedAt: new Date().toISOString(),
    fatal: [],
    warnings: warnings,
    context: {
      roleCode: roleCode,
      roleName: policy.roleName,
      vendorId: vendorId,
      eventId: eventId,
      userEmail: userEmail,
      scopeType: 'VENDOR_BRANCH_USER_GROUP',
      dataPolicy: 'vendorId / eventId / roleCode 기준 제한',
      hqFullAccess: false
    },
    quickActions: erpB06J38_03_quickActions_(roleCode),
    visibleMenus: visibleMenus,
    hiddenMenus: hiddenMenus,
    safety: safety
  };
}

function erpFieldB06J38_03_getMenuBootstrapJson(params) {
  return JSON.stringify(erpFieldB06J38_03_getMenuBootstrap(params || {}));
}

function erpB06J38_03_selfTest_() {
  var checkedAt = new Date().toISOString();
  var fatal = [];
  var warnings = [];
  var checks = {};

  checks.config = erpB06J38_03_checkConfig_();
  if (!checks.config.ok) fatal = fatal.concat(checks.config.fatal || []);
  warnings = warnings.concat(checks.config.warnings || []);

  checks.sampleVendorOwner = erpFieldB06J38_03_getMenuBootstrap({
    roleCode: 'VENDOR_OWNER',
    vendorId: 'VENDOR-SAMPLE',
    eventId: 'EVT-SAMPLE',
    userEmail: 'vendor.owner@example.com'
  });

  checks.sampleVendorManager = erpFieldB06J38_03_getMenuBootstrap({
    roleCode: 'VENDOR_MANAGER',
    vendorId: 'VENDOR-SAMPLE',
    eventId: 'EVT-SAMPLE',
    userEmail: 'vendor.manager@example.com'
  });

  checks.sampleStaffSales = erpFieldB06J38_03_getMenuBootstrap({
    roleCode: 'STAFF_SALES',
    vendorId: 'VENDOR-SAMPLE',
    eventId: 'EVT-SAMPLE',
    userEmail: 'sales.staff@example.com'
  });

  checks.sampleStaffInstall = erpFieldB06J38_03_getMenuBootstrap({
    roleCode: 'STAFF_INSTALL',
    vendorId: 'VENDOR-SAMPLE',
    eventId: 'EVT-SAMPLE',
    userEmail: 'install.staff@example.com'
  });

  checks.sampleStaffAs = erpFieldB06J38_03_getMenuBootstrap({
    roleCode: 'STAFF_AS',
    vendorId: 'VENDOR-SAMPLE',
    eventId: 'EVT-SAMPLE',
    userEmail: 'as.staff@example.com'
  });

  checks.sampleViewer = erpFieldB06J38_03_getMenuBootstrap({
    roleCode: 'VIEWER',
    vendorId: 'VENDOR-SAMPLE',
    eventId: 'EVT-SAMPLE',
    userEmail: 'viewer@example.com'
  });

  checks.missingVendorBlocked = erpFieldB06J38_03_getMenuBootstrap({
    roleCode: 'VENDOR_MANAGER',
    eventId: 'EVT-SAMPLE'
  });

  checks.unknownRoleBlocked = erpFieldB06J38_03_getMenuBootstrap({
    roleCode: 'SUPER_ADMIN',
    vendorId: 'VENDOR-SAMPLE',
    eventId: 'EVT-SAMPLE'
  });

  var sampleNames = [
    'sampleVendorOwner',
    'sampleVendorManager',
    'sampleStaffSales',
    'sampleStaffInstall',
    'sampleStaffAs',
    'sampleViewer'
  ];
  for (var i = 0; i < sampleNames.length; i++) {
    var c = checks[sampleNames[i]];
    if (!c || !c.ok) fatal.push(sampleNames[i] + ' 메뉴 부트스트랩 실패');
    if (c && c.visibleMenus && c.visibleMenus.length < 1) fatal.push(sampleNames[i] + ' visibleMenus 없음');
  }

  if (checks.missingVendorBlocked.ok !== false) {
    fatal.push('vendorId 누락 차단 실패');
  }
  if (checks.unknownRoleBlocked.ok !== false) {
    fatal.push('허용되지 않은 roleCode 차단 실패');
  }

  checks.executionSafety = {
    ok: true,
    assertions: {
      menuBootstrapOnly: true,
      buttonsDisabled: true,
      noBusinessStateMutation: true,
      noSheetWrite: true,
      noSettlementExecution: true,
      vendorIndependentDbBlocked: true,
      vendorAsBranchUserGroup: true
    }
  };

  return {
    ok: fatal.length === 0,
    build: ERP_B06J38_03_BUILD,
    moduleCode: ERP_B06J38_03_MODULE,
    checkedAt: checkedAt,
    fatal: fatal,
    warnings: warnings,
    checks: checks,
    safety: erpB06J38_03_safety_()
  };
}

function erpB06J38_03_checkConfig_() {
  var fatal = [];
  var warnings = [];
  var out = {
    ok: false,
    fatal: fatal,
    warnings: warnings,
    setupDbId: ERP_B06J38_03_SETUP_DB_ID,
    setupDbName: '',
    configSheetName: ERP_B06J38_03_CONFIG_SHEET_NAME,
    configCount: 0,
    masterId: '',
    masterName: ''
  };

  try {
    var setup = SpreadsheetApp.openById(ERP_B06J38_03_SETUP_DB_ID);
    out.setupDbName = setup.getName();
    var sheet = setup.getSheetByName(ERP_B06J38_03_CONFIG_SHEET_NAME);
    if (!sheet) {
      fatal.push('SystemConfig 시트 없음');
      return out;
    }

    var values = sheet.getDataRange().getValues();
    out.configCount = Math.max(values.length - 1, 0);
    var map = erpB06J38_03_configMap_(values);
    var masterId = map.FEELHAUS_DB_MASTER_ID || map.MASTER_DB_ID || map.DB_MASTER_ID || '';
    if (!masterId) fatal.push('FEELHAUS_DB_MASTER ID 설정값 없음');
    out.masterId = masterId;

    if (masterId) {
      var master = SpreadsheetApp.openById(masterId);
      out.masterName = master.getName();
      if (out.masterName !== 'FEELHAUS_DB_MASTER') {
        warnings.push('마스터 DB 이름 확인 필요: ' + out.masterName);
      }
    }
  } catch (err) {
    fatal.push('설정/마스터 확인 실패: ' + err.message);
  }

  out.ok = fatal.length === 0;
  return out;
}

function erpB06J38_03_configMap_(values) {
  var map = {};
  if (!values || values.length < 2) return map;
  var headers = values[0].map(function(h) { return String(h || '').trim(); });
  var keyIdx = headers.indexOf('configKey');
  var valueIdx = headers.indexOf('configValue');
  if (keyIdx < 0) keyIdx = headers.indexOf('key');
  if (valueIdx < 0) valueIdx = headers.indexOf('value');
  if (keyIdx < 0) keyIdx = 0;
  if (valueIdx < 0) valueIdx = 1;

  for (var i = 1; i < values.length; i++) {
    var key = String(values[i][keyIdx] || '').trim();
    var value = String(values[i][valueIdx] || '').trim();
    if (key) map[key] = value;
  }
  return map;
}

function erpB06J38_03_getRoleMenuPolicy_(roleCode) {
  var policies = {
    VENDOR_OWNER: {
      roleName: '업체대표',
      allowedMenuCodes: ['CUSTOMER_LOOKUP', 'SALES', 'CONTRACT', 'INSTALL', 'AS', 'MY_STATUS', 'SETTLEMENT_VIEW', 'STAFF_MANAGEMENT']
    },
    VENDOR_MANAGER: {
      roleName: '업체관리자',
      allowedMenuCodes: ['CUSTOMER_LOOKUP', 'SALES', 'CONTRACT', 'INSTALL', 'AS', 'MY_STATUS', 'SETTLEMENT_VIEW']
    },
    STAFF_SALES: {
      roleName: '영업직원',
      allowedMenuCodes: ['CUSTOMER_LOOKUP', 'SALES', 'CONTRACT', 'MY_STATUS']
    },
    STAFF_INSTALL: {
      roleName: '설치담당',
      allowedMenuCodes: ['CUSTOMER_LOOKUP', 'INSTALL', 'MY_STATUS']
    },
    STAFF_AS: {
      roleName: 'A/S담당',
      allowedMenuCodes: ['CUSTOMER_LOOKUP', 'AS', 'MY_STATUS']
    },
    VIEWER: {
      roleName: '조회전용',
      allowedMenuCodes: ['CUSTOMER_LOOKUP', 'MY_STATUS']
    }
  };

  var p = policies[String(roleCode || '').trim()];
  if (!p) return { ok: false, roleName: '', allowedMenuCodes: [] };
  return {
    ok: true,
    roleName: p.roleName,
    allowedMenuCodes: p.allowedMenuCodes.slice()
  };
}

function erpB06J38_03_allFieldMenus_() {
  return [
    {
      menuCode: 'CUSTOMER_LOOKUP',
      title: '고객 조회',
      desc: 'eventId / vendorId 기준 고객 조회 화면 준비',
      route: 'customerLookup',
      icon: 'search',
      sortOrder: 10
    },
    {
      menuCode: 'SALES',
      title: '판매',
      desc: '판매 등록 화면 자리 준비. 현재 실행 차단',
      route: 'sales',
      icon: 'receipt',
      sortOrder: 20
    },
    {
      menuCode: 'CONTRACT',
      title: '계약',
      desc: '계약/서명 연결 화면 자리 준비. 현재 실행 차단',
      route: 'contract',
      icon: 'document',
      sortOrder: 30
    },
    {
      menuCode: 'INSTALL',
      title: '설치',
      desc: '설치 일정/완료 화면 자리 준비. 현재 실행 차단',
      route: 'install',
      icon: 'tools',
      sortOrder: 40
    },
    {
      menuCode: 'AS',
      title: 'A/S',
      desc: 'A/S 접수/처리 화면 자리 준비. 현재 실행 차단',
      route: 'as',
      icon: 'support',
      sortOrder: 50
    },
    {
      menuCode: 'MY_STATUS',
      title: '내 처리현황',
      desc: '내 업무 처리 현황 화면 자리 준비',
      route: 'myStatus',
      icon: 'checklist',
      sortOrder: 60
    },
    {
      menuCode: 'SETTLEMENT_VIEW',
      title: '정산 조회',
      desc: '업체 정산 조회 화면 자리 준비. 수정/지급 실행 차단',
      route: 'settlementView',
      icon: 'money',
      sortOrder: 70
    },
    {
      menuCode: 'STAFF_MANAGEMENT',
      title: '직원 관리',
      desc: '업체 직원/권한 관리 화면 자리 준비. 민감권한은 본사 승인 필요',
      route: 'staffManagement',
      icon: 'users',
      sortOrder: 80
    }
  ];
}

function erpB06J38_03_quickActions_(roleCode) {
  var policy = erpB06J38_03_getRoleMenuPolicy_(roleCode);
  if (!policy.ok) return [];
  var labels = {
    CUSTOMER_LOOKUP: '고객 조회',
    SALES: '판매 등록',
    CONTRACT: '계약 조회',
    INSTALL: '설치 확인',
    AS: 'A/S 확인',
    MY_STATUS: '내 처리현황',
    SETTLEMENT_VIEW: '정산 조회',
    STAFF_MANAGEMENT: '직원 관리'
  };
  return policy.allowedMenuCodes.map(function(code) {
    return {
      menuCode: code,
      title: labels[code] || code,
      enabled: false,
      disabledReason: 'B06J38 FIELD 최소 화면 단계: 업무 실행 차단'
    };
  });
}

function erpB06J38_03_safety_() {
  return {
    menuBootstrapOnly: true,
    uiRoutingOnly: true,
    buttonsDisabled: true,
    noBusinessStateMutation: true,
    noSheetWrite: true,
    paymentExecutionBlocked: true,
    settlementExecutionBlocked: true,
    externalIntegrationBlocked: true,
    vendorIndependentDbBlocked: true,
    vendorAsBranchUserGroup: true
  };
}

function erpB06J38_03_copy_(obj) {
  return JSON.parse(JSON.stringify(obj || {}));
}

function erpB06J38_03_getActiveEmail_() {
  try {
    return Session.getActiveUser().getEmail() || '';
  } catch (err) {
    return '';
  }
}


/* ===== Entry.js ===== */
/**
 * build: ERP_B06J38_01_FIELD_MIN_ENTRY_SCREEN_SAFE
 * role: ERP_FIELD 최소 진입 화면
 * apply: ERP_FIELD 폴더에 새 파일로 추가
 * file: ERP_FieldEntryPage.js
 */

var ERP_B06J38_01_BUILD = 'ERP_B06J38_01_FIELD_MIN_ENTRY_SCREEN_SAFE';
var ERP_B06J38_01_SETUP_DB_ID = '17VMSpgSZCvIrUlgcw8yCNcnl8WQWo2IcRf5tDCcuJGM';
var ERP_B06J38_01_CONFIG_SHEET_NAME = 'SystemConfig';

var ERP_B06J38_01_ALLOWED_FIELD_ROLES = [
  'VENDOR_OWNER',
  'VENDOR_MANAGER',
  'STAFF_SALES',
  'STAFF_INSTALL',
  'STAFF_AS',
  'VIEWER'
];

var ERP_B06J38_01_MENU = [
  { menuCode:'CUSTOMER_LOOKUP', title:'고객 조회', desc:'eventId / vendorId 기준 고객 조회 화면 준비', minRole:['VENDOR_OWNER','VENDOR_MANAGER','STAFF_SALES','STAFF_INSTALL','STAFF_AS','VIEWER'], status:'READY_PLACEHOLDER', executionBlocked:true },
  { menuCode:'SALES', title:'판매', desc:'현장 판매 등록 진입 자리. 실제 저장은 후속 빌드에서 연결', minRole:['VENDOR_OWNER','VENDOR_MANAGER','STAFF_SALES'], status:'PLACEHOLDER', executionBlocked:true },
  { menuCode:'CONTRACT', title:'계약', desc:'판매 → 계약 → SIGN 연결 진입 자리', minRole:['VENDOR_OWNER','VENDOR_MANAGER','STAFF_SALES'], status:'PLACEHOLDER', executionBlocked:true },
  { menuCode:'INSTALL', title:'설치', desc:'설치 일정/설치확인 진입 자리', minRole:['VENDOR_OWNER','VENDOR_MANAGER','STAFF_INSTALL'], status:'PLACEHOLDER', executionBlocked:true },
  { menuCode:'AS', title:'A/S', desc:'A/S 접수/처리 진입 자리', minRole:['VENDOR_OWNER','VENDOR_MANAGER','STAFF_AS'], status:'PLACEHOLDER', executionBlocked:true },
  { menuCode:'MY_STATUS', title:'내 처리현황', desc:'직원/업체별 처리현황 요약 자리', minRole:['VENDOR_OWNER','VENDOR_MANAGER','STAFF_SALES','STAFF_INSTALL','STAFF_AS','VIEWER'], status:'READY_PLACEHOLDER', executionBlocked:true }
];

function erpB06J38_01_autoRunSafe() {
  var result = {
    ok: true,
    build: ERP_B06J38_01_BUILD,
    moduleCode: 'ERP_FIELD',
    checkedAt: new Date().toISOString(),
    fatal: [],
    warnings: [],
    checks: {},
    safety: erpB06J38_01_safety_()
  };

  console.log('======================================================');
  console.log('[B06J38-01 FIELD MIN ENTRY SCREEN] START');

  try {
    result.checks.config = erpFieldB06J38_01_getConfig_();
    erpB06J38_01_collect_(result, 'config', result.checks.config);

    result.checks.master = erpFieldB06J38_01_getMasterInfo_();
    erpB06J38_01_collect_(result, 'master', result.checks.master);

    result.checks.entryDataSampleVendor = erpFieldB06J38_01_getEntryData({
      roleCode: 'VENDOR_MANAGER',
      vendorId: 'VENDOR-SAMPLE',
      eventId: 'EVT-SAMPLE'
    });
    erpB06J38_01_collect_(result, 'entryDataSampleVendor', result.checks.entryDataSampleVendor);

    result.checks.entryDataSampleStaff = erpFieldB06J38_01_getEntryData({
      roleCode: 'STAFF_SALES',
      vendorId: 'VENDOR-SAMPLE',
      eventId: 'EVT-SAMPLE'
    });
    erpB06J38_01_collect_(result, 'entryDataSampleStaff', result.checks.entryDataSampleStaff);

    result.checks.entryDataMissingVendor = erpFieldB06J38_01_getEntryData({
      roleCode: 'STAFF_SALES',
      vendorId: '',
      eventId: 'EVT-SAMPLE'
    });

    if (result.checks.entryDataMissingVendor.ok) {
      result.warnings.push('vendorId 누락 샘플이 ok=true입니다. FIELD 운영 조회 차단 정책 확인 필요.');
    }

  } catch (e) {
    result.fatal.push('B06J38-01 점검 예외: ' + String(e && e.message ? e.message : e));
    result.exceptionStack = String(e && e.stack ? e.stack : '');
  }

  result.fatalCount = result.fatal.length;
  result.warningCount = result.warnings.length;
  result.ok = result.fatalCount === 0;

  console.log('[B06J38-01 FIELD MIN ENTRY SCREEN] RESULT');
  console.log(JSON.stringify(result, null, 2));
  console.log('======================================================');

  return result;
}

function erpFieldB06J38_01_getEntryData(userContext) {
  var ctx = userContext || {};
  var roleCode = String(ctx.roleCode || '').trim().toUpperCase();
  var vendorId = String(ctx.vendorId || '').trim();
  var eventId = String(ctx.eventId || '').trim();

  var fatal = [];
  var warnings = [];

  if (ERP_B06J38_01_ALLOWED_FIELD_ROLES.indexOf(roleCode) < 0) {
    fatal.push('FIELD 허용 roleCode가 아닙니다: ' + roleCode);
  }

  if (!vendorId) {
    fatal.push('FIELD 화면은 vendorId가 필요합니다.');
  }

  var scope = {
    roleCode: roleCode,
    vendorId: vendorId,
    eventId: eventId,
    scopeType: roleCode.indexOf('VENDOR_') === 0 ? 'VENDOR' : 'STAFF',
    dataPolicy: 'vendorId / eventId / roleCode 기준 제한',
    hqFullAccess: false
  };

  var visibleMenus = ERP_B06J38_01_MENU.filter(function(menu) {
    return menu.minRole.indexOf(roleCode) >= 0;
  });

  return {
    ok: fatal.length === 0,
    build: ERP_B06J38_01_BUILD,
    moduleCode: 'ERP_FIELD',
    fatal: fatal,
    warnings: warnings,
    userContext: { roleCode: roleCode, vendorId: vendorId, eventId: eventId },
    scope: scope,
    visibleMenus: visibleMenus,
    blockedMessage: 'B06J38-01은 최소 진입 화면입니다. 실제 저장/계약/설치/A/S/정산 실행은 후속 빌드에서 연결합니다.',
    safety: erpB06J38_01_safety_()
  };
}

function erpFieldB06J38_01_renderEntryHtml(userContext) {
  var data = erpFieldB06J38_01_getEntryData(userContext || {
    roleCode: 'VENDOR_MANAGER',
    vendorId: 'VENDOR-SAMPLE',
    eventId: 'EVT-SAMPLE'
  });

  var cards = (data.visibleMenus || []).map(function(menu) {
    return ''
      + '<div class="fh-field-card">'
      + '<div class="fh-field-card-top">'
      + '<div class="fh-field-menu-code">' + erpFieldB06J38_01_escape_(menu.menuCode) + '</div>'
      + '<div class="fh-field-badge">' + erpFieldB06J38_01_escape_(menu.status) + '</div>'
      + '</div>'
      + '<h3>' + erpFieldB06J38_01_escape_(menu.title) + '</h3>'
      + '<p>' + erpFieldB06J38_01_escape_(menu.desc) + '</p>'
      + '<button type="button" disabled>후속 빌드에서 연결</button>'
      + '</div>';
  }).join('');

  if (!cards) cards = '<div class="fh-field-empty">표시 가능한 메뉴가 없습니다. roleCode / vendorId를 확인하세요.</div>';

  var fatalHtml = (data.fatal || []).length
    ? '<div class="fh-field-alert bad"><b>진입 제한</b><br>' + data.fatal.map(erpFieldB06J38_01_escape_).join('<br>') + '</div>'
    : '<div class="fh-field-alert ok"><b>진입 기준 정상</b><br>vendorId / eventId / roleCode 기준으로 FIELD 화면을 준비합니다.</div>';

  return ''
    + '<!doctype html><html><head><meta charset="utf-8">'
    + '<meta name="viewport" content="width=device-width,initial-scale=1">'
    + '<title>ERP FIELD</title>'
    + '<style>'
    + 'body{margin:0;background:#f6f8fb;font-family:Arial,"Noto Sans KR",sans-serif;color:#0f172a}'
    + '.fh-field-wrap{max-width:1180px;margin:0 auto;padding:24px}'
    + '.fh-field-head{background:#fff;border:1px solid #e2e8f0;border-radius:22px;padding:20px;box-shadow:0 8px 24px rgba(15,23,42,.05)}'
    + '.fh-field-kicker{font-size:12px;font-weight:900;color:#2563eb;margin-bottom:6px}'
    + 'h1{font-size:24px;margin:0 0 6px;letter-spacing:-.03em}'
    + '.fh-field-sub{font-size:13px;color:#64748b;line-height:1.5}'
    + '.fh-field-meta{display:flex;gap:8px;flex-wrap:wrap;margin-top:14px}'
    + '.fh-chip{padding:7px 10px;border-radius:999px;background:#eef2ff;color:#3730a3;font-size:12px;font-weight:800;border:1px solid #e0e7ff}'
    + '.fh-field-alert{margin-top:14px;padding:13px 14px;border-radius:16px;font-size:13px;line-height:1.55}'
    + '.fh-field-alert.ok{background:#ecfdf5;color:#065f46;border:1px solid #bbf7d0}'
    + '.fh-field-alert.bad{background:#fef2f2;color:#991b1b;border:1px solid #fecaca}'
    + '.fh-field-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(240px,1fr));gap:14px;margin-top:16px}'
    + '.fh-field-card{background:#fff;border:1px solid #e2e8f0;border-radius:18px;padding:16px;box-shadow:0 6px 18px rgba(15,23,42,.04)}'
    + '.fh-field-card-top{display:flex;justify-content:space-between;gap:8px;align-items:center}'
    + '.fh-field-menu-code{font-size:11px;color:#64748b;font-weight:900}'
    + '.fh-field-badge{font-size:11px;color:#7c2d12;background:#ffedd5;border:1px solid #fed7aa;border-radius:999px;padding:5px 8px;font-weight:900}'
    + '.fh-field-card h3{margin:14px 0 6px;font-size:17px}'
    + '.fh-field-card p{margin:0 0 14px;font-size:13px;color:#475569;line-height:1.5}'
    + '.fh-field-card button{border:0;border-radius:12px;background:#cbd5e1;color:#475569;font-weight:900;padding:10px 12px;width:100%}'
    + '.fh-field-footer{margin-top:18px;padding:14px;color:#64748b;font-size:12px;display:flex;justify-content:space-between;gap:10px;flex-wrap:wrap}'
    + '.fh-field-empty{background:#fff;border:1px dashed #cbd5e1;border-radius:18px;padding:18px;color:#64748b}'
    + '</style></head><body>'
    + '<div class="fh-field-wrap">'
    + '<div class="fh-field-head">'
    + '<div class="fh-field-kicker">ERP_FIELD · ' + erpFieldB06J38_01_escape_(ERP_B06J38_01_BUILD) + '</div>'
    + '<h1>현장 / 업체 / 직원용 최소 진입 화면</h1>'
    + '<div class="fh-field-sub">업체는 별도 앱이 아니라 ERP 내부 지점형 사용자 그룹입니다. 이 화면은 vendorId, eventId, roleCode 기준으로 메뉴를 분리하기 위한 1차 기준 화면입니다.</div>'
    + '<div class="fh-field-meta">'
    + '<span class="fh-chip">roleCode: ' + erpFieldB06J38_01_escape_(data.userContext.roleCode) + '</span>'
    + '<span class="fh-chip">vendorId: ' + erpFieldB06J38_01_escape_(data.userContext.vendorId || '필요') + '</span>'
    + '<span class="fh-chip">eventId: ' + erpFieldB06J38_01_escape_(data.userContext.eventId || '선택') + '</span>'
    + '</div>' + fatalHtml + '</div>'
    + '<div class="fh-field-grid">' + cards + '</div>'
    + '<div class="fh-field-footer"><span>© 2026 FEELHAUS. All rights reserved.</span><span>(주)필하우스 · 개발담당: 이용필 · 최고운영자: 이용필</span></div>'
    + '</div></body></html>';
}

function erpFieldB06J38_01_getConfig_() {
  var ss = SpreadsheetApp.openById(ERP_B06J38_01_SETUP_DB_ID);
  var sh = ss.getSheetByName(ERP_B06J38_01_CONFIG_SHEET_NAME);
  var fatal = [];
  var warnings = [];
  var configMap = {};

  if (!sh) {
    fatal.push('SystemConfig 시트를 찾지 못했습니다.');
    return { ok:false, fatal:fatal, warnings:warnings, configMap:configMap };
  }

  var values = sh.getDataRange().getValues();
  if (!values || values.length < 2) {
    fatal.push('SystemConfig 데이터가 비어 있습니다.');
    return { ok:false, fatal:fatal, warnings:warnings, configMap:configMap };
  }

  var headers = values[0].map(function(h){ return String(h || '').trim(); });
  var lower = headers.map(function(h){ return h.toLowerCase(); });
  var keyIdx = lower.indexOf('key');
  if (keyIdx < 0) keyIdx = lower.indexOf('configkey');
  if (keyIdx < 0) keyIdx = lower.indexOf('name');
  if (keyIdx < 0) keyIdx = 0;
  var valIdx = lower.indexOf('value');
  if (valIdx < 0) valIdx = lower.indexOf('configvalue');
  if (valIdx < 0) valIdx = lower.indexOf('spreadsheetid');
  if (valIdx < 0) valIdx = 1;

  for (var r = 1; r < values.length; r++) {
    var k = String(values[r][keyIdx] || '').trim();
    var v = String(values[r][valIdx] || '').trim();
    if (k) configMap[k] = v;
  }

  return {
    ok: true,
    fatal: fatal,
    warnings: warnings,
    setupDbId: ERP_B06J38_01_SETUP_DB_ID,
    setupDbName: ss.getName(),
    configSheetName: ERP_B06J38_01_CONFIG_SHEET_NAME,
    configCount: Object.keys(configMap).length,
    configMap: configMap
  };
}

function erpFieldB06J38_01_getMasterInfo_() {
  var cfg = erpFieldB06J38_01_getConfig_();
  if (!cfg.ok) return { ok:false, fatal:cfg.fatal, warnings:cfg.warnings };
  var keys = ['FEELHAUS_DB_MASTER_ID','FEELHAUS_DB_MASTER','MASTER_SPREADSHEET_ID','MASTER_DB_ID','DB_MASTER_ID','SPREADSHEET_ID'];
  var raw = '';
  var usedKey = '';
  for (var i = 0; i < keys.length; i++) {
    if (cfg.configMap[keys[i]]) {
      raw = cfg.configMap[keys[i]];
      usedKey = keys[i];
      break;
    }
  }
  if (!raw) return { ok:false, fatal:['MASTER ID를 SystemConfig에서 찾지 못했습니다.'], warnings:[] };
  var masterId = erpFieldB06J38_01_extractSpreadsheetId_(raw);
  var master = SpreadsheetApp.openById(masterId);
  return { ok:true, fatal:[], warnings:[], usedKey:usedKey, masterId:masterId, masterName:master.getName() };
}

function erpFieldB06J38_01_extractSpreadsheetId_(raw) {
  var s = String(raw || '').trim();
  var m = s.match(/\/d\/([a-zA-Z0-9-_]+)/);
  return m && m[1] ? m[1] : s;
}

function erpFieldB06J38_01_escape_(s) {
  return String(s == null ? '' : s)
    .replace(/&/g,'&amp;')
    .replace(/</g,'&lt;')
    .replace(/>/g,'&gt;')
    .replace(/"/g,'&quot;')
    .replace(/'/g,'&#39;');
}

function erpB06J38_01_collect_(result, label, check) {
  if (!check) return;
  if (check.fatal && check.fatal.length) {
    result.fatal = result.fatal.concat(check.fatal.map(function(x){ return label + ': ' + x; }));
  }
  if (check.warnings && check.warnings.length) {
    result.warnings = result.warnings.concat(check.warnings.map(function(x){ return label + ': ' + x; }));
  }
}

function erpB06J38_01_safety_() {
  return {
    fieldEntryScreenOnly: true,
    noSheetMutation: true,
    noBusinessDataMutation: true,
    noPaymentExecution: true,
    noRecoveryExecution: true,
    noAutoRecalculation: true,
    noExternalAccountingTransfer: true,
    executionButtonsDisabled: true,
    vendorIsBranchUserGroupInsideErp: true,
    independentVendorDbBlocked: true
  };
}


/* ===== ModCheck.js ===== */
/**
 * build: ERP_B06J37_01_MODULE_SPLIT_BASELINE_CHECK_SAFE
 * purpose:
 *  - ERP_CORE / ERP_ADMIN / ERP_FIELD 모듈 분리 기준점검
 *  - 업체 독립 앱/독립 DB 구조 차단 확인
 *  - FEELHAUS_SETUP_DB > SystemConfig 자동 읽기 확인
 *  - FEELHAUS_DB_MASTER 자동 연결 확인
 *  - 공통 ID / 핵심 시트 / 핵심 헤더 기준 확인
 *
 * apply:
 *  - 이 파일은 기존 파일에 붙이지 말고 새 파일로 추가합니다.
 *  - 권장 파일명: ERP_ModuleSplit_B06J37_01.gs
 *
 * standard auto:
 *  - erpB06J37_01_autoRunSafe()
 */

var ERP_B06J37_01_BUILD = 'ERP_B06J37_01_MODULE_SPLIT_BASELINE_CHECK_SAFE';

var ERP_B06J37_01_SETUP_DB_ID = '17VMSpgSZCvIrUlgcw8yCNcnl8WQWo2IcRf5tDCcuJGM';
var ERP_B06J37_01_CONFIG_SHEET_NAME = 'SystemConfig';

var ERP_B06J37_01_ALLOWED_MODULES = ['ERP_CORE', 'ERP_ADMIN', 'ERP_FIELD'];

var ERP_B06J37_01_CORE_SHEETS = [
  {
    sheetName: 'ERP_행사관리',
    requiredHeaders: ['eventId','status','statusReason','createdAt','createdBy','updatedAt','updatedBy']
  },
  {
    sheetName: 'ERP_업체관리',
    requiredHeaders: ['vendorId','status','statusReason','createdAt','createdBy','updatedAt','updatedBy']
  },
  {
    sheetName: 'ERP_고객관리',
    requiredHeaders: ['customerId','eventId','vendorId','status','statusReason','createdAt','createdBy','updatedAt','updatedBy']
  },
  {
    sheetName: 'ERP_행사업체연결',
    requiredHeaders: ['eventVendorId','eventId','vendorId','status','statusReason','createdAt','createdBy','updatedAt','updatedBy']
  }
];

var ERP_B06J37_01_COMMON_ID_HEADERS = [
  'eventId',
  'vendorId',
  'customerId',
  'saleId',
  'contractId',
  'installId',
  'asId',
  'documentId',
  'status',
  'statusReason',
  'createdAt',
  'createdBy',
  'updatedAt',
  'updatedBy'
];

function erpB06J37_01_autoRunSafe(moduleCode) {
  var result = {
    ok: true,
    build: ERP_B06J37_01_BUILD,
    checkedAt: new Date().toISOString(),
    moduleCode: moduleCode || erpB06J37_01_guessModuleCode_(),
    scriptId: erpB06J37_01_getScriptId_(),
    fatal: [],
    warnings: [],
    checks: {},
    safety: erpB06J37_01_safetyFlags_()
  };

  console.log('======================================================');
  console.log('[B06J37-01 MODULE SPLIT BASELINE CHECK] START');
  console.log(JSON.stringify({
    build: ERP_B06J37_01_BUILD,
    moduleCode: result.moduleCode,
    scriptId: result.scriptId
  }, null, 2));

  try {
    result.checks.moduleCodeAllowed = erpB06J37_01_checkModuleCode_(result.moduleCode);
    erpB06J37_01_collect_(result, 'moduleCodeAllowed', result.checks.moduleCodeAllowed);

    result.checks.setupDb = erpB06J37_01_checkSetupDb_();
    erpB06J37_01_collect_(result, 'setupDb', result.checks.setupDb);

    result.checks.masterDb = erpB06J37_01_checkMasterDb_(result.checks.setupDb.configMap);
    erpB06J37_01_collect_(result, 'masterDb', result.checks.masterDb);

    result.checks.coreSheets = erpB06J37_01_checkCoreSheets_(result.checks.masterDb.masterSpreadsheet);
    erpB06J37_01_collect_(result, 'coreSheets', result.checks.coreSheets);

    result.checks.independentDbGuard = erpB06J37_01_checkIndependentDbGuard_(result.checks.setupDb.configMap);
    erpB06J37_01_collect_(result, 'independentDbGuard', result.checks.independentDbGuard);

    result.checks.roleSplitPolicy = erpB06J37_01_checkRoleSplitPolicy_(result.moduleCode);
    erpB06J37_01_collect_(result, 'roleSplitPolicy', result.checks.roleSplitPolicy);

    result.checks.requiredCommonIds = erpB06J37_01_checkCommonIds_();
    erpB06J37_01_collect_(result, 'requiredCommonIds', result.checks.requiredCommonIds);

  } catch (e) {
    result.ok = false;
    result.fatal.push('B06J37-01 점검 중 예외: ' + String(e && e.message ? e.message : e));
    result.exceptionStack = String(e && e.stack ? e.stack : '');
  }

  result.fatalCount = result.fatal.length;
  result.warningCount = result.warnings.length;
  result.ok = result.fatalCount === 0;

  // Spreadsheet 객체는 로그 직렬화에서 제외
  if (result.checks.masterDb && result.checks.masterDb.masterSpreadsheet) {
    result.checks.masterDb.masterSpreadsheetName = result.checks.masterDb.masterSpreadsheet.getName();
    delete result.checks.masterDb.masterSpreadsheet;
  }

  console.log('[B06J37-01 MODULE SPLIT BASELINE CHECK] RESULT');
  console.log(JSON.stringify(result, null, 2));
  console.log('======================================================');

  return result;
}

function erpB06J37_01_checkModuleCode_(moduleCode) {
  var ok = ERP_B06J37_01_ALLOWED_MODULES.indexOf(String(moduleCode || '').trim()) >= 0;
  return {
    ok: ok,
    fatal: ok ? [] : ['moduleCode가 허용값이 아닙니다. ERP_CORE / ERP_ADMIN / ERP_FIELD 중 하나여야 합니다.'],
    warnings: [],
    moduleCode: moduleCode,
    allowedModules: ERP_B06J37_01_ALLOWED_MODULES
  };
}

function erpB06J37_01_checkSetupDb_() {
  var ss = SpreadsheetApp.openById(ERP_B06J37_01_SETUP_DB_ID);
  var sh = ss.getSheetByName(ERP_B06J37_01_CONFIG_SHEET_NAME);

  var fatal = [];
  var warnings = [];
  var configMap = {};

  if (!sh) {
    fatal.push('FEELHAUS_SETUP_DB에서 SystemConfig 시트를 찾지 못했습니다.');
    return {
      ok: false,
      fatal: fatal,
      warnings: warnings,
      setupDbId: ERP_B06J37_01_SETUP_DB_ID,
      configSheetName: ERP_B06J37_01_CONFIG_SHEET_NAME,
      configMap: configMap
    };
  }

  var values = sh.getDataRange().getValues();
  if (!values || values.length < 2) {
    fatal.push('SystemConfig 데이터가 비어 있습니다.');
    return {
      ok: false,
      fatal: fatal,
      warnings: warnings,
      setupDbId: ERP_B06J37_01_SETUP_DB_ID,
      configSheetName: ERP_B06J37_01_CONFIG_SHEET_NAME,
      configMap: configMap
    };
  }

  var headers = values[0].map(function(h) { return String(h || '').trim(); });
  var lower = headers.map(function(h) { return h.toLowerCase(); });

  var keyIdx = lower.indexOf('key');
  if (keyIdx < 0) keyIdx = lower.indexOf('configkey');
  if (keyIdx < 0) keyIdx = lower.indexOf('name');
  if (keyIdx < 0) keyIdx = 0;

  var valIdx = lower.indexOf('value');
  if (valIdx < 0) valIdx = lower.indexOf('configvalue');
  if (valIdx < 0) valIdx = lower.indexOf('spreadsheetid');
  if (valIdx < 0) valIdx = 1;

  for (var r = 1; r < values.length; r++) {
    var k = String(values[r][keyIdx] || '').trim();
    var v = String(values[r][valIdx] || '').trim();
    if (k) configMap[k] = v;
  }

  return {
    ok: true,
    fatal: fatal,
    warnings: warnings,
    setupDbId: ERP_B06J37_01_SETUP_DB_ID,
    setupDbName: ss.getName(),
    configSheetName: ERP_B06J37_01_CONFIG_SHEET_NAME,
    configCount: Object.keys(configMap).length,
    configMap: configMap
  };
}

function erpB06J37_01_checkMasterDb_(configMap) {
  var fatal = [];
  var warnings = [];

  var candidateKeys = [
    'FEELHAUS_DB_MASTER_ID',
    'FEELHAUS_DB_MASTER',
    'MASTER_SPREADSHEET_ID',
    'MASTER_DB_ID',
    'DB_MASTER_ID'
  ];

  var raw = '';
  var usedKey = '';

  for (var i = 0; i < candidateKeys.length; i++) {
    var k = candidateKeys[i];
    if (configMap && configMap[k]) {
      raw = String(configMap[k]).trim();
      usedKey = k;
      break;
    }
  }

  if (!raw) {
    fatal.push('SystemConfig에서 FEELHAUS_DB_MASTER ID를 찾지 못했습니다.');
    return {
      ok: false,
      fatal: fatal,
      warnings: warnings,
      usedKey: usedKey,
      rawValue: raw,
      masterId: ''
    };
  }

  var m = raw.match(/\/d\/([a-zA-Z0-9-_]+)/);
  var masterId = m && m[1] ? m[1] : raw;

  var masterSpreadsheet = SpreadsheetApp.openById(masterId);

  return {
    ok: true,
    fatal: fatal,
    warnings: warnings,
    usedKey: usedKey,
    rawValue: raw,
    masterId: masterId,
    masterName: masterSpreadsheet.getName(),
    masterSpreadsheet: masterSpreadsheet
  };
}

function erpB06J37_01_checkCoreSheets_(masterSpreadsheet) {
  var fatal = [];
  var warnings = [];
  var sheetChecks = [];

  ERP_B06J37_01_CORE_SHEETS.forEach(function(spec) {
    var sh = masterSpreadsheet.getSheetByName(spec.sheetName);
    if (!sh) {
      fatal.push('MASTER 필수 시트 누락: ' + spec.sheetName);
      sheetChecks.push({
        sheetName: spec.sheetName,
        exists: false,
        missingHeaders: spec.requiredHeaders
      });
      return;
    }

    var headers = erpB06J37_01_getHeaders_(sh);
    var missing = spec.requiredHeaders.filter(function(h) {
      return headers.indexOf(h) < 0;
    });

    if (missing.length) {
      fatal.push(spec.sheetName + ' 필수 헤더 누락: ' + missing.join(', '));
    }

    sheetChecks.push({
      sheetName: spec.sheetName,
      exists: true,
      lastRow: sh.getLastRow(),
      lastCol: sh.getLastColumn(),
      missingHeaders: missing
    });
  });

  return {
    ok: fatal.length === 0,
    fatal: fatal,
    warnings: warnings,
    sheetChecks: sheetChecks
  };
}

function erpB06J37_01_checkIndependentDbGuard_(configMap) {
  var fatal = [];
  var warnings = [];
  var suspicious = [];

  Object.keys(configMap || {}).forEach(function(k) {
    var key = String(k || '').toUpperCase();
    var val = String(configMap[k] || '').trim();

    // 업체별 독립 DB를 암시하는 설정 키는 금지 후보로 잡습니다.
    if (
      key.indexOf('VENDOR_DB') >= 0 ||
      key.indexOf('VENDOR_SPREADSHEET') >= 0 ||
      key.indexOf('PARTNER_DB') >= 0 ||
      key.indexOf('BRANCH_DB') >= 0
    ) {
      suspicious.push({ key: k, value: val });
    }
  });

  if (suspicious.length) {
    warnings.push('업체/지점 독립 DB로 오해될 수 있는 설정 키가 있습니다. 실제 운영 연결로 사용 중인지 확인 필요.');
  }

  return {
    ok: true,
    fatal: fatal,
    warnings: warnings,
    independentVendorDbBlocked: true,
    suspiciousConfigKeys: suspicious,
    message: '업체는 ERP 내부 지점형 사용자 그룹이며, 업체별 독립 DB 구조는 금지입니다.'
  };
}

function erpB06J37_01_checkRoleSplitPolicy_(moduleCode) {
  var fatal = [];
  var warnings = [];

  var policy = {
    ERP_CORE: {
      role: '공통 엔진 / 설정 / MASTER 연결 / 공통 ID / 헤더맵 / 공통 저장조회',
      screenScope: '공통/백엔드 중심',
      mustNotOwnIndependentDb: true
    },
    ERP_ADMIN: {
      role: '본사 관리자 화면 / 행사 / 업체 / 승인 / 정산 / 통제',
      screenScope: '본사 HQ 화면',
      mustNotOwnIndependentDb: true
    },
    ERP_FIELD: {
      role: '현장/업체/직원용 화면 / 판매 / 계약 / 설치 / A/S / 조회',
      screenScope: 'vendorId / eventId / roleCode 기준 화면 분기',
      mustNotOwnIndependentDb: true
    }
  };

  var p = policy[moduleCode] || null;
  if (!p) {
    fatal.push('모듈 정책을 찾을 수 없습니다: ' + moduleCode);
  }

  return {
    ok: fatal.length === 0,
    fatal: fatal,
    warnings: warnings,
    moduleCode: moduleCode,
    policy: p,
    allPolicies: policy
  };
}

function erpB06J37_01_checkCommonIds_() {
  return {
    ok: true,
    fatal: [],
    warnings: [],
    commonIdHeaders: ERP_B06J37_01_COMMON_ID_HEADERS,
    connectionRule: '모든 연결은 이름/전화번호/문서명이 아니라 공통 ID 기준입니다.',
    headerRule: '다른 프로젝트는 열 위치가 아니라 헤더명으로 자동 추적해야 합니다.'
  };
}

function erpB06J37_01_collect_(result, label, check) {
  if (!check) return;
  if (check.fatal && check.fatal.length) {
    result.fatal = result.fatal.concat(check.fatal.map(function(x) {
      return label + ': ' + x;
    }));
  }
  if (check.warnings && check.warnings.length) {
    result.warnings = result.warnings.concat(check.warnings.map(function(x) {
      return label + ': ' + x;
    }));
  }
}

function erpB06J37_01_getHeaders_(sh) {
  if (!sh || sh.getLastRow() < 1 || sh.getLastColumn() < 1) return [];
  return sh.getRange(1, 1, 1, sh.getLastColumn()).getValues()[0].map(function(h) {
    return String(h || '').trim();
  });
}

function erpB06J37_01_guessModuleCode_() {
  try {
    var name = DriveApp.getFileById(ScriptApp.getScriptId()).getName();
    var upper = String(name || '').toUpperCase();
    if (upper.indexOf('ERP_CORE') >= 0) return 'ERP_CORE';
    if (upper.indexOf('ERP_ADMIN') >= 0) return 'ERP_ADMIN';
    if (upper.indexOf('ERP_FIELD') >= 0) return 'ERP_FIELD';
    if (upper.indexOf('CORE') >= 0) return 'ERP_CORE';
    if (upper.indexOf('ADMIN') >= 0) return 'ERP_ADMIN';
    if (upper.indexOf('FIELD') >= 0) return 'ERP_FIELD';
  } catch (e) {}
  return 'ERP_ADMIN';
}

function erpB06J37_01_getScriptId_() {
  try {
    return ScriptApp.getScriptId();
  } catch (e) {
    return '';
  }
}

function erpB06J37_01_safetyFlags_() {
  return {
    baselineCheckOnly: true,
    noSheetMutation: true,
    noBusinessDataMutation: true,
    noUiMutation: true,
    noPaymentExecution: true,
    noRecoveryExecution: true,
    noAutoRecalculation: true,
    noExternalAccountingTransfer: true,
    independentVendorDbBlocked: true,
    vendorIsBranchUserGroupInsideErp: true
  };
}


/* ===== ModPrep.js ===== */
/**
 * build: ERP_B06J37_02_MASTER_CORE_HEADER_REPAIR_SAFE
 * purpose:
 *  - B06J37-01 기준점검 실패 원인 보정
 *  - FEELHAUS_DB_MASTER의 ERP_행사관리 / ERP_업체관리 누락 헤더 추가
 *  - 누락 헤더: statusReason, createdBy
 *
 * apply:
 *  - 기존 파일에 붙이지 말고 새 파일로 추가합니다.
 *  - 권장 파일명: ERP_ModuleSplit_B06J37_02.js
 *
 * safety:
 *  - 기존 헤더/데이터 삭제 없음
 *  - 기존 열 순서 변경 없음
 *  - 누락 헤더만 마지막 열 뒤에 추가
 *  - 기본 점검은 dryRun
 *
 * functions:
 *  - erpB06J37_02_dryRun()
 *  - erpB06J37_02_confirmed()
 */

var ERP_B06J37_02_BUILD = 'ERP_B06J37_02_MASTER_CORE_HEADER_REPAIR_SAFE';
var ERP_B06J37_02_SETUP_DB_ID = '17VMSpgSZCvIrUlgcw8yCNcnl8WQWo2IcRf5tDCcuJGM';
var ERP_B06J37_02_CONFIG_SHEET_NAME = 'SystemConfig';

var ERP_B06J37_02_TARGETS = [
  {
    sheetName: 'ERP_행사관리',
    requiredHeaders: ['statusReason', 'createdBy']
  },
  {
    sheetName: 'ERP_업체관리',
    requiredHeaders: ['statusReason', 'createdBy']
  }
];

function erpB06J37_02_dryRun() {
  return erpB06J37_02_run_(true);
}

function erpB06J37_02_confirmed() {
  return erpB06J37_02_run_(false);
}

function erpB06J37_02_run_(dryRun) {
  var result = {
    ok: true,
    build: ERP_B06J37_02_BUILD,
    dryRun: dryRun === true,
    checkedAt: new Date().toISOString(),
    fatal: [],
    warnings: [],
    targets: [],
    safety: {
      headerRepairOnly: true,
      appendMissingHeadersOnly: true,
      noHeaderDelete: true,
      noHeaderReorder: true,
      noDataDelete: true,
      noBusinessStateMutation: true,
      noPaymentExecution: true,
      noRecoveryExecution: true,
      noAutoRecalculation: true,
      noExternalAccountingTransfer: true
    }
  };

  console.log('======================================================');
  console.log('[B06J37-02 MASTER CORE HEADER REPAIR] START');
  console.log(JSON.stringify({ build: ERP_B06J37_02_BUILD, dryRun: result.dryRun }, null, 2));

  try {
    var setup = erpB06J37_02_getSetupConfig_();
    result.setup = {
      ok: setup.ok,
      setupDbName: setup.setupDbName,
      configCount: setup.configCount,
      usedMasterKey: setup.usedMasterKey,
      masterId: setup.masterId
    };

    if (!setup.ok) {
      result.fatal = result.fatal.concat(setup.fatal || []);
    } else {
      var master = SpreadsheetApp.openById(setup.masterId);
      result.masterName = master.getName();

      ERP_B06J37_02_TARGETS.forEach(function(target) {
        var one = erpB06J37_02_repairSheetHeaders_(master, target, result.dryRun);
        result.targets.push(one);
        if (!one.ok && one.fatal && one.fatal.length) {
          result.fatal = result.fatal.concat(one.fatal);
        }
        if (one.warnings && one.warnings.length) {
          result.warnings = result.warnings.concat(one.warnings);
        }
      });
    }
  } catch (e) {
    result.ok = false;
    result.fatal.push('B06J37-02 실행 예외: ' + String(e && e.message ? e.message : e));
    result.exceptionStack = String(e && e.stack ? e.stack : '');
  }

  result.fatalCount = result.fatal.length;
  result.warningCount = result.warnings.length;
  result.ok = result.fatalCount === 0;

  console.log('[B06J37-02 MASTER CORE HEADER REPAIR] RESULT');
  console.log(JSON.stringify(result, null, 2));
  console.log('======================================================');

  return result;
}

function erpB06J37_02_repairSheetHeaders_(master, target, dryRun) {
  var out = {
    ok: true,
    sheetName: target.sheetName,
    dryRun: dryRun === true,
    exists: false,
    beforeLastCol: 0,
    afterLastCol: 0,
    existingHeaders: [],
    missingHeaders: [],
    appendedHeaders: [],
    fatal: [],
    warnings: []
  };

  var sh = master.getSheetByName(target.sheetName);
  if (!sh) {
    out.ok = false;
    out.fatal.push('대상 시트를 찾지 못했습니다: ' + target.sheetName);
    return out;
  }

  out.exists = true;
  out.beforeLastCol = sh.getLastColumn();
  out.existingHeaders = erpB06J37_02_getHeaders_(sh);

  out.missingHeaders = target.requiredHeaders.filter(function(h) {
    return out.existingHeaders.indexOf(h) < 0;
  });

  if (!out.missingHeaders.length) {
    out.afterLastCol = out.beforeLastCol;
    out.message = '누락 헤더 없음';
    return out;
  }

  if (!dryRun) {
    var startCol = sh.getLastColumn() + 1;
    sh.getRange(1, startCol, 1, out.missingHeaders.length).setValues([out.missingHeaders]);
    SpreadsheetApp.flush();
    out.appendedHeaders = out.missingHeaders.slice();
    out.afterLastCol = sh.getLastColumn();
  } else {
    out.afterLastCol = out.beforeLastCol + out.missingHeaders.length;
    out.appendedHeaders = [];
  }

  out.message = dryRun
    ? 'DRY_RUN: 누락 헤더 추가 예정'
    : 'CONFIRMED: 누락 헤더 추가 완료';

  return out;
}

function erpB06J37_02_getSetupConfig_() {
  var out = {
    ok: true,
    fatal: [],
    configMap: {},
    configCount: 0,
    setupDbName: '',
    usedMasterKey: '',
    masterId: ''
  };

  var setup = SpreadsheetApp.openById(ERP_B06J37_02_SETUP_DB_ID);
  out.setupDbName = setup.getName();

  var sh = setup.getSheetByName(ERP_B06J37_02_CONFIG_SHEET_NAME);
  if (!sh) {
    out.ok = false;
    out.fatal.push('SystemConfig 시트를 찾지 못했습니다.');
    return out;
  }

  var values = sh.getDataRange().getValues();
  if (!values || values.length < 2) {
    out.ok = false;
    out.fatal.push('SystemConfig 데이터가 비어 있습니다.');
    return out;
  }

  var headers = values[0].map(function(h) { return String(h || '').trim(); });
  var lower = headers.map(function(h) { return h.toLowerCase(); });

  var keyIdx = lower.indexOf('key');
  if (keyIdx < 0) keyIdx = lower.indexOf('configkey');
  if (keyIdx < 0) keyIdx = lower.indexOf('name');
  if (keyIdx < 0) keyIdx = 0;

  var valIdx = lower.indexOf('value');
  if (valIdx < 0) valIdx = lower.indexOf('configvalue');
  if (valIdx < 0) valIdx = lower.indexOf('spreadsheetid');
  if (valIdx < 0) valIdx = 1;

  for (var r = 1; r < values.length; r++) {
    var k = String(values[r][keyIdx] || '').trim();
    var v = String(values[r][valIdx] || '').trim();
    if (k) out.configMap[k] = v;
  }

  out.configCount = Object.keys(out.configMap).length;

  var keys = [
    'FEELHAUS_DB_MASTER_ID',
    'FEELHAUS_DB_MASTER',
    'MASTER_SPREADSHEET_ID',
    'MASTER_DB_ID',
    'DB_MASTER_ID',
    'SPREADSHEET_ID'
  ];

  for (var i = 0; i < keys.length; i++) {
    var key = keys[i];
    if (out.configMap[key]) {
      out.usedMasterKey = key;
      out.masterId = erpB06J37_02_extractSpreadsheetId_(out.configMap[key]);
      break;
    }
  }

  if (!out.masterId) {
    out.ok = false;
    out.fatal.push('SystemConfig에서 FEELHAUS_DB_MASTER ID를 찾지 못했습니다.');
  }

  return out;
}

function erpB06J37_02_extractSpreadsheetId_(raw) {
  var s = String(raw || '').trim();
  var m = s.match(/\/d\/([a-zA-Z0-9-_]+)/);
  return m && m[1] ? m[1] : s;
}

function erpB06J37_02_getHeaders_(sh) {
  if (!sh || sh.getLastRow() < 1 || sh.getLastColumn() < 1) return [];
  return sh.getRange(1, 1, 1, sh.getLastColumn()).getValues()[0].map(function(h) {
    return String(h || '').trim();
  });
}


/* ===== Open.js ===== */
/**
 * build: ERP_FIELD_V27_DRY_RUN_PRESET_ONLY
 * purpose: FIELD 1차 제한 개방 상태 표시 및 최소 자체점검
 * scope: customerLookup READY, sales/salesSave DRY_RUN_ONLY, contract/install/as/settlement BLOCKED
 */
var ERP_FIELD_V25_BUILD = 'ERP_FIELD_V27_DRY_RUN_PRESET_ONLY';

function runErpFieldLimitedOpenV25SelfCheck() {
  var result = {
    ok: true,
    build: ERP_FIELD_V25_BUILD,
    checkedAt: new Date().toISOString(),
    routeScope: {
      customerLookup: 'READY',
      sales: 'READY',
      salesSave: 'DRY_RUN_ONLY',
      contracts: 'BLOCKED',
      install: 'BLOCKED',
      as: 'BLOCKED',
      settlement: 'BLOCKED'
    },
    fatal: [],
    nextAction: 'FIELD URL에서 roleCode/vendorId 포함 접속 후 customerLookup 및 salesSave dryRunPreset=Y 드라이런 화면 확인'
  };
  Logger.log(JSON.stringify(result));
  return result;
}
