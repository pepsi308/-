@echo off
setlocal EnableExtensions
title FEELHAUS UPLOAD ERP_ADMIN

cd /d D:\pepsi308\OneDrive\feelhaus_pull\ERP_ADMIN
if errorlevel 1 (
  echo [ERROR] ERP_ADMIN folder not found.
  pause
  exit /b 1
)

if not exist ".clasp.json" (
  echo [ERROR] ERP_ADMIN .clasp.json not found.
  pause
  exit /b 1
)

echo ==========================================
echo ERP_ADMIN upload start
echo Current folder:
cd
echo ==========================================
echo.

clasp.cmd push 
set RC=%ERRORLEVEL%

echo.
echo ==========================================
if %RC%==0 (
  echo [OK] ERP_ADMIN upload complete
) else (
  echo [ERROR] ERP_ADMIN upload failed
  echo ERRORLEVEL=%RC%
)
echo ==========================================
echo.

pause
