/**
 * build: ERP_B06J37_06_MODULE_SPLIT_OPERATION_BASELINE_SAFE
 * role:
 *  - ERP_CORE / ERP_ADMIN / ERP_FIELD 세 모듈 운영 기준본 확정
 *
 * purpose:
 *  - B06J37-01 ~ B06J37-05 결과를 기준으로 모듈 분리 운영 기준을 기록
 *  - 업체 독립 앱/독립 DB 금지 기준 고정
 *  - FEELHAUS_SETUP_DB > SystemConfig / FEELHAUS_DB_MASTER 기준 연결 확인
 *  - ERP_ModuleBaselineLog 시트에 기준본 기록
 *
 * apply:
 *  - ERP_ADMIN 폴더에 새 파일로 추가
 *  - 권장 파일명: ERP_ModuleBaseline_B06J37_06.js
 *
 * functions:
 *  - erpB06J37_06_dryRun()
 *  - erpB06J37_06_confirmed()
 */

var ERP_B06J37_06_BUILD = 'ERP_B06J37_06_MODULE_SPLIT_OPERATION_BASELINE_SAFE';
var ERP_B06J37_06_SETUP_DB_ID = '17VMSpgSZCvIrUlgcw8yCNcnl8WQWo2IcRf5tDCcuJGM';
var ERP_B06J37_06_CONFIG_SHEET_NAME = 'SystemConfig';
var ERP_B06J37_06_BASELINE_SHEET = 'ERP_ModuleBaselineLog';

var ERP_B06J37_06_MODULES = [
  {
    moduleCode: 'ERP_CORE',
    role: '공통 엔진 / SystemConfig / MASTER 연결 / HeaderMap / ID / 로그 / 권한 / 상태값',
    currentStatus: 'CORE_MIN_BASE_ENGINE_READY',
    requiredBuilds: ['ERP_B06J37_01_MODULE_SPLIT_BASELINE_CHECK_SAFE', 'ERP_B06J37_03_CORE_MIN_BASE_ENGINE_SAFE']
  },
  {
    moduleCode: 'ERP_ADMIN',
    role: '본사 관리자 / 행사 / 업체 / 승인 / 정산 / 통제 화면',
    currentStatus: 'ADMIN_CORE_LINK_READY',
    requiredBuilds: ['ERP_B06J37_01_MODULE_SPLIT_BASELINE_CHECK_SAFE', 'ERP_B06J37_04_ADMIN_CORE_LINK_CHECK_SAFE']
  },
  {
    moduleCode: 'ERP_FIELD',
    role: '현장 / 업체 / 직원 화면 준비 기준 / vendorId, eventId, roleCode 기반 제한',
    currentStatus: 'FIELD_CORE_LINK_READY',
    requiredBuilds: ['ERP_B06J37_01_MODULE_SPLIT_BASELINE_CHECK_SAFE', 'ERP_B06J37_05_FIELD_CORE_LINK_CHECK_SAFE']
  }
];

var ERP_B06J37_06_BASELINE_HEADERS = [
  'baselineId',
  'build',
  'baselineStatus',
  'moduleCode',
  'moduleRole',
  'currentStatus',
  'setupDbId',
  'setupDbName',
  'configSheetName',
  'masterId',
  'masterName',
  'coreSheetsOk',
  'independentVendorDbBlocked',
  'vendorAsBranchUserGroup',
  'requiredBuilds',
  'notes',
  'createdAt',
  'createdBy'
];

function erpB06J37_06_dryRun() {
  return erpB06J37_06_run_(true);
}

function erpB06J37_06_confirmed() {
  return erpB06J37_06_run_(false);
}

function erpB06J37_06_run_(dryRun) {
  var result = {
    ok: true,
    build: ERP_B06J37_06_BUILD,
    dryRun: dryRun === true,
    checkedAt: new Date().toISOString(),
    fatal: [],
    warnings: [],
    baselineStatus: 'MODULE_SPLIT_OPERATION_BASELINE_READY',
    checks: {},
    baselineRows: [],
    safety: {
      baselineRecordOnly: true,
      noBusinessDataMutation: true,
      noUiMutation: true,
      noPaymentExecution: true,
      noRecoveryExecution: true,
      noAutoRecalculation: true,
      noExternalAccountingTransfer: true,
      independentVendorDbBlocked: true,
      vendorIsBranchUserGroupInsideErp: true
    }
  };

  console.log('======================================================');
  console.log('[B06J37-06 MODULE SPLIT OPERATION BASELINE] START');
  console.log(JSON.stringify({ build: ERP_B06J37_06_BUILD, dryRun: result.dryRun }, null, 2));

  try {
    result.checks.setup = erpB06J37_06_checkSetup_();
    erpB06J37_06_collect_(result, 'setup', result.checks.setup);

    result.checks.master = erpB06J37_06_checkMaster_(result.checks.setup.configMap);
    erpB06J37_06_collect_(result, 'master', result.checks.master);

    result.checks.coreSheets = erpB06J37_06_checkCoreSheets_(result.checks.master.masterSpreadsheet);
    erpB06J37_06_collect_(result, 'coreSheets', result.checks.coreSheets);

    result.checks.policy = erpB06J37_06_policyCheck_(result.checks.setup.configMap);
    erpB06J37_06_collect_(result, 'policy', result.checks.policy);

    result.baselineRows = erpB06J37_06_buildBaselineRows_(result);

    if (!result.dryRun && result.fatal.length === 0) {
      erpB06J37_06_writeBaseline_(result.checks.master.masterSpreadsheet, result.baselineRows);
      result.written = true;
      result.baselineSheet = ERP_B06J37_06_BASELINE_SHEET;
      result.message = '세 모듈 운영 기준본 기록 완료';
    } else {
      result.written = false;
      result.baselineSheet = ERP_B06J37_06_BASELINE_SHEET;
      result.message = result.dryRun ? 'DRY_RUN: 기준본 기록 예정' : 'fatal 존재로 기록 중단';
    }
  } catch (e) {
    result.fatal.push('B06J37-06 기준본 처리 예외: ' + String(e && e.message ? e.message : e));
    result.exceptionStack = String(e && e.stack ? e.stack : '');
  }

  result.fatalCount = result.fatal.length;
  result.warningCount = result.warnings.length;
  result.ok = result.fatalCount === 0;

  if (result.checks.master && result.checks.master.masterSpreadsheet) {
    result.checks.master.masterSpreadsheetName = result.checks.master.masterSpreadsheet.getName();
    delete result.checks.master.masterSpreadsheet;
  }

  console.log('[B06J37-06 MODULE SPLIT OPERATION BASELINE] RESULT');
  console.log(JSON.stringify(result, null, 2));
  console.log('======================================================');

  return result;
}

function erpB06J37_06_checkSetup_() {
  var ss = SpreadsheetApp.openById(ERP_B06J37_06_SETUP_DB_ID);
  var sh = ss.getSheetByName(ERP_B06J37_06_CONFIG_SHEET_NAME);
  var fatal = [];
  var warnings = [];
  var configMap = {};

  if (!sh) {
    fatal.push('SystemConfig 시트를 찾지 못했습니다.');
    return { ok:false, fatal:fatal, warnings:warnings, configMap:configMap };
  }

  var values = sh.getDataRange().getValues();
  if (!values || values.length < 2) {
    fatal.push('SystemConfig 데이터가 비어 있습니다.');
    return { ok:false, fatal:fatal, warnings:warnings, configMap:configMap };
  }

  var headers = values[0].map(function(h){ return String(h || '').trim(); });
  var lower = headers.map(function(h){ return h.toLowerCase(); });

  var keyIdx = lower.indexOf('key');
  if (keyIdx < 0) keyIdx = lower.indexOf('configkey');
  if (keyIdx < 0) keyIdx = lower.indexOf('name');
  if (keyIdx < 0) keyIdx = 0;

  var valIdx = lower.indexOf('value');
  if (valIdx < 0) valIdx = lower.indexOf('configvalue');
  if (valIdx < 0) valIdx = lower.indexOf('spreadsheetid');
  if (valIdx < 0) valIdx = 1;

  for (var r = 1; r < values.length; r++) {
    var k = String(values[r][keyIdx] || '').trim();
    var v = String(values[r][valIdx] || '').trim();
    if (k) configMap[k] = v;
  }

  return {
    ok: true,
    fatal: fatal,
    warnings: warnings,
    setupDbId: ERP_B06J37_06_SETUP_DB_ID,
    setupDbName: ss.getName(),
    configSheetName: ERP_B06J37_06_CONFIG_SHEET_NAME,
    configCount: Object.keys(configMap).length,
    configMap: configMap
  };
}

function erpB06J37_06_checkMaster_(configMap) {
  var fatal = [];
  var warnings = [];
  var keys = ['FEELHAUS_DB_MASTER_ID','FEELHAUS_DB_MASTER','MASTER_SPREADSHEET_ID','MASTER_DB_ID','DB_MASTER_ID','SPREADSHEET_ID'];
  var raw = '';
  var usedKey = '';

  for (var i = 0; i < keys.length; i++) {
    if (configMap && configMap[keys[i]]) {
      raw = String(configMap[keys[i]]).trim();
      usedKey = keys[i];
      break;
    }
  }

  if (!raw) {
    fatal.push('MASTER ID를 SystemConfig에서 찾지 못했습니다.');
    return { ok:false, fatal:fatal, warnings:warnings, usedKey:usedKey, masterId:'' };
  }

  var masterId = erpB06J37_06_extractSpreadsheetId_(raw);
  var master = SpreadsheetApp.openById(masterId);

  return {
    ok: true,
    fatal: fatal,
    warnings: warnings,
    usedKey: usedKey,
    masterId: masterId,
    masterName: master.getName(),
    masterSpreadsheet: master
  };
}

function erpB06J37_06_checkCoreSheets_(master) {
  var specs = [
    ['ERP_행사관리', ['eventId','status','statusReason','createdAt','createdBy','updatedAt','updatedBy']],
    ['ERP_업체관리', ['vendorId','status','statusReason','createdAt','createdBy','updatedAt','updatedBy']],
    ['ERP_고객관리', ['customerId','eventId','vendorId','status','statusReason','createdAt','createdBy','updatedAt','updatedBy']],
    ['ERP_행사업체연결', ['eventVendorId','eventId','vendorId','status','statusReason','createdAt','createdBy','updatedAt','updatedBy']],
    ['ERP_CoreLog', ['logId','build','moduleCode','actionCode','targetSheet','targetId','actor','actedAt','snapshot','status','statusReason','createdAt','createdBy']]
  ];

  var fatal = [];
  var warnings = [];
  var sheets = [];

  specs.forEach(function(pair) {
    var sheetName = pair[0];
    var required = pair[1];
    var sh = master.getSheetByName(sheetName);
    if (!sh) {
      fatal.push('필수 시트 없음: ' + sheetName);
      sheets.push({ sheetName: sheetName, exists:false, missingHeaders:required });
      return;
    }

    var headers = erpB06J37_06_getHeaders_(sh);
    var missing = required.filter(function(h){ return headers.indexOf(h) < 0; });
    if (missing.length) fatal.push(sheetName + ' 누락 헤더: ' + missing.join(', '));

    sheets.push({
      sheetName: sheetName,
      exists: true,
      lastRow: sh.getLastRow(),
      lastCol: sh.getLastColumn(),
      missingHeaders: missing
    });
  });

  return {
    ok: fatal.length === 0,
    fatal: fatal,
    warnings: warnings,
    sheets: sheets
  };
}

function erpB06J37_06_policyCheck_(configMap) {
  var fatal = [];
  var warnings = [];
  var suspicious = [];

  Object.keys(configMap || {}).forEach(function(k) {
    var u = String(k || '').toUpperCase();
    if (
      u.indexOf('VENDOR_DB') >= 0 ||
      u.indexOf('VENDOR_SPREADSHEET') >= 0 ||
      u.indexOf('PARTNER_DB') >= 0 ||
      u.indexOf('BRANCH_DB') >= 0
    ) {
      suspicious.push({ key:k, value:configMap[k] });
    }
  });

  if (suspicious.length) {
    warnings.push('업체 독립 DB로 오해될 수 있는 설정 키가 있습니다. 운영 연결 사용 여부 확인 필요.');
  }

  return {
    ok: true,
    fatal: fatal,
    warnings: warnings,
    independentVendorDbBlocked: true,
    vendorAsBranchUserGroup: true,
    systemConfigAsSource: true,
    masterAsOperationHub: true,
    suspiciousConfigKeys: suspicious,
    fixedPrinciple: '업체는 별도 앱이 아니라 ERP 내부 지점형 사용자 그룹입니다.'
  };
}

function erpB06J37_06_buildBaselineRows_(result) {
  var now = new Date();
  var actor = erpB06J37_06_actor_();
  var setup = result.checks.setup || {};
  var master = result.checks.master || {};
  var coreSheetsOk = result.checks.coreSheets && result.checks.coreSheets.ok ? 'Y' : 'N';

  return ERP_B06J37_06_MODULES.map(function(m) {
    return {
      baselineId: erpB06J37_06_generateId_('BASE'),
      build: ERP_B06J37_06_BUILD,
      baselineStatus: result.baselineStatus,
      moduleCode: m.moduleCode,
      moduleRole: m.role,
      currentStatus: m.currentStatus,
      setupDbId: setup.setupDbId || ERP_B06J37_06_SETUP_DB_ID,
      setupDbName: setup.setupDbName || '',
      configSheetName: setup.configSheetName || ERP_B06J37_06_CONFIG_SHEET_NAME,
      masterId: master.masterId || '',
      masterName: master.masterName || '',
      coreSheetsOk: coreSheetsOk,
      independentVendorDbBlocked: 'Y',
      vendorAsBranchUserGroup: 'Y',
      requiredBuilds: m.requiredBuilds.join(', '),
      notes: 'B06J37 모듈 분리 운영 기준본. 기존 기능 삭제 금지. FEELHAUS_SETUP_DB/SystemConfig + FEELHAUS_DB_MASTER 기준 유지.',
      createdAt: now,
      createdBy: actor
    };
  });
}

function erpB06J37_06_writeBaseline_(master, baselineRows) {
  var sh = master.getSheetByName(ERP_B06J37_06_BASELINE_SHEET);
  if (!sh) {
    sh = master.insertSheet(ERP_B06J37_06_BASELINE_SHEET);
    sh.getRange(1, 1, 1, ERP_B06J37_06_BASELINE_HEADERS.length).setValues([ERP_B06J37_06_BASELINE_HEADERS]);
  } else {
    var current = erpB06J37_06_getHeaders_(sh);
    var missing = ERP_B06J37_06_BASELINE_HEADERS.filter(function(h){ return current.indexOf(h) < 0; });
    if (missing.length) {
      sh.getRange(1, sh.getLastColumn() + 1, 1, missing.length).setValues([missing]);
    }
  }

  var map = erpB06J37_06_headerMap_(sh);
  baselineRows.forEach(function(obj) {
    var row = new Array(sh.getLastColumn()).fill('');
    ERP_B06J37_06_BASELINE_HEADERS.forEach(function(h) {
      if (map[h]) row[map[h] - 1] = obj[h] || '';
    });
    sh.appendRow(row);
  });
}

function erpB06J37_06_headerMap_(sh) {
  var headers = erpB06J37_06_getHeaders_(sh);
  var map = {};
  headers.forEach(function(h, i) {
    if (h) map[h] = i + 1;
  });
  return map;
}

function erpB06J37_06_getHeaders_(sh) {
  if (!sh || sh.getLastRow() < 1 || sh.getLastColumn() < 1) return [];
  return sh.getRange(1, 1, 1, sh.getLastColumn()).getValues()[0].map(function(h) {
    return String(h || '').trim();
  });
}

function erpB06J37_06_extractSpreadsheetId_(raw) {
  var s = String(raw || '').trim();
  var m = s.match(/\/d\/([a-zA-Z0-9-_]+)/);
  return m && m[1] ? m[1] : s;
}

function erpB06J37_06_generateId_(prefix) {
  var p = String(prefix || 'ID').replace(/[^A-Z0-9_-]/gi, '').toUpperCase();
  var ts = Utilities.formatDate(new Date(), Session.getScriptTimeZone(), 'yyyyMMddHHmmss');
  var rand = Math.floor(Math.random() * 9000) + 1000;
  return p + '-' + ts + '-' + rand;
}

function erpB06J37_06_actor_() {
  try {
    return Session.getActiveUser().getEmail() || 'UNKNOWN_USER';
  } catch (e) {
    return 'UNKNOWN_USER';
  }
}

function erpB06J37_06_collect_(result, label, check) {
  if (!check) return;
  if (check.fatal && check.fatal.length) {
    result.fatal = result.fatal.concat(check.fatal.map(function(x){ return label + ': ' + x; }));
  }
  if (check.warnings && check.warnings.length) {
    result.warnings = result.warnings.concat(check.warnings.map(function(x){ return label + ': ' + x; }));
  }
}
