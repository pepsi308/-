/**
 * build: ERP_B06J37_01_MODULE_SPLIT_BASELINE_CHECK_SAFE
 * purpose:
 *  - ERP_CORE / ERP_ADMIN / ERP_FIELD 모듈 분리 기준점검
 *  - 업체 독립 앱/독립 DB 구조 차단 확인
 *  - FEELHAUS_SETUP_DB > SystemConfig 자동 읽기 확인
 *  - FEELHAUS_DB_MASTER 자동 연결 확인
 *  - 공통 ID / 핵심 시트 / 핵심 헤더 기준 확인
 *
 * apply:
 *  - 이 파일은 기존 파일에 붙이지 말고 새 파일로 추가합니다.
 *  - 권장 파일명: ERP_ModuleSplit_B06J37_01.gs
 *
 * standard auto:
 *  - erpB06J37_01_autoRunSafe()
 */

var ERP_B06J37_01_BUILD = 'ERP_B06J37_01_MODULE_SPLIT_BASELINE_CHECK_SAFE';

var ERP_B06J37_01_SETUP_DB_ID = '17VMSpgSZCvIrUlgcw8yCNcnl8WQWo2IcRf5tDCcuJGM';
var ERP_B06J37_01_CONFIG_SHEET_NAME = 'SystemConfig';

var ERP_B06J37_01_ALLOWED_MODULES = ['ERP_CORE', 'ERP_ADMIN', 'ERP_FIELD'];

var ERP_B06J37_01_CORE_SHEETS = [
  {
    sheetName: 'ERP_행사관리',
    requiredHeaders: ['eventId','status','statusReason','createdAt','createdBy','updatedAt','updatedBy']
  },
  {
    sheetName: 'ERP_업체관리',
    requiredHeaders: ['vendorId','status','statusReason','createdAt','createdBy','updatedAt','updatedBy']
  },
  {
    sheetName: 'ERP_고객관리',
    requiredHeaders: ['customerId','eventId','vendorId','status','statusReason','createdAt','createdBy','updatedAt','updatedBy']
  },
  {
    sheetName: 'ERP_행사업체연결',
    requiredHeaders: ['eventVendorId','eventId','vendorId','status','statusReason','createdAt','createdBy','updatedAt','updatedBy']
  }
];

var ERP_B06J37_01_COMMON_ID_HEADERS = [
  'eventId',
  'vendorId',
  'customerId',
  'saleId',
  'contractId',
  'installId',
  'asId',
  'documentId',
  'status',
  'statusReason',
  'createdAt',
  'createdBy',
  'updatedAt',
  'updatedBy'
];

function erpB06J37_01_autoRunSafe(moduleCode) {
  var result = {
    ok: true,
    build: ERP_B06J37_01_BUILD,
    checkedAt: new Date().toISOString(),
    moduleCode: moduleCode || erpB06J37_01_guessModuleCode_(),
    scriptId: erpB06J37_01_getScriptId_(),
    fatal: [],
    warnings: [],
    checks: {},
    safety: erpB06J37_01_safetyFlags_()
  };

  console.log('======================================================');
  console.log('[B06J37-01 MODULE SPLIT BASELINE CHECK] START');
  console.log(JSON.stringify({
    build: ERP_B06J37_01_BUILD,
    moduleCode: result.moduleCode,
    scriptId: result.scriptId
  }, null, 2));

  try {
    result.checks.moduleCodeAllowed = erpB06J37_01_checkModuleCode_(result.moduleCode);
    erpB06J37_01_collect_(result, 'moduleCodeAllowed', result.checks.moduleCodeAllowed);

    result.checks.setupDb = erpB06J37_01_checkSetupDb_();
    erpB06J37_01_collect_(result, 'setupDb', result.checks.setupDb);

    result.checks.masterDb = erpB06J37_01_checkMasterDb_(result.checks.setupDb.configMap);
    erpB06J37_01_collect_(result, 'masterDb', result.checks.masterDb);

    result.checks.coreSheets = erpB06J37_01_checkCoreSheets_(result.checks.masterDb.masterSpreadsheet);
    erpB06J37_01_collect_(result, 'coreSheets', result.checks.coreSheets);

    result.checks.independentDbGuard = erpB06J37_01_checkIndependentDbGuard_(result.checks.setupDb.configMap);
    erpB06J37_01_collect_(result, 'independentDbGuard', result.checks.independentDbGuard);

    result.checks.roleSplitPolicy = erpB06J37_01_checkRoleSplitPolicy_(result.moduleCode);
    erpB06J37_01_collect_(result, 'roleSplitPolicy', result.checks.roleSplitPolicy);

    result.checks.requiredCommonIds = erpB06J37_01_checkCommonIds_();
    erpB06J37_01_collect_(result, 'requiredCommonIds', result.checks.requiredCommonIds);

  } catch (e) {
    result.ok = false;
    result.fatal.push('B06J37-01 점검 중 예외: ' + String(e && e.message ? e.message : e));
    result.exceptionStack = String(e && e.stack ? e.stack : '');
  }

  result.fatalCount = result.fatal.length;
  result.warningCount = result.warnings.length;
  result.ok = result.fatalCount === 0;

  // Spreadsheet 객체는 로그 직렬화에서 제외
  if (result.checks.masterDb && result.checks.masterDb.masterSpreadsheet) {
    result.checks.masterDb.masterSpreadsheetName = result.checks.masterDb.masterSpreadsheet.getName();
    delete result.checks.masterDb.masterSpreadsheet;
  }

  console.log('[B06J37-01 MODULE SPLIT BASELINE CHECK] RESULT');
  console.log(JSON.stringify(result, null, 2));
  console.log('======================================================');

  return result;
}

function erpB06J37_01_checkModuleCode_(moduleCode) {
  var ok = ERP_B06J37_01_ALLOWED_MODULES.indexOf(String(moduleCode || '').trim()) >= 0;
  return {
    ok: ok,
    fatal: ok ? [] : ['moduleCode가 허용값이 아닙니다. ERP_CORE / ERP_ADMIN / ERP_FIELD 중 하나여야 합니다.'],
    warnings: [],
    moduleCode: moduleCode,
    allowedModules: ERP_B06J37_01_ALLOWED_MODULES
  };
}

function erpB06J37_01_checkSetupDb_() {
  var ss = SpreadsheetApp.openById(ERP_B06J37_01_SETUP_DB_ID);
  var sh = ss.getSheetByName(ERP_B06J37_01_CONFIG_SHEET_NAME);

  var fatal = [];
  var warnings = [];
  var configMap = {};

  if (!sh) {
    fatal.push('FEELHAUS_SETUP_DB에서 SystemConfig 시트를 찾지 못했습니다.');
    return {
      ok: false,
      fatal: fatal,
      warnings: warnings,
      setupDbId: ERP_B06J37_01_SETUP_DB_ID,
      configSheetName: ERP_B06J37_01_CONFIG_SHEET_NAME,
      configMap: configMap
    };
  }

  var values = sh.getDataRange().getValues();
  if (!values || values.length < 2) {
    fatal.push('SystemConfig 데이터가 비어 있습니다.');
    return {
      ok: false,
      fatal: fatal,
      warnings: warnings,
      setupDbId: ERP_B06J37_01_SETUP_DB_ID,
      configSheetName: ERP_B06J37_01_CONFIG_SHEET_NAME,
      configMap: configMap
    };
  }

  var headers = values[0].map(function(h) { return String(h || '').trim(); });
  var lower = headers.map(function(h) { return h.toLowerCase(); });

  var keyIdx = lower.indexOf('key');
  if (keyIdx < 0) keyIdx = lower.indexOf('configkey');
  if (keyIdx < 0) keyIdx = lower.indexOf('name');
  if (keyIdx < 0) keyIdx = 0;

  var valIdx = lower.indexOf('value');
  if (valIdx < 0) valIdx = lower.indexOf('configvalue');
  if (valIdx < 0) valIdx = lower.indexOf('spreadsheetid');
  if (valIdx < 0) valIdx = 1;

  for (var r = 1; r < values.length; r++) {
    var k = String(values[r][keyIdx] || '').trim();
    var v = String(values[r][valIdx] || '').trim();
    if (k) configMap[k] = v;
  }

  return {
    ok: true,
    fatal: fatal,
    warnings: warnings,
    setupDbId: ERP_B06J37_01_SETUP_DB_ID,
    setupDbName: ss.getName(),
    configSheetName: ERP_B06J37_01_CONFIG_SHEET_NAME,
    configCount: Object.keys(configMap).length,
    configMap: configMap
  };
}

function erpB06J37_01_checkMasterDb_(configMap) {
  var fatal = [];
  var warnings = [];

  var candidateKeys = [
    'FEELHAUS_DB_MASTER_ID',
    'FEELHAUS_DB_MASTER',
    'MASTER_SPREADSHEET_ID',
    'MASTER_DB_ID',
    'DB_MASTER_ID'
  ];

  var raw = '';
  var usedKey = '';

  for (var i = 0; i < candidateKeys.length; i++) {
    var k = candidateKeys[i];
    if (configMap && configMap[k]) {
      raw = String(configMap[k]).trim();
      usedKey = k;
      break;
    }
  }

  if (!raw) {
    fatal.push('SystemConfig에서 FEELHAUS_DB_MASTER ID를 찾지 못했습니다.');
    return {
      ok: false,
      fatal: fatal,
      warnings: warnings,
      usedKey: usedKey,
      rawValue: raw,
      masterId: ''
    };
  }

  var m = raw.match(/\/d\/([a-zA-Z0-9-_]+)/);
  var masterId = m && m[1] ? m[1] : raw;

  var masterSpreadsheet = SpreadsheetApp.openById(masterId);

  return {
    ok: true,
    fatal: fatal,
    warnings: warnings,
    usedKey: usedKey,
    rawValue: raw,
    masterId: masterId,
    masterName: masterSpreadsheet.getName(),
    masterSpreadsheet: masterSpreadsheet
  };
}

function erpB06J37_01_checkCoreSheets_(masterSpreadsheet) {
  var fatal = [];
  var warnings = [];
  var sheetChecks = [];

  ERP_B06J37_01_CORE_SHEETS.forEach(function(spec) {
    var sh = masterSpreadsheet.getSheetByName(spec.sheetName);
    if (!sh) {
      fatal.push('MASTER 필수 시트 누락: ' + spec.sheetName);
      sheetChecks.push({
        sheetName: spec.sheetName,
        exists: false,
        missingHeaders: spec.requiredHeaders
      });
      return;
    }

    var headers = erpB06J37_01_getHeaders_(sh);
    var missing = spec.requiredHeaders.filter(function(h) {
      return headers.indexOf(h) < 0;
    });

    if (missing.length) {
      fatal.push(spec.sheetName + ' 필수 헤더 누락: ' + missing.join(', '));
    }

    sheetChecks.push({
      sheetName: spec.sheetName,
      exists: true,
      lastRow: sh.getLastRow(),
      lastCol: sh.getLastColumn(),
      missingHeaders: missing
    });
  });

  return {
    ok: fatal.length === 0,
    fatal: fatal,
    warnings: warnings,
    sheetChecks: sheetChecks
  };
}

function erpB06J37_01_checkIndependentDbGuard_(configMap) {
  var fatal = [];
  var warnings = [];
  var suspicious = [];

  Object.keys(configMap || {}).forEach(function(k) {
    var key = String(k || '').toUpperCase();
    var val = String(configMap[k] || '').trim();

    // 업체별 독립 DB를 암시하는 설정 키는 금지 후보로 잡습니다.
    if (
      key.indexOf('VENDOR_DB') >= 0 ||
      key.indexOf('VENDOR_SPREADSHEET') >= 0 ||
      key.indexOf('PARTNER_DB') >= 0 ||
      key.indexOf('BRANCH_DB') >= 0
    ) {
      suspicious.push({ key: k, value: val });
    }
  });

  if (suspicious.length) {
    warnings.push('업체/지점 독립 DB로 오해될 수 있는 설정 키가 있습니다. 실제 운영 연결로 사용 중인지 확인 필요.');
  }

  return {
    ok: true,
    fatal: fatal,
    warnings: warnings,
    independentVendorDbBlocked: true,
    suspiciousConfigKeys: suspicious,
    message: '업체는 ERP 내부 지점형 사용자 그룹이며, 업체별 독립 DB 구조는 금지입니다.'
  };
}

function erpB06J37_01_checkRoleSplitPolicy_(moduleCode) {
  var fatal = [];
  var warnings = [];

  var policy = {
    ERP_CORE: {
      role: '공통 엔진 / 설정 / MASTER 연결 / 공통 ID / 헤더맵 / 공통 저장조회',
      screenScope: '공통/백엔드 중심',
      mustNotOwnIndependentDb: true
    },
    ERP_ADMIN: {
      role: '본사 관리자 화면 / 행사 / 업체 / 승인 / 정산 / 통제',
      screenScope: '본사 HQ 화면',
      mustNotOwnIndependentDb: true
    },
    ERP_FIELD: {
      role: '현장/업체/직원용 화면 / 판매 / 계약 / 설치 / A/S / 조회',
      screenScope: 'vendorId / eventId / roleCode 기준 화면 분기',
      mustNotOwnIndependentDb: true
    }
  };

  var p = policy[moduleCode] || null;
  if (!p) {
    fatal.push('모듈 정책을 찾을 수 없습니다: ' + moduleCode);
  }

  return {
    ok: fatal.length === 0,
    fatal: fatal,
    warnings: warnings,
    moduleCode: moduleCode,
    policy: p,
    allPolicies: policy
  };
}

function erpB06J37_01_checkCommonIds_() {
  return {
    ok: true,
    fatal: [],
    warnings: [],
    commonIdHeaders: ERP_B06J37_01_COMMON_ID_HEADERS,
    connectionRule: '모든 연결은 이름/전화번호/문서명이 아니라 공통 ID 기준입니다.',
    headerRule: '다른 프로젝트는 열 위치가 아니라 헤더명으로 자동 추적해야 합니다.'
  };
}

function erpB06J37_01_collect_(result, label, check) {
  if (!check) return;
  if (check.fatal && check.fatal.length) {
    result.fatal = result.fatal.concat(check.fatal.map(function(x) {
      return label + ': ' + x;
    }));
  }
  if (check.warnings && check.warnings.length) {
    result.warnings = result.warnings.concat(check.warnings.map(function(x) {
      return label + ': ' + x;
    }));
  }
}

function erpB06J37_01_getHeaders_(sh) {
  if (!sh || sh.getLastRow() < 1 || sh.getLastColumn() < 1) return [];
  return sh.getRange(1, 1, 1, sh.getLastColumn()).getValues()[0].map(function(h) {
    return String(h || '').trim();
  });
}

function erpB06J37_01_guessModuleCode_() {
  try {
    var name = DriveApp.getFileById(ScriptApp.getScriptId()).getName();
    var upper = String(name || '').toUpperCase();
    if (upper.indexOf('ERP_CORE') >= 0) return 'ERP_CORE';
    if (upper.indexOf('ERP_ADMIN') >= 0) return 'ERP_ADMIN';
    if (upper.indexOf('ERP_FIELD') >= 0) return 'ERP_FIELD';
    if (upper.indexOf('CORE') >= 0) return 'ERP_CORE';
    if (upper.indexOf('ADMIN') >= 0) return 'ERP_ADMIN';
    if (upper.indexOf('FIELD') >= 0) return 'ERP_FIELD';
  } catch (e) {}
  return 'ERP_ADMIN';
}

function erpB06J37_01_getScriptId_() {
  try {
    return ScriptApp.getScriptId();
  } catch (e) {
    return '';
  }
}

function erpB06J37_01_safetyFlags_() {
  return {
    baselineCheckOnly: true,
    noSheetMutation: true,
    noBusinessDataMutation: true,
    noUiMutation: true,
    noPaymentExecution: true,
    noRecoveryExecution: true,
    noAutoRecalculation: true,
    noExternalAccountingTransfer: true,
    independentVendorDbBlocked: true,
    vendorIsBranchUserGroupInsideErp: true
  };
}
