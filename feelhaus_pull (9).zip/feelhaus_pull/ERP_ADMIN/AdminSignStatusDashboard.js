/**
 * FEELHAUS ERP_ADMIN SIGN 연계 081~160 안전 조회 패치
 * Build: ERP_ADMIN_SIGN_B06J41_081_160_ADMIN_DOCUMENT_CONTROL_SAFE_UPLOAD
 * 범위: 본사 SIGN 문서 상태 요약 / 재오픈 후보 / 정산 인계 후보 / CONTROL 점검 안내
 * 원칙: 읽기 전용, 헤더 자동 추가 금지, 실제 재오픈/정산/외부연동/지급 실행 금지
 */
var ERP_ADMIN_SIGN_B06J41_081_160_BUILD = 'ERP_ADMIN_SIGN_B06J41_081_160_FORCE_ROUTE_CLEAN_V3';

function erpAdminB06J41_081_160_renderSignAdminDashboardHtml(ctx) {
  ctx = ctx || {};
  var vm = erpAdminB06J41_081_160_buildDashboardViewModel_(ctx);
  var t = HtmlService.createTemplateFromFile('AdminSignStatusDashboardPage');
  t.modelJson = JSON.stringify(vm);
  return t.evaluate()
    .setTitle('FEELHAUS ERP_ADMIN SIGN 문서 현황')
    .setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL);
}

function erpAdminB06J41_081_160_buildDashboardViewModel_(ctx) {
  ctx = ctx || {};
  var eventId = adminS_(ctx.eventId || '');
  var vendorId = adminS_(ctx.vendorId || '');
  var status = adminS_(ctx.status || '');
  var limit = Math.min(Math.max(Number(ctx.limit || 200), 1), 500);
  var now = new Date().toISOString();

  var config = adminGetSystemConfigSafe_();
  var master = adminOpenMasterDbSafe_();
  var vm = {
    ok: false,
    build: ERP_ADMIN_SIGN_B06J41_081_160_BUILD,
    generatedAt: now,
    mode: 'ADMIN_READ_ONLY_SAFE',
    filters: { eventId: eventId, vendorId: vendorId, status: status, limit: limit },
    config: { ok: config.ok, keyCount: config.keyCount || 0, message: config.message },
    master: { ok: master.ok, id: master.id || '', message: master.message },
    summary: erpAdminB06J41_081_160_emptySummary_(),
    documents: [],
    reopenCandidates: [],
    settlementHandoff: { summary: {}, rows: [], sourceSheet: '' },
    control: erpAdminB06J41_081_160_controlStatus_(),
    blocks: erpAdminB06J41_081_160_blocks_(),
    warnings: []
  };

  if (!config.ok) vm.warnings.push('SystemConfig 확인 필요: ' + config.message);
  if (!master.ok) {
    vm.warnings.push('FEELHAUS_DB_MASTER 연결 필요: ' + master.message);
    return vm;
  }

  var docPack = erpAdminB06J41_081_160_readDocuments_(master.ss, { eventId: eventId, vendorId: vendorId, status: status, limit: limit });
  vm.documents = docPack.rows;
  vm.summary = docPack.summary;
  vm.summary.sourceSheet = docPack.sourceSheet;
  vm.reopenCandidates = erpAdminB06J41_081_160_buildReopenCandidates_(docPack.rows);
  vm.settlementHandoff = erpAdminB06J41_081_160_readSettlementHandoff_(master.ss, { eventId: eventId, vendorId: vendorId, limit: 100 });
  vm.ok = true;
  return vm;
}

function erpAdminB06J41_081_160_readDocuments_(ss, opt) {
  opt = opt || {};
  var names = ['SIGN_Documents', 'SIGN_Document_Master', 'Documents', 'Document_Master', 'SIGN_QR_Documents'];
  var rows = [];
  var usedSheet = '';
  var summary = erpAdminB06J41_081_160_emptySummary_();
  var limit = opt.limit || 200;
  for (var i = 0; i < names.length && rows.length < limit; i++) {
    var sh = ss.getSheetByName(names[i]);
    if (!sh) continue;
    var table = adminReadTable_(sh);
    if (!table.rows.length) { if (!usedSheet) usedSheet = names[i]; continue; }
    usedSheet = names[i];
    for (var r = 0; r < table.rows.length && rows.length < limit; r++) {
      var raw = table.rows[r];
      var item = erpAdminB06J41_081_160_normalizeDocument_(raw, names[i], r + 2);
      if (opt.eventId && item.eventId !== opt.eventId) continue;
      if (opt.vendorId && item.vendorId !== opt.vendorId) continue;
      if (opt.status) {
        var hay = [item.signStatus, item.pdfStatus, item.archiveStatus, item.documentStatus, item.status].join(' ').toUpperCase();
        if (hay.indexOf(adminS_(opt.status).toUpperCase()) < 0) continue;
      }
      rows.push(item);
      erpAdminB06J41_081_160_countDocument_(summary, item);
    }
  }
  summary.total = rows.length;
  return { rows: rows, summary: summary, sourceSheet: usedSheet };
}

function erpAdminB06J41_081_160_normalizeDocument_(raw, sourceSheet, rowNumber) {
  var signStatus = adminS_(raw.signStatus || raw.signatureStatus || raw.status || raw.documentStatus || '');
  var pdfStatus = adminS_(raw.pdfStatus || raw.pdfCreateStatus || raw.pdfGenerationStatus || raw.pdfState || '');
  var archiveStatus = adminS_(raw.archiveStatus || raw.storageStatus || raw.storeStatus || raw.status || raw.documentStatus || '');
  var status = adminS_(raw.status || raw.documentStatus || '');
  var lockedText = [archiveStatus, status, raw.locked, raw.isLocked, raw.lockStatus].map(adminS_).join(' ').toUpperCase();
  var locked = lockedText.indexOf('ARCHIVED') >= 0 || lockedText.indexOf('LOCK') >= 0 || lockedText.indexOf('보관') >= 0 || adminS_(raw.locked).toLowerCase() === 'true' || adminS_(raw.isLocked).toLowerCase() === 'true';
  return {
    sourceSheet: sourceSheet,
    rowNumber: rowNumber,
    eventId: adminS_(raw.eventId || raw.eventID || raw.행사ID),
    vendorId: adminS_(raw.vendorId || raw.vendorID || raw.업체ID),
    customerId: adminS_(raw.customerId || raw.memberId || raw.고객ID),
    saleId: adminS_(raw.saleId || raw.salesId || raw.판매ID),
    contractId: adminS_(raw.contractId || raw.계약ID),
    documentId: adminS_(raw.documentId || raw.docId || raw.id || raw.문서ID),
    documentType: adminS_(raw.documentType || raw.templateCode || raw.type || ''),
    signStatus: signStatus || 'UNKNOWN',
    pdfStatus: pdfStatus || 'UNKNOWN',
    archiveStatus: archiveStatus || 'UNKNOWN',
    documentStatus: status || 'UNKNOWN',
    status: status || 'UNKNOWN',
    signUrl: adminS_(raw.signUrl || raw.signURL || raw.url || ''),
    qrUrl: adminS_(raw.qrUrl || raw.qrURL || ''),
    pdfUrl: adminS_(raw.pdfUrl || raw.pdfFileUrl || raw.pdfLink || raw.fileUrl || ''),
    createdAt: adminS_(raw.createdAt || raw.requestedAt || ''),
    updatedAt: adminS_(raw.updatedAt || raw.signedAt || ''),
    locked: locked
  };
}

function erpAdminB06J41_081_160_emptySummary_() {
  return {
    total: 0,
    signPending: 0,
    signCompleted: 0,
    pdfPending: 0,
    pdfCompleted: 0,
    archived: 0,
    locked: 0,
    draft: 0,
    active: 0,
    unknown: 0,
    sourceSheet: ''
  };
}

function erpAdminB06J41_081_160_countDocument_(summary, item) {
  var sign = adminS_(item.signStatus).toUpperCase();
  var pdf = adminS_(item.pdfStatus).toUpperCase();
  var arch = adminS_(item.archiveStatus).toUpperCase();
  var st = adminS_(item.status || item.documentStatus).toUpperCase();
  if (sign.indexOf('COMPLETED') >= 0 || sign.indexOf('SIGNED') >= 0 || sign.indexOf('서명완료') >= 0) summary.signCompleted++; else summary.signPending++;
  if (pdf.indexOf('CREATED') >= 0 || pdf.indexOf('COMPLETED') >= 0 || pdf.indexOf('PDF완료') >= 0) summary.pdfCompleted++; else summary.pdfPending++;
  if (arch.indexOf('ARCHIVED') >= 0 || arch.indexOf('STORED') >= 0 || arch.indexOf('보관') >= 0) summary.archived++;
  if (item.locked) summary.locked++;
  if (st === 'DRAFT') summary.draft++;
  else if (st === 'ACTIVE') summary.active++;
  else if (!st || st === 'UNKNOWN') summary.unknown++;
}

function erpAdminB06J41_081_160_buildReopenCandidates_(docs) {
  var out = [];
  for (var i = 0; i < docs.length && out.length < 50; i++) {
    var d = docs[i];
    if (!d.locked && adminS_(d.archiveStatus).toUpperCase().indexOf('ARCHIVED') < 0) continue;
    out.push({
      documentId: d.documentId,
      contractId: d.contractId,
      saleId: d.saleId,
      customerId: d.customerId,
      eventId: d.eventId,
      vendorId: d.vendorId,
      archiveStatus: d.archiveStatus,
      locked: d.locked,
      action: 'REOPEN_APPROVAL_REQUIRED',
      message: '보관완료 문서는 일반 수정 불가. 재오픈은 본사 승인 절차 필요.'
    });
  }
  return out;
}

function erpAdminB06J41_081_160_readSettlementHandoff_(ss, opt) {
  opt = opt || {};
  var names = ['SIGN_SettlementHandoffQueue', 'ERP_SettlementHandoffQueue', 'SettlementHandoffQueue', 'ERP_정산인계큐', 'SIGN_SettlementQueue'];
  var rows = [];
  var sourceSheet = '';
  var limit = opt.limit || 100;
  var summary = { total: 0, pending: 0, active: 0, hold: 0, closed: 0, cancelled: 0, unknown: 0 };
  for (var i = 0; i < names.length && rows.length < limit; i++) {
    var sh = ss.getSheetByName(names[i]);
    if (!sh) continue;
    var table = adminReadTable_(sh);
    sourceSheet = names[i];
    for (var r = 0; r < table.rows.length && rows.length < limit; r++) {
      var raw = table.rows[r];
      var row = {
        sourceSheet: names[i],
        rowNumber: r + 2,
        eventId: adminS_(raw.eventId || raw.행사ID),
        vendorId: adminS_(raw.vendorId || raw.업체ID),
        customerId: adminS_(raw.customerId || raw.memberId || ''),
        saleId: adminS_(raw.saleId || ''),
        contractId: adminS_(raw.contractId || ''),
        documentId: adminS_(raw.documentId || raw.docId || ''),
        settlementId: adminS_(raw.settlementId || ''),
        status: adminS_(raw.status || raw.queueStatus || raw.handoffStatus || 'UNKNOWN'),
        statusReason: adminS_(raw.statusReason || raw.reason || raw.memo || ''),
        createdAt: adminS_(raw.createdAt || raw.requestedAt || '')
      };
      if (opt.eventId && row.eventId !== opt.eventId) continue;
      if (opt.vendorId && row.vendorId !== opt.vendorId) continue;
      rows.push(row);
      var st = row.status.toUpperCase();
      if (st === 'PENDING' || st === 'DRAFT' || st === 'READY') summary.pending++;
      else if (st === 'ACTIVE') summary.active++;
      else if (st === 'HOLD') summary.hold++;
      else if (st === 'CLOSED' || st === 'DONE') summary.closed++;
      else if (st === 'CANCELLED') summary.cancelled++;
      else summary.unknown++;
    }
  }
  summary.total = rows.length;
  return { summary: summary, rows: rows, sourceSheet: sourceSheet };
}

function erpAdminB06J41_081_160_blocks_() {
  return [
    erpAdminB06J41_081_160_blockReopenExecution_(),
    erpAdminB06J41_081_160_blockSettlementExecution_(),
    erpAdminB06J41_081_160_blockPaymentRecoveryOffset_(),
    erpAdminB06J41_081_160_blockExternalIntegration_(),
    erpAdminB06J41_081_160_blockHeaderAutoCreate_()
  ];
}

function erpAdminB06J41_081_160_blockReopenExecution_() { return { ok: false, blocked: true, action: 'REOPEN_EXECUTE', message: '재오픈 실행은 ERP_ADMIN 081~160에서 차단됩니다. 후보 조회/승인 필요 안내만 가능합니다.' }; }
function erpAdminB06J41_081_160_blockSettlementExecution_() { return { ok: false, blocked: true, action: 'SETTLEMENT_EXECUTE', message: '정산 실행은 ERP_ADMIN 081~160에서 차단됩니다. 정산 인계 후보 큐 조회만 가능합니다.' }; }
function erpAdminB06J41_081_160_blockPaymentRecoveryOffset_() { return { ok: false, blocked: true, action: 'PAYMENT_RECOVERY_OFFSET', message: '지급/환수/차감 실행은 차단됩니다.' }; }
function erpAdminB06J41_081_160_blockExternalIntegration_() { return { ok: false, blocked: true, action: 'EXTERNAL_INTEGRATION', message: '외부연동 실행은 차단됩니다.' }; }
function erpAdminB06J41_081_160_blockHeaderAutoCreate_() { return { ok: false, blocked: true, action: 'HEADER_AUTO_CREATE', message: '헤더 자동 추가는 차단됩니다.' }; }

function erpAdminB06J41_081_160_controlStatus_() {
  return {
    deployBlockedUntilChecklistPass: true,
    backupRequiredBeforeDeploy: true,
    rollbackReferenceRequired: true,
    controlCenterLinkRequired: true,
    message: 'CONTROL CENTER 배포/백업/롤백 체크리스트 통과 전 실행 기능은 열지 않습니다.'
  };
}


/**
 * ROUTE 반영 확인 전용 함수
 * 파일: AdminSignStatusDashboard.js
 * 목적: Code.js의 doGet route가 signAdmin 계열을 렌더 함수로 연결할 수 있는지 확인
 */
function erpAdminB06J41_081_160_routeSmokeTest() {
  var pages = ['signAdmin', 'signAdminStatus', 'adminSignStatus', 'signDocuments'];
  var result = {
    ok: true,
    build: (typeof ADMIN_BUILD_NO !== 'undefined') ? ADMIN_BUILD_NO : ERP_ADMIN_SIGN_B06J41_081_160_BUILD,
    moduleBuild: ERP_ADMIN_SIGN_B06J41_081_160_BUILD,
    fileName: 'AdminSignStatusDashboard.js',
    routeFile: 'Code.js',
    routes: pages,
    renderFunctionExists: typeof erpAdminB06J41_081_160_renderSignAdminDashboardHtml === 'function',
    selfTestExists: typeof erpAdminB06J41_081_160_selfTest === 'function',
    message: 'routeSmokeTest는 AdminSignStatusDashboard.js 안에 있습니다. build가 B06J41-081-160-FORCE-ROUTE-CLEAN-V3이면 V3 반영 상태입니다.'
  };
  Logger.log('[ERP_ADMIN SIGN 081-160 ROUTE SMOKE TEST] ' + JSON.stringify(result));
  return result;
}

function erpAdminB06J41_081_160_selfTest() {
  var missing = [];
  var required = [
    'erpAdminB06J41_081_160_renderSignAdminDashboardHtml',
    'erpAdminB06J41_081_160_buildDashboardViewModel_',
    'erpAdminB06J41_081_160_readDocuments_',
    'erpAdminB06J41_081_160_readSettlementHandoff_',
    'erpAdminB06J41_081_160_blockReopenExecution_',
    'erpAdminB06J41_081_160_blockSettlementExecution_',
    'erpAdminB06J41_081_160_blockExternalIntegration_'
  ];
  var fnMap = {
    erpAdminB06J41_081_160_renderSignAdminDashboardHtml: typeof erpAdminB06J41_081_160_renderSignAdminDashboardHtml === 'function',
    erpAdminB06J41_081_160_buildDashboardViewModel_: typeof erpAdminB06J41_081_160_buildDashboardViewModel_ === 'function',
    erpAdminB06J41_081_160_readDocuments_: typeof erpAdminB06J41_081_160_readDocuments_ === 'function',
    erpAdminB06J41_081_160_readSettlementHandoff_: typeof erpAdminB06J41_081_160_readSettlementHandoff_ === 'function',
    erpAdminB06J41_081_160_blockReopenExecution_: typeof erpAdminB06J41_081_160_blockReopenExecution_ === 'function',
    erpAdminB06J41_081_160_blockSettlementExecution_: typeof erpAdminB06J41_081_160_blockSettlementExecution_ === 'function',
    erpAdminB06J41_081_160_blockExternalIntegration_: typeof erpAdminB06J41_081_160_blockExternalIntegration_ === 'function'
  };
  for (var i = 0; i < required.length; i++) {
    if (!fnMap[required[i]]) missing.push(required[i]);
  }
  var probe = erpAdminB06J41_081_160_buildDashboardViewModel_({ limit: 20 });
  var result = {
    ok: missing.length === 0 && probe.master.ok,
    build: ERP_ADMIN_SIGN_B06J41_081_160_BUILD,
    fatal: missing.length ? ['requiredFunctions missing'] : [],
    warnings: probe.warnings || [],
    checks: {
      requiredFunctions: { ok: missing.length === 0, missing: missing },
      safety: {
        ok: true,
        readOnlyModule: true,
        noHeaderAutoCreate: true,
        noReopenExecution: true,
        noSettlementExecution: true,
        noPaymentRecoveryOffset: true,
        noExternalIntegration: true,
        vendorBranchUserGroup: true,
        note: '기존 Code.js의 QR 재서명 승인 관련 기존 함수는 삭제하지 않고 유지. 본 081~160 모듈은 조회/차단 전용.'
      },
      blocks: {
        reopen: erpAdminB06J41_081_160_blockReopenExecution_(),
        settlement: erpAdminB06J41_081_160_blockSettlementExecution_(),
        paymentRecoveryOffset: erpAdminB06J41_081_160_blockPaymentRecoveryOffset_(),
        external: erpAdminB06J41_081_160_blockExternalIntegration_(),
        headerAutoCreate: erpAdminB06J41_081_160_blockHeaderAutoCreate_()
      },
      dataProbe: {
        ok: probe.ok,
        documentCount: (probe.documents || []).length,
        settlementQueueCount: probe.settlementHandoff && probe.settlementHandoff.rows ? probe.settlementHandoff.rows.length : 0,
        sourceSheet: probe.summary && probe.summary.sourceSheet || ''
      }
    }
  };
  Logger.log('[ERP_ADMIN SIGN 081-160 SELFTEST] ' + JSON.stringify(result));
  return result;
}
