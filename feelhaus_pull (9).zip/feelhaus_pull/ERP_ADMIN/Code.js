/**
 * FEELHAUS ERP_ADMIN
 * Build: v64-B06J36-13
 * Purpose: 직원관리 / 권한 / 승인센터 전용 분리 앱 골격
 * Principle: FEELHAUS_SETUP_DB > SystemConfig 자동 읽기 → FEELHAUS_DB_MASTER 자동 연결
 */

var ADMIN_BUILD_NO = 'B06J41-081-160-FORCE-ROUTE-CLEAN-V3';
var ADMIN_BUILD_NAME = 'ERP_ADMIN_SIGN_B06J41_081_160_FORCE_ROUTE_CLEAN_V3';
var ADMIN_BUILD_TITLE = 'ERP_ADMIN SIGN 081~160 FORCE ROUTE CLEAN V3 / 본사 문서현황 전용 / 실행차단';
var ADMIN_SETUP_DB_ID = '17VMSpgSZCvIrUlgcw8yCNcnl8WQWo2IcRf5tDCcuJGM';
var ADMIN_CONFIG_SHEET_NAME = 'SystemConfig';

function doGet(e) {
  e = e || {};
  var params = e.parameter || {};
  var page = adminS_(params.page || params.route || '').toLowerCase();

  if (page === 'signadmin' || page === 'signadminstatus' || page === 'adminsignstatus' || page === 'signdocuments') {
    return erpAdminB06J41_081_160_renderSignAdminDashboardHtml(params);
  }

  var t = HtmlService.createTemplateFromFile('Index');
  t.buildNo = ADMIN_BUILD_NO;
  t.buildTitle = ADMIN_BUILD_TITLE;
  return t.evaluate()
    .setTitle('FEELHAUS ERP_ADMIN')
    .setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL);
}

function adminInclude(filename) {
  return HtmlService.createHtmlOutputFromFile(filename).getContent();
}

function erpAdminB06J36_12_fullCheck_20260502_log() {
  var result = adminB06J36_12_fullCheck_();
  Logger.log('==============================');
  Logger.log("[ERP_ADMIN FULL CHECK] adminBuildSummary('B06J36-12')");
  Logger.log(JSON.stringify(result, null, 2));
  Logger.log('==============================');
  return result;
}

function adminB06J36_12_fullCheck_() {
  var checks = [];
  var fatal = 0;
  function add(name, ok, detail) {
    if (!ok) fatal++;
    checks.push({ name: name, ok: !!ok, detail: detail || '' });
  }

  var config = adminGetSystemConfigSafe_();
  add('SystemConfig read', config.ok, config.message);
  add('Code BUILD_NO B06J41-081-160-FORCE-ROUTE-CLEAN-V3', ADMIN_BUILD_NO === 'B06J41-081-160-FORCE-ROUTE-CLEAN-V3', ADMIN_BUILD_NO);
  add('adminGetBuildInfo exists', typeof adminGetBuildInfo === 'function', 'ADMIN build info');
  add('adminListEmployees exists', typeof adminListEmployees === 'function', 'employee list read wrapper');
  add('adminGetApprovalSummary exists', typeof adminGetApprovalSummary === 'function', 'approval summary read wrapper');
  add('adminListQrSignReissueRequests exists', typeof adminListQrSignReissueRequests === 'function', 'QR reissue request read wrapper');
  add('adminApproveQrSignReissue guarded', typeof adminApproveQrSignReissue === 'function', 'approval write guarded in skeleton');
  add('adminRejectQrSignReissue guarded', typeof adminRejectQrSignReissue === 'function', 'reject write guarded in skeleton');

  var master = adminOpenMasterDbSafe_();
  add('FEELHAUS_DB_MASTER connect', master.ok, master.message);

  var employeeProbe = { ok: true, data: { rows: [], count: 0 } };
  var approvalProbe = { ok: true, data: { totalPending: 0 } };
  var qrProbe = { ok: true, data: { rows: [], count: 0 } };
  if (master.ok) {
    try {
      employeeProbe = adminListEmployees({ limit: 10 });
      add('employee read probe', employeeProbe.ok, 'rows=' + ((employeeProbe.data && employeeProbe.data.rows) ? employeeProbe.data.rows.length : 0));
    } catch (err) {
      add('employee read probe', false, adminErr_(err));
    }
    try {
      approvalProbe = adminGetApprovalSummary({});
      add('approval summary probe', approvalProbe.ok, 'pending=' + ((approvalProbe.data && approvalProbe.data.totalPending) || 0));
    } catch (err2) {
      add('approval summary probe', false, adminErr_(err2));
    }
    try {
      qrProbe = adminListQrSignReissueRequests({ status: 'PENDING', limit: 10 });
      add('QR reissue read probe', qrProbe.ok, 'rows=' + ((qrProbe.data && qrProbe.data.rows) ? qrProbe.data.rows.length : 0));
    } catch (err3) {
      add('QR reissue read probe', false, adminErr_(err3));
    }
  }

  return adminResponse_(fatal === 0, fatal === 0 ? 'B06J41-081-160 ERP_ADMIN fullCheck 통과' : 'B06J41-081-160 ERP_ADMIN fullCheck 점검 필요', {
    build: ADMIN_BUILD_NO,
    title: ADMIN_BUILD_TITLE,
    fatal: fatal,
    checks: checks,
    configKeyCount: config.keyCount || 0,
    masterConnected: master.ok,
    employeeSample: employeeProbe.data || {},
    approvalSummary: approvalProbe.data || {},
    qrReissueSample: qrProbe.data || {},
    writePolicy: 'Phase 1에서는 조회 중심, 승인/반려 쓰기 작업은 guard 상태'
  }, fatal ? 'ADMIN_FULLCHECK_FAILED' : '');
}

function adminGetBuildInfo() {
  return adminResponse_(true, 'ERP_ADMIN build info', {
    build: ADMIN_BUILD_NO,
    buildName: ADMIN_BUILD_NAME,
    title: ADMIN_BUILD_TITLE,
    role: 'ERP_ADMIN',
    sourceDb: 'FEELHAUS_SETUP_DB > SystemConfig',
    masterHub: 'FEELHAUS_DB_MASTER',
    mode: 'ADMIN_READ_ONLY_SAFE_CLEAN',
    writePolicy: 'SIGN 081~160에서는 조회 중심. QR 재서명 승인/반려 실제 쓰기는 제거하고 guard만 유지'
  });
}

function adminListEmployees(payload) {
  payload = payload || {};
  var keyword = adminS_(payload.keyword || payload.query || '').toLowerCase();
  var limit = Math.min(Math.max(Number(payload.limit || 50), 1), 200);
  var master = adminOpenMasterDbSafe_();
  if (!master.ok) return adminResponse_(false, master.message, { rows: [] }, 'MASTER_NOT_CONNECTED');

  var sheetNames = ['Employees', 'ERP_직원관리', '직원관리', 'Users', 'Staff', 'ERP_Employees', 'Employee_Master'];
  var rows = [];
  var usedSheet = '';
  for (var i = 0; i < sheetNames.length && rows.length < limit; i++) {
    var sh = master.ss.getSheetByName(sheetNames[i]);
    if (!sh) continue;
    var table = adminReadTable_(sh);
    for (var r = 0; r < table.rows.length && rows.length < limit; r++) {
      var obj = table.rows[r];
      var employeeId = adminS_(obj.employeeId || obj.staffId || obj.userId || obj.id || obj.loginId);
      var name = adminS_(obj.name || obj.employeeName || obj.staffName || obj.이름);
      var email = adminS_(obj.email || obj.loginId || obj.userEmail || obj.이메일);
      var role = adminS_(obj.role || obj.roleCode || obj.auth || obj.권한 || obj.userRole);
      var status = adminS_(obj.status || obj.employeeStatus || obj.상태 || '');
      var vendorId = adminS_(obj.vendorId || obj.companyId || obj.업체ID || '');
      var department = adminS_(obj.department || obj.dept || obj.부서 || '');
      var hay = [employeeId, name, email, role, status, vendorId, department].join(' ').toLowerCase();
      if (keyword && hay.indexOf(keyword) === -1) continue;
      rows.push({
        sourceSheet: sheetNames[i],
        rowNumber: r + 2,
        employeeId: employeeId,
        name: name,
        email: email,
        role: role,
        status: status,
        vendorId: vendorId,
        department: department
      });
    }
    if (rows.length) usedSheet = sheetNames[i];
  }
  return adminResponse_(true, '직원목록 조회 완료', { rows: rows, count: rows.length, sourceSheet: usedSheet });
}

function adminGetApprovalSummary(payload) {
  payload = payload || {};
  var master = adminOpenMasterDbSafe_();
  if (!master.ok) return adminResponse_(false, master.message, {}, 'MASTER_NOT_CONNECTED');
  var rows = adminReadApprovalRows_(master.ss, 500);
  var summary = {
    total: rows.length,
    totalPending: 0,
    qrReissuePending: 0,
    rolePending: 0,
    settlementPending: 0,
    otherPending: 0,
    sourceSheets: {}
  };
  rows.forEach(function(row) {
    summary.sourceSheets[row.sourceSheet] = (summary.sourceSheets[row.sourceSheet] || 0) + 1;
    var st = adminS_(row.status).toUpperCase();
    var type = adminS_(row.type || row.requestType || row.category).toUpperCase();
    var memo = adminS_(row.memo || row.reason || row.reasonCode).toUpperCase();
    var pending = !st || st === 'PENDING' || st === 'DRAFT' || st === 'REQUESTED' || st === '승인대기';
    if (!pending) return;
    summary.totalPending++;
    if (type.indexOf('QR') >= 0 || memo.indexOf('QR') >= 0 || memo.indexOf('REISSUE') >= 0 || memo.indexOf('재서명') >= 0) summary.qrReissuePending++;
    else if (type.indexOf('ROLE') >= 0 || memo.indexOf('권한') >= 0 || memo.indexOf('역할') >= 0) summary.rolePending++;
    else if (type.indexOf('SETTLEMENT') >= 0 || memo.indexOf('정산') >= 0) summary.settlementPending++;
    else summary.otherPending++;
  });
  return adminResponse_(true, '승인 요약 조회 완료', summary);
}

function adminListQrSignReissueRequests(payload) {
  payload = payload || {};
  var statusFilter = adminS_(payload.status || 'PENDING').toUpperCase();
  var limit = Math.min(Math.max(Number(payload.limit || 50), 1), 200);
  var master = adminOpenMasterDbSafe_();
  if (!master.ok) return adminResponse_(false, master.message, { rows: [] }, 'MASTER_NOT_CONNECTED');
  var allRows = adminReadApprovalRows_(master.ss, 1000);
  var rows = [];
  for (var i = 0; i < allRows.length && rows.length < limit; i++) {
    var row = allRows[i];
    var typeText = [row.type, row.requestType, row.category, row.memo, row.reason, row.reasonCode, row.actionType].map(adminS_).join(' ').toUpperCase();
    var isQr = typeText.indexOf('QR') >= 0 || typeText.indexOf('REISSUE') >= 0 || typeText.indexOf('재서명') >= 0;
    if (!isQr) continue;
    var st = adminS_(row.status).toUpperCase() || 'PENDING';
    if (statusFilter && statusFilter !== 'ALL' && st !== statusFilter) continue;
    rows.push({
      sourceSheet: row.sourceSheet,
      rowNumber: row.rowNumber,
      requestId: adminS_(row.requestId || row.approvalId || row.id),
      approvalId: adminS_(row.approvalId || row.requestId || row.id),
      customerId: adminS_(row.customerId || row.targetId || row.memberId),
      originalDocumentId: adminS_(row.originalDocumentId || row.documentId),
      reasonCode: adminS_(row.reasonCode || row.reason || row.memo),
      status: adminS_(row.status || 'PENDING'),
      requestedAt: adminS_(row.requestedAt || row.createdAt),
      requestedBy: adminS_(row.requestedBy || row.createdBy),
      memo: adminS_(row.memo || row.reasonMemo || row.note)
    });
  }
  return adminResponse_(true, 'QR 재서명 승인요청 조회 완료', { rows: rows, count: rows.length });
}

function adminApproveQrSignReissue(payload) {
  return adminResponse_(false, 'ERP_ADMIN Phase 1 골격에서는 QR 재서명 승인 쓰기 작업을 비활성화했습니다. 기존 ERP 기준본에서 처리하세요.', {
    requestedPayload: payload || {},
    policy: 'APPROVAL_WRITE_GUARDED_IN_ADMIN_SKELETON',
    nextPhase: 'B06J36-13 이후 승인/반려 실제 처리 이관'
  }, 'ADMIN_APPROVAL_WRITE_GUARDED');
}

function adminRejectQrSignReissue(payload) {
  return adminResponse_(false, 'ERP_ADMIN Phase 1 골격에서는 QR 재서명 반려 쓰기 작업을 비활성화했습니다. 기존 ERP 기준본에서 처리하세요.', {
    requestedPayload: payload || {},
    policy: 'REJECT_WRITE_GUARDED_IN_ADMIN_SKELETON',
    nextPhase: 'B06J36-13 이후 승인/반려 실제 처리 이관'
  }, 'ADMIN_REJECT_WRITE_GUARDED');
}

function adminGetSystemConfigSafe_() {
  try {
    var ss = SpreadsheetApp.openById(ADMIN_SETUP_DB_ID);
    var sh = ss.getSheetByName(ADMIN_CONFIG_SHEET_NAME);
    if (!sh) return { ok: false, message: 'SystemConfig 시트를 찾을 수 없습니다.', map: {}, keyCount: 0 };
    var values = sh.getDataRange().getValues();
    if (!values.length) return { ok: false, message: 'SystemConfig가 비어 있습니다.', map: {}, keyCount: 0 };
    var headers = values[0].map(adminS_);
    var keyIdx = adminFindHeader_(headers, ['configKey', 'key', 'name', 'settingKey', '항목', '키']);
    var valIdx = adminFindHeader_(headers, ['configValue', 'value', 'settingValue', '값']);
    if (keyIdx < 0) keyIdx = 0;
    if (valIdx < 0) valIdx = 1;
    var map = {};
    for (var i = 1; i < values.length; i++) {
      var k = adminS_(values[i][keyIdx]);
      if (!k) continue;
      map[k] = values[i][valIdx];
    }
    return { ok: true, message: 'SystemConfig 자동 읽기 정상', map: map, keyCount: Object.keys(map).length };
  } catch (err) {
    return { ok: false, message: adminErr_(err), map: {}, keyCount: 0 };
  }
}

function adminOpenMasterDbSafe_() {
  var cfg = adminGetSystemConfigSafe_();
  if (!cfg.ok) return { ok: false, message: cfg.message };
  var keys = ['FEELHAUS_DB_MASTER_ID', 'FEELHAUS_DB_MASTER', 'MASTER_DB_ID', 'DB_MASTER_ID', 'ERP_DB_ID', 'FEELHAUS_MASTER_DB_ID'];
  var id = '';
  for (var i = 0; i < keys.length; i++) {
    if (cfg.map[keys[i]]) { id = adminExtractId_(cfg.map[keys[i]]); break; }
  }
  if (!id) return { ok: false, message: 'FEELHAUS_DB_MASTER ID 설정을 찾지 못했습니다.' };
  try {
    return { ok: true, message: 'FEELHAUS_DB_MASTER 연결 정상', ss: SpreadsheetApp.openById(id), id: id };
  } catch (err) {
    return { ok: false, message: 'FEELHAUS_DB_MASTER 연결 실패: ' + adminErr_(err), id: id };
  }
}

function adminReadApprovalRows_(ss, maxRows) {
  var sheetNames = ['ERP_ApprovalRequests', 'ApprovalRequests', 'Approvals', 'EmployeeRoleRequests', 'ERP_Approval_Log', 'Approval_Log'];
  var rows = [];
  for (var i = 0; i < sheetNames.length && rows.length < (maxRows || 500); i++) {
    var sh = ss.getSheetByName(sheetNames[i]);
    if (!sh) continue;
    var table = adminReadTable_(sh);
    for (var r = 0; r < table.rows.length && rows.length < (maxRows || 500); r++) {
      var obj = table.rows[r];
      obj.sourceSheet = sheetNames[i];
      obj.rowNumber = r + 2;
      rows.push(obj);
    }
  }
  return rows;
}

function adminReadTable_(sh) {
  var values = sh.getDataRange().getValues();
  if (!values.length) return { headers: [], rows: [] };
  var headers = values[0].map(adminS_);
  var rows = [];
  for (var i = 1; i < values.length; i++) {
    var obj = {};
    for (var c = 0; c < headers.length; c++) {
      if (headers[c]) obj[headers[c]] = values[i][c];
    }
    rows.push(obj);
  }
  return { headers: headers, rows: rows };
}

function adminFindHeader_(headers, aliases) {
  var lower = headers.map(function(h) { return adminS_(h).toLowerCase(); });
  for (var i = 0; i < aliases.length; i++) {
    var idx = lower.indexOf(adminS_(aliases[i]).toLowerCase());
    if (idx >= 0) return idx;
  }
  return -1;
}

function adminResponse_(ok, message, data, errorCode) {
  return { ok: !!ok, message: message || '', data: data || {}, errorCode: errorCode || '', meta: { build: ADMIN_BUILD_NO, generatedAt: new Date().toISOString() } };
}
function adminS_(v) { return v === null || v === undefined ? '' : String(v).trim(); }
function adminErr_(err) { return err && err.stack ? String(err.stack) : String(err); }
function adminExtractId_(v) {
  var s = adminS_(v);
  var m = s.match(/[-\w]{25,}/);
  return m ? m[0] : s;
}


/**
 * B06J41-081~160 CLEAN compatibility aliases
 * - 과거 B06J36-13 QR 재서명 실제 쓰기 함수 묶음은 이번 정리본에서 제거함.
 * - 승인/반려 함수명은 기존 UI/호출 호환을 위해 guard 응답만 유지함.
 */
function erpAdminB06J41_081_160_fullCheck_20260504_log() {
  var result = erpAdminB06J41_081_160_selfTest();
  Logger.log('[ERP_ADMIN SIGN 081-160 CLEAN FULLCHECK] ' + JSON.stringify(result));
  return result;
}

function erpAdminB06J36_13_fullCheck_20260502_log() {
  return erpAdminB06J41_081_160_fullCheck_20260504_log();
}

function adminB06J36_13_fullCheck_() {
  return erpAdminB06J41_081_160_selfTest();
}

