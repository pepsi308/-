# ERP_ADMIN SIGN 081~160 FORCE ROUTE CLEAN V3

## 반드시 교체할 파일
1. Code.js
2. Index.html
3. AdminSignStatusDashboard.js
4. AdminSignStatusDashboardPage.html

## 함수가 들어있는 파일
- erpAdminB06J41_081_160_routeSmokeTest(): AdminSignStatusDashboard.js
- erpAdminB06J41_081_160_selfTest(): AdminSignStatusDashboard.js
- erpAdminB06J41_081_160_fullCheck_20260504_log(): Code.js
- erpAdminB06J41_081_160_renderSignAdminDashboardHtml(ctx): AdminSignStatusDashboard.js

## route 연결 파일
- Code.js
- doGet(e)에서 page=signAdmin / signAdminStatus / adminSignStatus / signDocuments 를 처리합니다.

## 실행 순서
1. 위 4개 파일 교체
2. 저장
3. erpAdminB06J41_081_160_routeSmokeTest() 실행
4. erpAdminB06J41_081_160_selfTest() 실행
5. 배포 > 배포 관리 > 수정 > 새 버전 > 배포
6. /exec?page=signAdmin 접속

## 정상 build 값
B06J41-081-160-FORCE-ROUTE-CLEAN-V3

## 차단 유지
실제 재오픈, 정산, 지급/환수/차감, 외부연동, 헤더 자동생성은 모두 차단합니다.
