/**
 * build: ERP_B06J37_02_MASTER_CORE_HEADER_REPAIR_SAFE
 * purpose:
 *  - B06J37-01 기준점검 실패 원인 보정
 *  - FEELHAUS_DB_MASTER의 ERP_행사관리 / ERP_업체관리 누락 헤더 추가
 *  - 누락 헤더: statusReason, createdBy
 *
 * apply:
 *  - 기존 파일에 붙이지 말고 새 파일로 추가합니다.
 *  - 권장 파일명: ERP_ModuleSplit_B06J37_02.js
 *
 * safety:
 *  - 기존 헤더/데이터 삭제 없음
 *  - 기존 열 순서 변경 없음
 *  - 누락 헤더만 마지막 열 뒤에 추가
 *  - 기본 점검은 dryRun
 *
 * functions:
 *  - erpB06J37_02_dryRun()
 *  - erpB06J37_02_confirmed()
 */

var ERP_B06J37_02_BUILD = 'ERP_B06J37_02_MASTER_CORE_HEADER_REPAIR_SAFE';
var ERP_B06J37_02_SETUP_DB_ID = '17VMSpgSZCvIrUlgcw8yCNcnl8WQWo2IcRf5tDCcuJGM';
var ERP_B06J37_02_CONFIG_SHEET_NAME = 'SystemConfig';

var ERP_B06J37_02_TARGETS = [
  {
    sheetName: 'ERP_행사관리',
    requiredHeaders: ['statusReason', 'createdBy']
  },
  {
    sheetName: 'ERP_업체관리',
    requiredHeaders: ['statusReason', 'createdBy']
  }
];

function erpB06J37_02_dryRun() {
  return erpB06J37_02_run_(true);
}

function erpB06J37_02_confirmed() {
  return erpB06J37_02_run_(false);
}

function erpB06J37_02_run_(dryRun) {
  var result = {
    ok: true,
    build: ERP_B06J37_02_BUILD,
    dryRun: dryRun === true,
    checkedAt: new Date().toISOString(),
    fatal: [],
    warnings: [],
    targets: [],
    safety: {
      headerRepairOnly: true,
      appendMissingHeadersOnly: true,
      noHeaderDelete: true,
      noHeaderReorder: true,
      noDataDelete: true,
      noBusinessStateMutation: true,
      noPaymentExecution: true,
      noRecoveryExecution: true,
      noAutoRecalculation: true,
      noExternalAccountingTransfer: true
    }
  };

  console.log('======================================================');
  console.log('[B06J37-02 MASTER CORE HEADER REPAIR] START');
  console.log(JSON.stringify({ build: ERP_B06J37_02_BUILD, dryRun: result.dryRun }, null, 2));

  try {
    var setup = erpB06J37_02_getSetupConfig_();
    result.setup = {
      ok: setup.ok,
      setupDbName: setup.setupDbName,
      configCount: setup.configCount,
      usedMasterKey: setup.usedMasterKey,
      masterId: setup.masterId
    };

    if (!setup.ok) {
      result.fatal = result.fatal.concat(setup.fatal || []);
    } else {
      var master = SpreadsheetApp.openById(setup.masterId);
      result.masterName = master.getName();

      ERP_B06J37_02_TARGETS.forEach(function(target) {
        var one = erpB06J37_02_repairSheetHeaders_(master, target, result.dryRun);
        result.targets.push(one);
        if (!one.ok && one.fatal && one.fatal.length) {
          result.fatal = result.fatal.concat(one.fatal);
        }
        if (one.warnings && one.warnings.length) {
          result.warnings = result.warnings.concat(one.warnings);
        }
      });
    }
  } catch (e) {
    result.ok = false;
    result.fatal.push('B06J37-02 실행 예외: ' + String(e && e.message ? e.message : e));
    result.exceptionStack = String(e && e.stack ? e.stack : '');
  }

  result.fatalCount = result.fatal.length;
  result.warningCount = result.warnings.length;
  result.ok = result.fatalCount === 0;

  console.log('[B06J37-02 MASTER CORE HEADER REPAIR] RESULT');
  console.log(JSON.stringify(result, null, 2));
  console.log('======================================================');

  return result;
}

function erpB06J37_02_repairSheetHeaders_(master, target, dryRun) {
  var out = {
    ok: true,
    sheetName: target.sheetName,
    dryRun: dryRun === true,
    exists: false,
    beforeLastCol: 0,
    afterLastCol: 0,
    existingHeaders: [],
    missingHeaders: [],
    appendedHeaders: [],
    fatal: [],
    warnings: []
  };

  var sh = master.getSheetByName(target.sheetName);
  if (!sh) {
    out.ok = false;
    out.fatal.push('대상 시트를 찾지 못했습니다: ' + target.sheetName);
    return out;
  }

  out.exists = true;
  out.beforeLastCol = sh.getLastColumn();
  out.existingHeaders = erpB06J37_02_getHeaders_(sh);

  out.missingHeaders = target.requiredHeaders.filter(function(h) {
    return out.existingHeaders.indexOf(h) < 0;
  });

  if (!out.missingHeaders.length) {
    out.afterLastCol = out.beforeLastCol;
    out.message = '누락 헤더 없음';
    return out;
  }

  if (!dryRun) {
    var startCol = sh.getLastColumn() + 1;
    sh.getRange(1, startCol, 1, out.missingHeaders.length).setValues([out.missingHeaders]);
    SpreadsheetApp.flush();
    out.appendedHeaders = out.missingHeaders.slice();
    out.afterLastCol = sh.getLastColumn();
  } else {
    out.afterLastCol = out.beforeLastCol + out.missingHeaders.length;
    out.appendedHeaders = [];
  }

  out.message = dryRun
    ? 'DRY_RUN: 누락 헤더 추가 예정'
    : 'CONFIRMED: 누락 헤더 추가 완료';

  return out;
}

function erpB06J37_02_getSetupConfig_() {
  var out = {
    ok: true,
    fatal: [],
    configMap: {},
    configCount: 0,
    setupDbName: '',
    usedMasterKey: '',
    masterId: ''
  };

  var setup = SpreadsheetApp.openById(ERP_B06J37_02_SETUP_DB_ID);
  out.setupDbName = setup.getName();

  var sh = setup.getSheetByName(ERP_B06J37_02_CONFIG_SHEET_NAME);
  if (!sh) {
    out.ok = false;
    out.fatal.push('SystemConfig 시트를 찾지 못했습니다.');
    return out;
  }

  var values = sh.getDataRange().getValues();
  if (!values || values.length < 2) {
    out.ok = false;
    out.fatal.push('SystemConfig 데이터가 비어 있습니다.');
    return out;
  }

  var headers = values[0].map(function(h) { return String(h || '').trim(); });
  var lower = headers.map(function(h) { return h.toLowerCase(); });

  var keyIdx = lower.indexOf('key');
  if (keyIdx < 0) keyIdx = lower.indexOf('configkey');
  if (keyIdx < 0) keyIdx = lower.indexOf('name');
  if (keyIdx < 0) keyIdx = 0;

  var valIdx = lower.indexOf('value');
  if (valIdx < 0) valIdx = lower.indexOf('configvalue');
  if (valIdx < 0) valIdx = lower.indexOf('spreadsheetid');
  if (valIdx < 0) valIdx = 1;

  for (var r = 1; r < values.length; r++) {
    var k = String(values[r][keyIdx] || '').trim();
    var v = String(values[r][valIdx] || '').trim();
    if (k) out.configMap[k] = v;
  }

  out.configCount = Object.keys(out.configMap).length;

  var keys = [
    'FEELHAUS_DB_MASTER_ID',
    'FEELHAUS_DB_MASTER',
    'MASTER_SPREADSHEET_ID',
    'MASTER_DB_ID',
    'DB_MASTER_ID',
    'SPREADSHEET_ID'
  ];

  for (var i = 0; i < keys.length; i++) {
    var key = keys[i];
    if (out.configMap[key]) {
      out.usedMasterKey = key;
      out.masterId = erpB06J37_02_extractSpreadsheetId_(out.configMap[key]);
      break;
    }
  }

  if (!out.masterId) {
    out.ok = false;
    out.fatal.push('SystemConfig에서 FEELHAUS_DB_MASTER ID를 찾지 못했습니다.');
  }

  return out;
}

function erpB06J37_02_extractSpreadsheetId_(raw) {
  var s = String(raw || '').trim();
  var m = s.match(/\/d\/([a-zA-Z0-9-_]+)/);
  return m && m[1] ? m[1] : s;
}

function erpB06J37_02_getHeaders_(sh) {
  if (!sh || sh.getLastRow() < 1 || sh.getLastColumn() < 1) return [];
  return sh.getRange(1, 1, 1, sh.getLastColumn()).getValues()[0].map(function(h) {
    return String(h || '').trim();
  });
}
