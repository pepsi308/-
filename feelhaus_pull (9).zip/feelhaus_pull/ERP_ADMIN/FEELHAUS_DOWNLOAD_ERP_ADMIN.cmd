@echo off
setlocal EnableExtensions
title FEELHAUS DOWNLOAD ERP_ADMIN

if not exist "D:\pepsi308\OneDrive\feelhaus_pull\ERP_ADMIN" mkdir "D:\pepsi308\OneDrive\feelhaus_pull\ERP_ADMIN"
cd /d D:\pepsi308\OneDrive\feelhaus_pull\ERP_ADMIN

if exist ".clasp.json" (
  echo [ERP_ADMIN] clasp pull
  clasp.cmd pull
) else (
  echo [ERP_ADMIN] clasp clone
  clasp.cmd clone 1U_H4qtYBoULLQ29uIMOUmzswmIwbwfOyBeXy5kq9bsx0xRdp0nAxUtNT
)

pause
