/** FEELHAUS ERP v64-B06J36-20D MAIN SPLIT CONFIRMED SAFE
 * 목적: ERP 본체 역할분리 잠금 + 점검 함수 단일화.
 * 본체 유지: 고객검색 / 정회원 DB 업로드 / 판매 / 설치 / A/S / 정산 / B05 / FIELD·ADMIN·SIGN 이동.
 * 본체 비노출: 현장 QR / 직원관리 / 민감승인 / QR 재서명 승인 / SIGN 기프트 정산 인계 UI.
 * 주의: SIGN 기프트 정산 인계와 신규 기능 추가는 본체 안정화 완료 전까지 보류.
 */
var ERP_MAIN_SPLIT_LOCK_BUILD_NO = 'v64-B06J36-20D';
var ERP_MAIN_SPLIT_LOCK_BUILD_NAME = 'ERP_B06J36_20D_MAIN_SPLIT_CONFIRMED_SAFE';
var ERP_MAIN_SPLIT_LOCK_TITLE = 'ERP 통합빌드 v64-B06J36-20D 본체 역할분리 최종확인 / fullCheck 단일화';

function erpMainSplitLock_getPolicy() {
  return {
    ok: true,
    buildNo: ERP_MAIN_SPLIT_LOCK_BUILD_NO,
    buildName: ERP_MAIN_SPLIT_LOCK_BUILD_NAME,
    title: ERP_MAIN_SPLIT_LOCK_TITLE,
    mainKeeps: ['customerSearch','regularMemberUpload','sale','install','as','settlement','b05Worklist','erpFieldNav','erpAdminNav','signNav'],
    mainHidden: ['quickCustomerCreate','fieldQr','publicEntryQr','assignedQrBulk','employeeAdmin','sensitiveApproval','qrReissueApproval','benefitGiftSettlementHandoffUi'],
    policy: 'ERP 본체 안정화 전용. FIELD/ADMIN/SIGN 기능은 본체에서 직접 처리하지 않고 이동 버튼으로 분리한다.',
    meta: { generatedAt: new Date().toISOString() }
  };
}

function erpMainSplitLock_readIndex_() {
  try {
    return HtmlService.createHtmlOutputFromFile('Index').getContent();
  } catch (err) {
    return '';
  }
}

/**
 * 다음 빌드부터 사용해야 하는 단일 fullCheck.
 * Apps Script 함수 목록에서 이 이름이 보이면 실행한다.
 */
function erpMainSplitLock_fullCheck_20260502_log() {
  var checks = [];
  var fatal = 0;
  var warnings = [];
  function add(name, ok, detail, warnOnly) {
    if (!ok && warnOnly) warnings.push(name + ': ' + (detail || ''));
    if (!ok && !warnOnly) fatal++;
    checks.push({ name: name, ok: !!ok, detail: detail || '', warnOnly: !!warnOnly });
  }

  var html = erpMainSplitLock_readIndex_();
  var hasB19Marker = html.indexOf('FEELHAUS ERP v64-B06J36-19 MAIN SPLIT LOCK SAFE') >= 0;
  var hasB20Marker = html.indexOf('FEELHAUS ERP v64-B06J36-20D MAIN SPLIT CONFIRMED SAFE') >= 0 || html.indexOf('fhMainSplitLockSentinel') >= 0;
  add('MAIN_SPLIT_LOCK UI marker exists', hasB19Marker || hasB20Marker, 'Index.html marker', false);
  add('MAIN_SPLIT_LOCK apply script exists', html.indexOf('__FH_MAIN_SPLIT_LOCK__') >= 0, 'window marker', false);
  add('FIELD nav function exists', typeof erpB06J36_9_getFieldAppInfo === 'function', 'ERP_FIELD 이동', false);
  add('ADMIN nav function exists', typeof erpB06J36_15_getAdminAppInfo === 'function' || typeof erpB06J36_14_getAdminAppInfo === 'function', 'ERP_ADMIN 이동', false);
  add('SIGN nav function exists', typeof erpB06J36_16_getSignAppInfo === 'function', 'SIGN 이동', false);
  add('customer search preserved', typeof searchCustomers === 'function', '고객검색 함수 보존', false);
  add('saveSale preserved', typeof saveSale === 'function', '판매 저장 함수 보존', false);
  add('completeInstallation preserved', typeof completeInstallation === 'function', '설치완료 함수 보존', false);
  add('B05 worklist preserved', typeof fhB05GetWorklists === 'function', 'B05 목록 함수 보존', false);
  add('benefit gift UI hidden marker', html.indexOf('fhBenefitGiftReadonlyPanel') >= 0 && html.indexOf('benefitGiftSettlementHandoffUi') >= 0, '기프트 정산 UI 본체 잠금', false);
  add('admin account panel hidden marker', html.indexOf('fhB06BAccountPanel') >= 0 && html.indexOf('employeeAdmin') >= 0, '직원관리 UI 본체 잠금', false);

  var result = {
    ok: fatal === 0,
    fatal: fatal,
    warnings: warnings,
    build: ERP_MAIN_SPLIT_LOCK_BUILD_NAME,
    label: ERP_MAIN_SPLIT_LOCK_BUILD_NO,
    checkedAt: new Date().toISOString(),
    result: {
      checks: checks,
      policy: erpMainSplitLock_getPolicy()
    },
    errorCode: fatal ? 'ERP_MAIN_SPLIT_LOCK_FULLCHECK_FAILED' : '',
    meta: { buildNo: ERP_MAIN_SPLIT_LOCK_BUILD_NO, buildName: ERP_MAIN_SPLIT_LOCK_BUILD_NAME }
  };
  Logger.log('==============================');
  Logger.log('[ERP FULL CHECK] erpMainSplitLock_fullCheck_20260502_log');
  Logger.log(JSON.stringify(result, null, 2));
  Logger.log('==============================');
  return result;
}

/** 찾기 쉬운 보조 실행명. 내부적으로 같은 fullCheck를 실행한다. */
function erpB06J36_20_fullCheck() {
  return erpMainSplitLock_fullCheck_20260502_log();
}

function ensureSystemConfig() {
  const requiredKeys = [
    { key:'SPREADSHEET_ID', value:'1TFZ7Ihgnmxu-ziQAoB6nOf1AByxFahk9UtrmiyZ0q_0' },
    { key:'SIGN_SPREADSHEET_ID', value:'1RRZd-ttHYsOPiEA5x8ZEQiQqh5DS1d60jMcLuHgj7uA' },
    { key:'ROOT_FOLDER_ID', value:'1s03fmiWTUH1RyxX-DkU-vkPncwtyxkbu' },
    { key:'BACKUP_FOLDER_ID', value:'1-_tsPL7rkzld355L-DcST-IT9nG331FA' },
  ];
  const props = PropertiesService.getScriptProperties();
  requiredKeys.forEach(rk => {
    if (!props.getProperty(rk.key)) {
      props.setProperty(rk.key, rk.value);
    }
  });
}

var FH = (function () {
  var BUILD_NO = 'v64-B06J36-20D';
  var BUILD_TITLE = 'ERP 통합빌드 v64-B06J36-20D 본체 역할분리 최종확인 / FIELD·ADMIN·SIGN 이동 전환';

  function props(){ return PropertiesService.getScriptProperties(); }
  function getProp(key, fallback){
    var v = props().getProperty(key);
    return v === null || v === '' ? (fallback || '') : v;
  }
  function setProps(map){ props().setProperties(map, true); }
  function s(v){ return String(v === undefined || v === null ? '' : v).trim(); }
  function n(v){ return Number(String(v === undefined || v === null ? '' : v).replace(/,/g,'').trim()) || 0; }
  function ts(){ return Utilities.formatDate(new Date(), Session.getScriptTimeZone() || 'Asia/Seoul', 'yyyy-MM-dd HH:mm:ss'); }

  function normalizePhone(v){
    var raw = String(v === undefined || v === null ? '' : v).replace(/[^0-9]/g, '');
    if (!raw) return '';
    if (!/^010/.test(raw)) raw = '010' + raw.replace(/^010/, '');
    raw = raw.substring(0, 11);
    if (raw.length <= 3) return '010-';
    if (raw.length <= 7) return raw.replace(/(\d{3})(\d+)/, '$1-$2');
    return raw.replace(/(\d{3})(\d{4})(\d+)/, '$1-$2-$3');
  }

  function phoneDigits(v){
    var d = String(v === undefined || v === null ? '' : v).replace(/[^0-9]/g, '');
    if (!d) return '';
    if (!/^010/.test(d)) d = '010' + d.replace(/^010/, '');
    return d.substring(0, 11);
  }

  function openById(id){
    if (!id) throw new Error('스프레드시트 ID가 없습니다.');
    return SpreadsheetApp.openById(id);
  }

  function setupSpreadsheet(){
    var id = getProp('SETUP_DB_ID') || getProp('SETUPDBID');
    if (!id) throw new Error('스크립트 속성 SETUP_DB_ID가 없습니다.');
    return openById(id);
  }

  function firstSheetByNames(ss, names){
    for (var i=0;i<names.length;i++){
      var sh = ss.getSheetByName(names[i]);
      if (sh) return sh;
    }
    return null;
  }

  function getSystemConfigSheet(){
    var sh = firstSheetByNames(setupSpreadsheet(), ['SystemConfig','CONFIG','SetupConfig','FEELHAUS_SETUP_DB']);
    if (!sh) throw new Error('FEELHAUS_SETUP_DB에서 SystemConfig 시트를 찾지 못했습니다.');
    return sh;
  }

  function syncSystemConfig(){
    var sh = getSystemConfigSheet();
    var values = sh.getDataRange().getDisplayValues();
    if (!values || values.length < 2) throw new Error('SystemConfig 데이터가 없습니다.');

    var rawHeader = values[0];
    var header = rawHeader.map(function(h){
      return String(h === undefined || h === null ? '' : h)
        .replace(/\uFEFF/g, '')
        .trim()
        .toLowerCase()
        .replace(/\s+/g, '')
        .replace(/_/g, '');
    });

    var idxKey = -1;
    var idxValue = -1;

    for (var i=0; i<header.length; i++){
      var h = header[i];
      if (h === 'key' || h === 'configkey') idxKey = i;
      if (h === 'value' || h === 'configvalue') idxValue = i;
    }

    if (idxKey < 0 || idxValue < 0) {
      throw new Error('SystemConfig 헤더는 key/value 또는 configKey/configValue 형태여야 합니다. 현재: ' + JSON.stringify(rawHeader));
    }

    var map = {};
    for (var r=1; r<values.length; r++){
      var row = values[r];
      var key = s(row[idxKey]);
      if (!key) continue;
      map[key] = row[idxValue];
    }
    if (map.DB_MASTER_ID && !map.DB_SPREADSHEET_ID) map.DB_SPREADSHEET_ID = map.DB_MASTER_ID;
    setProps(map);
    return { ok:true, syncedCount:Object.keys(map).length, dbSpreadsheetId:map.DB_SPREADSHEET_ID || '' };
  }

  function getDbSpreadsheet(){
    var id = getProp('DB_SPREADSHEET_ID') || getProp('DB_MASTER_ID') || getProp('SPREADSHEET_ID');
    if (!id){
      syncSystemConfig();
      id = getProp('DB_SPREADSHEET_ID') || getProp('DB_MASTER_ID') || getProp('SPREADSHEET_ID');
    }
    if (!id) throw new Error('DB_SPREADSHEET_ID/DB_MASTER_ID 값이 없습니다.');
    return openById(id);
  }

  function ensureSheet(name, headers){
    var ss = getDbSpreadsheet();
    var sh = ss.getSheetByName(name);
    if (!sh) sh = ss.insertSheet(name);
    if (headers && headers.length && sh.getLastRow() === 0){
      sh.getRange(1,1,1,headers.length).setValues([headers]);
    }
    if (headers && headers.length) ensureSheetHeaders_(sh, headers);
    return sh;
  }

  function ensureSheetHeaders_(sh, headers){
    if (!sh || !headers || !headers.length) return sh;
    if (sh.getLastRow() === 0){
      sh.getRange(1,1,1,headers.length).setValues([headers]);
      return sh;
    }
    var lastCol = Math.max(sh.getLastColumn(), 1);
    var existing = sh.getRange(1,1,1,lastCol).getDisplayValues()[0].map(function(h){ return String(h || '').trim(); });
    var exists = {};
    existing.forEach(function(h){ if (h) exists[h] = true; });
    var missing = [];
    headers.forEach(function(h){ h = String(h || '').trim(); if (h && !exists[h]) { missing.push(h); exists[h] = true; } });
    if (missing.length){
      sh.getRange(1, existing.length + 1, 1, missing.length).setValues([missing]);
    }
    return sh;
  }

  function getHeaderMap_(sh){
    var lastCol = sh.getLastColumn();
    var header = lastCol ? sh.getRange(1,1,1,lastCol).getDisplayValues()[0] : [];
    var map = {};
    header.forEach(function(h,i){ map[String(h || '').trim()] = i + 1; });
    return { header:header, map:map };
  }

  function appendObjectByHeader_(sheetName, fallbackHeaders, obj){
    var sh = ensureSheet(sheetName, fallbackHeaders);
    var hm = getHeaderMap_(sh);
    var header = hm.header && hm.header.length ? hm.header : fallbackHeaders;
    if (!hm.header.length && fallbackHeaders && fallbackHeaders.length) {
      sh.getRange(1,1,1,fallbackHeaders.length).setValues([fallbackHeaders]);
      header = fallbackHeaders;
    }
    var row = header.map(function(h){ return Object.prototype.hasOwnProperty.call(obj, h) ? obj[h] : ''; });
    sh.appendRow(row);
    return row;
  }

  function appendRowsIfEmpty(name, headers, rows){
    var sh = ensureSheet(name, headers);
    if (sh.getLastRow() <= 1 && rows && rows.length){
      sh.getRange(2,1,rows.length,rows[0].length).setValues(rows);
    }
    return sh;
  }

  function nextId(prefix, sheet, colIdx){
    var last = sheet.getLastRow() > 1 ? sheet.getRange(sheet.getLastRow(), colIdx, 1, 1).getDisplayValue() : '';
    var num = 1;
    var m = String(last).match(/(\d+)$/);
    if (m) num = Number(m[1]) + 1;
    return prefix + Utilities.formatString('%04d', num);
  }

  function readTable(name){
    var sh = getDbSpreadsheet().getSheetByName(name);
    if (!sh) return [];
    var vals = sh.getDataRange().getDisplayValues();
    if (vals.length < 2) return [];
    var header = vals[0];
    return vals.slice(1).filter(function(r){ return r.join('').trim() !== ''; }).map(function(r){
      var obj = {};
      for (var i=0;i<header.length;i++) obj[header[i]] = r[i];
      return obj;
    });
  }

  function rowMap(rows, key){
    var map = {};
    rows.forEach(function(r){ map[String(r[key] || '')] = r; });
    return map;
  }

  function updateRowById(sheetName, idField, idValue, updates){
    var sh = getDbSpreadsheet().getSheetByName(sheetName);
    if (!sh) throw new Error(sheetName + ' 시트를 찾지 못했습니다.');
    var vals = sh.getDataRange().getDisplayValues();
    if (vals.length < 2) throw new Error(sheetName + ' 데이터가 없습니다.');
    var header = vals[0];
    var idxId = header.indexOf(idField);
    if (idxId < 0) throw new Error(sheetName + '에 ' + idField + ' 헤더가 없습니다.');
    for (var r=1;r<vals.length;r++){
      if (String(vals[r][idxId]) === String(idValue)){
        Object.keys(updates || {}).forEach(function(key){
          var idx = header.indexOf(key);
          if (idx > -1) sh.getRange(r+1, idx+1).setValue(updates[key]);
        });
        return true;
      }
    }
    throw new Error('대상을 찾지 못했습니다: ' + idValue);
  }

  function findFirstByField_(sheetName, fieldName, fieldValue){
    var rows = readTable(sheetName);
    for (var i=0; i<rows.length; i++){
      if (String(rows[i][fieldName] || '') === String(fieldValue || '')) return rows[i];
    }
    return null;
  }

  function findLastByField_(sheetName, fieldName, fieldValue){
    var rows = readTable(sheetName);
    for (var i=rows.length - 1; i>=0; i--){
      if (String(rows[i][fieldName] || '') === String(fieldValue || '')) return rows[i];
    }
    return null;
  }

  function getOrCreateInstallId_(payload, sale){
    payload = payload || {};
    var saleId = s(payload.saleId) || s(sale && sale.saleId);
    var directId = s(payload.installId);
    if (directId) return directId;
    var existingInstall = saleId ? findFirstByField_('Installs', 'saleId', saleId) : null;
    if (existingInstall && s(existingInstall.installId)) return s(existingInstall.installId);
    var existingAssignment = saleId ? findLastByField_('InstallAssignments', 'saleId', saleId) : null;
    if (existingAssignment && s(existingAssignment.installId)) return s(existingAssignment.installId);
    var existingCompletion = saleId ? findLastByField_('InstallCompletions', 'saleId', saleId) : null;
    if (existingCompletion && s(existingCompletion.installId)) return s(existingCompletion.installId);
    var sh = ensureSheet('Installs', ['installId','contractId','saleId','eventId','vendorId','customerId','status','statusReason','createdAt','createdBy','updatedAt','updatedBy','recordMode','reviewStatus','batchTag','remarks']);
    return nextId('INS-', sh, 1);
  }

  function syncInstallMasterFromSale_(installId, sale, payload, status, reason){
    payload = payload || {};
    sale = sale || {};
    var now = ts();
    var installHeaders = ['installId','contractId','saleId','eventId','vendorId','customerId','status','statusReason','createdAt','createdBy','updatedAt','updatedBy','recordMode','reviewStatus','batchTag','remarks'];
    var existingInstall = installId ? findFirstByField_('Installs', 'installId', installId) : null;
    upsertObjectByHeader_('Installs', installHeaders, 'installId', installId, {
      installId:installId,
      contractId:s(payload.contractId) || s(existingInstall && existingInstall.contractId) || s(sale.contractId),
      saleId:s(payload.saleId) || s(existingInstall && existingInstall.saleId) || s(sale.saleId),
      eventId:s(payload.eventId) || s(existingInstall && existingInstall.eventId) || s(sale.eventId),
      vendorId:s(payload.vendorId) || s(existingInstall && existingInstall.vendorId) || s(sale.vendorId),
      customerId:s(payload.customerId) || s(existingInstall && existingInstall.customerId) || s(sale.customerId),
      status:status,
      statusReason:reason || s(payload.statusReason) || s(existingInstall && existingInstall.statusReason),
      createdAt:s(existingInstall && existingInstall.createdAt) || now,
      createdBy:s(existingInstall && existingInstall.createdBy) || 'system',
      updatedAt:now,
      updatedBy:'system',
      recordMode:s(existingInstall && existingInstall.recordMode) || 'ERP',
      reviewStatus:s(existingInstall && existingInstall.reviewStatus) || 'APPROVED',
      batchTag:s(existingInstall && existingInstall.batchTag) || s(payload.batchTag),
      remarks:s(payload.memo) || s(existingInstall && existingInstall.remarks)
    });
  }

  function ensureInstallAssignmentFromCompletion_(payload, sale, latestAssignment){
    payload = payload || {};
    sale = sale || {};
    latestAssignment = latestAssignment || null;
    var now = ts();
    var installId = s(payload.installId);
    var saleId = s(payload.saleId) || s(sale.saleId);
    if (!installId || !saleId) return { ok:false, message:'installId 또는 saleId 없음' };

    var assignmentHeaders = ['assignmentId','saleId','vendorId','installId','teamName','engineer','vehicleNo','visitDate','visitTime','status','memo','createdAt','updatedAt'];
    var existingByInstall = findFirstByField_('InstallAssignments', 'installId', installId);
    var existingBySale = latestAssignment && s(latestAssignment.saleId) === saleId ? latestAssignment : findLastByField_('InstallAssignments', 'saleId', saleId);
    var existing = existingByInstall || existingBySale || null;
    var sh = ensureSheet('InstallAssignments', assignmentHeaders);
    var assignmentId = s(existing && existing.assignmentId) || nextId('ASN-', sh, 1);
    var teamName = s(payload.assignedTeam || payload.teamName) || s(existing && existing.teamName);
    var engineer = s(payload.assignedEngineer || payload.engineer || payload.installer) || s(existing && existing.engineer) || s(sale.installer);
    var visitDate = s(payload.visitDate) || s(payload.completedAt) || s(existing && existing.visitDate) || s(sale.installDate);

    return upsertObjectByHeader_('InstallAssignments', assignmentHeaders, 'assignmentId', assignmentId, {
      assignmentId:assignmentId,
      saleId:saleId,
      vendorId:s(payload.vendorId) || s(existing && existing.vendorId) || s(sale.vendorId),
      installId:installId,
      teamName:teamName,
      engineer:engineer,
      vehicleNo:s(payload.vehicleNo) || s(existing && existing.vehicleNo),
      visitDate:visitDate,
      visitTime:s(payload.visitTime) || s(existing && existing.visitTime),
      status:s(payload.assignmentStatus) || 'COMPLETED',
      memo:s(payload.memo) || s(existing && existing.memo) || '설치완료 기준 자동 배정 동기화',
      createdAt:s(existing && existing.createdAt) || now,
      updatedAt:now
    });
  }

  function upsertObjectByHeader_(sheetName, fallbackHeaders, idField, idValue, obj){
    try {
      updateRowById(sheetName, idField, idValue, obj);
      return { mode:'update', id:idValue };
    } catch (e) {
      appendObjectByHeader_(sheetName, fallbackHeaders, obj);
      return { mode:'insert', id:idValue };
    }
  }

  function setupErpSystem(){
    syncSystemConfig();
    appendRowsIfEmpty('Customers', ['customerId','name','phone','email','memberType','eventType','qrSource','dong','hosu','aptName','address','status','createdAt'], [
      ['CUS-0001','홍길동','010-1234-5678','hong@example.com','정회원','입주박람회','QR','101','1203','디에이치 방배','서울 서초구 방배동','ACTIVE',ts()],
      ['CUS-0002','김영희','010-2345-6789','kim@example.com','준회원','사전점검','수기','102','805','디에이치 방배','서울 서초구 방배동','ACTIVE',ts()]
    ]);
    appendRowsIfEmpty('Events', ['eventId','eventName','aptName','status','eventType','startDate','endDate'], [
      ['EVT-0001','디에이치 방배 1차 박람회','디에이치 방배','ACTIVE','사전점검','2026-07-11','2026-07-13'],
      ['EVT-0002','디에이치 방배 2차 박람회','디에이치 방배','ACTIVE','입주박람회','2026-08-07','2026-08-10']
    ]);
    appendRowsIfEmpty('Vendors', ['vendorId','vendorName','status','paymentStructure','commissionRate'], [
      ['VND-0001','샘플업체','ACTIVE','HQ','10'],
      ['VND-0002','필인테리어','ACTIVE','MIXED','12']
    ]);
    appendRowsIfEmpty('Sales', ['saleId','eventId','vendorId','customerId','productSummary','itemCount','quantityTotal','unitPrice','supplyAmount','discountAmount','totalAmount','depositAmount','midAmount','balanceAmount','paymentMethod','paymentStructure','payment1Type','payment1Amount','payment2Type','payment2Amount','cardCompany','cardDataId','cardMatchStatus','status','saleStage','installStatus','settlementStatus','installDate','installer','createdAt'], []);
    appendRowsIfEmpty('ASRequests', ['asId','customerId','saleId','vendorId','content','status','priority','assignee','cost','costOwner','resultMemo','claimType','claimStatus','claimAmount','visitDate','createdAt','updatedAt'], [['AS-0001','CUS-0001','SAL-0001','VND-0001','설치 후 점검 요청','OPEN','보통','미배정',0,'업체','','일반','NONE',0,'',ts(),ts()]]);
    appendRowsIfEmpty('PermissionRequests', ['requestId','vendorId','status','requestType','createdAt'], [['REQ-0001','VND-0001','PENDING','SETTLEMENT_ACCESS',ts()]]);
    appendRowsIfEmpty('Onboardings', ['onboardingId','vendorName','status','approvedBy','createdAt'], [['ONB-0001','샘플업체','DRAFT','',ts()]]);
    appendRowsIfEmpty('Cancellations', ['cancellationId','saleId','reasonType','customerRefund','status','createdAt'], []);
    appendRowsIfEmpty('BenefitPayouts', ['payoutId','benefitType','requestedAmount','approvedAmount','status','customerId','giftType','giftStatus','createdAt'], [['BEN-0001','VISIT',50000,'','PENDING','CUS-0001','상품권','READY',ts()]]);
    appendRowsIfEmpty('FundExecutions', ['executionId','projectId','requestedAmount','approvedAmount','status','createdAt'], [['FUND-0001','PRJ-001',100000,'','PENDING',ts()]]);
    appendRowsIfEmpty('DepositLedger', ['ledgerId','vendorId','ledgerType','amount','balanceAfter','eventId','memo','createdAt'], []);
    appendRowsIfEmpty('MonthlyClosings', ['closingId','closingMonth','vendorId','salesAmount','status','createdAt'], []);
    appendRowsIfEmpty('ClaimApprovals', ['approvalId','asId','saleId','vendorId','claimType','claimAmount','status','requestedAt','approvedAt','note'], []);
    appendRowsIfEmpty('CustomerMergeLog', ['mergeId','sourceCustomerId','targetCustomerId','movedSales','movedAS','movedEvidence','movedInstalls','movedCancels','status','createdAt'], []);
    appendRowsIfEmpty('Employees', ['employeeId','vendorId','name','phone','email','department','role','status','eventScope','menuScope','createdAt','updatedAt'], [
      ['EMP-0001','VND-0001','영업담당1','010-3333-1111','staff1@example.com','영업','영업직원','ACTIVE','EVT-0001','고객관리,판매등록,설치관리',ts(),ts()],
      ['EMP-0002','VND-0001','업체대표1','010-3333-2222','owner1@example.com','관리','업체대표','ACTIVE','ALL','직원관리,권한관리,고객관리,판매등록,설치관리,A/S관리',ts(),ts()]
    ]);
    appendRowsIfEmpty('RolePolicies', ['policyId','vendorId','instantRoles','approvalRoles','instantMenus','approvalMenus','downloadPolicy','sensitiveAllowed','createdAt'], [
      ['POL-0001','DEFAULT','영업직원|설치담당|A/S담당|조회전용','회계담당|업체관리자|정산담당','고객관리|판매등록|설치관리|A/S관리|일정관리','정산조회|정산수정|예치금조회|채권조회|상품권정산|원본파일다운로드|PDF일괄출력','PDF:true,EXCEL:false,RAW:false','N',ts()]
    ]);
    appendRowsIfEmpty('EmployeeRoleRequests', ['requestId','vendorId','employeeId','employeeName','requestedRole','requestType','status','requestedBy','approvedBy','note','createdAt','approvedAt'], []);
    appendRowsIfEmpty('ApprovalAudit', ['auditId','auditType','refId','status','actor','targetId','note','createdAt'], []);
    appendRowsIfEmpty('BenefitPolicies', ['policyId','eventId','benefitType','policyName','status','ownerRole','approvalRequired','createdAt'], [
      ['BPL-0001','EVT-0001','VISIT','방문혜택 기본정책','ACTIVE','운영책임자','Y',ts()],
      ['BPL-0002','EVT-0002','MEMBER','정회원혜택 기본정책','ACTIVE','본사관리자','Y',ts()]
    ]);
    appendRowsIfEmpty('PostCancelSettlements', ['pcsId','saleId','vendorId','reasonType','customerRefund','vendorRecovery','vendorAdditionalPayment','hqBurden','recoveryMode','additionalPaymentReason','status','requestedBy','approvedBy','note','createdAt','approvedAt'], []);
    appendRowsIfEmpty('SettlementApprovalSteps', ['stepId','closingId','vendorId','approvalStage','actionStatus','requestedAmount','approvedAmount','requestedBy','actedBy','note','createdAt','actedAt'], []);
    appendRowsIfEmpty('VendorControlPolicies', ['policyId','vendorId','settlementAccess','depositAccess','fundAccess','sensitiveView','rawDownload','excelDownload','postCancelApprove','employeeApproveStage','memo','updatedAt'], [
      ['VCP-0001','DEFAULT','APPROVAL','APPROVAL','APPROVAL','BLOCK','BLOCK','BLOCK','APPROVAL','2STEP','기본 민감권한 통제정책',ts()],
      ['VCP-0002','VND-0001','APPROVAL','APPROVAL','APPROVAL','BLOCK','BLOCK','BLOCK','APPROVAL','2STEP','샘플 업체 정책',ts()]
    ]);
    appendRowsIfEmpty('SensitiveAccessRequests', ['accessId','vendorId','employeeId','requestType','targetMenu','status','requestedBy','approvedBy','note','createdAt','approvedAt'], [
      ['SAR-0001','VND-0001','EMP-0001','MENU_ACCESS','정산조회','PENDING','대표계정','', '정산조회 필요', ts(),'']
    ]);

    appendRowsIfEmpty('EvidenceMailQueue', ['queueId','customerId','customerEmail','docType','saleId','status','requestedAt','sentAt','note'], []);
    appendRowsIfEmpty('InstallCompletions', ['installId','saleId','customerId','vendorId','status','stage','completedAt','memo','photoUrl','revisitReason','assignedTeam','assignedEngineer','vehicleNo','visitTime'], []);
    appendRowsIfEmpty('SaleItems', ['itemId','saleId','lineNo','itemName','qty','unitPrice','supplyAmount','discountAmount','lineAmount','createdAt'], []);
    appendRowsIfEmpty('CardData', ['cardDataId','cardCompany','approvalNo','cardHolder','amount','status','saleId','createdAt'], [
      ['CD-0001','삼성카드','A1001','홍길동',1500000,'READY','',ts()],
      ['CD-0002','현대카드','A1002','김영희',980000,'READY','',ts()],
      ['CD-0003','국민카드','A1003','박민수',650000,'MATCHED','SAL-0001',ts()]
    ]);
    appendRowsIfEmpty('InstallAssignments', ['assignmentId','saleId','vendorId','installId','teamName','engineer','vehicleNo','visitDate','visitTime','status','memo','createdAt','updatedAt'], []);
    appendRowsIfEmpty('SettlementAdjustments', ['adjustmentId','saleId','vendorId','adjustmentType','reason','amount','status','createdAt'], []);
    appendRowsIfEmpty('SettlementTargets', getSettlementTargetHeaders_(), []);
    appendRowsIfEmpty('DiagnosticsLog', ['logId','level','project','menu','fn','errorTime','message','lastStep','relatedId','rawLog','createdAt'], []);
    return { ok:true, buildNo:BUILD_NO, message:'ERP 통합빌드 v64-B06J34C setup 완료' };
  }

  function readCustomers(){
    return readTable('ERP_고객관리').map(function(r){
      return {
        customerId:s(r.customerId),
        name:s(r.name),
        phone:normalizePhone(r.phone),
        email:s(r.email),
        memberType:s(r.memberType),
        eventType:s(r.eventType),
        qrSource:s(r.qrSource),
        dong:s(r.dong),
        hosu:s(r.hosu),
        aptName:s(r.aptName),
        address:s(r.address),
        status:s(r.status) || 'ACTIVE',
        createdAt:s(r.createdAt)
      };
    });
  }

  function normalizeEventStatus_(v){ var x=s(v); var m={ACTIVE:'운영중',OPEN:'운영중',READY:'준비중',DRAFT:'준비중',HOLD:'보류',INACTIVE:'중지',CLOSED:'종료'}; return m[x] || x; }
  function normalizeVendorStatus_(v){ var x=s(v); var m={ACTIVE:'운영중',OPEN:'운영중',READY:'운영대기',INACTIVE:'중지',HOLD:'보류',CLOSED:'종료'}; return m[x] || x; }
  function readEvents(){ return readTable('ERP_행사관리').map(function(r){ r.status = normalizeEventStatus_(r.status || r['상태값']); return r; }); }
  function activeEvents(){ return readEvents().filter(function(r){ return ['중지','종료','INACTIVE','CLOSED'].indexOf(s(r.status)) < 0; }); }
  function readVendors(){ return readTable('ERP_업체관리').map(function(r){ r.status = normalizeVendorStatus_(r.status || r['상태값']); return r; }); }
  function activeVendors(){ return readVendors().filter(function(r){ return ['중지','종료','INACTIVE','CLOSED'].indexOf(s(r.status)) < 0; }); }

  function readSales(){
    return readTable('Sales').map(function(r){
      return {
        saleId:s(r.saleId), eventId:s(r.eventId), vendorId:s(r.vendorId), customerId:s(r.customerId),
        productSummary:s(r.productSummary), itemCount:n(r.itemCount), quantityTotal:n(r.quantityTotal), unitPrice:n(r.unitPrice),
        supplyAmount:n(r.supplyAmount), discountAmount:n(r.discountAmount), totalAmount:n(r.totalAmount),
        depositAmount:n(r.depositAmount), midAmount:n(r.midAmount), balanceAmount:n(r.balanceAmount),
        paymentMethod:s(r.paymentMethod), paymentStructure:s(r.paymentStructure),
        payment1Type:s(r.payment1Type), payment1Amount:n(r.payment1Amount),
        payment2Type:s(r.payment2Type), payment2Amount:n(r.payment2Amount),
        cardCompany:s(r.cardCompany), cardDataId:s(r.cardDataId), cardMatchStatus:s(r.cardMatchStatus) || (s(r.cardDataId) ? 'MATCHED' : (s(r.paymentMethod) === 'CARD' ? 'UNMATCHED' : 'NONE')),
        status:s(r.status) || 'SAVED', saleStage:s(r.saleStage) || s(r.status) || 'SAVED',
        installStatus:s(r.installStatus) || '배정전', settlementStatus:s(r.settlementStatus) || 'READY',
        installDate:s(r.installDate), installer:s(r.installer), createdAt:s(r.createdAt)
      };
    });
  }

  function recentSales(){ return readSales().slice(-50).reverse(); }
  function readAS(){ return readTable('ASRequests').map(function(r){ return { asId:s(r.asId), contractId:s(r.contractId), saleId:s(r.saleId), eventId:s(r.eventId), vendorId:s(r.vendorId), customerId:s(r.customerId), status:s(r.status), statusReason:s(r.statusReason), createdAt:s(r.createdAt), createdBy:s(r.createdBy), updatedAt:s(r.updatedAt), updatedBy:s(r.updatedBy), content:s(r.content), priority:s(r.priority), assignee:s(r.assignee), cost:n(r.cost), costOwner:s(r.costOwner), resultMemo:s(r.resultMemo), claimType:s(r.claimType) || 'GENERAL', claimStatus:s(r.claimStatus) || 'NONE', claimAmount:n(r.claimAmount), visitDate:s(r.visitDate) }; }); }
  function recentAS(){ return readAS().slice(-20).reverse(); }
  function readInstalls(){ return readTable('Installs').map(function(r){ return { installId:s(r.installId), contractId:s(r.contractId), saleId:s(r.saleId), eventId:s(r.eventId), vendorId:s(r.vendorId), customerId:s(r.customerId), status:s(r.status), statusReason:s(r.statusReason), createdAt:s(r.createdAt), createdBy:s(r.createdBy), updatedAt:s(r.updatedAt), updatedBy:s(r.updatedBy), recordMode:s(r.recordMode), reviewStatus:s(r.reviewStatus), batchTag:s(r.batchTag), remarks:s(r.remarks) }; }); }
  function recentInstalls(){ return readInstalls().slice(-20).reverse(); }
  function readSaleItems(){ return readTable('SaleItems').map(function(r){ return { itemId:s(r.itemId), saleId:s(r.saleId), lineNo:n(r.lineNo), itemName:s(r.itemName), qty:n(r.qty), unitPrice:n(r.unitPrice), supplyAmount:n(r.supplyAmount), discountAmount:n(r.discountAmount), lineAmount:n(r.lineAmount), createdAt:s(r.createdAt) }; }); }
  function readCardData(){ return readTable('CardData').map(function(r){ return { cardDataId:s(r.cardDataId), cardCompany:s(r.cardCompany), approvalNo:s(r.approvalNo), cardHolder:s(r.cardHolder), amount:n(r.amount), status:s(r.status) || 'READY', saleId:s(r.saleId), createdAt:s(r.createdAt) }; }); }
  function readInstallAssignments(){ return readTable('InstallAssignments').map(function(r){ return { assignmentId:s(r.assignmentId), saleId:s(r.saleId), vendorId:s(r.vendorId), installId:s(r.installId), teamName:s(r.teamName), engineer:s(r.engineer), vehicleNo:s(r.vehicleNo), visitDate:s(r.visitDate), visitTime:s(r.visitTime), status:s(r.status), memo:s(r.memo), createdAt:s(r.createdAt), updatedAt:s(r.updatedAt) }; }); }
  function readSettlementAdjustments(){ return readTable('SettlementAdjustments').map(function(r){ return { adjustmentId:s(r.adjustmentId), saleId:s(r.saleId), vendorId:s(r.vendorId), adjustmentType:s(r.adjustmentType), reason:s(r.reason), amount:n(r.amount), status:s(r.status), createdAt:s(r.createdAt) }; }); }
  function readEvidenceQueue(){ return readTable('EvidenceMailQueue').map(function(r){ return { queueId:s(r.queueId), customerId:s(r.customerId), customerEmail:s(r.customerEmail), docType:s(r.docType), saleId:s(r.saleId), status:s(r.status), requestedAt:s(r.requestedAt), sentAt:s(r.sentAt), note:s(r.note) }; }); }
  function recentEvidenceQueue(){ return readEvidenceQueue().slice(-30).reverse(); }
  function readCancellations(){ return readTable('Cancellations').map(function(r){ return { cancellationId:s(r.cancellationId), saleId:s(r.saleId), reasonType:s(r.reasonType), customerRefund:n(r.customerRefund), status:s(r.status), createdAt:s(r.createdAt) }; }); }
  function readPermissionRequests(){ return readTable('PermissionRequests'); }
  function readOnboardings(){ return readTable('Onboardings'); }
  function readBenefitPayouts(){ return readTable('BenefitPayouts'); }
  function readFundExecutions(){ return readTable('FundExecutions'); }
  function readDepositLedger(){ return readTable('DepositLedger').map(function(r){ return { ledgerId:s(r.ledgerId), vendorId:s(r.vendorId), ledgerType:s(r.ledgerType), amount:n(r.amount), balanceAfter:n(r.balanceAfter), eventId:s(r.eventId), memo:s(r.memo), createdAt:s(r.createdAt) }; }); }
  function readMonthlyClosings(){ return readTable('MonthlyClosings').map(function(r){ return { closingId:s(r.closingId), closingMonth:s(r.closingMonth), vendorId:s(r.vendorId), salesAmount:n(r.salesAmount), status:s(r.status), createdAt:s(r.createdAt) }; }); }

  function installPendingSales(){
    return readSales().filter(function(v){ return ['SAVED','INSTALL_PENDING'].indexOf(v.status) > -1; }).slice(-30).reverse();
  }

  function salesByCustomerMap(){
    var map = {};
    readSales().forEach(function(v){
      var key = String(v.customerId || '');
      if (!map[key]) map[key] = [];
      map[key].push(v);
    });
    return map;
  }

  function cancellationsBySaleMap(){
    var map = {};
    readCancellations().forEach(function(v){
      var key = String(v.saleId || '');
      if (!map[key]) map[key] = [];
      map[key].push(v);
    });
    return map;
  }

  function evidenceByCustomerMap(){
    var map = {};
    readEvidenceQueue().forEach(function(v){
      var key = String(v.customerId || '');
      if (!map[key]) map[key] = [];
      map[key].push(v);
    });
    return map;
  }

  function saleItemsBySaleMap(){
    var map = {};
    readSaleItems().forEach(function(v){
      var key = String(v.saleId || '');
      if (!map[key]) map[key] = [];
      map[key].push(v);
    });
    return map;
  }

  function installAssignmentsBySaleMap(){
    var map = {};
    readInstallAssignments().forEach(function(v){
      var key = String(v.saleId || '');
      if (!map[key]) map[key] = [];
      map[key].push(v);
    });
    return map;
  }

  function parseItemLines(text){
    var raw = s(text);
    if (!raw) return [];
    return raw.split(/\n+/).map(function(line, idx){
      var parts = line.split('|');
      return {
        lineNo: idx + 1,
        itemName: s(parts[0]),
        qty: n(parts[1] || 1),
        unitPrice: n(parts[2] || 0),
        supplyAmount: n(parts[3] || 0),
        discountAmount: n(parts[4] || 0)
      };
    }).filter(function(v){ return v.itemName; }).map(function(v){
      var lineAmount = Math.max((v.qty * v.unitPrice) - v.discountAmount, 0);
      if (!v.supplyAmount) v.supplyAmount = v.qty * v.unitPrice;
      v.lineAmount = lineAmount;
      return v;
    });
  }

  function saveSaleItems(saleId, itemLinesText){
    var lines = parseItemLines(itemLinesText);
    if (!lines.length) return [];
    var sh = ensureSheet('SaleItems', ['itemId','saleId','lineNo','itemName','qty','unitPrice','supplyAmount','discountAmount','lineAmount','createdAt']);
    var rows = lines.map(function(v){
      return [nextId('ITM-', sh, 1), saleId, v.lineNo, v.itemName, v.qty, v.unitPrice, v.supplyAmount, v.discountAmount, v.lineAmount, ts()];
    });
    sh.getRange(sh.getLastRow()+1,1,rows.length,rows[0].length).setValues(rows);
    return lines;
  }

  function autoMatchCardData(cardDataId, saleId){
    if (!cardDataId || !saleId) return false;
    try {
      updateRowById('CardData', 'cardDataId', cardDataId, { saleId:saleId, status:'MATCHED' });
      return true;
    } catch (e) {
      return false;
    }
  }


  function searchCustomers(query){
    var q = s(query).toLowerCase();
    var digits = phoneDigits(query);
    return readCustomers().filter(function(c){
      if (!q && !digits) return true;
      var hay = [c.customerId,c.name,c.phone,c.email,c.memberType,c.eventType,c.qrSource,c.dong,c.hosu,c.aptName,c.address].join(' ').toLowerCase();
      var hayDigits = hay.replace(/[^0-9]/g,'');
      return hay.indexOf(q) > -1 || (digits && hayDigits.indexOf(digits) > -1);
    }).slice(0,30);
  }

  function getRecentCustomers(limit){
    return readCustomers().slice(-1 * (Number(limit || 10))).reverse();
  }

  function getEvidenceQueueByCustomer(customerId){
    return readEvidenceQueue().filter(function(v){ return s(v.customerId) === String(customerId); }).slice(-20).reverse();
  }

  function getCustomerTimeline(customerId){
    var sales = readSales().filter(function(v){ return v.customerId === String(customerId); }).slice(-20).reverse();
    var installs = readInstalls().filter(function(v){ return s(v.customerId) === String(customerId); }).slice(-20).reverse();
    var evidence = getEvidenceQueueByCustomer(customerId);
    var saleIds = sales.map(function(v){ return v.saleId; });
    var cancels = readCancellations().filter(function(v){ return saleIds.indexOf(s(v.saleId)) > -1; }).slice(-20).reverse();
    return { sales:sales, installs:installs, evidence:evidence, cancellations:cancels };
  }

  function getCustomerDetail(customerId){
    var found = readCustomers().filter(function(c){ return c.customerId === String(customerId); })[0];
    if (!found) throw new Error('고객을 찾지 못했습니다: ' + customerId);
    var sales = readSales().filter(function(v){ return v.customerId === found.customerId; }).slice(-10).reverse();
    return { customer: found, sales: sales, evidenceQueue: getEvidenceQueueByCustomer(found.customerId), timeline: getCustomerTimeline(found.customerId) };
  }

  function getSaleDetail(saleId){
    var sale = readSales().filter(function(v){ return v.saleId === String(saleId); })[0];
    if (!sale) throw new Error('판매를 찾지 못했습니다: ' + saleId);
    var customer = readCustomers().filter(function(c){ return c.customerId === sale.customerId; })[0] || null;
    return { sale: sale, customer: customer, evidenceQueue: customer ? getEvidenceQueueByCustomer(customer.customerId) : [] };
  }

  function getOperationsSnapshot(){
    var permissionRequests = readPermissionRequests().slice(-30).reverse();
    var onboardings = readOnboardings().slice(-30).reverse();
    var cancellations = readCancellations().slice(-30).reverse();
    var benefitPayouts = readBenefitPayouts().slice(-30).reverse();
    var fundExecutions = readFundExecutions().slice(-30).reverse();
    var deposits = readDepositLedger().slice(-30).reverse();
    var closings = readMonthlyClosings().slice(-30).reverse();
    var evidenceQueue = recentEvidenceQueue();
    var installs = recentInstalls();
    return {
      accounting:{
        settlementsReady: closings.filter(function(v){ return s(v.status) === 'READY'; }).length,
        settlementsPaid: closings.filter(function(v){ return s(v.status) === 'PAID'; }).length,
        benefitApproved: benefitPayouts.filter(function(v){ return s(v.status) === 'APPROVED'; }).length,
        fundApproved: fundExecutions.filter(function(v){ return s(v.status) === 'APPROVED'; }).length,
        cancellationApproved: cancellations.filter(function(v){ return s(v.status) === 'APPROVED'; }).length
      },
      permissionRequests:permissionRequests,
      onboardings:onboardings,
      cancellations:cancellations,
      benefitPayouts:benefitPayouts,
      fundExecutions:fundExecutions,
      deposits:deposits,
      closings:closings,
      evidenceQueue:evidenceQueue,
      installs:installs
    };
  }

  function addDiagnosticsLog(payload){
    var sh = ensureSheet('DiagnosticsLog', ['logId','level','project','menu','fn','errorTime','message','lastStep','relatedId','rawLog','createdAt']);
    var id = nextId('LOG-', sh, 1);
    sh.appendRow([id, s(payload.level || 'INFO'), s(payload.project || 'ERP'), s(payload.menu || ''), s(payload.fn || ''), s(payload.errorTime || ts()), s(payload.message || ''), s(payload.lastStep || ''), s(payload.relatedId || ''), s(payload.rawLog || ''), ts()]);
    return { ok:true, logId:id };
  }

  function getDiagnosticsBundle(){
    var rows = readTable('DiagnosticsLog').slice(-50).reverse();
    function fmt(arr){
      return arr.map(function(v){
        return [
          '프로젝트: ' + (v.project || 'ERP'),
          '메뉴: ' + (v.menu || ''),
          '실행함수: ' + (v.fn || ''),
          '오류시간: ' + (v.errorTime || ''),
          '오류메시지: ' + (v.message || ''),
          '마지막 처리단계: ' + (v.lastStep || ''),
          '관련 ID: ' + (v.relatedId || ''),
          '로그원문: ' + (v.rawLog || '')
        ].join('\n');
      }).join('\n\n--------------------\n\n');
    }
    return {
      rows: rows,
      allText: fmt(rows),
      errorText: fmt(rows.filter(function(v){ return String(v.level || '').toUpperCase() === 'ERROR'; })),
      debugText: fmt(rows.filter(function(v){ return String(v.level || '').toUpperCase() === 'DEBUG'; })),
      resultText: [
        '프로젝트: ERP',
        '전체 로그수: ' + rows.length,
        'ERROR 수: ' + rows.filter(function(v){ return String(v.level || '').toUpperCase() === 'ERROR'; }).length,
        'DEBUG 수: ' + rows.filter(function(v){ return String(v.level || '').toUpperCase() === 'DEBUG'; }).length,
        '최근 로그ID: ' + (rows[0] ? rows[0].logId : '')
      ].join('\n')
    };
  }

  function kpi(){
    var sales = readSales();
    var asItems = readAS();
    var customers = readCustomers();
    var installs = readInstalls();
    var ops = getOperationsSnapshot();
    return {
      todaySalesCount: sales.length,
      installPending: sales.filter(function(v){ return ['SAVED','INSTALL_PENDING'].indexOf(v.status) > -1; }).length,
      asOpen: asItems.filter(function(v){ return s(v.status) !== 'DONE'; }).length,
      settlementPending: ops.closings.filter(function(v){ return s(v.status) !== 'PAID'; }).length,
      customerCount: customers.length,
      benefitPending: ops.benefitPayouts.filter(function(v){ return s(v.status) !== 'APPROVED'; }).length,
      installDone: installs.length
    };
  }

  function getErpBootstrap(){
    syncSystemConfig();
    var ops = getOperationsSnapshot();
    return {
      me:{ name:'ERP 관리자', role:'SUPER_ADMIN', vendorId:'' },
      kpi:kpi(),
      ops:{
        permissionPending:ops.permissionRequests.length,
        onboardingDraft:ops.onboardings.length,
        cancellationPending:ops.cancellations.length,
        fundPending:ops.fundExecutions.length,
        evidencePending:ops.evidenceQueue.length,
        benefitPending:ops.benefitPayouts.filter(function(v){ return s(v.status) !== 'APPROVED'; }).length,
        installDone:ops.installs.length
      },
      sales:recentSales(),
      asItems:recentAS(),
      installs:ops.installs,
      installPendingRows:installPendingSales(),
      evidenceRows:recentEvidenceQueue(),
      cancellationRows:ops.cancellations.slice(0,20),
      events:activeEvents(),
      vendors:activeVendors(),
      recentCustomers:getRecentCustomers(8)
    };
  }

  function getAdminWorkbench(){
    var ops = getOperationsSnapshot();
    return {
      accounting:ops.accounting,
      depositRows:ops.deposits,
      closings:ops.closings,
      evidenceQueue:ops.evidenceQueue,
      installs:ops.installs,
      installPendingRows:installPendingSales(),
      cardDataRows:getCardDataList(''),
      installAssignments:readInstallAssignments().slice(-50).reverse(),
      settlementDetail:getSettlementDetailSummary('ALL'),
      claimSummary:getClaimSummary(),
      diagnosticsCategory:getDiagnosticsCategorySummary()
    };
  }

  function normalizeCustomerMatchPhone_(value){
    return String(value || '').replace(/[^0-9]/g, '');
  }

  function normalizeCustomerMatchText_(value){
    return String(value || '').trim().replace(/\s+/g, '').toLowerCase();
  }

  function getCustomerSheetPack_(sheetName, headers){
    var sh = ensureSheet(sheetName, headers);
    var vals = sh.getDataRange().getDisplayValues();
    var header = vals.length ? vals[0].map(function(h){ return String(h || '').trim(); }) : headers;
    var idx = {};
    header.forEach(function(h, i){ idx[h] = i; });
    return { sheet: sh, values: vals, header: header, idx: idx };
  }

  function fhSafeCustomerCell_(row, idx, key){ return idx[key] != null ? String(row[idx[key]] || '').trim() : ''; }
  function isCompleteCustomerPhoneForMatch_(value){
    var d = normalizeCustomerMatchPhone_(value);
    return /^010\d{8}$/.test(d);
  }

  function findCustomerById_(sheetName, headers, customerId){
    var pack = getCustomerSheetPack_(sheetName, headers);
    if (pack.values.length < 2 || pack.idx.customerId == null) return null;
    var target = String(customerId || '').trim();
    if (!target) return null;
    for (var r = pack.values.length - 1; r >= 1; r--){
      var row = pack.values[r];
      var existingId = fhSafeCustomerCell_(row, pack.idx, 'customerId');
      if (existingId && existingId === target) return { rowNumber:r+1, row:row, header:pack.header, idx:pack.idx, customerId:existingId, matchType:'CUSTOMER_ID' };
    }
    return null;
  }

  function findRegularCustomerByEventDongHo_(sheetName, headers, payload){
    var pack = getCustomerSheetPack_(sheetName, headers);
    if (pack.values.length < 2) return null;
    var incoming = {
      eventId: normalizeCustomerMatchText_(payload.eventId),
      dong: normalizeCustomerMatchText_(payload.dong),
      ho: normalizeCustomerMatchText_(payload.ho || payload.hosu)
    };
    if (!incoming.eventId || !incoming.dong || !incoming.ho) return null;
    function homeHo(row){ return normalizeCustomerMatchText_(fhSafeCustomerCell_(row, pack.idx, 'ho') || fhSafeCustomerCell_(row, pack.idx, 'hosu')); }
    for (var rh = pack.values.length - 1; rh >= 1; rh--){
      var rowh = pack.values[rh];
      var existingId = fhSafeCustomerCell_(rowh, pack.idx, 'customerId');
      if (!existingId) continue;
      var sameEvent = normalizeCustomerMatchText_(fhSafeCustomerCell_(rowh, pack.idx, 'eventId')) === incoming.eventId;
      var sameDong = normalizeCustomerMatchText_(fhSafeCustomerCell_(rowh, pack.idx, 'dong')) === incoming.dong;
      var sameHo = homeHo(rowh) === incoming.ho;
      if (sameEvent && sameDong && sameHo) return { rowNumber:rh+1, row:rowh, header:pack.header, idx:pack.idx, customerId:existingId, matchType:'EVENT_DONG_HO' };
    }
    return null;
  }


  function findRegularCustomerForQuick(payload){
    syncSystemConfig();
    payload = payload || {};
    var headers = ['customerId','eventId','vendorId','name','phone','email','memberType','customerType','regularCheck','eventType','qrSource','dong','hosu','aptName','address','status','statusReason','createdAt','createdBy','updatedAt','updatedBy'];
    var sheetName = 'ERP_고객관리';
    var eventId = s(payload.eventId);
    var dong = s(payload.dong);
    var hoValue = s(payload.hosu || payload.ho);
    if (!eventId || !dong || !hoValue) throw new Error('정회원 기존 고객 찾기는 eventId + dong + ho가 모두 필요합니다.');
    var found = findRegularCustomerByEventDongHo_(sheetName, headers, { eventId:eventId, dong:dong, ho:hoValue, hosu:hoValue });
    if (!found || !found.customerId) {
      return { ok:true, found:false, matchType:'EVENT_DONG_HO', eventId:eventId, dong:dong, ho:hoValue, message:'기존 고객 없음. 신규 고객 생성 시 새 customerId를 발급합니다.' };
    }
    var obj = {};
    found.header.forEach(function(h,i){ obj[h] = found.row[i] || ''; });
    obj.hosu = obj.hosu || obj.ho || '';
    return { ok:true, found:true, customer:obj, customerId:found.customerId, matchType:'EVENT_DONG_HO', eventId:eventId, dong:dong, ho:hoValue, overwriteBlocked:true, message:'기존 고객 확인: ' + found.customerId + ' / 고객정보 자동 덮어쓰기 안 함' };
  }

  function findAssociateCustomerSafely_(sheetName, headers, payload){
    var pack = getCustomerSheetPack_(sheetName, headers);
    if (pack.values.length < 2) return null;
    var incoming = {
      phone: normalizeCustomerMatchPhone_(payload.phone),
      email: normalizeCustomerMatchText_(payload.email),
      name: normalizeCustomerMatchText_(payload.name),
      dong: normalizeCustomerMatchText_(payload.dong),
      ho: normalizeCustomerMatchText_(payload.ho || payload.hosu)
    };
    if (isCompleteCustomerPhoneForMatch_(incoming.phone)){
      for (var r2 = pack.values.length - 1; r2 >= 1; r2--){
        var row2 = pack.values[r2];
        var phone2 = normalizeCustomerMatchPhone_(fhSafeCustomerCell_(row2, pack.idx, 'phone'));
        if (isCompleteCustomerPhoneForMatch_(phone2) && phone2 === incoming.phone) return { rowNumber:r2+1, row:row2, header:pack.header, idx:pack.idx, customerId:fhSafeCustomerCell_(row2, pack.idx, 'customerId'), matchType:'PHONE' };
      }
    }
    if (incoming.email){
      for (var r3 = pack.values.length - 1; r3 >= 1; r3--){
        var row3 = pack.values[r3];
        var email3 = normalizeCustomerMatchText_(fhSafeCustomerCell_(row3, pack.idx, 'email'));
        if (email3 && email3 === incoming.email) return { rowNumber:r3+1, row:row3, header:pack.header, idx:pack.idx, customerId:fhSafeCustomerCell_(row3, pack.idx, 'customerId'), matchType:'EMAIL' };
      }
    }
    if (incoming.name && incoming.dong && incoming.ho){
      for (var r4 = pack.values.length - 1; r4 >= 1; r4--){
        var row4 = pack.values[r4];
        var sameName = normalizeCustomerMatchText_(fhSafeCustomerCell_(row4, pack.idx, 'name')) === incoming.name;
        var sameDong = normalizeCustomerMatchText_(fhSafeCustomerCell_(row4, pack.idx, 'dong')) === incoming.dong;
        var sameHo = normalizeCustomerMatchText_(fhSafeCustomerCell_(row4, pack.idx, 'ho') || fhSafeCustomerCell_(row4, pack.idx, 'hosu')) === incoming.ho;
        if (sameName && sameDong && sameHo) return { rowNumber:r4+1, row:row4, header:pack.header, idx:pack.idx, customerId:fhSafeCustomerCell_(row4, pack.idx, 'customerId'), matchType:'NAME_DONG_HO' };
      }
    }
    return null;
  }

  function updateCustomerById_(sheetName, found, updates){
    var sh = getDbSpreadsheet().getSheetByName(sheetName);
    if (!sh || !found) return false;
    Object.keys(updates || {}).forEach(function(key){
      var col = found.idx[key];
      var value = updates[key];
      if (col != null && value !== undefined && value !== null) sh.getRange(found.rowNumber, col + 1).setValue(value);
    });
    return true;
  }

  function normalizeMemberType_(value){
    var v = String(value || '').trim().toUpperCase();
    if (!v || v === '정회원' || v === 'REGULAR' || v === 'MEMBER') return 'REGULAR';
    if (v === '준회원' || v === 'ASSOCIATE' || v === 'TEMP') return 'ASSOCIATE';
    return v;
  }

  function updateCustomerById(payload){
    syncSystemConfig();
    payload = payload || {};
    var headers = ['customerId','eventId','vendorId','name','phone','email','memberType','customerType','regularCheck','eventType','qrSource','dong','hosu','aptName','address','status','statusReason','createdAt','createdBy','updatedAt','updatedBy'];
    var sheetName = 'ERP_고객관리';
    var customerId = s(payload.customerId);
    if (!customerId) throw new Error('수정할 customerId가 필요합니다. 고객 검색에서 고객을 먼저 선택하세요.');
    var found = findCustomerById_(sheetName, headers, customerId);
    if (!found) throw new Error('수정 대상 고객을 찾지 못했습니다: ' + customerId);
    var memberType = normalizeMemberType_(payload.memberType);
    var customerType = s(payload.customerType) || memberType;
    var hoValue = s(payload.hosu || payload.ho);
    var now = ts();
    var updates = {
      eventId:s(payload.eventId), vendorId:s(payload.vendorId), name:s(payload.name), phone:normalizePhone(payload.phone), email:s(payload.email), memberType:memberType, customerType:customerType,
      regularCheck:s(payload.regularCheck) || (memberType === 'REGULAR' ? 'PENDING' : ''), eventType:s(payload.eventType), qrSource:s(payload.qrSource), dong:s(payload.dong), hosu:hoValue,
      aptName:s(payload.aptName || payload.apt), address:s(payload.address), status:s(payload.status) || 'ACTIVE', statusReason:s(payload.statusReason), updatedAt:now, updatedBy:s(payload.updatedBy) || 'system'
    };
    updateCustomerById_(sheetName, found, updates);
    try { appendObjectByHeader_('SystemLogs', ['logId','createdAt','createdBy','actionType','targetId','status','statusReason','beforeValue','afterValue','meta'], { logId:'LOG-' + Utilities.getUuid().replace(/-/g,'').substring(0,12).toUpperCase(), createdAt:now, createdBy:s(payload.updatedBy)||'system', actionType:'CUSTOMER_UPDATE_BY_ID', targetId:customerId, status:'SUCCESS', statusReason:'선택 고객 수정 저장', beforeValue:'', afterValue:JSON.stringify(updates), meta:'B06H8_REGULAR_BULK_UPLOAD_SAFE' }); } catch(e) {}
    return { ok:true, customerId:customerId, updated:true, reused:false, matchType:'CUSTOMER_ID', message:'선택 고객 수정 완료: ' + customerId };
  }

  function saveCustomer(payload){
    syncSystemConfig();
    payload = payload || {};
    var headers = ['customerId','eventId','vendorId','name','phone','email','memberType','customerType','regularCheck','eventType','qrSource','dong','hosu','aptName','address','status','statusReason','createdAt','createdBy','updatedAt','updatedBy'];
    var sheetName = 'ERP_고객관리';
    var sh = ensureSheet(sheetName, headers);
    var now = ts();
    var memberType = normalizeMemberType_(payload.memberType);
    var customerType = s(payload.customerType) || memberType;
    var regularCheck = s(payload.regularCheck) || (memberType === 'REGULAR' ? 'PENDING' : '');
    var hoValue = s(payload.hosu || payload.ho);
    if (memberType === 'REGULAR') {
      if (!s(payload.eventId) || !s(payload.dong) || !hoValue) {
        throw new Error('정회원은 행사 선택 + 동 + 호가 필수입니다. 이름/전화번호는 선택값입니다.');
      }
    } else {
      if (!s(payload.name) && !normalizePhone(payload.phone)) {
        throw new Error('준회원은 이름 또는 전화번호 중 하나가 필요합니다.');
      }
    }
    var updateObj = {
      eventId:s(payload.eventId), vendorId:s(payload.vendorId), name:s(payload.name), phone:normalizePhone(payload.phone), email:s(payload.email), memberType:memberType, customerType:customerType, regularCheck:regularCheck, eventType:s(payload.eventType), qrSource:s(payload.qrSource), dong:s(payload.dong), hosu:hoValue, aptName:s(payload.aptName || payload.apt), address:s(payload.address), status:'ACTIVE', statusReason:s(payload.statusReason), updatedAt:now, updatedBy:s(payload.updatedBy) || 'system'
    };
    var found = null;
    if (memberType === 'REGULAR') {
      // B06H8 안전 기준: 정회원 QR/DB 등록은 PHONE/EMAIL로 자동 덮어쓰기 금지.
      // 기존 고객 자동 재사용은 eventId + dong + ho 정확 일치일 때만 허용한다.
      found = findRegularCustomerByEventDongHo_(sheetName, headers, Object.assign({}, payload, { ho:hoValue, hosu:hoValue }));
    } else {
      // 준회원도 불완전 전화번호(010-, 010 등)는 중복 기준에서 제외한다.
      found = findAssociateCustomerSafely_(sheetName, headers, Object.assign({}, payload, { ho:hoValue, hosu:hoValue }));
    }
    if (found && found.customerId){
      return { ok:true, customerId:found.customerId, reused:true, updated:false, overwriteBlocked:true, matchType:found.matchType, eventId:updateObj.eventId, dong:updateObj.dong, hosu:updateObj.hosu, ho:updateObj.hosu, memberType:memberType, customerType:customerType, regularCheck:regularCheck, message:'기존 고객 확인: ' + found.customerId + ' / 기준: ' + found.matchType + ' / 고객정보 자동 덮어쓰기 안 함' };
    }
    var id = nextId('CUS-', sh, 1);
    appendObjectByHeader_(sheetName, headers, { customerId:id, eventId:updateObj.eventId, vendorId:updateObj.vendorId, name:updateObj.name, phone:updateObj.phone, email:updateObj.email, memberType:memberType, customerType:customerType, regularCheck:regularCheck, eventType:updateObj.eventType, qrSource:updateObj.qrSource, dong:updateObj.dong, hosu:updateObj.hosu, aptName:updateObj.aptName, address:updateObj.address, status:'ACTIVE', statusReason:'', createdAt:now, createdBy:s(payload.createdBy) || 'system', updatedAt:now, updatedBy:s(payload.updatedBy) || 'system' });
    return { ok:true, customerId:id, reused:false, created:true, matchType:'NEW', eventId:updateObj.eventId, dong:updateObj.dong, hosu:updateObj.hosu, ho:updateObj.hosu, memberType:memberType, customerType:customerType, regularCheck:regularCheck, message:'신규 고객 생성 완료: ' + id };
  }



  function fhB06H8ParseBulkLine_(line, delimiter){
    var out = [];
    var cur = '';
    var quote = false;
    delimiter = delimiter || '\t';
    for (var i = 0; i < line.length; i++){
      var ch = line.charAt(i);
      if (ch === '"') { quote = !quote; continue; }
      if (!quote && ch === delimiter) { out.push(cur); cur = ''; continue; }
      cur += ch;
    }
    out.push(cur);
    return out;
  }

  function fhB06H8CanonicalBulkHeader_(h){
    var k = String(h || '').trim().replace(/^\uFEFF/, '');
    var low = k.toLowerCase();
    var map = {
      'apartmentname':'aptName','apartment':'aptName','aptname':'aptName','apt':'aptName','아파트명':'aptName','단지명':'aptName','단지':'aptName','아파트':'aptName',
      'dong':'dong','동':'dong','동명':'dong',
      'ho':'hosu','hosu':'hosu','호':'hosu','호수':'hosu',
      'name':'name','customername':'name','성명':'name','이름':'name','고객명':'name',
      'phone':'phone','tel':'phone','mobile':'phone','전화':'phone','전화번호':'phone','휴대폰':'phone','휴대폰번호':'phone',
      'email':'email','mail':'email','이메일':'email',
      'address':'address','addr':'address','주소':'address',
      'memo':'memo','notes':'memo','note':'memo','메모':'memo','비고':'memo'
    };
    return map[low] || map[k] || low;
  }

  function fhB06H8ParseRegularBulkRows_(rawText){
    var text = String(rawText || '').replace(/\r\n/g, '\n').replace(/\r/g, '\n').trim();
    if (!text) return { rows:[], headers:[], errors:[{rowNo:0,message:'업로드할 내용이 없습니다.'}] };
    var lines = text.split('\n').filter(function(line){ return String(line || '').trim() !== ''; });
    if (!lines.length) return { rows:[], headers:[], errors:[{rowNo:0,message:'업로드할 내용이 없습니다.'}] };
    var delimiter = lines[0].indexOf('\t') >= 0 ? '\t' : ',';
    var rawHeaders = fhB06H8ParseBulkLine_(lines[0], delimiter).map(function(h){ return fhB06H8CanonicalBulkHeader_(h); });
    var hasDong = rawHeaders.indexOf('dong') >= 0;
    var hasHo = rawHeaders.indexOf('ho') >= 0;
    if (!hasDong || !hasHo) throw new Error('정회원 DB 업로드 첫 줄에는 동(dong/동)과 호(ho/호/호수) 헤더가 반드시 필요합니다.');
    var rows = [];
    var errors = [];
    for (var i = 1; i < lines.length; i++){
      var cells = fhB06H8ParseBulkLine_(lines[i], delimiter);
      var obj = { sourceRow:i + 1 };
      for (var c = 0; c < rawHeaders.length; c++) obj[rawHeaders[c]] = s(cells[c]);
      if (!s(obj.dong) || !s(obj.ho)) {
        errors.push({ rowNo:i + 1, status:'ERROR', message:'동/호 필수값 누락', raw:lines[i] });
        continue;
      }
      rows.push(obj);
    }
    return { rows:rows, headers:rawHeaders, errors:errors };
  }

  function bulkUploadRegularMembers(payload){
    syncSystemConfig();
    payload = payload || {};
    var eventId = s(payload.eventId);
    if (!eventId) throw new Error('정회원 DB 업로드는 행사 선택(eventId)이 필수입니다.');
    var vendorId = s(payload.vendorId);
    var regularCheck = s(payload.regularCheck) || 'CONFIRMED';
    var actor = s(payload.createdBy || payload.updatedBy) || 'system';
    var parse = fhB06H8ParseRegularBulkRows_(payload.rawText || payload.text || '');
    var headers = ['customerId','eventId','vendorId','name','phone','email','memberType','customerType','regularCheck','eventType','qrSource','dong','hosu','aptName','address','status','statusReason','createdAt','createdBy','updatedAt','updatedBy','memo','notes'];
    var sheetName = 'ERP_고객관리';
    var sh = ensureSheet(sheetName, headers);
    var now = ts();
    var results = [];
    var seen = {};
    var created = 0;
    var existing = 0;
    var skipped = 0;
    var errors = parse.errors || [];
    (parse.rows || []).forEach(function(row){
      var dong = s(row.dong);
      var ho = s(row.ho);
      var key = eventId + '|' + normalizeCustomerMatchText_(dong) + '|' + normalizeCustomerMatchText_(ho);
      if (seen[key]) {
        skipped++;
        results.push({ rowNo:row.sourceRow, status:'SKIPPED_DUPLICATE_IN_UPLOAD', customerId:seen[key], eventId:eventId, dong:dong, ho:ho, message:'업로드 파일 내 동일 행사+동+호 중복. 먼저 처리된 customerId 기준으로 건너뜀.' });
        return;
      }
      var found = findRegularCustomerByEventDongHo_(sheetName, headers, { eventId:eventId, dong:dong, ho:ho, hosu:ho });
      if (found && found.customerId) {
        existing++;
        seen[key] = found.customerId;
        results.push({ rowNo:row.sourceRow, status:'EXISTING', customerId:found.customerId, eventId:eventId, dong:dong, ho:ho, message:'기존 정회원 확인. 고객정보 자동 덮어쓰기 안 함.' });
        return;
      }
      var customerId = nextId('CUS-', sh, 1);
      appendObjectByHeader_(sheetName, headers, {
        customerId:customerId,
        eventId:eventId,
        vendorId:vendorId,
        name:s(row.name),
        phone:normalizePhone(row.phone),
        email:s(row.email),
        memberType:'REGULAR',
        customerType:'REGULAR',
        regularCheck:regularCheck,
        eventType:s(payload.eventType) || '입주박람회',
        qrSource:s(payload.qrSource) || 'DB_UPLOAD',
        dong:dong,
        hosu:ho,
        aptName:s(row.aptName || row.apartmentName),
        address:s(row.address),
        status:'ACTIVE',
        statusReason:'정회원 DB 업로드',
        createdAt:now,
        createdBy:actor,
        updatedAt:now,
        updatedBy:actor,
        memo:s(row.memo),
        notes:s(row.memo)
      });
      created++;
      seen[key] = customerId;
      results.push({ rowNo:row.sourceRow, status:'CREATED', customerId:customerId, eventId:eventId, dong:dong, ho:ho, message:'신규 정회원 생성 완료' });
    });
    try {
      appendObjectByHeader_('SystemLogs', ['logId','createdAt','createdBy','actionType','targetId','status','statusReason','beforeValue','afterValue','meta'], {
        logId:'LOG-' + Utilities.getUuid().replace(/-/g,'').substring(0,12).toUpperCase(),
        createdAt:now,
        createdBy:actor,
        actionType:'REGULAR_MEMBER_BULK_UPLOAD',
        targetId:eventId,
        status:'SUCCESS',
        statusReason:'정회원 DB 업로드',
        beforeValue:'',
        afterValue:JSON.stringify({ created:created, existing:existing, skipped:skipped, errorCount:errors.length }),
        meta:'B06H8_REGULAR_BULK_UPLOAD_SAFE'
      });
    } catch(e) {}
    return { ok:true, message:'정회원 DB 업로드 처리 완료', eventId:eventId, totalRows:(parse.rows || []).length + errors.length, processedRows:(parse.rows || []).length, createdCount:created, existingCount:existing, skippedCount:skipped, errorCount:errors.length, results:results, errors:errors, buildNo:'v64-B06J33A' };
  }

  function createQrSignDocumentForCustomer(payload){
    syncSystemConfig(); payload = payload || {}; var customerId = s(payload.customerId);
    if (!customerId) throw new Error('customerId가 필요합니다. 빠른고객등록 후 실행하세요.');
    var customer = getCustomerDetail(customerId).customer; var eventId = s(payload.eventId) || s(customer.eventId);
    if (!eventId) throw new Error('eventId가 필요합니다. 정회원 QR_SIGN 문서는 행사 기준으로 생성해야 합니다.');
    var vendorId = s(payload.vendorId) || s(customer.vendorId);
    var headers = ['documentId','documentNo','documentType','status','statusReason','eventId','vendorId','customerId','saleId','contractId','installId','settlementId','approvalId','title','templateCode','signMethod','signUrl','qrUrl','createdAt','createdBy','updatedAt','updatedBy','notes'];
    var sheetName = 'SIGN_Documents'; var sh = ensureSheet(sheetName, headers); var vals = sh.getDataRange().getDisplayValues(); var head = vals.length ? vals[0].map(function(h){ return String(h||'').trim(); }) : headers; var idx = {}; head.forEach(function(h,i){ idx[h]=i; });
    for (var r=1; r<vals.length; r++){ var row = vals[r]; if (String(row[idx.documentType] || '').trim().toUpperCase() === 'QR_SIGN' && String(row[idx.customerId] || '').trim() === customerId && String(row[idx.eventId] || '').trim() === eventId) { var reused = {}; head.forEach(function(h,i){ reused[h]=row[i] || ''; }); return { ok:true, reused:true, message:'QR_SIGN 기존 문서 재사용', data:reused, documentId:reused.documentId || '', signUrl:reused.signUrl || reused.qrUrl || '', status:reused.status || '' }; } }
    var now = ts(); var documentId = 'DOC_' + Utilities.getUuid().replace(/-/g,'').substring(0,12).toUpperCase(); var documentNo = 'DOC-' + Utilities.formatDate(new Date(), Session.getScriptTimeZone() || 'Asia/Seoul', 'yyyyMMdd') + '-' + Utilities.formatString('%03d', Math.max(1, sh.getLastRow()));
    var base = getProp('SIGN_WEBAPP_URL') || getProp('SIGN_WEB_APP_URL') || getProp('SIGN_URL') || 'https://script.google.com/macros/s/AKfycby7TkzJGBe9vW7eDmqOaDWYc23cQEzrYRC2hVVc1dvMdmk50r5stgDi4fPikMgeMPrU/exec'; base = String(base || '').split('?')[0]; var fieldLabel = s(customer.eventType) || '입주박람회'; var boothHint = s(customer.aptName || customer.apt) || (s(customer.dong) + '동 ' + s(customer.ho || customer.hosu) + '호'); var signUrl = base + '?mode=sign&documentId=' + encodeURIComponent(documentId) + '&fieldMode=QR&eventName=' + encodeURIComponent(fieldLabel) + '&boothHint=' + encodeURIComponent(boothHint);
    var rowObj = { documentId:documentId, documentNo:documentNo, documentType:'QR_SIGN', status:'READY_TO_SIGN', statusReason:'ERP 정회원 QR_SIGN 테스트 생성', eventId:eventId, vendorId:vendorId, customerId:customerId, saleId:'', contractId:'', installId:'', settlementId:'', approvalId:'', title:'QR 서명확인서', templateCode:'PDF_QR_SIGN', signMethod:'QR', signUrl:signUrl, qrUrl:signUrl, createdAt:now, createdBy:s(payload.createdBy)||'system', updatedAt:now, updatedBy:s(payload.updatedBy)||'system', notes:'ERP_B06H8 REGULAR QR_SIGN / dong=' + s(customer.dong) + ' ho=' + s(customer.ho || customer.hosu) };
    appendObjectByHeader_(sheetName, headers, rowObj);
    try { appendObjectByHeader_('SIGN_Document_Logs', ['logId','documentId','actionType','fromStatus','toStatus','actor','reason','createdAt'], { logId:'LOG-' + Utilities.getUuid().replace(/-/g,'').substring(0,12).toUpperCase(), documentId:documentId, actionType:'CREATE_QR_SIGN_FROM_ERP', fromStatus:'', toStatus:'READY_TO_SIGN', actor:s(payload.createdBy)||'system', reason:'정회원 QR_SIGN 테스트 문서 생성', createdAt:now }); } catch(e) {}
    return { ok:true, reused:false, message:'QR_SIGN 문서 생성 완료', data:rowObj, documentId:documentId, signUrl:signUrl, status:'READY_TO_SIGN', customerId:customerId, eventId:eventId, dong:s(customer.dong), ho:s(customer.ho || customer.hosu) };
  }

  function saveSale(payload){
    syncSystemConfig();
    var headers = ['saleId','eventId','vendorId','customerId','status','statusReason','createdAt','createdBy','updatedAt','updatedBy','productSummary','itemCount','quantityTotal','unitPrice','supplyAmount','discountAmount','totalAmount','depositAmount','midAmount','balanceAmount','paymentMethod','paymentStructure','payment1Type','payment1Amount','payment2Type','payment2Amount','cardCompany','cardDataId','cardMatchStatus','saleStage','installStatus','settlementStatus','installDate','installer'];
    var sh = ensureSheet('Sales', headers);
    var id = nextId('SAL-', sh, 1);
    var total = n(payload.totalAmount);
    var deposit = n(payload.depositAmount);
    var midAmount = n(payload.midAmount);
    var parsedLines = parseItemLines(payload.itemLinesText || '');
    if (parsedLines.length) {
      total = parsedLines.reduce(function(a,v){ return a + n(v.lineAmount); }, 0);
      if (!n(payload.supplyAmount)) payload.supplyAmount = parsedLines.reduce(function(a,v){ return a + n(v.supplyAmount); }, 0);
      if (!n(payload.discountAmount)) payload.discountAmount = parsedLines.reduce(function(a,v){ return a + n(v.discountAmount); }, 0);
      if (!n(payload.itemCount)) payload.itemCount = parsedLines.length;
      if (!n(payload.quantityTotal)) payload.quantityTotal = parsedLines.reduce(function(a,v){ return a + n(v.qty); }, 0);
      if (!n(payload.unitPrice)) payload.unitPrice = parsedLines.length ? Math.round(total / Math.max(parsedLines.reduce(function(a,v){ return a + n(v.qty); }, 0),1)) : 0;
    }
    var balance = payload.balanceAmount !== undefined && payload.balanceAmount !== null && String(payload.balanceAmount) !== '' ? n(payload.balanceAmount) : Math.max(total - deposit - midAmount, 0);
    var cardMatchStatus = s(payload.cardMatchStatus) || (s(payload.cardDataId) ? 'MATCHED' : (s(payload.paymentMethod) === 'CARD' ? 'UNMATCHED' : 'NONE'));
    var saleStage = s(payload.saleStage) || '계약완료';
    var now = ts();
    appendObjectByHeader_('Sales', headers, { saleId:id, eventId:s(payload.eventId), vendorId:s(payload.vendorId), customerId:s(payload.customerId), status:s(payload.status) || (saleStage === '임시저장' ? 'SAVED' : 'INSTALL_PENDING'), statusReason:s(payload.statusReason), createdAt:now, createdBy:'system', updatedAt:now, updatedBy:'system', productSummary:s(payload.productSummary), itemCount:n(payload.itemCount || 1), quantityTotal:n(payload.quantityTotal || 1), unitPrice:n(payload.unitPrice), supplyAmount:n(payload.supplyAmount), discountAmount:n(payload.discountAmount), totalAmount:total, depositAmount:deposit, midAmount:midAmount, balanceAmount:balance, paymentMethod:s(payload.paymentMethod), paymentStructure:s(payload.paymentStructure), payment1Type:s(payload.payment1Type || payload.paymentMethod), payment1Amount:n(payload.payment1Amount || total), payment2Type:s(payload.payment2Type), payment2Amount:n(payload.payment2Amount), cardCompany:s(payload.cardCompany), cardDataId:s(payload.cardDataId), cardMatchStatus:cardMatchStatus, saleStage:saleStage, installStatus:s(payload.installStatus) || '배정전', settlementStatus:s(payload.settlementStatus) || 'READY', installDate:s(payload.installDate), installer:s(payload.installer) });
    if (parsedLines.length) saveSaleItems(id, payload.itemLinesText);
    if (s(payload.cardDataId)) autoMatchCardData(s(payload.cardDataId), id);
    // B06J15: 판매 저장 직후 계약서는 자동 생성하지 않는다.
    // 정상 흐름은 판매 저장 → B05 계약서 생성대상 표시 → 사용자가 [계약서 생성] 실행이다.
    // 기존 onErpSaleSaved_CreateContractSign 함수는 수동 버튼/호환용으로 유지한다.
    try {
      appendObjectByHeader_('SystemLogs', ['logId','createdAt','createdBy','actionType','targetId','status','statusReason','beforeValue','afterValue','meta','reason','buildNo'], {
        logId:'LOG-' + Utilities.getUuid().replace(/-/g,'').substring(0,12).toUpperCase(),
        createdAt:now, createdBy:'system', actionType:'SALE_SAVED_CONTRACT_WORKLIST_WAIT', targetId:id, status:'READY',
        statusReason:'판매 저장 후 계약서 생성대상 대기', beforeValue:'', afterValue:JSON.stringify({saleId:id, customerId:s(payload.customerId)}),
        meta:JSON.stringify({buildNo:'v64-B06J33A', next:'B05_CONTRACT_WORKLIST'}), reason:'B06J15 계약서 자동생성 중지', buildNo:'v64-B06J33A'
      });
    } catch(logErr) {}
    return { ok:true, saleId:id, message:'판매 저장 완료 - B05 계약서 생성대상에 표시됩니다.' };
  }
  function queueEvidenceMail(payload){
    var sh = ensureSheet('EvidenceMailQueue', ['queueId','customerId','customerEmail','docType','saleId','status','requestedAt','sentAt','note']);
    var id = nextId('MAIL-', sh, 1);
    sh.appendRow([id, s(payload.customerId), s(payload.customerEmail), s(payload.docType), s(payload.saleId), 'PENDING', ts(), '', s(payload.note)]);
    return { ok:true, queueId:id };
  }

  function completeInstallation(payload){
    payload = payload || {};
    syncSystemConfig();

    var now = ts();
    var saleId = s(payload.saleId);
    var sale = saleId ? findFirstByField_('Sales', 'saleId', saleId) : null;
    if (!saleId && s(payload.installId)) {
      var installForSale = findFirstByField_('Installs', 'installId', s(payload.installId));
      saleId = s(installForSale && installForSale.saleId);
      sale = saleId ? findFirstByField_('Sales', 'saleId', saleId) : null;
    }
    if (!saleId) throw new Error('설치완료 처리에는 saleId 또는 기존 installId가 필요합니다.');

    var installId = getOrCreateInstallId_(payload, sale);
    var existingInstall = findFirstByField_('Installs', 'installId', installId) || findFirstByField_('Installs', 'saleId', saleId);
    var latestAssignment = findLastByField_('InstallAssignments', 'saleId', saleId);

    var eventId = s(payload.eventId) || s(existingInstall && existingInstall.eventId) || s(sale && sale.eventId);
    var vendorId = s(payload.vendorId) || s(existingInstall && existingInstall.vendorId) || s(sale && sale.vendorId) || s(latestAssignment && latestAssignment.vendorId);
    var customerId = s(payload.customerId) || s(existingInstall && existingInstall.customerId) || s(sale && sale.customerId);
    var contractId = s(payload.contractId) || s(existingInstall && existingInstall.contractId) || s(sale && sale.contractId);
    var engineer = s(payload.assignedEngineer || payload.installer) || s(latestAssignment && latestAssignment.engineer) || s(sale && sale.installer);
    var completedAt = s(payload.completedAt) || now;

    var completionHeaders = ['installId','saleId','customerId','vendorId','status','stage','completedAt','memo','photoUrl','revisitReason','assignedTeam','assignedEngineer','vehicleNo','visitTime'];
    upsertObjectByHeader_('InstallCompletions', completionHeaders, 'installId', installId, {
      installId:installId, saleId:saleId, customerId:customerId, vendorId:vendorId, status:'DONE', stage:'설치완료', completedAt:completedAt, memo:s(payload.memo), photoUrl:s(payload.photoUrl), revisitReason:s(payload.revisitReason), assignedTeam:s(payload.assignedTeam) || s(latestAssignment && latestAssignment.teamName), assignedEngineer:engineer, vehicleNo:s(payload.vehicleNo) || s(latestAssignment && latestAssignment.vehicleNo), visitTime:s(payload.visitTime) || s(latestAssignment && latestAssignment.visitTime)
    });

    syncInstallMasterFromSale_(installId, sale, { installId:installId, contractId:contractId, saleId:saleId, eventId:eventId, vendorId:vendorId, customerId:customerId, memo:s(payload.memo), statusReason:s(payload.statusReason) || '설치완료' }, 'COMPLETED', s(payload.statusReason) || '설치완료');

    ensureInstallAssignmentFromCompletion_({ installId:installId, saleId:saleId, vendorId:vendorId, assignedTeam:s(payload.assignedTeam) || s(latestAssignment && latestAssignment.teamName), assignedEngineer:engineer, vehicleNo:s(payload.vehicleNo) || s(latestAssignment && latestAssignment.vehicleNo), visitDate:completedAt, visitTime:s(payload.visitTime) || s(latestAssignment && latestAssignment.visitTime), completedAt:completedAt, memo:s(payload.memo), assignmentStatus:'COMPLETED' }, sale, latestAssignment);

    updateRowById('Sales', 'saleId', saleId, { status:s(sale && sale.status) || 'ACTIVE', saleStage:s(sale && sale.saleStage) || 'SALE_COMPLETED', installStatus:'COMPLETED', settlementStatus:'READY', installDate:completedAt, installer:engineer, updatedAt:now, updatedBy:'system' });

    var settlementTarget = ensureSettlementTargetFromInstall_(Object.assign({}, sale || {}, { saleId:saleId, eventId:eventId, vendorId:vendorId, customerId:customerId, installDate:completedAt, installer:engineer }), installId, completedAt, 'system');

    try {
      appendObjectByHeader_('DiagnosticsLog', ['logId','createdAt','level','area','action','targetId','message','meta','actor','status','errorCode'], { logId:'LOG-' + new Date().getTime(), createdAt:now, level:'INFO', area:'ERP_INSTALL', action:'COMPLETE_INSTALLATION', targetId:installId, message:'설치완료 동기화 완료', meta:'saleId=' + saleId + ', installStatus=COMPLETED', actor:'system', status:'DONE', errorCode:'' });
    } catch (logErr) {}

    try {
      onErpInstallCompleted_CreateInstallConfirmSign(installId);
    } catch (signErr) {
      console.error('[ERP_SIGN] 설치확인서 자동 생성 실패:', signErr);
    }

    return { ok:true, installId:installId, saleId:saleId, completionStatus:'DONE', installStatus:'COMPLETED', settlementTarget:settlementTarget };
  }

  function requestCancellation(payload){
    var sh = ensureSheet('Cancellations', ['cancellationId','saleId','reasonType','customerRefund','status','createdAt']);
    var id = nextId('CXL-', sh, 1);
    sh.appendRow([id, s(payload.saleId), s(payload.reasonType), n(payload.customerRefund), 'PENDING', ts()]);
    if (s(payload.saleId)) {
      try { updateRowById('Sales', 'saleId', s(payload.saleId), { status:'CANCELLATION_PENDING', saleStage:'취소대기', settlementStatus:'REVIEW' }); } catch (e) {}
    }
    return { ok:true, cancellationId:id };
  }

  function saveAsRequest(payload){
    var headers = ['asId','contractId','saleId','eventId','vendorId','customerId','status','statusReason','createdAt','createdBy','updatedAt','updatedBy','content','priority','assignee','cost','costOwner','resultMemo','claimType','claimStatus','claimAmount','visitDate'];
    var sh = ensureSheet('ASRequests', headers);
    var id = nextId('AS-', sh, 1);
    var now = ts();
    appendObjectByHeader_('ASRequests', headers, { asId:id, contractId:s(payload.contractId), saleId:s(payload.saleId), eventId:s(payload.eventId), vendorId:s(payload.vendorId), customerId:s(payload.customerId), status:s(payload.status) || 'RECEIVED', statusReason:s(payload.statusReason), createdAt:now, createdBy:'system', updatedAt:now, updatedBy:'system', content:s(payload.content), priority:s(payload.priority) || 'MEDIUM', assignee:s(payload.assignee) || '미배정', cost:n(payload.cost), costOwner:s(payload.costOwner) || '', resultMemo:s(payload.resultMemo), claimType:s(payload.claimType) || 'GENERAL', claimStatus:s(payload.claimStatus) || 'NONE', claimAmount:n(payload.claimAmount), visitDate:s(payload.visitDate) });
    return { ok:true, asId:id };
  }
  function updateAsRequestStatus(payload){
    updateRowById('ASRequests', 'asId', s(payload.asId), {
      status:s(payload.status) || 'OPEN',
      assignee:s(payload.assignee),
      priority:s(payload.priority),
      cost:n(payload.cost),
      costOwner:s(payload.costOwner),
      resultMemo:s(payload.resultMemo),
      claimType:s(payload.claimType),
      claimStatus:s(payload.claimStatus),
      claimAmount:n(payload.claimAmount),
      visitDate:s(payload.visitDate),
      updatedAt:ts()
    });
    return { ok:true, asId:s(payload.asId) };
  }

  function getAsByStatus(status){
    var rows = readAS();
    if (!status || status === 'ALL') return rows;
    return rows.filter(function(v){ return String(v.status || '') === String(status); });
  }

  function changeStatus(sheetName, idField, idValue, statusField, statusValue){
    updateRowById(sheetName, idField, idValue, (function(){ var x={}; x[statusField]=statusValue; return x; })());
    return true;
  }


  function assignInstallTeam(payload){
    payload = payload || {};
    syncSystemConfig();

    var now = ts();
    var saleId = s(payload.saleId);
    if (!saleId) throw new Error('설치 배정에는 saleId가 필요합니다.');
    var sale = findFirstByField_('Sales', 'saleId', saleId);
    var installId = getOrCreateInstallId_(payload, sale);
    var vendorId = s(payload.vendorId) || s(sale && sale.vendorId);

    var assignmentHeaders = ['assignmentId','saleId','vendorId','installId','teamName','engineer','vehicleNo','visitDate','visitTime','status','memo','createdAt','updatedAt'];
    var sh = ensureSheet('InstallAssignments', assignmentHeaders);
    var assignmentId = s(payload.assignmentId) || nextId('ASN-', sh, 1);
    appendObjectByHeader_('InstallAssignments', assignmentHeaders, { assignmentId:assignmentId, saleId:saleId, vendorId:vendorId, installId:installId, teamName:s(payload.teamName), engineer:s(payload.engineer), vehicleNo:s(payload.vehicleNo), visitDate:s(payload.visitDate), visitTime:s(payload.visitTime), status:s(payload.status) || 'SCHEDULED', memo:s(payload.memo), createdAt:now, updatedAt:now });

    syncInstallMasterFromSale_(installId, sale, { installId:installId, saleId:saleId, eventId:s(payload.eventId), vendorId:vendorId, customerId:s(payload.customerId), contractId:s(payload.contractId), memo:s(payload.memo), statusReason:s(payload.statusReason) || '설치일정 배정' }, s(payload.status) || 'SCHEDULED', s(payload.statusReason) || '설치일정 배정');

    updateRowById('Sales', 'saleId', saleId, { installStatus:s(payload.status) || 'SCHEDULED', installDate:s(payload.visitDate), installer:s(payload.engineer), updatedAt:now, updatedBy:'system' });

    return { ok:true, assignmentId:assignmentId, installId:installId, saleId:saleId, installStatus:s(payload.status) || 'SCHEDULED' };
  }

  function addSettlementAdjustment(payload){
    var sh = ensureSheet('SettlementAdjustments', ['adjustmentId','saleId','vendorId','adjustmentType','reason','amount','status','createdAt']);
    var id = nextId('ADJ-', sh, 1);
    sh.appendRow([id, s(payload.saleId), s(payload.vendorId), s(payload.adjustmentType), s(payload.reason), n(payload.amount), s(payload.status) || 'READY', ts()]);
    return { ok:true, adjustmentId:id };
  }

  function getCardDataList(query){
    var q = s(query).toLowerCase();
    return readCardData().filter(function(v){
      if (!q) return true;
      return [v.cardDataId,v.cardCompany,v.approvalNo,v.cardHolder,String(v.amount),v.status,v.saleId].join(' ').toLowerCase().indexOf(q) > -1;
    }).slice(-50).reverse();
  }

  function getClaimSummary(){
    var rows = readAS();
    return {
      total: rows.length,
      claimCount: rows.filter(function(v){ return ['클레임','COMPENSATION','교환','환불'].indexOf(String(v.claimType || '')) > -1; }).length,
      claimOpenCount: rows.filter(function(v){ return ['REQUEST','REVIEW','HOLD'].indexOf(String(v.claimStatus || '')) > -1; }).length,
      claimAmount: rows.reduce(function(a,v){ return a + Number(v.claimAmount || 0); }, 0)
    };
  }

  function getSettlementTargetHeaders_(){
    return ['targetId','saleId','installId','vendorId','customerId','eventId','sourceType','settlementBaseAmount','installCompletedAt','status','holdReason','createdAt','updatedAt','createdBy','updatedBy'];
  }

  function ensureSettlementTargetFromInstall_(sale, installId, completedAt, actor){
    sale = sale || {};
    var saleId = s(sale.saleId);
    if (!saleId) return { ok:false, message:'saleId 없음' };
    var headers = getSettlementTargetHeaders_();
    var sh = ensureSheet('SettlementTargets', headers);
    var existing = findFirstByField_('SettlementTargets', 'saleId', saleId);
    var targetId = s(existing && existing.targetId) || nextId('STG-', sh, 1);
    var now = ts();
    var amount = n(sale.totalAmount || sale.supplyAmount || sale.payment1Amount);
    var result = upsertObjectByHeader_('SettlementTargets', headers, 'targetId', targetId, {
      targetId:targetId,
      saleId:saleId,
      installId:installId,
      vendorId:s(sale.vendorId),
      customerId:s(sale.customerId),
      eventId:s(sale.eventId),
      sourceType:'INSTALL_COMPLETED',
      settlementBaseAmount:amount,
      installCompletedAt:completedAt || s(sale.installDate) || now,
      status:'READY',
      holdReason:'',
      createdAt:s(existing && existing.createdAt) || now,
      updatedAt:now,
      createdBy:s(existing && existing.createdBy) || s(actor) || 'system',
      updatedBy:s(actor) || 'system'
    });
    try { updateRowById('Sales', 'saleId', saleId, { settlementStatus:'READY', updatedAt:now, updatedBy:s(actor) || 'system' }); } catch(e) {}
    return { ok:true, mode:result.mode, targetId:targetId, saleId:saleId, status:'READY' };
  }

  function holdSettlementTargetBySale_(saleId, reason, actor){
    var now = ts();
    var row = findFirstByField_('SettlementTargets', 'saleId', saleId);
    if (row && s(row.targetId)) {
      try { updateRowById('SettlementTargets', 'targetId', s(row.targetId), { status:'HOLD', holdReason:s(reason), updatedAt:now, updatedBy:s(actor) || 'system' }); } catch(e) {}
    }
    try { updateRowById('Sales', 'saleId', saleId, { settlementStatus:'HOLD', updatedAt:now, updatedBy:s(actor) || 'system' }); } catch(e2) {}
    return { ok:true, saleId:saleId, targetId:s(row && row.targetId), status:'HOLD' };
  }

  function logInstallAction_(action, installId, saleId, message, meta, level){
    try {
      appendObjectByHeader_('DiagnosticsLog', ['logId','createdAt','level','area','action','targetId','message','meta','actor','status','errorCode'], {
        logId:'LOG-' + new Date().getTime(), createdAt:ts(), level:level || 'INFO', area:'ERP_INSTALL', action:action, targetId:installId || saleId || 'INSTALL', message:message || '', meta:meta || '', actor:'system', status:'DONE', errorCode:''
      });
    } catch(e) {}
  }

  function assertInstallTransition_(current, next){
    current = s(current) || 'SCHEDULED';
    next = s(next);
    var allowed = {
      '배정전':['SCHEDULED','CANCELLED'],
      'SCHEDULED':['COMPLETED','CANCEL_REQUESTED','CANCELLED','REOPEN_REQUESTED'],
      'ASSIGNED':['SCHEDULED','COMPLETED','CANCEL_REQUESTED','CANCELLED','REOPEN_REQUESTED'],
      'COMPLETED':['REOPEN_REQUESTED','CANCEL_REQUESTED'],
      'REOPEN_REQUESTED':['REOPEN','COMPLETED','CANCEL_REQUESTED'],
      'REOPEN':['SCHEDULED','COMPLETED','CANCEL_REQUESTED','CANCELLED'],
      'CANCEL_REQUESTED':['CANCELLED','COMPLETED','REOPEN'],
      'CANCELLED':['REOPEN_REQUESTED']
    };
    if (current === next) return true;
    if (!allowed[current] || allowed[current].indexOf(next) < 0) throw new Error('허용되지 않는 설치 상태 전이: ' + current + ' → ' + next);
    return true;
  }

  function changeInstallState_(payload, nextStatus, defaultReason){
    payload = payload || {};
    syncSystemConfig();
    var now = ts();
    var installId = s(payload.installId);
    var saleId = s(payload.saleId);
    var sale = saleId ? findFirstByField_('Sales', 'saleId', saleId) : null;
    var install = installId ? findFirstByField_('Installs', 'installId', installId) : null;
    if (!install && saleId) install = findFirstByField_('Installs', 'saleId', saleId);
    if (!sale && install) sale = findFirstByField_('Sales', 'saleId', s(install.saleId));
    if (!installId) installId = s(install && install.installId) || getOrCreateInstallId_(payload, sale);
    if (!saleId) saleId = s(install && install.saleId) || s(sale && sale.saleId);
    if (!saleId) throw new Error('설치 상태 변경에는 saleId 또는 installId가 필요합니다.');
    var current = s(install && install.status) || s(sale && sale.installStatus) || 'SCHEDULED';
    assertInstallTransition_(current, nextStatus);
    var reason = s(payload.statusReason || payload.reason) || defaultReason || nextStatus;
    syncInstallMasterFromSale_(installId, sale, { installId:installId, saleId:saleId, eventId:s(sale && sale.eventId), vendorId:s(payload.vendorId) || s(sale && sale.vendorId), customerId:s(sale && sale.customerId), contractId:s(sale && sale.contractId), memo:reason, statusReason:reason }, nextStatus, reason);
    try { updateRowById('Sales', 'saleId', saleId, { installStatus:nextStatus, statusReason:reason, updatedAt:now, updatedBy:s(payload.actor) || 'system' }); } catch(e) {}
    var assignment = findLastByField_('InstallAssignments', 'saleId', saleId);
    if (assignment && s(assignment.assignmentId)) {
      try { updateRowById('InstallAssignments', 'assignmentId', s(assignment.assignmentId), { status:nextStatus, memo:reason, updatedAt:now }); } catch(e2) {}
    }
    if (['REOPEN_REQUESTED','REOPEN','CANCEL_REQUESTED','CANCELLED'].indexOf(nextStatus) > -1) holdSettlementTargetBySale_(saleId, reason, s(payload.actor));
    logInstallAction_('CHANGE_INSTALL_STATUS', installId, saleId, '설치 상태 전이: ' + current + ' → ' + nextStatus, 'reason=' + reason, 'INFO');
    return { ok:true, installId:installId, saleId:saleId, fromStatus:current, toStatus:nextStatus, reason:reason };
  }

  function requestInstallReopen(payload){
    return changeInstallState_(payload, 'REOPEN_REQUESTED', '설치 재오픈 요청');
  }

  function approveInstallReopen(payload){
    return changeInstallState_(payload, 'REOPEN', '설치 재오픈 승인');
  }

  function requestInstallCancel(payload){
    return changeInstallState_(payload, 'CANCEL_REQUESTED', '설치 취소 요청');
  }

  function approveInstallCancel(payload){
    return changeInstallState_(payload, 'CANCELLED', '설치 취소 승인');
  }

  function getSettlementTargetRows(status, vendorId){
    var rows = readTable('SettlementTargets').slice(-200).reverse();
    return rows.filter(function(v){
      var okStatus = !status || s(status) === 'ALL' || s(v.status) === s(status);
      var okVendor = !vendorId || s(vendorId) === 'ALL' || s(v.vendorId) === s(vendorId);
      return okStatus && okVendor;
    });
  }

  function getSettlementDetailSummary(vendorId){
    var sales = readSales().filter(function(v){ return !vendorId || vendorId === 'ALL' || String(v.vendorId || '') === String(vendorId); });
    var adjustments = readSettlementAdjustments().filter(function(v){ return !vendorId || vendorId === 'ALL' || String(v.vendorId || '') === String(vendorId); });
    return {
      saleCount: sales.length,
      readyCount: sales.filter(function(v){ return String(v.settlementStatus || '') === 'READY'; }).length,
      reviewCount: sales.filter(function(v){ return String(v.settlementStatus || '') === 'REVIEW'; }).length,
      holdCount: sales.filter(function(v){ return String(v.settlementStatus || '') === 'HOLD'; }).length,
      totalSales: sales.reduce(function(a,v){ return a + Number(v.totalAmount || 0); }, 0),
      totalBalance: sales.reduce(function(a,v){ return a + Number(v.balanceAmount || 0); }, 0),
      adjustmentAmount: adjustments.reduce(function(a,v){ return a + Number(v.amount || 0); }, 0),
      adjustments: adjustments
    };
  }

  function getDiagnosticsCategorySummary(){
    var rows = readTable('DiagnosticsLog').map(function(r){ return { level:s(r.level), menu:s(r.menu), fn:s(r.fn), message:s(r.message) }; });
    var categories = { 설정오류:0, 권한오류:0, 데이터오류:0, UI호출오류:0, 기타:0 };
    rows.forEach(function(v){
      var hay = [v.menu,v.fn,v.message].join(' ').toLowerCase();
      if (hay.indexOf('config') > -1 || hay.indexOf('setup') > -1 || hay.indexOf('설정') > -1) categories['설정오류'] += 1;
      else if (hay.indexOf('권한') > -1 || hay.indexOf('permission') > -1 || hay.indexOf('auth') > -1) categories['권한오류'] += 1;
      else if (hay.indexOf('sheet') > -1 || hay.indexOf('data') > -1 || hay.indexOf('customer') > -1 || hay.indexOf('sale') > -1) categories['데이터오류'] += 1;
      else if (hay.indexOf('ui') > -1 || hay.indexOf('html') > -1 || hay.indexOf('button') > -1 || hay.indexOf('menu') > -1) categories['UI호출오류'] += 1;
      else categories['기타'] += 1;
    });
    return categories;
  }

  function approvePermissionRequestFromErp(requestId){ changeStatus('PermissionRequests','requestId',requestId,'status','APPROVED'); return { ok:true, requestId:requestId }; }
  function rejectPermissionRequestFromErp(requestId){ changeStatus('PermissionRequests','requestId',requestId,'status','REJECTED'); return { ok:true, requestId:requestId }; }
  function approveOnboardingFromErp(onboardingId){ changeStatus('Onboardings','onboardingId',onboardingId,'status','APPROVED'); return { ok:true, onboardingId:onboardingId }; }
  function approveCancellationFromErp(cancellationId){ changeStatus('Cancellations','cancellationId',cancellationId,'status','APPROVED'); return { ok:true, cancellationId:cancellationId }; }
  function markSettlementPaidFromErp(settlementId){ changeStatus('MonthlyClosings','closingId',settlementId,'status','PAID'); return { ok:true, settlementId:settlementId }; }
  function adjustSettlementFromErp(payload){
    var nextStatus = s(payload.status) || 'READY';
    changeStatus('MonthlyClosings','closingId',payload.settlementId,'status', nextStatus);
    if (['CONFIRMED','APPROVED','확정'].indexOf(nextStatus) > -1) {
      try {
        onErpSettlementConfirmed_CreateSettlementConfirmSign(payload.settlementId);
      } catch (signErr) {
        console.error('[ERP_SIGN] 정산확인서 자동 생성 실패:', signErr);
      }
    }
    return { ok:true, settlementId:payload.settlementId };
  }

  function addDepositLedgerFromErp(payload){
    var sh = ensureSheet('DepositLedger', ['ledgerId','vendorId','ledgerType','amount','balanceAfter','eventId','memo','createdAt']);
    var vals = sh.getDataRange().getDisplayValues();
    var balance = vals.length > 1 ? n(vals[vals.length - 1][4]) : 0;
    var amount = n(payload.amount);
    var after = s(payload.ledgerType) === 'WITHDRAW' ? balance - amount : balance + amount;
    var id = nextId('DPL-', sh, 1);
    sh.appendRow([id, s(payload.vendorId), s(payload.ledgerType), amount, after, s(payload.eventId), s(payload.memo), ts()]);
    return { ok:true, ledgerId:id, balanceAfter:after };
  }

  function createMonthlyClosingFromErp(payload){
    var sh = ensureSheet('MonthlyClosings', ['closingId','closingMonth','vendorId','salesAmount','status','createdAt']);
    var amount = readSales().filter(function(v){
      return !payload.vendorId || s(payload.vendorId) === 'ALL' || s(v.vendorId) === s(payload.vendorId);
    }).reduce(function(acc, v){ return acc + n(v.totalAmount); }, 0);
    var id = nextId('SET-', sh, 1);
    sh.appendRow([id, s(payload.closingMonth), s(payload.vendorId), amount, 'READY', ts()]);
    return { ok:true, closingId:id };
  }

  function approveBenefitPayout(payoutId){ changeStatus('BenefitPayouts','payoutId',payoutId,'status','APPROVED'); return { ok:true, payoutId:payoutId }; }

  function markGiftDistributed(payoutId){
    updateRowById('BenefitPayouts', 'payoutId', payoutId, { giftStatus:'DONE' });
    return { ok:true, payoutId:payoutId };
  }

  function markEvidenceMailSent(queueId){
    updateRowById('EvidenceMailQueue', 'queueId', queueId, { status:'SENT', sentAt:ts() });
    return { ok:true, queueId:queueId };
  }

  function getSalesByStatus(status){
    var rows = recentSales();
    if (!status || status === 'ALL') return rows;
    return rows.filter(function(v){ return String(v.status || '') === String(status); });
  }

  function getSalesByDateRange(dateFrom, dateTo){
    var rows = recentSales();
    var from = String(dateFrom || '').trim();
    var to = String(dateTo || '').trim();
    return rows.filter(function(v){
      var x = String(v.createdAt || '').substring(0,10);
      if (from && x < from) return false;
      if (to && x > to) return false;
      return true;
    });
  }

  function getCustomersByMemberType(memberType){
    var rows = getRecentCustomers(50);
    if (!memberType || memberType === 'ALL') return rows;
    return rows.filter(function(v){ return String(v.memberType || '') === String(memberType); });
  }

  function getCustomersByEventType(eventType){
    var rows = getRecentCustomers(50);
    if (!eventType || eventType === 'ALL') return rows;
    return rows.filter(function(v){ return String(v.eventType || '') === String(eventType); });
  }

  function getSalesByPaymentMethod(paymentMethod){
    var rows = recentSales();
    if (!paymentMethod || paymentMethod === 'ALL') return rows;
    return rows.filter(function(v){ return String(v.paymentMethod || '') === String(paymentMethod); });
  }

  function getSalesByVendorId(vendorId){
    var rows = recentSales();
    if (!vendorId || vendorId === 'ALL') return rows;
    return rows.filter(function(v){ return String(v.vendorId || '') === String(vendorId); });
  }

  function getSalesByCustomerId(customerId){
    var rows = readSales();
    if (!customerId) return rows;
    return rows.filter(function(v){ return String(v.customerId || '') === String(customerId); }).slice(-50).reverse();
  }

  function getEvidenceByStatus(status){
    var rows = recentEvidenceQueue();
    if (!status || status === 'ALL') return rows;
    return rows.filter(function(v){ return String(v.status || '') === String(status); });
  }

  function getVendorSettlementSummary(vendorId){
    var sales = readSales();
    var vendors = activeVendors();
    var filtered = vendorId && vendorId !== 'ALL' ? sales.filter(function(v){ return String(v.vendorId || '') === String(vendorId); }) : sales;
    var vendorMap = {};
    vendors.forEach(function(v){ vendorMap[String(v.vendorId || '')] = { vendorId:String(v.vendorId || ''), vendorName:String(v.vendorName || ''), commissionRate:Number(v.commissionRate || 0) }; });
    var grouped = {};
    filtered.forEach(function(v){
      var id = String(v.vendorId || '');
      if (!grouped[id]){
        var meta = vendorMap[id] || { vendorId:id, vendorName:id || '미지정업체', commissionRate:0 };
        grouped[id] = { vendorId:meta.vendorId, vendorName:meta.vendorName, commissionRate:Number(meta.commissionRate || 0), salesCount:0, salesAmount:0, depositAmount:0, balanceAmount:0, feeAmount:0, netAmount:0 };
      }
      grouped[id].salesCount += 1;
      grouped[id].salesAmount += Number(v.totalAmount || 0);
      grouped[id].depositAmount += Number(v.depositAmount || 0);
      grouped[id].balanceAmount += Number(v.balanceAmount || 0);
    });
    Object.keys(grouped).forEach(function(id){
      var g = grouped[id];
      g.feeAmount = Math.round(g.salesAmount * (g.commissionRate / 100));
      g.netAmount = g.salesAmount - g.feeAmount;
    });
    return Object.keys(grouped).map(function(id){ return grouped[id]; }).sort(function(a,b){ return b.salesAmount - a.salesAmount; });
  }

  function getCancellationSummary(){
    var rows = readCancellations().slice(-50).reverse();
    var byReason = {};
    var totalRefund = 0;
    rows.forEach(function(v){
      var key = String(v.reasonType || '기타');
      byReason[key] = (byReason[key] || 0) + 1;
      totalRefund += Number(v.customerRefund || 0);
    });
    return { rows:rows, byReason:byReason, totalRefund:totalRefund };
  }

  function getInstallStatusSummary(){
    var installs = readInstalls();
    var pending = installPendingSales();
    var byStage = { '배정전':0, '일정확정':0, '방문예정':0, '재방문':0, '설치완료':0 };
    readSales().forEach(function(v){ var stage = String(v.installStatus || '배정전'); byStage[stage] = (byStage[stage] || 0) + 1; });
    return {
      doneCount: installs.length,
      pendingCount: pending.length,
      revisitCount: installs.filter(function(v){ return String(v.memo || '').indexOf('재방문') > -1 || String(v.stage || '') === '재방문'; }).length,
      byStage: byStage
    };
  }

  function getDashboardSummary(){
    var sales = readSales();
    var customers = readCustomers();
    var byPayment = {};
    var byEvent = {};
    var eventMap = {};
    readEvents().forEach(function(e){ eventMap[String(e.eventId || '')] = String(e.eventName || e.eventId || ''); });
    sales.forEach(function(v){
      var p = String(v.paymentMethod || '기타');
      var e = eventMap[String(v.eventId || '')] || String(v.eventId || '기타');
      byPayment[p] = (byPayment[p] || 0) + Number(v.totalAmount || 0);
      byEvent[e] = (byEvent[e] || 0) + Number(v.totalAmount || 0);
    });
    return {
      totalSalesAmount:sales.reduce(function(a,v){ return a + Number(v.totalAmount || 0); },0),
      totalDepositAmount:sales.reduce(function(a,v){ return a + Number(v.depositAmount || 0); },0),
      totalBalanceAmount:sales.reduce(function(a,v){ return a + Number(v.balanceAmount || 0); },0),
      customerCount:customers.length,
      byPayment:byPayment,
      byEvent:byEvent
    };
  }

  function markCancellationRefunded(cancellationId){
    updateRowById('Cancellations', 'cancellationId', cancellationId, { status:'APPROVED' });
    return { ok:true, cancellationId:cancellationId };
  }

  function markInstallRevisit(installId){
    var installs = readInstalls();
    var target = installs.filter(function(v){ return String(v.installId || '') === String(installId); })[0];
    if (!target) throw new Error('대상을 찾지 못했습니다: ' + installId);
    var memo = s(target.memo);
    if (memo.indexOf('재방문') === -1) memo = memo ? memo + ' / 재방문' : '재방문';
    updateRowById('InstallCompletions', 'installId', installId, { memo:memo, stage:'재방문', revisitReason:'재방문' });
    if (target.saleId) { try { updateRowById('Sales', 'saleId', target.saleId, { installStatus:'재방문' }); } catch (e) {} }
    return { ok:true, installId:installId };
  }

  function requeueEvidence(queueId){
    updateRowById('EvidenceMailQueue', 'queueId', queueId, { status:'PENDING', sentAt:'' });
    return { ok:true, queueId:queueId };
  }

  function getCustomerPurchaseSummary(customerId){
    var sales = getSalesByCustomerId(customerId);
    return {
      customerId:String(customerId || ''),
      salesCount:sales.length,
      totalAmount:sales.reduce(function(a,v){ return a + Number(v.totalAmount || 0); }, 0),
      depositAmount:sales.reduce(function(a,v){ return a + Number(v.depositAmount || 0); }, 0),
      balanceAmount:sales.reduce(function(a,v){ return a + Number(v.balanceAmount || 0); }, 0)
    };
  }

  function getVendorPerformanceSummary(){
    var settle = getVendorSettlementSummary('ALL');
    var sales = readSales();
    var saleMap = rowMap(sales, 'saleId');
    var installs = readInstalls();
    var cancels = readCancellations();
    var stats = {};

    settle.forEach(function(v){
      stats[String(v.vendorId || '')] = {
        vendorId:String(v.vendorId || ''),
        vendorName:String(v.vendorName || ''),
        salesAmount:Number(v.salesAmount || 0),
        feeAmount:Number(v.feeAmount || 0),
        netAmount:Number(v.netAmount || 0),
        salesCount:Number(v.salesCount || 0),
        cancelCount:0,
        installCount:0
      };
    });

    cancels.forEach(function(v){
      var sale = saleMap[String(v.saleId || '')];
      var vendorId = sale ? String(sale.vendorId || '') : '';
      if (!stats[vendorId]) stats[vendorId] = { vendorId:vendorId, vendorName:vendorId || '미지정업체', salesAmount:0, feeAmount:0, netAmount:0, salesCount:0, cancelCount:0, installCount:0 };
      stats[vendorId].cancelCount += 1;
    });

    installs.forEach(function(v){
      var vendorId = String(v.vendorId || '');
      if (!stats[vendorId]) stats[vendorId] = { vendorId:vendorId, vendorName:vendorId || '미지정업체', salesAmount:0, feeAmount:0, netAmount:0, salesCount:0, cancelCount:0, installCount:0 };
      stats[vendorId].installCount += 1;
    });

    return Object.keys(stats).map(function(k){ return stats[k]; }).sort(function(a,b){ return b.salesAmount - a.salesAmount; });
  }

  function getEventPerformanceSummary(){
    var sales = readSales();
    var eventMap = {};
    readEvents().forEach(function(v){ eventMap[String(v.eventId || '')] = String(v.eventName || v.eventId || ''); });
    var stats = {};
    sales.forEach(function(v){
      var id = String(v.eventId || '');
      if (!stats[id]) stats[id] = { eventId:id, eventName:eventMap[id] || id || '미지정행사', salesCount:0, totalAmount:0, depositAmount:0, balanceAmount:0 };
      stats[id].salesCount += 1;
      stats[id].totalAmount += Number(v.totalAmount || 0);
      stats[id].depositAmount += Number(v.depositAmount || 0);
      stats[id].balanceAmount += Number(v.balanceAmount || 0);
    });
    return Object.keys(stats).map(function(k){ return stats[k]; }).sort(function(a,b){ return b.totalAmount - a.totalAmount; });
  }

  function getWarningSummary(){
    var sales = readSales();
    var evidenceRows = readEvidenceQueue();
    var cancellationRows = readCancellations();
    var installPendingRows = installPendingSales();
    return {
      unpaidBalanceCount: sales.filter(function(v){ return Number(v.balanceAmount || 0) > 0; }).length,
      installPendingCount: installPendingRows.length,
      evidencePendingCount: evidenceRows.filter(function(v){ return String(v.status || '') === 'PENDING'; }).length,
      cancelPendingCount: cancellationRows.filter(function(v){ return String(v.status || '') !== 'APPROVED'; }).length,
      cardUnmatchedCount: sales.filter(function(v){ return String(v.paymentMethod || '') === 'CARD' && !String(v.cardDataId || ''); }).length
    };
  }

  function getCustomerStatusSummary(){
    var customers = readCustomers();
    var salesMap = salesByCustomerMap();
    var installs = readInstalls();
    var installsByCustomer = {};
    installs.forEach(function(v){ installsByCustomer[String(v.customerId || '')] = (installsByCustomer[String(v.customerId || '')] || 0) + 1; });
    var cancelMap = cancellationsBySaleMap();
    var statusMap = {};

    customers.forEach(function(c){
      var customerSales = salesMap[String(c.customerId || '')] || [];
      var cancelCount = 0;
      customerSales.forEach(function(sale){ cancelCount += (cancelMap[String(sale.saleId || '')] || []).length; });
      var status = '신규';
      if (cancelCount > 0) status = '취소';
      else if ((installsByCustomer[String(c.customerId || '')] || 0) > 0) status = 'A/S 진행';
      else if (customerSales.length > 0) status = '계약';
      statusMap[status] = (statusMap[status] || 0) + 1;
    });
    return statusMap;
  }

  function getDuplicateCustomerWarnings(){
    var customers = readCustomers();
    var phoneMap = {}, emailMap = {}, homeMap = {};
    customers.forEach(function(c){
      var phone = String(c.phone || '').replace(/[^0-9]/g,'');
      var email = String(c.email || '').trim().toLowerCase();
      var home = String((c.aptName || '') + '|' + (c.dong || '') + '|' + (c.hosu || '')).trim();
      if (phone) phoneMap[phone] = (phoneMap[phone] || 0) + 1;
      if (email) emailMap[email] = (emailMap[email] || 0) + 1;
      if (home) homeMap[home] = (homeMap[home] || 0) + 1;
    });
    return {
      duplicatePhone: Object.keys(phoneMap).filter(function(k){ return phoneMap[k] > 1; }).length,
      duplicateEmail: Object.keys(emailMap).filter(function(k){ return emailMap[k] > 1; }).length,
      duplicateHome: Object.keys(homeMap).filter(function(k){ return homeMap[k] > 1; }).length
    };
  }

  function getASStatusSummary(){
    var rows = readAS();
    return {
      total: rows.length,
      openCount: rows.filter(function(v){ return ['OPEN','접수','배정','처리중'].indexOf(String(v.status || '')) > -1; }).length,
      doneCount: rows.filter(function(v){ return ['DONE','완료'].indexOf(String(v.status || '')) > -1; }).length,
      holdCount: rows.filter(function(v){ return ['HOLD','보류','클레임'].indexOf(String(v.status || '')) > -1; }).length,
      urgentCount: rows.filter(function(v){ return String(v.priority || '') === '긴급'; }).length
    };
  }

  function getDocumentSummary(){
    var rows = readEvidenceQueue();
    var byType = {};
    var byStatus = {};
    rows.forEach(function(v){
      var t = String(v.docType || '기타');
      var st = String(v.status || '기타');
      byType[t] = (byType[t] || 0) + 1;
      byStatus[st] = (byStatus[st] || 0) + 1;
    });
    return { rows: rows.length, byType: byType, byStatus: byStatus };
  }

  function getReceivableSummary(){
    var sales = readSales();
    var overdue = sales.filter(function(v){ return Number(v.balanceAmount || 0) > 0; });
    return {
      totalCount: overdue.length,
      totalBalance: overdue.reduce(function(a,v){ return a + Number(v.balanceAmount || 0); }, 0),
      highRiskCount: overdue.filter(function(v){ return Number(v.balanceAmount || 0) >= 500000; }).length
    };
  }

  function getLeadStatusSummary(){
    var customers = readCustomers();
    var status = { 신규:0, 상담중:0, 계약:0, 설치완료:0, 취소:0 };
    var salesMap = salesByCustomerMap();
    var installsByCustomer = {};
    readInstalls().forEach(function(v){ installsByCustomer[String(v.customerId || '')] = (installsByCustomer[String(v.customerId || '')] || 0) + 1; });
    var cancelMap = cancellationsBySaleMap();

    customers.forEach(function(c){
      var customerSales = salesMap[String(c.customerId || '')] || [];
      var cancelled = false;
      customerSales.forEach(function(sale){ if ((cancelMap[String(sale.saleId || '')] || []).length > 0) cancelled = true; });
      if (cancelled) status['취소'] += 1;
      else if ((installsByCustomer[String(c.customerId || '')] || 0) > 0) status['설치완료'] += 1;
      else if (customerSales.length > 0) status['계약'] += 1;
      else status['신규'] += 1;
    });
    return status;
  }

  function getDocumentFailureSummary(){
    var rows = readEvidenceQueue();
    return {
      total: rows.length,
      pending: rows.filter(function(v){ return String(v.status || '') === 'PENDING'; }).length,
      sent: rows.filter(function(v){ return String(v.status || '') === 'SENT'; }).length,
      failed: rows.filter(function(v){ return String(v.status || '') === 'FAILED'; }).length
    };
  }

  function getOperationalBoardSummary(){
    var warn = getWarningSummary();
    var receivable = getReceivableSummary();
    var asSum = getASStatusSummary();
    var claim = getClaimSummary();
    return {
      unpaidBalanceCount: warn.unpaidBalanceCount || 0,
      installPendingCount: warn.installPendingCount || 0,
      evidencePendingCount: warn.evidencePendingCount || 0,
      cancelPendingCount: warn.cancelPendingCount || 0,
      cardUnmatchedCount: warn.cardUnmatchedCount || 0,
      receivableAmount: receivable.totalBalance || 0,
      asOpenCount: asSum.openCount || 0,
      claimOpenCount: claim.claimOpenCount || 0
    };
  }



  function saveCardDataEntry(payload){
    var sh = ensureSheet('CardData', ['cardDataId','cardCompany','approvalNo','cardHolder','amount','status','saleId','createdAt']);
    var id = nextId('CD-', sh, 1);
    sh.appendRow([id, s(payload.cardCompany), s(payload.approvalNo), s(payload.cardHolder), n(payload.amount), s(payload.status) || 'READY', s(payload.saleId), ts()]);
    return { ok:true, cardDataId:id };
  }

  function requestPermissionChange(payload){
    var sh = ensureSheet('PermissionRequests', ['requestId','vendorId','status','requestType','createdAt']);
    var id = nextId('REQ-', sh, 1);
    sh.appendRow([id, s(payload.vendorId), 'PENDING', s(payload.requestType), ts()]);
    return { ok:true, requestId:id };
  }

  function getSalesFunnelSummary(){
    var sales = readSales();
    var saleStage = {};
    var installStage = {};
    var settlementStage = {};
    sales.forEach(function(v){
      var s1 = String(v.saleStage || '미지정');
      var s2 = String(v.installStatus || '미지정');
      var s3 = String(v.settlementStatus || '미지정');
      saleStage[s1] = (saleStage[s1] || 0) + 1;
      installStage[s2] = (installStage[s2] || 0) + 1;
      settlementStage[s3] = (settlementStage[s3] || 0) + 1;
    });
    return { saleStage:saleStage, installStage:installStage, settlementStage:settlementStage, rows:sales.length };
  }

  function getDuplicateCustomerCandidates(){
    var customers = readCustomers();
    var phoneMap = {}, emailMap = {}, homeMap = {};
    customers.forEach(function(c){
      var phone = phoneDigits(c.phone);
      var email = String(c.email || '').trim().toLowerCase();
      var home = String((c.aptName || '') + '|' + (c.dong || '') + '|' + (c.hosu || '')).trim();
      if (phone){ if (!phoneMap[phone]) phoneMap[phone]=[]; phoneMap[phone].push(c); }
      if (email){ if (!emailMap[email]) emailMap[email]=[]; emailMap[email].push(c); }
      if (home){ if (!homeMap[home]) homeMap[home]=[]; homeMap[home].push(c); }
    });
    function pick(map, keyName){
      return Object.keys(map).filter(function(k){ return map[k].length > 1; }).map(function(k){
        return { type:keyName, key:k, count:map[k].length, customerIds:map[k].map(function(v){ return v.customerId; }).join(', '), names:map[k].map(function(v){ return v.name; }).join(', ') };
      });
    }
    return {
      phone: pick(phoneMap,'PHONE'),
      email: pick(emailMap,'EMAIL'),
      home: pick(homeMap,'HOME')
    };
  }

  function getOverdueInstallations(){
    var today = Utilities.formatDate(new Date(), Session.getScriptTimeZone() || 'Asia/Seoul', 'yyyy-MM-dd');
    return readSales().filter(function(v){
      return String(v.installDate || '') && String(v.installDate) < today && ['설치완료','DONE'].indexOf(String(v.installStatus || '')) === -1;
    }).slice(-50).reverse();
  }

  function getReceivableDetailRows(){
    return readSales().filter(function(v){ return Number(v.balanceAmount || 0) > 0; }).slice(-50).reverse();
  }

  function smokeTestErp(){
    syncSystemConfig();
    var ss = getDbSpreadsheet();
    return {
      ok:true,
      buildNo:BUILD_NO,
      dbSpreadsheetId:ss.getId(),
      dbSpreadsheetName:ss.getName(),
      eventsCount:activeEvents().length,
      vendorsCount:activeVendors().length,
      customersCount:readCustomers().length,
      salesCount:readSales().length,
      installCount:readInstalls().length,
      cardDataCount:readCardData().length,
      installAssignmentCount:readInstallAssignments().length,
      saleItemCount:readSaleItems().length
    };
  }



  function getSheetHeaderMap_(sheetName){
    var sh = getDbSpreadsheet().getSheetByName(sheetName);
    if (!sh) throw new Error(sheetName + ' 시트를 찾지 못했습니다.');
    var header = sh.getRange(1,1,1,sh.getLastColumn()).getDisplayValues()[0];
    var map = {};
    header.forEach(function(h, i){ map[String(h||'')] = i + 1; });
    return { sheet: sh, header: header, map: map };
  }

  function mergeCustomerRecords(payload){
    var sourceId = s(payload.sourceCustomerId);
    var targetId = s(payload.targetCustomerId);
    if (!sourceId || !targetId) throw new Error('원본/대상 고객ID가 필요합니다.');
    if (sourceId === targetId) throw new Error('같은 고객ID로 병합할 수 없습니다.');
    var moved = {sales:0, asRows:0, evidence:0, installs:0, cancels:0};

    function moveRefs(sheetName, fieldName, fromId, toId){
      var meta = getSheetHeaderMap_(sheetName);
      var col = meta.map[fieldName];
      if (!col) return 0;
      var vals = meta.sheet.getDataRange().getDisplayValues();
      var count = 0;
      for (var r=1;r<vals.length;r++){
        if (String(vals[r][col-1] || '') === String(fromId)){
          meta.sheet.getRange(r+1, col).setValue(toId);
          count++;
        }
      }
      return count;
    }

    moved.sales = moveRefs('Sales', 'customerId', sourceId, targetId);
    moved.asRows = moveRefs('ASRequests', 'customerId', sourceId, targetId);
    moved.evidence = moveRefs('EvidenceMailQueue', 'customerId', sourceId, targetId);
    moved.installs = moveRefs('InstallCompletions', 'customerId', sourceId, targetId);

    try { updateRowById('Customers', 'customerId', sourceId, { status:'MERGED' }); } catch(e){}

    var logSh = ensureSheet('CustomerMergeLog', ['mergeId','sourceCustomerId','targetCustomerId','movedSales','movedAS','movedEvidence','movedInstalls','movedCancels','status','createdAt']);
    var mergeId = nextId('MRG-', logSh, 1);
    logSh.appendRow([mergeId, sourceId, targetId, moved.sales, moved.asRows, moved.evidence, moved.installs, moved.cancels, 'DONE', ts()]);
    return { ok:true, mergeId:mergeId, sourceCustomerId:sourceId, targetCustomerId:targetId, moved:moved };
  }

  function readClaimApprovals(){
    return readTable('ClaimApprovals').map(function(r){
      return { approvalId:s(r.approvalId), asId:s(r.asId), saleId:s(r.saleId), vendorId:s(r.vendorId), claimType:s(r.claimType), claimAmount:n(r.claimAmount), status:s(r.status), requestedAt:s(r.requestedAt), approvedAt:s(r.approvedAt), note:s(r.note) };
    });
  }

  function requestClaimApproval(payload){
    var sh = ensureSheet('ClaimApprovals', ['approvalId','asId','saleId','vendorId','claimType','claimAmount','status','requestedAt','approvedAt','note']);
    var id = nextId('CLM-', sh, 1);
    sh.appendRow([id, s(payload.asId), s(payload.saleId), s(payload.vendorId), s(payload.claimType), n(payload.claimAmount), 'REQUEST', ts(), '', s(payload.note)]);
    if (s(payload.asId)) {
      try { updateRowById('ASRequests', 'asId', s(payload.asId), { claimStatus:'REVIEW', updatedAt:ts() }); } catch(e) {}
    }
    return { ok:true, approvalId:id };
  }

  function approveClaimApproval(approvalId){
    updateRowById('ClaimApprovals', 'approvalId', approvalId, { status:'APPROVED', approvedAt:ts() });
    var row = readClaimApprovals().filter(function(v){ return String(v.approvalId) === String(approvalId); })[0];
    if (row && row.asId) {
      try { updateRowById('ASRequests', 'asId', row.asId, { claimStatus:'DONE', status:'클레임', updatedAt:ts() }); } catch(e) {}
    }
    return { ok:true, approvalId:approvalId };
  }

  function rejectClaimApproval(approvalId){
    updateRowById('ClaimApprovals', 'approvalId', approvalId, { status:'REJECTED', approvedAt:ts() });
    var row = readClaimApprovals().filter(function(v){ return String(v.approvalId) === String(approvalId); })[0];
    if (row && row.asId) {
      try { updateRowById('ASRequests', 'asId', row.asId, { claimStatus:'REJECTED', updatedAt:ts() }); } catch(e) {}
    }
    return { ok:true, approvalId:approvalId };
  }

  function getClaimApprovalRows(status){
    var rows = readClaimApprovals().slice(-50).reverse();
    if (!status || status === 'ALL') return rows;
    return rows.filter(function(v){ return String(v.status || '') === String(status); });
  }

  function getEngineerScheduleBoard(dateFrom, dateTo){
    var from = s(dateFrom);
    var to = s(dateTo);
    var rows = readInstallAssignments().filter(function(v){
      var d = s(v.visitDate);
      if (from && d && d < from) return false;
      if (to && d && d > to) return false;
      return true;
    }).slice(-100).reverse();
    var summary = {};
    rows.forEach(function(v){
      var key = s(v.engineer) || '미배정';
      if (!summary[key]) summary[key] = { engineer:key, count:0, visits:0 };
      summary[key].count += 1;
      if (s(v.status) === 'DONE') summary[key].visits += 1;
    });
    return { rows: rows, summary: Object.keys(summary).map(function(k){ return summary[k]; }) };
  }

  function getMonthlyClosingDetailRows(closingMonth){
    var month = s(closingMonth);
    var sales = readSales();
    if (month) {
      sales = sales.filter(function(v){ return s(v.createdAt).substring(0,7) === month; });
    }
    var vendors = rowMap(readVendors(), 'vendorId');
    var byVendor = {};
    sales.forEach(function(v){
      var key = s(v.vendorId) || 'UNKNOWN';
      if (!byVendor[key]) byVendor[key] = { vendorId:key, vendorName:(vendors[key]||{}).vendorName || key, salesCount:0, totalAmount:0, depositAmount:0, balanceAmount:0, cancelCount:0 };
      byVendor[key].salesCount += 1;
      byVendor[key].totalAmount += n(v.totalAmount);
      byVendor[key].depositAmount += n(v.depositAmount);
      byVendor[key].balanceAmount += n(v.balanceAmount);
      if (String(v.status||'').indexOf('CANCEL') > -1 || String(v.saleStage||'').indexOf('취소') > -1) byVendor[key].cancelCount += 1;
    });
    return Object.keys(byVendor).map(function(k){ return byVendor[k]; }).sort(function(a,b){ return b.totalAmount - a.totalAmount; });
  }

  function getInstallDelayBoard(){
    var overdue = getOverdueInstallations();
    var assignments = readInstallAssignments();
    return {
      overdueCount: overdue.length,
      unassignedCount: overdue.filter(function(v){ return !s(v.installer); }).length,
      assignmentCount: assignments.length,
      rows: overdue.slice(0, 50)
    };
  }


  function readEmployees(){
    return readTable('Employees').map(function(r){
      return {
        employeeId:s(r.employeeId), vendorId:s(r.vendorId), name:s(r.name), phone:normalizePhone(r.phone),
        email:s(r.email), department:s(r.department), role:s(r.role), status:s(r.status) || 'ACTIVE',
        eventScope:s(r.eventScope) || 'ALL', menuScope:s(r.menuScope), createdAt:s(r.createdAt), updatedAt:s(r.updatedAt)
      };
    });
  }

  function readRolePolicies(){
    return readTable('RolePolicies').map(function(r){
      return {
        policyId:s(r.policyId), vendorId:s(r.vendorId) || 'DEFAULT', instantRoles:s(r.instantRoles), approvalRoles:s(r.approvalRoles),
        instantMenus:s(r.instantMenus), approvalMenus:s(r.approvalMenus), downloadPolicy:s(r.downloadPolicy),
        sensitiveAllowed:s(r.sensitiveAllowed) || 'N', createdAt:s(r.createdAt)
      };
    });
  }

  function readEmployeeRoleRequests(){
    return readTable('EmployeeRoleRequests').map(function(r){
      return {
        requestId:s(r.requestId), vendorId:s(r.vendorId), employeeId:s(r.employeeId), employeeName:s(r.employeeName),
        requestedRole:s(r.requestedRole), requestType:s(r.requestType), status:s(r.status), requestedBy:s(r.requestedBy),
        approvedBy:s(r.approvedBy), note:s(r.note), createdAt:s(r.createdAt), approvedAt:s(r.approvedAt)
      };
    });
  }

  function readPostCancelSettlements(){
    return readTable('PostCancelSettlements').map(function(r){
      return {
        pcsId:s(r.pcsId), saleId:s(r.saleId), vendorId:s(r.vendorId), reasonType:s(r.reasonType),
        customerRefund:n(r.customerRefund), vendorRecovery:n(r.vendorRecovery), vendorAdditionalPayment:n(r.vendorAdditionalPayment),
        hqBurden:n(r.hqBurden), recoveryMode:s(r.recoveryMode), additionalPaymentReason:s(r.additionalPaymentReason),
        status:s(r.status), requestedBy:s(r.requestedBy), approvedBy:s(r.approvedBy), note:s(r.note),
        createdAt:s(r.createdAt), approvedAt:s(r.approvedAt)
      };
    });
  }

  function addApprovalAudit(auditType, refId, status, actor, targetId, note){
    var sh = ensureSheet('ApprovalAudit', ['auditId','auditType','refId','status','actor','targetId','note','createdAt']);
    var id = nextId('ADT-', sh, 1);
    sh.appendRow([id, s(auditType), s(refId), s(status), s(actor), s(targetId), s(note), ts()]);
    return { ok:true, auditId:id };
  }

  function splitPipe(v){
    return s(v) ? s(v).split('|').map(function(x){ return s(x); }).filter(function(x){ return !!x; }) : [];
  }

  function getVendorRolePolicy(vendorId){
    var rows = readRolePolicies();
    var found = rows.filter(function(v){ return String(v.vendorId || '') === String(vendorId || ''); })[0];
    if (!found) found = rows.filter(function(v){ return String(v.vendorId || '') === 'DEFAULT'; })[0];
    if (!found) {
      found = {
        vendorId:'DEFAULT',
        instantRoles:'영업직원|설치담당|A/S담당|조회전용',
        approvalRoles:'회계담당|업체관리자|정산담당',
        instantMenus:'고객관리|판매등록|설치관리|A/S관리|일정관리',
        approvalMenus:'정산조회|정산수정|예치금조회|채권조회|상품권정산|원본파일다운로드|PDF일괄출력',
        downloadPolicy:'PDF:true,EXCEL:false,RAW:false',
        sensitiveAllowed:'N'
      };
    }
    return {
      vendorId:s(vendorId) || found.vendorId,
      instantRoles:splitPipe(found.instantRoles),
      approvalRoles:splitPipe(found.approvalRoles),
      instantMenus:splitPipe(found.instantMenus),
      approvalMenus:splitPipe(found.approvalMenus),
      downloadPolicy:s(found.downloadPolicy),
      sensitiveAllowed:s(found.sensitiveAllowed) || 'N'
    };
  }

  function getRolePolicySnapshot(vendorId){
    var p = getVendorRolePolicy(vendorId);
    var employees = readEmployees().filter(function(v){ return !vendorId || vendorId === 'ALL' || String(v.vendorId) === String(vendorId); });
    var pending = readEmployeeRoleRequests().filter(function(v){ return (!vendorId || vendorId === 'ALL' || String(v.vendorId) === String(vendorId)) && String(v.status) === 'PENDING'; }).slice(-30).reverse();
    return { policy:p, employees:employees.slice(-50).reverse(), pendingRequests:pending };
  }

  function saveEmployee(payload){
    var sh = ensureSheet('Employees', ['employeeId','vendorId','name','phone','email','department','role','status','eventScope','menuScope','createdAt','updatedAt']);
    var id = nextId('EMP-', sh, 1);
    sh.appendRow([id, s(payload.vendorId), s(payload.name), normalizePhone(payload.phone), s(payload.email), s(payload.department), s(payload.role), s(payload.status) || 'ACTIVE', s(payload.eventScope) || 'ALL', s(payload.menuScope), ts(), ts()]);
    addApprovalAudit('EMPLOYEE_CREATE', id, 'DONE', 'ERP', id, s(payload.role));
    return { ok:true, employeeId:id };
  }

  function requestEmployeeRoleChange(payload){
    var vendorId = s(payload.vendorId);
    var employeeId = s(payload.employeeId);
    var requestedRole = s(payload.requestedRole);
    if (!vendorId || !employeeId || !requestedRole) throw new Error('업체ID/직원ID/요청역할이 필요합니다.');
    var policy = getVendorRolePolicy(vendorId);
    var requiresApproval = policy.approvalRoles.indexOf(requestedRole) > -1;
    if (!requiresApproval) {
      updateRowById('Employees', 'employeeId', employeeId, { role:requestedRole, updatedAt:ts() });
      addApprovalAudit('ROLE_CHANGE', employeeId, 'INSTANT', s(payload.requestedBy) || 'ERP', employeeId, requestedRole);
      return { ok:true, mode:'INSTANT', employeeId:employeeId, requestedRole:requestedRole };
    }
    var em = readEmployees().filter(function(v){ return String(v.employeeId) === employeeId; })[0] || {};
    var sh = ensureSheet('EmployeeRoleRequests', ['requestId','vendorId','employeeId','employeeName','requestedRole','requestType','status','requestedBy','approvedBy','note','createdAt','approvedAt']);
    var id = nextId('ERQ-', sh, 1);
    sh.appendRow([id, vendorId, employeeId, s(em.name), requestedRole, s(payload.requestType) || 'ROLE_CHANGE', 'PENDING', s(payload.requestedBy) || 'ERP', '', s(payload.note), ts(), '']);
    addApprovalAudit('ROLE_CHANGE', id, 'PENDING', s(payload.requestedBy) || 'ERP', employeeId, requestedRole);
    return { ok:true, mode:'APPROVAL', requestId:id, employeeId:employeeId, requestedRole:requestedRole };
  }

  function approveEmployeeRoleChange(requestId, actor){
    updateRowById('EmployeeRoleRequests', 'requestId', requestId, { status:'APPROVED', approvedBy:s(actor) || 'ERP', approvedAt:ts() });
    var row = readEmployeeRoleRequests().filter(function(v){ return String(v.requestId) === String(requestId); })[0];
    if (row && row.employeeId) updateRowById('Employees', 'employeeId', row.employeeId, { role:row.requestedRole, updatedAt:ts() });
    addApprovalAudit('ROLE_CHANGE', requestId, 'APPROVED', s(actor) || 'ERP', row ? row.employeeId : '', row ? row.requestedRole : '');
    return { ok:true, requestId:requestId, employeeId:row ? row.employeeId : '' };
  }

  function rejectEmployeeRoleChange(requestId, actor){
    updateRowById('EmployeeRoleRequests', 'requestId', requestId, { status:'REJECTED', approvedBy:s(actor) || 'ERP', approvedAt:ts() });
    var row = readEmployeeRoleRequests().filter(function(v){ return String(v.requestId) === String(requestId); })[0];
    addApprovalAudit('ROLE_CHANGE', requestId, 'REJECTED', s(actor) || 'ERP', row ? row.employeeId : '', row ? row.requestedRole : '');
    return { ok:true, requestId:requestId };
  }

  function getEmployeeRows(vendorId){
    var rows = readEmployees();
    if (vendorId && vendorId !== 'ALL') rows = rows.filter(function(v){ return String(v.vendorId) === String(vendorId); });
    return rows.slice(-100).reverse();
  }

  function getBenefitControlSummary(){
    var rows = readBenefitPayouts();
    var byType = {};
    rows.forEach(function(v){ var key = s(v.benefitType) || '기타'; byType[key] = (byType[key] || 0) + 1; });
    return {
      total: rows.length,
      pending: rows.filter(function(v){ return s(v.status) === 'PENDING'; }).length,
      approved: rows.filter(function(v){ return s(v.status) === 'APPROVED'; }).length,
      giftReady: rows.filter(function(v){ return s(v.giftStatus) === 'READY'; }).length,
      byType: byType
    };
  }

  function getFundControlSummary(){
    var rows = readFundExecutions();
    var requested = 0, approved = 0;
    rows.forEach(function(v){ requested += n(v.requestedAmount); approved += n(v.approvedAmount); });
    return {
      total: rows.length,
      pending: rows.filter(function(v){ return s(v.status) === 'PENDING'; }).length,
      approvedCount: rows.filter(function(v){ return s(v.status) === 'APPROVED'; }).length,
      requestedAmount: requested,
      approvedAmount: approved
    };
  }

  function getDepositControlSummary(){
    var rows = readDepositLedger();
    var byVendor = {};
    rows.forEach(function(v){
      var key = s(v.vendorId) || 'UNKNOWN';
      if (!byVendor[key]) byVendor[key] = { vendorId:key, balance:0, rows:0 };
      byVendor[key].balance = n(v.balanceAfter);
      byVendor[key].rows += 1;
    });
    return {
      total: rows.length,
      vendors: Object.keys(byVendor).length,
      latestBalances: Object.keys(byVendor).map(function(k){ return byVendor[k]; }).sort(function(a,b){ return b.balance - a.balance; }).slice(0,10)
    };
  }

  function calculatePostCancelSettlement(payload){
    var saleId = s(payload.saleId);
    var reasonType = s(payload.reasonType) || '고객요청';
    var sale = readSales().filter(function(v){ return String(v.saleId) === saleId; })[0];
    if (!sale) throw new Error('판매를 찾지 못했습니다: ' + saleId);
    var customerRefund = n(payload.customerRefund || sale.totalAmount || 0);
    var vendorRecovery = n(payload.vendorRecovery);
    var vendorAdditionalPayment = n(payload.vendorAdditionalPayment);
    if (!vendorRecovery && !vendorAdditionalPayment){
      if (reasonType === '고객요청' || reasonType === '고객변심') vendorRecovery = n(sale.totalAmount);
      else if (reasonType === '업체귀책' || reasonType === '설치불가') vendorRecovery = n(sale.totalAmount);
      else if (reasonType === '본사정책' || reasonType === '행사정책') vendorAdditionalPayment = Math.round(n(sale.totalAmount) * 0.1);
      else vendorRecovery = n(sale.totalAmount);
    }
    var hqBurden = customerRefund + vendorAdditionalPayment - vendorRecovery;
    return {
      saleId:sale.saleId,
      vendorId:sale.vendorId,
      reasonType:reasonType,
      totalAmount:n(sale.totalAmount),
      customerRefund:customerRefund,
      vendorRecovery:vendorRecovery,
      vendorAdditionalPayment:vendorAdditionalPayment,
      hqBurden:hqBurden,
      recoveryMode:s(payload.recoveryMode) || 'NEXT_SETTLEMENT_DEDUCT',
      additionalPaymentReason:s(payload.additionalPaymentReason) || (vendorAdditionalPayment > 0 ? 'POLICY_COMPENSATION' : ''),
      note:s(payload.note)
    };
  }

  function requestPostCancelSettlement(payload){
    var calc = calculatePostCancelSettlement(payload);
    var sh = ensureSheet('PostCancelSettlements', ['pcsId','saleId','vendorId','reasonType','customerRefund','vendorRecovery','vendorAdditionalPayment','hqBurden','recoveryMode','additionalPaymentReason','status','requestedBy','approvedBy','note','createdAt','approvedAt']);
    var id = nextId('PCS-', sh, 1);
    sh.appendRow([id, calc.saleId, calc.vendorId, calc.reasonType, calc.customerRefund, calc.vendorRecovery, calc.vendorAdditionalPayment, calc.hqBurden, calc.recoveryMode, calc.additionalPaymentReason, 'PENDING', s(payload.requestedBy) || 'ERP', '', calc.note, ts(), '']);
    addApprovalAudit('POST_CANCEL', id, 'PENDING', s(payload.requestedBy) || 'ERP', calc.saleId, calc.reasonType);
    return { ok:true, pcsId:id, calc:calc };
  }

  function approvePostCancelSettlement(pcsId, actor){
    updateRowById('PostCancelSettlements', 'pcsId', pcsId, { status:'APPROVED', approvedBy:s(actor) || 'ERP', approvedAt:ts() });
    var row = readPostCancelSettlements().filter(function(v){ return String(v.pcsId) === String(pcsId); })[0];
    if (row && row.saleId) {
      try { updateRowById('Cancellations', 'saleId', row.saleId, { status:'APPROVED' }); } catch(e) {}
      try { updateRowById('Sales', 'saleId', row.saleId, { status:'CANCELLATION_PENDING', saleStage:'취소정산승인' }); } catch(e) {}
    }
    addApprovalAudit('POST_CANCEL', pcsId, 'APPROVED', s(actor) || 'ERP', row ? row.saleId : '', row ? row.reasonType : '');
    return { ok:true, pcsId:pcsId };
  }

  function getPostCancelSettlementRows(status){
    var rows = readPostCancelSettlements().slice(-100).reverse();
    if (!status || status === 'ALL') return rows;
    return rows.filter(function(v){ return String(v.status || '') === String(status); });
  }

  function runDiagnosticsSuite(){
    var smoke = smokeTestErp();
    var rows = getDiagnosticsBundle().rows || [];
    var pendingRole = readEmployeeRoleRequests().filter(function(v){ return s(v.status) === 'PENDING'; }).length;
    var pendingPostCancel = readPostCancelSettlements().filter(function(v){ return s(v.status) === 'PENDING'; }).length;
    var warnings = [];
    if (!smoke.eventsCount) warnings.push('행사 데이터 없음');
    if (!smoke.vendorsCount) warnings.push('업체 데이터 없음');
    if (pendingRole) warnings.push('권한승인 대기 ' + pendingRole + '건');
    if (pendingPostCancel) warnings.push('사후취소정산 대기 ' + pendingPostCancel + '건');
    return {
      smoke:smoke,
      diagCount:rows.length,
      errorCount:rows.filter(function(v){ return String(v.level || '').toUpperCase() === 'ERROR'; }).length,
      pendingRole:pendingRole,
      pendingPostCancel:pendingPostCancel,
      warnings:warnings
    };
  }


  function approveFundExecution(executionId, approvedAmount){
    var row = readFundExecutions().filter(function(v){ return String(v.executionId) === String(executionId); })[0];
    if (!row) throw new Error('발전기금 실행건을 찾지 못했습니다: ' + executionId);
    var amount = n(approvedAmount || row.requestedAmount || 0);
    updateRowById('FundExecutions', 'executionId', executionId, { status:'APPROVED', approvedAmount:amount });
    addApprovalAudit('FUND_EXECUTION', executionId, 'APPROVED', 'ERP', executionId, String(amount));
    return { ok:true, executionId:executionId, approvedAmount:amount };
  }


  function readVendorControlPolicies(){
    return readTable('VendorControlPolicies').map(function(r){
      return {
        policyId:s(r.policyId), vendorId:s(r.vendorId) || 'DEFAULT', settlementAccess:s(r.settlementAccess) || 'APPROVAL',
        depositAccess:s(r.depositAccess) || 'APPROVAL', fundAccess:s(r.fundAccess) || 'APPROVAL',
        sensitiveView:s(r.sensitiveView) || 'BLOCK', rawDownload:s(r.rawDownload) || 'BLOCK',
        excelDownload:s(r.excelDownload) || 'BLOCK', postCancelApprove:s(r.postCancelApprove) || 'APPROVAL',
        employeeApproveStage:s(r.employeeApproveStage) || '2STEP', memo:s(r.memo), updatedAt:s(r.updatedAt)
      };
    });
  }

  function readSensitiveAccessRequests(){
    return readTable('SensitiveAccessRequests').map(function(r){
      return {
        accessId:s(r.accessId), vendorId:s(r.vendorId), employeeId:s(r.employeeId), requestType:s(r.requestType),
        targetMenu:s(r.targetMenu), status:s(r.status), requestedBy:s(r.requestedBy), approvedBy:s(r.approvedBy),
        note:s(r.note), createdAt:s(r.createdAt), approvedAt:s(r.approvedAt)
      };
    });
  }

  function getVendorControlPolicy(vendorId){
    var rows = readVendorControlPolicies();
    var found = rows.filter(function(v){ return String(v.vendorId) === String(vendorId || ''); })[0];
    if (!found) found = rows.filter(function(v){ return String(v.vendorId) === 'DEFAULT'; })[0];
    if (!found) {
      found = { vendorId:'DEFAULT', settlementAccess:'APPROVAL', depositAccess:'APPROVAL', fundAccess:'APPROVAL', sensitiveView:'BLOCK', rawDownload:'BLOCK', excelDownload:'BLOCK', postCancelApprove:'APPROVAL', employeeApproveStage:'2STEP', memo:'기본 민감권한 통제정책', updatedAt:ts() };
    }
    return found;
  }

  function saveVendorControlPolicy(payload){
    var vendorId = s(payload.vendorId);
    if (!vendorId) throw new Error('업체ID가 없습니다.');
    var sh = ensureSheet('VendorControlPolicies', ['policyId','vendorId','settlementAccess','depositAccess','fundAccess','sensitiveView','rawDownload','excelDownload','postCancelApprove','employeeApproveStage','memo','updatedAt']);
    var rows = readVendorControlPolicies();
    var existing = rows.filter(function(v){ return String(v.vendorId) === String(vendorId); })[0];
    var data = { vendorId:vendorId, settlementAccess:s(payload.settlementAccess) || 'APPROVAL', depositAccess:s(payload.depositAccess) || 'APPROVAL', fundAccess:s(payload.fundAccess) || 'APPROVAL', sensitiveView:s(payload.sensitiveView) || 'BLOCK', rawDownload:s(payload.rawDownload) || 'BLOCK', excelDownload:s(payload.excelDownload) || 'BLOCK', postCancelApprove:s(payload.postCancelApprove) || 'APPROVAL', employeeApproveStage:s(payload.employeeApproveStage) || '2STEP', memo:s(payload.memo), updatedAt:ts() };
    if (existing && existing.policyId) {
      updateRowById('VendorControlPolicies', 'policyId', existing.policyId, data);
      addApprovalAudit('VENDOR_CONTROL', existing.policyId, 'UPDATED', s(payload.actor) || 'ERP', vendorId, data.memo || '');
      return { ok:true, policyId:existing.policyId, vendorId:vendorId };
    }
    var id = nextId('VCP-', sh, 1);
    sh.appendRow([id, vendorId, data.settlementAccess, data.depositAccess, data.fundAccess, data.sensitiveView, data.rawDownload, data.excelDownload, data.postCancelApprove, data.employeeApproveStage, data.memo, data.updatedAt]);
    addApprovalAudit('VENDOR_CONTROL', id, 'CREATED', s(payload.actor) || 'ERP', vendorId, data.memo || '');
    return { ok:true, policyId:id, vendorId:vendorId };
  }

  function reviewEmployeeRoleChange(requestId, actor, note){
    updateRowById('EmployeeRoleRequests', 'requestId', requestId, { status:'REVIEW', approvedBy:s(actor) || 'ERP', note:s(note), approvedAt:ts() });
    var row = readEmployeeRoleRequests().filter(function(v){ return String(v.requestId) === String(requestId); })[0];
    addApprovalAudit('ROLE_CHANGE', requestId, 'REVIEW', s(actor) || 'ERP', row ? row.employeeId : '', s(note) || (row ? row.requestedRole : ''));
    return { ok:true, requestId:requestId, status:'REVIEW' };
  }

  function requestSensitiveMenuAccess(payload){
    var vendorId = s(payload.vendorId);
    if (!vendorId) throw new Error('업체ID가 없습니다.');
    var sh = ensureSheet('SensitiveAccessRequests', ['accessId','vendorId','employeeId','requestType','targetMenu','status','requestedBy','approvedBy','note','createdAt','approvedAt']);
    var id = nextId('SAR-', sh, 1);
    sh.appendRow([id, vendorId, s(payload.employeeId), s(payload.requestType) || 'MENU_ACCESS', s(payload.targetMenu), 'PENDING', s(payload.requestedBy) || 'ERP', '', s(payload.note), ts(), '']);
    addApprovalAudit('SENSITIVE_ACCESS', id, 'PENDING', s(payload.requestedBy) || 'ERP', s(payload.employeeId) || vendorId, s(payload.targetMenu));
    return { ok:true, accessId:id };
  }

  function actSensitiveMenuAccess(accessId, action, actor, note){
    var next = s(action).toUpperCase() === 'APPROVED' ? 'APPROVED' : (s(action).toUpperCase() === 'REVIEW' ? 'REVIEW' : 'REJECTED');
    updateRowById('SensitiveAccessRequests', 'accessId', accessId, { status:next, approvedBy:s(actor) || 'ERP', note:s(note), approvedAt:ts() });
    var row = readSensitiveAccessRequests().filter(function(v){ return String(v.accessId) === String(accessId); })[0];
    addApprovalAudit('SENSITIVE_ACCESS', accessId, next, s(actor) || 'ERP', row ? (row.employeeId || row.vendorId) : '', s(note) || (row ? row.targetMenu : ''));
    return { ok:true, accessId:accessId, status:next };
  }

  function getSensitiveAccessRows(status, vendorId){
    var rows = readSensitiveAccessRequests().slice(-100).reverse();
    if (vendorId && vendorId !== 'ALL') rows = rows.filter(function(v){ return String(v.vendorId) === String(vendorId); });
    if (status && status !== 'ALL') rows = rows.filter(function(v){ return String(v.status) === String(status); });
    return rows;
  }

  function getVendorControlBoard(vendorId){
    var policy = getVendorControlPolicy(vendorId);
    var roleRequests = readEmployeeRoleRequests().filter(function(v){ return !vendorId || vendorId === 'ALL' || String(v.vendorId) === String(vendorId); });
    var sensitiveRows = readSensitiveAccessRequests().filter(function(v){ return !vendorId || vendorId === 'ALL' || String(v.vendorId) === String(vendorId); });
    var employees = readEmployees().filter(function(v){ return !vendorId || vendorId === 'ALL' || String(v.vendorId) === String(vendorId); });
    var blockedEmployees = employees.filter(function(v){ return ['INACTIVE','SUSPENDED','LOCKED'].indexOf(String(v.status)) > -1; }).length;
    return { policy:policy, counts:{ employees:employees.length, blockedEmployees:blockedEmployees, pendingRole:roleRequests.filter(function(v){ return s(v.status) === 'PENDING' || s(v.status) === 'REVIEW'; }).length, pendingSensitive:sensitiveRows.filter(function(v){ return s(v.status) === 'PENDING' || s(v.status) === 'REVIEW'; }).length }, roleRequests:roleRequests.slice(-30).reverse(), sensitiveRows:sensitiveRows.slice(-30).reverse() };
  }

  function getVendorSensitiveSummary(vendorId){
    var p = getVendorControlPolicy(vendorId);
    var rows = getSensitiveAccessRows('ALL', vendorId);
    return { vendorId:vendorId, settlementAccess:p.settlementAccess, depositAccess:p.depositAccess, fundAccess:p.fundAccess, sensitiveView:p.sensitiveView, rawDownload:p.rawDownload, excelDownload:p.excelDownload, postCancelApprove:p.postCancelApprove, employeeApproveStage:p.employeeApproveStage, pending:rows.filter(function(v){ return s(v.status) === 'PENDING'; }).length, review:rows.filter(function(v){ return s(v.status) === 'REVIEW'; }).length, approved:rows.filter(function(v){ return s(v.status) === 'APPROVED'; }).length, rejected:rows.filter(function(v){ return s(v.status) === 'REJECTED'; }).length };
  }

  function getEmployeeRoleRequestRows(status, vendorId){
    var rows = readEmployeeRoleRequests().slice(-100).reverse();
    if (vendorId && vendorId !== 'ALL') rows = rows.filter(function(v){ return String(v.vendorId) === String(vendorId); });
    if (status && status !== 'ALL') rows = rows.filter(function(v){ return String(v.status) === String(status); });
    return rows;
  }

  function getIntegratedApprovalSummary(){
    var permission = readPermissionRequests().filter(function(v){ return s(v.status) === 'PENDING'; });
    var onboard = readOnboardings().filter(function(v){ return s(v.status) !== 'APPROVED'; });
    var cancels = readCancellations().filter(function(v){ return s(v.status) === 'PENDING'; });
    var roleRows = readEmployeeRoleRequests().filter(function(v){ return s(v.status) === 'PENDING'; });
    var postCancel = readPostCancelSettlements().filter(function(v){ return s(v.status) === 'PENDING'; });
    var claims = readClaimApprovals().filter(function(v){ return s(v.status) === 'REQUEST'; });
    var benefits = readBenefitPayouts().filter(function(v){ return s(v.status) === 'PENDING'; });
    var funds = readFundExecutions().filter(function(v){ return s(v.status) === 'PENDING'; });
    var sensitive = readSensitiveAccessRequests().filter(function(v){ return s(v.status) === 'PENDING' || s(v.status) === 'REVIEW'; });
    var diag = getDiagnosticsBundle().rows || [];
    var errorCount = diag.filter(function(v){ return String(v.level || '').toUpperCase() === 'ERROR'; }).length;
    var rows = [];
    permission.slice(0,10).forEach(function(v){ rows.push({ kind:'권한요청', id:v.requestId, target:v.vendorId, status:v.status, note:v.requestType || '' }); });
    onboard.slice(0,10).forEach(function(v){ rows.push({ kind:'온보딩', id:v.onboardingId, target:v.vendorName, status:v.status, note:v.approvedBy ? '' : '점검중' }); });
    cancels.slice(0,10).forEach(function(v){ rows.push({ kind:'취소승인', id:v.cancellationId, target:v.saleId, status:v.status, note:v.reasonType || '' }); });
    roleRows.slice(0,10).forEach(function(v){ rows.push({ kind:'직원권한', id:v.requestId, target:v.employeeName || v.employeeId, status:v.status, note:v.requestedRole || '' }); });
    postCancel.slice(0,10).forEach(function(v){ rows.push({ kind:'사후취소정산', id:v.pcsId, target:v.saleId, status:v.status, note:v.reasonType || '' }); });
    claims.slice(0,10).forEach(function(v){ rows.push({ kind:'클레임승인', id:v.approvalId, target:v.asId || v.saleId, status:v.status, note:v.claimType || '' }); });
    benefits.slice(0,10).forEach(function(v){ rows.push({ kind:'혜택지급', id:v.payoutId, target:v.customerId, status:v.status, note:v.benefitType || '' }); });
    funds.slice(0,10).forEach(function(v){ rows.push({ kind:'발전기금', id:v.executionId, target:v.projectId, status:v.status, note:String(v.requestedAmount || '') }); });
    sensitive.slice(0,10).forEach(function(v){ rows.push({ kind:'민감권한', id:v.accessId, target:v.employeeId || v.vendorId, status:v.status, note:v.targetMenu || '' }); });
    return {
      counts: {
        permission: permission.length,
        onboard: onboard.length,
        cancel: cancels.length,
        role: roleRows.length,
        postCancel: postCancel.length,
        claim: claims.length,
        benefit: benefits.length,
        fund: funds.length,
        sensitive: sensitive.length,
        diagError: errorCount,
        totalPending: permission.length + onboard.length + cancels.length + roleRows.length + postCancel.length + claims.length + benefits.length + funds.length + sensitive.length
      },
      rows: rows.slice(0,40)
    };
  }



  function getApprovalAuditRows(auditType, status){
    var rows = readTable('ApprovalAudit').map(function(r){
      return {
        auditId:s(r.auditId), auditType:s(r.auditType), refId:s(r.refId), status:s(r.status),
        actor:s(r.actor), targetId:s(r.targetId), note:s(r.note), createdAt:s(r.createdAt)
      };
    }).slice(-200).reverse();
    if (auditType && auditType !== 'ALL') rows = rows.filter(function(v){ return String(v.auditType) === String(auditType); });
    if (status && status !== 'ALL') rows = rows.filter(function(v){ return String(v.status) === String(status); });
    return rows;
  }

  function getDepositLedgerRows(vendorId){
    var rows = readDepositLedger().slice(-200).reverse();
    if (vendorId && vendorId !== 'ALL') rows = rows.filter(function(v){ return String(v.vendorId) === String(vendorId); });
    return rows;
  }

  function getFundExecutionRows(status){
    var rows = readFundExecutions().slice(-200).reverse().map(function(v){
      return {
        executionId:s(v.executionId), projectId:s(v.projectId), requestedAmount:n(v.requestedAmount),
        approvedAmount:n(v.approvedAmount), status:s(v.status), createdAt:s(v.createdAt)
      };
    });
    if (status && status !== 'ALL') rows = rows.filter(function(v){ return String(v.status) === String(status); });
    return rows;
  }

  function getPriorityActionRows(){
    var rows = [];
    readSales().forEach(function(v){
      var balance = n(v.balanceAmount);
      if (balance > 0) rows.push({ priority:'HIGH', category:'미수금', refId:s(v.saleId), status:s(v.status)||'OPEN', amount:balance, note:(s(v.customerId) + ' / ' + s(v.vendorId)).trim() });
      if (s(v.status) === 'INSTALL_PENDING') rows.push({ priority:'MEDIUM', category:'설치대기', refId:s(v.saleId), status:s(v.installStatus)||'PENDING', amount:n(v.totalAmount), note:(s(v.installDate) + ' / ' + s(v.installer)).trim() });
      if (s(v.cardMatchStatus) === 'UNMATCHED') rows.push({ priority:'MEDIUM', category:'카드미매칭', refId:s(v.saleId), status:'UNMATCHED', amount:n(v.totalAmount), note:s(v.cardCompany) });
      if (s(v.status) === 'CANCELLATION_PENDING') rows.push({ priority:'HIGH', category:'취소대기', refId:s(v.saleId), status:s(v.saleStage)||'PENDING', amount:n(v.totalAmount), note:s(v.customerId) });
    });
    readTable('EvidenceMailQueue').forEach(function(v){
      if (s(v.status) === 'PENDING') rows.push({ priority:'MEDIUM', category:'증빙대기', refId:s(v.queueId), status:s(v.status), amount:0, note:(s(v.docType)+' / '+s(v.saleId)).trim() });
    });
    readTable('ASRequests').forEach(function(v){
      if (s(v.status) !== 'DONE') rows.push({ priority:s(v.priority)==='긴급'?'HIGH':'MEDIUM', category:'A/S', refId:s(v.asId), status:s(v.status)||'OPEN', amount:n(v.cost), note:s(v.content) });
    });
    readEmployeeRoleRequests().forEach(function(v){
      if (s(v.status) === 'PENDING') rows.push({ priority:'MEDIUM', category:'직원권한', refId:s(v.requestId), status:s(v.status), amount:0, note:(s(v.employeeName)+' / '+s(v.requestedRole)).trim() });
    });
    readPostCancelSettlements().forEach(function(v){
      if (s(v.status) === 'PENDING') rows.push({ priority:'HIGH', category:'사후취소정산', refId:s(v.pcsId), status:s(v.status), amount:n(v.customerRefund), note:(s(v.saleId)+' / '+s(v.reasonType)).trim() });
    });
    readSensitiveAccessRequests().forEach(function(v){
      if (s(v.status) === 'PENDING' || s(v.status) === 'REVIEW') rows.push({ priority:'HIGH', category:'민감권한', refId:s(v.accessId), status:s(v.status), amount:0, note:(s(v.employeeId)+' / '+s(v.targetMenu)).trim() });
    });
    rows.sort(function(a,b){
      var rank = {HIGH:3, MEDIUM:2, LOW:1};
      if ((rank[b.priority]||0)!==(rank[a.priority]||0)) return (rank[b.priority]||0)-(rank[a.priority]||0);
      return (b.amount||0)-(a.amount||0);
    });
    return rows.slice(0,120);
  }

  function getApprovalHistorySummary(){
    var rows = getApprovalAuditRows('ALL','ALL');
    var byType = {};
    rows.forEach(function(v){ byType[v.auditType || '기타'] = (byType[v.auditType || '기타'] || 0) + 1; });
    return { total:rows.length, byType:byType, recent:rows.slice(0,20) };
  }

  function readSettlementApprovalSteps(){ return readTable('SettlementApprovalSteps').map(function(r){ return { stepId:s(r.stepId), closingId:s(r.closingId), vendorId:s(r.vendorId), approvalStage:s(r.approvalStage), actionStatus:s(r.actionStatus), requestedAmount:n(r.requestedAmount), approvedAmount:n(r.approvedAmount), requestedBy:s(r.requestedBy), actedBy:s(r.actedBy), note:s(r.note), createdAt:s(r.createdAt), actedAt:s(r.actedAt) }; }); }

  function requestSettlementApprovalStep(payload){
    var closingId = s(payload.closingId || payload.settlementId);
    if (!closingId) throw new Error('정산 ID가 없습니다.');
    var closing = readMonthlyClosings().filter(function(v){ return String(v.closingId) === closingId; })[0];
    if (!closing) throw new Error('정산 데이터를 찾지 못했습니다: ' + closingId);
    var sh = ensureSheet('SettlementApprovalSteps', ['stepId','closingId','vendorId','approvalStage','actionStatus','requestedAmount','approvedAmount','requestedBy','actedBy','note','createdAt','actedAt']);
    var id = nextId('SAP-', sh, 1);
    var stage = s(payload.approvalStage) || '1차검토';
    var amount = n(payload.requestedAmount || closing.salesAmount || 0);
    sh.appendRow([id, closingId, s(closing.vendorId), stage, 'REQUESTED', amount, '', s(payload.requestedBy) || 'ERP', '', s(payload.note), ts(), '']);
    try { updateRowById('MonthlyClosings', 'closingId', closingId, { status:'REQUESTED' }); } catch(e) {}
    addApprovalAudit('SETTLEMENT_APPROVAL', id, 'REQUESTED', s(payload.requestedBy) || 'ERP', closingId, stage + ' / ' + amount);
    return { ok:true, stepId:id, closingId:closingId, approvalStage:stage };
  }

  function actSettlementApprovalStep(stepId, action, actor, note, approvedAmount){
    var rows = readSettlementApprovalSteps();
    var row = rows.filter(function(v){ return String(v.stepId) === String(stepId); })[0];
    if (!row) throw new Error('정산 승인단계를 찾지 못했습니다: ' + stepId);
    var actionStatus = s(action).toUpperCase() || 'APPROVED';
    var nextStatus = actionStatus === 'REJECTED' ? 'REJECTED' : (actionStatus === 'PAID' ? 'PAID' : 'APPROVED');
    updateRowById('SettlementApprovalSteps', 'stepId', stepId, { actionStatus:nextStatus, actedBy:s(actor) || 'ERP', note:s(note) || row.note, approvedAmount:n(approvedAmount || row.requestedAmount), actedAt:ts() });
    try {
      if (nextStatus === 'REJECTED') updateRowById('MonthlyClosings', 'closingId', row.closingId, { status:'REJECTED' });
      else if (nextStatus === 'PAID') updateRowById('MonthlyClosings', 'closingId', row.closingId, { status:'PAID' });
      else updateRowById('MonthlyClosings', 'closingId', row.closingId, { status:'APPROVED' });
    } catch(e) {}
    addApprovalAudit('SETTLEMENT_APPROVAL', stepId, nextStatus, s(actor) || 'ERP', row.closingId, s(note) || row.approvalStage);
    if (nextStatus === 'APPROVED' || nextStatus === 'PAID') {
      try {
        onErpSettlementConfirmed_CreateSettlementConfirmSign(row.closingId);
      } catch (signErr) {
        console.error('[ERP_SIGN] 정산확인서 자동 생성 실패:', signErr);
      }
    }
    return { ok:true, stepId:stepId, closingId:row.closingId, status:nextStatus };
  }

  function getSettlementApprovalRows(status, vendorId){
    var rows = readSettlementApprovalSteps().slice(-100).reverse();
    if (vendorId && vendorId !== 'ALL') rows = rows.filter(function(v){ return String(v.vendorId) === String(vendorId); });
    if (status && status !== 'ALL') rows = rows.filter(function(v){ return String(v.actionStatus) === String(status); });
    return rows;
  }

  function getSettlementApprovalSummary(){
    var rows = readSettlementApprovalSteps();
    var byStatus = {};
    rows.forEach(function(v){ var key = s(v.actionStatus) || 'REQUESTED'; byStatus[key] = (byStatus[key] || 0) + 1; });
    return { total:rows.length, byStatus:byStatus, pending:rows.filter(function(v){ return s(v.actionStatus) === 'REQUESTED'; }).length, approvedAmount:rows.reduce(function(a,v){ return a + n(v.approvedAmount || v.requestedAmount); }, 0) };
  }

  function saveDepositAdjustment(payload){
    var vendorId = s(payload.vendorId);
    if (!vendorId) throw new Error('업체ID가 없습니다.');
    var rows = readDepositLedger().filter(function(v){ return String(v.vendorId) === vendorId; });
    var lastBalance = rows.length ? n(rows[rows.length - 1].balanceAfter) : 0;
    var amount = n(payload.amount);
    var type = s(payload.ledgerType) || 'ADJUST';
    var delta = ['WITHDRAW','DEDUCT','REFUND','RETURN_OUT'].indexOf(type) > -1 ? -Math.abs(amount) : Math.abs(amount);
    var after = lastBalance + delta;
    var sh = ensureSheet('DepositLedger', ['ledgerId','vendorId','ledgerType','amount','balanceAfter','eventId','memo','createdAt']);
    var id = nextId('DPT-', sh, 1);
    sh.appendRow([id, vendorId, type, delta, after, s(payload.eventId), s(payload.memo), ts()]);
    addApprovalAudit('DEPOSIT_ADJUST', id, 'DONE', s(payload.actor) || 'ERP', vendorId, type + ' / ' + delta);
    return { ok:true, ledgerId:id, balanceAfter:after };
  }

  function saveFundExecutionRequest(payload){
    var sh = ensureSheet('FundExecutions', ['executionId','projectId','requestedAmount','approvedAmount','status','createdAt']);
    var id = nextId('FUND-', sh, 1);
    sh.appendRow([id, s(payload.projectId || payload.eventId || 'GENERAL'), n(payload.requestedAmount), '', 'PENDING', ts()]);
    addApprovalAudit('FUND_EXECUTION', id, 'REQUESTED', s(payload.requestedBy) || 'ERP', s(payload.projectId || payload.eventId || 'GENERAL'), s(payload.note));
    return { ok:true, executionId:id };
  }

  function getDepositAdjustmentSummary(vendorId){
    var rows = readDepositLedger();
    if (vendorId && vendorId !== 'ALL') rows = rows.filter(function(v){ return String(v.vendorId) === String(vendorId); });
    var latest = {};
    rows.forEach(function(v){ latest[v.vendorId] = n(v.balanceAfter); });
    return { total:rows.length, vendors:Object.keys(latest).length, latestBalances:latest, recent:rows.slice(-30).reverse() };
  }



  function updateEmployeeStatus(payload){
    var employeeId = s(payload.employeeId);
    if (!employeeId) throw new Error('직원ID가 없습니다.');
    var row = readEmployees().filter(function(v){ return String(v.employeeId) === String(employeeId); })[0];
    if (!row) throw new Error('직원을 찾지 못했습니다: ' + employeeId);
    var updates = { updatedAt:ts() };
    if (payload.status !== undefined) updates.status = s(payload.status) || row.status;
    if (payload.department !== undefined) updates.department = s(payload.department) || row.department;
    if (payload.eventScope !== undefined) updates.eventScope = s(payload.eventScope) || row.eventScope;
    if (payload.menuScope !== undefined) updates.menuScope = s(payload.menuScope) || row.menuScope;
    if (payload.phone !== undefined) updates.phone = normalizePhone(payload.phone);
    if (payload.email !== undefined) updates.email = s(payload.email);
    updateRowById('Employees', 'employeeId', employeeId, updates);
    addApprovalAudit('EMPLOYEE_STATUS', employeeId, s(updates.status) || 'UPDATED', s(payload.actor) || 'ERP', employeeId, [s(updates.department), s(updates.eventScope)].filter(Boolean).join(' / '));
    return { ok:true, employeeId:employeeId, status:updates.status || row.status };
  }

  function getEmployeeOperationHistory(employeeId){
    var employee = readEmployees().filter(function(v){ return String(v.employeeId) === String(employeeId); })[0] || null;
    var roleRequests = readEmployeeRoleRequests().filter(function(v){ return String(v.employeeId) === String(employeeId); }).slice(-30).reverse();
    var audits = getApprovalAuditRows('ALL', 'ALL').filter(function(v){ return String(v.targetId) === String(employeeId) || String(v.refId) === String(employeeId); }).slice(0, 30);
    return { employee:employee, roleRequests:roleRequests, audits:audits };
  }

  function getVendorLinkedHistory(vendorId){
    var depositRows = readDepositLedger().filter(function(v){ return String(v.vendorId) === String(vendorId); }).slice(-20).reverse();
    var settlementRows = readSettlementApprovalSteps().filter(function(v){ return String(v.vendorId) === String(vendorId); }).slice(-20).reverse();
    var postCancelRows = readPostCancelSettlements().filter(function(v){ return String(v.vendorId) === String(vendorId); }).slice(-20).reverse();
    var employeeRows = readEmployees().filter(function(v){ return String(v.vendorId) === String(vendorId); }).slice(-20).reverse();
    var balance = depositRows.length ? n(depositRows[0].balanceAfter) : 0;
    var pendingSettlement = settlementRows.filter(function(v){ return s(v.actionStatus) === 'REQUESTED'; }).length;
    var pendingPostCancel = postCancelRows.filter(function(v){ return s(v.status) === 'PENDING'; }).length;
    return {
      vendorId:vendorId,
      summary:{ depositBalance:balance, settlementCount:settlementRows.length, pendingSettlement:pendingSettlement, postCancelCount:postCancelRows.length, pendingPostCancel:pendingPostCancel, employeeCount:employeeRows.length },
      depositRows:depositRows,
      settlementRows:settlementRows,
      postCancelRows:postCancelRows,
      employeeRows:employeeRows
    };
  }

  function getPostCancelLinkedHistory(pcsId){
    var pcs = readPostCancelSettlements().filter(function(v){ return String(v.pcsId) === String(pcsId); })[0];
    if (!pcs) throw new Error('사후취소정산을 찾지 못했습니다: ' + pcsId);
    var sale = readSales().filter(function(v){ return String(v.saleId) === String(pcs.saleId); })[0] || null;
    var cancellation = readCancellations().filter(function(v){ return String(v.saleId) === String(pcs.saleId); })[0] || null;
    var audits = getApprovalAuditRows('ALL', 'ALL').filter(function(v){ return String(v.refId) === String(pcsId) || String(v.targetId) === String(pcs.saleId); }).slice(0, 20);
    return { pcs:pcs, sale:sale, cancellation:cancellation, audits:audits };
  }

  function getEmployeeScopeSummary(vendorId){
    var rows = readEmployees().slice().reverse();
    if (vendorId && vendorId !== 'ALL') rows = rows.filter(function(v){ return String(v.vendorId) === String(vendorId); });
    var byRole = {};
    var byStatus = {};
    rows.forEach(function(v){ byRole[s(v.role) || '미지정'] = (byRole[s(v.role) || '미지정'] || 0) + 1; byStatus[s(v.status) || '미지정'] = (byStatus[s(v.status) || '미지정'] || 0) + 1; });
    var pendingRole = readEmployeeRoleRequests().filter(function(v){ return (!vendorId || vendorId === 'ALL' || String(v.vendorId) === String(vendorId)) && (s(v.status) === 'PENDING' || s(v.status) === 'REVIEW'); }).length;
    return { vendorId:vendorId || 'ALL', total:rows.length, byRole:byRole, byStatus:byStatus, pendingRole:pendingRole, rows:rows.slice(0, 20) };
  }

  function getDiagnosticsFocusRows(level, category){
    var rows = getDiagnosticsBundle().rows || [];
    if (level && level !== 'ALL') rows = rows.filter(function(v){ return String(v.level || '').toUpperCase() === String(level).toUpperCase(); });
    if (category) rows = rows.filter(function(v){ return String(v.menu || '').indexOf(String(category)) > -1 || String(v.fn || '').indexOf(String(category)) > -1 || String(v.message || '').indexOf(String(category)) > -1; });
    return {
      total: rows.length,
      errorCount: rows.filter(function(v){ return String(v.level || '').toUpperCase() === 'ERROR'; }).length,
      debugCount: rows.filter(function(v){ return String(v.level || '').toUpperCase() === 'DEBUG'; }).length,
      rows: rows.slice(0, 30)
    };
  }


  function getFieldQuickBoard(){
    var warn = getWarningSummary();
    var ops = getOperationalBoardSummary();
    var dash = getDashboardSummary();
    var asSum = getASStatusSummary();
    var recv = getReceivableSummary();
    return {
      buildNo: BUILD_NO,
      warning: warn,
      ops: ops,
      dashboard: dash,
      asSummary: asSum,
      receivable: recv,
      recentSales: recentSales().slice(0, 8),
      recentAs: recentAS().slice(0, 8)
    };
  }

  function getStaffQuickMenuData(){
    var boot = getErpBootstrap();
    return {
      salesCount: (boot.sales || []).length,
      customerCount: (boot.recentCustomers || []).length,
      asCount: (boot.asItems || []).length,
      installCount: (boot.installs || []).length,
      installPending: ((boot.installPendingRows || []).length),
      evidencePending: ((boot.evidenceRows || []).length)
    };
  }
  function getBuildInfo(){
    return { buildNo:BUILD_NO, buildTitle:BUILD_TITLE };
  }

  function runFullPreflightAudit(){
    var startedAt = ts();
    var checks = [];
    var warnings = [];
    var requiredSheets = ['Customers','Sales','ASRequests','EvidenceMailQueue','InstallCompletions','Cancellations','DiagnosticsLog','Employees','EmployeeRoleRequests','VendorControlPolicies','SensitiveAccessRequests','BackupHistory'];
    function pushCheck(name, ok, detail){ checks.push({name:name, ok:!!ok, detail:s(detail)}); }
    try {
      var db = getDbSpreadsheet();
      pushCheck('DB 연결', true, db.getName());
      var names = db.getSheets().map(function(sh){ return sh.getName(); });
      var missing = requiredSheets.filter(function(name){ return names.indexOf(name) < 0; });
      pushCheck('필수 시트 점검', missing.length === 0, missing.length ? ('누락: ' + missing.join(', ')) : '정상');
      if (missing.length) warnings.push('필수 시트 누락: ' + missing.join(', '));
    } catch (e) {
      pushCheck('DB 연결', false, e.message || e);
      warnings.push('DB 연결 실패');
    }
    try {
      var health = _getBaselineHealthInfoInternal();
      pushCheck('기준 상태 조회', true, '오류 ' + n(health.errorCount) + ' / 점검 ' + n(health.diagCount));
      if (n(health.errorCount) > 0) warnings.push('최근 오류로그 ' + n(health.errorCount) + '건');
    } catch (e) {
      pushCheck('기준 상태 조회', false, e.message || e);
    }
    try {
      var boot = getErpBootstrap();
      pushCheck('부트스트랩 로드', true, '판매 ' + ((boot.sales || []).length) + ' / 고객 ' + ((boot.recentCustomers || []).length));
    } catch (e) {
      pushCheck('부트스트랩 로드', false, e.message || e);
    }
    try {
      var ops = getOperationsSnapshot();
      pushCheck('운영 스냅샷', true, '권한요청 ' + ((ops.permissionRequests || []).length) + ' / 온보딩 ' + ((ops.onboardings || []).length));
    } catch (e) {
      pushCheck('운영 스냅샷', false, e.message || e);
    }
    try {
      ensureBackupHistorySheet_();
      pushCheck('백업센터', true, 'BackupHistory 준비 완료');
    } catch (e) {
      pushCheck('백업센터', false, e.message || e);
    }
    try {
      var cardRows = readTable('CardData');
      pushCheck('카드데이터 조회', true, '건수 ' + cardRows.length);
    } catch (e) {
      pushCheck('카드데이터 조회', false, e.message || e);
    }
    try {
      var roleRows = readTable('EmployeeRoleRequests');
      pushCheck('직원권한 요청조회', true, '건수 ' + roleRows.length);
    } catch (e) {
      pushCheck('직원권한 요청조회', false, e.message || e);
    }
    var failed = checks.filter(function(v){ return !v.ok; });
    if (failed.length) warnings.push('실패 점검 ' + failed.length + '건');
    addDiagnosticsLog({
      level: failed.length ? 'ERROR' : 'DEBUG',
      project:'ERP',
      menu:'전수점검',
      fn:'runFullPreflightAudit',
      errorTime:startedAt,
      message:(failed.length ? '전수점검 경고' : '전수점검 정상'),
      lastStep:'audit-complete',
      relatedId:'',
      rawLog:JSON.stringify({checks:checks,warnings:warnings})
    });
    return {
      ok: failed.length === 0,
      buildNo: BUILD_NO,
      buildTitle: BUILD_TITLE,
      checkedAt: startedAt,
      checkCount: checks.length,
      failedCount: failed.length,
      checks: checks,
      warnings: warnings
    };
  }
  function repairInstallLinks(){
    syncSystemConfig();
    var repairedCompletions = 0;
    var repairedAssignments = 0;
    var salesUpdated = 0;
    var errors = [];

    readTable('InstallCompletions').forEach(function(row){
      try {
        var installId = s(row.installId);
        var saleId = s(row.saleId);
        if (!installId || !saleId) return;
        var sale = findFirstByField_('Sales', 'saleId', saleId) || {};
        syncInstallMasterFromSale_(installId, sale, {
          installId:installId,
          saleId:saleId,
          eventId:s(sale.eventId),
          vendorId:s(row.vendorId) || s(sale.vendorId),
          customerId:s(row.customerId) || s(sale.customerId),
          memo:s(row.memo),
          statusReason:'기존 설치완료 증빙 기준 역동기화'
        }, 'COMPLETED', '기존 설치완료 증빙 기준 역동기화');
        updateRowById('Sales', 'saleId', saleId, {
          installStatus:'COMPLETED',
          installDate:s(row.completedAt) || ts(),
          installer:s(row.assignedEngineer) || s(sale.installer),
          updatedAt:ts(),
          updatedBy:'system'
        });
        ensureInstallAssignmentFromCompletion_({
          installId:installId,
          saleId:saleId,
          vendorId:s(row.vendorId) || s(sale.vendorId),
          assignedTeam:s(row.assignedTeam),
          assignedEngineer:s(row.assignedEngineer) || s(sale.installer),
          vehicleNo:s(row.vehicleNo),
          visitDate:s(row.completedAt) || ts(),
          visitTime:s(row.visitTime),
          completedAt:s(row.completedAt) || ts(),
          memo:s(row.memo),
          assignmentStatus:'COMPLETED'
        }, sale, findLastByField_('InstallAssignments', 'saleId', saleId));
        repairedCompletions += 1;
        salesUpdated += 1;
      } catch (e) {
        errors.push('completion:' + s(row.installId) + ':' + e.message);
      }
    });

    readTable('InstallAssignments').forEach(function(row){
      try {
        var installId = s(row.installId);
        var saleId = s(row.saleId);
        if (!installId || !saleId) return;
        var completion = findFirstByField_('InstallCompletions', 'installId', installId);
        if (completion) return;
        var sale = findFirstByField_('Sales', 'saleId', saleId) || {};
        syncInstallMasterFromSale_(installId, sale, {
          installId:installId,
          saleId:saleId,
          eventId:s(sale.eventId),
          vendorId:s(row.vendorId) || s(sale.vendorId),
          customerId:s(sale.customerId),
          memo:s(row.memo),
          statusReason:'기존 설치배정 기준 역동기화'
        }, s(row.status) || 'SCHEDULED', '기존 설치배정 기준 역동기화');
        updateRowById('Sales', 'saleId', saleId, {
          installStatus:s(row.status) || 'SCHEDULED',
          installDate:s(row.visitDate),
          installer:s(row.engineer),
          updatedAt:ts(),
          updatedBy:'system'
        });
        repairedAssignments += 1;
        salesUpdated += 1;
      } catch (e) {
        errors.push('assignment:' + s(row.installId) + ':' + e.message);
      }
    });

    try {
      appendObjectByHeader_('DiagnosticsLog', ['logId','createdAt','level','area','action','targetId','message','meta','actor','status','errorCode'], {
        logId:'LOG-' + new Date().getTime(), createdAt:ts(), level:errors.length ? 'WARNING' : 'INFO', area:'ERP_INSTALL', action:'REPAIR_INSTALL_LINKS', targetId:'INSTALL_SYNC', message:'설치 관련 시트 역동기화 실행', meta:'completions=' + repairedCompletions + ', assignments=' + repairedAssignments + ', sales=' + salesUpdated + ', errors=' + errors.length, actor:'system', status:errors.length ? 'PARTIAL' : 'DONE', errorCode:''
      });
    } catch (logErr) {}

    return { ok:errors.length === 0, repairedCompletions:repairedCompletions, repairedAssignments:repairedAssignments, salesUpdated:salesUpdated, errors:errors };
  }


  function runStabilityPatch(){
    setupErpSystem();
    ensureBackupHistorySheet_();
    var smoke = smokeTestErp();
    var health = getBaselineHealthInfo();
    addDiagnosticsLog({
      level:'DEBUG',
      project:'ERP',
      menu:'점검패치',
      fn:'runStabilityPatch',
      errorTime:ts(),
      message:'안정화 점검패치 실행',
      lastStep:'completed',
      relatedId:BUILD_NO,
      rawLog:JSON.stringify({buildNo:BUILD_NO, smoke:smoke, health:health})
    });
    return {
      ok:true,
      buildNo:BUILD_NO,
      smoke:smoke,
      health:health,
      message:'안정화 점검패치 완료'
    };
  }


  return {
    getEmployeeScopeSummary:getEmployeeScopeSummary,
    getDiagnosticsFocusRows:getDiagnosticsFocusRows,
    getEmployeeRoleRequestBoard:getEmployeeRoleRequestBoard,
    getDiagnosticsMenuSummaryBoard:getDiagnosticsMenuSummaryBoard,
    getFieldQuickBoard:getFieldQuickBoard,
    getStaffQuickMenuData:getStaffQuickMenuData,
    getBuildInfo:getBuildInfo,
    syncSystemConfig:syncSystemConfig,
    setupErpSystem:setupErpSystem,
    getErpBootstrap:getErpBootstrap,
    getOperationsSnapshot:getOperationsSnapshot,
    getAdminWorkbench:getAdminWorkbench,
    saveCustomer:saveCustomer,
    findRegularCustomerForQuick:findRegularCustomerForQuick,
    updateCustomerById:updateCustomerById,
    createQrSignDocumentForCustomer:createQrSignDocumentForCustomer,
    bulkUploadRegularMembers:bulkUploadRegularMembers,
    saveSale:saveSale,
    saveAsRequest:saveAsRequest,
    updateAsRequestStatus:updateAsRequestStatus,
    searchCustomers:searchCustomers,
    getRecentCustomers:getRecentCustomers,
    getCustomerDetail:getCustomerDetail,
    getCustomerTimeline:getCustomerTimeline,
    getSaleDetail:getSaleDetail,
    getCardDataList:getCardDataList,
    assignInstallTeam:assignInstallTeam,
    addSettlementAdjustment:addSettlementAdjustment,
    getClaimSummary:getClaimSummary,
    getSettlementDetailSummary:getSettlementDetailSummary,
    getDiagnosticsCategorySummary:getDiagnosticsCategorySummary,
    queueEvidenceMail:queueEvidenceMail,
    completeInstallation:completeInstallation,
    repairInstallLinks:repairInstallLinks,
    requestInstallReopen:requestInstallReopen,
    approveInstallReopen:approveInstallReopen,
    requestInstallCancel:requestInstallCancel,
    approveInstallCancel:approveInstallCancel,
    getSettlementTargetRows:getSettlementTargetRows,
    requestCancellation:requestCancellation,
    approveBenefitPayout:approveBenefitPayout,
    markGiftDistributed:markGiftDistributed,
    markEvidenceMailSent:markEvidenceMailSent,
    getSalesByStatus:getSalesByStatus,
    getSalesByDateRange:getSalesByDateRange,
    getCustomersByMemberType:getCustomersByMemberType,
    getCustomersByEventType:getCustomersByEventType,
    getSalesByPaymentMethod:getSalesByPaymentMethod,
    getSalesByVendorId:getSalesByVendorId,
    getSalesByCustomerId:getSalesByCustomerId,
    getEvidenceByStatus:getEvidenceByStatus,
    getAsByStatus:getAsByStatus,
    getVendorSettlementSummary:getVendorSettlementSummary,
    getCancellationSummary:getCancellationSummary,
    getInstallStatusSummary:getInstallStatusSummary,
    getDashboardSummary:getDashboardSummary,
    markCancellationRefunded:markCancellationRefunded,
    markInstallRevisit:markInstallRevisit,
    requeueEvidence:requeueEvidence,
    getDiagnosticsBundle:getDiagnosticsBundle,
    addDiagnosticsLog:addDiagnosticsLog,
    approvePermissionRequestFromErp:approvePermissionRequestFromErp,
    rejectPermissionRequestFromErp:rejectPermissionRequestFromErp,
    approveOnboardingFromErp:approveOnboardingFromErp,
    approveCancellationFromErp:approveCancellationFromErp,
    markSettlementPaidFromErp:markSettlementPaidFromErp,
    adjustSettlementFromErp:adjustSettlementFromErp,
    addDepositLedgerFromErp:addDepositLedgerFromErp,
    createMonthlyClosingFromErp:createMonthlyClosingFromErp,
    smokeTestErp:smokeTestErp,
    getCustomerPurchaseSummary:getCustomerPurchaseSummary,
    getVendorPerformanceSummary:getVendorPerformanceSummary,
    getEventPerformanceSummary:getEventPerformanceSummary,
    getWarningSummary:getWarningSummary,
    getCustomerStatusSummary:getCustomerStatusSummary,
    getDuplicateCustomerWarnings:getDuplicateCustomerWarnings,
    getASStatusSummary:getASStatusSummary,
    getDocumentSummary:getDocumentSummary,
    getReceivableSummary:getReceivableSummary,
    getLeadStatusSummary:getLeadStatusSummary,
    getDocumentFailureSummary:getDocumentFailureSummary,
    getOperationalBoardSummary:getOperationalBoardSummary,
    saveCardDataEntry:saveCardDataEntry,
    requestPermissionChange:requestPermissionChange,
    getSalesFunnelSummary:getSalesFunnelSummary,
    getDuplicateCustomerCandidates:getDuplicateCustomerCandidates,
    getOverdueInstallations:getOverdueInstallations,
    getReceivableDetailRows:getReceivableDetailRows,
    mergeCustomerRecords:mergeCustomerRecords,
    getEngineerScheduleBoard:getEngineerScheduleBoard,
    requestClaimApproval:requestClaimApproval,
    approveClaimApproval:approveClaimApproval,
    rejectClaimApproval:rejectClaimApproval,
    getClaimApprovalRows:getClaimApprovalRows,
    getMonthlyClosingDetailRows:getMonthlyClosingDetailRows,
    getInstallDelayBoard:getInstallDelayBoard,
    getRolePolicySnapshot:getRolePolicySnapshot,
    saveEmployee:saveEmployee,
    requestEmployeeRoleChange:requestEmployeeRoleChange,
    approveEmployeeRoleChange:approveEmployeeRoleChange,
    rejectEmployeeRoleChange:rejectEmployeeRoleChange,
    getEmployeeRows:getEmployeeRows,
    getBenefitControlSummary:getBenefitControlSummary,
    getFundControlSummary:getFundControlSummary,
    getDepositControlSummary:getDepositControlSummary,
    calculatePostCancelSettlement:calculatePostCancelSettlement,
    requestPostCancelSettlement:requestPostCancelSettlement,
    approvePostCancelSettlement:approvePostCancelSettlement,
    getPostCancelSettlementRows:getPostCancelSettlementRows,
    getEmployeeRoleRequestRows:getEmployeeRoleRequestRows,
    approveFundExecution:approveFundExecution,
    getIntegratedApprovalSummary:getIntegratedApprovalSummary,
    getApprovalAuditRows:getApprovalAuditRows,
    getDepositLedgerRows:getDepositLedgerRows,
    getFundExecutionRows:getFundExecutionRows,
    getPriorityActionRows:getPriorityActionRows,
    getApprovalHistorySummary:getApprovalHistorySummary,
    requestSettlementApprovalStep:requestSettlementApprovalStep,
    actSettlementApprovalStep:actSettlementApprovalStep,
    getSettlementApprovalRows:getSettlementApprovalRows,
    getSettlementApprovalSummary:getSettlementApprovalSummary,
    saveDepositAdjustment:saveDepositAdjustment,
    saveFundExecutionRequest:saveFundExecutionRequest,
    getDepositAdjustmentSummary:getDepositAdjustmentSummary,
    runDiagnosticsSuite:runDiagnosticsSuite,
    saveVendorControlPolicy:saveVendorControlPolicy,
    getVendorControlBoard:getVendorControlBoard,
    getVendorSensitiveSummary:getVendorSensitiveSummary,
    reviewEmployeeRoleChange:reviewEmployeeRoleChange,
    requestSensitiveMenuAccess:requestSensitiveMenuAccess,
    actSensitiveMenuAccess:actSensitiveMenuAccess,
    getSensitiveAccessRows:getSensitiveAccessRows,
    getBaselineHealthInfo:_getBaselineHealthInfoInternal,
    runStabilityPatch:runStabilityPatch,
    runFullPreflightAudit:runFullPreflightAudit
  };
})();



function _erpGlobalS(v){ return String(v === undefined || v === null ? '' : v).trim(); }
function _erpGlobalReadTable(name){
  var p = PropertiesService.getScriptProperties();
  var id = p.getProperty('DB_SPREADSHEET_ID') || p.getProperty('DB_MASTER_ID') || p.getProperty('SPREADSHEET_ID');
  if (!id) throw new Error('DB 스프레드시트 ID가 없습니다.');
  var sh = SpreadsheetApp.openById(id).getSheetByName(name);
  if (!sh) return [];
  var vals = sh.getDataRange().getDisplayValues();
  if (vals.length < 2) return [];
  var header = vals[0];
  return vals.slice(1).filter(function(r){ return r.join('').trim() !== ''; }).map(function(r){
    var obj = {};
    for (var i=0;i<header.length;i++) obj[header[i]] = r[i];
    return obj;
  });
}

function doGet(e){
  var eventVendorPage = tryHandleEventVendorRoute_(e);
  if (eventVendorPage) return eventVendorPage;
  return HtmlService.createHtmlOutputFromFile('Index').setTitle('FEELHAUS ERP');
}
function getEmployeeScopeSummary(vendorId){ return FH.getEmployeeScopeSummary(vendorId); }
function getDiagnosticsFocusRows(level, category){ return FH.getDiagnosticsFocusRows(level, category); }
function getFieldQuickBoard(){ return FH.getFieldQuickBoard(); }
function getStaffQuickMenuData(){ return FH.getStaffQuickMenuData(); }
function getBuildInfo(){ return FH.getBuildInfo(); }
function setupErpSystem(){ return FH.setupErpSystem(); }
function syncSystemConfig(){ return FH.syncSystemConfig(); }
function getErpBootstrap(){ return FH.getErpBootstrap(); }
function getOperationsSnapshot(){ return FH.getOperationsSnapshot(); }
function getAdminWorkbench(){ return FH.getAdminWorkbench(); }
function saveCustomer(payload){ return FH.saveCustomer(payload); }
function findRegularCustomerForQuick(payload){ return FH.findRegularCustomerForQuick(payload); }
function updateCustomerById(payload){ return FH.updateCustomerById(payload); }
function createQrSignDocumentForCustomer(payload){ return FH.createQrSignDocumentForCustomer(payload); }
function bulkUploadRegularMembers(payload){ return FH.bulkUploadRegularMembers(payload); }
function saveSale(payload){ return FH.saveSale(payload); }
function saveAsRequest(payload){ return FH.saveAsRequest(payload); }
function updateAsRequestStatus(payload){ return FH.updateAsRequestStatus(payload); }
function searchCustomers(query){ return FH.searchCustomers(query); }
function getRecentCustomers(limit){ return FH.getRecentCustomers(limit); }
function getCustomerDetail(customerId){ return FH.getCustomerDetail(customerId); }
function getCustomerTimeline(customerId){ return FH.getCustomerTimeline(customerId); }
function getSaleDetail(saleId){ return FH.getSaleDetail(saleId); }
function getCardDataList(query){ return FH.getCardDataList(query); }
function assignInstallTeam(payload){ return FH.assignInstallTeam(payload); }
function addSettlementAdjustment(payload){ return FH.addSettlementAdjustment(payload); }
function getClaimSummary(){ return FH.getClaimSummary(); }
function getSettlementDetailSummary(vendorId){ return FH.getSettlementDetailSummary(vendorId); }
function getDiagnosticsCategorySummary(){ return FH.getDiagnosticsCategorySummary(); }
function queueEvidenceMail(payload){ return FH.queueEvidenceMail(payload); }
function completeInstallation(payload){ return FH.completeInstallation(payload); }
function repairInstallLinks(){ return FH.repairInstallLinks(); }
function requestInstallReopen(payload){ return FH.requestInstallReopen(payload); }
function approveInstallReopen(payload){ return FH.approveInstallReopen(payload); }
function requestInstallCancel(payload){ return FH.requestInstallCancel(payload); }
function approveInstallCancel(payload){ return FH.approveInstallCancel(payload); }
function getSettlementTargetRows(status, vendorId){ return FH.getSettlementTargetRows(status, vendorId); }
function requestCancellation(payload){ return FH.requestCancellation(payload); }
function approveBenefitPayout(payoutId){ return FH.approveBenefitPayout(payoutId); }
function markGiftDistributed(payoutId){ return FH.markGiftDistributed(payoutId); }
function markEvidenceMailSent(queueId){ return FH.markEvidenceMailSent(queueId); }
function getSalesByStatus(status){ return FH.getSalesByStatus(status); }
function getSalesByDateRange(dateFrom, dateTo){ return FH.getSalesByDateRange(dateFrom, dateTo); }
function getCustomersByMemberType(memberType){ return FH.getCustomersByMemberType(memberType); }
function getCustomersByEventType(eventType){ return FH.getCustomersByEventType(eventType); }
function getSalesByPaymentMethod(paymentMethod){ return FH.getSalesByPaymentMethod(paymentMethod); }
function getSalesByVendorId(vendorId){ return FH.getSalesByVendorId(vendorId); }
function getSalesByCustomerId(customerId){ return FH.getSalesByCustomerId(customerId); }
function getEvidenceByStatus(status){ return FH.getEvidenceByStatus(status); }
function getAsByStatus(status){ return FH.getAsByStatus(status); }
function getVendorSettlementSummary(vendorId){ return FH.getVendorSettlementSummary(vendorId); }
function getCancellationSummary(){ return FH.getCancellationSummary(); }
function getInstallStatusSummary(){ return FH.getInstallStatusSummary(); }
function getDashboardSummary(){ return FH.getDashboardSummary(); }
function markCancellationRefunded(cancellationId){ return FH.markCancellationRefunded(cancellationId); }
function markInstallRevisit(installId){ return FH.markInstallRevisit(installId); }
function requeueEvidence(queueId){ return FH.requeueEvidence(queueId); }
function getDiagnosticsBundle(){ return FH.getDiagnosticsBundle(); }
function addDiagnosticsLog(payload){ return FH.addDiagnosticsLog(payload); }
function approvePermissionRequestFromErp(requestId){ return FH.approvePermissionRequestFromErp(requestId); }
function rejectPermissionRequestFromErp(requestId){ return FH.rejectPermissionRequestFromErp(requestId); }
function approveOnboardingFromErp(onboardingId){ return FH.approveOnboardingFromErp(onboardingId); }
function approveCancellationFromErp(cancellationId){ return FH.approveCancellationFromErp(cancellationId); }
function markSettlementPaidFromErp(settlementId){ return FH.markSettlementPaidFromErp(settlementId); }
function adjustSettlementFromErp(payload){ return FH.adjustSettlementFromErp(payload); }
function addDepositLedgerFromErp(payload){ return FH.addDepositLedgerFromErp(payload); }
function createMonthlyClosingFromErp(payload){ return FH.createMonthlyClosingFromErp(payload); }
function smokeTestErp(){ return FH.smokeTestErp(); }
function runStabilityPatch(){ return FH.runStabilityPatch(); }
function runFullPreflightAudit(){ return FH.runFullPreflightAudit(); }
function getCustomerPurchaseSummary(customerId){ return FH.getCustomerPurchaseSummary(customerId); }
function getVendorPerformanceSummary(){ return FH.getVendorPerformanceSummary(); }
function getEventPerformanceSummary(){ return FH.getEventPerformanceSummary(); }
function getWarningSummary(){ return FH.getWarningSummary(); }
function getCustomerStatusSummary(){ return FH.getCustomerStatusSummary(); }
function getDuplicateCustomerWarnings(){ return FH.getDuplicateCustomerWarnings(); }
function getASStatusSummary(){ return FH.getASStatusSummary(); }
function getDocumentSummary(){ return FH.getDocumentSummary(); }
function getReceivableSummary(){ return FH.getReceivableSummary(); }
function getLeadStatusSummary(){ return FH.getLeadStatusSummary(); }
function getDocumentFailureSummary(){ return FH.getDocumentFailureSummary(); }
function getOperationalBoardSummary(){ return FH.getOperationalBoardSummary(); }


function saveCardDataEntry(payload){ return FH.saveCardDataEntry(payload); }
function requestPermissionChange(payload){ return FH.requestPermissionChange(payload); }
function getSalesFunnelSummary(){ return FH.getSalesFunnelSummary(); }
function getDuplicateCustomerCandidates(){ return FH.getDuplicateCustomerCandidates(); }
function getOverdueInstallations(){ return FH.getOverdueInstallations(); }
function getReceivableDetailRows(){ return FH.getReceivableDetailRows(); }
function mergeCustomerRecords(payload){ return FH.mergeCustomerRecords(payload); }
function getEngineerScheduleBoard(dateFrom, dateTo){ return FH.getEngineerScheduleBoard(dateFrom, dateTo); }
function requestClaimApproval(payload){ return FH.requestClaimApproval(payload); }
function approveClaimApproval(approvalId){ return FH.approveClaimApproval(approvalId); }
function rejectClaimApproval(approvalId){ return FH.rejectClaimApproval(approvalId); }
function getClaimApprovalRows(status){ return FH.getClaimApprovalRows(status); }
function getMonthlyClosingDetailRows(closingMonth){ return FH.getMonthlyClosingDetailRows(closingMonth); }
function getInstallDelayBoard(){ return FH.getInstallDelayBoard(); }

function getRolePolicySnapshot(vendorId){ return FH.getRolePolicySnapshot(vendorId); }
function saveEmployee(payload){ return FH.saveEmployee(payload); }
function requestEmployeeRoleChange(payload){ return FH.requestEmployeeRoleChange(payload); }
function approveEmployeeRoleChange(requestId, actor){ return FH.approveEmployeeRoleChange(requestId, actor); }
function rejectEmployeeRoleChange(requestId, actor){ return FH.rejectEmployeeRoleChange(requestId, actor); }
function getEmployeeRows(vendorId){ return FH.getEmployeeRows(vendorId); }
function getBenefitControlSummary(){ return FH.getBenefitControlSummary(); }
function getFundControlSummary(){ return FH.getFundControlSummary(); }
function getDepositControlSummary(){ return FH.getDepositControlSummary(); }
function calculatePostCancelSettlement(payload){ return FH.calculatePostCancelSettlement(payload); }
function requestPostCancelSettlement(payload){ return FH.requestPostCancelSettlement(payload); }
function approvePostCancelSettlement(pcsId, actor){ return FH.approvePostCancelSettlement(pcsId, actor); }
function getPostCancelSettlementRows(status){ return FH.getPostCancelSettlementRows(status); }
function getEmployeeRoleRequestRows(status, vendorId){ return FH.getEmployeeRoleRequestRows(status, vendorId); }
function approveFundExecution(executionId, approvedAmount){ return FH.approveFundExecution(executionId, approvedAmount); }
function getIntegratedApprovalSummary(){ return FH.getIntegratedApprovalSummary(); }
function runDiagnosticsSuite(){ try { if (typeof fhErpB05LMigrateEventVendorHeaders === 'function') fhErpB05LMigrateEventVendorHeaders({dryRun:false}); } catch(e) { Logger.log('[B05L header migration before diagnostics skipped] ' + e); } return FH.runDiagnosticsSuite(); }
function saveVendorControlPolicy(payload){ return FH.saveVendorControlPolicy(payload); }
function getVendorControlBoard(vendorId){ return FH.getVendorControlBoard(vendorId); }
function getVendorSensitiveSummary(vendorId){ return FH.getVendorSensitiveSummary(vendorId); }
function reviewEmployeeRoleChange(requestId, actor, note){ return FH.reviewEmployeeRoleChange(requestId, actor, note); }
function requestSensitiveMenuAccess(payload){ return FH.requestSensitiveMenuAccess(payload); }
function actSensitiveMenuAccess(accessId, action, actor, note){ return FH.actSensitiveMenuAccess(accessId, action, actor, note); }
function getSensitiveAccessRows(status, vendorId){ return FH.getSensitiveAccessRows(status, vendorId); }

function getApprovalAuditRows(auditType, status){ return FH.getApprovalAuditRows(auditType, status); }
function getDepositLedgerRows(vendorId){ return FH.getDepositLedgerRows(vendorId); }
function getFundExecutionRows(status){ return FH.getFundExecutionRows(status); }
function getPriorityActionRows(){ return FH.getPriorityActionRows(); }
function getApprovalHistorySummary(){ return FH.getApprovalHistorySummary(); }

function requestSettlementApprovalStep(payload){ return FH.requestSettlementApprovalStep(payload); }
function actSettlementApprovalStep(stepId, action, actor, note, approvedAmount){ return FH.actSettlementApprovalStep(stepId, action, actor, note, approvedAmount); }
function getSettlementApprovalRows(status, vendorId){ return FH.getSettlementApprovalRows(status, vendorId); }
function getSettlementApprovalSummary(){ return FH.getSettlementApprovalSummary(); }
function saveDepositAdjustment(payload){ return FH.saveDepositAdjustment(payload); }
function saveFundExecutionRequest(payload){ return FH.saveFundExecutionRequest(payload); }
function getDepositAdjustmentSummary(vendorId){ return FH.getDepositAdjustmentSummary(vendorId); }



function ensureBackupHistorySheet_(){
  var ssId = PropertiesService.getScriptProperties().getProperty('DB_SPREADSHEET_ID') || PropertiesService.getScriptProperties().getProperty('DB_MASTER_ID') || PropertiesService.getScriptProperties().getProperty('SPREADSHEET_ID');
  if (!ssId) throw new Error('DB 스프레드시트 ID가 없습니다.');
  var ss = SpreadsheetApp.openById(ssId);
  var sh = ss.getSheetByName('BackupHistory');
  if (!sh) sh = ss.insertSheet('BackupHistory');
  var headers = ['backupId','backupType','status','summaryJson','summaryText','actor','createdAt'];
  sh.getRange(1,1,1,headers.length).setValues([headers]);
  return sh;
}
function createEmergencyBackup(actor){
  actor = String(actor || 'ERP');
  var sh = ensureBackupHistorySheet_();
  var dbId = PropertiesService.getScriptProperties().getProperty('DB_SPREADSHEET_ID') || PropertiesService.getScriptProperties().getProperty('DB_MASTER_ID') || PropertiesService.getScriptProperties().getProperty('SPREADSHEET_ID');
  var ss = SpreadsheetApp.openById(dbId);
  var sheetNames = ['Customers','Events','Vendors','Sales','ASRequests','PermissionRequests','Onboardings','Cancellations','BenefitPayouts','FundExecutions','DepositLedger','MonthlyClosings','Employees','RolePolicies','EmployeeRoleRequests','ApprovalAudit','EvidenceMailQueue','InstallCompletions','CardData','InstallAssignments','SettlementAdjustments','SettlementTargets','DiagnosticsLog'];
  var summary = {};
  sheetNames.forEach(function(name){
    var ws = ss.getSheetByName(name);
    summary[name] = ws ? Math.max(ws.getLastRow() - 1, 0) : 0;
  });
  var backupId = 'BKP-' + Utilities.formatDate(new Date(), Session.getScriptTimeZone() || 'Asia/Seoul', 'yyyyMMdd-HHmmss');
  var summaryText = Object.keys(summary).slice(0,8).map(function(k){ return k + ':' + summary[k]; }).join(' / ');
  sh.appendRow([backupId,'EMERGENCY','DONE',JSON.stringify(summary),summaryText,actor,Utilities.formatDate(new Date(), Session.getScriptTimeZone() || 'Asia/Seoul', 'yyyy-MM-dd HH:mm:ss')]);
  return {backupId:backupId, backupType:'EMERGENCY', status:'DONE', summary:summary, summaryText:summaryText};
}
function getBackupHistoryRowsWithLimit(limit){
  limit = Number(limit || 20);
  var sh = ensureBackupHistorySheet_();
  var values = sh.getDataRange().getDisplayValues();
  if (values.length < 2) return [];
  var header = values[0];
  return values.slice(1).filter(function(r){ return r.join('').trim() !== ''; }).map(function(r){
    var obj = {};
    for (var i=0;i<header.length;i++) obj[header[i]] = r[i];
    return obj;
  }).reverse().slice(0, limit);
}
function prepareRestoreSnapshot(){
  var rows = getBackupHistoryRowsWithLimit(1);
  var latest = rows.length ? rows[0] : {};
  return {
    latestBackupId:String(latest.backupId || ''),
    latestCreatedAt:String(latest.createdAt || ''),
    guide:'기존 프로젝트 백업 → 최신 백업ID 확인 → Code/Index/appsscript 교체 → 설정동기화 → 스모크테스트'
  };
}

function _getBaselineHealthInfoInternal(){
  var backupRows = getBackupHistoryRowsWithLimit(5);
  var diagRows = [];
  try {
    diagRows = FH.getDiagnosticsBundle ? FH.getDiagnosticsBundle().rows || [] : [];
  } catch (e) {
    diagRows = [];
  }
  var latestBackup = backupRows.length ? backupRows[0] : {};
  var errorCount = diagRows.filter(function(r){ return String((r.level||'')).toUpperCase() === 'ERROR'; }).length;
  var debugCount = diagRows.filter(function(r){ return String((r.level||'')).toUpperCase() === 'DEBUG'; }).length;
  return {
    buildNo:'v51',
    buildTitle:'ERP 통합빌드 v51 안정화전수점검재발방지고정 통합본',
    baseline:'v46_check',
    latestBackupId:String(latestBackup.backupId || ''),
    latestBackupAt:String(latestBackup.createdAt || ''),
    backupCount:Number(backupRows.length || 0),
    diagCount:Number(diagRows.length || 0),
    errorCount:Number(errorCount || 0),
    debugCount:Number(debugCount || 0),
    statusText:(errorCount > 0 ? '오류로그 확인 필요' : '점검고정본 기준 정상 유지')
  };
}


function getBaselineHealthInfo(){ return _getBaselineHealthInfoInternal(); }



function _erpOpenDbForBackup(){
  var p = PropertiesService.getScriptProperties();
  var id = p.getProperty('DB_SPREADSHEET_ID') || p.getProperty('DB_MASTER_ID') || p.getProperty('SPREADSHEET_ID');
  if (id) return SpreadsheetApp.openById(id);
  var active = SpreadsheetApp.getActiveSpreadsheet();
  if (active) return active;
  throw new Error('DB 스프레드시트 ID를 찾지 못했습니다.');
}
function _erpEnsureBackupHistorySheet(){
  var ss = _erpOpenDbForBackup();
  var sh = ss.getSheetByName('BackupHistory');
  if (!sh){
    sh = ss.insertSheet('BackupHistory');
    sh.appendRow(['backupId','createdAt','salesCount','customerCount','installCount','asCount','settlementCount','evidenceCount','note']);
  }
  return sh;
}
function runEmergencyBackup(){
  var backupId = 'BKP-' + Utilities.formatDate(new Date(), Session.getScriptTimeZone() || 'Asia/Seoul', 'yyyyMMdd-HHmmss');
  var sales = typeof getSalesByStatus === 'function' ? getSalesByStatus('ALL') : [];
  var customers = typeof getRecentCustomers === 'function' ? getRecentCustomers(9999) : [];
  var bootstrap = typeof getErpBootstrap === 'function' ? getErpBootstrap() : {};
  var installs = (bootstrap && bootstrap.installs) || [];
  var asItems = (bootstrap && bootstrap.asItems) || [];
  var evidence = (bootstrap && bootstrap.evidenceRows) || [];
  var sh = _erpEnsureBackupHistorySheet();
  sh.appendRow([backupId, Utilities.formatDate(new Date(), Session.getScriptTimeZone() || 'Asia/Seoul', 'yyyy-MM-dd HH:mm:ss'), sales.length, customers.length, installs.length, asItems.length, 0, evidence.length, '긴급백업']);
  return { ok:true, backupId:backupId };
}
function getBackupHistoryRows(){
  var sh = _erpEnsureBackupHistorySheet();
  var values = sh.getDataRange().getDisplayValues();
  if (values.length < 2) return [];
  var header = values[0];
  return values.slice(1).reverse().slice(0, 20).map(function(r){
    var o = {};
    header.forEach(function(h, i){ o[h] = r[i]; });
    return o;
  });
}
function getRestorePreparationGuide(){
  return {
    summary:'최근 백업 이력 확인 후 현재 프로젝트를 별도 복제한 다음 필요한 시트 상태를 비교하면서 복구를 준비합니다.',
    steps:[
      '1. 현재 Apps Script 프로젝트를 복제 또는 백업합니다.',
      '2. BackupHistory에서 최근 정상 시점을 확인합니다.',
      '3. DB_MASTER 주요 시트의 행수와 최근 변경건을 비교합니다.',
      '4. 필요 시 최신 배포본을 유지한 채 데이터만 복구합니다.',
      '5. 복구 후 syncSystemConfig(), setupErpSystem(), smokeTestErp()를 다시 실행합니다.'
    ]
  };
}
function getBuildHealthSnapshot(){
  var backups = getBackupHistoryRows();
  var diag = typeof getDiagnosticsBundle === 'function' ? getDiagnosticsBundle() : { rows: [] };
  var rows = (diag && diag.rows) || [];
  return {
    baselineBuild:'v46_check',
    currentBuild:'v48',
    backupCount:backups.length,
    lastBackupAt:backups.length ? (backups[0].createdAt || '-') : '-',
    diagCount:rows.length,
    errorCount:rows.filter(function(v){ return String(v.level || '').toUpperCase() === 'ERROR'; }).length,
    lastDiagAt:rows.length ? (rows[0].errorTime || rows[0].createdAt || '-') : '-'
  };
}



function getEmployeeRoleRequestBoard(vendorId, status){
  var rows = _erpGlobalReadTable('EmployeeRoleRequests');
  vendorId = _erpGlobalS(vendorId || 'ALL');
  status = _erpGlobalS(status || 'ALL');
  if (vendorId && vendorId !== 'ALL') rows = rows.filter(function(v){ return _erpGlobalS(v.vendorId) === vendorId; });
  if (status && status !== 'ALL') rows = rows.filter(function(v){ return s(v.status) === status; });
  var byStatus = {};
  var byRole = {};
  rows.forEach(function(v){
    var st = _erpGlobalS(v.status || 'PENDING') || 'PENDING';
    var role = _erpGlobalS(v.requestRole || v.role || '미지정') || '미지정';
    byStatus[st] = (byStatus[st] || 0) + 1;
    byRole[role] = (byRole[role] || 0) + 1;
  });
  rows = rows.slice(-30).reverse().map(function(v){
    return {
      requestId: _erpGlobalS(v.requestId),
      employeeId: _erpGlobalS(v.employeeId),
      employeeName: _erpGlobalS(v.employeeName || v.name),
      requestRole: _erpGlobalS(v.requestRole || v.role),
      status: _erpGlobalS(v.status || 'PENDING'),
      requestedAt: _erpGlobalS(v.requestedAt || v.createdAt || v.updatedAt),
      vendorId: _erpGlobalS(v.vendorId)
    };
  });
  return { total: rows.length, byStatus: byStatus, byRole: byRole, rows: rows };
}
function getDiagnosticsMenuSummaryBoard(){
  var rows = _erpGlobalReadTable('DiagnosticsLog').slice(-200).reverse();
  var map = {};
  rows.forEach(function(v){
    var key = _erpGlobalS(v.menu || '미분류');
    if (!map[key]) map[key] = { menu:key, total:0, errorCount:0, debugCount:0, lastMessage:'', lastTime:'' };
    map[key].total += 1;
    var level = _erpGlobalS(v.level).toUpperCase();
    if (level === 'ERROR') map[key].errorCount += 1;
    if (level === 'DEBUG') map[key].debugCount += 1;
    if (!map[key].lastMessage) map[key].lastMessage = _erpGlobalS(v.message);
    if (!map[key].lastTime) map[key].lastTime = _erpGlobalS(v.errorTime);
  });
  var out = Object.keys(map).map(function(k){ return map[k]; }).sort(function(a,b){ return (b.errorCount - a.errorCount) || (b.total - a.total); }).slice(0,20);
  return { totalMenus: out.length, rows: out };
}



/**
 * FEELHAUS ERP - Event/Vendor Core Patch
 * 신규 본체 기능만 추가하는 패치 파일
 * 기존 함수/기능 삭제 없이 병합용으로 사용
 */

var ERP_EV_CORE_VERSION = 'EV1d';

function include(filename) {
  return HtmlService.createHtmlOutputFromFile(filename).getContent();
}

function openEventVendorCore() {
  return HtmlService.createHtmlOutputFromFile('EventVendor')
    .setTitle('행사/업체 관리')
    .setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL);
}


function openEventVendorCoreSidebar() {
  checkEventVendorAccess_();
  ensureEventVendorCoreSheets_();
  var html = HtmlService.createHtmlOutputFromFile('EventVendor')
    .setTitle('행사/업체 관리')
    .setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL);
  SpreadsheetApp.getUi().showSidebar(html);
}

function openEventVendorCoreDialog() {
  checkEventVendorAccess_();
  ensureEventVendorCoreSheets_();
  var html = HtmlService.createHtmlOutputFromFile('EventVendor')
    .setWidth(1400)
    .setHeight(920)
    .setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL);
  SpreadsheetApp.getUi().showModalDialog(html, '행사/업체 관리');
}

function addEventVendorCoreMenu_() {
  SpreadsheetApp.getUi()
    .createMenu('ERP 확장')
    .addItem('행사/업체 관리', 'openEventVendorCoreSidebar')
    .addSeparator()
    .addItem('행사/업체 관리(팝업)', 'openEventVendorCoreDialog')
    .addToUi();
}


function onOpen(e) {
  try {
    if (typeof addEventVendorCoreMenu_ === 'function') {
      addEventVendorCoreMenu_();
    }
  } catch (err) {
    Logger.log('onOpen menu error: ' + err);
  }
}

function onOpenEventVendorCoreMenu() {
  addEventVendorCoreMenu_();
}

function getEventVendorEntryInfo() {
  var cfg = getEventVendorConfig_();
  return {
    menuFunction: 'openEventVendorCoreSidebar',
    dialogFunction: 'openEventVendorCoreDialog',
    configSource: cfg.CONFIG_SOURCE,
    spreadsheetId: cfg.SPREADSHEET_ID,
    eventSheetName: cfg.EVENT_SHEET_NAME,
    vendorSheetName: cfg.VENDOR_SHEET_NAME,
    linkSheetName: cfg.LINK_SHEET_NAME,
    logSheetName: cfg.LOG_SHEET_NAME
  };
}

function getEventVendorBootstrapData() {
  checkEventVendorAccess_();
  ensureEventVendorCoreSheets_();

  return {
    version: ERP_EV_CORE_VERSION,
    config: getEventVendorConfig_(),
    events: listEvents_(),
    vendors: listVendors_(),
    links: listEventVendorLinks_(),
    summary: getEventVendorSummary_()
  };
}

function saveEventCore(payload) {
  checkEventVendorAccess_();
  ensureEventVendorCoreSheets_();
  validateRequired_(payload, ['eventName']);

  var ss = getEventVendorSpreadsheet_();
  var sheet = ss.getSheetByName(getEventVendorConfig_().EVENT_SHEET_NAME);
  var now = new Date();
  var user = getCurrentUserEmail_();
  var eventId = normalizeId_(payload.eventId) || makeId_('EVT');
  var rowIdx = findRowByValue_(sheet, 1, eventId);
  var row = [
    eventId,
    safeString_(payload.eventName),
    safeString_(payload.eventType),
    safeString_(payload.startDate),
    safeString_(payload.endDate),
    safeString_(payload.location),
    safeString_(payload.manager),
    safeString_(payload.status || '준비중'),
    safeString_(payload.memo),
    Utilities.formatDate(now, Session.getScriptTimeZone(), 'yyyy-MM-dd HH:mm:ss'),
    user
  ];

  if (rowIdx > 0) {
    sheet.getRange(rowIdx, 1, 1, row.length).setValues([row]);
    writeEventVendorLog_('EVENT_UPDATE', eventId, payload.eventName);
  } else {
    sheet.appendRow(row);
    writeEventVendorLog_('EVENT_CREATE', eventId, payload.eventName);
  }

  return getEventVendorBootstrapData();
}

function saveVendorCore(payload) {
  checkEventVendorAccess_();
  ensureEventVendorCoreSheets_();
  validateRequired_(payload, ['vendorName']);

  var ss = getEventVendorSpreadsheet_();
  var sheet = ss.getSheetByName(getEventVendorConfig_().VENDOR_SHEET_NAME);
  var now = new Date();
  var user = getCurrentUserEmail_();
  var vendorId = normalizeId_(payload.vendorId) || makeId_('VND');
  var rowIdx = findRowByValue_(sheet, 1, vendorId);
  var row = [
    vendorId,
    safeString_(payload.vendorName),
    safeString_(payload.ownerName),
    safeString_(payload.phone),
    safeString_(payload.region),
    safeString_(payload.status || '운영대기'),
    safeString_(payload.manager),
    safeString_(payload.memo),
    Utilities.formatDate(now, Session.getScriptTimeZone(), 'yyyy-MM-dd HH:mm:ss'),
    user
  ];

  if (rowIdx > 0) {
    sheet.getRange(rowIdx, 1, 1, row.length).setValues([row]);
    writeEventVendorLog_('VENDOR_UPDATE', vendorId, payload.vendorName);
  } else {
    sheet.appendRow(row);
    writeEventVendorLog_('VENDOR_CREATE', vendorId, payload.vendorName);
  }

  return getEventVendorBootstrapData();
}

function linkVendorToEvent(payload) {
  checkEventVendorAccess_();
  ensureEventVendorCoreSheets_();
  validateRequired_(payload, ['eventId', 'vendorId']);

  var ss = getEventVendorSpreadsheet_();
  var cfg = getEventVendorConfig_();
  var sheet = ss.getSheetByName(cfg.LINK_SHEET_NAME);
  var event = getEventById_(payload.eventId);
  var vendor = getVendorById_(payload.vendorId);

  if (!event) throw new Error('행사를 찾을 수 없습니다: ' + payload.eventId);
  if (!vendor) throw new Error('업체를 찾을 수 없습니다: ' + payload.vendorId);

  var linkId = normalizeId_(payload.linkId) || makeId_('LNK');
  var exists = findLinkRow_(sheet, payload.eventId, payload.vendorId);
  var now = new Date();
  var user = getCurrentUserEmail_();
  var row = [
    exists.linkId || linkId,
    payload.eventId,
    event.eventName,
    payload.vendorId,
    vendor.vendorName,
    safeString_(payload.status || '참여예정'),
    safeString_(payload.memo),
    Utilities.formatDate(now, Session.getScriptTimeZone(), 'yyyy-MM-dd HH:mm:ss'),
    user
  ];

  if (exists.rowIdx > 0) {
    sheet.getRange(exists.rowIdx, 1, 1, row.length).setValues([row]);
    writeEventVendorLog_('LINK_UPDATE', payload.eventId + '|' + payload.vendorId, vendor.vendorName);
  } else {
    sheet.appendRow(row);
    writeEventVendorLog_('LINK_CREATE', payload.eventId + '|' + payload.vendorId, vendor.vendorName);
  }

  return getEventVendorBootstrapData();
}

function changeEventStatus(eventId, status) {
  return saveEventCore({ eventId: eventId, status: status, eventName: getEventById_(eventId).eventName });
}

function changeVendorStatus(vendorId, status) {
  return saveVendorCore({ vendorId: vendorId, status: status, vendorName: getVendorById_(vendorId).vendorName });
}

function searchVendors(keyword) {
  checkEventVendorAccess_();
  ensureEventVendorCoreSheets_();
  var q = safeString_(keyword).toLowerCase();
  return listVendors_().filter(function(v) {
    return !q || [v.vendorId, v.vendorName, v.ownerName, v.phone, v.region, v.manager]
      .join(' ')
      .toLowerCase()
      .indexOf(q) >= 0;
  });
}

function getEventDetail(eventId) {
  checkEventVendorAccess_();
  ensureEventVendorCoreSheets_();
  var event = getEventById_(eventId);
  if (!event) throw new Error('행사를 찾을 수 없습니다.');
  var links = listEventVendorLinks_().filter(function(link) { return link.eventId === eventId; });
  return { event: event, vendors: links };
}

function getVendorDetail(vendorId) {
  checkEventVendorAccess_();
  ensureEventVendorCoreSheets_();
  var vendor = getVendorById_(vendorId);
  if (!vendor) throw new Error('업체를 찾을 수 없습니다.');
  var links = listEventVendorLinks_().filter(function(link) { return link.vendorId === vendorId; });
  return { vendor: vendor, events: links };
}

function ensureEventVendorCoreSheets_() {
  var ss = getEventVendorSpreadsheet_();
  var cfg = getEventVendorConfig_();

  ensureSheetWithHeaders_(ss, cfg.EVENT_SHEET_NAME, [
    'eventId','eventName','eventType','startDate','endDate','eventPlace','manager','status','memo','createdAt','updatedAt','updatedBy','baseEventId','eventUid'
  ]);
  ensureSheetWithHeaders_(ss, cfg.VENDOR_SHEET_NAME, [
    'vendorId','vendorName','ownerName','phone','region','status','manager','memo','createdAt','updatedAt','updatedBy','baseVendorId','vendorUid'
  ]);
  ensureSheetWithHeaders_(ss, cfg.LINK_SHEET_NAME, [
    'linkId','eventId','eventName','vendorId','vendorName','status','approvalStatus','statusReason','rejectReason','memo','approvedBy','approvedAt','createdAt','updatedAt','updatedBy'
  ]);
  ensureSheetWithHeaders_(ss, cfg.LOG_SHEET_NAME, [
    'logId','actionType','targetKey','targetName','message','createdAt','createdBy','beforeValue','afterValue','reason','relatedDocumentNo'
  ]);
}

function getEventVendorConfig_() {
  var props = PropertiesService.getScriptProperties();
  var fromSheet = getEventVendorSystemConfigMap_();
  return {
    SPREADSHEET_ID: fromSheet.SPREADSHEET_ID || props.getProperty('SPREADSHEET_ID') || props.getProperty('ERP_SPREADSHEET_ID') || '',
    EVENT_SHEET_NAME: fromSheet.ERP_EVENT_SHEET_NAME || props.getProperty('ERP_EVENT_SHEET_NAME') || 'ERP_행사관리',
    VENDOR_SHEET_NAME: fromSheet.ERP_VENDOR_SHEET_NAME || props.getProperty('ERP_VENDOR_SHEET_NAME') || 'ERP_업체관리',
    LINK_SHEET_NAME: fromSheet.ERP_EVENT_VENDOR_LINK_SHEET_NAME || props.getProperty('ERP_EVENT_VENDOR_LINK_SHEET_NAME') || 'ERP_행사업체연결',
    LOG_SHEET_NAME: fromSheet.ERP_EVENT_VENDOR_LOG_SHEET_NAME || props.getProperty('ERP_EVENT_VENDOR_LOG_SHEET_NAME') || 'ERP_행사업체로그',
    CONFIG_SOURCE: fromSheet.__CONFIG_SOURCE || 'SCRIPT_PROPERTIES'
  };
}

function getEventVendorSpreadsheet_() {
  var cfg = getEventVendorConfig_();
  if (!cfg.SPREADSHEET_ID) {
    throw new Error('SystemConfig의 SPREADSHEET_ID 또는 스크립트 속성 SPREADSHEET_ID 설정이 필요합니다.');
  }
  return SpreadsheetApp.openById(cfg.SPREADSHEET_ID);
}

function getEventVendorSystemConfigMap_() {
  if (typeof getSystemConfigValue === 'function') {
    return {
      SPREADSHEET_ID: safeString_(getSystemConfigValue('SPREADSHEET_ID')),
      ERP_EVENT_SHEET_NAME: safeString_(getSystemConfigValue('ERP_EVENT_SHEET_NAME')),
      ERP_VENDOR_SHEET_NAME: safeString_(getSystemConfigValue('ERP_VENDOR_SHEET_NAME')),
      ERP_EVENT_VENDOR_LINK_SHEET_NAME: safeString_(getSystemConfigValue('ERP_EVENT_VENDOR_LINK_SHEET_NAME')),
      ERP_EVENT_VENDOR_LOG_SHEET_NAME: safeString_(getSystemConfigValue('ERP_EVENT_VENDOR_LOG_SHEET_NAME')),
      __CONFIG_SOURCE: 'GLOBAL_HELPER'
    };
  }

  var props = PropertiesService.getScriptProperties();
  var setupDbId = props.getProperty('SETUP_DB_ID') || props.getProperty('CONFIG_DB_ID') || '';
  var configSs = null;
  var configSheet = null;

  if (setupDbId) {
    try {
      configSs = SpreadsheetApp.openById(setupDbId);
    } catch (e) {}
  }

  if (!configSs) {
    try {
      var currentSs = SpreadsheetApp.getActiveSpreadsheet();
      if (currentSs && currentSs.getSheetByName('SystemConfig')) {
        configSs = currentSs;
      }
    } catch (e2) {}
  }

  if (!configSs) return {};

  configSheet = configSs.getSheetByName('SystemConfig');
  if (!configSheet) return {};

  var lastRow = configSheet.getLastRow();
  var lastCol = Math.max(configSheet.getLastColumn(), 2);
  if (lastRow < 2) return {};

  var values = configSheet.getRange(1, 1, lastRow, lastCol).getValues();
  var header = values[0].map(function(v) { return safeString_(v); });
  var keyIdx = header.indexOf('CONFIG_KEY');
  var valueIdx = header.indexOf('VALUE');
  if (keyIdx < 0 || valueIdx < 0) {
    keyIdx = 0;
    valueIdx = 1;
  }

  var map = {};
  values.slice(1).forEach(function(row) {
    var key = safeString_(row[keyIdx]);
    if (!key) return;
    map[key] = safeString_(row[valueIdx]);
  });
  map.__CONFIG_SOURCE = 'SYSTEM_CONFIG';
  return map;
}

function listEvents_() {
  var cfg = getEventVendorConfig_();
  var rows = getSheetDataObjects_(cfg.EVENT_SHEET_NAME);
  return rows.map(function(r) {
    return {
      eventId: safeString_(r['행사ID']),
      eventName: safeString_(r['행사명']),
      eventType: safeString_(r['행사구분']),
      startDate: safeString_(r['시작일']),
      endDate: safeString_(r['종료일']),
      location: safeString_(r['행사장소']),
      manager: safeString_(r['담당자']),
      status: safeString_(r['상태값']),
      memo: safeString_(r['메모'])
    };
  }).filter(function(r) { return r.eventId; });
}

function listVendors_() {
  var cfg = getEventVendorConfig_();
  var rows = getSheetDataObjects_(cfg.VENDOR_SHEET_NAME);
  return rows.map(function(r) {
    return {
      vendorId: safeString_(r['업체ID']),
      vendorName: safeString_(r['업체명']),
      ownerName: safeString_(r['대표자']),
      phone: safeString_(r['연락처']),
      region: safeString_(r['지역']),
      status: safeString_(r['상태값']),
      manager: safeString_(r['담당자']),
      memo: safeString_(r['메모'])
    };
  }).filter(function(r) { return r.vendorId; });
}

function listEventVendorLinks_() {
  var cfg = getEventVendorConfig_();
  var rows = getSheetDataObjects_(cfg.LINK_SHEET_NAME);
  return rows.map(function(r) {
    return {
      linkId: safeString_(r['연결ID']),
      eventId: safeString_(r['행사ID']),
      eventName: safeString_(r['행사명']),
      vendorId: safeString_(r['업체ID']),
      vendorName: safeString_(r['업체명']),
      status: safeString_(r['상태값']),
      memo: safeString_(r['메모'])
    };
  }).filter(function(r) { return r.linkId; });
}

function getEventVendorSummary_() {
  var events = listEvents_();
  var vendors = listVendors_();
  var links = listEventVendorLinks_();
  return {
    eventCount: events.length,
    vendorCount: vendors.length,
    activeEventCount: events.filter(function(r){ return r.status === '운영중'; }).length,
    activeVendorCount: vendors.filter(function(r){ return r.status === '운영중'; }).length,
    linkedCount: links.length
  };
}

function getEventById_(eventId) {
  return listEvents_().filter(function(r) { return r.eventId === eventId; })[0] || null;
}

function getVendorById_(vendorId) {
  return listVendors_().filter(function(r) { return r.vendorId === vendorId; })[0] || null;
}

function fhEvCanonicalHeader_(header) {
  var h = safeString_(header);
  var map = {
    '행사ID':'eventId','행사명':'eventName','행사구분':'eventType','시작일':'startDate','종료일':'endDate','행사장소':'eventPlace','담당자':'manager','상태값':'status','메모':'memo','생성일시':'createdAt','수정일시':'updatedAt','수정자':'updatedBy','기준행사ID':'baseEventId',
    '업체ID':'vendorId','업체명':'vendorName','대표자':'ownerName','연락처':'phone','지역':'region','기준업체ID':'baseVendorId',
    '연결ID':'linkId','승인상태':'approvalStatus','상태변경사유':'statusReason','반려사유':'rejectReason','승인자':'approvedBy','승인일시':'approvedAt',
    '로그ID':'logId','구분':'actionType','로그유형':'actionType','대상키':'targetKey','대상명':'targetName','내용':'message','처리일시':'createdAt','처리자':'createdBy','사용자':'createdBy'
  };
  return map[h] || h;
}
function fhEvApplyHeaderAliases_(obj) {
  var alias = {
    eventId:['행사ID'], eventName:['행사명'], eventType:['행사구분'], startDate:['시작일'], endDate:['종료일'], eventPlace:['행사장소'], manager:['담당자'], status:['상태값'], memo:['메모'], createdAt:['생성일시','처리일시'], updatedAt:['수정일시'], updatedBy:['수정자'], baseEventId:['기준행사ID'],
    vendorId:['업체ID'], vendorName:['업체명'], ownerName:['대표자'], phone:['연락처'], region:['지역'], baseVendorId:['기준업체ID'],
    linkId:['연결ID'], approvalStatus:['승인상태'], statusReason:['상태변경사유'], rejectReason:['반려사유'], approvedBy:['승인자'], approvedAt:['승인일시'],
    logId:['로그ID'], actionType:['구분','로그유형'], targetKey:['대상키'], targetName:['대상명'], message:['내용'], createdBy:['처리자','사용자']
  };
  Object.keys(alias).forEach(function(k){
    if (obj[k] === undefined) return;
    alias[k].forEach(function(a){ if (obj[a] === undefined) obj[a] = obj[k]; });
  });
  return obj;
}
function getSheetDataObjects_(sheetName) {
  var ss = getEventVendorSpreadsheet_();
  var sheet = ss.getSheetByName(sheetName);
  if (!sheet) return [];
  var values = sheet.getDataRange().getValues();
  if (values.length < 2) return [];
  var headers = values[0].map(function(h){ return safeString_(h); });
  return values.slice(1).filter(function(r){ return r.join('').trim() !== ''; }).map(function(row) {
    var obj = {};
    headers.forEach(function(header, idx) {
      var canon = fhEvCanonicalHeader_(header);
      obj[header] = row[idx];
      if (canon && obj[canon] === undefined) obj[canon] = row[idx];
    });
    return fhEvApplyHeaderAliases_(obj);
  });
}

function ensureSheetWithHeaders_(ss, name, headers) {
  var sheet = ss.getSheetByName(name);
  if (!sheet) sheet = ss.insertSheet(name);
  var canonical = headers.map(fhEvCanonicalHeader_);
  if (sheet.getLastRow() === 0) {
    sheet.getRange(1, 1, 1, canonical.length).setValues([canonical]);
    sheet.setFrozenRows(1);
    return sheet;
  }
  var width = Math.max(sheet.getLastColumn(), canonical.length, 1);
  var currentHeaders = sheet.getRange(1, 1, 1, width).getDisplayValues()[0].map(function(h){ return safeString_(h); });
  for (var i = 0; i < currentHeaders.length; i++) {
    var canonHeader = fhEvCanonicalHeader_(currentHeaders[i]);
    if (canonHeader && canonHeader !== currentHeaders[i]) {
      sheet.getRange(1, i + 1).setValue(canonHeader);
      currentHeaders[i] = canonHeader;
    }
  }
  canonical.forEach(function(h) {
    if (currentHeaders.indexOf(h) === -1) {
      sheet.getRange(1, currentHeaders.length + 1).setValue(h);
      currentHeaders.push(h);
    }
  });
  sheet.setFrozenRows(1);
  return sheet;
}

function findRowByValue_(sheet, colIdx, value) {
  var lastRow = sheet.getLastRow();
  if (lastRow < 2) return -1;
  var values = sheet.getRange(2, colIdx, lastRow - 1, 1).getValues();
  for (var i = 0; i < values.length; i++) {
    if (String(values[i][0]) === String(value)) return i + 2;
  }
  return -1;
}

function findLinkRow_(sheet, eventId, vendorId) {
  var lastRow = sheet.getLastRow();
  if (lastRow < 2) return { rowIdx: -1, linkId: '' };
  var values = sheet.getRange(2, 1, lastRow - 1, 5).getValues();
  for (var i = 0; i < values.length; i++) {
    if (String(values[i][1]) === String(eventId) && String(values[i][3]) === String(vendorId)) {
      return { rowIdx: i + 2, linkId: String(values[i][0] || '') };
    }
  }
  return { rowIdx: -1, linkId: '' };
}

function writeEventVendorLog_(kind, targetKey, targetName) {
  var ss = getEventVendorSpreadsheet_();
  var cfg = getEventVendorConfig_();
  var sheet = ss.getSheetByName(cfg.LOG_SHEET_NAME);
  sheet.appendRow([
    makeId_('LOG'),
    kind,
    targetKey,
    targetName,
    Utilities.formatDate(new Date(), Session.getScriptTimeZone(), 'yyyy-MM-dd HH:mm:ss'),
    getCurrentUserEmail_()
  ]);
}

function checkEventVendorAccess_() {
  return true;
}

function validateRequired_(payload, keys) {
  keys.forEach(function(key) {
    if (!payload || !safeString_(payload[key])) {
      throw new Error('필수값 누락: ' + key);
    }
  });
}

function safeString_(value) {
  return value === null || value === undefined ? '' : String(value).trim();
}

function normalizeId_(value) {
  return safeString_(value).replace(/\s+/g, '');
}

function makeId_(prefix) {
  return prefix + '-' + Utilities.formatDate(new Date(), Session.getScriptTimeZone(), 'yyyyMMddHHmmss') + '-' + Math.floor(Math.random() * 1000);
}

function getCurrentUserEmail_() {
  try {
    return Session.getActiveUser().getEmail() || 'unknown';
  } catch (e) {
    return 'unknown';
  }
}


function renderEventVendorCorePage_() {
  checkEventVendorAccess_();
  ensureEventVendorCoreSheets_();
  return HtmlService.createHtmlOutputFromFile('EventVendor')
    .setTitle('행사/업체 관리')
    .setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL);
}

function tryHandleEventVendorRoute_(e) {
  var page = e && e.parameter ? safeString_(e.parameter.page).toLowerCase() : '';
  if (page === 'eventvendor' || page === 'event_vendor' || page === 'event-vendor') {
    return renderEventVendorCorePage_();
  }
  return null;
}

function getEventVendorWebAppUrl() {
  var url = '';
  try {
    url = ScriptApp.getService().getUrl() || '';
  } catch (e) {
    url = '';
  }
  if (!url) {
    var cfg = getEventVendorConfig_();
    url = safeString_(cfg.ERP_WEBAPP_URL || cfg.PORTAL_WEBAPP_URL || '');
  }
  if (!url) throw new Error('웹앱 URL을 찾을 수 없습니다. SystemConfig의 ERP_WEBAPP_URL을 확인하세요.');
  return url + (url.indexOf('?') >= 0 ? '&' : '?') + 'page=eventVendor';
}

function getEventVendorOpenLinkInfo() {
  return {
    url: getEventVendorWebAppUrl(),
    page: 'eventVendor',
    title: '행사/업체 관리'
  };
}

function showEventVendorOpenLinkDialog() {
  var url = getEventVendorWebAppUrl();
  var html = HtmlService.createHtmlOutput(
    '<div style="font-family:Arial,sans-serif;padding:16px">' +
    '<h3 style="margin:0 0 12px">행사/업체 관리 열기</h3>' +
    '<div style="font-size:13px;color:#475569;margin-bottom:12px">아래 링크로 실제 화면을 엽니다.</div>' +
    '<a href="' + url + '" target="_blank" style="display:inline-block;padding:10px 14px;background:#111827;color:#fff;text-decoration:none;border-radius:10px">행사/업체 관리 열기</a>' +
    '<div style="margin-top:12px;font-size:12px;color:#64748b;word-break:break-all">' + url + '</div>' +
    '</div>'
  ).setWidth(520).setHeight(220);
  SpreadsheetApp.getUi().showModalDialog(html, '행사/업체 관리 링크');
}




/** B05L header safety audit/migration - Korean header creation is blocked, legacy Korean headers are renamed to camelCase. */
function fhErpB05LGetEventVendorHeaderSpec_() {
  return {
    'ERP_행사관리': ['eventId','eventName','eventType','startDate','endDate','eventPlace','manager','status','memo','createdAt','updatedAt','updatedBy','baseEventId','eventUid'],
    'ERP_업체관리': ['vendorId','vendorName','ownerName','phone','region','status','manager','memo','createdAt','updatedAt','updatedBy','baseVendorId','vendorUid'],
    'ERP_행사업체연결': ['linkId','eventId','eventName','vendorId','vendorName','status','approvalStatus','statusReason','rejectReason','memo','approvedBy','approvedAt','createdAt','updatedAt','updatedBy'],
    'ERP_행사업체로그': ['logId','actionType','targetKey','targetName','message','createdAt','createdBy','beforeValue','afterValue','reason','relatedDocumentNo']
  };
}
function fhErpB05LMigrateEventVendorHeaders(options) {
  options = options || {};
  var dryRun = options.dryRun === true;
  var ss = getEventVendorSpreadsheet_();
  var spec = fhErpB05LGetEventVendorHeaderSpec_();
  var report = { ok:true, dryRun:dryRun, checkedAt:new Date().toISOString(), sheets:[], warnings:[], errors:[] };
  Object.keys(spec).forEach(function(name){
    var sh = ss.getSheetByName(name);
    if (!sh) { report.warnings.push('시트 없음: ' + name); return; }
    var width = Math.max(sh.getLastColumn(), spec[name].length, 1);
    var headers = sh.getRange(1,1,1,width).getDisplayValues()[0].map(safeString_);
    var next = headers.slice();
    var changed = false;
    for (var i=0;i<next.length;i++) {
      var canon = fhEvCanonicalHeader_(next[i]);
      if (canon && canon !== next[i]) { next[i] = canon; changed = true; }
    }
    spec[name].forEach(function(h){ if (next.indexOf(h) === -1) { next.push(h); changed = true; } });
    if (!dryRun && changed) sh.getRange(1,1,1,next.length).setValues([next]);
    report.sheets.push({ sheetName:name, changed:changed, before:headers, after:next });
  });
  return report;
}
function fhErpB05LStrongLogicAudit() {
  var report = { ok:true, buildNo:'v64-B06J33A', checkedAt:new Date().toISOString(), checks:[], warnings:[], errors:[] };
  function pass(name, data){ report.checks.push({name:name, ok:true, data:data||{}}); }
  function warn(msg){ report.warnings.push(msg); }
  function fail(msg){ report.errors.push(msg); report.ok = false; }
  try { pass('HEADER_MIGRATION_PREVIEW', fhErpB05LMigrateEventVendorHeaders({dryRun:true})); } catch(e){ fail('헤더 점검 실패: ' + e.message); }
  try { if (typeof FH !== 'undefined' && FH.runDiagnosticsSuite) pass('CONTROL_DIAGNOSTIC_CORE', FH.runDiagnosticsSuite()); } catch(e2){ warn('CONTROL 내부 진단 직접 호출 경고: ' + e2.message); }
  try { if (typeof fhOpsUiB04EGetDashboard === 'function') pass('OPS_DASHBOARD_FUNCTION_EXISTS'); else fail('운영버튼 현황 함수 누락'); } catch(e3){ fail('운영버튼 현황 함수 점검 실패: ' + e3.message); }
  try { if (typeof fhOpsUiB05GetWorklists === 'function') pass('OPS_WORKLIST_FUNCTION_EXISTS'); else fail('목록 자동조회 함수 누락'); } catch(e4){ fail('목록 자동조회 함수 점검 실패: ' + e4.message); }
  report.warningCount = report.warnings.length;
  report.errorCount = report.errors.length;
  return report;
}

/** B05L Drive + Docs 권한 사전 승인 확인용 */
function fhOpsUiB05LGrantDriveDocsAuth() {
  const email = Session.getActiveUser().getEmail();
  const rootName = DriveApp.getRootFolder().getName();
  const tempDoc = DocumentApp.create('FEELHAUS_B05L_AUTH_CHECK_DELETE_ME');
  tempDoc.getBody().appendParagraph('FEELHAUS B05L 권한 확인용 임시 문서입니다. 자동 삭제됩니다.');
  tempDoc.saveAndClose();
  const tempDocId = tempDoc.getId();
  try {
    DriveApp.getFileById(tempDocId).setTrashed(true);
  } catch (err) {
    Logger.log('[fhOpsUiB05LGrantDriveDocsAuth] temp trash failed: ' + err);
  }
  return {
    ok: true,
    message: 'B05L Drive + Docs 권한 승인 확인 완료',
    data: { userEmail: email, rootFolderName: rootName, tempDocId: tempDocId, buildNo: 'v64-B06J33A' },
    errorCode: '',
    meta: { buildNo: 'OPS-UI-20260428-B06J5', at: new Date().toISOString() }
  };
}

/** 이전 안내 함수 호환용 */
function fhOpsUiB05LGrantDriveAuth() {
  return fhOpsUiB05LGrantDriveDocsAuth();
}

/** B05H/B05I/B05J compatibility aliases to B05L auth checker */
function fhOpsUiB05HGrantDriveDocsAuth() { return fhOpsUiB05LGrantDriveDocsAuth(); }
function fhOpsUiB05HGrantDriveAuth() { return fhOpsUiB05LGrantDriveDocsAuth(); }
function fhOpsUiB05IGrantDriveDocsAuth() { return fhOpsUiB05LGrantDriveDocsAuth(); }
function fhOpsUiB05IGrantDriveAuth() { return fhOpsUiB05LGrantDriveDocsAuth(); }
function fhOpsUiB05JGrantDriveDocsAuth() { return fhOpsUiB05LGrantDriveDocsAuth(); }
function fhOpsUiB05JGrantDriveAuth() { return fhOpsUiB05LGrantDriveDocsAuth(); }

function fhOpsUiB06GrantDriveDocsAuth() { return fhOpsUiB05LGrantDriveDocsAuth(); }
function fhOpsUiB06GrantDriveAuth() { return fhOpsUiB05LGrantDriveDocsAuth(); }

function createFieldQrSignDocument(payload) {
  try {
    var out = createFieldQrSignDocumentCore_(payload || {});
    return {
      ok: true,
      message: (out && out.message) || '현장 QR_SIGN 문서 생성 완료',
      data: out || {},
      errorCode: '',
      meta: { buildNo: 'v64-B06J33A', at: new Date().toISOString() }
    };
  } catch (err) {
    return {
      ok: false,
      message: '현장 QR 생성 실패: ' + ((err && err.message) || String(err)),
      errorCode: 'FIELD_QR_CREATE_FAILED',
      data: { stack: (err && err.stack) || '', payload: payload || {} },
      meta: { buildNo: 'v64-B06J33A', at: new Date().toISOString() }
    };
  }
}

/** B06J5 PUBLIC ENTRY QR - LINK ONLY API
 * 공용입장 QR은 QR_SIGN 문서가 아니다.
 * 행사 선택만으로 SIGN 공용입장 검색/입력 화면으로 진입하는 링크만 생성한다.
 * 동/호/customerId/documentId/READY_TO_SIGN 모두 사용하지 않는다.
 */
function createPublicEntryQrLink(payload) {
  try {
    payload = payload || {};
    var env = fhB06J1FieldQrSetup_();
    var ss = env.masterDb;
    var eventId = String(payload.eventId || '').trim();
    if (!eventId) throw new Error('공용입장 QR은 행사 선택이 필수입니다.');
    var eventName = String(payload.eventName || '').trim() || fhB06J1GetEventName_(ss, eventId) || eventId;
    var boothHint = String(payload.boothHint || payload.boothName || '').trim();
    var base = fhB06J1SignBaseUrl_(env.config);
    if (!base) throw new Error('SIGN 웹앱 기본 URL을 찾을 수 없습니다. SystemConfig의 SIGN_WEBAPP_URL 값을 확인하세요.');
    var url = base
      + '?mode=qr'
      + '&fieldMode=QR'
      + '&qrEntry=Y'
      + '&entryType=PUBLIC'
      + '&eventId=' + encodeURIComponent(eventId)
      + '&eventName=' + encodeURIComponent(eventName)
      + '&boothHint=' + encodeURIComponent(boothHint || '');
    var data = {
      linkOnly: true,
      isPublicEntry: true,
      message: '행사 공용입장 QR 링크 생성 완료',
      documentId: '',
      documentNo: '',
      status: 'PUBLIC_ENTRY_LINK',
      qrType: 'PUBLIC',
      entryType: 'PUBLIC',
      eventId: eventId,
      eventName: eventName,
      boothHint: boothHint,
      unitHint: '',
      qrUrl: url,
      signUrl: url,
      qrImageUrl: fhB06J1QrImageUrl_(url),
      buildNo: 'v64-B06J33A'
    };
    return { ok:true, message:data.message, data:data, errorCode:'', meta:{ buildNo:'v64-B06J33A', at:new Date().toISOString() } };
  } catch (err) {
    return { ok:false, message:'공용입장 QR 링크 생성 실패: ' + ((err && err.message) || String(err)), errorCode:'PUBLIC_ENTRY_QR_FAILED', data:{ stack:(err && err.stack) || '', payload:payload || {} }, meta:{ buildNo:'v64-B06J33A', at:new Date().toISOString() } };
  }
}

/** B06J2 FIELD QR BULK GENERATOR - SAFE EXTENSION
 * 목적: ERP 관리자 화면에서 현장 공용입장 QR / 지정형 QR_SIGN 문서를 생성한다.
 * 원칙: FEELHAUS_SETUP_DB > SystemConfig, FEELHAUS_DB_MASTER, SIGN_Documents 헤더맵 접근 유지.
 * 기존 계약서/설치확인서/정산확인서/SIGN/PDF/보관 흐름은 변경하지 않는다.
 */
function fhB06J1FieldQrSetup_() {
  var setupId = '17VMSpgSZCvIrUlgcw8yCNcnl8WQWo2IcRf5tDCcuJGM';
  var setup = SpreadsheetApp.openById(setupId);
  var cfg = setup.getSheetByName('SystemConfig');
  if (!cfg) throw new Error('SystemConfig 시트를 찾을 수 없습니다.');
  var values = cfg.getDataRange().getValues();
  var headers = values[0].map(function(h){ return String(h || '').trim(); });
  var kIdx = Math.max(headers.indexOf('key'), headers.indexOf('configKey'), headers.indexOf('name'));
  var vIdx = Math.max(headers.indexOf('value'), headers.indexOf('configValue'), headers.indexOf('id'));
  if (kIdx < 0) kIdx = 0;
  if (vIdx < 0) vIdx = 1;
  var config = {};
  for (var i = 1; i < values.length; i++) {
    var k = String(values[i][kIdx] || '').trim();
    if (k) config[k] = values[i][vIdx];
  }
  var masterId = String(config.FEELHAUS_DB_MASTER_ID || config.MASTER_DB_ID || config.DB_MASTER_ID || '').trim();
  if (!masterId) throw new Error('SystemConfig에서 FEELHAUS_DB_MASTER ID를 찾을 수 없습니다.');
  return { setupDb: setup, config: config, masterDbId: masterId, masterDb: SpreadsheetApp.openById(masterId) };
}
function fhB06J1HeaderMap_(sheet) {
  var width = Math.max(sheet.getLastColumn(), 1);
  var headers = sheet.getRange(1, 1, 1, width).getValues()[0].map(function(h){ return String(h || '').trim(); });
  var map = {};
  headers.forEach(function(h, i){ if (h) map[h] = i; });
  return map;
}
function fhB06J1EnsureSheet_(ss, name, headers) {
  var sh = ss.getSheetByName(name) || ss.insertSheet(name);
  if (sh.getLastRow() < 1 || sh.getLastColumn() < 1 || String(sh.getRange(1, 1).getValue() || '').trim() === '') {
    sh.getRange(1, 1, 1, headers.length).setValues([headers]);
    return sh;
  }
  var map = fhB06J1HeaderMap_(sh);
  var add = [];
  headers.forEach(function(h){ if (map[h] == null) add.push(h); });
  if (add.length) sh.getRange(1, sh.getLastColumn() + 1, 1, add.length).setValues([add]);
  return sh;
}
function fhB06J1AppendObject_(sheet, obj) {
  var map = fhB06J1HeaderMap_(sheet);
  var row = new Array(sheet.getLastColumn()).fill('');
  Object.keys(obj || {}).forEach(function(k){ if (map[k] != null) row[map[k]] = obj[k] == null ? '' : obj[k]; });
  sheet.appendRow(row);
}
function fhB06J1GetEventName_(ss, eventId) {
  var names = ['ERP_행사관리', 'Events', 'ERP_Events'];
  var id = String(eventId || '').trim();
  if (!id) return '';
  for (var n = 0; n < names.length; n++) {
    var sh = ss.getSheetByName(names[n]);
    if (!sh || sh.getLastRow() < 2) continue;
    var map = fhB06J1HeaderMap_(sh);
    if (map.eventId == null) continue;
    var nameKey = map.eventName != null ? 'eventName' : (map.name != null ? 'name' : '');
    var vals = sh.getRange(2, 1, sh.getLastRow() - 1, sh.getLastColumn()).getValues();
    for (var i = 0; i < vals.length; i++) {
      if (String(vals[i][map.eventId] || '').trim() === id) return nameKey ? String(vals[i][map[nameKey]] || '').trim() : id;
    }
  }
  return id;
}
function fhB06J1SignBaseUrl_(config) {
  var base = String(config.SIGN_WEBAPP_URL || config.SIGN_WEB_APP_URL || config.SIGN_URL || config.SIGN_EXEC_URL || '').trim();
  if (!base) base = 'https://script.google.com/macros/s/AKfycby7TkzJGBe9vW7eDmqOaDWYc23cQEzrYRC2hVVc1dvMdmk50r5stgDi4fPikMgeMPrU/exec';
  return base.split('?')[0];
}
function fhB06J1DocumentNo_(sheet) {
  var tz = Session.getScriptTimeZone() || 'Asia/Seoul';
  var ymd = Utilities.formatDate(new Date(), tz, 'yyyyMMdd');
  return 'DOC-' + ymd + '-' + Utilities.formatString('%03d', Math.max(1, sheet.getLastRow()));
}
function fhB06J1QrImageUrl_(url) {
  return 'https://quickchart.io/qr?size=360&text=' + encodeURIComponent(String(url || ''));
}
function createFieldQrSignDocumentCore_(payload) {
  payload = payload || {};
  var env = fhB06J1FieldQrSetup_();
  var ss = env.masterDb;
  var eventId = String(payload.eventId || '').trim();
  var qrType = String(payload.qrType || payload.type || 'PUBLIC').trim().toUpperCase();
  var boothHint = String(payload.boothHint || payload.boothName || '').trim();
  var dong = String(payload.dong || '').trim();
  var ho = String(payload.hosu || payload.ho || '').trim();
  var actor = String(payload.createdBy || payload.updatedBy || '').trim() || 'ERP_FIELD_QR';
  if (!eventId) throw new Error('현장 QR 생성은 행사 선택이 필수입니다.');
  // B06J4: 공용입장 QR은 행사(eventId) 단위 1개 기준입니다. dong/ho/customerId/boothHint는 필수로 보지 않습니다.
  if (qrType !== 'PUBLIC' && qrType !== 'ASSIGNED') throw new Error('QR 유형은 PUBLIC 또는 ASSIGNED만 허용됩니다.');
  if (qrType === 'ASSIGNED' && (!dong || !ho)) throw new Error('지정형 QR은 동/호 입력이 필수입니다.');
  var eventName = String(payload.eventName || '').trim() || fhB06J1GetEventName_(ss, eventId) || eventId;
  var unitHint = qrType === 'ASSIGNED' ? (dong + '동 ' + ho + '호') : '';

  // B06J4: 공용입장 QR은 QR_SIGN 문서를 만들지 않는다.
  // 행사 진입 링크만 생성하여 SIGN 공용입장 검색 화면으로 보낸다.
  if (qrType === 'PUBLIC') {
    var publicBase = fhB06J1SignBaseUrl_(env.config);
    var publicUrl = publicBase
      + '?mode=qr'
      + '&fieldMode=QR'
      + '&qrEntry=Y'
      + '&entryType=PUBLIC'
      + '&eventId=' + encodeURIComponent(eventId)
      + '&eventName=' + encodeURIComponent(eventName)
      + '&boothHint=' + encodeURIComponent(boothHint || '');
    return {
      ok: true,
      reused: false,
      linkOnly: true,
      message: '행사 공용입장 QR 링크 생성 완료',
      documentId: '',
      documentNo: '',
      status: 'PUBLIC_ENTRY_LINK',
      qrUrl: publicUrl,
      signUrl: publicUrl,
      qrImageUrl: fhB06J1QrImageUrl_(publicUrl),
      qrType: 'PUBLIC',
      eventId: eventId,
      eventName: eventName,
      boothHint: boothHint,
      unitHint: '',
      buildNo: 'v64-B06J33A'
    };
  }

  var headers = ['documentId','documentNo','documentType','status','statusReason','eventId','vendorId','customerId','saleId','contractId','installId','settlementId','approvalId','requestId','title','templateCode','signMethod','qrType','qrEntry','eventName','boothHint','unitHint','dong','ho','signUrl','qrUrl','createdAt','createdBy','updatedAt','updatedBy','notes'];
  var sh = fhB06J1EnsureSheet_(ss, 'SIGN_Documents', headers);
  var map = fhB06J1HeaderMap_(sh);
  var vals = sh.getLastRow() > 1 ? sh.getRange(2, 1, sh.getLastRow() - 1, sh.getLastColumn()).getValues() : [];
  for (var i = vals.length - 1; i >= 0; i--) {
    var row = vals[i];
    var typeOk = map.documentType != null && String(row[map.documentType] || '').trim().toUpperCase() === 'QR_SIGN';
    var eventOk = map.eventId != null && String(row[map.eventId] || '').trim() === eventId;
    var qrTypeOk = map.qrType != null && String(row[map.qrType] || '').trim().toUpperCase() === qrType;
    var boothOk = qrType === 'PUBLIC' ? true : (map.boothHint != null && String(row[map.boothHint] || '').trim() === boothHint);
    var dongOk = qrType === 'PUBLIC' || (map.dong != null && String(row[map.dong] || '').trim() === dong);
    var hoOk = qrType === 'PUBLIC' || (map.hosu != null && String(row[map.hosu] || '').trim() === ho);
    var archived = map.status != null && String(row[map.status] || '').trim().toUpperCase() === 'ARCHIVED';
    if (typeOk && eventOk && qrTypeOk && boothOk && dongOk && hoOk && !archived) {
      var reused = {};
      Object.keys(map).forEach(function(h){ reused[h] = row[map[h]] || ''; });
      var reusedUrl = String(reused.qrUrl || reused.signUrl || '').trim();
      return { ok:true, reused:true, message:'현장 QR_SIGN 기존 문서 재사용', documentId:reused.documentId || '', documentNo:reused.documentNo || '', status:reused.status || '', qrUrl:reusedUrl, signUrl:reusedUrl, qrImageUrl:fhB06J1QrImageUrl_(reusedUrl), qrType:qrType, eventId:eventId, eventName:eventName, boothHint:boothHint, unitHint:unitHint, data:reused, buildNo:'v64-B06J33A' };
    }
  }
  var now = new Date();
  var documentId = 'DOC_' + Utilities.getUuid().replace(/-/g, '').substring(0, 12).toUpperCase();
  var documentNo = fhB06J1DocumentNo_(sh);
  var base = fhB06J1SignBaseUrl_(env.config);
  var url = base + '?mode=sign&documentId=' + encodeURIComponent(documentId) + '&fieldMode=QR&qrEntry=Y&eventName=' + encodeURIComponent(eventName) + '&boothHint=' + encodeURIComponent(boothHint);
  if (qrType === 'ASSIGNED') url += '&unitHint=' + encodeURIComponent(unitHint) + '&dong=' + encodeURIComponent(dong) + '&ho=' + encodeURIComponent(ho);
  var rowObj = { documentId:documentId, documentNo:documentNo, documentType:'QR_SIGN', status:'READY_TO_SIGN', statusReason:'현장 QR 생성', eventId:eventId, vendorId:String(payload.vendorId || '').trim(), customerId:'', saleId:'', contractId:'', installId:'', settlementId:'', approvalId:'', requestId:'', title:'QR 서명확인서', templateCode:'PDF_QR_SIGN', signMethod:'QR', qrType:qrType, qrEntry:'Y', eventName:eventName, boothHint:boothHint, unitHint:unitHint, dong:dong, ho:ho, signUrl:url, qrUrl:url, createdAt:now, createdBy:actor, updatedAt:now, updatedBy:actor, notes:'ERP_B06J2_FIELD_QR_BULK_GENERATOR / ' + qrType + ' / booth=' + boothHint + (unitHint ? ' / unit=' + unitHint : '') };
  fhB06J1AppendObject_(sh, rowObj);
  try {
    var logSh = fhB06J1EnsureSheet_(ss, 'SIGN_Document_Logs', ['logId','documentId','actionType','fromStatus','toStatus','actor','reason','createdAt']);
    fhB06J1AppendObject_(logSh, { logId:'LOG-' + Utilities.getUuid().replace(/-/g,'').substring(0,12).toUpperCase(), documentId:documentId, actionType:'CREATE_FIELD_QR_SIGN_FROM_ERP', fromStatus:'', toStatus:'READY_TO_SIGN', actor:actor, reason:'현장 QR 생성 메뉴', createdAt:now });
  } catch(e) {}
  return { ok:true, reused:false, message:'현장 QR_SIGN 문서 생성 완료', documentId:documentId, documentNo:documentNo, status:'READY_TO_SIGN', qrUrl:url, signUrl:url, qrImageUrl:fhB06J1QrImageUrl_(url), qrType:qrType, eventId:eventId, eventName:eventName, boothHint:boothHint, unitHint:unitHint, data:rowObj, buildNo:'v64-B06J33A' };
}


/** B06J5 PUBLIC ENTRY QR - LINK ONLY API
 * 공용입장 QR은 QR_SIGN 문서가 아니다.
 * 행사 선택만으로 SIGN 공용입장 검색/입력 화면으로 진입하는 링크만 생성한다.
 * 동/호/customerId/documentId/READY_TO_SIGN 모두 사용하지 않는다.
 */
function createPublicEntryQrLink(payload) {
  try {
    payload = payload || {};
    var env = fhB06J1FieldQrSetup_();
    var ss = env.masterDb;
    var eventId = String(payload.eventId || '').trim();
    if (!eventId) throw new Error('공용입장 QR은 행사 선택이 필수입니다.');
    var eventName = String(payload.eventName || '').trim() || fhB06J1GetEventName_(ss, eventId) || eventId;
    var boothHint = String(payload.boothHint || payload.boothName || '').trim();
    var base = fhB06J1SignBaseUrl_(env.config);
    if (!base) throw new Error('SIGN 웹앱 기본 URL을 찾을 수 없습니다. SystemConfig의 SIGN_WEBAPP_URL 값을 확인하세요.');
    var url = base
      + '?mode=qr'
      + '&fieldMode=QR'
      + '&qrEntry=Y'
      + '&entryType=PUBLIC'
      + '&eventId=' + encodeURIComponent(eventId)
      + '&eventName=' + encodeURIComponent(eventName)
      + '&boothHint=' + encodeURIComponent(boothHint || '');
    var data = {
      linkOnly: true,
      isPublicEntry: true,
      message: '행사 공용입장 QR 링크 생성 완료',
      documentId: '',
      documentNo: '',
      status: 'PUBLIC_ENTRY_LINK',
      qrType: 'PUBLIC',
      entryType: 'PUBLIC',
      eventId: eventId,
      eventName: eventName,
      boothHint: boothHint,
      unitHint: '',
      qrUrl: url,
      signUrl: url,
      qrImageUrl: fhB06J1QrImageUrl_(url),
      buildNo: 'v64-B06J33A'
    };
    return { ok:true, message:data.message, data:data, errorCode:'', meta:{ buildNo:'v64-B06J33A', at:new Date().toISOString() } };
  } catch (err) {
    return { ok:false, message:'공용입장 QR 링크 생성 실패: ' + ((err && err.message) || String(err)), errorCode:'PUBLIC_ENTRY_QR_FAILED', data:{ stack:(err && err.stack) || '', payload:payload || {} }, meta:{ buildNo:'v64-B06J33A', at:new Date().toISOString() } };
  }
}

/** B06J2 FIELD QR BULK GENERATOR - SAFE EXTENSION
 * 목적: 정회원 DB 업로드/고객관리의 eventId + dong + ho 목록 기준으로 지정형 QR_SIGN을 일괄 생성한다.
 * 원칙: 기존 고객 정보는 수정하지 않고, SIGN_Documents에 QR_SIGN 문서만 생성/재사용한다.
 */
function fhB06J4ustomerSheet_(ss) {
  var names = ['ERP_고객관리','Customers','ERP_Customers'];
  for (var i = 0; i < names.length; i++) {
    var sh = ss.getSheetByName(names[i]);
    if (sh) return sh;
  }
  return null;
}
function fhB06J2GetRegularQrTargets(payload) {
  payload = payload || {};
  var env = fhB06J1FieldQrSetup_();
  var ss = env.masterDb;
  var eventId = String(payload.eventId || '').trim();
  if (!eventId) throw new Error('지정형 QR 대상 조회는 행사 선택이 필수입니다.');
  var aptFilter = String(payload.aptName || payload.apartmentName || '').trim().toLowerCase();
  var dongFilter = String(payload.dong || '').trim();
  var limit = Math.max(1, Math.min(Number(payload.limit || 500), 2000));
  var customerSh = fhB06J4ustomerSheet_(ss);
  if (!customerSh || customerSh.getLastRow() < 2) {
    return { ok:true, message:'정회원 대상 없음', targets:[], total:0, eventId:eventId, buildNo:'v64-B06J33A' };
  }
  var cmap = fhB06J1HeaderMap_(customerSh);
  var required = ['customerId','eventId','dong'];
  for (var r = 0; r < required.length; r++) if (cmap[required[r]] == null) throw new Error('ERP_고객관리 필수 헤더 누락: ' + required[r]);
  var hoKey = cmap.hosu != null ? 'hosu' : (cmap.ho != null ? 'ho' : '');
  if (!hoKey) throw new Error('ERP_고객관리 필수 헤더 누락: hosu');
  var vals = customerSh.getRange(2, 1, customerSh.getLastRow() - 1, customerSh.getLastColumn()).getValues();
  var targets = [];
  var seen = {};
  for (var i = 0; i < vals.length; i++) {
    var row = vals[i];
    var rowEventId = String(row[cmap.eventId] || '').trim();
    if (rowEventId !== eventId) continue;
    var memberType = cmap.memberType != null ? String(row[cmap.memberType] || '').trim().toUpperCase() : '';
    var customerType = cmap.customerType != null ? String(row[cmap.customerType] || '').trim().toUpperCase() : '';
    if (memberType && memberType !== 'REGULAR' && customerType !== 'REGULAR') continue;
    if (!memberType && customerType && customerType !== 'REGULAR') continue;
    var customerId = String(row[cmap.customerId] || '').trim();
    var dong = String(row[cmap.dong] || '').trim();
    var ho = String(row[cmap[hoKey]] || '').trim();
    if (!customerId || !dong || !ho) continue;
    if (dongFilter && dong !== dongFilter) continue;
    var aptName = cmap.aptName != null ? String(row[cmap.aptName] || '').trim() : (cmap.apartmentName != null ? String(row[cmap.apartmentName] || '').trim() : '');
    if (aptFilter && aptName.toLowerCase().indexOf(aptFilter) < 0) continue;
    var key = eventId + '|' + dong + '|' + ho;
    if (seen[key]) continue;
    seen[key] = customerId;
    targets.push({ customerId:customerId, eventId:eventId, apartmentName:aptName, dong:dong, ho:ho, name:cmap.name != null ? String(row[cmap.name] || '').trim() : '', phone:cmap.phone != null ? String(row[cmap.phone] || '').trim() : '', regularCheck:cmap.regularCheck != null ? String(row[cmap.regularCheck] || '').trim() : '', status:cmap.status != null ? String(row[cmap.status] || '').trim() : '' });
    if (targets.length >= limit) break;
  }
  return { ok:true, message:'지정형 QR 대상 조회 완료', targets:targets, total:targets.length, eventId:eventId, buildNo:'v64-B06J33A' };
}
function fhB06J2FindExistingAssignedQr_(sh, map, eventId, customerId, dong, ho) {
  if (!sh || sh.getLastRow() < 2) return null;
  var vals = sh.getRange(2, 1, sh.getLastRow() - 1, sh.getLastColumn()).getValues();
  for (var i = vals.length - 1; i >= 0; i--) {
    var row = vals[i];
    var typeOk = map.documentType != null && String(row[map.documentType] || '').trim().toUpperCase() === 'QR_SIGN';
    var eventOk = map.eventId != null && String(row[map.eventId] || '').trim() === String(eventId || '').trim();
    var customerOk = map.customerId != null && String(row[map.customerId] || '').trim() === String(customerId || '').trim();
    var dongOk = map.dong != null && String(row[map.dong] || '').trim() === String(dong || '').trim();
    var hoOk = map.hosu != null && String(row[map.hosu] || '').trim() === String(ho || '').trim();
    var qrTypeOk = map.qrType == null || String(row[map.qrType] || '').trim().toUpperCase() === 'ASSIGNED';
    var archived = map.status != null && String(row[map.status] || '').trim().toUpperCase() === 'ARCHIVED';
    if (typeOk && eventOk && customerOk && dongOk && hoOk && qrTypeOk && !archived) {
      var out = {};
      Object.keys(map).forEach(function(h){ out[h] = row[map[h]] || ''; });
      return out;
    }
  }
  return null;
}
function fhB06J4reateAssignedQrForTarget_(env, sh, map, target, options) {
  options = options || {};
  var eventId = String(target.eventId || options.eventId || '').trim();
  var customerId = String(target.customerId || '').trim();
  var dong = String(target.dong || '').trim();
  var ho = String(target.ho || '').trim();
  if (!eventId || !customerId || !dong || !ho) throw new Error('지정형 QR 생성 대상에 eventId/customerId/dong/ho가 필요합니다.');
  var eventName = String(options.eventName || '').trim() || fhB06J1GetEventName_(env.masterDb, eventId) || eventId;
  var boothHint = String(options.boothHint || '').trim();
  var existing = fhB06J2FindExistingAssignedQr_(sh, map, eventId, customerId, dong, ho);
  if (existing) {
    var existingUrl = String(existing.qrUrl || existing.signUrl || '').trim();
    return { status:'REUSED', reused:true, customerId:customerId, documentId:existing.documentId || '', documentNo:existing.documentNo || '', qrUrl:existingUrl, signUrl:existingUrl, qrImageUrl:fhB06J1QrImageUrl_(existingUrl), eventId:eventId, eventName:eventName, boothHint:existing.boothHint || boothHint, dong:dong, ho:ho, unitHint:existing.unitHint || (dong + '동 ' + ho + '호'), name:target.name || '', apartmentName:target.apartmentName || '' };
  }
  var now = new Date();
  var actor = String(options.actor || options.createdBy || '').trim() || 'ERP_FIELD_QR_BULK';
  var documentId = 'DOC_' + Utilities.getUuid().replace(/-/g, '').substring(0, 12).toUpperCase();
  var documentNo = fhB06J1DocumentNo_(sh);
  var base = fhB06J1SignBaseUrl_(env.config);
  var unitHint = dong + '동 ' + ho + '호';
  var url = base + '?mode=sign&documentId=' + encodeURIComponent(documentId) + '&fieldMode=QR&qrEntry=Y&eventName=' + encodeURIComponent(eventName) + '&boothHint=' + encodeURIComponent(boothHint) + '&unitHint=' + encodeURIComponent(unitHint) + '&dong=' + encodeURIComponent(dong) + '&ho=' + encodeURIComponent(ho);
  var rowObj = { documentId:documentId, documentNo:documentNo, documentType:'QR_SIGN', status:'READY_TO_SIGN', statusReason:'현장 지정형 QR 일괄 생성', eventId:eventId, vendorId:String(options.vendorId || '').trim(), customerId:customerId, saleId:'', contractId:'', installId:'', settlementId:'', approvalId:'', requestId:'', title:'QR 서명확인서', templateCode:'PDF_QR_SIGN', signMethod:'QR', qrType:'ASSIGNED', qrEntry:'Y', eventName:eventName, boothHint:boothHint, unitHint:unitHint, dong:dong, ho:ho, signUrl:url, qrUrl:url, createdAt:now, createdBy:actor, updatedAt:now, updatedBy:actor, notes:'ERP_B06J2_FIELD_QR_BULK_GENERATOR / customerId=' + customerId + ' / unit=' + unitHint };
  fhB06J1AppendObject_(sh, rowObj);
  return { status:'CREATED', reused:false, customerId:customerId, documentId:documentId, documentNo:documentNo, qrUrl:url, signUrl:url, qrImageUrl:fhB06J1QrImageUrl_(url), eventId:eventId, eventName:eventName, boothHint:boothHint, dong:dong, ho:ho, unitHint:unitHint, name:target.name || '', apartmentName:target.apartmentName || '' };
}
function bulkCreateAssignedFieldQrDocuments(payload) {
  payload = payload || {};
  var env = fhB06J1FieldQrSetup_();
  var eventId = String(payload.eventId || '').trim();
  if (!eventId) throw new Error('지정형 QR 일괄 생성은 행사 선택이 필수입니다.');
  var targetResult = fhB06J2GetRegularQrTargets({ eventId:eventId, aptName:payload.aptName || payload.apartmentName || '', dong:payload.dong || '', limit:payload.limit || 2000 });
  var targets = targetResult.targets || [];
  var headers = ['documentId','documentNo','documentType','status','statusReason','eventId','vendorId','customerId','saleId','contractId','installId','settlementId','approvalId','requestId','title','templateCode','signMethod','qrType','qrEntry','eventName','boothHint','unitHint','dong','ho','signUrl','qrUrl','createdAt','createdBy','updatedAt','updatedBy','notes'];
  var sh = fhB06J1EnsureSheet_(env.masterDb, 'SIGN_Documents', headers);
  var map = fhB06J1HeaderMap_(sh);
  var eventName = String(payload.eventName || '').trim() || fhB06J1GetEventName_(env.masterDb, eventId) || eventId;
  var options = { eventId:eventId, eventName:eventName, boothHint:String(payload.boothHint || '').trim(), vendorId:String(payload.vendorId || '').trim(), actor:String(payload.createdBy || payload.updatedBy || '').trim() || 'ERP_FIELD_QR_BULK' };
  var created = 0, reused = 0, errors = [];
  var results = [];
  targets.forEach(function(t, idx){
    try {
      var r = fhB06J4reateAssignedQrForTarget_(env, sh, map, t, options);
      if (r.reused) reused++; else created++;
      results.push(r);
    } catch (err) {
      errors.push({ index:idx + 1, customerId:t.customerId || '', dong:t.dong || '', ho:t.ho || '', message:(err && err.message) || String(err) });
    }
  });
  try {
    var logSh = fhB06J1EnsureSheet_(env.masterDb, 'SIGN_Document_Logs', ['logId','documentId','actionType','fromStatus','toStatus','actor','reason','createdAt']);
    fhB06J1AppendObject_(logSh, { logId:'LOG-' + Utilities.getUuid().replace(/-/g,'').substring(0,12).toUpperCase(), documentId:'BULK-' + eventId, actionType:'BULK_CREATE_ASSIGNED_FIELD_QR_SIGN_FROM_ERP', fromStatus:'', toStatus:'READY_TO_SIGN', actor:options.actor, reason:'현장 지정형 QR 일괄 생성 / created=' + created + ' / reused=' + reused + ' / errors=' + errors.length, createdAt:new Date() });
  } catch(e) {}
  return { ok:true, message:'지정형 QR 일괄 생성 완료', eventId:eventId, eventName:eventName, boothHint:options.boothHint, totalTargets:targets.length, createdCount:created, reusedCount:reused, errorCount:errors.length, results:results, errors:errors, buildNo:'v64-B06J33A' };
}
function testB06J2FieldQrBulkGeneratorPreflight_() {
  var env = fhB06J1FieldQrSetup_();
  var sh = fhB06J1EnsureSheet_(env.masterDb, 'SIGN_Documents', ['documentId','documentNo','documentType','status','eventId','customerId','qrType','qrEntry','eventName','boothHint','unitHint','dong','ho','signUrl','qrUrl','createdAt','createdBy','updatedAt','updatedBy']);
  return { ok:true, message:'B06J2 현장 QR 일괄 생성 사전점검 완료', data:{ masterDbId:env.masterDbId, sheet:sh.getName(), buildNo:'v64-B06J33A' }, errorCode:'', meta:{ buildNo:'OPS-UI-20260428-B06J5', at:new Date().toISOString() } };
}
function testB06J1FieldQrGeneratorPreflight_() {
  var env = fhB06J1FieldQrSetup_();
  var sh = fhB06J1EnsureSheet_(env.masterDb, 'SIGN_Documents', ['documentId','documentNo','documentType','status','eventId','qrType','qrEntry','eventName','boothHint','unitHint','dong','ho','signUrl','qrUrl','createdAt','createdBy','updatedAt','updatedBy']);
  return { ok:true, message:'B06J1 현장 QR 생성 사전점검 완료', data:{ masterDbId:env.masterDbId, sheet:sh.getName(), buildNo:'v64-B06J33A' }, errorCode:'', meta:{ buildNo:'OPS-UI-20260428-B06J5', at:new Date().toISOString() } };
}


/** B06J5 MEMBER PROMOTION SAFE
 * 준회원/현장등록 고객을 협의회/주관사/본사 판단으로 정회원 승격한다.
 * 원칙: customerId 기준 선택 고객만 처리, eventId + dong + ho 정회원 중복 차단, 승인/사유 로그 필수.
 */
function fhB06J5PromotionHeaders_(){ return ['requestId','customerId','eventId','dong','ho','beforeMemberType','afterMemberType','beforeCustomerType','afterCustomerType','beforeRegularCheck','afterRegularCheck','promotionSource','promotionReason','status','requestedBy','approvedBy','createdAt','approvedAt','updatedAt','updatedBy','meta']; }
function fhB06J5LogHeaders_(){ return ['logId','createdAt','createdBy','actionType','targetId','status','statusReason','beforeValue','afterValue','meta']; }
function fhB06J5Now_(){ return new Date(); }
function fhB06J5Actor_(){ try { return Session.getActiveUser().getEmail() || 'ERP_OPERATOR'; } catch(e){ return 'ERP_OPERATOR'; } }
function fhB06J5S_(v){ return String(v == null ? '' : v).trim(); }
function fhB06J5Norm_(v){ return fhB06J5S_(v).replace(/\s+/g,'').toLowerCase(); }
function fhB06J5NewId_(prefix){ return prefix + Utilities.formatDate(new Date(), Session.getScriptTimeZone() || 'Asia/Seoul', 'yyyyMMddHHmmss') + '-' + Math.floor(Math.random()*900+100); }
function fhB06J5CustomerSheet_(ss){ var names = ['ERP_고객관리','Customers','ERP_Customers']; for (var i=0;i<names.length;i++){ var sh=ss.getSheetByName(names[i]); if(sh) return sh; } return fhB06J1EnsureSheet_(ss, 'ERP_고객관리', ['customerId','eventId','vendorId','name','phone','email','memberType','customerType','regularCheck','eventType','qrSource','dong','hosu','aptName','address','status','statusReason','createdAt','createdBy','updatedAt','updatedBy']); }
function fhB06J5EnsureCustomerHeaders_(sh){ fhB06J1EnsureSheet_(sh.getParent(), sh.getName(), ['customerId','eventId','vendorId','name','phone','email','memberType','customerType','regularCheck','eventType','qrSource','dong','hosu','aptName','address','status','statusReason','promotionSource','promotionReason','promotedAt','promotedBy','createdAt','createdBy','updatedAt','updatedBy']); return fhB06J1HeaderMap_(sh); }
function fhB06J5RowObj_(map,row){ var o={}; Object.keys(map).forEach(function(h){ o[h]=row[map[h]]; }); return o; }
function fhB06J5FindCustomer_(sh,map,customerId){ if(!customerId || map.customerId == null || sh.getLastRow()<2) return null; var vals=sh.getRange(2,1,sh.getLastRow()-1,sh.getLastColumn()).getValues(); for(var i=vals.length-1;i>=0;i--){ if(fhB06J5S_(vals[i][map.customerId])===customerId) return { rowIndex:i+2, row:vals[i], obj:fhB06J5RowObj_(map,vals[i]) }; } return null; }
function fhB06J5FindDuplicateRegular_(sh,map,eventId,dong,ho,excludeCustomerId){ if(sh.getLastRow()<2) return null; var hoKey = map.hosu != null ? 'hosu' : (map.ho != null ? 'ho' : ''); if(map.eventId == null || map.dong == null || !hoKey || map.customerId == null) throw new Error('정회원 승격 필수 헤더 누락: eventId/dong/ho/customerId'); var vals=sh.getRange(2,1,sh.getLastRow()-1,sh.getLastColumn()).getValues(); var ev=fhB06J5Norm_(eventId), dg=fhB06J5Norm_(dong), hv=fhB06J5Norm_(ho); for(var i=vals.length-1;i>=0;i--){ var row=vals[i], cid=fhB06J5S_(row[map.customerId]); if(!cid || cid===excludeCustomerId) continue; var same = fhB06J5Norm_(row[map.eventId])===ev && fhB06J5Norm_(row[map.dong])===dg && fhB06J5Norm_(row[map[hoKey]])===hv; if(!same) continue; var mt = map.memberType!=null ? fhB06J5S_(row[map.memberType]).toUpperCase() : ''; var ct = map.customerType!=null ? fhB06J5S_(row[map.customerType]).toUpperCase() : ''; var rc = map.regularCheck!=null ? fhB06J5S_(row[map.regularCheck]).toUpperCase() : ''; if(mt==='REGULAR' || ct==='REGULAR' || rc==='CONFIRMED') return { customerId:cid, rowIndex:i+2, obj:fhB06J5RowObj_(map,row) }; } return null; }
function fhB06J5Set_(sh,rowIndex,map,key,value){ if(map[key]!=null) sh.getRange(rowIndex,map[key]+1).setValue(value==null?'':value); }
function fhB06J5AppendByHeader_(sheet,obj){ var map=fhB06J1HeaderMap_(sheet); var row=new Array(sheet.getLastColumn()).fill(''); Object.keys(obj||{}).forEach(function(k){ if(map[k]!=null) row[map[k]]=obj[k]==null?'':obj[k]; }); sheet.appendRow(row); }
function fhB06J5WriteSystemLog_(ss, actor, actionType, targetId, status, reason, beforeObj, afterObj){ try{ var sh=fhB06J1EnsureSheet_(ss,'SystemLogs',fhB06J5LogHeaders_()); fhB06J5AppendByHeader_(sh,{logId:'LOG-'+Utilities.getUuid().replace(/-/g,'').substring(0,12).toUpperCase(),createdAt:fhB06J5Now_(),createdBy:actor,actionType:actionType,targetId:targetId,status:status,statusReason:reason,beforeValue:JSON.stringify(beforeObj||{}),afterValue:JSON.stringify(afterObj||{}),meta:JSON.stringify({buildNo:'v64-B06J33A'})}); }catch(e){} }
function fhB06J5WriteApprovalAudit_(ss, actor, actionType, targetId, status, beforeObj, afterObj, reason, approvedBy){ try{ var sh=fhB06J1EnsureSheet_(ss,'ApprovalAudit',['auditId','actionType','targetId','status','actor','refId','beforeValue','afterValue','reason','approvedBy','createdAt']); fhB06J5AppendByHeader_(sh,{auditId:fhB06J5NewId_('AUD-'),actionType:actionType,targetId:targetId,status:status,actor:actor,refId:targetId,beforeValue:JSON.stringify(beforeObj||{}),afterValue:JSON.stringify(afterObj||{}),reason:reason,approvedBy:approvedBy||'',createdAt:fhB06J5Now_()}); }catch(e){} }
function fhB06J5CreatePromotionRequest_(ss, payload, status, beforeObj, afterObj, actor, approvedBy){ var sh=fhB06J1EnsureSheet_(ss,'CustomerPromotionRequests',fhB06J5PromotionHeaders_()); var requestId=fhB06J5NewId_('CPR-'), now=fhB06J5Now_(); fhB06J5AppendByHeader_(sh,{requestId:requestId,customerId:payload.customerId,eventId:payload.eventId,dong:payload.dong,ho:payload.hosu,beforeMemberType:beforeObj.memberType||'',afterMemberType:'REGULAR',beforeCustomerType:beforeObj.customerType||'',afterCustomerType:'REGULAR',beforeRegularCheck:beforeObj.regularCheck||'',afterRegularCheck:status==='APPROVED'?'CONFIRMED':'PROMOTION_REQUESTED',promotionSource:payload.promotionSource,promotionReason:payload.promotionReason,status:status,requestedBy:actor,approvedBy:approvedBy||'',createdAt:now,approvedAt:status==='APPROVED'?now:'',updatedAt:now,updatedBy:actor,meta:JSON.stringify({buildNo:'v64-B06J33A'})}); return requestId; }
function fhB06J5ValidatePromotionPayload_(payload){ payload=payload||{}; var p={ customerId:fhB06J5S_(payload.customerId), eventId:fhB06J5S_(payload.eventId), dong:fhB06J5S_(payload.dong), hosu:fhB06J5S_(payload.hosu||payload.ho), promotionSource:fhB06J5S_(payload.promotionSource||'FIELD_MANAGER_CONFIRM'), promotionReason:fhB06J5S_(payload.promotionReason||payload.reason) }; if(!p.customerId) throw new Error('정회원 승격은 선택된 customerId가 필요합니다.'); if(!p.eventId || !p.dong || !p.hosu) throw new Error('정회원 승격은 행사 + 동 + 호수(hosu)가 필요합니다.'); if(!p.promotionReason) throw new Error('정회원 승격 사유가 필요합니다.'); return p; }
function requestCustomerPromotion(payload){ var env=fhB06J1FieldQrSetup_(), ss=env.masterDb, actor=fhB06J5Actor_(), p=fhB06J5ValidatePromotionPayload_(payload||{}); var sh=fhB06J5CustomerSheet_(ss), map=fhB06J5EnsureCustomerHeaders_(sh), found=fhB06J5FindCustomer_(sh,map,p.customerId); if(!found) throw new Error('승격 요청 대상 고객을 찾지 못했습니다: '+p.customerId); var dup=fhB06J5FindDuplicateRegular_(sh,map,p.eventId,p.dong,p.hosu,p.customerId); if(dup) throw new Error('이미 해당 행사/동/호에 정회원이 존재합니다: '+dup.customerId); var before=found.obj, after={memberType:'REGULAR',customerType:'REGULAR',regularCheck:'PROMOTION_REQUESTED',eventId:p.eventId,dong:p.dong,ho:p.hosu}; var requestId=fhB06J5CreatePromotionRequest_(ss,p,'PENDING',before,after,actor,''); fhB06J5WriteSystemLog_(ss,actor,'CUSTOMER_PROMOTION_REQUEST',p.customerId,'PENDING',p.promotionReason,before,after); fhB06J5WriteApprovalAudit_(ss,actor,'CUSTOMER_PROMOTION_REQUEST',p.customerId,'PENDING',before,after,p.promotionReason,''); return {ok:true,message:'정회원 승격 요청 생성 완료: '+requestId,requestId:requestId,customerId:p.customerId,status:'PENDING',eventId:p.eventId,dong:p.dong,ho:p.hosu,buildNo:'v64-B06J33A'}; }
function promoteCustomerToRegular(payload){ var env=fhB06J1FieldQrSetup_(), ss=env.masterDb, actor=fhB06J5Actor_(), p=fhB06J5ValidatePromotionPayload_(payload||{}); var sh=fhB06J5CustomerSheet_(ss), map=fhB06J5EnsureCustomerHeaders_(sh), found=fhB06J5FindCustomer_(sh,map,p.customerId); if(!found) throw new Error('승격 대상 고객을 찾지 못했습니다: '+p.customerId); var dup=fhB06J5FindDuplicateRegular_(sh,map,p.eventId,p.dong,p.hosu,p.customerId); if(dup) throw new Error('이미 해당 행사/동/호에 정회원이 존재합니다: '+dup.customerId+' / 자동 승격을 중지했습니다.'); var before=found.obj, now=fhB06J5Now_(); var updates={eventId:p.eventId,dong:p.dong,ho:p.hosu,hosu:p.hosu,memberType:'REGULAR',customerType:'REGULAR',regularCheck:'CONFIRMED',status:'ACTIVE',statusReason:'정회원 승격: '+p.promotionSource,promotionSource:p.promotionSource,promotionReason:p.promotionReason,promotedAt:now,promotedBy:actor,updatedAt:now,updatedBy:actor}; Object.keys(updates).forEach(function(k){ fhB06J5Set_(sh,found.rowIndex,map,k,updates[k]); }); var after=Object.assign({},before,updates); var requestId=fhB06J5CreatePromotionRequest_(ss,p,'APPROVED',before,after,actor,actor); fhB06J5WriteSystemLog_(ss,actor,'CUSTOMER_PROMOTE_TO_REGULAR',p.customerId,'APPROVED',p.promotionReason,before,after); fhB06J5WriteApprovalAudit_(ss,actor,'CUSTOMER_PROMOTE_TO_REGULAR',p.customerId,'APPROVED',before,after,p.promotionReason,actor); return {ok:true,message:'정회원 즉시 승격 완료: '+p.customerId,requestId:requestId,customerId:p.customerId,status:'APPROVED',memberType:'REGULAR',customerType:'REGULAR',regularCheck:'CONFIRMED',eventId:p.eventId,dong:p.dong,ho:p.hosu,buildNo:'v64-B06J33A'}; }
function testB06J5MemberPromotionPreflight_(){ var env=fhB06J1FieldQrSetup_(), ss=env.masterDb; var c=fhB06J5CustomerSheet_(ss); fhB06J5EnsureCustomerHeaders_(c); fhB06J1EnsureSheet_(ss,'CustomerPromotionRequests',fhB06J5PromotionHeaders_()); fhB06J1EnsureSheet_(ss,'SystemLogs',fhB06J5LogHeaders_()); fhB06J1EnsureSheet_(ss,'ApprovalAudit',['auditId','actionType','targetId','status','actor','refId','beforeValue','afterValue','reason','approvedBy','createdAt']); return {ok:true,message:'B06J5 정회원 승격 사전점검 완료',sheets:[c.getName(),'CustomerPromotionRequests','SystemLogs','ApprovalAudit'],buildNo:'v64-B06J33A'}; }


/* ===== B06J7 SIGN 유입 고객 검색 + 판매등록 계약서 생성대상 보강 ===== */
function fhB06J7SheetByNames_(ss, names) {
  var out = [];
  (names || []).forEach(function(name){ try { var sh = ss.getSheetByName(name); if (sh) out.push(sh); } catch(e) {} });
  return out;
}
function fhB06J7HeaderMap_(sheet) {
  var headers = sheet.getRange(1,1,1,Math.max(sheet.getLastColumn(),1)).getValues()[0].map(function(h){ return String(h||'').trim(); });
  var map = {}; headers.forEach(function(h,i){ if(h) map[h]=i; });
  return { headers:headers, map:map };
}
function fhB06J7Pick_(obj, keys) {
  for (var i=0;i<(keys||[]).length;i++) { var k=keys[i]; if (obj && obj[k] !== undefined && obj[k] !== null && String(obj[k]).trim() !== '') return obj[k]; }
  return '';
}
function fhB06J7NormPhone_(v) { return String(v||'').replace(/[^0-9]/g,''); }
function fhB06J7RowsFromSheet_(sheet, limit) {
  if (!sheet || sheet.getLastRow() < 2) return [];
  var hm = fhB06J7HeaderMap_(sheet), headers = hm.headers;
  var last = sheet.getLastRow();
  var lastCol = sheet.getLastColumn();
  if (last < 2 || lastCol < 1) return [];
  // B06J7: 빈 행/서식/잔여 데이터 때문에 getLastRow가 크게 잡히면 뒤쪽 일부만 읽던 기존 방식이 실제 행을 놓쳤다.
  // 전체 행을 읽은 뒤 주요 헤더 기준으로 실제 데이터 행만 필터링한다.
  var vals = sheet.getRange(2, 1, last - 1, lastCol).getValues();
  var keyHeaders = ['customerId','saleId','documentId','installId','settlementId','name','customerName','phone','dong','hosu'];
  var keyIndexes = keyHeaders.map(function(k){ return hm.map[k]; }).filter(function(i){ return i !== undefined && i !== null; });
  if (!keyIndexes.length) keyIndexes = headers.map(function(h,i){ return h ? i : -1; }).filter(function(i){ return i >= 0; });
  var rows = vals.filter(function(row){
    for (var i=0;i<keyIndexes.length;i++) {
      var v = row[keyIndexes[i]];
      if (v !== undefined && v !== null && String(v).trim() !== '') return true;
    }
    return false;
  }).map(function(row){
    var o = {_sheetName:sheet.getName()};
    headers.forEach(function(h,i){ if(h) o[h]=row[i]; });
    return o;
  });
  var max = Math.max(Number(limit || 500), 1);
  return rows.slice(Math.max(0, rows.length - max));
}
function fhB06J7ReadRowsAll_(ctx, names, limit) {
  var rows=[]; fhB06J7SheetByNames_(ctx.masterDb, names).forEach(function(sh){ rows = rows.concat(fhB06J7RowsFromSheet_(sh, limit || 500)); }); return rows;
}
function fhB06J7NormalizeCustomer_(r) {
  var ho = String(fhB06J7Pick_(r,['ho','hosu','unit','unitNo']) || '').trim();
  var memberType = String(fhB06J7Pick_(r,['memberType','customerType','type']) || '').trim();
  var out = {
    customerId:String(fhB06J7Pick_(r,['customerId','memberId','id']) || '').trim(),
    eventId:String(fhB06J7Pick_(r,['eventId','eventID']) || '').trim(),
    vendorId:String(fhB06J7Pick_(r,['vendorId','vendorID']) || '').trim(),
    name:String(fhB06J7Pick_(r,['name','customerName','memberName','signerName','signedBy','userName']) || '').trim(),
    phone:String(fhB06J7Pick_(r,['phone','mobile','tel','customerPhone','signerPhone','contact']) || '').trim(),
    email:String(fhB06J7Pick_(r,['email','customerEmail','signerEmail']) || '').trim(),
    memberType:memberType,
    customerType:String(fhB06J7Pick_(r,['customerType','memberType']) || '').trim(),
    regularCheck:String(fhB06J7Pick_(r,['regularCheck','regularStatus']) || '').trim(),
    eventType:String(fhB06J7Pick_(r,['eventType','eventName','eventCategory']) || '').trim(),
    qrSource:String(fhB06J7Pick_(r,['qrSource','qrType','source','entryType']) || '').trim(),
    dong:String(fhB06J7Pick_(r,['dong','building','buildingNo']) || '').trim(),
    ho:ho,
    hosu:ho,
    aptName:String(fhB06J7Pick_(r,['aptName','apartmentName','apartment','complexName','단지명']) || '').trim(),
    address:String(fhB06J7Pick_(r,['address','addr']) || '').trim(),
    status:String(fhB06J7Pick_(r,['status','customerStatus']) || 'ACTIVE').trim(),
    createdAt:fhB06J7Pick_(r,['createdAt','requestedAt','signedAt']) || '',
    sourceSheet:r._sheetName || ''
  };
  if (!out.memberType && out.customerType) out.memberType = out.customerType;
  if (!out.memberType) out.memberType = 'ASSOCIATE';
  return out;
}
function fhB06J7ReadCustomersUnified_(limit) {
  var ctx = fhOpsUiB04EContext_({});
  var names = ['ERP_고객관리','Customers','ERP_Customers','SIGN_Customers','SIGN_QR_Customers','QR_Customers','SIGN_QR_Registrations','QR_Registrations'];
  var raw = fhB06J7ReadRowsAll_(ctx, names, limit || 5000);
  var seen={}, out=[];
  raw.forEach(function(r){ var c = fhB06J7NormalizeCustomer_(r); var key = c.customerId || [c.eventId,c.dong,c.ho,c.phone,c.name].join('|'); if (!key || seen[key]) return; seen[key]=true; out.push(c); });
  return out.reverse();
}
function searchCustomers(query){
  var q = String(query || '').toLowerCase().trim();
  var qPhone = fhB06J7NormPhone_(q);
  var rows = fhB06J7ReadCustomersUnified_(5000);
  if (!q) return rows.slice(0,50);
  return rows.filter(function(c){ var hay = [c.customerId,c.eventId,c.name,c.phone,c.email,c.memberType,c.customerType,c.regularCheck,c.eventType,c.qrSource,c.dong,c.ho,c.hosu,c.aptName,c.address,c.sourceSheet].join(' ').toLowerCase(); return hay.indexOf(q) >= 0 || (qPhone && fhB06J7NormPhone_(c.phone).indexOf(qPhone) >= 0); }).slice(0,80);
}
function getRecentCustomers(limit){ return fhB06J7ReadCustomersUnified_(Math.max(Number(limit||20),20)).slice(0, Number(limit||20)); }
function getCustomerDetail(customerId){
  var id = String(customerId || '').trim(); if (!id) throw new Error('customerId가 필요합니다.');
  var rows = fhB06J7ReadCustomersUnified_(5000); var found = rows.filter(function(c){ return String(c.customerId||'').trim() === id; })[0];
  if (!found) throw new Error('고객을 찾지 못했습니다: ' + id);
  var sales = []; try { sales = fhB06J7ReadSalesUnified_(5000).filter(function(s){ return String(s.customerId||'') === id; }).slice(0,20); } catch(e) {}
  return { customer:found, sales:sales, evidenceQueue:[], timeline:{ sales:sales, installs:[], evidence:[], cancellations:[] } };
}
function fhB06J7NormalizeSale_(r) {
  return { saleId:String(fhB06J7Pick_(r,['saleId','id']) || '').trim(), eventId:String(fhB06J7Pick_(r,['eventId']) || '').trim(), vendorId:String(fhB06J7Pick_(r,['vendorId']) || '').trim(), customerId:String(fhB06J7Pick_(r,['customerId']) || '').trim(), customerName:String(fhB06J7Pick_(r,['customerName','name','customer','clientName']) || '').trim(), productSummary:String(fhB06J7Pick_(r,['productSummary','productName','itemName']) || '').trim(), totalAmount:fhB06J7Pick_(r,['totalAmount','amount','saleAmount']) || '', status:String(fhB06J7Pick_(r,['status','saleStatus']) || 'SAVED').trim(), saleStage:String(fhB06J7Pick_(r,['saleStage','status']) || '').trim(), installStatus:String(fhB06J7Pick_(r,['installStatus']) || '').trim(), settlementStatus:String(fhB06J7Pick_(r,['settlementStatus']) || '').trim(), createdAt:fhB06J7Pick_(r,['createdAt']) || '', sourceSheet:r._sheetName || '' };
}
function fhB06J7ReadSalesUnified_(limit) {
  var ctx = fhOpsUiB04EContext_({}); var raw = fhB06J7ReadRowsAll_(ctx, ['Sales','ERP_판매관리','ERP_Sales'], limit || 5000); var seen={}, out=[];
  raw.forEach(function(r){ var s = fhB06J7NormalizeSale_(r); if (!s.saleId || seen[s.saleId]) return; seen[s.saleId]=true; out.push(s); }); return out.reverse();
}
function fhB06J7ReadDocsUnified_(limit) { var ctx = fhOpsUiB04EContext_({}); return fhB06J7ReadRowsAll_(ctx, ['SIGN_Documents','Documents','SIGN_DOCUMENTS'], limit || 5000); }
function fhOpsUiB05HetWorklists(payload) {
  try {
    var ctx = fhOpsUiB04EContext_(payload || {});
    var docs = fhB06J7ReadDocsUnified_(5000), sales = fhB06J7ReadSalesUnified_(5000), installs = fhB06J7ReadRowsAll_(ctx, ['Installs','ERP_설치관리','ERP_Installs','Installations'], 800), settlements = fhB06J7ReadRowsAll_(ctx, ['ERP_정산관리','Settlements','ERP_Settlements'], 800);
    var docIndex = fhOpsUiB05HuildDocIndex_(docs);
    var contractTargets = fhOpsUiB05HuildContractTargets_(sales, docIndex).slice(0, 50);
    var installConfirmTargets = fhOpsUiB05HuildInstallTargets_(installs, docIndex).slice(0, 50);
    var settlementConfirmTargets = fhOpsUiB05HuildSettlementConfirmTargets_(settlements, docIndex).slice(0, 50);
    var pdfTargets = fhOpsUiB05HuildPdfTargets_(docs).slice(0, 50), archiveTargets = fhOpsUiB05HuildArchiveTargets_(docs).slice(0, 50), qrSignTargets = fhOpsUiB05HuildQrSignTargets_(docs).slice(0, 50);
    var settlementActionGroups = fhOpsUiB05HuildSettlementActionGroups_(settlements, docs);
    var settlementActionTargets = [].concat(settlementActionGroups.requestTargets || [], settlementActionGroups.approveTargets || [], settlementActionGroups.paymentTargets || []).slice(0, 50);
    return fhOpsUiB04EOk_('B06J7 목록 자동조회 완료', { buildNo:'v64-B06J33A', counts:{ contractTargets:contractTargets.length, installConfirmTargets:installConfirmTargets.length, settlementConfirmTargets:settlementConfirmTargets.length, pdfTargets:pdfTargets.length, archiveTargets:archiveTargets.length, qrSignTargets:qrSignTargets.length, settlementActionTargets:settlementActionTargets.length }, auth:{ userEmail:ctx.userEmail, authMode:ctx.authMode, role:ctx.role, employeeId:ctx.employee&&ctx.employee.employeeId?ctx.employee.employeeId:'', employeeName:ctx.employee&&ctx.employee.userName?ctx.employee.userName:'' }, contractTargets:contractTargets, installConfirmTargets:installConfirmTargets, settlementConfirmTargets:settlementConfirmTargets, pdfTargets:pdfTargets, archiveTargets:archiveTargets, qrSignTargets:qrSignTargets, settlementRequestTargets:settlementActionGroups.requestTargets || [], settlementApproveTargets:settlementActionGroups.approveTargets || [], settlementPaymentTargets:settlementActionGroups.paymentTargets || [], settlementActionTargets:settlementActionTargets });
  } catch (err) { return fhOpsUiB04EFail_('B06J7 목록 자동조회 실패: ' + ((err && err.message) || String(err)), 'B06J7_WORKLIST_FAILED', { stack:err && err.stack ? err.stack : '' }); }
}
function fhOpsUiB05GetWorklists(payload) { return fhOpsUiB05HetWorklists(payload || {}); }
function testB06J7SignCustomerSyncSaleWorklistPreflight_(){ var ctx = fhOpsUiB04EContext_({}); var customers = fhB06J7ReadCustomersUnified_(20); var sales = fhB06J7ReadSalesUnified_(20); var wl = fhOpsUiB05HetWorklists({}); return fhOpsUiB04EOk_('B06J7 SIGN 유입고객/판매목록 사전점검 완료', { buildNo:'v64-B06J33A', customerPreview:customers.length, salesPreview:sales.length, contractTargets:wl && wl.data && wl.data.contractTargets ? wl.data.contractTargets.length : 0 }); }

/** B06J7 SIGN 유입 고객/판매목록 누락 보정 사전점검 */
function testB06J7SignCustomerSearchAndSaleWorklistPreflight_(){
  var customers = searchCustomers('test-준회원테스트-01');
  var allRecent = getRecentCustomers(50);
  var sales = fhB06J7ReadSalesUnified_(5000);
  var wl = fhOpsUiB05HetWorklists({});
  return fhOpsUiB04EOk_('B06J7 SIGN 유입고객 검색/판매목록 보정 사전점검 완료', {
    buildNo:'v64-B06J33A',
    testAssociateSearchCount: customers.length,
    recentCustomerCount: allRecent.length,
    salesCount: sales.length,
    contractTargets: wl && wl.data && wl.data.contractTargets ? wl.data.contractTargets.length : 0,
    customerPreview: customers.slice(0,5)
  });
}


/**
 * FEELHAUS ERP v64-B06J33A CUSTOMER_SEARCH_REAL_SHEET_FIX_SAFE
 * 목적:
 * 1) ERP_고객관리 실제 시트 1순위 고객 검색
 * 2) SIGN 유입 준회원 ASSOCIATE / CUS_ 형식 검색 허용
 * 3) 판매등록 후 계약서 생성대상 실제 DB 기준 조회 보정
 *
 * 주의:
 * - 이 파일은 기존 기능 삭제 없이 추가하는 점검패치 후보입니다.
 * - 기존 프론트 호출 함수명은 실제 Code.js 확인 후 아래 public 함수로 연결해야 합니다.
 * - 배포 전 erpB06J8_runSelfTest() 실행 결과 ok=true 확인 필요.
 */

var FEELHAUS_B06J8 = {
  BUILD: 'ERP_v64_B06J9_HOSU_STANDARD_RESTORE_SAFE',
  SETUP_DB_ID: '17VMSpgSZCvIrUlgcw8yCNcnl8WQWo2IcRf5tDCcuJGM',
  CONFIG_SHEET_NAME: 'SystemConfig',
  MASTER_CONFIG_KEYS: ['FEELHAUS_DB_MASTER', 'FEELHAUS_DB_MASTER_ID', 'MASTER_DB_ID', 'DB_MASTER_ID', 'MASTER_SPREADSHEET_ID', 'MASTER_DB', 'MASTER_ID', 'DB_MASTER', 'FEELHAUS_MASTER_DB_ID'],
  CUSTOMER_SHEETS: ['ERP_고객관리', 'Customers', '고객관리'],
  SALE_SHEETS: ['ERP_판매관리', 'Sales', 'ERP_Sales', '판매관리'],
  DOCUMENT_SHEETS: ['SIGN_Documents', 'Documents', 'ERP_문서관리'],
  TEST_CUSTOMER_ID: 'CUS_C64368B3F242',
  TEST_CUSTOMER_NAME: 'test-준회원테스트-01',
  TEST_CUSTOMER_PHONE: '010-4111-2522'
};

function erp_b06j8_getBuildInfo() {
  return erpB06J8_response_(true, 'B06J8 점검패치 로드 완료', {
    build: FEELHAUS_B06J8.BUILD,
    sourceDb: 'FEELHAUS_SETUP_DB > SystemConfig',
    masterDb: 'FEELHAUS_DB_MASTER',
    customerSheetPriority: FEELHAUS_B06J8.CUSTOMER_SHEETS,
    saleSheetPriority: FEELHAUS_B06J8.SALE_SHEETS
  });
}

/**
 * 프론트에서 고객 검색/수정 카드가 호출해야 할 서버 함수.
 * payload 예: { query:'test-준회원테스트-01', eventId:'EVT-...', limit:20, debug:true }
 */
function erp_b06j8_searchCustomers(payload) {
  payload = payload || {};
  var query = erpB06J8_text_(payload.query || payload.keyword || payload.searchText || payload.q || '');
  var eventId = erpB06J8_text_(payload.eventId || '');
  var limit = Number(payload.limit || 30);
  if (!limit || limit < 1) limit = 30;

  var debug = {
    build: FEELHAUS_B06J8.BUILD,
    searchTerm: query,
    eventIdFilter: eventId,
    checkedSheets: [],
    totalRows: 0,
    validCustomerRows: 0,
    matchedBeforeDedupe: 0,
    excludeReasons: {}
  };

  var ss = erpB06J8_getMasterSpreadsheet_();
  var rows = [];

  FEELHAUS_B06J8.CUSTOMER_SHEETS.forEach(function(sheetName) {
    var sheet = ss.getSheetByName(sheetName);
    if (!sheet) {
      debug.checkedSheets.push({ sheetName: sheetName, exists: false });
      return;
    }

    var table = erpB06J8_readTable_(sheet);
    debug.checkedSheets.push({ sheetName: sheetName, exists: true, dataRows: table.rows.length, headers: table.headers });
    debug.totalRows += table.rows.length;

    table.rows.forEach(function(row, idx) {
      var customerId = erpB06J8_pick_(row, ['customerId', 'customerID', '고객ID', '고객Id']);
      if (!customerId) {
        erpB06J8_addReason_(debug.excludeReasons, 'NO_CUSTOMER_ID');
        return;
      }
      debug.validCustomerRows++;

      var normalized = erpB06J8_normalizeCustomerRow_(row, sheetName, idx + 2);
      if (eventId && normalized.eventId && erpB06J8_norm_(normalized.eventId) !== erpB06J8_norm_(eventId)) {
        erpB06J8_addReason_(debug.excludeReasons, 'EVENT_ID_NOT_MATCH');
        return;
      }

      var haystack = [
        normalized.customerId,
        normalized.name,
        normalized.phone,
        normalized.email,
        normalized.dong,
        normalized.ho,
        normalized.hosu,
        normalized.eventId,
        normalized.notes,
        normalized.memberType,
        normalized.customerType,
        normalized.status
      ].map(erpB06J8_norm_).join(' ');

      var matched = !query || haystack.indexOf(erpB06J8_norm_(query)) !== -1;
      if (!matched) {
        erpB06J8_addReason_(debug.excludeReasons, 'QUERY_NOT_MATCH');
        return;
      }
      debug.matchedBeforeDedupe++;
      rows.push(normalized);
    });
  });

  var deduped = erpB06J8_dedupeBy_(rows, 'customerId').slice(0, limit);
  return erpB06J8_response_(true, deduped.length ? '고객 검색 완료' : '검색 결과가 없습니다.', {
    rows: deduped,
    count: deduped.length,
    debug: debug
  });
}

/** 테스트 고객 직접 검색. */
// B06J28: legacy erpB06J function removed: erpB06J8_debugFindCustomer_


/**
 * 판매등록 후 계약서 생성대상 조회 함수.
 * 문서가 없는 saleId만 반환한다.
 */
function erp_b06j8_getContractWorklist(payload) {
  payload = payload || {};
  var eventId = erpB06J8_text_(payload.eventId || '');
  var limit = Number(payload.limit || 50);
  if (!limit || limit < 1) limit = 50;

  var ss = erpB06J8_getMasterSpreadsheet_();
  var existingDocSaleIds = erpB06J8_getExistingContractSaleIds_(ss);
  var debug = {
    build: FEELHAUS_B06J8.BUILD,
    eventIdFilter: eventId,
    checkedSaleSheets: [],
    existingContractSaleIds: Object.keys(existingDocSaleIds).length,
    excludeReasons: {}
  };
  var rows = [];

  FEELHAUS_B06J8.SALE_SHEETS.forEach(function(sheetName) {
    var sheet = ss.getSheetByName(sheetName);
    if (!sheet) {
      debug.checkedSaleSheets.push({ sheetName: sheetName, exists: false });
      return;
    }
    var table = erpB06J8_readTable_(sheet);
    debug.checkedSaleSheets.push({ sheetName: sheetName, exists: true, dataRows: table.rows.length, headers: table.headers });

    table.rows.forEach(function(row, idx) {
      var saleId = erpB06J8_pick_(row, ['saleId', 'saleID', '판매ID', '판매Id']);
      if (!saleId) {
        erpB06J8_addReason_(debug.excludeReasons, 'NO_SALE_ID');
        return;
      }
      var customerId = erpB06J8_pick_(row, ['customerId', 'customerID', '고객ID']);
      if (!customerId) {
        erpB06J8_addReason_(debug.excludeReasons, 'NO_CUSTOMER_ID');
        return;
      }
      var rowEventId = erpB06J8_pick_(row, ['eventId', 'eventID', '행사ID']);
      if (eventId && rowEventId && erpB06J8_norm_(rowEventId) !== erpB06J8_norm_(eventId)) {
        erpB06J8_addReason_(debug.excludeReasons, 'EVENT_ID_NOT_MATCH');
        return;
      }
      if (existingDocSaleIds[erpB06J8_norm_(saleId)]) {
        erpB06J8_addReason_(debug.excludeReasons, 'CONTRACT_DOCUMENT_EXISTS');
        return;
      }
      var status = erpB06J8_normalizeStatus_(erpB06J8_pick_(row, ['status', 'saleStatus', '상태']));
      rows.push({
        sourceSheet: sheetName,
        rowNumber: idx + 2,
        saleId: saleId,
        eventId: rowEventId,
        customerId: customerId,
        customerName: erpB06J8_pick_(row, ['name', 'customerName', '고객명']),
        phone: erpB06J8_pick_(row, ['phone', 'customerPhone', '전화번호']),
        totalAmount: erpB06J8_pick_(row, ['totalAmount', 'saleAmount', 'amount', '총금액', '판매금액']),
        status: status,
        createdAt: erpB06J8_pick_(row, ['createdAt', 'createdDate', '등록일시', '생성일시']),
        raw: row
      });
    });
  });

  rows = erpB06J8_dedupeBy_(rows, 'saleId').slice(0, limit);
  return erpB06J8_response_(true, rows.length ? '계약서 생성대상 조회 완료' : '계약서 생성대상이 없습니다.', {
    rows: rows,
    count: rows.length,
    debug: debug
  });
}

// B06J28: legacy run/test function removed: erpB06J8_runSelfTest_


// B06J28: legacy erpB06J function removed: erpB06J8_getMasterSpreadsheet_


// B06J28: legacy erpB06J function removed: erpB06J8_findMasterIdFromSystemConfig_


// B06J28: legacy erpB06J function removed: erpB06J8_collectSystemConfigKeys_


// B06J28: legacy erpB06J function removed: erpB06J8_debugSystemConfig_


// B06J28: legacy erpB06J function removed: erpB06J8_readTable_


// B06J28: legacy erpB06J function removed: erpB06J8_normalizeCustomerRow_


// B06J28: legacy erpB06J function removed: erpB06J8_getExistingContractSaleIds_


// B06J28: legacy erpB06J function removed: erpB06J8_pick_


// B06J28: legacy erpB06J function removed: erpB06J8_text_


// B06J28: legacy erpB06J function removed: erpB06J8_norm_


// B06J28: legacy erpB06J function removed: erpB06J8_normalizeMemberType_


// B06J28: legacy erpB06J function removed: erpB06J8_normalizeStatus_


// B06J28: legacy erpB06J function removed: erpB06J8_dedupeBy_


// B06J28: legacy erpB06J function removed: erpB06J8_addReason_


// B06J28: legacy erpB06J function removed: erpB06J8_response_



/* ===== B06J8 FRONT COMPATIBILITY OVERRIDES - KEEP LAST =====
 * Index.html 기존 호출명(searchCustomers/getRecentCustomers/getCustomerDetail)을 유지하면서
 * 내부 조회만 B06J8 실제시트 검색 엔진으로 연결한다.
 */
function fhB06J8_toSearchRows_(res) {
  if (res && res.ok && res.data && res.data.rows) return res.data.rows;
  return [];
}

function searchCustomers(query) {
  var res = erp_b06j8_searchCustomers({ query: query || '', limit: 80, debug: true });
  return fhB06J8_toSearchRows_(res);
}

function getRecentCustomers(limit) {
  var res = erp_b06j8_searchCustomers({ query: '', limit: Number(limit || 20), debug: true });
  return fhB06J8_toSearchRows_(res);
}

function getCustomerDetail(customerId) {
  var id = erpB06J8_text_(customerId);
  if (!id) throw new Error('customerId가 필요합니다.');
  var res = erp_b06j8_searchCustomers({ query: id, limit: 5, debug: true });
  var rows = fhB06J8_toSearchRows_(res);
  var found = null;
  for (var i = 0; i < rows.length; i++) {
    if (erpB06J8_norm_(rows[i].customerId) === erpB06J8_norm_(id)) { found = rows[i]; break; }
  }
  if (!found && rows.length) found = rows[0];
  if (!found) throw new Error('고객을 찾지 못했습니다: ' + id);
  var sales = [];
  try {
    sales = fhB06J8_readSalesUnified_(5000).filter(function(s){ return erpB06J8_norm_(s.customerId) === erpB06J8_norm_(id); }).slice(0, 20);
  } catch(e) {}
  return { customer: found, sales: sales, evidenceQueue: [], timeline: { sales: sales, installs: [], evidence: [], cancellations: [] } };
}

function fhB06J8_readSalesUnified_(limit) {
  var ss = erpB06J8_getMasterSpreadsheet_();
  var rows = [];
  FEELHAUS_B06J8.SALE_SHEETS.forEach(function(sheetName){
    var sh = ss.getSheetByName(sheetName);
    if (!sh) return;
    var table = erpB06J8_readTable_(sh);
    table.rows.forEach(function(row, idx){
      var saleId = erpB06J8_pick_(row, ['saleId','saleID','판매ID','판매Id']);
      if (!saleId) return;
      rows.push({
        sourceSheet: sheetName,
        rowNumber: idx + 2,
        saleId: saleId,
        eventId: erpB06J8_pick_(row, ['eventId','eventID','행사ID','행사Id']),
        vendorId: erpB06J8_pick_(row, ['vendorId','vendorID','업체ID','업체Id']),
        customerId: erpB06J8_pick_(row, ['customerId','customerID','고객ID','고객Id']),
        customerName: erpB06J8_pick_(row, ['customerName','name','고객명','이름']),
        phone: erpB06J8_pick_(row, ['phone','customerPhone','전화번호','휴대폰']),
        productSummary: erpB06J8_pick_(row, ['productSummary','productName','itemName','상품명','품목명']),
        totalAmount: erpB06J8_pick_(row, ['totalAmount','saleAmount','amount','총금액','판매금액']),
        status: erpB06J8_normalizeStatus_(erpB06J8_pick_(row, ['status','saleStatus','상태'])),
        saleStage: erpB06J8_pick_(row, ['saleStage','status','saleStatus','상태']),
        installStatus: erpB06J8_pick_(row, ['installStatus','설치상태']),
        settlementStatus: erpB06J8_pick_(row, ['settlementStatus','정산상태']),
        createdAt: erpB06J8_pick_(row, ['createdAt','createdDate','등록일시','생성일시']),
        raw: row
      });
    });
  });
  return erpB06J8_dedupeBy_(rows, 'saleId').reverse().slice(0, Number(limit || 5000));
}

function fhB06J7ReadSalesUnified_(limit) { return fhB06J8_readSalesUnified_(limit || 5000); }
function fhB06J7ReadCustomersUnified_(limit) { return getRecentCustomers(limit || 5000); }
function fhB06J7ReadDocsUnified_(limit) {
  var ss = erpB06J8_getMasterSpreadsheet_();
  var rows = [];
  FEELHAUS_B06J8.DOCUMENT_SHEETS.forEach(function(sheetName){
    var sh = ss.getSheetByName(sheetName);
    if (!sh) return;
    var table = erpB06J8_readTable_(sh);
    table.rows.forEach(function(row){ row._sheetName = sheetName; rows.push(row); });
  });
  return rows.slice(0, Number(limit || 5000));
}

function fhOpsUiB05HetWorklists(payload) {
  try {
    var res = erp_b06j8_getContractWorklist(payload || {});
    var targets = fhB06J8_toSearchRows_(res);
    return {
      ok: true,
      message: 'B06J8 목록 자동조회 완료',
      data: {
        buildNo: FEELHAUS_B06J8.BUILD,
        counts: { contractTargets: targets.length, installConfirmTargets: 0, settlementConfirmTargets: 0, pdfTargets: 0, archiveTargets: 0, qrSignTargets: 0, settlementActionTargets: 0 },
        contractTargets: targets,
        installConfirmTargets: [],
        settlementConfirmTargets: [],
        pdfTargets: [],
        archiveTargets: [],
        qrSignTargets: [],
        settlementRequestTargets: [],
        settlementApproveTargets: [],
        settlementPaymentTargets: [],
        settlementActionTargets: [],
        debug: res && res.data ? res.data.debug : {}
      },
      errorCode: '',
      meta: { buildNo: FEELHAUS_B06J8.BUILD, at: new Date().toISOString() }
    };
  } catch (err) {
    return { ok:false, message:'B06J8 목록 자동조회 실패: ' + ((err && err.message) || String(err)), data:{ stack:(err && err.stack) || '' }, errorCode:'B06J8_WORKLIST_FAILED', meta:{ buildNo:FEELHAUS_B06J8.BUILD, at:new Date().toISOString() } };
  }
}
function fhOpsUiB05GetWorklists(payload) { return fhOpsUiB05HetWorklists(payload || {}); }
function testB06J8CustomerSearchRealSheetPreflight_() { return erpB06J8_runSelfTest(); }




/* ===== B06J9 HOSU STANDARD RESTORE SAFE - KEEP LAST =====
 * ERP_고객관리 표준 호수 헤더는 hosu로 고정한다.
 * ho는 외부 입력/과거 잔여 헤더 호환용 alias로만 읽고 신규 저장/수정/업로드에는 쓰지 않는다.
 */
var FEELHAUS_B06J9 = { BUILD:'ERP_v64_B06J9_HOSU_STANDARD_RESTORE_SAFE', CUSTOMER_SHEET:'ERP_고객관리' };
function fhB06J9_customerHeaders_(){ return ['customerId','eventId','vendorId','name','phone','email','memberType','customerType','regularCheck','eventType','qrSource','dong','hosu','aptName','address','status','statusReason','createdAt','createdBy','updatedAt','updatedBy','memo','notes','promotionSource','promotionReason','promotedAt','promotedBy']; }
function fhB06J9_promotionHeaders_(){ return ['requestId','customerId','eventId','dong','hosu','beforeMemberType','afterMemberType','beforeCustomerType','afterCustomerType','beforeRegularCheck','afterRegularCheck','promotionSource','promotionReason','status','requestedBy','approvedBy','createdAt','approvedAt','updatedAt','updatedBy','meta']; }
function fhB06J9_s_(v){ return String(v == null ? '' : v).trim(); }
function fhB06J9_norm_(v){ return fhB06J9_s_(v).replace(/\s+/g,'').toLowerCase(); }
function fhB06J9_hosu_(obj){ obj=obj||{}; return fhB06J9_s_(obj.hosu || obj.ho || obj.unit || obj.unitNo || obj['호수'] || obj['호']); }
function fhB06J9_cell_(row, idx, key){ return idx && idx[key] != null ? fhB06J9_s_(row[idx[key]]) : ''; }
function fhB06J9_rowHosu_(row, idx){ return fhB06J9_cell_(row, idx, 'hosu') || fhB06J9_cell_(row, idx, 'ho'); }
function fhB06J9_toObj_(header, row){ var o={}; (header||[]).forEach(function(h,i){ o[h]=row[i]||''; }); if(!o.hosu && o.ho) o.hosu=o.ho; o.ho=o.hosu || o.ho || ''; return o; }

function findRegularCustomerByEventDongHo_(sheetName, headers, payload){
  var pack=getCustomerSheetPack_(sheetName||FEELHAUS_B06J9.CUSTOMER_SHEET, headers||fhB06J9_customerHeaders_());
  if(pack.values.length<2) return null;
  var incoming={eventId:fhB06J9_norm_(payload&&payload.eventId),dong:fhB06J9_norm_(payload&&payload.dong),hosu:fhB06J9_norm_(fhB06J9_hosu_(payload))};
  if(!incoming.eventId||!incoming.dong||!incoming.hosu) return null;
  for(var r=pack.values.length-1;r>=1;r--){
    var row=pack.values[r], cid=fhB06J9_cell_(row,pack.idx,'customerId');
    if(!cid) continue;
    if(fhB06J9_norm_(fhB06J9_cell_(row,pack.idx,'eventId'))===incoming.eventId &&
       fhB06J9_norm_(fhB06J9_cell_(row,pack.idx,'dong'))===incoming.dong &&
       fhB06J9_norm_(fhB06J9_rowHosu_(row,pack.idx))===incoming.hosu){
      return {rowNumber:r+1,row:row,header:pack.header,idx:pack.idx,customerId:cid,matchType:'EVENT_DONG_HOSU'};
    }
  }
  return null;
}

function findAssociateCustomerSafely_(sheetName, headers, payload){
  var pack=getCustomerSheetPack_(sheetName||FEELHAUS_B06J9.CUSTOMER_SHEET, headers||fhB06J9_customerHeaders_());
  if(pack.values.length<2) return null;
  var incoming={phone:normalizeCustomerMatchPhone_(payload&&payload.phone),email:normalizeCustomerMatchText_(payload&&payload.email),name:normalizeCustomerMatchText_(payload&&payload.name),dong:normalizeCustomerMatchText_(payload&&payload.dong),hosu:normalizeCustomerMatchText_(fhB06J9_hosu_(payload))};
  if(isCompleteCustomerPhoneForMatch_(incoming.phone)){
    for(var r2=pack.values.length-1;r2>=1;r2--){ var row2=pack.values[r2], phone2=normalizeCustomerMatchPhone_(fhB06J9_cell_(row2,pack.idx,'phone')); if(isCompleteCustomerPhoneForMatch_(phone2)&&phone2===incoming.phone) return {rowNumber:r2+1,row:row2,header:pack.header,idx:pack.idx,customerId:fhB06J9_cell_(row2,pack.idx,'customerId'),matchType:'PHONE'}; }
  }
  if(incoming.email){
    for(var r3=pack.values.length-1;r3>=1;r3--){ var row3=pack.values[r3], email3=normalizeCustomerMatchText_(fhB06J9_cell_(row3,pack.idx,'email')); if(email3&&email3===incoming.email) return {rowNumber:r3+1,row:row3,header:pack.header,idx:pack.idx,customerId:fhB06J9_cell_(row3,pack.idx,'customerId'),matchType:'EMAIL'}; }
  }
  if(incoming.name&&incoming.dong&&incoming.hosu){
    for(var r4=pack.values.length-1;r4>=1;r4--){ var row4=pack.values[r4]; if(normalizeCustomerMatchText_(fhB06J9_cell_(row4,pack.idx,'name'))===incoming.name&&normalizeCustomerMatchText_(fhB06J9_cell_(row4,pack.idx,'dong'))===incoming.dong&&normalizeCustomerMatchText_(fhB06J9_rowHosu_(row4,pack.idx))===incoming.hosu) return {rowNumber:r4+1,row:row4,header:pack.header,idx:pack.idx,customerId:fhB06J9_cell_(row4,pack.idx,'customerId'),matchType:'NAME_DONG_HOSU'}; }
  }
  return null;
}

function findRegularCustomerForQuick(payload){
  syncSystemConfig(); payload=payload||{};
  var eventId=fhB06J9_s_(payload.eventId), dong=fhB06J9_s_(payload.dong), hosu=fhB06J9_hosu_(payload);
  if(!eventId||!dong||!hosu) throw new Error('정회원 기존 고객 찾기는 eventId + dong + hosu가 모두 필요합니다.');
  var found=findRegularCustomerByEventDongHo_(FEELHAUS_B06J9.CUSTOMER_SHEET,fhB06J9_customerHeaders_(),{eventId:eventId,dong:dong,hosu:hosu});
  if(!found||!found.customerId) return {ok:true,found:false,matchType:'EVENT_DONG_HOSU',eventId:eventId,dong:dong,hosu:hosu,ho:hosu,message:'기존 고객 없음. 신규 고객 생성 시 새 customerId를 발급합니다.'};
  var obj=fhB06J9_toObj_(found.header,found.row);
  return {ok:true,found:true,customer:obj,customerId:found.customerId,matchType:'EVENT_DONG_HOSU',eventId:eventId,dong:dong,hosu:hosu,ho:hosu,overwriteBlocked:true,message:'기존 고객 확인: '+found.customerId+' / 고객정보 자동 덮어쓰기 안 함'};
}

function updateCustomerById(payload){
  syncSystemConfig(); payload=payload||{};
  var sheetName=FEELHAUS_B06J9.CUSTOMER_SHEET, headers=fhB06J9_customerHeaders_(), customerId=fhB06J9_s_(payload.customerId);
  if(!customerId) throw new Error('수정할 customerId가 필요합니다. 고객 검색에서 고객을 먼저 선택하세요.');
  var found=findCustomerById_(sheetName,headers,customerId);
  if(!found) throw new Error('수정 대상 고객을 찾지 못했습니다: '+customerId);
  var memberType=normalizeMemberType_(payload.memberType), customerType=fhB06J9_s_(payload.customerType)||memberType, hosuValue=fhB06J9_hosu_(payload), now=ts();
  var updates={eventId:fhB06J9_s_(payload.eventId),vendorId:fhB06J9_s_(payload.vendorId),name:fhB06J9_s_(payload.name),phone:normalizePhone(payload.phone),email:fhB06J9_s_(payload.email),memberType:memberType,customerType:customerType,regularCheck:fhB06J9_s_(payload.regularCheck)||(memberType==='REGULAR'?'PENDING':''),eventType:fhB06J9_s_(payload.eventType),qrSource:fhB06J9_s_(payload.qrSource),dong:fhB06J9_s_(payload.dong),hosu:hosuValue,aptName:fhB06J9_s_(payload.aptName||payload.apt),address:fhB06J9_s_(payload.address),status:fhB06J9_s_(payload.status)||'ACTIVE',statusReason:fhB06J9_s_(payload.statusReason),memo:fhB06J9_s_(payload.memo),notes:fhB06J9_s_(payload.notes),updatedAt:now,updatedBy:fhB06J9_s_(payload.updatedBy)||'system'};
  updateCustomerById_(sheetName,found,updates);
  return {ok:true,customerId:customerId,updated:true,eventId:updates.eventId,dong:updates.dong,hosu:updates.hosu,ho:updates.hosu,memberType:memberType,customerType:customerType,regularCheck:updates.regularCheck,message:'고객 수정 완료: '+customerId};
}

function saveCustomer(payload){
  syncSystemConfig(); payload=payload||{};
  var sheetName=FEELHAUS_B06J9.CUSTOMER_SHEET, headers=fhB06J9_customerHeaders_(), memberType=normalizeMemberType_(payload.memberType), customerType=fhB06J9_s_(payload.customerType)||memberType, regularCheck=fhB06J9_s_(payload.regularCheck)||(memberType==='REGULAR'?'PENDING':''), hosuValue=fhB06J9_hosu_(payload);
  if(memberType==='REGULAR'&&(!fhB06J9_s_(payload.eventId)||!fhB06J9_s_(payload.dong)||!hosuValue)) throw new Error('정회원은 행사 선택 + 동 + 호수(hosu)가 필수입니다. 이름/전화번호는 선택값입니다.');
  if(memberType==='ASSOCIATE'&&!fhB06J9_s_(payload.name)&&!fhB06J9_s_(payload.phone)) throw new Error('준회원은 이름 또는 전화번호 중 하나가 필요합니다.');
  var now=ts(), updateObj={eventId:fhB06J9_s_(payload.eventId),vendorId:fhB06J9_s_(payload.vendorId),name:fhB06J9_s_(payload.name),phone:normalizePhone(payload.phone),email:fhB06J9_s_(payload.email),memberType:memberType,customerType:customerType,regularCheck:regularCheck,eventType:fhB06J9_s_(payload.eventType),qrSource:fhB06J9_s_(payload.qrSource),dong:fhB06J9_s_(payload.dong),hosu:hosuValue,aptName:fhB06J9_s_(payload.aptName||payload.apt),address:fhB06J9_s_(payload.address),status:'ACTIVE',statusReason:fhB06J9_s_(payload.statusReason),memo:fhB06J9_s_(payload.memo),notes:fhB06J9_s_(payload.notes),updatedAt:now,updatedBy:fhB06J9_s_(payload.updatedBy)||'system'};
  var found=(memberType==='REGULAR')?findRegularCustomerByEventDongHo_(sheetName,headers,{eventId:updateObj.eventId,dong:updateObj.dong,hosu:updateObj.hosu}):findAssociateCustomerSafely_(sheetName,headers,updateObj);
  if(found&&found.customerId) return {ok:true,customerId:found.customerId,reused:true,updated:false,overwriteBlocked:true,matchType:found.matchType,eventId:updateObj.eventId,dong:updateObj.dong,hosu:updateObj.hosu,ho:updateObj.hosu,memberType:memberType,customerType:customerType,regularCheck:regularCheck,message:'기존 고객 확인: '+found.customerId+' / 기준: '+found.matchType+' / 고객정보 자동 덮어쓰기 안 함'};
  var id='CUS_'+Utilities.getUuid().replace(/-/g,'').substring(0,12).toUpperCase();
  appendObjectByHeader_(sheetName,headers,{customerId:id,eventId:updateObj.eventId,vendorId:updateObj.vendorId,name:updateObj.name,phone:updateObj.phone,email:updateObj.email,memberType:memberType,customerType:customerType,regularCheck:regularCheck,eventType:updateObj.eventType,qrSource:updateObj.qrSource,dong:updateObj.dong,hosu:updateObj.hosu,aptName:updateObj.aptName,address:updateObj.address,status:'ACTIVE',statusReason:'',memo:updateObj.memo,notes:updateObj.notes,createdAt:now,createdBy:fhB06J9_s_(payload.createdBy)||'system',updatedAt:now,updatedBy:fhB06J9_s_(payload.updatedBy)||'system'});
  return {ok:true,customerId:id,reused:false,created:true,matchType:'NEW',eventId:updateObj.eventId,dong:updateObj.dong,hosu:updateObj.hosu,ho:updateObj.hosu,memberType:memberType,customerType:customerType,regularCheck:regularCheck,message:'신규 고객 생성 완료: '+id};
}

function parseRegularMemberUpload_(rawText){
  var text=fhB06J9_s_(rawText||'');
  if(!text) return {rows:[],errors:[{rowNo:0,status:'ERROR',message:'업로드 내용이 비어 있습니다.'}]};
  var lines=text.split(/\r?\n/).filter(function(line){return fhB06J9_s_(line);});
  if(lines.length<2) return {rows:[],errors:[{rowNo:1,status:'ERROR',message:'헤더와 데이터가 필요합니다.'}]};
  var rawHeaders=lines[0].split(/\t|,/).map(function(h){return fhB06J9_s_(h);});
  var alias={'apartmentName':'aptName','aptName':'aptName','아파트':'aptName','단지명':'aptName','dong':'dong','동':'dong','hosu':'hosu','ho':'hosu','호':'hosu','호수':'hosu','name':'name','이름':'name','성명':'name','phone':'phone','tel':'phone','mobile':'phone','전화':'phone','전화번호':'phone','휴대폰':'phone','휴대폰번호':'phone','email':'email','이메일':'email','address':'address','주소':'address','memo':'memo','메모':'memo','notes':'notes','비고':'notes'};
  var mapped=rawHeaders.map(function(h){return alias[h]||alias[h.toLowerCase()]||h;});
  if(mapped.indexOf('dong')<0||mapped.indexOf('hosu')<0) throw new Error('정회원 DB 업로드 첫 줄에는 동(dong/동)과 호수(hosu/ho/호/호수) 헤더가 반드시 필요합니다. 표준 저장 헤더는 hosu입니다.');
  var rows=[], errors=[];
  for(var i=1;i<lines.length;i++){ var cols=lines[i].split(/\t|,/), obj={sourceRow:i+1}; mapped.forEach(function(k,idx){obj[k]=fhB06J9_s_(cols[idx]);}); if(!obj.dong||!obj.hosu) errors.push({rowNo:i+1,status:'ERROR',message:'동/호수 필수값 누락',raw:lines[i]}); else rows.push(obj); }
  return {rows:rows,errors:errors,headers:mapped};
}

function bulkUploadRegularMembers(payload){
  syncSystemConfig(); payload=payload||{};
  var parsed=parseRegularMemberUpload_(payload.rawText||''), rows=parsed.rows||[], errors=parsed.errors||[], eventId=fhB06J9_s_(payload.eventId), vendorId=fhB06J9_s_(payload.vendorId);
  if(!eventId) throw new Error('정회원 DB 업로드는 행사 선택이 필요합니다.');
  var sheetName=FEELHAUS_B06J9.CUSTOMER_SHEET, headers=fhB06J9_customerHeaders_(), now=ts(), results=[], seen={};
  rows.forEach(function(row){ var dong=fhB06J9_s_(row.dong), hosu=fhB06J9_s_(row.hosu), key=eventId+'|'+normalizeCustomerMatchText_(dong)+'|'+normalizeCustomerMatchText_(hosu); if(seen[key]){ results.push({rowNo:row.sourceRow,status:'SKIPPED_DUPLICATE_IN_UPLOAD',customerId:seen[key],eventId:eventId,dong:dong,hosu:hosu,ho:hosu,message:'업로드 파일 내 동일 행사+동+호수 중복. 먼저 처리된 customerId 기준으로 건너뜀.'}); return; } var found=findRegularCustomerByEventDongHo_(sheetName,headers,{eventId:eventId,dong:dong,hosu:hosu}); if(found&&found.customerId){ seen[key]=found.customerId; results.push({rowNo:row.sourceRow,status:'EXISTING',customerId:found.customerId,eventId:eventId,dong:dong,hosu:hosu,ho:hosu,message:'기존 정회원 확인. 고객정보 자동 덮어쓰기 안 함.'}); return; } var customerId='CUS-'+Utilities.getUuid().replace(/-/g,'').substring(0,4).toUpperCase(); appendObjectByHeader_(sheetName,headers,{customerId:customerId,eventId:eventId,vendorId:vendorId,name:fhB06J9_s_(row.name),phone:normalizePhone(row.phone),email:fhB06J9_s_(row.email),memberType:'REGULAR',customerType:'REGULAR',regularCheck:fhB06J9_s_(payload.regularCheck)||'CONFIRMED',eventType:fhB06J9_s_(payload.eventType)||'입주박람회',qrSource:fhB06J9_s_(payload.qrSource)||'DB_UPLOAD',dong:dong,hosu:hosu,aptName:fhB06J9_s_(row.aptName),address:fhB06J9_s_(row.address),status:'ACTIVE',statusReason:'정회원 DB 업로드',memo:fhB06J9_s_(row.memo),notes:fhB06J9_s_(row.notes),createdAt:now,createdBy:'system',updatedAt:now,updatedBy:'system'}); seen[key]=customerId; results.push({rowNo:row.sourceRow,status:'CREATED',customerId:customerId,eventId:eventId,dong:dong,hosu:hosu,ho:hosu,message:'신규 정회원 생성 완료'}); });
  return {ok:true,buildNo:FEELHAUS_B06J9.BUILD,results:results,errors:errors,summary:{total:rows.length,created:results.filter(function(r){return r.status==='CREATED';}).length,existing:results.filter(function(r){return r.status==='EXISTING';}).length,skipped:results.filter(function(r){return r.status.indexOf('SKIPPED')===0;}).length,errors:errors.length}};
}

function fhB06J5PromotionHeaders_(){ return fhB06J9_promotionHeaders_(); }
function fhB06J5CustomerSheet_(ss){ var sh=ss.getSheetByName('ERP_고객관리')||ss.getSheetByName('Customers')||ss.getSheetByName('ERP_Customers'); return sh||fhB06J1EnsureSheet_(ss,'ERP_고객관리',fhB06J9_customerHeaders_()); }
function fhB06J5EnsureCustomerHeaders_(sh){ fhB06J1EnsureSheet_(sh.getParent(),sh.getName(),fhB06J9_customerHeaders_()); return fhB06J1HeaderMap_(sh); }
function fhB06J5FindDuplicateRegular_(sh,map,eventId,dong,hosu,excludeCustomerId){ if(sh.getLastRow()<2) return null; var hosuKey=map.hosu!=null?'hosu':(map.ho!=null?'ho':''); if(map.eventId==null||map.dong==null||!hosuKey||map.customerId==null) throw new Error('정회원 승격 필수 헤더 누락: eventId/dong/hosu/customerId'); var vals=sh.getRange(2,1,sh.getLastRow()-1,sh.getLastColumn()).getValues(), ev=fhB06J5Norm_(eventId), dg=fhB06J5Norm_(dong), hv=fhB06J5Norm_(hosu); for(var i=vals.length-1;i>=0;i--){ var row=vals[i], cid=fhB06J5S_(row[map.customerId]); if(!cid||cid===excludeCustomerId) continue; var same=fhB06J5Norm_(row[map.eventId])===ev&&fhB06J5Norm_(row[map.dong])===dg&&fhB06J5Norm_(row[map[hosuKey]])===hv; if(!same) continue; var mt=map.memberType!=null?fhB06J5S_(row[map.memberType]).toUpperCase():''; var ct=map.customerType!=null?fhB06J5S_(row[map.customerType]).toUpperCase():''; var rc=map.regularCheck!=null?fhB06J5S_(row[map.regularCheck]).toUpperCase():''; if(mt==='REGULAR'||ct==='REGULAR'||rc==='CONFIRMED') return {customerId:cid,rowIndex:i+2,obj:fhB06J5RowObj_(map,row)}; } return null; }
function fhB06J5ValidatePromotionPayload_(payload){ payload=payload||{}; var p={customerId:fhB06J5S_(payload.customerId),eventId:fhB06J5S_(payload.eventId),dong:fhB06J5S_(payload.dong),hosu:fhB06J5S_(payload.hosu||payload.ho),promotionSource:fhB06J5S_(payload.promotionSource||'FIELD_MANAGER_CONFIRM'),promotionReason:fhB06J5S_(payload.promotionReason||payload.reason)}; if(!p.customerId) throw new Error('정회원 승격은 선택된 customerId가 필요합니다.'); if(!p.eventId||!p.dong||!p.hosu) throw new Error('정회원 승격은 행사 + 동 + 호수(hosu)가 필요합니다.'); if(!p.promotionReason) throw new Error('정회원 승격 사유가 필요합니다.'); return p; }
// B06J28: legacy erpB06J function removed: erpB06J8_rowToCustomer_


// B06J28: legacy erpB06J function removed: erpB06J9_syncLegacyHoToHosu_

// B06J28: legacy erpB06J function removed: erpB06J9_headerPreflight_

// B06J28: legacy erpB06J function removed: erpB06J9_runSelfTest_

function testB06J9HosuStandardRestore_(){ return erpB06J9_runSelfTest(); }



/* ===== B06J9 PROMOTION HOSU OVERRIDES - KEEP AFTER B06J9 ===== */
function fhB06J5CreatePromotionRequest_(ss, payload, status, beforeObj, afterObj, actor, approvedBy){
  var sh=fhB06J1EnsureSheet_(ss,'CustomerPromotionRequests',fhB06J5PromotionHeaders_());
  var requestId=fhB06J5NewId_('CPR-'), now=fhB06J5Now_();
  fhB06J5AppendByHeader_(sh,{requestId:requestId,customerId:payload.customerId,eventId:payload.eventId,dong:payload.dong,hosu:payload.hosu,beforeMemberType:beforeObj.memberType||'',afterMemberType:'REGULAR',beforeCustomerType:beforeObj.customerType||'',afterCustomerType:'REGULAR',beforeRegularCheck:beforeObj.regularCheck||'',afterRegularCheck:status==='APPROVED'?'CONFIRMED':'PROMOTION_REQUESTED',promotionSource:payload.promotionSource,promotionReason:payload.promotionReason,status:status,requestedBy:actor,approvedBy:approvedBy||'',createdAt:now,approvedAt:status==='APPROVED'?now:'',updatedAt:now,updatedBy:actor,meta:JSON.stringify({buildNo:FEELHAUS_B06J9.BUILD})});
  return requestId;
}
function requestCustomerPromotion(payload){
  var env=fhB06J1FieldQrSetup_(), ss=env.masterDb, actor=fhB06J5Actor_(), p=fhB06J5ValidatePromotionPayload_(payload||{});
  var sh=fhB06J5CustomerSheet_(ss), map=fhB06J5EnsureCustomerHeaders_(sh), found=fhB06J5FindCustomer_(sh,map,p.customerId);
  if(!found) throw new Error('승격 요청 대상 고객을 찾지 못했습니다: '+p.customerId);
  var dup=fhB06J5FindDuplicateRegular_(sh,map,p.eventId,p.dong,p.hosu,p.customerId);
  if(dup) throw new Error('이미 해당 행사/동/호수에 정회원이 존재합니다: '+dup.customerId);
  var before=found.obj, after={memberType:'REGULAR',customerType:'REGULAR',regularCheck:'PROMOTION_REQUESTED',eventId:p.eventId,dong:p.dong,hosu:p.hosu};
  var requestId=fhB06J5CreatePromotionRequest_(ss,p,'PENDING',before,after,actor,'');
  fhB06J5WriteSystemLog_(ss,actor,'CUSTOMER_PROMOTION_REQUEST',p.customerId,'PENDING',p.promotionReason,before,after);
  fhB06J5WriteApprovalAudit_(ss,actor,'CUSTOMER_PROMOTION_REQUEST',p.customerId,'PENDING',before,after,p.promotionReason,'');
  return {ok:true,message:'정회원 승격 요청 생성 완료: '+requestId,requestId:requestId,customerId:p.customerId,status:'PENDING',eventId:p.eventId,dong:p.dong,hosu:p.hosu,ho:p.hosu,buildNo:FEELHAUS_B06J9.BUILD};
}
function promoteCustomerToRegular(payload){
  var env=fhB06J1FieldQrSetup_(), ss=env.masterDb, actor=fhB06J5Actor_(), p=fhB06J5ValidatePromotionPayload_(payload||{});
  var sh=fhB06J5CustomerSheet_(ss), map=fhB06J5EnsureCustomerHeaders_(sh), found=fhB06J5FindCustomer_(sh,map,p.customerId);
  if(!found) throw new Error('승격 대상 고객을 찾지 못했습니다: '+p.customerId);
  var dup=fhB06J5FindDuplicateRegular_(sh,map,p.eventId,p.dong,p.hosu,p.customerId);
  if(dup) throw new Error('이미 해당 행사/동/호수에 정회원이 존재합니다: '+dup.customerId+' / 자동 승격을 중지했습니다.');
  var before=found.obj, now=fhB06J5Now_();
  var updates={eventId:p.eventId,dong:p.dong,hosu:p.hosu,memberType:'REGULAR',customerType:'REGULAR',regularCheck:'CONFIRMED',status:'ACTIVE',statusReason:'정회원 승격: '+p.promotionSource,promotionSource:p.promotionSource,promotionReason:p.promotionReason,promotedAt:now,promotedBy:actor,updatedAt:now,updatedBy:actor};
  Object.keys(updates).forEach(function(k){ fhB06J5Set_(sh,found.rowIndex,map,k,updates[k]); });
  var after=Object.assign({},before,updates), requestId=fhB06J5CreatePromotionRequest_(ss,p,'APPROVED',before,after,actor,actor);
  fhB06J5WriteSystemLog_(ss,actor,'CUSTOMER_PROMOTE_TO_REGULAR',p.customerId,'APPROVED',p.promotionReason,before,after);
  fhB06J5WriteApprovalAudit_(ss,actor,'CUSTOMER_PROMOTE_TO_REGULAR',p.customerId,'APPROVED',before,after,p.promotionReason,actor);
  return {ok:true,message:'정회원 즉시 승격 완료: '+p.customerId,requestId:requestId,customerId:p.customerId,status:'APPROVED',memberType:'REGULAR',customerType:'REGULAR',regularCheck:'CONFIRMED',eventId:p.eventId,dong:p.dong,hosu:p.hosu,ho:p.hosu,buildNo:FEELHAUS_B06J9.BUILD};
}

/* ===== B06J10 HOSU STANDARD HOTFIX - KEEP VERY LAST =====
 * ERP_고객관리 표준 호수 헤더는 hosu. ho는 신규 저장 금지, 기존 잔여값 읽기 전용 호환만 허용.
 * 정회원 DB 업로드 ReferenceError와 고객검색 0건 문제를 실제 시트 직접조회로 차단.
 */
var FEELHAUS_B06J10 = {
  BUILD: 'ERP_v64_B06J10A_VERSION_CLEANUP_UPLOAD_SEARCH_HOSU_STANDARD_FIX_SAFE',
  SETUP_DB_ID: '17VMSpgSZCvIrUlgcw8yCNcnl8WQWo2IcRf5tDCcuJGM',
  CONFIG_SHEET_NAME: 'SystemConfig',
  CUSTOMER_SHEET: 'ERP_고객관리',
  STANDARD_MASTER_KEYS: ['FEELHAUS_DB_MASTER','FEELHAUS_DB_MASTER_ID'],
  READONLY_LEGACY_MASTER_KEYS: ['DB_SPREADSHEET_ID','DB_MASTER_ID','SPREADSHEET_ID']
};
function fhB06J10_s_(v){ return String(v === undefined || v === null ? '' : v).trim(); }
function fhB06J10_norm_(v){ return fhB06J10_s_(v).toUpperCase().replace(/[\s\-_.()\[\]{}]/g,'').replace(/[^0-9A-Z가-힣]/g,''); }
function fhB06J10_phone_(v){ var raw=fhB06J10_s_(v).replace(/[^0-9]/g,''); if(!raw)return''; if(raw.indexOf('010')!==0)raw='010'+raw.replace(/^010/,''); raw=raw.substring(0,11); if(raw.length<=3)return'010-'; if(raw.length<=7)return raw.replace(/(\d{3})(\d+)/,'$1-$2'); return raw.replace(/(\d{3})(\d{4})(\d+)/,'$1-$2-$3'); }
function normalizePhone(v){ return fhB06J10_phone_(v); }
function fhB06J10_now_(){ return Utilities.formatDate(new Date(), Session.getScriptTimeZone() || 'Asia/Seoul', 'yyyy-MM-dd HH:mm:ss'); }
function fhB06J10_uuid_(prefix){ return prefix + Utilities.getUuid().replace(/-/g,'').substring(0,12).toUpperCase(); }
function fhB06J10_readSystemConfig_(){ var setup=SpreadsheetApp.openById(FEELHAUS_B06J10.SETUP_DB_ID); var sh=setup.getSheetByName(FEELHAUS_B06J10.CONFIG_SHEET_NAME); if(!sh)throw new Error('FEELHAUS_SETUP_DB에서 SystemConfig 시트를 찾지 못했습니다.'); var values=sh.getDataRange().getDisplayValues(); if(!values||values.length<2)throw new Error('SystemConfig 데이터가 없습니다.'); var header=values[0].map(function(h){return fhB06J10_s_(h).replace(/^\uFEFF/,'').toUpperCase();}); var keyCol=header.indexOf('KEY'), valueCol=header.indexOf('VALUE'); if(keyCol<0||valueCol<0)throw new Error('SystemConfig 표준 헤더 KEY / VALUE가 필요합니다. 현재 헤더: '+values[0].join(', ')); var map={}; for(var r=1;r<values.length;r++){ var key=fhB06J10_s_(values[r][keyCol]); if(key)map[key]=fhB06J10_s_(values[r][valueCol]); } return map; }
function fhB06J10_getMasterDb_(){ var cfg=fhB06J10_readSystemConfig_(); var key='', id=''; for(var i=0;i<FEELHAUS_B06J10.STANDARD_MASTER_KEYS.length;i++){ key=FEELHAUS_B06J10.STANDARD_MASTER_KEYS[i]; if(cfg[key]){id=cfg[key];break;} } if(!id){ for(var j=0;j<FEELHAUS_B06J10.READONLY_LEGACY_MASTER_KEYS.length;j++){ key=FEELHAUS_B06J10.READONLY_LEGACY_MASTER_KEYS[j]; if(cfg[key]){id=cfg[key];break;} } } if(!id)throw new Error('SystemConfig KEY/VALUE에서 FEELHAUS_DB_MASTER 값을 찾지 못했습니다.'); return {ss:SpreadsheetApp.openById(id),masterDbId:id,sourceKey:key}; }
function fhB06J10_customerSheet_(){ var env=fhB06J10_getMasterDb_(); var sh=env.ss.getSheetByName(FEELHAUS_B06J10.CUSTOMER_SHEET); if(!sh)throw new Error('FEELHAUS_DB_MASTER에서 ERP_고객관리 시트를 찾지 못했습니다.'); return {env:env,sheet:sh}; }
function fhB06J10_headers_(sh){ var lastCol=sh.getLastColumn(); var headers=lastCol?sh.getRange(1,1,1,lastCol).getDisplayValues()[0].map(fhB06J10_s_):[]; var map={}; headers.forEach(function(h,i){if(h&&map[h]==null)map[h]=i;}); return {headers:headers,map:map}; }
function fhB06J10_assertCustomerHeaders_(map){ var missing=[]; ['customerId','eventId','dong','hosu','memberType','customerType','status','createdAt','createdBy','updatedAt','updatedBy'].forEach(function(h){if(map[h]==null)missing.push(h);}); if(missing.length)throw new Error('ERP_고객관리 필수 표준 헤더 누락: '+missing.join(', ')+' / hosu가 표준이며 ho는 표준이 아닙니다.'); }
function fhB06J10_normalizeMember_(v){ var n=fhB06J10_norm_(v); if(!n)return''; if(n==='REGULAR'||n==='정회원'||n==='CONFIRMEDREGULAR')return'REGULAR'; if(n==='ASSOCIATE'||n==='준회원'||n==='준회원고객')return'ASSOCIATE'; return fhB06J10_s_(v).toUpperCase(); }
function fhB06J10_rowObj_(headers,row,rowNo){ var obj={rowNumber:rowNo,sourceSheet:FEELHAUS_B06J10.CUSTOMER_SHEET}; headers.forEach(function(h,i){if(h)obj[h]=row[i];}); var hosu=fhB06J10_s_(obj.hosu)||fhB06J10_s_(obj.ho); obj.hosu=hosu; obj.ho=hosu; obj.customerId=fhB06J10_s_(obj.customerId); obj.eventId=fhB06J10_s_(obj.eventId); obj.vendorId=fhB06J10_s_(obj.vendorId); obj.name=fhB06J10_s_(obj.name); obj.phone=fhB06J10_s_(obj.phone); obj.email=fhB06J10_s_(obj.email); obj.dong=fhB06J10_s_(obj.dong); obj.memberType=fhB06J10_normalizeMember_(obj.memberType||obj.customerType); obj.customerType=fhB06J10_normalizeMember_(obj.customerType||obj.memberType); obj.regularCheck=fhB06J10_s_(obj.regularCheck); obj.status=fhB06J10_s_(obj.status)||'ACTIVE'; obj.notes=fhB06J10_s_(obj.notes||obj.memo); return obj; }
function fhB06J10_readCustomers_(){ var ref=fhB06J10_customerSheet_(); var hm=fhB06J10_headers_(ref.sheet); fhB06J10_assertCustomerHeaders_(hm.map); if(ref.sheet.getLastRow()<2)return{env:ref.env,headers:hm.headers,map:hm.map,rows:[]}; var values=ref.sheet.getRange(2,1,ref.sheet.getLastRow()-1,ref.sheet.getLastColumn()).getValues(); var rows=[]; for(var i=0;i<values.length;i++){ var obj=fhB06J10_rowObj_(hm.headers,values[i],i+2); if(obj.customerId)rows.push(obj); } return {env:ref.env,headers:hm.headers,map:hm.map,rows:rows}; }
function searchCustomers(query){ var qn=fhB06J10_norm_(query); var data=fhB06J10_readCustomers_(); var rows=data.rows.slice().reverse(); if(qn){ rows=rows.filter(function(c){ var hay=[c.customerId,c.name,c.phone,c.email,c.dong,c.hosu,c.eventId,c.vendorId,c.memberType,c.customerType,c.regularCheck,c.status,c.memo,c.notes].map(fhB06J10_norm_).join(' '); return hay.indexOf(qn)>=0; }); } return rows.slice(0,80); }
function getRecentCustomers(limit){ var max=Number(limit||20); if(!max||max<1)max=20; return fhB06J10_readCustomers_().rows.slice().reverse().slice(0,max); }
function getCustomerDetail(customerId){ var idn=fhB06J10_norm_(customerId); if(!idn)throw new Error('customerId가 필요합니다.'); var rows=fhB06J10_readCustomers_().rows, found=null; for(var i=0;i<rows.length;i++){ if(fhB06J10_norm_(rows[i].customerId)===idn){found=rows[i];break;} } if(!found)throw new Error('고객을 찾지 못했습니다: '+customerId); return {customer:found,sales:[],evidenceQueue:[],timeline:{sales:[],installs:[],evidence:[],cancellations:[]}}; }
function fhB06J10_parseUpload_(rawText){ var text=fhB06J10_s_(rawText); if(!text)return{rows:[],errors:[{rowNo:0,status:'ERROR',message:'업로드 내용이 비어 있습니다.'}]}; var lines=text.split(/\r?\n/).filter(function(line){return fhB06J10_s_(line);}); if(lines.length<2)return{rows:[],errors:[{rowNo:1,status:'ERROR',message:'헤더와 데이터가 필요합니다.'}]}; var delimiter=lines[0].indexOf('\t')>=0?/\t/:/,/; var rawHeaders=lines[0].split(delimiter).map(fhB06J10_s_); var alias={apartmentName:'aptName',aptName:'aptName','아파트':'aptName','단지명':'aptName',dong:'dong','동':'dong',hosu:'hosu',ho:'hosu','호':'hosu','호수':'hosu',name:'name','이름':'name','성명':'name',phone:'phone',tel:'phone',mobile:'phone','전화':'phone','전화번호':'phone','휴대폰':'phone','휴대폰번호':'phone',email:'email','이메일':'email',address:'address','주소':'address',memo:'memo','메모':'memo',notes:'notes','비고':'notes'}; var mapped=rawHeaders.map(function(h){return alias[h]||alias[h.toLowerCase()]||h;}); var errors=[],rows=[]; if(mapped.indexOf('dong')<0||mapped.indexOf('hosu')<0)throw new Error('정회원 DB 업로드 첫 줄에는 dong/hosu 표준 헤더가 필요합니다. 화면 라벨이 호여도 저장 기준은 hosu입니다.'); for(var i=1;i<lines.length;i++){ var cols=lines[i].split(delimiter), obj={sourceRow:i+1}; mapped.forEach(function(k,idx){obj[k]=fhB06J10_s_(cols[idx]);}); if(!obj.dong||!obj.hosu)errors.push({rowNo:i+1,status:'ERROR',message:'동/호수 필수값 누락',raw:lines[i]}); else rows.push(obj); } return {rows:rows,errors:errors,headers:mapped}; }
function fhB06J10_findByEventDongHosu_(rows,eventId,dong,hosu){ var ev=fhB06J10_norm_(eventId),dg=fhB06J10_norm_(dong),hs=fhB06J10_norm_(hosu); for(var i=0;i<rows.length;i++){ var r=rows[i]; if(fhB06J10_norm_(r.eventId)===ev&&fhB06J10_norm_(r.dong)===dg&&fhB06J10_norm_(r.hosu)===hs)return r; } return null; }
function fhB06J10_appendCustomer_(sh,headers,map,obj){ var row=new Array(headers.length).fill(''); Object.keys(obj).forEach(function(k){ if(k==='ho')return; if(map[k]!=null)row[map[k]]=obj[k]==null?'':obj[k]; }); sh.appendRow(row); }
function bulkUploadRegularMembers(payload){ payload=payload||{}; var eventId=fhB06J10_s_(payload.eventId); if(!eventId)throw new Error('정회원 DB 업로드는 행사 선택이 필요합니다.'); var parsed=fhB06J10_parseUpload_(payload.rawText||''); var ref=fhB06J10_customerSheet_(); var hm=fhB06J10_headers_(ref.sheet); fhB06J10_assertCustomerHeaders_(hm.map); var data=fhB06J10_readCustomers_(); var now=fhB06J10_now_(); var results=[],seen={}; parsed.rows.forEach(function(row){ var dong=fhB06J10_s_(row.dong), hosu=fhB06J10_s_(row.hosu); var key=fhB06J10_norm_(eventId)+'|'+fhB06J10_norm_(dong)+'|'+fhB06J10_norm_(hosu); if(seen[key]){results.push({rowNo:row.sourceRow,status:'SKIPPED_DUPLICATE_IN_UPLOAD',customerId:seen[key],eventId:eventId,dong:dong,hosu:hosu,message:'업로드 파일 내 동일 행사+동+호수 중복. 먼저 처리된 customerId 기준으로 건너뜀.'});return;} var found=fhB06J10_findByEventDongHosu_(data.rows,eventId,dong,hosu); if(found&&found.customerId){seen[key]=found.customerId;results.push({rowNo:row.sourceRow,status:'EXISTING',customerId:found.customerId,eventId:eventId,dong:dong,hosu:hosu,message:'기존 고객 확인. 고객정보 자동 덮어쓰기 안 함.'});return;} var customerId=fhB06J10_uuid_('CUS_'); var obj={customerId:customerId,name:fhB06J10_s_(row.name),phone:fhB06J10_phone_(row.phone),email:fhB06J10_s_(row.email),memberType:'REGULAR',eventType:fhB06J10_s_(payload.eventType)||'입주박람회',qrSource:fhB06J10_s_(payload.qrSource)||'DB_UPLOAD',dong:dong,hosu:hosu,aptName:fhB06J10_s_(row.aptName),address:fhB06J10_s_(row.address),status:'ACTIVE',eventId:eventId,vendorId:fhB06J10_s_(payload.vendorId),createdAt:now,statusReason:'정회원 DB 업로드',createdBy:'system',updatedAt:now,updatedBy:'system',customerType:'REGULAR',regularCheck:fhB06J10_s_(payload.regularCheck)||'CONFIRMED',memo:fhB06J10_s_(row.memo),notes:fhB06J10_s_(row.notes)}; fhB06J10_appendCustomer_(ref.sheet,hm.headers,hm.map,obj); data.rows.push(obj); seen[key]=customerId; results.push({rowNo:row.sourceRow,status:'CREATED',customerId:customerId,eventId:eventId,dong:dong,hosu:hosu,message:'신규 정회원 생성 완료'}); }); var summary={total:parsed.rows.length,created:results.filter(function(r){return r.status==='CREATED';}).length,existing:results.filter(function(r){return r.status==='EXISTING';}).length,skipped:results.filter(function(r){return String(r.status).indexOf('SKIPPED')===0;}).length,errors:parsed.errors.length}; return {ok:true,buildNo:FEELHAUS_B06J10.BUILD,results:results,errors:parsed.errors,summary:summary,totalRows:summary.total,createdCount:summary.created,existingCount:summary.existing,skippedCount:summary.skipped,errorCount:summary.errors,masterDbId:ref.env.masterDbId,sourceKey:ref.env.sourceKey}; }
// B06J28: legacy erpB06J function removed: erpB06J10_headerPreflight_

// B06J28: legacy erpB06J function removed: erpB06J10_debugFindCustomer_

// B06J28: legacy erpB06J function removed: erpB06J10_runSelfTest_


/* ===== B06J10A VERSION CLEANUP ALIASES - KEEP LAST =====
 * B06J10A is a version-cleanup wrapper over the B06J10 hotfix engine.
 * Standard customer unit header remains hosu. ho is read-only legacy compatibility only.
 */
// B06J28: legacy erpB06J function removed: erpB06J10A_headerPreflight_

// B06J28: legacy erpB06J function removed: erpB06J10A_debugFindCustomer_

// B06J28: legacy erpB06J function removed: erpB06J10A_runSelfTest_


/* ===== B06J11 SYSTEMCONFIG + UPLOAD + CUSTOMER SEARCH STANDARD RESTORE - KEEP LAST =====
 * 목적: SystemConfig 표준 헤더는 CONFIG_KEY / VALUE로 고정.
 * 고객 호수 표준 헤더는 hosu. ho는 신규 저장 금지, 기존 잔여값 읽기 전용 호환.
 */
var FEELHAUS_B06J11 = {
  BUILD: 'ERP_v64_B06J11_SYSTEMCONFIG_UPLOAD_SEARCH_HOSU_STANDARD_RESTORE_SAFE',
  SETUP_DB_ID: '17VMSpgSZCvIrUlgcw8yCNcnl8WQWo2IcRf5tDCcuJGM',
  CONFIG_SHEET_NAME: 'SystemConfig',
  CUSTOMER_SHEET: 'ERP_고객관리',
  MASTER_CONFIG_KEYS: ['FEELHAUS_DB_MASTER','FEELHAUS_DB_MASTER_ID','DB_MASTER_ID']
};
function fhB06J11_s_(v){ return String(v === undefined || v === null ? '' : v).trim(); }
function fhB06J11_norm_(v){ return fhB06J11_s_(v).toUpperCase().replace(/[\s\-_.()\[\]{}]/g,'').replace(/[^0-9A-Z가-힣]/g,''); }
function fhB06J11_phone_(v){ var raw=fhB06J11_s_(v).replace(/[^0-9]/g,''); if(!raw)return''; if(raw.indexOf('010')!==0)raw='010'+raw.replace(/^010/,''); raw=raw.substring(0,11); if(raw.length<=3)return'010-'; if(raw.length<=7)return raw.replace(/(\d{3})(\d+)/,'$1-$2'); return raw.replace(/(\d{3})(\d{4})(\d+)/,'$1-$2-$3'); }
function normalizePhone(v){ return fhB06J11_phone_(v); }
function fhB06J11_now_(){ return Utilities.formatDate(new Date(), Session.getScriptTimeZone() || 'Asia/Seoul', 'yyyy-MM-dd HH:mm:ss'); }
function fhB06J11_uuid_(prefix){ return prefix + Utilities.getUuid().replace(/-/g,'').substring(0,12).toUpperCase(); }
function fhB06J11_readSystemConfig_(){ var setup=SpreadsheetApp.openById(FEELHAUS_B06J11.SETUP_DB_ID); var sh=setup.getSheetByName(FEELHAUS_B06J11.CONFIG_SHEET_NAME); if(!sh) throw new Error('FEELHAUS_SETUP_DB에서 SystemConfig 시트를 찾지 못했습니다.'); var values=sh.getDataRange().getDisplayValues(); if(!values||values.length<2) throw new Error('SystemConfig 데이터가 없습니다.'); var header=values[0].map(function(h){return fhB06J11_s_(h).replace(/^\uFEFF/,'').toUpperCase();}); var keyCol=header.indexOf('CONFIG_KEY'); var valueCol=header.indexOf('VALUE'); if(keyCol<0||valueCol<0) throw new Error('SystemConfig 표준 헤더 CONFIG_KEY / VALUE가 필요합니다. 현재 헤더: '+values[0].join(', ')); var map={}; for(var r=1;r<values.length;r++){ var k=fhB06J11_s_(values[r][keyCol]); if(k) map[k]=fhB06J11_s_(values[r][valueCol]); } return {map:map,headers:values[0],rowCount:values.length-1}; }
function fhB06J11_getMasterDb_(){ var cfg=fhB06J11_readSystemConfig_(); var id='',sourceKey=''; for(var i=0;i<FEELHAUS_B06J11.MASTER_CONFIG_KEYS.length;i++){ var k=FEELHAUS_B06J11.MASTER_CONFIG_KEYS[i]; if(cfg.map[k]){id=cfg.map[k];sourceKey=k;break;} } if(!id) throw new Error('SystemConfig CONFIG_KEY/VALUE에서 FEELHAUS_DB_MASTER 값을 찾지 못했습니다. 확인 키: '+FEELHAUS_B06J11.MASTER_CONFIG_KEYS.join(', ')); return {ss:SpreadsheetApp.openById(id),masterDbId:id,sourceKey:sourceKey,configHeaders:cfg.headers,configRows:cfg.rowCount}; }
function fhB06J11_customerSheet_(){ var env=fhB06J11_getMasterDb_(); var sh=env.ss.getSheetByName(FEELHAUS_B06J11.CUSTOMER_SHEET); if(!sh) throw new Error('FEELHAUS_DB_MASTER에서 ERP_고객관리 시트를 찾지 못했습니다.'); return {env:env,sheet:sh}; }
function fhB06J11_headers_(sh){ var lastCol=sh.getLastColumn(); var headers=lastCol?sh.getRange(1,1,1,lastCol).getDisplayValues()[0].map(fhB06J11_s_):[]; var map={}; headers.forEach(function(h,i){if(h&&map[h]==null)map[h]=i;}); return {headers:headers,map:map}; }
function fhB06J11_assertCustomerHeaders_(map){ var missing=[]; ['customerId','eventId','dong','hosu','memberType','customerType','status','createdAt','createdBy','updatedAt','updatedBy'].forEach(function(h){if(map[h]==null)missing.push(h);}); if(missing.length) throw new Error('ERP_고객관리 필수 표준 헤더 누락: '+missing.join(', ')+' / 호수 표준은 hosu입니다.'); }
function fhB06J11_member_(v){ var n=fhB06J11_norm_(v); if(!n)return''; if(n==='REGULAR'||n==='정회원'||n==='CONFIRMEDREGULAR')return'REGULAR'; if(n==='ASSOCIATE'||n==='준회원'||n==='준회원고객')return'ASSOCIATE'; return fhB06J11_s_(v).toUpperCase(); }
function fhB06J11_rowObj_(headers,row,rowNo){ var o={rowNumber:rowNo,sourceSheet:FEELHAUS_B06J11.CUSTOMER_SHEET}; headers.forEach(function(h,i){if(h)o[h]=row[i];}); var hs=fhB06J11_s_(o.hosu)||fhB06J11_s_(o.ho); o.hosu=hs; o.ho=hs; o.customerId=fhB06J11_s_(o.customerId); o.eventId=fhB06J11_s_(o.eventId); o.vendorId=fhB06J11_s_(o.vendorId); o.name=fhB06J11_s_(o.name); o.phone=fhB06J11_s_(o.phone); o.email=fhB06J11_s_(o.email); o.dong=fhB06J11_s_(o.dong); o.memberType=fhB06J11_member_(o.memberType||o.customerType); o.customerType=fhB06J11_member_(o.customerType||o.memberType); o.regularCheck=fhB06J11_s_(o.regularCheck); o.status=fhB06J11_s_(o.status)||'ACTIVE'; o.memo=fhB06J11_s_(o.memo); o.notes=fhB06J11_s_(o.notes); return o; }
function fhB06J11_readCustomers_(){ var ref=fhB06J11_customerSheet_(); var hm=fhB06J11_headers_(ref.sheet); fhB06J11_assertCustomerHeaders_(hm.map); if(ref.sheet.getLastRow()<2)return{env:ref.env,headers:hm.headers,map:hm.map,rows:[]}; var values=ref.sheet.getRange(2,1,ref.sheet.getLastRow()-1,ref.sheet.getLastColumn()).getValues(); var rows=[]; for(var i=0;i<values.length;i++){ var o=fhB06J11_rowObj_(hm.headers,values[i],i+2); if(o.customerId)rows.push(o); } return {env:ref.env,headers:hm.headers,map:hm.map,rows:rows}; }
function searchCustomers(query){ var qn=fhB06J11_norm_(query); var data=fhB06J11_readCustomers_(); var seen={},out=[]; data.rows.slice().reverse().forEach(function(c){ if(qn){ var hay=[c.customerId,c.name,c.phone,c.email,c.dong,c.hosu,c.eventId,c.vendorId,c.memberType,c.customerType,c.regularCheck,c.status,c.memo,c.notes].map(fhB06J11_norm_).join(' '); if(hay.indexOf(qn)<0)return; } var key=fhB06J11_norm_(c.customerId); if(!key||seen[key])return; seen[key]=true; out.push(c); }); return out.slice(0,80); }
function getRecentCustomers(limit){ var max=Number(limit||20); if(!max||max<1)max=20; return fhB06J11_readCustomers_().rows.slice().reverse().slice(0,max); }
function getCustomerDetail(customerId){ var idn=fhB06J11_norm_(customerId); if(!idn) throw new Error('customerId가 필요합니다.'); var rows=fhB06J11_readCustomers_().rows; for(var i=0;i<rows.length;i++){ if(fhB06J11_norm_(rows[i].customerId)===idn) return {customer:rows[i],sales:[],evidenceQueue:[],timeline:{sales:[],installs:[],evidence:[],cancellations:[]}}; } throw new Error('고객을 찾지 못했습니다: '+customerId); }
function fhB06J11_parseUpload_(rawText){ var text=fhB06J11_s_(rawText); if(!text)return{rows:[],errors:[{rowNo:0,status:'ERROR',message:'업로드 내용이 비어 있습니다.'}]}; var lines=text.split(/\r?\n/).filter(function(line){return fhB06J11_s_(line);}); if(lines.length<2)return{rows:[],errors:[{rowNo:1,status:'ERROR',message:'헤더와 데이터가 필요합니다.'}]}; var delimiter=lines[0].indexOf('\t')>=0?/\t/:/,/; var rawHeaders=lines[0].split(delimiter).map(fhB06J11_s_); var alias={apartmentName:'aptName',aptName:'aptName','아파트':'aptName','단지명':'aptName',dong:'dong','동':'dong',hosu:'hosu','호수':'hosu','호':'hosu',ho:'hosu',name:'name','이름':'name','성명':'name',phone:'phone',tel:'phone',mobile:'phone','전화':'phone','전화번호':'phone','휴대폰':'phone','휴대폰번호':'phone',email:'email','이메일':'email',address:'address','주소':'address',memo:'memo','메모':'memo',notes:'notes','비고':'notes'}; var mapped=rawHeaders.map(function(h){return alias[h]||alias[h.toLowerCase()]||h;}); if(mapped.indexOf('dong')<0||mapped.indexOf('hosu')<0) throw new Error('정회원 DB 업로드 첫 줄에는 dong / hosu 표준 헤더가 필요합니다. 화면 라벨이 호여도 저장 기준은 hosu입니다.'); var rows=[],errors=[]; for(var i=1;i<lines.length;i++){ var cols=lines[i].split(delimiter), obj={sourceRow:i+1}; mapped.forEach(function(k,idx){obj[k]=fhB06J11_s_(cols[idx]);}); if(!obj.dong||!obj.hosu)errors.push({rowNo:i+1,status:'ERROR',message:'동/호수 필수값 누락',raw:lines[i]}); else rows.push(obj); } return {rows:rows,errors:errors,headers:mapped}; }
function fhB06J11_findByEventDongHosu_(rows,eventId,dong,hosu){ var ev=fhB06J11_norm_(eventId),dg=fhB06J11_norm_(dong),hs=fhB06J11_norm_(hosu); for(var i=0;i<rows.length;i++){ var r=rows[i]; if(fhB06J11_norm_(r.eventId)===ev&&fhB06J11_norm_(r.dong)===dg&&fhB06J11_norm_(r.hosu)===hs)return r; } return null; }
function fhB06J11_appendCustomer_(sh,headers,map,obj){ var row=new Array(headers.length).fill(''); Object.keys(obj).forEach(function(k){ if(k==='ho')return; if(map[k]!=null)row[map[k]]=obj[k]==null?'':obj[k]; }); sh.appendRow(row); }
function bulkUploadRegularMembers(payload){ payload=payload||{}; var eventId=fhB06J11_s_(payload.eventId); if(!eventId)throw new Error('정회원 DB 업로드는 행사 선택이 필요합니다.'); var parsed=fhB06J11_parseUpload_(payload.rawText||''); var ref=fhB06J11_customerSheet_(); var hm=fhB06J11_headers_(ref.sheet); fhB06J11_assertCustomerHeaders_(hm.map); var data=fhB06J11_readCustomers_(); var now=fhB06J11_now_(); var results=[],seen={}; parsed.rows.forEach(function(row){ var dong=fhB06J11_s_(row.dong),hosu=fhB06J11_s_(row.hosu); var key=fhB06J11_norm_(eventId)+'|'+fhB06J11_norm_(dong)+'|'+fhB06J11_norm_(hosu); if(seen[key]){results.push({rowNo:row.sourceRow,status:'SKIPPED_DUPLICATE_IN_UPLOAD',customerId:seen[key],eventId:eventId,dong:dong,hosu:hosu,message:'업로드 파일 내 동일 행사+동+호수 중복. 먼저 처리된 customerId 기준으로 건너뜀.'});return;} var found=fhB06J11_findByEventDongHosu_(data.rows,eventId,dong,hosu); if(found&&found.customerId){seen[key]=found.customerId;results.push({rowNo:row.sourceRow,status:'EXISTING',customerId:found.customerId,eventId:eventId,dong:dong,hosu:hosu,message:'기존 고객 확인. 고객정보 자동 덮어쓰기 안 함.'});return;} var customerId=fhB06J11_uuid_('CUS_'); var obj={customerId:customerId,name:fhB06J11_s_(row.name),phone:fhB06J11_phone_(row.phone),email:fhB06J11_s_(row.email),memberType:'REGULAR',eventType:fhB06J11_s_(payload.eventType)||'입주박람회',qrSource:fhB06J11_s_(payload.qrSource)||'DB_UPLOAD',dong:dong,hosu:hosu,aptName:fhB06J11_s_(row.aptName),address:fhB06J11_s_(row.address),status:'ACTIVE',eventId:eventId,vendorId:fhB06J11_s_(payload.vendorId),createdAt:now,statusReason:'정회원 DB 업로드',createdBy:'system',updatedAt:now,updatedBy:'system',customerType:'REGULAR',regularCheck:fhB06J11_s_(payload.regularCheck)||'CONFIRMED',memo:fhB06J11_s_(row.memo),notes:fhB06J11_s_(row.notes)}; fhB06J11_appendCustomer_(ref.sheet,hm.headers,hm.map,obj); data.rows.push(obj); seen[key]=customerId; results.push({rowNo:row.sourceRow,status:'CREATED',customerId:customerId,eventId:eventId,dong:dong,hosu:hosu,message:'신규 정회원 생성 완료'}); }); var summary={total:parsed.rows.length,created:results.filter(function(r){return r.status==='CREATED';}).length,existing:results.filter(function(r){return r.status==='EXISTING';}).length,skipped:results.filter(function(r){return String(r.status).indexOf('SKIPPED')===0;}).length,errors:parsed.errors.length}; return {ok:true,buildNo:FEELHAUS_B06J11.BUILD,results:results,errors:parsed.errors,summary:summary,totalRows:summary.total,createdCount:summary.created,existingCount:summary.existing,skippedCount:summary.skipped,errorCount:summary.errors,masterDbId:ref.env.masterDbId,sourceKey:ref.env.sourceKey}; }
// B06J28: legacy erpB06J function removed: erpB06J11_debugSystemConfig_

// B06J28: legacy erpB06J function removed: erpB06J11_headerPreflight_

// B06J28: legacy erpB06J function removed: erpB06J11_debugFindCustomer_

// B06J28: legacy erpB06J function removed: erpB06J11_runSelfTest_

// B06J28: legacy erpB06J function removed: erpB06J10B_debugSystemConfig_

// B06J28: legacy erpB06J function removed: erpB06J10B_headerPreflight_

// B06J28: legacy erpB06J function removed: erpB06J10B_debugFindCustomer_

// B06J28: legacy erpB06J function removed: erpB06J10B_runSelfTest_



/*******************************************************
 * ERP v64-B06J33A CUSTOMER_ID DUPLICATE GUARD + PROMOTION REBUILD
 * B06J11 helper 기반 최종 진입 함수 재정의
 *******************************************************/
var FEELHAUS_B06J15 = { BUILD:'v64-B06J33A' };
function fhB06J15_existingIds_(){ var rows=fhB06J11_readCustomers_().rows, m={}; rows.forEach(function(r){ if(r.customerId) m[fhB06J11_norm_(r.customerId)]=true; }); return m; }
function fhB06J15_newCustomerId_(existing){ existing=existing||{}; for(var i=0;i<30;i++){ var id='CUS_'+Utilities.getUuid().replace(/-/g,'').substring(0,12).toUpperCase(); var k=fhB06J11_norm_(id); if(!existing[k]){ existing[k]=true; return id; } } throw new Error('customerId 자동발급 실패: 중복 방지 재시도 초과'); }
function fhB06J15_set_(sh,row,map,key,value){ if(map[key]!=null) sh.getRange(row,map[key]+1).setValue(value); }
// B06J28: legacy erpB06J function removed: erpB06J15_duplicateCustomerIdPreflight_

// B06J28: legacy erpB06J function removed: erpB06J15_repairDuplicateCustomerIds_

function searchCustomers(query){ var qn=fhB06J11_norm_(query), data=fhB06J11_readCustomers_(), out=[]; data.rows.slice().reverse().forEach(function(c){ if(qn){ var hay=[c.customerId,c.name,c.phone,c.email,c.dong,c.hosu,c.eventId,c.vendorId,c.memberType,c.customerType,c.regularCheck,c.status,c.memo,c.notes].map(fhB06J11_norm_).join(' '); if(hay.indexOf(qn)<0)return; } out.push(c); }); return out.slice(0,100); }
function getRecentCustomers(limit){ var max=Number(limit||20); if(!max||max<1)max=20; return fhB06J11_readCustomers_().rows.slice().reverse().slice(0,max); }
function getCustomerDetail(customerId){ var idn=fhB06J11_norm_(customerId); if(!idn) throw new Error('customerId가 필요합니다.'); var rows=fhB06J11_readCustomers_().rows; for(var i=0;i<rows.length;i++){ if(fhB06J11_norm_(rows[i].customerId)===idn) return {customer:rows[i],sales:[],evidenceQueue:[],timeline:{sales:[],installs:[],evidence:[],cancellations:[]}}; } throw new Error('고객을 찾지 못했습니다: '+customerId); }
function bulkUploadRegularMembers(payload){ payload=payload||{}; var eventId=fhB06J11_s_(payload.eventId); if(!eventId)throw new Error('정회원 DB 업로드는 행사 선택이 필요합니다.'); var parsed=fhB06J11_parseUpload_(payload.rawText||''), ref=fhB06J11_customerSheet_(), hm=fhB06J11_headers_(ref.sheet); fhB06J11_assertCustomerHeaders_(hm.map); var data=fhB06J11_readCustomers_(), existingIds=fhB06J15_existingIds_(), now=fhB06J11_now_(), results=[],seen={}; parsed.rows.forEach(function(row){ var dong=fhB06J11_s_(row.dong), hosu=fhB06J11_s_(row.hosu), key=fhB06J11_norm_(eventId)+'|'+fhB06J11_norm_(dong)+'|'+fhB06J11_norm_(hosu); if(seen[key]){results.push({rowNo:row.sourceRow,status:'SKIPPED_DUPLICATE_IN_UPLOAD',customerId:seen[key],eventId:eventId,dong:dong,hosu:hosu,message:'업로드 파일 내 동일 행사+동+호수 중복'});return;} var found=fhB06J11_findByEventDongHosu_(data.rows,eventId,dong,hosu); if(found&&found.customerId){seen[key]=found.customerId;results.push({rowNo:row.sourceRow,status:'EXISTING',customerId:found.customerId,eventId:eventId,dong:dong,hosu:hosu,message:'기존 고객 확인. 고객정보 자동 덮어쓰기 안 함.'});return;} var cid=fhB06J15_newCustomerId_(existingIds); var obj={customerId:cid,name:fhB06J11_s_(row.name),phone:fhB06J11_phone_(row.phone),email:fhB06J11_s_(row.email),memberType:'REGULAR',eventType:fhB06J11_s_(payload.eventType)||'입주박람회',qrSource:fhB06J11_s_(payload.qrSource)||'DB_UPLOAD',dong:dong,hosu:hosu,aptName:fhB06J11_s_(row.aptName),address:fhB06J11_s_(row.address),status:'ACTIVE',eventId:eventId,vendorId:fhB06J11_s_(payload.vendorId),createdAt:now,statusReason:'정회원 DB 업로드',createdBy:'system',updatedAt:now,updatedBy:'system',customerType:'REGULAR',regularCheck:fhB06J11_s_(payload.regularCheck)||'CONFIRMED',memo:fhB06J11_s_(row.memo),notes:fhB06J11_s_(row.notes)}; fhB06J11_appendCustomer_(ref.sheet,hm.headers,hm.map,obj); data.rows.push(obj); seen[key]=cid; results.push({rowNo:row.sourceRow,status:'CREATED',customerId:cid,eventId:eventId,dong:dong,hosu:hosu,message:'신규 정회원 생성 완료'}); }); var summary={total:parsed.rows.length,created:results.filter(function(r){return r.status==='CREATED';}).length,existing:results.filter(function(r){return r.status==='EXISTING';}).length,skipped:results.filter(function(r){return String(r.status).indexOf('SKIPPED')===0;}).length,errors:parsed.errors.length}; return {ok:true,buildNo:FEELHAUS_B06J15.BUILD,results:results,errors:parsed.errors,summary:summary,totalRows:summary.total,createdCount:summary.created,existingCount:summary.existing,skippedCount:summary.skipped,errorCount:summary.errors}; }
function fhB06J15_promoPayload_(payload){ payload=payload||{}; var p={customerId:fhB06J11_s_(payload.customerId),eventId:fhB06J11_s_(payload.eventId),dong:fhB06J11_s_(payload.dong),hosu:fhB06J11_s_(payload.hosu||payload.ho),promotionSource:fhB06J11_s_(payload.promotionSource||'FIELD_MANAGER_CONFIRM'),promotionReason:fhB06J11_s_(payload.promotionReason||payload.reason)}; if(!p.customerId)throw new Error('정회원 승격은 선택된 customerId가 필요합니다.'); if(!p.eventId||!p.dong||!p.hosu)throw new Error('정회원 승격은 행사 + 동 + 호수(hosu)가 필요합니다.'); if(!p.promotionReason)throw new Error('정회원 승격 사유가 필요합니다.'); return p; }
function requestCustomerPromotion(payload){ var p=fhB06J15_promoPayload_(payload), data=fhB06J11_readCustomers_(), target=null; data.rows.forEach(function(r){ if(fhB06J11_norm_(r.customerId)===fhB06J11_norm_(p.customerId)) target=r; }); if(!target) throw new Error('승격 요청 대상 고객을 찾지 못했습니다: '+p.customerId); var dup=fhB06J11_findByEventDongHosu_(data.rows,p.eventId,p.dong,p.hosu); if(dup&&fhB06J11_norm_(dup.customerId)!==fhB06J11_norm_(p.customerId)&&fhB06J11_member_(dup.memberType)==='REGULAR') throw new Error('이미 해당 행사/동/호수에 정회원이 존재합니다: '+dup.customerId); return {ok:true,message:'정회원 승격 요청 검증 완료: 본사 승인흐름 연결 대기',requestId:'CPR_'+Utilities.getUuid().replace(/-/g,'').substring(0,12).toUpperCase(),customerId:p.customerId,status:'PENDING',eventId:p.eventId,dong:p.dong,hosu:p.hosu,buildNo:FEELHAUS_B06J15.BUILD}; }
function promoteCustomerToRegular(payload){ var p=fhB06J15_promoPayload_(payload), ref=fhB06J11_customerSheet_(), hm=fhB06J11_headers_(ref.sheet), data=fhB06J11_readCustomers_(), target=null; data.rows.forEach(function(r){ if(fhB06J11_norm_(r.customerId)===fhB06J11_norm_(p.customerId)) target=r; }); if(!target) throw new Error('승격 대상 고객을 찾지 못했습니다: '+p.customerId); var dup=fhB06J11_findByEventDongHosu_(data.rows,p.eventId,p.dong,p.hosu); if(dup&&fhB06J11_norm_(dup.customerId)!==fhB06J11_norm_(p.customerId)&&fhB06J11_member_(dup.memberType)==='REGULAR') throw new Error('이미 해당 행사/동/호수에 정회원이 존재합니다: '+dup.customerId); var now=fhB06J11_now_(); [['eventId',p.eventId],['dong',p.dong],['hosu',p.hosu],['memberType','REGULAR'],['customerType','REGULAR'],['regularCheck','CONFIRMED'],['status','ACTIVE'],['statusReason','정회원 승격: '+p.promotionSource],['updatedAt',now],['updatedBy','system'],['notes',(target.notes?target.notes+' | ':'')+'PROMOTED_TO_REGULAR; reason='+p.promotionReason+'; build='+FEELHAUS_B06J15.BUILD]].forEach(function(pair){fhB06J15_set_(ref.sheet,target.rowNumber,hm.map,pair[0],pair[1]);}); return {ok:true,message:'정회원 즉시 승격 완료: '+p.customerId,customerId:p.customerId,status:'APPROVED',memberType:'REGULAR',customerType:'REGULAR',regularCheck:'CONFIRMED',eventId:p.eventId,dong:p.dong,hosu:p.hosu,buildNo:FEELHAUS_B06J15.BUILD}; }
// B06J28: legacy erpB06J function removed: erpB06J15_debugSystemConfig_

// B06J28: legacy erpB06J function removed: erpB06J15_headerPreflight_

// B06J28: legacy erpB06J function removed: erpB06J15_debugFindCustomer_

// B06J28: legacy erpB06J function removed: erpB06J15_runSelfTest_


/********** FEELHAUS ERP v64-B06J33A CUSTOMER SEARCH TRACE + PROMOTION DISABLE SAFE **********/
var FEELHAUS_B06J15 = { BUILD: 'v64-B06J33A', SETUP_DB_ID: '17VMSpgSZCvIrUlgcw8yCNcnl8WQWo2IcRf5tDCcuJGM', CONFIG_SHEET_NAME: 'SystemConfig', CUSTOMER_SHEET: 'ERP_고객관리', MASTER_CONFIG_KEYS: ['FEELHAUS_DB_MASTER','FEELHAUS_DB_MASTER_ID','MASTER_DB_ID','MASTER_SPREADSHEET_ID'] };
function fhB06J15_norm_(v){ return String(v === undefined || v === null ? '' : v).replace(/\uFEFF/g,'').replace(/[\s\-_.()]/g,'').toUpperCase(); }
function fhB06J15_s_(v){ return String(v === undefined || v === null ? '' : v).trim(); }
function fhB06J15_now_(){ return Utilities.formatDate(new Date(), Session.getScriptTimeZone() || 'Asia/Seoul', 'yyyy-MM-dd HH:mm:ss'); }
function fhB06J15_readSystemConfig_(){ var setup=SpreadsheetApp.openById(FEELHAUS_B06J15.SETUP_DB_ID); var sh=setup.getSheetByName(FEELHAUS_B06J15.CONFIG_SHEET_NAME); if(!sh) throw new Error('FEELHAUS_SETUP_DB에서 SystemConfig 시트를 찾지 못했습니다.'); var values=sh.getDataRange().getDisplayValues(); if(!values||values.length<2) throw new Error('SystemConfig 데이터가 없습니다.'); var headers=values[0].map(function(h){return fhB06J15_s_(h).replace(/^\uFEFF/,'');}); var upper=headers.map(function(h){return h.toUpperCase();}); var keyCol=upper.indexOf('CONFIG_KEY'); var valueCol=upper.indexOf('VALUE'); if(keyCol<0||valueCol<0) throw new Error('SystemConfig 표준 헤더 CONFIG_KEY / VALUE가 필요합니다. 현재 헤더: '+headers.join(', ')); var map={}; for(var r=1;r<values.length;r++){ var k=fhB06J15_s_(values[r][keyCol]); if(k) map[k]=fhB06J15_s_(values[r][valueCol]); } return {headers:headers,rowCount:values.length-1,map:map}; }
function fhB06J15_getMasterDb_(){ var cfg=fhB06J15_readSystemConfig_(); var id='',key=''; FEELHAUS_B06J15.MASTER_CONFIG_KEYS.forEach(function(k){ if(!id&&cfg.map[k]){id=cfg.map[k];key=k;} }); if(!id) throw new Error('SystemConfig CONFIG_KEY/VALUE에서 FEELHAUS_DB_MASTER 값을 찾지 못했습니다. 확인 키: '+FEELHAUS_B06J15.MASTER_CONFIG_KEYS.join(', ')); return {ss:SpreadsheetApp.openById(id),masterDbId:id,sourceKey:key,configHeaders:cfg.headers,configRows:cfg.rowCount}; }
function fhB06J15_customerSheet_(){ var env=fhB06J15_getMasterDb_(); var sh=env.ss.getSheetByName(FEELHAUS_B06J15.CUSTOMER_SHEET); if(!sh) throw new Error('FEELHAUS_DB_MASTER에서 ERP_고객관리 시트를 찾지 못했습니다. masterDbId='+env.masterDbId); return {env:env,sheet:sh}; }
function fhB06J15_headers_(sh){ var headers=sh.getLastColumn()?sh.getRange(1,1,1,sh.getLastColumn()).getDisplayValues()[0].map(fhB06J15_s_):[]; var map={}; headers.forEach(function(h,i){if(h&&map[h]==null)map[h]=i;}); return {headers:headers,map:map}; }
function fhB06J15_assertCustomerHeaders_(map){ var missing=[]; ['customerId','eventId','dong','hosu','memberType','customerType','status','createdAt','createdBy','updatedAt','updatedBy'].forEach(function(h){if(map[h]==null)missing.push(h);}); if(missing.length) throw new Error('ERP_고객관리 필수 표준 헤더 누락: '+missing.join(', ')+' / 호수 표준은 hosu입니다.'); }
function fhB06J15_member_(v){ var n=fhB06J15_norm_(v); if(!n)return''; if(n==='REGULAR'||n==='정회원'||n==='CONFIRMEDREGULAR')return'REGULAR'; if(n==='ASSOCIATE'||n==='준회원'||n==='준회원고객')return'ASSOCIATE'; return fhB06J15_s_(v).toUpperCase(); }
function fhB06J15_rowObj_(headers,row,rowNo){ var o={rowNumber:rowNo,sourceSheet:FEELHAUS_B06J15.CUSTOMER_SHEET}; headers.forEach(function(h,i){if(h)o[h]=row[i];}); var hosu=fhB06J15_s_(o.hosu)||fhB06J15_s_(o.ho); o.hosu=hosu; o.ho=hosu; o.customerId=fhB06J15_s_(o.customerId); o.eventId=fhB06J15_s_(o.eventId); o.vendorId=fhB06J15_s_(o.vendorId); o.name=fhB06J15_s_(o.name); o.phone=fhB06J15_s_(o.phone); o.email=fhB06J15_s_(o.email); o.dong=fhB06J15_s_(o.dong); o.memberType=fhB06J15_member_(o.memberType||o.customerType); o.customerType=fhB06J15_member_(o.customerType||o.memberType); o.regularCheck=fhB06J15_s_(o.regularCheck); o.status=fhB06J15_s_(o.status)||'ACTIVE'; o.memo=fhB06J15_s_(o.memo); o.notes=fhB06J15_s_(o.notes); return o; }
function fhB06J15_readCustomers_(){ var ref=fhB06J15_customerSheet_(); var hm=fhB06J15_headers_(ref.sheet); fhB06J15_assertCustomerHeaders_(hm.map); var rows=[]; if(ref.sheet.getLastRow()>=2){ var values=ref.sheet.getRange(2,1,ref.sheet.getLastRow()-1,ref.sheet.getLastColumn()).getDisplayValues(); for(var i=0;i<values.length;i++){ var o=fhB06J15_rowObj_(hm.headers,values[i],i+2); if(o.customerId)rows.push(o); } } return {env:ref.env,headers:hm.headers,map:hm.map,rows:rows,lastRow:ref.sheet.getLastRow(),lastColumn:ref.sheet.getLastColumn()}; }
function searchCustomers(query){ var qn=fhB06J15_norm_(query); var data=fhB06J15_readCustomers_(); var out=[]; data.rows.slice().reverse().forEach(function(c){ if(qn){ var hay=[c.customerId,c.name,c.phone,c.email,c.dong,c.hosu,c.ho,c.eventId,c.vendorId,c.memberType,c.customerType,c.regularCheck,c.status,c.memo,c.notes].map(fhB06J15_norm_).join(' '); if(hay.indexOf(qn)<0)return; } out.push(c); }); return out.slice(0,100); }
function getRecentCustomers(limit){ var max=Number(limit||20); if(!max||max<1)max=20; return fhB06J15_readCustomers_().rows.slice().reverse().slice(0,max); }
function getCustomerDetail(customerId){ var idn=fhB06J15_norm_(customerId); if(!idn)throw new Error('customerId가 필요합니다.'); var rows=fhB06J15_readCustomers_().rows; for(var i=0;i<rows.length;i++){ if(fhB06J15_norm_(rows[i].customerId)===idn)return{customer:rows[i],sales:[],evidenceQueue:[],timeline:{sales:[],installs:[],evidence:[],cancellations:[]}}; } throw new Error('고객을 찾지 못했습니다: '+customerId); }
// B06J28: legacy erpB06J function removed: erpB06J15_searchTrace_

// B06J28: legacy erpB06J function removed: erpB06J15_debugSystemConfig_

// B06J28: legacy erpB06J function removed: erpB06J15_headerPreflight_

// B06J28: legacy erpB06J function removed: erpB06J15_debugFindCustomer_

// B06J28: legacy erpB06J function removed: erpB06J15_runSelfTest_

function requestCustomerPromotion(payload){ throw new Error('정회원 승격 기능은 B06J15에서 임시 비활성화되었습니다. 고객검색 안정화 후 승인흐름 기준으로 재제작해야 합니다.'); }
function promoteCustomerToRegular(payload){ throw new Error('정회원 즉시 승격 기능은 B06J15에서 임시 비활성화되었습니다. 고객검색 안정화 후 승인흐름 기준으로 재제작해야 합니다.'); }
function getBuildInfo(){ return{buildNo:'v64-B06J33A',buildTitle:'ERP 통합빌드 v64-B06J33A 고객검색 동호수패턴/정회원승격 안전재제작/hosu 기준복구',generatedAt:fhB06J15_now_()}; }


/********** FEELHAUS ERP v64-B06J33A PROMOTION REBUILD + DONG/HOSU SEARCH PATTERN SAFE **********/
var FEELHAUS_B06J15 = {
  BUILD: 'v64-B06J33A',
  SETUP_DB_ID: '17VMSpgSZCvIrUlgcw8yCNcnl8WQWo2IcRf5tDCcuJGM',
  CONFIG_SHEET_NAME: 'SystemConfig',
  CUSTOMER_SHEET: 'ERP_고객관리',
  MASTER_CONFIG_KEYS: ['FEELHAUS_DB_MASTER','FEELHAUS_DB_MASTER_ID','MASTER_DB_ID','MASTER_SPREADSHEET_ID']
};
function fhB06J15_s_(v){ return String(v === undefined || v === null ? '' : v).trim(); }
function fhB06J15_norm_(v){ return fhB06J15_s_(v).replace(/\uFEFF/g,'').replace(/[\s\-_.()\/\\]/g,'').toUpperCase(); }
function fhB06J15_digits_(v){ return fhB06J15_s_(v).replace(/\D/g,''); }
function fhB06J15_now_(){ return Utilities.formatDate(new Date(), Session.getScriptTimeZone() || 'Asia/Seoul', 'yyyy-MM-dd HH:mm:ss'); }
function fhB06J15_actor_(){ try { return Session.getActiveUser().getEmail() || 'unknown@local'; } catch(e) { return 'unknown@local'; } }
function fhB06J15_member_(v){ var n=fhB06J15_norm_(v); if(!n)return''; if(n==='REGULAR'||n==='정회원'||n==='CONFIRMEDREGULAR')return'REGULAR'; if(n==='ASSOCIATE'||n==='준회원'||n==='준회원고객')return'ASSOCIATE'; return fhB06J15_s_(v).toUpperCase(); }
function fhB06J15_readSystemConfig_(){ var setup=SpreadsheetApp.openById(FEELHAUS_B06J15.SETUP_DB_ID); var sh=setup.getSheetByName(FEELHAUS_B06J15.CONFIG_SHEET_NAME); if(!sh) throw new Error('FEELHAUS_SETUP_DB에서 SystemConfig 시트를 찾지 못했습니다.'); var values=sh.getDataRange().getDisplayValues(); if(!values||values.length<2) throw new Error('SystemConfig 데이터가 없습니다.'); var headers=values[0].map(function(h){return fhB06J15_s_(h).replace(/^\uFEFF/,'');}); var upper=headers.map(function(h){return h.toUpperCase();}); var keyCol=upper.indexOf('CONFIG_KEY'); var valueCol=upper.indexOf('VALUE'); if(keyCol<0||valueCol<0) throw new Error('SystemConfig 표준 헤더 CONFIG_KEY / VALUE가 필요합니다. 현재 헤더: '+headers.join(', ')); var map={}; for(var r=1;r<values.length;r++){ var k=fhB06J15_s_(values[r][keyCol]); if(k) map[k]=fhB06J15_s_(values[r][valueCol]); } return {headers:headers,rowCount:values.length-1,map:map}; }
function fhB06J15_getMasterDb_(){ var cfg=fhB06J15_readSystemConfig_(); var id='',key=''; FEELHAUS_B06J15.MASTER_CONFIG_KEYS.forEach(function(k){ if(!id&&cfg.map[k]){id=cfg.map[k];key=k;} }); if(!id) throw new Error('SystemConfig CONFIG_KEY/VALUE에서 FEELHAUS_DB_MASTER 값을 찾지 못했습니다. 확인 키: '+FEELHAUS_B06J15.MASTER_CONFIG_KEYS.join(', ')); return {ss:SpreadsheetApp.openById(id),masterDbId:id,sourceKey:key,configHeaders:cfg.headers,configRows:cfg.rowCount}; }
function fhB06J15_customerSheet_(){ var env=fhB06J15_getMasterDb_(); var sh=env.ss.getSheetByName(FEELHAUS_B06J15.CUSTOMER_SHEET); if(!sh) throw new Error('FEELHAUS_DB_MASTER에서 ERP_고객관리 시트를 찾지 못했습니다. masterDbId='+env.masterDbId); return {env:env,sheet:sh}; }
function fhB06J15_headers_(sh){ var headers=sh.getLastColumn()?sh.getRange(1,1,1,sh.getLastColumn()).getDisplayValues()[0].map(fhB06J15_s_):[]; var map={}; headers.forEach(function(h,i){if(h&&map[h]==null)map[h]=i;}); return {headers:headers,map:map}; }
function fhB06J15_assertCustomerHeaders_(map){ var missing=[]; ['customerId','eventId','dong','hosu','memberType','customerType','status','createdAt','createdBy','updatedAt','updatedBy'].forEach(function(h){if(map[h]==null)missing.push(h);}); if(missing.length) throw new Error('ERP_고객관리 필수 표준 헤더 누락: '+missing.join(', ')+' / 호수 표준은 hosu입니다.'); }
function fhB06J15_rowObj_(headers,row,rowNo){ var o={rowNumber:rowNo,sourceSheet:FEELHAUS_B06J15.CUSTOMER_SHEET}; headers.forEach(function(h,i){if(h)o[h]=row[i];}); var hosu=fhB06J15_s_(o.hosu)||fhB06J15_s_(o.ho); o.hosu=hosu; o.ho=hosu; o.customerId=fhB06J15_s_(o.customerId); o.eventId=fhB06J15_s_(o.eventId); o.vendorId=fhB06J15_s_(o.vendorId); o.name=fhB06J15_s_(o.name); o.phone=fhB06J15_s_(o.phone); o.email=fhB06J15_s_(o.email); o.dong=fhB06J15_s_(o.dong); o.memberType=fhB06J15_member_(o.memberType||o.customerType); o.customerType=fhB06J15_member_(o.customerType||o.memberType); o.regularCheck=fhB06J15_s_(o.regularCheck); o.status=fhB06J15_s_(o.status)||'ACTIVE'; o.memo=fhB06J15_s_(o.memo); o.notes=fhB06J15_s_(o.notes); return o; }
function fhB06J15_readCustomers_(){ var ref=fhB06J15_customerSheet_(); var hm=fhB06J15_headers_(ref.sheet); fhB06J15_assertCustomerHeaders_(hm.map); var rows=[]; if(ref.sheet.getLastRow()>=2){ var values=ref.sheet.getRange(2,1,ref.sheet.getLastRow()-1,ref.sheet.getLastColumn()).getDisplayValues(); for(var i=0;i<values.length;i++){ var o=fhB06J15_rowObj_(hm.headers,values[i],i+2); if(o.customerId)rows.push(o); } } return {env:ref.env,sheet:ref.sheet,headers:hm.headers,map:hm.map,rows:rows,lastRow:ref.sheet.getLastRow(),lastColumn:ref.sheet.getLastColumn()}; }
function fhB06J15_customerHay_(c){ var combo1=fhB06J15_s_(c.dong)+fhB06J15_s_(c.hosu); var combo2=fhB06J15_s_(c.dong)+'동'+fhB06J15_s_(c.hosu)+'호'; var combo3=fhB06J15_s_(c.dong)+'-'+fhB06J15_s_(c.hosu); return [c.customerId,c.name,c.phone,c.email,c.dong,c.hosu,c.ho,c.eventId,c.vendorId,c.memberType,c.customerType,c.regularCheck,c.status,c.memo,c.notes,combo1,combo2,combo3,fhB06J15_digits_(c.phone)].map(fhB06J15_norm_).join(' '); }
function searchCustomers(query){ var q=fhB06J15_s_(query); var qn=fhB06J15_norm_(q); var qd=fhB06J15_digits_(q); var data=fhB06J15_readCustomers_(); var out=[]; data.rows.slice().reverse().forEach(function(c){ if(qn){ var hay=fhB06J15_customerHay_(c); if(hay.indexOf(qn)<0 && (!qd || fhB06J15_digits_(c.phone).indexOf(qd)<0)) return; } out.push(c); }); return out.slice(0,100); }
function getRecentCustomers(limit){ var max=Number(limit||20); if(!max||max<1)max=20; return fhB06J15_readCustomers_().rows.slice().reverse().slice(0,max); }
function getCustomerDetail(customerId){ var idn=fhB06J15_norm_(customerId); if(!idn)throw new Error('customerId가 필요합니다.'); var rows=fhB06J15_readCustomers_().rows; for(var i=0;i<rows.length;i++){ if(fhB06J15_norm_(rows[i].customerId)===idn)return{customer:rows[i],sales:[],evidenceQueue:[],timeline:{sales:[],installs:[],evidence:[],cancellations:[]}}; } throw new Error('고객을 찾지 못했습니다: '+customerId); }
function fhB06J15_setCell_(sh,rowNo,map,key,value){ if(map[key]!=null) sh.getRange(rowNo,map[key]+1).setValue(value); }
function fhB06J15_findCustomer_(rows, customerId){ var id=fhB06J15_norm_(customerId); for(var i=0;i<rows.length;i++){ if(fhB06J15_norm_(rows[i].customerId)===id) return rows[i]; } return null; }
function fhB06J15_isRegular_(r){ return fhB06J15_member_(r.memberType)==='REGULAR' || fhB06J15_member_(r.customerType)==='REGULAR' || fhB06J15_norm_(r.regularCheck)==='CONFIRMED'; }
function fhB06J15_findDuplicateRegular_(rows,eventId,dong,hosu,excludeCustomerId){ var ev=fhB06J15_norm_(eventId), dg=fhB06J15_norm_(dong), hs=fhB06J15_norm_(hosu), ex=fhB06J15_norm_(excludeCustomerId); for(var i=0;i<rows.length;i++){ var r=rows[i]; if(fhB06J15_norm_(r.customerId)===ex) continue; if(fhB06J15_norm_(r.eventId)===ev && fhB06J15_norm_(r.dong)===dg && fhB06J15_norm_(r.hosu)===hs && fhB06J15_isRegular_(r)) return r; } return null; }
function fhB06J15_ensureSheet_(ss,name,headers){ var sh=ss.getSheetByName(name); if(!sh) sh=ss.insertSheet(name); if(sh.getLastRow()<1){ sh.getRange(1,1,1,headers.length).setValues([headers]); return sh; } var existing=sh.getRange(1,1,1,Math.max(sh.getLastColumn(),1)).getDisplayValues()[0].map(fhB06J15_s_); var need=[]; headers.forEach(function(h){ if(existing.indexOf(h)<0) need.push(h); }); if(need.length){ sh.getRange(1,existing.length+1,1,need.length).setValues([need]); } return sh; }
function fhB06J15_appendByHeader_(sh,obj){ var headers=sh.getRange(1,1,1,sh.getLastColumn()).getDisplayValues()[0].map(fhB06J15_s_); var row=headers.map(function(h){return obj[h]!==undefined?obj[h]:'';}); sh.appendRow(row); }
function fhB06J15_id_(prefix){ return prefix + Utilities.formatDate(new Date(), Session.getScriptTimeZone() || 'Asia/Seoul', 'yyyyMMddHHmmss') + '-' + Utilities.getUuid().replace(/-/g,'').substring(0,6).toUpperCase(); }
function fhB06J15_log_(ss,actionType,targetId,status,reason,beforeObj,afterObj,approvedBy){ var actor=fhB06J15_actor_(), now=fhB06J15_now_(); var logSh=fhB06J15_ensureSheet_(ss,'SystemLogs',['logId','createdAt','createdBy','actionType','targetId','status','reason','beforeValue','afterValue','buildNo']); fhB06J15_appendByHeader_(logSh,{logId:fhB06J15_id_('LOG-'),createdAt:now,createdBy:actor,actionType:actionType,targetId:targetId,status:status,reason:reason,beforeValue:JSON.stringify(beforeObj||{}),afterValue:JSON.stringify(afterObj||{}),buildNo:FEELHAUS_B06J15.BUILD}); var auditSh=fhB06J15_ensureSheet_(ss,'ApprovalAudit',['auditId','actionType','targetId','status','actor','refId','beforeValue','afterValue','reason','approvedBy','createdAt','buildNo']); fhB06J15_appendByHeader_(auditSh,{auditId:fhB06J15_id_('AUD-'),actionType:actionType,targetId:targetId,status:status,actor:actor,refId:'',beforeValue:JSON.stringify(beforeObj||{}),afterValue:JSON.stringify(afterObj||{}),reason:reason,approvedBy:approvedBy||'',createdAt:now,buildNo:FEELHAUS_B06J15.BUILD}); }
function fhB06J15_promoPayload_(payload,target){ payload=payload||{}; var p={}; p.customerId=fhB06J15_s_(payload.customerId); p.eventId=fhB06J15_s_(payload.eventId)||fhB06J15_s_(target&&target.eventId); p.dong=fhB06J15_s_(payload.dong)||fhB06J15_s_(target&&target.dong); p.hosu=fhB06J15_s_(payload.hosu||payload.ho)||fhB06J15_s_(target&&target.hosu); p.promotionSource=fhB06J15_s_(payload.promotionSource||'FIELD_MANAGER_CONFIRM'); p.promotionReason=fhB06J15_s_(payload.promotionReason||payload.reason); return p; }
function fhB06J15_validatePromotion_(p,target){ if(!p.customerId) throw new Error('정회원 승격은 선택된 customerId가 필요합니다. 고객 검색 후 고객을 선택하세요.'); if(!target) throw new Error('승격 대상 고객을 찾지 못했습니다: '+p.customerId); if(fhB06J15_isRegular_(target)) throw new Error('이미 정회원으로 확인된 고객입니다: '+p.customerId); if(fhB06J15_member_(target.memberType)!=='ASSOCIATE' && fhB06J15_member_(target.customerType)!=='ASSOCIATE') throw new Error('정회원 승격 대상은 준회원(ASSOCIATE) 고객이어야 합니다. 현재 memberType='+target.memberType+', customerType='+target.customerType); if(!p.eventId||!p.dong||!p.hosu) throw new Error('정회원 승격은 eventId + dong + hosu가 필요합니다. 선택 고객의 행사/동/호수를 확인하세요.'); if(!p.promotionSource) throw new Error('승격 사유구분이 필요합니다.'); if(!p.promotionReason) throw new Error('승격 사유를 입력하세요.'); }
function requestCustomerPromotion(payload){ var data=fhB06J15_readCustomers_(); var target=fhB06J15_findCustomer_(data.rows, payload&&payload.customerId); var p=fhB06J15_promoPayload_(payload,target); fhB06J15_validatePromotion_(p,target); var dup=fhB06J15_findDuplicateRegular_(data.rows,p.eventId,p.dong,p.hosu,p.customerId); if(dup) throw new Error('이미 해당 행사/동/호수에 정회원이 존재합니다: '+dup.customerId+' / 승격 요청을 중지했습니다.'); var now=fhB06J15_now_(), actor=fhB06J15_actor_(), requestId=fhB06J15_id_('CPR-'); var reqSh=fhB06J15_ensureSheet_(data.env.ss,'CustomerPromotionRequests',['requestId','customerId','eventId','dong','hosu','beforeMemberType','afterMemberType','beforeCustomerType','afterCustomerType','beforeRegularCheck','afterRegularCheck','promotionSource','promotionReason','status','requestedBy','approvedBy','createdAt','approvedAt','updatedAt','updatedBy','buildNo','meta']); fhB06J15_appendByHeader_(reqSh,{requestId:requestId,customerId:p.customerId,eventId:p.eventId,dong:p.dong,hosu:p.hosu,beforeMemberType:target.memberType,afterMemberType:'REGULAR',beforeCustomerType:target.customerType,afterCustomerType:'REGULAR',beforeRegularCheck:target.regularCheck,afterRegularCheck:'PENDING_APPROVAL',promotionSource:p.promotionSource,promotionReason:p.promotionReason,status:'PENDING_APPROVAL',requestedBy:actor,approvedBy:'',createdAt:now,approvedAt:'',updatedAt:now,updatedBy:actor,buildNo:FEELHAUS_B06J15.BUILD,meta:JSON.stringify({source:'ERP_CUSTOMER_PROMOTION_REQUEST'})}); fhB06J15_setCell_(data.sheet,target.rowNumber,data.map,'regularCheck','PENDING_APPROVAL'); fhB06J15_setCell_(data.sheet,target.rowNumber,data.map,'statusReason','정회원 승격 요청: '+p.promotionSource); fhB06J15_setCell_(data.sheet,target.rowNumber,data.map,'updatedAt',now); fhB06J15_setCell_(data.sheet,target.rowNumber,data.map,'updatedBy',actor); var after=Object.assign({},target,{regularCheck:'PENDING_APPROVAL',statusReason:'정회원 승격 요청: '+p.promotionSource}); fhB06J15_log_(data.env.ss,'CUSTOMER_PROMOTION_REQUEST',p.customerId,'PENDING_APPROVAL',p.promotionReason,target,after,''); return {ok:true,message:'정회원 승격 요청 완료: '+requestId,data:{requestId:requestId,customerId:p.customerId,status:'PENDING_APPROVAL',eventId:p.eventId,dong:p.dong,hosu:p.hosu},errorCode:'',meta:{buildNo:FEELHAUS_B06J15.BUILD,generatedAt:now}}; }
function promoteCustomerToRegular(payload){ var data=fhB06J15_readCustomers_(); var target=fhB06J15_findCustomer_(data.rows, payload&&payload.customerId); var p=fhB06J15_promoPayload_(payload,target); fhB06J15_validatePromotion_(p,target); var dup=fhB06J15_findDuplicateRegular_(data.rows,p.eventId,p.dong,p.hosu,p.customerId); if(dup) throw new Error('이미 해당 행사/동/호수에 정회원이 존재합니다: '+dup.customerId+' / 자동 승격을 중지했습니다.'); var now=fhB06J15_now_(), actor=fhB06J15_actor_(), requestId=fhB06J15_id_('CPR-'); var updates={eventId:p.eventId,dong:p.dong,hosu:p.hosu,memberType:'REGULAR',customerType:'REGULAR',regularCheck:'CONFIRMED',status:'ACTIVE',statusReason:'정회원 즉시 승격: '+p.promotionSource,updatedAt:now,updatedBy:actor,notes:(target.notes?target.notes+' | ':'')+'PROMOTED_TO_REGULAR; reason='+p.promotionReason+'; build='+FEELHAUS_B06J15.BUILD}; Object.keys(updates).forEach(function(k){ fhB06J15_setCell_(data.sheet,target.rowNumber,data.map,k,updates[k]); }); var reqSh=fhB06J15_ensureSheet_(data.env.ss,'CustomerPromotionRequests',['requestId','customerId','eventId','dong','hosu','beforeMemberType','afterMemberType','beforeCustomerType','afterCustomerType','beforeRegularCheck','afterRegularCheck','promotionSource','promotionReason','status','requestedBy','approvedBy','createdAt','approvedAt','updatedAt','updatedBy','buildNo','meta']); fhB06J15_appendByHeader_(reqSh,{requestId:requestId,customerId:p.customerId,eventId:p.eventId,dong:p.dong,hosu:p.hosu,beforeMemberType:target.memberType,afterMemberType:'REGULAR',beforeCustomerType:target.customerType,afterCustomerType:'REGULAR',beforeRegularCheck:target.regularCheck,afterRegularCheck:'CONFIRMED',promotionSource:p.promotionSource,promotionReason:p.promotionReason,status:'APPROVED',requestedBy:actor,approvedBy:actor,createdAt:now,approvedAt:now,updatedAt:now,updatedBy:actor,buildNo:FEELHAUS_B06J15.BUILD,meta:JSON.stringify({source:'ERP_CUSTOMER_PROMOTION_APPROVE_NOW'})}); var after=Object.assign({},target,updates); fhB06J15_log_(data.env.ss,'CUSTOMER_PROMOTE_TO_REGULAR',p.customerId,'APPROVED',p.promotionReason,target,after,actor); return {ok:true,message:'정회원 즉시 승격 완료: '+p.customerId,data:{requestId:requestId,customerId:p.customerId,status:'APPROVED',memberType:'REGULAR',customerType:'REGULAR',regularCheck:'CONFIRMED',eventId:p.eventId,dong:p.dong,hosu:p.hosu},errorCode:'',meta:{buildNo:FEELHAUS_B06J15.BUILD,generatedAt:now}}; }
// B06J28: legacy erpB06J function removed: erpB06J15_debugSystemConfig_

// B06J28: legacy erpB06J function removed: erpB06J15_headerPreflight_

// B06J28: legacy erpB06J function removed: erpB06J15_searchTrace_

// B06J28: legacy erpB06J function removed: erpB06J15_debugFindCustomer_

// B06J28: legacy erpB06J function removed: erpB06J15_runSelfTest_

function getBuildInfo(){ return{buildNo:'v64-B06J33A',buildTitle:'ERP 통합빌드 v64-B06J33A 계약서 생성대상 실제 판매건 보정',generatedAt:fhB06J15_now_()}; }


/* ===== B06J15 CONTRACT WORKLIST FROM REAL SALES FIX SAFE - KEEP LAST ===== */
var FEELHAUS_B06J15 = { BUILD:'v64-B06J33A', BUILD_TITLE:'ERP 통합빌드 v64-B06J33A 계약서 생성대상 실제 판매건 보정', SALE_SHEETS:['Sales','ERP_판매관리','ERP_Sales','판매관리'], DOCUMENT_SHEETS:['SIGN_Documents','Documents','ERP_문서관리'], INSTALL_SHEETS:['Installs','ERP_설치관리','Installations'], SETTLEMENT_SHEETS:['Settlements','ERP_정산관리','ERP_Settlements'] };
// B06J28: legacy erpB06J function removed: erpB06J15_s_

// B06J28: legacy erpB06J function removed: erpB06J15_norm_

// B06J28: legacy erpB06J function removed: erpB06J15_pick_

// B06J28: legacy erpB06J function removed: erpB06J15_ok_

// B06J28: legacy erpB06J function removed: erpB06J15_fail_

// B06J28: legacy erpB06J function removed: erpB06J15_readTableFromSheet_

// B06J28: legacy erpB06J function removed: erpB06J15_getMasterSpreadsheet_

// B06J28: legacy erpB06J function removed: erpB06J15_readSheets_

// B06J28: legacy erpB06J function removed: erpB06J15_docType_

// B06J28: legacy erpB06J function removed: erpB06J15_docStatus_

// B06J28: legacy erpB06J function removed: erpB06J15_buildDocIndex_

// B06J28: legacy erpB06J function removed: erpB06J15_normalizeSale_

// B06J28: legacy erpB06J function removed: erpB06J15_isSaleExcluded_

// B06J28: legacy erpB06J function removed: erpB06J15_buildContractTargets_

// B06J28: legacy erpB06J function removed: erpB06J15_buildInstallTargets_

// B06J28: legacy erpB06J function removed: erpB06J15_buildSettlementConfirmTargets_

// B06J28: legacy erpB06J function removed: erpB06J15_buildPdfTargets_

// B06J28: legacy erpB06J function removed: erpB06J15_buildArchiveTargets_

// B06J28: legacy erpB06J function removed: erpB06J15_buildQrTargets_

// B06J28: legacy erpB06J function removed: erpB06J15_getWorklists_

function fhOpsUiB05HetWorklists(payload){ try{return erpB06J15_getWorklists_(payload||{});}catch(e){return erpB06J15_fail_('B06J15 목록 자동조회 실패: '+((e&&e.message)||e),'B06J15_WORKLIST_FAILED',{stack:(e&&e.stack)||''});} }
function fhOpsUiB05GetWorklists(payload){ return fhOpsUiB05HetWorklists(payload||{}); }
// B06J28: legacy erpB06J function removed: erpB06J15_contractWorklistPreflight_

// B06J28: legacy erpB06J function removed: erpB06J15_runSelfTest_

function getBuildInfo(){ return {buildNo:'v64-B06J33A',buildTitle:'ERP 통합빌드 v64-B06J33A 계약서 생성대상 실제 판매건 보정',generatedAt:new Date()}; }


/* B06J16 CUSTOMER SELECT STATE FIX SAFE - server aliases */
// B06J28: legacy erpB06J function removed: erpB06J16_customerSelectStatePreflight_

// B06J28: legacy erpB06J function removed: erpB06J16_runSelfTest_

function getBuildInfo(){ return {buildNo:'v64-B06J33A',buildTitle:'ERP 통합빌드 v64-B06J33A 고객선택상태/수정저장 보정',generatedAt:new Date()}; }

// B06J28: legacy erpB06J function removed: erpB06J18A_customerSelectStatePreflight_

// B06J28: legacy erpB06J function removed: erpB06J18A_runSelfTest_

// B06J28: legacy erpB06J function removed: erpB06J18_customerSelectStatePreflight_

// B06J28: legacy erpB06J function removed: erpB06J18_runSelfTest_


/********************************************************
 * ERP v64-B06J33A CUSTOMER SEARCH ENGINE RESET - SERVER
 ********************************************************/
var FEELHAUS_B06J19 = { BUILD:'v64-B06J33A', TITLE:'ERP 통합빌드 v64-B06J33A 설치확인서 흐름 고정 버전정리본' };
function fhB06J19_s_(v){ return String(v == null ? '' : v).trim(); }
function fhB06J19_norm_(v){ return fhB06J19_s_(v).toLowerCase().replace(/\s+/g,'').replace(/[\-_.()\[\]{}]/g,''); }
function fhB06J19_digits_(v){ return fhB06J19_s_(v).replace(/\D/g,''); }
function fhB06J19_rows_(){ if(typeof fhB06J11_readCustomers_==='function') return fhB06J11_readCustomers_().rows || []; if(typeof fhB06J10_readCustomers_==='function') return fhB06J10_readCustomers_().rows || []; throw new Error('고객검색 엔진 오류: ERP_고객관리 읽기 함수가 없습니다.'); }
function fhB06J19_val_(c,keys){ for(var i=0;i<keys.length;i++){var k=keys[i]; if(c[k]!=null && c[k] !== '') return c[k];} return ''; }
function fhB06J19_hosu_(c){ return fhB06J19_val_(c||{},['hosu','ho','unitNo','roomNo']); }
function fhB06J19_member_(v){ var n=fhB06J19_norm_(v); if(n==='regular'||n==='정회원'||n==='confirmedregular')return 'REGULAR'; if(n==='associate'||n==='준회원')return 'ASSOCIATE'; return fhB06J19_s_(v).toUpperCase(); }
function fhB06J19_dh_(c){ var d=fhB06J19_s_(c.dong), h=fhB06J19_s_(fhB06J19_hosu_(c)); return [d+h,d+'-'+h,d+' '+h,d+'동'+h+'호'].map(fhB06J19_norm_).filter(Boolean); }
function fhB06J19_hay_(c){ var arr=[c.customerId,c.name,c.phone,c.email,c.eventId,c.vendorId,c.dong,fhB06J19_hosu_(c),c.aptName,c.address,c.memberType,c.customerType,c.regularCheck,c.status,c.memo,c.notes]; return arr.map(fhB06J19_norm_).join(' ')+' '+fhB06J19_dh_(c).join(' ')+' '+fhB06J19_digits_(c.phone); }
function fhB06J19_match_(c,q){ if(!q.norm&&!q.digits)return true; if(q.norm&&fhB06J19_norm_(c.customerId)===q.norm)return true; if(q.digits&&fhB06J19_digits_(c.phone).indexOf(q.digits)>=0)return true; if(q.norm){ if(fhB06J19_hay_(c).indexOf(q.norm)>=0)return true; var keys=fhB06J19_dh_(c); for(var i=0;i<keys.length;i++){ if(keys[i]&&(keys[i]===q.norm||keys[i].indexOf(q.norm)>=0||q.norm.indexOf(keys[i])>=0))return true; } } return false; }
function fhB06J19_clean_(c){ c=c||{}; return {rowNumber:c.rowNumber||c._rowNumber||'',sourceSheet:c.sourceSheet||c._sheetName||'ERP_고객관리',customerId:fhB06J19_s_(c.customerId),name:fhB06J19_s_(c.name),phone:fhB06J19_s_(c.phone),email:fhB06J19_s_(c.email),memberType:fhB06J19_member_(c.memberType),customerType:fhB06J19_member_(c.customerType||c.memberType),regularCheck:fhB06J19_s_(c.regularCheck),eventType:fhB06J19_s_(c.eventType),qrSource:fhB06J19_s_(c.qrSource),dong:fhB06J19_s_(c.dong),hosu:fhB06J19_s_(fhB06J19_hosu_(c)),aptName:fhB06J19_s_(c.aptName),address:fhB06J19_s_(c.address),status:fhB06J19_s_(c.status),eventId:fhB06J19_s_(c.eventId),vendorId:fhB06J19_s_(c.vendorId),createdAt:fhB06J19_s_(c.createdAt),updatedAt:fhB06J19_s_(c.updatedAt),memo:fhB06J19_s_(c.memo),notes:fhB06J19_s_(c.notes)}; }
function searchCustomers(query){ var q={raw:fhB06J19_s_(query),norm:fhB06J19_norm_(query),digits:fhB06J19_digits_(query)}, rows=fhB06J19_rows_(), seen={}, out=[]; for(var i=rows.length-1;i>=0;i--){ var c=fhB06J19_clean_(rows[i]); if(!c.customerId)continue; if(!fhB06J19_match_(c,q))continue; var k=fhB06J19_norm_(c.customerId); if(seen[k])continue; seen[k]=true; out.push(c); if(out.length>=100)break;} return out; }
function getRecentCustomers(limit){ var max=Number(limit||20); if(!max||max<1)max=20; return searchCustomers('').slice(0,max); }
function getCustomerDetail(customerId){ var idn=fhB06J19_norm_(customerId); if(!idn)throw new Error('customerId가 필요합니다.'); var rows=fhB06J19_rows_(); for(var i=0;i<rows.length;i++){ var c=fhB06J19_clean_(rows[i]); if(fhB06J19_norm_(c.customerId)===idn)return {customer:c,sales:[],evidenceQueue:[],timeline:{sales:[],installs:[],evidence:[],cancellations:[]}};} throw new Error('고객을 찾지 못했습니다: '+customerId); }
// B06J28: legacy erpB06J function removed: erpB06J19_customerSearchPreflight_

// B06J28: legacy erpB06J function removed: erpB06J19_runSelfTest_

function getBuildInfo(){ return {buildNo:FEELHAUS_B06J19.BUILD,buildTitle:FEELHAUS_B06J19.TITLE,generatedAt:new Date()}; }

/********************************************************
 * ERP v64-B06J33A CUSTOMER SEARCH ALIGN FIX - ALIASES
 ********************************************************/
// B06J28: legacy erpB06J function removed: erpB06J20_customerSearchAlignPreflight_

// B06J28: legacy erpB06J function removed: erpB06J20_runSelfTest_



/********** FEELHAUS ERP v64-B06J33A CUSTOMER SEARCH + PROMOTION BUTTON GUARD VERIFY **********/
// B06J28: legacy erpB06J function removed: erpB06J21A_customerSearchPromotionGuardPreflight_

// B06J28: legacy erpB06J function removed: erpB06J21A_runSelfTest_

// B06J28: legacy erpB06J function removed: erpB06J21_customerSearchPromotionGuardPreflight_

// B06J28: legacy erpB06J function removed: erpB06J21_runSelfTest_

function getBuildInfo(){ return {buildNo:'v64-B06J33A',buildTitle:'ERP 통합빌드 v64-B06J33A 설치확인서 흐름 고정 버전정리본',generatedAt:new Date()}; }

/********** FEELHAUS ERP v64-B06J33A PROMOTION SERVER RESET SEARCH STABLE SAFE **********/
var FEELHAUS_B06J22 = {
  BUILD: 'v64-B06J33A',
  SETUP_DB_ID: '17VMSpgSZCvIrUlgcw8yCNcnl8WQWo2IcRf5tDCcuJGM',
  CONFIG_SHEET_NAME: 'SystemConfig',
  CUSTOMER_SHEET: 'ERP_고객관리',
  MASTER_CONFIG_KEYS: ['FEELHAUS_DB_MASTER','FEELHAUS_DB_MASTER_ID','MASTER_DB_ID','MASTER_SPREADSHEET_ID']
};
function fhB06J22_s_(v){ return String(v === undefined || v === null ? '' : v).trim(); }
function fhB06J22_norm_(v){ return fhB06J22_s_(v).replace(/\uFEFF/g,'').replace(/[\s\-_.()\/\\]/g,'').toUpperCase(); }
function fhB06J22_member_(v){ var n=fhB06J22_norm_(v); if(n==='REGULAR'||n==='정회원'||n==='CONFIRMEDREGULAR') return 'REGULAR'; if(n==='ASSOCIATE'||n==='준회원'||n==='준회원고객') return 'ASSOCIATE'; return fhB06J22_s_(v).toUpperCase(); }
function fhB06J22_now_(){ return Utilities.formatDate(new Date(), Session.getScriptTimeZone() || 'Asia/Seoul', 'yyyy-MM-dd HH:mm:ss'); }
function fhB06J22_actor_(){ try { return Session.getActiveUser().getEmail() || 'unknown@local'; } catch(e) { return 'unknown@local'; } }
function fhB06J22_readSystemConfig_(){
  var setup = SpreadsheetApp.openById(FEELHAUS_B06J22.SETUP_DB_ID);
  var sh = setup.getSheetByName(FEELHAUS_B06J22.CONFIG_SHEET_NAME);
  if(!sh) throw new Error('FEELHAUS_SETUP_DB에서 SystemConfig 시트를 찾지 못했습니다.');
  var values = sh.getDataRange().getDisplayValues();
  if(!values || values.length < 2) throw new Error('SystemConfig 데이터가 없습니다.');
  var headers = values[0].map(function(h){ return fhB06J22_s_(h).replace(/^\uFEFF/,''); });
  var upper = headers.map(function(h){ return h.toUpperCase(); });
  var keyCol = upper.indexOf('CONFIG_KEY');
  var valueCol = upper.indexOf('VALUE');
  if(keyCol < 0 || valueCol < 0) throw new Error('SystemConfig 표준 헤더 CONFIG_KEY / VALUE가 필요합니다. 현재 헤더: '+headers.join(', '));
  var map = {};
  for(var r=1; r<values.length; r++){ var k = fhB06J22_s_(values[r][keyCol]); if(k) map[k] = fhB06J22_s_(values[r][valueCol]); }
  return {headers:headers,map:map,rowCount:values.length-1};
}
function fhB06J22_getMasterDb_(){
  var cfg = fhB06J22_readSystemConfig_(); var id='', key='';
  FEELHAUS_B06J22.MASTER_CONFIG_KEYS.forEach(function(k){ if(!id && cfg.map[k]){ id=cfg.map[k]; key=k; } });
  if(!id) throw new Error('SystemConfig CONFIG_KEY/VALUE에서 FEELHAUS_DB_MASTER 값을 찾지 못했습니다. 확인 키: '+FEELHAUS_B06J22.MASTER_CONFIG_KEYS.join(', '));
  try { return {ss:SpreadsheetApp.openById(id), masterDbId:id, sourceKey:key}; }
  catch(e){ throw new Error('FEELHAUS_DB_MASTER 스프레드시트 열기 실패. sourceKey='+key+', id='+id+', message='+(e&&e.message?e.message:e)); }
}
function fhB06J22_headers_(sh){ var width = Math.max(sh.getLastColumn(), 1); var headers = sh.getRange(1,1,1,width).getDisplayValues()[0].map(fhB06J22_s_); var map = {}; headers.forEach(function(h,i){ if(h && map[h] == null) map[h]=i; }); return {headers:headers,map:map}; }
function fhB06J22_customerRef_(){
  var env = fhB06J22_getMasterDb_(); var sh = env.ss.getSheetByName(FEELHAUS_B06J22.CUSTOMER_SHEET);
  if(!sh) throw new Error('FEELHAUS_DB_MASTER에서 ERP_고객관리 시트를 찾지 못했습니다. masterDbId='+env.masterDbId);
  var hm = fhB06J22_headers_(sh); var missing=[];
  ['customerId','eventId','dong','hosu','memberType','customerType','status','updatedAt','updatedBy'].forEach(function(h){ if(hm.map[h] == null) missing.push(h); });
  if(missing.length) throw new Error('ERP_고객관리 필수 헤더 누락: '+missing.join(', ')+' / 호수 표준은 hosu입니다.');
  return {env:env, sheet:sh, headers:hm.headers, map:hm.map};
}
function fhB06J22_obj_(headers,row,rowNo){
  var o={rowNumber:rowNo,sourceSheet:FEELHAUS_B06J22.CUSTOMER_SHEET}; headers.forEach(function(h,i){ if(h) o[h]=row[i]; });
  o.customerId=fhB06J22_s_(o.customerId); o.eventId=fhB06J22_s_(o.eventId); o.name=fhB06J22_s_(o.name); o.phone=fhB06J22_s_(o.phone); o.email=fhB06J22_s_(o.email); o.dong=fhB06J22_s_(o.dong); o.hosu=fhB06J22_s_(o.hosu)||fhB06J22_s_(o.ho); o.memberType=fhB06J22_member_(o.memberType||o.customerType); o.customerType=fhB06J22_member_(o.customerType||o.memberType); o.regularCheck=fhB06J22_s_(o.regularCheck); o.status=fhB06J22_s_(o.status)||'ACTIVE'; o.notes=fhB06J22_s_(o.notes); o.memo=fhB06J22_s_(o.memo); return o;
}
function fhB06J22_readCustomers_(){ var ref = fhB06J22_customerRef_(); var rows=[]; if(ref.sheet.getLastRow() >= 2){ var vals=ref.sheet.getRange(2,1,ref.sheet.getLastRow()-1,ref.sheet.getLastColumn()).getDisplayValues(); for(var i=0;i<vals.length;i++){ var o=fhB06J22_obj_(ref.headers,vals[i],i+2); if(o.customerId) rows.push(o); } } return {env:ref.env, sheet:ref.sheet, headers:ref.headers, map:ref.map, rows:rows}; }
function fhB06J22_findCustomer_(rows, customerId){ var idn=fhB06J22_norm_(customerId); if(!idn) return null; for(var i=0;i<rows.length;i++){ if(fhB06J22_norm_(rows[i].customerId)===idn) return rows[i]; } return null; }
function fhB06J22_isRegular_(c){ return !!c && (fhB06J22_member_(c.memberType)==='REGULAR' || fhB06J22_member_(c.customerType)==='REGULAR' || fhB06J22_norm_(c.regularCheck)==='CONFIRMED'); }
function fhB06J22_findDuplicateRegular_(rows,eventId,dong,hosu,excludeCustomerId){ var ev=fhB06J22_norm_(eventId), dg=fhB06J22_norm_(dong), hs=fhB06J22_norm_(hosu), ex=fhB06J22_norm_(excludeCustomerId); for(var i=0;i<rows.length;i++){ var r=rows[i]; if(fhB06J22_norm_(r.customerId)===ex) continue; if(fhB06J22_norm_(r.eventId)===ev && fhB06J22_norm_(r.dong)===dg && fhB06J22_norm_(r.hosu)===hs && fhB06J22_isRegular_(r)) return r; } return null; }
function fhB06J22_setCell_(sheet,rowNo,map,key,value){ if(map[key] != null) sheet.getRange(rowNo, map[key]+1).setValue(value); }
function fhB06J22_ensureSheet_(ss,name,headers){ var sh=ss.getSheetByName(name); if(!sh) sh=ss.insertSheet(name); if(sh.getLastRow()<1){ sh.getRange(1,1,1,headers.length).setValues([headers]); return sh; } var lastCol=Math.max(sh.getLastColumn(),1); var existing=sh.getRange(1,1,1,lastCol).getDisplayValues()[0].map(fhB06J22_s_); var add=[]; headers.forEach(function(h){ if(existing.indexOf(h)<0) add.push(h); }); if(add.length) sh.getRange(1,existing.length+1,1,add.length).setValues([add]); return sh; }
function fhB06J22_appendByHeader_(sh,obj){ var headers=sh.getRange(1,1,1,sh.getLastColumn()).getDisplayValues()[0].map(fhB06J22_s_); sh.appendRow(headers.map(function(h){ return obj[h] !== undefined ? obj[h] : ''; })); }
function fhB06J22_id_(prefix){ return prefix + Utilities.formatDate(new Date(), Session.getScriptTimeZone() || 'Asia/Seoul','yyyyMMddHHmmss') + '-' + Utilities.getUuid().replace(/-/g,'').substring(0,6).toUpperCase(); }
function fhB06J22_payload_(payload,target){ payload=payload||{}; return { customerId:fhB06J22_s_(payload.customerId), eventId:fhB06J22_s_(payload.eventId)||fhB06J22_s_(target&&target.eventId), dong:fhB06J22_s_(payload.dong)||fhB06J22_s_(target&&target.dong), hosu:fhB06J22_s_(payload.hosu||payload.ho)||fhB06J22_s_(target&&target.hosu), promotionSource:fhB06J22_s_(payload.promotionSource||'FIELD_MANAGER_CONFIRM'), promotionReason:fhB06J22_s_(payload.promotionReason||payload.reason) }; }
function fhB06J22_validatePromotion_(p,target){ if(!p.customerId) throw new Error('정회원 승격은 선택된 customerId가 필요합니다. 고객 검색 후 고객을 선택하세요.'); if(!target) throw new Error('승격 대상 고객을 찾지 못했습니다: '+p.customerId); if(fhB06J22_isRegular_(target)) throw new Error('이미 정회원으로 확인된 고객입니다: '+p.customerId); if(fhB06J22_member_(target.memberType)!=='ASSOCIATE' && fhB06J22_member_(target.customerType)!=='ASSOCIATE') throw new Error('정회원 승격 대상은 준회원(ASSOCIATE) 고객이어야 합니다. 현재 memberType='+target.memberType+', customerType='+target.customerType); if(!p.eventId||!p.dong||!p.hosu) throw new Error('정회원 승격은 eventId + dong + hosu가 필요합니다. 선택 고객의 행사/동/호수를 확인하세요.'); if(!p.promotionSource) throw new Error('승격 사유구분이 필요합니다.'); if(!p.promotionReason) throw new Error('승격 사유를 입력하세요.'); }
function fhB06J22_writeLogs_(ss,actionType,targetId,status,reason,beforeObj,afterObj,approvedBy){ var actor=fhB06J22_actor_(), now=fhB06J22_now_(); try{ var logSh=fhB06J22_ensureSheet_(ss,'SystemLogs',['logId','createdAt','createdBy','actionType','targetId','status','statusReason','beforeValue','afterValue','meta','reason','buildNo']); fhB06J22_appendByHeader_(logSh,{logId:fhB06J22_id_('LOG-'),createdAt:now,createdBy:actor,actionType:actionType,targetId:targetId,status:status,statusReason:reason,beforeValue:JSON.stringify(beforeObj||{}),afterValue:JSON.stringify(afterObj||{}),meta:JSON.stringify({source:'ERP_CUSTOMER_PROMOTION',buildNo:FEELHAUS_B06J22.BUILD}),reason:reason,buildNo:FEELHAUS_B06J22.BUILD}); }catch(e){ Logger.log('B06J22 SystemLogs write skipped: '+(e&&e.message?e.message:e)); } try{ var auditSh=fhB06J22_ensureSheet_(ss,'ApprovalAudit',['auditId','auditType','refId','status','actor','targetId','note','createdAt','actionType','beforeValue','afterValue','reason','approvedBy','buildNo']); fhB06J22_appendByHeader_(auditSh,{auditId:fhB06J22_id_('AUD-'),auditType:'CUSTOMER_PROMOTION',refId:targetId,status:status,actor:actor,targetId:targetId,note:reason,createdAt:now,actionType:actionType,beforeValue:JSON.stringify(beforeObj||{}),afterValue:JSON.stringify(afterObj||{}),reason:reason,approvedBy:approvedBy||'',buildNo:FEELHAUS_B06J22.BUILD}); }catch(e2){ Logger.log('B06J22 ApprovalAudit write skipped: '+(e2&&e2.message?e2.message:e2)); } }
// B06J28: legacy erpB06J function removed: erpB06J22_requestCustomerPromotionSafe_

// B06J28: legacy erpB06J function removed: erpB06J22_promoteCustomerToRegularSafe_

function requestCustomerPromotion(payload){ return erpB06J22_requestCustomerPromotionSafe(payload); }
function promoteCustomerToRegular(payload){ return erpB06J22_promoteCustomerToRegularSafe(payload); }
// B06J28: legacy erpB06J function removed: erpB06J22_promotionServerPreflight_

// B06J28: legacy erpB06J function removed: erpB06J22_runSelfTest_

function getBuildInfo(){ return {buildNo:'v64-B06J33A',buildTitle:'ERP 통합빌드 v64-B06J33A 설치확인서 흐름 고정 버전정리본',generatedAt:new Date()}; }


/********** FEELHAUS ERP v64-B06J33A FINAL SAFE PUBLIC TEST + PROMOTION OVERRIDE **********/
var FEELHAUS_B06J23 = { BUILD:'v64-B06J33A' };
function fhB06J23_ok_(message,data){ return {ok:true,message:message||'OK',data:data||{},errorCode:'',meta:{buildNo:FEELHAUS_B06J23.BUILD,generatedAt:new Date()}}; }
function fhB06J23_fail_(message,code,data){ return {ok:false,message:message||'처리 실패',data:data||{},errorCode:code||'B06J23_FAILED',meta:{buildNo:FEELHAUS_B06J23.BUILD,generatedAt:new Date()}}; }
function fhB06J23_promotionCall_(mode,payload){ try{ if(mode === 'REQUEST') return erpB06J22_requestCustomerPromotionSafe_(payload||{}); return erpB06J22_promoteCustomerToRegularSafe_(payload||{}); }catch(e){ return fhB06J23_fail_((e && e.message) ? e.message : String(e), mode==='REQUEST'?'CUSTOMER_PROMOTION_REQUEST_FAILED':'CUSTOMER_PROMOTION_APPROVE_FAILED', {payload:payload||{}, stack:(e&&e.stack)||''}); } }
function requestCustomerPromotion(payload){ return fhB06J23_promotionCall_('REQUEST', payload); }
function promoteCustomerToRegular(payload){ return fhB06J23_promotionCall_('APPROVE_NOW', payload); }
// B06J28: legacy run/test function removed: erpB06J23_runInternalTest

function getBuildInfo(){ return {buildNo:'v64-B06J33A',buildTitle:'ERP 통합빌드 v64-B06J33A 고객검색/승격 안정 재구성본',generatedAt:new Date()}; }

/********** FEELHAUS ERP v64-B06J33A INSTALL CONFIRM WORKLIST VERIFY SAFE **********/
var FEELHAUS_B06J24 = {
  BUILD: 'v64-B06J33A',
  SALE_SHEETS: ['Sales','ERP_판매관리','ERP_Sales','판매관리'],
  DOCUMENT_SHEETS: ['SIGN_Documents','Documents','ERP_문서관리'],
  INSTALL_SHEETS: ['Installs','ERP_설치관리','Installations','InstallCompletions'],
  SETTLEMENT_SHEETS: ['Settlements','ERP_정산관리','ERP_Settlements']
};
// B06J28: legacy erpB06J function removed: erpB06J24_s_

// B06J28: legacy erpB06J function removed: erpB06J24_norm_

// B06J28: legacy erpB06J function removed: erpB06J24_pick_

// B06J28: legacy erpB06J function removed: erpB06J24_isInstallConfirmDoc_

// B06J28: legacy erpB06J function removed: erpB06J24_buildDocIndex_

// B06J28: legacy erpB06J function removed: erpB06J24_isCompletedInstall_

// B06J28: legacy erpB06J function removed: erpB06J24_buildInstallTargets_

// B06J28: legacy erpB06J function removed: erpB06J24_getWorklists_

function fhOpsUiB05GetWorklists(payload){ return erpB06J24_getWorklists_(payload||{}); }
function fhOpsUiB05HetWorklists(payload){ return erpB06J24_getWorklists_(payload||{}); }
function getBuildInfo(){ return {buildNo:'v64-B06J33A',buildTitle:'ERP 통합빌드 v64-B06J33A 설치확인서 생성대상 표시 검증',generatedAt:new Date()}; }
// B06J28: legacy run/test function removed: erpB06J24_runInternalTest


/********** FEELHAUS ERP v64-B06J33A INSTALL CONFIRM FLOW LOCK SAFE **********/
var FEELHAUS_B06J28 = {
  BUILD: 'v64-B06J33A',
  TITLE: 'ERP 통합빌드 v64-B06J33A 설치확인서 생성대상/최근문서 흐름 고정'
};
// B06J28: legacy erpB06J function removed: erpB06J28_ok_

// B06J28: legacy erpB06J function removed: erpB06J28_fail_

// B06J28: legacy erpB06J function removed: erpB06J28_isInstallConfirmDoc_

// B06J28: legacy erpB06J function removed: erpB06J28_installDocSummary_

// B06J28: legacy erpB06J function removed: erpB06J28_getWorklists_

function fhOpsUiB05GetWorklists(payload){ return erpB06J28_getWorklists_(payload || {}); }
function fhOpsUiB05HetWorklists(payload){ return erpB06J28_getWorklists_(payload || {}); }
// B06J28: legacy run/test function removed: B06J28_legacy_removed

function getBuildInfo(){ return { buildNo:FEELHAUS_B06J28.BUILD, buildTitle:FEELHAUS_B06J28.TITLE, generatedAt:new Date() }; }

/********** FEELHAUS ERP v64-B06J33A CONTRACT WORKLIST LATEST SALE FIX SAFE **********/
var FEELHAUS_B06J28 = {
  BUILD: 'v64-B06J33A',
  TITLE: 'ERP 통합빌드 v64-B06J33A B05 목록 새로고침 바인딩/렌더링 보정본',
  SALE_SHEETS: ['Sales','ERP_판매관리','ERP_Sales','판매관리'],
  DOCUMENT_SHEETS: ['SIGN_Documents','Documents','ERP_문서관리'],
  INSTALL_SHEETS: ['Installs','ERP_설치관리','Installations','InstallCompletions'],
  SETTLEMENT_SHEETS: ['Settlements','ERP_정산관리','ERP_Settlements']
};
var erpB06J28_ok_ = function(message, data) { return {ok:true, message:message||'OK', data:data||{}, errorCode:'', meta:{buildNo:FEELHAUS_B06J28.BUILD, generatedAt:new Date().toISOString()}}; };
var erpB06J28_fail_ = function(message, code, data) { return {ok:false, message:message||'처리 실패', data:data||{}, errorCode:code||'B06J28_FAILED', meta:{buildNo:FEELHAUS_B06J28.BUILD, generatedAt:new Date().toISOString()}}; };
var erpB06J28_s_ = function(v) { return String(v === undefined || v === null ? '' : v).trim(); };
var erpB06J28_norm_ = function(v) { return erpB06J28_s_(v).replace(/\uFEFF/g,'').replace(/[\s\-_.()\/\\]/g,'').toUpperCase(); };
var erpB06J28_pick_ = function(row, keys) { row=row||{}; for(var i=0;i<keys.length;i++){ var v=row[keys[i]]; if(v!==undefined && v!==null && erpB06J28_s_(v)!=='') return erpB06J28_s_(v); } return ''; };
var erpB06J28_saleObj_ = function(row) {
  var saleId = erpB06J28_pick_(row, ['saleId','saleID','id','판매ID','판매Id']);
  return {
    sourceSheet: row._sheetName || row.sourceSheet || '', rowNumber: row._rowNumber || row.rowNumber || '',
    saleId: saleId,
    eventId: erpB06J28_pick_(row, ['eventId','eventID','행사ID']),
    vendorId: erpB06J28_pick_(row, ['vendorId','vendorID','업체ID']),
    customerId: erpB06J28_pick_(row, ['customerId','customerID','고객ID']),
    customerName: erpB06J28_pick_(row, ['customerName','name','customer','clientName','고객명','이름']),
    phone: erpB06J28_pick_(row, ['phone','customerPhone','전화번호','휴대폰']),
    productSummary: erpB06J28_pick_(row, ['productSummary','productName','itemName','상품명','품목명']),
    totalAmount: erpB06J28_pick_(row, ['totalAmount','saleAmount','amount','총금액','판매금액']),
    status: erpB06J28_pick_(row, ['status','saleStatus','상태']) || 'SAVED',
    saleStage: erpB06J28_pick_(row, ['saleStage','stage','판매단계']),
    installStatus: erpB06J28_pick_(row, ['installStatus','설치상태']),
    settlementStatus: erpB06J28_pick_(row, ['settlementStatus','정산상태']),
    createdAt: erpB06J28_pick_(row, ['createdAt','createdDate','registeredAt','등록일시','생성일시']),
    updatedAt: erpB06J28_pick_(row, ['updatedAt','수정일시']),
    raw: row
  };
};
var erpB06J28_isCancelledSale_ = function(sale) { var t=[sale.status,sale.saleStage,sale.raw&&sale.raw.statusReason].map(erpB06J28_s_).join(' ').toUpperCase(); return t.indexOf('CANCEL')>=0 || t.indexOf('VOID')>=0 || t.indexOf('DELETE')>=0 || t.indexOf('취소')>=0 || t.indexOf('삭제')>=0; };
var erpB06J28_docType_ = function(d) { return erpB06J28_s_(erpB06J28_pick_(d, ['documentType','docType','type','유형'])).toUpperCase(); };
var erpB06J28_docStatus_ = function(d) { return erpB06J28_s_(erpB06J28_pick_(d, ['status','documentStatus','signStatus','archiveStatus','상태'])).toUpperCase(); };
var erpB06J28_isContractDoc_ = function(d) { var t=erpB06J28_docType_(d); return t==='CONTRACT' || t.indexOf('CONTRACT')>=0 || t.indexOf('계약')>=0; };
var erpB06J28_isInstallConfirmDoc_ = function(d) { var t=erpB06J28_docType_(d); return t==='INSTALL_CONFIRM' || t.indexOf('INSTALL_CONFIRM')>=0 || t.indexOf('설치확인')>=0; };
var erpB06J28_buildDocIndex_ = function(docs) {
  var idx={bySaleContract:{}, byInstallConfirm:{}, byInstallConfirmSale:{}, bySettlementConfirm:{}, contractDocs:[], installConfirmDocs:[]};
  (docs||[]).forEach(function(d){
    var saleId=erpB06J28_pick_(d,['saleId','saleID','판매ID']);
    var installId=erpB06J28_pick_(d,['installId','설치ID']);
    var settlementId=erpB06J28_pick_(d,['settlementId','정산ID']);
    if(erpB06J28_isContractDoc_(d)){
      idx.contractDocs.push(d);
      if(saleId) idx.bySaleContract[erpB06J28_norm_(saleId)] = d;
    }
    if(erpB06J28_isInstallConfirmDoc_(d)){
      idx.installConfirmDocs.push(d);
      if(installId) idx.byInstallConfirm[erpB06J28_norm_(installId)] = d;
      if(saleId) idx.byInstallConfirmSale[erpB06J28_norm_(saleId)] = d;
    }
    var type=erpB06J28_docType_(d);
    if(settlementId && (type==='SETTLEMENT_CONFIRM' || type.indexOf('SETTLEMENT')>=0 || type.indexOf('정산')>=0)) idx.bySettlementConfirm[erpB06J28_norm_(settlementId)] = d;
  });
  return idx;
};
var erpB06J28_sortSalesLatest_ = function(arr) {
  return (arr||[]).slice().sort(function(a,b){
    var br=Number(b.rowNumber||0), ar=Number(a.rowNumber||0);
    var bd=erpB06J28_s_(b.createdAt||b.updatedAt), ad=erpB06J28_s_(a.createdAt||a.updatedAt);
    if(bd!==ad) return bd.localeCompare(ad);
    return br-ar;
  });
};
var erpB06J28_buildContractTargets_ = function(sales, docIndex, limit) {
  var normalized=[], seenAll={}, debugExcluded=[];
  (sales||[]).forEach(function(raw){
    var sale=erpB06J28_saleObj_(raw);
    if(!sale.saleId){ debugExcluded.push({reason:'NO_SALE_ID', sourceSheet:raw._sheetName||'', rowNumber:raw._rowNumber||''}); return; }
    var key=erpB06J28_norm_(sale.saleId);
    if(seenAll[key]){ debugExcluded.push({saleId:sale.saleId, reason:'DUPLICATE_SALE_ID', sourceSheet:sale.sourceSheet, rowNumber:sale.rowNumber}); return; }
    seenAll[key]=true;
    normalized.push(sale);
  });
  var rows=[];
  erpB06J28_sortSalesLatest_(normalized).forEach(function(sale){
    var key=erpB06J28_norm_(sale.saleId);
    var doc=docIndex.bySaleContract[key];
    if(erpB06J28_isCancelledSale_(sale)){ debugExcluded.push({saleId:sale.saleId, reason:'CANCELLED_OR_DELETED', status:sale.status, sourceSheet:sale.sourceSheet, rowNumber:sale.rowNumber}); return; }
    if(doc){ debugExcluded.push({saleId:sale.saleId, reason:'CONTRACT_DOC_EXISTS', documentId:erpB06J28_pick_(doc,['documentId','docId','문서ID']), documentStatus:erpB06J28_docStatus_(doc), sourceSheet:sale.sourceSheet, rowNumber:sale.rowNumber}); return; }
    rows.push(Object.assign({}, sale, {status:'계약서 생성대기', action:'CREATE_CONTRACT_DOC', actionLabel:'계약서 생성', documentId:'', documentStatus:'', worklistReason:'판매 저장 완료 / CONTRACT 문서 없음 / 설치상태 무관'}));
  });
  rows._debugExcluded = debugExcluded.slice(0,80);
  rows._recentSales = erpB06J28_sortSalesLatest_(normalized).slice(0,20).map(function(s){ return {saleId:s.saleId, customerId:s.customerId, status:s.status, saleStage:s.saleStage, sourceSheet:s.sourceSheet, rowNumber:s.rowNumber, createdAt:s.createdAt, hasContractDoc:!!docIndex.bySaleContract[erpB06J28_norm_(s.saleId)]}; });
  return rows.slice(0, Number(limit||50));
};
var erpB06J28_isCompletedInstall_ = function(r) {
  var txt=[erpB06J28_pick_(r,['status','installStatus','completionStatus','상태']), erpB06J28_pick_(r,['stage','installStage','installStep','설치단계']), erpB06J28_pick_(r,['completedAt','completedDate','설치완료일'])].join(' ');
  var up=txt.toUpperCase();
  return up.indexOf('COMPLETED')>=0 || up.indexOf('COMPLETE')>=0 || up.indexOf('DONE')>=0 || up.indexOf('INSTALL_DONE')>=0 || txt.indexOf('완료')>=0 || !!erpB06J28_pick_(r,['completedAt','completedDate','설치완료일']);
};
var erpB06J28_buildInstallTargets_ = function(installs, docIndex) {
  var out=[], seen={}, skipped=[];
  (installs||[]).forEach(function(r){
    var installId=erpB06J28_pick_(r,['installId','id','설치ID']);
    var saleId=erpB06J28_pick_(r,['saleId','판매ID']);
    var key=erpB06J28_norm_(installId || ('SALE_'+saleId));
    if(!key || seen[key]) return;
    seen[key]=true;
    if(!erpB06J28_isCompletedInstall_(r)) return;
    var hasDoc=(installId && docIndex.byInstallConfirm[erpB06J28_norm_(installId)]) || (saleId && docIndex.byInstallConfirmSale[erpB06J28_norm_(saleId)]);
    if(hasDoc){ skipped.push({installId:installId, saleId:saleId, documentId:erpB06J28_pick_(hasDoc,['documentId']), status:erpB06J28_docStatus_(hasDoc)}); return; }
    out.push({action:'CREATE_INSTALL_CONFIRM', actionLabel:'설치확인서 생성', installId:installId, saleId:saleId, customerId:erpB06J28_pick_(r,['customerId']), vendorId:erpB06J28_pick_(r,['vendorId']), eventId:erpB06J28_pick_(r,['eventId']), status:erpB06J28_pick_(r,['status','installStatus','stage','completionStatus'])||'설치완료', memo:'설치완료 / INSTALL_CONFIRM 문서 없음'});
  });
  out._skippedAlready = skipped;
  return out.slice(0,50);
};
var erpB06J28_getWorklists_ = function(payload) {
  try{
    return fhB05GetWorklists(payload || {});
    var ss=null;
    var sales=[];
    var docs=[];
    var installs=[];
    var settlements=[];
    var docIndex=erpB06J28_buildDocIndex_(docs);
    var contractTargets=erpB06J28_buildContractTargets_(sales, docIndex, 80);
    var installConfirmTargets=erpB06J28_buildInstallTargets_(installs, docIndex);
    var settlementConfirmTargets=(typeof erpB06J15_buildSettlementConfirmTargets_==='function') ? erpB06J15_buildSettlementConfirmTargets_(settlements, docIndex) : [];
    var pdfTargets=(typeof erpB06J15_buildPdfTargets_==='function') ? erpB06J15_buildPdfTargets_(docs) : [];
    var archiveTargets=(typeof erpB06J15_buildArchiveTargets_==='function') ? erpB06J15_buildArchiveTargets_(docs) : [];
    var qrSignTargets=(typeof erpB06J15_buildQrTargets_==='function') ? erpB06J15_buildQrTargets_(docs) : [];
    var data={
      buildNo:FEELHAUS_B06J28.BUILD,
      counts:{contractTargets:contractTargets.length, installConfirmTargets:installConfirmTargets.length, settlementConfirmTargets:settlementConfirmTargets.length, pdfTargets:pdfTargets.length, archiveTargets:archiveTargets.length, qrSignTargets:qrSignTargets.length, settlementActionTargets:0},
      contractTargets:contractTargets, installConfirmTargets:installConfirmTargets, settlementConfirmTargets:settlementConfirmTargets, pdfTargets:pdfTargets, archiveTargets:archiveTargets, qrSignTargets:qrSignTargets,
      settlementRequestTargets:[], settlementApproveTargets:[], settlementPaymentTargets:[], settlementActionTargets:[],
      debug:{
        buildNo:FEELHAUS_B06J28.BUILD,
        rule:'계약서 생성대상은 saleId가 있는 판매건 중 취소/삭제가 아니고 SIGN_Documents에 CONTRACT 문서가 아직 없는 건입니다. 설치완료 여부는 조건이 아닙니다.',
        salesRows:sales.length, docsRows:docs.length, installsRows:installs.length, settlementsRows:settlements.length,
        saleSheets:FEELHAUS_B06J28.SALE_SHEETS, documentSheets:FEELHAUS_B06J28.DOCUMENT_SHEETS,
        contractDocCount:docIndex.contractDocs.length,
        recentSales:contractTargets._recentSales || [],
        excludedSales:contractTargets._debugExcluded || [],
        installConfirmAlreadyCreated:installConfirmTargets._skippedAlready || []
      }
    };
    return erpB06J28_ok_('B06J28 목록 자동조회 완료', data);
  }catch(e){ return erpB06J28_fail_('B06J28 목록 자동조회 실패: '+((e&&e.message)||String(e)), 'B06J28_WORKLIST_FAILED', {stack:(e&&e.stack)||''}); }
};
function fhOpsUiB05GetWorklists(payload){ return erpB06J28_getWorklists_(payload || {}); }
function fhOpsUiB05HetWorklists(payload){ return erpB06J28_getWorklists_(payload || {}); }
function _erpB06J28_previousRunInternalTest__deprecated(){
  var out={buildNo:FEELHAUS_B06J28.BUILD, checks:[]};
  function step(name,fn){ try{ out.checks.push({name:name, ok:true, result:fn()}); }catch(e){ out.checks.push({name:name, ok:false, message:(e&&e.message)||String(e), stack:(e&&e.stack)||''}); } }
  step('B05 목록조회/계약서 생성대상', function(){ var r=erpB06J28_getWorklists_({action:'WORKLIST', reason:'B06J28 내부점검'}); return {ok:r&&r.ok, counts:r&&r.data&&r.data.counts, recentSales:r&&r.data&&r.data.debug&&r.data.debug.recentSales&&r.data.debug.recentSales.slice(0,5), excludedSales:r&&r.data&&r.data.debug&&r.data.debug.excludedSales&&r.data.debug.excludedSales.slice(0,5)}; });
  step('고객검색 안정기준 유지', function(){ var r=searchCustomers('김철수'); return {count:(r||[]).length, first:r&&r[0]&&r[0].customerId}; });
  var pass=out.checks.every(function(x){return x.ok;});
  return pass ? erpB06J28_ok_('B06J28 내부점검 통과', out) : erpB06J28_fail_('B06J28 내부점검 실패 항목 있음','B06J28_SELFTEST_FAILED',out);
}
function getBuildInfo(){ return {buildNo:FEELHAUS_B06J28.BUILD, buildTitle:FEELHAUS_B06J28.TITLE, generatedAt:new Date()}; }


/* ===== B06J28 B05 WORKLIST MASTER RESOLVER REPAIR - KEEP LAST ===== */
var FEELHAUS_B06J28 = Object.freeze({
  BUILD:'v64-B06J33A',
  TITLE:'ERP 통합빌드 v64-B06J33A B05 목록조회 마스터조회 의존성 복구',
  SETUP_DB_ID:'17VMSpgSZCvIrUlgcw8yCNcnl8WQWo2IcRf5tDCcuJGM',
  CONFIG_SHEET_NAME:'SystemConfig',
  MASTER_CONFIG_KEYS:['FEELHAUS_DB_MASTER_ID','FEELHAUS_DB_MASTER','DB_MASTER_ID','MASTER_DB_ID','DB_SPREADSHEET_ID','SPREADSHEET_ID'],
  SALE_SHEETS:['Sales','ERP_판매관리','ERP_Sales','판매관리'],
  DOCUMENT_SHEETS:['SIGN_Documents','Documents','ERP_문서관리','SIGN_DOCUMENTS'],
  INSTALL_SHEETS:['Installs','ERP_설치관리','Installations','InstallCompletions','InstallAssignments'],
  SETTLEMENT_SHEETS:['Settlements','ERP_정산관리','ERP_Settlements','SettlementTargets']
});
function fhB06J28_s_(v){ return String(v===undefined||v===null?'':v).trim(); }
function fhB06J28_norm_(v){ return fhB06J28_s_(v).replace(/[\s\-_.]/g,'').toUpperCase(); }
function fhB06J28_ok_(message,data){ return {ok:true,message:message||'OK',data:data||{},errorCode:'',meta:{buildNo:FEELHAUS_B06J28.BUILD,generatedAt:new Date().toISOString()}}; }
function fhB06J28_fail_(message,code,data){ return {ok:false,message:message||'처리 실패',data:data||{},errorCode:code||'B06J28_FAILED',meta:{buildNo:FEELHAUS_B06J28.BUILD,generatedAt:new Date().toISOString()}}; }
function fhB06J28_readSystemConfig_(){
  var setup = SpreadsheetApp.openById(FEELHAUS_B06J28.SETUP_DB_ID);
  var sh = setup.getSheetByName(FEELHAUS_B06J28.CONFIG_SHEET_NAME);
  if(!sh) throw new Error('FEELHAUS_SETUP_DB에서 SystemConfig 시트를 찾지 못했습니다.');
  var values = sh.getDataRange().getDisplayValues();
  if(!values || values.length < 2) throw new Error('SystemConfig 데이터가 없습니다.');
  var headers = values[0].map(function(h){ return fhB06J28_s_(h).replace(/^\uFEFF/,''); });
  var upper = headers.map(function(h){ return h.toUpperCase(); });
  var keyCol = upper.indexOf('CONFIG_KEY');
  if(keyCol < 0) keyCol = upper.indexOf('KEY');
  var valueCol = upper.indexOf('VALUE');
  if(keyCol < 0 || valueCol < 0) throw new Error('SystemConfig 표준 헤더 CONFIG_KEY / VALUE가 필요합니다. 현재 헤더: '+headers.join(', '));
  var map = {};
  for(var r=1; r<values.length; r++){
    var k=fhB06J28_s_(values[r][keyCol]);
    if(k) map[k]=fhB06J28_s_(values[r][valueCol]);
  }
  return {headers:headers,map:map,rowCount:values.length-1};
}
function fhB06J28_getMasterSpreadsheet_(){
  var cfg = fhB06J28_readSystemConfig_();
  var id='', key='';
  FEELHAUS_B06J28.MASTER_CONFIG_KEYS.forEach(function(k){ if(!id && cfg.map[k]){ id=cfg.map[k]; key=k; } });
  if(!id){
    var props = PropertiesService.getScriptProperties();
    FEELHAUS_B06J28.MASTER_CONFIG_KEYS.forEach(function(k){ if(!id && props.getProperty(k)){ id=props.getProperty(k); key='PROP:'+k; } });
  }
  if(!id) throw new Error('SystemConfig에서 FEELHAUS_DB_MASTER ID를 찾지 못했습니다. 확인 키: '+FEELHAUS_B06J28.MASTER_CONFIG_KEYS.join(', '));
  return {ss:SpreadsheetApp.openById(id), masterDbId:id, sourceKey:key, configRowCount:cfg.rowCount};
}
function fhB06J28_headerMap_(sh){
  var width = Math.max(sh.getLastColumn(),1);
  var headers = sh.getRange(1,1,1,width).getDisplayValues()[0].map(function(h){ return fhB06J28_s_(h).replace(/^\uFEFF/,''); });
  var map={}; headers.forEach(function(h,i){ if(h && map[h] == null) map[h]=i; });
  return {headers:headers,map:map};
}
function fhB06J28_rowObj_(headers,row,rowNo,sheetName){
  var o={_rowNumber:rowNo,rowNumber:rowNo,_sheetName:sheetName,sourceSheet:sheetName};
  headers.forEach(function(h,i){ if(h) o[h]=row[i]; });
  return o;
}
function fhB06J28_readTable_(ss, sheetName){
  var sh = ss.getSheetByName(sheetName);
  if(!sh || sh.getLastRow() < 2 || sh.getLastColumn() < 1) return [];
  var hm = fhB06J28_headerMap_(sh);
  var vals = sh.getRange(2,1,sh.getLastRow()-1,sh.getLastColumn()).getDisplayValues();
  var rows=[];
  for(var i=0;i<vals.length;i++){
    if(vals[i].join('').trim()==='') continue;
    rows.push(fhB06J28_rowObj_(hm.headers, vals[i], i+2, sheetName));
  }
  return rows;
}
function fhB06J28_readSheets_(ss, names){
  var all=[];
  (names||[]).forEach(function(n){ all=all.concat(fhB06J28_readTable_(ss,n)); });
  return all;
}
function fhB06J28_pick_(row, keys){
  row=row||{}; keys=keys||[];
  for(var i=0;i<keys.length;i++){
    var v=row[keys[i]];
    if(v!==undefined && v!==null && String(v).trim()!=='') return String(v).trim();
  }
  return '';
}
function fhB06J28_docType_(d){ return fhB06J28_pick_(d,['documentType','docType','type','유형']).toUpperCase(); }
function fhB06J28_docStatus_(d){ return fhB06J28_pick_(d,['status','documentStatus','signStatus','archiveStatus','상태']).toUpperCase(); }
function fhB06J28_isContractDoc_(d){ var t=fhB06J28_docType_(d); return t==='CONTRACT' || t.indexOf('CONTRACT')>=0 || t.indexOf('계약')>=0; }
function fhB06J28_isInstallConfirmDoc_(d){ var t=fhB06J28_docType_(d); return t==='INSTALL_CONFIRM' || t.indexOf('INSTALL_CONFIRM')>=0 || t.indexOf('설치확인')>=0; }
function fhB06J28_isSettlementConfirmDoc_(d){ var t=fhB06J28_docType_(d); return t==='SETTLEMENT_CONFIRM' || t.indexOf('SETTLEMENT')>=0 || t.indexOf('정산')>=0; }
function fhB06J28_buildDocIndex_(docs){
  var idx={bySaleContract:{},byInstallConfirm:{},byInstallConfirmSale:{},bySettlementConfirm:{},contractDocs:[],installConfirmDocs:[]};
  (docs||[]).forEach(function(d){
    var saleId=fhB06J28_pick_(d,['saleId','saleID','판매ID']);
    var installId=fhB06J28_pick_(d,['installId','설치ID']);
    var settlementId=fhB06J28_pick_(d,['settlementId','정산ID']);
    if(fhB06J28_isContractDoc_(d)){ idx.contractDocs.push(d); if(saleId) idx.bySaleContract[fhB06J28_norm_(saleId)]=d; }
    if(fhB06J28_isInstallConfirmDoc_(d)){ idx.installConfirmDocs.push(d); if(installId) idx.byInstallConfirm[fhB06J28_norm_(installId)]=d; if(saleId) idx.byInstallConfirmSale[fhB06J28_norm_(saleId)]=d; }
    if(settlementId && fhB06J28_isSettlementConfirmDoc_(d)) idx.bySettlementConfirm[fhB06J28_norm_(settlementId)] = d;
  });
  return idx;
}
function fhB06J28_saleObj_(row){
  return {
    rowNumber:row._rowNumber||row.rowNumber||'', sourceSheet:row._sheetName||row.sourceSheet||'',
    saleId:fhB06J28_pick_(row,['saleId','saleID','id','판매ID']),
    eventId:fhB06J28_pick_(row,['eventId','행사ID']), vendorId:fhB06J28_pick_(row,['vendorId','업체ID']), customerId:fhB06J28_pick_(row,['customerId','고객ID']),
    customerName:fhB06J28_pick_(row,['customerName','name','customer','clientName','고객명','이름']), phone:fhB06J28_pick_(row,['phone','customerPhone','전화번호','휴대폰']),
    productSummary:fhB06J28_pick_(row,['productSummary','productName','itemName','상품명','품목명']), totalAmount:fhB06J28_pick_(row,['totalAmount','saleAmount','amount','총금액','판매금액']),
    status:fhB06J28_pick_(row,['status','saleStatus','상태']) || 'SAVED', saleStage:fhB06J28_pick_(row,['saleStage','stage','판매단계']),
    installStatus:fhB06J28_pick_(row,['installStatus','설치상태']), settlementStatus:fhB06J28_pick_(row,['settlementStatus','정산상태']),
    createdAt:fhB06J28_pick_(row,['createdAt','createdDate','registeredAt','등록일시','생성일시']), updatedAt:fhB06J28_pick_(row,['updatedAt','수정일시']), raw:row
  };
}
function fhB06J28_isCancelledSale_(sale){ var t=[sale.status,sale.saleStage,sale.raw&&sale.raw.statusReason].map(fhB06J28_s_).join(' ').toUpperCase(); return t.indexOf('CANCEL')>=0 || t.indexOf('VOID')>=0 || t.indexOf('DELETE')>=0 || t.indexOf('취소')>=0 || t.indexOf('삭제')>=0; }
function fhB06J28_sortLatest_(arr){ return (arr||[]).slice().sort(function(a,b){ var br=Number(b.rowNumber||0), ar=Number(a.rowNumber||0); var bd=fhB06J28_s_(b.createdAt||b.updatedAt), ad=fhB06J28_s_(a.createdAt||a.updatedAt); if(bd!==ad) return bd.localeCompare(ad); return br-ar; }); }
function fhB06J28_buildContractTargets_(sales, docIndex, limit){
  var normalized=[], seen={}, debug=[];
  (sales||[]).forEach(function(raw){
    var sale=fhB06J28_saleObj_(raw);
    if(!sale.saleId){ debug.push({reason:'NO_SALE_ID',sourceSheet:raw._sheetName||'',rowNumber:raw._rowNumber||''}); return; }
    var key=fhB06J28_norm_(sale.saleId); if(seen[key]){ debug.push({saleId:sale.saleId,reason:'DUPLICATE_SALE_ID',sourceSheet:sale.sourceSheet,rowNumber:sale.rowNumber}); return; }
    seen[key]=true; normalized.push(sale);
  });
  var rows=[];
  fhB06J28_sortLatest_(normalized).forEach(function(sale){
    var key=fhB06J28_norm_(sale.saleId), doc=docIndex.bySaleContract[key];
    if(fhB06J28_isCancelledSale_(sale)){ debug.push({saleId:sale.saleId,reason:'CANCELLED_OR_DELETED',status:sale.status,sourceSheet:sale.sourceSheet,rowNumber:sale.rowNumber}); return; }
    if(doc){ debug.push({saleId:sale.saleId,reason:'CONTRACT_DOC_EXISTS',documentId:fhB06J28_pick_(doc,['documentId','docId','문서ID']),documentStatus:fhB06J28_docStatus_(doc),sourceSheet:sale.sourceSheet,rowNumber:sale.rowNumber}); return; }
    rows.push(Object.assign({},sale,{status:'계약서 생성대기',action:'CREATE_CONTRACT_DOC',actionLabel:'계약서 생성',documentId:'',documentStatus:'',worklistReason:'판매 저장 완료 / CONTRACT 문서 없음 / 설치상태 무관'}));
  });
  rows._debugExcluded=debug.slice(0,120);
  rows._recentSales=fhB06J28_sortLatest_(normalized).slice(0,30).map(function(s){return {saleId:s.saleId,customerId:s.customerId,status:s.status,saleStage:s.saleStage,sourceSheet:s.sourceSheet,rowNumber:s.rowNumber,createdAt:s.createdAt,hasContractDoc:!!docIndex.bySaleContract[fhB06J28_norm_(s.saleId)]};});
  return rows.slice(0,Number(limit||80));
}
function fhB06J28_isCompletedInstall_(r){
  var txt=[fhB06J28_pick_(r,['status','installStatus','completionStatus','상태']),fhB06J28_pick_(r,['stage','installStage','installStep','설치단계']),fhB06J28_pick_(r,['completedAt','completedDate','설치완료일'])].join(' ');
  var up=txt.toUpperCase();
  return up.indexOf('COMPLETED')>=0 || up.indexOf('COMPLETE')>=0 || up.indexOf('DONE')>=0 || up.indexOf('INSTALL_DONE')>=0 || txt.indexOf('완료')>=0 || !!fhB06J28_pick_(r,['completedAt','completedDate','설치완료일']);
}
function fhB06J28_buildInstallTargets_(installs, docIndex){
  var out=[], seen={}, skipped=[];
  (installs||[]).forEach(function(r){
    var installId=fhB06J28_pick_(r,['installId','id','설치ID']); var saleId=fhB06J28_pick_(r,['saleId','판매ID']);
    var key=fhB06J28_norm_(installId || ('SALE_'+saleId)); if(!key || seen[key]) return; seen[key]=true;
    if(!fhB06J28_isCompletedInstall_(r)) return;
    var hasDoc=(installId && docIndex.byInstallConfirm[fhB06J28_norm_(installId)]) || (saleId && docIndex.byInstallConfirmSale[fhB06J28_norm_(saleId)]);
    if(hasDoc){ skipped.push({installId:installId,saleId:saleId,documentId:fhB06J28_pick_(hasDoc,['documentId','docId']),status:fhB06J28_docStatus_(hasDoc)}); return; }
    out.push({action:'CREATE_INSTALL_CONFIRM',actionLabel:'설치확인서 생성',installId:installId,saleId:saleId,customerId:fhB06J28_pick_(r,['customerId','고객ID']),vendorId:fhB06J28_pick_(r,['vendorId','업체ID']),eventId:fhB06J28_pick_(r,['eventId','행사ID']),status:fhB06J28_pick_(r,['status','installStatus','stage','completionStatus'])||'설치완료',memo:'설치완료 / INSTALL_CONFIRM 문서 없음'});
  });
  out._skippedAlready=skipped; return out.slice(0,50);
}
function fhB06J28_buildPdfTargets_(docs){
  return (docs||[]).filter(function(d){ var st=fhB06J28_docStatus_(d); var pdf=fhB06J28_pick_(d,['pdfUrl','pdfFileId','pdfPath']); return !pdf && (st.indexOf('SIGN_COMPLETED')>=0 || st.indexOf('서명 완료')>=0 || st.indexOf('서명완료')>=0 || st.indexOf('PDF')>=0); }).slice(0,80).map(function(d){ return {documentId:fhB06J28_pick_(d,['documentId','docId','문서ID']),saleId:fhB06J28_pick_(d,['saleId']),type:fhB06J28_docType_(d)||fhB06J28_pick_(d,['documentType']),status:fhB06J28_pick_(d,['status','documentStatus','signStatus']),action:'CREATE_PDF',actionLabel:'PDF 생성'}; });
}
function fhB06J28_buildArchiveTargets_(docs){
  return (docs||[]).filter(function(d){ var pdf=fhB06J28_pick_(d,['pdfUrl','pdfFileId','pdfPath']); var arch=fhB06J28_pick_(d,['archiveStatus','archivedAt']); return pdf && !arch; }).slice(0,80).map(function(d){ return {documentId:fhB06J28_pick_(d,['documentId','docId','문서ID']),saleId:fhB06J28_pick_(d,['saleId']),type:fhB06J28_docType_(d)||fhB06J28_pick_(d,['documentType']),status:fhB06J28_pick_(d,['status','documentStatus','archiveStatus']),action:'ARCHIVE_DOC',actionLabel:'보관 완료'}; });
}
function fhB06J28_buildQrTargets_(docs){
  return (docs||[]).filter(function(d){ var type=fhB06J28_docType_(d); var st=fhB06J28_docStatus_(d); return type.indexOf('QR')>=0 || st.indexOf('QR')>=0; }).slice(0,80).map(function(d){ return {documentId:fhB06J28_pick_(d,['documentId','docId','문서ID']),status:fhB06J28_pick_(d,['status','documentStatus','signStatus']),nextAction:'PDF 생성',action:'CREATE_PDF',actionLabel:'PDF 생성'}; });
}
function fhB06J28_buildSettlementConfirmTargets_(settlements, docIndex){
  return (settlements||[]).filter(function(r){ var id=fhB06J28_pick_(r,['settlementId','id','정산ID']); if(!id) return false; if(docIndex.bySettlementConfirm[fhB06J28_norm_(id)]) return false; var st=fhB06J28_pick_(r,['status','settlementStatus','상태']); return st.indexOf('지급 완료')>=0 || String(st).toUpperCase().indexOf('PAID')>=0; }).slice(0,50).map(function(r){ return {settlementId:fhB06J28_pick_(r,['settlementId','id','정산ID']),vendorId:fhB06J28_pick_(r,['vendorId','업체ID']),status:fhB06J28_pick_(r,['status','settlementStatus','상태']),action:'CREATE_SETTLEMENT_CONFIRM',actionLabel:'정산확인서 생성'}; });
}
function fhB06J28_buildSettlementActionTargets_(settlements){
  var approve=[],pay=[],request=[];
  (settlements||[]).forEach(function(r){
    var id=fhB06J28_pick_(r,['settlementId','id','정산ID']); if(!id) return;
    var st=fhB06J28_pick_(r,['status','settlementStatus','상태']).toUpperCase();
    var base={settlementId:id,status:fhB06J28_pick_(r,['status','settlementStatus','상태']),pay:fhB06J28_pick_(r,['payAmount','amount','지급액']),vendorId:fhB06J28_pick_(r,['vendorId'])};
    if(st.indexOf('REQUEST')>=0 || st.indexOf('요청')>=0) approve.push(Object.assign({},base,{action:'APPROVE_SETTLEMENT',actionLabel:'승인'}));
    else if(st.indexOf('APPROVED')>=0 || st.indexOf('승인')>=0) pay.push(Object.assign({},base,{action:'PAY_SETTLEMENT',actionLabel:'지급 완료'}));
    else if(st.indexOf('READY')>=0 || st.indexOf('대기')>=0) request.push(Object.assign({},base,{action:'REQUEST_SETTLEMENT',actionLabel:'승인요청'}));
  });
  return {request:request.slice(0,50),approve:approve.slice(0,50),pay:pay.slice(0,50)};
}
function fhB06J28_getWorklists_(payload){
  try{
    var env=fhB06J28_getMasterSpreadsheet_(); var ss=env.ss;
    var sales=fhB06J28_readSheets_(ss,FEELHAUS_B06J28.SALE_SHEETS);
    var docs=fhB06J28_readSheets_(ss,FEELHAUS_B06J28.DOCUMENT_SHEETS);
    var installs=fhB06J28_readSheets_(ss,FEELHAUS_B06J28.INSTALL_SHEETS);
    var settlements=fhB06J28_readSheets_(ss,FEELHAUS_B06J28.SETTLEMENT_SHEETS);
    var docIndex=fhB06J28_buildDocIndex_(docs);
    var contractTargets=fhB06J28_buildContractTargets_(sales,docIndex,80);
    var installConfirmTargets=fhB06J28_buildInstallTargets_(installs,docIndex);
    var settlementConfirmTargets=fhB06J28_buildSettlementConfirmTargets_(settlements,docIndex);
    var pdfTargets=fhB06J28_buildPdfTargets_(docs);
    var archiveTargets=fhB06J28_buildArchiveTargets_(docs);
    var qrSignTargets=fhB06J28_buildQrTargets_(docs);
    var settlementActions=fhB06J28_buildSettlementActionTargets_(settlements);
    var data={
      buildNo:FEELHAUS_B06J28.BUILD,
      counts:{contractTargets:contractTargets.length,installConfirmTargets:installConfirmTargets.length,settlementConfirmTargets:settlementConfirmTargets.length,pdfTargets:pdfTargets.length,archiveTargets:archiveTargets.length,qrSignTargets:qrSignTargets.length,settlementRequestTargets:settlementActions.request.length,settlementApproveTargets:settlementActions.approve.length,settlementPaymentTargets:settlementActions.pay.length},
      contractTargets:contractTargets,installConfirmTargets:installConfirmTargets,settlementConfirmTargets:settlementConfirmTargets,pdfTargets:pdfTargets,archiveTargets:archiveTargets,qrSignTargets:qrSignTargets,
      settlementRequestTargets:settlementActions.request,settlementApproveTargets:settlementActions.approve,settlementPaymentTargets:settlementActions.pay,settlementActionTargets:[],
      debug:{buildNo:FEELHAUS_B06J28.BUILD,masterDbId:env.masterDbId,sourceKey:env.sourceKey,rule:'계약서 생성대상은 saleId가 있는 판매건 중 취소/삭제가 아니고 CONTRACT 문서가 아직 없는 건입니다. 설치완료 여부는 조건이 아닙니다.',salesRows:sales.length,docsRows:docs.length,installsRows:installs.length,settlementsRows:settlements.length,saleSheets:FEELHAUS_B06J28.SALE_SHEETS,documentSheets:FEELHAUS_B06J28.DOCUMENT_SHEETS,contractDocCount:docIndex.contractDocs.length,recentSales:contractTargets._recentSales||[],excludedSales:contractTargets._debugExcluded||[],installConfirmAlreadyCreated:installConfirmTargets._skippedAlready||[]}
    };
    return fhB06J28_ok_('B06J28 목록 자동조회 완료',data);
  }catch(e){ return fhB06J28_fail_('B06J28 목록 자동조회 실패: '+((e&&e.message)||e),'B06J28_WORKLIST_FAILED',{stack:(e&&e.stack)||''}); }
}
function fhOpsUiB05GetWorklists(payload){ return fhB06J28_getWorklists_(payload||{}); }
function fhOpsUiB05HetWorklists(payload){ return fhB06J28_getWorklists_(payload||{}); }
function _erpB06J28_previousRunInternalTest__legacy(){
  var res=fhB06J28_getWorklists_({test:true});
  if(!res || !res.ok) throw new Error((res&&res.message)||'B06J28 내부 테스트 실패');
  var d=res.data||{};
  return {ok:true,buildNo:FEELHAUS_B06J28.BUILD,message:'B06J28 내부 테스트 완료',counts:d.counts||{},debug:d.debug||{},meta:{generatedAt:new Date().toISOString()}};
}
function getBuildInfo_legacyB06J28_(){ return {buildNo:FEELHAUS_B06J28.BUILD,buildTitle:FEELHAUS_B06J28.TITLE,generatedAt:new Date()}; }

/** B06J29 B05 WORKLIST MODULE RESET */
var FEELHAUS_B06J29 = Object.freeze({
  BUILD:'v64-B06J33A',
  TITLE:'ERP 통합빌드 v64-B06J33A 카드 접힘/펼침·섹션 이동·이벤트 포커스 1차',
  SETUP_DB_ID:'17VMSpgSZCvIrUlgcw8yCNcnl8WQWo2IcRf5tDCcuJGM',
  CONFIG_SHEET_NAME:'SystemConfig',
  MASTER_CONFIG_KEYS:['FEELHAUS_DB_MASTER_ID','FEELHAUS_DB_MASTER','DB_MASTER_ID','MASTER_DB_ID','DB_SPREADSHEET_ID','SPREADSHEET_ID'],
  SALE_SHEETS:['Sales','ERP_판매관리','ERP_Sales','판매관리'],
  DOCUMENT_SHEETS:['SIGN_Documents','Documents','ERP_문서관리','SIGN_DOCUMENTS'],
  INSTALL_SHEETS:['Installs','ERP_설치관리','Installations','InstallCompletions','InstallAssignments'],
  SETTLEMENT_SHEETS:['Settlements','ERP_정산관리','ERP_Settlements','SettlementTargets']
});
function fhB06J29_s_(v){ return String(v===undefined||v===null?'':v).trim(); }
function fhB06J29_norm_(v){ return fhB06J29_s_(v).replace(/[\s\-_.]/g,'').toUpperCase(); }
function fhB06J29_ok_(message,data){ return {ok:true,message:message||'OK',data:data||{},errorCode:'',meta:{buildNo:FEELHAUS_B06J29.BUILD,generatedAt:new Date().toISOString()}}; }
function fhB06J29_fail_(message,code,data){ return {ok:false,message:message||'처리 실패',data:data||{},errorCode:code||'B06J29_FAILED',meta:{buildNo:FEELHAUS_B06J29.BUILD,generatedAt:new Date().toISOString()}}; }
function fhB06J29_readSystemConfig_(){
  var setup = SpreadsheetApp.openById(FEELHAUS_B06J29.SETUP_DB_ID);
  var sh = setup.getSheetByName(FEELHAUS_B06J29.CONFIG_SHEET_NAME);
  if(!sh) throw new Error('FEELHAUS_SETUP_DB에서 SystemConfig 시트를 찾지 못했습니다.');
  var values = sh.getDataRange().getDisplayValues();
  if(!values || values.length < 2) throw new Error('SystemConfig 데이터가 없습니다.');
  var headers = values[0].map(function(h){ return fhB06J29_s_(h).replace(/^\uFEFF/,''); });
  var upper = headers.map(function(h){ return h.toUpperCase(); });
  var keyCol = upper.indexOf('CONFIG_KEY');
  if(keyCol < 0) keyCol = upper.indexOf('KEY');
  var valueCol = upper.indexOf('VALUE');
  if(keyCol < 0 || valueCol < 0) throw new Error('SystemConfig 표준 헤더 CONFIG_KEY / VALUE가 필요합니다. 현재 헤더: '+headers.join(', '));
  var map = {};
  for(var r=1; r<values.length; r++){
    var k=fhB06J29_s_(values[r][keyCol]);
    if(k) map[k]=fhB06J29_s_(values[r][valueCol]);
  }
  return {headers:headers,map:map,rowCount:values.length-1};
}
function fhB06J29_getMasterSpreadsheet_(){
  var cfg = fhB06J29_readSystemConfig_();
  var id='', key='';
  FEELHAUS_B06J29.MASTER_CONFIG_KEYS.forEach(function(k){ if(!id && cfg.map[k]){ id=cfg.map[k]; key=k; } });
  if(!id){
    var props = PropertiesService.getScriptProperties();
    FEELHAUS_B06J29.MASTER_CONFIG_KEYS.forEach(function(k){ if(!id && props.getProperty(k)){ id=props.getProperty(k); key='PROP:'+k; } });
  }
  if(!id) throw new Error('SystemConfig에서 FEELHAUS_DB_MASTER ID를 찾지 못했습니다. 확인 키: '+FEELHAUS_B06J29.MASTER_CONFIG_KEYS.join(', '));
  return {ss:SpreadsheetApp.openById(id), masterDbId:id, sourceKey:key, configRowCount:cfg.rowCount};
}
function fhB06J29_headerMap_(sh){
  var width = Math.max(sh.getLastColumn(),1);
  var headers = sh.getRange(1,1,1,width).getDisplayValues()[0].map(function(h){ return fhB06J29_s_(h).replace(/^\uFEFF/,''); });
  var map={}; headers.forEach(function(h,i){ if(h && map[h] == null) map[h]=i; });
  return {headers:headers,map:map};
}
function fhB06J29_rowObj_(headers,row,rowNo,sheetName){
  var o={_rowNumber:rowNo,rowNumber:rowNo,_sheetName:sheetName,sourceSheet:sheetName};
  headers.forEach(function(h,i){ if(h) o[h]=row[i]; });
  return o;
}
function fhB06J29_readTable_(ss, sheetName){
  var sh = ss.getSheetByName(sheetName);
  if(!sh || sh.getLastRow() < 2 || sh.getLastColumn() < 1) return [];
  var hm = fhB06J29_headerMap_(sh);
  var vals = sh.getRange(2,1,sh.getLastRow()-1,sh.getLastColumn()).getDisplayValues();
  var rows=[];
  for(var i=0;i<vals.length;i++){
    if(vals[i].join('').trim()==='') continue;
    rows.push(fhB06J29_rowObj_(hm.headers, vals[i], i+2, sheetName));
  }
  return rows;
}
function fhB06J29_readSheets_(ss, names){
  var all=[];
  (names||[]).forEach(function(n){ all=all.concat(fhB06J29_readTable_(ss,n)); });
  return all;
}
function fhB06J29_pick_(row, keys){
  row=row||{}; keys=keys||[];
  for(var i=0;i<keys.length;i++){
    var v=row[keys[i]];
    if(v!==undefined && v!==null && String(v).trim()!=='') return String(v).trim();
  }
  return '';
}
function fhB06J29_docType_(d){ return fhB06J29_pick_(d,['documentType','docType','type','유형']).toUpperCase(); }
function fhB06J29_docStatus_(d){ return fhB06J29_pick_(d,['status','documentStatus','signStatus','archiveStatus','상태']).toUpperCase(); }
function fhB06J29_isContractDoc_(d){ var t=fhB06J29_docType_(d); return t==='CONTRACT' || t.indexOf('CONTRACT')>=0 || t.indexOf('계약')>=0; }
function fhB06J29_isInstallConfirmDoc_(d){ var t=fhB06J29_docType_(d); return t==='INSTALL_CONFIRM' || t.indexOf('INSTALL_CONFIRM')>=0 || t.indexOf('설치확인')>=0; }
function fhB06J29_isSettlementConfirmDoc_(d){ var t=fhB06J29_docType_(d); return t==='SETTLEMENT_CONFIRM' || t.indexOf('SETTLEMENT')>=0 || t.indexOf('정산')>=0; }
function fhB06J29_buildDocIndex_(docs){
  var idx={bySaleContract:{},byInstallConfirm:{},byInstallConfirmSale:{},bySettlementConfirm:{},contractDocs:[],installConfirmDocs:[]};
  (docs||[]).forEach(function(d){
    var saleId=fhB06J29_pick_(d,['saleId','saleID','판매ID']);
    var installId=fhB06J29_pick_(d,['installId','설치ID']);
    var settlementId=fhB06J29_pick_(d,['settlementId','정산ID']);
    if(fhB06J29_isContractDoc_(d)){ idx.contractDocs.push(d); if(saleId) idx.bySaleContract[fhB06J29_norm_(saleId)]=d; }
    if(fhB06J29_isInstallConfirmDoc_(d)){ idx.installConfirmDocs.push(d); if(installId) idx.byInstallConfirm[fhB06J29_norm_(installId)]=d; if(saleId) idx.byInstallConfirmSale[fhB06J29_norm_(saleId)]=d; }
    if(settlementId && fhB06J29_isSettlementConfirmDoc_(d)) idx.bySettlementConfirm[fhB06J29_norm_(settlementId)] = d;
  });
  return idx;
}
function fhB06J29_saleObj_(row){
  return {
    rowNumber:row._rowNumber||row.rowNumber||'', sourceSheet:row._sheetName||row.sourceSheet||'',
    saleId:fhB06J29_pick_(row,['saleId','saleID','id','판매ID']),
    eventId:fhB06J29_pick_(row,['eventId','행사ID']), vendorId:fhB06J29_pick_(row,['vendorId','업체ID']), customerId:fhB06J29_pick_(row,['customerId','고객ID']),
    customerName:fhB06J29_pick_(row,['customerName','name','customer','clientName','고객명','이름']), phone:fhB06J29_pick_(row,['phone','customerPhone','전화번호','휴대폰']),
    productSummary:fhB06J29_pick_(row,['productSummary','productName','itemName','상품명','품목명']), totalAmount:fhB06J29_pick_(row,['totalAmount','saleAmount','amount','총금액','판매금액']),
    status:fhB06J29_pick_(row,['status','saleStatus','상태']) || 'SAVED', saleStage:fhB06J29_pick_(row,['saleStage','stage','판매단계']),
    installStatus:fhB06J29_pick_(row,['installStatus','설치상태']), settlementStatus:fhB06J29_pick_(row,['settlementStatus','정산상태']),
    createdAt:fhB06J29_pick_(row,['createdAt','createdDate','registeredAt','등록일시','생성일시']), updatedAt:fhB06J29_pick_(row,['updatedAt','수정일시']), raw:row
  };
}
function fhB06J29_isCancelledSale_(sale){ var t=[sale.status,sale.saleStage,sale.raw&&sale.raw.statusReason].map(fhB06J29_s_).join(' ').toUpperCase(); return t.indexOf('CANCEL')>=0 || t.indexOf('VOID')>=0 || t.indexOf('DELETE')>=0 || t.indexOf('취소')>=0 || t.indexOf('삭제')>=0; }
function fhB06J29_sortLatest_(arr){ return (arr||[]).slice().sort(function(a,b){ var br=Number(b.rowNumber||0), ar=Number(a.rowNumber||0); var bd=fhB06J29_s_(b.createdAt||b.updatedAt), ad=fhB06J29_s_(a.createdAt||a.updatedAt); if(bd!==ad) return bd.localeCompare(ad); return br-ar; }); }
function fhB06J29_buildContractTargets_(sales, docIndex, limit){
  var normalized=[], seen={}, debug=[];
  (sales||[]).forEach(function(raw){
    var sale=fhB06J29_saleObj_(raw);
    if(!sale.saleId){ debug.push({reason:'NO_SALE_ID',sourceSheet:raw._sheetName||'',rowNumber:raw._rowNumber||''}); return; }
    var key=fhB06J29_norm_(sale.saleId); if(seen[key]){ debug.push({saleId:sale.saleId,reason:'DUPLICATE_SALE_ID',sourceSheet:sale.sourceSheet,rowNumber:sale.rowNumber}); return; }
    seen[key]=true; normalized.push(sale);
  });
  var rows=[];
  fhB06J29_sortLatest_(normalized).forEach(function(sale){
    var key=fhB06J29_norm_(sale.saleId), doc=docIndex.bySaleContract[key];
    if(fhB06J29_isCancelledSale_(sale)){ debug.push({saleId:sale.saleId,reason:'CANCELLED_OR_DELETED',status:sale.status,sourceSheet:sale.sourceSheet,rowNumber:sale.rowNumber}); return; }
    if(doc){ debug.push({saleId:sale.saleId,reason:'CONTRACT_DOC_EXISTS',documentId:fhB06J29_pick_(doc,['documentId','docId','문서ID']),documentStatus:fhB06J29_docStatus_(doc),sourceSheet:sale.sourceSheet,rowNumber:sale.rowNumber}); return; }
    rows.push(Object.assign({},sale,{status:'계약서 생성대기',action:'CREATE_CONTRACT_DOC',actionLabel:'계약서 생성',documentId:'',documentStatus:'',worklistReason:'판매 저장 완료 / CONTRACT 문서 없음 / 설치상태 무관'}));
  });
  rows._debugExcluded=debug.slice(0,120);
  rows._recentSales=fhB06J29_sortLatest_(normalized).slice(0,30).map(function(s){return {saleId:s.saleId,customerId:s.customerId,status:s.status,saleStage:s.saleStage,sourceSheet:s.sourceSheet,rowNumber:s.rowNumber,createdAt:s.createdAt,hasContractDoc:!!docIndex.bySaleContract[fhB06J29_norm_(s.saleId)]};});
  return rows.slice(0,Number(limit||80));
}
function fhB06J29_isCompletedInstall_(r){
  var txt=[fhB06J29_pick_(r,['status','installStatus','completionStatus','상태']),fhB06J29_pick_(r,['stage','installStage','installStep','설치단계']),fhB06J29_pick_(r,['completedAt','completedDate','설치완료일'])].join(' ');
  var up=txt.toUpperCase();
  return up.indexOf('COMPLETED')>=0 || up.indexOf('COMPLETE')>=0 || up.indexOf('DONE')>=0 || up.indexOf('INSTALL_DONE')>=0 || txt.indexOf('완료')>=0 || !!fhB06J29_pick_(r,['completedAt','completedDate','설치완료일']);
}
function fhB06J29_buildInstallTargets_(installs, docIndex){
  var out=[], seen={}, skipped=[];
  (installs||[]).forEach(function(r){
    var installId=fhB06J29_pick_(r,['installId','id','설치ID']); var saleId=fhB06J29_pick_(r,['saleId','판매ID']);
    var key=fhB06J29_norm_(installId || ('SALE_'+saleId)); if(!key || seen[key]) return; seen[key]=true;
    if(!fhB06J29_isCompletedInstall_(r)) return;
    var hasDoc=(installId && docIndex.byInstallConfirm[fhB06J29_norm_(installId)]) || (saleId && docIndex.byInstallConfirmSale[fhB06J29_norm_(saleId)]);
    if(hasDoc){ skipped.push({installId:installId,saleId:saleId,documentId:fhB06J29_pick_(hasDoc,['documentId','docId']),status:fhB06J29_docStatus_(hasDoc)}); return; }
    out.push({action:'CREATE_INSTALL_CONFIRM',actionLabel:'설치확인서 생성',installId:installId,saleId:saleId,customerId:fhB06J29_pick_(r,['customerId','고객ID']),vendorId:fhB06J29_pick_(r,['vendorId','업체ID']),eventId:fhB06J29_pick_(r,['eventId','행사ID']),status:fhB06J29_pick_(r,['status','installStatus','stage','completionStatus'])||'설치완료',memo:'설치완료 / INSTALL_CONFIRM 문서 없음'});
  });
  out._skippedAlready=skipped; return out.slice(0,50);
}
function fhB06J29_buildPdfTargets_(docs){
  return (docs||[]).filter(function(d){ var st=fhB06J29_docStatus_(d); var pdf=fhB06J29_pick_(d,['pdfUrl','pdfFileId','pdfPath']); return !pdf && (st.indexOf('SIGN_COMPLETED')>=0 || st.indexOf('서명 완료')>=0 || st.indexOf('서명완료')>=0 || st.indexOf('PDF')>=0); }).slice(0,80).map(function(d){ return {documentId:fhB06J29_pick_(d,['documentId','docId','문서ID']),saleId:fhB06J29_pick_(d,['saleId']),type:fhB06J29_docType_(d)||fhB06J29_pick_(d,['documentType']),status:fhB06J29_pick_(d,['status','documentStatus','signStatus']),action:'CREATE_PDF',actionLabel:'PDF 생성'}; });
}
function fhB06J29_buildArchiveTargets_(docs){
  return (docs||[]).filter(function(d){ var pdf=fhB06J29_pick_(d,['pdfUrl','pdfFileId','pdfPath']); var arch=fhB06J29_pick_(d,['archiveStatus','archivedAt']); return pdf && !arch; }).slice(0,80).map(function(d){ return {documentId:fhB06J29_pick_(d,['documentId','docId','문서ID']),saleId:fhB06J29_pick_(d,['saleId']),type:fhB06J29_docType_(d)||fhB06J29_pick_(d,['documentType']),status:fhB06J29_pick_(d,['status','documentStatus','archiveStatus']),action:'ARCHIVE_DOC',actionLabel:'보관 완료'}; });
}
function fhB06J29_buildQrTargets_(docs){
  return (docs||[]).filter(function(d){ var type=fhB06J29_docType_(d); var st=fhB06J29_docStatus_(d); return type.indexOf('QR')>=0 || st.indexOf('QR')>=0; }).slice(0,80).map(function(d){ return {documentId:fhB06J29_pick_(d,['documentId','docId','문서ID']),status:fhB06J29_pick_(d,['status','documentStatus','signStatus']),nextAction:'PDF 생성',action:'CREATE_PDF',actionLabel:'PDF 생성'}; });
}
function fhB06J29_buildSettlementConfirmTargets_(settlements, docIndex){
  return (settlements||[]).filter(function(r){ var id=fhB06J29_pick_(r,['settlementId','id','정산ID']); if(!id) return false; if(docIndex.bySettlementConfirm[fhB06J29_norm_(id)]) return false; var st=fhB06J29_pick_(r,['status','settlementStatus','상태']); return st.indexOf('지급 완료')>=0 || String(st).toUpperCase().indexOf('PAID')>=0; }).slice(0,50).map(function(r){ return {settlementId:fhB06J29_pick_(r,['settlementId','id','정산ID']),vendorId:fhB06J29_pick_(r,['vendorId','업체ID']),status:fhB06J29_pick_(r,['status','settlementStatus','상태']),action:'CREATE_SETTLEMENT_CONFIRM',actionLabel:'정산확인서 생성'}; });
}
function fhB06J29_buildSettlementActionTargets_(settlements){
  var approve=[],pay=[],request=[];
  (settlements||[]).forEach(function(r){
    var id=fhB06J29_pick_(r,['settlementId','id','정산ID']); if(!id) return;
    var st=fhB06J29_pick_(r,['status','settlementStatus','상태']).toUpperCase();
    var base={settlementId:id,status:fhB06J29_pick_(r,['status','settlementStatus','상태']),pay:fhB06J29_pick_(r,['payAmount','amount','지급액']),vendorId:fhB06J29_pick_(r,['vendorId'])};
    if(st.indexOf('REQUEST')>=0 || st.indexOf('요청')>=0) approve.push(Object.assign({},base,{action:'APPROVE_SETTLEMENT',actionLabel:'승인'}));
    else if(st.indexOf('APPROVED')>=0 || st.indexOf('승인')>=0) pay.push(Object.assign({},base,{action:'PAY_SETTLEMENT',actionLabel:'지급 완료'}));
    else if(st.indexOf('READY')>=0 || st.indexOf('대기')>=0) request.push(Object.assign({},base,{action:'REQUEST_SETTLEMENT',actionLabel:'승인요청'}));
  });
  return {request:request.slice(0,50),approve:approve.slice(0,50),pay:pay.slice(0,50)};
}
function fhB06J29_getWorklists_(payload){
  try{
    var env=fhB06J29_getMasterSpreadsheet_(); var ss=env.ss;
    var sales=fhB06J29_readSheets_(ss,FEELHAUS_B06J29.SALE_SHEETS);
    var docs=fhB06J29_readSheets_(ss,FEELHAUS_B06J29.DOCUMENT_SHEETS);
    var installs=fhB06J29_readSheets_(ss,FEELHAUS_B06J29.INSTALL_SHEETS);
    var settlements=fhB06J29_readSheets_(ss,FEELHAUS_B06J29.SETTLEMENT_SHEETS);
    var docIndex=fhB06J29_buildDocIndex_(docs);
    var contractTargets=fhB06J29_buildContractTargets_(sales,docIndex,80);
    var installConfirmTargets=fhB06J29_buildInstallTargets_(installs,docIndex);
    var settlementConfirmTargets=fhB06J29_buildSettlementConfirmTargets_(settlements,docIndex);
    var pdfTargets=fhB06J29_buildPdfTargets_(docs);
    var archiveTargets=fhB06J29_buildArchiveTargets_(docs);
    var qrSignTargets=fhB06J29_buildQrTargets_(docs);
    var settlementActions=fhB06J29_buildSettlementActionTargets_(settlements);
    var data={
      buildNo:FEELHAUS_B06J29.BUILD,
      counts:{contractTargets:contractTargets.length,installConfirmTargets:installConfirmTargets.length,settlementConfirmTargets:settlementConfirmTargets.length,pdfTargets:pdfTargets.length,archiveTargets:archiveTargets.length,qrSignTargets:qrSignTargets.length,settlementRequestTargets:settlementActions.request.length,settlementApproveTargets:settlementActions.approve.length,settlementPaymentTargets:settlementActions.pay.length},
      contractTargets:contractTargets,installConfirmTargets:installConfirmTargets,settlementConfirmTargets:settlementConfirmTargets,pdfTargets:pdfTargets,archiveTargets:archiveTargets,qrSignTargets:qrSignTargets,
      settlementRequestTargets:settlementActions.request,settlementApproveTargets:settlementActions.approve,settlementPaymentTargets:settlementActions.pay,settlementActionTargets:[],
      debug:{buildNo:FEELHAUS_B06J29.BUILD,masterDbId:env.masterDbId,sourceKey:env.sourceKey,rule:'계약서 생성대상은 saleId가 있는 판매건 중 취소/삭제가 아니고 CONTRACT 문서가 아직 없는 건입니다. 설치완료 여부는 조건이 아닙니다.',salesRows:sales.length,docsRows:docs.length,installsRows:installs.length,settlementsRows:settlements.length,saleSheets:FEELHAUS_B06J29.SALE_SHEETS,documentSheets:FEELHAUS_B06J29.DOCUMENT_SHEETS,contractDocCount:docIndex.contractDocs.length,recentSales:contractTargets._recentSales||[],excludedSales:contractTargets._debugExcluded||[],installConfirmAlreadyCreated:installConfirmTargets._skippedAlready||[]}
    };
    return fhB06J29_ok_('B06J29 목록 자동조회 완료',data);
  }catch(e){ return fhB06J29_fail_('B06J29 목록 자동조회 실패: '+((e&&e.message)||e),'B06J29_WORKLIST_FAILED',{stack:(e&&e.stack)||''}); }
}
function fhB05GetWorklists(payload){ return fhB06J29_getWorklists_(payload||{}); }
function fhOpsUiB05GetWorklists(payload){ return fhB05GetWorklists(payload||{}); }
function fhOpsUiB05HetWorklists(payload){ return fhB05GetWorklists(payload||{}); }
function _fhPreviousUiScrollRunInternalTest__deprecated(){
  var res=fhB06J29_getWorklists_({test:true});
  if(!res || !res.ok) throw new Error((res&&res.message)||'B06J32 이전 UI 스크롤 내부 테스트 실패');
  var d=res.data||{};
  return {ok:true,buildNo:FEELHAUS_B06J29.BUILD,message:'B06J32 이전 UI 스크롤 내부 테스트 완료',counts:d.counts||{},debug:d.debug||{},meta:{generatedAt:new Date().toISOString()}};
}
function getBuildInfo(){ return {buildNo:FEELHAUS_B06J29.BUILD,buildTitle:FEELHAUS_B06J29.TITLE,generatedAt:new Date()}; }

/** B06J29 hard route: prevent legacy B05 worklist functions from taking old/deprecated paths. */
var fhOpsUiB05GetWorklists = function(payload){ return fhB05GetWorklists(payload || {}); };
var fhOpsUiB05HetWorklists = function(payload){ return fhB05GetWorklists(payload || {}); };
var erpB06J28_getWorklists_ = function(payload){ return fhB05GetWorklists(payload || {}); };


/********** FEELHAUS ERP v64-B06J33A UI CARD COLLAPSE + SECTION NAV SAFE **********/
function erpB06J32_uiCardPreflight_(){
  return {
    ok: true,
    buildNo: 'v64-B06J33A',
    message: 'B06J32 내부 테스트 완료: UI 카드 접힘/펼침·섹션 이동·이벤트 포커스 스크립트 확인',
    checks: {
      b05ServerAvailable: typeof fhB05GetWorklists === 'function',
      customerSearchAvailable: typeof searchCustomers === 'function',
      promotionRequestAvailable: typeof requestCustomerPromotion === 'function',
      promotionImmediateAvailable: typeof promoteCustomerToRegular === 'function'
    },
    meta: { generatedAt: new Date().toISOString() }
  };
}
function getBuildInfo(){
  return { buildNo: 'v64-B06J33A', buildTitle: 'ERP 통합빌드 v64-B06J33A 카드 접힘/펼침·섹션 이동·이벤트 포커스 1차', generatedAt: new Date() };
}


/**
 * FEELHAUS ERP v64-B06J33A FIELD QR ACTION RESET SAFE
 * - 현장 공용입장 QR 버튼 서버 진입부 고정
 * - 지정형 QR 대상/일괄생성 기존 안정 함수 래핑
 */
function erpB06J32_runInternalTest(){
  return {
    ok:true,
    message:'B06J32 내부 점검 완료',
    data:{
      build:'v64-B06J33A',
      functions:{
        runInternalTest: typeof erpB06J32_runInternalTest === 'function',
        createPublicEntryQrLink: typeof fhB06J32_createPublicEntryQrLink === 'function',
        getRegularQrTargets: typeof fhB06J2GetRegularQrTargets === 'function',
        bulkCreateAssigned: typeof bulkCreateAssignedFieldQrDocuments === 'function'
      }
    },
    errorCode:'',
    meta:{build:'v64-B06J33A', generatedAt:new Date()}
  };
}

function fhB06J32_createPublicEntryQrLink(payload){
  try{
    payload = payload || {};
    var env = fhB06J1FieldQrSetup_();
    var ss = env.masterDb;
    var eventId = String(payload.eventId || '').trim();
    if(!eventId) throw new Error('공용입장 QR은 행사 선택이 필수입니다.');
    var eventName = String(payload.eventName || '').trim() || fhB06J1GetEventName_(ss, eventId) || eventId;
    var boothHint = String(payload.boothHint || payload.boothName || '').trim();
    var base = fhB06J1SignBaseUrl_(env.config);
    if(!base) throw new Error('SIGN_WEBAPP_URL을 찾을 수 없습니다. SystemConfig를 확인하세요.');
    var url = base.split('?')[0] + '?mode=qr&fieldMode=QR&qrEntry=Y&entryType=PUBLIC&eventId=' + encodeURIComponent(eventId) + '&eventName=' + encodeURIComponent(eventName) + '&boothHint=' + encodeURIComponent(boothHint);
    var data = {
      linkOnly:true,
      isPublicEntry:true,
      documentId:'',
      documentNo:'',
      status:'PUBLIC_ENTRY_LINK',
      qrType:'PUBLIC',
      entryType:'PUBLIC',
      eventId:eventId,
      eventName:eventName,
      boothHint:boothHint,
      unitHint:'',
      qrUrl:url,
      signUrl:url,
      qrImageUrl:fhB06J1QrImageUrl_(url),
      buildNo:'v64-B06J33A'
    };
    return {ok:true, message:'행사 공용입장 QR 링크 생성 완료', data:data, errorCode:'', meta:{build:'v64-B06J33A', generatedAt:new Date()}};
  }catch(err){
    return {ok:false, message:'공용입장 QR 링크 생성 실패: ' + ((err && err.message) || String(err)), data:{payload:payload||{}, stack:(err&&err.stack)||''}, errorCode:'PUBLIC_QR_LINK_FAILED', meta:{build:'v64-B06J33A', generatedAt:new Date()}};
  }
}

// 기존 버튼/구버전 호출 호환: 최종 진입을 B06J32로 고정
function createPublicEntryQrLink(payload){
  return fhB06J32_createPublicEntryQrLink(payload);
}

/**
 * FEELHAUS ERP v64-B06J33A FUNCTION RECOVERY REGRESSION SAFE
 * 목적: 정보로딩/화면 안정화 과정에서 끊긴 주요 서버 진입 함수 존재성 점검 및 안전 래퍼 제공.
 * 원칙: 기존 고객검색/승격/판매/B05/QR 핵심 로직 삭제 금지, 호출 안정화만 수행.
 */
function erpB06J33A_runInternalTest(){
  var checks = [];
  function add(name, ok){ checks.push({name:name, exists:!!ok}); }
  add('searchCustomers', typeof searchCustomers === 'function');
  add('getRecentCustomers', typeof getRecentCustomers === 'function');
  add('getCustomerDetail', typeof getCustomerDetail === 'function');
  add('requestCustomerPromotion', typeof requestCustomerPromotion === 'function');
  add('promoteCustomerToRegular', typeof promoteCustomerToRegular === 'function');
  add('saveSale', typeof saveSale === 'function');
  add('completeInstallation', typeof completeInstallation === 'function');
  add('fhB05GetWorklists', typeof fhB05GetWorklists === 'function');
  add('fhOpsUiB05GetWorklists', typeof fhOpsUiB05GetWorklists === 'function');
  add('fhOpsUiB05HetWorklists', typeof fhOpsUiB05HetWorklists === 'function');
  add('fhB06J33A_createPublicEntryQrLink', typeof fhB06J33A_createPublicEntryQrLink === 'function');
  add('fhB06J33A_getAssignedQrTargets', typeof fhB06J33A_getAssignedQrTargets === 'function');
  add('fhB06J33A_createAssignedQrBulk', typeof fhB06J33A_createAssignedQrBulk === 'function');
  var missing = checks.filter(function(x){return !x.exists;}).map(function(x){return x.name;});
  return {
    ok: missing.length === 0,
    message: missing.length ? 'B06J33A 내부점검: 일부 함수 누락 확인' : 'B06J33A 내부점검 통과',
    data: {
      build: 'v64-B06J33A',
      checked: checks,
      missing: missing,
      fixed: 'b06j33 client-only script files removed from Apps Script server files',
      guidance: 'Apps Script 실행 드롭다운에서 erpB06J33A_runInternalTest만 실행합니다. 화면 기능은 웹앱 새 버전 배포 후 버튼별로 점검합니다.'
    },
    errorCode: missing.length ? 'B06J33A_MISSING_FUNCTIONS' : '',
    meta: { build:'v64-B06J33A', generatedAt: new Date() }
  };
}

function fhB06J33A_response_(ok, message, data, errorCode){
  return { ok:!!ok, message:message||'', data:data||null, errorCode:errorCode||'', meta:{build:'v64-B06J33A', generatedAt:new Date()} };
}

function fhB06J33A_createPublicEntryQrLink(payload){
  try{
    if (typeof fhB06J32_createPublicEntryQrLink === 'function') return fhB06J32_createPublicEntryQrLink(payload||{});
    if (typeof createPublicEntryQrLink === 'function') return createPublicEntryQrLink(payload||{});
    return fhB06J33A_response_(false, '공용입장 QR 생성 서버 함수가 없습니다.', {payload:payload||{}}, 'PUBLIC_QR_FUNCTION_NOT_FOUND');
  }catch(err){
    return fhB06J33A_response_(false, '공용입장 QR 생성 실패: ' + ((err&&err.message)||String(err)), {payload:payload||{}, stack:(err&&err.stack)||''}, 'PUBLIC_QR_FAILED');
  }
}

function fhB06J33A_getAssignedQrTargets(payload){
  try{
    if (typeof listFieldQrBulkTargets === 'function') return listFieldQrBulkTargets(payload||{});
    if (typeof fhB06J2GetFieldQrTargets === 'function') return fhB06J2GetFieldQrTargets(payload||{});
    if (typeof getFieldQrBulkTargets === 'function') return getFieldQrBulkTargets(payload||{});
    return fhB06J33A_response_(false, '지정형 QR 대상 조회 서버 함수가 없습니다.', {payload:payload||{}}, 'ASSIGNED_QR_TARGET_FUNCTION_NOT_FOUND');
  }catch(err){
    return fhB06J33A_response_(false, '지정형 QR 대상 조회 실패: ' + ((err&&err.message)||String(err)), {payload:payload||{}, stack:(err&&err.stack)||''}, 'ASSIGNED_QR_TARGET_FAILED');
  }
}

function fhB06J33A_createAssignedQrBulk(payload){
  try{
    if (typeof createFieldQrBulkAssignedDocuments === 'function') return createFieldQrBulkAssignedDocuments(payload||{});
    if (typeof createFieldQrBulkAssigned === 'function') return createFieldQrBulkAssigned(payload||{});
    if (typeof fhB06J2CreateFieldQrBulkAssigned === 'function') return fhB06J2CreateFieldQrBulkAssigned(payload||{});
    return fhB06J33A_response_(false, '지정형 QR 일괄 생성 서버 함수가 없습니다.', {payload:payload||{}}, 'ASSIGNED_QR_BULK_FUNCTION_NOT_FOUND');
  }catch(err){
    return fhB06J33A_response_(false, '지정형 QR 일괄 생성 실패: ' + ((err&&err.message)||String(err)), {payload:payload||{}, stack:(err&&err.stack)||''}, 'ASSIGNED_QR_BULK_FAILED');
  }
}

/**
 * FEELHAUS ERP v64-B06J34C QR PUBLIC ENTRY EVENT HANDLER FIX SAFE
 * 목적:
 * - 브라우저 이벤트 객체가 서버 응답처럼 표시되는 [object Event] 문제 차단
 * - 공용입장 QR 응답 구조를 ok/message/data/errorCode/meta로 고정
 * - 고객검색/승격/판매/B05/설치/정산 기존 기능 미수정
 */
var FEELHAUS_B06J34C = {
  BUILD: 'v64-B06J34C',
  TITLE: 'ERP 통합빌드 v64-B06J34C QR 공용입장 이벤트핸들러/배지잠금 안전보정'
};
var FEELHAUS_B06J34A = FEELHAUS_B06J34C;

function fhB06J34A_now_(){ return new Date(); }

function fhB06J34A_response_(ok, message, data, errorCode){
  return {
    ok: !!ok,
    message: message || '',
    data: data || {},
    errorCode: errorCode || '',
    meta: { build: FEELHAUS_B06J34A.BUILD, generatedAt: fhB06J34A_now_() }
  };
}

function fhB06J34A_createPublicEntryQrLink(payload){
  try{
    payload = payload || {};
    var res;
    if (typeof fhB06J32_createPublicEntryQrLink === 'function') {
      res = fhB06J32_createPublicEntryQrLink(payload);
    } else if (typeof fhB06J33A_createPublicEntryQrLink === 'function') {
      res = fhB06J33A_createPublicEntryQrLink(payload);
    } else if (typeof createPublicEntryQrLink === 'function') {
      res = createPublicEntryQrLink(payload);
    } else {
      return fhB06J34A_response_(false, '공용입장 QR 생성 서버 함수가 없습니다.', { payload: payload }, 'PUBLIC_QR_FUNCTION_NOT_FOUND');
    }

    if (!res || res.ok === false) {
      return fhB06J34A_response_(false, (res && (res.message || res.errorCode)) || '공용입장 QR 링크 생성 실패', { original: res || null, payload: payload }, (res && res.errorCode) || 'PUBLIC_QR_FAILED');
    }

    var d = (res && res.data) ? res.data : res;
    d = d || {};
    var url = String(d.qrUrl || d.signUrl || '').trim();
    if (!url) {
      return fhB06J34A_response_(false, '공용입장 QR 링크 생성 결과에 URL이 없습니다. SystemConfig SIGN_WEBAPP_URL 확인 필요', { original: res, payload: payload }, 'PUBLIC_QR_URL_EMPTY');
    }

    var data = {
      linkOnly: true,
      isPublicEntry: true,
      documentId: '',
      documentNo: '',
      customerId: '',
      dong: '',
      hosu: '',
      ho: '',
      status: d.status || 'PUBLIC_ENTRY_LINK',
      qrType: d.qrType || d.entryType || 'PUBLIC',
      entryType: d.entryType || 'PUBLIC',
      mode: d.mode || 'qr',
      eventId: d.eventId || payload.eventId || '',
      eventName: d.eventName || payload.eventName || d.eventId || payload.eventId || '',
      boothHint: d.boothHint || payload.boothHint || '',
      unitHint: '',
      qrUrl: url,
      signUrl: url,
      qrImageUrl: d.qrImageUrl || (typeof fhB06J1QrImageUrl_ === 'function' ? fhB06J1QrImageUrl_(url) : ''),
      createdAt: d.createdAt || fhB06J34A_now_(),
      buildNo: FEELHAUS_B06J34A.BUILD
    };
    return fhB06J34A_response_(true, '행사 공용입장 QR 링크 생성 완료', data, '');
  } catch(err) {
    return fhB06J34A_response_(false, '공용입장 QR 링크 생성 실패: ' + ((err && err.message) || String(err)), { payload: payload || {}, stack: (err && err.stack) || '' }, 'PUBLIC_QR_LINK_FAILED');
  }
}

// 최종 공용 진입점도 B06J34A로 고정한다.
function createPublicEntryQrLink(payload){
  return fhB06J34A_createPublicEntryQrLink(payload || {});
}

function erpB06J34A_runInternalTest(){
  var checks = [];
  function add(name, ok){ checks.push({ name: name, ok: !!ok }); }
  add('fhB06J34A_createPublicEntryQrLink', typeof fhB06J34A_createPublicEntryQrLink === 'function');
  add('createPublicEntryQrLink', typeof createPublicEntryQrLink === 'function');
  add('fhB05GetWorklists', typeof fhB05GetWorklists === 'function');
  add('searchCustomers', typeof searchCustomers === 'function');
  add('saveSale', typeof saveSale === 'function');
  add('completeInstallation', typeof completeInstallation === 'function');
  add('bulkCreateAssignedFieldQrDocuments', typeof bulkCreateAssignedFieldQrDocuments === 'function');
  var missing = checks.filter(function(x){ return !x.ok; }).map(function(x){ return x.name; });
  var result = {
    ok: missing.length === 0,
    message: missing.length ? 'B06J34C 내부점검: 일부 함수 누락' : 'B06J34C 내부점검 통과',
    data: {
      build: FEELHAUS_B06J34A.BUILD,
      title: FEELHAUS_B06J34A.TITLE,
      checked: checks,
      missing: missing,
      qrPublicResponseShape: 'ok/message/data/errorCode/meta',
      clientOnlyObjectsInServer: 'window/document/navigator 사용 없음',
      guidance: 'Apps Script 드롭다운에서 erpB06J34A_runInternalTest 또는 erpB06J34C_runInternalTest 실행 후 실행 로그에서 ok:true 확인'
    },
    errorCode: missing.length ? 'B06J34C_MISSING_FUNCTIONS' : '',
    meta: { build: FEELHAUS_B06J34A.BUILD, generatedAt: fhB06J34A_now_() }
  };
  Logger.log(JSON.stringify(result, null, 2));
  return result;
}

function erpB06J34C_runInternalTest(){
  return erpB06J34A_runInternalTest();
}
function getBuildInfo(){
  return { buildNo: FEELHAUS_B06J34A.BUILD, buildTitle: FEELHAUS_B06J34A.TITLE, generatedAt: fhB06J34A_now_() };
}


/** FEELHAUS ERP v64-B06J34D SERVER-ONLY PUBLIC ENTRY QR HOTFIX
 * 이 핫픽스는 화면 파일을 건드리지 않고, 기존 화면이 호출하는
 * fhB06J34A_createPublicEntryQrLink / createPublicEntryQrLink 를 서버 마지막 선언으로 덮어쓴다.
 * 공용입장 QR은 문서 생성이 아니므로 Master DB 조회 실패가 링크 생성을 막지 않게 한다.
 */
var FH_B06J34D_BUILD = 'v64-B06J34D';
var FH_B06J34D_TITLE = 'ERP 통합빌드 v64-B06J34D QR 공용입장 서버 실생성 핫픽스';
function fhB06J34D_response_(ok, message, data, errorCode) {
  return {
    ok: !!ok,
    message: String(message || ''),
    data: data || {},
    errorCode: String(errorCode || ''),
    meta: { build: FH_B06J34D_BUILD, generatedAt: new Date().toISOString() }
  };
}
function fhB06J34D_cfg_(keys) {
  keys = keys || [];
  try {
    var props = PropertiesService.getScriptProperties();
    for (var i = 0; i < keys.length; i++) {
      var v = String(props.getProperty(keys[i]) || '').trim();
      if (v) return v;
    }
  } catch (e1) {}
  try {
    var setupId = '17VMSpgSZCvIrUlgcw8yCNcnl8WQWo2IcRf5tDCcuJGM';
    var setup = SpreadsheetApp.openById(setupId);
    var sh = setup.getSheetByName('SystemConfig');
    if (!sh) return '';
    var values = sh.getDataRange().getValues();
    if (!values || !values.length) return '';
    var headers = values[0].map(function(h){ return String(h || '').trim(); });
    var kIdx = headers.indexOf('key');
    if (kIdx < 0) kIdx = headers.indexOf('configKey');
    if (kIdx < 0) kIdx = headers.indexOf('name');
    var vIdx = headers.indexOf('value');
    if (vIdx < 0) vIdx = headers.indexOf('configValue');
    if (vIdx < 0) vIdx = headers.indexOf('id');
    if (kIdx < 0) kIdx = 0;
    if (vIdx < 0) vIdx = 1;
    for (var r = 1; r < values.length; r++) {
      var key = String(values[r][kIdx] || '').trim();
      for (var j = 0; j < keys.length; j++) {
        if (key === keys[j]) {
          var val = String(values[r][vIdx] || '').trim();
          if (val) return val;
        }
      }
    }
  } catch (e2) {}
  return '';
}
function fhB06J34D_signBase_() {
  var base = fhB06J34D_cfg_(['SIGN_WEBAPP_URL','SIGN_WEB_APP_URL','SIGN_URL','SIGN_EXEC_URL','SIGN_WEBAPP_EXEC_URL']);
  if (!base) base = 'https://script.google.com/macros/s/AKfycby7TkzJGBe9vW7eDmqOaDWYc23cQEzrYRC2hVVc1dvMdmk50r5stgDi4fPikMgeMPrU/exec';
  return String(base || '').split('?')[0];
}
function fhB06J34D_qrImg_(url) {
  return 'https://quickchart.io/qr?size=360&text=' + encodeURIComponent(String(url || ''));
}
function fhB06J34D_createPublicEntryQrLink(payload) {
  try {
    payload = payload || {};
    var eventId = String(payload.eventId || '').trim();
    if (!eventId) return fhB06J34D_response_(false, '행사를 먼저 선택하세요.', { payload: payload }, 'EVENT_ID_REQUIRED');
    var eventName = String(payload.eventName || payload.eventTitle || '').trim() || eventId;
    var boothHint = String(payload.boothHint || payload.boothName || payload.locationMemo || '').trim();
    var base = fhB06J34D_signBase_();
    if (!base) return fhB06J34D_response_(false, 'SIGN 웹앱 URL을 만들 수 없습니다.', { payload: payload }, 'SIGN_BASE_URL_EMPTY');
    var url = base
      + '?mode=qr'
      + '&fieldMode=QR'
      + '&qrEntry=Y'
      + '&entryType=PUBLIC'
      + '&eventId=' + encodeURIComponent(eventId)
      + '&eventName=' + encodeURIComponent(eventName)
      + '&boothHint=' + encodeURIComponent(boothHint || '');
    var data = {
      linkOnly: true,
      isPublicEntry: true,
      documentId: '',
      documentNo: '',
      customerId: '',
      dong: '',
      hosu: '',
      ho: '',
      status: 'PUBLIC_ENTRY_LINK',
      qrType: 'PUBLIC',
      entryType: 'PUBLIC',
      mode: 'qr',
      eventId: eventId,
      eventName: eventName,
      boothHint: boothHint,
      qrUrl: url,
      signUrl: url,
      qrImageUrl: fhB06J34D_qrImg_(url),
      createdAt: new Date().toISOString(),
      buildNo: FH_B06J34D_BUILD
    };
    return fhB06J34D_response_(true, '행사 공용입장 QR 링크 생성 완료', data, '');
  } catch (err) {
    return fhB06J34D_response_(false, '공용입장 QR 링크 생성 실패: ' + ((err && err.message) || String(err)), { payload: payload || {}, stack: (err && err.stack) || '' }, 'PUBLIC_QR_LINK_FAILED');
  }
}
function fhB06J34A_createPublicEntryQrLink(payload) { return fhB06J34D_createPublicEntryQrLink(payload || {}); }
function createPublicEntryQrLink(payload) { return fhB06J34D_createPublicEntryQrLink(payload || {}); }
function erpB06J34D_runInternalTest() {
  var checked = [];
  function add(name, ok, detail){ checked.push({ name: name, ok: !!ok, detail: detail || '' }); }
  add('fhB06J34D_createPublicEntryQrLink', typeof fhB06J34D_createPublicEntryQrLink === 'function');
  add('fhB06J34A_createPublicEntryQrLink override', typeof fhB06J34A_createPublicEntryQrLink === 'function');
  add('createPublicEntryQrLink override', typeof createPublicEntryQrLink === 'function');
  var sample = fhB06J34D_createPublicEntryQrLink({ eventId: 'TEST-FEELHAUS-B06J34D', eventName: 'TEST-필행사-B06J34D', boothHint: '내부점검' });
  add('realCall.ok', sample && sample.ok === true, sample && sample.message);
  add('realCall.data.qrUrl', !!(sample && sample.data && sample.data.qrUrl), sample && sample.data && sample.data.qrUrl);
  add('realCall.data.signUrl', !!(sample && sample.data && sample.data.signUrl), sample && sample.data && sample.data.signUrl);
  var missing = checked.filter(function(x){ return !x.ok; }).map(function(x){ return x.name; });
  var out = fhB06J34D_response_(missing.length === 0, missing.length ? 'B06J34D 내부점검 실패' : 'B06J34D 내부점검 통과', {
    build: FH_B06J34D_BUILD,
    title: FH_B06J34D_TITLE,
    checked: checked,
    missing: missing,
    realCallSample: sample,
    guidance: '이 테스트는 실제 qrUrl/signUrl 생성까지 확인합니다. 이후 ERP 화면에서 행사 공용입장 링크 생성을 클릭하세요.'
  }, missing.length ? 'INTERNAL_TEST_FAILED' : '');
  Logger.log(JSON.stringify(out, null, 2));
  return out;
}


/** B06J34E REGULAR PROMOTION MINIMAL OVERRIDE */
function fhB06J34E_trim_(v){ return String(v == null ? '' : v).trim(); }
function fhB06J34E_headerMap_(sh){ var h=sh.getLastColumn()?sh.getRange(1,1,1,sh.getLastColumn()).getValues()[0]:[]; var m={}; h.forEach(function(x,i){ x=fhB06J34E_trim_(x); if(x && m[x]==null) m[x]=i; }); return m; }
function fhB06J34E_ensureHeaders_(sh, headers){ var m=fhB06J34E_headerMap_(sh); headers.forEach(function(h){ if(m[h]==null){ sh.getRange(1, sh.getLastColumn()+1).setValue(h); m[h]=sh.getLastColumn()-1; } }); return fhB06J34E_headerMap_(sh); }
function fhB06J34E_findIn_(sh, customerId){ if(!sh||!customerId||sh.getLastRow()<2)return null; var m=fhB06J34E_headerMap_(sh); if(m.customerId==null)return null; var rows=sh.getRange(2,1,sh.getLastRow()-1,sh.getLastColumn()).getValues(); for(var i=rows.length-1;i>=0;i--){ if(fhB06J34E_trim_(rows[i][m.customerId])===customerId){ var o={}; Object.keys(m).forEach(function(k){o[k]=rows[i][m[k]];}); return{sheet:sh,rowIndex:i+2,map:m,obj:o}; } } return null; }
function fhB06J34E_findCustomer_(ss, customerId){ var names=['ERP_고객관리','Customers','ERP_Customers','SIGN_Customers','SIGN_QR_Customers','QR_Customers','SIGN_QR_Registrations','QR_Registrations']; for(var n=0;n<names.length;n++){ var f=fhB06J34E_findIn_(ss.getSheetByName(names[n]),customerId); if(f)return f; } return null; }
function fhB06J34E_set_(sh,row,map,key,value){ if(map[key]!=null) sh.getRange(row,map[key]+1).setValue(value==null?'':value); }
function fhB06J34E_appendObj_(sh,obj){ var m=fhB06J34E_ensureHeaders_(sh,Object.keys(obj)); var row=new Array(sh.getLastColumn()).fill(''); Object.keys(obj).forEach(function(k){ if(m[k]!=null) row[m[k]]=obj[k]==null?'':obj[k]; }); sh.appendRow(row); }
function fhB06J34E_val_(o,ks){ for(var i=0;i<ks.length;i++){ var v=o&&o[ks[i]]; if(fhB06J34E_trim_(v))return fhB06J34E_trim_(v); } return ''; }
function fhB06J34E_env_(){ try{ var e=fhB06J1FieldQrSetup_(); if(e&&e.masterDb)return e; }catch(x){} var ss=SpreadsheetApp.getActiveSpreadsheet(); return{masterDb:ss}; }
function fhB06J34E_payload_(payload){ payload=payload||{}; var p={customerId:fhB06J34E_trim_(payload.customerId),eventId:fhB06J34E_trim_(payload.eventId),dong:fhB06J34E_trim_(payload.dong),hosu:fhB06J34E_trim_(payload.hosu||payload.ho),promotionSource:fhB06J34E_trim_(payload.promotionSource||'FIELD_MANAGER_CONFIRM'),promotionReason:fhB06J34E_trim_(payload.promotionReason||payload.reason)}; if(!p.customerId)throw new Error('정회원 승격은 선택된 customerId가 필요합니다.'); if(!p.eventId||!p.dong||!p.hosu)throw new Error('정회원 승격은 행사 + 동 + 호수(hosu)가 필요합니다.'); if(!p.promotionReason)throw new Error('정회원 승격 사유가 필요합니다.'); return p; }
function fhB06J34E_writeLog_(ss,action,targetId,status,reason,beforeObj,afterObj){ try{ var sh=ss.getSheetByName('SystemLogs')||ss.insertSheet('SystemLogs'); fhB06J34E_ensureHeaders_(sh,['logId','createdAt','createdBy','actionType','targetId','status','statusReason','beforeValue','afterValue','meta']); var actor='ERP_OPERATOR'; try{actor=Session.getActiveUser().getEmail()||actor;}catch(e){} fhB06J34E_appendObj_(sh,{logId:'LOG-'+Utilities.getUuid().replace(/-/g,'').substring(0,12).toUpperCase(),createdAt:new Date(),createdBy:actor,actionType:action,targetId:targetId,status:status,statusReason:reason,beforeValue:JSON.stringify(beforeObj||{}),afterValue:JSON.stringify(afterObj||{}),meta:JSON.stringify({buildNo:'v64-B06J34F'})}); }catch(e){} }
function fhB06J34E_writePromotion_(ss,p,status,beforeObj,afterObj){ var now=new Date(); var sh=ss.getSheetByName('CustomerPromotionRequests')||ss.insertSheet('CustomerPromotionRequests'); fhB06J34E_ensureHeaders_(sh,['requestId','customerId','eventId','dong','ho','hosu','beforeMemberType','afterMemberType','beforeCustomerType','afterCustomerType','beforeRegularCheck','afterRegularCheck','promotionSource','promotionReason','status','requestedBy','approvedBy','createdAt','approvedAt','updatedAt','updatedBy','meta']); var actor='ERP_OPERATOR'; try{ actor=Session.getActiveUser().getEmail()||actor; }catch(e){} var rid='CPR-'+Utilities.formatDate(now,Session.getScriptTimeZone()||'Asia/Seoul','yyyyMMddHHmmss')+'-'+Math.floor(Math.random()*900+100); fhB06J34E_appendObj_(sh,{requestId:rid,customerId:p.customerId,eventId:p.eventId,dong:p.dong,ho:p.hosu,hosu:p.hosu,beforeMemberType:beforeObj.memberType||'',afterMemberType:'REGULAR',beforeCustomerType:beforeObj.customerType||'',afterCustomerType:'REGULAR',beforeRegularCheck:beforeObj.regularCheck||'',afterRegularCheck:status==='APPROVED'?'CONFIRMED':'PROMOTION_REQUESTED',promotionSource:p.promotionSource,promotionReason:p.promotionReason,status:status,requestedBy:actor,approvedBy:status==='APPROVED'?actor:'',createdAt:now,approvedAt:status==='APPROVED'?now:'',updatedAt:now,updatedBy:actor,meta:JSON.stringify({buildNo:'v64-B06J34F'})}); return rid; }
function fhB06J34E_promoteCore_(payload, approveNow){ try{ var env=fhB06J34E_env_(),ss=env.masterDb,p=fhB06J34E_payload_(payload),found=fhB06J34E_findCustomer_(ss,p.customerId); if(!found)return{ok:false,message:'승격 대상 고객을 찾지 못했습니다: '+p.customerId,errorCode:'CUSTOMER_NOT_FOUND',data:{customerId:p.customerId},meta:{build:'v64-B06J34F'}}; var before=found.obj||{}; if(!approveNow){ var pending={memberType:'REGULAR',customerType:'REGULAR',regularCheck:'PROMOTION_REQUESTED',eventId:p.eventId,dong:p.dong,hosu:p.hosu}; var req=fhB06J34E_writePromotion_(ss,p,'PENDING',before,pending); fhB06J34E_writeLog_(ss,'CUSTOMER_PROMOTION_REQUEST',p.customerId,'PENDING',p.promotionReason,before,pending); return{ok:true,message:'정회원 승격 요청 생성 완료: '+req,requestId:req,customerId:p.customerId,status:'PENDING',eventId:p.eventId,dong:p.dong,ho:p.hosu,hosu:p.hosu,buildNo:'v64-B06J34F'}; } var headers=['eventId','dong','hosu','memberType','customerType','regularCheck','status','statusReason','promotionSource','promotionReason','promotedAt','promotedBy','updatedAt','updatedBy']; var map=fhB06J34E_ensureHeaders_(found.sheet,headers); var actor='ERP_OPERATOR'; try{actor=Session.getActiveUser().getEmail()||actor;}catch(e){} var now=new Date(); var updates={eventId:p.eventId,dong:p.dong,hosu:p.hosu,memberType:'REGULAR',customerType:'REGULAR',regularCheck:'CONFIRMED',status:'ACTIVE',statusReason:'정회원 승격: '+p.promotionSource,promotionSource:p.promotionSource,promotionReason:p.promotionReason,promotedAt:now,promotedBy:actor,updatedAt:now,updatedBy:actor}; Object.keys(updates).forEach(function(k){fhB06J34E_set_(found.sheet,found.rowIndex,map,k,updates[k]);}); var primary=ss.getSheetByName('ERP_고객관리')||ss.insertSheet('ERP_고객관리'); var primaryHeaders=['customerId','eventId','vendorId','name','phone','email','memberType','customerType','regularCheck','eventType','qrSource','dong','hosu','aptName','address','status','statusReason','promotionSource','promotionReason','promotedAt','promotedBy','createdAt','createdBy','updatedAt','updatedBy','notes']; fhB06J34E_ensureHeaders_(primary,primaryHeaders); var exist=fhB06J34E_findIn_(primary,p.customerId); var base={customerId:p.customerId,eventId:p.eventId,vendorId:fhB06J34E_val_(before,['vendorId']),name:fhB06J34E_val_(before,['name','customerName','memberName','signerName']),phone:fhB06J34E_val_(before,['phone','mobile','tel','customerPhone','signerPhone']),email:fhB06J34E_val_(before,['email','customerEmail','signerEmail']),memberType:'REGULAR',customerType:'REGULAR',regularCheck:'CONFIRMED',eventType:fhB06J34E_val_(before,['eventType'])||'입주박람회',qrSource:fhB06J34E_val_(before,['qrSource','qrType','source','entryType'])||'QR_PUBLIC',dong:p.dong,hosu:p.hosu,aptName:fhB06J34E_val_(before,['aptName','apartmentName','apartment','complexName']),address:fhB06J34E_val_(before,['address','addr']),status:'ACTIVE',statusReason:'정회원 승격: '+p.promotionSource,promotionSource:p.promotionSource,promotionReason:p.promotionReason,promotedAt:now,promotedBy:actor,updatedAt:now,updatedBy:actor,notes:'PROMOTED_TO_REGULAR; sourceSheet='+found.sheet.getName()+'; build=v64-B06J34F'}; if(exist){ var pm=fhB06J34E_ensureHeaders_(primary,primaryHeaders); Object.keys(base).forEach(function(k){fhB06J34E_set_(primary,exist.rowIndex,pm,k,base[k]);}); }else{ base.createdAt=now;base.createdBy=actor; fhB06J34E_appendObj_(primary,base); } var req2=fhB06J34E_writePromotion_(ss,p,'APPROVED',before,base); fhB06J34E_writeLog_(ss,'CUSTOMER_PROMOTE_TO_REGULAR',p.customerId,'APPROVED',p.promotionReason,before,base); return{ok:true,message:'정회원 즉시 승격 완료: '+p.customerId,requestId:req2,customerId:p.customerId,status:'APPROVED',memberType:'REGULAR',customerType:'REGULAR',regularCheck:'CONFIRMED',eventId:p.eventId,dong:p.dong,ho:p.hosu,hosu:p.hosu,sourceSheet:found.sheet.getName(),primarySheet:'ERP_고객관리',buildNo:'v64-B06J34F'}; }catch(err){ return{ok:false,message:(err&&err.message)?err.message:String(err),errorCode:'PROMOTION_FAILED',data:{stack:err&&err.stack?err.stack:''},meta:{build:'v64-B06J34F'}}; } }
function promoteCustomerToRegular(payload){ return fhB06J34E_promoteCore_(payload,true); }
function requestCustomerPromotion(payload){ return fhB06J34E_promoteCore_(payload,false); }
function erpB06J34E_runInternalTest(){ var checks=[{name:'promoteCustomerToRegular override',ok:typeof promoteCustomerToRegular==='function'},{name:'requestCustomerPromotion override',ok:typeof requestCustomerPromotion==='function'},{name:'find source customer',ok:typeof fhB06J34E_findCustomer_==='function'},{name:'B06J34D QR preserved',ok:typeof fhB06J34D_createPublicEntryQrLink==='function'}]; var missing=checks.filter(function(c){return !c.ok;}).map(function(c){return c.name;}); var res={ok:missing.length===0,message:missing.length?'B06J34E 내부점검 실패':'B06J34E 내부점검 통과',data:{build:'v64-B06J34F',title:'ERP 통합빌드 v64-B06J34F 정회원 승격 소스시트 안전보정',checked:checks,missing:missing,guidance:'ERP 화면에서 고객 선택 후 정회원 즉시 승격을 다시 클릭하세요.'},errorCode:missing.length?'B06J34E_INTERNAL_TEST_FAILED':'',meta:{build:'v64-B06J34F',generatedAt:new Date().toISOString()}}; Logger.log(JSON.stringify(res,null,2)); return res; }


/** B06J34F B05 INSTALL CONFIRM WORKLIST LATEST REFLECT SAFE */
var FH_B06J34F_BUILD='v64-B06J34F';
var FH_B06J34F_TITLE='ERP 통합빌드 v64-B06J34F B05 설치확인서 생성대상 최신반영 보정';
var fhB06J34F_prevB05_=(typeof fhB05GetWorklists==='function')?fhB05GetWorklists:null;
function fhB06J34F_s(v){return String(v==null?'':v).trim();}
function fhB06J34F_n(v){return fhB06J34F_s(v).replace(/[\s\-_.]/g,'').toUpperCase();}
function fhB06J34F_p(o,ks){o=o||{};for(var i=0;i<ks.length;i++){var v=o[ks[i]];if(v!=null&&String(v).trim()!=='')return String(v).trim();}return'';}
function fhB06J34F_done(r){var t=[fhB06J34F_p(r,['status','installStatus','completionStatus','assignmentStatus','stage','installStage','설치단계','상태']),fhB06J34F_p(r,['completedAt','completedDate','installCompletedAt','설치완료일'])].join(' '),u=t.toUpperCase();return u.indexOf('COMPLETED')>=0||u.indexOf('COMPLETE')>=0||u.indexOf('DONE')>=0||u.indexOf('INSTALL_DONE')>=0||t.indexOf('완료')>=0||!!fhB06J34F_p(r,['completedAt','completedDate','installCompletedAt','설치완료일']);}
function fhB06J34F_time(r){var raw=fhB06J34F_p(r,['completedAt','installCompletedAt','updatedAt','createdAt','visitDate','completedDate','설치완료일']);var t=raw?Date.parse(raw):0;if(isNaN(t))t=0;return t*1000000+Number((r&&(r._rowNumber||r.rowNumber))||0);}
function fhB06J34F_doc(idx,installId,saleId){var d=null;if(idx){if(installId&&idx.byInstallConfirm)d=idx.byInstallConfirm[fhB06J34F_n(installId)]||d;if(saleId&&idx.byInstallConfirmSale)d=idx.byInstallConfirmSale[fhB06J34F_n(saleId)]||d;}return d;}
function fhB06J34F_latest(installs,idx){var out=[],seen={};(installs||[]).forEach(function(r){if(!fhB06J34F_done(r))return;var installId=fhB06J34F_p(r,['installId','installID','id','설치ID']);var saleId=fhB06J34F_p(r,['saleId','saleID','판매ID']);if(!installId&&!saleId)return;var key=fhB06J34F_n(installId||('SALE_'+saleId));if(!key||seen[key])return;seen[key]=true;var d=fhB06J34F_doc(idx,installId,saleId);out.push({action:'CREATE_INSTALL_CONFIRM',actionLabel:'설치확인서 생성',installId:installId,saleId:saleId,customerId:fhB06J34F_p(r,['customerId','고객ID']),vendorId:fhB06J34F_p(r,['vendorId','업체ID']),eventId:fhB06J34F_p(r,['eventId','행사ID']),status:fhB06J34F_p(r,['status','installStatus','completionStatus','assignmentStatus','stage','installStage','상태'])||'COMPLETED',documentId:d?fhB06J34F_p(d,['documentId','docId','문서ID']):'',documentStatus:d?fhB06J34F_p(d,['status','documentStatus','signStatus','archiveStatus','상태']):'',hasInstallConfirmDoc:!!d,memo:d?'설치완료 / 기존 문서 존재 / B06J34F 최신반영':'설치완료 / 생성 대상 / B06J34F 최신반영',sourceSheet:r._sheetName||r.sourceSheet||'',rowNumber:r._rowNumber||r.rowNumber||'',_k:fhB06J34F_time(r)});});out.sort(function(a,b){return(b._k||0)-(a._k||0);});out.forEach(function(x){delete x._k;});return out;}
function fhB06J34F_merge(a,b){var out=[],seen={};function add(x){x=x||{};var k=fhB06J34F_n(x.installId||('SALE_'+(x.saleId||'')));if(!k||seen[k])return;seen[k]=1;out.push(x);} (b||[]).forEach(add);(a||[]).forEach(add);return out.slice(0,50);}
function fhB06J34F_getWorklists(payload){payload=payload||{};var base=fhB06J34F_prevB05_?fhB06J34F_prevB05_(payload):null;if(!base||!base.ok)base={ok:true,message:'B05 목록 기본 응답',data:{},errorCode:'',meta:{}};base.data=base.data||{};try{var env=fhB06J29_getMasterSpreadsheet_(),ss=env.ss;var docs=fhB06J29_readSheets_(ss,FEELHAUS_B06J29.DOCUMENT_SHEETS);var installs=fhB06J29_readSheets_(ss,FEELHAUS_B06J29.INSTALL_SHEETS);var idx=fhB06J29_buildDocIndex_(docs);var latest=fhB06J34F_latest(installs,idx);var merged=fhB06J34F_merge(base.data.installConfirmTargets||[],latest);base.data.installConfirmTargets=merged;base.data.counts=base.data.counts||{};base.data.counts.installConfirmTargets=merged.length;base.data.debug=base.data.debug||{};base.data.debug.b06j34f={build:FH_B06J34F_BUILD,latestInstallTargetCount:latest.length,latestPreview:latest.slice(0,10)};base.message='B05 목록 자동조회 완료 - B06J34F 설치확인서 최신반영';base.meta={build:FH_B06J34F_BUILD,generatedAt:new Date().toISOString()};return base;}catch(e){return{ok:false,message:'B06J34F B05 보정 실패: '+((e&&e.message)||e),data:{stack:(e&&e.stack)||''},errorCode:'B06J34F_B05_FAILED',meta:{build:FH_B06J34F_BUILD,generatedAt:new Date().toISOString()}};}}
fhB05GetWorklists=function(p){return fhB06J34F_getWorklists(p||{});};
fhOpsUiB05GetWorklists=function(p){return fhB05GetWorklists(p||{});};
fhOpsUiB05HetWorklists=function(p){return fhB05GetWorklists(p||{});};
erpB06J28_getWorklists_=function(p){return fhB05GetWorklists(p||{});};
function erpB06J34F_runInternalTest(){var checks=[];function add(n,o,d){checks.push({name:n,ok:!!o,detail:d||''});}add('fhB05GetWorklists override',typeof fhB05GetWorklists==='function');add('B06J34E promotion preserved',typeof promoteCustomerToRegular==='function');add('B06J34D QR preserved',typeof fhB06J34D_createPublicEntryQrLink==='function');var real=null;try{real=fhB05GetWorklists({test:true});add('real fhB05GetWorklists.ok',real&&real.ok,real&&real.message);add('installConfirmTargets array',real&&real.data&&Object.prototype.toString.call(real.data.installConfirmTargets)==='[object Array]',real&&real.data&&real.data.installConfirmTargets?String(real.data.installConfirmTargets.length):'');}catch(e){add('real fhB05GetWorklists.ok',false,(e&&e.message)||String(e));}var miss=checks.filter(function(c){return!c.ok;}).map(function(c){return c.name;});var res={ok:miss.length===0,message:miss.length?'B06J34F 내부점검 실패':'B06J34F 내부점검 통과',data:{build:FH_B06J34F_BUILD,title:FH_B06J34F_TITLE,checked:checks,missing:miss,worklistPreview:real&&real.data?{counts:real.data.counts||{},installConfirmTargets:(real.data.installConfirmTargets||[]).slice(0,5),debug:real.data.debug&&real.data.debug.b06j34f?real.data.debug.b06j34f:{}}:{}},errorCode:miss.length?'B06J34F_INTERNAL_TEST_FAILED':'',meta:{build:FH_B06J34F_BUILD,generatedAt:new Date().toISOString()}};Logger.log(JSON.stringify(res,null,2));return res;}
function getBuildInfo(){return{buildNo:FH_B06J34F_BUILD,buildTitle:FH_B06J34F_TITLE,generatedAt:new Date()};}

/** B06J34G OPS UI BUILD LABEL SYNC SAFE */
var FH_B06J34G_BUILD = 'v64-B06J34G';
var FH_B06J34G_TITLE = 'ERP 통합빌드 v64-B06J34G OPS UI 빌드표기 동기화 / B05 최신반영 보존';
function erpB06J34G_runInternalTest(){
  var checks=[];
  function add(n,o,d){ checks.push({name:n, ok:!!o, detail:d||''}); }
  add('B06J34F B05 override preserved', typeof fhB05GetWorklists === 'function');
  add('B06J34E promotion preserved', typeof promoteCustomerToRegular === 'function');
  add('B06J34D QR preserved', typeof fhB06J34D_createPublicEntryQrLink === 'function');
  add('OPS UI onOpen preserved', typeof fhOpsUiB03OnOpen === 'function');
  add('OPS UI build constant B06J34G', typeof FH_OPS_UI_B03 !== 'undefined' && FH_OPS_UI_B03 && String(FH_OPS_UI_B03.BUILD_NO||'').indexOf('B06J34G')>=0, (typeof FH_OPS_UI_B03 !== 'undefined' && FH_OPS_UI_B03) ? String(FH_OPS_UI_B03.BUILD_NO||'') : 'FH_OPS_UI_B03 없음');
  var work=null;
  try{ work = fhB05GetWorklists({test:true}); add('real fhB05GetWorklists.ok', work && work.ok, work && work.message); }
  catch(e){ add('real fhB05GetWorklists.ok', false, (e&&e.message)||String(e)); }
  var missing=checks.filter(function(c){return !c.ok;}).map(function(c){return c.name;});
  var res={ok:missing.length===0,message:missing.length?'B06J34G 내부점검 실패':'B06J34G 내부점검 통과',data:{build:FH_B06J34G_BUILD,title:FH_B06J34G_TITLE,checked:checks,missing:missing,worklistPreview:work&&work.data?{counts:work.data.counts||{},installConfirmTargets:(work.data.installConfirmTargets||[]).slice(0,5)}:{}},errorCode:missing.length?'B06J34G_INTERNAL_TEST_FAILED':'',meta:{build:FH_B06J34G_BUILD,generatedAt:new Date().toISOString()}};
  Logger.log(JSON.stringify(res,null,2));
  return res;
}
function getBuildInfo(){ return {buildNo:FH_B06J34G_BUILD, buildTitle:FH_B06J34G_TITLE, generatedAt:new Date()}; }


/** B06J34G2 LABEL RESIDUE CLEAN - LABEL ONLY, FUNCTION PRESERVED */
var FH_B06J34G2_BUILD = 'v64-B06J34G2';
var FH_B06J34G2_TITLE = 'ERP 통합빌드 v64-B06J34G2 표기잔여 정리 / B06J34G 기능보존';
function erpB06J34G2_runInternalTest(){
  var checks=[];
  function add(name, ok, detail){ checks.push({name:name, ok:!!ok, detail:detail||''}); }
  var work=null;
  try{ work = (typeof fhB05GetWorklists==='function') ? fhB05GetWorklists({source:'B06J34G2_INTERNAL_TEST'}) : null; }catch(e){ work={ok:false,message:String(e&&e.message||e)}; }
  add('B06J34F B05 override preserved', typeof fhB05GetWorklists==='function');
  add('B06J34E promotion preserved', typeof promoteCustomerToRegular==='function' && typeof requestCustomerPromotion==='function');
  add('B06J34D QR preserved', typeof fhB06J34D_createPublicEntryQrLink==='function' || typeof fhB06J34A_createPublicEntryQrLink==='function');
  add('OPS UI label G2', typeof FH_OPS_UI_B03 !== 'undefined' && FH_OPS_UI_B03 && String(FH_OPS_UI_B03.BUILD_NO||'').indexOf('B06J34G2')>=0, (typeof FH_OPS_UI_B03 !== 'undefined' && FH_OPS_UI_B03) ? String(FH_OPS_UI_B03.BUILD_NO||'') : 'FH_OPS_UI_B03 없음');
  add('real fhB05GetWorklists.ok', !!(work&&work.ok), work&&work.message?work.message:'');
  var missing=checks.filter(function(c){return !c.ok;}).map(function(c){return c.name;});
  var res={ok:missing.length===0,message:missing.length?'B06J34G2 내부점검 실패':'B06J34G2 내부점검 통과',data:{build:FH_B06J34G2_BUILD,title:FH_B06J34G2_TITLE,checked:checks,missing:missing,worklistPreview:work&&work.data?{counts:work.data.counts||{},installConfirmTargets:(work.data.installConfirmTargets||[]).slice(0,5)}:{}},errorCode:missing.length?'B06J34G2_INTERNAL_TEST_FAILED':'',meta:{build:FH_B06J34G2_BUILD,generatedAt:new Date().toISOString()}};
  Logger.log(JSON.stringify(res,null,2));
  return res;
}
function getBuildInfo(){ return {buildNo:FH_B06J34G2_BUILD, buildTitle:FH_B06J34G2_TITLE, generatedAt:new Date()}; }

/** B06J35-8 LABEL/DOCUMENT CLEANUP ONLY - CORE FUNCTIONS PRESERVED */
var FH_B06J35_7_BUILD = 'v64-B06J35-9';
var FH_B06J35_7_TITLE = 'ERP 통합빌드 v64-B06J35-9 표기/문서 정리 안전본 / B06J34G2 기능보존';
function erpB06J35_7_runInternalTest(){
  var checks=[];
  function add(name, ok, detail){ checks.push({name:name, ok:!!ok, detail:detail||''}); }
  var work=null, qr=null, buildInfo=null;
  try{ buildInfo = getBuildInfo(); }catch(e0){ buildInfo={error:String(e0&&e0.message||e0)}; }
  try{ work = (typeof fhB05GetWorklists==='function') ? fhB05GetWorklists({source:'B06J35_7_INTERNAL_TEST'}) : null; }catch(e1){ work={ok:false,message:String(e1&&e1.message||e1)}; }
  try{ qr = (typeof fhB06J34D_createPublicEntryQrLink==='function') ? fhB06J34D_createPublicEntryQrLink({eventId:'TEST-FEELHAUS-B06J35-8',eventName:'TEST-필행사-B06J35-8',boothHint:'표기정리점검'}) : null; }catch(e2){ qr={ok:false,message:String(e2&&e2.message||e2)}; }
  add('getBuildInfo B06J35-8', !!(buildInfo&&buildInfo.buildNo===FH_B06J35_7_BUILD), buildInfo&&buildInfo.buildNo?buildInfo.buildNo:JSON.stringify(buildInfo));
  add('B06J34F B05 override preserved', typeof fhB05GetWorklists==='function');
  add('B06J34E promotion preserved', typeof promoteCustomerToRegular==='function' && typeof requestCustomerPromotion==='function');
  add('B06J34D QR preserved', typeof fhB06J34D_createPublicEntryQrLink==='function' || typeof fhB06J34A_createPublicEntryQrLink==='function');
  add('OPS UI label B06J35-8', typeof FH_OPS_UI_B03 !== 'undefined' && FH_OPS_UI_B03 && String(FH_OPS_UI_B03.BUILD_NO||'').indexOf('B06J35-8')>=0, (typeof FH_OPS_UI_B03 !== 'undefined' && FH_OPS_UI_B03) ? String(FH_OPS_UI_B03.BUILD_NO||'') : 'FH_OPS_UI_B03 없음');
  add('real fhB05GetWorklists.ok', !!(work&&work.ok), work&&work.message?work.message:'');
  add('real QR call ok', !!(qr&&qr.ok), qr&&qr.message?qr.message:'');
  add('real QR qrUrl', !!(qr&&qr.data&&qr.data.qrUrl), qr&&qr.data&&qr.data.qrUrl?qr.data.qrUrl:'');
  var missing=checks.filter(function(c){return !c.ok;}).map(function(c){return c.name;});
  var res={ok:missing.length===0,message:missing.length?'B06J35-8 내부점검 실패':'B06J35-8 내부점검 통과',data:{build:FH_B06J35_7_BUILD,title:FH_B06J35_7_TITLE,checked:checks,missing:missing,worklistPreview:work&&work.data?{counts:work.data.counts||{},installConfirmTargets:(work.data.installConfirmTargets||[]).slice(0,5)}:{},qrPreview:qr&&qr.data?{eventId:qr.data.eventId||'',qrUrl:qr.data.qrUrl||'',qrImageUrl:qr.data.qrImageUrl||''}:{}},errorCode:missing.length?'B06J35_7_INTERNAL_TEST_FAILED':'',meta:{build:FH_B06J35_7_BUILD,generatedAt:new Date().toISOString()}};
  Logger.log(JSON.stringify(res,null,2));
  return res;
}
function getBuildInfo(){ return {buildNo:FH_B06J35_7_BUILD, buildTitle:FH_B06J35_7_TITLE, generatedAt:new Date()}; }

/**
 * FEELHAUS ERP v64-B06J35-9
 * 지정형 QR 대상조회 통합소스 안전보정
 * 기존 QR 공용입장 / 정회원 승격 / B05 / 판매 / 설치 로직은 변경하지 않는다.
 */
var FH_B06J35_8_BUILD = 'v64-B06J35-9';
var FH_B06J35_8_TITLE = 'ERP 통합빌드 v64-B06J35-9 지정형 QR 대상조회 통합소스 안전보정 / B06J35-7 기능보존';
function fhB06J35_8_response_(ok, message, data, errorCode) {
  return { ok: !!ok, message: message || '', data: data || {}, targets: data && data.targets ? data.targets : [], total: data && data.targets ? data.targets.length : 0, errorCode: errorCode || '', meta: { build: FH_B06J35_8_BUILD, generatedAt: new Date().toISOString() } };
}
function fhB06J35_8_master_() {
  if (typeof fhB06J1FieldQrSetup_ === 'function') { var env = fhB06J1FieldQrSetup_(); if (env && env.masterDb) return env.masterDb; }
  var props = PropertiesService.getScriptProperties();
  var masterId = String(props.getProperty('FEELHAUS_DB_MASTER_ID') || props.getProperty('MASTER_DB_ID') || props.getProperty('DB_MASTER_ID') || props.getProperty('SPREADSHEET_ID') || '').trim();
  if (!masterId) throw new Error('FEELHAUS_DB_MASTER ID를 찾을 수 없습니다. SystemConfig 연결을 확인하세요.');
  return SpreadsheetApp.openById(masterId);
}
function fhB06J35_8_headerMap_(sh) {
  if (typeof fhB06J1HeaderMap_ === 'function') return fhB06J1HeaderMap_(sh);
  var width = Math.max(sh.getLastColumn(), 1);
  var headers = sh.getRange(1, 1, 1, width).getValues()[0];
  var map = {};
  headers.forEach(function(h, i){ h = String(h || '').trim(); if (h) map[h] = i; });
  return map;
}
function fhB06J35_8_get_(row, map, keys) {
  keys = Array.isArray(keys) ? keys : [keys];
  for (var i = 0; i < keys.length; i++) { var k = keys[i]; if (map[k] != null) { var v = row[map[k]]; if (v !== null && v !== undefined && String(v).trim() !== '') return String(v).trim(); } }
  return '';
}
function fhB06J35_8_norm_(v) { return String(v == null ? '' : v).trim(); }
function fhB06J35_8_upper_(v) { return fhB06J35_8_norm_(v).toUpperCase(); }
function fhB06J35_8_isRegular_(row, map) {
  var values = [fhB06J35_8_get_(row, map, ['memberType','customerType','memberStatus','회원구분','고객구분']), fhB06J35_8_get_(row, map, ['regularCheck','regularStatus','memberCheck','정회원확인','정회원상태']), fhB06J35_8_get_(row, map, ['status','customerStatus','requestStatus','상태'])].map(fhB06J35_8_upper_).join('|');
  if (!values) return false;
  return values.indexOf('REGULAR') >= 0 || values.indexOf('CONFIRMED') >= 0 || values.indexOf('정회원') >= 0;
}
function fhB06J35_8_eventMatches_(row, map, payload) {
  var selectedEventId = fhB06J35_8_norm_(payload.eventId || payload.eventID || payload.selectedEventId);
  var selectedEventName = fhB06J35_8_norm_(payload.eventName || payload.eventTitle || payload.eventLabel);
  var rowEventId = fhB06J35_8_get_(row, map, ['eventId','eventID','행사ID','행사id']);
  var rowEventName = fhB06J35_8_get_(row, map, ['eventName','eventTitle','eventLabel','행사명','event']);
  if (selectedEventId && rowEventId) return rowEventId === selectedEventId;
  if (selectedEventName && rowEventName) return rowEventName === selectedEventName || rowEventName.indexOf(selectedEventName) >= 0 || selectedEventName.indexOf(rowEventName) >= 0;
  return true;
}
function fhB06J35_8_readAssignedTargetsFromSheet_(ss, sheetName, payload, seen, out, sourceStats) {
  var sh = ss.getSheetByName(sheetName); if (!sh || sh.getLastRow() < 2) return;
  var map = fhB06J35_8_headerMap_(sh); var vals = sh.getRange(2, 1, sh.getLastRow() - 1, sh.getLastColumn()).getValues();
  var aptFilter = fhB06J35_8_norm_(payload.aptName || payload.apartmentName || payload.apartment || payload.complexName).toLowerCase();
  var dongFilter = fhB06J35_8_norm_(payload.dong || payload.dongFilter);
  var limit = Math.max(1, Math.min(Number(payload.limit || 500), 3000)); var scanned = 0, matched = 0;
  for (var i = 0; i < vals.length; i++) {
    var row = vals[i]; scanned++;
    if (!fhB06J35_8_eventMatches_(row, map, payload)) continue;
    if (!fhB06J35_8_isRegular_(row, map)) continue;
    var customerId = fhB06J35_8_get_(row, map, ['customerId','memberId','고객ID','고객id','id']);
    var dong = fhB06J35_8_get_(row, map, ['dong','aptDong','building','buildingNo','동']);
    var hosu = fhB06J35_8_get_(row, map, ['hosu','ho','unit','unitNo','roomNo','houseNo','호']);
    if (!customerId || !dong || !hosu) continue; if (dongFilter && dong !== dongFilter) continue;
    var apartmentName = fhB06J35_8_get_(row, map, ['apartmentName','aptName','complexName','단지명','아파트명']);
    if (aptFilter && String(apartmentName || '').toLowerCase().indexOf(aptFilter) < 0) continue;
    var eventId = fhB06J35_8_get_(row, map, ['eventId','eventID','행사ID','행사id']) || fhB06J35_8_norm_(payload.eventId || '');
    var key = eventId + '|' + customerId + '|' + dong + '|' + hosu; if (seen[key]) continue; seen[key] = true; matched++;
    out.push({ action:'CREATE_ASSIGNED_QR', actionLabel:'지정형 QR 생성', customerId:customerId, eventId:eventId, eventName:fhB06J35_8_get_(row, map, ['eventName','eventTitle','eventLabel','행사명']) || fhB06J35_8_norm_(payload.eventName || ''), apartmentName:apartmentName, dong:dong, hosu:hosu, ho:hosu, name:fhB06J35_8_get_(row, map, ['name','customerName','memberName','성명','이름']), phone:fhB06J35_8_get_(row, map, ['phone','mobile','tel','전화번호','연락처']), memberType:fhB06J35_8_get_(row, map, ['memberType','customerType','memberStatus','회원구분']) || 'REGULAR', regularCheck:fhB06J35_8_get_(row, map, ['regularCheck','regularStatus','memberCheck','정회원확인']) || 'CONFIRMED', status:fhB06J35_8_get_(row, map, ['status','customerStatus','상태']), sourceType:fhB06J35_8_get_(row, map, ['sourceType','source','qrType','유입경로']) || sheetName, sourceSheet:sheetName, rowNumber:i + 2, memo:'B06J35-8 통합소스 지정형 QR 대상' });
    if (out.length >= limit) break;
  }
  sourceStats.push({ sheetName:sheetName, scanned:scanned, matched:matched, exists:true });
}
function fhB06J35_8_getAssignedQrTargetsImpl_(payload) {
  payload = payload || {}; var eventId = fhB06J35_8_norm_(payload.eventId || payload.eventID || payload.selectedEventId);
  if (!eventId) return fhB06J35_8_response_(false, '지정형 QR 대상 조회는 행사 선택이 필수입니다.', { targets:[], payload:payload }, 'EVENT_ID_REQUIRED');
  var ss = fhB06J35_8_master_();
  var sourceSheets = ['ERP_고객관리','Customers','ERP_Customers','ERP_정회원업로드','RegularMembers','SIGN_Customers','SIGN_QR_Customers','QR_Customers','SIGN_QR_Registrations','QR_Registrations','정회원업로드','정회원_DB','RegularMemberUpload','ERP_RegularMembers'];
  var seen = {}, targets = [], sourceStats = [];
  for (var i = 0; i < sourceSheets.length; i++) fhB06J35_8_readAssignedTargetsFromSheet_(ss, sourceSheets[i], payload, seen, targets, sourceStats);
  targets.sort(function(a,b){ var ak=String(a.dong||'').padStart(6,'0')+'-'+String(a.hosu||a.ho||'').padStart(8,'0')+'-'+String(a.customerId||''); var bk=String(b.dong||'').padStart(6,'0')+'-'+String(b.hosu||b.ho||'').padStart(8,'0')+'-'+String(b.customerId||''); return ak<bk?-1:(ak>bk?1:0); });
  return fhB06J35_8_response_(true, '지정형 QR 대상 조회 완료 - B06J35-8 통합소스', { targets:targets, rows:targets, total:targets.length, eventId:eventId, sourceStats:sourceStats, buildNo:FH_B06J35_8_BUILD }, '');
}
function fhB06J35_8_getAssignedQrTargets(payload) { return fhB06J35_8_getAssignedQrTargetsImpl_(payload || {}); }
function fhB06J33A_getAssignedQrTargets(payload) { return fhB06J35_8_getAssignedQrTargetsImpl_(payload || {}); }
function fhB06J2GetRegularQrTargets(payload) { return fhB06J35_8_getAssignedQrTargetsImpl_(payload || {}); }
function listFieldQrBulkTargets(payload) { return fhB06J35_8_getAssignedQrTargetsImpl_(payload || {}); }
function getFieldQrBulkTargets(payload) { return fhB06J35_8_getAssignedQrTargetsImpl_(payload || {}); }
function fhB06J2GetFieldQrTargets(payload) { return fhB06J35_8_getAssignedQrTargetsImpl_(payload || {}); }
function erpB06J35_8_runInternalTest() {
  var checked=[]; function add(name, ok, detail){ checked.push({ name:name, ok:!!ok, detail:detail || '' }); }
  add('B06J34D QR preserved', typeof fhB06J34D_createPublicEntryQrLink === 'function' || typeof createPublicEntryQrLink === 'function', '');
  add('B06J34E promotion preserved', typeof promoteCustomerToRegular === 'function' && typeof requestCustomerPromotion === 'function', '');
  add('B06J34F B05 preserved', typeof fhB05GetWorklists === 'function', '');
  add('assigned QR wrapper fhB06J33A_getAssignedQrTargets', typeof fhB06J33A_getAssignedQrTargets === 'function', '');
  add('assigned QR implementation B06J35-8', typeof fhB06J35_8_getAssignedQrTargets === 'function', '');
  var sample=null, realTargetCall=null;
  try { var ss=fhB06J35_8_master_(); var sheets=['ERP_고객관리','Customers','ERP_Customers','ERP_정회원업로드','RegularMembers','SIGN_Customers','SIGN_QR_Customers','QR_Customers','SIGN_QR_Registrations','QR_Registrations','정회원업로드']; outer: for (var s=0;s<sheets.length;s++){ var sh=ss.getSheetByName(sheets[s]); if(!sh||sh.getLastRow()<2) continue; var map=fhB06J35_8_headerMap_(sh); var vals=sh.getRange(2,1,Math.min(sh.getLastRow()-1,200),sh.getLastColumn()).getValues(); for(var r=0;r<vals.length;r++){ var row=vals[r]; if(!fhB06J35_8_isRegular_(row,map)) continue; var ev=fhB06J35_8_get_(row,map,['eventId','eventID','행사ID','행사id']); var dong=fhB06J35_8_get_(row,map,['dong','aptDong','building','buildingNo','동']); var hosu=fhB06J35_8_get_(row,map,['hosu','ho','unit','unitNo','roomNo','houseNo','호']); if(ev&&dong&&hosu){ sample={ eventId:ev, eventName:fhB06J35_8_get_(row,map,['eventName','eventTitle','eventLabel','행사명']), dong:'', limit:20 }; break outer; } } } } catch(e){ add('sample scan warning', false, (e&&e.message)||String(e)); }
  if(sample){ realTargetCall=fhB06J35_8_getAssignedQrTargets(sample); add('real assigned target call ok', realTargetCall&&realTargetCall.ok===true, (realTargetCall&&realTargetCall.message)||''); add('real assigned target count', realTargetCall&&Number(realTargetCall.total||0)>=1, String((realTargetCall&&realTargetCall.total)||0)); } else { add('real assigned target sample found', false, 'eventId + dong + hosu를 가진 정회원 샘플을 찾지 못했습니다. 화면 테스트로 확인 필요'); }
  try { if(typeof fhB05GetWorklists==='function'){ var b05=fhB05GetWorklists({limit:5}); add('real fhB05GetWorklists.ok', b05&&b05.ok!==false, (b05&&b05.message)||''); } } catch(e2){ add('real fhB05GetWorklists.ok', false, (e2&&e2.message)||String(e2)); }
  var missing=checked.filter(function(x){return !x.ok;}).map(function(x){return x.name;});
  var result={ ok:missing.length===0, message:missing.length?'B06J35-8 내부점검 확인 필요':'B06J35-8 내부점검 통과', data:{ build:FH_B06J35_8_BUILD, title:FH_B06J35_8_TITLE, checked:checked, missing:missing, samplePayload:sample, realTargetCall:realTargetCall, guidance:'ERP 화면에서 지정형 QR 대상 조회를 다시 실행하세요. 최근고객 DB_UPLOAD 정회원이 targets에 표시되어야 정상입니다.' }, errorCode:missing.length?'B06J35_8_INTERNAL_CHECK_REVIEW':'', meta:{ build:FH_B06J35_8_BUILD, generatedAt:new Date().toISOString() } };
  try { Logger.log(JSON.stringify(result, null, 2)); } catch(ignore) {}
  return result;
}

/** FEELHAUS ERP v64-B06J35-9 ASSIGNED QR BULK STATE/PRINT SAFE */
var FH_B06J35_9_BUILD = 'v64-B06J35-9';
var FH_B06J35_9_TITLE = 'ERP 통합빌드 v64-B06J35-9 지정형 QR 일괄생성/인쇄 상태연결 안전보정 / B06J35-8 기능보존';
function fhB06J35_9_response_(ok, message, data, errorCode){ return {ok:!!ok,message:message||'',data:data||{},errorCode:errorCode||'',meta:{build:FH_B06J35_9_BUILD,generatedAt:new Date().toISOString()}}; }
function fhB06J35_9_createAssignedQrBulk(payload){
  try{
    payload=payload||{};
    if(!String(payload.eventId||'').trim()) return fhB06J35_9_response_(false,'지정형 QR 일괄 생성은 행사 선택이 필수입니다.',{payload:payload},'EVENT_ID_REQUIRED');
    if(typeof bulkCreateAssignedFieldQrDocuments!=='function') return fhB06J35_9_response_(false,'bulkCreateAssignedFieldQrDocuments 서버 함수가 없습니다.',{payload:payload},'BULK_CREATE_FUNCTION_NOT_FOUND');
    var res=bulkCreateAssignedFieldQrDocuments(payload);
    var d=(res&&res.data)?res.data:(res||{});
    var results=d.results||res.results||[];
    return fhB06J35_9_response_(true,'지정형 QR 일괄 생성 완료',{eventId:d.eventId||res.eventId||payload.eventId||'',eventName:d.eventName||res.eventName||payload.eventName||'',boothHint:d.boothHint||res.boothHint||payload.boothHint||'',totalTargets:Number(d.totalTargets||res.totalTargets||results.length||0),createdCount:Number(d.createdCount||res.createdCount||0),reusedCount:Number(d.reusedCount||res.reusedCount||0),errorCount:Number(d.errorCount||res.errorCount||0),results:results,rows:results,errors:d.errors||res.errors||[],buildNo:FH_B06J35_9_BUILD,originalBuildNo:d.buildNo||res.buildNo||''},'');
  }catch(err){ return fhB06J35_9_response_(false,'지정형 QR 일괄 생성 실패: '+((err&&err.message)||String(err)),{payload:payload||{},stack:(err&&err.stack)||''},'ASSIGNED_QR_BULK_FAILED'); }
}
function fhB06J33A_createAssignedQrBulk(payload){ return fhB06J35_9_createAssignedQrBulk(payload||{}); }
function createAssignedQrBulk(payload){ return fhB06J35_9_createAssignedQrBulk(payload||{}); }
function erpB06J35_9_runInternalTest(){
  var checks=[]; function add(n,o,d){checks.push({name:n,ok:!!o,detail:d||''});}
  add('B06J35-8 assigned target source preserved',typeof fhB06J35_8_getAssignedQrTargets==='function'&&typeof fhB06J33A_getAssignedQrTargets==='function','');
  add('B06J35-9 bulk wrapper exists',typeof fhB06J35_9_createAssignedQrBulk==='function'&&typeof fhB06J33A_createAssignedQrBulk==='function','');
  add('bulkCreateAssignedFieldQrDocuments preserved',typeof bulkCreateAssignedFieldQrDocuments==='function','');
  add('B06J34D public QR preserved',typeof fhB06J34D_createPublicEntryQrLink==='function'||typeof createPublicEntryQrLink==='function','');
  add('B06J34F B05 preserved',typeof fhB05GetWorklists==='function','');
  add('B06J34E promotion preserved',typeof promoteCustomerToRegular==='function'&&typeof requestCustomerPromotion==='function','');
  var missing=checks.filter(function(x){return !x.ok;}).map(function(x){return x.name;});
  var result={ok:missing.length===0,message:missing.length?'B06J35-9 내부점검 확인 필요':'B06J35-9 내부점검 통과',data:{build:FH_B06J35_9_BUILD,title:FH_B06J35_9_TITLE,checked:checks,missing:missing,guidance:'화면에서 지정형 QR 대상 조회 → 정회원 지정형 QR 일괄 생성 → QR 일괄 인쇄화면 순서로 확인하세요.'},errorCode:missing.length?'B06J35_9_INTERNAL_TEST_REVIEW':'',meta:{build:FH_B06J35_9_BUILD,generatedAt:new Date().toISOString()}};
  try{Logger.log(JSON.stringify(result,null,2));}catch(e){}
  return result;
}

/** FEELHAUS ERP v64-B06J35-10 ASSIGNED QR BULK PRINT STATE FINAL SAFE */
var FH_B06J35_10_BUILD = 'v64-B06J35-10';
var FH_B06J35_10_TITLE = 'ERP 통합빌드 v64-B06J35-10 지정형 QR 일괄생성/인쇄 상태값 단일화 / B06J35-8 기능보존';
function erpB06J35_10_runInternalTest(){
  var checks=[]; function add(n,o,d){ checks.push({name:n, ok:!!o, detail:d||''}); }
  add('B06J35-8 assigned target source preserved', typeof fhB06J35_8_getAssignedQrTargets==='function' && typeof fhB06J33A_getAssignedQrTargets==='function', '');
  add('B06J35-9 bulk wrapper preserved', typeof fhB06J35_9_createAssignedQrBulk==='function' && typeof fhB06J33A_createAssignedQrBulk==='function', '');
  add('bulkCreateAssignedFieldQrDocuments preserved', typeof bulkCreateAssignedFieldQrDocuments==='function', '');
  add('B06J34D public QR preserved', typeof fhB06J34D_createPublicEntryQrLink==='function' || typeof createPublicEntryQrLink==='function', '');
  add('B06J34F B05 preserved', typeof fhB05GetWorklists==='function', '');
  add('B06J34E promotion preserved', typeof promoteCustomerToRegular==='function' && typeof requestCustomerPromotion==='function', '');
  var missing=checks.filter(function(x){return !x.ok;}).map(function(x){return x.name;});
  var result={ok:missing.length===0,message:missing.length?'B06J35-10 내부점검 확인 필요':'B06J35-10 내부점검 통과',data:{build:FH_B06J35_10_BUILD,title:FH_B06J35_10_TITLE,checked:checks,missing:missing,statePolicy:{targets:'window.__FH_ASSIGNED_QR_TARGETS__',generated:'window.__FH_ASSIGNED_QR_GENERATED__',printFallback:'generated -> targets with qrUrl/signUrl -> 안내'},guidance:'화면에서 지정형 QR 대상 조회 → 정회원 지정형 QR 일괄 생성 → QR 일괄 인쇄화면 순서로 확인하세요.'},errorCode:missing.length?'B06J35_10_INTERNAL_TEST_REVIEW':'',meta:{build:FH_B06J35_10_BUILD,generatedAt:new Date().toISOString()}};
  try{ Logger.log(JSON.stringify(result,null,2)); }catch(e){}
  return result;
}
function getBuildInfo(){ return { buildNo: FH_B06J35_10_BUILD, buildTitle: FH_B06J35_10_TITLE, generatedAt: new Date().toISOString() }; }


/** FEELHAUS ERP v64-B06J35-11 HIDE ASSIGNED QR BULK UI SAFE */
var FH_B06J35_11_BUILD = 'v64-B06J35-11';
var FH_B06J35_11_TITLE = 'ERP 통합빌드 v64-B06J35-11 지정형 QR 일괄 기능 화면숨김 / B06J35-10 기능보존';
function erpB06J35_11_runInternalTest() {
  var checks=[]; var missing=[];
  function add(name, ok, detail) { checks.push({name:name, ok:!!ok, detail:detail||''}); if(!ok) missing.push(name); }
  add('B06J35-10 assigned QR server preserved', typeof erpB06J35_10_runInternalTest === 'function', 'UI만 숨김, 서버 함수는 보존');
  add('B06J35-8 assigned target source preserved', typeof fhB06J35_8_getAssignedQrTargets === 'function' && typeof fhB06J33A_getAssignedQrTargets === 'function', '');
  add('B06J35-9 bulk wrapper preserved', typeof fhB06J35_9_createAssignedQrBulk === 'function' && typeof fhB06J33A_createAssignedQrBulk === 'function', '');
  add('B06J34D public QR preserved', typeof fhB06J34D_createPublicEntryQrLink === 'function' || typeof fhB06J34A_createPublicEntryQrLink === 'function', '');
  add('B06J34F B05 preserved', typeof fhB05GetWorklists === 'function', '');
  add('B06J34E promotion preserved', typeof promoteCustomerToRegular === 'function' && typeof requestCustomerPromotion === 'function', '');
  var b={}; try { b=getBuildInfo(); } catch(e) { b={error:String(e)}; }
  add('getBuildInfo B06J35-11', b && b.buildNo === FH_B06J35_11_BUILD, b && b.buildNo ? b.buildNo : JSON.stringify(b));
  var result={ok:missing.length===0,message:missing.length?'B06J35-11 내부점검 확인 필요':'B06J35-11 내부점검 통과',data:{build:FH_B06J35_11_BUILD,title:FH_B06J35_11_TITLE,checked:checks,missing:missing,policy:'지정형 QR 일괄 기능은 화면에서 숨김. 빠른고객등록 QR_SIGN 문서 생성으로 1건씩 운영.'},errorCode:missing.length?'B06J35_11_INTERNAL_TEST_REVIEW':'',meta:{build:FH_B06J35_11_BUILD,generatedAt:new Date().toISOString()}};
  Logger.log(JSON.stringify(result,null,2));
  return result;
}
function getBuildInfo() { return { buildNo: FH_B06J35_11_BUILD, buildTitle: FH_B06J35_11_TITLE, generatedAt: new Date().toISOString() }; }


/** FEELHAUS ERP v64-B06J35-13 QR_SIGN ensureSheet FIX SAFE
 * 빠른 고객등록 QR_SIGN 문서 생성에서 전역 ensureSheet 미정의 오류를 차단한다.
 * B06J35-11 지정형 QR 일괄 UI 숨김, 공용 QR, B05, 승격, 판매, 설치 기능은 건드리지 않는다.
 */
var FH_B06J35_13_BUILD = 'v64-B06J35-13';
var FH_B06J35_13_TITLE = 'ERP 통합빌드 v64-B06J35-13 QR_SIGN ensureSheet 오류수정 / B06J35-11 기능보존';
function fhB06J35_13_s_(v){ return String(v == null ? '' : v).trim(); }
function fhB06J35_13_upper_(v){ return fhB06J35_13_s_(v).toUpperCase(); }
function fhB06J35_13_getProp_(key){ try { return PropertiesService.getScriptProperties().getProperty(key) || ''; } catch(e){ return ''; } }
function fhB06J35_13_master_(){
  try { if (typeof syncSystemConfig === 'function') syncSystemConfig(); } catch(e) {}
  var props = PropertiesService.getScriptProperties();
  var keys = ['FEELHAUS_DB_MASTER_ID','DB_SPREADSHEET_ID','DB_MASTER_ID','MASTER_DB_ID','SPREADSHEET_ID'];
  for (var i=0;i<keys.length;i++){
    var id = props.getProperty(keys[i]);
    if (id) return SpreadsheetApp.openById(id);
  }
  throw new Error('FEELHAUS_DB_MASTER 연결 ID를 찾지 못했습니다. SystemConfig/ScriptProperties를 확인하세요.');
}
function fhB06J35_13_ensureSheet_(name, headers){
  var ss = fhB06J35_13_master_();
  var sh = ss.getSheetByName(name);
  if (!sh) sh = ss.insertSheet(name);
  headers = headers || [];
  if (headers.length && sh.getLastRow() === 0) sh.getRange(1,1,1,headers.length).setValues([headers]);
  if (headers.length) fhB06J35_13_ensureHeaders_(sh, headers);
  return sh;
}
function fhB06J35_13_ensureHeaders_(sh, headers){
  var lastCol = Math.max(sh.getLastColumn(), 1);
  var current = sh.getRange(1,1,1,lastCol).getDisplayValues()[0].map(function(h){return fhB06J35_13_s_(h);});
  var exists = {}; current.forEach(function(h){ if(h) exists[h]=true; });
  var missing = [];
  (headers||[]).forEach(function(h){ h=fhB06J35_13_s_(h); if(h && !exists[h]){ missing.push(h); exists[h]=true; } });
  if (missing.length) sh.getRange(1,current.length+1,1,missing.length).setValues([missing]);
  return sh;
}
function fhB06J35_13_headerMap_(sh){
  var lastCol=Math.max(sh.getLastColumn(),1);
  var head=sh.getRange(1,1,1,lastCol).getDisplayValues()[0].map(function(h){return fhB06J35_13_s_(h);});
  var map={}; head.forEach(function(h,i){ if(h) map[h]=i; });
  return {head:head,map:map};
}
function fhB06J35_13_appendObject_(sheetName, headers, obj){
  var sh = fhB06J35_13_ensureSheet_(sheetName, headers);
  var hm = fhB06J35_13_headerMap_(sh);
  var row = hm.head.map(function(h){ return Object.prototype.hasOwnProperty.call(obj,h) ? obj[h] : ''; });
  sh.appendRow(row);
  return row;
}
function fhB06J35_13_docHeaders_(){
  return ['documentId','documentNo','documentType','status','statusReason','eventId','vendorId','customerId','saleId','contractId','installId','settlementId','approvalId','title','templateCode','signMethod','signUrl','qrUrl','createdAt','createdBy','updatedAt','updatedBy','notes'];
}
function fhB06J35_13_isReusableQrSignStatus_(status){
  var st=fhB06J35_13_upper_(status);
  return !st || ['READY_TO_SIGN','QR_SIGN_CREATED','DRAFT','CREATED','PENDING_SIGN','SIGN_READY'].indexOf(st)>=0;
}
function fhB06J35_13_mustCreateNewQrSignStatus_(status){
  var st=fhB06J35_13_upper_(status);
  return ['ARCHIVED','PDF_COMPLETED','SIGN_COMPLETED','COMPLETED','LOCKED','CANCELLED','CANCELED','REJECTED','VOID','VOIDED'].indexOf(st)>=0;
}
function fhB06J35_13_makeQrSignUrl_(documentId, customer, eventId){
  var base = fhB06J35_13_getProp_('SIGN_WEBAPP_URL') || fhB06J35_13_getProp_('SIGN_WEB_APP_URL') || fhB06J35_13_getProp_('SIGN_URL');
  if(!base) base='https://script.google.com/macros/s/AKfycby7TkzJGBe9vW7eDmqOaDWYc23cQEzrYRC2hVVc1dvMdmk50r5stgDi4fPikMgeMPrU/exec';
  base=String(base||'').split('?')[0];
  var eventName=fhB06J35_13_s_((customer&&(customer.eventType||customer.eventName))||'입주박람회');
  var boothHint=fhB06J35_13_s_((customer&&(customer.aptName||customer.apartmentName||customer.apt))||((customer&&customer.dong?customer.dong+'동 ':'')+(customer&&(customer.hosu||customer.ho)?(customer.hosu||customer.ho)+'호':'')));
  return base+'?mode=sign&documentId='+encodeURIComponent(documentId)+'&fieldMode=QR&eventId='+encodeURIComponent(eventId||'')+'&eventName='+encodeURIComponent(eventName)+'&boothHint='+encodeURIComponent(boothHint);
}
function fhB06J35_13_findQrSignDocs_(sheet, customerId, eventId){
  var vals=sheet.getDataRange().getDisplayValues();
  if(!vals || !vals.length) return [];
  var head=vals[0].map(function(h){return fhB06J35_13_s_(h);});
  var idx={}; head.forEach(function(h,i){ if(h) idx[h]=i; });
  var rows=[];
  for(var r=1;r<vals.length;r++){
    var row=vals[r];
    if(fhB06J35_13_upper_(row[idx.documentType])!=='QR_SIGN') continue;
    if(fhB06J35_13_s_(row[idx.customerId])!==customerId) continue;
    if(fhB06J35_13_s_(row[idx.eventId])!==eventId) continue;
    var obj={}; head.forEach(function(h,i){ obj[h]=row[i]||''; }); obj.__rowNumber=r+1; rows.push(obj);
  }
  return rows;
}
function fhB06J35_13_documentNo_(sheet){
  var seq = Math.max(1, sheet.getLastRow());
  var tz = Session.getScriptTimeZone() || 'Asia/Seoul';
  return 'DOC-' + Utilities.formatDate(new Date(), tz, 'yyyyMMdd') + '-' + Utilities.formatString('%03d', seq);
}
function fhB06J35_13_now_(){ return Utilities.formatDate(new Date(), Session.getScriptTimeZone() || 'Asia/Seoul', 'yyyy-MM-dd HH:mm:ss'); }
function fhB06J35_13_appendQrSignLog_(documentId, actionType, fromStatus, toStatus, actor, reason){
  try{
    fhB06J35_13_appendObject_('SIGN_Document_Logs',['logId','documentId','actionType','fromStatus','toStatus','actor','reason','createdAt'],{
      logId:'LOG-'+Utilities.getUuid().replace(/-/g,'').substring(0,12).toUpperCase(), documentId:documentId||'', actionType:actionType||'CREATE_QR_SIGN_FROM_ERP', fromStatus:fromStatus||'', toStatus:toStatus||'', actor:actor||'system', reason:reason||'', createdAt:fhB06J35_13_now_()
    });
  }catch(e){}
}
function createQrSignDocumentForCustomer(payload){
  payload=payload||{};
  try { if (typeof syncSystemConfig === 'function') syncSystemConfig(); } catch(e) {}
  var customerId=fhB06J35_13_s_(payload.customerId);
  if(!customerId) throw new Error('customerId가 필요합니다. 빠른고객등록 후 실행하세요.');
  var detail={}; try { if (typeof getCustomerDetail === 'function') detail=getCustomerDetail(customerId)||{}; } catch(e) { detail={}; }
  var customer=detail.customer||detail.data||detail||{};
  var eventId=fhB06J35_13_s_(payload.eventId)||fhB06J35_13_s_(customer.eventId);
  if(!eventId) throw new Error('eventId가 필요합니다. QR_SIGN 문서는 행사 기준으로 생성해야 합니다.');
  var vendorId=fhB06J35_13_s_(payload.vendorId)||fhB06J35_13_s_(customer.vendorId);
  var actor=fhB06J35_13_s_(payload.createdBy||payload.updatedBy)||'system';
  var headers=fhB06J35_13_docHeaders_();
  var sh=fhB06J35_13_ensureSheet_('SIGN_Documents',headers);
  var existing=fhB06J35_13_findQrSignDocs_(sh,customerId,eventId);
  for(var i=existing.length-1;i>=0;i--){
    var doc=existing[i]; var st=fhB06J35_13_s_(doc.status);
    if(fhB06J35_13_isReusableQrSignStatus_(st)){
      var reuseUrl=doc.signUrl||doc.qrUrl||fhB06J35_13_makeQrSignUrl_(doc.documentId,customer,eventId);
      return {ok:true,reused:true,createdNew:false,message:'QR_SIGN 기존 서명대기 문서 재사용',data:doc,documentId:doc.documentId||'',signUrl:reuseUrl,qrUrl:reuseUrl,status:st||'READY_TO_SIGN',customerId:customerId,eventId:eventId,policy:'REUSE_ACTIVE_QR_SIGN',buildNo:FH_B06J35_13_BUILD};
    }
  }
  var archivedDocs=existing.filter(function(d){return fhB06J35_13_mustCreateNewQrSignStatus_(d.status);});
  var now=fhB06J35_13_now_();
  var documentId='DOC_'+Utilities.getUuid().replace(/-/g,'').substring(0,12).toUpperCase();
  var documentNo=fhB06J35_13_documentNo_(sh);
  var signUrl=fhB06J35_13_makeQrSignUrl_(documentId,customer,eventId);
  var oldIds=archivedDocs.map(function(d){return d.documentId||'';}).filter(String).join(',');
  var reason=archivedDocs.length?'기존 보관/완료 QR_SIGN 재사용 금지 → 신규 문서 생성':'ERP 빠른고객등록 QR_SIGN 신규 생성';
  var rowObj={documentId:documentId,documentNo:documentNo,documentType:'QR_SIGN',status:'READY_TO_SIGN',statusReason:reason,eventId:eventId,vendorId:vendorId,customerId:customerId,saleId:'',contractId:'',installId:'',settlementId:'',approvalId:'',title:'QR 서명확인서',templateCode:'PDF_QR_SIGN',signMethod:'QR',signUrl:signUrl,qrUrl:signUrl,createdAt:now,createdBy:actor,updatedAt:now,updatedBy:actor,notes:'ERP_B06J35_13 QR_SIGN_NEW_IF_ARCHIVED / dong='+fhB06J35_13_s_(customer.dong)+' hosu='+fhB06J35_13_s_(customer.hosu||customer.ho)+(oldIds?' / oldArchivedDocumentIds='+oldIds:'')};
  fhB06J35_13_appendObject_('SIGN_Documents',headers,rowObj);
  fhB06J35_13_appendQrSignLog_(documentId,'CREATE_QR_SIGN_FROM_ERP','','READY_TO_SIGN',actor,reason+(oldIds?' / 기존문서='+oldIds:''));
  return {ok:true,reused:false,createdNew:true,message:archivedDocs.length?'기존 보관완료 QR_SIGN은 재사용하지 않고 새 문서를 생성했습니다':'QR_SIGN 문서 생성 완료',data:rowObj,documentId:documentId,signUrl:signUrl,qrUrl:signUrl,status:'READY_TO_SIGN',customerId:customerId,eventId:eventId,oldArchivedDocumentIds:oldIds,policy:'CREATE_NEW_IF_ARCHIVED_OR_COMPLETED',buildNo:FH_B06J35_13_BUILD};
}
function erpB06J35_13_runInternalTest(){
  var checks=[]; var missing=[]; function add(n,o,d){checks.push({name:n,ok:!!o,detail:d||''}); if(!o) missing.push(n);}
  add('B06J35-11 hide assigned QR UI preserved',typeof erpB06J35_11_runInternalTest==='function','');
  add('createQrSignDocumentForCustomer override exists',typeof createQrSignDocumentForCustomer==='function','');
  add('global ensureSheet not required',typeof fhB06J35_13_ensureSheet_==='function','uses fhB06J35_13_ensureSheet_');
  add('READY_TO_SIGN reuse policy',fhB06J35_13_isReusableQrSignStatus_('READY_TO_SIGN')===true,'');
  add('ARCHIVED create-new policy',fhB06J35_13_mustCreateNewQrSignStatus_('ARCHIVED')===true&&fhB06J35_13_isReusableQrSignStatus_('ARCHIVED')===false,'');
  add('B06J34D public QR preserved',typeof fhB06J34D_createPublicEntryQrLink==='function'||typeof fhB06J34A_createPublicEntryQrLink==='function'||typeof createPublicEntryQrLink==='function','');
  add('B06J34F B05 preserved',typeof fhB05GetWorklists==='function','');
  add('B06J34E promotion preserved',typeof promoteCustomerToRegular==='function'&&typeof requestCustomerPromotion==='function','');
  var b={}; try{b=getBuildInfo();}catch(e){b={error:String(e)}} add('getBuildInfo B06J35-13',b&&b.buildNo===FH_B06J35_13_BUILD,b&&b.buildNo?b.buildNo:JSON.stringify(b));
  var result={ok:missing.length===0,message:missing.length?'B06J35-13 내부점검 확인 필요':'B06J35-13 내부점검 통과',data:{build:FH_B06J35_13_BUILD,title:FH_B06J35_13_TITLE,checked:checks,missing:missing,policy:'QR_SIGN 생성 시 전역 ensureSheet에 의존하지 않음. ARCHIVED/SIGN_COMPLETED/PDF_COMPLETED는 신규 READY_TO_SIGN 문서 생성.'},errorCode:missing.length?'B06J35_13_INTERNAL_TEST_REVIEW':'',meta:{build:FH_B06J35_13_BUILD,generatedAt:new Date().toISOString()}};
  Logger.log(JSON.stringify(result,null,2)); return result;
}
function getBuildInfo(){ return {buildNo:FH_B06J35_13_BUILD,buildTitle:FH_B06J35_13_TITLE,generatedAt:new Date().toISOString()}; }


/* FEELHAUS ERP v64-B06J35-14 QR_SIGN ARCHIVED REISSUE APPROVAL CONTROL */
var FH_B06J35_14_BUILD='v64-B06J35-14';
var FH_B06J35_14_TITLE='ERP 통합빌드 v64-B06J35-14 QR_SIGN 보관완료 재서명 사유/승인 통제 / B06J35-11 기능보존';

function fhB06J35_14_reasonCode_(v){
  var c=fhB06J35_13_upper_(v);
  var a=['CUSTOMER_INFO_CORRECTION','SIGNATURE_ERROR','DOCUMENT_TYPE_ERROR','CUSTOMER_REQUEST','STAFF_INPUT_ERROR','SYSTEM_ERROR','REISSUE_FOR_EVENT_OPERATION','OTHER'];
  return a.indexOf(c)>=0?c:'';
}
function requestQrSignReissueApproval(payload){
  payload=payload||{};
  var cid=fhB06J35_13_s_(payload.customerId);
  if(!cid) throw new Error('customerId가 필요합니다.');
  var detail={}; try{ if(typeof getCustomerDetail==='function') detail=getCustomerDetail(cid)||{}; }catch(e){}
  var customer=detail.customer||detail.data||detail||{};
  var eid=fhB06J35_13_s_(payload.eventId)||fhB06J35_13_s_(customer.eventId);
  if(!eid) throw new Error('eventId가 필요합니다.');
  var sh=fhB06J35_13_ensureSheet_('SIGN_Documents',fhB06J35_13_docHeaders_());
  var docs=fhB06J35_13_findQrSignDocs_(sh,cid,eid);
  var archived=docs.filter(function(d){return fhB06J35_13_mustCreateNewQrSignStatus_(d.status);});
  if(!archived.length) return {ok:false,message:'재서명 승인요청 대상 보관완료 QR_SIGN 문서가 없습니다.',errorCode:'QR_SIGN_ARCHIVED_DOC_NOT_FOUND',data:{customerId:cid,eventId:eid},meta:{build:FH_B06J35_14_BUILD}};
  var doc=archived[archived.length-1];
  var rc=fhB06J35_14_reasonCode_(payload.reasonCode||payload.reissueReasonCode);
  var rm=fhB06J35_13_s_(payload.reasonMemo||payload.reissueReasonMemo||payload.reason);
  if(!rc) return {ok:false,message:'재서명 사유코드를 선택하세요.',errorCode:'QR_SIGN_REISSUE_REASON_CODE_REQUIRED',data:{originalDocumentId:doc.documentId||'',allowedReasonCodes:['CUSTOMER_INFO_CORRECTION','SIGNATURE_ERROR','DOCUMENT_TYPE_ERROR','CUSTOMER_REQUEST','STAFF_INPUT_ERROR','SYSTEM_ERROR','REISSUE_FOR_EVENT_OPERATION','OTHER']},meta:{build:FH_B06J35_14_BUILD}};
  if(!rm) return {ok:false,message:'재서명 상세 사유를 입력하세요.',errorCode:'QR_SIGN_REISSUE_REASON_MEMO_REQUIRED',data:{originalDocumentId:doc.documentId||'',reasonCode:rc},meta:{build:FH_B06J35_14_BUILD}};
  var now=fhB06J35_13_now_();
  var actor=fhB06J35_13_s_(payload.requestedBy||payload.createdBy)||'system';
  var obj={
    requestId:'REQ_'+Utilities.getUuid().replace(/-/g,'').substring(0,12).toUpperCase(),
    approvalId:'',
    requestType:'QR_SIGN_REISSUE',
    targetType:'SIGN_DOCUMENT',
    originalDocumentId:doc.documentId||'',
    originalDocumentNo:doc.documentNo||'',
    customerId:cid,
    eventId:eid,
    vendorId:fhB06J35_13_s_(payload.vendorId)||fhB06J35_13_s_(customer.vendorId),
    reasonCode:rc,
    reasonMemo:rm,
    approvalStatus:'PENDING',
    status:'PENDING',
    requestedBy:actor,
    requestedAt:now,
    newDocumentId:'',
    notes:'ERP_B06J35_14 재서명 승인요청 / 자동 재오픈·자동 신규생성 차단',
    createdAt:now,
    createdBy:actor,
    updatedAt:now,
    updatedBy:actor
  };
  fhB06J35_13_appendObject_('ERP_ApprovalRequests',['requestId','approvalId','requestType','targetType','originalDocumentId','originalDocumentNo','customerId','eventId','vendorId','reasonCode','reasonMemo','approvalStatus','status','requestedBy','requestedAt','newDocumentId','notes','createdAt','createdBy','updatedAt','updatedBy'],obj);
  try{fhB06J35_13_appendQrSignLog_(doc.documentId||'','REQUEST_QR_SIGN_REISSUE',doc.status||'','PENDING_APPROVAL',actor,rc+' / '+rm);}catch(e){}
  return {ok:true,message:'보관 완료 QR_SIGN 재서명 승인요청을 등록했습니다.',data:obj,meta:{build:FH_B06J35_14_BUILD}};
}
function createQrSignDocumentForCustomer(payload){
  payload=payload||{};
  try{ if(typeof syncSystemConfig==='function') syncSystemConfig(); }catch(e){}
  var cid=fhB06J35_13_s_(payload.customerId);
  if(!cid) throw new Error('customerId가 필요합니다. 빠른고객등록 후 실행하세요.');
  var detail={}; try{ if(typeof getCustomerDetail==='function') detail=getCustomerDetail(cid)||{}; }catch(e){}
  var customer=detail.customer||detail.data||detail||{};
  var eid=fhB06J35_13_s_(payload.eventId)||fhB06J35_13_s_(customer.eventId);
  if(!eid) throw new Error('eventId가 필요합니다. QR_SIGN 문서는 행사 기준으로 생성해야 합니다.');
  var sh=fhB06J35_13_ensureSheet_('SIGN_Documents',fhB06J35_13_docHeaders_());
  var docs=fhB06J35_13_findQrSignDocs_(sh,cid,eid);
  for(var i=docs.length-1;i>=0;i--){
    var d=docs[i], st=fhB06J35_13_s_(d.status);
    if(fhB06J35_13_isReusableQrSignStatus_(st)){
      var u=d.signUrl||d.qrUrl||fhB06J35_13_makeQrSignUrl_(d.documentId,customer,eid);
      return {ok:true,reused:true,createdNew:false,message:'QR_SIGN 기존 서명대기 문서 재사용',data:d,documentId:d.documentId||'',signUrl:u,qrUrl:u,status:st||'READY_TO_SIGN',customerId:cid,eventId:eid,policy:'REUSE_ACTIVE_QR_SIGN',buildNo:FH_B06J35_14_BUILD};
    }
  }
  var archived=docs.filter(function(d){return fhB06J35_13_mustCreateNewQrSignStatus_(d.status);});
  if(archived.length){
    var doc=archived[archived.length-1];
    return {ok:false,message:'이미 보관 완료된 QR_SIGN 문서가 있어 자동 생성하지 않았습니다. 재서명이 필요하면 사유를 입력하고 승인요청하세요.',errorCode:'QR_SIGN_REISSUE_APPROVAL_REQUIRED',data:{originalDocumentId:doc.documentId||'',originalStatus:doc.status||'',customerId:cid,eventId:eid,required:['reasonCode','reasonMemo'],policy:'ARCHIVED_REQUIRES_REASON_AND_APPROVAL'},meta:{build:FH_B06J35_14_BUILD}};
  }
  var now=fhB06J35_13_now_();
  var documentId='DOC_'+Utilities.getUuid().replace(/-/g,'').substring(0,12).toUpperCase();
  var signUrl=fhB06J35_13_makeQrSignUrl_(documentId,customer,eid);
  var actor=fhB06J35_13_s_(payload.createdBy||payload.updatedBy)||'system';
  var obj={documentId:documentId,documentNo:fhB06J35_13_documentNo_(sh),documentType:'QR_SIGN',status:'READY_TO_SIGN',statusReason:'ERP 빠른고객등록 QR_SIGN 신규 생성',eventId:eid,vendorId:fhB06J35_13_s_(payload.vendorId)||fhB06J35_13_s_(customer.vendorId),customerId:cid,title:'QR 서명확인서',templateCode:'PDF_QR_SIGN',signMethod:'QR',signUrl:signUrl,qrUrl:signUrl,createdAt:now,createdBy:actor,updatedAt:now,updatedBy:actor,notes:'ERP_B06J35_14 QR_SIGN_NEW_NO_ARCHIVED'};
  fhB06J35_13_appendObject_('SIGN_Documents',fhB06J35_13_docHeaders_(),obj);
  fhB06J35_13_appendQrSignLog_(documentId,'CREATE_QR_SIGN_FROM_ERP','','READY_TO_SIGN',actor,'ERP 빠른고객등록 QR_SIGN 신규 생성');
  return {ok:true,reused:false,createdNew:true,message:'QR_SIGN 문서 생성 완료',data:obj,documentId:documentId,signUrl:signUrl,qrUrl:signUrl,status:'READY_TO_SIGN',customerId:cid,eventId:eid,policy:'CREATE_NEW_NO_ARCHIVED',buildNo:FH_B06J35_14_BUILD};
}
function erpB06J35_14_runInternalTest(){
  var c=[],m=[]; function add(n,o,d){c.push({name:n,ok:!!o,detail:d||''}); if(!o)m.push(n);}
  add('B06J35-11 hide assigned QR UI preserved',typeof erpB06J35_11_runInternalTest==='function','');
  add('B06J35-13 ensureSheet helper preserved',typeof fhB06J35_13_ensureSheet_==='function','');
  add('createQrSignDocumentForCustomer B06J35-14 override exists',typeof createQrSignDocumentForCustomer==='function','');
  add('requestQrSignReissueApproval exists',typeof requestQrSignReissueApproval==='function','');
  add('ARCHIVED requires approval policy',fhB06J35_13_mustCreateNewQrSignStatus_('ARCHIVED')===true&&fhB06J35_13_isReusableQrSignStatus_('ARCHIVED')===false,'');
  add('reason whitelist',fhB06J35_14_reasonCode_('CUSTOMER_INFO_CORRECTION')==='CUSTOMER_INFO_CORRECTION'&&fhB06J35_14_reasonCode_('BAD_CODE')==='','');
  add('B05 preserved',typeof fhB05GetWorklists==='function','');
  add('promotion preserved',typeof promoteCustomerToRegular==='function'&&typeof requestCustomerPromotion==='function','');
  var b={}; try{b=getBuildInfo();}catch(e){b={error:String(e)}}
  add('getBuildInfo B06J35-14',b&&b.buildNo===FH_B06J35_14_BUILD,b&&b.buildNo?b.buildNo:JSON.stringify(b));
  var r={ok:m.length===0,message:m.length?'B06J35-14 내부점검 확인 필요':'B06J35-14 내부점검 통과',data:{build:FH_B06J35_14_BUILD,title:FH_B06J35_14_TITLE,checked:c,missing:m,policy:'보관완료 QR_SIGN 자동 재사용/자동 신규생성 금지. 사유코드+상세사유 기반 승인요청 필요.'},errorCode:m.length?'B06J35_14_INTERNAL_TEST_REVIEW':'',meta:{build:FH_B06J35_14_BUILD,generatedAt:new Date().toISOString()}};
  Logger.log(JSON.stringify(r,null,2)); return r;
}
function getBuildInfo(){return {buildNo:FH_B06J35_14_BUILD,buildTitle:FH_B06J35_14_TITLE,generatedAt:new Date().toISOString()};}
/* /FEELHAUS ERP v64-B06J35-14 QR_SIGN ARCHIVED REISSUE APPROVAL CONTROL */


/* FEELHAUS ERP v64-B06J35-16 QR_SIGN REISSUE REQUEST UI SUPPORT */
var FH_B06J35_15_BUILD='v64-B06J35-16';
var FH_B06J35_15_TITLE='ERP 통합빌드 v64-B06J35-16 QR_SIGN 재서명 승인처리 / B06J35-15 요청UI 보존';
function erpB06J35_15_runInternalTest(){
  var checks=[], missing=[];
  function add(n, ok, detail){checks.push({name:n,ok:!!ok,detail:detail||''}); if(!ok) missing.push(n);}
  add('B06J35-14 archived reissue control preserved', typeof createQrSignDocumentForCustomer==='function' && typeof requestQrSignReissueApproval==='function','');
  add('B06J35-13 ensureSheet helper preserved', typeof fhB06J35_13_ensureSheet_==='function','');
  add('B06J35-11 assigned bulk UI hide preserved', typeof erpB06J35_11_runInternalTest==='function','');
  add('B05 preserved', typeof fhB05GetWorklists==='function','');
  add('promotion preserved', typeof promoteCustomerToRegular==='function' && typeof requestCustomerPromotion==='function','');
  var result={ok:missing.length===0,message:missing.length?'B06J35-15 내부점검 확인 필요':'B06J35-15 내부점검 통과',data:{build:FH_B06J35_15_BUILD,title:FH_B06J35_15_TITLE,checked:checks,missing:missing,policy:'보관완료 QR_SIGN은 자동 생성 차단, 화면에서 사유코드/상세사유 입력 후 승인요청'},errorCode:missing.length?'B06J35_15_INTERNAL_TEST_REVIEW':'',meta:{build:FH_B06J35_15_BUILD,generatedAt:new Date().toISOString()}};
  Logger.log(JSON.stringify(result,null,2));
  return result;
}
function getBuildInfo(){return {buildNo:FH_B06J35_15_BUILD,buildTitle:FH_B06J35_15_TITLE,generatedAt:new Date().toISOString()};}

/* FEELHAUS ERP v64-B06J35-16 QR_SIGN REISSUE APPROVAL PROCESS */
var FH_B06J35_16_BUILD='v64-B06J35-16';
var FH_B06J35_16_TITLE='ERP 통합빌드 v64-B06J35-16 QR_SIGN 재서명 승인처리 / B06J35-15 요청UI 보존';
function fhB06J35_16_approvalHeaders_(){return ['requestId','approvalId','requestType','targetType','originalDocumentId','originalDocumentNo','customerId','eventId','vendorId','reasonCode','reasonMemo','approvalStatus','status','requestedBy','requestedAt','approvedBy','approvedAt','rejectReason','newDocumentId','notes','createdAt','createdBy','updatedAt','updatedBy'];}
function fhB06J35_16_getApprovalSheet_(){return fhB06J35_13_ensureSheet_('ERP_ApprovalRequests',fhB06J35_16_approvalHeaders_());}
function fhB06J35_16_readSheetObjects_(sh){var vals=sh.getDataRange().getDisplayValues();if(!vals||!vals.length)return[];var head=vals[0].map(function(h){return fhB06J35_13_s_(h);});var rows=[];for(var r=1;r<vals.length;r++){var obj={__rowNumber:r+1};head.forEach(function(h,i){if(h)obj[h]=vals[r][i]||'';});rows.push(obj);}return rows;}
function fhB06J35_16_updateRow_(sh,rowNumber,obj){var hm=fhB06J35_13_headerMap_(sh);Object.keys(obj||{}).forEach(function(k){if(hm.map[k]===undefined){fhB06J35_13_ensureHeaders_(sh,[k]);hm=fhB06J35_13_headerMap_(sh);}sh.getRange(rowNumber,hm.map[k]+1).setValue(obj[k]);});}
function fhB06J35_16_findRequest_(requestId){var sh=fhB06J35_16_getApprovalSheet_();var id=fhB06J35_13_s_(requestId);var rows=fhB06J35_16_readSheetObjects_(sh);for(var i=0;i<rows.length;i++){if(fhB06J35_13_s_(rows[i].requestId)===id)return{sheet:sh,row:rows[i]};}return null;}
function fhB06J35_16_findDocumentById_(documentId){var sh=fhB06J35_13_ensureSheet_('SIGN_Documents',fhB06J35_13_docHeaders_());var id=fhB06J35_13_s_(documentId);var rows=fhB06J35_16_readSheetObjects_(sh);for(var i=0;i<rows.length;i++){if(fhB06J35_13_s_(rows[i].documentId)===id)return{sheet:sh,row:rows[i]};}return null;}
function getQrSignReissueApprovalRows(status){var st=fhB06J35_13_upper_(status||'PENDING');var rows=fhB06J35_16_readSheetObjects_(fhB06J35_16_getApprovalSheet_()).filter(function(r){if(fhB06J35_13_upper_(r.requestType)!=='QR_SIGN_REISSUE')return false;var rs=fhB06J35_13_upper_(r.approvalStatus||r.status);return st==='ALL'||rs===st;}).reverse();return rows.map(function(r){return{requestId:r.requestId||'',originalDocumentId:r.originalDocumentId||'',originalDocumentNo:r.originalDocumentNo||'',customerId:r.customerId||'',eventId:r.eventId||'',reasonCode:r.reasonCode||'',reasonMemo:r.reasonMemo||'',status:r.approvalStatus||r.status||'',requestedBy:r.requestedBy||'',requestedAt:r.requestedAt||'',approvedBy:r.approvedBy||'',approvedAt:r.approvedAt||'',newDocumentId:r.newDocumentId||'',notes:r.notes||''};});}
function approveQrSignReissueRequest(requestId,actor){var found=fhB06J35_16_findRequest_(requestId);if(!found)throw new Error('재서명 승인요청을 찾을 수 없습니다: '+requestId);var req=found.row;if(fhB06J35_13_upper_(req.requestType)!=='QR_SIGN_REISSUE')throw new Error('QR_SIGN 재서명 요청이 아닙니다: '+requestId);var cur=fhB06J35_13_upper_(req.approvalStatus||req.status);if(cur&&cur!=='PENDING')return{ok:false,message:'이미 처리된 요청입니다: '+cur,errorCode:'QR_SIGN_REISSUE_ALREADY_PROCESSED',data:req,meta:{build:FH_B06J35_16_BUILD}};var original=fhB06J35_16_findDocumentById_(req.originalDocumentId);if(!original)throw new Error('원문서를 찾을 수 없습니다: '+(req.originalDocumentId||''));var odoc=original.row;var ost=fhB06J35_13_upper_(odoc.status);if(!fhB06J35_13_mustCreateNewQrSignStatus_(ost))throw new Error('원문서가 보관/완료/잠금 상태가 아닙니다: '+ost);var cid=fhB06J35_13_s_(req.customerId||odoc.customerId);var eid=fhB06J35_13_s_(req.eventId||odoc.eventId);if(!cid||!eid)throw new Error('customerId/eventId가 필요합니다.');var detail={};try{if(typeof getCustomerDetail==='function')detail=getCustomerDetail(cid)||{};}catch(e){}var customer=detail.customer||detail.data||detail||{customerId:cid,eventId:eid};var sh=fhB06J35_13_ensureSheet_('SIGN_Documents',fhB06J35_13_docHeaders_());var now=fhB06J35_13_now_();var by=fhB06J35_13_s_(actor)||'ERP_ADMIN';var documentId='DOC_'+Utilities.getUuid().replace(/-/g,'').substring(0,12).toUpperCase();var signUrl=fhB06J35_13_makeQrSignUrl_(documentId,customer,eid);var rowObj={documentId:documentId,documentNo:fhB06J35_13_documentNo_(sh),documentType:'QR_SIGN',status:'READY_TO_SIGN',statusReason:'QR_SIGN_REISSUE_APPROVED / '+(req.reasonCode||''),eventId:eid,vendorId:fhB06J35_13_s_(req.vendorId||odoc.vendorId||customer.vendorId),customerId:cid,saleId:odoc.saleId||'',contractId:odoc.contractId||'',installId:odoc.installId||'',settlementId:odoc.settlementId||'',approvalId:req.requestId||'',title:'QR 서명확인서 재서명',templateCode:'PDF_QR_SIGN',signMethod:'QR',signUrl:signUrl,qrUrl:signUrl,createdAt:now,createdBy:by,updatedAt:now,updatedBy:by,notes:'ERP_B06J35_16 QR_SIGN_REISSUE_APPROVED / originalDocumentId='+(req.originalDocumentId||'')+' / reasonCode='+(req.reasonCode||'')+' / reasonMemo='+(req.reasonMemo||'')};fhB06J35_13_appendObject_('SIGN_Documents',fhB06J35_13_docHeaders_(),rowObj);fhB06J35_16_updateRow_(found.sheet,req.__rowNumber,{approvalStatus:'APPROVED',status:'APPROVED',approvedBy:by,approvedAt:now,newDocumentId:documentId,updatedAt:now,updatedBy:by});try{fhB06J35_13_appendQrSignLog_(req.originalDocumentId||'','APPROVE_QR_SIGN_REISSUE',odoc.status||'','REISSUE_APPROVED',by,(req.reasonCode||'')+' / '+(req.reasonMemo||''));}catch(e){}try{fhB06J35_13_appendQrSignLog_(documentId,'CREATE_QR_SIGN_REISSUE','','READY_TO_SIGN',by,'originalDocumentId='+(req.originalDocumentId||'')+' / requestId='+(req.requestId||''));}catch(e){}return{ok:true,message:'QR_SIGN 재서명 승인 및 새 문서 생성 완료',requestId:req.requestId||requestId,documentId:documentId,signUrl:signUrl,qrUrl:signUrl,data:rowObj,meta:{build:FH_B06J35_16_BUILD,generatedAt:new Date().toISOString()}};}
function rejectQrSignReissueRequest(requestId,actor,note){var found=fhB06J35_16_findRequest_(requestId);if(!found)throw new Error('재서명 승인요청을 찾을 수 없습니다: '+requestId);var req=found.row;if(fhB06J35_13_upper_(req.requestType)!=='QR_SIGN_REISSUE')throw new Error('QR_SIGN 재서명 요청이 아닙니다: '+requestId);var cur=fhB06J35_13_upper_(req.approvalStatus||req.status);if(cur&&cur!=='PENDING')return{ok:false,message:'이미 처리된 요청입니다: '+cur,errorCode:'QR_SIGN_REISSUE_ALREADY_PROCESSED',data:req,meta:{build:FH_B06J35_16_BUILD}};var now=fhB06J35_13_now_();var by=fhB06J35_13_s_(actor)||'ERP_ADMIN';var memo=fhB06J35_13_s_(note)||'관리자 반려';fhB06J35_16_updateRow_(found.sheet,req.__rowNumber,{approvalStatus:'REJECTED',status:'REJECTED',approvedBy:by,approvedAt:now,rejectReason:memo,updatedAt:now,updatedBy:by});try{fhB06J35_13_appendQrSignLog_(req.originalDocumentId||'','REJECT_QR_SIGN_REISSUE','','REISSUE_REJECTED',by,memo);}catch(e){}return{ok:true,message:'QR_SIGN 재서명 승인요청 반려 완료',requestId:req.requestId||requestId,data:{requestId:req.requestId||requestId,status:'REJECTED',rejectReason:memo},meta:{build:FH_B06J35_16_BUILD,generatedAt:new Date().toISOString()}};}
function getIntegratedApprovalSummary(){var base={counts:{},rows:[]};try{if(typeof FH!=='undefined'&&FH&&typeof FH.getIntegratedApprovalSummary==='function')base=FH.getIntegratedApprovalSummary()||base;}catch(e){base={counts:{},rows:[],error:String(e)};}base.counts=base.counts||{};base.rows=base.rows||[];var qrRows=[];try{qrRows=getQrSignReissueApprovalRows('PENDING')||[];}catch(e){qrRows=[];}base.counts.qrReissue=qrRows.length;base.counts.totalPending=(Number(base.counts.totalPending)||0)+qrRows.length;qrRows.slice(0,10).forEach(function(v){base.rows.push({kind:'QR재서명',id:v.requestId,target:v.customerId,status:v.status,note:(v.reasonCode||'')+' / '+(v.originalDocumentId||'')});});return base;}
function erpB06J35_16_runInternalTest(){var checks=[],missing=[];function add(n,o,d){checks.push({name:n,ok:!!o,detail:d||''});if(!o)missing.push(n);}add('B06J35-15 reissue request UI preserved',typeof requestQrSignReissueApproval==='function','');add('approveQrSignReissueRequest exists',typeof approveQrSignReissueRequest==='function','');add('rejectQrSignReissueRequest exists',typeof rejectQrSignReissueRequest==='function','');add('getQrSignReissueApprovalRows exists',typeof getQrSignReissueApprovalRows==='function','');add('ERP_ApprovalRequests ensure helper',typeof fhB06J35_16_getApprovalSheet_==='function','');add('B06J35-11 assigned bulk UI hide preserved',typeof erpB06J35_11_runInternalTest==='function','');add('B05 preserved',typeof fhB05GetWorklists==='function','');add('public QR preserved',typeof createPublicEntryQrLink==='function'||typeof fhB06J34A_createPublicEntryQrLink==='function','');var info={};try{info=getBuildInfo();}catch(e){info={error:String(e)}}add('getBuildInfo B06J35-16',info&&info.buildNo===FH_B06J35_16_BUILD,info&&info.buildNo?info.buildNo:JSON.stringify(info));var result={ok:missing.length===0,message:missing.length?'B06J35-16 내부점검 확인 필요':'B06J35-16 내부점검 통과',data:{build:FH_B06J35_16_BUILD,title:FH_B06J35_16_TITLE,checked:checks,missing:missing,policy:'QR_SIGN 재서명 승인요청 PENDING → 승인 시 새 READY_TO_SIGN 문서 생성 / 반려 시 REJECTED 처리'},errorCode:missing.length?'B06J35_16_INTERNAL_TEST_REVIEW':'',meta:{build:FH_B06J35_16_BUILD,generatedAt:new Date().toISOString()}};Logger.log(JSON.stringify(result,null,2));return result;}
function getBuildInfo(){return{buildNo:FH_B06J35_16_BUILD,buildTitle:FH_B06J35_16_TITLE,generatedAt:new Date().toISOString()};}
/* /FEELHAUS ERP v64-B06J35-16 QR_SIGN REISSUE APPROVAL PROCESS */

/* FEELHAUS ERP v64-B06J35-17 QR_SIGN REISSUE APPROVAL LOOKUP FIX */
var FH_B06J35_17_BUILD='v64-B06J35-17';
var FH_B06J35_17_TITLE='ERP 통합빌드 v64-B06J35-17 QR_SIGN 재서명 승인요청 조회보정 / B06J35-16 기능보존';
function fhB06J35_17_s_(v){return String(v==null?'':v).replace(/[\u200B-\u200D\uFEFF]/g,'').replace(/\u00A0/g,' ').trim();}
function fhB06J35_17_norm_(v){return fhB06J35_17_s_(v).replace(/\s+/g,'').toUpperCase();}
function fhB06J35_17_now_(){try{return Utilities.formatDate(new Date(),Session.getScriptTimeZone()||'Asia/Seoul','yyyy-MM-dd HH:mm:ss');}catch(e){return new Date().toISOString();}}
function fhB06J35_17_read_(sh){var v=sh.getDataRange().getDisplayValues();if(!v||!v.length)return[];var h=v[0].map(function(x){return fhB06J35_17_s_(x)}),a=[];for(var r=1;r<v.length;r++){var o={__rowNumber:r+1,__raw:v[r]};h.forEach(function(k,i){if(k)o[k]=v[r][i]||''});a.push(o)}return a;}
function fhB06J35_17_docFrom_(o){var s=[o.originalDocumentId,o.documentId,o.memo,o.notes,o.note,o.reasonMemo].join(' ');var m=String(s).match(/DOC[_-][A-Z0-9]+/i);return m?m[0]:'';}
function fhB06J35_17_findRequest_(requestId){var id=fhB06J35_17_norm_(requestId);var ss=fhB06J35_13_master_();var names=['ERP_ApprovalRequests','ApprovalRequests','Approvals','ERP_Approvals','ApprovalAudit','SystemLogs'];var sheets=[];names.forEach(function(n){var sh=ss.getSheetByName(n);if(sh)sheets.push(sh)});ss.getSheets().forEach(function(sh){var n=sh.getName();if(/approval|승인|audit/i.test(n)&&sheets.map(function(x){return x.getName()}).indexOf(n)<0)sheets.push(sh)});for(var s=0;s<sheets.length;s++){var rows=fhB06J35_17_read_(sheets[s]);for(var i=0;i<rows.length;i++){var o=rows[i];var raw=fhB06J35_17_norm_((o.__raw||[]).join(' '));if(fhB06J35_17_norm_(o.requestId)!==id&&fhB06J35_17_norm_(o.approvalId)!==id&&fhB06J35_17_norm_(o.id)!==id&&raw.indexOf(id)<0)continue;o.requestId=fhB06J35_17_s_(o.requestId||o.approvalId||o.id||requestId);o.originalDocumentId=fhB06J35_17_s_(o.originalDocumentId)||fhB06J35_17_docFrom_(o);o.customerId=fhB06J35_17_s_(o.customerId||o.targetId||o.target);o.reasonCode=fhB06J35_17_s_(o.reasonCode)||fhB06J35_17_s_((o.memo||o.notes||'').split('/')[0]);o.reasonMemo=fhB06J35_17_s_(o.reasonMemo||o.memo||o.notes||o.note);o.approvalStatus=fhB06J35_17_s_(o.approvalStatus||o.status);if((fhB06J35_17_norm_(o.requestType).indexOf('QR_SIGN_REISSUE')>=0)||fhB06J35_17_norm_(o.reasonMemo).indexOf('DOC_')>=0||fhB06J35_17_norm_(o.__raw.join(' ')).indexOf('재서명')>=0)return{sheet:sheets[s],row:o};}}return null;}
function fhB06J35_17_update_(sh,row,obj){fhB06J35_13_ensureHeaders_(sh,Object.keys(obj));var hm=fhB06J35_13_headerMap_(sh);Object.keys(obj).forEach(function(k){if(hm.map[k]!==undefined)sh.getRange(row,hm.map[k]+1).setValue(obj[k])});}
function approveQrSignReissueRequest(requestId,actor){var f=fhB06J35_17_findRequest_(requestId);if(!f)throw new Error('재서명 승인요청을 찾을 수 없습니다: '+requestId);var req=f.row;if(!req.originalDocumentId)throw new Error('원문서 ID를 확인할 수 없습니다: '+requestId);var original=fhB06J35_16_findDocumentById_(req.originalDocumentId);if(!original)throw new Error('원문서를 찾을 수 없습니다: '+req.originalDocumentId);var odoc=original.row,st=String(odoc.status||'').toUpperCase();if(!fhB06J35_13_mustCreateNewQrSignStatus_(st))throw new Error('원문서가 보관/완료/잠금 상태가 아닙니다: '+st);var cid=fhB06J35_17_s_(req.customerId||odoc.customerId),eid=fhB06J35_17_s_(req.eventId||odoc.eventId);if(!cid||!eid)throw new Error('customerId/eventId가 필요합니다.');var customer={customerId:cid,eventId:eid};try{var d=getCustomerDetail(cid)||{};customer=d.customer||d.data||d||customer}catch(e){}var now=fhB06J35_17_now_(),by=fhB06J35_17_s_(actor)||'ERP_ADMIN',docId='DOC_'+Utilities.getUuid().replace(/-/g,'').substring(0,12).toUpperCase();var sh=fhB06J35_13_ensureSheet_('SIGN_Documents',fhB06J35_13_docHeaders_()),url=fhB06J35_13_makeQrSignUrl_(docId,customer,eid);var rowObj={documentId:docId,documentNo:fhB06J35_13_documentNo_(sh),documentType:'QR_SIGN',status:'READY_TO_SIGN',statusReason:'QR_SIGN_REISSUE_APPROVED / '+(req.reasonCode||''),eventId:eid,vendorId:req.vendorId||odoc.vendorId||customer.vendorId||'',customerId:cid,saleId:odoc.saleId||'',contractId:odoc.contractId||'',installId:odoc.installId||'',settlementId:odoc.settlementId||'',approvalId:req.requestId||requestId,title:'QR 서명확인서 재서명',templateCode:'PDF_QR_SIGN',signMethod:'QR',signUrl:url,qrUrl:url,createdAt:now,createdBy:by,updatedAt:now,updatedBy:by,notes:'ERP_B06J35_17 QR_SIGN_REISSUE_APPROVED / originalDocumentId='+req.originalDocumentId+' / reasonCode='+(req.reasonCode||'')+' / reasonMemo='+(req.reasonMemo||'')};fhB06J35_13_appendObject_('SIGN_Documents',fhB06J35_13_docHeaders_(),rowObj);fhB06J35_17_update_(f.sheet,req.__rowNumber,{approvalStatus:'APPROVED',status:'APPROVED',approvedBy:by,approvedAt:now,newDocumentId:docId,updatedAt:now,updatedBy:by});return{ok:true,message:'QR_SIGN 재서명 승인 및 새 문서 생성 완료',requestId:req.requestId||requestId,documentId:docId,signUrl:url,qrUrl:url,data:rowObj,meta:{build:FH_B06J35_17_BUILD,generatedAt:new Date().toISOString()}};}
function rejectQrSignReissueRequest(requestId,reason,actor){var f=fhB06J35_17_findRequest_(requestId);if(!f)throw new Error('재서명 승인요청을 찾을 수 없습니다: '+requestId);var now=fhB06J35_17_now_(),by=fhB06J35_17_s_(actor)||'ERP_ADMIN';fhB06J35_17_update_(f.sheet,f.row.__rowNumber,{approvalStatus:'REJECTED',status:'REJECTED',rejectedBy:by,rejectedAt:now,rejectReason:fhB06J35_17_s_(reason)||'반려',updatedAt:now,updatedBy:by});return{ok:true,message:'QR_SIGN 재서명 요청 반려 완료',requestId:f.row.requestId||requestId,meta:{build:FH_B06J35_17_BUILD,generatedAt:new Date().toISOString()}};}
function getBuildInfo(){return{buildNo:FH_B06J35_17_BUILD,buildTitle:FH_B06J35_17_TITLE,generatedAt:new Date().toISOString()};}
function erpB06J35_17_runInternalTest(){var c=[],m=[];function a(n,o,d){c.push({name:n,ok:!!o,detail:d||''});if(!o)m.push(n)}a('approval robust finder',typeof fhB06J35_17_findRequest_==='function','');a('approve override',typeof approveQrSignReissueRequest==='function','');a('reject override',typeof rejectQrSignReissueRequest==='function','');a('request UI preserved',typeof requestQrSignReissueApproval==='function','');a('B05 preserved',typeof fhB05GetWorklists==='function','');a('public QR preserved',typeof createPublicEntryQrLink==='function'||typeof fhB06J34A_createPublicEntryQrLink==='function','');var info=getBuildInfo();a('getBuildInfo B17',info.buildNo===FH_B06J35_17_BUILD,info.buildNo);var r={ok:m.length===0,message:m.length?'B06J35-17 내부점검 확인 필요':'B06J35-17 내부점검 통과',data:{build:FH_B06J35_17_BUILD,title:FH_B06J35_17_TITLE,checked:c,missing:m},errorCode:m.length?'B06J35_17_INTERNAL_TEST_REVIEW':'',meta:{build:FH_B06J35_17_BUILD,generatedAt:new Date().toISOString()}};Logger.log(JSON.stringify(r,null,2));return r;}

/* =========================================================
 * FEELHAUS ERP v64-B06J36-9
 * Purpose: ERP 본체에는 FIELD 이동 버튼만 추가하기 위한 서버 보조 함수
 * Scope: 기존 ERP 기능 본문 변경 없음
 * ========================================================= */
function erpB06J36_9_getFieldAppInfo() {
  var url = '';
  var source = '';
  try {
    var cfg = erpB06J36_9_readSystemConfig_();
    var keys = ['ERP_FIELD_WEBAPP_URL', 'ERP_FIELD_URL', 'FIELD_WEBAPP_URL', 'FIELD_APP_URL', 'FEELHAUS_ERP_FIELD_URL'];
    for (var i = 0; i < keys.length; i++) {
      if (cfg.map[keys[i]]) {
        url = erpB06J36_9_s_(cfg.map[keys[i]]);
        source = keys[i];
        break;
      }
    }
    return {
      ok: !!url,
      message: url ? 'ERP_FIELD URL 조회 완료' : 'ERP_FIELD URL 설정이 필요합니다. SystemConfig에 ERP_FIELD_WEBAPP_URL을 등록하세요.',
      data: {
        build: 'v64-B06J36-9',
        title: 'ERP 통합빌드 v64-B06J36-9 FIELD 이동 버튼 추가 / ERP 본체 무수정 전환',
        url: url,
        sourceKey: source,
        requiredKey: 'ERP_FIELD_WEBAPP_URL'
      },
      errorCode: url ? '' : 'ERP_FIELD_URL_NOT_CONFIGURED',
      meta: { build: 'v64-B06J36-9', generatedAt: new Date().toISOString() }
    };
  } catch (err) {
    return { ok:false, message: erpB06J36_9_err_(err), data:{build:'v64-B06J36-9'}, errorCode:'ERP_FIELD_INFO_FAILED', meta:{build:'v64-B06J36-9', generatedAt:new Date().toISOString()} };
  }
}

function erpB06J36_9_fullCheck_20260501_log() {
  var result = erpB06J36_9_fullCheck_();
  Logger.log('==============================');
  Logger.log("[ERP FULL CHECK] erpBuildSummary('B06J36-9')");
  Logger.log(JSON.stringify(result, null, 2));
  Logger.log('==============================');
  return result;
}

function erpB06J36_9_fullCheck_() {
  var checks = [];
  var warnings = [];
  var fatal = 0;
  function add(name, ok, detail, warnOnly) {
    if (!ok && !warnOnly) fatal++;
    if (!ok && warnOnly) warnings.push(name + ': ' + (detail || ''));
    checks.push({ name:name, ok:!!ok, detail:detail || '', warnOnly:!!warnOnly });
  }
  add('ERP_FIELD info function exists', typeof erpB06J36_9_getFieldAppInfo === 'function', 'FIELD 이동 URL 조회 함수');
  add('public QR preserved', typeof createPublicEntryQrLink === 'function' || typeof fhB06J34A_createPublicEntryQrLink === 'function', '공용 QR 함수 보존');
  add('QR_SIGN reissue approval preserved', typeof approveQrSignReissueRequest === 'function' && typeof requestQrSignReissueApproval === 'function', 'QR 재서명 승인 함수 보존');
  add('B05 worklist preserved', typeof fhB05GetWorklists === 'function', 'B05 목록 함수 보존');
  add('customer search preserved', typeof searchCustomers === 'function', '고객검색 함수 보존');
  var field = erpB06J36_9_getFieldAppInfo();
  add('ERP_FIELD URL configured', field.ok, field.message, true);
  return {
    ok: fatal === 0,
    fatal: fatal,
    warnings: warnings,
    label: 'ERP v64-B06J36-9',
    build: 'ERP_v64_B06J36_9_FIELD_NAV_BUTTON_ONLY_SAFE',
    checkedAt: new Date().toISOString(),
    result: { checks: checks, fieldApp: field.data || {} },
    errorCode: fatal ? 'ERP_FULLCHECK_FAILED' : '',
    meta: { build:'v64-B06J36-9', generatedAt:new Date().toISOString() }
  };
}

function erpB06J36_9_readSystemConfig_() {
  var setupId = '17VMSpgSZCvIrUlgcw8yCNcnl8WQWo2IcRf5tDCcuJGM';
  var ss = SpreadsheetApp.openById(setupId);
  var sh = ss.getSheetByName('SystemConfig');
  if (!sh) return { ok:false, map:{}, message:'SystemConfig 시트 없음' };
  var values = sh.getDataRange().getValues();
  if (!values.length) return { ok:false, map:{}, message:'SystemConfig 비어 있음' };
  var headers = values[0].map(function(v){ return erpB06J36_9_s_(v); });
  var keyIdx = erpB06J36_9_findIdx_(headers, ['configKey','key','name','settingKey','항목','키']);
  var valIdx = erpB06J36_9_findIdx_(headers, ['configValue','value','settingValue','값']);
  if (keyIdx < 0) keyIdx = 0;
  if (valIdx < 0) valIdx = 1;
  var map = {};
  for (var i=1; i<values.length; i++) {
    var k = erpB06J36_9_s_(values[i][keyIdx]);
    if (k) map[k] = values[i][valIdx];
  }
  return { ok:true, map:map, keyCount:Object.keys(map).length };
}
function erpB06J36_9_findIdx_(headers, names) {
  var lower = headers.map(function(h){return erpB06J36_9_s_(h).toLowerCase();});
  for (var i=0; i<names.length; i++) {
    var idx = lower.indexOf(erpB06J36_9_s_(names[i]).toLowerCase());
    if (idx >= 0) return idx;
  }
  return -1;
}
function erpB06J36_9_s_(v) { return v === null || v === undefined ? '' : String(v).trim(); }
function erpB06J36_9_err_(err) { return err && err.stack ? String(err.stack) : String(err); }

function getBuildInfo() {
  return {
    buildNo: 'v64-B06J36-9',
    buildTitle: 'ERP 통합빌드 v64-B06J36-9 FIELD 이동 버튼 추가 / ERP 본체 무수정 전환',
    buildName: 'ERP_v64_B06J36_9_FIELD_NAV_BUTTON_ONLY_SAFE',
    ok: true,
    message: 'ERP build info',
    data: { build:'v64-B06J36-9', title:'ERP 통합빌드 v64-B06J36-9 FIELD 이동 버튼 추가 / ERP 본체 무수정 전환' }
  };
}


/**
 * FEELHAUS ERP v64-B06J36-10
 * Purpose: ERP 본체 현장영역 접힘/ERP_FIELD 이동 안내 - 기능 삭제 없음
 */
function erpB06J36_10_getFieldAppInfo() {
  if (typeof erpB06J36_9_getFieldAppInfo === 'function') return erpB06J36_9_getFieldAppInfo();
  return { ok:false, message:'ERP_FIELD URL 조회 함수가 없습니다.', data:{ build:'v64-B06J36-10' }, errorCode:'FIELD_INFO_FUNCTION_MISSING', meta:{ build:'v64-B06J36-10', generatedAt:new Date().toISOString() } };
}

function erpB06J36_10_fullCheck_20260501_log() {
  var result = erpB06J36_10_fullCheck_();
  Logger.log('==============================');
  Logger.log("[ERP FULL CHECK] erpBuildSummary('B06J36-10')");
  Logger.log(JSON.stringify(result, null, 2));
  Logger.log('==============================');
  return result;
}

function erpB06J36_10_fullCheck_() {
  var checks = [];
  var fatal = 0;
  function add(name, ok, detail) { if (!ok) fatal++; checks.push({ name:name, ok:!!ok, detail:detail||'' }); }
  add('Code BUILD_NO B06J36-10', typeof getBuildInfo === 'function', 'getBuildInfo available');
  add('ERP_FIELD info function exists', typeof erpB06J36_10_getFieldAppInfo === 'function', 'FIELD 이동 URL 조회 함수');
  add('public QR preserved', typeof createPublicEntryQrLink === 'function' || typeof fhB06J34A_createPublicEntryQrLink === 'function', '공용 QR 함수 보존');
  add('QR_SIGN reissue approval preserved', typeof approveQrSignReissueRequest === 'function' && typeof requestQrSignReissueApproval === 'function', 'QR 재서명 요청/승인 함수 보존');
  add('B05 worklist preserved', typeof fhB05GetWorklists === 'function', 'B05 목록 함수 보존');
  add('customer search preserved', typeof searchCustomers === 'function', '고객검색 함수 보존');
  var field = { ok:true, message:'FIELD URL 조회 미실행', data:{} };
  try { field = erpB06J36_10_getFieldAppInfo(); add('ERP_FIELD URL lookup', !!field, (field && field.message) || ''); } catch(e) { add('ERP_FIELD URL lookup', false, e && e.message ? e.message : String(e)); }
  return {
    ok: fatal === 0,
    fatal: fatal,
    label: 'ERP v64-B06J36-10',
    build: 'ERP_v64_B06J36_10_CORE_FIELD_COLLAPSE_NOTICE_SAFE',
    checkedAt: new Date().toISOString(),
    result: { checks: checks, fieldInfo: field && field.data ? field.data : {} },
    errorCode: fatal ? 'ERP_B06J36_10_FULLCHECK_FAILED' : '',
    meta: { build:'v64-B06J36-10', generatedAt:new Date().toISOString() }
  };
}

function getBuildInfo() {
  return {
    ok: true,
    buildNo: 'v64-B06J36-10',
    buildTitle: 'ERP 통합빌드 v64-B06J36-10 ERP 본체 현장영역 접힘/ERP_FIELD 이동 안내',
    buildName: 'ERP_v64_B06J36_10_CORE_FIELD_COLLAPSE_NOTICE_SAFE',
    message: 'ERP 통합빌드 v64-B06J36-10 ERP 본체 현장영역 접힘/ERP_FIELD 이동 안내',
    data: { build:'v64-B06J36-10', title:'ERP 통합빌드 v64-B06J36-10 ERP 본체 현장영역 접힘/ERP_FIELD 이동 안내', roleSplit:'ERP_FIELD_NAV_READY', coreFieldArea:'COLLAPSED_NOTICE_ONLY' }
  };
}


/**
 * FEELHAUS ERP v64-B06J36-11
 * ERP 본체 현장기능 삭제 / ERP_FIELD 이동 전환 최소패치
 * 기존 FIELD 이동 버튼과 핵심 기능 보존 확인용 fullCheck
 */
function erpB06J36_11_fullCheck_20260501_log() {
  var checks = [], fatal = 0;
  function add(name, ok, detail) {
    if (!ok) fatal++;
    checks.push({ name: name, ok: !!ok, detail: detail || '' });
  }
  add('Code BUILD_NO B06J36-11', true, 'v64-B06J36-11');
  add('ERP_FIELD nav info function exists', typeof erpB06J36_10_getFieldAppInfo === 'function' || typeof erpB06J36_9_getFieldAppInfo === 'function', 'FIELD 이동 버튼 연결 함수');
  add('public QR preserved', typeof createPublicEntryQrLink === 'function' || typeof fhB06J34A_createPublicEntryQrLink === 'function', '공용 QR 함수 보존');
  add('QR_SIGN reissue approval preserved', typeof requestQrSignReissueApproval === 'function' && typeof approveQrSignReissueRequest === 'function', 'QR 재서명 요청/승인 함수 보존');
  add('B05 worklist preserved', typeof fhB05GetWorklists === 'function', 'B05 목록 함수 보존');
  add('customer search preserved', typeof searchCustomers === 'function', '고객검색 함수 보존');
  add('saveSale preserved', typeof saveSale === 'function', '판매 저장 함수 보존');
  add('completeInstallation preserved', typeof completeInstallation === 'function', '설치완료 함수 보존');
  var result = {
    ok: fatal === 0,
    fatal: fatal,
    label: 'ERP v64-B06J36-11',
    build: 'ERP_v64_B06J36_11_CORE_FIELD_DELETE_NAV_ONLY_SAFE',
    checkedAt: new Date().toISOString(),
    result: { checks: checks, fieldAreaPolicy: 'ERP 본체 현장 QR / 빠른 고객등록 UI 삭제, ERP_FIELD 이동 버튼만 유지' }
  };
  Logger.log('==============================');
  Logger.log("[ERP FULL CHECK] erpBuildSummary('B06J36-11')");
  Logger.log(JSON.stringify(result, null, 2));
  Logger.log('==============================');
  return result;
}

function getBuildInfo() {
  return {
    buildNo: 'v64-B06J36-11',
    buildTitle: 'ERP 통합빌드 v64-B06J36-11 ERP 본체 현장기능 삭제 / ERP_FIELD 이동 전환',
    generatedAt: new Date().toISOString(),
    message: 'ERP 통합빌드 v64-B06J36-11 ERP 본체 현장기능 삭제 / ERP_FIELD 이동 전환',
    data: {
      build: 'v64-B06J36-11',
      title: 'ERP 통합빌드 v64-B06J36-11 ERP 본체 현장기능 삭제 / ERP_FIELD 이동 전환',
      roleSplit: 'ERP_FIELD_NAV_ONLY',
      coreFieldArea: 'REMOVED_FROM_ERP_CORE'
    }
  };
}


/**
 * FEELHAUS ERP v64-B06J36-14
 * ERP_ADMIN 이동 버튼 추가 / ERP 본체 무수정 전환
 * 기존 FIELD 이동/핵심 기능 보존 확인용 fullCheck
 */
function erpB06J36_14_getAdminAppInfo() {
  var url = '';
  var source = '';
  try {
    var cfg = (typeof erpB06J36_9_readSystemConfig_ === 'function') ? erpB06J36_9_readSystemConfig_() : { map:{} };
    var keys = ['ERP_ADMIN_WEBAPP_URL', 'ERP_ADMIN_URL', 'ADMIN_WEBAPP_URL', 'ADMIN_APP_URL', 'FEELHAUS_ERP_ADMIN_URL'];
    for (var i = 0; i < keys.length; i++) {
      if (cfg.map && cfg.map[keys[i]]) {
        url = String(cfg.map[keys[i]] || '').trim();
        source = keys[i];
        break;
      }
    }
    return {
      ok: !!url,
      message: url ? 'ERP_ADMIN URL 조회 완료' : 'ERP_ADMIN URL 설정이 필요합니다. SystemConfig에 ERP_ADMIN_WEBAPP_URL을 등록하세요.',
      data: {
        build: 'v64-B06J36-14',
        title: 'ERP 통합빌드 v64-B06J36-14 ADMIN 이동 버튼 추가 / ERP 본체 무수정 전환',
        url: url,
        sourceKey: source,
        requiredKey: 'ERP_ADMIN_WEBAPP_URL'
      },
      errorCode: url ? '' : 'ERP_ADMIN_URL_NOT_CONFIGURED',
      meta: { build:'v64-B06J36-14', generatedAt:new Date().toISOString() }
    };
  } catch (err) {
    return { ok:false, message: String(err && err.stack ? err.stack : err), data:{ build:'v64-B06J36-14' }, errorCode:'ERP_ADMIN_INFO_FAILED', meta:{ build:'v64-B06J36-14', generatedAt:new Date().toISOString() } };
  }
}

function erpB06J36_14_fullCheck_20260502_log() {
  var checks = [], warnings = [], fatal = 0;
  function add(name, ok, detail, warnOnly) {
    if (!ok && !warnOnly) fatal++;
    if (!ok && warnOnly) warnings.push(name + ': ' + (detail || ''));
    checks.push({ name:name, ok:!!ok, detail:detail || '', warnOnly:!!warnOnly });
  }
  add('Code BUILD_NO B06J36-14', true, 'v64-B06J36-14');
  add('ERP_FIELD nav info function exists', typeof erpB06J36_9_getFieldAppInfo === 'function' || typeof erpB06J36_10_getFieldAppInfo === 'function', 'FIELD 이동 버튼 연결 함수');
  add('ERP_ADMIN nav info function exists', typeof erpB06J36_14_getAdminAppInfo === 'function', 'ADMIN 이동 버튼 연결 함수');
  add('public QR preserved', typeof createPublicEntryQrLink === 'function' || typeof fhB06J34A_createPublicEntryQrLink === 'function', '공용 QR 함수 보존');
  add('QR_SIGN reissue approval preserved', typeof requestQrSignReissueApproval === 'function' && typeof approveQrSignReissueRequest === 'function', 'QR 재서명 요청/승인 함수 보존');
  add('B05 worklist preserved', typeof fhB05GetWorklists === 'function', 'B05 목록 함수 보존');
  add('customer search preserved', typeof searchCustomers === 'function', '고객검색 함수 보존');
  add('saveSale preserved', typeof saveSale === 'function', '판매 저장 함수 보존');
  add('completeInstallation preserved', typeof completeInstallation === 'function', '설치완료 함수 보존');
  var admin = erpB06J36_14_getAdminAppInfo();
  add('ERP_ADMIN URL configured', admin.ok, admin.message, true);
  var result = {
    ok: fatal === 0,
    fatal: fatal,
    warnings: warnings,
    label: 'ERP v64-B06J36-14',
    build: 'ERP_v64_B06J36_14_ADMIN_NAV_BUTTON_ONLY_SAFE',
    checkedAt: new Date().toISOString(),
    result: {
      checks: checks,
      adminApp: admin.data || {},
      roleSplitPolicy: 'ERP 본체는 판매/설치/B05 중심 유지, ADMIN 기능은 ERP_ADMIN 이동 버튼으로 연결'
    },
    errorCode: fatal ? 'ERP_B06J36_14_FULLCHECK_FAILED' : '',
    meta: { build:'v64-B06J36-14', generatedAt:new Date().toISOString() }
  };
  Logger.log('==============================');
  Logger.log("[ERP FULL CHECK] erpBuildSummary('B06J36-14')");
  Logger.log(JSON.stringify(result, null, 2));
  Logger.log('==============================');
  return result;
}

function getBuildInfo() {
  return {
    buildNo: 'v64-B06J36-14',
    buildTitle: 'ERP 통합빌드 v64-B06J36-14 ADMIN 이동 버튼 추가 / ERP 본체 무수정 전환',
    generatedAt: new Date().toISOString(),
    message: 'ERP 통합빌드 v64-B06J36-14 ADMIN 이동 버튼 추가 / ERP 본체 무수정 전환',
    data: {
      build: 'v64-B06J36-14',
      title: 'ERP 통합빌드 v64-B06J36-14 ADMIN 이동 버튼 추가 / ERP 본체 무수정 전환',
      roleSplit: 'ERP_FIELD_AND_ADMIN_NAV_READY',
      corePolicy: 'ERP_CORE_LIGHTWEIGHT_NAV_ONLY'
    }
  };
}


/**
 * FEELHAUS ERP v64-B06J36-15
 * ADMIN UI removal from ERP core / ERP_ADMIN navigation preserved
 * Minimal server-side fullCheck only. Existing functions are not deleted.
 */
function erpB06J36_15_getAdminAppInfo() {
  try {
    var info = (typeof erpB06J36_14_getAdminAppInfo === 'function') ? erpB06J36_14_getAdminAppInfo() : null;
    if (info && info.ok) {
      info.data = info.data || {};
      info.data.build = 'v64-B06J36-15';
      info.data.title = 'ERP 통합빌드 v64-B06J36-15 ADMIN 기능 본체 UI 제거 / ERP_ADMIN 이동 전환';
      info.meta = { build:'v64-B06J36-15', generatedAt:new Date().toISOString() };
      return info;
    }
    return info || { ok:false, message:'ERP_ADMIN URL 설정 확인 함수를 찾지 못했습니다.', data:{ build:'v64-B06J36-15', url:'' }, errorCode:'ERP_ADMIN_INFO_NOT_FOUND', meta:{ build:'v64-B06J36-15', generatedAt:new Date().toISOString() } };
  } catch (err) {
    return { ok:false, message:String(err && err.stack ? err.stack : err), data:{ build:'v64-B06J36-15' }, errorCode:'ERP_ADMIN_INFO_FAILED', meta:{ build:'v64-B06J36-15', generatedAt:new Date().toISOString() } };
  }
}

function erpB06J36_15_fullCheck_20260502_log() {
  var checks = [];
  var fatal = 0;
  var warnings = [];
  function add(name, ok, detail, warnOnly) {
    if (!ok && warnOnly) warnings.push(name + ': ' + (detail || ''));
    if (!ok && !warnOnly) fatal++;
    checks.push({ name:name, ok:!!ok, detail:detail || '', warnOnly:!!warnOnly });
  }
  add('Code BUILD_NO B06J36-15', true, 'v64-B06J36-15', false);
  add('ERP_FIELD nav info function exists', typeof erpB06J36_9_getFieldAppInfo === 'function', 'FIELD 이동 버튼 연결 함수', false);
  add('ERP_ADMIN nav info function exists', typeof erpB06J36_15_getAdminAppInfo === 'function', 'ADMIN 이동 버튼 연결 함수', false);
  add('public QR preserved', typeof createPublicEntryQrLink === 'function' || typeof fhB06J34D_createPublicEntryQrLink === 'function', '공용 QR 함수 보존', false);
  add('QR_SIGN reissue approval preserved', typeof approveQrSignReissueRequest === 'function' && typeof rejectQrSignReissueRequest === 'function', 'ERP 본체 서버 함수 보존 / UI는 ERP_ADMIN으로 이동', false);
  add('B05 worklist preserved', typeof fhB05GetWorklists === 'function', 'B05 목록 함수 보존', false);
  add('customer search preserved', typeof searchCustomers === 'function', '고객검색 함수 보존', false);
  add('saveSale preserved', typeof saveSale === 'function', '판매 저장 함수 보존', false);
  add('completeInstallation preserved', typeof completeInstallation === 'function', '설치완료 함수 보존', false);
  add('ADMIN UI migration policy', true, '직원계정관리/민감역할/QR재서명 승인 UI는 ERP 본체에서 비노출, ERP_ADMIN 이동', false);
  var admin = erpB06J36_15_getAdminAppInfo();
  add('ERP_ADMIN URL configured', !!(admin && admin.ok && admin.data && admin.data.url), (admin && admin.message) || 'ERP_ADMIN URL 확인', true);
  var result = {
    ok: fatal === 0,
    fatal: fatal,
    warnings: warnings,
    label: 'ERP v64-B06J36-15',
    build: 'ERP_v64_B06J36_15_CORE_ADMIN_UI_DELETE_NAV_ONLY_SAFE',
    checkedAt: new Date().toISOString(),
    result: {
      checks: checks,
      adminApp: admin && admin.data ? admin.data : {},
      roleSplitPolicy: 'ERP 본체는 판매/설치/B05 중심 유지, 직원/권한/QR재서명 승인 UI는 ERP_ADMIN으로 이동'
    },
    errorCode: fatal ? 'ERP_B06J36_15_FULLCHECK_FAILED' : '',
    meta: { build:'v64-B06J36-15', generatedAt:new Date().toISOString() }
  };
  Logger.log('==============================');
  Logger.log("[ERP FULL CHECK] erpBuildSummary('B06J36-15')");
  Logger.log(JSON.stringify(result, null, 2));
  Logger.log('==============================');
  return result;
}

function getBuildInfo() {
  return {
    ok: true,
    buildNo: 'v64-B06J36-15',
    buildTitle: 'ERP 통합빌드 v64-B06J36-15 ADMIN 기능 본체 UI 제거 / ERP_ADMIN 이동 전환',
    message: 'ERP 통합빌드 v64-B06J36-15 ADMIN 기능 본체 UI 제거 / ERP_ADMIN 이동 전환',
    data: {
      build: 'v64-B06J36-15',
      title: 'ERP 통합빌드 v64-B06J36-15 ADMIN 기능 본체 UI 제거 / ERP_ADMIN 이동 전환',
      roleSplitPolicy: 'ERP 본체는 판매/설치/B05 중심, ADMIN 기능은 ERP_ADMIN으로 분리'
    },
    errorCode: '',
    meta: { build:'v64-B06J36-15', generatedAt:new Date().toISOString() }
  };
}


/**
 * FEELHAUS ERP v64-B06J36-16 SIGN NAV BUTTON ONLY
 * Purpose: ERP 본체에서 SIGN 문서/서명/PDF 시스템으로 이동 버튼만 연결한다.
 * Scope: 기존 ERP 본체 기능 삭제/수정 없음.
 */
function erpB06J36_16_getSignAppInfo() {
  var url = '';
  var source = '';
  try {
    var cfg = (typeof erpB06J36_9_readSystemConfig_ === 'function') ? erpB06J36_9_readSystemConfig_() : { map:{} };
    var keys = ['SIGN_WEBAPP_URL', 'SIGN_WEB_APP_URL', 'SIGN_URL', 'SIGN_EXEC_URL', 'SIGN_WEBAPP_EXEC_URL', 'FEELHAUS_SIGN_URL'];
    for (var i = 0; i < keys.length; i++) {
      if (cfg.map && cfg.map[keys[i]]) {
        url = String(cfg.map[keys[i]] || '').trim();
        source = keys[i];
        break;
      }
    }
    return {
      ok: !!url,
      message: url ? 'SIGN URL 조회 완료' : 'SIGN URL 설정이 필요합니다. SystemConfig에 SIGN_WEBAPP_URL을 등록하세요.',
      data: {
        build: 'v64-B06J36-16',
        title: 'ERP 통합빌드 v64-B06J36-16 SIGN 이동 버튼 추가 / ERP 본체 무수정 전환',
        url: url,
        sourceKey: source,
        requiredKey: 'SIGN_WEBAPP_URL'
      },
      errorCode: url ? '' : 'SIGN_URL_NOT_CONFIGURED',
      meta: { build:'v64-B06J36-16', generatedAt:new Date().toISOString() }
    };
  } catch (err) {
    return { ok:false, message:String(err && err.stack ? err.stack : err), data:{ build:'v64-B06J36-16' }, errorCode:'SIGN_INFO_FAILED', meta:{ build:'v64-B06J36-16', generatedAt:new Date().toISOString() } };
  }
}

function erpB06J36_16_fullCheck_20260502_log() {
  var checks = [];
  var fatal = 0;
  var warnings = [];
  function add(name, ok, detail, warnOnly) {
    if (!ok && warnOnly) warnings.push(name + ': ' + (detail || ''));
    if (!ok && !warnOnly) fatal++;
    checks.push({ name:name, ok:!!ok, detail:detail || '', warnOnly:!!warnOnly });
  }
  add('Code BUILD_NO B06J36-16', true, 'v64-B06J36-16', false);
  add('ERP_FIELD nav info function exists', typeof erpB06J36_9_getFieldAppInfo === 'function', 'FIELD 이동 버튼 연결 함수', false);
  add('ERP_ADMIN nav info function exists', typeof erpB06J36_15_getAdminAppInfo === 'function' || typeof erpB06J36_14_getAdminAppInfo === 'function', 'ADMIN 이동 버튼 연결 함수', false);
  add('SIGN nav info function exists', typeof erpB06J36_16_getSignAppInfo === 'function', 'SIGN 이동 버튼 연결 함수', false);
  add('public QR preserved', typeof createPublicEntryQrLink === 'function' || typeof fhB06J34D_createPublicEntryQrLink === 'function', '공용 QR 함수 보존', false);
  add('QR_SIGN reissue approval preserved', typeof approveQrSignReissueRequest === 'function' && typeof rejectQrSignReissueRequest === 'function', 'ERP 본체 서버 함수 보존 / UI는 ERP_ADMIN으로 이동', false);
  add('B05 worklist preserved', typeof fhB05GetWorklists === 'function', 'B05 목록 함수 보존', false);
  add('customer search preserved', typeof searchCustomers === 'function', '고객검색 함수 보존', false);
  add('saveSale preserved', typeof saveSale === 'function', '판매 저장 함수 보존', false);
  add('completeInstallation preserved', typeof completeInstallation === 'function', '설치완료 함수 보존', false);
  add('SIGN UI migration prep policy', true, '문서/서명/PDF/보관은 SIGN 이동 버튼으로 연결. ERP 본체 세부 UI는 다음 단계에서 이관 판단', false);
  var sign = erpB06J36_16_getSignAppInfo();
  add('SIGN URL configured', !!(sign && sign.ok && sign.data && sign.data.url), (sign && sign.message) || 'SIGN URL 확인', true);
  var admin = (typeof erpB06J36_15_getAdminAppInfo === 'function') ? erpB06J36_15_getAdminAppInfo() : ((typeof erpB06J36_14_getAdminAppInfo === 'function') ? erpB06J36_14_getAdminAppInfo() : {data:{}});
  var field = (typeof erpB06J36_9_getFieldAppInfo === 'function') ? erpB06J36_9_getFieldAppInfo() : {data:{}};
  var result = {
    ok: fatal === 0,
    fatal: fatal,
    warnings: warnings,
    label: 'ERP v64-B06J36-16',
    build: 'ERP_v64_B06J36_16_SIGN_NAV_BUTTON_ONLY_SAFE',
    checkedAt: new Date().toISOString(),
    result: {
      checks: checks,
      fieldApp: field && field.data ? field.data : {},
      adminApp: admin && admin.data ? admin.data : {},
      signApp: sign && sign.data ? sign.data : {},
      roleSplitPolicy: 'ERP 본체는 판매/설치/B05 중심 유지, FIELD/ADMIN/SIGN은 각 전용 앱으로 연결'
    },
    errorCode: fatal ? 'ERP_B06J36_16_FULLCHECK_FAILED' : '',
    meta: { build:'v64-B06J36-16', generatedAt:new Date().toISOString() }
  };
  Logger.log('==============================');
  Logger.log("[ERP FULL CHECK] erpBuildSummary('B06J36-16')");
  Logger.log(JSON.stringify(result, null, 2));
  Logger.log('==============================');
  return result;
}

function getBuildInfo() {
  return {
    ok: true,
    buildNo: 'v64-B06J36-16',
    buildTitle: 'ERP 통합빌드 v64-B06J36-16 SIGN 이동 버튼 추가 / ERP 본체 무수정 전환',
    message: 'ERP 통합빌드 v64-B06J36-16 SIGN 이동 버튼 추가 / ERP 본체 무수정 전환',
    data: {
      build: 'v64-B06J36-16',
      title: 'ERP 통합빌드 v64-B06J36-16 SIGN 이동 버튼 추가 / ERP 본체 무수정 전환',
      roleSplitPolicy: 'ERP 본체는 판매/설치/B05 중심, FIELD/ADMIN/SIGN은 전용 앱으로 분리'
    },
    errorCode: '',
    meta: { build:'v64-B06J36-16', generatedAt:new Date().toISOString() }
  };
}

/**
 * FEELHAUS ERP BENEFIT/GIFT SETTLEMENT READONLY HANDOFF
 * Build: ERP_BENEFIT_GIFT_SETTLEMENT_READONLY_SAFE / v64-B06J36-17
 * Purpose: SIGN 기프트/상품권 지급 상태를 ERP 행사/혜택/정산 화면에서 읽기 전용으로 표시한다.
 * Source: SIGN_B06J90_GIFT_ERP_SETTLEMENT_HANDOFF_SAFE
 */
var ERP_BENEFIT_GIFT_BUILD_NO = 'v64-B06J36-17';
var ERP_BENEFIT_GIFT_BUILD_NAME = 'ERP_BENEFIT_GIFT_SETTLEMENT_READONLY_SAFE';
var ERP_BENEFIT_GIFT_TITLE = 'ERP v64-B06J36-17 SIGN 기프트/상품권 정산 읽기전용 인계';

function erpBenefitGiftSettlementReadonlyData(payload) {
  payload = payload || {};
  var eventId = erpBenefitGift_s_(payload.eventId || payload.fieldEventId || '');
  var result = {
    build: ERP_BENEFIT_GIFT_BUILD_NO,
    buildName: ERP_BENEFIT_GIFT_BUILD_NAME,
    title: ERP_BENEFIT_GIFT_TITLE,
    eventId: eventId,
    readOnly: true,
    sourceBuild: 'SIGN_B06J90_GIFT_ERP_SETTLEMENT_HANDOFF_SAFE',
    sourceFunction: 'signGiftErpSettlementHandoffData',
    sourceSheets: [
      'SIGN_Gift_Status_Summary',
      'SIGN_Benefit_Gift_Links',
      'SIGN_Gift_Stock',
      'SIGN_Gift_Stock_Movements'
    ],
    writePolicy: {
      erpDirectEdit: false,
      forbidden: [
        'SIGN_Gift_Status_Summary 직접 수정 금지',
        'SIGN_Benefit_Gift_Links 상태 직접 변경 금지',
        '지급완료/보류/재대기 직접 처리 금지',
        '재고 입출고 직접 수정 금지'
      ],
      settlementCalculation: 'SIGN은 계산하지 않고 ERP 중앙 정산 엔진에서 처리'
    },
    handoffFunctionAvailable: false,
    handoffFunctionResult: null,
    sheets: {},
    cards: {},
    settlementCandidates: [],
    warnings: []
  };

  if (typeof signGiftErpSettlementHandoffData === 'function') {
    result.handoffFunctionAvailable = true;
    try {
      result.handoffFunctionResult = signGiftErpSettlementHandoffData({ eventId: eventId });
    } catch (handoffErr) {
      result.warnings.push('SIGN handoff function call failed: ' + erpBenefitGift_err_(handoffErr));
    }
  }

  var master = erpBenefitGift_openMasterDbSafe_();
  if (!master.ok) {
    return erpBenefitGift_response_(false, master.message, result, 'MASTER_NOT_CONNECTED');
  }

  result.sheets.statusSummary = erpBenefitGift_readRowsByEvent_(master.ss, 'SIGN_Gift_Status_Summary', eventId, 200);
  result.sheets.benefitLinks = erpBenefitGift_readRowsByEvent_(master.ss, 'SIGN_Benefit_Gift_Links', eventId, 500);
  result.sheets.stock = erpBenefitGift_readRowsByEvent_(master.ss, 'SIGN_Gift_Stock', eventId, 500);
  result.sheets.stockMovements = erpBenefitGift_readRowsByEvent_(master.ss, 'SIGN_Gift_Stock_Movements', eventId, 500);

  var links = result.sheets.benefitLinks.rows || [];
  var statusRows = result.sheets.statusSummary.rows || [];
  var movements = result.sheets.stockMovements.rows || [];
  var stockRows = result.sheets.stock.rows || [];

  var paid = 0, pending = 0, hold = 0, rewait = 0, settlementReady = 0;
  var statusCounts = {};
  links.forEach(function(row) {
    var st = erpBenefitGift_s_(row.status || row.giftStatus || row.payoutStatus || row.linkStatus || row.issueStatus).toUpperCase();
    if (!st) st = 'UNKNOWN';
    statusCounts[st] = (statusCounts[st] || 0) + 1;
    if (st === 'PAID' || st === 'GIFT_PAID' || st === 'COMPLETED' || st === '지급완료') paid++;
    if (st === 'PENDING' || st === 'READY' || st === 'WAITING' || st === '대기') pending++;
    if (st === 'HOLD' || st === 'ON_HOLD' || st === '보류') hold++;
    if (st === 'REWAIT' || st === 'RE_WAIT' || st === '재대기') rewait++;

    var settlementStatus = erpBenefitGift_s_(row.settlementStatus || row.erpSettlementStatus || row.settlementReady || row.accountingStatus).toUpperCase();
    var isCandidate = settlementStatus === 'READY' || settlementStatus === 'PENDING' || settlementStatus === 'Y' || settlementStatus === 'TRUE' || settlementStatus === '';
    var amount = erpBenefitGift_n_(row.amount || row.giftAmount || row.benefitAmount || row.settlementAmount || row.price || row.totalAmount);
    if (isCandidate && (st === 'PAID' || st === 'GIFT_PAID' || st === 'COMPLETED' || st === '지급완료')) {
      settlementReady++;
      result.settlementCandidates.push({
        eventId: erpBenefitGift_s_(row.eventId || eventId),
        benefitId: erpBenefitGift_s_(row.benefitId || row.id || row.linkId),
        customerId: erpBenefitGift_s_(row.customerId || row.memberId),
        vendorId: erpBenefitGift_s_(row.vendorId),
        giftId: erpBenefitGift_s_(row.giftId || row.itemId || row.stockId),
        status: st,
        amount: amount,
        settlementStatus: erpBenefitGift_s_(row.settlementStatus || row.erpSettlementStatus || ''),
        sourceSheet: 'SIGN_Benefit_Gift_Links',
        readOnly: true
      });
    }
  });

  result.cards = {
    linkCount: links.length,
    statusSummaryCount: statusRows.length,
    stockCount: stockRows.length,
    stockMovementCount: movements.length,
    paidCount: paid,
    pendingCount: pending,
    holdCount: hold,
    rewaitCount: rewait,
    settlementCandidateCount: settlementReady,
    statusCounts: statusCounts
  };

  return erpBenefitGift_response_(true, 'SIGN 기프트/상품권 정산 인계 데이터 읽기 완료', result, '');
}

function erpBenefitGiftSettlementReadonly_fullCheck_20260502_log() {
  var checks = [];
  var fatal = 0;
  var warnings = [];
  function add(name, ok, detail, warnOnly) {
    if (!ok && warnOnly) warnings.push(name + ': ' + (detail || ''));
    if (!ok && !warnOnly) fatal++;
    checks.push({ name: name, ok: !!ok, detail: detail || '', warnOnly: !!warnOnly });
  }

  add('Code BUILD ERP_BENEFIT_GIFT_SETTLEMENT_READONLY_SAFE', true, ERP_BENEFIT_GIFT_BUILD_NO, false);
  add('erpBenefitGiftSettlementReadonlyData exists', typeof erpBenefitGiftSettlementReadonlyData === 'function', 'ERP read-only wrapper', false);
  add('SIGN handoff function available', typeof signGiftErpSettlementHandoffData === 'function', 'signGiftErpSettlementHandoffData({ eventId }) 직접 호출 가능 여부 - 미연결 시 시트 fallback 사용', true);
  add('ERP_FIELD nav info function exists', typeof erpB06J36_9_getFieldAppInfo === 'function', 'FIELD 이동 버튼 연결 함수', false);
  add('ERP_ADMIN nav info function exists', typeof erpB06J36_15_getAdminAppInfo === 'function' || typeof erpB06J36_14_getAdminAppInfo === 'function', 'ADMIN 이동 버튼 연결 함수', false);
  add('SIGN nav info function exists', typeof erpB06J36_16_getSignAppInfo === 'function', 'SIGN 이동 버튼 연결 함수', false);
  add('B05 worklist preserved', typeof fhB05GetWorklists === 'function', 'B05 목록 함수 보존', false);
  add('customer search preserved', typeof searchCustomers === 'function', '고객검색 함수 보존', false);
  add('saveSale preserved', typeof saveSale === 'function', '판매 저장 함수 보존', false);
  add('completeInstallation preserved', typeof completeInstallation === 'function', '설치완료 함수 보존', false);

  var master = erpBenefitGift_openMasterDbSafe_();
  add('FEELHAUS_DB_MASTER connect', master.ok, master.message, false);
  var requiredSheets = ['SIGN_Gift_Status_Summary', 'SIGN_Benefit_Gift_Links', 'SIGN_Gift_Stock', 'SIGN_Gift_Stock_Movements'];
  var sheetStatus = {};
  if (master.ok) {
    requiredSheets.forEach(function(name) {
      var sh = master.ss.getSheetByName(name);
      var ok = !!sh;
      sheetStatus[name] = ok ? sh.getLastRow() + ' rows' : 'missing';
      add('SIGN handoff sheet ' + name, ok, sheetStatus[name], false);
    });
  }

  var probe = { ok: true, data: { cards: {}, settlementCandidates: [] } };
  try {
    probe = erpBenefitGiftSettlementReadonlyData({ eventId: '' });
    add('read-only handoff data probe', !!(probe && probe.ok), (probe && probe.message) || '', false);
    add('read-only write policy enforced', !!(probe && probe.data && probe.data.readOnly === true), 'ERP direct edit false', false);
  } catch (err) {
    add('read-only handoff data probe', false, erpBenefitGift_err_(err), false);
  }

  var result = {
    ok: fatal === 0,
    fatal: fatal,
    warnings: warnings,
    label: 'ERP ' + ERP_BENEFIT_GIFT_BUILD_NO,
    build: ERP_BENEFIT_GIFT_BUILD_NAME,
    checkedAt: new Date().toISOString(),
    result: {
      checks: checks,
      requiredSheets: sheetStatus,
      probeCards: (probe && probe.data && probe.data.cards) ? probe.data.cards : {},
      settlementCandidatePreviewCount: (probe && probe.data && probe.data.settlementCandidates) ? probe.data.settlementCandidates.length : 0,
      readOnlyPolicy: 'SIGN 기프트/상품권 상태는 ERP에서 읽기 전용. 정산 계산은 ERP 중앙 정산 엔진에서만 처리.'
    },
    errorCode: fatal ? 'ERP_BENEFIT_GIFT_FULLCHECK_FAILED' : '',
    meta: { build: ERP_BENEFIT_GIFT_BUILD_NO, buildName: ERP_BENEFIT_GIFT_BUILD_NAME, generatedAt: new Date().toISOString() }
  };
  Logger.log('==============================');
  Logger.log("[ERP FULL CHECK] erpBenefitGiftSettlementReadonlySummary('" + ERP_BENEFIT_GIFT_BUILD_NAME + "')");
  Logger.log(JSON.stringify(result, null, 2));
  Logger.log('==============================');
  return result;
}

function erpBenefitGift_openMasterDbSafe_() {
  try {
    var cfg = (typeof erpB06J36_9_readSystemConfig_ === 'function') ? erpB06J36_9_readSystemConfig_() : erpBenefitGift_readSystemConfig_();
    if (!cfg || cfg.ok === false) return { ok: false, message: (cfg && cfg.message) || 'SystemConfig 읽기 실패' };
    var map = cfg.map || {};
    var keys = ['FEELHAUS_DB_MASTER_ID', 'FEELHAUS_DB_MASTER', 'MASTER_DB_ID', 'DB_MASTER_ID', 'ERP_DB_ID', 'FEELHAUS_MASTER_DB_ID'];
    var id = '';
    for (var i = 0; i < keys.length; i++) {
      if (map[keys[i]]) { id = erpBenefitGift_extractId_(map[keys[i]]); break; }
    }
    if (!id) return { ok: false, message: 'FEELHAUS_DB_MASTER ID 설정을 찾지 못했습니다.' };
    return { ok: true, message: 'FEELHAUS_DB_MASTER 연결 정상', ss: SpreadsheetApp.openById(id), id: id };
  } catch (err) {
    return { ok: false, message: 'FEELHAUS_DB_MASTER 연결 실패: ' + erpBenefitGift_err_(err) };
  }
}

function erpBenefitGift_readSystemConfig_() {
  var setupId = '17VMSpgSZCvIrUlgcw8yCNcnl8WQWo2IcRf5tDCcuJGM';
  var sh = SpreadsheetApp.openById(setupId).getSheetByName('SystemConfig');
  if (!sh) return { ok: false, message: 'SystemConfig 시트를 찾을 수 없습니다.', map: {} };
  var values = sh.getDataRange().getValues();
  if (!values.length) return { ok: false, message: 'SystemConfig가 비어 있습니다.', map: {} };
  var headers = values[0].map(erpBenefitGift_s_);
  var keyIdx = erpBenefitGift_findHeader_(headers, ['configKey', 'key', 'name', 'settingKey', '항목', '키']);
  var valIdx = erpBenefitGift_findHeader_(headers, ['configValue', 'value', 'settingValue', '값']);
  if (keyIdx < 0) keyIdx = 0;
  if (valIdx < 0) valIdx = 1;
  var map = {};
  for (var r = 1; r < values.length; r++) {
    var k = erpBenefitGift_s_(values[r][keyIdx]);
    if (k) map[k] = values[r][valIdx];
  }
  return { ok: true, message: 'SystemConfig 자동 읽기 정상', map: map };
}

function erpBenefitGift_readRowsByEvent_(ss, sheetName, eventId, limit) {
  var sh = ss.getSheetByName(sheetName);
  if (!sh) return { ok: false, sheetName: sheetName, message: '시트 없음', rows: [], count: 0 };
  var table = erpBenefitGift_readTable_(sh);
  var rows = [];
  for (var i = 0; i < table.rows.length && rows.length < (limit || 500); i++) {
    var row = table.rows[i];
    var rowEventId = erpBenefitGift_s_(row.eventId || row.fieldEventId || row.eventID || '');
    if (eventId && rowEventId && rowEventId !== eventId) continue;
    if (eventId && !rowEventId) continue;
    row._sourceSheet = sheetName;
    row._rowNumber = i + 2;
    rows.push(row);
  }
  return { ok: true, sheetName: sheetName, headers: table.headers, rows: rows, count: rows.length, totalRows: table.rows.length };
}

function erpBenefitGift_readTable_(sh) {
  var values = sh.getDataRange().getValues();
  if (!values.length) return { headers: [], rows: [] };
  var headers = values[0].map(erpBenefitGift_s_);
  var rows = [];
  for (var r = 1; r < values.length; r++) {
    var obj = {};
    for (var c = 0; c < headers.length; c++) {
      if (headers[c]) obj[headers[c]] = values[r][c];
    }
    rows.push(obj);
  }
  return { headers: headers, rows: rows };
}

function erpBenefitGift_findHeader_(headers, aliases) {
  var lower = headers.map(function(h) { return erpBenefitGift_s_(h).toLowerCase(); });
  for (var i = 0; i < aliases.length; i++) {
    var idx = lower.indexOf(erpBenefitGift_s_(aliases[i]).toLowerCase());
    if (idx >= 0) return idx;
  }
  return -1;
}
function erpBenefitGift_response_(ok, message, data, errorCode) {
  return { ok: !!ok, message: message || '', data: data || {}, errorCode: errorCode || '', meta: { build: ERP_BENEFIT_GIFT_BUILD_NO, buildName: ERP_BENEFIT_GIFT_BUILD_NAME, generatedAt: new Date().toISOString() } };
}
function erpBenefitGift_s_(v) { return v === null || v === undefined ? '' : String(v).trim(); }
function erpBenefitGift_n_(v) { var n = Number(String(v === null || v === undefined ? 0 : v).replace(/,/g, '')); return isNaN(n) ? 0 : n; }
function erpBenefitGift_err_(err) { return err && err.stack ? String(err.stack) : String(err); }
function erpBenefitGift_extractId_(v) { var s = erpBenefitGift_s_(v); var m = s.match(/[-\w]{25,}/); return m ? m[0] : s; }

function getBuildInfo() {
  return {
    ok: true,
    buildNo: ERP_BENEFIT_GIFT_BUILD_NO,
    buildName: ERP_BENEFIT_GIFT_BUILD_NAME,
    buildTitle: ERP_BENEFIT_GIFT_TITLE,
    message: ERP_BENEFIT_GIFT_TITLE,
    data: {
      build: ERP_BENEFIT_GIFT_BUILD_NO,
      buildName: ERP_BENEFIT_GIFT_BUILD_NAME,
      title: ERP_BENEFIT_GIFT_TITLE,
      roleSplitPolicy: 'ERP 본체는 판매/설치/B05 중심, FIELD/ADMIN/SIGN은 전용 앱으로 분리, SIGN 기프트/상품권 정산 인계는 ERP 읽기 전용 표시'
    },
    errorCode: '',
    meta: { build: ERP_BENEFIT_GIFT_BUILD_NO, buildName: ERP_BENEFIT_GIFT_BUILD_NAME, generatedAt: new Date().toISOString() }
  };
}


/**
 * FEELHAUS ERP BENEFIT/GIFT SETTLEMENT READONLY STATUS MAP
 * Build: ERP_BENEFIT_GIFT_SETTLEMENT_STATUS_MAP_READONLY_SAFE / v64-B06J36-18
 * Purpose: SIGN 기프트/상품권 상태값(GIFT_ISSUED 등)을 ERP 읽기전용 정산 후보로 표준 매핑한다.
 * Policy: SIGN 원본 시트 직접 수정 금지, ERP 중앙 정산 엔진 계산 전 후보 표시만 수행.
 */
ERP_BENEFIT_GIFT_BUILD_NO = 'v64-B06J36-18';
ERP_BENEFIT_GIFT_BUILD_NAME = 'ERP_BENEFIT_GIFT_SETTLEMENT_STATUS_MAP_READONLY_SAFE';
ERP_BENEFIT_GIFT_TITLE = 'ERP v64-B06J36-18 SIGN 기프트/상품권 상태매핑 읽기전용 인계';

function erpBenefitGift_normalizeStatus_(raw) {
  var src = erpBenefitGift_s_(raw).toUpperCase();
  if (!src) return { raw: '', normalized: 'UNKNOWN', label: '미확인', bucket: 'unknown', settlementCandidate: false };
  var issued = ['GIFT_ISSUED', 'ISSUED', 'BENEFIT_ISSUED', 'COUPON_ISSUED', '상품권발급', '발급완료', '지급완료'];
  var paid = ['PAID', 'GIFT_PAID', 'COMPLETED', 'PAYOUT_COMPLETED', 'PAYMENT_COMPLETED'];
  var pending = ['GIFT_PENDING', 'PENDING', 'READY', 'WAITING', '대기', '지급대기', '발급대기'];
  var hold = ['GIFT_HOLD', 'HOLD', 'ON_HOLD', '보류', '지급보류'];
  var rewait = ['GIFT_REWAIT', 'REWAIT', 'RE_WAIT', '재대기'];
  if (issued.indexOf(src) >= 0) return { raw: src, normalized: 'GIFT_ISSUED', label: '발급완료', bucket: 'issued', settlementCandidate: true };
  if (paid.indexOf(src) >= 0) return { raw: src, normalized: 'GIFT_PAID', label: '지급완료', bucket: 'paid', settlementCandidate: true };
  if (pending.indexOf(src) >= 0) return { raw: src, normalized: 'GIFT_PENDING', label: '대기', bucket: 'pending', settlementCandidate: false };
  if (hold.indexOf(src) >= 0) return { raw: src, normalized: 'GIFT_HOLD', label: '보류', bucket: 'hold', settlementCandidate: false };
  if (rewait.indexOf(src) >= 0) return { raw: src, normalized: 'GIFT_REWAIT', label: '재대기', bucket: 'rewait', settlementCandidate: false };
  return { raw: src, normalized: src, label: src, bucket: 'other', settlementCandidate: false };
}

function erpBenefitGift_isSettlementReady_(row) {
  var settlementStatus = erpBenefitGift_s_(row.settlementStatus || row.erpSettlementStatus || row.settlementReady || row.accountingStatus).toUpperCase();
  return settlementStatus === '' || settlementStatus === 'READY' || settlementStatus === 'PENDING' || settlementStatus === 'Y' || settlementStatus === 'TRUE';
}

function erpBenefitGiftSettlementReadonlyData(payload) {
  payload = payload || {};
  var eventId = erpBenefitGift_s_(payload.eventId || payload.fieldEventId || '');
  var result = {
    build: ERP_BENEFIT_GIFT_BUILD_NO,
    buildName: ERP_BENEFIT_GIFT_BUILD_NAME,
    title: ERP_BENEFIT_GIFT_TITLE,
    eventId: eventId,
    readOnly: true,
    sourceBuild: 'SIGN_B06J90_GIFT_ERP_SETTLEMENT_HANDOFF_SAFE',
    sourceFunction: 'signGiftErpSettlementHandoffData',
    sourceSheets: ['SIGN_Gift_Status_Summary','SIGN_Benefit_Gift_Links','SIGN_Gift_Stock','SIGN_Gift_Stock_Movements'],
    statusMapPolicy: {
      GIFT_ISSUED: '발급완료로 표시하고 ERP 중앙 정산 엔진의 후보로만 전달',
      GIFT_HOLD: '보류로 표시, 정산 후보 제외',
      GIFT_PENDING: '대기로 표시, 정산 후보 제외',
      GIFT_REWAIT: '재대기로 표시, 정산 후보 제외',
      ACTIVE: '재고/링크 활성 상태로 표시, 정산 후보 제외'
    },
    writePolicy: {
      erpDirectEdit: false,
      forbidden: ['SIGN_Gift_Status_Summary 직접 수정 금지','SIGN_Benefit_Gift_Links 상태 직접 변경 금지','지급완료/보류/재대기 직접 처리 금지','재고 입출고 직접 수정 금지'],
      settlementCalculation: 'SIGN은 계산하지 않고 ERP 중앙 정산 엔진에서 처리'
    },
    handoffFunctionAvailable: false,
    handoffFunctionResult: null,
    sheets: {},
    cards: {},
    settlementCandidates: [],
    warnings: []
  };
  if (typeof signGiftErpSettlementHandoffData === 'function') {
    result.handoffFunctionAvailable = true;
    try { result.handoffFunctionResult = signGiftErpSettlementHandoffData({ eventId: eventId }); }
    catch (handoffErr) { result.warnings.push('SIGN handoff function call failed: ' + erpBenefitGift_err_(handoffErr)); }
  }
  var master = erpBenefitGift_openMasterDbSafe_();
  if (!master.ok) return erpBenefitGift_response_(false, master.message, result, 'MASTER_NOT_CONNECTED');

  result.sheets.statusSummary = erpBenefitGift_readRowsByEvent_(master.ss, 'SIGN_Gift_Status_Summary', eventId, 200);
  result.sheets.benefitLinks = erpBenefitGift_readRowsByEvent_(master.ss, 'SIGN_Benefit_Gift_Links', eventId, 500);
  result.sheets.stock = erpBenefitGift_readRowsByEvent_(master.ss, 'SIGN_Gift_Stock', eventId, 500);
  result.sheets.stockMovements = erpBenefitGift_readRowsByEvent_(master.ss, 'SIGN_Gift_Stock_Movements', eventId, 500);

  var links = result.sheets.benefitLinks.rows || [];
  var statusRows = result.sheets.statusSummary.rows || [];
  var movements = result.sheets.stockMovements.rows || [];
  var stockRows = result.sheets.stock.rows || [];
  var issued = 0, paid = 0, pending = 0, hold = 0, rewait = 0, active = 0, other = 0, settlementReady = 0;
  var statusCounts = {}, normalizedStatusCounts = {};

  links.forEach(function(row) {
    var rawStatus = erpBenefitGift_s_(row.status || row.giftStatus || row.payoutStatus || row.linkStatus || row.issueStatus);
    var map = erpBenefitGift_normalizeStatus_(rawStatus);
    statusCounts[map.raw || 'UNKNOWN'] = (statusCounts[map.raw || 'UNKNOWN'] || 0) + 1;
    normalizedStatusCounts[map.normalized] = (normalizedStatusCounts[map.normalized] || 0) + 1;
    if (map.bucket === 'issued') issued++;
    else if (map.bucket === 'paid') paid++;
    else if (map.bucket === 'pending') pending++;
    else if (map.bucket === 'hold') hold++;
    else if (map.bucket === 'rewait') rewait++;
    else if (map.normalized === 'ACTIVE') active++;
    else other++;

    var isCandidate = erpBenefitGift_isSettlementReady_(row) && map.settlementCandidate;
    var amount = erpBenefitGift_n_(row.amount || row.giftAmount || row.benefitAmount || row.settlementAmount || row.price || row.totalAmount);
    if (isCandidate) {
      settlementReady++;
      result.settlementCandidates.push({
        eventId: erpBenefitGift_s_(row.eventId || eventId),
        benefitId: erpBenefitGift_s_(row.benefitId || row.id || row.linkId),
        customerId: erpBenefitGift_s_(row.customerId || row.memberId),
        vendorId: erpBenefitGift_s_(row.vendorId),
        giftId: erpBenefitGift_s_(row.giftId || row.itemId || row.stockId),
        rawStatus: map.raw,
        status: map.normalized,
        statusLabel: map.label,
        amount: amount,
        settlementStatus: erpBenefitGift_s_(row.settlementStatus || row.erpSettlementStatus || ''),
        sourceSheet: 'SIGN_Benefit_Gift_Links',
        readOnly: true,
        calculationPolicy: 'ERP 중앙 정산 엔진 계산 대상 후보'
      });
    }
  });

  result.cards = {
    linkCount: links.length,
    statusSummaryCount: statusRows.length,
    stockCount: stockRows.length,
    stockMovementCount: movements.length,
    issuedCount: issued,
    paidCount: paid,
    pendingCount: pending,
    holdCount: hold,
    rewaitCount: rewait,
    activeCount: active,
    otherCount: other,
    settlementCandidateCount: settlementReady,
    statusCounts: statusCounts,
    normalizedStatusCounts: normalizedStatusCounts
  };
  return erpBenefitGift_response_(true, 'SIGN 기프트/상품권 상태매핑 읽기전용 인계 데이터 조회 완료', result, '');
}

function erpBenefitGiftSettlementStatusMap_fullCheck_20260502_log() {
  var checks = [];
  var fatal = 0;
  var warnings = [];
  function add(name, ok, detail, warnOnly) {
    if (!ok && warnOnly) warnings.push(name + ': ' + (detail || ''));
    if (!ok && !warnOnly) fatal++;
    checks.push({ name: name, ok: !!ok, detail: detail || '', warnOnly: !!warnOnly });
  }
  add('Code BUILD B06J36-18', ERP_BENEFIT_GIFT_BUILD_NO === 'v64-B06J36-18', ERP_BENEFIT_GIFT_BUILD_NO, false);
  add('erpBenefitGiftSettlementReadonlyData exists', typeof erpBenefitGiftSettlementReadonlyData === 'function', 'ERP read-only wrapper with status map', false);
  add('status normalizer exists', typeof erpBenefitGift_normalizeStatus_ === 'function', 'GIFT_ISSUED/GIFT_HOLD/GIFT_PENDING mapping', false);
  add('ERP_FIELD nav info function exists', typeof erpB06J36_9_getFieldAppInfo === 'function', 'FIELD 이동 버튼 연결 함수', false);
  add('ERP_ADMIN nav info function exists', typeof erpB06J36_15_getAdminAppInfo === 'function' || typeof erpB06J36_14_getAdminAppInfo === 'function', 'ADMIN 이동 버튼 연결 함수', false);
  add('SIGN nav info function exists', typeof erpB06J36_16_getSignAppInfo === 'function', 'SIGN 이동 버튼 연결 함수', false);
  add('B05 worklist preserved', typeof fhB05GetWorklists === 'function', 'B05 목록 함수 보존', false);
  add('customer search preserved', typeof searchCustomers === 'function', '고객검색 함수 보존', false);
  add('saveSale preserved', typeof saveSale === 'function', '판매 저장 함수 보존', false);
  add('completeInstallation preserved', typeof completeInstallation === 'function', '설치완료 함수 보존', false);

  var master = erpBenefitGift_openMasterDbSafe_();
  add('FEELHAUS_DB_MASTER connect', master.ok, master.message, false);
  var requiredSheets = ['SIGN_Gift_Status_Summary','SIGN_Benefit_Gift_Links','SIGN_Gift_Stock','SIGN_Gift_Stock_Movements'];
  var sheetStatus = {};
  if (master.ok) {
    requiredSheets.forEach(function(name) {
      var sh = master.ss.getSheetByName(name);
      var ok = !!sh;
      sheetStatus[name] = ok ? sh.getLastRow() + ' rows' : 'missing';
      add('SIGN handoff sheet ' + name, ok, sheetStatus[name], false);
    });
  }
  var probe = { ok: true, data: { cards: {}, settlementCandidates: [] } };
  try {
    probe = erpBenefitGiftSettlementReadonlyData({ eventId: '' });
    add('read-only handoff data probe', !!(probe && probe.ok), (probe && probe.message) || '', false);
    add('read-only write policy enforced', !!(probe && probe.data && probe.data.readOnly === true), 'ERP direct edit false', false);
    var cards = (probe && probe.data && probe.data.cards) ? probe.data.cards : {};
    var issuedCount = Number(cards.issuedCount || 0);
    var candidateCount = Number(cards.settlementCandidateCount || 0);
    add('GIFT_ISSUED status mapped', issuedCount >= 0, 'issuedCount=' + issuedCount, false);
    add('settlement candidate mapping probe', candidateCount >= 0, 'settlementCandidateCount=' + candidateCount, false);
  } catch (err) {
    add('read-only handoff data probe', false, erpBenefitGift_err_(err), false);
  }
  var result = {
    ok: fatal === 0,
    fatal: fatal,
    warnings: warnings,
    label: 'ERP ' + ERP_BENEFIT_GIFT_BUILD_NO,
    build: ERP_BENEFIT_GIFT_BUILD_NAME,
    checkedAt: new Date().toISOString(),
    result: {
      checks: checks,
      requiredSheets: sheetStatus,
      probeCards: (probe && probe.data && probe.data.cards) ? probe.data.cards : {},
      settlementCandidatePreviewCount: (probe && probe.data && probe.data.settlementCandidates) ? probe.data.settlementCandidates.length : 0,
      readOnlyPolicy: 'SIGN 기프트/상품권 상태는 ERP에서 읽기 전용. GIFT_ISSUED는 후보 표시만 하며 정산 계산은 ERP 중앙 정산 엔진에서 처리.'
    },
    errorCode: fatal ? 'ERP_BENEFIT_GIFT_STATUS_MAP_FULLCHECK_FAILED' : '',
    meta: { build: ERP_BENEFIT_GIFT_BUILD_NO, buildName: ERP_BENEFIT_GIFT_BUILD_NAME, generatedAt: new Date().toISOString() }
  };
  Logger.log('==============================');
  Logger.log("[ERP FULL CHECK] erpBenefitGiftSettlementStatusMapSummary('" + ERP_BENEFIT_GIFT_BUILD_NAME + "')");
  Logger.log(JSON.stringify(result, null, 2));
  Logger.log('==============================');
  return result;
}

function getBuildInfo() {
  return {
    ok: true,
    buildNo: ERP_BENEFIT_GIFT_BUILD_NO,
    buildName: ERP_BENEFIT_GIFT_BUILD_NAME,
    buildTitle: ERP_BENEFIT_GIFT_TITLE,
    message: ERP_BENEFIT_GIFT_TITLE,
    data: { build: ERP_BENEFIT_GIFT_BUILD_NO, buildName: ERP_BENEFIT_GIFT_BUILD_NAME, title: ERP_BENEFIT_GIFT_TITLE },
    errorCode: '',
    meta: { build: ERP_BENEFIT_GIFT_BUILD_NO, buildName: ERP_BENEFIT_GIFT_BUILD_NAME, generatedAt: new Date().toISOString() }
  };
}
