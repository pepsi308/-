@echo off
cd /d D:\pepsi308\OneDrive\feelhaus_pull\ERP
clasp.cmd push --force
pause
