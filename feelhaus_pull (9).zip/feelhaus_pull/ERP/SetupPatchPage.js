/**
 * FEELHAUS ERP - FEELHAUS_SETUP_DB 자동 스크립트속성 점검패치
 *
 * 적용 원칙
 * - 기존 ERP 화면(Index.html) 절대 교체 금지
 * - 기존 Code.gs / doGet() / 메뉴 로직 유지
 * - 이 파일은 기존 ERP 프로젝트에 '추가 파일'로만 넣는다
 * - 중복 선언 방지를 위해 이 파일 내부에서만 사용하는 고유 접두사 FHSP_ 사용
 */

var FHSP_CONFIG = {
  SHEET_NAME: 'FEELHAUS_SETUP_DB',
  LOG_SHEET_NAME: 'FEELHAUS_SETUP_LOG',
  HEADER_ROW: 1,
  DATA_START_ROW: 2,
  REQUIRED_KEYS: [
    'SPREADSHEET_ID',
    'DB_SPREADSHEET_ID',
    'ROOT_FOLDER_ID'
  ],
  OPTIONAL_KEYS: [
    'SIGN_SPREADSHEET_ID',
    'ROOT_FOLDER_URL',
    'SIGN_FOLDER_ID',
    'PDF_FOLDER_ID',
    'BACKUP_FOLDER_ID',
    'ERP_WEBAPP_URL',
    'PORTAL_WEBAPP_URL',
    'SIGN_WEBAPP_URL'
  ]
};

function ensureFeelhausSetupDbSheet() {
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  if (!ss) throw new Error('활성 스프레드시트를 찾을 수 없습니다. ERP 연결 스프레드시트에서 실행하거나 바인딩 프로젝트인지 확인하세요.');

  var sh = ss.getSheetByName(FHSP_CONFIG.SHEET_NAME);
  if (!sh) sh = ss.insertSheet(FHSP_CONFIG.SHEET_NAME);

  if (sh.getLastRow() === 0) {
    sh.getRange(1, 1, 1, 4).setValues([['KEY', 'VALUE', 'USE_YN', 'MEMO']]);
    sh.getRange(2, 1, 3, 4).setValues([
      ['SPREADSHEET_ID', ss.getId(), 'Y', '현재 ERP 스프레드시트 ID'],
      ['DB_SPREADSHEET_ID', ss.getId(), 'Y', 'ERP DB 스프레드시트 ID'],
      ['ROOT_FOLDER_ID', '', 'N', '공통 루트 폴더 ID']
    ]);
  }

  var logSh = ss.getSheetByName(FHSP_CONFIG.LOG_SHEET_NAME);
  if (!logSh) {
    logSh = ss.insertSheet(FHSP_CONFIG.LOG_SHEET_NAME);
    logSh.getRange(1, 1, 1, 6).setValues([['AT', 'ACTION', 'STATUS', 'MESSAGE', 'COUNT', 'USER']]);
  }

  FHSP_log_('ensureFeelhausSetupDbSheet', 'OK', '설정 시트/로그 시트 점검 완료', 0);
  return { ok: true, message: 'FEELHAUS_SETUP_DB / LOG 시트 점검 완료' };
}

function syncScriptPropertiesFromSetupDb() {
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  if (!ss) throw new Error('활성 스프레드시트를 찾을 수 없습니다.');
  var sh = ss.getSheetByName(FHSP_CONFIG.SHEET_NAME);
  if (!sh) throw new Error('FEELHAUS_SETUP_DB 시트가 없습니다. ensureFeelhausSetupDbSheet() 먼저 실행하세요.');

  var lastRow = sh.getLastRow();
  if (lastRow < FHSP_CONFIG.DATA_START_ROW) throw new Error('FEELHAUS_SETUP_DB 데이터가 없습니다.');

  var values = sh.getRange(FHSP_CONFIG.DATA_START_ROW, 1, lastRow - 1, 4).getValues();
  var props = PropertiesService.getScriptProperties();
  var applied = 0;
  var skipped = 0;
  var emptyKeys = [];

  values.forEach(function(row) {
    var key = String(row[0] || '').trim();
    var value = String(row[1] || '').trim();
    var useYn = String(row[2] || '').trim().toUpperCase();

    if (!key) {
      skipped++;
      return;
    }
    if (useYn !== 'Y') {
      skipped++;
      return;
    }
    if (!value) {
      emptyKeys.push(key);
      skipped++;
      return;
    }

    props.setProperty(key, value);
    applied++;
  });

  var message = '적용 ' + applied + '건, 건너뜀 ' + skipped + '건';
  if (emptyKeys.length) message += ', 값 누락: ' + emptyKeys.join(', ');
  FHSP_log_('syncScriptPropertiesFromSetupDb', emptyKeys.length ? 'WARN' : 'OK', message, applied);

  return {
    ok: emptyKeys.length === 0,
    appliedCount: applied,
    skippedCount: skipped,
    emptyKeys: emptyKeys,
    message: message
  };
}

function runFeelhausSetupInspection() {
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  if (!ss) throw new Error('활성 스프레드시트를 찾을 수 없습니다.');
  var sh = ss.getSheetByName(FHSP_CONFIG.SHEET_NAME);
  if (!sh) throw new Error('FEELHAUS_SETUP_DB 시트가 없습니다.');

  var lastRow = sh.getLastRow();
  var rows = lastRow >= 2 ? sh.getRange(2, 1, lastRow - 1, 4).getValues() : [];
  var map = {};
  rows.forEach(function(r) {
    var key = String(r[0] || '').trim();
    var value = String(r[1] || '').trim();
    var useYn = String(r[2] || '').trim().toUpperCase();
    if (key && useYn === 'Y') map[key] = value;
  });

  var missingRequired = FHSP_CONFIG.REQUIRED_KEYS.filter(function(k) {
    return !map[k];
  });
  var enabledOptional = FHSP_CONFIG.OPTIONAL_KEYS.filter(function(k) {
    return !!map[k];
  });

  var report = {
    ok: missingRequired.length === 0,
    spreadsheetId: ss.getId(),
    requiredKeys: FHSP_CONFIG.REQUIRED_KEYS,
    missingRequiredKeys: missingRequired,
    enabledOptionalKeys: enabledOptional,
    activeEnabledKeys: Object.keys(map),
    message: missingRequired.length ? '필수 키 누락: ' + missingRequired.join(', ') : '필수 키 점검 완료'
  };

  FHSP_log_('runFeelhausSetupInspection', report.ok ? 'OK' : 'WARN', report.message, report.activeEnabledKeys.length);
  return report;
}

function autoSetupErpSystemWithSetupDbPatch() {
  ensureFeelhausSetupDbSheet();
  var inspection = runFeelhausSetupInspection();
  var sync = syncScriptPropertiesFromSetupDb();
  return {
    ok: inspection.ok && sync.ok,
    inspection: inspection,
    sync: sync,
    message: '점검패치 실행 완료'
  };
}

function FHSP_log_(action, status, message, count) {
  try {
    var ss = SpreadsheetApp.getActiveSpreadsheet();
    if (!ss) return;
    var sh = ss.getSheetByName(FHSP_CONFIG.LOG_SHEET_NAME);
    if (!sh) {
      sh = ss.insertSheet(FHSP_CONFIG.LOG_SHEET_NAME);
      sh.getRange(1, 1, 1, 6).setValues([['AT', 'ACTION', 'STATUS', 'MESSAGE', 'COUNT', 'USER']]);
    }
    sh.appendRow([
      new Date(),
      action,
      status,
      message,
      count || 0,
      Session.getActiveUser().getEmail() || ''
    ]);
  } catch (e) {}
}

function openSetupPatchLegacyPage() {
  return HtmlService.createHtmlOutputFromFile('SetupPatchView')
    .setTitle('FEELHAUS ERP 점검패치');
}
