/**
 * FEELHAUS ERP index_scripts server-safe build marker
 * Build: ERP_BENEFIT_GIFT_SETTLEMENT_READONLY_SAFE / v64-B06J36-18
 * Reason: SIGN 기프트/상품권 정산 읽기전용 인계; server runtime safe.
 */
var FEELHAUS_INDEX_SCRIPTS_BUILD = {
  buildNo: 'v64-B06J36-18',
  buildName: 'ERP_BENEFIT_GIFT_SETTLEMENT_READONLY_SAFE',
  buildTitle: 'ERP v64-B06J36-18 SIGN 기프트/상품권 정산 읽기전용 인계'
};

function getFeelhausIndexScriptsBuild_() {
  return FEELHAUS_INDEX_SCRIPTS_BUILD;
}
