/**
 * ERP_B06J36_41A_EVENT_SCRIPT_SERVER_SAFE_STUB
 *
 * This file is intentionally kept as a server-safe stub.
 * Previous builds included browser-only code here. Apps Script uploads .js files
 * as server-side .gs files, so top-level calls that used document/google.script.run
 * caused: ReferenceError: document is not defined.
 *
 * The actual EventVendor browser script is inline inside EventVendor.html.
 * Do not add document/window/google.script.run code to this .js file.
 */
function erpB06J36_41A_eventScriptServerSafeCheck() {
  return {
    ok: true,
    build: 'ERP_B06J36_41A_EVENT_SCRIPT_SERVER_SAFE_STUB',
    message: 'event_script.js is server-safe stub. Browser UI code remains in EventVendor.html.',
    noDocumentAccess: (typeof document === 'undefined'),
    checkedAt: new Date()
  };
}
