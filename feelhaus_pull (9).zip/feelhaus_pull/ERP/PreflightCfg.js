/**
 * FEELHAUS ERP - Preflight + SystemConfig Patch v1
 * 기존 기능 교체 금지 / 추가 파일 전용
 */

var FHERP_CORE = {
  SETUP_DB_ID: '17VMSpgSZCvIrUlgcw8yCNcnl8WQWo2IcRf5tDCcuJGM',
  CONFIG_SHEET_NAME: 'SystemConfig',
  REQUIRED_CONFIG_KEYS: ['DB_MASTER_ID', 'ERP_WEBAPP_URL'],
  OPTIONAL_CONFIG_KEYS: ['PORTAL_WEBAPP_URL', 'SIGN_WEBAPP_URL', 'ROOT_FOLDER_ID', 'BACKUP_FOLDER_ID'],
  REQUIRED_MASTER_SHEETS: ['Customers', 'Sales'],
  REQUIRED_LOCAL_SHEETS: ['ERP_행사관리', 'ERP_업체관리', 'ERP_행사업체연결', 'ERP_행사업체로그']
};

function FHERP_now_() {
  return Utilities.formatDate(new Date(), Session.getScriptTimeZone() || 'Asia/Seoul', 'yyyy-MM-dd HH:mm:ss');
}
function FHERP_s_(v) { return String(v === null || v === undefined ? '' : v).trim(); }
function FHERP_safeGetActiveSpreadsheet_() { try { return SpreadsheetApp.getActiveSpreadsheet(); } catch (e) { return null; } }
function FHERP_getSetupDb_() { return SpreadsheetApp.openById(FHERP_CORE.SETUP_DB_ID); }
function FHERP_getSystemConfigSheet_() {
  var ss = FHERP_getSetupDb_();
  var sh = ss.getSheetByName(FHERP_CORE.CONFIG_SHEET_NAME);
  if (!sh) throw new Error('SystemConfig 시트를 찾지 못했습니다.');
  return sh;
}
function FHERP_getSystemConfigMap() {
  var sh = FHERP_getSystemConfigSheet_();
  var values = sh.getDataRange().getDisplayValues();
  if (!values || values.length < 2) return {};
  var headers = values[0].map(FHERP_s_);
  var keyIdx = headers.indexOf('key') > -1 ? headers.indexOf('key') : (headers.indexOf('KEY') > -1 ? headers.indexOf('KEY') : headers.indexOf('configKey'));
  var valueIdx = headers.indexOf('value') > -1 ? headers.indexOf('value') : (headers.indexOf('VALUE') > -1 ? headers.indexOf('VALUE') : headers.indexOf('configValue'));
  var useIdx = headers.indexOf('useYn') > -1 ? headers.indexOf('useYn') : headers.indexOf('USE_YN');
  if (keyIdx === -1 || valueIdx === -1) throw new Error('SystemConfig 헤더에 key/value 또는 KEY/VALUE 컬럼이 필요합니다.');
  var map = {};
  values.slice(1).forEach(function(r) {
    var key = FHERP_s_(r[keyIdx]);
    var value = FHERP_s_(r[valueIdx]);
    var useYn = useIdx > -1 ? FHERP_s_(r[useIdx]).toUpperCase() : 'Y';
    if (!key || useYn === 'N') return;
    map[key] = value;
  });
  return map;
}
function FHERP_getConfigValue_(key, defaultValue) {
  var map = FHERP_getSystemConfigMap();
  var val = FHERP_s_(map[key]);
  return val || FHERP_s_(defaultValue);
}
function getDbSpreadsheet() {
  var masterId = FHERP_getConfigValue_('DB_MASTER_ID', '');
  if (!masterId) throw new Error('SystemConfig > DB_MASTER_ID가 비어 있습니다.');
  return SpreadsheetApp.openById(masterId);
}
function readTable(sheetName) {
  var ss = getDbSpreadsheet();
  var sh = ss.getSheetByName(sheetName);
  if (!sh) return [];
  var values = sh.getDataRange().getDisplayValues();
  if (!values || values.length < 2) return [];
  var headers = values[0].map(FHERP_s_);
  return values.slice(1).filter(function(r){ return r.join('').trim() !== ''; }).map(function(r){
    var o = {};
    headers.forEach(function(h, i){ o[h] = r[i]; });
    return o;
  });
}
function FHERP_ensureSheet_(ss, name, headers) {
  var sh = ss.getSheetByName(name);
  if (!sh) sh = ss.insertSheet(name);
  if (sh.getLastRow() === 0) {
    sh.getRange(1, 1, 1, headers.length).setValues([headers]);
    return sh;
  }
  var currentHeaders = sh.getRange(1, 1, 1, Math.max(sh.getLastColumn(), headers.length)).getDisplayValues()[0].map(FHERP_s_);
  headers.forEach(function(h) {
    if (currentHeaders.indexOf(h) === -1) {
      sh.getRange(1, currentHeaders.length + 1).setValue(h);
      currentHeaders.push(h);
    }
  });
  return sh;
}
function FHERP_ensureEventVendorLocalSheets() {
  var ss = FHERP_safeGetActiveSpreadsheet_();
  if (!ss) throw new Error('활성 ERP 스프레드시트를 찾지 못했습니다.');
  FHERP_ensureSheet_(ss, 'ERP_행사관리', ['eventId','eventName','eventType','startDate','endDate','eventPlace','manager','status','memo','createdAt','updatedAt','updatedBy','baseEventId','eventUid']);
  FHERP_ensureSheet_(ss, 'ERP_업체관리', ['vendorId','vendorName','ownerName','phone','region','manager','status','memo','createdAt','updatedAt','updatedBy','baseVendorId','vendorUid']);
  FHERP_ensureSheet_(ss, 'ERP_행사업체연결', ['linkId','eventId','eventName','vendorId','vendorName','status','approvalStatus','statusReason','rejectReason','memo','approvedBy','approvedAt','createdAt','updatedAt','updatedBy']);
  FHERP_ensureSheet_(ss, 'ERP_행사업체로그', ['logId','actionType','targetKey','targetName','message','createdAt','createdBy','beforeValue','afterValue','reason','relatedDocumentNo']);
  return { ok: true, message: 'EventVendor 로컬 시트 영문 헤더 점검 완료' };
}
function FHERP_appendAuditLog_(action, status, message, meta) {
  try {
    var ss = FHERP_safeGetActiveSpreadsheet_();
    if (!ss) return;
    var sh = ss.getSheetByName('ERP_행사업체로그');
    if (!sh) return;
    sh.appendRow([
      'LOG-' + new Date().getTime(),
      action,
      status,
      '',
      message + (meta ? ' / ' + JSON.stringify(meta) : ''),
      FHERP_now_(),
      (function(){ try { return Session.getActiveUser().getEmail() || ''; } catch(e){ return ''; } })()
    ]);
  } catch (e) {}
}
function runErpPreflightAudit() {
  var result = { ok: true, checkedAt: FHERP_now_(), config: {}, master: {}, local: {}, errors: [], warnings: [] };
  try {
    var configMap = FHERP_getSystemConfigMap();
    FHERP_CORE.REQUIRED_CONFIG_KEYS.forEach(function(k){ if (!FHERP_s_(configMap[k])) result.errors.push('필수 설정 누락: ' + k); });
    FHERP_CORE.OPTIONAL_CONFIG_KEYS.forEach(function(k){ if (!FHERP_s_(configMap[k])) result.warnings.push('선택 설정 누락: ' + k); });
    result.config.enabledKeys = Object.keys(configMap).length;
  } catch (e) {
    result.errors.push('SystemConfig 읽기 실패: ' + e.message);
  }
  try {
    var masterSs = getDbSpreadsheet();
    var missingMaster = FHERP_CORE.REQUIRED_MASTER_SHEETS.filter(function(name){ return !masterSs.getSheetByName(name); });
    result.master.missingSheets = missingMaster;
    if (missingMaster.length) result.errors.push('마스터 필수 시트 누락: ' + missingMaster.join(', '));
  } catch (e2) {
    result.errors.push('DB_MASTER 연결 실패: ' + e2.message);
  }
  try {
    var localSs = FHERP_safeGetActiveSpreadsheet_();
    if (!localSs) throw new Error('활성 ERP 스프레드시트 없음');
    var missingLocal = FHERP_CORE.REQUIRED_LOCAL_SHEETS.filter(function(name){ return !localSs.getSheetByName(name); });
    result.local.missingSheets = missingLocal;
    if (missingLocal.length) result.warnings.push('로컬 시트 누락: ' + missingLocal.join(', '));
  } catch (e3) {
    result.errors.push('로컬 시트 점검 실패: ' + e3.message);
  }
  result.ok = result.errors.length === 0;
  FHERP_appendAuditLog_('PREFLIGHT_AUDIT', result.ok ? 'OK' : 'ERROR', result.ok ? '사전점검 완료' : '사전점검 실패', result);
  return result;
}
function simulateEventVendorBridge() {
  var simulation = { ok: true, simulatedAt: FHERP_now_(), events: 0, vendors: 0, customers: 0, sales: 0, bridgeWarnings: [] };
  try {
    FHERP_ensureEventVendorLocalSheets();
    var events = readTable('Events');
    var vendors = readTable('Vendors');
    var customers = readTable('Customers');
    var sales = readTable('Sales');
    simulation.events = events.length;
    simulation.vendors = vendors.length;
    simulation.customers = customers.length;
    simulation.sales = sales.length;
    if (!events.length) simulation.bridgeWarnings.push('마스터 Events 데이터 없음');
    if (!vendors.length) simulation.bridgeWarnings.push('마스터 Vendors 데이터 없음');
    if (!customers.length) simulation.bridgeWarnings.push('마스터 Customers 데이터 없음');
    if (!sales.length) simulation.bridgeWarnings.push('마스터 Sales 데이터 없음');
    simulation.ok = simulation.bridgeWarnings.length === 0;
  } catch (e) {
    simulation.ok = false;
    simulation.bridgeWarnings.push('시뮬레이션 실패: ' + e.message);
  }
  FHERP_appendAuditLog_('BRIDGE_SIMULATION', simulation.ok ? 'OK' : 'WARN', '브릿지 시뮬레이션 완료', simulation);
  return simulation;
}
function getErpBuildBaselineStatus() {
  var audit = runErpPreflightAudit();
  var sim = simulateEventVendorBridge();
  return {
    ok: audit.ok && sim.ok,
    checkedAt: FHERP_now_(),
    audit: audit,
    simulation: sim,
    message: (audit.ok && sim.ok) ? '빌드 기준 통과' : '빌드 기준 보완 필요'
  };
}


/* B06J11 Preflight override: SystemConfig standard is CONFIG_KEY / VALUE */
function FHERP_getSystemConfigMap() {
  var sh = FHERP_getSystemConfigSheet_();
  var values = sh.getDataRange().getDisplayValues();
  if (!values || values.length < 2) return {};
  var headers = values[0].map(function(h){ return FHERP_s_(h).replace(/^\uFEFF/,'').toUpperCase(); });
  var keyIdx = headers.indexOf('CONFIG_KEY');
  var valueIdx = headers.indexOf('VALUE');
  if (keyIdx === -1 || valueIdx === -1) throw new Error('SystemConfig 표준 헤더 CONFIG_KEY / VALUE가 필요합니다.');
  var map = {};
  values.slice(1).forEach(function(r) {
    var key = FHERP_s_(r[keyIdx]);
    var value = FHERP_s_(r[valueIdx]);
    if (!key) return;
    map[key] = value;
  });
  return map;
}
function getDbSpreadsheet() {
  var masterId = FHERP_getConfigValue_('FEELHAUS_DB_MASTER', '') || FHERP_getConfigValue_('FEELHAUS_DB_MASTER_ID', '') || FHERP_getConfigValue_('DB_MASTER_ID', '');
  if (!masterId) throw new Error('SystemConfig > FEELHAUS_DB_MASTER가 비어 있습니다.');
  return SpreadsheetApp.openById(masterId);
}
