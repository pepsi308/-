/**
 * FEELHAUS ERP/SIGN 운영 UI Bridge - Unique Build
 * Build: OPS-UI-20260502-BENEFIT-GIFT-READONLY
 * Purpose: 직원이 Apps Script 직접 실행 없이 ERP 화면 버튼으로 SIGN/정산/CONTROL 작업 실행
 * Rule: 기존 함수 삭제/변경 금지, 중앙 설정(SystemConfig) + FEELHAUS_DB_MASTER + 헤더맵 기반
 */

const FH_OPS_UI_B03 = Object.freeze({
  BUILD_NO: 'OPS-UI-20260502-BENEFIT-GIFT-READONLY',
  BUILD_DESC: 'ERP_BENEFIT_GIFT_SETTLEMENT_READONLY_SAFE SIGN 기프트/상품권 정산 읽기전용 인계',
  SETUP_DB_ID: '17VMSpgSZCvIrUlgcw8yCNcnl8WQWo2IcRf5tDCcuJGM',
  CONFIG_SHEET_NAME: 'SystemConfig',
  SOURCE_DB: 'FEELHAUS_SETUP_DB',
  DEFAULT_MASTER_KEYS: ['FEELHAUS_DB_MASTER_ID', 'MASTER_DB_ID', 'DB_MASTER_ID'],
  SHEETS: {
    documents: ['SIGN_Documents', 'Documents', 'SIGN_DOCUMENTS'],
    settlements: ['ERP_정산관리', 'Settlements', 'ERP_Settlements'],
    logs: ['SystemLogs', 'ERP_Logs', 'SIGN_Logs'],
    users: ['Users', 'ERP_사용자관리', 'Employees']
  },
  ACTIONS: {
    CREATE_CONTRACT_DOC: {
      label: '계약서 생성',
      candidates: ['runCreateContractSignFromSale', 'onErpSaleSaved_CreateContractSign', 'createContractSignFromSale', 'createContractDocument', 'signCreateContractDocument', 'createContractSignDocument', 'createSignContractFromSale']
    },
    CREATE_INSTALL_CONFIRM: {
      label: '설치확인서 생성',
      candidates: ['runCreateInstallConfirmSignFromInstall', 'onErpInstallCompleted_CreateInstallConfirmSign', 'createInstallConfirmSignFromInstall', 'createInstallConfirmDocument', 'signCreateInstallConfirmDocument', 'createInstallDocumentFromInstall']
    },
    CREATE_SETTLEMENT_CONFIRM: {
      label: '정산확인서 생성',
      candidates: ['runCreateSettlementConfirmSignFromSettlement', 'onErpSettlementConfirmed_CreateSettlementConfirmSign', 'createSettlementConfirmSignFromSettlement', 'createSettlementConfirmDocument', 'signCreateSettlementConfirmDocument', 'createSettlementDocumentFromSettlement']
    },
    OPEN_SIGN_LINK: {
      label: '서명 링크 열기',
      candidates: []
    },
    GENERATE_PDF: {
      label: 'PDF 생성',
      candidates: ['generateSignPdf', 'signGeneratePdf', 'createSignPdf', 'generateDocumentPdf']
    },
    ARCHIVE_DOC: {
      label: '보관 완료',
      candidates: ['archiveSignDocument', 'signArchiveDocument', 'markDocumentArchived', 'completeDocumentArchive']
    },
    CREATE_SETTLEMENT: {
      label: '정산 생성',
      candidates: ['createSettlement', 'erpCreateSettlement', 'createSettlementFromSale']
    },
    REQUEST_SETTLEMENT_APPROVAL: {
      label: '승인 요청',
      candidates: ['requestSettlementApproval', 'erpRequestSettlementApproval', 'submitSettlementApproval']
    },
    APPROVE_SETTLEMENT: {
      label: '승인',
      candidates: ['approveSettlement', 'erpApproveSettlement', 'approveSettlementRequest']
    },
    COMPLETE_PAYMENT: {
      label: '지급 완료',
      candidates: ['completeSettlementPayment', 'erpCompletePayment', 'markSettlementPaid']
    },
    RUN_CONTROL_DIAG: {
      label: 'CONTROL 진단 실행',
      candidates: ['runControlDiagnostics', 'controlRunDiagnostics', 'runIntegratedDiagnostics', 'runSignErpControlDiagnostics', 'runDiagnosticsSuite', 'getDiagnosticsBundle']
    },
    CREATE_TEST_SAMPLES: {
      label: '테스트샘플 생성',
      candidates: []
    },
    RESET_TEST_SAMPLES: {
      label: 'TEST 샘플 초기화',
      candidates: []
    }
  }
});

function fhOpsUiB03OnOpen() {
  return fhOpsUiB03Ok_('B04는 ERP 웹앱 내장형 UI입니다. 스프레드시트 상단 메뉴를 생성하지 않습니다.', {
    buildNo: FH_OPS_UI_B03.BUILD_NO,
    mode: 'WEBAPP_EMBEDDED'
  });
}

function fhOpsUiB03AddMenu_() {
  return fhOpsUiB03Ok_('B04는 ERP 웹앱 내장형 UI입니다. SpreadsheetApp.getUi()를 호출하지 않습니다.', {
    buildNo: FH_OPS_UI_B03.BUILD_NO,
    mode: 'NO_SPREADSHEET_MENU'
  });
}

function fhOpsUiB03InstallOpenTrigger() {
  return fhOpsUiB03Ok_('B04 설치 확인 완료. ERP 웹앱을 새 배포/배포수정 후 화면의 [운영버튼]에서 실행하세요.', {
    buildNo: FH_OPS_UI_B03.BUILD_NO,
    mode: 'WEBAPP_ONLY',
    requiredAction: 'Deploy web app new version or update deployment'
  });
}

function fhOpsUiB03ShowUi() {
  return HtmlService.createHtmlOutputFromFile('Index')
    .setTitle('FEELHAUS ERP')
    .setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL);
}

function fhOpsUiB03RunControlDiagnosticsFromMenu() {
  return fhOpsUiB03RunAction({ action: 'RUN_CONTROL_DIAG', reason: 'ERP 웹앱 운영버튼에서 CONTROL 진단 실행' });
}

function fhOpsUiB04Ping() {
  const ctx = fhOpsUiB03GetContext_();
  return fhOpsUiB03Ok_('B06A 서버 연결 정상', {
    buildNo: 'v64-B06J34G',
    userEmail: ctx.userEmail,
    masterDbId: ctx.masterDbId,
    serverTime: new Date().toISOString()
  });
}

function fhOpsUiB03GetDashboard() {
  const ctx = fhOpsUiB03GetContext_();
  const docs = fhOpsUiB03ReadRecentDocuments_(ctx, 20);
  const settlements = fhOpsUiB03ReadRecentSettlements_(ctx, 20);
  return fhOpsUiB03Ok_('운영 현황 조회 완료', {
    buildNo: FH_OPS_UI_B03.BUILD_NO,
    buildDesc: FH_OPS_UI_B03.BUILD_DESC,
    userEmail: ctx.userEmail,
    masterDbId: ctx.masterDbId,
    documentSummary: fhOpsUiB03SummarizeDocuments_(docs),
    settlementSummary: fhOpsUiB03SummarizeSettlements_(settlements),
    recentDocuments: docs,
    recentSettlements: settlements,
    actions: Object.keys(FH_OPS_UI_B03.ACTIONS).map(function (key) {
      return { action: key, label: FH_OPS_UI_B03.ACTIONS[key].label };
    })
  });
}

function fhOpsUiB03RunAction(payload) {
  const lock = LockService.getScriptLock();
  lock.waitLock(30000);
  try {
    const data = payload || {};
    const action = String(data.action || '').trim();
    if (!FH_OPS_UI_B03.ACTIONS[action]) {
      return fhOpsUiB03Fail_('허용되지 않은 작업입니다.', 'INVALID_ACTION', { action: action });
    }

    const ctx = fhOpsUiB03GetContext_();
    fhOpsUiB03ValidateReason_(data, action);
    fhOpsUiB03AssertPermission_(ctx, action);

    if (action === 'OPEN_SIGN_LINK') {
      return fhOpsUiB03OpenSignLink_(ctx, data);
    }
    if (action === 'GENERATE_PDF') {
      const pdfResult = fhOpsUiB04GeneratePdfStatus_(ctx, data);
      fhOpsUiB03WriteAuditLog_(ctx, action, data, pdfResult, pdfResult.ok ? 'SUCCESS' : 'FAIL');
      return pdfResult;
    }
    if (action === 'ARCHIVE_DOC') {
      const archiveResult = fhOpsUiB04ArchiveDocumentStatus_(ctx, data);
      fhOpsUiB03WriteAuditLog_(ctx, action, data, archiveResult, archiveResult.ok ? 'SUCCESS' : 'FAIL');
      return archiveResult;
    }

    const spec = FH_OPS_UI_B03.ACTIONS[action];
    const execResult = fhOpsUiB04CallActionFunction_(action, spec.candidates, data);
    fhOpsUiB03WriteAuditLog_(ctx, action, data, execResult, 'SUCCESS');

    return fhOpsUiB03Ok_(spec.label + ' 완료', {
      action: action,
      label: spec.label,
      result: execResult
    });
  } catch (err) {
    try {
      const ctxForLog = fhOpsUiB03GetContext_();
      fhOpsUiB03WriteAuditLog_(ctxForLog, payload && payload.action, payload, { message: err.message }, 'FAIL');
    } catch (logErr) {}
    return fhOpsUiB03Fail_(err.message || String(err), 'ACTION_FAILED', { stack: err.stack || '' });
  } finally {
    lock.releaseLock();
  }
}

function fhOpsUiB03OpenSignLink(payload) {
  return fhOpsUiB03RunAction(Object.assign({}, payload || {}, { action: 'OPEN_SIGN_LINK' }));
}

function fhOpsUiB03GetContext_() {
  const setup = SpreadsheetApp.openById(FH_OPS_UI_B03.SETUP_DB_ID);
  const configSheet = setup.getSheetByName(FH_OPS_UI_B03.CONFIG_SHEET_NAME);
  if (!configSheet) throw new Error('SystemConfig 시트를 찾을 수 없습니다.');
  const config = fhOpsUiB03ReadKeyValueSheet_(configSheet);
  const masterDbId = fhOpsUiB03PickFirst_(config, FH_OPS_UI_B03.DEFAULT_MASTER_KEYS);
  if (!masterDbId) throw new Error('SystemConfig에서 FEELHAUS_DB_MASTER ID를 찾을 수 없습니다.');
  return {
    setupDb: setup,
    config: config,
    masterDbId: masterDbId,
    masterDb: SpreadsheetApp.openById(masterDbId),
    userEmail: Session.getActiveUser().getEmail() || 'UNKNOWN_USER'
  };
}

function fhOpsUiB03ReadKeyValueSheet_(sheet) {
  const values = sheet.getDataRange().getValues();
  if (values.length < 2) return {};
  const headers = values[0].map(function (h) { return String(h || '').trim(); });
  const keyIdx = Math.max(headers.indexOf('key'), headers.indexOf('configKey'), headers.indexOf('name'));
  const valueIdx = Math.max(headers.indexOf('value'), headers.indexOf('configValue'), headers.indexOf('id'));
  const out = {};
  values.slice(1).forEach(function (row) {
    const k = String(row[keyIdx >= 0 ? keyIdx : 0] || '').trim();
    if (k) out[k] = row[valueIdx >= 0 ? valueIdx : 1];
  });
  return out;
}

function fhOpsUiB03PickFirst_(obj, keys) {
  for (var i = 0; i < keys.length; i++) {
    if (obj[keys[i]]) return String(obj[keys[i]]).trim();
  }
  return '';
}

function fhOpsUiB03GetSheetByCandidates_(ss, names, required) {
  for (var i = 0; i < names.length; i++) {
    const sheet = ss.getSheetByName(names[i]);
    if (sheet) return sheet;
  }
  if (required) throw new Error('필수 시트를 찾을 수 없습니다: ' + names.join(' / '));
  return null;
}

function fhOpsUiB03HeaderMap_(sheet) {
  const headers = sheet.getRange(1, 1, 1, sheet.getLastColumn()).getValues()[0];
  const map = {};
  headers.forEach(function (h, i) {
    const key = String(h || '').trim();
    if (key) map[key] = i;
  });
  return map;
}

function fhOpsUiB03RowsAsObjects_(sheet, limit) {
  if (!sheet || sheet.getLastRow() < 2) return [];
  const map = fhOpsUiB03HeaderMap_(sheet);
  const lastRow = sheet.getLastRow();
  const startRow = Math.max(2, lastRow - (limit || 20) + 1);
  const values = sheet.getRange(startRow, 1, lastRow - startRow + 1, sheet.getLastColumn()).getValues();
  const headers = Object.keys(map);
  return values.reverse().map(function (row) {
    const obj = {};
    headers.forEach(function (h) { obj[h] = row[map[h]]; });
    return obj;
  });
}

function fhOpsUiB03ReadRecentDocuments_(ctx, limit) {
  const sheet = fhOpsUiB03GetSheetByCandidates_(ctx.masterDb, FH_OPS_UI_B03.SHEETS.documents, false);
  return fhOpsUiB03RowsAsObjects_(sheet, limit);
}

function fhOpsUiB03ReadRecentSettlements_(ctx, limit) {
  const sheet = fhOpsUiB03GetSheetByCandidates_(ctx.masterDb, FH_OPS_UI_B03.SHEETS.settlements, false);
  return fhOpsUiB03RowsAsObjects_(sheet, limit);
}

function fhOpsUiB03SummarizeDocuments_(rows) {
  const summary = { total: rows.length, pendingSign: 0, signed: 0, pdfReady: 0, archived: 0 };
  rows.forEach(function (r) {
    const status = String(r.status || r.documentStatus || '').toUpperCase();
    if (status.indexOf('PENDING') >= 0 || status.indexOf('WAIT') >= 0) summary.pendingSign++;
    if (status.indexOf('SIGNED') >= 0 || status.indexOf('서명') >= 0) summary.signed++;
    if (String(r.pdfUrl || r.PDF || '').trim()) summary.pdfReady++;
    if (status.indexOf('ARCHIVED') >= 0 || status.indexOf('보관') >= 0) summary.archived++;
  });
  return summary;
}

function fhOpsUiB03SummarizeSettlements_(rows) {
  const summary = { total: rows.length, draft: 0, approvalPending: 0, approved: 0, paid: 0 };
  rows.forEach(function (r) {
    const status = String(r.status || r.settlementStatus || '').toUpperCase();
    if (status.indexOf('DRAFT') >= 0 || status.indexOf('작성') >= 0) summary.draft++;
    if (status.indexOf('REQUEST') >= 0 || status.indexOf('PENDING') >= 0 || status.indexOf('요청') >= 0) summary.approvalPending++;
    if (status.indexOf('APPROVED') >= 0 || status.indexOf('승인') >= 0) summary.approved++;
    if (status.indexOf('PAID') >= 0 || status.indexOf('지급') >= 0) summary.paid++;
  });
  return summary;
}

function fhOpsUiB03ValidateReason_(data, action) {
  const sensitive = ['APPROVE_SETTLEMENT', 'COMPLETE_PAYMENT', 'ARCHIVE_DOC'];
  if (sensitive.indexOf(action) >= 0 && !String(data.reason || '').trim()) {
    throw new Error('이 작업은 사유 입력이 필요합니다.');
  }
}

function fhOpsUiB03AssertPermission_(ctx, action) {
  const sensitive = ['APPROVE_SETTLEMENT', 'COMPLETE_PAYMENT', 'RUN_CONTROL_DIAG'];
  if (sensitive.indexOf(action) < 0) return true;
  const allow = ['SUPER_ADMIN', 'HQ_ADMIN', 'ACCOUNTING_MANAGER', 'OPERATION_MANAGER'];
  const role = fhOpsUiB03FindUserRole_(ctx);
  if (allow.indexOf(role) < 0) throw new Error('권한 없음: ' + action + ' / 현재 역할: ' + role);
  return true;
}

function fhOpsUiB03FindUserRole_(ctx) {
  if (ctx && ctx.role) return fhOpsUiB05MNormalizeRole_(ctx.role);
  const sheet = fhOpsUiB03GetSheetByCandidates_(ctx.masterDb, FH_OPS_UI_B03.SHEETS.users, false);
  if (!sheet || sheet.getLastRow() < 2) return 'VIEWER';
  const map = fhOpsUiB03HeaderMap_(sheet);
  if (map.email == null || map.role == null) return 'VIEWER';
  const values = sheet.getRange(2, 1, sheet.getLastRow() - 1, sheet.getLastColumn()).getValues();
  const email = String((ctx && ctx.userEmail) || '').toLowerCase();
  for (var i = 0; i < values.length; i++) {
    if (String(values[i][map.email] || '').toLowerCase() === email) {
      return fhOpsUiB05MNormalizeRole_(values[i][map.role] || 'VIEWER');
    }
  }
  return 'VIEWER';
}

function fhOpsUiB03CallFirstAvailable_(candidates, payload) {
  return fhOpsUiB04CallFirstAvailableWithArgs_(candidates, [payload || {}]);
}

function fhOpsUiB04CallActionFunction_(action, candidates, payload) {
  const data = payload || {};
  let args = [data];
  if (action === 'CREATE_CONTRACT_DOC') {
    if (!String(data.saleId || '').trim()) throw new Error('saleId가 필요합니다.');
    args = [String(data.saleId).trim()];
  } else if (action === 'CREATE_INSTALL_CONFIRM') {
    if (!String(data.installId || '').trim()) throw new Error('installId가 필요합니다.');
    args = [String(data.installId).trim()];
  } else if (action === 'CREATE_SETTLEMENT_CONFIRM') {
    if (!String(data.settlementId || '').trim()) throw new Error('settlementId가 필요합니다.');
    args = [String(data.settlementId).trim()];
  }
  return fhOpsUiB04CallFirstAvailableWithArgs_(candidates, args);
}

function fhOpsUiB04CallFirstAvailableWithArgs_(candidates, args) {
  const globalObj = (typeof globalThis !== 'undefined') ? globalThis : this;
  const errors = [];
  for (var i = 0; i < candidates.length; i++) {
    const fnName = candidates[i];
    if (typeof globalObj[fnName] === 'function') {
      try {
        const result = globalObj[fnName].apply(globalObj, args || []);
        if (result == null) {
          return { ok: true, message: fnName + ' 실행 완료(반환값 없음)', data: null, usedFunction: fnName };
        }
        return { ok: true, message: fnName + ' 실행 완료', data: result, usedFunction: fnName };
      } catch (err) {
        errors.push(fnName + ': ' + (err && err.message ? err.message : String(err)));
      }
    }
  }
  throw new Error('연결 가능한 기존 함수가 없거나 모두 실패했습니다: ' + candidates.join(' / ') + (errors.length ? ' / 오류: ' + errors.join(' | ') : ''));
}

function fhOpsUiB03OpenSignLink_(ctx, data) {
  const documentId = String(data.documentId || '').trim();
  if (!documentId) throw new Error('documentId가 필요합니다.');
  const sheet = fhOpsUiB03GetSheetByCandidates_(ctx.masterDb, FH_OPS_UI_B03.SHEETS.documents, true);
  const map = fhOpsUiB03HeaderMap_(sheet);
  if (map.documentId == null) throw new Error('SIGN 문서 시트에 documentId 헤더가 없습니다.');
  const signKey = map.signUrl != null ? 'signUrl' : (map.qrUrl != null ? 'qrUrl' : '');
  if (!signKey) throw new Error('SIGN 문서 시트에 signUrl 또는 qrUrl 헤더가 없습니다.');
  const values = sheet.getRange(2, 1, Math.max(sheet.getLastRow() - 1, 0), sheet.getLastColumn()).getValues();
  for (var i = 0; i < values.length; i++) {
    if (String(values[i][map.documentId] || '').trim() === documentId) {
      const url = String(values[i][map[signKey]] || '').trim();
      if (!url) throw new Error('서명 링크가 비어 있습니다: ' + documentId);
      return fhOpsUiB03Ok_('서명 링크 조회 완료', { documentId: documentId, signUrl: url });
    }
  }
  throw new Error('documentId를 찾을 수 없습니다: ' + documentId);
}


function fhOpsUiB04FindDocumentById_(ctx, documentId) {
  const id = String(documentId || '').trim();
  if (!id) throw new Error('documentId가 필요합니다.');
  const sheet = fhOpsUiB03GetSheetByCandidates_(ctx.masterDb, FH_OPS_UI_B03.SHEETS.documents, true);
  const map = fhOpsUiB03HeaderMap_(sheet);
  if (map.documentId == null) throw new Error('SIGN 문서 시트에 documentId 헤더가 없습니다.');
  const lastRow = sheet.getLastRow();
  if (lastRow < 2) throw new Error('SIGN 문서 데이터가 없습니다.');
  const values = sheet.getRange(2, 1, lastRow - 1, sheet.getLastColumn()).getValues();
  for (var i = 0; i < values.length; i++) {
    if (String(values[i][map.documentId] || '').trim() === id) {
      const row = values[i];
      const obj = {};
      Object.keys(map).forEach(function (h) { obj[h] = row[map[h]]; });
      return { sheet: sheet, map: map, rowIndex: i + 2, rowValues: row, row: obj };
    }
  }
  throw new Error('documentId를 찾을 수 없습니다: ' + id);
}

function fhOpsUiB04IsPdfReady_(doc) {
  const r = doc.row || {};
  const status = String(r.status || '').toUpperCase();
  return !!String(r.pdfFileId || r.pdfFileUrl || r.archivePath || r.archiveFileName || '').trim() || status === 'PDF_COMPLETED' || status === 'ARCHIVED';
}

function fhOpsUiB04IsArchived_(doc) {
  const r = doc.row || {};
  const status = String(r.status || '').toUpperCase();
  const archiveStatus = String(r.archiveStatus || '').toUpperCase();
  return status === 'ARCHIVED' || archiveStatus === 'ARCHIVED' || String(r.archivedAt || '').trim();
}


function fhOpsUiB06F1PdfLockMessage_(r) {
  r = r || {};
  var st = String(r.status || '').toUpperCase();
  var ast = String(r.archiveStatus || '').toUpperCase();
  if (st === 'ARCHIVED' || ast === 'ARCHIVED' || String(r.archivedAt || '').trim()) {
    return '정상 차단: 보관 완료된 잠금 문서입니다. PDF 재생성은 차단됩니다. 수정이 필요하면 재오픈 요청을 진행하세요.';
  }
  if (st === 'PDF_COMPLETED' || String(r.pdfFileId || r.pdfFileUrl || r.archivePath || r.archiveFileName || '').trim()) {
    return '이미 PDF 생성 완료 상태입니다. 다음 단계는 보관 완료입니다.';
  }
  return 'PDF 이미 생성 완료 또는 보관 완료 상태입니다.';
}

function fhOpsUiB04GeneratePdfStatus_(ctx, data) {
  const doc = fhOpsUiB04FindDocumentById_(ctx, data && data.documentId);
  if (fhOpsUiB04IsPdfReady_(doc)) {
    return fhOpsUiB03Ok_(fhOpsUiB06F1PdfLockMessage_(doc.row), {
      documentId: doc.row.documentId,
      documentNo: doc.row.documentNo || '',
      documentType: doc.row.documentType || '',
      status: doc.row.status || '',
      pdfFileId: doc.row.pdfFileId || '',
      pdfFileUrl: doc.row.pdfFileUrl || '',
      archivePath: doc.row.archivePath || ''
    });
  }
  return fhOpsUiB03Fail_('PDF 생성 엔진 함수가 ERP 프로젝트에 연결되어 있지 않습니다. 현재 문서는 PDF 미생성 상태입니다.', 'PDF_ENGINE_NOT_MAPPED', {
    documentId: doc.row.documentId,
    documentNo: doc.row.documentNo || '',
    status: doc.row.status || '',
    requiredCandidates: FH_OPS_UI_B03.ACTIONS.GENERATE_PDF.candidates
  });
}

function fhOpsUiB04ArchiveDocumentStatus_(ctx, data) {
  const doc = fhOpsUiB04FindDocumentById_(ctx, data && data.documentId);
  if (fhOpsUiB04IsArchived_(doc)) {
    return fhOpsUiB03Ok_('정상 차단: 이미 보관 완료된 잠금 문서입니다. 수정이 필요하면 재오픈 요청을 진행하세요.', {
      documentId: doc.row.documentId,
      documentNo: doc.row.documentNo || '',
      documentType: doc.row.documentType || '',
      status: doc.row.status || '',
      archiveStatus: doc.row.archiveStatus || '',
      archivePath: doc.row.archivePath || '',
      archiveFileName: doc.row.archiveFileName || ''
    });
  }
  if (!fhOpsUiB04IsPdfReady_(doc)) {
    return fhOpsUiB03Fail_('PDF 생성 전 문서는 보관 완료 처리할 수 없습니다.', 'PDF_NOT_READY', {
      documentId: doc.row.documentId,
      documentNo: doc.row.documentNo || '',
      status: doc.row.status || ''
    });
  }
  const now = new Date();
  const user = ctx.userEmail || Session.getActiveUser().getEmail() || 'UNKNOWN_USER';
  const updates = {
    status: 'ARCHIVED',
    statusReason: '보관 완료',
    archiveStatus: 'ARCHIVED',
    archivedAt: now,
    archivedBy: user,
    updatedAt: now,
    updatedBy: user
  };
  Object.keys(updates).forEach(function (key) {
    if (doc.map[key] != null) doc.sheet.getRange(doc.rowIndex, doc.map[key] + 1).setValue(updates[key]);
  });
  return fhOpsUiB03Ok_('보관 완료 상태로 갱신했습니다.', {
    documentId: doc.row.documentId,
    documentNo: doc.row.documentNo || '',
    status: 'ARCHIVED',
    archiveStatus: 'ARCHIVED'
  });
}

function fhOpsUiB03WriteAuditLog_(ctx, action, payload, result, status) {
  let sheet = fhOpsUiB03GetSheetByCandidates_(ctx.masterDb, FH_OPS_UI_B03.SHEETS.logs, false);
  if (!sheet) {
    sheet = ctx.masterDb.insertSheet('SystemLogs');
    sheet.appendRow(['logId', 'createdAt', 'createdBy', 'actionType', 'targetId', 'status', 'statusReason', 'beforeValue', 'afterValue', 'meta']);
  }
  const map = fhOpsUiB03HeaderMap_(sheet);
  const rowObj = {
    logId: 'LOG-' + Utilities.getUuid().replace(/-/g, '').slice(0, 12).toUpperCase(),
    createdAt: new Date(),
    createdBy: ctx.userEmail,
    actionType: action || '',
    targetId: (payload && (payload.documentId || payload.settlementId || payload.saleId || payload.installId || payload.contractId)) || '',
    status: status,
    statusReason: (payload && payload.reason) || '',
    beforeValue: '',
    afterValue: JSON.stringify(result || {}),
    meta: JSON.stringify({ buildNo: FH_OPS_UI_B03.BUILD_NO, payload: payload || {} })
  };
  const row = new Array(sheet.getLastColumn()).fill('');
  Object.keys(rowObj).forEach(function (key) {
    if (map[key] != null) row[map[key]] = rowObj[key];
  });
  sheet.appendRow(row);
}

function fhOpsUiB03Ok_(message, data) {
  return { ok: true, message: message, data: data || {}, errorCode: '', meta: { buildNo: FH_OPS_UI_B03.BUILD_NO, at: new Date().toISOString() } };
}

function fhOpsUiB03Fail_(message, errorCode, data) {
  return { ok: false, message: message, data: data || {}, errorCode: errorCode || 'ERROR', meta: { buildNo: FH_OPS_UI_B03.BUILD_NO, at: new Date().toISOString() } };
}

/**
 * ===== FEELHAUS OPS UI B04E SAFE WRAPPER =====
 * ERP 본체 대시보드와 운영버튼 서버 처리를 분리한다.
 */
function fhOpsUiB04EPing(payload) {
  const ctx = fhOpsUiB04EContext_(payload || {});
  return fhOpsUiB04EOk_('B06A 서버 연결 정상', {
    buildNo: 'v64-B06J34G',
    opsBuildNo: FH_OPS_UI_B03.BUILD_NO,
    userEmail: ctx.userEmail,
    sessionEmail: ctx.sessionEmail,
    operatorEmail: ctx.operatorEmail,
    authMode: ctx.authMode,
    role: ctx.role,
    employeeId: ctx.employee && ctx.employee.employeeId ? ctx.employee.employeeId : '',
    employeeName: ctx.employee && ctx.employee.userName ? ctx.employee.userName : '',
    employeeStatus: ctx.employee && ctx.employee.status ? ctx.employee.status : '',
    employeeVendorId: ctx.employee && ctx.employee.vendorId ? ctx.employee.vendorId : '',
    employeeEventScope: ctx.employee && ctx.employee.eventScope ? ctx.employee.eventScope : '',
    manualEmailReceived: String(fhOpsUiB05PGetManualEmail_(payload || {}) || ctx.operatorEmail || '').trim(),
    manualEmailPresent: !!String(fhOpsUiB05PGetManualEmail_(payload || {}) || ctx.operatorEmail || '').trim(),
    employeeFound: !!(ctx.employee && ctx.employee.isActive),
    sessionTokenPresent: !!fhOpsUiB06GetSessionToken_(payload || {}),
    rawPayloadKeys: fhOpsUiB05PAuthDebugPayload_(payload || {}).rawPayloadKeys,
    rawPayloadPreview: fhOpsUiB05PAuthDebugPayload_(payload || {}).rawPayloadPreview,
    masterDbId: ctx.masterDbId,
    serverTime: new Date().toISOString()
  });
}

function fhOpsUiB04EGetDashboard(payload) {
  try {
    const ctx = fhOpsUiB04EContext_(payload || {});
    const docs = fhOpsUiB04EReadRows_(ctx, ['SIGN_Documents', 'Documents', 'SIGN_DOCUMENTS'], 20);
    const settles = fhOpsUiB04EReadRows_(ctx, ['ERP_정산관리', 'Settlements', 'ERP_Settlements'], 20);
    return fhOpsUiB04EOk_('B06A 운영버튼 전용 현황 조회 완료', {
      documentSummary: fhOpsUiB04EDocSummary_(docs),
      settlementSummary: fhOpsUiB04ESettlementSummary_(settles),
      recentDocuments: docs,
      recentSettlements: settles,
      actor: { userEmail: ctx.userEmail, authMode: ctx.authMode, role: ctx.role, employeeId: ctx.employee && ctx.employee.employeeId ? ctx.employee.employeeId : '', employeeName: ctx.employee && ctx.employee.userName ? ctx.employee.userName : '' },
      buildNo: 'v64-B06J34G'
    });
  } catch (err) {
    return fhOpsUiB04EFail_('B05 운영버튼 현황 조회 실패: ' + ((err && err.message) || String(err)), 'B05_DASHBOARD_FAILED', { recentDocuments: [], recentSettlements: [] });
  }
}

function fhOpsUiB04ERunAction(payload) {
  const data = payload || {};
  const action = String(data.action || '').trim();
  try {
    const ctx = fhOpsUiB04EContext_(data);
    fhOpsUiB05MAssertActionPermission_(ctx, action);
    if (!action) return fhOpsUiB04EFail_('작업 코드가 없습니다.', 'ACTION_REQUIRED', data);
    if (action === 'OPEN_SIGN_LINK') return fhOpsUiB04EOpenSignLink(data);
    if (action === 'GENERATE_PDF') return fhOpsUiB04EPdfStatus_(ctx, data);
    if (action === 'ARCHIVE_DOC') return fhOpsUiB04EArchiveStatus_(ctx, data);
    if (action === 'CREATE_CONTRACT_DOC') return fhOpsUiB04ECreateOrReuseDoc_(ctx, data, 'CONTRACT', 'saleId', data.saleId, ['runCreateContractSignFromSale', 'createContractSignFromSale', 'createContractDocument']);
    if (action === 'CREATE_INSTALL_CONFIRM') return fhOpsUiB04ECreateOrReuseDoc_(ctx, data, 'INSTALL_CONFIRM', 'installId', data.installId, ['runCreateInstallConfirmSignFromInstall', 'createInstallConfirmSignFromInstall', 'createInstallConfirmDocument']);
    if (action === 'CREATE_SETTLEMENT_CONFIRM') return fhOpsUiB04ECreateOrReuseDoc_(ctx, data, 'SETTLEMENT_CONFIRM', 'settlementId', data.settlementId, ['runCreateSettlementConfirmSignFromSettlement', 'createSettlementConfirmSignFromSettlement', 'createSettlementConfirmDocument']);
    if (action === 'CREATE_SETTLEMENT') return fhOpsUiB04GCreateSettlement_(ctx, data);
    if (action === 'REQUEST_SETTLEMENT_APPROVAL') return fhOpsUiB04GRequestSettlementApproval_(ctx, data);
    if (action === 'APPROVE_SETTLEMENT') return fhOpsUiB04GActSettlement_(ctx, data, 'APPROVED');
    if (action === 'COMPLETE_PAYMENT') return fhOpsUiB04GActSettlement_(ctx, data, 'PAID');
    if (action === 'RUN_CONTROL_DIAG') return fhOpsUiB05IRunControlDiag_(ctx, data);
    if (action === 'CREATE_TEST_SAMPLES') return fhOpsUiB06A7CreateTestSamples_(ctx, data);
    if (action === 'RESET_TEST_SAMPLES') return fhOpsUiB06A7ResetTestSamples_(ctx, data);
    return fhOpsUiB04EFail_('허용되지 않은 작업입니다: ' + action, 'INVALID_ACTION', data);
  } catch (err) {
    return fhOpsUiB04EFail_((err && err.message) || String(err), 'B05_ACTION_FAILED', { action: action, stack: err && err.stack ? err.stack : '' });
  }
}


/**
 * B05I CONTROL/ERP lightweight diagnostics fallback.
 * 기존 CONTROL 전용 함수가 ERP 프로젝트에 없을 때도 운영버튼에서 최소 진단 결과를 반환한다.
 * 기존 함수가 있으면 우선 사용하고, 없거나 실패하면 직접 시트/헤더/문서상태를 점검한다.
 */
/**
 * B06A1 FULL FIX
 * 기존 B04E 운영버튼 코드가 후보 함수 라우터를 호출하지만,
 * 일부 기준본에서 fhOpsUiB04ECallCandidates_ 정의가 누락되어 PDF 생성이 실패하던 문제를 보정한다.
 * - 권한 검증은 fhOpsUiB04ERunAction / 개별 액션 함수에서 먼저 수행한다.
 * - 존재하는 후보 함수만 안전 호출한다.
 * - 후보 함수가 없으면 skipped=true를 반환하여 ERP 내장 PDF 엔진으로 정상 fallback 되게 한다.
 */
function fhOpsUiB04ECallCandidates_(candidates, args) {
  var names = Array.isArray(candidates) ? candidates : [candidates];
  var callArgs = Array.isArray(args) ? args : [];
  var tried = [];
  var errors = [];

  for (var i = 0; i < names.length; i++) {
    var name = String(names[i] || '').trim();
    if (!name) continue;
    tried.push(name);

    var fn = null;
    try {
      if (typeof globalThis !== 'undefined' && typeof globalThis[name] === 'function') {
        fn = globalThis[name];
      }
    } catch (e1) {}

    if (!fn) {
      try {
        var evaluated = eval(name);
        if (typeof evaluated === 'function') fn = evaluated;
      } catch (e2) {}
    }

    if (typeof fn !== 'function') continue;

    try {
      return {
        skipped: false,
        error: false,
        usedFunction: name,
        result: fn.apply(null, callArgs)
      };
    } catch (err) {
      errors.push({
        usedFunction: name,
        message: (err && err.message) || String(err),
        stack: err && err.stack ? err.stack : ''
      });
    }
  }

  return {
    skipped: true,
    error: errors.length > 0,
    triedFunctions: tried,
    errors: errors,
    message: errors.length ? '후보 함수 호출 실패' : '연결 가능한 후보 함수가 없습니다.'
  };
}

function testB06A1FullFixedCandidateRouter_() {
  var res = fhOpsUiB04ECallCandidates_(['__FH_NOT_EXISTS_TEST__'], []);
  if (!res || res.skipped !== true) throw new Error('fhOpsUiB04ECallCandidates_ skipped 결과 오류');
  return {
    ok: true,
    message: 'B06A1 후보 함수 라우터 문법/기본동작 확인 완료',
    data: res,
    errorCode: '',
    meta: { buildNo: 'ERP_v64_B06A1_LOGIN_SESSION_REBASE_SAFE_FULL_FIXED', at: new Date().toISOString() }
  };
}

function fhOpsUiB05IRunControlDiag_(ctx, data) {
  var candidates = ['runControlDiagnostics', 'controlRunDiagnostics', 'runIntegratedDiagnostics', 'runSignErpControlDiagnostics', 'runDiagnosticsSuite', 'getDiagnosticsBundle'];
  var call = fhOpsUiB04ECallCandidates_(candidates, [data || {}]);
  if (call && !call.skipped && !call.error) {
    return fhOpsUiB04EOk_('CONTROL 진단 실행 완료', {
      mode: 'EXISTING_DIAGNOSTIC_FUNCTION',
      usedFunction: call.usedFunction || '',
      result: call
    });
  }

  var checks = [];
  function addCheck(name, ok, message, meta) {
    checks.push({ name: name, ok: !!ok, level: ok ? 'PASS' : 'WARNING', message: message || '', meta: fhOpsUiB04ESafeValue_(meta || {}) });
  }

  try {
    addCheck('중앙 마스터 연결', !!(ctx && ctx.masterDb), 'FEELHAUS_DB_MASTER 연결 확인', { masterDbId: ctx && ctx.masterDbId });
    var ss = ctx.masterDb;
    var sheetNames = ss.getSheets().map(function(sh){ return sh.getName(); });
    var requiredSheets = ['Sales', 'SIGN_Documents', 'Documents', 'Settlements'];
    requiredSheets.forEach(function(name){ addCheck('필수 시트: ' + name, sheetNames.indexOf(name) >= 0, sheetNames.indexOf(name) >= 0 ? '시트 존재' : '시트 없음', {}); });

    var signInfo = fhOpsUiB04EOpenFirstSheet_(ss, ['SIGN_Documents', 'Documents', 'SIGN_DOCUMENTS']);
    if (signInfo && signInfo.sheet) {
      var headers = signInfo.headers || [];
      ['documentId', 'documentType', 'status', 'signUrl'].forEach(function(h){ addCheck('SIGN 헤더: ' + h, headers.indexOf(h) >= 0, headers.indexOf(h) >= 0 ? '헤더 존재' : '헤더 없음', { sheet: signInfo.sheet.getName() }); });
      var docs = fhOpsUiB04EReadRows_(ctx, ['SIGN_Documents', 'Documents', 'SIGN_DOCUMENTS'], 200);
      var summary = fhOpsUiB04EDocSummary_(docs);
      addCheck('문서 요약 조회', true, '문서 요약 조회 완료', summary);
    } else {
      addCheck('문서 시트 조회', false, 'SIGN_Documents/Documents 시트를 찾지 못했습니다.', {});
    }

    var setInfo = fhOpsUiB04EOpenFirstSheet_(ss, ['ERP_정산관리', 'Settlements', 'ERP_Settlements']);
    if (setInfo && setInfo.sheet) {
      var sh2 = setInfo.sheet;
      var vals = sh2.getDataRange().getValues();
      var count = Math.max(0, vals.length - 1);
      addCheck('정산 시트 조회', true, '정산 시트 조회 완료', { sheet: sh2.getName(), rows: count });
    } else {
      addCheck('정산 시트 조회', false, '정산 시트를 찾지 못했습니다.', {});
    }
  } catch (err) {
    addCheck('진단 처리 예외', false, (err && err.message) || String(err), { stack: err && err.stack ? err.stack : '' });
  }

  var warningCount = checks.filter(function(c){ return !c.ok; }).length;
  var status = warningCount ? 'WARNING' : 'PASS';
  return fhOpsUiB04EOk_('CONTROL 진단 실행 완료 - ERP 내장 진단 사용', {
    mode: 'ERP_EMBEDDED_DIAGNOSTICS_B05I',
    status: status,
    warningCount: warningCount,
    criticalCount: 0,
    checks: checks,
    previousCandidateResult: call || {}
  });
}

function fhOpsUiB04EResolveDocFromPayload_(ctx, payload, preferredType) {
  const data = payload || {};
  const documentId = String(data.documentId || '').trim();
  if (documentId) return fhOpsUiB04EFindDoc_(ctx, documentId);
  const candidates = [];
  if (String(data.saleId || '').trim()) candidates.push({ type: preferredType || 'CONTRACT', key: 'saleId', value: data.saleId });
  if (String(data.installId || '').trim()) candidates.push({ type: preferredType || 'INSTALL_CONFIRM', key: 'installId', value: data.installId });
  if (String(data.settlementId || '').trim()) candidates.push({ type: preferredType || 'SETTLEMENT_CONFIRM', key: 'settlementId', value: data.settlementId });
  for (var i = 0; i < candidates.length; i++) {
    const c = candidates[i];
    const found = fhOpsUiB04EFindDocByLink_(ctx, c.type, c.key, c.value);
    if (found && found.row && found.row.documentId) return fhOpsUiB04EFindDoc_(ctx, found.row.documentId);
  }

  // B06A5: 문서 생성 직후 클라이언트 documentId 전달이 누락되거나 목록이 갱신되기 전에도
  // saleId/installId/settlementId 기준으로 기존 생성 함수를 다시 호출해 중복 없이 재사용/생성 후 연결한다.
  // createSignDocument_ 내부 중복검사가 있으므로 동일 링크 기준 중복 문서 생성을 방지한다.
  let created = null;
  if (String(data.saleId || '').trim()) {
    created = fhOpsUiB04ECreateOrReuseDoc_(ctx, data, 'CONTRACT', 'saleId', data.saleId, ['runCreateContractSignFromSale', 'createContractSignFromSale', 'createContractDocument']);
  } else if (String(data.installId || '').trim()) {
    created = fhOpsUiB04ECreateOrReuseDoc_(ctx, data, 'INSTALL_CONFIRM', 'installId', data.installId, ['runCreateInstallConfirmSignFromInstall', 'createInstallConfirmSignFromInstall', 'createInstallConfirmDocument']);
  } else if (String(data.settlementId || '').trim()) {
    created = fhOpsUiB04ECreateOrReuseDoc_(ctx, data, 'SETTLEMENT_CONFIRM', 'settlementId', data.settlementId, ['runCreateSettlementConfirmSignFromSettlement', 'createSettlementConfirmSignFromSettlement', 'createSettlementConfirmDocument']);
  }
  const createdId = String(created && created.ok && created.data && created.data.documentId || '').trim();
  if (createdId) return fhOpsUiB04EFindDoc_(ctx, createdId);

  throw new Error('documentId가 필요합니다. 문서 생성 직후에는 목록 새로고침 후 해당 문서 행에서 실행하거나 saleId/installId/settlementId를 함께 전달해야 합니다.');
}

function fhOpsUiB04EOpenSignLink(payload) {
  try {
    const ctx = fhOpsUiB04EContext_(payload || {});
    fhOpsUiB05MAssertActionPermission_(ctx, 'OPEN_SIGN_LINK');
    const doc = fhOpsUiB04EResolveDocFromPayload_(ctx, payload || {}, 'CONTRACT');
    const url = String(doc.row.signUrl || doc.row.qrUrl || '').trim();
    if (!url) return fhOpsUiB04EFail_('서명 링크가 비어 있습니다.', 'SIGN_URL_EMPTY', { documentId: doc.row.documentId });
    return fhOpsUiB04EOk_('서명 링크 조회 완료', { documentId: doc.row.documentId, documentNo: doc.row.documentNo || '', documentType: doc.row.documentType || '', status: doc.row.status || '', signUrl: url, linkedKey: doc.row.saleId ? 'saleId' : (doc.row.installId ? 'installId' : (doc.row.settlementId ? 'settlementId' : '')), linkedId: doc.row.saleId || doc.row.installId || doc.row.settlementId || '', saleId: doc.row.saleId || '', installId: doc.row.installId || '', settlementId: doc.row.settlementId || '' });
  } catch (err) {
    return fhOpsUiB04EFail_((err && err.message) || String(err), 'OPEN_SIGN_LINK_FAILED', payload || {});
  }
}

function fhOpsUiB04ECreateOrReuseDoc_(ctx, data, documentType, idKey, idValue, candidates) {
  const id = String(idValue || '').trim();
  if (!id) return fhOpsUiB04EFail_(idKey + '가 필요합니다.', 'ID_REQUIRED', { idKey: idKey });
  const existing = fhOpsUiB04EFindDocByLink_(ctx, documentType, idKey, id);
  if (existing) {
    return fhOpsUiB04EOk_(documentType + ' 기존 문서 재사용', {
      reused: true,
      documentId: existing.row.documentId || '',
      documentNo: existing.row.documentNo || '',
      documentType: existing.row.documentType || '',
      status: existing.row.status || '',
      signUrl: existing.row.signUrl || existing.row.qrUrl || '',
      linkedKey: idKey,
      linkedId: id,
      saleId: existing.row.saleId || '',
      installId: existing.row.installId || '',
      settlementId: existing.row.settlementId || ''
    });
  }
  const call = fhOpsUiB04ECallCandidates_(candidates, [id]);
  if (call && call.skipped) {
    return fhOpsUiB04EFail_(
      documentType + ' 생성 엔진 함수가 ERP 프로젝트에 연결되어 있지 않습니다.',
      'DOC_ENGINE_NOT_MAPPED',
      { reused: false, linkedKey: idKey, linkedId: id, documentType: documentType, requiredCandidates: candidates, result: call }
    );
  }

  // B06A5: 기존 SIGN bridge 응답은 {ok,message,data:{documentId...}} 형태라
  // call.result 안에 숨어 있던 documentId를 풀어서 클라이언트가 즉시 다음 작업에 사용할 수 있게 한다.
  let createdData = {};
  const raw = call && call.data;
  if (raw && raw.ok && raw.data) createdData = raw.data;
  else if (raw && raw.documentId) createdData = raw;
  let createdId = String(createdData.documentId || '').trim();
  if (!createdId) {
    const after = fhOpsUiB04EFindDocByLink_(ctx, documentType, idKey, id);
    if (after && after.row) createdData = after.row;
    createdId = String(createdData.documentId || '').trim();
  }
  if (createdId) {
    return fhOpsUiB04EOk_(documentType + ' 문서 생성 완료', {
      reused: false,
      documentId: createdId,
      documentNo: createdData.documentNo || '',
      documentType: createdData.documentType || documentType,
      status: createdData.status || 'READY_TO_SIGN',
      signUrl: createdData.signUrl || createdData.qrUrl || '',
      linkedKey: idKey,
      linkedId: id,
      saleId: idKey === 'saleId' ? id : (createdData.saleId || ''),
      installId: idKey === 'installId' ? id : (createdData.installId || ''),
      settlementId: idKey === 'settlementId' ? id : (createdData.settlementId || ''),
      result: call
    });
  }
  return fhOpsUiB04EOk_(documentType + ' 생성 함수 호출 완료', { reused: false, linkedKey: idKey, linkedId: id, result: call });
}

function fhOpsUiB04EPdfStatus_(ctx, data) {
  // B06A6: 상단 PDF 버튼에서 documentId가 비어 있어도 saleId/installId/settlementId 기준으로 문서를 보정한다.
  const doc = fhOpsUiB04EResolveDocFromPayload_(ctx, data || {}, 'CONTRACT');
  const r = doc.row;
  const st = String(r.status || '').toUpperCase();
  const ready = !!String(r.pdfFileId || r.pdfFileUrl || r.archivePath || r.archiveFileName || '').trim() || st === 'PDF_COMPLETED' || st === 'ARCHIVED';
  if (ready) return fhOpsUiB04EOk_(fhOpsUiB06F1PdfLockMessage_(r), fhOpsUiB04EDocPayload_(r));
  const candidates = ['generateSignPdf', 'signGeneratePdf', 'createSignPdf', 'generateDocumentPdf'];
  const call = fhOpsUiB04ECallCandidates_(candidates, [r.documentId]);
  if (call && !call.skipped && !call.error) return fhOpsUiB04EOk_('PDF 생성 함수 호출 완료', { documentId: r.documentId, result: call });
  const created = fhOpsUiB05HCreatePdfInErp_(ctx, doc);
  
  if (String((doc.row && doc.row.documentType) || '').toUpperCase() === 'QR_SIGN') {
    return fhOpsUiB04EOk_('QR 문서 PDF 생성 완료 - QR 문서 별도 검토에서 보관 완료를 실행하세요.', created);
  }
  return fhOpsUiB04EOk_('PDF 생성 완료 - 보관 완료 대기로 이동합니다.', created);
}

function fhOpsUiB05HCreatePdfInErp_(ctx, doc) {
  const sh = doc.sheet;
  const map = doc.map;
  const r = doc.row;
  const documentId = String(r.documentId || '').trim();
  if (!documentId) throw new Error('documentId가 비어 있어 PDF를 생성할 수 없습니다.');
  const now = new Date();
  const tz = Session.getScriptTimeZone() || 'Asia/Seoul';
  const ymd = Utilities.formatDate(now, tz, 'yyyyMMdd');
  const yyyy = Utilities.formatDate(now, tz, 'yyyy');
  const mm = Utilities.formatDate(now, tz, 'MM');
  const dd = Utilities.formatDate(now, tz, 'dd');
  const documentNo = String(r.documentNo || documentId).trim();
  const fileName = documentNo + '.pdf';
  const folder = fhOpsUiB05HResolvePdfFolder_(ctx, r, yyyy, mm, dd);
  const tempDoc = DocumentApp.create('TMP_FEELHAUS_' + documentNo + '_' + ymd);
  let tempDocId = '';
  try {
    tempDocId = tempDoc.getId();
    const body = tempDoc.getBody();
    body.clear();
    body.appendParagraph('FEELHAUS').setHeading(DocumentApp.ParagraphHeading.HEADING1);
    body.appendParagraph(String(r.title || r.documentType || '문서')).setHeading(DocumentApp.ParagraphHeading.HEADING2);
    body.appendParagraph('문서번호: ' + documentNo);
    body.appendParagraph('문서ID: ' + documentId);
    body.appendParagraph('문서유형: ' + String(r.documentType || ''));
    body.appendParagraph('상태: ' + String(r.status || ''));
    body.appendParagraph('행사ID: ' + String(r.eventId || ''));
    body.appendParagraph('업체ID: ' + String(r.vendorId || ''));
    body.appendParagraph('고객ID: ' + String(r.customerId || ''));
    body.appendParagraph('판매ID: ' + String(r.saleId || ''));
    body.appendParagraph('설치ID: ' + String(r.installId || ''));
    body.appendParagraph('정산ID: ' + String(r.settlementId || ''));
    body.appendParagraph('서명자: ' + String(r.signedBy || r.signerName || r.customerName || ''));
    body.appendParagraph('서명일시: ' + fhOpsUiB05HFormatForPdf_(r.signedAt || r.signCompletedAt, tz));
    body.appendParagraph('PDF 생성일시: ' + Utilities.formatDate(now, tz, 'yyyy-MM-dd HH:mm:ss'));
    body.appendParagraph('');
    body.appendParagraph('서명 링크');
    body.appendParagraph(String(r.signUrl || r.qrUrl || ''));
    body.appendParagraph('');
    body.appendParagraph('메모');
    body.appendParagraph(String(r.notes || r.memo || ''));
    tempDoc.saveAndClose();
    SpreadsheetApp.flush();
    Utilities.sleep(700);

    const pdfBlob = fhOpsUiB06A3ExportDocPdfBlob_(tempDocId, fileName);
    const pdfFile = folder.createFile(pdfBlob);
    fhOpsUiB06A3TrashTempDocSafe_(tempDocId);

    const pdfFileId = pdfFile.getId();
    const pdfFileUrl = pdfFile.getUrl();
    const archivePath = '/' + yyyy + '/' + mm + '/' + dd + '/' + fileName;
    const updates = { pdfFileId: pdfFileId, pdfFileUrl: pdfFileUrl, archivePath: archivePath, archiveFileName: fileName, pdfGeneratedAt: now, pdfGeneratedBy: ctx.userEmail, status: 'PDF_COMPLETED', statusReason: 'PDF 생성 완료', updatedAt: now, updatedBy: ctx.userEmail };
    if (!String(r.archiveFolderId || '').trim()) updates.archiveFolderId = folder.getId();
    Object.keys(updates).forEach(function(k){ if (map[k] != null) sh.getRange(doc.rowIndex, map[k] + 1).setValue(updates[k]); });
    SpreadsheetApp.flush();
    return Object.assign(fhOpsUiB04EDocPayload_(Object.assign({}, r, updates)), { pdfFileId: pdfFileId, pdfFileUrl: pdfFileUrl, archivePath: archivePath, archiveFileName: fileName, archiveFolderId: folder.getId(), generatedBy: ctx.userEmail, engine: 'ERP_EMBEDDED_PDF_B06A3_EXPORT_FALLBACK' });
  } catch (err) {
    fhOpsUiB06A3TrashTempDocSafe_(tempDocId);
    throw err;
  }
}

function fhOpsUiB06A3ExportDocPdfBlob_(docId, fileName) {
  const id = String(docId || '').trim();
  if (!id) throw new Error('임시 문서 ID가 없어 PDF 변환을 할 수 없습니다.');
  const name = String(fileName || 'FEELHAUS_DOCUMENT.pdf').trim() || 'FEELHAUS_DOCUMENT.pdf';
  const attempts = [];

  try {
    const file = fhOpsUiB06A3Retry_('DriveApp.getFileById/getAs', function(){ return DriveApp.getFileById(id); }, 3, 700);
    const blob = fhOpsUiB06A3Retry_('DriveApp.getAs PDF', function(){ return file.getAs(MimeType.PDF); }, 3, 700);
    return blob.setName(name);
  } catch (driveErr) {
    attempts.push({ engine: 'DriveApp', message: (driveErr && driveErr.message) || String(driveErr) });
  }

  try {
    const url = 'https://docs.google.com/document/d/' + encodeURIComponent(id) + '/export?format=pdf';
    const response = fhOpsUiB06A3Retry_('UrlFetch export pdf', function(){
      return UrlFetchApp.fetch(url, {
        method: 'get',
        headers: { Authorization: 'Bearer ' + ScriptApp.getOAuthToken() },
        muteHttpExceptions: true
      });
    }, 3, 900);
    const code = response.getResponseCode();
    if (code < 200 || code >= 300) throw new Error('PDF export HTTP ' + code + ': ' + response.getContentText().slice(0, 300));
    return response.getBlob().setName(name);
  } catch (fetchErr) {
    attempts.push({ engine: 'UrlFetchExport', message: (fetchErr && fetchErr.message) || String(fetchErr) });
  }

  throw new Error('PDF 변환 실패: ' + JSON.stringify(attempts));
}

function fhOpsUiB06A3Retry_(label, fn, maxTry, sleepMs) {
  let lastErr = null;
  const count = Math.max(1, Number(maxTry || 1));
  for (let i = 0; i < count; i++) {
    try { return fn(); } catch (err) { lastErr = err; if (i < count - 1) Utilities.sleep(Number(sleepMs || 500)); }
  }
  throw new Error(String(label || 'retry') + ' 실패: ' + ((lastErr && lastErr.message) || String(lastErr)));
}

function fhOpsUiB06A3TrashTempDocSafe_(docId) {
  const id = String(docId || '').trim();
  if (!id) return;
  try { DriveApp.getFileById(id).setTrashed(true); } catch (e) {}
}

function fhOpsUiB05HResolvePdfFolder_(ctx, row, yyyy, mm, dd) {
  const fromRow = String(row.archiveFolderId || '').trim();
  if (fromRow) { try { return DriveApp.getFolderById(fromRow); } catch (e) {} }
  const configIds = ['PDF_FOLDER_ID', 'SIGN_PDF_FOLDER_ID', 'ARCHIVE_FOLDER_ID', 'DRIVE_ARCHIVE_FOLDER_ID'];
  for (var i = 0; i < configIds.length; i++) {
    const v = fhOpsUiB05HGetConfigValue_(configIds[i]);
    if (v) { try { return DriveApp.getFolderById(v); } catch (e2) {} }
  }
  const root = DriveApp.getRootFolder();
  return fhOpsUiB05HGetOrCreateChildFolder_(fhOpsUiB05HGetOrCreateChildFolder_(fhOpsUiB05HGetOrCreateChildFolder_(root, 'FEELHAUS_PDF_ARCHIVE'), yyyy), mm + '-' + dd);
}

function fhOpsUiB05HGetOrCreateChildFolder_(parent, name) {
  const it = parent.getFoldersByName(name);
  if (it.hasNext()) return it.next();
  return parent.createFolder(name);
}

function fhOpsUiB05HGetConfigValue_(key) {
  try {
    const ss = SpreadsheetApp.openById(FH_OPS_UI_B03.SETUP_DB_ID);
    const sh = ss.getSheetByName(FH_OPS_UI_B03.CONFIG_SHEET_NAME);
    if (!sh || sh.getLastRow() < 2) return '';
    const values = sh.getDataRange().getValues();
    const headers = values[0].map(function(h){ return String(h || '').trim(); });
    const kIdx = headers.indexOf('key') >= 0 ? headers.indexOf('key') : (headers.indexOf('configKey') >= 0 ? headers.indexOf('configKey') : 0);
    const vIdx = headers.indexOf('value') >= 0 ? headers.indexOf('value') : (headers.indexOf('configValue') >= 0 ? headers.indexOf('configValue') : 1);
    for (var i = 1; i < values.length; i++) if (String(values[i][kIdx] || '').trim() === key) return String(values[i][vIdx] || '').trim();
  } catch (e) {}
  return '';
}

function fhOpsUiB05HFormatForPdf_(value, tz) {
  if (value instanceof Date) return Utilities.formatDate(value, tz || 'Asia/Seoul', 'yyyy-MM-dd HH:mm:ss');
  return String(value || '');
}

function fhOpsUiB04EArchiveStatus_(ctx, data) {
  const doc = fhOpsUiB04EFindDoc_(ctx, String((data || {}).documentId || '').trim());
  const r = doc.row;
  const st = String(r.status || '').toUpperCase();
  const ast = String(r.archiveStatus || '').toUpperCase();
  const archived = st === 'ARCHIVED' || ast === 'ARCHIVED' || !!String(r.archivedAt || '').trim();
  if (archived) return fhOpsUiB04EOk_('정상 차단: 이미 보관 완료된 잠금 문서입니다. 수정이 필요하면 재오픈 요청을 진행하세요.', fhOpsUiB04EDocPayload_(r));
  const pdfReady = !!String(r.pdfFileId || r.pdfFileUrl || r.archivePath || r.archiveFileName || '').trim() || st === 'PDF_COMPLETED';
  if (!pdfReady) return fhOpsUiB04EFail_('PDF 생성 전 문서는 보관 완료 처리할 수 없습니다.', 'PDF_NOT_READY', fhOpsUiB04EDocPayload_(r));
  const now = new Date();
  const updates = { status: 'ARCHIVED', statusReason: '보관 완료', archiveStatus: 'ARCHIVED', archivedAt: now, archivedBy: ctx.userEmail, updatedAt: now, updatedBy: ctx.userEmail };
  Object.keys(updates).forEach(function(k){ if (doc.map[k] != null) doc.sheet.getRange(doc.rowIndex, doc.map[k] + 1).setValue(updates[k]); });
  return fhOpsUiB04EOk_('보관 완료 상태로 갱신했습니다. 이후 문서는 잠금 처리됩니다.', { documentId: r.documentId, status: 'ARCHIVED', archiveStatus: 'ARCHIVED' });
}

function fhOpsUiB04ECallExisting_(action, candidates, data) {
  const result = fhOpsUiB04ECallCandidates_(candidates, [data || {}]);
  if (result && result.skipped) {
    return fhOpsUiB04EFail_(action + ' 연결 가능한 기존 함수가 없습니다.', 'ACTION_NOT_CONNECTED', { action: action, result: result });
  }
  return fhOpsUiB04EOk_(action + ' 기존 함수 호출 완료', { action: action, result: result });
}

function fhOpsUiB04GCreateSettlement_(ctx, data) {
  const settlementId = String((data && data.settlementId) || '').trim();
  if (settlementId) {
    const existingDoc = fhOpsUiB04EFindDocByLink_(ctx, 'SETTLEMENT_CONFIRM', 'settlementId', settlementId);
    if (existingDoc) {
      return fhOpsUiB04EOk_('정산확인서 기존 문서가 있어 정산 생성은 재실행하지 않습니다.', {
        settlementId: settlementId,
        documentId: existingDoc.row.documentId || '',
        documentNo: existingDoc.row.documentNo || '',
        status: existingDoc.row.status || '',
        skippedCreate: true
      });
    }
  }
  const vendorId = String((data && data.vendorId) || '').trim();
  const closingMonth = String((data && (data.closingMonth || data.settlementMonth)) || '').trim();
  if (!vendorId || !closingMonth) {
    return fhOpsUiB04EFail_('정산 생성은 vendorId와 정산월(closingMonth)이 필요합니다. B05 목록형에서 정산대상을 선택하도록 보정합니다.', 'SETTLEMENT_INPUT_REQUIRED', {
      required: ['vendorId', 'closingMonth'],
      received: { saleId: data && data.saleId || '', settlementId: settlementId, vendorId: vendorId, closingMonth: closingMonth }
    });
  }
  const result = fhOpsUiB04ECallCandidates_(['createMonthlyClosingFromErp'], [{ vendorId: vendorId, closingMonth: closingMonth, saleId: data && data.saleId || '', note: data && data.reason || '' }]);
  if (result && result.skipped) return fhOpsUiB04EFail_('정산 생성 함수 연결 실패', 'CREATE_SETTLEMENT_NOT_CONNECTED', result);
  return fhOpsUiB04EOk_('정산 생성 함수 호출 완료', { result: result });
}

function fhOpsUiB04GRequestSettlementApproval_(ctx, data) {
  const settlementId = String((data && data.settlementId) || '').trim();
  if (!settlementId) return fhOpsUiB04EFail_('settlementId가 필요합니다.', 'SETTLEMENT_ID_REQUIRED', data || {});
  const existingDoc = fhOpsUiB04EFindDocByLink_(ctx, 'SETTLEMENT_CONFIRM', 'settlementId', settlementId);
  if (existingDoc && String(existingDoc.row.status || '').toUpperCase() === 'ARCHIVED') {
    return fhOpsUiB04EOk_('정산확인서가 이미 보관 완료되어 승인 요청을 재실행하지 않습니다.', {
      settlementId: settlementId, documentId: existingDoc.row.documentId || '', documentNo: existingDoc.row.documentNo || '', status: existingDoc.row.status || '', skippedRequest: true
    });
  }
  const direct = fhOpsUiB05HRequestSettlementApprovalDirect_(ctx, data);
  return fhOpsUiB04EOk_('정산 승인요청 처리 완료', direct);
}

function fhOpsUiB04GActSettlement_(ctx, data, nextAction) {
  const settlementId = String((data && data.settlementId) || '').trim();
  if (!settlementId) return fhOpsUiB04EFail_('settlementId가 필요합니다.', 'SETTLEMENT_ID_REQUIRED', data || {});
  const existingDoc = fhOpsUiB04EFindDocByLink_(ctx, 'SETTLEMENT_CONFIRM', 'settlementId', settlementId);
  if (existingDoc && String(existingDoc.row.status || '').toUpperCase() === 'ARCHIVED') {
    return fhOpsUiB04EOk_('정산확인서가 이미 보관 완료되어 ' + (nextAction === 'PAID' ? '지급완료' : '승인') + '을 재실행하지 않습니다.', {
      settlementId: settlementId, documentId: existingDoc.row.documentId || '', documentNo: existingDoc.row.documentNo || '', status: existingDoc.row.status || '', skippedAction: nextAction
    });
  }
  const direct = fhOpsUiB05HActSettlementApprovalDirect_(ctx, data, nextAction);
  if (direct && direct.ok === false) return direct;
  return fhOpsUiB04EOk_('정산 ' + (nextAction === 'PAID' ? '지급완료' : '승인') + ' 처리 완료', direct);
}

function fhOpsUiB05HSettlementStepHeaders_() {
  return ['stepId','closingId','vendorId','approvalStage','actionStatus','requestedAmount','approvedAmount','requestedBy','actedBy','note','createdAt','actedAt'];
}

function fhOpsUiB05HEnsureSheet_(ss, name, headers) {
  let sh = ss.getSheetByName(name);
  if (!sh) sh = ss.insertSheet(name);
  if (sh.getLastRow() < 1 || sh.getLastColumn() < 1 || String(sh.getRange(1,1).getValue() || '').trim() === '') {
    sh.getRange(1, 1, 1, headers.length).setValues([headers]);
  } else {
    const map = fhOpsUiB04EHeaderMap_(sh);
    const missing = headers.filter(function(h){ return map[h] == null; });
    if (missing.length) sh.getRange(1, sh.getLastColumn() + 1, 1, missing.length).setValues([missing]);
  }
  return sh;
}

function fhOpsUiB05HNow_() { return new Date(); }
function fhOpsUiB05HStepId_() { return 'SAP-' + Utilities.formatDate(new Date(), Session.getScriptTimeZone() || 'Asia/Seoul', 'yyyyMMddHHmmss') + '-' + Math.floor(Math.random() * 1000); }

function fhOpsUiB05HFindSettlementRow_(ctx, settlementId) {
  const names = ['ERP_정산관리', 'Settlements', 'ERP_Settlements', 'MonthlyClosings'];
  for (var n = 0; n < names.length; n++) {
    const sh = ctx.masterDb.getSheetByName(names[n]);
    if (!sh || sh.getLastRow() < 2) continue;
    const map = fhOpsUiB04EHeaderMap_(sh);
    const idKeys = ['settlementId','closingId','id'];
    for (var k = 0; k < idKeys.length; k++) {
      const key = idKeys[k];
      if (map[key] == null) continue;
      const vals = sh.getRange(2, 1, sh.getLastRow()-1, sh.getLastColumn()).getValues();
      for (var i = vals.length - 1; i >= 0; i--) {
        if (String(vals[i][map[key]] || '').trim() === String(settlementId)) {
          const row = {};
          Object.keys(map).forEach(function(h){ row[h] = vals[i][map[h]]; });
          return { sheet: sh, map: map, rowIndex: i + 2, row: row, idKey: key, sheetName: names[n] };
        }
      }
    }
  }
  return null;
}

function fhOpsUiB05HUpdateRowByMap_(found, updates) {
  if (!found) return;
  Object.keys(updates).forEach(function(k){
    if (found.map[k] != null) found.sheet.getRange(found.rowIndex, found.map[k] + 1).setValue(updates[k]);
  });
}

function fhOpsUiB05HFindLatestStep_(ctx, settlementId) {
  const sh = ctx.masterDb.getSheetByName('SettlementApprovalSteps');
  if (!sh || sh.getLastRow() < 2) return null;
  const map = fhOpsUiB04EHeaderMap_(sh);
  if (map.closingId == null && map.settlementId == null) return null;
  const vals = sh.getRange(2, 1, sh.getLastRow()-1, sh.getLastColumn()).getValues();
  for (var i = vals.length - 1; i >= 0; i--) {
    const closingId = map.closingId != null ? vals[i][map.closingId] : vals[i][map.settlementId];
    if (String(closingId || '').trim() === String(settlementId)) {
      const row = {};
      Object.keys(map).forEach(function(h){ row[h] = vals[i][map[h]]; });
      return { sheet: sh, map: map, rowIndex: i + 2, row: row };
    }
  }
  return null;
}

function fhOpsUiB05HRequestSettlementApprovalDirect_(ctx, data) {
  const settlementId = String((data && data.settlementId) || '').trim();
  const found = fhOpsUiB05HFindSettlementRow_(ctx, settlementId);
  const existingStep = fhOpsUiB05HFindLatestStep_(ctx, settlementId);
  const now = fhOpsUiB05HNow_();
  const vendorId = String((found && (found.row.vendorId || found.row.vendorID)) || (data && data.vendorId) || '').trim();
  if (existingStep) {
    const st = String(existingStep.row.actionStatus || '').toUpperCase();
    if (st === 'REQUESTED' || st === 'APPROVAL_REQUESTED' || st === 'PENDING' || st === 'APPROVED' || st === 'PAID') {
      return { settlementId: settlementId, stepId: existingStep.row.stepId || '', reused: true, actionStatus: existingStep.row.actionStatus || '', settlementSheet: found && found.sheetName || '' };
    }
  }
  const sh = fhOpsUiB05HEnsureSheet_(ctx.masterDb, 'SettlementApprovalSteps', fhOpsUiB05HSettlementStepHeaders_());
  const map = fhOpsUiB04EHeaderMap_(sh);
  const rowObj = {
    stepId: fhOpsUiB05HStepId_(), closingId: settlementId, vendorId: vendorId,
    approvalStage: 'HQ_APPROVAL', actionStatus: 'REQUESTED', requestedAmount: '', approvedAmount: '',
    requestedBy: ctx.userEmail, actedBy: '', note: (data && data.reason) || '운영버튼 승인요청', createdAt: now, actedAt: ''
  };
  const headers = Object.keys(map);
  sh.appendRow(headers.map(function(h){ return rowObj[h] == null ? '' : rowObj[h]; }));
  fhOpsUiB05HUpdateRowByMap_(found, { status:'APPROVAL_REQUESTED', settlementStatus:'APPROVAL_REQUESTED', approvalStatus:'REQUESTED', updatedAt:now, updatedBy:ctx.userEmail });
  return { settlementId: settlementId, stepId: rowObj.stepId, created: true, actionStatus: 'REQUESTED', settlementSheet: found && found.sheetName || '' };
}

function fhOpsUiB05HActSettlementApprovalDirect_(ctx, data, nextAction) {
  const settlementId = String((data && data.settlementId) || '').trim();
  const found = fhOpsUiB05HFindSettlementRow_(ctx, settlementId);
  let step = fhOpsUiB05HFindLatestStep_(ctx, settlementId);
  if (!step) {
    if (nextAction !== 'APPROVED') return fhOpsUiB04EFail_('승인단계 요청이 먼저 필요합니다.', 'APPROVAL_STEP_REQUIRED', { settlementId: settlementId, nextAction: nextAction });
    fhOpsUiB05HRequestSettlementApprovalDirect_(ctx, data);
    step = fhOpsUiB05HFindLatestStep_(ctx, settlementId);
    if (!step) return fhOpsUiB04EFail_('승인단계 생성 후 조회에 실패했습니다.', 'APPROVAL_STEP_CREATE_FAILED', { settlementId: settlementId });
  }
  const now = fhOpsUiB05HNow_();
  const status = nextAction === 'PAID' ? 'PAID' : 'APPROVED';
  const updates = { actionStatus: status, actedBy: ctx.userEmail, note: (data && data.reason) || ('운영버튼 ' + status), actedAt: now };
  fhOpsUiB05HUpdateRowByMap_(step, updates);
  if (nextAction === 'PAID') {
    fhOpsUiB05HUpdateRowByMap_(found, { status:'PAID', settlementStatus:'PAID', paymentStatus:'PAID', payoutStatus:'PAID', paidAt:now, paidBy:ctx.userEmail, updatedAt:now, updatedBy:ctx.userEmail });
  } else {
    fhOpsUiB05HUpdateRowByMap_(found, { status:'APPROVED', settlementStatus:'APPROVED', approvalStatus:'APPROVED', approvedAt:now, approvedBy:ctx.userEmail, updatedAt:now, updatedBy:ctx.userEmail });
  }
  return { settlementId: settlementId, stepId: step.row.stepId || '', actionStatus: status, settlementSheet: found && found.sheetName || '' };
}

function fhOpsUiB04GFindLatestApprovalStep_(ctx, settlementId) {
  const sh = fhOpsUiB04EGetSheet_(ctx.master, ['SettlementApprovalSteps'], false);
  if (!sh) return null;
  const map = fhOpsUiB04EHeaderMap_(sh);
  const vals = sh.getDataRange().getDisplayValues();
  for (var i = vals.length - 1; i >= 1; i--) {
    const row = vals[i];
    const closingId = map.closingId != null ? row[map.closingId] : '';
    if (String(closingId) === String(settlementId)) {
      return {
        stepId: map.stepId != null ? row[map.stepId] : '',
        closingId: closingId,
        actionStatus: map.actionStatus != null ? row[map.actionStatus] : ''
      };
    }
  }
  return null;
}

function fhOpsUiB05MNormalizeRole_(role) {
  const r = String(role || '').trim();
  const map = {'영업직원':'STAFF_SALES','판매담당':'STAFF_SALES','판매직원':'STAFF_SALES','설치담당':'STAFF_INSTALL','설치직원':'STAFF_INSTALL','A/S담당':'STAFF_AS','AS담당':'STAFF_AS','업체대표':'VENDOR_OWNER','업체관리자':'VENDOR_MANAGER','회계담당':'ACCOUNTING_MANAGER','정산담당':'ACCOUNTING_MANAGER','본사관리자':'HQ_ADMIN','본사매니저':'HQ_MANAGER','조회전용':'VIEWER'};
  return map[r] || r || 'VIEWER';
}
function fhOpsUiB05MSessionEmail_() { try { return String(Session.getActiveUser().getEmail() || '').trim(); } catch (err) { return ''; } }
function fhOpsUiB05MFindEmployeeByEmail_(masterDb, email) {
  const sh = fhOpsUiB04EGetSheet_(masterDb, ['Employees','ERP_직원관리','Users','ERP_사용자관리'], false);
  if (!sh || sh.getLastRow() < 2) return null;
  const map = fhOpsUiB04EHeaderMap_(sh);
  if (map.email == null) return null;
  const values = sh.getRange(2, 1, sh.getLastRow() - 1, sh.getLastColumn()).getValues();
  const target = String(email || '').trim().toLowerCase();
  for (var i = 0; i < values.length; i++) {
    const row = values[i];
    if (String(row[map.email] || '').trim().toLowerCase() !== target) continue;
    const status = map.status != null ? String(row[map.status] || '').trim().toUpperCase() : 'ACTIVE';
    const active = status === '' || status === 'ACTIVE' || status === '사용중';
    return { employeeId: map.employeeId != null ? row[map.employeeId] : (map.userId != null ? row[map.userId] : ''), userName: map.name != null ? row[map.name] : (map.userName != null ? row[map.userName] : ''), email: row[map.email], role: map.role != null ? fhOpsUiB05MNormalizeRole_(row[map.role]) : 'VIEWER', vendorId: map.vendorId != null ? row[map.vendorId] : (map.companyId != null ? row[map.companyId] : ''), eventScope: map.eventScope != null ? row[map.eventScope] : (map.eventId != null ? row[map.eventId] : ''), menuScope: map.menuScope != null ? row[map.menuScope] : '', status: status || 'ACTIVE', isActive: active };
  }
  return null;
}

function fhOpsUiB05PGetManualEmail_(payload) {payload=payload||{};var keys=['operatorEmail','employeeEmail','manualEmployeeEmail','manualEmail','actorEmail','userEmail','email','fhOpsOperatorEmail','fhOpsEmployeeEmail'];for(var i=0;i<keys.length;i++){var v=String(payload[keys[i]]||'').trim();if(v)return v;}return '';}
function fhOpsUiB05PFindLimitedDefaultEmployee_(masterDb){return null;} // B06G: 개인/테스트 이메일 자동기본값 사용 금지
function fhOpsUiB05PAuthDebugPayload_(payload){payload=payload||{};var keys=['operatorEmail','employeeEmail','manualEmployeeEmail','manualEmail','actorEmail','userEmail','email','fhOpsOperatorEmail','fhOpsEmployeeEmail'];var out={};for(var i=0;i<keys.length;i++)out[keys[i]]=String(payload[keys[i]]||'').trim();return{rawPayloadKeys:Object.keys(payload),rawPayloadPreview:out};}

function fhOpsUiB06GetSessionToken_(payload) {
  payload = payload || {};
  var keys = ['sessionToken','fhOpsSessionToken','employeeSessionToken','authToken'];
  for (var i = 0; i < keys.length; i++) { var v = String(payload[keys[i]] || '').trim(); if (v) return v; }
  return '';
}
function fhOpsUiB06AuthHeaders_() { return ['authId','employeeId','email','loginId','passwordHash','passwordSalt','status','mustChangePassword','failedCount','lockedUntil','lastLoginAt','createdAt','createdBy','updatedAt','updatedBy','memo']; }
function fhOpsUiB06SessionHeaders_() { return ['sessionId','sessionToken','employeeId','email','role','vendorId','eventScope','status','issuedAt','expiresAt','lastSeenAt','createdAt','updatedAt','memo']; }
function fhOpsUiB06EnsureSheet_(ss, name, headers) {
  var sh = ss.getSheetByName(name);
  if (!sh) sh = ss.insertSheet(name);
  if (sh.getLastRow() === 0) sh.getRange(1,1,1,headers.length).setValues([headers]);
  var map = fhOpsUiB04EHeaderMap_(sh);
  headers.forEach(function(h){ if (map[h] == null) { sh.getRange(1, sh.getLastColumn()+1).setValue(h); map[h] = sh.getLastColumn()-1; } });
  return sh;
}
function fhOpsUiB06Hash_(password, salt) {
  var bytes = Utilities.computeDigest(Utilities.DigestAlgorithm.SHA_256, String(salt || '') + '|' + String(password || ''), Utilities.Charset.UTF_8);
  return bytes.map(function(b){ var v=(b<0?b+256:b).toString(16); return v.length===1?'0'+v:v; }).join('');
}
function fhOpsUiB06RandomToken_() { return Utilities.getUuid().replace(/-/g,'') + String(new Date().getTime()); }
function fhOpsUiB06GetMasterDb_() {
  var setup = SpreadsheetApp.openById(FH_OPS_UI_B03.SETUP_DB_ID);
  var configSheet = setup.getSheetByName(FH_OPS_UI_B03.CONFIG_SHEET_NAME);
  if (!configSheet) throw new Error('SystemConfig 시트를 찾을 수 없습니다.');
  var config = fhOpsUiB04EReadKeyValue_(configSheet);
  var masterDbId = String(config.FEELHAUS_DB_MASTER_ID || config.MASTER_DB_ID || config.DB_MASTER_ID || '').trim();
  if (!masterDbId) throw new Error('SystemConfig에서 FEELHAUS_DB_MASTER ID를 찾을 수 없습니다.');
  return { setupDb: setup, config: config, masterDbId: masterDbId, masterDb: SpreadsheetApp.openById(masterDbId) };
}
function fhOpsUiB06FindAuthByEmail_(sheet, email) {
  if (!sheet || sheet.getLastRow() < 2) return null;
  var map = fhOpsUiB04EHeaderMap_(sheet);
  if (map.email == null) return null;
  var vals = sheet.getRange(2,1,sheet.getLastRow()-1,sheet.getLastColumn()).getValues();
  var target = String(email || '').trim().toLowerCase();
  for (var i=0;i<vals.length;i++) if (String(vals[i][map.email] || '').trim().toLowerCase() === target) return { sheet: sheet, rowIndex: i+2, row: vals[i], map: map };
  return null;
}
function fhOpsUiB06FindSessionByToken_(sheet, token) {
  if (!sheet || sheet.getLastRow() < 2) return null;
  var map = fhOpsUiB04EHeaderMap_(sheet);
  if (map.sessionToken == null) return null;
  var vals = sheet.getRange(2,1,sheet.getLastRow()-1,sheet.getLastColumn()).getValues();
  for (var i=0;i<vals.length;i++) if (String(vals[i][map.sessionToken] || '').trim() === String(token || '').trim()) return { sheet: sheet, rowIndex: i+2, row: vals[i], map: map };
  return null;
}
function fhOpsUiB06SetRow_(found, updates) { if (!found) return; Object.keys(updates || {}).forEach(function(k){ if (found.map[k] != null) found.sheet.getRange(found.rowIndex, found.map[k]+1).setValue(updates[k]); }); }
function fhOpsUiB06Login(payload) {
  payload = payload || {};
  var email = String(payload.email || payload.loginId || '').trim().toLowerCase();
  var password = String(payload.password || payload.pin || '').trim();
  if (!email) return fhOpsUiB04EFail_('이메일을 입력하세요.', 'LOGIN_EMAIL_REQUIRED', {});
  if (!password) return fhOpsUiB04EFail_('비밀번호를 입력하세요.', 'LOGIN_PASSWORD_REQUIRED', { email: email });
  var env = fhOpsUiB06GetMasterDb_();
  var employee = fhOpsUiB05MFindEmployeeByEmail_(env.masterDb, email);
  if (!employee || !employee.isActive) return fhOpsUiB04EFail_('등록된 활성 직원이 아닙니다.', 'EMPLOYEE_NOT_ACTIVE', { email: email });
  var authSh = fhOpsUiB06EnsureSheet_(env.masterDb, 'EmployeeAuth', fhOpsUiB06AuthHeaders_());
  var sessSh = fhOpsUiB06EnsureSheet_(env.masterDb, 'EmployeeSessions', fhOpsUiB06SessionHeaders_());
  var auth = fhOpsUiB06FindAuthByEmail_(authSh, email);
  var now = new Date();
  var user = 'ERP_LOGIN';
  if (!auth) {
    if (password !== 'FH@2026!') return fhOpsUiB04EFail_('초기 비밀번호가 맞지 않습니다. 초기비밀번호는 FH@2026! 입니다.', 'INITIAL_PASSWORD_REQUIRED', { email: email });
    var salt = fhOpsUiB06RandomToken_().substring(0,16);
    var hash = fhOpsUiB06Hash_(password, salt);
    var authMap = fhOpsUiB04EHeaderMap_(authSh);
    var rowObj = { authId:'AUTH-' + Utilities.formatDate(now, Session.getScriptTimeZone() || 'Asia/Seoul', 'yyyyMMddHHmmss') + '-' + Math.floor(Math.random()*1000), employeeId:employee.employeeId, email:email, loginId:email, passwordHash:hash, passwordSalt:salt, status:'ACTIVE', mustChangePassword:'Y', failedCount:0, lockedUntil:'', lastLoginAt:now, createdAt:now, createdBy:user, updatedAt:now, updatedBy:user, memo:'B06 최초 로그인 자동생성' };
    authSh.appendRow(Object.keys(authMap).map(function(h){ return rowObj[h] == null ? '' : rowObj[h]; }));
    auth = fhOpsUiB06FindAuthByEmail_(authSh, email);
  } else {
    var map=auth.map, row=auth.row;
    var status = map.status != null ? String(row[map.status] || '').trim().toUpperCase() : 'ACTIVE';
    if (status !== 'ACTIVE') return fhOpsUiB04EFail_('로그인 계정이 비활성 상태입니다.', 'AUTH_INACTIVE', { email: email, status: status });
    var salt2 = map.passwordSalt != null ? String(row[map.passwordSalt] || '') : '';
    var hash2 = map.passwordHash != null ? String(row[map.passwordHash] || '') : '';
    if (!salt2 || !hash2 || fhOpsUiB06Hash_(password, salt2) !== hash2) {
      var fc = map.failedCount != null ? Number(row[map.failedCount] || 0) + 1 : 1;
      fhOpsUiB06SetRow_(auth, { failedCount:fc, updatedAt:now, updatedBy:user });
      return fhOpsUiB04EFail_('비밀번호가 맞지 않습니다.', 'LOGIN_FAILED', { email: email, failedCount: fc });
    }
    fhOpsUiB06SetRow_(auth, { failedCount:0, lastLoginAt:now, updatedAt:now, updatedBy:user });
  }
  var token = fhOpsUiB06RandomToken_();
  var expires = new Date(now.getTime() + 12*60*60*1000);
  var sessMap = fhOpsUiB04EHeaderMap_(sessSh);
  var sessObj = { sessionId:'SES-' + Utilities.formatDate(now, Session.getScriptTimeZone() || 'Asia/Seoul', 'yyyyMMddHHmmss') + '-' + Math.floor(Math.random()*1000), sessionToken:token, employeeId:employee.employeeId, email:email, role:employee.role, vendorId:employee.vendorId, eventScope:employee.eventScope, status:'ACTIVE', issuedAt:now, expiresAt:expires, lastSeenAt:now, createdAt:now, updatedAt:now, memo:'B06 ERP 자체 로그인' };
  sessSh.appendRow(Object.keys(sessMap).map(function(h){ return sessObj[h] == null ? '' : sessObj[h]; }));
  return fhOpsUiB04EOk_('로그인 성공', { sessionToken:token, expiresAt:expires, userEmail:email, employeeId:employee.employeeId, employeeName:employee.userName, role:employee.role, vendorId:employee.vendorId, eventScope:employee.eventScope, authMode:'ERP_SESSION_TOKEN', mustChangePassword:'Y' });
}
function fhOpsUiB06Logout(payload) {
  var token = fhOpsUiB06GetSessionToken_(payload || {});
  if (!token) return fhOpsUiB04EOk_('로그아웃 처리 완료', { loggedOut:false });
  var env = fhOpsUiB06GetMasterDb_();
  var sh = fhOpsUiB06EnsureSheet_(env.masterDb, 'EmployeeSessions', fhOpsUiB06SessionHeaders_());
  var found = fhOpsUiB06FindSessionByToken_(sh, token);
  if (found) fhOpsUiB06SetRow_(found, { status:'LOGGED_OUT', lastSeenAt:new Date(), updatedAt:new Date() });
  return fhOpsUiB04EOk_('로그아웃 처리 완료', { loggedOut:!!found });
}
function fhOpsUiB06ResolveSession_(masterDb, token) {
  token = String(token || '').trim();
  if (!token) return null;
  var sh = fhOpsUiB04EGetSheet_(masterDb, ['EmployeeSessions'], false);
  var found = fhOpsUiB06FindSessionByToken_(sh, token);
  if (!found) return null;
  var map=found.map, row=found.row;
  var status = map.status != null ? String(row[map.status] || '').trim().toUpperCase() : 'ACTIVE';
  var exp = map.expiresAt != null ? row[map.expiresAt] : '';
  var expDate = exp instanceof Date ? exp : new Date(exp);
  if (status !== 'ACTIVE' || isNaN(expDate.getTime()) || expDate.getTime() < new Date().getTime()) return null;
  var email = map.email != null ? String(row[map.email] || '').trim().toLowerCase() : '';
  var employee = fhOpsUiB05MFindEmployeeByEmail_(masterDb, email);
  if (!employee || !employee.isActive) return null;
  fhOpsUiB06SetRow_(found, { lastSeenAt:new Date(), updatedAt:new Date() });
  return { userEmail:email, sessionEmail:email, operatorEmail:email, authMode:'ERP_SESSION_TOKEN', employee:employee, role:employee.role || 'VIEWER', employeeFound:true, sessionToken:token };
}
function fhOpsUiB06SetupAuthSheets() {
  var env = fhOpsUiB06GetMasterDb_();
  fhOpsUiB06EnsureSheet_(env.masterDb, 'EmployeeAuth', fhOpsUiB06AuthHeaders_());
  fhOpsUiB06EnsureSheet_(env.masterDb, 'EmployeeSessions', fhOpsUiB06SessionHeaders_());
  return fhOpsUiB04EOk_('B06 인증 시트 점검 완료', { sheets:['EmployeeAuth','EmployeeSessions'], masterDbId:env.masterDbId });
}

function fhOpsUiB05MResolveActor_(masterDb, payload) {
  payload = payload || {};
  var token = fhOpsUiB06GetSessionToken_(payload);
  var sessionActor = fhOpsUiB06ResolveSession_(masterDb, token);
  if (sessionActor) return sessionActor;
  const sessionEmail = fhOpsUiB05MSessionEmail_();
  const explicitRaw = payload._allowManualEmailAuth ? fhOpsUiB05PGetManualEmail_(payload) : '';
  var explicit = String(explicitRaw || '').trim().toLowerCase();
  let userEmail = explicit || String(sessionEmail || '').trim().toLowerCase();
  let authMode = explicit ? 'MANUAL_EMPLOYEE_EMAIL_LIMITED' : (sessionEmail ? 'SESSION_EMAIL' : 'UNKNOWN_SESSION');
  let operatorEmail = explicit || '';
  if (!userEmail) userEmail = 'UNKNOWN_USER';
  let employee = null;
  if (userEmail !== 'UNKNOWN_USER') employee = fhOpsUiB05MFindEmployeeByEmail_(masterDb, userEmail);
  let role = 'VIEWER';
  if (employee && employee.isActive) role = employee.role || 'VIEWER';
  return { userEmail:userEmail, sessionEmail:sessionEmail || 'UNKNOWN_USER', operatorEmail:operatorEmail, authMode:authMode, employee:employee, role:role, manualEmailReceived:explicit, employeeFound:!!(employee && employee.isActive), sessionToken:token || '' };
}
function fhOpsUiB05MAssertActionPermission_(ctx, action) {
  if (!ctx || !ctx.userEmail || ctx.userEmail === 'UNKNOWN_USER') {
    throw new Error('로그인이 필요합니다. 운영버튼 상단의 ERP 로그인에서 이메일/비밀번호로 로그인하세요.');
  }
  const role = fhOpsUiB05MNormalizeRole_(ctx.role || 'VIEWER');
  const manualMode = String(ctx.authMode || '') === 'MANUAL_EMPLOYEE_EMAIL_LIMITED';
  if (manualMode && (!ctx.employee || !ctx.employee.isActive)) {
    throw new Error('등록된 활성 직원이 아닙니다: ' + ctx.userEmail + ' / Employees.email, status=ACTIVE를 확인하세요.');
  }
  const actionCode = String(action || '').toUpperCase();
  const adminRoles = ['SUPER_ADMIN','HQ_ADMIN','HQ_MANAGER','ACCOUNTING_MANAGER'];
  const settlementSensitive = ['CREATE_SETTLEMENT','CREATE_SETTLEMENT_CONFIRM','REQUEST_SETTLEMENT_APPROVAL','APPROVE_SETTLEMENT','COMPLETE_PAYMENT','RUN_CONTROL_DIAG'];
  if (settlementSensitive.indexOf(actionCode) >= 0 && adminRoles.indexOf(role) < 0) {
    throw new Error('권한 없음: ' + role + ' 계정은 ' + actionCode + ' 작업을 실행할 수 없습니다.');
  }
  const staffAllowed = ['CREATE_CONTRACT_DOC','CREATE_INSTALL_CONFIRM','OPEN_SIGN_LINK','GENERATE_PDF','ARCHIVE_DOC'];
  if (['STAFF_SALES','STAFF_INSTALL','STAFF_AS','VIEWER'].indexOf(role) >= 0 && staffAllowed.indexOf(actionCode) < 0) {
    throw new Error('권한 없음: ' + role + ' 계정은 문서/서명/PDF/보관 작업만 허용됩니다.');
  }
  return true;
}

function fhOpsUiB04EContext_(payload) {
  const setup = SpreadsheetApp.openById(FH_OPS_UI_B03.SETUP_DB_ID);
  const configSheet = setup.getSheetByName(FH_OPS_UI_B03.CONFIG_SHEET_NAME);
  if (!configSheet) throw new Error('SystemConfig 시트를 찾을 수 없습니다.');
  const config = fhOpsUiB04EReadKeyValue_(configSheet);
  const masterDbId = String(config.FEELHAUS_DB_MASTER_ID || config.MASTER_DB_ID || config.DB_MASTER_ID || '').trim();
  if (!masterDbId) throw new Error('SystemConfig에서 FEELHAUS_DB_MASTER ID를 찾을 수 없습니다.');
  const masterDb = SpreadsheetApp.openById(masterDbId);
  const actor = fhOpsUiB05MResolveActor_(masterDb, payload || {});
  return { setupDb: setup, config: config, masterDbId: masterDbId, masterDb: masterDb, userEmail: actor.userEmail, sessionEmail: actor.sessionEmail, operatorEmail: actor.operatorEmail, authMode: actor.authMode, employee: actor.employee, role: actor.role };
}

function fhOpsUiB04EReadKeyValue_(sheet) {
  const values = sheet.getDataRange().getValues();
  if (values.length < 2) return {};
  const headers = values[0].map(function(h){ return String(h || '').trim(); });
  const keyIdx = (function(){ const a=['key','configKey','name']; for(var i=0;i<a.length;i++){ const x=headers.indexOf(a[i]); if(x>=0)return x;} return 0; })();
  const valIdx = (function(){ const a=['value','configValue','id']; for(var i=0;i<a.length;i++){ const x=headers.indexOf(a[i]); if(x>=0)return x;} return 1; })();
  const out = {};
  values.slice(1).forEach(function(row){ const k = String(row[keyIdx] || '').trim(); if (k) out[k] = row[valIdx]; });
  return out;
}

function fhOpsUiB04EGetSheet_(ss, names, required) {
  for (var i = 0; i < names.length; i++) { const sh = ss.getSheetByName(names[i]); if (sh) return sh; }
  if (required) throw new Error('시트를 찾을 수 없습니다: ' + names.join(' / '));
  return null;
}

function fhOpsUiB04EHeaderMap_(sheet) {
  const headers = sheet.getRange(1, 1, 1, sheet.getLastColumn()).getValues()[0];
  const map = {};
  headers.forEach(function(h, i){ const key = String(h || '').trim(); if (key) map[key] = i; });
  return map;
}

function fhOpsUiB04EReadRows_(ctx, names, limit) {
  const sh = fhOpsUiB04EGetSheet_(ctx.masterDb, names, false);
  if (!sh || sh.getLastRow() < 2) return [];
  const map = fhOpsUiB04EHeaderMap_(sh);
  const headers = Object.keys(map);
  const lastRow = sh.getLastRow();
  const start = Math.max(2, lastRow - (limit || 20) + 1);
  return sh.getRange(start, 1, lastRow - start + 1, sh.getLastColumn()).getValues().reverse().filter(function(row){ return row.some(function(v){ return String(v || '').trim() !== ''; }); }).map(function(row){ const o = {}; headers.forEach(function(h){ o[h] = row[map[h]]; }); return o; });
}

function fhOpsUiB04EFindDoc_(ctx, documentId) {
  const id = String(documentId || '').trim();
  if (!id) throw new Error('documentId가 필요합니다.');
  const sh = fhOpsUiB04EGetSheet_(ctx.masterDb, ['SIGN_Documents', 'Documents', 'SIGN_DOCUMENTS'], true);
  const map = fhOpsUiB04EHeaderMap_(sh);
  if (map.documentId == null) throw new Error('documentId 헤더가 없습니다.');
  const values = sh.getRange(2, 1, Math.max(sh.getLastRow()-1, 0), sh.getLastColumn()).getValues();
  for (var i = 0; i < values.length; i++) {
    if (String(values[i][map.documentId] || '').trim() === id) {
      const row = {};
      Object.keys(map).forEach(function(h){ row[h] = values[i][map[h]]; });
      return { sheet: sh, map: map, rowIndex: i + 2, row: row };
    }
  }
  throw new Error('documentId를 찾을 수 없습니다: ' + id);
}

function fhOpsUiB04EFindDocByLink_(ctx, documentType, idKey, idValue) {
  const sh = fhOpsUiB04EGetSheet_(ctx.masterDb, ['SIGN_Documents', 'Documents', 'SIGN_DOCUMENTS'], false);
  if (!sh || sh.getLastRow() < 2) return null;
  const map = fhOpsUiB04EHeaderMap_(sh);
  if (map.documentType == null || map[idKey] == null) return null;
  const values = sh.getRange(2, 1, sh.getLastRow()-1, sh.getLastColumn()).getValues();
  for (var i = values.length - 1; i >= 0; i--) {
    const typeOk = String(values[i][map.documentType] || '').trim().toUpperCase() === String(documentType).toUpperCase();
    const idOk = String(values[i][map[idKey]] || '').trim() === String(idValue || '').trim();
    if (typeOk && idOk) { const row = {}; Object.keys(map).forEach(function(h){ row[h] = values[i][map[h]]; }); return { row: row, rowIndex: i + 2 }; }
  }
  return null;
}

function fhOpsUiB04EDocPayload_(r) {
  return { documentId: r.documentId || '', documentNo: r.documentNo || '', documentType: r.documentType || '', status: r.status || '', statusReason: r.statusReason || '', signUrl: r.signUrl || r.qrUrl || '', pdfFileId: r.pdfFileId || '', pdfFileUrl: r.pdfFileUrl || '', archiveStatus: r.archiveStatus || '', archivePath: r.archivePath || '', archiveFileName: r.archiveFileName || '' };
}

function fhOpsUiB04EDocSummary_(rows) {
  const s = { total: rows.length, pdfReady: 0, archived: 0, signCompleted: 0, readyToSign: 0 };
  rows.forEach(function(r){ const st = String(r.status || '').toUpperCase(); if (st === 'ARCHIVED' || String(r.archiveStatus || '').toUpperCase() === 'ARCHIVED') s.archived++; if (st === 'PDF_COMPLETED' || st === 'ARCHIVED' || r.pdfFileId || r.pdfFileUrl) s.pdfReady++; if (st === 'SIGN_COMPLETED') s.signCompleted++; if (st === 'READY_TO_SIGN') s.readyToSign++; });
  return s;
}

function fhOpsUiB04ESettlementSummary_(rows) {
  const s = { total: rows.length, paid: 0, approved: 0, pending: 0 };
  rows.forEach(function(r){ const st = String(r.status || r.settlementStatus || '').toUpperCase(); const pay = String(r.paymentStatus || r.payoutStatus || '').toUpperCase(); if (st.indexOf('PAID') >= 0 || pay.indexOf('PAID') >= 0 || st.indexOf('지급') >= 0) s.paid++; if (st.indexOf('APPROVED') >= 0 || st.indexOf('승인') >= 0) s.approved++; if (st.indexOf('PENDING') >= 0 || st.indexOf('REQUEST') >= 0 || st.indexOf('대기') >= 0) s.pending++; });
  return s;
}

function fhOpsUiB04ESafeValue_(value) {
  if (value instanceof Date) {
    return Utilities.formatDate(value, Session.getScriptTimeZone() || 'Asia/Seoul', 'yyyy-MM-dd HH:mm:ss');
  }
  if (Array.isArray(value)) return value.map(function(v){ return fhOpsUiB04ESafeValue_(v); });
  if (value && typeof value === 'object') {
    const out = {};
    Object.keys(value).forEach(function(k){ out[k] = fhOpsUiB04ESafeValue_(value[k]); });
    return out;
  }
  if (value === undefined) return '';
  return value;
}

function fhOpsUiB04EOk_(message, data) {
  return { ok: true, message: message, data: fhOpsUiB04ESafeValue_(data || {}), errorCode: '', meta: { buildNo: 'OPS-UI-20260427-B06B', at: new Date().toISOString() } };
}

function fhOpsUiB04EFail_(message, errorCode, data) {
  return { ok: false, message: message, data: fhOpsUiB04ESafeValue_(data || {}), errorCode: errorCode || 'B05_ERROR', meta: { buildNo: 'OPS-UI-20260427-B06B', at: new Date().toISOString() } };
}

/**
 * ===== FEELHAUS OPS UI B05 LIST MODE =====
 * 직원이 ID를 직접 입력하지 않고 대상 목록에서 선택 실행한다.
 */
function fhOpsUiB05HetWorklists(payload) {
  try {
    const ctx = fhOpsUiB04EContext_(payload || {});
    const docs = fhOpsUiB04EReadRows_(ctx, ['SIGN_Documents', 'Documents', 'SIGN_DOCUMENTS'], 500);
    const sales = fhOpsUiB04EReadRows_(ctx, ['Sales', 'ERP_판매관리', 'ERP_Sales'], 500);
    const installs = fhOpsUiB04EReadRows_(ctx, ['Installs', 'ERP_설치관리', 'Installations'], 500);
    const settlements = fhOpsUiB04EReadRows_(ctx, ['ERP_정산관리', 'Settlements', 'ERP_Settlements'], 500);
    const docIndex = fhOpsUiB05HuildDocIndex_(docs);
    const contractTargets = fhOpsUiB05HuildContractTargets_(sales, docIndex).slice(0, 30);
    const installConfirmTargets = fhOpsUiB05HuildInstallTargets_(installs, docIndex).slice(0, 30);
    const settlementConfirmTargets = fhOpsUiB05HuildSettlementConfirmTargets_(settlements, docIndex).slice(0, 30);
    const pdfTargets = fhOpsUiB05HuildPdfTargets_(docs).slice(0, 30);
    const archiveTargets = fhOpsUiB05HuildArchiveTargets_(docs).slice(0, 30);
    const qrSignTargets = fhOpsUiB05HuildQrSignTargets_(docs).slice(0, 30);
    const settlementActionGroups = fhOpsUiB05HuildSettlementActionGroups_(settlements, docs);
    const settlementActionTargets = [].concat(settlementActionGroups.requestTargets || [], settlementActionGroups.approveTargets || [], settlementActionGroups.paymentTargets || []).slice(0, 30);
    return fhOpsUiB04EOk_('B06A 목록 자동조회 완료', {
      buildNo: 'v64-B06J34G',
      counts: { contractTargets: contractTargets.length, installConfirmTargets: installConfirmTargets.length, settlementConfirmTargets: settlementConfirmTargets.length, pdfTargets: pdfTargets.length, archiveTargets: archiveTargets.length, qrSignTargets: qrSignTargets.length, settlementRequestTargets: (settlementActionGroups.requestTargets || []).length, settlementApproveTargets: (settlementActionGroups.approveTargets || []).length, settlementPaymentTargets: (settlementActionGroups.paymentTargets || []).length, settlementActionTargets: settlementActionTargets.length },
      auth: { userEmail: ctx.userEmail, authMode: ctx.authMode, role: ctx.role, employeeId: ctx.employee && ctx.employee.employeeId ? ctx.employee.employeeId : '', employeeName: ctx.employee && ctx.employee.userName ? ctx.employee.userName : '' }, contractTargets: contractTargets, installConfirmTargets: installConfirmTargets, settlementConfirmTargets: settlementConfirmTargets, pdfTargets: pdfTargets, archiveTargets: archiveTargets, qrSignTargets: qrSignTargets, settlementRequestTargets: settlementActionGroups.requestTargets || [], settlementApproveTargets: settlementActionGroups.approveTargets || [], settlementPaymentTargets: settlementActionGroups.paymentTargets || [], settlementActionTargets: settlementActionTargets
    });
  } catch (err) { return fhOpsUiB04EFail_('B05H 목록 자동조회 실패: ' + ((err && err.message) || String(err)), 'B05H_WORKLIST_FAILED', { stack: err && err.stack ? err.stack : '' }); }
}
function fhOpsUiB05HuildDocIndex_(docs) {
  const out = {};
  (docs || []).forEach(function (d) {
    const type = String(d.documentType || '').trim().toUpperCase();
    ['saleId','installId','settlementId','contractId','requestId','approvalId'].forEach(function (key) {
      const id = String(d[key] || '').trim();
      if (type && id) out[type + '|' + key + '|' + id] = d;
    });
  });
  return out;
}
function fhOpsUiB05HasDoc_(idx, type, key, id) { return !!idx[String(type || '').toUpperCase() + '|' + key + '|' + String(id || '').trim()]; }
function fhOpsUiB05Pick_(row, keys) { for (var i=0;i<keys.length;i++){ const v=row&&row[keys[i]]; if(v!==undefined&&v!==null&&String(v).trim()!=='') return v; } return ''; }
function fhOpsUiB05HocStatus_(d) { return String((d && (d.status || d.documentStatus)) || '').trim().toUpperCase(); }
function fhOpsUiB05HocType_(d) { return String((d && d.documentType) || '').trim().toUpperCase(); }
function fhOpsUiB05IsArchivedDoc_(d) { const st = fhOpsUiB05HocStatus_(d); const ast = String((d && d.archiveStatus) || '').trim().toUpperCase(); return st === 'ARCHIVED' || ast === 'ARCHIVED' || !!String((d && d.archivedAt) || '').trim(); }
function fhOpsUiB05HasPdf_(d) { const st = fhOpsUiB05HocStatus_(d); return !!String((d && (d.pdfFileId || d.pdfFileUrl || d.archivePath || d.archiveFileName)) || '').trim() || st === 'PDF_COMPLETED' || st === 'ARCHIVED'; }
function fhOpsUiB05IsCancelStatus_(value) { const st = String(value || '').trim().toUpperCase(); return st.indexOf('CANCEL') >= 0 || st.indexOf('VOID') >= 0 || st.indexOf('취소') >= 0 || st.indexOf('삭제') >= 0; }
function fhOpsUiB05HuildContractTargets_(sales, idx) {
  return (sales || []).filter(function (s) {
    const saleId = String(fhOpsUiB05Pick_(s, ['saleId','id']) || '').trim();
    if (!saleId) return false;
    const st = String(fhOpsUiB05Pick_(s, ['status','saleStatus']) || '').toUpperCase();
    if (st.indexOf('CANCEL') >= 0 || st.indexOf('VOID') >= 0 || st.indexOf('취소') >= 0) return false;
    return !fhOpsUiB05HasDoc_(idx, 'CONTRACT', 'saleId', saleId);
  }).map(function (s) {
    return { action:'CREATE_CONTRACT_DOC', saleId:String(fhOpsUiB05Pick_(s,['saleId','id'])||'').trim(), customerId:fhOpsUiB05Pick_(s,['customerId']), customerName:fhOpsUiB05Pick_(s,['customerName','name','customer','clientName']), vendorId:fhOpsUiB05Pick_(s,['vendorId']), eventId:fhOpsUiB05Pick_(s,['eventId']), status:fhOpsUiB05Pick_(s,['status','saleStatus']), amount:fhOpsUiB05Pick_(s,['totalAmount','amount','saleAmount']), memo:'계약서 미생성 판매' };
  });
}
function fhOpsUiB05HuildInstallTargets_(installs, idx) {
  return (installs || []).filter(function (r) {
    const installId = String(fhOpsUiB05Pick_(r, ['installId','id']) || '').trim();
    if (!installId) return false;
    const st = String(fhOpsUiB05Pick_(r, ['status','installStatus']) || '').toUpperCase();
    const completed = st.indexOf('COMPLETED') >= 0 || st.indexOf('COMPLETE') >= 0 || st.indexOf('설치완료') >= 0 || st.indexOf('완료') >= 0;
    return completed && !fhOpsUiB05HasDoc_(idx, 'INSTALL_CONFIRM', 'installId', installId);
  }).map(function (r) {
    return { action:'CREATE_INSTALL_CONFIRM', installId:String(fhOpsUiB05Pick_(r,['installId','id'])||'').trim(), saleId:fhOpsUiB05Pick_(r,['saleId']), customerId:fhOpsUiB05Pick_(r,['customerId']), customerName:fhOpsUiB05Pick_(r,['customerName','name','customer']), vendorId:fhOpsUiB05Pick_(r,['vendorId']), eventId:fhOpsUiB05Pick_(r,['eventId']), status:fhOpsUiB05Pick_(r,['status','installStatus']), memo:'설치완료 / 확인서 미생성' };
  });
}
function fhOpsUiB05HuildSettlementConfirmTargets_(settlements, idx) {
  return (settlements || []).filter(function (r) {
    const settlementId = String(fhOpsUiB05Pick_(r, ['settlementId','closingId','id']) || '').trim();
    if (!settlementId) return false;
    return !fhOpsUiB05HasDoc_(idx, 'SETTLEMENT_CONFIRM', 'settlementId', settlementId);
  }).map(function (r) {
    return { action:'CREATE_SETTLEMENT_CONFIRM', settlementId:String(fhOpsUiB05Pick_(r,['settlementId','closingId','id'])||'').trim(), saleId:fhOpsUiB05Pick_(r,['saleId']), vendorId:fhOpsUiB05Pick_(r,['vendorId']), eventId:fhOpsUiB05Pick_(r,['eventId']), status:fhOpsUiB05Pick_(r,['status','settlementStatus']), paymentStatus:fhOpsUiB05Pick_(r,['paymentStatus','payoutStatus']), memo:'정산확인서 미생성' };
  });
}
function fhOpsUiB06A7IsPdfReadyDoc_(d) {
  const id = String((d && d.documentId) || '').trim();
  if (!id) return false;
  const type = fhOpsUiB05HocType_(d);
  if (type === 'QR_SIGN' || type === 'QR') return false;
  if (fhOpsUiB05IsArchivedDoc_(d) || fhOpsUiB05HasPdf_(d)) return false;
  const st = fhOpsUiB05HocStatus_(d);
  const signedBy = String((d && d.signedBy) || '').trim();
  const signedAt = String((d && d.signedAt) || '').trim();
  const signStatus = String((d && (d.signStatus || d.signatureStatus)) || '').trim().toUpperCase();
  return st === 'SIGN_COMPLETED' || st === 'PDF_READY' || st === 'READY_TO_PDF' || st === 'SIGNED' || st === '서명 완료' || st === '서명완료' || signStatus === 'SIGN_COMPLETED' || signStatus === 'SIGNED' || !!signedBy || !!signedAt;
}
function fhOpsUiB05HuildPdfTargets_(docs) {
  return (docs || []).filter(fhOpsUiB06A7IsPdfReadyDoc_).map(function (d) {
    return { action:'GENERATE_PDF', documentId:String(d.documentId||'').trim(), documentNo:d.documentNo||'', documentType:d.documentType||'', saleId:d.saleId||'', installId:d.installId||'', settlementId:d.settlementId||'', status:d.status||d.signStatus||'', memo:'서명완료/PDF 생성 대기' };
  });
}
function fhOpsUiB05HuildArchiveTargets_(docs) { return (docs || []).filter(function (d) { const id = String(d.documentId || '').trim(); if (!id) return false; if (fhOpsUiB05HocType_(d) === 'QR_SIGN') return false; return fhOpsUiB05HasPdf_(d) && !fhOpsUiB05IsArchivedDoc_(d); }).map(function (d) { return { action:'ARCHIVE_DOC', documentId:String(d.documentId||'').trim(), documentNo:d.documentNo||'', documentType:d.documentType||'', saleId:d.saleId||'', installId:d.installId||'', settlementId:d.settlementId||'', status:d.status||'', memo:'보관 완료 대기' }; }); }
function fhOpsUiB05HuildQrSignTargets_(docs) {
  return (docs || []).filter(function (d) {
    const id = String(d.documentId || '').trim();
    if (!id || fhOpsUiB05HocType_(d) !== 'QR_SIGN') return false;
    return !fhOpsUiB05IsArchivedDoc_(d);
  }).map(function (d) {
    const st = fhOpsUiB05HocStatus_(d);
    const hasPdf = fhOpsUiB05HasPdf_(d);
    let action = 'OPEN_SIGN_LINK';
    let actionLabel = '서명 링크 열기';
    let nextStep = 'SIGN';
    let flowStatus = '서명 필요';
    if (hasPdf) {
      action = 'ARCHIVE_DOC';
      actionLabel = '보관 완료';
      nextStep = 'ARCHIVE';
      flowStatus = 'PDF 생성 완료 / 보관 대기';
    } else if (st === 'SIGN_COMPLETED' || st === 'PDF_READY' || st === 'READY_TO_PDF') {
      action = 'GENERATE_PDF';
      actionLabel = 'PDF 생성';
      nextStep = 'PDF';
      flowStatus = '서명 완료 / PDF 생성 대기';
    }
    return {
      action: action,
      actionLabel: actionLabel,
      nextStep: nextStep,
      flowStatus: flowStatus,
      documentId: String(d.documentId || '').trim(),
      documentNo: d.documentNo || '',
      documentType: d.documentType || '',
      requestId: d.requestId || '',
      status: d.status || '',
      memo: 'QR 문서 별도 검토 - ' + flowStatus
    };
  });
}
function fhOpsUiB05HuildSettlementActionGroups_(settlements, docs) { const archivedSettlementDocs = {}; (docs || []).forEach(function (d) { const sid = String(d.settlementId || '').trim(); if (sid && fhOpsUiB05HocType_(d) === 'SETTLEMENT_CONFIRM' && fhOpsUiB05IsArchivedDoc_(d)) archivedSettlementDocs[sid] = true; }); const requestTargets = []; const approveTargets = []; const paymentTargets = []; (settlements || []).forEach(function (r) { const settlementId = String(fhOpsUiB05Pick_(r, ['settlementId','closingId','id']) || '').trim(); if (!settlementId || archivedSettlementDocs[settlementId]) return; const rawStatus = fhOpsUiB05Pick_(r, ['status','settlementStatus']); const rawPay = fhOpsUiB05Pick_(r, ['paymentStatus','payoutStatus']); const st = String(rawStatus || '').trim().toUpperCase(); const pay = String(rawPay || '').trim().toUpperCase(); if (fhOpsUiB05IsCancelStatus_(st) || fhOpsUiB05IsCancelStatus_(pay)) return; if (pay === 'PAID' || st === 'PAID' || st.indexOf('지급완료') >= 0) return; const base = { settlementId:settlementId, vendorId:fhOpsUiB05Pick_(r,['vendorId']), saleId:fhOpsUiB05Pick_(r,['saleId']), rawStatus:rawStatus, rawPaymentStatus:rawPay, paymentStatus: rawPay || '미지급' }; if (st === 'APPROVAL_REQUESTED' || st === 'REQUESTED' || st === 'PENDING_APPROVAL' || st.indexOf('승인요청') >= 0 || st.indexOf('승인대기') >= 0) { approveTargets.push(Object.assign({}, base, { action:'APPROVE_SETTLEMENT', status:'승인요청', displayStatus:'승인요청', memo:'승인 대기' })); } else if (st === 'APPROVED' || st.indexOf('승인완료') >= 0 || pay === 'READY' || pay === 'PENDING' || pay.indexOf('지급대기') >= 0) { paymentTargets.push(Object.assign({}, base, { action:'COMPLETE_PAYMENT', status:'승인 완료', displayStatus:'승인 완료', memo:'지급 대기' })); } else { requestTargets.push(Object.assign({}, base, { action:'REQUEST_SETTLEMENT_APPROVAL', status:'승인요청 대기', displayStatus:'승인요청 대기', memo:'승인요청 대기' })); } }); return { requestTargets: requestTargets.slice(0,30), approveTargets: approveTargets.slice(0,30), paymentTargets: paymentTargets.slice(0,30) }; }
function fhOpsUiB05HuildSettlementActionTargets_(settlements, docs) { const g = fhOpsUiB05HuildSettlementActionGroups_(settlements, docs); return [].concat(g.requestTargets || [], g.approveTargets || [], g.paymentTargets || []); }

/** B05H compatibility alias: keep the public worklist API name stable. */
function fhOpsUiB05GetWorklists(payload) {
  return fhOpsUiB05HetWorklists(payload || {});
}


/** B05L public aliases */
function fhOpsUiB05LRunControlDiag_(ctx, data) { return fhOpsUiB05IRunControlDiag_(ctx, data); }



/** B06B ERP ACCOUNT ADMIN - SAFE EXTENSION
 * 안정 기준: B06A8 문서/서명/PDF/보관/권한차단 흐름은 변경하지 않는다.
 * 목적: 관리자 직원계정관리, 초기비밀번호 발급, 비밀번호 초기화, 활성/중지, 일반역할 즉시 적용, 민감역할 승인요청 생성.
 */
function fhOpsUiB06BEmployeeHeaders_() { return ['employeeId','vendorId','name','phone','email','department','role','status','eventScope','menuScope','createdAt','createdBy','updatedAt','updatedBy','memo']; }
function fhOpsUiB06BRoleRequestHeaders_() { return ['requestId','vendorId','employeeId','employeeName','requestedRole','requestType','status','requestedBy','approvedBy','note','createdAt','approvedAt']; }
function fhOpsUiB06BApprovalAuditHeaders_() { return ['auditId','actionType','targetId','status','actor','refId','beforeValue','afterValue','reason','approvedBy','createdAt']; }
function fhOpsUiB06BEnsureHeaders_(sheet, headers) { if (!sheet) throw new Error('시트가 없습니다.'); var lastCol=sheet.getLastColumn(); if (lastCol<1){ sheet.getRange(1,1,1,headers.length).setValues([headers]); return fhOpsUiB04EHeaderMap_(sheet); } var current=sheet.getRange(1,1,1,lastCol).getValues()[0].map(function(h){return String(h||'').trim();}); var add=[]; for(var i=0;i<headers.length;i++) if(current.indexOf(headers[i])<0) add.push(headers[i]); if(add.length) sheet.getRange(1,lastCol+1,1,add.length).setValues([add]); return fhOpsUiB04EHeaderMap_(sheet); }
function fhOpsUiB06BEnsureSheet_(ss, name, headers) { var sh=ss.getSheetByName(name)||ss.insertSheet(name); fhOpsUiB06BEnsureHeaders_(sh,headers); return sh; }
function fhOpsUiB06BNow_(){return new Date();}
function fhOpsUiB06BDateKey_(){return Utilities.formatDate(new Date(), Session.getScriptTimeZone() || 'Asia/Seoul', 'yyyyMMddHHmmss');}
function fhOpsUiB06BNewId_(prefix){return prefix + fhOpsUiB06BDateKey_() + '-' + Math.floor(Math.random()*900+100);}
function fhOpsUiB06BNormalizeEmail_(v){return String(v||'').trim().toLowerCase();}
function fhOpsUiB06BNormalizeRole_(v){return fhOpsUiB05MNormalizeRole_(v||'VIEWER');}
function fhOpsUiB06BInstantRoles_(){return ['STAFF_SALES','STAFF_INSTALL','STAFF_AS','VIEWER'];}
function fhOpsUiB06BSensitiveRoles_(){return ['SUPER_ADMIN','HQ_ADMIN','ACCOUNTING_MANAGER','VENDOR_OWNER','VENDOR_MANAGER'];}
function fhOpsUiB06BHeadOfficeInstantRoles_(){return ['HQ_MANAGER','OPERATION_MANAGER','STAFF_SALES','STAFF_INSTALL','STAFF_AS','VIEWER'];}
function fhOpsUiB06BVendorInstantRoles_(){return ['STAFF_SALES','STAFF_INSTALL','STAFF_AS','VIEWER'];}
function fhOpsUiB06BHeadOfficeOnlyRoles_(){return ['HQ_MANAGER','HQ_ADMIN','OPERATION_MANAGER','ACCOUNTING_MANAGER','SUPER_ADMIN'];}
function fhOpsUiB06BVendorOnlyRoles_(){return ['VENDOR_OWNER','VENDOR_MANAGER'];}
function fhOpsUiB06BEmployeeType_(payload,vendorId){var t=String((payload&&payload.employeeType)||'').trim().toUpperCase(); if(t==='HQ'||t==='HEAD_OFFICE'||t==='본사직원')return 'HQ'; if(t==='VENDOR'||t==='업체직원')return 'VENDOR'; return String(vendorId||'').trim()?'VENDOR':'HQ';}
function fhOpsUiB06BValidateRoleScope_(role,employeeType){var r=fhOpsUiB06BNormalizeRole_(role); var t=String(employeeType||'').toUpperCase(); if(t==='HQ' && fhOpsUiB06BVendorOnlyRoles_().indexOf(r)>=0) throw new Error('본사직원에는 업체전용 역할을 부여할 수 없습니다: '+r); if(t==='VENDOR' && fhOpsUiB06BHeadOfficeOnlyRoles_().indexOf(r)>=0) throw new Error('업체직원에는 본사전용 역할을 부여할 수 없습니다: '+r);}
function fhOpsUiB06BIsInstantRoleForEmployee_(role,employeeType,ctx){var r=fhOpsUiB06BNormalizeRole_(role); var t=String(employeeType||'').toUpperCase(); if(t==='HQ') return fhOpsUiB06BHeadOfficeInstantRoles_().indexOf(r)>=0; if(t==='VENDOR') return fhOpsUiB06BVendorInstantRoles_().indexOf(r)>=0 && fhOpsUiB06BIsInstantRole_(r,ctx); return fhOpsUiB06BIsInstantRole_(r,ctx);}
function fhOpsUiB06BSplitPolicy_(v){return String(v||'').split(/[|,]/).map(function(x){return fhOpsUiB06BNormalizeRole_(x);}).filter(Boolean);}
function fhOpsUiB06BGetRolePolicy_(ctx){var fallback={instantRoles:fhOpsUiB06BInstantRoles_(),approvalRoles:fhOpsUiB06BSensitiveRoles_()};try{var sh=ctx.masterDb.getSheetByName('RolePolicies');if(!sh||sh.getLastRow()<2)return fallback;var map=fhOpsUiB04EHeaderMap_(sh);var rows=sh.getRange(2,1,sh.getLastRow()-1,sh.getLastColumn()).getValues();var found=null;for(var i=0;i<rows.length;i++){var key=(map.vendorId!=null?rows[i][map.vendorId]:(map.policyId!=null?rows[i][map.policyId]:''));if(String(key||'').toUpperCase()==='DEFAULT'||String(key||'').toUpperCase()==='POL-0001'){found=rows[i];break;}}if(!found)found=rows[0];var instant=map.instantRoles!=null?fhOpsUiB06BSplitPolicy_(found[map.instantRoles]):fallback.instantRoles;var approval=map.approvalRoles!=null?fhOpsUiB06BSplitPolicy_(found[map.approvalRoles]):fallback.approvalRoles;return {instantRoles:instant.length?instant:fallback.instantRoles,approvalRoles:approval.length?approval:fallback.approvalRoles};}catch(e){return fallback;}}
function fhOpsUiB06BIsInstantRole_(role,ctx){var r=fhOpsUiB06BNormalizeRole_(role);var p=ctx?fhOpsUiB06BGetRolePolicy_(ctx):{instantRoles:fhOpsUiB06BInstantRoles_()};return p.instantRoles.indexOf(r)>=0;}
function fhOpsUiB06BRequireAdmin_(ctx){var role=fhOpsUiB05MNormalizeRole_(ctx&&ctx.role?ctx.role:'VIEWER'); if(['SUPER_ADMIN','HQ_ADMIN','HQ_MANAGER'].indexOf(role)<0) throw new Error('권한 없음: 직원계정관리는 본사 관리자 이상만 실행할 수 있습니다. 현재 role='+role); return true;}
function fhOpsUiB06BRowToObj_(headers,row){var obj={}; for(var i=0;i<headers.length;i++) obj[String(headers[i]||'').trim()]=row[i]; return obj;}
function fhOpsUiB06BFindRowBy_(sheet,key,value){var map=fhOpsUiB04EHeaderMap_(sheet); if(map[key]==null)return null; var last=sheet.getLastRow(); if(last<2)return null; var values=sheet.getRange(2,1,last-1,sheet.getLastColumn()).getValues(); var target=String(value||'').trim(); for(var i=0;i<values.length;i++){ if(String(values[i][map[key]]||'').trim()===target) return {sheet:sheet,rowIndex:i+2,row:values[i],map:map}; } return null;}
function fhOpsUiB06BFindEmployeeByEmail_(sheet,email){var map=fhOpsUiB04EHeaderMap_(sheet); if(map.email==null)return null; var last=sheet.getLastRow(); if(last<2)return null; var values=sheet.getRange(2,1,last-1,sheet.getLastColumn()).getValues(); var target=fhOpsUiB06BNormalizeEmail_(email); for(var i=0;i<values.length;i++) if(fhOpsUiB06BNormalizeEmail_(values[i][map.email])===target) return {sheet:sheet,rowIndex:i+2,row:values[i],map:map}; return null;}
function fhOpsUiB06BSetCell_(found,key,value){if(found&&found.map[key]!=null) found.sheet.getRange(found.rowIndex,found.map[key]+1).setValue(value==null?'':value);}
function fhOpsUiB06BAppendObj_(sheet,obj){var map=fhOpsUiB04EHeaderMap_(sheet); var row=new Array(sheet.getLastColumn()).fill(''); Object.keys(obj||{}).forEach(function(k){if(map[k]!=null)row[map[k]]=obj[k]==null?'':obj[k];}); sheet.appendRow(row);}
function fhOpsUiB06BTempPassword_(){var chars='ABCDEFGHJKLMNPQRSTUVWXYZ23456789'; var out=''; for(var i=0;i<8;i++) out+=chars.charAt(Math.floor(Math.random()*chars.length)); return 'FH@'+Utilities.formatDate(new Date(), Session.getScriptTimeZone() || 'Asia/Seoul', 'MMdd')+'!'+out;}
function fhOpsUiB06BWriteAudit_(ctx,actionType,targetId,status,beforeValue,afterValue,reason,approvedBy){try{var sh=fhOpsUiB06BEnsureSheet_(ctx.masterDb,'ApprovalAudit',fhOpsUiB06BApprovalAuditHeaders_()); fhOpsUiB06BAppendObj_(sh,{auditId:fhOpsUiB06BNewId_('AUD-'),actionType:actionType,targetId:targetId,status:status||'DONE',actor:ctx.userEmail||'',refId:targetId||'',beforeValue:beforeValue||'',afterValue:afterValue||'',reason:reason||'',approvedBy:approvedBy||'',createdAt:fhOpsUiB06BNow_()});}catch(err){}}
function fhOpsUiB06BAuthUpsert_(ctx,employee,tempPassword,status,reason){var authSh=fhOpsUiB06EnsureSheet_(ctx.masterDb,'EmployeeAuth',fhOpsUiB06AuthHeaders_()); var found=fhOpsUiB06FindAuthByEmail_(authSh,employee.email); var now=fhOpsUiB06BNow_(); var salt=fhOpsUiB06RandomToken_().substring(0,16); var hash=fhOpsUiB06Hash_(tempPassword,salt); if(found){fhOpsUiB06SetRow_(found,{employeeId:employee.employeeId,loginId:employee.email,passwordHash:hash,passwordSalt:salt,status:status||'ACTIVE',mustChangePassword:'Y',failedCount:0,lockedUntil:'',updatedAt:now,updatedBy:ctx.userEmail,memo:reason||'B06B password reset'});}else{fhOpsUiB06BAppendObj_(authSh,{authId:fhOpsUiB06BNewId_('AUTH-'),employeeId:employee.employeeId,email:employee.email,loginId:employee.email,passwordHash:hash,passwordSalt:salt,status:status||'ACTIVE',mustChangePassword:'Y',failedCount:0,lockedUntil:'',lastLoginAt:'',createdAt:now,createdBy:ctx.userEmail,updatedAt:now,updatedBy:ctx.userEmail,memo:reason||'B06B initial issue'});}}
function fhB06BListEmployees(payload){var ctx=fhOpsUiB04EContext_(payload||{}); fhOpsUiB06BRequireAdmin_(ctx); var vendorId=String((payload&&payload.vendorId)||'ALL').trim()||'ALL'; var empSh=fhOpsUiB06BEnsureSheet_(ctx.masterDb,'Employees',fhOpsUiB06BEmployeeHeaders_()); var authSh=fhOpsUiB06EnsureSheet_(ctx.masterDb,'EmployeeAuth',fhOpsUiB06AuthHeaders_()); var reqSh=fhOpsUiB06BEnsureSheet_(ctx.masterDb,'EmployeeRoleRequests',fhOpsUiB06BRoleRequestHeaders_()); var empHeaders=empSh.getRange(1,1,1,empSh.getLastColumn()).getValues()[0]; var authMap=fhOpsUiB04EHeaderMap_(authSh); var authByEmail={}; if(authSh.getLastRow()>1&&authMap.email!=null){authSh.getRange(2,1,authSh.getLastRow()-1,authSh.getLastColumn()).getValues().forEach(function(r){authByEmail[fhOpsUiB06BNormalizeEmail_(r[authMap.email])]=authMap.status!=null?r[authMap.status]:'';});} var employees=[]; if(empSh.getLastRow()>1){empSh.getRange(2,1,empSh.getLastRow()-1,empSh.getLastColumn()).getValues().forEach(function(row){var o=fhOpsUiB06BRowToObj_(empHeaders,row); if(vendorId==='HQ'&&String(o.vendorId||''))return; if(vendorId!=='ALL'&&vendorId!=='HQ'&&String(o.vendorId||'')!==vendorId)return; employees.push({employeeId:o.employeeId||'',employeeType:String(o.vendorId||'')?'VENDOR':'HQ',vendorId:o.vendorId||'',name:o.name||o.userName||'',email:o.email||'',department:o.department||'',role:fhOpsUiB06BNormalizeRole_(o.role),status:o.status||'',eventScope:o.eventScope||'',menuScope:o.menuScope||'',authStatus:authByEmail[fhOpsUiB06BNormalizeEmail_(o.email)]||''});});} var reqHeaders=reqSh.getRange(1,1,1,reqSh.getLastColumn()).getValues()[0]; var requests=[]; if(reqSh.getLastRow()>1){reqSh.getRange(2,1,reqSh.getLastRow()-1,reqSh.getLastColumn()).getValues().forEach(function(row){var o=fhOpsUiB06BRowToObj_(reqHeaders,row); if(vendorId==='HQ'&&String(o.vendorId||''))return; if(vendorId!=='ALL'&&vendorId!=='HQ'&&String(o.vendorId||'')!==vendorId)return; var st=String(o.status||'').toUpperCase(); if(st==='APPROVED'||st==='REJECTED')return; requests.push({requestId:o.requestId||'',vendorId:o.vendorId||'',employeeId:o.employeeId||'',employeeName:o.employeeName||'',requestedRole:o.requestedRole||'',requestType:o.requestType||'',status:o.status||'',requestedBy:o.requestedBy||'',note:o.note||'',createdAt:o.createdAt||''});});} return fhOpsUiB04EOk_('B06B 직원계정관리 조회 완료',{employees:employees.slice(-200).reverse(),pendingRequests:requests.slice(-100).reverse(),vendorId:vendorId,buildNo:'v64-B06C'});}
function fhB06BCreateEmployee(payload){var ctx=fhOpsUiB04EContext_(payload||{}); fhOpsUiB06BRequireAdmin_(ctx); payload=payload||{}; var email=fhOpsUiB06BNormalizeEmail_(payload.email); var name=String(payload.name||'').trim(); var vendorId=String(payload.vendorId||'').trim(); var employeeType=fhOpsUiB06BEmployeeType_(payload,vendorId); if(employeeType==='HQ') vendorId=''; var role=fhOpsUiB06BNormalizeRole_(payload.role||'VIEWER'); var status=String(payload.status||'ACTIVE').trim().toUpperCase(); if(!email||!name) throw new Error('직원명 / 이메일은 필수입니다.'); if(employeeType==='VENDOR'&&!vendorId) throw new Error('업체직원은 업체ID가 필수입니다. 본사직원은 직원구분을 본사직원으로 선택하세요.'); fhOpsUiB06BValidateRoleScope_(role,employeeType); var empSh=fhOpsUiB06BEnsureSheet_(ctx.masterDb,'Employees',fhOpsUiB06BEmployeeHeaders_()); if(fhOpsUiB06BFindEmployeeByEmail_(empSh,email)) throw new Error('이미 등록된 직원 이메일입니다: '+email); var now=fhOpsUiB06BNow_(); var employeeId=fhOpsUiB06BNewId_(employeeType==='HQ'?'EMP-HQ-':'EMP-'); var instant=fhOpsUiB06BIsInstantRoleForEmployee_(role,employeeType,ctx); var appliedRole=instant?role:'VIEWER'; var tempPassword=fhOpsUiB06BTempPassword_(); var eventScope=String(payload.eventScope||'').trim(); if(!eventScope) eventScope=employeeType==='HQ'?'ALL':''; var memoPrefix=employeeType==='HQ'?'본사직원':'업체직원'; fhOpsUiB06BAppendObj_(empSh,{employeeId:employeeId,vendorId:vendorId,name:name,phone:String(payload.phone||''),email:email,department:String(payload.department||''),role:appliedRole,status:status||'ACTIVE',eventScope:eventScope,menuScope:String(payload.menuScope||''),createdAt:now,createdBy:ctx.userEmail,updatedAt:now,updatedBy:ctx.userEmail,memo:memoPrefix+' / '+String(payload.memo||payload.reason||'')}); fhOpsUiB06BAuthUpsert_(ctx,{employeeId:employeeId,email:email},tempPassword,status||'ACTIVE','B06B1 initial password issue'); var mode='INSTANT'; var requestId=''; if(!instant){var reqSh=fhOpsUiB06BEnsureSheet_(ctx.masterDb,'EmployeeRoleRequests',fhOpsUiB06BRoleRequestHeaders_()); requestId=fhOpsUiB06BNewId_('ERQ-'); fhOpsUiB06BAppendObj_(reqSh,{requestId:requestId,vendorId:vendorId,employeeId:employeeId,employeeName:name,requestedRole:role,requestType:employeeType==='HQ'?'HQ_SENSITIVE_ROLE_REQUEST':'SENSITIVE_ROLE_REQUEST',status:'PENDING',requestedBy:ctx.userEmail,approvedBy:'',note:'B06B1 민감역할은 CONTROL 승인 후 반영 / employeeType='+employeeType,createdAt:now,approvedAt:''}); mode='APPROVAL_REQUIRED';} fhOpsUiB06BWriteAudit_(ctx,'EMPLOYEE_CREATE_'+employeeType,employeeId,mode,'',appliedRole,String(payload.reason||'B06B1 직원 생성'),''); return fhOpsUiB04EOk_('B06B1 직원 생성 완료',{employeeId:employeeId,email:email,employeeType:employeeType,vendorId:vendorId,role:appliedRole,requestedRole:role,mode:mode,requestId:requestId,initialPassword:tempPassword,mustChangePassword:'Y'});}
function fhB06BResetPassword(payload){
  return fhB06GResetPasswordByEmail(payload || {});
}
function fhB06GResetPasswordByEmail(payload){
  var ctx=fhOpsUiB04EContext_(payload||{});
  fhOpsUiB06BRequireAdmin_(ctx);
  payload=payload||{};
  var employeeId=String(payload.employeeId||'').trim();
  var email=fhOpsUiB06BNormalizeEmail_(payload.email||payload.loginId||'');
  if(!employeeId&&!email) throw new Error('employeeId 또는 이메일이 필요합니다.');
  var empSh=fhOpsUiB06BEnsureSheet_(ctx.masterDb,'Employees',fhOpsUiB06BEmployeeHeaders_());
  var found=employeeId?fhOpsUiB06BFindRowBy_(empSh,'employeeId',employeeId):null;
  if(!found&&email) found=fhOpsUiB06BFindEmployeeByEmail_(empSh,email);
  if(!found) throw new Error('직원을 찾지 못했습니다: '+(employeeId||email));
  var targetEmployeeId=found.map.employeeId!=null?String(found.row[found.map.employeeId]||'').trim():employeeId;
  var targetEmail=found.map.email!=null?fhOpsUiB06BNormalizeEmail_(found.row[found.map.email]):email;
  if(!targetEmail) throw new Error('직원 이메일이 비어 있어 비밀번호를 발급할 수 없습니다.');
  var status=found.map.status!=null?String(found.row[found.map.status]||'ACTIVE').toUpperCase():'ACTIVE';
  if(['DISABLED','INACTIVE'].indexOf(status)>=0) throw new Error('비활성/중지 계정은 먼저 ACTIVE 또는 SUSPENDED 상태를 확인해야 합니다: '+status);
  var tempPassword=fhOpsUiB06BTempPassword_();
  fhOpsUiB06BAuthUpsert_(ctx,{employeeId:targetEmployeeId,email:targetEmail},tempPassword,'ACTIVE','B06G password recovery reset');
  fhOpsUiB06BSetCell_(found,'status',status==='LOCKED'?'ACTIVE':status);
  fhOpsUiB06BSetCell_(found,'updatedAt',fhOpsUiB06BNow_());
  fhOpsUiB06BSetCell_(found,'updatedBy',ctx.userEmail);
  fhOpsUiB06BWriteAudit_(ctx,'EMPLOYEE_PASSWORD_RESET',targetEmployeeId,'DONE','','mustChangePassword=Y',String(payload.reason||'B06G 비밀번호 초기화'),ctx.userEmail);
  try{fhOpsUiB06DSecurityLog_(ctx.masterDb,'PASSWORD_RESET_BY_ADMIN','WARNING',targetEmail,targetEmployeeId,'',ctx.sessionId||'','OK','관리자 비밀번호 초기화',{admin:ctx.userEmail,reason:String(payload.reason||'')});}catch(e){}
  return fhOpsUiB04EOk_('B06G 비밀번호 초기화 완료',{employeeId:targetEmployeeId,email:targetEmail,initialPassword:tempPassword,mustChangePassword:'Y',resetBy:ctx.userEmail});
}
function fhB06BSetEmployeeStatus(payload){var ctx=fhOpsUiB04EContext_(payload||{}); fhOpsUiB06BRequireAdmin_(ctx); payload=payload||{}; var employeeId=String(payload.employeeId||'').trim(); var status=String(payload.status||'').trim().toUpperCase(); if(!employeeId||!status) throw new Error('employeeId / status가 필요합니다.'); if(['ACTIVE','SUSPENDED','DISABLED','INACTIVE','LOCKED'].indexOf(status)<0) throw new Error('허용되지 않은 상태값입니다: '+status); var empSh=fhOpsUiB06BEnsureSheet_(ctx.masterDb,'Employees',fhOpsUiB06BEmployeeHeaders_()); var found=fhOpsUiB06BFindRowBy_(empSh,'employeeId',employeeId); if(!found) throw new Error('직원을 찾지 못했습니다: '+employeeId); var before=found.map.status!=null?found.row[found.map.status]:''; var email=found.map.email!=null?fhOpsUiB06BNormalizeEmail_(found.row[found.map.email]):''; fhOpsUiB06BSetCell_(found,'status',status); fhOpsUiB06BSetCell_(found,'updatedAt',fhOpsUiB06BNow_()); fhOpsUiB06BSetCell_(found,'updatedBy',ctx.userEmail); if(email){var authSh=fhOpsUiB06EnsureSheet_(ctx.masterDb,'EmployeeAuth',fhOpsUiB06AuthHeaders_()); var auth=fhOpsUiB06FindAuthByEmail_(authSh,email); if(auth) fhOpsUiB06SetRow_(auth,{status:status,updatedAt:fhOpsUiB06BNow_(),updatedBy:ctx.userEmail});} fhOpsUiB06BWriteAudit_(ctx,'EMPLOYEE_STATUS_CHANGE',employeeId,'DONE',before,status,String(payload.reason||'B06B 직원 상태 변경'),''); return fhOpsUiB04EOk_('B06B 직원 상태 변경 완료',{employeeId:employeeId,status:status});}
function fhB06BRequestRoleChange(payload){var ctx=fhOpsUiB04EContext_(payload||{}); fhOpsUiB06BRequireAdmin_(ctx); payload=payload||{}; var employeeId=String(payload.employeeId||'').trim(); var requestedRole=fhOpsUiB06BNormalizeRole_(payload.requestedRole||''); if(!employeeId||!requestedRole) throw new Error('employeeId / requestedRole이 필요합니다.'); var empSh=fhOpsUiB06BEnsureSheet_(ctx.masterDb,'Employees',fhOpsUiB06BEmployeeHeaders_()); var found=fhOpsUiB06BFindRowBy_(empSh,'employeeId',employeeId); if(!found) throw new Error('직원을 찾지 못했습니다: '+employeeId); var vendorId=found.map.vendorId!=null?String(found.row[found.map.vendorId]||''):''; var employeeType=vendorId?'VENDOR':'HQ'; fhOpsUiB06BValidateRoleScope_(requestedRole,employeeType); var employeeName=found.map.name!=null?String(found.row[found.map.name]||''):''; var beforeRole=found.map.role!=null?String(found.row[found.map.role]||''):''; if(fhOpsUiB06BIsInstantRoleForEmployee_(requestedRole,employeeType,ctx)){fhOpsUiB06BSetCell_(found,'role',requestedRole); fhOpsUiB06BSetCell_(found,'updatedAt',fhOpsUiB06BNow_()); fhOpsUiB06BSetCell_(found,'updatedBy',ctx.userEmail); fhOpsUiB06BWriteAudit_(ctx,'EMPLOYEE_ROLE_CHANGE',employeeId,'INSTANT',beforeRole,requestedRole,String(payload.reason||'B06B1 일반역할 즉시변경'),''); return fhOpsUiB04EOk_('B06B1 일반역할 즉시 변경 완료',{employeeId:employeeId,employeeType:employeeType,mode:'INSTANT',requestedRole:requestedRole});} var reqSh=fhOpsUiB06BEnsureSheet_(ctx.masterDb,'EmployeeRoleRequests',fhOpsUiB06BRoleRequestHeaders_()); var requestId=fhOpsUiB06BNewId_('ERQ-'); fhOpsUiB06BAppendObj_(reqSh,{requestId:requestId,vendorId:vendorId,employeeId:employeeId,employeeName:employeeName,requestedRole:requestedRole,requestType:employeeType==='HQ'?'HQ_SENSITIVE_ROLE_REQUEST':'SENSITIVE_ROLE_REQUEST',status:'PENDING',requestedBy:ctx.userEmail,approvedBy:'',note:String(payload.reason||'B06B1 민감역할 승인 요청'),createdAt:fhOpsUiB06BNow_(),approvedAt:''}); fhOpsUiB06BWriteAudit_(ctx,'EMPLOYEE_ROLE_REQUEST',requestId,'PENDING',beforeRole,requestedRole,String(payload.reason||'B06B1 민감역할 승인 요청'),''); return fhOpsUiB04EOk_('B06B1 민감역할 승인요청 생성 완료',{employeeId:employeeId,employeeType:employeeType,mode:'APPROVAL_REQUIRED',requestId:requestId,requestedRole:requestedRole});}


/**
 * B06C_CONTROL_AUTH_APPROVAL
 * 목적: B06B에서 생성된 민감 역할 승인요청을 승인/반려하고 Employees.role, EmployeeRoleRequests, ApprovalAudit를 동기화한다.
 */
function fhOpsUiB06CRequireApprover_(ctx){
  var role=fhOpsUiB06BNormalizeRole_(ctx && ctx.role);
  if(role!=='SUPER_ADMIN' && role!=='HQ_ADMIN') throw new Error('권한 없음: 민감 역할 승인/반려는 SUPER_ADMIN 또는 HQ_ADMIN만 가능합니다.');
}
function fhOpsUiB06CFindPendingRequest_(ctx, requestId){
  var reqSh=fhOpsUiB06BEnsureSheet_(ctx.masterDb,'EmployeeRoleRequests',fhOpsUiB06BRoleRequestHeaders_());
  var found=fhOpsUiB06BFindRowBy_(reqSh,'requestId',requestId);
  if(!found) throw new Error('승인요청을 찾지 못했습니다: '+requestId);
  var status=found.map.status!=null?String(found.row[found.map.status]||'').trim().toUpperCase():'';
  if(status && status!=='PENDING' && status!=='REQUESTED') throw new Error('처리 가능한 PENDING 요청이 아닙니다: '+status);
  return {sheet:reqSh, found:found};
}
function fhOpsUiB06CAssertNotSelfApprove_(ctx, reqObj, empObj){
  var actorEmail=fhOpsUiB06BNormalizeEmail_(ctx.userEmail||'');
  var actorId=String((ctx.employee && ctx.employee.employeeId) || '').trim();
  var targetEmail=fhOpsUiB06BNormalizeEmail_(empObj.email||'');
  var targetId=String(reqObj.employeeId||empObj.employeeId||'').trim();
  if(actorEmail && targetEmail && actorEmail===targetEmail) throw new Error('자기 자신의 민감 역할은 직접 승인/반려할 수 없습니다.');
  if(actorId && targetId && actorId===targetId) throw new Error('자기 자신의 민감 역할은 직접 승인/반려할 수 없습니다.');
}
function fhOpsUiB06CAssertRoleApprovalLevel_(ctx, requestedRole){
  var actorRole=fhOpsUiB06BNormalizeRole_(ctx.role);
  var role=fhOpsUiB06BNormalizeRole_(requestedRole);
  if(role==='SUPER_ADMIN' && actorRole!=='SUPER_ADMIN') throw new Error('SUPER_ADMIN 부여 승인은 기존 SUPER_ADMIN만 가능합니다.');
}
function fhB06CApproveRoleRequest(payload){
  var ctx=fhOpsUiB04EContext_(payload||{}); fhOpsUiB06CRequireApprover_(ctx); payload=payload||{};
  var requestId=String(payload.requestId||'').trim(); if(!requestId) throw new Error('requestId가 필요합니다.');
  var reason=String(payload.reason||'B06C 민감 역할 승인').trim();
  var pack=fhOpsUiB06CFindPendingRequest_(ctx,requestId); var found=pack.found;
  var req=fhOpsUiB06BRowToObj_(pack.sheet.getRange(1,1,1,pack.sheet.getLastColumn()).getValues()[0],found.row);
  var employeeId=String(req.employeeId||'').trim(); var requestedRole=fhOpsUiB06BNormalizeRole_(req.requestedRole||'');
  if(!employeeId||!requestedRole) throw new Error('승인요청에 employeeId/requestedRole이 없습니다.');
  fhOpsUiB06CAssertRoleApprovalLevel_(ctx,requestedRole);
  var empSh=fhOpsUiB06BEnsureSheet_(ctx.masterDb,'Employees',fhOpsUiB06BEmployeeHeaders_());
  var empFound=fhOpsUiB06BFindRowBy_(empSh,'employeeId',employeeId); if(!empFound) throw new Error('대상 직원을 찾지 못했습니다: '+employeeId);
  var emp=fhOpsUiB06BRowToObj_(empSh.getRange(1,1,1,empSh.getLastColumn()).getValues()[0],empFound.row);
  fhOpsUiB06CAssertNotSelfApprove_(ctx,req,emp);
  var beforeRole=empFound.map.role!=null?String(empFound.row[empFound.map.role]||''):'';
  fhOpsUiB06BSetCell_(empFound,'role',requestedRole);
  fhOpsUiB06BSetCell_(empFound,'updatedAt',fhOpsUiB06BNow_());
  fhOpsUiB06BSetCell_(empFound,'updatedBy',ctx.userEmail);
  fhOpsUiB06BSetCell_(found,'status','APPROVED');
  fhOpsUiB06BSetCell_(found,'approvedBy',ctx.userEmail);
  fhOpsUiB06BSetCell_(found,'approvedAt',fhOpsUiB06BNow_());
  fhOpsUiB06BSetCell_(found,'note',String(req.note||'')+' / APPROVED: '+reason);
  fhOpsUiB06BWriteAudit_(ctx,'EMPLOYEE_ROLE_APPROVE',employeeId,'APPROVED',beforeRole,requestedRole,reason,ctx.userEmail);
  return fhOpsUiB04EOk_('B06C 민감 역할 승인 완료',{requestId:requestId,employeeId:employeeId,beforeRole:beforeRole,approvedRole:requestedRole,status:'APPROVED',approvedBy:ctx.userEmail});
}
function fhB06CRejectRoleRequest(payload){
  var ctx=fhOpsUiB04EContext_(payload||{}); fhOpsUiB06CRequireApprover_(ctx); payload=payload||{};
  var requestId=String(payload.requestId||'').trim(); if(!requestId) throw new Error('requestId가 필요합니다.');
  var reason=String(payload.reason||'B06C 민감 역할 반려').trim();
  var pack=fhOpsUiB06CFindPendingRequest_(ctx,requestId); var found=pack.found;
  var req=fhOpsUiB06BRowToObj_(pack.sheet.getRange(1,1,1,pack.sheet.getLastColumn()).getValues()[0],found.row);
  var employeeId=String(req.employeeId||'').trim();
  var empSh=fhOpsUiB06BEnsureSheet_(ctx.masterDb,'Employees',fhOpsUiB06BEmployeeHeaders_());
  var empFound=employeeId?fhOpsUiB06BFindRowBy_(empSh,'employeeId',employeeId):null;
  var emp=empFound?fhOpsUiB06BRowToObj_(empSh.getRange(1,1,1,empSh.getLastColumn()).getValues()[0],empFound.row):{};
  fhOpsUiB06CAssertNotSelfApprove_(ctx,req,emp);
  fhOpsUiB06BSetCell_(found,'status','REJECTED');
  fhOpsUiB06BSetCell_(found,'approvedBy',ctx.userEmail);
  fhOpsUiB06BSetCell_(found,'approvedAt',fhOpsUiB06BNow_());
  fhOpsUiB06BSetCell_(found,'note',String(req.note||'')+' / REJECTED: '+reason);
  fhOpsUiB06BWriteAudit_(ctx,'EMPLOYEE_ROLE_REJECT',requestId,'REJECTED',String(req.requestedRole||''),'',reason,ctx.userEmail);
  return fhOpsUiB04EOk_('B06C 민감 역할 반려 완료',{requestId:requestId,employeeId:employeeId,requestedRole:req.requestedRole||'',status:'REJECTED',approvedBy:ctx.userEmail});
}
function testB06CControlAuthApprovalPreflight(){
  var env=fhOpsUiB06GetMasterDb_();
  var roleReq=fhOpsUiB06BEnsureSheet_(env.masterDb,'EmployeeRoleRequests',fhOpsUiB06BRoleRequestHeaders_());
  var audit=fhOpsUiB06BEnsureSheet_(env.masterDb,'ApprovalAudit',fhOpsUiB06BApprovalAuditHeaders_());
  var emp=fhOpsUiB06BEnsureSheet_(env.masterDb,'Employees',fhOpsUiB06BEmployeeHeaders_());
  return fhOpsUiB04EOk_('B06C 민감 역할 승인센터 사전점검 완료',{sheets:[emp.getName(),roleReq.getName(),audit.getName()],masterDbId:env.masterDbId,buildNo:'v64-B06C'});
}
function testB06B1AccountAdminPreflight(){var env=fhOpsUiB06GetMasterDb_(); var employees=fhOpsUiB06BEnsureSheet_(env.masterDb,'Employees',fhOpsUiB06BEmployeeHeaders_()); var auth=fhOpsUiB06EnsureSheet_(env.masterDb,'EmployeeAuth',fhOpsUiB06AuthHeaders_()); var sessions=fhOpsUiB06EnsureSheet_(env.masterDb,'EmployeeSessions',fhOpsUiB06SessionHeaders_()); var roleReq=fhOpsUiB06BEnsureSheet_(env.masterDb,'EmployeeRoleRequests',fhOpsUiB06BRoleRequestHeaders_()); var audit=fhOpsUiB06BEnsureSheet_(env.masterDb,'ApprovalAudit',fhOpsUiB06BApprovalAuditHeaders_()); return fhOpsUiB04EOk_('B06B1 본사/업체 직원계정관리 사전점검 완료',{sheets:[employees.getName(),auth.getName(),sessions.getName(),roleReq.getName(),audit.getName()],masterDbId:env.masterDbId,buildNo:'v64-B06B1'});}

/** B06A7 TEST SAMPLE MANAGER */
function fhOpsUiB06A7RequireAdmin_(ctx) {
  const role = fhOpsUiB05MNormalizeRole_((ctx && ctx.role) || 'VIEWER');
  if (['SUPER_ADMIN','HQ_ADMIN','HQ_MANAGER'].indexOf(role) < 0) throw new Error('권한 없음: 테스트샘플 생성/초기화는 본사 관리자만 실행할 수 있습니다. 현재 role=' + role);
}
function fhOpsUiB06A7Sheet_(ctx, names, required) {
  const sh = fhOpsUiB03GetSheetByCandidates_(ctx.masterDb, names, false);
  if (!sh && required) throw new Error('시트를 찾을 수 없습니다: ' + names.join(' / '));
  return sh;
}
function fhOpsUiB06A7Set_(row, map, key, value) { if (map[key] != null) row[map[key]] = value == null ? '' : value; }
function fhOpsUiB06A7Append_(sheet, obj) {
  const map = fhOpsUiB03HeaderMap_(sheet);
  const row = new Array(sheet.getLastColumn()).fill('');
  Object.keys(obj || {}).forEach(function(k){ fhOpsUiB06A7Set_(row, map, k, obj[k]); });
  sheet.appendRow(row);
}
function fhOpsUiB06A7FirstId_(ctx, sheetNames, key, fallback) {
  const sh = fhOpsUiB06A7Sheet_(ctx, sheetNames, false);
  if (!sh || sh.getLastRow() < 2) return fallback;
  const map = fhOpsUiB03HeaderMap_(sh);
  if (map[key] == null) return fallback;
  const values = sh.getRange(2, map[key] + 1, sh.getLastRow() - 1, 1).getValues();
  for (var i = 0; i < values.length; i++) { const v = String(values[i][0] || '').trim(); if (v) return v; }
  return fallback;
}
function fhOpsUiB06A7Prefix_(v) { return /^(TEST|DEV|TMP|SAMPLE)-/i.test(String(v || '').trim()); }
function fhOpsUiB06A7DeleteByIdPrefixes_(sheet, keys) {
  if (!sheet || sheet.getLastRow() < 2) return 0;
  const map = fhOpsUiB03HeaderMap_(sheet);
  const hitCols = (keys || []).filter(function(k){ return map[k] != null; });
  if (!hitCols.length) return 0;
  const values = sheet.getRange(2, 1, sheet.getLastRow() - 1, sheet.getLastColumn()).getValues();
  let count = 0;
  for (var i = values.length - 1; i >= 0; i--) {
    let hit = false;
    for (var j = 0; j < hitCols.length; j++) { if (fhOpsUiB06A7Prefix_(values[i][map[hitCols[j]]])) { hit = true; break; } }
    if (hit) { sheet.deleteRow(i + 2); count++; }
  }
  return count;
}
function fhOpsUiB06A7ResetTestSamples_(ctx, data) {
  fhOpsUiB06A7RequireAdmin_(ctx);
  const result = {};
  const targets = [
    { key:'customers', names:['Customers','ERP_고객관리','ERP_Customers'], ids:['customerId'] },
    { key:'sales', names:['Sales','ERP_판매관리','ERP_Sales'], ids:['saleId','customerId'] },
    { key:'contracts', names:['Contracts','ERP_계약관리','ERP_Contracts'], ids:['contractId','saleId','customerId'] },
    { key:'installs', names:['Installs','ERP_설치관리','ERP_Installs'], ids:['installId','saleId','customerId'] },
    { key:'installAssignments', names:['InstallAssignments','ERP_설치배정'], ids:['installId','saleId','customerId'] },
    { key:'installCompletions', names:['InstallCompletions','ERP_설치완료'], ids:['installId','saleId','customerId'] },
    { key:'settlements', names:['Settlements','ERP_정산관리','ERP_Settlements'], ids:['settlementId','saleId','customerId'] },
    { key:'documents', names:['SIGN_Documents','Documents','SIGN_DOCUMENTS'], ids:['saleId','installId','settlementId','customerId'] }
  ];
  targets.forEach(function(t){ const sh = fhOpsUiB06A7Sheet_(ctx, t.names, false); result[t.key] = fhOpsUiB06A7DeleteByIdPrefixes_(sh, t.ids); });
  return fhOpsUiB04EOk_('TEST/DEV/TMP/SAMPLE 샘플 초기화 완료', { deleted: result, rule: '운영 데이터는 삭제하지 않고 TEST-/DEV-/TMP-/SAMPLE- 접두어 행만 제거했습니다.' });
}
function fhOpsUiB06A7CreateTestSamples_(ctx, data) {
  fhOpsUiB06A7RequireAdmin_(ctx);
  const now = new Date();
  const stamp = Utilities.formatDate(now, Session.getScriptTimeZone() || 'Asia/Seoul', 'yyyyMMddHHmmss');
  const eventId = fhOpsUiB06A7FirstId_(ctx, ['Events','ERP_행사관리','ERP_Events'], 'eventId', 'TEST-EVENT');
  const vendorId = fhOpsUiB06A7FirstId_(ctx, ['Vendors','ERP_업체관리','ERP_Vendors'], 'vendorId', 'TEST-VENDOR');
  const actor = (ctx && ctx.userEmail) || 'system';
  const made = [];
  const customers = fhOpsUiB06A7Sheet_(ctx, ['Customers','ERP_고객관리','ERP_Customers'], true);
  const sales = fhOpsUiB06A7Sheet_(ctx, ['Sales','ERP_판매관리','ERP_Sales'], true);
  const installs = fhOpsUiB06A7Sheet_(ctx, ['Installs','ERP_설치관리','ERP_Installs'], true);
  const settlements = fhOpsUiB06A7Sheet_(ctx, ['Settlements','ERP_정산관리','ERP_Settlements'], true);
  for (var i = 1; i <= 5; i++) {
    const suffix = stamp + '-' + ('0' + i).slice(-2);
    const customerId = 'TEST-CUS-' + suffix, saleId = 'TEST-SALE-' + suffix, installId = 'TEST-INS-' + suffix, settlementId = 'TEST-SET-' + suffix, contractId = 'TEST-CON-' + suffix;
    const amount = 1000000 + (i * 100000);
    fhOpsUiB06A7Append_(customers, { customerId:customerId, customerName:'테스트고객' + i, name:'테스트고객' + i, phone:'010-0000-' + ('000' + i).slice(-4), eventId:eventId, vendorId:vendorId, status:'ACTIVE', memberType:'TEST', createdAt:now, createdBy:actor, updatedAt:now, updatedBy:actor, notes:'B06A7 테스트샘플' });
    fhOpsUiB06A7Append_(sales, { saleId:saleId, contractId:contractId, customerId:customerId, customerName:'테스트고객' + i, eventId:eventId, vendorId:vendorId, status:'ACTIVE', saleStatus:'ACTIVE', saleStage:'SALE_COMPLETED', installStatus:'COMPLETED', settlementStatus:'READY', productSummary:'B06A7 테스트상품', totalAmount:amount, amount:amount, saleAmount:amount, createdAt:now, createdBy:actor, updatedAt:now, updatedBy:actor, notes:'B06A7 테스트샘플' });
    fhOpsUiB06A7Append_(installs, { installId:installId, saleId:saleId, contractId:contractId, customerId:customerId, customerName:'테스트고객' + i, eventId:eventId, vendorId:vendorId, status:'COMPLETED', installStatus:'COMPLETED', completedAt:now, installDate:now, installer:'테스트기사', createdAt:now, createdBy:actor, updatedAt:now, updatedBy:actor, notes:'B06A7 테스트샘플' });
    fhOpsUiB06A7Append_(settlements, { settlementId:settlementId, saleId:saleId, contractId:contractId, installId:installId, customerId:customerId, eventId:eventId, vendorId:vendorId, status:i <= 2 ? 'APPROVAL_REQUESTED' : 'APPROVED', settlementStatus:i <= 2 ? 'APPROVAL_REQUESTED' : 'APPROVED', paymentStatus:i <= 3 ? 'UNPAID' : 'PAID', payoutStatus:i <= 3 ? 'UNPAID' : 'PAID', totalAmount:amount, settlementAmount:amount, createdAt:now, createdBy:actor, updatedAt:now, updatedBy:actor, notes:'B06A7 테스트샘플' });
    made.push({ saleId:saleId, installId:installId, settlementId:settlementId, customerId:customerId });
  }
  return fhOpsUiB04EOk_('B06A7 테스트샘플 5세트 생성 완료', { created: made, eventId:eventId, vendorId:vendorId, next: '목록 새로고침 후 계약서/설치확인서/정산확인서 생성 테스트를 진행하세요.' });
}


/**
 * B06D SECURITY HARDENING
 * - 비밀번호 변경 강제
 * - 로그인 실패 잠금
 * - 세션 만료/로그아웃 강화
 * - 보안 이벤트 기록
 */
function fhOpsUiB06DSecurityLogHeaders_(){return ['logId','eventType','severity','employeeId','email','role','sessionId','targetId','ipHint','result','message','createdAt','createdBy','meta'];}
function fhOpsUiB06DSecurityLog_(masterDb,eventType,severity,email,employeeId,role,sessionId,result,message,meta){
  try{
    var sh=fhOpsUiB06EnsureSheet_(masterDb,'SecurityEvents',fhOpsUiB06DSecurityLogHeaders_());
    var now=new Date();
    var map=fhOpsUiB04EHeaderMap_(sh);
    var obj={logId:'SEC-'+Utilities.formatDate(now,Session.getScriptTimeZone()||'Asia/Seoul','yyyyMMddHHmmss')+'-'+Math.floor(Math.random()*1000),eventType:eventType||'',severity:severity||'INFO',employeeId:employeeId||'',email:email||'',role:role||'',sessionId:sessionId||'',targetId:'',ipHint:'',result:result||'',message:message||'',createdAt:now,createdBy:email||'SYSTEM',meta:typeof meta==='string'?meta:JSON.stringify(meta||{})};
    sh.appendRow(Object.keys(map).map(function(h){return obj[h]==null?'':obj[h];}));
  }catch(e){}
}
function fhOpsUiB06DParseDate_(v){if(v instanceof Date)return v; if(!v)return null; var d=new Date(v); return isNaN(d.getTime())?null:d;}
function fhOpsUiB06DGetAuthMustChange_(masterDb,email){var sh=fhOpsUiB04EGetSheet_(masterDb,['EmployeeAuth'],false); if(!sh)return 'N'; var auth=fhOpsUiB06FindAuthByEmail_(sh,email); if(!auth)return 'N'; return auth.map.mustChangePassword!=null?String(auth.row[auth.map.mustChangePassword]||'N').trim().toUpperCase():'N';}
function fhOpsUiB06DAssertPasswordPolicy_(password){var p=String(password||''); if(p.length<8) throw new Error('비밀번호는 8자 이상이어야 합니다.'); if(!/[A-Za-z]/.test(p)||!/[0-9]/.test(p)) throw new Error('비밀번호는 영문과 숫자를 포함해야 합니다.'); if(p==='FH@2026!') throw new Error('초기 비밀번호는 계속 사용할 수 없습니다.'); return true;}
function fhOpsUiB06Login(payload) {
  payload = payload || {}; var email = String(payload.email || payload.loginId || '').trim().toLowerCase(); var password = String(payload.password || payload.pin || '').trim();
  if (!email) return fhOpsUiB04EFail_('이메일을 입력하세요.', 'LOGIN_EMAIL_REQUIRED', {}); if (!password) return fhOpsUiB04EFail_('비밀번호를 입력하세요.', 'LOGIN_PASSWORD_REQUIRED', { email: email });
  var env = fhOpsUiB06GetMasterDb_(); var employee = fhOpsUiB05MFindEmployeeByEmail_(env.masterDb, email);
  if (!employee || !employee.isActive) { fhOpsUiB06DSecurityLog_(env.masterDb,'LOGIN_DENIED','WARNING',email,'','','','FAIL','등록된 활성 직원 아님',{}); return fhOpsUiB04EFail_('등록된 활성 직원이 아닙니다.', 'EMPLOYEE_NOT_ACTIVE', { email: email }); }
  var authSh = fhOpsUiB06EnsureSheet_(env.masterDb, 'EmployeeAuth', fhOpsUiB06AuthHeaders_()); var sessSh = fhOpsUiB06EnsureSheet_(env.masterDb, 'EmployeeSessions', fhOpsUiB06SessionHeaders_()); fhOpsUiB06EnsureSheet_(env.masterDb,'SecurityEvents',fhOpsUiB06DSecurityLogHeaders_());
  var auth = fhOpsUiB06FindAuthByEmail_(authSh, email); var now = new Date(); var user = 'ERP_LOGIN'; var lockMinutes = 30; var maxFail = 5;
  if (!auth) {
    if (password !== 'FH@2026!') { fhOpsUiB06DSecurityLog_(env.masterDb,'LOGIN_FAILED','WARNING',email,employee.employeeId,employee.role,'','FAIL','초기 비밀번호 불일치',{}); return fhOpsUiB04EFail_('초기 비밀번호가 맞지 않습니다. 초기비밀번호는 FH@2026! 입니다.', 'INITIAL_PASSWORD_REQUIRED', { email: email }); }
    var salt = fhOpsUiB06RandomToken_().substring(0,16); var hash = fhOpsUiB06Hash_(password, salt); var authMap = fhOpsUiB04EHeaderMap_(authSh);
    var rowObj = { authId:'AUTH-' + Utilities.formatDate(now, Session.getScriptTimeZone() || 'Asia/Seoul', 'yyyyMMddHHmmss') + '-' + Math.floor(Math.random()*1000), employeeId:employee.employeeId, email:email, loginId:email, passwordHash:hash, passwordSalt:salt, status:'ACTIVE', mustChangePassword:'Y', failedCount:0, lockedUntil:'', lastLoginAt:now, createdAt:now, createdBy:user, updatedAt:now, updatedBy:user, memo:'B06D 최초 로그인 자동생성 / 비밀번호 변경 필요' };
    authSh.appendRow(Object.keys(authMap).map(function(h){ return rowObj[h] == null ? '' : rowObj[h]; })); auth = fhOpsUiB06FindAuthByEmail_(authSh, email);
  } else {
    var map=auth.map, row=auth.row; var status = map.status != null ? String(row[map.status] || '').trim().toUpperCase() : 'ACTIVE';
    if (status !== 'ACTIVE') { fhOpsUiB06DSecurityLog_(env.masterDb,'LOGIN_DENIED','WARNING',email,employee.employeeId,employee.role,'','FAIL','AUTH 상태 비활성: '+status,{}); return fhOpsUiB04EFail_('로그인 계정이 비활성 상태입니다.', 'AUTH_INACTIVE', { email: email, status: status }); }
    var lockedUntil = map.lockedUntil != null ? fhOpsUiB06DParseDate_(row[map.lockedUntil]) : null; if (lockedUntil && lockedUntil.getTime() > now.getTime()) { fhOpsUiB06DSecurityLog_(env.masterDb,'LOGIN_LOCKED','WARNING',email,employee.employeeId,employee.role,'','FAIL','로그인 실패 잠금 유지',{lockedUntil:lockedUntil}); return fhOpsUiB04EFail_('로그인 실패 횟수 초과로 잠금 상태입니다.', 'LOGIN_LOCKED', { email: email, lockedUntil: lockedUntil }); }
    var salt2 = map.passwordSalt != null ? String(row[map.passwordSalt] || '') : ''; var hash2 = map.passwordHash != null ? String(row[map.passwordHash] || '') : '';
    if (!salt2 || !hash2 || fhOpsUiB06Hash_(password, salt2) !== hash2) { var fc = map.failedCount != null ? Number(row[map.failedCount] || 0) + 1 : 1; var updates = { failedCount:fc, updatedAt:now, updatedBy:user }; if (fc >= maxFail) updates.lockedUntil = new Date(now.getTime()+lockMinutes*60*1000); fhOpsUiB06SetRow_(auth, updates); fhOpsUiB06DSecurityLog_(env.masterDb,fc>=maxFail?'LOGIN_LOCKED':'LOGIN_FAILED','WARNING',email,employee.employeeId,employee.role,'','FAIL','비밀번호 불일치',{failedCount:fc,lockedUntil:updates.lockedUntil||''}); return fhOpsUiB04EFail_(fc>=maxFail?'로그인 실패 횟수 초과로 30분 잠금 처리되었습니다.':'비밀번호가 맞지 않습니다.', fc>=maxFail?'LOGIN_LOCKED':'LOGIN_FAILED', { email: email, failedCount: fc, lockedUntil: updates.lockedUntil || '' }); }
    fhOpsUiB06SetRow_(auth, { failedCount:0, lockedUntil:'', lastLoginAt:now, updatedAt:now, updatedBy:user });
  }
  auth = fhOpsUiB06FindAuthByEmail_(authSh, email); var mustChange = auth && auth.map.mustChangePassword != null ? String(auth.row[auth.map.mustChangePassword] || 'N').trim().toUpperCase() : 'N';
  var token = fhOpsUiB06RandomToken_(); var expires = new Date(now.getTime() + 8*60*60*1000); var sessMap = fhOpsUiB04EHeaderMap_(sessSh); var sessionId='SES-' + Utilities.formatDate(now, Session.getScriptTimeZone() || 'Asia/Seoul', 'yyyyMMddHHmmss') + '-' + Math.floor(Math.random()*1000);
  var sessObj = { sessionId:sessionId, sessionToken:token, employeeId:employee.employeeId, email:email, role:employee.role, vendorId:employee.vendorId, eventScope:employee.eventScope, status:'ACTIVE', issuedAt:now, expiresAt:expires, lastSeenAt:now, createdAt:now, updatedAt:now, memo:'B06D ERP 자체 로그인 / 8시간 만료' };
  sessSh.appendRow(Object.keys(sessMap).map(function(h){ return sessObj[h] == null ? '' : sessObj[h]; })); fhOpsUiB06DSecurityLog_(env.masterDb,'LOGIN_SUCCESS','INFO',email,employee.employeeId,employee.role,sessionId,'OK','로그인 성공',{mustChangePassword:mustChange,expiresAt:expires});
  return fhOpsUiB04EOk_('로그인 성공', { sessionToken:token, expiresAt:expires, userEmail:email, employeeId:employee.employeeId, employeeName:employee.userName, role:employee.role, vendorId:employee.vendorId, eventScope:employee.eventScope, authMode:'ERP_SESSION_TOKEN', mustChangePassword:mustChange, passwordChangeRequired:mustChange==='Y' });
}
function fhOpsUiB06ResolveSession_(masterDb, token) {token = String(token || '').trim(); if (!token) return null; var sh = fhOpsUiB04EGetSheet_(masterDb, ['EmployeeSessions'], false); var found = fhOpsUiB06FindSessionByToken_(sh, token); if (!found) return null; var map=found.map, row=found.row; var status = map.status != null ? String(row[map.status] || '').trim().toUpperCase() : 'ACTIVE'; var exp = map.expiresAt != null ? row[map.expiresAt] : ''; var expDate = exp instanceof Date ? exp : new Date(exp); var sessionId = map.sessionId != null ? String(row[map.sessionId]||'') : ''; var email = map.email != null ? String(row[map.email] || '').trim().toLowerCase() : ''; if (status !== 'ACTIVE' || isNaN(expDate.getTime()) || expDate.getTime() < new Date().getTime()) { if(status==='ACTIVE' && expDate && !isNaN(expDate.getTime()) && expDate.getTime() < new Date().getTime()) fhOpsUiB06SetRow_(found,{status:'EXPIRED',updatedAt:new Date(),lastSeenAt:new Date()}); fhOpsUiB06DSecurityLog_(masterDb,'SESSION_INVALID','WARNING',email,'','',sessionId,'FAIL','세션 무효 또는 만료',{status:status,expiresAt:exp}); return null;} var employee = fhOpsUiB05MFindEmployeeByEmail_(masterDb, email); if (!employee || !employee.isActive) return null; fhOpsUiB06SetRow_(found, { lastSeenAt:new Date(), updatedAt:new Date() }); var mustChange = fhOpsUiB06DGetAuthMustChange_(masterDb,email); return { userEmail:email, sessionEmail:email, operatorEmail:email, authMode:'ERP_SESSION_TOKEN', employee:employee, role:employee.role || 'VIEWER', employeeFound:true, sessionToken:token, mustChangePassword:mustChange, passwordChangeRequired:mustChange==='Y', sessionId:sessionId };}
function fhOpsUiB04EContext_(payload) {const setup = SpreadsheetApp.openById(FH_OPS_UI_B03.SETUP_DB_ID); const configSheet = setup.getSheetByName(FH_OPS_UI_B03.CONFIG_SHEET_NAME); if (!configSheet) throw new Error('SystemConfig 시트를 찾을 수 없습니다.'); const config = fhOpsUiB04EReadKeyValue_(configSheet); const masterDbId = String(config.FEELHAUS_DB_MASTER_ID || config.MASTER_DB_ID || config.DB_MASTER_ID || '').trim(); if (!masterDbId) throw new Error('SystemConfig에서 FEELHAUS_DB_MASTER ID를 찾을 수 없습니다.'); const masterDb = SpreadsheetApp.openById(masterDbId); const actor = fhOpsUiB05MResolveActor_(masterDb, payload || {}); return { setupDb: setup, config: config, masterDbId: masterDbId, masterDb: masterDb, userEmail: actor.userEmail, sessionEmail: actor.sessionEmail, operatorEmail: actor.operatorEmail, authMode: actor.authMode, employee: actor.employee, role: actor.role, mustChangePassword: actor.mustChangePassword || 'N', passwordChangeRequired: !!actor.passwordChangeRequired, sessionId: actor.sessionId || '', sessionToken: actor.sessionToken || '' };}
function fhOpsUiB05MAssertActionPermission_(ctx, action) {if (!ctx || !ctx.userEmail || ctx.userEmail === 'UNKNOWN_USER') {throw new Error('로그인이 필요합니다. 운영버튼 상단의 ERP 로그인에서 이메일/비밀번호로 로그인하세요.');} if (ctx.passwordChangeRequired) {throw new Error('초기 비밀번호 변경이 필요합니다. 상단 ERP 로그인 영역에서 비밀번호를 먼저 변경하세요.');} const role = fhOpsUiB05MNormalizeRole_(ctx.role || 'VIEWER'); const manualMode = String(ctx.authMode || '') === 'MANUAL_EMPLOYEE_EMAIL_LIMITED'; if (manualMode && (!ctx.employee || !ctx.employee.isActive)) {throw new Error('등록된 활성 직원이 아닙니다: ' + ctx.userEmail + ' / Employees.email, status=ACTIVE를 확인하세요.');} const actionCode = String(action || '').toUpperCase(); const adminRoles = ['SUPER_ADMIN','HQ_ADMIN','HQ_MANAGER','ACCOUNTING_MANAGER']; const settlementSensitive = ['CREATE_SETTLEMENT','CREATE_SETTLEMENT_CONFIRM','REQUEST_SETTLEMENT_APPROVAL','APPROVE_SETTLEMENT','COMPLETE_PAYMENT','RUN_CONTROL_DIAG','CREATE_TEST_SAMPLES','RESET_TEST_SAMPLES']; if (settlementSensitive.indexOf(actionCode) >= 0 && adminRoles.indexOf(role) < 0) {throw new Error('권한 없음: ' + role + ' 계정은 ' + actionCode + ' 작업을 실행할 수 없습니다.');} const staffAllowed = ['CREATE_CONTRACT_DOC','CREATE_INSTALL_CONFIRM','OPEN_SIGN_LINK','GENERATE_PDF','ARCHIVE_DOC']; if (['STAFF_SALES','STAFF_INSTALL','STAFF_AS','VIEWER'].indexOf(role) >= 0 && staffAllowed.indexOf(actionCode) < 0) {throw new Error('권한 없음: ' + role + ' 계정은 문서/서명/PDF/보관 작업만 허용됩니다.');} return true;}
function fhOpsUiB06ChangePassword(payload){payload=payload||{}; var env=fhOpsUiB06GetMasterDb_(); var token=fhOpsUiB06GetSessionToken_(payload); var actor=fhOpsUiB06ResolveSession_(env.masterDb,token); if(!actor) return fhOpsUiB04EFail_('유효한 세션이 아닙니다. 다시 로그인하세요.','SESSION_REQUIRED',{}); var current=String(payload.currentPassword||''); var next=String(payload.newPassword||''); var confirm=String(payload.confirmPassword||''); if(!current||!next) return fhOpsUiB04EFail_('현재 비밀번호와 새 비밀번호가 필요합니다.','PASSWORD_REQUIRED',{}); if(next!==confirm) return fhOpsUiB04EFail_('새 비밀번호 확인이 일치하지 않습니다.','PASSWORD_CONFIRM_MISMATCH',{}); try{fhOpsUiB06DAssertPasswordPolicy_(next);}catch(e){return fhOpsUiB04EFail_(e.message,'PASSWORD_POLICY_FAILED',{});} var authSh=fhOpsUiB06EnsureSheet_(env.masterDb,'EmployeeAuth',fhOpsUiB06AuthHeaders_()); var auth=fhOpsUiB06FindAuthByEmail_(authSh,actor.userEmail); if(!auth) return fhOpsUiB04EFail_('인증 정보를 찾지 못했습니다.','AUTH_NOT_FOUND',{}); var salt=auth.map.passwordSalt!=null?String(auth.row[auth.map.passwordSalt]||''):''; var hash=auth.map.passwordHash!=null?String(auth.row[auth.map.passwordHash]||''):''; if(!salt||!hash||fhOpsUiB06Hash_(current,salt)!==hash){fhOpsUiB06DSecurityLog_(env.masterDb,'PASSWORD_CHANGE_FAILED','WARNING',actor.userEmail,actor.employee&&actor.employee.employeeId,actor.role,actor.sessionId,'FAIL','현재 비밀번호 불일치',{});return fhOpsUiB04EFail_('현재 비밀번호가 맞지 않습니다.','CURRENT_PASSWORD_FAILED',{});} var newSalt=fhOpsUiB06RandomToken_().substring(0,16); var newHash=fhOpsUiB06Hash_(next,newSalt); fhOpsUiB06SetRow_(auth,{passwordHash:newHash,passwordSalt:newSalt,mustChangePassword:'N',failedCount:0,lockedUntil:'',updatedAt:new Date(),updatedBy:actor.userEmail,memo:'B06D password changed'}); fhOpsUiB06DSecurityLog_(env.masterDb,'PASSWORD_CHANGED','INFO',actor.userEmail,actor.employee&&actor.employee.employeeId,actor.role,actor.sessionId,'OK','비밀번호 변경 완료',{}); return fhOpsUiB04EOk_('비밀번호 변경 완료',{userEmail:actor.userEmail,mustChangePassword:'N'});}
function fhOpsUiB06Logout(payload) {var token = fhOpsUiB06GetSessionToken_(payload || {}); if (!token) return fhOpsUiB04EOk_('로그아웃 처리 완료', { loggedOut:false }); var env = fhOpsUiB06GetMasterDb_(); var sh = fhOpsUiB06EnsureSheet_(env.masterDb, 'EmployeeSessions', fhOpsUiB06SessionHeaders_()); var found = fhOpsUiB06FindSessionByToken_(sh, token); var email='', employeeId='', role='', sessionId=''; if(found){var map=found.map,row=found.row; email=map.email!=null?String(row[map.email]||''):''; employeeId=map.employeeId!=null?String(row[map.employeeId]||''):''; role=map.role!=null?String(row[map.role]||''):''; sessionId=map.sessionId!=null?String(row[map.sessionId]||''):''; fhOpsUiB06SetRow_(found, { status:'LOGGED_OUT', lastSeenAt:new Date(), updatedAt:new Date() });} fhOpsUiB06DSecurityLog_(env.masterDb,'LOGOUT','INFO',email,employeeId,role,sessionId,'OK','로그아웃 처리',{loggedOut:!!found}); return fhOpsUiB04EOk_('로그아웃 처리 완료', { loggedOut:!!found });}
function testB06DSecurityPreflight(){var env=fhOpsUiB06GetMasterDb_(); fhOpsUiB06EnsureSheet_(env.masterDb,'EmployeeAuth',fhOpsUiB06AuthHeaders_()); fhOpsUiB06EnsureSheet_(env.masterDb,'EmployeeSessions',fhOpsUiB06SessionHeaders_()); fhOpsUiB06EnsureSheet_(env.masterDb,'SecurityEvents',fhOpsUiB06DSecurityLogHeaders_()); return fhOpsUiB04EOk_('B06D 보안강화 사전점검 완료',{sheets:['EmployeeAuth','EmployeeSessions','SecurityEvents'],sessionHours:8,lockRule:'5회 실패 시 30분 잠금',buildNo:'v64-B06D'});}

function testB06GPasswordRecoveryPreflight(){
  var env=fhOpsUiB06GetMasterDb_();
  fhOpsUiB06EnsureSheet_(env.masterDb,'EmployeeAuth',fhOpsUiB06AuthHeaders_());
  fhOpsUiB06EnsureSheet_(env.masterDb,'EmployeeSessions',fhOpsUiB06SessionHeaders_());
  fhOpsUiB06EnsureSheet_(env.masterDb,'SecurityEvents',fhOpsUiB06DSecurityLogHeaders_());
  fhOpsUiB06BEnsureSheet_(env.masterDb,'ApprovalAudit',fhOpsUiB06BApprovalAuditHeaders_());
  return fhOpsUiB04EOk_('B06J1 현장 QR 생성 메뉴 사전점검 완료',{sheets:['EmployeeAuth','EmployeeSessions','SecurityEvents','ApprovalAudit'],buildNo:'v64-B06J35-10'});
}

/* ===== B06H1 AUDIT LOG BOARD =====
 * 목적: 직원계정관리 화면에서 최근 보안 이벤트와 승인/계정 감사 기록을 조회한다.
 * 유지: 기존 저장/서명/PDF/정산/권한 로직 변경 없음.
 */
function fhB06HSheetRows_(sh, limit) {
  limit = Math.max(1, Math.min(Number(limit || 30), 100));
  if (!sh || sh.getLastRow() < 2) return [];
  var lastCol = sh.getLastColumn();
  var headers = sh.getRange(1, 1, 1, lastCol).getValues()[0].map(function(h){ return String(h || '').trim(); });
  var count = Math.min(limit, sh.getLastRow() - 1);
  var start = Math.max(2, sh.getLastRow() - count + 1);
  var values = sh.getRange(start, 1, count, lastCol).getValues();
  return values.map(function(row){
    var o = {};
    headers.forEach(function(h, i){
      var v = row[i];
      if (v instanceof Date) v = Utilities.formatDate(v, Session.getScriptTimeZone(), 'yyyy-MM-dd HH:mm:ss');
      o[h] = v == null ? '' : String(v);
    });
    return o;
  }).reverse();
}
function fhB06HGetAuditLogBoard(payload) {
  var ctx = fhOpsUiB04EContext_(payload || {});
  fhOpsUiB06BRequireAdmin_(ctx);
  var limit = Math.max(1, Math.min(Number((payload && payload.limit) || 50), 100));
  var filterType = String((payload && payload.filterType) || 'ALL').toUpperCase();
  var keyword = String((payload && payload.keyword) || '').toLowerCase().trim();
  function hitKeyword(o){ if (!keyword) return true; return JSON.stringify(o || {}).toLowerCase().indexOf(keyword) >= 0; }
  function hitType(text, status){
    text = String(text || '').toUpperCase(); status = String(status || '').toUpperCase();
    if (filterType === 'ALL') return true;
    if (filterType === 'FAILED') return status === 'FAIL' || text.indexOf('FAIL') >= 0 || text.indexOf('INVALID') >= 0 || text.indexOf('DENIED') >= 0;
    if (filterType === 'LOGIN') return text.indexOf('LOGIN') >= 0 || text.indexOf('LOGOUT') >= 0 || text.indexOf('SESSION') >= 0;
    if (filterType === 'PASSWORD') return text.indexOf('PASSWORD') >= 0 || text.indexOf('RESET') >= 0;
    if (filterType === 'EMPLOYEE') return text.indexOf('EMPLOYEE') >= 0 || text.indexOf('ACCOUNT') >= 0 || text.indexOf('STATUS') >= 0;
    if (filterType === 'ROLE') return text.indexOf('ROLE') >= 0 || text.indexOf('APPROVE') >= 0 || text.indexOf('AUTH') >= 0;
    if (filterType === 'SETTLEMENT') return text.indexOf('SETTLEMENT') >= 0 || text.indexOf('PAY') >= 0;
    if (filterType === 'DOCUMENT') return text.indexOf('DOCUMENT') >= 0 || text.indexOf('PDF') >= 0 || text.indexOf('ARCHIVE') >= 0 || text.indexOf('SIGN') >= 0;
    return true;
  }
  var scanLimit = Math.max(limit * 3, 100);
  var secSh = fhOpsUiB06EnsureSheet_(ctx.masterDb, 'SecurityEvents', fhOpsUiB06DSecurityLogHeaders_());
  var auditSh = fhOpsUiB06BEnsureSheet_(ctx.masterDb, 'ApprovalAudit', fhOpsUiB06BApprovalAuditHeaders_());
  var securityEvents = fhB06HSheetRows_(secSh, scanLimit).map(function(o){ return {
      eventId: o.eventId || o.logId || '', eventType: o.eventType || o.actionType || '', severity: o.severity || '',
      email: o.email || o.userEmail || '', employeeId: o.employeeId || '', role: o.role || '',
      result: o.result || o.status || '', message: o.message || '', createdAt: o.createdAt || o.at || o.eventAt || ''
    }; }).filter(function(o){ return hitType(o.eventType + ' ' + o.message, o.result) && hitKeyword(o); }).slice(0, limit);
  var approvalAudits = fhB06HSheetRows_(auditSh, scanLimit).map(function(o){ return {
      auditId: o.auditId || '', actionType: o.actionType || '', targetId: o.targetId || '', status: o.status || '',
      actor: o.actor || '', refId: o.refId || '', reason: o.reason || '', approvedBy: o.approvedBy || '', createdAt: o.createdAt || ''
    }; }).filter(function(o){ return hitType(o.actionType + ' ' + o.reason, o.status) && hitKeyword(o); }).slice(0, limit);
  return fhOpsUiB04EOk_('B06H4 운영/보안 감사로그 필터 조회 완료', {
    securityEvents: securityEvents, approvalAudits: approvalAudits,
    securityCount: securityEvents.length, approvalCount: approvalAudits.length,
    filterType: filterType, keyword: keyword, limit: limit, buildNo: 'v64-B06J34G'
  });
}
function testB06H1AuditLogBoardPreflight() {
  var env = fhOpsUiB06GetMasterDb_();
  fhOpsUiB06EnsureSheet_(env.masterDb, 'SecurityEvents', fhOpsUiB06DSecurityLogHeaders_());
  fhOpsUiB06BEnsureSheet_(env.masterDb, 'ApprovalAudit', fhOpsUiB06BApprovalAuditHeaders_());
  return fhOpsUiB04EOk_('B06H8 운영/보안 감사로그 사전점검 완료', { sheets:['SecurityEvents','ApprovalAudit'], buildNo:'v64-B06J35-10' });
}

/********** FEELHAUS ERP OPS UI v64-B06J34G WORKLIST FINAL OVERRIDE **********/
function fhOpsUiB05GetWorklists(payload){ return erpB06J28_getWorklists_(payload || {}); }
function fhOpsUiB05HetWorklists(payload){ return erpB06J28_getWorklists_(payload || {}); }
var erpB06J28_opsUiWorklistOverridePreflight_ = function(){
  return {ok:true,message:'B06J29 OPS UI 목록조회 최종 진입은 fhB05GetWorklists로 고정되었습니다.',data:{buildNo:'v64-B06J35-10',publicFunctions:['fhOpsUiB05GetWorklists','fhOpsUiB05HetWorklists','B06J28_legacy_removed']},errorCode:'',meta:{buildNo:'OPS-UI-20260430-B06J35-10',generatedAt:new Date().toISOString()}};
}

/** B06J29 B05 compatibility wrappers */
function fhOpsUiB05GetWorklists(payload){ return fhB05GetWorklists(payload || {}); }
function fhOpsUiB05HetWorklists(payload){ return fhB05GetWorklists(payload || {}); }
function erpB06J29_opsUiPreflight(){ return {ok:true,message:'B06J29 OPS UI B05 wrappers route to fhB05GetWorklists',data:{buildNo:'v64-B06J35-10',opsBuild:'OPS-UI-20260430-B06J35-10'},errorCode:'',meta:{generatedAt:new Date().toISOString()}}; }

/** B06J29 hard route: prevent legacy B05 worklist functions from taking old/deprecated paths. */
var fhOpsUiB05GetWorklists = function(payload){ return fhB05GetWorklists(payload || {}); };
var fhOpsUiB05HetWorklists = function(payload){ return fhB05GetWorklists(payload || {}); };
