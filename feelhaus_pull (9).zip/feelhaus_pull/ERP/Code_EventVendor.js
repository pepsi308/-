/**
 * FEELHAUS ERP - Event/Vendor Policy Schema Preflight v32R1
 * ERP_B06J36_32R1_EVENT_VENDOR_POLICY_SCHEMA_PREFLIGHT_CHECKER_FIX_SAFE
 * 목적: ERP 본체 분리 안정화 후 행사-업체 연결 상태전이/잠금/로그 안정화 + 연결 선택 전 상태버튼 UI 가드.
 * 범위: 행사업체 조회/저장/상태전이/잠금 + 연결별 상품/품목 등록/조회/중복차단/가격검증/상품상태전이/로그/운영 UI 가드. 정산 실행·상품권·민감권한 실행은 제외. B30 안정본 기준에서 결제구조/정산정책 확장 전 사전점검만 수행한다. 기능/계산/화면 변경 없음.
 */

function renderEventVendorCorePage_() {
  return HtmlService.createHtmlOutputFromFile('EventVendor')
    .setTitle('ERP_event_vendor_product_ui_operate_v26')
    .setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL);
}

function tryHandleEventVendorRoute_(e) {
  var page = '';
  try { page = String((e && e.parameter && e.parameter.page) ? e.parameter.page : '').trim(); } catch (err) { page = ''; }
  if (page !== 'eventVendor') return null;
  return renderEventVendorCorePage_();
}

function EV8_getSpreadsheet_() {
  var props = PropertiesService.getScriptProperties();
  var id = props.getProperty('DB_SPREADSHEET_ID') || props.getProperty('SPREADSHEET_ID');
  if (!id) throw new Error('SPREADSHEET_ID 또는 DB_SPREADSHEET_ID가 없습니다.');
  return SpreadsheetApp.openById(id);
}
function EV8_now_() {
  return Utilities.formatDate(new Date(), Session.getScriptTimeZone() || 'Asia/Seoul', 'yyyy-MM-dd HH:mm:ss');
}
function EV8_s_(v) { return String(v === null || v === undefined ? '' : v).trim(); }
function EV8_n_(v) { return Number(String(v === null || v === undefined ? '' : v).replace(/,/g,'').trim()) || 0; }
function EV8_makeId_(prefix) {
  return prefix + Utilities.formatDate(new Date(), Session.getScriptTimeZone() || 'Asia/Seoul', 'yyyyMMddHHmmss') + '-' + Math.floor(Math.random() * 1000);
}
function EV8_canon_(header) {
  var h = EV8_s_(header);
  var map = {
    '행사ID':'eventId','행사명':'eventName','행사구분':'eventType','시작일':'startDate','종료일':'endDate','행사장소':'eventPlace','담당자':'manager','상태값':'status','메모':'memo','생성일시':'createdAt','수정일시':'updatedAt','수정자':'updatedBy','기준행사ID':'baseEventId',
    '업체ID':'vendorId','업체명':'vendorName','대표자':'ownerName','연락처':'phone','지역':'region','기준업체ID':'baseVendorId',
    '연결ID':'linkId','행사업체연결ID':'eventVendorId','eventVendorId':'eventVendorId','eventVendorNo':'eventVendorNo','vendorRole':'vendorRole','업체역할':'vendorRole','boothNo':'boothNo','부스번호':'boothNo','category':'category','카테고리':'category','승인상태':'approvalStatus','상태변경사유':'statusReason','반려사유':'rejectReason','승인자':'approvedBy','승인일시':'approvedAt',
    '로그ID':'logId','구분':'actionType','로그유형':'actionType','대상키':'targetKey','대상명':'targetName','내용':'message','처리일시':'createdAt','처리자':'createdBy','사용자':'createdBy',
    '상품ID':'productId','품목ID':'productId','productId':'productId','상품명':'productName','품목명':'productName','productName':'productName','기본가':'basePrice','판매가':'basePrice','basePrice':'basePrice','상품상태':'productStatus','품목상태':'productStatus','productStatus':'productStatus'
  };
  return map[h] || h;
}
function EV8_applyAliases_(obj) {
  var alias = {eventId:['행사ID'],eventName:['행사명'],eventType:['행사구분'],startDate:['시작일'],endDate:['종료일'],eventPlace:['행사장소'],manager:['담당자'],status:['상태값'],memo:['메모'],createdAt:['생성일시','처리일시'],updatedAt:['수정일시'],updatedBy:['수정자'],vendorId:['업체ID'],vendorName:['업체명'],ownerName:['대표자'],phone:['연락처'],region:['지역'],linkId:['연결ID'],eventVendorId:['행사업체연결ID'],vendorRole:['업체역할'],boothNo:['부스번호'],category:['카테고리'],actionType:['구분'],targetKey:['대상키'],targetName:['대상명'],message:['내용'],createdBy:['사용자','처리자'],productId:['상품ID','품목ID'],productName:['상품명','품목명'],basePrice:['기본가','판매가'],productStatus:['상품상태','품목상태']};
  Object.keys(alias).forEach(function(k){ if (obj[k] !== undefined) alias[k].forEach(function(a){ if (obj[a] === undefined) obj[a] = obj[k]; }); });
  return obj;
}
function EV8_normalizeDataKeys_(data) {
  var out = {};
  Object.keys(data || {}).forEach(function(k){ out[EV8_canon_(k)] = data[k]; out[k] = data[k]; });
  return out;
}
function EV8_ensureSheet_(name, headers) {
  var ss = EV8_getSpreadsheet_();
  var sh = ss.getSheetByName(name);
  var canonical = headers.map(EV8_canon_);
  if (!sh) sh = ss.insertSheet(name);
  if (sh.getLastRow() === 0) {
    sh.getRange(1,1,1,canonical.length).setValues([canonical]);
    sh.setFrozenRows(1);
    return sh;
  }
  var width = Math.max(sh.getLastColumn(), canonical.length, 1);
  var current = sh.getRange(1,1,1,width).getDisplayValues()[0].map(EV8_s_);
  for (var i = 0; i < current.length; i++) {
    var canon = EV8_canon_(current[i]);
    if (canon && canon !== current[i]) { sh.getRange(1, i + 1).setValue(canon); current[i] = canon; }
  }
  canonical.forEach(function(h){ if (current.indexOf(h) === -1) { sh.getRange(1, current.length + 1).setValue(h); current.push(h); } });
  sh.setFrozenRows(1);
  return sh;
}
function EV8_eventSheet_() { return EV8_ensureSheet_('ERP_행사관리', ['eventId','eventName','eventType','startDate','endDate','eventPlace','manager','status','memo','createdAt','updatedAt','updatedBy','baseEventId','eventUid']); }
function EV8_vendorSheet_() { return EV8_ensureSheet_('ERP_업체관리', ['vendorId','vendorName','ownerName','phone','region','manager','status','memo','createdAt','updatedAt','updatedBy','baseVendorId','vendorUid']); }
function EV8_linkSheet_() { return EV8_ensureSheet_('ERP_행사업체연결', ['linkId','eventVendorId','eventId','eventName','vendorId','vendorName','vendorRole','boothNo','category','status','statusReason','approvalStatus','rejectReason','memo','approvedBy','approvedAt','createdAt','createdBy','updatedAt','updatedBy']); }
function EV8_logSheet_() { return EV8_ensureSheet_('ERP_행사업체로그', ['logId','actionType','targetKey','targetName','message','createdAt','createdBy','beforeValue','afterValue','reason','relatedDocumentNo']); }
function EV24_productSheet_() { return EV8_ensureSheet_('ERP_행사업체상품', ['productId','eventVendorId','linkId','eventId','eventName','vendorId','vendorName','productName','category','basePrice','productStatus','memo','createdAt','createdBy','updatedAt','updatedBy']); }



/* =====================================================================
 * B06J36-30 SETTLEMENT PREVIEW AUDIT SAFE
 * 범위: 정산 미리보기 결과에 previewId를 부여하고 입력/결과 스냅샷을 별도 로그로 보관한다.
 * 실제 정산 확정/지급/전표/SIGN 기프트 정산 인계는 실행하지 않는다.
 * ===================================================================== */
function EV30_previewSheet_() {
  return EV8_ensureSheet_('ERP_정산미리보기로그', [
    'previewId','eventVendorId','linkId','eventId','eventName','vendorId','vendorName','policyId','policyName','productIds','productCount','baseAmount','commissionRate','fixedFee','commissionAmount','fixedFeeAmount','totalDeduction','estimatedPayout','mode','inputSnapshot','resultSnapshot','createdAt','createdBy'
  ]);
}
function EV30_safeJson_(v){ try { return JSON.stringify(v || {}); } catch(e){ return String(v); } }
function EV30_appendPreviewSnapshot_(out, inputSnapshot) {
  var t = out.totals || {}, p = out.policy || {};
  var productIds = (out.rows || []).map(function(r){ return EV8_s_(r.productId); }).filter(String).join(',');
  EV8_appendObjectByHeaders_(EV30_previewSheet_(), {
    previewId: out.previewId,
    eventVendorId: out.eventVendorId,
    linkId: out.eventVendorId,
    eventId: out.eventId,
    eventName: out.eventName,
    vendorId: out.vendorId,
    vendorName: out.vendorName,
    policyId: p.policyId,
    policyName: p.policyName,
    productIds: productIds,
    productCount: t.productCount,
    baseAmount: t.grossAmount,
    commissionRate: p.commissionRate,
    fixedFee: p.fixedFee,
    commissionAmount: t.rateFee,
    fixedFeeAmount: t.fixedFeeApplied,
    totalDeduction: t.totalFee,
    estimatedPayout: t.vendorExpectedAmount,
    mode: 'PREVIEW_ONLY',
    inputSnapshot: EV30_safeJson_(inputSnapshot),
    resultSnapshot: EV30_safeJson_(out),
    createdAt: EV8_now_(),
    createdBy: (function(){ try { return Session.getActiveUser().getEmail() || ''; } catch(e){ return ''; } })()
  });
}

function EV8_appendLog_(kind, targetKey, targetName, content) {
  EV8_appendObjectByHeaders_(EV8_logSheet_(), {
    logId: EV8_makeId_('LOG-'), actionType: kind, targetKey: EV8_s_(targetKey), targetName: EV8_s_(targetName), message: EV8_s_(content), createdAt: EV8_now_(),
    createdBy: (function(){ try { return Session.getActiveUser().getEmail() || ''; } catch(e){ return ''; } })()
  });
}
function EV8_rowsToObjects_(sh) {
  var values = sh.getDataRange().getDisplayValues();
  if (!values || values.length < 2) return [];
  var headers = values[0].map(EV8_s_);
  return values.slice(1).filter(function(r){ return r.join('').trim() !== ''; }).map(function(r, idx){
    var o = { __rowNum: idx + 2 };
    headers.forEach(function(h, i){ var c = EV8_canon_(h); o[h] = r[i]; if (o[c] === undefined) o[c] = r[i]; });
    return EV8_applyAliases_(o);
  });
}
function EV8_findRowById_(sh, idHeader, idValue) {
  var rows = EV8_rowsToObjects_(sh);
  for (var i = 0; i < rows.length; i++) if (EV8_s_(rows[i][idHeader]) === EV8_s_(idValue)) return rows[i];
  return null;
}
function EV8_setRowValuesByHeaders_(sh, rowNum, data) {
  var normalized = EV8_normalizeDataKeys_(data || {});
  var headerRow = sh.getRange(1,1,1,sh.getLastColumn()).getDisplayValues()[0].map(EV8_s_);
  headerRow.forEach(function(h, idx){
    var c = EV8_canon_(h);
    if (normalized[c] !== undefined) sh.getRange(rowNum, idx + 1).setValue(EV8_s_(normalized[c]));
    else if (normalized[h] !== undefined) sh.getRange(rowNum, idx + 1).setValue(EV8_s_(normalized[h]));
  });
}

function EV8_appendObjectByHeaders_(sh, data) {
  var normalized = EV8_normalizeDataKeys_(data || {});
  var headers = sh.getRange(1,1,1,sh.getLastColumn()).getDisplayValues()[0].map(EV8_s_);
  var row = headers.map(function(h){
    var c = EV8_canon_(h);
    if (normalized[c] !== undefined) return EV8_s_(normalized[c]);
    if (normalized[h] !== undefined) return EV8_s_(normalized[h]);
    return '';
  });
  sh.appendRow(row);
}
function EV8_getSheetObjects_(sheetName) {
  var sh = EV8_getSpreadsheet_().getSheetByName(sheetName);
  if (!sh) return [];
  var vals = sh.getDataRange().getDisplayValues();
  if (!vals || vals.length < 2) return [];
  var headers = vals[0].map(EV8_s_);
  return vals.slice(1).filter(function(r){ return r.join('').trim() !== ''; }).map(function(r){
    var o = {};
    headers.forEach(function(h, i){ var c = EV8_canon_(h); o[h] = r[i]; if (o[c] === undefined) o[c] = r[i]; });
    return EV8_applyAliases_(o);
  });
}
function EV8_getSalesRows_() { return EV8_getSheetObjects_('Sales'); }
function EV8_getCustomerRows_() { return EV8_getSheetObjects_('Customers'); }
function EV8_mapBy_(rows, key) {
  var map = {};
  rows.forEach(function(r){ map[EV8_s_(r[key])] = r; });
  return map;
}

function getEventVendorBootstrap() {
  var events = EV8_rowsToObjects_(EV8_eventSheet_());
  var vendors = EV8_rowsToObjects_(EV8_vendorSheet_());
  var links = EV8_rowsToObjects_(EV8_linkSheet_());
  var products = EV8_rowsToObjects_(EV24_productSheet_());
  return {
    stats: {
      totalEvents: events.length,
      activeEvents: events.filter(function(v){ var st=EV21_normalizeStatus_(v['상태값']); return st === 'ACTIVE' || EV8_s_(v['상태값']) === '운영중'; }).length,
      totalVendors: vendors.length,
      activeVendors: vendors.filter(function(v){ var st=EV21_normalizeStatus_(v['상태값']); return st === 'ACTIVE' || EV8_s_(v['상태값']) === '운영중'; }).length,
      totalLinks: links.length,
      totalProducts: products.length
    },
    events: events,
    vendors: vendors,
    links: links,
    products: products
  };
}

function saveEventVendorEvent(payload) {
  var sh = EV8_eventSheet_();
  var id = EV8_s_(payload['행사ID']);
  var now = EV8_now_();
  if (id) {
    var row = EV8_findRowById_(sh, '행사ID', id);
    if (!row) throw new Error('수정할 행사를 찾지 못했습니다: ' + id);
    EV8_setRowValuesByHeaders_(sh, row.__rowNum, {
      '행사명': payload['행사명'], '행사구분': payload['행사구분'], '시작일': payload['시작일'], '종료일': payload['종료일'],
      '행사장소': payload['행사장소'], '담당자': payload['담당자'], '상태값': payload['상태값'], '메모': payload['메모'], '수정일시': now
    });
    EV8_appendLog_('EVENT_UPDATE', id, payload['행사명'], '행사 수정');
    return { ok:true, mode:'update', eventId:id };
  }
  id = EV8_makeId_('EVT-');
  EV8_appendObjectByHeaders_(sh, {eventId:id, eventName:EV8_s_(payload['행사명']), eventType:EV8_s_(payload['행사구분']), startDate:EV8_s_(payload['시작일']), endDate:EV8_s_(payload['종료일']), eventPlace:EV8_s_(payload['행사장소']), manager:EV8_s_(payload['담당자']), status:EV8_s_(payload['상태값']) || '준비중', memo:EV8_s_(payload['메모']), createdAt:now, updatedAt:now});
  EV8_appendLog_('EVENT_CREATE', id, payload['행사명'], '행사 생성');
  return { ok:true, mode:'create', eventId:id };
}
function saveEventVendorVendor(payload) {
  var sh = EV8_vendorSheet_();
  var id = EV8_s_(payload['업체ID']);
  var now = EV8_now_();
  if (id) {
    var row = EV8_findRowById_(sh, '업체ID', id);
    if (!row) throw new Error('수정할 업체를 찾지 못했습니다: ' + id);
    EV8_setRowValuesByHeaders_(sh, row.__rowNum, {
      '업체명': payload['업체명'], '대표자': payload['대표자'], '연락처': payload['연락처'], '지역': payload['지역'],
      '담당자': payload['담당자'], '상태값': payload['상태값'], '메모': payload['메모'], '수정일시': now
    });
    EV8_appendLog_('VENDOR_UPDATE', id, payload['업체명'], '업체 수정');
    return { ok:true, mode:'update', vendorId:id };
  }
  id = EV8_makeId_('VND-');
  EV8_appendObjectByHeaders_(sh, {vendorId:id, vendorName:EV8_s_(payload['업체명']), ownerName:EV8_s_(payload['대표자']), phone:EV8_s_(payload['연락처']), region:EV8_s_(payload['지역']), manager:EV8_s_(payload['담당자']), status:EV8_s_(payload['상태값']) || '운영대기', memo:EV8_s_(payload['메모']), createdAt:now, updatedAt:now});
  EV8_appendLog_('VENDOR_CREATE', id, payload['업체명'], '업체 생성');
  return { ok:true, mode:'create', vendorId:id };
}

var EV21_BUILD_NO = 'v64-B06J36-28';
var EV21_BUILD_NAME = 'ERP_B06J36_32R1_EVENT_VENDOR_POLICY_SCHEMA_PREFLIGHT_CHECKER_FIX_SAFE';
var EV21_ALLOWED_STATUSES = ['DRAFT','READY','ACTIVE','HOLD','CLOSED','LOCKED'];

function EV21_normalizeStatus_(value) {
  var v = EV8_s_(value).toUpperCase();
  var map = {
    '준비':'DRAFT','준비중':'DRAFT','DRAFT':'DRAFT',
    '참여예정':'READY','운영대기':'READY','운영준비완료':'READY','READY':'READY',
    '운영중':'ACTIVE','참여중':'ACTIVE','ACTIVE':'ACTIVE',
    '보류':'HOLD','HOLD':'HOLD',
    '종료':'CLOSED','취소':'CLOSED','CLOSED':'CLOSED',
    '잠금':'LOCKED','LOCKED':'LOCKED'
  };
  return map[v] || map[EV8_s_(value)] || v;
}
function EV21_assertStatus_(status) {
  var st = EV21_normalizeStatus_(status || 'READY');
  if (EV21_ALLOWED_STATUSES.indexOf(st) < 0) throw new Error('허용되지 않는 행사업체 상태값입니다: ' + status);
  return st;
}
function EV21_getActiveUser_(){ try { return Session.getActiveUser().getEmail() || 'system'; } catch(e){ return 'system'; } }
function EV21_findByCanonicalId_(rows, key, value){
  value = EV8_s_(value);
  for (var i=0; i<rows.length; i++) if (EV8_s_(rows[i][key]) === value || EV8_s_(rows[i][EV8_canon_(key)]) === value) return rows[i];
  return null;
}
function EV21_ensureCoreHeaders_(){
  EV8_eventSheet_(); EV8_vendorSheet_(); EV8_linkSheet_(); EV8_logSheet_(); EV24_productSheet_();
  return { ok:true, eventSheet:'ERP_행사관리', vendorSheet:'ERP_업체관리', linkSheet:'ERP_행사업체연결', logSheet:'ERP_행사업체로그', productSheet:'ERP_행사업체상품' };
}


var EV23_TRANSITIONS = {
  DRAFT: ['READY','HOLD'],
  READY: ['ACTIVE','HOLD'],
  ACTIVE: ['CLOSED','HOLD'],
  HOLD: ['READY','ACTIVE'],
  CLOSED: ['LOCKED'],
  LOCKED: []
};
function EV23_canTransition_(fromStatus, toStatus) {
  var from = EV21_normalizeStatus_(fromStatus || 'DRAFT');
  var to = EV21_normalizeStatus_(toStatus || '');
  if (!to || EV21_ALLOWED_STATUSES.indexOf(to) < 0) return false;
  if (from === to) return true;
  return (EV23_TRANSITIONS[from] || []).indexOf(to) >= 0;
}
function EV23_reasonRequired_(toStatus) {
  var to = EV21_normalizeStatus_(toStatus || '');
  return ['HOLD','CLOSED','LOCKED'].indexOf(to) >= 0;
}
function EV23_assertCreateStatus_(status, reason) {
  var st = EV21_assertStatus_(status || 'READY');
  if (st === 'CLOSED' || st === 'LOCKED') throw new Error('신규 행사업체 연결은 CLOSED/LOCKED 상태로 바로 생성할 수 없습니다. 먼저 저장 후 상태전이로 처리하세요.');
  if (EV23_reasonRequired_(st) && !EV8_s_(reason)) throw new Error(st + ' 상태는 상태 변경 사유가 필요합니다.');
  return st;
}
function EV23_assertTransition_(fromStatus, toStatus, reason) {
  var from = EV21_assertStatus_(fromStatus || 'DRAFT');
  var to = EV21_assertStatus_(toStatus || '');
  if (from === 'LOCKED') throw new Error('LOCKED 상태의 행사업체 연결은 일반 상태변경/수정이 불가합니다. 재오픈은 승인 기반 후속 기능에서 처리합니다.');
  if (!EV23_canTransition_(from, to)) throw new Error('허용되지 않는 행사업체 상태 전이입니다: ' + from + ' → ' + to);
  if (from !== to && EV23_reasonRequired_(to) && !EV8_s_(reason)) throw new Error(to + ' 전환은 상태 변경 사유가 필요합니다.');
  return { fromStatus: from, toStatus: to };
}
function EV23_statusReasonGuardSelfTest_() {
  var result = { ok:true, tests:[] };
  function record(name, ok, detail){ result.tests.push({name:name, ok:!!ok, detail:detail||''}); if(!ok) result.ok=false; }
  function mustThrow(name, fn){ try { fn(); record(name, false, 'throw expected but passed'); } catch(e) { record(name, true, e.message || String(e)); } }
  function mustPass(name, fn){ try { fn(); record(name, true, 'passed'); } catch(e) { record(name, false, e.message || String(e)); } }
  mustThrow('ACTIVE to HOLD without transition reason is blocked', function(){ EV23_assertTransition_('ACTIVE','HOLD',''); });
  mustPass('ACTIVE to HOLD with transition reason is allowed', function(){ EV23_assertTransition_('ACTIVE','HOLD','보류 사유 테스트'); });
  mustThrow('ACTIVE to CLOSED without transition reason is blocked', function(){ EV23_assertTransition_('ACTIVE','CLOSED',''); });
  mustThrow('CLOSED to LOCKED without transition reason is blocked', function(){ EV23_assertTransition_('CLOSED','LOCKED',''); });
  mustThrow('LOCKED to READY is blocked', function(){ EV23_assertTransition_('LOCKED','READY','재오픈'); });
  mustThrow('create LOCKED is blocked', function(){ EV23_assertCreateStatus_('LOCKED','잠금'); });
  return result;
}
function EV23_appendStatusLog_(linkId, targetName, fromStatus, toStatus, reason, actor) {
  EV8_appendObjectByHeaders_(EV8_logSheet_(), {
    logId: EV8_makeId_('LOG-'),
    actionType: 'EVENT_VENDOR_STATUS_CHANGE',
    targetKey: EV8_s_(linkId),
    targetName: EV8_s_(targetName),
    message: '행사업체 상태 변경: ' + EV8_s_(fromStatus) + ' → ' + EV8_s_(toStatus),
    createdAt: EV8_now_(),
    createdBy: EV8_s_(actor) || EV21_getActiveUser_(),
    beforeValue: EV8_s_(fromStatus),
    afterValue: EV8_s_(toStatus),
    reason: EV8_s_(reason),
    relatedDocumentNo: ''
  });
}
function EV23_getLinkRow_(linkId) {
  var sh = EV8_linkSheet_();
  return EV8_findRowById_(sh, 'linkId', linkId) || EV8_findRowById_(sh, 'eventVendorId', linkId) || EV8_findRowById_(sh, '연결ID', linkId) || EV8_findRowById_(sh, '행사업체연결ID', linkId);
}
function changeEventVendorLinkStatus(payload) {
  EV21_ensureCoreHeaders_();
  payload = payload || {};
  var linkId = EV8_s_(payload.linkId || payload.eventVendorId || payload['연결ID'] || payload['행사업체연결ID']);
  var nextStatus = EV8_s_(payload.nextStatus || payload.status || payload['상태값']);
  var reason = EV8_s_(payload.reason || payload.statusReason || payload['상태변경사유']);
  if (!linkId) throw new Error('상태 변경할 연결ID가 필요합니다.');
  if (!nextStatus) throw new Error('변경할 상태값이 필요합니다.');
  var sh = EV8_linkSheet_();
  var row = EV23_getLinkRow_(linkId);
  if (!row) throw new Error('상태 변경할 행사업체 연결을 찾지 못했습니다: ' + linkId);
  var current = EV21_normalizeStatus_(row.status || row['상태값'] || 'DRAFT');
  var check = EV23_assertTransition_(current, nextStatus, reason);
  var actor = EV21_getActiveUser_();
  var targetName = (EV8_s_(row.eventName || row['행사명']) + '/' + EV8_s_(row.vendorName || row['업체명'])).replace(/^\//,'').replace(/\/$/,'');
  EV8_setRowValuesByHeaders_(sh, row.__rowNum, { status:check.toStatus, statusReason:reason, updatedAt:EV8_now_(), updatedBy:actor });
  if (check.fromStatus !== check.toStatus) EV23_appendStatusLog_(linkId, targetName, check.fromStatus, check.toStatus, reason, actor);
  return { ok:true, linkId:linkId, eventVendorId:EV8_s_(row.eventVendorId || row['행사업체연결ID']) || linkId, fromStatus:check.fromStatus, toStatus:check.toStatus, reason:reason };
}
function getEventVendorStatusHistory(linkId) {
  var key = EV8_s_(linkId);
  if (!key) return [];
  var rows = EV8_rowsToObjects_(EV8_logSheet_()).filter(function(r){
    return EV8_s_(r.targetKey || r['대상키']) === key || EV8_s_(r.eventVendorId || r['행사업체연결ID']) === key;
  }).filter(function(r){
    var a = EV8_s_(r.actionType || r['구분']);
    return a.indexOf('EVENT_VENDOR') >= 0 || a.indexOf('LINK') >= 0 || a.indexOf('STATUS') >= 0;
  });
  return rows.slice(-50).reverse();
}

function saveEventVendorLink(payload) {
  EV21_ensureCoreHeaders_();
  payload = payload || {};
  var sh = EV8_linkSheet_();
  var rows = EV8_rowsToObjects_(sh);
  var id = EV8_s_(payload['연결ID'] || payload.linkId || payload.eventVendorId);
  var eventId = EV8_s_(payload['행사ID'] || payload.eventId);
  var vendorId = EV8_s_(payload['업체ID'] || payload.vendorId);
  var now = EV8_now_();
  var actor = EV21_getActiveUser_();
  if (!eventId) throw new Error('행사ID는 필수입니다.');
  if (!vendorId) throw new Error('업체ID는 필수입니다.');

  var events = EV8_rowsToObjects_(EV8_eventSheet_());
  var vendors = EV8_rowsToObjects_(EV8_vendorSheet_());
  var event = EV21_findByCanonicalId_(events, 'eventId', eventId);
  var vendor = EV21_findByCanonicalId_(vendors, 'vendorId', vendorId);
  if (!event) throw new Error('존재하지 않는 행사ID입니다: ' + eventId);
  if (!vendor) throw new Error('존재하지 않는 업체ID입니다: ' + vendorId);

  // B06J36-23B: 상태전이 사유와 일반 메모/기존 사유를 분리한다.
  // 상태가 실제로 바뀌는 경우에는 반드시 신규 상태변경사유 전용 필드가 필요하다.
  var statusReason = EV8_s_(payload.statusReason || payload['상태변경사유']);
  var transitionReason = EV8_s_(payload.statusChangeReason || payload.transitionReason || payload.reasonNew || payload['상태변경사유_신규']);
  var status = EV21_assertStatus_(payload['상태값'] || payload.status || 'READY');
  var eventName = EV8_s_(payload['행사명'] || payload.eventName || event.eventName || event['행사명']);
  var vendorName = EV8_s_(payload['업체명'] || payload.vendorName || vendor.vendorName || vendor['업체명']);
  var dup = rows.filter(function(r){
    var samePair = EV8_s_(r.eventId || r['행사ID']) === eventId && EV8_s_(r.vendorId || r['업체ID']) === vendorId;
    var sameId = id && (EV8_s_(r.linkId || r['연결ID']) === id || EV8_s_(r.eventVendorId || r['행사업체연결ID']) === id);
    return samePair && !sameId;
  })[0];
  if (dup) throw new Error('이미 연결된 행사-업체입니다. eventId + vendorId 중복은 허용하지 않습니다.');

  var rowData = {
    linkId:id,
    eventVendorId:id,
    eventId:eventId,
    eventName:eventName,
    vendorId:vendorId,
    vendorName:vendorName,
    vendorRole:EV8_s_(payload.vendorRole || payload['업체역할']),
    boothNo:EV8_s_(payload.boothNo || payload['부스번호']),
    category:EV8_s_(payload.category || payload['카테고리']),
    status:status,
    statusReason:statusReason,
    memo:EV8_s_(payload['메모'] || payload.memo),
    updatedAt:now,
    updatedBy:actor
  };

  if (id) {
    var row = EV8_findRowById_(sh, 'linkId', id) || EV8_findRowById_(sh, 'eventVendorId', id);
    if (!row) throw new Error('수정할 연결을 찾지 못했습니다: ' + id);
    var currentStatus = EV21_normalizeStatus_(row.status || row['상태값'] || 'DRAFT');
    var requestedStatus = EV21_assertStatus_(status);
    if (currentStatus === 'LOCKED') throw new Error('LOCKED 상태의 행사업체 연결은 일반 수정할 수 없습니다.');
    if (currentStatus !== requestedStatus) {
      // B06J36-23B: 연결 저장 버튼을 통한 상태변경도 상태전이 규칙과 사유 필수 규칙을 동일하게 적용한다.
      // 특히 HOLD/CLOSED/LOCKED 전환은 기존 상태사유/메모가 아니라 이번 전환용 신규 상태변경사유가 반드시 필요하다.
      EV23_assertTransition_(currentStatus, requestedStatus, transitionReason);
      rowData.statusReason = transitionReason;
    }
    rowData.status = requestedStatus;
    EV8_setRowValuesByHeaders_(sh, row.__rowNum, rowData);
    EV8_appendLog_('EVENT_VENDOR_LINK_UPDATE', id, eventName + '/' + vendorName, '행사-업체 연결 수정');
    if (currentStatus !== requestedStatus) EV23_appendStatusLog_(id, eventName + '/' + vendorName, currentStatus, requestedStatus, transitionReason, actor);
    return { ok:true, mode:'update', linkId:id, eventVendorId:id, status:requestedStatus };
  }

  status = EV23_assertCreateStatus_(status, statusReason);
  rowData.status = status;
  id = EV8_makeId_('EVL-');
  rowData.linkId = id;
  rowData.eventVendorId = id;
  rowData.createdAt = now;
  rowData.createdBy = actor;
  EV8_appendObjectByHeaders_(sh, rowData);
  EV8_appendLog_('EVENT_VENDOR_LINK_CREATE', id, eventName + '/' + vendorName, '행사-업체 연결 생성');
  return { ok:true, mode:'create', linkId:id, eventVendorId:id, status:status };
}
function deleteEventVendorLink(linkId) {
  var sh = EV8_linkSheet_();
  var row = EV23_getLinkRow_(linkId);
  if (!row) throw new Error('삭제할 연결을 찾지 못했습니다: ' + linkId);
  if (EV21_normalizeStatus_(row.status || row['상태값']) === 'LOCKED') throw new Error('LOCKED 상태의 행사업체 연결은 삭제할 수 없습니다.');
  sh.deleteRow(row.__rowNum);
  EV8_appendLog_('LINK_DELETE', linkId, row['행사명'] + '/' + row['업체명'], '연결 삭제');
  return { ok:true, linkId:linkId };
}
function searchEventVendorData(type, query) {
  query = EV8_s_(query).toLowerCase();
  var rows = [];
  if (type === 'event') rows = EV8_rowsToObjects_(EV8_eventSheet_());
  else if (type === 'vendor') rows = EV8_rowsToObjects_(EV8_vendorSheet_());
  else rows = EV8_rowsToObjects_(EV8_linkSheet_());
  if (!query) return rows;
  return rows.filter(function(r){
    return Object.keys(r).some(function(k){
      if (k === '__rowNum') return false;
      return EV8_s_(r[k]).toLowerCase().indexOf(query) > -1;
    });
  });
}

function getEventVendorDetail(type, id) {
  var events = EV8_rowsToObjects_(EV8_eventSheet_());
  var vendors = EV8_rowsToObjects_(EV8_vendorSheet_());
  var links = EV8_rowsToObjects_(EV8_linkSheet_());
  var sales = EV8_getSalesRows_();
  var customers = EV8_getCustomerRows_();
  var customerMap = EV8_mapBy_(customers, 'customerId');

  if (type === 'event') {
    var eventRow = events.filter(function(v){ return EV8_s_(v['행사ID']) === EV8_s_(id); })[0];
    if (!eventRow) throw new Error('행사를 찾지 못했습니다: ' + id);
    var eventLinks = links.filter(function(v){ return EV8_s_(v['행사ID']) === EV8_s_(id); });
    var eventSales = sales.filter(function(v){ return EV8_s_(v['eventId']) === EV8_s_(id); });
    var eventCustomerIds = {};
    eventSales.forEach(function(v){ if (EV8_s_(v['customerId'])) eventCustomerIds[EV8_s_(v['customerId'])] = true; });
    var eventCustomers = Object.keys(eventCustomerIds).map(function(cid){
      var c = customerMap[cid] || {};
      return { customerId: cid, name: EV8_s_(c.name), phone: EV8_s_(c.phone), aptName: EV8_s_(c.aptName), dong: EV8_s_(c.dong), hosu: EV8_s_(c.hosu), address: EV8_s_(c.address) };
    });
    return {
      type:'event',
      detail:eventRow,
      linkCount:eventLinks.length,
      vendors:eventLinks,
      salesCount:eventSales.length,
      customerCount:eventCustomers.length,
      salesAmount:eventSales.reduce(function(a,v){ return a + EV8_n_(v['totalAmount']); }, 0),
      sales:eventSales.slice(-50).reverse(),
      customers:eventCustomers.slice(0,100)
    };
  }

  if (type === 'vendor') {
    var vendorRow = vendors.filter(function(v){ return EV8_s_(v['업체ID']) === EV8_s_(id); })[0];
    if (!vendorRow) throw new Error('업체를 찾지 못했습니다: ' + id);
    var vendorLinks = links.filter(function(v){ return EV8_s_(v['업체ID']) === EV8_s_(id); });
    var vendorSales = sales.filter(function(v){ return EV8_s_(v['vendorId']) === EV8_s_(id); });
    var vendorCustomerIds = {};
    vendorSales.forEach(function(v){ if (EV8_s_(v['customerId'])) vendorCustomerIds[EV8_s_(v['customerId'])] = true; });
    var vendorCustomers = Object.keys(vendorCustomerIds).map(function(cid){
      var c = customerMap[cid] || {};
      return { customerId: cid, name: EV8_s_(c.name), phone: EV8_s_(c.phone), aptName: EV8_s_(c.aptName), dong: EV8_s_(c.dong), hosu: EV8_s_(c.hosu), address: EV8_s_(c.address) };
    });
    return {
      type:'vendor',
      detail:vendorRow,
      linkCount:vendorLinks.length,
      events:vendorLinks,
      salesCount:vendorSales.length,
      customerCount:vendorCustomers.length,
      salesAmount:vendorSales.reduce(function(a,v){ return a + EV8_n_(v['totalAmount']); }, 0),
      sales:vendorSales.slice(-50).reverse(),
      customers:vendorCustomers.slice(0,100)
    };
  }
  throw new Error('지원하지 않는 상세 타입입니다.');
}

function getEventVendorCustomerDetail(customerId, type, scopeId) {
  var customers = EV8_getCustomerRows_();
  var sales = EV8_getSalesRows_();
  var customer = customers.filter(function(v){ return EV8_s_(v['customerId']) === EV8_s_(customerId); })[0] || {};
  var filteredSales = sales.filter(function(v){
    if (EV8_s_(v['customerId']) !== EV8_s_(customerId)) return false;
    if (type === 'event') return EV8_s_(v['eventId']) === EV8_s_(scopeId);
    if (type === 'vendor') return EV8_s_(v['vendorId']) === EV8_s_(scopeId);
    return true;
  });

  var byStatus = {};
  filteredSales.forEach(function(v){
    var s = EV8_s_(v['status']) || '미분류';
    byStatus[s] = (byStatus[s] || 0) + 1;
  });

  return {
    customer: {
      customerId: EV8_s_(customer['customerId']),
      name: EV8_s_(customer['name']),
      phone: EV8_s_(customer['phone']),
      email: EV8_s_(customer['email']),
      aptName: EV8_s_(customer['aptName']),
      dong: EV8_s_(customer['dong']),
      hosu: EV8_s_(customer['hosu']),
      address: EV8_s_(customer['address']),
      memberType: EV8_s_(customer['memberType'])
    },
    salesCount: filteredSales.length,
    salesAmount: filteredSales.reduce(function(a,v){ return a + EV8_n_(v['totalAmount']); }, 0),
    statusSummary: byStatus,
    sales: filteredSales.slice(-30).reverse(),
    saleDraft: {
      customerId: EV8_s_(customer['customerId']),
      customerName: EV8_s_(customer['name']),
      phone: EV8_s_(customer['phone']),
      type: type,
      scopeId: scopeId
    }
  };
}


var EV24_PRODUCT_STATUSES = ['DRAFT','ACTIVE','HOLD','CLOSED'];
function EV24_normalizeProductStatus_(value) {
  var v = EV8_s_(value || 'ACTIVE').toUpperCase();
  var map = {'준비':'DRAFT','DRAFT':'DRAFT','판매중':'ACTIVE','운영중':'ACTIVE','ACTIVE':'ACTIVE','보류':'HOLD','HOLD':'HOLD','종료':'CLOSED','CLOSED':'CLOSED'};
  return map[v] || map[EV8_s_(value)] || v;
}
function EV24_assertProductStatus_(status) {
  var st = EV24_normalizeProductStatus_(status || 'ACTIVE');
  if (EV24_PRODUCT_STATUSES.indexOf(st) < 0) throw new Error('허용되지 않는 상품/품목 상태값입니다: ' + status);
  return st;
}
function EV25_parseBasePrice_(value) {
  var raw = EV8_s_(value);
  if (!raw) throw new Error('상품 기본가는 필수입니다. 0 이상 숫자로 입력하세요.');
  raw = raw.replace(/,/g, '');
  if (!/^-?\d+(\.\d+)?$/.test(raw)) throw new Error('상품 기본가는 숫자만 입력할 수 있습니다.');
  var n = Number(raw);
  if (!isFinite(n)) throw new Error('상품 기본가 숫자 형식이 올바르지 않습니다.');
  if (n < 0) throw new Error('상품 기본가는 음수로 입력할 수 없습니다.');
  return Math.round(n);
}
function EV25_canProductTransition_(fromStatus, toStatus) {
  var from = EV24_assertProductStatus_(fromStatus || 'DRAFT');
  var to = EV24_assertProductStatus_(toStatus || 'ACTIVE');
  if (from === to) return true;
  var allowed = {
    DRAFT: ['ACTIVE'],
    ACTIVE: ['HOLD','CLOSED'],
    HOLD: ['ACTIVE','CLOSED'],
    CLOSED: []
  };
  return (allowed[from] || []).indexOf(to) >= 0;
}
function EV25_assertProductTransition_(fromStatus, toStatus) {
  var from = EV24_assertProductStatus_(fromStatus || 'DRAFT');
  var to = EV24_assertProductStatus_(toStatus || 'ACTIVE');
  if (from === 'CLOSED' && from !== to) throw new Error('CLOSED 상태의 상품/품목은 일반 수정 또는 상태변경이 불가합니다.');
  if (!EV25_canProductTransition_(from, to)) throw new Error('허용되지 않는 상품 상태 전이입니다: ' + from + ' → ' + to);
  return true;
}
function EV24_getLinkById_(linkId) {
  var key = EV8_s_(linkId);
  if (!key) return null;
  return EV23_getLinkRow_(key);
}
function EV24_assertLinkEditableForProduct_(link) {
  if (!link) throw new Error('상품을 연결할 행사업체 연결을 찾지 못했습니다.');
  var st = EV21_normalizeStatus_(link.status || link['상태값']);
  if (st === 'LOCKED') throw new Error('LOCKED 상태의 행사업체 연결에는 상품/품목을 추가하거나 수정할 수 없습니다.');
  if (st === 'CLOSED') throw new Error('CLOSED 상태의 행사업체 연결에는 상품/품목을 추가하거나 수정할 수 없습니다.');
  return st;
}
function EV24_readProducts_() { return EV8_rowsToObjects_(EV24_productSheet_()); }
function getEventVendorProductRows(eventVendorId) {
  var key = EV8_s_(eventVendorId);
  var rows = EV24_readProducts_();
  if (!key) return rows.slice(-200).reverse();
  return rows.filter(function(r){ return EV8_s_(r.eventVendorId || r['행사업체연결ID'] || r.linkId || r['연결ID']) === key; }).slice(-200).reverse();
}
function saveEventVendorProduct(payload) {
  EV21_ensureCoreHeaders_();
  payload = payload || {};
  var sh = EV24_productSheet_();
  var rows = EV24_readProducts_();
  var productId = EV8_s_(payload.productId || payload['상품ID'] || payload['품목ID']);
  var eventVendorId = EV8_s_(payload.eventVendorId || payload.linkId || payload['행사업체연결ID'] || payload['연결ID']);
  var productName = EV8_s_(payload.productName || payload['상품명'] || payload['품목명']);
  var category = EV8_s_(payload.category || payload['카테고리']);
  var basePrice = EV25_parseBasePrice_(payload.basePrice || payload['기본가'] || payload['판매가']);
  var productStatus = EV24_assertProductStatus_(payload.productStatus || payload['상품상태'] || payload.status || 'ACTIVE');
  var memo = EV8_s_(payload.memo || payload['메모']);
  var now = EV8_now_();
  var actor = EV21_getActiveUser_();
  if (!eventVendorId) throw new Error('행사업체 연결ID는 필수입니다. 연결 목록에서 대상을 먼저 선택하세요.');
  if (!productName) throw new Error('상품명/품목명은 필수입니다.');
  var link = EV24_getLinkById_(eventVendorId);
  EV24_assertLinkEditableForProduct_(link);
  var eventId = EV8_s_(link.eventId || link['행사ID']);
  var eventName = EV8_s_(link.eventName || link['행사명']);
  var vendorId = EV8_s_(link.vendorId || link['업체ID']);
  var vendorName = EV8_s_(link.vendorName || link['업체명']);
  if (!productId && ['HOLD','CLOSED'].indexOf(productStatus) >= 0) throw new Error('신규 상품/품목은 HOLD/CLOSED 상태로 바로 생성할 수 없습니다. DRAFT 또는 ACTIVE로 먼저 등록하세요.');
  var dup = rows.filter(function(r){
    var sameLink = EV8_s_(r.eventVendorId || r['행사업체연결ID'] || r.linkId || r['연결ID']) === eventVendorId;
    var sameProduct = EV8_s_(r.productName || r['상품명'] || r['품목명']).toLowerCase() === productName.toLowerCase();
    var sameCategory = EV8_s_(r.category || r['카테고리']).toLowerCase() === category.toLowerCase();
    var sameId = productId && EV8_s_(r.productId || r['상품ID'] || r['품목ID']) === productId;
    return sameLink && sameProduct && sameCategory && !sameId;
  })[0];
  if (dup) throw new Error('이미 연결된 상품/품목입니다. 같은 행사업체 연결 안에서 상품명+카테고리 중복은 허용하지 않습니다.');
  var data = {productId:productId,eventVendorId:eventVendorId,linkId:eventVendorId,eventId:eventId,eventName:eventName,vendorId:vendorId,vendorName:vendorName,productName:productName,category:category,basePrice:basePrice,productStatus:productStatus,memo:memo,updatedAt:now,updatedBy:actor};
  if (productId) {
    var row = EV8_findRowById_(sh, 'productId', productId) || EV8_findRowById_(sh, '상품ID', productId);
    if (!row) throw new Error('수정할 상품/품목을 찾지 못했습니다: ' + productId);
    var previousStatus = EV24_assertProductStatus_(row.productStatus || row['상품상태'] || 'DRAFT');
    if (previousStatus === 'CLOSED') throw new Error('CLOSED 상태의 상품/품목은 일반 수정이 불가합니다.');
    EV25_assertProductTransition_(previousStatus, productStatus);
    EV8_setRowValuesByHeaders_(sh, row.__rowNum, data);
    EV8_appendLog_('EVENT_VENDOR_PRODUCT_UPDATE', productId, eventName + '/' + vendorName + '/' + productName, '행사업체 상품/품목 수정', JSON.stringify(row), JSON.stringify(data), previousStatus === productStatus ? '상품 정보 수정' : ('상품 상태 변경 ' + previousStatus + ' → ' + productStatus));
    return { ok:true, mode:'update', productId:productId, eventVendorId:eventVendorId, previousStatus:previousStatus, productStatus:productStatus };
  }
  productId = EV8_makeId_('PRD-');
  data.productId = productId;
  data.createdAt = now;
  data.createdBy = actor;
  EV8_appendObjectByHeaders_(sh, data);
  EV8_appendLog_('EVENT_VENDOR_PRODUCT_CREATE', productId, eventName + '/' + vendorName + '/' + productName, '행사업체 상품/품목 생성', '', JSON.stringify(data), '상품 신규 생성');
  return { ok:true, mode:'create', productId:productId, eventVendorId:eventVendorId, productStatus:productStatus };
}
function deleteEventVendorProduct(productId) {
  var key = EV8_s_(productId);
  if (!key) throw new Error('종료 처리할 상품ID가 필요합니다.');
  var sh = EV24_productSheet_();
  var row = EV8_findRowById_(sh, 'productId', key) || EV8_findRowById_(sh, '상품ID', key);
  if (!row) throw new Error('종료 처리할 상품/품목을 찾지 못했습니다: ' + key);
  var link = EV24_getLinkById_(row.eventVendorId || row['행사업체연결ID'] || row.linkId || row['연결ID']);
  EV24_assertLinkEditableForProduct_(link);
  var previousStatus = EV24_assertProductStatus_(row.productStatus || row['상품상태'] || 'DRAFT');
  if (previousStatus === 'CLOSED') throw new Error('이미 CLOSED 종료 상태인 상품/품목입니다.');
  EV25_assertProductTransition_(previousStatus, 'CLOSED');
  var now = EV8_now_();
  var actor = EV21_getActiveUser_();
  EV8_setRowValuesByHeaders_(sh, row.__rowNum, { productStatus:'CLOSED', updatedAt:now, updatedBy:actor, memo:EV8_s_(row.memo || row['메모']) });
  EV8_appendLog_('EVENT_VENDOR_PRODUCT_CLOSE', key, row.productName || row['상품명'], '행사업체 상품/품목 CLOSED 처리', JSON.stringify(row), JSON.stringify({productStatus:'CLOSED'}), '삭제 대신 종료 처리');
  return { ok:true, productId:key, productStatus:'CLOSED', mode:'close' };
}
function searchEventVendorProducts(query, status) {
  query = EV8_s_(query).toLowerCase();
  status = EV8_s_(status || 'ALL').toUpperCase();
  var rows = EV24_readProducts_().slice(-300).reverse();
  rows = rows.filter(function(r){
    if (!status || status === 'ALL') return true;
    var st = EV24_normalizeProductStatus_(r.productStatus || r['상품상태'] || '');
    return st === status;
  });
  if (!query) return rows;
  return rows.filter(function(r){
    return ['productId','productName','category','eventName','vendorName','productStatus','basePrice'].some(function(k){ return EV8_s_(r[k]).toLowerCase().indexOf(query) >= 0; });
  });
}

function getEventVendorProductHistory(productId) {
  var key = EV8_s_(productId);
  if (!key) throw new Error('상품 로그를 조회할 상품ID가 필요합니다. 상품 목록에서 상품을 먼저 선택하세요.');
  return EV8_rowsToObjects_(EV8_logSheet_()).filter(function(r){
    var target = EV8_s_(r.targetKey || r['대상키']);
    var action = EV8_s_(r.actionType || r['구분']);
    return target === key && action.indexOf('EVENT_VENDOR_PRODUCT') >= 0;
  }).slice(-50).reverse();
}
function EV24_productSelfTest_() {
  var result = { ok:true, tests:[] };
  function record(name, ok, detail){ result.tests.push({name:name, ok:!!ok, detail:detail||''}); if(!ok) result.ok=false; }
  function mustThrow(name, fn){ try { fn(); record(name, false, 'throw expected but passed'); } catch(e) { record(name, true, e.message || String(e)); } }
  function mustPass(name, fn){ try { fn(); record(name, true, 'passed'); } catch(e) { record(name, false, e.message || String(e)); } }
  mustPass('product status ACTIVE allowed', function(){ EV24_assertProductStatus_('ACTIVE'); });
  mustThrow('invalid product status blocked', function(){ EV24_assertProductStatus_('FREE_TEXT'); });
  mustThrow('empty base price blocked', function(){ EV25_parseBasePrice_(''); });
  mustThrow('negative base price blocked', function(){ EV25_parseBasePrice_('-1'); });
  mustThrow('text base price blocked', function(){ EV25_parseBasePrice_('abc'); });
  mustPass('zero base price allowed', function(){ EV25_parseBasePrice_('0'); });
  mustPass('comma base price allowed', function(){ EV25_parseBasePrice_('5,200,000'); });
  mustPass('DRAFT to ACTIVE allowed', function(){ EV25_assertProductTransition_('DRAFT','ACTIVE'); });
  mustThrow('DRAFT to HOLD blocked', function(){ EV25_assertProductTransition_('DRAFT','HOLD'); });
  mustPass('ACTIVE to HOLD allowed', function(){ EV25_assertProductTransition_('ACTIVE','HOLD'); });
  mustPass('HOLD to ACTIVE allowed', function(){ EV25_assertProductTransition_('HOLD','ACTIVE'); });
  mustPass('ACTIVE to CLOSED allowed', function(){ EV25_assertProductTransition_('ACTIVE','CLOSED'); });
  mustThrow('CLOSED to ACTIVE blocked', function(){ EV25_assertProductTransition_('CLOSED','ACTIVE'); });
  mustThrow('locked link product edit blocked', function(){ EV24_assertLinkEditableForProduct_({status:'LOCKED'}); });
  mustThrow('closed link product edit blocked', function(){ EV24_assertLinkEditableForProduct_({status:'CLOSED'}); });
  mustPass('active link product edit allowed', function(){ EV24_assertLinkEditableForProduct_({status:'ACTIVE'}); });
  return result;
}

function EV22_readEventVendorHtml_() {
  try {
    return HtmlService.createHtmlOutputFromFile('EventVendor').getContent();
  } catch (e) {
    return '';
  }
}




















/* =====================================================================
 * B06J36-27 EVENT VENDOR SETTLEMENT POLICY CORE SAFE
 * 범위: 행사업체 연결별 정산정책 등록/조회/수정/기본정책 1개 보장/LOCKED·CLOSED 차단.
 * 실제 정산 계산·지급·SIGN 기프트 정산 인계는 실행하지 않는다.
 * ===================================================================== */
EV21_BUILD_NO = 'v64-B06J36-28';
EV21_BUILD_NAME = 'ERP_B06J36_32R1_EVENT_VENDOR_POLICY_SCHEMA_PREFLIGHT_CHECKER_FIX_SAFE';

function EV27_policySheet_() {
  return EV8_ensureSheet_('ERP_행사업체정산정책', [
    'policyId','eventVendorId','linkId','eventId','eventName','vendorId','vendorName',
    'policyName','settlementType','commissionRate','fixedFee','paymentCycle','isDefault','policyStatus','memo',
    'createdAt','createdBy','updatedAt','updatedBy'
  ]);
}
function EV27_readPolicies_(){ return EV8_rowsToObjects_(EV27_policySheet_()); }
function EV27_normalizeType_(v){
  var x = EV8_s_(v).toUpperCase();
  var map = {'수수료율':'COMMISSION_RATE','정률':'COMMISSION_RATE','COMMISSION':'COMMISSION_RATE','COMMISSION_RATE':'COMMISSION_RATE','고정수수료':'FIXED_FEE','정액':'FIXED_FEE','FIXED':'FIXED_FEE','FIXED_FEE':'FIXED_FEE','혼합':'MIXED','MIXED':'MIXED','없음':'NONE','NONE':'NONE'};
  return map[x] || map[EV8_s_(v)] || x;
}
function EV27_assertType_(v){
  var t = EV27_normalizeType_(v || 'COMMISSION_RATE');
  if (['COMMISSION_RATE','FIXED_FEE','MIXED','NONE'].indexOf(t) < 0) throw new Error('허용되지 않는 정산방식입니다: ' + v);
  return t;
}
function EV27_normalizeCycle_(v){
  var x = EV8_s_(v).toUpperCase();
  var map = {'마감시':'ON_CLOSING','마감':'ON_CLOSING','ON_CLOSING':'ON_CLOSING','주간':'WEEKLY','WEEKLY':'WEEKLY','월간':'MONTHLY','MONTHLY':'MONTHLY','수기':'MANUAL','MANUAL':'MANUAL'};
  return map[x] || map[EV8_s_(v)] || x;
}
function EV27_assertCycle_(v){
  var c = EV27_normalizeCycle_(v || 'ON_CLOSING');
  if (['ON_CLOSING','WEEKLY','MONTHLY','MANUAL'].indexOf(c) < 0) throw new Error('허용되지 않는 지급주기입니다: ' + v);
  return c;
}
function EV27_normalizePolicyStatus_(v){
  var x = EV8_s_(v).toUpperCase();
  var map = {'준비':'DRAFT','DRAFT':'DRAFT','활성':'ACTIVE','사용':'ACTIVE','ACTIVE':'ACTIVE','보류':'HOLD','HOLD':'HOLD','종료':'CLOSED','CLOSED':'CLOSED'};
  return map[x] || map[EV8_s_(v)] || x;
}
function EV27_assertPolicyStatus_(v){
  var s = EV27_normalizePolicyStatus_(v || 'ACTIVE');
  if (['DRAFT','ACTIVE','HOLD','CLOSED'].indexOf(s) < 0) throw new Error('허용되지 않는 정산정책 상태입니다: ' + v);
  return s;
}
function EV27_parsePercent_(v){
  var raw = EV8_s_(v);
  if (raw === '') return 0;
  var n = Number(raw.replace(/%/g,'').replace(/,/g,''));
  if (isNaN(n)) throw new Error('수수료율은 숫자만 입력하세요.');
  if (n < 0 || n > 100) throw new Error('수수료율은 0 이상 100 이하만 허용됩니다.');
  return n;
}
function EV27_parseMoney_(v){
  var raw = EV8_s_(v);
  if (raw === '') return 0;
  var n = Number(raw.replace(/,/g,''));
  if (isNaN(n)) throw new Error('고정수수료는 숫자만 입력하세요.');
  if (n < 0) throw new Error('고정수수료는 음수일 수 없습니다.');
  return Math.round(n);
}
function EV27_getLinkForPolicy_(eventVendorId){
  var key = EV8_s_(eventVendorId);
  if (!key) throw new Error('정산정책을 연결할 eventVendorId가 필요합니다.');
  var link = EV24_getLinkById_(key);
  if (!link) throw new Error('행사업체 연결을 찾지 못했습니다: ' + key);
  return link;
}
function EV27_assertLinkEditableForPolicy_(link){
  var st = EV21_assertStatus_((link && (link.status || link['상태값'])) || '');
  if (st === 'LOCKED' || st === 'CLOSED') throw new Error('LOCKED/CLOSED 행사업체 연결은 정산정책 추가·수정이 불가합니다. 재오픈은 승인 기반 후속 기능에서 처리합니다.');
  return true;
}
function EV27_setOtherDefaultPoliciesOff_(eventVendorId, exceptPolicyId){
  var sh = EV27_policySheet_();
  var rows = EV8_rowsToObjects_(sh);
  rows.forEach(function(r){
    var sameLink = EV8_s_(r.eventVendorId || r['eventVendorId'] || r.linkId || r['linkId']) === EV8_s_(eventVendorId);
    var samePolicy = EV8_s_(r.policyId || r['policyId']) === EV8_s_(exceptPolicyId);
    if (sameLink && !samePolicy && EV8_s_(r.isDefault || r['isDefault']).toUpperCase() === 'Y') {
      EV8_setRowValuesByHeaders_(sh, r.__rowNum, {isDefault:'N', updatedAt:EV8_now_(), updatedBy:EV21_getActiveUser_()});
    }
  });
}
function saveEventVendorSettlementPolicy(payload){
  payload = payload || {};
  var sh = EV27_policySheet_();
  var now = EV8_now_();
  var actor = EV21_getActiveUser_();
  var policyId = EV8_s_(payload.policyId || payload['policyId'] || payload['정책ID']);
  var eventVendorId = EV8_s_(payload.eventVendorId || payload.linkId || payload['eventVendorId'] || payload['연결ID']);
  var link = EV27_getLinkForPolicy_(eventVendorId);
  EV27_assertLinkEditableForPolicy_(link);
  var policyName = EV8_s_(payload.policyName || payload['정책명']);
  if (!policyName) throw new Error('정산정책명은 필수입니다.');
  var settlementType = EV27_assertType_(payload.settlementType || payload['정산방식']);
  var commissionRate = EV27_parsePercent_(payload.commissionRate || payload['수수료율']);
  var fixedFee = EV27_parseMoney_(payload.fixedFee || payload['고정수수료']);
  var paymentCycle = EV27_assertCycle_(payload.paymentCycle || payload['지급주기']);
  var isDefault = EV8_s_(payload.isDefault || payload['기본정책']).toUpperCase() === 'N' ? 'N' : 'Y';
  var policyStatus = EV27_assertPolicyStatus_(payload.policyStatus || payload['정책상태'] || 'ACTIVE');
  if (!policyId && ['HOLD','CLOSED'].indexOf(policyStatus) >= 0) throw new Error('신규 정산정책은 HOLD/CLOSED 상태로 바로 생성할 수 없습니다. DRAFT 또는 ACTIVE로 먼저 등록하세요.');
  if (settlementType === 'COMMISSION_RATE' && commissionRate <= 0) throw new Error('정률 정산은 수수료율이 0보다 커야 합니다.');
  if (settlementType === 'FIXED_FEE' && fixedFee <= 0) throw new Error('정액 정산은 고정수수료가 0보다 커야 합니다.');
  if (settlementType === 'MIXED' && commissionRate <= 0 && fixedFee <= 0) throw new Error('혼합 정산은 수수료율 또는 고정수수료 중 하나 이상이 필요합니다.');
  var rows = EV27_readPolicies_();
  var dup = rows.filter(function(r){
    var sameLink = EV8_s_(r.eventVendorId || r['eventVendorId'] || r.linkId || r['linkId']) === eventVendorId;
    var sameName = EV8_s_(r.policyName || r['policyName']).toLowerCase() === policyName.toLowerCase();
    var sameId = policyId && EV8_s_(r.policyId || r['policyId']) === policyId;
    return sameLink && sameName && !sameId;
  })[0];
  if (dup) throw new Error('이미 같은 행사업체 연결에 동일한 정책명이 있습니다. 정산정책명 중복은 허용하지 않습니다.');
  var eventId = EV8_s_(link.eventId || link['행사ID']);
  var eventName = EV8_s_(link.eventName || link['행사명']);
  var vendorId = EV8_s_(link.vendorId || link['업체ID']);
  var vendorName = EV8_s_(link.vendorName || link['업체명']);
  var data = {policyId:policyId,eventVendorId:eventVendorId,linkId:eventVendorId,eventId:eventId,eventName:eventName,vendorId:vendorId,vendorName:vendorName,policyName:policyName,settlementType:settlementType,commissionRate:commissionRate,fixedFee:fixedFee,paymentCycle:paymentCycle,isDefault:isDefault,policyStatus:policyStatus,memo:EV8_s_(payload.memo || payload['메모']),updatedAt:now,updatedBy:actor};
  if (policyId) {
    var row = EV8_findRowById_(sh, 'policyId', policyId);
    if (!row) throw new Error('수정할 정산정책을 찾지 못했습니다: ' + policyId);
    var prevStatus = EV27_assertPolicyStatus_(row.policyStatus || 'DRAFT');
    if (prevStatus === 'CLOSED') throw new Error('CLOSED 상태의 정산정책은 일반 수정이 불가합니다.');
    EV8_setRowValuesByHeaders_(sh, row.__rowNum, data);
    if (isDefault === 'Y') EV27_setOtherDefaultPoliciesOff_(eventVendorId, policyId);
    EV8_appendLog_('EVENT_VENDOR_SETTLEMENT_POLICY_UPDATE', policyId, eventName + '/' + vendorName + '/' + policyName, '행사업체 정산정책 수정');
    return {ok:true, mode:'update', policyId:policyId, eventVendorId:eventVendorId, isDefault:isDefault, policyStatus:policyStatus};
  }
  policyId = EV8_makeId_('POL-');
  data.policyId = policyId; data.createdAt = now; data.createdBy = actor;
  EV8_appendObjectByHeaders_(sh, data);
  if (isDefault === 'Y') EV27_setOtherDefaultPoliciesOff_(eventVendorId, policyId);
  EV8_appendLog_('EVENT_VENDOR_SETTLEMENT_POLICY_CREATE', policyId, eventName + '/' + vendorName + '/' + policyName, '행사업체 정산정책 생성');
  return {ok:true, mode:'create', policyId:policyId, eventVendorId:eventVendorId, isDefault:isDefault, policyStatus:policyStatus};
}
function searchEventVendorSettlementPolicies(query, status){
  query = EV8_s_(query).toLowerCase();
  status = EV8_s_(status || 'ALL').toUpperCase();
  var rows = EV27_readPolicies_().slice(-300).reverse();
  rows = rows.filter(function(r){
    if (!status || status === 'ALL') return true;
    return EV27_normalizePolicyStatus_(r.policyStatus || '') === status;
  });
  if (!query) return rows;
  return rows.filter(function(r){ return ['policyId','policyName','eventName','vendorName','settlementType','paymentCycle','policyStatus'].some(function(k){ return EV8_s_(r[k]).toLowerCase().indexOf(query) >= 0; }); });
}
function getEventVendorSettlementPolicyHistory(policyId){
  var key = EV8_s_(policyId);
  if (!key) throw new Error('정산정책 로그를 조회할 policyId가 필요합니다.');
  return EV8_rowsToObjects_(EV8_logSheet_()).filter(function(r){
    var target = EV8_s_(r.targetKey || r['대상키']);
    var action = EV8_s_(r.actionType || r['구분']);
    return target === key && action.indexOf('EVENT_VENDOR_SETTLEMENT_POLICY') >= 0;
  }).slice(-50).reverse();
}


/* =====================================================================
 * B06J36-28 EVENT VENDOR POLICY UI GUARD SAFE
 * 범위: 정산정책 운영 UI 안정화. CLOSED 정책은 수정 불가, 정책 종료는 실제 삭제가 아니라 CLOSED 처리.
 * 실제 정산 계산·지급·SIGN 기프트 정산 인계는 실행하지 않는다.
 * ===================================================================== */
EV21_BUILD_NO = 'v64-B06J36-28';
EV21_BUILD_NAME = 'ERP_B06J36_32R1_EVENT_VENDOR_POLICY_SCHEMA_PREFLIGHT_CHECKER_FIX_SAFE';

function closeEventVendorSettlementPolicy(policyId){
  policyId = EV8_s_(policyId);
  if (!policyId) throw new Error('종료 처리할 정산정책ID가 필요합니다.');
  var sh = EV27_policySheet_();
  var row = EV8_findRowById_(sh, 'policyId', policyId);
  if (!row) throw new Error('종료 처리할 정산정책을 찾지 못했습니다: ' + policyId);
  var status = EV27_assertPolicyStatus_(row.policyStatus || 'DRAFT');
  if (status === 'CLOSED') throw new Error('이미 종료된 정산정책입니다.');
  var link = EV27_getLinkForPolicy_(row.eventVendorId || row.linkId);
  EV27_assertLinkEditableForPolicy_(link);
  EV8_setRowValuesByHeaders_(sh, row.__rowNum, {
    policyStatus:'CLOSED',
    isDefault:'N',
    updatedAt:EV8_now_(),
    updatedBy:EV21_getActiveUser_()
  });
  EV8_appendLog_('EVENT_VENDOR_SETTLEMENT_POLICY_CLOSE', policyId, EV8_s_(row.eventName) + '/' + EV8_s_(row.vendorName) + '/' + EV8_s_(row.policyName), '행사업체 정산정책 종료 CLOSED 처리');
  return {ok:true, mode:'close', policyId:policyId, policyStatus:'CLOSED', isDefault:'N'};
}

function EV27_policySelfTest_(){
  var result = {ok:true, tests:[]};
  function record(name, ok, detail){ result.tests.push({name:name, ok:!!ok, detail:detail||''}); if(!ok) result.ok=false; }
  function mustThrow(name, fn){ try{ fn(); record(name,false,'throw expected but passed'); }catch(e){ record(name,true,e.message||String(e)); } }
  function mustPass(name, fn){ try{ fn(); record(name,true,'passed'); }catch(e){ record(name,false,e.message||String(e)); } }
  mustPass('settlement type COMMISSION_RATE allowed', function(){ EV27_assertType_('COMMISSION_RATE'); });
  mustThrow('invalid settlement type blocked', function(){ EV27_assertType_('FREE_TEXT'); });
  mustPass('payment cycle MONTHLY allowed', function(){ EV27_assertCycle_('MONTHLY'); });
  mustThrow('invalid payment cycle blocked', function(){ EV27_assertCycle_('DAILY_RANDOM'); });
  mustPass('commission rate 10 allowed', function(){ EV27_parsePercent_('10'); });
  mustThrow('commission rate over 100 blocked', function(){ EV27_parsePercent_('101'); });
  mustThrow('commission rate text blocked', function(){ EV27_parsePercent_('abc'); });
  mustPass('fixed fee comma money allowed', function(){ EV27_parseMoney_('50,000'); });
  mustThrow('fixed fee negative blocked', function(){ EV27_parseMoney_('-1'); });
  mustThrow('locked link policy edit blocked', function(){ EV27_assertLinkEditableForPolicy_({status:'LOCKED'}); });
  mustThrow('closed link policy edit blocked', function(){ EV27_assertLinkEditableForPolicy_({status:'CLOSED'}); });
  mustPass('active link policy edit allowed', function(){ EV27_assertLinkEditableForPolicy_({status:'ACTIVE'}); });
  mustPass('policy close function exists', function(){ if (typeof closeEventVendorSettlementPolicy !== 'function') throw new Error('missing closeEventVendorSettlementPolicy'); });
  return result;
}

function EV21_ensureCoreHeaders_(){
  EV8_eventSheet_(); EV8_vendorSheet_(); EV8_linkSheet_(); EV8_logSheet_(); EV24_productSheet_(); EV27_policySheet_();
  return { ok:true, eventSheet:'ERP_행사관리', vendorSheet:'ERP_업체관리', linkSheet:'ERP_행사업체연결', logSheet:'ERP_행사업체로그', productSheet:'ERP_행사업체상품', policySheet:'ERP_행사업체정산정책' };
}
function getEventVendorBootstrap(){
  var events = EV8_rowsToObjects_(EV8_eventSheet_());
  var vendors = EV8_rowsToObjects_(EV8_vendorSheet_());
  var links = EV8_rowsToObjects_(EV8_linkSheet_());
  var products = EV8_rowsToObjects_(EV24_productSheet_());
  var policies = EV8_rowsToObjects_(EV27_policySheet_());
  return { stats:{ totalEvents:events.length, activeEvents:events.filter(function(v){ var st=EV21_normalizeStatus_(v['상태값']); return st === 'ACTIVE' || EV8_s_(v['상태값']) === '운영중'; }).length, totalVendors:vendors.length, activeVendors:vendors.filter(function(v){ var st=EV21_normalizeStatus_(v['상태값']); return st === 'ACTIVE' || EV8_s_(v['상태값']) === '운영중'; }).length, totalLinks:links.length, totalProducts:products.length, totalPolicies:policies.length }, events:events, vendors:vendors, links:links, products:products, policies:policies };
}



/* =====================================================================
 * B06J36-29 EVENT VENDOR SETTLEMENT PREVIEW SAFE
 * 범위: ACTIVE 기본정책 + ACTIVE 상품/품목 기준 정산 미리보기.
 * 실제 정산 확정/지급/전표/SIGN 기프트 정산 인계는 실행하지 않는다.
 * ===================================================================== */
EV21_BUILD_NO = 'v64-B06J36-30';
EV21_BUILD_NAME = 'ERP_B06J36_32R1_EVENT_VENDOR_POLICY_SCHEMA_PREFLIGHT_CHECKER_FIX_SAFE';

function EV29_money_(v){
  var raw = String(v === null || v === undefined ? '' : v).replace(/,/g,'').trim();
  if (raw === '') return 0;
  if (isNaN(Number(raw))) throw new Error('정산 미리보기 금액이 숫자가 아닙니다: ' + v);
  var n = Number(raw);
  if (n < 0) throw new Error('정산 미리보기 금액은 음수일 수 없습니다: ' + v);
  return Math.round(n);
}
function EV29_round_(v){ return Math.round(Number(v || 0)); }
function EV29_getActiveDefaultPolicy_(eventVendorId){
  var key = EV8_s_(eventVendorId);
  var rows = EV27_readPolicies_().filter(function(r){
    var same = EV8_s_(r.eventVendorId || r.linkId || r['eventVendorId']) === key;
    var active = EV27_normalizePolicyStatus_(r.policyStatus || r['policyStatus'] || '') === 'ACTIVE';
    var def = EV8_s_(r.isDefault || r['isDefault']).toUpperCase() === 'Y';
    return same && active && def;
  });
  if (!rows.length) throw new Error('ACTIVE 기본 정산정책이 없습니다. 정산정책을 먼저 등록하고 기본정책 Y로 설정하세요.');
  return rows[rows.length - 1];
}
function EV29_getActiveProducts_(eventVendorId){
  var key = EV8_s_(eventVendorId);
  return EV24_readProducts_().filter(function(r){
    var same = EV8_s_(r.eventVendorId || r.linkId || r['eventVendorId']) === key;
    var active = EV24_normalizeProductStatus_(r.productStatus || r['productStatus'] || '') === 'ACTIVE';
    return same && active;
  });
}
function EV29_calcPreview_(products, policy){
  var settlementType = EV27_assertType_(policy.settlementType || 'NONE');
  var rate = EV27_parsePercent_(policy.commissionRate || 0);
  var fixedFee = EV27_parseMoney_(policy.fixedFee || 0);
  var gross = 0, rateFee = 0;
  var rows = products.map(function(p){
    var price = EV29_money_(p.basePrice || p['basePrice'] || p['기본가']);
    var productRateFee = (settlementType === 'COMMISSION_RATE' || settlementType === 'MIXED') ? EV29_round_(price * rate / 100) : 0;
    gross += price;
    rateFee += productRateFee;
    return {
      productId: EV8_s_(p.productId || p['productId']),
      productName: EV8_s_(p.productName || p['productName'] || p['상품명']),
      category: EV8_s_(p.category || p['category'] || p['카테고리']),
      basePrice: price,
      rateFee: productRateFee,
      productStatus: EV8_s_(p.productStatus || p['productStatus'])
    };
  });
  var fixedApplied = (settlementType === 'FIXED_FEE' || settlementType === 'MIXED') ? fixedFee : 0;
  var totalFee = EV29_round_(rateFee + fixedApplied);
  return {
    settlementType: settlementType,
    commissionRate: rate,
    fixedFee: fixedFee,
    productCount: products.length,
    grossAmount: gross,
    rateFee: rateFee,
    fixedFeeApplied: fixedApplied,
    totalFee: totalFee,
    vendorExpectedAmount: gross - totalFee,
    rows: rows
  };
}
function previewEventVendorSettlement(payload){
  payload = payload || {};
  var eventVendorId = EV8_s_(payload.eventVendorId || payload.linkId || payload['eventVendorId'] || payload['연결ID']);
  if (!eventVendorId) throw new Error('정산 미리보기를 실행할 행사업체 연결을 선택하세요.');
  var link = EV24_getLinkById_(eventVendorId);
  if (!link) throw new Error('행사업체 연결을 찾지 못했습니다: ' + eventVendorId);
  var linkStatus = EV21_assertStatus_(link.status || link['상태값'] || '');
  if (linkStatus === 'LOCKED' || linkStatus === 'CLOSED') throw new Error('LOCKED/CLOSED 행사업체 연결은 정산 미리보기 대상에서 제외됩니다.');
  var policy = EV29_getActiveDefaultPolicy_(eventVendorId);
  var products = EV29_getActiveProducts_(eventVendorId);
  if (!products.length) throw new Error('ACTIVE 상품/품목이 없습니다. 정산 미리보기는 ACTIVE 상품만 대상으로 합니다.');
  var calc = EV29_calcPreview_(products, policy);
  var previewId = EV8_makeId_('PRV-');
  var inputSnapshot = {
    eventVendorId: eventVendorId,
    linkStatus: linkStatus,
    policyId: EV8_s_(policy.policyId || policy['policyId']),
    policyName: EV8_s_(policy.policyName || policy['policyName']),
    productIds: products.map(function(p){ return EV8_s_(p.productId || p['productId']); }),
    baseAmount: calc.grossAmount,
    commissionRate: calc.commissionRate,
    fixedFee: calc.fixedFee
  };
  var out = {
    ok: true,
    previewId: previewId,
    mode: 'PREVIEW_ONLY',
    message: '정산 미리보기 완료. 정산 확정/지급/전표 생성은 실행하지 않았습니다.',
    eventVendorId: eventVendorId,
    linkStatus: linkStatus,
    eventId: EV8_s_(link.eventId || link['행사ID']),
    eventName: EV8_s_(link.eventName || link['행사명']),
    vendorId: EV8_s_(link.vendorId || link['업체ID']),
    vendorName: EV8_s_(link.vendorName || link['업체명']),
    policy: {
      policyId: EV8_s_(policy.policyId || policy['policyId']),
      policyName: EV8_s_(policy.policyName || policy['policyName']),
      settlementType: calc.settlementType,
      commissionRate: calc.commissionRate,
      fixedFee: calc.fixedFee,
      paymentCycle: EV8_s_(policy.paymentCycle || policy['paymentCycle']),
      isDefault: EV8_s_(policy.isDefault || policy['isDefault']),
      policyStatus: EV8_s_(policy.policyStatus || policy['policyStatus'])
    },
    totals: {
      productCount: calc.productCount,
      grossAmount: calc.grossAmount,
      rateFee: calc.rateFee,
      fixedFeeApplied: calc.fixedFeeApplied,
      totalFee: calc.totalFee,
      vendorExpectedAmount: calc.vendorExpectedAmount
    },
    rows: calc.rows,
    inputSnapshot: inputSnapshot,
    excluded: { closedProductsExcluded:true, closedPoliciesExcluded:true, giftSettlementExcluded:true, finalSettlementExecuted:false }
  };
  EV30_appendPreviewSnapshot_(out, inputSnapshot);
  EV8_appendLog_('EVENT_VENDOR_SETTLEMENT_PREVIEW', eventVendorId, out.eventName + '/' + out.vendorName, '행사업체 정산 미리보기 실행. previewId=' + previewId + ' / 정산 확정·지급·전표 생성 없음');
  return out;
}
function EV29_previewSelfTest_(){
  var result = {ok:true, tests:[]};
  function record(name, ok, detail){ result.tests.push({name:name, ok:!!ok, detail:detail||''}); if(!ok) result.ok=false; }
  function mustThrow(name, fn){ try{ fn(); record(name,false,'throw expected but passed'); }catch(e){ record(name,true,e.message||String(e)); } }
  function mustPass(name, fn){ try{ fn(); record(name,true,'passed'); }catch(e){ record(name,false,e.message||String(e)); } }
  mustPass('commission preview calculation', function(){
    var c = EV29_calcPreview_([{productId:'P1',productName:'A',category:'C',basePrice:100000}], {settlementType:'COMMISSION_RATE',commissionRate:10,fixedFee:0});
    if (c.grossAmount !== 100000 || c.rateFee !== 10000 || c.totalFee !== 10000 || c.vendorExpectedAmount !== 90000) throw new Error(JSON.stringify(c));
  });
  mustPass('fixed fee preview calculation', function(){
    var c = EV29_calcPreview_([{productId:'P1',productName:'A',category:'C',basePrice:100000}], {settlementType:'FIXED_FEE',commissionRate:0,fixedFee:5000});
    if (c.totalFee !== 5000 || c.vendorExpectedAmount !== 95000) throw new Error(JSON.stringify(c));
  });
  mustPass('mixed preview calculation', function(){
    var c = EV29_calcPreview_([{productId:'P1',productName:'A',category:'C',basePrice:100000}], {settlementType:'MIXED',commissionRate:10,fixedFee:5000});
    if (c.totalFee !== 15000 || c.vendorExpectedAmount !== 85000) throw new Error(JSON.stringify(c));
  });
  mustPass('none preview calculation', function(){
    var c = EV29_calcPreview_([{productId:'P1',productName:'A',category:'C',basePrice:100000}], {settlementType:'NONE',commissionRate:0,fixedFee:0});
    if (c.totalFee !== 0 || c.vendorExpectedAmount !== 100000) throw new Error(JSON.stringify(c));
  });
  mustThrow('negative product amount blocked', function(){ EV29_calcPreview_([{basePrice:-1}], {settlementType:'NONE',commissionRate:0,fixedFee:0}); });
  mustPass('previewId format check', function(){ var id = EV8_makeId_('PRV-'); if (id.indexOf('PRV-') !== 0) throw new Error(id); });
  return result;
}



/* B06J36-29 fullCheck override */


/**
 * B06J36-32R POLICY SCHEMA PREFLIGHT SAFE
 * 목적: B32 오류 중지 후 B30 안정본 기준에서 결제구조/정산정책 확장 전 비파괴 사전점검.
 * - 시트 데이터 쓰기/헤더 추가/계산 변경/화면 변경 없음
 * - 누락 헤더는 다음 빌드 보정 대상(warnOnly)으로만 보고
 */
var EV32R_BUILD_NO = 'v64-B06J36-32R1';
var EV32R_BUILD_NAME = 'ERP_B06J36_32R1_EVENT_VENDOR_POLICY_SCHEMA_PREFLIGHT_CHECKER_FIX_SAFE';

function EV32R_requiredPolicyHeaders_() {
  return [
    'paymentOwnerType','settlementPolicyType','boothFee','boothFeeBillingType','boothFeeStatus','boothFeePaidAmount','boothFeeBalance',
    'saleCommissionRate','saleCommissionFixedAmount','unitCommissionAmount','unitCommissionBasis',
    'companyReceivedAmount','vendorReceivedAmount','customerTotalPaidAmount','settlementDirection',
    'vendorPayableAmount','vendorReceivableAmount','offsetAmount','settlementNote'
  ];
}
function EV32R_requiredPolicyCodes_() {
  return {
    paymentOwnerType: ['COMPANY_ALL','MIXED','VENDOR_DIRECT'],
    settlementPolicyType: ['NONE','BOOTH_ONLY','RATE','FIXED_PER_SALE','PER_UNIT','MIXED'],
    boothFeeBillingType: ['PREPAID','DEDUCT_FROM_SETTLEMENT','INVOICE','WAIVED'],
    boothFeeStatus: ['UNPAID','PARTIAL','PAID','WAIVED'],
    settlementDirection: ['PAY_TO_VENDOR','COLLECT_FROM_VENDOR','OFFSET','NO_ACTION'],
    unitCommissionBasis: ['PRODUCT_UNIT','INDOOR_UNIT','OUTDOOR_UNIT','SET','CONTRACT_ITEM']
  };
}
function EV32R_existingHeaderMap_(sheetName) {
  var ss = EV8_getSpreadsheet_();
  var sh = ss.getSheetByName(sheetName);
  if (!sh || sh.getLastColumn() < 1) return { ok:false, sheetName:sheetName, headers:[], map:{}, message:'sheet missing or empty' };
  var headers = sh.getRange(1, 1, 1, sh.getLastColumn()).getDisplayValues()[0].map(function(v){ return EV8_s_(v); });
  var map = {};
  headers.forEach(function(h, i){ if (h && map[h] === undefined) map[h] = i + 1; });
  return { ok:true, sheetName:sheetName, headers:headers, map:map, message:'ok' };
}
function EV32R_missingHeaders_(sheetName, required) {
  var hm = EV32R_existingHeaderMap_(sheetName);
  var missing = [];
  var duplicate = [];
  var duplicatePositions = {};
  var seen = {};
  hm.headers.forEach(function(h, idx){
    if (!h) return;
    seen[h] = seen[h] || [];
    seen[h].push(idx + 1);
  });
  Object.keys(seen).forEach(function(h){
    if (seen[h].length > 1) { duplicate.push(h); duplicatePositions[h] = seen[h]; }
  });
  required.forEach(function(h){ if (!hm.map[h]) missing.push(h); });
  return { sheetName:sheetName, ok:hm.ok, missing:missing, duplicate:duplicate, duplicatePositions:duplicatePositions, headers:hm.headers };
}
function EV32R_legacyFixedFeeProbe_() {
  var policy = EV32R_existingHeaderMap_('ERP_행사업체정산정책');
  var link = EV32R_existingHeaderMap_('ERP_행사업체연결');
  return {
    policyHasFixedFee: !!(policy.map && policy.map.fixedFee),
    policyHasBoothFee: !!(policy.map && policy.map.boothFee),
    linkHasFixedFee: !!(link.map && link.map.fixedFee),
    linkHasBoothFee: !!(link.map && link.map.boothFee),
    rule: 'fixedFee는 삭제하지 않고 boothFee 이관 후보로만 처리'
  };
}
function EV32R_calcDryRun_(input) {
  input = input || {};
  var saleAmount = EV8_n_(input.saleAmount);
  var saleCount = EV8_n_(input.saleCount);
  var unitCount = EV8_n_(input.unitCount);
  var boothFee = EV8_n_(input.boothFee);
  var saleCommissionRate = EV8_n_(input.saleCommissionRate);
  var saleCommissionFixedAmount = EV8_n_(input.saleCommissionFixedAmount);
  var unitCommissionAmount = EV8_n_(input.unitCommissionAmount);
  var boothFeeStatus = EV8_s_(input.boothFeeStatus);
  var boothFeeBillingType = EV8_s_(input.boothFeeBillingType);
  var boothFeeChargeAmount = (boothFeeStatus === 'PAID' || boothFeeStatus === 'WAIVED' || boothFeeBillingType === 'PREPAID') ? 0 : boothFee;
  var rateCommission = Math.round(saleAmount * saleCommissionRate / 100);
  var fixedSaleCommission = saleCount * saleCommissionFixedAmount;
  var unitCommission = unitCount * unitCommissionAmount;
  var feelhausChargeAmount = boothFeeChargeAmount + rateCommission + fixedSaleCommission + unitCommission;
  var companyReceivedAmount = EV8_n_(input.companyReceivedAmount);
  var vendorReceivedAmount = EV8_n_(input.vendorReceivedAmount);
  var customerTotalPaidAmount = EV8_n_(input.customerTotalPaidAmount);
  var paymentOwnerType = EV8_s_(input.paymentOwnerType) || 'COMPANY_ALL';
  var vendorPayableAmount = 0;
  var vendorReceivableAmount = 0;
  var offsetAmount = 0;
  var settlementDirection = 'NO_ACTION';
  if (paymentOwnerType === 'COMPANY_ALL') {
    vendorPayableAmount = Math.max(0, companyReceivedAmount - feelhausChargeAmount);
    settlementDirection = vendorPayableAmount > 0 ? 'PAY_TO_VENDOR' : 'NO_ACTION';
  } else if (paymentOwnerType === 'VENDOR_DIRECT') {
    vendorReceivableAmount = feelhausChargeAmount;
    settlementDirection = vendorReceivableAmount > 0 ? 'COLLECT_FROM_VENDOR' : 'NO_ACTION';
  } else if (paymentOwnerType === 'MIXED') {
    var expectedCompanyKeep = feelhausChargeAmount;
    var diff = companyReceivedAmount - expectedCompanyKeep;
    if (diff > 0) { vendorPayableAmount = diff; settlementDirection = 'PAY_TO_VENDOR'; }
    else if (diff < 0) { vendorReceivableAmount = Math.abs(diff); settlementDirection = 'COLLECT_FROM_VENDOR'; }
    else { settlementDirection = 'NO_ACTION'; }
    offsetAmount = Math.min(vendorReceivedAmount, vendorReceivableAmount);
    if (offsetAmount > 0 && vendorReceivableAmount > 0) settlementDirection = 'OFFSET';
  }
  return {
    ok:true,
    paymentOwnerType: paymentOwnerType,
    saleAmount: saleAmount,
    saleCount: saleCount,
    unitCount: unitCount,
    boothFee: boothFee,
    boothFeeChargeAmount: boothFeeChargeAmount,
    rateCommission: rateCommission,
    fixedSaleCommission: fixedSaleCommission,
    unitCommission: unitCommission,
    feelhausChargeAmount: feelhausChargeAmount,
    companyReceivedAmount: companyReceivedAmount,
    vendorReceivedAmount: vendorReceivedAmount,
    customerTotalPaidAmount: customerTotalPaidAmount,
    settlementDirection: settlementDirection,
    vendorPayableAmount: vendorPayableAmount,
    vendorReceivableAmount: vendorReceivableAmount,
    offsetAmount: offsetAmount,
    previewOnly: true
  };
}
function EV32R_policySchemaPreflight_() {
  var required = EV32R_requiredPolicyHeaders_();
  var codes = EV32R_requiredPolicyCodes_();
  var linkCheck = EV32R_missingHeaders_('ERP_행사업체연결', required);
  var policyCheck = EV32R_missingHeaders_('ERP_행사업체정산정책', required);
  var legacy = EV32R_legacyFixedFeeProbe_();
  var dryCompany = EV32R_calcDryRun_({ paymentOwnerType:'COMPANY_ALL', saleAmount:5200000, saleCount:1, unitCount:1, boothFee:1000000, boothFeeStatus:'PAID', saleCommissionRate:13, saleCommissionFixedAmount:50000, unitCommissionAmount:10000, companyReceivedAmount:5200000, customerTotalPaidAmount:5200000 });
  var dryMixed = EV32R_calcDryRun_({ paymentOwnerType:'MIXED', saleAmount:5200000, saleCount:1, unitCount:1, boothFee:1000000, boothFeeStatus:'UNPAID', saleCommissionRate:13, saleCommissionFixedAmount:50000, unitCommissionAmount:10000, companyReceivedAmount:2000000, vendorReceivedAmount:3200000, customerTotalPaidAmount:5200000 });
  var dryVendor = EV32R_calcDryRun_({ paymentOwnerType:'VENDOR_DIRECT', saleAmount:5200000, saleCount:1, unitCount:1, boothFee:1000000, boothFeeStatus:'UNPAID', saleCommissionRate:13, saleCommissionFixedAmount:50000, unitCommissionAmount:10000, vendorReceivedAmount:5200000, customerTotalPaidAmount:5200000 });
  return { ok:true, requiredHeaders:required, codeSets:codes, linkCheck:linkCheck, policyCheck:policyCheck, legacyFixedFee:legacy, dryRuns:{ COMPANY_ALL:dryCompany, MIXED:dryMixed, VENDOR_DIRECT:dryVendor } };
}


/**
 * FEELHAUS ERP - Duplicate Header Repair Simulation v32H
 * ERP_B06J36_32H_DUPLICATE_HEADER_REPAIR_SIMULATE_SAFE
 * 목적: ERP_행사업체연결 중복 헤더 정리 전 비파괴 시뮬레이션.
 * - 실제 삭제/수정 없음
 * - 중복 열별 데이터 존재 여부, 충돌 여부, 자동정리 가능성만 판정
 */
var EV32H_BUILD_NO = 'v64-B06J36-32H';
var EV32H_BUILD_NAME = 'ERP_B06J36_32H_DUPLICATE_HEADER_REPAIR_SIMULATE_SAFE';

function EV32H_duplicateHeaderProbe_(sheetName) {
  var ss = EV8_getSpreadsheet_();
  var sh = ss.getSheetByName(sheetName);
  if (!sh) return { ok:false, sheetName:sheetName, error:'sheet missing', duplicates:[], duplicatePositions:{}, columns:{}, recommendation:'STOP' };
  var lastCol = Math.max(1, sh.getLastColumn());
  var lastRow = Math.max(1, sh.getLastRow());
  var headers = sh.getRange(1, 1, 1, lastCol).getDisplayValues()[0].map(function(v){ return EV8_s_(v); });
  var seen = {};
  headers.forEach(function(h, idx){
    if (!h) return;
    seen[h] = seen[h] || [];
    seen[h].push(idx + 1);
  });
  var duplicatePositions = {};
  Object.keys(seen).forEach(function(h){ if (seen[h].length > 1) duplicatePositions[h] = seen[h]; });
  var rowCount = Math.max(0, lastRow - 1);
  var data = rowCount ? sh.getRange(2, 1, rowCount, lastCol).getDisplayValues() : [];
  var columns = {};
  var fatalConflicts = [];
  var manualRequired = [];
  var autoCandidates = [];
  Object.keys(duplicatePositions).forEach(function(h){
    var positions = duplicatePositions[h];
    var perColumn = positions.map(function(col){
      var nonEmpty = 0;
      var sample = [];
      data.forEach(function(row){
        var v = EV8_s_(row[col - 1]);
        if (v !== '') {
          nonEmpty++;
          if (sample.length < 5) sample.push(v);
        }
      });
      return { col:col, nonEmpty:nonEmpty, sample:sample };
    });
    var rowConflicts = [];
    data.forEach(function(row, rIdx){
      var values = positions.map(function(col){ return EV8_s_(row[col - 1]); }).filter(function(v){ return v !== ''; });
      var unique = [];
      values.forEach(function(v){ if (unique.indexOf(v) < 0) unique.push(v); });
      if (unique.length > 1) {
        rowConflicts.push({ row:rIdx + 2, values:unique });
      }
    });
    var nonEmptyCols = perColumn.filter(function(c){ return c.nonEmpty > 0; });
    var action = 'MANUAL_REVIEW';
    var reason = '';
    if (rowConflicts.length) {
      action = 'STOP_CONFLICT';
      reason = '같은 행의 중복 열 값이 서로 다릅니다.';
      fatalConflicts.push(h);
    } else if (nonEmptyCols.length === 0) {
      action = 'AUTO_REMOVE_DUP_EMPTY_COLUMNS_POSSIBLE';
      reason = '중복 열 모두 데이터가 없습니다. 첫 번째 헤더만 남기고 후속 중복 열 삭제 후보입니다.';
      autoCandidates.push(h);
    } else if (nonEmptyCols.length === 1) {
      if (nonEmptyCols[0].col === positions[0]) {
        action = 'AUTO_REMOVE_TRAILING_EMPTY_DUP_COLUMNS_POSSIBLE';
        reason = '첫 번째 열에만 데이터가 있고 후속 중복 열은 비어 있습니다.';
        autoCandidates.push(h);
      } else {
        action = 'MANUAL_OR_MERGE_REQUIRED';
        reason = '첫 번째 열이 아닌 중복 열에 데이터가 있습니다. 병합 또는 헤더 위치 조정 판단이 필요합니다.';
        manualRequired.push(h);
      }
    } else {
      action = 'MERGE_REQUIRED_SAME_VALUES';
      reason = '여러 중복 열에 데이터가 있으나 행 단위 값 충돌은 없습니다. 병합 후 정리 가능 여부 검토 필요합니다.';
      manualRequired.push(h);
    }
    columns[h] = {
      positions:positions,
      perColumn:perColumn,
      rowConflicts:rowConflicts.slice(0, 20),
      conflictCount:rowConflicts.length,
      action:action,
      reason:reason
    };
  });
  var duplicates = Object.keys(duplicatePositions);
  var recommendation = 'NO_DUPLICATE';
  if (fatalConflicts.length) recommendation = 'STOP_MANUAL_REVIEW_REQUIRED';
  else if (manualRequired.length) recommendation = 'MANUAL_REVIEW_OR_MERGE_REQUIRED';
  else if (autoCandidates.length) recommendation = 'AUTO_REPAIR_POSSIBLE_AFTER_BACKUP';
  return {
    ok: duplicates.length === 0,
    sheetName:sheetName,
    lastRow:lastRow,
    lastCol:lastCol,
    duplicates:duplicates,
    duplicatePositions:duplicatePositions,
    columns:columns,
    autoCandidates:autoCandidates,
    manualRequired:manualRequired,
    fatalConflicts:fatalConflicts,
    recommendation:recommendation,
    backupRequired:duplicates.length > 0,
    writeExecuted:false,
    note:'비파괴 시뮬레이션만 수행했습니다. 시트 수정/삭제/병합은 하지 않았습니다.'
  };
}

function EV32H_policyHeaderReadinessProbe_() {
  var required = EV32R_requiredPolicyHeaders_();
  return {
    linkCheck: EV32R_missingHeaders_('ERP_행사업체연결', required),
    policyCheck: EV32R_missingHeaders_('ERP_행사업체정산정책', required),
    requiredHeaders: required
  };
}

function EV32H_duplicateHeaderRepairSimulation_() {
  return {
    ok:true,
    linkDuplicateProbe: EV32H_duplicateHeaderProbe_('ERP_행사업체연결'),
    policyDuplicateProbe: EV32H_duplicateHeaderProbe_('ERP_행사업체정산정책'),
    readiness: EV32H_policyHeaderReadinessProbe_(),
    scope:'duplicate header repair simulation only; no sheet write, no header delete, no settlement execution'
  };
}




/**
 * FEELHAUS ERP - Duplicate Header Repair Plan v64-B06J36-32H1
 * BUILD: ERP_B06J36_32H1_DUPLICATE_HEADER_REPAIR_PLAN_SAFE
 * 목적: ERP_행사업체연결 중복 헤더 정리 전 수동 판정용 계획표 출력.
 * 주의: 이 빌드는 시트 수정/삭제/병합을 절대 수행하지 않는다.
 */
var EV32H1_BUILD_NO = 'v64-B06J36-32H1';
var EV32H1_BUILD_NAME = 'ERP_B06J36_32H1_DUPLICATE_HEADER_REPAIR_PLAN_SAFE';

function EV32H1_isDateLike_(v) {
  var s = EV8_s_(v);
  if (!s) return false;
  if (/^\d{4}[-\/]\d{1,2}[-\/]\d{1,2}(\s+\d{1,2}:\d{2}(:\d{2})?)?$/.test(s)) return true;
  if (/^\d{4}\.\d{1,2}\.\d{1,2}/.test(s)) return true;
  return false;
}

function EV32H1_safeHeaderPlan_(sheetName) {
  var probe = EV32H_duplicateHeaderProbe_(sheetName);
  var plan = {
    sheetName: sheetName,
    ok: true,
    backupRequired: true,
    writeExecuted: false,
    recommendation: 'PLAN_ONLY_CONFIRM_REQUIRED',
    message: '중복 헤더 실제 정리 전 수동 확인용 계획입니다. 시트 수정은 하지 않았습니다.',
    keepColumns: {},
    mergeCandidates: [],
    conflictResolutions: [],
    removeCandidatesAfterBackup: [],
    manualConfirmRequired: [],
    stopReasons: [],
    sourceProbe: probe
  };
  if (!probe || !probe.duplicates || !probe.duplicates.length) {
    plan.backupRequired = false;
    plan.recommendation = 'NO_DUPLICATE';
    plan.message = '중복 헤더가 없습니다.';
    return plan;
  }

  var ss = EV8_getSpreadsheet_();
  var sh = ss.getSheetByName(sheetName);
  var lastRow = sh ? sh.getLastRow() : 0;
  var headers = (sh && sh.getLastColumn()) ? sh.getRange(1, 1, 1, sh.getLastColumn()).getValues()[0].map(EV8_s_) : [];
  var rows = (sh && lastRow > 1) ? sh.getRange(2, 1, lastRow - 1, sh.getLastColumn()).getValues() : [];

  Object.keys(probe.duplicatePositions || {}).forEach(function(h) {
    var positions = probe.duplicatePositions[h] || [];
    var info = probe.columns[h] || {};
    if (h === 'memo') {
      plan.keepColumns.memo = positions[0];
      plan.mergeCandidates.push({
        header: 'memo',
        keepCol: positions[0],
        mergeFromCols: positions.slice(1),
        rule: '동일 행 값이 같으면 첫 번째 memo 유지. 다른 값이 발견되면 줄바꿈 병합 후보로 수동 확인.',
        currentAction: info.action || ''
      });
      positions.slice(1).forEach(function(c){ plan.removeCandidatesAfterBackup.push({header:'memo', col:c, removeAfter:'값 병합 또는 동일값 확인 후'}); });
      if (info.action && info.action !== 'AUTO_REMOVE_TRAILING_EMPTY_DUP_COLUMNS_POSSIBLE') plan.manualConfirmRequired.push('memo 병합/삭제 확인');
    } else if (h === 'updatedAt') {
      plan.keepColumns.updatedAt = positions[0];
      plan.mergeCandidates.push({
        header: 'updatedAt',
        keepCol: positions[0],
        mergeFromCols: positions.slice(1),
        rule: '행 단위 값이 같으면 첫 번째 updatedAt 유지. 값 차이가 있으면 더 최신 날짜 사용 여부 수동 확인.',
        currentAction: info.action || ''
      });
      positions.slice(1).forEach(function(c){ plan.removeCandidatesAfterBackup.push({header:'updatedAt', col:c, removeAfter:'동일값 확인 후'}); });
      if (info.action && info.action !== 'AUTO_REMOVE_TRAILING_EMPTY_DUP_COLUMNS_POSSIBLE') plan.manualConfirmRequired.push('updatedAt 병합/삭제 확인');
    } else if (h === 'createdAt') {
      // Prefer the column with valid createdAt date values. In current sheet the later createdAt column contains proper dates.
      var keepCol = positions[positions.length - 1];
      var reviewCol = positions[0];
      plan.keepColumns.createdAt = keepCol;
      var conflicts = [];
      rows.forEach(function(row, i){
        var rowNo = i + 2;
        var reviewValue = EV8_s_(row[reviewCol - 1]);
        var keepValue = EV8_s_(row[keepCol - 1]);
        if (reviewValue && keepValue && reviewValue !== keepValue) {
          var memoValue = plan.keepColumns.memo ? EV8_s_(row[plan.keepColumns.memo - 1]) : '';
          var decision = 'MANUAL_REVIEW';
          if (!EV32H1_isDateLike_(reviewValue) && EV32H1_isDateLike_(keepValue)) {
            decision = (memoValue && memoValue === reviewValue) ? 'DUPLICATE_MEMO_VALUE_CAN_IGNORE_AFTER_CONFIRM' : 'MOVE_NON_DATE_VALUE_TO_MEMO_CANDIDATE';
          } else if (EV32H1_isDateLike_(reviewValue) && !EV32H1_isDateLike_(keepValue)) {
            decision = 'KEEP_REVIEW_COL_DATE_MANUAL_CHECK_REQUIRED';
          }
          conflicts.push({
            row: rowNo,
            reviewCol: reviewCol,
            reviewValue: reviewValue,
            keepCol: keepCol,
            keepValue: keepValue,
            memoCol: plan.keepColumns.memo || '',
            memoValue: memoValue,
            decision: decision
          });
        }
      });
      plan.conflictResolutions.push({
        header: 'createdAt',
        keepCol: keepCol,
        reviewCol: reviewCol,
        rule: 'createdAt는 날짜값이 있는 열을 유지한다. 날짜가 아닌 값은 memo 중복값 여부를 확인 후 이관/무시를 결정한다.',
        conflicts: conflicts
      });
      plan.removeCandidatesAfterBackup.push({header:'createdAt', col:reviewCol, removeAfter:'conflicts 수동 확인 및 필요한 memo 이관 후'});
      plan.manualConfirmRequired.push('createdAt 충돌 행 수동 확인');
      if (conflicts.some(function(x){ return x.decision === 'MANUAL_REVIEW' || x.decision === 'KEEP_REVIEW_COL_DATE_MANUAL_CHECK_REQUIRED'; })) {
        plan.stopReasons.push('createdAt 충돌 중 자동 판정 불가 항목 있음');
      }
    } else {
      plan.keepColumns[h] = positions[0];
      plan.manualConfirmRequired.push(h + ' 중복 헤더 수동 확인');
      positions.slice(1).forEach(function(c){ plan.removeCandidatesAfterBackup.push({header:h, col:c, removeAfter:'수동 확인 후'}); });
    }
  });

  if (plan.stopReasons.length) {
    plan.recommendation = 'STOP_MANUAL_REVIEW_REQUIRED';
    plan.ok = false;
  } else {
    plan.recommendation = 'MANUAL_PLAN_READY_CONFIRM_BEFORE_APPLY';
    plan.ok = true;
  }
  return plan;
}

function EV32H1_duplicateHeaderRepairPlan_() {
  return {
    ok: true,
    build: EV32H1_BUILD_NAME,
    label: EV32H1_BUILD_NO,
    linkRepairPlan: EV32H1_safeHeaderPlan_('ERP_행사업체연결'),
    policyRepairPlan: EV32H1_safeHeaderPlan_('ERP_행사업체정산정책'),
    policyHeaderReadiness: EV32H_policyHeaderReadinessProbe_(),
    writeExecuted: false,
    scope: 'repair plan only; no sheet write, no column delete, no settlement execution'
  };
}



/**
 * FEELHAUS ERP - Duplicate Header Repair Apply v64-B06J36-32H2
 * BUILD: ERP_B06J36_32H2_DUPLICATE_HEADER_REPAIR_APPLY_SAFE
 * 목적: ERP_행사업체연결 중복 헤더를 백업 후 안전 정리한다.
 * - 기본 fullCheck는 쓰기 없음
 * - 실제 적용은 erpB06J36_32H2_duplicateHeaderRepairApply_confirmed() 명시 실행 시에만 수행
 */
var EV32H2_BUILD_NO = 'v64-B06J36-32H2';
var EV32H2_BUILD_NAME = 'ERP_B06J36_32H2_DUPLICATE_HEADER_REPAIR_APPLY_SAFE';

function EV32H2_expectedPlan_() {
  return {
    sheetName: 'ERP_행사업체연결',
    keepColumns: { memo: 7, createdAt: 13, updatedAt: 9 },
    removeColumnsDesc: [
      { header:'updatedAt', col:14, reason:'9열 updatedAt 유지, 14열 중복 제거' },
      { header:'memo', col:10, reason:'7열 memo 유지, 10열 중복 제거' },
      { header:'createdAt', col:8, reason:'13열 createdAt 유지, 8열 중복 제거' }
    ],
    deleteOrder: [14, 10, 8],
    backupRequired: true,
    applyRequiresExplicitFunction: true
  };
}

function EV32H2_getHeaders_(sh) {
  var lastCol = Math.max(1, sh.getLastColumn());
  return sh.getRange(1, 1, 1, lastCol).getDisplayValues()[0].map(function(v){ return EV8_s_(v); });
}

function EV32H2_duplicatePositions_(headers) {
  var seen = {};
  headers.forEach(function(h, idx){
    if (!h) return;
    seen[h] = seen[h] || [];
    seen[h].push(idx + 1);
  });
  var dup = {};
  Object.keys(seen).forEach(function(h){ if (seen[h].length > 1) dup[h] = seen[h]; });
  return dup;
}

function EV32H2_isSameOrEmpty_(a, b) {
  var av = EV8_s_(a);
  var bv = EV8_s_(b);
  return av === '' || bv === '' || av === bv;
}

function EV32H2_validateApplyReadiness_() {
  var ss = EV8_getSpreadsheet_();
  var sh = ss.getSheetByName('ERP_행사업체연결');
  if (!sh) return { ok:false, error:'ERP_행사업체연결 시트를 찾을 수 없습니다.', canApply:false };

  var headers = EV32H2_getHeaders_(sh);
  var expected = {
    7:'memo', 8:'createdAt', 9:'updatedAt', 10:'memo', 13:'createdAt', 14:'updatedAt'
  };
  var positionErrors = [];
  Object.keys(expected).forEach(function(k){
    var col = Number(k);
    if (headers[col - 1] !== expected[k]) positionErrors.push(col + '열 expected=' + expected[k] + ', actual=' + headers[col - 1]);
  });
  if (positionErrors.length) {
    return { ok:false, canApply:false, error:'예상 중복 헤더 위치와 현재 시트가 다릅니다.', positionErrors:positionErrors, headers:headers };
  }

  var lastRow = Math.max(1, sh.getLastRow());
  var lastCol = Math.max(1, sh.getLastColumn());
  var rows = lastRow > 1 ? sh.getRange(2, 1, lastRow - 1, lastCol).getDisplayValues() : [];
  var memoConflicts = [];
  var createdAtConflicts = [];
  var updatedAtConflicts = [];

  rows.forEach(function(row, i){
    var rowNo = i + 2;
    var memoKeep = EV8_s_(row[6]);
    var memoDup = EV8_s_(row[9]);
    if (!EV32H2_isSameOrEmpty_(memoKeep, memoDup)) {
      memoConflicts.push({ row:rowNo, keepCol:7, keepValue:memoKeep, removeCol:10, removeValue:memoDup });
    }

    var createdRemove = EV8_s_(row[7]);
    var createdKeep = EV8_s_(row[12]);
    if (createdRemove && createdKeep && createdRemove !== createdKeep) {
      var createdRemoveIsDate = EV32H1_isDateLike_(createdRemove);
      var createdKeepIsDate = EV32H1_isDateLike_(createdKeep);
      var isMemoDuplicate = memoKeep && memoKeep === createdRemove;
      if (!(isMemoDuplicate && !createdRemoveIsDate && createdKeepIsDate)) {
        createdAtConflicts.push({ row:rowNo, keepCol:13, keepValue:createdKeep, removeCol:8, removeValue:createdRemove, memoCol:7, memoValue:memoKeep, removeIsDate:createdRemoveIsDate, keepIsDate:createdKeepIsDate });
      }
    }

    var updatedKeep = EV8_s_(row[8]);
    var updatedDup = EV8_s_(row[13]);
    if (!EV32H2_isSameOrEmpty_(updatedKeep, updatedDup)) {
      updatedAtConflicts.push({ row:rowNo, keepCol:9, keepValue:updatedKeep, removeCol:14, removeValue:updatedDup });
    }
  });

  var dup = EV32H2_duplicatePositions_(headers);
  var expectedDupOk = JSON.stringify(dup.memo || []) === JSON.stringify([7,10]) &&
    JSON.stringify(dup.createdAt || []) === JSON.stringify([8,13]) &&
    JSON.stringify(dup.updatedAt || []) === JSON.stringify([9,14]);
  var conflicts = { memo:memoConflicts, createdAt:createdAtConflicts, updatedAt:updatedAtConflicts };
  var conflictCount = memoConflicts.length + createdAtConflicts.length + updatedAtConflicts.length;
  return {
    ok: expectedDupOk && conflictCount === 0,
    canApply: expectedDupOk && conflictCount === 0,
    sheetName: 'ERP_행사업체연결',
    lastRow:lastRow,
    lastCol:lastCol,
    duplicatePositions: dup,
    expectedDuplicatePositionsOk: expectedDupOk,
    conflicts: conflicts,
    conflictCount: conflictCount,
    deletionOrder: [14,10,8],
    deletionPlan: EV32H2_expectedPlan_(),
    backupRequired:true,
    writeExecuted:false,
    note:'적용 전 검증입니다. 이 함수는 시트를 수정하지 않습니다.'
  };
}

function EV32H2_makeBackupSheet_(ss, sourceSheet) {
  var tz = Session.getScriptTimeZone ? Session.getScriptTimeZone() : 'Asia/Seoul';
  var stamp = Utilities.formatDate(new Date(), tz, 'yyyyMMdd_HHmmss');
  var base = 'BACKUP_행사업체연결_' + stamp;
  var name = base;
  var n = 1;
  while (ss.getSheetByName(name)) {
    name = base + '_' + n;
    n++;
  }
  var backup = sourceSheet.copyTo(ss);
  backup.setName(name);
  return { backupSheetName:name, backupSheetId:backup.getSheetId() };
}

function EV32H2_applyDuplicateHeaderRepair_(options) {
  options = options || {};
  var apply = options.apply === true;
  var validation = EV32H2_validateApplyReadiness_();
  if (!apply) {
    validation.previewOnly = true;
    validation.message = 'dryRun만 수행했습니다. 실제 적용은 erpB06J36_32H2_duplicateHeaderRepairApply_confirmed() 실행 시에만 가능합니다.';
    return validation;
  }
  if (!validation.canApply) {
    validation.previewOnly = false;
    validation.writeExecuted = false;
    validation.error = validation.error || '적용 전 검증 실패로 열 삭제를 중지했습니다.';
    return validation;
  }

  var ss = EV8_getSpreadsheet_();
  var sh = ss.getSheetByName('ERP_행사업체연결');
  var backup = EV32H2_makeBackupSheet_(ss, sh);
  [14, 10, 8].forEach(function(col){
    sh.deleteColumn(col);
  });
  var afterHeaders = EV32H2_getHeaders_(sh);
  var afterDup = EV32H2_duplicatePositions_(afterHeaders);
  var afterOk = Object.keys(afterDup).length === 0;
  return {
    ok: afterOk,
    applied: true,
    writeExecuted: true,
    backup: backup,
    deletedColumnsOriginalOrder: [14,10,8],
    afterDuplicatePositions: afterDup,
    afterHeaders: afterHeaders,
    message: afterOk ? 'ERP_행사업체연결 중복 헤더 정리 완료' : '열 삭제 후에도 중복 헤더가 남아 있습니다. 즉시 확인 필요',
    checkedAt: new Date().toISOString()
  };
}

function EV32H2_duplicateHeaderRepairApplyFullCheck_() {
  var checks = [];
  var fatal = 0;
  var warnings = [];
  function add(name, ok, detail, warnOnly) {
    if (!ok && warnOnly) warnings.push(name + ': ' + (detail || ''));
    if (!ok && !warnOnly) fatal++;
    checks.push({ name:name, ok:!!ok, detail:detail || '', warnOnly:!!warnOnly });
  }
  var validation = null;
  try {
    validation = EV32H2_validateApplyReadiness_();
    add('apply validation object created', !!validation, '중복 헤더 실제 정리 전 검증 객체', false);
  } catch (err) {
    validation = { ok:false, canApply:false, error:String(err && err.message ? err.message : err) };
    add('apply validation object created', false, validation.error, false);
  }
  try { add('event/vendor functions still exist', typeof getEventVendorBootstrap === 'function' && typeof saveEventVendorLink === 'function' && typeof searchEventVendorData === 'function', '기존 행사/업체/연결 함수 보존', false); } catch(e1) { add('event/vendor functions still exist', false, String(e1), false); }
  try { add('product/policy/preview functions still exist', typeof saveEventVendorProduct === 'function' && typeof saveEventVendorSettlementPolicy === 'function' && typeof previewEventVendorSettlement === 'function', '상품/정책/미리보기 함수 보존', false); } catch(e2) { add('product/policy/preview functions still exist', false, String(e2), false); }

  if (validation) {
    var afterAlreadyClean = validation.duplicatePositions && Object.keys(validation.duplicatePositions).length === 0;
    if (afterAlreadyClean) {
      add('ERP_행사업체연결 duplicate headers already absent', true, '이미 중복 헤더 없음', false);
    } else {
      add('ERP_행사업체연결 expected duplicate positions verified', validation.expectedDuplicatePositionsOk === true, JSON.stringify(validation.duplicatePositions || {}), false);
      add('ERP_행사업체연결 no unsafe row conflicts', validation.conflictCount === 0, JSON.stringify(validation.conflicts || {}), false);
      add('ERP_행사업체연결 apply possible after backup', validation.canApply === true, 'canApply=' + validation.canApply, false);
    }
    add('ERP_행사업체연결 write not executed by fullCheck', validation.writeExecuted === false, 'fullCheck는 쓰기 없음', false);
    add('ERP_행사업체연결 backup required before apply', validation.backupRequired === true, 'backupRequired=' + validation.backupRequired, false);
    add('explicit apply function exists', typeof erpB06J36_32H2_duplicateHeaderRepairApply_confirmed === 'function', '명시 실행 함수', false);
  }
  var result = {
    ok: fatal === 0,
    fatal: fatal,
    warnings: warnings,
    build: EV32H2_BUILD_NAME,
    label: EV32H2_BUILD_NO,
    checkedAt: new Date().toISOString(),
    result: { checks:checks, validation:validation, scope:'apply readiness only; fullCheck does not write/delete columns' },
    errorCode: fatal ? 'ERP_DUPLICATE_HEADER_REPAIR_APPLY_PREFLIGHT_FAILED' : '',
    meta: { buildNo:EV32H2_BUILD_NO, buildName:EV32H2_BUILD_NAME }
  };
  Logger.log('==============================');
  Logger.log('[ERP FULL CHECK] erpEventVendorCore_fullCheck_20260502_log');
  Logger.log(JSON.stringify(result, null, 2));
  Logger.log('==============================');
  return result;
}


/**
 * FEELHAUS ERP - Duplicate Header Repair Post Apply Verifier v64-B06J36-32H3
 * BUILD: ERP_B06J36_32H3_DUPLICATE_HEADER_REPAIR_POST_VERIFY_SAFE
 * 목적: B32H2 실제 적용 후 중복 헤더 정리 완료 상태를 검증한다.
 * - 시트 수정 없음
 * - H2의 사전 적용 검증과 달리, 이미 정리된 상태를 정상으로 판정한다.
 */
var EV32H3_BUILD_NO = 'v64-B06J36-32H3';
var EV32H3_BUILD_NAME = 'ERP_B06J36_32H3_DUPLICATE_HEADER_REPAIR_POST_VERIFY_SAFE';

function EV32H3_getHeaders_(sh) {
  var lastCol = Math.max(1, sh.getLastColumn());
  return sh.getRange(1, 1, 1, lastCol).getDisplayValues()[0].map(function(v){ return EV8_s_(v); });
}

function EV32H3_duplicatePositions_(headers) {
  var seen = {};
  headers.forEach(function(h, idx){
    if (!h) return;
    seen[h] = seen[h] || [];
    seen[h].push(idx + 1);
  });
  var dup = {};
  Object.keys(seen).forEach(function(h){ if (seen[h].length > 1) dup[h] = seen[h]; });
  return dup;
}

function EV32H3_postApplyProbe_() {
  var ss = EV8_getSpreadsheet_();
  var sh = ss.getSheetByName('ERP_행사업체연결');
  if (!sh) return { ok:false, error:'ERP_행사업체연결 시트를 찾을 수 없습니다.', writeExecuted:false };
  var headers = EV32H3_getHeaders_(sh);
  var dup = EV32H3_duplicatePositions_(headers);
  var required = ['linkId','eventId','vendorId','status','memo','createdAt','updatedAt','createdBy','updatedBy','eventVendorId'];
  var missing = required.filter(function(h){ return headers.indexOf(h) < 0; });
  var blankPositions = [];
  headers.forEach(function(h, idx){ if (!EV8_s_(h)) blankPositions.push(idx + 1); });
  return {
    ok: Object.keys(dup).length === 0 && missing.length === 0,
    sheetName:'ERP_행사업체연결',
    lastRow: sh.getLastRow(),
    lastCol: sh.getLastColumn(),
    duplicatePositions: dup,
    missingRequiredHeaders: missing,
    blankHeaderPositions: blankPositions,
    headers: headers,
    writeExecuted:false,
    note:'B32H2 적용 후 검증입니다. 이 함수는 시트를 수정하지 않습니다.'
  };
}

function EV32H3_postApplyFullCheck_() {
  var checks = [];
  var fatal = 0;
  var warnings = [];
  function add(name, ok, detail, warnOnly) {
    if (!ok && warnOnly) warnings.push(name + ': ' + (detail || ''));
    if (!ok && !warnOnly) fatal++;
    checks.push({ name:name, ok:!!ok, detail:detail || '', warnOnly:!!warnOnly });
  }
  var probe = null;
  try {
    probe = EV32H3_postApplyProbe_();
    add('post apply probe created', !!probe, '중복 헤더 정리 후 검증 객체', false);
  } catch (err) {
    probe = { ok:false, error:String(err && err.message ? err.message : err), writeExecuted:false };
    add('post apply probe created', false, probe.error, false);
  }
  try { add('event/vendor functions still exist', typeof getEventVendorBootstrap === 'function' && typeof saveEventVendorLink === 'function' && typeof searchEventVendorData === 'function', '기존 행사/업체/연결 함수 보존', false); } catch(e1) { add('event/vendor functions still exist', false, String(e1), false); }
  try { add('product/policy/preview functions still exist', typeof saveEventVendorProduct === 'function' && typeof saveEventVendorSettlementPolicy === 'function' && typeof previewEventVendorSettlement === 'function', '상품/정책/미리보기 함수 보존', false); } catch(e2) { add('product/policy/preview functions still exist', false, String(e2), false); }
  if (probe) {
    add('ERP_행사업체연결 duplicate headers absent', probe.duplicatePositions && Object.keys(probe.duplicatePositions).length === 0, JSON.stringify(probe.duplicatePositions || {}), false);
    add('ERP_행사업체연결 required headers preserved', (probe.missingRequiredHeaders || []).length === 0, 'missing=' + (probe.missingRequiredHeaders || []).join('|'), false);
    add('ERP_행사업체연결 blank headers only warning', (probe.blankHeaderPositions || []).length === 0, 'blank=' + (probe.blankHeaderPositions || []).join('|'), true);
    add('ERP_행사업체연결 write not executed by verifier', probe.writeExecuted === false, '검증 함수는 쓰기 없음', false);
  }
  var result = {
    ok: fatal === 0,
    fatal: fatal,
    warnings: warnings,
    build: EV32H3_BUILD_NAME,
    label: EV32H3_BUILD_NO,
    checkedAt: new Date().toISOString(),
    result: { checks:checks, postApplyProbe:probe, scope:'post apply verification only; no write/delete columns' },
    errorCode: fatal ? 'ERP_DUPLICATE_HEADER_REPAIR_POST_VERIFY_FAILED' : '',
    meta: { buildNo:EV32H3_BUILD_NO, buildName:EV32H3_BUILD_NAME }
  };
  Logger.log('==============================');
  Logger.log('[ERP FULL CHECK] erpEventVendorCore_fullCheck_20260502_log');
  Logger.log(JSON.stringify(result, null, 2));
  Logger.log('==============================');
  return result;
}


// B32H2 적용 후에는 대표 fullCheck가 사후 검증 기준으로 동작해야 한다.


/**
 * FEELHAUS ERP - Blank Header Reuse Plan v64-B06J36-32I
 * BUILD: ERP_B06J36_32I_BLANK_HEADER_REUSE_PLAN_SAFE
 * 목적: B33 신규 정책 헤더 추가 전, ERP_행사업체연결 빈 헤더 재사용 가능 여부를 비파괴로 계획한다.
 */
var EV32I_BUILD_NO = 'v64-B06J36-32I';
var EV32I_BUILD_NAME = 'ERP_B06J36_32I_BLANK_HEADER_REUSE_PLAN_SAFE';

function EV32I_getHeaders_(sh) {
  var lastCol = Math.max(1, sh.getLastColumn());
  return sh.getRange(1, 1, 1, lastCol).getValues()[0].map(function(v){ return EV8_s_(v); });
}

function EV32I_duplicatePositions_(headers) {
  var seen = {};
  headers.forEach(function(h, idx){
    if (!h) return;
    seen[h] = seen[h] || [];
    seen[h].push(idx + 1);
  });
  var dup = {};
  Object.keys(seen).forEach(function(h){ if (seen[h].length > 1) dup[h] = seen[h]; });
  return dup;
}

function EV32I_requiredPolicyHeaders_() {
  return [
    'paymentOwnerType',
    'boothFeeBillingType',
    'boothFeeStatus',
    'boothFeePaidAmount',
    'boothFeeBalance',
    'companyReceivedAmount',
    'vendorReceivedAmount',
    'customerTotalPaidAmount',
    'settlementDirection',
    'vendorPayableAmount',
    'vendorReceivableAmount',
    'offsetAmount'
  ];
}

function EV32I_blankColumnProbe_(sh, col) {
  var lastRow = sh.getLastRow();
  if (lastRow < 2) return { col: col, nonEmpty: 0, sample: [], reusable: true };
  var values = sh.getRange(2, col, lastRow - 1, 1).getValues().map(function(r){ return EV8_s_(r[0]); });
  var nonEmptyValues = values.filter(function(v){ return !!v; });
  return {
    col: col,
    nonEmpty: nonEmptyValues.length,
    sample: nonEmptyValues.slice(0, 5),
    reusable: nonEmptyValues.length === 0
  };
}

function EV32I_policySheetMissing_(ss, headers) {
  var sh = ss.getSheetByName('ERP_행사업체정산정책');
  if (!sh) return { sheetName:'ERP_행사업체정산정책', exists:false, missing:headers.slice(), duplicatePositions:{} };
  var hs = EV32I_getHeaders_(sh);
  return {
    sheetName:'ERP_행사업체정산정책',
    exists:true,
    missing: headers.filter(function(h){ return hs.indexOf(h) < 0; }),
    duplicatePositions: EV32I_duplicatePositions_(hs)
  };
}

function EV32I_blankHeaderReusePlan_() {
  var ss = EV8_getSpreadsheet_();
  var sh = ss.getSheetByName('ERP_행사업체연결');
  if (!sh) return { ok:false, error:'ERP_행사업체연결 시트를 찾을 수 없습니다.', writeExecuted:false };
  var headers = EV32I_getHeaders_(sh);
  var duplicates = EV32I_duplicatePositions_(headers);
  var blankPositions = [];
  headers.forEach(function(h, idx){ if (!h) blankPositions.push(idx + 1); });
  var blankProbes = blankPositions.map(function(c){ return EV32I_blankColumnProbe_(sh, c); });
  var unsafeBlanks = blankProbes.filter(function(p){ return !p.reusable; });
  var required = EV32I_requiredPolicyHeaders_();
  var missing = required.filter(function(h){ return headers.indexOf(h) < 0; });
  var reusableCols = blankProbes.filter(function(p){ return p.reusable; }).map(function(p){ return p.col; });
  var reuseAssignments = [];
  var appendHeaders = [];
  missing.forEach(function(h, idx){
    if (idx < reusableCols.length) {
      reuseAssignments.push({ header: h, targetCol: reusableCols[idx], mode: 'REUSE_BLANK_COLUMN' });
    } else {
      appendHeaders.push(h);
    }
  });
  var existingAlready = required.filter(function(h){ return headers.indexOf(h) >= 0; });
  var policySheetPlan = EV32I_policySheetMissing_(ss, required);
  return {
    ok: Object.keys(duplicates).length === 0 && unsafeBlanks.length === 0,
    sheetName: 'ERP_행사업체연결',
    lastRow: sh.getLastRow(),
    lastCol: sh.getLastColumn(),
    duplicatePositions: duplicates,
    blankHeaderPositions: blankPositions,
    blankColumnProbes: blankProbes,
    unsafeBlankColumns: unsafeBlanks,
    requiredPolicyHeaders: required,
    alreadyExists: existingAlready,
    missingPolicyHeaders: missing,
    reuseAssignments: reuseAssignments,
    appendHeaders: appendHeaders,
    policySheetPlan: policySheetPlan,
    backupRequiredBeforeB33: true,
    writeExecuted: false,
    recommendation: unsafeBlanks.length ? 'STOP_BLANK_COLUMNS_HAVE_DATA' : 'B33_CAN_REUSE_BLANKS_AND_APPEND_REST',
    note: '비파괴 계획표입니다. 시트 수정/헤더 추가는 하지 않았습니다.'
  };
}

function EV32I_blankHeaderReusePlanFullCheck_() {
  var checks = [];
  var fatal = 0;
  var warnings = [];
  function add(name, ok, detail, warnOnly) {
    if (!ok && warnOnly) warnings.push(name + ': ' + (detail || ''));
    if (!ok && !warnOnly) fatal++;
    checks.push({ name:name, ok:!!ok, detail:detail || '', warnOnly:!!warnOnly });
  }
  var plan = null;
  try {
    plan = EV32I_blankHeaderReusePlan_();
    add('blank header reuse plan object created', !!plan, '빈 헤더 재사용 계획표', false);
  } catch (err) {
    plan = { ok:false, error:String(err && err.message ? err.message : err), writeExecuted:false };
    add('blank header reuse plan object created', false, plan.error, false);
  }
  try { add('event/vendor functions still exist', typeof getEventVendorBootstrap === 'function' && typeof saveEventVendorLink === 'function' && typeof searchEventVendorData === 'function', '기존 행사/업체/연결 함수 보존', false); } catch(e1) { add('event/vendor functions still exist', false, String(e1), false); }
  try { add('product/policy/preview functions still exist', typeof saveEventVendorProduct === 'function' && typeof saveEventVendorSettlementPolicy === 'function' && typeof previewEventVendorSettlement === 'function', '상품/정책/미리보기 함수 보존', false); } catch(e2) { add('product/policy/preview functions still exist', false, String(e2), false); }
  if (plan) {
    add('ERP_행사업체연결 duplicate headers absent before B33', plan.duplicatePositions && Object.keys(plan.duplicatePositions).length === 0, JSON.stringify(plan.duplicatePositions || {}), false);
    add('ERP_행사업체연결 blank headers detected', (plan.blankHeaderPositions || []).length > 0, 'blank=' + (plan.blankHeaderPositions || []).join('|'), true);
    add('ERP_행사업체연결 blank columns have no data', (plan.unsafeBlankColumns || []).length === 0, JSON.stringify(plan.unsafeBlankColumns || []), false);
    add('ERP_행사업체연결 reuse assignments ready', (plan.reuseAssignments || []).length > 0 || (plan.missingPolicyHeaders || []).length === 0, JSON.stringify(plan.reuseAssignments || []), false);
    add('ERP_행사업체연결 append headers plan ready', Array.isArray(plan.appendHeaders), 'append=' + (plan.appendHeaders || []).join('|'), false);
    add('ERP_행사업체정산정책 missing policy headers plan ready', !!plan.policySheetPlan, plan.policySheetPlan ? 'missing=' + (plan.policySheetPlan.missing || []).join('|') : '', false);
    add('B33 backup required before header add', plan.backupRequiredBeforeB33 === true, 'backupRequiredBeforeB33=' + plan.backupRequiredBeforeB33, false);
    add('write not executed by B32I', plan.writeExecuted === false, '비파괴 계획표', false);
  }
  var result = {
    ok: fatal === 0,
    fatal: fatal,
    warnings: warnings,
    build: EV32I_BUILD_NAME,
    label: EV32I_BUILD_NO,
    checkedAt: new Date().toISOString(),
    result: { checks:checks, plan:plan, scope:'blank header reuse planning only; no write/add headers' },
    errorCode: fatal ? 'ERP_BLANK_HEADER_REUSE_PLAN_FAILED' : '',
    meta: { buildNo:EV32I_BUILD_NO, buildName:EV32I_BUILD_NAME }
  };
  Logger.log('==============================');
  Logger.log('[ERP FULL CHECK] erpEventVendorCore_fullCheck_20260502_log');
  Logger.log(JSON.stringify(result, null, 2));
  Logger.log('==============================');
  return result;
}


// B33 전에는 대표 fullCheck가 빈 헤더 재사용 계획 기준으로 동작한다.

/**
 * FEELHAUS ERP - Event/Vendor Settlement Policy Headers v64-B06J36-33
 * BUILD: ERP_B06J36_33_EVENT_VENDOR_POLICY_HEADERS_SAFE
 * 목적: B32I 계획에 따라 신규 정산정책 헤더를 비파괴로 추가한다.
 * 원칙: fixedFee 삭제 금지, 기존 기능 삭제 금지, fullCheck는 쓰기 없음, confirmed 함수만 백업 후 헤더를 반영한다.
 */
var EV33_BUILD_NO = 'v64-B06J36-33';
var EV33_BUILD_NAME = 'ERP_B06J36_33_EVENT_VENDOR_POLICY_HEADERS_SAFE';

function EV33_s_(v) { return EV8_s_(v); }
function EV33_ss_() { return EV8_getSpreadsheet_(); }

function EV33_getHeaders_(sh) {
  var lastCol = Math.max(1, sh.getLastColumn());
  return sh.getRange(1, 1, 1, lastCol).getValues()[0].map(function(v){ return EV33_s_(v); });
}

function EV33_duplicatePositions_(headers) {
  var seen = {};
  headers.forEach(function(h, idx){
    if (!h) return;
    seen[h] = seen[h] || [];
    seen[h].push(idx + 1);
  });
  var dup = {};
  Object.keys(seen).forEach(function(h){ if (seen[h].length > 1) dup[h] = seen[h]; });
  return dup;
}

function EV33_requiredPolicyHeaders_() {
  return [
    'paymentOwnerType',
    'boothFeeBillingType',
    'boothFeeStatus',
    'boothFeePaidAmount',
    'boothFeeBalance',
    'companyReceivedAmount',
    'vendorReceivedAmount',
    'customerTotalPaidAmount',
    'settlementDirection',
    'vendorPayableAmount',
    'vendorReceivableAmount',
    'offsetAmount'
  ];
}

function EV33_requiredLinkBaseHeaders_() {
  return ['linkId','eventId','vendorId','status','eventVendorId','settlementPolicyType','boothFee','saleCommissionRate','saleCommissionFixedAmount','unitCommissionAmount','unitCommissionBasis','settlementNote'];
}

function EV33_findBlankColumns_(sh, headers) {
  var blanks = [];
  headers.forEach(function(h, idx){ if (!h) blanks.push(idx + 1); });
  return blanks;
}

function EV33_blankColumnHasData_(sh, col) {
  var lastRow = sh.getLastRow();
  if (lastRow < 2) return false;
  var values = sh.getRange(2, col, lastRow - 1, 1).getValues();
  return values.some(function(r){ return !!EV33_s_(r[0]); });
}

function EV33_policyHeaderPlanForSheet_(sh, options) {
  options = options || {};
  var headers = EV33_getHeaders_(sh);
  var required = EV33_requiredPolicyHeaders_();
  var duplicatePositions = EV33_duplicatePositions_(headers);
  var missing = required.filter(function(h){ return headers.indexOf(h) < 0; });
  var alreadyExists = required.filter(function(h){ return headers.indexOf(h) >= 0; });
  var blankCols = EV33_findBlankColumns_(sh, headers);
  var safeBlankCols = blankCols.filter(function(c){ return !EV33_blankColumnHasData_(sh, c); });
  var unsafeBlankCols = blankCols.filter(function(c){ return EV33_blankColumnHasData_(sh, c); });
  var reuseBlanks = options.reuseBlanks !== false;
  var reuseAssignments = [];
  var appendHeaders = [];
  missing.forEach(function(h, idx){
    if (reuseBlanks && idx < safeBlankCols.length) {
      reuseAssignments.push({ header:h, targetCol:safeBlankCols[idx], mode:'REUSE_BLANK_COLUMN' });
    } else {
      appendHeaders.push(h);
    }
  });
  return {
    sheetName: sh.getName(),
    lastRow: sh.getLastRow(),
    lastCol: sh.getLastColumn(),
    headers: headers,
    duplicatePositions: duplicatePositions,
    missing: missing,
    alreadyExists: alreadyExists,
    blankHeaderPositions: blankCols,
    unsafeBlankColumns: unsafeBlankCols,
    reuseAssignments: reuseAssignments,
    appendHeaders: appendHeaders,
    canApply: Object.keys(duplicatePositions).length === 0 && unsafeBlankCols.length === 0,
    reuseBlanks: reuseBlanks
  };
}

function EV33_makeBackup_(ss, sheetName) {
  var sh = ss.getSheetByName(sheetName);
  if (!sh) throw new Error(sheetName + ' 시트를 찾을 수 없습니다.');
  var tz = Session.getScriptTimeZone() || 'Asia/Seoul';
  var stamp = Utilities.formatDate(new Date(), tz, 'yyyyMMdd_HHmmss');
  var base = 'BACKUP_' + sheetName.replace(/^ERP_/, '') + '_B33_' + stamp;
  var backupName = base;
  var i = 1;
  while (ss.getSheetByName(backupName)) backupName = base + '_' + (i++);
  var copied = sh.copyTo(ss).setName(backupName);
  return { backupSheetName: backupName, backupSheetId: copied.getSheetId() };
}

function EV33_getPlan_() {
  var ss = EV33_ss_();
  var linkSh = ss.getSheetByName('ERP_행사업체연결');
  var policySh = ss.getSheetByName('ERP_행사업체정산정책');
  if (!linkSh) return { ok:false, error:'ERP_행사업체연결 시트를 찾을 수 없습니다.', writeExecuted:false };
  if (!policySh) return { ok:false, error:'ERP_행사업체정산정책 시트를 찾을 수 없습니다.', writeExecuted:false };
  var linkPlan = EV33_policyHeaderPlanForSheet_(linkSh, { reuseBlanks:true });
  var policyPlan = EV33_policyHeaderPlanForSheet_(policySh, { reuseBlanks:false });
  var linkHeaders = linkPlan.headers;
  var missingBase = EV33_requiredLinkBaseHeaders_().filter(function(h){ return linkHeaders.indexOf(h) < 0; });
  var fixedFeePolicyPreserved = EV33_getHeaders_(policySh).indexOf('fixedFee') >= 0;
  return {
    ok: !!(linkPlan.canApply && policyPlan.canApply && missingBase.length === 0),
    build: EV33_BUILD_NAME,
    label: EV33_BUILD_NO,
    linkPlan: linkPlan,
    policyPlan: policyPlan,
    missingBaseLinkHeaders: missingBase,
    fixedFeePolicyPreserved: fixedFeePolicyPreserved,
    backupRequired: true,
    writeExecuted: false,
    note: 'B33 적용 전 계획입니다. 이 함수는 시트에 쓰지 않습니다.'
  };
}

function EV33_applyPlanToSheet_(sh, plan) {
  plan.reuseAssignments.forEach(function(a){
    sh.getRange(1, a.targetCol).setValue(a.header);
  });
  if (plan.appendHeaders.length) {
    var startCol = sh.getLastColumn() + 1;
    sh.getRange(1, startCol, 1, plan.appendHeaders.length).setValues([plan.appendHeaders]);
  }
}

function EV33_postProbe_() {
  var ss = EV33_ss_();
  var linkSh = ss.getSheetByName('ERP_행사업체연결');
  var policySh = ss.getSheetByName('ERP_행사업체정산정책');
  var required = EV33_requiredPolicyHeaders_();
  var linkHeaders = EV33_getHeaders_(linkSh);
  var policyHeaders = EV33_getHeaders_(policySh);
  return {
    ok: true,
    linkDuplicatePositions: EV33_duplicatePositions_(linkHeaders),
    policyDuplicatePositions: EV33_duplicatePositions_(policyHeaders),
    linkMissing: required.filter(function(h){ return linkHeaders.indexOf(h) < 0; }),
    policyMissing: required.filter(function(h){ return policyHeaders.indexOf(h) < 0; }),
    linkHeaders: linkHeaders,
    policyHeaders: policyHeaders,
    fixedFeePolicyPreserved: policyHeaders.indexOf('fixedFee') >= 0,
    writeExecuted: false
  };
}

function EV33_applyConfirmed_() {
  var ss = EV33_ss_();
  var plan = EV33_getPlan_();
  if (!plan.ok) {
    throw new Error('B33 적용 전 점검 실패: ' + JSON.stringify({
      linkMissingBase: plan.missingBaseLinkHeaders,
      linkDuplicate: plan.linkPlan && plan.linkPlan.duplicatePositions,
      policyDuplicate: plan.policyPlan && plan.policyPlan.duplicatePositions,
      linkUnsafeBlank: plan.linkPlan && plan.linkPlan.unsafeBlankColumns,
      policyUnsafeBlank: plan.policyPlan && plan.policyPlan.unsafeBlankColumns,
      error: plan.error
    }));
  }
  var linkSh = ss.getSheetByName('ERP_행사업체연결');
  var policySh = ss.getSheetByName('ERP_행사업체정산정책');
  var backups = {
    link: EV33_makeBackup_(ss, 'ERP_행사업체연결'),
    policy: EV33_makeBackup_(ss, 'ERP_행사업체정산정책')
  };
  EV33_applyPlanToSheet_(linkSh, plan.linkPlan);
  EV33_applyPlanToSheet_(policySh, plan.policyPlan);
  var post = EV33_postProbe_();
  var ok = Object.keys(post.linkDuplicatePositions).length === 0 && Object.keys(post.policyDuplicatePositions).length === 0 && post.linkMissing.length === 0 && post.policyMissing.length === 0;
  var result = {
    ok: ok,
    applied: ok,
    writeExecuted: true,
    build: EV33_BUILD_NAME,
    label: EV33_BUILD_NO,
    backups: backups,
    linkApplied: { reuseAssignments: plan.linkPlan.reuseAssignments, appendHeaders: plan.linkPlan.appendHeaders },
    policyApplied: { reuseAssignments: plan.policyPlan.reuseAssignments, appendHeaders: plan.policyPlan.appendHeaders },
    postProbe: post,
    message: ok ? 'B33 정산정책 신규 헤더 비파괴 추가 완료' : 'B33 적용 후 검증 실패',
    checkedAt: new Date().toISOString()
  };
  Logger.log('==============================');
  Logger.log('[ERP B33 HEADER APPLY] erpB06J36_33_eventVendorPolicyHeaders_confirmed');
  Logger.log(JSON.stringify(result, null, 2));
  Logger.log('==============================');
  return result;
}

function EV33_fullCheck_() {
  var checks = [];
  var fatal = 0;
  var warnings = [];
  function add(name, ok, detail, warnOnly) {
    if (!ok && warnOnly) warnings.push(name + ': ' + (detail || ''));
    if (!ok && !warnOnly) fatal++;
    checks.push({ name:name, ok:!!ok, detail:detail || '', warnOnly:!!warnOnly });
  }
  var plan = null;
  try {
    plan = EV33_getPlan_();
    add('B33 header plan object created', !!plan, '정산정책 신규 헤더 적용 계획', false);
  } catch (err) {
    plan = { ok:false, error:String(err && err.message ? err.message : err), writeExecuted:false };
    add('B33 header plan object created', false, plan.error, false);
  }
  try { add('event/vendor functions still exist', typeof getEventVendorBootstrap === 'function' && typeof saveEventVendorLink === 'function' && typeof searchEventVendorData === 'function', '기존 행사/업체/연결 함수 보존', false); } catch(e1) { add('event/vendor functions still exist', false, String(e1), false); }
  try { add('product/policy/preview functions still exist', typeof saveEventVendorProduct === 'function' && typeof saveEventVendorSettlementPolicy === 'function' && typeof previewEventVendorSettlement === 'function', '상품/정책/미리보기 함수 보존', false); } catch(e2) { add('product/policy/preview functions still exist', false, String(e2), false); }
  if (plan) {
    add('ERP_행사업체연결 duplicate headers absent before B33', plan.linkPlan && Object.keys(plan.linkPlan.duplicatePositions || {}).length === 0, JSON.stringify(plan.linkPlan ? plan.linkPlan.duplicatePositions : {}), false);
    add('ERP_행사업체정산정책 duplicate headers absent before B33', plan.policyPlan && Object.keys(plan.policyPlan.duplicatePositions || {}).length === 0, JSON.stringify(plan.policyPlan ? plan.policyPlan.duplicatePositions : {}), false);
    add('ERP_행사업체연결 base headers preserved', (plan.missingBaseLinkHeaders || []).length === 0, 'missing=' + (plan.missingBaseLinkHeaders || []).join('|'), false);
    add('ERP_행사업체연결 policy header plan ready', !!plan.linkPlan && (plan.linkPlan.reuseAssignments.length + plan.linkPlan.appendHeaders.length >= 0), JSON.stringify({reuse:plan.linkPlan ? plan.linkPlan.reuseAssignments : [], append:plan.linkPlan ? plan.linkPlan.appendHeaders : []}), false);
    add('ERP_행사업체정산정책 policy header plan ready', !!plan.policyPlan, JSON.stringify({append:plan.policyPlan ? plan.policyPlan.appendHeaders : []}), false);
    add('fixedFee preservation rule kept', plan.fixedFeePolicyPreserved === true, 'fixedFee 삭제 금지/보존', false);
    add('B33 backup required before header add', plan.backupRequired === true, 'backupRequired=' + plan.backupRequired, false);
    add('write not executed by B33 fullCheck', plan.writeExecuted === false, 'fullCheck는 쓰기 없음', false);
    add('explicit B33 apply function exists', typeof erpB06J36_33_eventVendorPolicyHeaders_confirmed === 'function', '명시 실행 함수', false);
  }
  var result = {
    ok: fatal === 0,
    fatal: fatal,
    warnings: warnings,
    build: EV33_BUILD_NAME,
    label: EV33_BUILD_NO,
    checkedAt: new Date().toISOString(),
    result: { checks:checks, plan:plan, scope:'B33 header add readiness only; fullCheck does not write/add headers' },
    errorCode: fatal ? 'ERP_EVENT_VENDOR_POLICY_HEADERS_PREFLIGHT_FAILED' : '',
    meta: { buildNo:EV33_BUILD_NO, buildName:EV33_BUILD_NAME }
  };
  Logger.log('==============================');
  Logger.log('[ERP FULL CHECK] erpEventVendorCore_fullCheck_20260502_log');
  Logger.log(JSON.stringify(result, null, 2));
  Logger.log('==============================');
  return result;
}



/* =====================================================================
 * B06J36-34 EVENT VENDOR POLICY UI SAVE SAFE
 * 목적: 고정수수료 표현을 제거하고 참여부스비/결제구조/수수료 항목을 분리 저장한다.
 * 범위: 화면/저장 분리. 정산 계산 재구성·확정·지급·전표·SIGN 기프트 인계는 하지 않는다.
 * ===================================================================== */
var EV34_BUILD_NO = 'v64-B06J36-34';
var EV34_BUILD_NAME = 'ERP_B06J36_34_EVENT_VENDOR_POLICY_UI_SAVE_SAFE';

function EV34_policyHeaders_(){
  return [
    'paymentOwnerType','settlementPolicyType','boothFee','boothFeeBillingType','boothFeeStatus','boothFeePaidAmount','boothFeeBalance',
    'saleCommissionRate','saleCommissionFixedAmount','unitCommissionAmount','unitCommissionBasis',
    'companyReceivedAmount','vendorReceivedAmount','customerTotalPaidAmount','settlementDirection',
    'vendorPayableAmount','vendorReceivableAmount','offsetAmount','settlementNote'
  ];
}
function EV34_s_(v){ return EV8_s_(v); }
function EV34_money_(v, label){
  var raw = EV34_s_(v).replace(/,/g,'').trim();
  if (raw === '') return 0;
  var n = Number(raw);
  if (isNaN(n)) throw new Error(label + '은(는) 숫자만 입력하세요.');
  if (n < 0) throw new Error(label + '은(는) 음수일 수 없습니다.');
  return Math.round(n);
}
function EV34_percent_(v, label){
  var raw = EV34_s_(v).replace(/,/g,'').replace(/%/g,'').trim();
  if (raw === '') return 0;
  var n = Number(raw);
  if (isNaN(n)) throw new Error(label + '은(는) 숫자만 입력하세요.');
  if (n < 0 || n > 100) throw new Error(label + '은(는) 0 이상 100 이하만 허용됩니다.');
  return n;
}
function EV34_assertIn_(value, allowed, label, fallback){
  var v = EV34_s_(value || fallback).toUpperCase();
  if (allowed.indexOf(v) < 0) throw new Error('허용되지 않는 ' + label + '입니다: ' + value);
  return v;
}
function EV34_normalizePolicyType_(v){
  var x = EV34_s_(v || '').toUpperCase();
  var map = {
    'COMMISSION_RATE':'RATE','RATE':'RATE','수수료율':'RATE','정률':'RATE',
    'FIXED_FEE':'BOOTH_ONLY','FIXED':'BOOTH_ONLY','고정수수료':'BOOTH_ONLY','정액':'BOOTH_ONLY','참여부스비':'BOOTH_ONLY','BOOTH_ONLY':'BOOTH_ONLY',
    'FIXED_PER_SALE':'FIXED_PER_SALE','전표당':'FIXED_PER_SALE','전표당수수료':'FIXED_PER_SALE',
    'PER_UNIT':'PER_UNIT','대당':'PER_UNIT','대당수수료':'PER_UNIT',
    'MIXED':'MIXED','혼합':'MIXED','NONE':'NONE','없음':'NONE'
  };
  return map[x] || map[EV34_s_(v)] || x || 'NONE';
}
function EV34_assertPolicyType_(v){
  var t = EV34_normalizePolicyType_(v || 'NONE');
  if (['NONE','BOOTH_ONLY','RATE','FIXED_PER_SALE','PER_UNIT','MIXED'].indexOf(t) < 0) throw new Error('허용되지 않는 정산방식입니다: ' + v);
  return t;
}
function EV34_assertPaymentOwnerType_(v){ return EV34_assertIn_(v, ['COMPANY_ALL','MIXED','VENDOR_DIRECT'], '결제구조', 'COMPANY_ALL'); }
function EV34_assertBoothFeeBillingType_(v){ return EV34_assertIn_(v, ['PREPAID','DEDUCT_FROM_SETTLEMENT','INVOICE','WAIVED'], '부스비 청구방식', 'DEDUCT_FROM_SETTLEMENT'); }
function EV34_assertBoothFeeStatus_(v){ return EV34_assertIn_(v, ['UNPAID','PARTIAL','PAID','WAIVED'], '부스비 상태', 'UNPAID'); }
function EV34_assertSettlementDirection_(v){ return EV34_assertIn_(v, ['PAY_TO_VENDOR','COLLECT_FROM_VENDOR','OFFSET','NO_ACTION'], '정산방향', 'NO_ACTION'); }
function EV34_assertUnitBasis_(v){ return EV34_assertIn_(v, ['PRODUCT_UNIT','INDOOR_UNIT','OUTDOOR_UNIT','SET','CONTRACT_ITEM'], '대당수수료 기준', 'PRODUCT_UNIT'); }
function EV34_balance_(boothFee, paid, billingType, status){
  if (billingType === 'WAIVED' || status === 'WAIVED') return 0;
  var bal = Number(boothFee || 0) - Number(paid || 0);
  return bal > 0 ? Math.round(bal) : 0;
}
function EV34_policyFieldData_(payload){
  payload = payload || {};
  var settlementPolicyType = EV34_assertPolicyType_(payload.settlementPolicyType || payload.settlementType || payload['정산방식']);
  var paymentOwnerType = EV34_assertPaymentOwnerType_(payload.paymentOwnerType || payload['결제구조']);
  var boothFee = EV34_money_(payload.boothFee !== undefined ? payload.boothFee : (payload.fixedFee !== undefined ? payload.fixedFee : payload['참여부스비']), '참여부스비');
  var boothFeeBillingType = EV34_assertBoothFeeBillingType_(payload.boothFeeBillingType || payload['부스비청구방식']);
  var boothFeeStatus = EV34_assertBoothFeeStatus_(payload.boothFeeStatus || payload['부스비상태']);
  var boothFeePaidAmount = EV34_money_(payload.boothFeePaidAmount || payload['부스비납부액'], '부스비 납부액');
  var boothFeeBalance = payload.boothFeeBalance !== undefined && EV34_s_(payload.boothFeeBalance) !== ''
    ? EV34_money_(payload.boothFeeBalance, '부스비 잔액')
    : EV34_balance_(boothFee, boothFeePaidAmount, boothFeeBillingType, boothFeeStatus);
  var saleCommissionRate = EV34_percent_(payload.saleCommissionRate !== undefined ? payload.saleCommissionRate : (payload.commissionRate !== undefined ? payload.commissionRate : payload['판매수수료율']), '판매수수료율');
  var saleCommissionFixedAmount = EV34_money_(payload.saleCommissionFixedAmount || payload['전표당수수료'], '전표당수수료');
  var unitCommissionAmount = EV34_money_(payload.unitCommissionAmount || payload['대당수수료'], '대당수수료');
  var unitCommissionBasis = EV34_assertUnitBasis_(payload.unitCommissionBasis || payload['대당수수료기준']);
  var companyReceivedAmount = EV34_money_(payload.companyReceivedAmount || payload['당사수취액'], '당사수취액');
  var vendorReceivedAmount = EV34_money_(payload.vendorReceivedAmount || payload['업체수취액'], '업체수취액');
  var customerTotalPaidAmount = EV34_money_(payload.customerTotalPaidAmount || payload['고객총결제액'], '고객총결제액');
  var settlementDirection = EV34_assertSettlementDirection_(payload.settlementDirection || payload['정산방향']);
  var vendorPayableAmount = EV34_money_(payload.vendorPayableAmount || payload['업체지급액'], '업체지급액');
  var vendorReceivableAmount = EV34_money_(payload.vendorReceivableAmount || payload['업체청구액'], '업체청구액');
  var offsetAmount = EV34_money_(payload.offsetAmount || payload['상계액'], '상계액');
  var settlementNote = EV34_s_(payload.settlementNote || payload['비고'] || payload.memo || payload['메모']);

  if (settlementPolicyType === 'BOOTH_ONLY' && boothFee <= 0) throw new Error('BOOTH_ONLY 정산방식은 참여부스비가 필요합니다.');
  if (settlementPolicyType === 'RATE' && saleCommissionRate <= 0) throw new Error('RATE 정산방식은 판매수수료율이 필요합니다.');
  if (settlementPolicyType === 'FIXED_PER_SALE' && saleCommissionFixedAmount <= 0) throw new Error('FIXED_PER_SALE 정산방식은 전표당수수료가 필요합니다.');
  if (settlementPolicyType === 'PER_UNIT' && unitCommissionAmount <= 0) throw new Error('PER_UNIT 정산방식은 대당수수료가 필요합니다.');
  if (settlementPolicyType === 'MIXED' && boothFee <= 0 && saleCommissionRate <= 0 && saleCommissionFixedAmount <= 0 && unitCommissionAmount <= 0) throw new Error('MIXED 정산방식은 참여부스비/판매수수료율/전표당수수료/대당수수료 중 하나 이상이 필요합니다.');
  if (boothFeeStatus === 'PAID' && boothFeePaidAmount < boothFee && boothFee > 0) throw new Error('부스비 상태 PAID는 납부액이 참여부스비 이상이어야 합니다.');
  if (boothFeeStatus === 'WAIVED' || boothFeeBillingType === 'WAIVED') { boothFeeBalance = 0; }

  return {
    paymentOwnerType: paymentOwnerType,
    settlementPolicyType: settlementPolicyType,
    boothFee: boothFee,
    boothFeeBillingType: boothFeeBillingType,
    boothFeeStatus: boothFeeStatus,
    boothFeePaidAmount: boothFeePaidAmount,
    boothFeeBalance: boothFeeBalance,
    saleCommissionRate: saleCommissionRate,
    saleCommissionFixedAmount: saleCommissionFixedAmount,
    unitCommissionAmount: unitCommissionAmount,
    unitCommissionBasis: unitCommissionBasis,
    companyReceivedAmount: companyReceivedAmount,
    vendorReceivedAmount: vendorReceivedAmount,
    customerTotalPaidAmount: customerTotalPaidAmount,
    settlementDirection: settlementDirection,
    vendorPayableAmount: vendorPayableAmount,
    vendorReceivableAmount: vendorReceivableAmount,
    offsetAmount: offsetAmount,
    settlementNote: settlementNote,
    // legacy compatibility; 삭제 금지
    settlementType: settlementPolicyType,
    commissionRate: saleCommissionRate,
    fixedFee: boothFee
  };
}

function EV34_settleSearchKeys_(){ return ['policyId','policyName','eventName','vendorName','settlementPolicyType','paymentOwnerType','boothFeeBillingType','boothFeeStatus','settlementDirection','policyStatus']; }

// B34 override: 정산정책 저장을 참여부스비/결제구조/수수료 분리 필드 기준으로 저장한다.
function saveEventVendorSettlementPolicy(payload){
  payload = payload || {};
  var sh = EV27_policySheet_();
  var now = EV8_now_();
  var actor = EV21_getActiveUser_();
  var policyId = EV8_s_(payload.policyId || payload['policyId'] || payload['정책ID']);
  var eventVendorId = EV8_s_(payload.eventVendorId || payload.linkId || payload['eventVendorId'] || payload['연결ID']);
  var link = EV27_getLinkForPolicy_(eventVendorId);
  EV27_assertLinkEditableForPolicy_(link);
  var policyName = EV8_s_(payload.policyName || payload['정책명']);
  if (!policyName) throw new Error('정산정책명은 필수입니다.');
  var policyFields = EV34_policyFieldData_(payload);
  var paymentCycle = EV27_assertCycle_(payload.paymentCycle || payload['지급주기']);
  var isDefault = EV8_s_(payload.isDefault || payload['기본정책']).toUpperCase() === 'N' ? 'N' : 'Y';
  var policyStatus = EV27_assertPolicyStatus_(payload.policyStatus || payload['정책상태'] || 'ACTIVE');
  if (!policyId && ['HOLD','CLOSED'].indexOf(policyStatus) >= 0) throw new Error('신규 정산정책은 HOLD/CLOSED 상태로 바로 생성할 수 없습니다. DRAFT 또는 ACTIVE로 먼저 등록하세요.');
  var rows = EV27_readPolicies_();
  var dup = rows.filter(function(r){
    var sameLink = EV8_s_(r.eventVendorId || r['eventVendorId'] || r.linkId || r['linkId']) === eventVendorId;
    var sameName = EV8_s_(r.policyName || r['policyName']).toLowerCase() === policyName.toLowerCase();
    var sameId = policyId && EV8_s_(r.policyId || r['policyId']) === policyId;
    return sameLink && sameName && !sameId;
  })[0];
  if (dup) throw new Error('이미 같은 행사업체 연결에 동일한 정책명이 있습니다. 정산정책명 중복은 허용하지 않습니다.');
  var eventId = EV8_s_(link.eventId || link['행사ID']);
  var eventName = EV8_s_(link.eventName || link['행사명']);
  var vendorId = EV8_s_(link.vendorId || link['업체ID']);
  var vendorName = EV8_s_(link.vendorName || link['업체명']);
  var data = {
    policyId:policyId,eventVendorId:eventVendorId,linkId:eventVendorId,eventId:eventId,eventName:eventName,vendorId:vendorId,vendorName:vendorName,
    policyName:policyName,paymentCycle:paymentCycle,isDefault:isDefault,policyStatus:policyStatus,memo:EV8_s_(payload.memo || payload['메모']),
    updatedAt:now,updatedBy:actor
  };
  Object.keys(policyFields).forEach(function(k){ data[k] = policyFields[k]; });
  if (policyId) {
    var row = EV8_findRowById_(sh, 'policyId', policyId);
    if (!row) throw new Error('수정할 정산정책을 찾지 못했습니다: ' + policyId);
    var prevStatus = EV27_assertPolicyStatus_(row.policyStatus || 'DRAFT');
    if (prevStatus === 'CLOSED') throw new Error('CLOSED 상태의 정산정책은 일반 수정이 불가합니다.');
    EV8_setRowValuesByHeaders_(sh, row.__rowNum, data);
    if (isDefault === 'Y') EV27_setOtherDefaultPoliciesOff_(eventVendorId, policyId);
    EV8_appendLog_('EVENT_VENDOR_SETTLEMENT_POLICY_UPDATE', policyId, eventName + '/' + vendorName + '/' + policyName, '행사업체 정산정책 수정: 참여부스비/결제구조/수수료 분리 저장');
    return {ok:true, mode:'update', policyId:policyId, eventVendorId:eventVendorId, isDefault:isDefault, policyStatus:policyStatus, settlementPolicyType:policyFields.settlementPolicyType, paymentOwnerType:policyFields.paymentOwnerType};
  }
  policyId = EV8_makeId_('POL-');
  data.policyId = policyId; data.createdAt = now; data.createdBy = actor;
  EV8_appendObjectByHeaders_(sh, data);
  if (isDefault === 'Y') EV27_setOtherDefaultPoliciesOff_(eventVendorId, policyId);
  EV8_appendLog_('EVENT_VENDOR_SETTLEMENT_POLICY_CREATE', policyId, eventName + '/' + vendorName + '/' + policyName, '행사업체 정산정책 생성: 참여부스비/결제구조/수수료 분리 저장');
  return {ok:true, mode:'create', policyId:policyId, eventVendorId:eventVendorId, isDefault:isDefault, policyStatus:policyStatus, settlementPolicyType:policyFields.settlementPolicyType, paymentOwnerType:policyFields.paymentOwnerType};
}

// B34 override: 행사업체 연결 저장에도 정책 필드를 수용하되 기존 흐름은 유지한다.
function saveEventVendorLink(payload) {
  EV21_ensureCoreHeaders_();
  payload = payload || {};
  var sh = EV8_linkSheet_();
  var rows = EV8_rowsToObjects_(sh);
  var id = EV8_s_(payload['연결ID'] || payload.linkId || payload.eventVendorId);
  var eventId = EV8_s_(payload['행사ID'] || payload.eventId);
  var vendorId = EV8_s_(payload['업체ID'] || payload.vendorId);
  var now = EV8_now_();
  var actor = EV21_getActiveUser_();
  if (!eventId) throw new Error('행사ID는 필수입니다.');
  if (!vendorId) throw new Error('업체ID는 필수입니다.');
  var events = EV8_rowsToObjects_(EV8_eventSheet_());
  var vendors = EV8_rowsToObjects_(EV8_vendorSheet_());
  var event = EV21_findByCanonicalId_(events, 'eventId', eventId);
  var vendor = EV21_findByCanonicalId_(vendors, 'vendorId', vendorId);
  if (!event) throw new Error('존재하지 않는 행사ID입니다: ' + eventId);
  if (!vendor) throw new Error('존재하지 않는 업체ID입니다: ' + vendorId);
  var statusReason = EV8_s_(payload.statusReason || payload['상태변경사유']);
  var transitionReason = EV8_s_(payload.statusChangeReason || payload.transitionReason || payload.reasonNew || payload['상태변경사유_신규']);
  var status = EV21_assertStatus_(payload['상태값'] || payload.status || 'READY');
  var eventName = EV8_s_(payload['행사명'] || payload.eventName || event.eventName || event['행사명']);
  var vendorName = EV8_s_(payload['업체명'] || payload.vendorName || vendor.vendorName || vendor['업체명']);
  var dup = rows.filter(function(r){
    var samePair = EV8_s_(r.eventId || r['행사ID']) === eventId && EV8_s_(r.vendorId || r['업체ID']) === vendorId;
    var sameId = id && (EV8_s_(r.linkId || r['연결ID']) === id || EV8_s_(r.eventVendorId || r['행사업체연결ID']) === id);
    return samePair && !sameId;
  })[0];
  if (dup) throw new Error('이미 연결된 행사-업체입니다. eventId + vendorId 중복은 허용하지 않습니다.');
  var rowData = {
    linkId:id,eventVendorId:id,eventId:eventId,eventName:eventName,vendorId:vendorId,vendorName:vendorName,
    vendorRole:EV8_s_(payload.vendorRole || payload['업체역할']),boothNo:EV8_s_(payload.boothNo || payload['부스번호']),category:EV8_s_(payload.category || payload['카테고리']),
    status:status,statusReason:statusReason,memo:EV8_s_(payload['메모'] || payload.memo),updatedAt:now,updatedBy:actor
  };
  // payload에 정책 필드가 들어온 경우에만 분리 저장한다. 기존 연결 저장 화면 영향 최소화.
  var hasPolicyPayload = EV34_policyHeaders_().some(function(k){ return payload[k] !== undefined && EV34_s_(payload[k]) !== ''; });
  if (hasPolicyPayload) {
    var policyFields = EV34_policyFieldData_(payload);
    Object.keys(policyFields).forEach(function(k){ rowData[k] = policyFields[k]; });
  }
  if (id) {
    var row = EV8_findRowById_(sh, 'linkId', id) || EV8_findRowById_(sh, 'eventVendorId', id);
    if (!row) throw new Error('수정할 연결을 찾지 못했습니다: ' + id);
    var currentStatus = EV21_normalizeStatus_(row.status || row['상태값'] || 'DRAFT');
    var requestedStatus = EV21_assertStatus_(status);
    if (currentStatus === 'LOCKED') throw new Error('LOCKED 상태의 행사업체 연결은 일반 수정할 수 없습니다.');
    if (currentStatus !== requestedStatus) {
      EV23_assertTransition_(currentStatus, requestedStatus, transitionReason);
      rowData.statusReason = transitionReason;
    }
    rowData.status = requestedStatus;
    EV8_setRowValuesByHeaders_(sh, row.__rowNum, rowData);
    EV8_appendLog_('EVENT_VENDOR_LINK_UPDATE', id, eventName + '/' + vendorName, '행사-업체 연결 수정');
    if (currentStatus !== requestedStatus) EV23_appendStatusLog_(id, eventName + '/' + vendorName, currentStatus, requestedStatus, transitionReason, actor);
    return { ok:true, mode:'update', linkId:id, eventVendorId:id, status:requestedStatus };
  }
  status = EV23_assertCreateStatus_(status, statusReason);
  rowData.status = status;
  id = EV8_makeId_('EVL-');
  rowData.linkId = id; rowData.eventVendorId = id; rowData.createdAt = now; rowData.createdBy = actor;
  EV8_appendObjectByHeaders_(sh, rowData);
  EV8_appendLog_('EVENT_VENDOR_LINK_CREATE', id, eventName + '/' + vendorName, '행사-업체 연결 생성');
  return { ok:true, mode:'create', linkId:id, eventVendorId:id, status:status };
}

function searchEventVendorSettlementPolicies(query, status){
  query = EV8_s_(query).toLowerCase();
  status = EV8_s_(status || 'ALL').toUpperCase();
  var rows = EV27_readPolicies_().slice(-300).reverse();
  rows = rows.filter(function(r){ if (!status || status === 'ALL') return true; return EV27_normalizePolicyStatus_(r.policyStatus || '') === status; });
  if (!query) return rows;
  var keys = EV34_settleSearchKeys_();
  return rows.filter(function(r){ return keys.some(function(k){ return EV8_s_(r[k]).toLowerCase().indexOf(query) >= 0; }); });
}

function EV34_fullCheck_(){
  var checks = [], fatal = 0, warnings = [];
  function add(name, ok, detail, warnOnly){ if(!ok && warnOnly) warnings.push(name + ': ' + (detail||'')); if(!ok && !warnOnly) fatal++; checks.push({name:name, ok:!!ok, detail:detail||'', warnOnly:!!warnOnly}); }
  var html = EV22_readEventVendorHtml_();
  var linkHeaders = [], policyHeaders = [];
  try { linkHeaders = EV33_getHeaders_(EV33_ss_().getSheetByName('ERP_행사업체연결')); policyHeaders = EV33_getHeaders_(EV33_ss_().getSheetByName('ERP_행사업체정산정책')); } catch(e) { add('headers readable', false, String(e && e.message ? e.message : e), false); }
  var required = EV34_policyHeaders_();
  add('event/vendor functions still exist', typeof getEventVendorBootstrap === 'function' && typeof saveEventVendorLink === 'function' && typeof searchEventVendorData === 'function', '기존 행사/업체/연결 함수 보존', false);
  add('product/policy/preview functions still exist', typeof saveEventVendorProduct === 'function' && typeof saveEventVendorSettlementPolicy === 'function' && typeof previewEventVendorSettlement === 'function', '상품/정책/미리보기 함수 보존', false);
  add('ERP_행사업체연결 policy headers present', required.filter(function(h){ return linkHeaders.indexOf(h) < 0; }).length === 0, 'missing=' + required.filter(function(h){ return linkHeaders.indexOf(h) < 0; }).join('|'), false);
  add('ERP_행사업체정산정책 policy headers present', required.filter(function(h){ return policyHeaders.indexOf(h) < 0; }).length === 0, 'missing=' + required.filter(function(h){ return policyHeaders.indexOf(h) < 0; }).join('|'), false);
  add('fixedFee preserved in policy sheet', policyHeaders.indexOf('fixedFee') >= 0, 'fixedFee 삭제 금지', false);
  add('UI removes fixed fee wording', html.indexOf('고정수수료') < 0, '고정수수료 문구 제거', false);
  add('UI shows boothFee term', html.indexOf('참여부스비') >= 0 && html.indexOf('boothFee') >= 0, '참여부스비/boothFee 표시', false);
  add('UI has payment owner fields', html.indexOf('paymentOwnerType') >= 0 && html.indexOf('COMPANY_ALL') >= 0 && html.indexOf('VENDOR_DIRECT') >= 0, '결제구조 3종', false);
  add('UI has commission separated fields', html.indexOf('saleCommissionRate') >= 0 && html.indexOf('saleCommissionFixedAmount') >= 0 && html.indexOf('unitCommissionAmount') >= 0, '판매수수료율/전표당/대당 분리', false);
  add('UI has settlement direction fields', html.indexOf('settlementDirection') >= 0 && html.indexOf('vendorPayableAmount') >= 0 && html.indexOf('vendorReceivableAmount') >= 0 && html.indexOf('offsetAmount') >= 0, '정산방향/지급/청구/상계 분리', false);
  add('code set validation exists', typeof EV34_assertPaymentOwnerType_ === 'function' && typeof EV34_assertSettlementDirection_ === 'function' && typeof EV34_assertPolicyType_ === 'function', '코드값 검증 함수', false);
  try {
    var sample = EV34_policyFieldData_({paymentOwnerType:'MIXED', settlementPolicyType:'MIXED', boothFee:'1,000,000', boothFeeBillingType:'DEDUCT_FROM_SETTLEMENT', boothFeeStatus:'PARTIAL', boothFeePaidAmount:'300,000', saleCommissionRate:'13', saleCommissionFixedAmount:'50,000', unitCommissionAmount:'10,000', unitCommissionBasis:'PRODUCT_UNIT', companyReceivedAmount:'2,000,000', vendorReceivedAmount:'3,200,000', customerTotalPaidAmount:'5,200,000', settlementDirection:'OFFSET', vendorPayableAmount:'0', vendorReceivableAmount:'0', offsetAmount:'264,000'});
    add('policy field parser self test', sample.boothFeeBalance === 700000 && sample.saleCommissionRate === 13 && sample.settlementDirection === 'OFFSET', JSON.stringify(sample), false);
  } catch(e2) { add('policy field parser self test', false, String(e2 && e2.message ? e2.message : e2), false); }
  var result = { ok:fatal===0, fatal:fatal, warnings:warnings, build:EV34_BUILD_NAME, label:EV34_BUILD_NO, checkedAt:new Date().toISOString(), result:{checks:checks, scope:'B34 UI/save separation only; no settlement execution'}, errorCode:fatal?'ERP_EVENT_VENDOR_POLICY_UI_SAVE_FULLCHECK_FAILED':'', meta:{buildNo:EV34_BUILD_NO, buildName:EV34_BUILD_NAME} };
  Logger.log('=============================='); Logger.log('[ERP FULL CHECK] erpEventVendorCore_fullCheck_20260502_log'); Logger.log(JSON.stringify(result,null,2)); Logger.log('==============================');
  return result;
}

// ---- B34 실행 함수 정리본 ----
function erpEventVendorCore_fullCheck_20260502_log() { return EV34_fullCheck_(); }
function erpB06J36_34_eventVendorPolicyUiSave_fullCheck() { return EV34_fullCheck_(); }


/**
 * B34A - Settlement preview policy type compatibility fix
 * - 원인: B34부터 화면/저장은 settlementPolicyType = RATE/BOOTH_ONLY/FIXED_PER_SALE/PER_UNIT/MIXED 로 전환되었지만
 *   기존 미리보기 계산 함수는 legacy settlementType = COMMISSION_RATE/FIXED_FEE/MIXED/NONE 만 허용했다.
 * - 조치: 미리보기 계산 함수가 신규 코드와 legacy 코드를 모두 허용하도록 override 한다.
 * - 정산 확정/지급/전표 생성 없음. PREVIEW_ONLY 유지.
 */
var EV34A_BUILD_NO = 'v64-B06J36-34A';
var EV34A_BUILD_NAME = 'ERP_B06J36_34A_SETTLEMENT_PREVIEW_POLICY_TYPE_COMPAT_SAFE';

function EV34A_policyTypeForPreview_(policy) {
  policy = policy || {};
  return EV34_assertPolicyType_(policy.settlementPolicyType || policy.settlementType || policy['정산방식'] || 'NONE');
}

function EV34A_policyMoney_(policy, key, legacyKey) {
  policy = policy || {};
  if (policy[key] !== undefined && EV34_s_(policy[key]) !== '') return EV34_money_(policy[key], key);
  if (legacyKey && policy[legacyKey] !== undefined && EV34_s_(policy[legacyKey]) !== '') return EV34_money_(policy[legacyKey], legacyKey);
  return 0;
}

function EV34A_policyPercent_(policy, key, legacyKey) {
  policy = policy || {};
  if (policy[key] !== undefined && EV34_s_(policy[key]) !== '') return EV34_percent_(policy[key], key);
  if (legacyKey && policy[legacyKey] !== undefined && EV34_s_(policy[legacyKey]) !== '') return EV34_percent_(policy[legacyKey], legacyKey);
  return 0;
}

// Override EV29_calcPreview_: 신규 정산방식 코드도 미리보기에서 허용한다.
function EV29_calcPreview_(products, policy) {
  products = products || [];
  policy = policy || {};
  var settlementPolicyType = EV34A_policyTypeForPreview_(policy);
  var rate = EV34A_policyPercent_(policy, 'saleCommissionRate', 'commissionRate');
  var boothFee = EV34A_policyMoney_(policy, 'boothFee', 'fixedFee');
  var saleCommissionFixedAmount = EV34A_policyMoney_(policy, 'saleCommissionFixedAmount', null);
  var unitCommissionAmount = EV34A_policyMoney_(policy, 'unitCommissionAmount', null);

  var gross = 0;
  var rateFee = 0;
  var rows = products.map(function(p) {
    var price = EV29_money_(p.basePrice || p['basePrice'] || p['기본가']);
    var productRateFee = (settlementPolicyType === 'RATE' || settlementPolicyType === 'MIXED') ? EV29_round_(price * rate / 100) : 0;
    gross += price;
    rateFee += productRateFee;
    return {
      productId: EV8_s_(p.productId || p['productId']),
      productName: EV8_s_(p.productName || p['productName'] || p['상품명']),
      category: EV8_s_(p.category || p['category'] || p['카테고리']),
      basePrice: price,
      rateFee: productRateFee,
      productStatus: EV8_s_(p.productStatus || p['productStatus'])
    };
  });

  var saleCount = products.length;
  var unitCount = products.length;
  var boothFeeApplied = (settlementPolicyType === 'BOOTH_ONLY' || settlementPolicyType === 'MIXED') ? boothFee : 0;
  var fixedSaleCommission = (settlementPolicyType === 'FIXED_PER_SALE' || settlementPolicyType === 'MIXED') ? EV29_round_(saleCount * saleCommissionFixedAmount) : 0;
  var unitCommission = (settlementPolicyType === 'PER_UNIT' || settlementPolicyType === 'MIXED') ? EV29_round_(unitCount * unitCommissionAmount) : 0;
  var totalFee = EV29_round_(boothFeeApplied + rateFee + fixedSaleCommission + unitCommission);

  return {
    settlementType: settlementPolicyType,
    settlementPolicyType: settlementPolicyType,
    commissionRate: rate,
    saleCommissionRate: rate,
    fixedFee: boothFee,
    boothFee: boothFee,
    saleCommissionFixedAmount: saleCommissionFixedAmount,
    unitCommissionAmount: unitCommissionAmount,
    productCount: products.length,
    saleCount: saleCount,
    unitCount: unitCount,
    grossAmount: gross,
    rateFee: rateFee,
    boothFeeApplied: boothFeeApplied,
    fixedFeeApplied: boothFeeApplied,
    fixedSaleCommission: fixedSaleCommission,
    unitCommission: unitCommission,
    totalFee: totalFee,
    vendorExpectedAmount: gross - totalFee,
    rows: rows
  };
}

function EV34A_fullCheck_(){
  var checks = [], fatal = 0, warnings = [];
  function add(name, ok, detail, warnOnly){ if(!ok && warnOnly) warnings.push(name + ': ' + (detail||'')); if(!ok && !warnOnly) fatal++; checks.push({name:name, ok:!!ok, detail:detail||'', warnOnly:!!warnOnly}); }
  var html = EV22_readEventVendorHtml_();
  var linkHeaders = [], policyHeaders = [];
  try { linkHeaders = EV33_getHeaders_(EV33_ss_().getSheetByName('ERP_행사업체연결')); policyHeaders = EV33_getHeaders_(EV33_ss_().getSheetByName('ERP_행사업체정산정책')); } catch(e) { add('headers readable', false, String(e && e.message ? e.message : e), false); }
  var required = EV34_policyHeaders_();
  add('event/vendor functions still exist', typeof getEventVendorBootstrap === 'function' && typeof saveEventVendorLink === 'function' && typeof searchEventVendorData === 'function', '기존 행사/업체/연결 함수 보존', false);
  add('product/policy/preview functions still exist', typeof saveEventVendorProduct === 'function' && typeof saveEventVendorSettlementPolicy === 'function' && typeof previewEventVendorSettlement === 'function', '상품/정책/미리보기 함수 보존', false);
  add('policy headers present', required.filter(function(h){ return linkHeaders.indexOf(h) < 0 || policyHeaders.indexOf(h) < 0; }).length === 0, 'link/policy missing checked', false);
  add('UI removes fixed fee wording', html.indexOf('고정수수료') < 0, '고정수수료 문구 제거', false);
  add('UI shows boothFee term', html.indexOf('참여부스비') >= 0 && html.indexOf('boothFee') >= 0, '참여부스비/boothFee 표시', false);
  add('new policy type normalizer exists', typeof EV34_assertPolicyType_ === 'function' && typeof EV34A_policyTypeForPreview_ === 'function', 'RATE/BOOTH_ONLY/FIXED_PER_SALE/PER_UNIT/MIXED 지원', false);
  try {
    var rateCalc = EV29_calcPreview_([{productId:'P1',productName:'A',category:'C',basePrice:100000}], {settlementPolicyType:'RATE',saleCommissionRate:10,boothFee:0});
    add('preview accepts RATE policy type', rateCalc.totalFee === 10000 && rateCalc.settlementPolicyType === 'RATE', JSON.stringify(rateCalc), false);
  } catch(e1) { add('preview accepts RATE policy type', false, String(e1 && e1.message ? e1.message : e1), false); }
  try {
    var mixedCalc = EV29_calcPreview_([{productId:'P1',productName:'A',category:'C',basePrice:5200000}], {settlementPolicyType:'MIXED',saleCommissionRate:13,boothFee:2000000,saleCommissionFixedAmount:0,unitCommissionAmount:0});
    add('preview accepts MIXED separated policy fields', mixedCalc.rateFee === 676000 && mixedCalc.boothFeeApplied === 2000000 && mixedCalc.totalFee === 2676000, JSON.stringify(mixedCalc), false);
  } catch(e2) { add('preview accepts MIXED separated policy fields', false, String(e2 && e2.message ? e2.message : e2), false); }
  try {
    var legacyCalc = EV29_calcPreview_([{productId:'P1',productName:'A',category:'C',basePrice:100000}], {settlementType:'COMMISSION_RATE',commissionRate:10,fixedFee:0});
    add('preview keeps legacy COMMISSION_RATE compatibility', legacyCalc.totalFee === 10000 && legacyCalc.settlementPolicyType === 'RATE', JSON.stringify(legacyCalc), false);
  } catch(e3) { add('preview keeps legacy COMMISSION_RATE compatibility', false, String(e3 && e3.message ? e3.message : e3), false); }

  var result = { ok:fatal===0, fatal:fatal, warnings:warnings, build:EV34A_BUILD_NAME, label:EV34A_BUILD_NO, checkedAt:new Date().toISOString(), result:{checks:checks, scope:'B34A preview policy type compatibility only; no settlement execution'}, errorCode:fatal?'ERP_EVENT_VENDOR_POLICY_PREVIEW_COMPAT_FULLCHECK_FAILED':'', meta:{buildNo:EV34A_BUILD_NO, buildName:EV34A_BUILD_NAME} };
  Logger.log('=============================='); Logger.log('[ERP FULL CHECK] erpEventVendorCore_fullCheck_20260502_log'); Logger.log(JSON.stringify(result,null,2)); Logger.log('==============================');
  return result;
}

// ---- B34A 실행 함수 정리본 ----
function erpEventVendorCore_fullCheck_20260502_log() { return EV34A_fullCheck_(); }
function erpB06J36_34A_settlementPreviewPolicyTypeCompat_fullCheck() { return EV34A_fullCheck_(); }


/* =====================================================================
 * B06J36-35 SETTLEMENT PREVIEW PAYMENT OWNER SAFE
 * 결제구조별 정산 미리보기 재계산 / 수취비율 자동 + 수동보정 가능
 * - COMPANY_ALL / MIXED / VENDOR_DIRECT 계산 분리
 * - boothFeeStatus PAID/WAIVED 시 부스비 재차감 금지
 * - companyReceivedRate / vendorReceivedRate / receivedCalcMode 지원
 * - PREVIEW_ONLY 유지. 정산 확정/지급/전표/SIGN 기프트 정산 인계 없음.
 * ===================================================================== */
var EV35_BUILD_NO = 'v64-B06J36-35';
var EV35_BUILD_NAME = 'ERP_B06J36_35_SETTLEMENT_PREVIEW_PAYMENT_OWNER_SAFE';

function EV35_assertReceivedCalcMode_(v) {
  return EV34_assertIn_(v, ['RATE_AUTO','AMOUNT_MANUAL','PAYMENT_MATCHED'], '수취계산방식', 'RATE_AUTO');
}
function EV35_num_(v){ return EV34_money_(v || 0, '금액'); }
function EV35_percent_(v){ return EV34_percent_(v || 0, '비율'); }
function EV35_round_(n){ return Math.round(Number(n || 0)); }
function EV35_isChargeableBooth_(billingType, status){
  return !(billingType === 'WAIVED' || status === 'WAIVED' || status === 'PAID');
}
function EV35_feeComponentFlags_(type){
  return {
    rate: type === 'RATE' || type === 'MIXED',
    fixedSale: type === 'FIXED_PER_SALE' || type === 'MIXED',
    unit: type === 'PER_UNIT' || type === 'MIXED',
    none: type === 'NONE'
  };
}
function EV35_policyFieldData_(payload){
  var base = EV34_policyFieldData_(payload || {});
  base.receivedCalcMode = EV35_assertReceivedCalcMode_((payload || {}).receivedCalcMode || (payload || {})['수취계산방식']);
  base.companyReceivedRate = EV35_percent_((payload || {}).companyReceivedRate || (payload || {})['당사수취비율']);
  base.vendorReceivedRate = EV35_percent_((payload || {}).vendorReceivedRate || (payload || {})['업체수취비율']);
  if (base.receivedCalcMode === 'RATE_AUTO' && base.paymentOwnerType === 'MIXED') {
    var sum = Number(base.companyReceivedRate || 0) + Number(base.vendorReceivedRate || 0);
    if (sum > 0 && Math.round(sum * 100) !== 10000) throw new Error('혼합결제 비율 자동 계산은 당사수취비율 + 업체수취비율이 100%여야 합니다. 현재=' + sum + '%');
  }
  return base;
}
// B35 override: 정책 저장 파서에 수취비율/계산방식을 추가한다.
function EV34_policyFieldData_(payload){ return EV35_policyFieldData_(payload || {}); }

// B35 override: 정책 시트 헤더에 수취비율/계산방식 필드를 보존한다.
function EV27_policySheet_() {
  return EV8_ensureSheet_('ERP_행사업체정산정책', [
    'policyId','eventVendorId','linkId','eventId','eventName','vendorId','vendorName',
    'policyName','settlementType','commissionRate','fixedFee','paymentCycle','isDefault','policyStatus','memo',
    'createdAt','createdBy','updatedAt','updatedBy',
    'settlementPolicyType','boothFee','saleCommissionRate','saleCommissionFixedAmount','unitCommissionAmount','unitCommissionBasis','settlementNote',
    'paymentOwnerType','boothFeeBillingType','boothFeeStatus','boothFeePaidAmount','boothFeeBalance','companyReceivedAmount','vendorReceivedAmount','customerTotalPaidAmount','settlementDirection','vendorPayableAmount','vendorReceivableAmount','offsetAmount',
    'receivedCalcMode','companyReceivedRate','vendorReceivedRate'
  ]);
}

function EV35_policyValue_(policy, key, fallbackKey, def){
  policy = policy || {};
  if (policy[key] !== undefined && EV34_s_(policy[key]) !== '') return policy[key];
  if (fallbackKey && policy[fallbackKey] !== undefined && EV34_s_(policy[fallbackKey]) !== '') return policy[fallbackKey];
  return def;
}
function EV35_calcReceived_(policy, gross){
  var paymentOwnerType = EV34_assertPaymentOwnerType_(EV35_policyValue_(policy,'paymentOwnerType',null,'COMPANY_ALL'));
  var mode = EV35_assertReceivedCalcMode_(EV35_policyValue_(policy,'receivedCalcMode',null,'RATE_AUTO'));
  var customerTotal = EV35_num_(EV35_policyValue_(policy,'customerTotalPaidAmount',null,gross));
  if (customerTotal <= 0) customerTotal = gross;
  var companyRate = EV35_percent_(EV35_policyValue_(policy,'companyReceivedRate',null,0));
  var vendorRate = EV35_percent_(EV35_policyValue_(policy,'vendorReceivedRate',null,0));
  var companyAmount = EV35_num_(EV35_policyValue_(policy,'companyReceivedAmount',null,0));
  var vendorAmount = EV35_num_(EV35_policyValue_(policy,'vendorReceivedAmount',null,0));

  if (mode === 'RATE_AUTO') {
    if (paymentOwnerType === 'COMPANY_ALL') { companyRate = 100; vendorRate = 0; companyAmount = customerTotal; vendorAmount = 0; }
    else if (paymentOwnerType === 'VENDOR_DIRECT') { companyRate = 0; vendorRate = 100; companyAmount = 0; vendorAmount = customerTotal; }
    else {
      if (companyRate <= 0 && vendorRate <= 0 && (companyAmount > 0 || vendorAmount > 0)) {
        // 기존 수동 금액이 있으면 비율이 없어도 금액을 존중한다.
        mode = 'AMOUNT_MANUAL';
      } else {
        if (companyRate <= 0 && vendorRate <= 0) { companyRate = 0; vendorRate = 100; }
        if (companyRate > 0 && vendorRate <= 0) vendorRate = Math.max(0, 100 - companyRate);
        if (vendorRate > 0 && companyRate <= 0) companyRate = Math.max(0, 100 - vendorRate);
        companyAmount = EV35_round_(customerTotal * companyRate / 100);
        vendorAmount = Math.max(0, customerTotal - companyAmount);
      }
    }
  }
  if (mode === 'AMOUNT_MANUAL' || mode === 'PAYMENT_MATCHED') {
    if (companyAmount <= 0 && vendorAmount <= 0) {
      if (paymentOwnerType === 'COMPANY_ALL') companyAmount = customerTotal;
      else if (paymentOwnerType === 'VENDOR_DIRECT') vendorAmount = customerTotal;
    }
    if (companyRate <= 0 && customerTotal > 0) companyRate = EV35_round_(companyAmount / customerTotal * 10000) / 100;
    if (vendorRate <= 0 && customerTotal > 0) vendorRate = EV35_round_(vendorAmount / customerTotal * 10000) / 100;
  }
  return { paymentOwnerType:paymentOwnerType, receivedCalcMode:mode, customerTotalPaidAmount:customerTotal, companyReceivedRate:companyRate, vendorReceivedRate:vendorRate, companyReceivedAmount:companyAmount, vendorReceivedAmount:vendorAmount };
}

// Override EV29_calcPreview_: 결제구조/수취방식/부스비 상태를 반영한다.
function EV29_calcPreview_(products, policy) {
  products = products || [];
  policy = policy || {};
  var settlementPolicyType = EV34A_policyTypeForPreview_(policy);
  var flags = EV35_feeComponentFlags_(settlementPolicyType);
  var rate = EV34A_policyPercent_(policy, 'saleCommissionRate', 'commissionRate');
  var boothFee = EV34A_policyMoney_(policy, 'boothFee', 'fixedFee');
  var boothFeePaidAmount = EV35_num_(EV35_policyValue_(policy,'boothFeePaidAmount',null,0));
  var boothFeeBalance = EV35_num_(EV35_policyValue_(policy,'boothFeeBalance',null,Math.max(0, boothFee - boothFeePaidAmount)));
  var boothFeeBillingType = EV34_assertBoothFeeBillingType_(EV35_policyValue_(policy,'boothFeeBillingType',null,'DEDUCT_FROM_SETTLEMENT'));
  var boothFeeStatus = EV34_assertBoothFeeStatus_(EV35_policyValue_(policy,'boothFeeStatus',null,'UNPAID'));
  var saleCommissionFixedAmount = EV34A_policyMoney_(policy, 'saleCommissionFixedAmount', null);
  var unitCommissionAmount = EV34A_policyMoney_(policy, 'unitCommissionAmount', null);
  var unitCommissionBasis = EV34_assertUnitBasis_(EV35_policyValue_(policy,'unitCommissionBasis',null,'PRODUCT_UNIT'));

  var gross = 0, rateFee = 0;
  var rows = products.map(function(p) {
    var price = EV29_money_(p.basePrice || p['basePrice'] || p['기본가']);
    var productRateFee = (!flags.none && flags.rate) ? EV29_round_(price * rate / 100) : 0;
    gross += price;
    rateFee += productRateFee;
    return {
      productId: EV8_s_(p.productId || p['productId']),
      productName: EV8_s_(p.productName || p['productName'] || p['상품명']),
      category: EV8_s_(p.category || p['category'] || p['카테고리']),
      basePrice: price,
      rateFee: productRateFee,
      productStatus: EV8_s_(p.productStatus || p['productStatus'])
    };
  });

  var saleCount = products.length;
  var unitCount = products.length;
  var boothFeeChargeAmount = (!flags.none && boothFee > 0 && EV35_isChargeableBooth_(boothFeeBillingType, boothFeeStatus)) ? (boothFeeBalance > 0 ? boothFeeBalance : Math.max(0, boothFee - boothFeePaidAmount)) : 0;
  if (settlementPolicyType === 'BOOTH_ONLY') { rateFee = 0; }
  var fixedSaleCommission = (!flags.none && flags.fixedSale) ? EV29_round_(saleCount * saleCommissionFixedAmount) : 0;
  var unitCommission = (!flags.none && flags.unit) ? EV29_round_(unitCount * unitCommissionAmount) : 0;
  var feelhausChargeAmount = EV29_round_(boothFeeChargeAmount + rateFee + fixedSaleCommission + unitCommission);
  var received = EV35_calcReceived_(policy, gross);
  var direction = 'NO_ACTION', vendorPayable = 0, vendorReceivable = 0, offsetAmount = 0;

  if (received.paymentOwnerType === 'COMPANY_ALL') {
    vendorPayable = Math.max(0, received.companyReceivedAmount - feelhausChargeAmount);
    vendorReceivable = Math.max(0, feelhausChargeAmount - received.companyReceivedAmount);
  } else if (received.paymentOwnerType === 'VENDOR_DIRECT') {
    vendorReceivable = Math.max(0, feelhausChargeAmount - received.companyReceivedAmount);
    vendorPayable = 0;
  } else {
    var delta = received.companyReceivedAmount - feelhausChargeAmount;
    if (delta > 0) vendorPayable = delta;
    else if (delta < 0) vendorReceivable = Math.abs(delta);
  }
  if (vendorPayable > 0 && vendorReceivable > 0) {
    offsetAmount = Math.min(vendorPayable, vendorReceivable);
    vendorPayable -= offsetAmount;
    vendorReceivable -= offsetAmount;
    direction = 'OFFSET';
  } else if (vendorPayable > 0) direction = 'PAY_TO_VENDOR';
  else if (vendorReceivable > 0) direction = 'COLLECT_FROM_VENDOR';
  else direction = 'NO_ACTION';

  return {
    settlementType: settlementPolicyType,
    settlementPolicyType: settlementPolicyType,
    paymentOwnerType: received.paymentOwnerType,
    receivedCalcMode: received.receivedCalcMode,
    companyReceivedRate: received.companyReceivedRate,
    vendorReceivedRate: received.vendorReceivedRate,
    commissionRate: rate,
    saleCommissionRate: rate,
    fixedFee: boothFee,
    boothFee: boothFee,
    boothFeeBillingType: boothFeeBillingType,
    boothFeeStatus: boothFeeStatus,
    boothFeePaidAmount: boothFeePaidAmount,
    boothFeeBalance: boothFeeBalance,
    saleCommissionFixedAmount: saleCommissionFixedAmount,
    unitCommissionAmount: unitCommissionAmount,
    unitCommissionBasis: unitCommissionBasis,
    productCount: products.length,
    saleCount: saleCount,
    unitCount: unitCount,
    grossAmount: gross,
    customerTotalPaidAmount: received.customerTotalPaidAmount,
    companyReceivedAmount: received.companyReceivedAmount,
    vendorReceivedAmount: received.vendorReceivedAmount,
    rateFee: rateFee,
    rateCommission: rateFee,
    boothFeeApplied: boothFeeChargeAmount,
    boothFeeChargeAmount: boothFeeChargeAmount,
    fixedFeeApplied: boothFeeChargeAmount,
    fixedSaleCommission: fixedSaleCommission,
    unitCommission: unitCommission,
    totalFee: feelhausChargeAmount,
    totalCommission: feelhausChargeAmount,
    feelhausChargeAmount: feelhausChargeAmount,
    settlementDirection: direction,
    vendorPayableAmount: vendorPayable,
    vendorReceivableAmount: vendorReceivable,
    offsetAmount: offsetAmount,
    vendorExpectedAmount: vendorPayable,
    rows: rows
  };
}

// Override preview: B35 계산 결과 스냅샷 확장. PREVIEW_ONLY만 수행한다.
function previewEventVendorSettlement(payload){
  payload = payload || {};
  var eventVendorId = EV8_s_(payload.eventVendorId || payload.linkId || payload['eventVendorId'] || payload['연결ID']);
  if (!eventVendorId) throw new Error('정산 미리보기를 실행할 행사업체 연결을 선택하세요.');
  var link = EV24_getLinkById_(eventVendorId);
  if (!link) throw new Error('행사업체 연결을 찾지 못했습니다: ' + eventVendorId);
  var linkStatus = EV21_assertStatus_(link.status || link['상태값'] || '');
  if (linkStatus === 'LOCKED' || linkStatus === 'CLOSED') throw new Error('LOCKED/CLOSED 행사업체 연결은 정산 미리보기 대상에서 제외됩니다.');
  var policy = EV29_getActiveDefaultPolicy_(eventVendorId);
  var products = EV29_getActiveProducts_(eventVendorId);
  if (!products.length) throw new Error('ACTIVE 상품/품목이 없습니다. 정산 미리보기는 ACTIVE 상품만 대상으로 합니다.');
  var calc = EV29_calcPreview_(products, policy);
  var previewId = EV8_makeId_('PRV-');
  var inputSnapshot = {
    eventVendorId: eventVendorId,
    linkStatus: linkStatus,
    policyId: EV8_s_(policy.policyId || policy['policyId']),
    policyName: EV8_s_(policy.policyName || policy['policyName']),
    productIds: products.map(function(p){ return EV8_s_(p.productId || p['productId']); }),
    baseAmount: calc.grossAmount,
    customerTotalPaidAmount: calc.customerTotalPaidAmount,
    paymentOwnerType: calc.paymentOwnerType,
    receivedCalcMode: calc.receivedCalcMode,
    companyReceivedRate: calc.companyReceivedRate,
    vendorReceivedRate: calc.vendorReceivedRate,
    companyReceivedAmount: calc.companyReceivedAmount,
    vendorReceivedAmount: calc.vendorReceivedAmount,
    settlementPolicyType: calc.settlementPolicyType,
    boothFee: calc.boothFee,
    boothFeeStatus: calc.boothFeeStatus,
    boothFeeBillingType: calc.boothFeeBillingType,
    boothFeeChargeAmount: calc.boothFeeChargeAmount,
    saleCommissionRate: calc.saleCommissionRate,
    saleCommissionFixedAmount: calc.saleCommissionFixedAmount,
    unitCommissionAmount: calc.unitCommissionAmount
  };
  var out = {
    ok: true,
    previewId: previewId,
    mode: 'PREVIEW_ONLY',
    message: '정산 미리보기 완료. 정산 확정/지급/전표 생성은 실행하지 않았습니다.',
    eventVendorId: eventVendorId,
    linkStatus: linkStatus,
    eventId: EV8_s_(link.eventId || link['행사ID']),
    eventName: EV8_s_(link.eventName || link['행사명']),
    vendorId: EV8_s_(link.vendorId || link['업체ID']),
    vendorName: EV8_s_(link.vendorName || link['업체명']),
    policy: {
      policyId: EV8_s_(policy.policyId || policy['policyId']),
      policyName: EV8_s_(policy.policyName || policy['policyName']),
      settlementType: calc.settlementPolicyType,
      settlementPolicyType: calc.settlementPolicyType,
      paymentOwnerType: calc.paymentOwnerType,
      receivedCalcMode: calc.receivedCalcMode,
      companyReceivedRate: calc.companyReceivedRate,
      vendorReceivedRate: calc.vendorReceivedRate,
      commissionRate: calc.commissionRate,
      saleCommissionRate: calc.saleCommissionRate,
      fixedFee: calc.boothFee,
      boothFee: calc.boothFee,
      boothFeeStatus: calc.boothFeeStatus,
      boothFeeBillingType: calc.boothFeeBillingType,
      saleCommissionFixedAmount: calc.saleCommissionFixedAmount,
      unitCommissionAmount: calc.unitCommissionAmount,
      paymentCycle: EV8_s_(policy.paymentCycle || policy['paymentCycle']),
      isDefault: EV8_s_(policy.isDefault || policy['isDefault']),
      policyStatus: EV8_s_(policy.policyStatus || policy['policyStatus'])
    },
    totals: {
      productCount: calc.productCount,
      grossAmount: calc.grossAmount,
      customerTotalPaidAmount: calc.customerTotalPaidAmount,
      companyReceivedAmount: calc.companyReceivedAmount,
      vendorReceivedAmount: calc.vendorReceivedAmount,
      rateFee: calc.rateFee,
      boothFeeChargeAmount: calc.boothFeeChargeAmount,
      fixedFeeApplied: calc.fixedFeeApplied,
      fixedSaleCommission: calc.fixedSaleCommission,
      unitCommission: calc.unitCommission,
      totalFee: calc.totalFee,
      totalCommission: calc.totalCommission,
      feelhausChargeAmount: calc.feelhausChargeAmount,
      settlementDirection: calc.settlementDirection,
      vendorPayableAmount: calc.vendorPayableAmount,
      vendorReceivableAmount: calc.vendorReceivableAmount,
      offsetAmount: calc.offsetAmount,
      vendorExpectedAmount: calc.vendorExpectedAmount
    },
    rows: calc.rows,
    inputSnapshot: inputSnapshot,
    excluded: { closedProductsExcluded:true, closedPoliciesExcluded:true, giftSettlementExcluded:true, finalSettlementExecuted:false }
  };
  EV30_appendPreviewSnapshot_(out, inputSnapshot);
  EV8_appendLog_('EVENT_VENDOR_SETTLEMENT_PREVIEW', eventVendorId, out.eventName + '/' + out.vendorName, '행사업체 정산 미리보기 실행. previewId=' + previewId + ' / ' + calc.paymentOwnerType + ' / ' + calc.settlementDirection + ' / 정산 확정·지급·전표 생성 없음');
  return out;
}

function EV35_fullCheck_(){
  var checks = [], fatal = 0, warnings = [];
  function add(name, ok, detail, warnOnly){ if(!ok && warnOnly) warnings.push(name + ': ' + (detail||'')); if(!ok && !warnOnly) fatal++; checks.push({name:name, ok:!!ok, detail:detail||'', warnOnly:!!warnOnly}); }
  try { add('event/vendor functions still exist', typeof getEventVendorBootstrap === 'function' && typeof saveEventVendorLink === 'function' && typeof searchEventVendorData === 'function', '기존 행사/업체/연결 함수 보존', false); } catch(e1) { add('event/vendor functions still exist', false, String(e1), false); }
  try { add('product/policy/preview functions still exist', typeof saveEventVendorProduct === 'function' && typeof saveEventVendorSettlementPolicy === 'function' && typeof previewEventVendorSettlement === 'function', '상품/정책/미리보기 함수 보존', false); } catch(e2) { add('product/policy/preview functions still exist', false, String(e2), false); }
  try {
    var html = HtmlService.createHtmlOutputFromFile('EventVendor').getContent();
    add('UI has received rate fields', html.indexOf('companyReceivedRate') >= 0 && html.indexOf('vendorReceivedRate') >= 0 && html.indexOf('receivedCalcMode') >= 0, '수취비율/계산방식 UI', false);
    add('UI keeps PREVIEW_ONLY wording', html.indexOf('PREVIEW_ONLY') >= 0, '정산 확정/지급/전표 생성 없음', false);
  } catch(e3) { add('UI fields check', false, String(e3), false); }
  try {
    var p1 = {paymentOwnerType:'COMPANY_ALL', settlementPolicyType:'RATE', saleCommissionRate:10, boothFee:500000, boothFeeStatus:'PAID', customerTotalPaidAmount:1000000, receivedCalcMode:'RATE_AUTO'};
    var c1 = EV29_calcPreview_([{productId:'P1',productName:'A',basePrice:1000000,productStatus:'ACTIVE'}], p1);
    add('COMPANY_ALL paid boothFee not recharged', c1.boothFeeChargeAmount === 0 && c1.vendorPayableAmount === 900000 && c1.settlementDirection === 'PAY_TO_VENDOR', JSON.stringify(c1), false);
  } catch(e4) { add('COMPANY_ALL paid boothFee not recharged', false, String(e4), false); }
  try {
    var p2 = {paymentOwnerType:'VENDOR_DIRECT', settlementPolicyType:'RATE', saleCommissionRate:13, boothFee:0, customerTotalPaidAmount:1000000, receivedCalcMode:'RATE_AUTO'};
    var c2 = EV29_calcPreview_([{productId:'P1',productName:'A',basePrice:1000000,productStatus:'ACTIVE'}], p2);
    add('VENDOR_DIRECT creates collect receivable', c2.vendorReceivableAmount === 130000 && c2.vendorPayableAmount === 0 && c2.settlementDirection === 'COLLECT_FROM_VENDOR', JSON.stringify(c2), false);
  } catch(e5) { add('VENDOR_DIRECT creates collect receivable', false, String(e5), false); }
  try {
    var p3 = {paymentOwnerType:'MIXED', settlementPolicyType:'MIXED', saleCommissionRate:10, boothFee:100000, boothFeeStatus:'UNPAID', customerTotalPaidAmount:1000000, receivedCalcMode:'RATE_AUTO', companyReceivedRate:30, vendorReceivedRate:70};
    var c3 = EV29_calcPreview_([{productId:'P1',productName:'A',basePrice:1000000,productStatus:'ACTIVE'}], p3);
    add('MIXED rate auto separates company/vendor received', c3.companyReceivedAmount === 300000 && c3.vendorReceivedAmount === 700000 && c3.vendorPayableAmount === 100000 && c3.settlementDirection === 'PAY_TO_VENDOR', JSON.stringify(c3), false);
  } catch(e6) { add('MIXED rate auto separates company/vendor received', false, String(e6), false); }
  try {
    var p4 = {paymentOwnerType:'MIXED', settlementPolicyType:'RATE', saleCommissionRate:10, customerTotalPaidAmount:1000000, receivedCalcMode:'AMOUNT_MANUAL', companyReceivedAmount:50000, vendorReceivedAmount:950000};
    var c4 = EV29_calcPreview_([{productId:'P1',productName:'A',basePrice:1000000,productStatus:'ACTIVE'}], p4);
    add('MIXED amount manual can collect shortage', c4.vendorReceivableAmount === 50000 && c4.settlementDirection === 'COLLECT_FROM_VENDOR', JSON.stringify(c4), false);
  } catch(e7) { add('MIXED amount manual can collect shortage', false, String(e7), false); }
  try {
    var p5 = EV35_policyFieldData_({paymentOwnerType:'MIXED', settlementPolicyType:'RATE', saleCommissionRate:13, receivedCalcMode:'RATE_AUTO', companyReceivedRate:40, vendorReceivedRate:60});
    add('policy parser supports received rate fields', p5.receivedCalcMode === 'RATE_AUTO' && p5.companyReceivedRate === 40 && p5.vendorReceivedRate === 60, JSON.stringify(p5), false);
  } catch(e8) { add('policy parser supports received rate fields', false, String(e8), false); }
  var result = { ok:fatal===0, fatal:fatal, warnings:warnings, build:EV35_BUILD_NAME, label:EV35_BUILD_NO, checkedAt:new Date().toISOString(), result:{checks:checks, scope:'B35 paymentOwner settlement preview only; no final settlement execution'}, errorCode:fatal?'ERP_EVENT_VENDOR_PAYMENT_OWNER_PREVIEW_FULLCHECK_FAILED':'', meta:{buildNo:EV35_BUILD_NO, buildName:EV35_BUILD_NAME} };
  Logger.log('=============================='); Logger.log('[ERP FULL CHECK] erpEventVendorCore_fullCheck_20260502_log'); Logger.log(JSON.stringify(result,null,2)); Logger.log('==============================');
  return result;
}

// ---- B35 실행 함수 정리본 ----
function erpEventVendorCore_fullCheck_20260502_log() { return EV35_fullCheck_(); }
function erpB06J36_35_settlementPreviewPaymentOwner_fullCheck() { return EV35_fullCheck_(); }


/**
 * B35A: 결제구조/정산방식 기반 UI 잠금과 서버 저장 정규화.
 * - 상품 수취액은 관리자가 직접 계산하지 않는 것을 기본으로 한다.
 * - MIXED/RATE_AUTO는 당사비율만 입력하면 업체비율을 자동 보정한다.
 * - COMPANY_ALL/VENDOR_DIRECT는 수취비율과 결과 필드를 서버에서도 정규화한다.
 */
var EV35A_BUILD_NO = 'v64-B06J36-35A';
var EV35A_BUILD_NAME = 'ERP_B06J36_35A_POLICY_SMART_UI_GUARD_SAFE';

function EV35A_basePolicyFieldData_(payload){
  payload = payload || {};
  var settlementPolicyType = EV34_assertPolicyType_(payload.settlementPolicyType || payload.settlementType || payload['정산방식']);
  var paymentOwnerType = EV34_assertPaymentOwnerType_(payload.paymentOwnerType || payload['결제구조']);
  var boothFee = EV34_money_(payload.boothFee !== undefined ? payload.boothFee : (payload.fixedFee !== undefined ? payload.fixedFee : payload['참여부스비']), '참여부스비');
  var boothFeeBillingType = EV34_assertBoothFeeBillingType_(payload.boothFeeBillingType || payload['부스비청구방식']);
  var boothFeeStatus = EV34_assertBoothFeeStatus_(payload.boothFeeStatus || payload['부스비상태']);
  var boothFeePaidAmount = EV34_money_(payload.boothFeePaidAmount || payload['부스비납부액'], '부스비 납부액');
  var boothFeeBalance = payload.boothFeeBalance !== undefined && EV34_s_(payload.boothFeeBalance) !== ''
    ? EV34_money_(payload.boothFeeBalance, '부스비 잔액')
    : EV34_balance_(boothFee, boothFeePaidAmount, boothFeeBillingType, boothFeeStatus);
  var saleCommissionRate = EV34_percent_(payload.saleCommissionRate !== undefined ? payload.saleCommissionRate : (payload.commissionRate !== undefined ? payload.commissionRate : payload['판매수수료율']), '판매수수료율');
  var saleCommissionFixedAmount = EV34_money_(payload.saleCommissionFixedAmount || payload['전표당수수료'], '전표당수수료');
  var unitCommissionAmount = EV34_money_(payload.unitCommissionAmount || payload['대당수수료'], '대당수수료');
  var unitCommissionBasis = EV34_assertUnitBasis_(payload.unitCommissionBasis || payload['대당수수료기준']);
  var companyReceivedAmount = EV34_money_(payload.companyReceivedAmount || payload['당사수취액'], '당사수취액');
  var vendorReceivedAmount = EV34_money_(payload.vendorReceivedAmount || payload['업체수취액'], '업체수취액');
  var customerTotalPaidAmount = EV34_money_(payload.customerTotalPaidAmount || payload['고객총결제액'], '고객총결제액');
  var settlementDirection = EV34_assertSettlementDirection_(payload.settlementDirection || payload['정산방향']);
  var vendorPayableAmount = EV34_money_(payload.vendorPayableAmount || payload['업체지급액'], '업체지급액');
  var vendorReceivableAmount = EV34_money_(payload.vendorReceivableAmount || payload['업체청구액'], '업체청구액');
  var offsetAmount = EV34_money_(payload.offsetAmount || payload['상계액'], '상계액');
  var settlementNote = EV34_s_(payload.settlementNote || payload['비고'] || payload.memo || payload['메모']);

  // 정산방식별 불필요 필드 정규화. 조합은 MIXED에서만 저장한다.
  if (settlementPolicyType !== 'BOOTH_ONLY' && settlementPolicyType !== 'MIXED') { boothFee = 0; boothFeePaidAmount = 0; boothFeeBalance = 0; }
  if (settlementPolicyType !== 'RATE' && settlementPolicyType !== 'MIXED') saleCommissionRate = 0;
  if (settlementPolicyType !== 'FIXED_PER_SALE' && settlementPolicyType !== 'MIXED') saleCommissionFixedAmount = 0;
  if (settlementPolicyType !== 'PER_UNIT' && settlementPolicyType !== 'MIXED') unitCommissionAmount = 0;

  if (settlementPolicyType === 'BOOTH_ONLY' && boothFee <= 0) throw new Error('BOOTH_ONLY 정산방식은 참여부스비가 필요합니다.');
  if (settlementPolicyType === 'RATE' && saleCommissionRate <= 0) throw new Error('RATE 정산방식은 판매수수료율이 필요합니다.');
  if (settlementPolicyType === 'FIXED_PER_SALE' && saleCommissionFixedAmount <= 0) throw new Error('FIXED_PER_SALE 정산방식은 전표당수수료가 필요합니다.');
  if (settlementPolicyType === 'PER_UNIT' && unitCommissionAmount <= 0) throw new Error('PER_UNIT 정산방식은 대당수수료가 필요합니다.');
  if (settlementPolicyType === 'MIXED' && boothFee <= 0 && saleCommissionRate <= 0 && saleCommissionFixedAmount <= 0 && unitCommissionAmount <= 0) throw new Error('MIXED 정산방식은 참여부스비/판매수수료율/전표당수수료/대당수수료 중 하나 이상이 필요합니다.');
  if (boothFeeStatus === 'PAID' && boothFeePaidAmount < boothFee && boothFee > 0) throw new Error('부스비 상태 PAID는 납부액이 참여부스비 이상이어야 합니다.');
  if (boothFeeStatus === 'WAIVED' || boothFeeBillingType === 'WAIVED') { boothFeeBalance = 0; }

  var receivedCalcMode = EV35_assertReceivedCalcMode_(payload.receivedCalcMode || payload['수취계산방식'] || 'RATE_AUTO');
  var companyReceivedRate = EV35_percent_(payload.companyReceivedRate || payload['당사수취비율']);
  var vendorReceivedRate = EV35_percent_(payload.vendorReceivedRate || payload['업체수취비율']);

  if (paymentOwnerType === 'COMPANY_ALL') {
    receivedCalcMode = 'RATE_AUTO';
    companyReceivedRate = 100; vendorReceivedRate = 0;
    vendorReceivedAmount = 0;
    settlementDirection = 'PAY_TO_VENDOR';
    vendorReceivableAmount = 0; offsetAmount = 0;
  } else if (paymentOwnerType === 'VENDOR_DIRECT') {
    receivedCalcMode = 'RATE_AUTO';
    companyReceivedRate = 0; vendorReceivedRate = 100;
    companyReceivedAmount = 0;
    settlementDirection = 'COLLECT_FROM_VENDOR';
    vendorPayableAmount = 0; offsetAmount = 0;
  } else if (paymentOwnerType === 'MIXED') {
    if (receivedCalcMode === 'RATE_AUTO') {
      if (companyReceivedRate > 0 && vendorReceivedRate <= 0) vendorReceivedRate = Math.max(0, 100 - companyReceivedRate);
      if (vendorReceivedRate > 0 && companyReceivedRate <= 0) companyReceivedRate = Math.max(0, 100 - vendorReceivedRate);
      var sum = Number(companyReceivedRate || 0) + Number(vendorReceivedRate || 0);
      if (sum > 0 && Math.round(sum * 100) !== 10000) throw new Error('혼합결제 비율 자동 계산은 당사수취비율 + 업체수취비율이 100%여야 합니다. 현재=' + sum + '%');
      companyReceivedAmount = 0; vendorReceivedAmount = 0;
    }
    settlementDirection = 'NO_ACTION';
    vendorPayableAmount = 0; vendorReceivableAmount = 0; offsetAmount = 0;
  }

  return {
    paymentOwnerType: paymentOwnerType,
    settlementPolicyType: settlementPolicyType,
    boothFee: boothFee,
    boothFeeBillingType: boothFeeBillingType,
    boothFeeStatus: boothFeeStatus,
    boothFeePaidAmount: boothFeePaidAmount,
    boothFeeBalance: boothFeeBalance,
    saleCommissionRate: saleCommissionRate,
    saleCommissionFixedAmount: saleCommissionFixedAmount,
    unitCommissionAmount: unitCommissionAmount,
    unitCommissionBasis: unitCommissionBasis,
    companyReceivedAmount: companyReceivedAmount,
    vendorReceivedAmount: vendorReceivedAmount,
    customerTotalPaidAmount: customerTotalPaidAmount,
    settlementDirection: settlementDirection,
    vendorPayableAmount: vendorPayableAmount,
    vendorReceivableAmount: vendorReceivableAmount,
    offsetAmount: offsetAmount,
    settlementNote: settlementNote,
    receivedCalcMode: receivedCalcMode,
    companyReceivedRate: companyReceivedRate,
    vendorReceivedRate: vendorReceivedRate,
    settlementType: settlementPolicyType,
    commissionRate: saleCommissionRate,
    fixedFee: boothFee
  };
}

function EV34_policyFieldData_(payload){ return EV35A_basePolicyFieldData_(payload || {}); }
function EV35_policyFieldData_(payload){ return EV35A_basePolicyFieldData_(payload || {}); }

function EV35A_fullCheck_(){
  var checks = [], fatal = 0, warnings = [];
  function add(name, ok, detail, warnOnly){ if(!ok && warnOnly) warnings.push(name + ': ' + (detail||'')); if(!ok && !warnOnly) fatal++; checks.push({name:name, ok:!!ok, detail:detail||'', warnOnly:!!warnOnly}); }
  try { add('event/vendor functions still exist', typeof getEventVendorBootstrap === 'function' && typeof saveEventVendorLink === 'function' && typeof searchEventVendorData === 'function', '기존 행사/업체/연결 함수 보존', false); } catch(e1) { add('event/vendor functions still exist', false, String(e1), false); }
  try { add('product/policy/preview functions still exist', typeof saveEventVendorProduct === 'function' && typeof saveEventVendorSettlementPolicy === 'function' && typeof previewEventVendorSettlement === 'function', '상품/정책/미리보기 함수 보존', false); } catch(e2) { add('product/policy/preview functions still exist', false, String(e2), false); }
  try {
    var html = HtmlService.createHtmlOutputFromFile('EventVendor').getContent();
    add('UI has smart guard sentinel', html.indexOf('ERP_B06J36_35A_POLICY_SMART_UI_GUARD_SAFE') >= 0, 'B35A UI sentinel', false);
    add('UI has payment owner onchange guard', html.indexOf('paymentOwnerType" onchange="EV35A_applyPolicySmartGuard') >= 0, '결제구조 변경 시 자동 잠금', false);
    add('UI has auto rate sync handlers', html.indexOf('EV35A_syncCompanyRate') >= 0 && html.indexOf('EV35A_syncVendorRate') >= 0, '당사율/업체율 자동보정', false);
    add('UI locks settlement result fields by smart guard', html.indexOf("['settlementDirection','vendorPayableAmount','vendorReceivableAmount','offsetAmount']") >= 0, '결과필드 직접입력 잠금', false);
  } catch(e3) { add('UI smart guard check', false, String(e3), false); }
  try {
    var a = EV35A_basePolicyFieldData_({paymentOwnerType:'COMPANY_ALL', settlementPolicyType:'RATE', saleCommissionRate:13, receivedCalcMode:'AMOUNT_MANUAL', companyReceivedRate:30, vendorReceivedRate:70, vendorReceivedAmount:100000});
    add('COMPANY_ALL normalizes received fields', a.receivedCalcMode==='RATE_AUTO' && a.companyReceivedRate===100 && a.vendorReceivedRate===0 && a.vendorReceivedAmount===0 && a.settlementDirection==='PAY_TO_VENDOR', JSON.stringify(a), false);
  } catch(e4) { add('COMPANY_ALL normalizes received fields', false, String(e4), false); }
  try {
    var b = EV35A_basePolicyFieldData_({paymentOwnerType:'VENDOR_DIRECT', settlementPolicyType:'RATE', saleCommissionRate:13, companyReceivedAmount:100000, receivedCalcMode:'AMOUNT_MANUAL'});
    add('VENDOR_DIRECT normalizes received fields', b.receivedCalcMode==='RATE_AUTO' && b.companyReceivedRate===0 && b.vendorReceivedRate===100 && b.companyReceivedAmount===0 && b.settlementDirection==='COLLECT_FROM_VENDOR', JSON.stringify(b), false);
  } catch(e5) { add('VENDOR_DIRECT normalizes received fields', false, String(e5), false); }
  try {
    var c = EV35A_basePolicyFieldData_({paymentOwnerType:'MIXED', settlementPolicyType:'RATE', saleCommissionRate:13, receivedCalcMode:'RATE_AUTO', companyReceivedRate:30});
    add('MIXED auto fills vendor rate from company rate', c.companyReceivedRate===30 && c.vendorReceivedRate===70 && c.companyReceivedAmount===0 && c.vendorReceivedAmount===0, JSON.stringify(c), false);
  } catch(e6) { add('MIXED auto fills vendor rate from company rate', false, String(e6), false); }
  try {
    var d = EV35A_basePolicyFieldData_({paymentOwnerType:'MIXED', settlementPolicyType:'MIXED', boothFee:1000000, saleCommissionRate:13, saleCommissionFixedAmount:50000, unitCommissionAmount:10000, receivedCalcMode:'RATE_AUTO', companyReceivedRate:30, vendorReceivedRate:70});
    add('MIXED keeps combined fee fields', d.boothFee===1000000 && d.saleCommissionRate===13 && d.saleCommissionFixedAmount===50000 && d.unitCommissionAmount===10000, JSON.stringify(d), false);
  } catch(e7) { add('MIXED keeps combined fee fields', false, String(e7), false); }
  var result = { ok:fatal===0, fatal:fatal, warnings:warnings, build:EV35A_BUILD_NAME, label:EV35A_BUILD_NO, checkedAt:new Date().toISOString(), result:{checks:checks, scope:'B35A policy smart UI guard and server normalization only; no final settlement execution'}, errorCode:fatal?'ERP_EVENT_VENDOR_POLICY_SMART_UI_GUARD_FULLCHECK_FAILED':'', meta:{buildNo:EV35A_BUILD_NO, buildName:EV35A_BUILD_NAME} };
  Logger.log('=============================='); Logger.log('[ERP FULL CHECK] erpEventVendorCore_fullCheck_20260502_log'); Logger.log(JSON.stringify(result,null,2)); Logger.log('==============================');
  return result;
}

function erpEventVendorCore_fullCheck_20260502_log() { return EV35A_fullCheck_(); }
function erpB06J36_35A_policySmartUiGuard_fullCheck() { return EV35A_fullCheck_(); }


/**
 * B35B: 결제금액 자동계산/보정 구조 확정 SAFE.
 * - 상품합계는 ACTIVE 상품/품목에서 자동 합산한다.
 * - 고객총결제액은 직접입력이 아니라 상품합계 + 보정액으로 계산한다.
 * - 보정액 입력 시 사유를 필수로 받아 추후 승인/로그 확장 가능 구조를 연다.
 * - 정산 확정/지급/전표 생성은 계속 금지한다.
 */
var EV35B_BUILD_NO = 'v64-B06J36-35B';
var EV35B_BUILD_NAME = 'ERP_B06J36_35B_PAYMENT_AMOUNT_AUTO_GUARD_SAFE';

function EV35B_signedMoney_(v, label){
  var raw = EV34_s_(v).replace(/,/g,'').trim();
  if (raw === '') return 0;
  var n = Number(raw);
  if (isNaN(n)) throw new Error(label + '은(는) 숫자만 입력하세요. 할인/차감은 음수로 입력할 수 있습니다.');
  return Math.round(n);
}
function EV35B_extHeaders_(){
  return [
    'receivedCalcMode','companyReceivedRate','vendorReceivedRate',
    'grossProductAmount','paymentAdjustmentAmount','paymentAdjustmentReason','customerTotalCalcMode','receivedDifferenceAmount'
  ];
}
function EV34_policyHeaders_(){
  return [
    'paymentOwnerType','settlementPolicyType','boothFee','boothFeeBillingType','boothFeeStatus','boothFeePaidAmount','boothFeeBalance',
    'saleCommissionRate','saleCommissionFixedAmount','unitCommissionAmount','unitCommissionBasis',
    'companyReceivedAmount','vendorReceivedAmount','customerTotalPaidAmount','settlementDirection',
    'vendorPayableAmount','vendorReceivableAmount','offsetAmount','settlementNote'
  ].concat(EV35B_extHeaders_());
}
function EV35B_policyFieldData_(payload){
  payload = payload || {};
  var base = EV35A_basePolicyFieldData_(payload);
  var paymentAdjustmentAmount = EV35B_signedMoney_(payload.paymentAdjustmentAmount || payload['보정액'], '결제 보정액');
  var paymentAdjustmentReason = EV34_s_(payload.paymentAdjustmentReason || payload['보정사유']);
  if (paymentAdjustmentAmount !== 0 && !paymentAdjustmentReason) throw new Error('결제 보정액을 입력하면 보정사유가 필요합니다.');
  base.grossProductAmount = 0; // 정책 저장 단계에서는 상품합계를 저장하지 않고 미리보기에서 ACTIVE 상품 기준으로 계산한다.
  base.paymentAdjustmentAmount = paymentAdjustmentAmount;
  base.paymentAdjustmentReason = paymentAdjustmentReason;
  base.customerTotalCalcMode = 'PRODUCT_SUM_PLUS_ADJUSTMENT';
  base.customerTotalPaidAmount = 0; // 직접 입력값 저장 금지. 미리보기에서 상품합계 + 보정액으로 산출한다.
  base.receivedDifferenceAmount = 0;
  return base;
}
function EV34_policyFieldData_(payload){ return EV35B_policyFieldData_(payload || {}); }
function EV35_policyFieldData_(payload){ return EV35B_policyFieldData_(payload || {}); }

function EV35B_customerTotalFromProducts_(policy, gross){
  var adjustment = EV35B_signedMoney_(EV35_policyValue_(policy,'paymentAdjustmentAmount',null,0), '결제 보정액');
  var customerTotal = Math.round(Number(gross || 0) + Number(adjustment || 0));
  if (customerTotal < 0) throw new Error('고객총결제액은 음수가 될 수 없습니다. 상품합계와 보정액을 확인하세요.');
  return { grossProductAmount: Math.round(Number(gross || 0)), paymentAdjustmentAmount: adjustment, customerTotalPaidAmount: customerTotal, customerTotalCalcMode:'PRODUCT_SUM_PLUS_ADJUSTMENT' };
}
function EV35_calcReceived_(policy, gross){
  var paymentOwnerType = EV34_assertPaymentOwnerType_(EV35_policyValue_(policy,'paymentOwnerType',null,'COMPANY_ALL'));
  var mode = EV35_assertReceivedCalcMode_(EV35_policyValue_(policy,'receivedCalcMode',null,'RATE_AUTO'));
  var totalInfo = EV35B_customerTotalFromProducts_(policy, gross);
  var customerTotal = totalInfo.customerTotalPaidAmount;
  var companyRate = EV35_percent_(EV35_policyValue_(policy,'companyReceivedRate',null,0));
  var vendorRate = EV35_percent_(EV35_policyValue_(policy,'vendorReceivedRate',null,0));
  var companyAmount = EV35_num_(EV35_policyValue_(policy,'companyReceivedAmount',null,0));
  var vendorAmount = EV35_num_(EV35_policyValue_(policy,'vendorReceivedAmount',null,0));

  if (mode === 'RATE_AUTO') {
    if (paymentOwnerType === 'COMPANY_ALL') { companyRate = 100; vendorRate = 0; companyAmount = customerTotal; vendorAmount = 0; }
    else if (paymentOwnerType === 'VENDOR_DIRECT') { companyRate = 0; vendorRate = 100; companyAmount = 0; vendorAmount = customerTotal; }
    else {
      if (companyRate <= 0 && vendorRate <= 0) { companyRate = 0; vendorRate = 100; }
      if (companyRate > 0 && vendorRate <= 0) vendorRate = Math.max(0, 100 - companyRate);
      if (vendorRate > 0 && companyRate <= 0) companyRate = Math.max(0, 100 - vendorRate);
      var sum = Number(companyRate || 0) + Number(vendorRate || 0);
      if (Math.round(sum * 100) !== 10000) throw new Error('혼합결제 비율 자동 계산은 당사수취비율 + 업체수취비율이 100%여야 합니다. 현재=' + sum + '%');
      companyAmount = EV35_round_(customerTotal * companyRate / 100);
      vendorAmount = Math.max(0, customerTotal - companyAmount);
    }
  }
  if (mode === 'AMOUNT_MANUAL' || mode === 'PAYMENT_MATCHED') {
    if (paymentOwnerType === 'COMPANY_ALL') { companyAmount = customerTotal; vendorAmount = 0; companyRate = 100; vendorRate = 0; }
    else if (paymentOwnerType === 'VENDOR_DIRECT') { companyAmount = 0; vendorAmount = customerTotal; companyRate = 0; vendorRate = 100; }
    else {
      if (companyAmount <= 0 && vendorAmount <= 0) vendorAmount = customerTotal;
      if (companyRate <= 0 && customerTotal > 0) companyRate = EV35_round_(companyAmount / customerTotal * 10000) / 100;
      if (vendorRate <= 0 && customerTotal > 0) vendorRate = EV35_round_(vendorAmount / customerTotal * 10000) / 100;
    }
  }
  var receivedDifferenceAmount = Math.round(customerTotal - (companyAmount + vendorAmount));
  return {
    paymentOwnerType:paymentOwnerType, receivedCalcMode:mode,
    grossProductAmount:totalInfo.grossProductAmount,
    paymentAdjustmentAmount:totalInfo.paymentAdjustmentAmount,
    customerTotalCalcMode:totalInfo.customerTotalCalcMode,
    customerTotalPaidAmount:customerTotal,
    companyReceivedRate:companyRate, vendorReceivedRate:vendorRate,
    companyReceivedAmount:companyAmount, vendorReceivedAmount:vendorAmount,
    receivedDifferenceAmount:receivedDifferenceAmount
  };
}

// Override EV29_calcPreview_: 고객총결제액 직접입력을 금지하고 상품합계+보정액 기준으로 계산한다.
function EV29_calcPreview_(products, policy) {
  products = products || [];
  policy = policy || {};
  var settlementPolicyType = EV34A_policyTypeForPreview_(policy);
  var flags = EV35_feeComponentFlags_(settlementPolicyType);
  var rate = EV34A_policyPercent_(policy, 'saleCommissionRate', 'commissionRate');
  var boothFee = EV34A_policyMoney_(policy, 'boothFee', 'fixedFee');
  var boothFeePaidAmount = EV35_num_(EV35_policyValue_(policy,'boothFeePaidAmount',null,0));
  var boothFeeBalance = EV35_num_(EV35_policyValue_(policy,'boothFeeBalance',null,Math.max(0, boothFee - boothFeePaidAmount)));
  var boothFeeBillingType = EV34_assertBoothFeeBillingType_(EV35_policyValue_(policy,'boothFeeBillingType',null,'DEDUCT_FROM_SETTLEMENT'));
  var boothFeeStatus = EV34_assertBoothFeeStatus_(EV35_policyValue_(policy,'boothFeeStatus',null,'UNPAID'));
  var saleCommissionFixedAmount = EV34A_policyMoney_(policy, 'saleCommissionFixedAmount', null);
  var unitCommissionAmount = EV34A_policyMoney_(policy, 'unitCommissionAmount', null);
  var unitCommissionBasis = EV34_assertUnitBasis_(EV35_policyValue_(policy,'unitCommissionBasis',null,'PRODUCT_UNIT'));

  var gross = 0, rateFee = 0;
  var rows = products.map(function(p) {
    var price = EV29_money_(p.basePrice || p['basePrice'] || p['기본가']);
    var productRateFee = (!flags.none && flags.rate) ? EV29_round_(price * rate / 100) : 0;
    gross += price;
    rateFee += productRateFee;
    return { productId:EV8_s_(p.productId || p['productId']), productName:EV8_s_(p.productName || p['productName'] || p['상품명']), category:EV8_s_(p.category || p['category'] || p['카테고리']), basePrice:price, rateFee:productRateFee, productStatus:EV8_s_(p.productStatus || p['productStatus']) };
  });

  var saleCount = products.length;
  var unitCount = products.length;
  var boothFeeChargeAmount = (!flags.none && boothFee > 0 && EV35_isChargeableBooth_(boothFeeBillingType, boothFeeStatus)) ? (boothFeeBalance > 0 ? boothFeeBalance : Math.max(0, boothFee - boothFeePaidAmount)) : 0;
  if (settlementPolicyType === 'BOOTH_ONLY') rateFee = 0;
  var fixedSaleCommission = (!flags.none && flags.fixedSale) ? EV29_round_(saleCount * saleCommissionFixedAmount) : 0;
  var unitCommission = (!flags.none && flags.unit) ? EV29_round_(unitCount * unitCommissionAmount) : 0;
  var feelhausChargeAmount = EV29_round_(boothFeeChargeAmount + rateFee + fixedSaleCommission + unitCommission);
  var received = EV35_calcReceived_(policy, gross);
  var direction = 'NO_ACTION', vendorPayable = 0, vendorReceivable = 0, offsetAmount = 0;

  if (received.paymentOwnerType === 'COMPANY_ALL') {
    vendorPayable = Math.max(0, received.companyReceivedAmount - feelhausChargeAmount);
    vendorReceivable = Math.max(0, feelhausChargeAmount - received.companyReceivedAmount);
  } else if (received.paymentOwnerType === 'VENDOR_DIRECT') {
    vendorReceivable = Math.max(0, feelhausChargeAmount - received.companyReceivedAmount);
    vendorPayable = 0;
  } else {
    var delta = received.companyReceivedAmount - feelhausChargeAmount;
    if (delta > 0) vendorPayable = delta;
    else if (delta < 0) vendorReceivable = Math.abs(delta);
  }
  if (vendorPayable > 0 && vendorReceivable > 0) { offsetAmount = Math.min(vendorPayable, vendorReceivable); vendorPayable -= offsetAmount; vendorReceivable -= offsetAmount; direction = 'OFFSET'; }
  else if (vendorPayable > 0) direction = 'PAY_TO_VENDOR';
  else if (vendorReceivable > 0) direction = 'COLLECT_FROM_VENDOR';
  else direction = 'NO_ACTION';

  return {
    settlementType:settlementPolicyType, settlementPolicyType:settlementPolicyType,
    paymentOwnerType:received.paymentOwnerType, receivedCalcMode:received.receivedCalcMode,
    grossProductAmount:received.grossProductAmount,
    paymentAdjustmentAmount:received.paymentAdjustmentAmount,
    customerTotalCalcMode:received.customerTotalCalcMode,
    receivedDifferenceAmount:received.receivedDifferenceAmount,
    companyReceivedRate:received.companyReceivedRate, vendorReceivedRate:received.vendorReceivedRate,
    commissionRate:rate, saleCommissionRate:rate, fixedFee:boothFee, boothFee:boothFee,
    boothFeeBillingType:boothFeeBillingType, boothFeeStatus:boothFeeStatus, boothFeePaidAmount:boothFeePaidAmount, boothFeeBalance:boothFeeBalance,
    saleCommissionFixedAmount:saleCommissionFixedAmount, unitCommissionAmount:unitCommissionAmount, unitCommissionBasis:unitCommissionBasis,
    productCount:products.length, saleCount:saleCount, unitCount:unitCount,
    grossAmount:gross, customerTotalPaidAmount:received.customerTotalPaidAmount,
    companyReceivedAmount:received.companyReceivedAmount, vendorReceivedAmount:received.vendorReceivedAmount,
    rateFee:rateFee, rateCommission:rateFee, boothFeeApplied:boothFeeChargeAmount, boothFeeChargeAmount:boothFeeChargeAmount,
    fixedFeeApplied:boothFeeChargeAmount, fixedSaleCommission:fixedSaleCommission, unitCommission:unitCommission,
    totalFee:feelhausChargeAmount, totalCommission:feelhausChargeAmount, feelhausChargeAmount:feelhausChargeAmount,
    settlementDirection:direction, vendorPayableAmount:vendorPayable, vendorReceivableAmount:vendorReceivable, offsetAmount:offsetAmount,
    vendorExpectedAmount:vendorPayable, rows:rows
  };
}

// Header extension plan/apply: B35B 확장 필드가 없으면 백업 후 추가한다.
function EV35B_headerPlan_(){
  var ss = EV33_ss_();
  var linkSh = ss.getSheetByName('ERP_행사업체연결');
  var policySh = ss.getSheetByName('ERP_행사업체정산정책');
  var ext = EV35B_extHeaders_();
  function plan(sh){
    var headers = EV33_getHeaders_(sh);
    var missing = ext.filter(function(h){ return headers.indexOf(h) < 0; });
    return { sheetName:sh.getName(), lastCol:sh.getLastColumn(), missing:missing, duplicatePositions:EV33_duplicatePositions_(headers), canApply:Object.keys(EV33_duplicatePositions_(headers)).length===0, headers:headers };
  }
  return { ok:true, build:EV35B_BUILD_NAME, label:EV35B_BUILD_NO, linkPlan:plan(linkSh), policyPlan:plan(policySh), backupRequired:true, writeExecuted:false };
}
function EV35B_applyHeadersConfirmed_(){
  var ss = EV33_ss_();
  var plan = EV35B_headerPlan_();
  if (!plan.linkPlan.canApply || !plan.policyPlan.canApply) throw new Error('B35B 확장 헤더 적용 전 중복 헤더가 있습니다.');
  var linkSh = ss.getSheetByName('ERP_행사업체연결');
  var policySh = ss.getSheetByName('ERP_행사업체정산정책');
  var backups = { link:EV33_makeBackup_(ss,'ERP_행사업체연결'), policy:EV33_makeBackup_(ss,'ERP_행사업체정산정책') };
  function append(sh, missing){ if (missing.length) sh.getRange(1, sh.getLastColumn()+1, 1, missing.length).setValues([missing]); }
  append(linkSh, plan.linkPlan.missing);
  append(policySh, plan.policyPlan.missing);
  var post = EV35B_headerPlan_();
  return { ok:true, applied:true, writeExecuted:true, build:EV35B_BUILD_NAME, label:EV35B_BUILD_NO, backups:backups, linkApplied:plan.linkPlan.missing, policyApplied:plan.policyPlan.missing, postProbe:post, message:'B35B 확장 헤더 추가 완료', checkedAt:new Date().toISOString() };
}
function erpB06J36_35B_paymentAmountAutoGuard_confirmed(){ var r = EV35B_applyHeadersConfirmed_(); Logger.log('=============================='); Logger.log('[ERP B35B HEADER APPLY] erpB06J36_35B_paymentAmountAutoGuard_confirmed'); Logger.log(JSON.stringify(r,null,2)); Logger.log('=============================='); return r; }

function EV35B_fullCheck_(){
  var checks = [], fatal = 0, warnings = [];
  function add(name, ok, detail, warnOnly){ if(!ok && warnOnly) warnings.push(name + ': ' + (detail||'')); if(!ok && !warnOnly) fatal++; checks.push({name:name, ok:!!ok, detail:detail||'', warnOnly:!!warnOnly}); }
  try { add('event/vendor functions still exist', typeof getEventVendorBootstrap === 'function' && typeof saveEventVendorLink === 'function' && typeof searchEventVendorData === 'function', '기존 행사/업체/연결 함수 보존', false); } catch(e1) { add('event/vendor functions still exist', false, String(e1), false); }
  try { add('product/policy/preview functions still exist', typeof saveEventVendorProduct === 'function' && typeof saveEventVendorSettlementPolicy === 'function' && typeof previewEventVendorSettlement === 'function', '상품/정책/미리보기 함수 보존', false); } catch(e2) { add('product/policy/preview functions still exist', false, String(e2), false); }
  try { var hp = EV35B_headerPlan_(); add('B35B extension header plan ready', hp.linkPlan.canApply && hp.policyPlan.canApply, JSON.stringify({linkMissing:hp.linkPlan.missing, policyMissing:hp.policyPlan.missing}), false); } catch(e3) { add('B35B extension header plan ready', false, String(e3), false); }
  try { var html = HtmlService.createHtmlOutputFromFile('EventVendor').getContent(); add('UI has product sum and adjustment fields', html.indexOf('grossProductAmount')>=0 && html.indexOf('paymentAdjustmentAmount')>=0 && html.indexOf('paymentAdjustmentReason')>=0, '상품합계/보정액/보정사유 UI', false); add('UI locks customer total field', html.indexOf('customerTotalPaidAmount')>=0 && html.indexOf('readonly')>=0 && html.indexOf('고객총결제액')>=0, '고객총결제액 직접입력 잠금', false); } catch(e4) { add('UI auto amount guard check', false, String(e4), false); }
  try { var p = EV35B_policyFieldData_({paymentOwnerType:'MIXED', settlementPolicyType:'RATE', saleCommissionRate:10, receivedCalcMode:'RATE_AUTO', companyReceivedRate:30, paymentAdjustmentAmount:'-50,000', paymentAdjustmentReason:'할인'}); add('policy parser supports adjustment reason', p.paymentAdjustmentAmount===-50000 && p.paymentAdjustmentReason==='할인' && p.customerTotalPaidAmount===0, JSON.stringify(p), false); } catch(e5) { add('policy parser supports adjustment reason', false, String(e5), false); }
  try { var c = EV29_calcPreview_([{productId:'P1',productName:'A',basePrice:100000},{productId:'P2',productName:'B',basePrice:200000}], {paymentOwnerType:'MIXED', settlementPolicyType:'RATE', saleCommissionRate:10, receivedCalcMode:'RATE_AUTO', companyReceivedRate:30, paymentAdjustmentAmount:-50000}); add('preview auto totals multiple products plus adjustment', c.grossProductAmount===300000 && c.customerTotalPaidAmount===250000 && c.companyReceivedAmount===75000 && c.vendorReceivedAmount===175000, JSON.stringify(c), false); } catch(e6) { add('preview auto totals multiple products plus adjustment', false, String(e6), false); }
  try { var thrown = false; try { EV35B_policyFieldData_({paymentOwnerType:'MIXED', settlementPolicyType:'RATE', saleCommissionRate:10, paymentAdjustmentAmount:'-5000'}); } catch(ee) { thrown = String(ee.message||ee).indexOf('보정사유') >= 0; } add('adjustment requires reason', thrown, '보정액 입력 시 사유 필수', false); } catch(e7) { add('adjustment requires reason', false, String(e7), false); }
  var result = { ok:fatal===0, fatal:fatal, warnings:warnings, build:EV35B_BUILD_NAME, label:EV35B_BUILD_NO, checkedAt:new Date().toISOString(), result:{checks:checks, scope:'B35B payment amount auto guard only; no final settlement execution'}, errorCode:fatal?'ERP_PAYMENT_AMOUNT_AUTO_GUARD_FULLCHECK_FAILED':'', meta:{buildNo:EV35B_BUILD_NO, buildName:EV35B_BUILD_NAME} };
  Logger.log('=============================='); Logger.log('[ERP FULL CHECK] erpEventVendorCore_fullCheck_20260502_log'); Logger.log(JSON.stringify(result,null,2)); Logger.log('==============================');
  return result;
}
function erpB06J36_35B_paymentAmountAutoGuard_fullCheck(){ return EV35B_fullCheck_(); }
function erpEventVendorCore_fullCheck_20260502_log(){ return EV35B_fullCheck_(); }
