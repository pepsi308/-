@echo off
setlocal EnableExtensions
title FEELHAUS UPLOAD ERP SAFE

cd /d "%~dp0"

if not exist ".clasp.json" (
  echo [ERROR] .clasp.json not found in current ERP folder.
  echo Current folder:
  cd
  pause
  exit /b 1
)

echo ==========================================
echo ERP upload start - SAFE CURRENT FOLDER
echo Current folder:
cd
echo.
echo [1] clasp status before push
clasp.cmd status
echo.
echo [2] push --force
clasp.cmd push --force
set RC=%ERRORLEVEL%

echo.
echo ==========================================
if %RC%==0 (
  echo [OK] ERP upload complete
) else (
  echo [ERROR] ERP upload failed
  echo ERRORLEVEL=%RC%
)
echo ==========================================
echo.
pause
exit /b %RC%
