function fhRunConfigPreflight_(projectCode) {
  var map = FH_CFG.dump();
  var out = [];
  function push(level, key, msg) { out.push([level, key, msg]); }
  var required = ['FEELHAUS_SETUP_DB_ID', 'FEELHAUS_DB_MASTER_ID', 'CONFIG_SHEET_NAME'];
  if (String(projectCode || '').toUpperCase() === 'SIGN') required.push('SIGN_SPREADSHEET_ID');
  required.forEach(function (k) {
    if (!FH_CFG.get(k, '')) push('CRITICAL', k, '필수키 누락');
  });

  [
    ['ROOT_FOLDER_ID','ROOT_FOLDER_URL'],
    ['PDF_FOLDER_ID','PDF_FOLDER_URL'],
    ['BACKUP_FOLDER_ID','BACKUP_FOLDER_URL'],
    ['BACKUP_DB_FOLDER_ID','BACKUP_DB_FOLDER_URL'],
    ['BACKUP_ERP_FOLDER_ID','BACKUP_ERP_FOLDER_URL'],
    ['BACKUP_PORTAL_FOLDER_ID','BACKUP_PORTAL_FOLDER_URL'],
    ['BACKUP_SIGN_FOLDER_ID','BACKUP_SIGN_FOLDER_URL'],
    ['LOG_CHECK_FOLDER_ID','LOG_CHECK_FOLDER_URL'],
    ['LOG_ERROR_FOLDER_ID','LOG_ERROR_FOLDER_URL'],
    ['LOG_DEBUG_FOLDER_ID','LOG_DEBUG_FOLDER_URL'],
    ['LOG_REPORT_FOLDER_ID','LOG_REPORT_FOLDER_URL']
  ].forEach(function(pair){
    var id = map[pair[0]];
    var url = map[pair[1]];
    if (id && url && String(url).indexOf(String(id)) === -1) {
      push('CRITICAL', pair[0], 'ID/URL 불일치: ' + pair[1]);
    }
  });

  if (map.DB_MASTER_ID && map.SPREADSHEET_ID && String(map.DB_MASTER_ID) !== String(map.SPREADSHEET_ID)) {
    push('CRITICAL', 'DB_MASTER_ID', 'SPREADSHEET_ID와 값 충돌');
  }
  if (map.SIGN_DB_ID && map.SIGN_SPREADSHEET_ID && String(map.SIGN_DB_ID) !== String(map.SIGN_SPREADSHEET_ID)) {
    push('CRITICAL', 'SIGN_SPREADSHEET_ID', 'SIGN_DB_ID와 값 충돌');
  }
  if (map.ADMIN_PASSWORD) push('WARNING', 'ADMIN_PASSWORD', '평문 비밀번호 저장 지양');
  if (map.SIGN_ADMIN_PASSWORD) push('WARNING', 'SIGN_ADMIN_PASSWORD', '평문 비밀번호 저장 지양');

  if (!out.length) out.push(['PASS', String(projectCode || 'ALL'), '설정 점검 통과']);
  Logger.log(JSON.stringify(out));
  return out;
}
function runPreflightErp() {
  return fhRunConfigPreflight_('ERP');
}