/**
 * FEELHAUS ERP v64-B06J36-36A
 * ERP_B06J36_36A_SETTLEMENT_ADJUSTMENT_CORE_FILE_FIX_SAFE
 * Scope: Settlement adjustment core only. No final settlement/payment/voucher execution.
 * File fix: proper FULL package includes latest integrated ERP files + this module.
 */
var ERP_B06J36_36A_BUILD_NO = 'v64-B06J36-36A';
var ERP_B06J36_36A_BUILD_NAME = 'ERP_B06J36_36A_SETTLEMENT_ADJUSTMENT_CORE_FILE_FIX_SAFE';

function erpB06J36_36A_settlementAdjustmentCore_fullCheck() {
  var out = { ok: false, fatal: 0, warnings: [], build: ERP_B06J36_36A_BUILD_NAME, label: ERP_B06J36_36A_BUILD_NO, checkedAt: new Date().toISOString(), result: { checks: [] }, errorCode: '', meta: { buildNo: ERP_B06J36_36A_BUILD_NO, buildName: ERP_B06J36_36A_BUILD_NAME } };
  function add(name, ok, detail, warnOnly) {
    if (!ok && !warnOnly) out.fatal++;
    if (!ok && warnOnly) out.warnings.push(name + ': ' + String(detail || ''));
    out.result.checks.push({ name: name, ok: !!ok, detail: detail || '', warnOnly: !!warnOnly });
  }
  try {
    var ss = EV36A_getSpreadsheet_();
    add('spreadsheet connected', !!ss, 'FEELHAUS_DB_MASTER or active spreadsheet', false);
    add('B35B baseline function exists', typeof erpB06J36_35B_paymentAmountAutoGuard_fullCheck === 'function', 'B35B 기준 함수 보존', true);
    add('event/vendor representative function exists', typeof erpEventVendorCore_fullCheck_20260502_log === 'function', '대표 fullCheck 보존', true);

    var sheetPlan = EV36A_planAdjustmentSheet_();
    add('adjustment sheet plan ready', !!sheetPlan.ok, JSON.stringify({ exists: sheetPlan.exists, missing: sheetPlan.missing, duplicatePositions: sheetPlan.duplicatePositions }), false);
    add('adjustment required headers defined', EV36A_REQUIRED_HEADERS.length >= 20, EV36A_REQUIRED_HEADERS.join('|'), false);
    add('adjustment type code set complete', EV36A_ADJUSTMENT_TYPES.length === 9, EV36A_ADJUSTMENT_TYPES.join('|'), false);
    add('approval status code set complete', EV36A_APPROVAL_STATUS.length === 5, EV36A_APPROVAL_STATUS.join('|'), false);
    add('approved only rule exists', EV36A_isApprovedAdjustment_({ approvalStatus: 'APPROVED' }) === true && EV36A_isApprovedAdjustment_({ approvalStatus: 'REQUESTED' }) === false, 'APPROVED only can affect final settlement', false);
    add('amount requires reason self test', EV36A_validateAdjustmentPayload_({ amount: 1000, reason: '' }).ok === false && EV36A_validateAdjustmentPayload_({ amount: 1000, reason: '테스트' }).ok === true, 'amount reason required', false);
    add('invalid adjustment type blocked', EV36A_validateAdjustmentPayload_({ adjustmentType: 'BAD', amount: 1000, reason: 'x' }).ok === false, 'invalid type blocked', false);
    add('requested create function exists', typeof EV36A_createAdjustmentRequest === 'function', '조정 요청 생성 함수', false);
    add('preview-only guard exists', true, 'no final settlement/payment/voucher execution', false);

    out.result.plan = sheetPlan;
    out.result.scope = 'settlement adjustment core only; no settlement execution';
    out.ok = out.fatal === 0;
    if (!out.ok) out.errorCode = 'ERP_B36A_ADJUSTMENT_CORE_FULLCHECK_FAILED';
  } catch (err) {
    out.ok = false;
    out.fatal++;
    out.errorCode = 'ERP_B36A_ADJUSTMENT_CORE_EXCEPTION';
    out.error = err && err.stack ? err.stack : String(err);
  }
  Logger.log('==============================');
  Logger.log('[ERP FULL CHECK] erpB06J36_36A_settlementAdjustmentCore_fullCheck');
  Logger.log(JSON.stringify(out, null, 2));
  Logger.log('==============================');
  return out;
}

function erpB06J36_36A_settlementAdjustmentCore_confirmed() {
  var ss = EV36A_getSpreadsheet_();
  var backup = null;
  var sheet = ss.getSheetByName(EV36A_SHEET_NAME);
  if (sheet) backup = EV36A_backupSheet_(ss, sheet, 'BACKUP_정산조정내역_B36A_');
  if (!sheet) sheet = ss.insertSheet(EV36A_SHEET_NAME);
  EV36A_ensureHeaders_(sheet, EV36A_REQUIRED_HEADERS);
  var out = {
    ok: true,
    applied: true,
    writeExecuted: true,
    build: ERP_B06J36_36A_BUILD_NAME,
    label: ERP_B06J36_36A_BUILD_NO,
    backup: backup,
    sheetName: EV36A_SHEET_NAME,
    headers: EV36A_getHeaders_(sheet),
    message: 'ERP_정산조정내역 시트/헤더 준비 완료. 정산 확정/지급/전표 생성은 실행하지 않았습니다.',
    checkedAt: new Date().toISOString()
  };
  Logger.log('==============================');
  Logger.log('[ERP B36A ADJUSTMENT APPLY] erpB06J36_36A_settlementAdjustmentCore_confirmed');
  Logger.log(JSON.stringify(out, null, 2));
  Logger.log('==============================');
  return out;
}

function erpB06J36_36A_settlementAdjustmentCore_preview() {
  var out = EV36A_planAdjustmentSheet_();
  Logger.log(JSON.stringify(out, null, 2));
  return out;
}

function EV36A_planAdjustmentSheet_() {
  var ss = EV36A_getSpreadsheet_();
  var sheet = ss.getSheetByName(EV36A_SHEET_NAME);
  var headers = sheet ? EV36A_getHeaders_(sheet) : [];
  var missing = EV36A_REQUIRED_HEADERS.filter(function(h){ return headers.indexOf(h) < 0; });
  var duplicatePositions = EV36A_duplicatePositions_(headers);
  return {
    ok: Object.keys(duplicatePositions).length === 0,
    sheetName: EV36A_SHEET_NAME,
    exists: !!sheet,
    lastRow: sheet ? sheet.getLastRow() : 0,
    lastCol: sheet ? sheet.getLastColumn() : 0,
    headers: headers,
    missing: missing,
    duplicatePositions: duplicatePositions,
    requiredHeaders: EV36A_REQUIRED_HEADERS,
    writeExecuted: false,
    applyRequired: missing.length > 0 || !sheet,
    note: '비파괴 계획입니다. confirmed 함수 실행 전에는 시트에 쓰지 않습니다.'
  };
}

function EV36A_validateAdjustmentPayload_(data) {
  data = data || {};
  var type = EV36A_s_(data.adjustmentType || 'MANUAL_ADDITION');
  var amount = EV36A_n_(data.amount);
  var reason = EV36A_s_(data.reason);
  if (EV36A_ADJUSTMENT_TYPES.indexOf(type) < 0) return { ok: false, errorCode: 'INVALID_ADJUSTMENT_TYPE' };
  if (amount !== 0 && !reason) return { ok: false, errorCode: 'REASON_REQUIRED_FOR_AMOUNT' };
  return { ok: true, adjustmentType: type, amount: amount, reason: reason };
}

function EV36A_isApprovedAdjustment_(row) {
  return EV36A_s_(row && row.approvalStatus) === 'APPROVED';
}

function EV36A_createAdjustmentRequest(data) {
  data = data || {};
  var v = EV36A_validateAdjustmentPayload_(data);
  if (!v.ok) throw new Error(v.errorCode);
  var ss = EV36A_getSpreadsheet_();
  var sheet = ss.getSheetByName(EV36A_SHEET_NAME) || ss.insertSheet(EV36A_SHEET_NAME);
  EV36A_ensureHeaders_(sheet, EV36A_REQUIRED_HEADERS);
  var headers = EV36A_getHeaders_(sheet);
  var map = EV36A_headerMap_(headers);
  var now = EV36A_now_();
  var row = new Array(headers.length).fill('');
  function set(h, val) { if (map[h] != null) row[map[h]] = val; }
  set('adjustmentId', 'ADJ-' + Utilities.formatDate(new Date(), Session.getScriptTimeZone() || 'Asia/Seoul', 'yyyyMMddHHmmss') + '-' + Math.floor(Math.random() * 900 + 100));
  set('eventVendorId', EV36A_s_(data.eventVendorId));
  set('settlementId', EV36A_s_(data.settlementId));
  set('previewId', EV36A_s_(data.previewId));
  set('policyId', EV36A_s_(data.policyId));
  set('adjustmentType', v.adjustmentType);
  set('amount', v.amount);
  set('reason', v.reason);
  set('approvalStatus', 'REQUESTED');
  set('requestedBy', EV36A_user_());
  set('requestedAt', now);
  set('createdAt', now);
  set('createdBy', EV36A_user_());
  set('updatedAt', now);
  set('updatedBy', EV36A_user_());
  sheet.appendRow(row);
  return { ok: true, adjustmentId: row[map.adjustmentId], approvalStatus: 'REQUESTED', finalSettlementExecuted: false };
}

var EV36A_SHEET_NAME = 'ERP_정산조정내역';
var EV36A_REQUIRED_HEADERS = [
  'adjustmentId','eventVendorId','settlementId','previewId','policyId','adjustmentType','amount','reason','approvalStatus','requestedBy','requestedAt','approvedBy','approvedAt','rejectedBy','rejectedAt','appliedToPreview','appliedToSettlement','sourceType','sourceId','memo','createdAt','createdBy','updatedAt','updatedBy'
];
var EV36A_ADJUSTMENT_TYPES = ['DISCOUNT','EXTRA_CHARGE','POLICY_COMPENSATION','MANUAL_DEDUCTION','MANUAL_ADDITION','ROUNDING_ADJUSTMENT','GIFT_ADJUSTMENT','CANCEL_ADJUSTMENT','INSTALL_COST_ADJUSTMENT'];
var EV36A_APPROVAL_STATUS = ['DRAFT','REQUESTED','APPROVED','REJECTED','CANCELED'];

function EV36A_getSpreadsheet_() {
  var props = PropertiesService.getScriptProperties();
  var id = props.getProperty('DB_SPREADSHEET_ID') || props.getProperty('SPREADSHEET_ID') || props.getProperty('MASTER_DB_ID');
  if (id) return SpreadsheetApp.openById(id);
  return SpreadsheetApp.getActiveSpreadsheet();
}
function EV36A_getHeaders_(sheet) {
  if (!sheet || sheet.getLastColumn() < 1) return [];
  return sheet.getRange(1,1,1,sheet.getLastColumn()).getValues()[0].map(function(v){ return EV36A_s_(v); });
}
function EV36A_ensureHeaders_(sheet, required) {
  var headers = EV36A_getHeaders_(sheet);
  if (headers.length === 0) { sheet.getRange(1,1,1,required.length).setValues([required]); return; }
  var missing = required.filter(function(h){ return headers.indexOf(h) < 0; });
  if (missing.length) sheet.getRange(1, headers.length + 1, 1, missing.length).setValues([missing]);
}
function EV36A_headerMap_(headers) { var m={}; headers.forEach(function(h,i){ if(h && m[h] == null) m[h]=i; }); return m; }
function EV36A_duplicatePositions_(headers) { var seen={}, dup={}; headers.forEach(function(h,i){ if(!h) return; if(!seen[h]) seen[h]=[]; seen[h].push(i+1); }); Object.keys(seen).forEach(function(h){ if(seen[h].length>1) dup[h]=seen[h]; }); return dup; }
function EV36A_backupSheet_(ss, sheet, prefix) { var name = prefix + Utilities.formatDate(new Date(), Session.getScriptTimeZone() || 'Asia/Seoul', 'yyyyMMdd_HHmmss'); var cp = sheet.copyTo(ss).setName(name); return { backupSheetName: name, backupSheetId: cp.getSheetId() }; }
function EV36A_s_(v) { return String(v == null ? '' : v).trim(); }
function EV36A_n_(v) { var s = EV36A_s_(v).replace(/,/g, ''); var n = Number(s || 0); return isFinite(n) ? n : 0; }
function EV36A_now_() { return Utilities.formatDate(new Date(), Session.getScriptTimeZone() || 'Asia/Seoul', 'yyyy-MM-dd HH:mm:ss'); }
function EV36A_user_() { try { return Session.getActiveUser().getEmail() || 'system'; } catch(e) { return 'system'; } }


/**
 * FEELHAUS ERP v64-B06J36-36B
 * ERP_B06J36_36B_SETTLEMENT_ADJUSTMENT_UI_REQUEST_SAFE
 * Scope: Adjustment list/request UI only. No final settlement/payment/voucher execution.
 * B36A1 visibility wrappers are absorbed here so the temporary wrapper file can be removed.
 */
var ERP_B06J36_36A1_BUILD_NO = 'v64-B06J36-36A1';
var ERP_B06J36_36A1_BUILD_NAME = 'ERP_B06J36_36A1_SETTLEMENT_ADJUSTMENT_FUNCTION_VISIBLE_SAFE';
var ERP_B06J36_36B_BUILD_NO = 'v64-B06J36-36B';
var ERP_B06J36_36B_BUILD_NAME = 'ERP_B06J36_36B_SETTLEMENT_ADJUSTMENT_UI_REQUEST_SAFE';

function erpB06J36_36A1_fullCheck() { return erpB06J36_36A_settlementAdjustmentCore_fullCheck(); }
function erpB06J36_36A1_confirmed() { return erpB06J36_36A_settlementAdjustmentCore_confirmed(); }
function erpB06J36_36A1_preview() { return erpB06J36_36A_settlementAdjustmentCore_preview(); }
function erpB06J36_36A1_functionVisibleCheck() {
  var result = {
    ok: true,
    build: ERP_B06J36_36A1_BUILD_NAME,
    label: ERP_B06J36_36A1_BUILD_NO,
    checkedAt: new Date().toISOString(),
    functions: {
      fullCheck: typeof erpB06J36_36A_settlementAdjustmentCore_fullCheck === 'function',
      confirmed: typeof erpB06J36_36A_settlementAdjustmentCore_confirmed === 'function',
      preview: typeof erpB06J36_36A_settlementAdjustmentCore_preview === 'function',
      requestCreate: typeof EV36A_createAdjustmentRequest === 'function'
    },
    scope: 'absorbed wrapper/visibility only; no final settlement/payment/voucher execution'
  };
  result.ok = result.functions.fullCheck && result.functions.confirmed && result.functions.preview && result.functions.requestCreate;
  Logger.log('==============================');
  Logger.log('[ERP B36A1 FUNCTION VISIBLE CHECK] ' + ERP_B06J36_36A1_BUILD_NAME);
  Logger.log(JSON.stringify(result, null, 2));
  Logger.log('==============================');
  return result;
}

function erpB06J36_36B_adjustmentUi_fullCheck() {
  var out = { ok: false, fatal: 0, warnings: [], build: ERP_B06J36_36B_BUILD_NAME, label: ERP_B06J36_36B_BUILD_NO, checkedAt: new Date().toISOString(), result: { checks: [] }, errorCode: '' };
  function add(name, ok, detail, warnOnly) {
    if (!ok && !warnOnly) out.fatal++;
    if (!ok && warnOnly) out.warnings.push(name + ': ' + String(detail || ''));
    out.result.checks.push({ name: name, ok: !!ok, detail: detail || '', warnOnly: !!warnOnly });
  }
  try {
    var core = erpB06J36_36A_settlementAdjustmentCore_fullCheck();
    add('B36A core fullCheck ok', !!(core && core.ok), core && core.errorCode ? core.errorCode : 'B36A 조정내역 CORE 기준 통과 필요', false);
    add('B36A1 wrapper absorbed', typeof erpB06J36_36A1_functionVisibleCheck === 'function' && typeof erpB06J36_36A1_fullCheck === 'function', '임시 래퍼 파일 제거 후 EV36_Adjust 안에 흡수', false);
    add('adjustment list function exists', typeof erpB06J36_36B_listAdjustments === 'function', '조회 함수', false);
    add('adjustment UI data function exists', typeof erpB06J36_36B_getUiData === 'function', 'UI 데이터 함수', false);
    add('adjustment request wrapper exists', typeof erpB06J36_36B_createAdjustmentRequest === 'function', 'REQUESTED 생성 래퍼', false);
    add('reason required guard', EV36A_validateAdjustmentPayload_({ adjustmentType: 'MANUAL_ADDITION', amount: 1, reason: '' }).ok === false, '금액 입력 시 사유 필수', false);
    add('invalid type blocked guard', EV36A_validateAdjustmentPayload_({ adjustmentType: 'BAD', amount: 1, reason: 'x' }).ok === false, '허용 조정유형만 저장 가능', false);
    add('requested only create guard', erpB06J36_36B_previewCreateAdjustmentRequest_({ adjustmentType: 'MANUAL_ADDITION', amount: 1, reason: 'x' }).approvalStatus === 'REQUESTED', '조정 요청은 REQUESTED 상태만 생성', false);
    add('preview-only/final execution blocked', true, 'no final settlement/payment/voucher execution', false);
    out.result.sheet = EV36A_planAdjustmentSheet_();
    out.result.types = EV36A_ADJUSTMENT_TYPES;
    out.result.statuses = EV36A_APPROVAL_STATUS;
    out.result.scope = 'list/request UI only; no settlement execution';
    out.ok = out.fatal === 0;
    if (!out.ok) out.errorCode = 'ERP_B36B_ADJUSTMENT_UI_FULLCHECK_FAILED';
  } catch (err) {
    out.ok = false;
    out.fatal++;
    out.errorCode = 'ERP_B36B_ADJUSTMENT_UI_EXCEPTION';
    out.error = err && err.stack ? err.stack : String(err);
  }
  Logger.log('==============================');
  Logger.log('[ERP B36B ADJUSTMENT UI FULL CHECK] ' + ERP_B06J36_36B_BUILD_NAME);
  Logger.log(JSON.stringify(out, null, 2));
  Logger.log('==============================');
  return out;
}

function erpB06J36_36B_confirmed() {
  var core = erpB06J36_36A_settlementAdjustmentCore_confirmed();
  var out = {
    ok: !!(core && core.ok),
    applied: !!(core && core.applied),
    writeExecuted: !!(core && core.writeExecuted),
    build: ERP_B06J36_36B_BUILD_NAME,
    label: ERP_B06J36_36B_BUILD_NO,
    core: core,
    message: 'B36B 조정내역 조회/요청 UI 기준 준비 완료. 정산 확정/지급/전표 생성은 실행하지 않았습니다.',
    checkedAt: new Date().toISOString()
  };
  Logger.log('==============================');
  Logger.log('[ERP B36B ADJUSTMENT UI CONFIRMED] ' + ERP_B06J36_36B_BUILD_NAME);
  Logger.log(JSON.stringify(out, null, 2));
  Logger.log('==============================');
  return out;
}

function erpB06J36_36B_getUiData(limit) {
  return {
    ok: true,
    build: ERP_B06J36_36B_BUILD_NAME,
    label: ERP_B06J36_36B_BUILD_NO,
    sheetPlan: EV36A_planAdjustmentSheet_(),
    adjustmentTypes: EV36A_ADJUSTMENT_TYPES.slice(),
    approvalStatuses: EV36A_APPROVAL_STATUS.slice(),
    rows: erpB06J36_36B_listAdjustments({ limit: limit || 50 }).rows,
    scope: 'REQUESTED 조정요청 생성/조회 전용. 정산 확정/지급/전표 생성 없음.'
  };
}

function erpB06J36_36B_listAdjustments(filter) {
  filter = filter || {};
  var ss = EV36A_getSpreadsheet_();
  var sheet = ss.getSheetByName(EV36A_SHEET_NAME);
  if (!sheet) return { ok: true, rows: [], total: 0, sheetName: EV36A_SHEET_NAME, note: '조정내역 시트가 아직 없습니다.' };
  EV36A_ensureHeaders_(sheet, EV36A_REQUIRED_HEADERS);
  var headers = EV36A_getHeaders_(sheet);
  var map = EV36A_headerMap_(headers);
  var last = sheet.getLastRow();
  if (last < 2) return { ok: true, rows: [], total: 0, sheetName: EV36A_SHEET_NAME };
  var values = sheet.getRange(2, 1, last - 1, headers.length).getValues();
  var q = EV36A_s_(filter.query).toLowerCase();
  var status = EV36A_s_(filter.approvalStatus);
  var eventVendorId = EV36A_s_(filter.eventVendorId);
  var limit = Math.max(1, Math.min(Number(filter.limit || 100), 500));
  var rows = [];
  values.forEach(function(row, idx) {
    var obj = { _row: idx + 2 };
    headers.forEach(function(h, i) { if (h) obj[h] = row[i]; });
    if (status && EV36A_s_(obj.approvalStatus) !== status) return;
    if (eventVendorId && EV36A_s_(obj.eventVendorId) !== eventVendorId) return;
    if (q) {
      var hay = [obj.adjustmentId, obj.eventVendorId, obj.settlementId, obj.previewId, obj.policyId, obj.adjustmentType, obj.amount, obj.reason, obj.approvalStatus, obj.sourceType, obj.sourceId, obj.memo].join(' ').toLowerCase();
      if (hay.indexOf(q) < 0) return;
    }
    rows.push(obj);
  });
  rows.sort(function(a, b) { return EV36A_s_(b.createdAt || b.requestedAt).localeCompare(EV36A_s_(a.createdAt || a.requestedAt)); });
  return { ok: true, rows: rows.slice(0, limit), total: rows.length, sheetName: EV36A_SHEET_NAME, headers: headers };
}

function erpB06J36_36B_createAdjustmentRequest(data) {
  data = data || {};
  data.approvalStatus = 'REQUESTED';
  var out = EV36A_createAdjustmentRequest(data);
  out.build = ERP_B06J36_36B_BUILD_NAME;
  out.label = ERP_B06J36_36B_BUILD_NO;
  out.message = '조정요청이 REQUESTED 상태로 생성되었습니다. 정산 확정/지급/전표 생성은 실행하지 않았습니다.';
  out.finalSettlementExecuted = false;
  return out;
}

function erpB06J36_36B_previewCreateAdjustmentRequest_(data) {
  data = data || {};
  var v = EV36A_validateAdjustmentPayload_(data);
  if (!v.ok) return { ok: false, errorCode: v.errorCode };
  return { ok: true, adjustmentType: v.adjustmentType, amount: v.amount, reason: v.reason, approvalStatus: 'REQUESTED', finalSettlementExecuted: false };
}


/**
 * FEELHAUS ERP v64-B06J36-37
 * ERP_B06J36_37_ADJUSTED_PREVIEW_SAFE
 * Scope: Approved settlement adjustments are included in preview only.
 * No final settlement/payment/voucher execution.
 */
var ERP_B06J36_37_BUILD_NO = 'v64-B06J36-37';
var ERP_B06J36_37_BUILD_NAME = 'ERP_B06J36_37_ADJUSTED_PREVIEW_SAFE';
var EV37_ADD_TYPES = ['EXTRA_CHARGE','POLICY_COMPENSATION','MANUAL_ADDITION','ROUNDING_ADJUSTMENT','GIFT_ADJUSTMENT','INSTALL_COST_ADJUSTMENT'];
var EV37_DEDUCT_TYPES = ['DISCOUNT','MANUAL_DEDUCTION','CANCEL_ADJUSTMENT'];

function erpB06J36_37_adjustedPreview_fullCheck() {
  var out = { ok:false, fatal:0, warnings:[], build:ERP_B06J36_37_BUILD_NAME, label:ERP_B06J36_37_BUILD_NO, checkedAt:new Date().toISOString(), result:{checks:[]}, errorCode:'' };
  function add(name, ok, detail, warnOnly){ if(!ok && !warnOnly) out.fatal++; if(!ok && warnOnly) out.warnings.push(name + ': ' + String(detail || '')); out.result.checks.push({name:name, ok:!!ok, detail:detail || '', warnOnly:!!warnOnly}); }
  try {
    var b36b = erpB06J36_36B_adjustmentUi_fullCheck();
    add('B36B adjustment UI baseline ok', !!(b36b && b36b.ok), b36b && b36b.errorCode ? b36b.errorCode : 'B36B 기준 통과 필요', false);
    add('adjusted preview function exists', typeof erpB06J36_37_previewEventVendorSettlement === 'function', '조정반영 미리보기 래퍼', false);
    add('approved filter function exists', typeof EV37_filterApprovedAdjustments_ === 'function', 'APPROVED 조정만 반영', false);
    var sample = [
      { adjustmentType:'MANUAL_ADDITION', amount:1000, approvalStatus:'APPROVED', adjustmentId:'ADJ-A' },
      { adjustmentType:'MANUAL_DEDUCTION', amount:300, approvalStatus:'APPROVED', adjustmentId:'ADJ-B' },
      { adjustmentType:'EXTRA_CHARGE', amount:9999, approvalStatus:'REQUESTED', adjustmentId:'ADJ-C' },
      { adjustmentType:'BAD', amount:9999, approvalStatus:'APPROVED', adjustmentId:'ADJ-D' }
    ];
    var ap = EV37_filterApprovedAdjustments_(sample);
    var sum = EV37_sumAdjustments_(ap);
    add('APPROVED only calculation self test', ap.length === 2 && sum.total === 700 && sum.addTotal === 1000 && sum.deductTotal === -300, JSON.stringify({approvedCount:ap.length, sum:sum}), false);
    add('non-approved excluded self test', ap.map(function(x){return x.adjustmentId;}).join('|') === 'ADJ-A|ADJ-B', 'REQUESTED/invalid type excluded', false);
    add('preview result separates before/adjustment/after', EV37_applyAdjustmentSummary_({ totals:{vendorPayableAmount:5000, vendorReceivableAmount:0, offsetAmount:0} }, sample).totals.adjustedVendorPayableAmount === 5700, '조정 전/합계/후 금액 분리', false);
    try {
      var html = HtmlService.createHtmlOutputFromFile('EventVendor').getContent();
      add('UI calls B37 adjusted preview wrapper', html.indexOf('erpB06J36_37_previewEventVendorSettlement') >= 0, '미리보기 UI가 B37 래퍼 호출', false);
      add('UI shows approved adjustment summary', html.indexOf('approvedAdjustmentTotalAmount') >= 0 && html.indexOf('조정 후 업체 지급액') >= 0, '조정 전/후 표시', false);
    } catch(hErr) { add('UI B37 check', false, String(hErr), false); }
    add('preview-only/final execution blocked', true, 'no final settlement/payment/voucher execution', false);
    out.result.scope = 'approved adjustments included in preview only; no settlement execution';
    out.result.addTypes = EV37_ADD_TYPES.slice();
    out.result.deductTypes = EV37_DEDUCT_TYPES.slice();
    out.ok = out.fatal === 0;
    if (!out.ok) out.errorCode = 'ERP_B37_ADJUSTED_PREVIEW_FULLCHECK_FAILED';
  } catch(err) {
    out.ok = false; out.fatal++; out.errorCode = 'ERP_B37_ADJUSTED_PREVIEW_EXCEPTION'; out.error = err && err.stack ? err.stack : String(err);
  }
  Logger.log('==============================');
  Logger.log('[ERP B37 ADJUSTED PREVIEW FULL CHECK] ' + ERP_B06J36_37_BUILD_NAME);
  Logger.log(JSON.stringify(out, null, 2));
  Logger.log('==============================');
  return out;
}

function erpB06J36_37_previewEventVendorSettlement(payload) {
  var base = previewEventVendorSettlement(payload || {});
  return EV37_applyAdjustmentSummary_(base, null);
}

function EV37_applyAdjustmentSummary_(preview, rowsOverride) {
  preview = preview || {};
  var totals = preview.totals || {};
  var rows = rowsOverride || EV37_getAdjustmentRowsForPreview_(preview.eventVendorId, preview.previewId);
  var approved = EV37_filterApprovedAdjustments_(rows);
  var sum = EV37_sumAdjustments_(approved);
  var beforePayable = EV36A_n_(totals.vendorPayableAmount);
  var beforeReceivable = EV36A_n_(totals.vendorReceivableAmount);
  var beforeOffset = EV36A_n_(totals.offsetAmount);
  var afterPayable = beforePayable + sum.total;
  var afterReceivable = beforeReceivable;
  var afterOffset = beforeOffset;
  if (afterPayable < 0) {
    afterReceivable = beforeReceivable + Math.abs(afterPayable);
    afterPayable = 0;
  }
  totals.adjustmentBeforeVendorPayableAmount = beforePayable;
  totals.adjustmentBeforeVendorReceivableAmount = beforeReceivable;
  totals.adjustmentBeforeOffsetAmount = beforeOffset;
  totals.approvedAdjustmentAddAmount = sum.addTotal;
  totals.approvedAdjustmentDeductAmount = sum.deductTotal;
  totals.approvedAdjustmentTotalAmount = sum.total;
  totals.adjustedVendorPayableAmount = afterPayable;
  totals.adjustedVendorReceivableAmount = afterReceivable;
  totals.adjustedOffsetAmount = afterOffset;
  totals.adjustedSettlementDirection = afterPayable > 0 ? 'PAY_TO_VENDOR' : (afterReceivable > 0 ? 'COLLECT_FROM_VENDOR' : (afterOffset > 0 ? 'OFFSET' : 'NO_ACTION'));
  preview.totals = totals;
  preview.adjustments = {
    approvedOnly: true,
    source: 'ERP_정산조정내역',
    approvedCount: approved.length,
    excludedCount: Math.max(0, rows.length - approved.length),
    approvedRows: approved,
    addTotal: sum.addTotal,
    deductTotal: sum.deductTotal,
    total: sum.total,
    note: 'APPROVED 조정내역만 미리보기에 반영했습니다. REQUESTED/DRAFT/REJECTED/CANCELED 및 미승인 조정은 계산에서 제외됩니다.'
  };
  preview.build = ERP_B06J36_37_BUILD_NAME;
  preview.label = ERP_B06J36_37_BUILD_NO;
  preview.message = '조정내역 포함 정산 미리보기 완료. 정산 확정/지급/전표 생성은 실행하지 않았습니다.';
  preview.excluded = preview.excluded || {};
  preview.excluded.nonApprovedAdjustmentsExcluded = true;
  preview.excluded.finalSettlementExecuted = false;
  return preview;
}

function EV37_getAdjustmentRowsForPreview_(eventVendorId, previewId) {
  var list = erpB06J36_36B_listAdjustments({ eventVendorId: eventVendorId || '', limit: 500 });
  var rows = (list && list.rows) ? list.rows : [];
  var pv = EV36A_s_(previewId);
  if (pv) {
    return rows.filter(function(r){
      var rowPv = EV36A_s_(r.previewId);
      return !rowPv || rowPv === pv;
    });
  }
  return rows;
}

function EV37_filterApprovedAdjustments_(rows) {
  rows = rows || [];
  return rows.filter(function(r){
    var st = EV36A_s_(r.approvalStatus);
    var tp = EV36A_s_(r.adjustmentType);
    return st === 'APPROVED' && (EV37_ADD_TYPES.indexOf(tp) >= 0 || EV37_DEDUCT_TYPES.indexOf(tp) >= 0);
  }).map(function(r){
    var obj = {};
    Object.keys(r).forEach(function(k){ obj[k] = r[k]; });
    obj.signedAmount = EV37_signedAdjustmentAmount_(r);
    return obj;
  });
}

function EV37_signedAdjustmentAmount_(row) {
  var type = EV36A_s_(row && row.adjustmentType);
  var amount = Math.abs(EV36A_n_(row && row.amount));
  if (EV37_DEDUCT_TYPES.indexOf(type) >= 0) return -amount;
  if (EV37_ADD_TYPES.indexOf(type) >= 0) return amount;
  return 0;
}

function EV37_sumAdjustments_(rows) {
  var add = 0, deduct = 0, total = 0;
  (rows || []).forEach(function(r){
    var signed = typeof r.signedAmount === 'number' ? r.signedAmount : EV37_signedAdjustmentAmount_(r);
    total += signed;
    if (signed >= 0) add += signed; else deduct += signed;
  });
  return { addTotal:add, deductTotal:deduct, total:total };
}

function erpB06J36_37_getApprovedAdjustments(eventVendorId, previewId) {
  var rows = EV37_getAdjustmentRowsForPreview_(eventVendorId, previewId);
  var approved = EV37_filterApprovedAdjustments_(rows);
  var sum = EV37_sumAdjustments_(approved);
  return { ok:true, build:ERP_B06J36_37_BUILD_NAME, label:ERP_B06J36_37_BUILD_NO, eventVendorId:eventVendorId || '', previewId:previewId || '', rows:approved, total:approved.length, summary:sum, scope:'APPROVED only; preview calculation support only' };
}

/**
 * FEELHAUS ERP v64-B06J36-38
 * ERP_B06J36_38_SETTLEMENT_REQUEST_RECONNECT_SAFE
 * Scope: Create settlement confirmation REQUEST only from B37 adjusted preview.
 * No approval/final settlement/payment/voucher execution.
 */
var ERP_B06J36_38_BUILD_NO = 'v64-B06J36-38';
var ERP_B06J36_38_BUILD_NAME = 'ERP_B06J36_38_SETTLEMENT_REQUEST_RECONNECT_SAFE';
var EV38_REQUEST_SHEET_NAME = 'ERP_정산확정요청';
var EV38_REQUEST_HEADERS = [
  'settlementRequestId','eventVendorId','previewId','policyId','eventId','vendorId','requestStatus','requestReason',
  'beforeVendorPayableAmount','beforeVendorReceivableAmount','beforeOffsetAmount','approvedAdjustmentAddAmount','approvedAdjustmentDeductAmount','approvedAdjustmentTotalAmount',
  'requestedVendorPayableAmount','requestedVendorReceivableAmount','requestedOffsetAmount','requestedSettlementDirection',
  'approvedAdjustmentCount','excludedAdjustmentCount','previewSnapshot','adjustmentSnapshot','requestedBy','requestedAt','approvedBy','approvedAt','rejectedBy','rejectedAt','createdAt','createdBy','updatedAt','updatedBy','status','statusReason'
];

function erpB06J36_38_settlementRequest_fullCheck() {
  var out = { ok:false, fatal:0, warnings:[], build:ERP_B06J36_38_BUILD_NAME, label:ERP_B06J36_38_BUILD_NO, checkedAt:new Date().toISOString(), result:{checks:[]}, errorCode:'' };
  function add(name, ok, detail, warnOnly){ if(!ok && !warnOnly) out.fatal++; if(!ok && warnOnly) out.warnings.push(name + ': ' + String(detail || '')); out.result.checks.push({name:name, ok:!!ok, detail:detail || '', warnOnly:!!warnOnly}); }
  try {
    var b37 = erpB06J36_37_adjustedPreview_fullCheck();
    add('B37 adjusted preview baseline ok', !!(b37 && b37.ok), b37 && b37.errorCode ? b37.errorCode : 'B37 기준 통과 필요', false);
    var plan = EV38_planSettlementRequestSheet_();
    add('settlement request sheet plan ready', !!plan.ok, JSON.stringify({exists:plan.exists, missing:plan.missing, duplicatePositions:plan.duplicatePositions}), false);
    add('settlement request required headers defined', EV38_REQUEST_HEADERS.length >= 30, EV38_REQUEST_HEADERS.join('|'), false);
    add('create settlement request function exists', typeof erpB06J36_38_createSettlementRequest === 'function', 'REQUESTED 정산확정요청 생성 함수', false);
    add('list settlement request function exists', typeof erpB06J36_38_listSettlementRequests === 'function', '정산확정요청 조회 함수', false);
    add('request status guard self test', EV38_validateSettlementRequestPayload_({eventVendorId:'EVL-1', requestReason:'테스트'}).ok === true && EV38_validateSettlementRequestPayload_({eventVendorId:'', requestReason:'테스트'}).ok === false, 'eventVendorId 필수', false);
    try {
      var sample = EV38_buildRequestRowObject_({ eventVendorId:'EVL-TEST', requestReason:'테스트 요청' }, { ok:true, eventVendorId:'EVL-TEST', previewId:'PV-1', policy:{policyId:'POL-1'}, totals:{ vendorPayableAmount:5000, vendorReceivableAmount:0, offsetAmount:0, adjustmentBeforeVendorPayableAmount:5000, adjustmentBeforeVendorReceivableAmount:0, adjustmentBeforeOffsetAmount:0, approvedAdjustmentAddAmount:1000, approvedAdjustmentDeductAmount:-300, approvedAdjustmentTotalAmount:700, adjustedVendorPayableAmount:5700, adjustedVendorReceivableAmount:0, adjustedOffsetAmount:0, adjustedSettlementDirection:'PAY_TO_VENDOR' }, adjustments:{ approvedCount:2, excludedCount:1, approvedRows:[{adjustmentId:'ADJ-1'}] } });
      add('request snapshot self test', sample.requestStatus === 'REQUESTED' && sample.requestedVendorPayableAmount === 5700 && sample.approvedAdjustmentCount === 2, JSON.stringify({status:sample.requestStatus, amount:sample.requestedVendorPayableAmount, approvedCount:sample.approvedAdjustmentCount}), false);
    } catch(tErr) { add('request snapshot self test', false, String(tErr), false); }
    try {
      var html = HtmlService.createHtmlOutputFromFile('EventVendor').getContent();
      add('UI calls B38 settlement request creator', html.indexOf('erpB06J36_38_createSettlementRequest') >= 0, 'UI가 B38 REQUEST 생성 호출', false);
      add('UI shows settlement request guard', html.indexOf('EV38_SETTLEMENT_REQUEST_SENTINEL') >= 0 && html.indexOf('정산 확정 요청') >= 0, '확정요청 UI/가드 표시', false);
    } catch(hErr) { add('UI B38 check', false, String(hErr), false); }
    add('request-only/final execution blocked', true, 'no approval/final settlement/payment/voucher execution', false);
    out.result.sheet = plan;
    out.result.scope = 'settlement confirmation request only; REQUESTED status only; no settlement execution';
    out.ok = out.fatal === 0;
    if (!out.ok) out.errorCode = 'ERP_B38_SETTLEMENT_REQUEST_FULLCHECK_FAILED';
  } catch(err) {
    out.ok = false; out.fatal++; out.errorCode = 'ERP_B38_SETTLEMENT_REQUEST_EXCEPTION'; out.error = err && err.stack ? err.stack : String(err);
  }
  Logger.log('==============================');
  Logger.log('[ERP B38 SETTLEMENT REQUEST FULL CHECK] ' + ERP_B06J36_38_BUILD_NAME);
  Logger.log(JSON.stringify(out, null, 2));
  Logger.log('==============================');
  return out;
}

function erpB06J36_38_confirmed() {
  var ss = EV36A_getSpreadsheet_();
  var sheet = ss.getSheetByName(EV38_REQUEST_SHEET_NAME) || ss.insertSheet(EV38_REQUEST_SHEET_NAME);
  EV36A_ensureHeaders_(sheet, EV38_REQUEST_HEADERS);
  var out = { ok:true, applied:true, writeExecuted:true, build:ERP_B06J36_38_BUILD_NAME, label:ERP_B06J36_38_BUILD_NO, sheetName:EV38_REQUEST_SHEET_NAME, headers:EV36A_getHeaders_(sheet), message:'ERP_정산확정요청 시트/헤더 준비 완료. 승인/확정/지급/전표 생성은 실행하지 않았습니다.', checkedAt:new Date().toISOString() };
  Logger.log('==============================');
  Logger.log('[ERP B38 SETTLEMENT REQUEST APPLY] ' + ERP_B06J36_38_BUILD_NAME);
  Logger.log(JSON.stringify(out, null, 2));
  Logger.log('==============================');
  return out;
}

function EV38_planSettlementRequestSheet_() {
  var ss = EV36A_getSpreadsheet_();
  var sheet = ss.getSheetByName(EV38_REQUEST_SHEET_NAME);
  var headers = sheet ? EV36A_getHeaders_(sheet) : [];
  var missing = EV38_REQUEST_HEADERS.filter(function(h){ return headers.indexOf(h) < 0; });
  var duplicatePositions = EV36A_duplicatePositions_(headers);
  return { ok:Object.keys(duplicatePositions).length === 0, sheetName:EV38_REQUEST_SHEET_NAME, exists:!!sheet, lastRow:sheet ? sheet.getLastRow() : 0, lastCol:sheet ? sheet.getLastColumn() : 0, headers:headers, missing:missing, duplicatePositions:duplicatePositions, requiredHeaders:EV38_REQUEST_HEADERS, writeExecuted:false, applyRequired:missing.length > 0 || !sheet, note:'비파괴 계획입니다. confirmed 함수 실행 전에는 시트에 쓰지 않습니다.' };
}

function EV38_validateSettlementRequestPayload_(payload) {
  payload = payload || {};
  var eventVendorId = EV36A_s_(payload.eventVendorId);
  var reason = EV36A_s_(payload.requestReason || payload.reason || payload.statusReason);
  if (!eventVendorId) return { ok:false, errorCode:'EVENT_VENDOR_ID_REQUIRED' };
  if (!reason) return { ok:false, errorCode:'REQUEST_REASON_REQUIRED' };
  return { ok:true, eventVendorId:eventVendorId, requestReason:reason };
}

function erpB06J36_38_createSettlementRequest(payload) {
  payload = payload || {};
  var v = EV38_validateSettlementRequestPayload_(payload);
  if (!v.ok) throw new Error(v.errorCode);
  var preview = erpB06J36_37_previewEventVendorSettlement({ eventVendorId:v.eventVendorId });
  if (!preview || !preview.ok) throw new Error('B37_PREVIEW_FAILED');
  var ss = EV36A_getSpreadsheet_();
  var sheet = ss.getSheetByName(EV38_REQUEST_SHEET_NAME) || ss.insertSheet(EV38_REQUEST_SHEET_NAME);
  EV36A_ensureHeaders_(sheet, EV38_REQUEST_HEADERS);
  var headers = EV36A_getHeaders_(sheet);
  var map = EV36A_headerMap_(headers);
  var req = EV38_buildRequestRowObject_(payload, preview);
  var dup = EV38_findOpenRequest_(sheet, headers, req.eventVendorId, req.previewId);
  if (dup) throw new Error('OPEN_SETTLEMENT_REQUEST_ALREADY_EXISTS: ' + dup.settlementRequestId);
  var row = new Array(headers.length).fill('');
  headers.forEach(function(h, i){ if (h && req[h] != null) row[i] = req[h]; });
  sheet.appendRow(row);
  return { ok:true, build:ERP_B06J36_38_BUILD_NAME, label:ERP_B06J36_38_BUILD_NO, settlementRequestId:req.settlementRequestId, eventVendorId:req.eventVendorId, previewId:req.previewId, requestStatus:req.requestStatus, requestedVendorPayableAmount:req.requestedVendorPayableAmount, requestedVendorReceivableAmount:req.requestedVendorReceivableAmount, requestedSettlementDirection:req.requestedSettlementDirection, approvedAdjustmentCount:req.approvedAdjustmentCount, excludedAdjustmentCount:req.excludedAdjustmentCount, finalSettlementExecuted:false, paymentExecuted:false, voucherCreated:false, message:'정산 확정 요청이 REQUESTED 상태로 생성되었습니다. 승인/확정/지급/전표 생성은 실행하지 않았습니다.' };
}

function EV38_buildRequestRowObject_(payload, preview) {
  payload = payload || {}; preview = preview || {};
  var totals = preview.totals || {};
  var policy = preview.policy || {};
  var adj = preview.adjustments || {};
  var now = EV36A_now_();
  var requestId = 'SRQ-' + Utilities.formatDate(new Date(), Session.getScriptTimeZone() || 'Asia/Seoul', 'yyyyMMddHHmmss') + '-' + Math.floor(Math.random() * 900 + 100);
  var reason = EV36A_s_(payload.requestReason || payload.reason || payload.statusReason);
  return {
    settlementRequestId: requestId,
    eventVendorId: EV36A_s_(preview.eventVendorId || payload.eventVendorId),
    previewId: EV36A_s_(preview.previewId || payload.previewId),
    policyId: EV36A_s_(policy.policyId || payload.policyId),
    eventId: EV36A_s_(preview.eventId || payload.eventId),
    vendorId: EV36A_s_(preview.vendorId || payload.vendorId),
    requestStatus: 'REQUESTED',
    requestReason: reason,
    beforeVendorPayableAmount: EV36A_n_(totals.adjustmentBeforeVendorPayableAmount != null ? totals.adjustmentBeforeVendorPayableAmount : totals.vendorPayableAmount),
    beforeVendorReceivableAmount: EV36A_n_(totals.adjustmentBeforeVendorReceivableAmount != null ? totals.adjustmentBeforeVendorReceivableAmount : totals.vendorReceivableAmount),
    beforeOffsetAmount: EV36A_n_(totals.adjustmentBeforeOffsetAmount != null ? totals.adjustmentBeforeOffsetAmount : totals.offsetAmount),
    approvedAdjustmentAddAmount: EV36A_n_(totals.approvedAdjustmentAddAmount),
    approvedAdjustmentDeductAmount: EV36A_n_(totals.approvedAdjustmentDeductAmount),
    approvedAdjustmentTotalAmount: EV36A_n_(totals.approvedAdjustmentTotalAmount),
    requestedVendorPayableAmount: EV36A_n_(totals.adjustedVendorPayableAmount != null ? totals.adjustedVendorPayableAmount : totals.vendorPayableAmount),
    requestedVendorReceivableAmount: EV36A_n_(totals.adjustedVendorReceivableAmount != null ? totals.adjustedVendorReceivableAmount : totals.vendorReceivableAmount),
    requestedOffsetAmount: EV36A_n_(totals.adjustedOffsetAmount != null ? totals.adjustedOffsetAmount : totals.offsetAmount),
    requestedSettlementDirection: EV36A_s_(totals.adjustedSettlementDirection || totals.settlementDirection),
    approvedAdjustmentCount: EV36A_n_(adj.approvedCount),
    excludedAdjustmentCount: EV36A_n_(adj.excludedCount),
    previewSnapshot: JSON.stringify({ previewId:preview.previewId || '', eventVendorId:preview.eventVendorId || '', eventName:preview.eventName || '', vendorName:preview.vendorName || '', policy:policy, totals:totals, rows:preview.rows || [] }),
    adjustmentSnapshot: JSON.stringify({ approvedOnly:true, approvedRows:adj.approvedRows || [], approvedCount:adj.approvedCount || 0, excludedCount:adj.excludedCount || 0, total:adj.total || 0 }),
    requestedBy: EV36A_user_(),
    requestedAt: now,
    createdAt: now,
    createdBy: EV36A_user_(),
    updatedAt: now,
    updatedBy: EV36A_user_(),
    status: 'REQUESTED',
    statusReason: reason
  };
}

function EV38_findOpenRequest_(sheet, headers, eventVendorId, previewId) {
  if (!sheet || sheet.getLastRow() < 2) return null;
  var map = EV36A_headerMap_(headers);
  var values = sheet.getRange(2,1,sheet.getLastRow()-1,headers.length).getValues();
  var ev = EV36A_s_(eventVendorId), pv = EV36A_s_(previewId);
  for (var i=0; i<values.length; i++) {
    var row = values[i];
    var st = EV36A_s_(row[map.requestStatus]).toUpperCase();
    var rowEv = EV36A_s_(row[map.eventVendorId]);
    var rowPv = EV36A_s_(row[map.previewId]);
    if (rowEv === ev && (!pv || rowPv === pv) && ['REQUESTED','PENDING','PENDING_APPROVAL'].indexOf(st) >= 0) {
      return { row:i+2, settlementRequestId:row[map.settlementRequestId], requestStatus:st };
    }
  }
  return null;
}

function erpB06J36_38_listSettlementRequests(filter) {
  filter = filter || {};
  var ss = EV36A_getSpreadsheet_();
  var sheet = ss.getSheetByName(EV38_REQUEST_SHEET_NAME);
  if (!sheet) return { ok:true, rows:[], total:0, sheetName:EV38_REQUEST_SHEET_NAME, note:'정산확정요청 시트가 아직 없습니다.' };
  EV36A_ensureHeaders_(sheet, EV38_REQUEST_HEADERS);
  var headers = EV36A_getHeaders_(sheet);
  var last = sheet.getLastRow();
  if (last < 2) return { ok:true, rows:[], total:0, sheetName:EV38_REQUEST_SHEET_NAME, headers:headers };
  var q = EV36A_s_(filter.query).toLowerCase();
  var status = EV36A_s_(filter.requestStatus || filter.status);
  var eventVendorId = EV36A_s_(filter.eventVendorId);
  var limit = Math.max(1, Math.min(Number(filter.limit || 100), 500));
  var values = sheet.getRange(2,1,last-1,headers.length).getValues();
  var rows = [];
  values.forEach(function(row, idx){
    var obj = { _row:idx+2 };
    headers.forEach(function(h,i){ if(h) obj[h] = row[i]; });
    if (status && EV36A_s_(obj.requestStatus) !== status) return;
    if (eventVendorId && EV36A_s_(obj.eventVendorId) !== eventVendorId) return;
    if (q) {
      var hay = [obj.settlementRequestId,obj.eventVendorId,obj.previewId,obj.policyId,obj.eventId,obj.vendorId,obj.requestStatus,obj.requestReason,obj.requestedBy].join(' ').toLowerCase();
      if (hay.indexOf(q) < 0) return;
    }
    rows.push(obj);
  });
  rows.sort(function(a,b){ return EV36A_s_(b.createdAt || b.requestedAt).localeCompare(EV36A_s_(a.createdAt || a.requestedAt)); });
  return { ok:true, build:ERP_B06J36_38_BUILD_NAME, label:ERP_B06J36_38_BUILD_NO, rows:rows.slice(0,limit), total:rows.length, sheetName:EV38_REQUEST_SHEET_NAME, headers:headers, scope:'REQUESTED settlement request list only; no approval/final/payment/voucher execution' };
}

/**
 * FEELHAUS ERP v64-B06J36-39
 * ERP_B06J36_39_SETTLEMENT_APPROVAL_WAIT_UI_SAFE
 * Scope: HQ approval wait list + approve/reject status change only. No final settlement/payment/voucher execution.
 */
var ERP_B06J36_39_BUILD_NO = 'v64-B06J36-39';
var ERP_B06J36_39_BUILD_NAME = 'ERP_B06J36_39_SETTLEMENT_APPROVAL_WAIT_UI_SAFE';

function erpB06J36_39_approvalWait_fullCheck() {
  var out = { ok:false, fatal:0, warnings:[], build:ERP_B06J36_39_BUILD_NAME, label:ERP_B06J36_39_BUILD_NO, checkedAt:new Date().toISOString(), result:{checks:[]}, errorCode:'' };
  function add(name, ok, detail, warnOnly){ if(!ok && !warnOnly) out.fatal++; if(!ok && warnOnly) out.warnings.push(name + ': ' + String(detail || '')); out.result.checks.push({name:name, ok:!!ok, detail:detail || '', warnOnly:!!warnOnly}); }
  try {
    var b38 = erpB06J36_38_settlementRequest_fullCheck();
    add('B38 settlement request baseline ok', !!(b38 && b38.ok), b38 && b38.errorCode ? b38.errorCode : 'B38 기준 통과 필요', false);
    var plan = EV38_planSettlementRequestSheet_();
    add('settlement request sheet ready', !!plan.ok && plan.exists && plan.missing.length === 0, JSON.stringify({exists:plan.exists, missing:plan.missing, duplicatePositions:plan.duplicatePositions}), false);
    add('approval wait list function exists', typeof erpB06J36_39_listApprovalWaitRequests === 'function', 'REQUESTED 승인대기 목록 조회', false);
    add('approval status update function exists', typeof erpB06J36_39_updateSettlementRequestApprovalStatus === 'function', '승인/반려 상태 변경 함수', false);
    add('approve wrapper exists', typeof erpB06J36_39_approveSettlementRequest === 'function', 'APPROVED 상태 변경 래퍼', false);
    add('reject wrapper exists', typeof erpB06J36_39_rejectSettlementRequest === 'function', 'REJECTED 상태 변경 래퍼', false);
    add('reason required self test', EV39_validateApprovalPayload_({settlementRequestId:'SRQ-X', action:'APPROVE', reason:''}).ok === false && EV39_validateApprovalPayload_({settlementRequestId:'SRQ-X', action:'APPROVE', reason:'승인 테스트'}).ok === true, '승인/반려 사유 필수', false);
    add('action code guard self test', EV39_validateApprovalPayload_({settlementRequestId:'SRQ-X', action:'FINALIZE', reason:'x'}).ok === false, 'APPROVE/REJECT only', false);
    try {
      var html = HtmlService.createHtmlOutputFromFile('EventVendor').getContent();
      add('UI calls B39 approval wait list', html.indexOf('erpB06J36_39_listApprovalWaitRequests') >= 0, 'UI가 B39 승인대기 목록 호출', false);
      add('UI calls B39 approve/reject wrappers', html.indexOf('erpB06J36_39_approveSettlementRequest') >= 0 && html.indexOf('erpB06J36_39_rejectSettlementRequest') >= 0, '승인/반려 버튼은 B39 상태변경만 호출', false);
      add('UI shows final execution block guard', html.indexOf('B39_APPROVAL_WAIT_SENTINEL') >= 0 && html.indexOf('지급/전표 생성은 실행하지 않습니다') >= 0, '실제 확정/지급/전표 차단 안내', false);
    } catch(hErr) { add('UI B39 check', false, String(hErr), false); }
    add('approval status only/final execution blocked', true, 'status change only; no final settlement/payment/voucher execution', false);
    out.result.sheet = plan;
    out.result.scope = 'HQ approval wait UI and request status change only; no settlement execution';
    out.ok = out.fatal === 0;
    if (!out.ok) out.errorCode = 'ERP_B39_APPROVAL_WAIT_FULLCHECK_FAILED';
  } catch(err) {
    out.ok = false; out.fatal++; out.errorCode = 'ERP_B39_APPROVAL_WAIT_EXCEPTION'; out.error = err && err.stack ? err.stack : String(err);
  }
  Logger.log('==============================');
  Logger.log('[ERP B39 SETTLEMENT APPROVAL WAIT FULL CHECK] ' + ERP_B06J36_39_BUILD_NAME);
  Logger.log(JSON.stringify(out, null, 2));
  Logger.log('==============================');
  return out;
}

function erpB06J36_39_listApprovalWaitRequests(filter) {
  filter = filter || {};
  filter.requestStatus = 'REQUESTED';
  var res = erpB06J36_38_listSettlementRequests(filter);
  res.build = ERP_B06J36_39_BUILD_NAME;
  res.label = ERP_B06J36_39_BUILD_NO;
  res.scope = 'REQUESTED approval wait list only; no final settlement/payment/voucher execution';
  return res;
}

function erpB06J36_39_approveSettlementRequest(payload) {
  payload = payload || {};
  payload.action = 'APPROVE';
  return erpB06J36_39_updateSettlementRequestApprovalStatus(payload);
}

function erpB06J36_39_rejectSettlementRequest(payload) {
  payload = payload || {};
  payload.action = 'REJECT';
  return erpB06J36_39_updateSettlementRequestApprovalStatus(payload);
}

function erpB06J36_39_updateSettlementRequestApprovalStatus(payload) {
  payload = payload || {};
  var v = EV39_validateApprovalPayload_(payload);
  if (!v.ok) throw new Error(v.errorCode);
  var ss = EV36A_getSpreadsheet_();
  var sheet = ss.getSheetByName(EV38_REQUEST_SHEET_NAME);
  if (!sheet) throw new Error('SETTLEMENT_REQUEST_SHEET_NOT_FOUND');
  EV36A_ensureHeaders_(sheet, EV38_REQUEST_HEADERS);
  var headers = EV36A_getHeaders_(sheet);
  var map = EV36A_headerMap_(headers);
  var rowNo = EV39_findSettlementRequestRow_(sheet, headers, v.settlementRequestId);
  if (!rowNo) throw new Error('SETTLEMENT_REQUEST_NOT_FOUND: ' + v.settlementRequestId);
  var row = sheet.getRange(rowNo, 1, 1, headers.length).getValues()[0];
  var currentStatus = EV36A_s_(row[map.requestStatus] || row[map.status]).toUpperCase();
  if (currentStatus !== 'REQUESTED') throw new Error('ONLY_REQUESTED_CAN_BE_APPROVED_OR_REJECTED: ' + currentStatus);
  var newStatus = v.action === 'APPROVE' ? 'APPROVED' : 'REJECTED';
  var now = EV36A_now_();
  function set(h, val) { if (map[h] != null) row[map[h]] = val; }
  set('requestStatus', newStatus);
  set('status', newStatus);
  set('statusReason', v.reason);
  set('updatedAt', now);
  set('updatedBy', EV36A_user_());
  if (newStatus === 'APPROVED') {
    set('approvedBy', EV36A_user_());
    set('approvedAt', now);
  } else {
    set('rejectedBy', EV36A_user_());
    set('rejectedAt', now);
  }
  sheet.getRange(rowNo, 1, 1, headers.length).setValues([row]);
  try { EV43_appendAuditLog_({ targetType:'SETTLEMENT_REQUEST', targetId:v.settlementRequestId, actionCode:(newStatus === 'APPROVED' ? 'SETTLEMENT_REQUEST_APPROVE' : 'SETTLEMENT_REQUEST_REJECT'), beforeStatus:currentStatus, afterStatus:newStatus, reason:v.reason, relatedRequestId:v.settlementRequestId, eventVendorId:EV36A_s_(row[map.eventVendorId]), previousValue:JSON.stringify({requestStatus:currentStatus}), newValue:JSON.stringify({requestStatus:newStatus}), snapshot:JSON.stringify({row:rowNo, settlementRequestId:v.settlementRequestId, status:newStatus}) }); } catch(logErr) { Logger.log('[B43 AUDIT LOG WARNING] ' + (logErr && logErr.message ? logErr.message : logErr)); }
  return {
    ok:true,
    build:ERP_B06J36_39_BUILD_NAME,
    label:ERP_B06J36_39_BUILD_NO,
    settlementRequestId:v.settlementRequestId,
    requestStatus:newStatus,
    previousStatus:currentStatus,
    statusReason:v.reason,
    row:rowNo,
    approvalStatusChanged:true,
    finalSettlementExecuted:false,
    paymentExecuted:false,
    voucherCreated:false,
    message:'정산확정요청 상태가 ' + newStatus + '로 변경되었습니다. 실제 정산확정/지급/전표 생성은 실행하지 않았습니다.'
  };
}

function EV39_validateApprovalPayload_(payload) {
  payload = payload || {};
  var id = EV36A_s_(payload.settlementRequestId || payload.requestId);
  var action = EV36A_s_(payload.action).toUpperCase();
  var reason = EV36A_s_(payload.reason || payload.statusReason || payload.approvalReason);
  if (!id) return { ok:false, errorCode:'SETTLEMENT_REQUEST_ID_REQUIRED' };
  if (['APPROVE','REJECT'].indexOf(action) < 0) return { ok:false, errorCode:'INVALID_APPROVAL_ACTION' };
  if (!reason) return { ok:false, errorCode:'APPROVAL_REASON_REQUIRED' };
  return { ok:true, settlementRequestId:id, action:action, reason:reason };
}

function EV39_findSettlementRequestRow_(sheet, headers, settlementRequestId) {
  if (!sheet || sheet.getLastRow() < 2) return 0;
  var map = EV36A_headerMap_(headers);
  var idCol = map.settlementRequestId;
  if (idCol == null) return 0;
  var values = sheet.getRange(2, idCol + 1, sheet.getLastRow() - 1, 1).getValues();
  var target = EV36A_s_(settlementRequestId);
  for (var i=0; i<values.length; i++) {
    if (EV36A_s_(values[i][0]) === target) return i + 2;
  }
  return 0;
}

/**
 * FEELHAUS ERP v64-B06J36-40
 * ERP_B06J36_40_FINAL_SETTLEMENT_READY_SAFE
 * Scope: Create READY/DRAFT final-settlement candidate only from APPROVED settlement request.
 * No payment/voucher/accounting journal execution.
 */
var ERP_B06J36_40_BUILD_NO = 'v64-B06J36-40';
var ERP_B06J36_40_BUILD_NAME = 'ERP_B06J36_40_FINAL_SETTLEMENT_READY_SAFE';
var EV40_FINAL_SHEET_NAME = 'ERP_확정정산';
var EV40_FINAL_HEADERS = [
  'finalSettlementId','settlementRequestId','eventVendorId','previewId','policyId','eventId','vendorId',
  'finalStatus','sourceRequestStatus','requestReason','vendorPayableAmount','vendorReceivableAmount','offsetAmount','settlementDirection',
  'approvedAdjustmentTotalAmount','approvedAdjustmentCount','excludedAdjustmentCount','previewSnapshot','adjustmentSnapshot','requestSnapshot',
  'createdFromRequestBy','createdFromRequestAt','createdAt','createdBy','updatedAt','updatedBy','status','statusReason'
];

function erpB06J36_40_finalSettlementReady_fullCheck() {
  var out = { ok:false, fatal:0, warnings:[], build:ERP_B06J36_40_BUILD_NAME, label:ERP_B06J36_40_BUILD_NO, checkedAt:new Date().toISOString(), result:{checks:[]}, errorCode:'' };
  function add(name, ok, detail, warnOnly){ if(!ok && !warnOnly) out.fatal++; if(!ok && warnOnly) out.warnings.push(name + ': ' + String(detail || '')); out.result.checks.push({name:name, ok:!!ok, detail:detail || '', warnOnly:!!warnOnly}); }
  try {
    var b39 = erpB06J36_39_approvalWait_fullCheck();
    add('B39 approval wait baseline ok', !!(b39 && b39.ok), b39 && b39.errorCode ? b39.errorCode : 'B39 기준 통과 필요', false);
    var reqPlan = EV38_planSettlementRequestSheet_();
    add('settlement request sheet ready', !!reqPlan.ok && reqPlan.exists && reqPlan.missing.length === 0, JSON.stringify({exists:reqPlan.exists, missing:reqPlan.missing, duplicatePositions:reqPlan.duplicatePositions}), false);
    var plan = EV40_planFinalSettlementSheet_();
    add('final settlement sheet plan ready', !!plan.ok, JSON.stringify({exists:plan.exists, missing:plan.missing, duplicatePositions:plan.duplicatePositions}), false);
    add('final settlement required headers defined', EV40_FINAL_HEADERS.length >= 25, EV40_FINAL_HEADERS.join('|'), false);
    add('approved request list function exists', typeof erpB06J36_40_listApprovedSettlementRequests === 'function', 'APPROVED 확정요청 후보 조회', false);
    add('final settlement ready create function exists', typeof erpB06J36_40_createFinalSettlementReady === 'function', 'READY 확정정산 후보 생성 함수', false);
    try {
      var sampleApproved = { settlementRequestId:'SRQ-T', requestStatus:'APPROVED', eventVendorId:'EVL-T', requestedVendorPayableAmount:5700, requestedVendorReceivableAmount:0, requestedOffsetAmount:0, requestedSettlementDirection:'PAY_TO_VENDOR', approvedAdjustmentTotalAmount:700, approvedAdjustmentCount:2, excludedAdjustmentCount:1, requestReason:'테스트', previewSnapshot:'{}', adjustmentSnapshot:'{}', requestedBy:'tester', requestedAt:'now' };
      var sample = EV40_buildFinalSettlementRowObject_(sampleApproved);
      add('READY candidate snapshot self test', sample.finalStatus === 'READY' && sample.status === 'READY' && sample.vendorPayableAmount === 5700 && sample.sourceRequestStatus === 'APPROVED', JSON.stringify({status:sample.finalStatus, amount:sample.vendorPayableAmount, source:sample.sourceRequestStatus}), false);
      add('approved only source guard self test', EV40_validateFinalReadySource_({settlementRequestId:'SRQ-X', requestStatus:'REQUESTED'}).ok === false && EV40_validateFinalReadySource_(sampleApproved).ok === true, 'APPROVED request only', false);
    } catch(tErr) { add('READY candidate self test', false, String(tErr), false); }
    try {
      var html = HtmlService.createHtmlOutputFromFile('EventVendor').getContent();
      add('UI calls B40 approved request list', html.indexOf('erpB06J36_40_listApprovedSettlementRequests') >= 0, 'UI가 B40 승인요청 후보 조회 호출', false);
      add('UI calls B40 final ready creator', html.indexOf('erpB06J36_40_createFinalSettlementReady') >= 0, 'UI가 B40 READY 생성 호출', false);
      add('UI shows payment/voucher block guard', html.indexOf('B40_FINAL_READY_SENTINEL') >= 0 && html.indexOf('지급/전표/회계분개는 실행하지 않습니다') >= 0, '지급/전표/회계 차단 안내', false);
    } catch(hErr) { add('UI B40 check', false, String(hErr), false); }
    add('ready-only/payment-voucher-accounting blocked', true, 'READY candidate only; no payment/voucher/accounting journal execution', false);
    out.result.requestSheet = reqPlan;
    out.result.finalSheet = plan;
    out.result.scope = 'approved request to READY final-settlement candidate only; no payment/voucher/accounting execution';
    out.ok = out.fatal === 0;
    if (!out.ok) out.errorCode = 'ERP_B40_FINAL_SETTLEMENT_READY_FULLCHECK_FAILED';
  } catch(err) {
    out.ok = false; out.fatal++; out.errorCode = 'ERP_B40_FINAL_SETTLEMENT_READY_EXCEPTION'; out.error = err && err.stack ? err.stack : String(err);
  }
  Logger.log('==============================');
  Logger.log('[ERP B40 FINAL SETTLEMENT READY FULL CHECK] ' + ERP_B06J36_40_BUILD_NAME);
  Logger.log(JSON.stringify(out, null, 2));
  Logger.log('==============================');
  return out;
}

function erpB06J36_40_confirmed() {
  var ss = EV36A_getSpreadsheet_();
  var sheet = ss.getSheetByName(EV40_FINAL_SHEET_NAME) || ss.insertSheet(EV40_FINAL_SHEET_NAME);
  EV36A_ensureHeaders_(sheet, EV40_FINAL_HEADERS);
  var out = { ok:true, applied:true, writeExecuted:true, build:ERP_B06J36_40_BUILD_NAME, label:ERP_B06J36_40_BUILD_NO, sheetName:EV40_FINAL_SHEET_NAME, headers:EV36A_getHeaders_(sheet), message:'ERP_확정정산 시트/헤더 준비 완료. READY 후보 생성 전용이며 지급/전표/회계분개는 실행하지 않았습니다.', checkedAt:new Date().toISOString() };
  Logger.log('==============================');
  Logger.log('[ERP B40 FINAL SETTLEMENT READY APPLY] ' + ERP_B06J36_40_BUILD_NAME);
  Logger.log(JSON.stringify(out, null, 2));
  Logger.log('==============================');
  return out;
}

function EV40_planFinalSettlementSheet_() {
  var ss = EV36A_getSpreadsheet_();
  var sheet = ss.getSheetByName(EV40_FINAL_SHEET_NAME);
  var headers = sheet ? EV36A_getHeaders_(sheet) : [];
  var missing = EV40_FINAL_HEADERS.filter(function(h){ return headers.indexOf(h) < 0; });
  var duplicatePositions = EV36A_duplicatePositions_(headers);
  return { ok:Object.keys(duplicatePositions).length === 0, sheetName:EV40_FINAL_SHEET_NAME, exists:!!sheet, lastRow:sheet ? sheet.getLastRow() : 0, lastCol:sheet ? sheet.getLastColumn() : 0, headers:headers, missing:missing, duplicatePositions:duplicatePositions, requiredHeaders:EV40_FINAL_HEADERS, writeExecuted:false, applyRequired:missing.length > 0 || !sheet, note:'비파괴 계획입니다. confirmed 함수 실행 전에는 시트에 쓰지 않습니다.' };
}

function erpB06J36_40_listApprovedSettlementRequests(filter) {
  filter = filter || {};
  filter.requestStatus = 'APPROVED';
  var res = erpB06J36_38_listSettlementRequests(filter);
  res.build = ERP_B06J36_40_BUILD_NAME;
  res.label = ERP_B06J36_40_BUILD_NO;
  res.scope = 'APPROVED settlement request candidates only; no final execution/payment/voucher';
  return res;
}

function erpB06J36_40_listFinalSettlements(filter) {
  filter = filter || {};
  var ss = EV36A_getSpreadsheet_();
  var sheet = ss.getSheetByName(EV40_FINAL_SHEET_NAME);
  if (!sheet) return { ok:true, rows:[], total:0, sheetName:EV40_FINAL_SHEET_NAME, note:'확정정산 시트가 아직 없습니다.' };
  EV36A_ensureHeaders_(sheet, EV40_FINAL_HEADERS);
  var headers = EV36A_getHeaders_(sheet);
  var last = sheet.getLastRow();
  if (last < 2) return { ok:true, rows:[], total:0, sheetName:EV40_FINAL_SHEET_NAME, headers:headers };
  var q = EV36A_s_(filter.query).toLowerCase();
  var status = EV36A_s_(filter.finalStatus || filter.status);
  var limit = Math.max(1, Math.min(Number(filter.limit || 100), 500));
  var values = sheet.getRange(2,1,last-1,headers.length).getValues();
  var rows = [];
  values.forEach(function(row, idx){
    var obj = { _row:idx+2 };
    headers.forEach(function(h,i){ if(h) obj[h] = row[i]; });
    if (status && EV36A_s_(obj.finalStatus || obj.status) !== status) return;
    if (q) {
      var hay = [obj.finalSettlementId,obj.settlementRequestId,obj.eventVendorId,obj.eventId,obj.vendorId,obj.finalStatus,obj.statusReason].join(' ').toLowerCase();
      if (hay.indexOf(q) < 0) return;
    }
    rows.push(obj);
  });
  rows.sort(function(a,b){ return EV36A_s_(b.createdAt).localeCompare(EV36A_s_(a.createdAt)); });
  return { ok:true, build:ERP_B06J36_40_BUILD_NAME, label:ERP_B06J36_40_BUILD_NO, rows:rows.slice(0,limit), total:rows.length, sheetName:EV40_FINAL_SHEET_NAME, headers:headers, scope:'READY/DRAFT final settlement candidates only; no payment/voucher/accounting' };
}

function erpB06J36_40_createFinalSettlementReady(payload) {
  payload = payload || {};
  var requestId = EV36A_s_(payload.settlementRequestId || payload.requestId);
  if (!requestId) throw new Error('SETTLEMENT_REQUEST_ID_REQUIRED');
  var req = EV40_getSettlementRequestById_(requestId);
  var v = EV40_validateFinalReadySource_(req);
  if (!v.ok) throw new Error(v.errorCode + ': ' + (v.status || ''));
  var ss = EV36A_getSpreadsheet_();
  var sheet = ss.getSheetByName(EV40_FINAL_SHEET_NAME) || ss.insertSheet(EV40_FINAL_SHEET_NAME);
  EV36A_ensureHeaders_(sheet, EV40_FINAL_HEADERS);
  var headers = EV36A_getHeaders_(sheet);
  var dup = EV40_findFinalSettlementByRequest_(sheet, headers, requestId);
  if (dup) throw new Error('FINAL_SETTLEMENT_READY_ALREADY_EXISTS: ' + dup.finalSettlementId);
  var obj = EV40_buildFinalSettlementRowObject_(req);
  var row = new Array(headers.length).fill('');
  headers.forEach(function(h,i){ if (h && obj[h] != null) row[i] = obj[h]; });
  sheet.appendRow(row);
  return { ok:true, build:ERP_B06J36_40_BUILD_NAME, label:ERP_B06J36_40_BUILD_NO, finalSettlementId:obj.finalSettlementId, settlementRequestId:obj.settlementRequestId, finalStatus:obj.finalStatus, vendorPayableAmount:obj.vendorPayableAmount, vendorReceivableAmount:obj.vendorReceivableAmount, settlementDirection:obj.settlementDirection, paymentExecuted:false, voucherCreated:false, accountingJournalCreated:false, message:'확정정산 후보가 READY 상태로 생성되었습니다. 지급/전표/회계분개는 실행하지 않았습니다.' };
}

function EV40_getSettlementRequestById_(settlementRequestId) {
  var ss = EV36A_getSpreadsheet_();
  var sheet = ss.getSheetByName(EV38_REQUEST_SHEET_NAME);
  if (!sheet) throw new Error('SETTLEMENT_REQUEST_SHEET_NOT_FOUND');
  EV36A_ensureHeaders_(sheet, EV38_REQUEST_HEADERS);
  var headers = EV36A_getHeaders_(sheet);
  var rowNo = EV39_findSettlementRequestRow_(sheet, headers, settlementRequestId);
  if (!rowNo) throw new Error('SETTLEMENT_REQUEST_NOT_FOUND: ' + settlementRequestId);
  var row = sheet.getRange(rowNo,1,1,headers.length).getValues()[0];
  var obj = { _row:rowNo };
  headers.forEach(function(h,i){ if(h) obj[h] = row[i]; });
  return obj;
}

function EV40_validateFinalReadySource_(req) {
  req = req || {};
  var id = EV36A_s_(req.settlementRequestId);
  var st = EV36A_s_(req.requestStatus || req.status).toUpperCase();
  if (!id) return { ok:false, errorCode:'SETTLEMENT_REQUEST_ID_REQUIRED' };
  if (st !== 'APPROVED') return { ok:false, errorCode:'ONLY_APPROVED_REQUEST_CAN_CREATE_READY_FINAL_SETTLEMENT', status:st };
  return { ok:true, settlementRequestId:id, status:st };
}

function EV40_buildFinalSettlementRowObject_(req) {
  req = req || {};
  var now = EV36A_now_();
  var finalId = 'FST-' + Utilities.formatDate(new Date(), Session.getScriptTimeZone() || 'Asia/Seoul', 'yyyyMMddHHmmss') + '-' + Math.floor(Math.random() * 900 + 100);
  return {
    finalSettlementId: finalId,
    settlementRequestId: EV36A_s_(req.settlementRequestId),
    eventVendorId: EV36A_s_(req.eventVendorId),
    previewId: EV36A_s_(req.previewId),
    policyId: EV36A_s_(req.policyId),
    eventId: EV36A_s_(req.eventId),
    vendorId: EV36A_s_(req.vendorId),
    finalStatus: 'READY',
    sourceRequestStatus: EV36A_s_(req.requestStatus || req.status),
    requestReason: EV36A_s_(req.requestReason || req.statusReason),
    vendorPayableAmount: EV36A_n_(req.requestedVendorPayableAmount),
    vendorReceivableAmount: EV36A_n_(req.requestedVendorReceivableAmount),
    offsetAmount: EV36A_n_(req.requestedOffsetAmount),
    settlementDirection: EV36A_s_(req.requestedSettlementDirection),
    approvedAdjustmentTotalAmount: EV36A_n_(req.approvedAdjustmentTotalAmount),
    approvedAdjustmentCount: EV36A_n_(req.approvedAdjustmentCount),
    excludedAdjustmentCount: EV36A_n_(req.excludedAdjustmentCount),
    previewSnapshot: EV36A_s_(req.previewSnapshot),
    adjustmentSnapshot: EV36A_s_(req.adjustmentSnapshot),
    requestSnapshot: JSON.stringify(req),
    createdFromRequestBy: EV36A_s_(req.requestedBy),
    createdFromRequestAt: EV36A_s_(req.requestedAt),
    createdAt: now,
    createdBy: EV36A_user_(),
    updatedAt: now,
    updatedBy: EV36A_user_(),
    status: 'READY',
    statusReason: 'APPROVED 정산확정요청 기반 READY 후보 생성'
  };
}

function EV40_findFinalSettlementByRequest_(sheet, headers, settlementRequestId) {
  if (!sheet || sheet.getLastRow() < 2) return null;
  var map = EV36A_headerMap_(headers);
  var reqCol = map.settlementRequestId;
  if (reqCol == null) return null;
  var id = EV36A_s_(settlementRequestId);
  var values = sheet.getRange(2,1,sheet.getLastRow()-1,headers.length).getValues();
  for (var i=0; i<values.length; i++) {
    if (EV36A_s_(values[i][reqCol]) === id) {
      return { row:i+2, finalSettlementId:values[i][map.finalSettlementId], settlementRequestId:id, finalStatus:values[i][map.finalStatus] };
    }
  }
  return null;
}


/**
 * FEELHAUS ERP v64-B06J36-41
 * ERP_B06J36_41_FINAL_LOCK_REOPEN_GUARD_SAFE
 * Scope: READY/LOCKED final-settlement guard and reopen request only.
 * No payment/voucher/accounting journal execution.
 */
var ERP_B06J36_41_BUILD_NO = 'v64-B06J36-41';
var ERP_B06J36_41_BUILD_NAME = 'ERP_B06J36_41_FINAL_LOCK_REOPEN_GUARD_SAFE';
var EV41_REOPEN_SHEET_NAME = 'ERP_확정정산재오픈요청';
var EV41_REOPEN_HEADERS = [
  'reopenRequestId','finalSettlementId','settlementRequestId','eventVendorId','requestStatus','requestReason',
  'finalStatusAtRequest','finalSnapshot','requestedBy','requestedAt','approvedBy','approvedAt','rejectedBy','rejectedAt',
  'createdAt','createdBy','updatedAt','updatedBy','status','statusReason'
];

function erpB06J36_41_finalLockReopenGuard_fullCheck() {
  var out = { ok:false, fatal:0, warnings:[], build:ERP_B06J36_41_BUILD_NAME, label:ERP_B06J36_41_BUILD_NO, checkedAt:new Date().toISOString(), result:{checks:[]}, errorCode:'' };
  function add(name, ok, detail, warnOnly){ if(!ok && !warnOnly) out.fatal++; if(!ok && warnOnly) out.warnings.push(name + ': ' + String(detail || '')); out.result.checks.push({name:name, ok:!!ok, detail:detail || '', warnOnly:!!warnOnly}); }
  try {
    var b40 = erpB06J36_40_finalSettlementReady_fullCheck();
    add('B40 final READY baseline ok', !!(b40 && b40.ok), b40 && b40.errorCode ? b40.errorCode : 'B40 기준 통과 필요', false);
    var finalPlan = EV40_planFinalSettlementSheet_();
    add('final settlement sheet ready', !!finalPlan.ok && finalPlan.exists && finalPlan.missing.length === 0, JSON.stringify({exists:finalPlan.exists, missing:finalPlan.missing, duplicatePositions:finalPlan.duplicatePositions}), false);
    var reopenPlan = EV41_planReopenRequestSheet_();
    add('reopen request sheet plan ready', !!reopenPlan.ok, JSON.stringify({exists:reopenPlan.exists, missing:reopenPlan.missing, duplicatePositions:reopenPlan.duplicatePositions}), false);
    add('reopen request required headers defined', EV41_REOPEN_HEADERS.length >= 15, EV41_REOPEN_HEADERS.join('|'), false);
    add('READY/LOCKED list function exists', typeof erpB06J36_41_listLockGuardFinalSettlements === 'function', 'READY/LOCKED 확정정산 목록 조회', false);
    add('lock final settlement function exists', typeof erpB06J36_41_lockFinalSettlement === 'function', 'READY → LOCKED 상태변경', false);
    add('reopen request function exists', typeof erpB06J36_41_requestReopenFinalSettlement === 'function', 'LOCKED 재오픈 요청 생성', false);
    add('reopen request list function exists', typeof erpB06J36_41_listReopenRequests === 'function', '재오픈 요청 조회', false);
    try {
      var lockOk = EV41_validateLockPayload_({finalSettlementId:'FST-T', reason:'마감 잠금'}).ok === true;
      var noReason = EV41_validateLockPayload_({finalSettlementId:'FST-T'}).ok === false;
      var reopenOk = EV41_validateReopenPayload_({finalSettlementId:'FST-T', reason:'승인 기반 재오픈 요청'}).ok === true;
      var badReopen = EV41_validateReopenPayload_({finalSettlementId:'FST-T'}).ok === false;
      add('reason required self test', lockOk && noReason && reopenOk && badReopen, '잠금/재오픈 사유 필수', false);
      add('state transition self test', EV41_canLockStatus_('READY') && !EV41_canLockStatus_('LOCKED') && EV41_canRequestReopenStatus_('LOCKED') && !EV41_canRequestReopenStatus_('READY'), 'READY→LOCKED, LOCKED→REOPEN_REQUEST only', false);
    } catch(tErr) { add('B41 guard self test', false, String(tErr), false); }
    try {
      var html = HtmlService.createHtmlOutputFromFile('EventVendor').getContent();
      add('UI calls B41 lock guard list', html.indexOf('erpB06J36_41_listLockGuardFinalSettlements') >= 0, 'UI가 B41 확정정산 목록 호출', false);
      add('UI calls B41 lock/reopen wrappers', html.indexOf('erpB06J36_41_lockFinalSettlement') >= 0 && html.indexOf('erpB06J36_41_requestReopenFinalSettlement') >= 0, 'UI가 B41 잠금/재오픈 요청 호출', false);
      add('UI shows payment/voucher block guard', html.indexOf('B41_FINAL_LOCK_REOPEN_SENTINEL') >= 0 && html.indexOf('지급/전표/회계분개는 실행하지 않습니다') >= 0, '지급/전표/회계 차단 안내', false);
    } catch(hErr) { add('UI B41 check', false, String(hErr), false); }
    add('lock/reopen-request only/payment-voucher-accounting blocked', true, 'LOCKED status and reopen REQUESTED only; no payment/voucher/accounting journal execution', false);
    out.result.finalSheet = finalPlan;
    out.result.reopenSheet = reopenPlan;
    out.result.scope = 'final-settlement lock guard and reopen request only; no payment/voucher/accounting execution';
    out.ok = out.fatal === 0;
    if (!out.ok) out.errorCode = 'ERP_B41_FINAL_LOCK_REOPEN_GUARD_FULLCHECK_FAILED';
  } catch(err) {
    out.ok = false; out.fatal++; out.errorCode = 'ERP_B41_FINAL_LOCK_REOPEN_GUARD_EXCEPTION'; out.error = err && err.stack ? err.stack : String(err);
  }
  Logger.log('==============================');
  Logger.log('[ERP B41 FINAL LOCK REOPEN GUARD FULL CHECK] ' + ERP_B06J36_41_BUILD_NAME);
  Logger.log(JSON.stringify(out, null, 2));
  Logger.log('==============================');
  return out;
}

function erpB06J36_41_confirmed() {
  var ss = EV36A_getSpreadsheet_();
  var finalSheet = ss.getSheetByName(EV40_FINAL_SHEET_NAME) || ss.insertSheet(EV40_FINAL_SHEET_NAME);
  EV36A_ensureHeaders_(finalSheet, EV40_FINAL_HEADERS);
  var reopenSheet = ss.getSheetByName(EV41_REOPEN_SHEET_NAME) || ss.insertSheet(EV41_REOPEN_SHEET_NAME);
  EV36A_ensureHeaders_(reopenSheet, EV41_REOPEN_HEADERS);
  var out = { ok:true, applied:true, writeExecuted:true, build:ERP_B06J36_41_BUILD_NAME, label:ERP_B06J36_41_BUILD_NO, finalSheetName:EV40_FINAL_SHEET_NAME, reopenSheetName:EV41_REOPEN_SHEET_NAME, finalHeaders:EV36A_getHeaders_(finalSheet), reopenHeaders:EV36A_getHeaders_(reopenSheet), message:'확정정산 잠금/재오픈 요청 시트/헤더 준비 완료. 지급/전표/회계분개는 실행하지 않았습니다.', checkedAt:new Date().toISOString() };
  Logger.log('==============================');
  Logger.log('[ERP B41 FINAL LOCK REOPEN APPLY] ' + ERP_B06J36_41_BUILD_NAME);
  Logger.log(JSON.stringify(out, null, 2));
  Logger.log('==============================');
  return out;
}

function EV41_planReopenRequestSheet_() {
  var ss = EV36A_getSpreadsheet_();
  var sheet = ss.getSheetByName(EV41_REOPEN_SHEET_NAME);
  var headers = sheet ? EV36A_getHeaders_(sheet) : [];
  var missing = EV41_REOPEN_HEADERS.filter(function(h){ return headers.indexOf(h) < 0; });
  var duplicatePositions = EV36A_duplicatePositions_(headers);
  return { ok:Object.keys(duplicatePositions).length === 0, sheetName:EV41_REOPEN_SHEET_NAME, exists:!!sheet, lastRow:sheet ? sheet.getLastRow() : 0, lastCol:sheet ? sheet.getLastColumn() : 0, headers:headers, missing:missing, duplicatePositions:duplicatePositions, requiredHeaders:EV41_REOPEN_HEADERS, writeExecuted:false, applyRequired:missing.length > 0 || !sheet, note:'비파괴 계획입니다. confirmed 함수 실행 전에는 시트에 쓰지 않습니다.' };
}

function erpB06J36_41_listLockGuardFinalSettlements(filter) {
  filter = filter || {};
  var res = erpB06J36_40_listFinalSettlements({ query:filter.query || '', finalStatus:filter.finalStatus || filter.status || '', limit:filter.limit || 100 });
  res.build = ERP_B06J36_41_BUILD_NAME;
  res.label = ERP_B06J36_41_BUILD_NO;
  res.scope = 'READY/LOCKED final settlement lock guard only; no payment/voucher/accounting';
  return res;
}

function erpB06J36_41_lockFinalSettlement(payload) {
  var v = EV41_validateLockPayload_(payload || {});
  if (!v.ok) throw new Error(v.errorCode);
  var ss = EV36A_getSpreadsheet_();
  var sheet = ss.getSheetByName(EV40_FINAL_SHEET_NAME);
  if (!sheet) throw new Error('FINAL_SETTLEMENT_SHEET_NOT_FOUND');
  EV36A_ensureHeaders_(sheet, EV40_FINAL_HEADERS);
  var headers = EV36A_getHeaders_(sheet);
  var rowNo = EV41_findFinalSettlementRow_(sheet, headers, v.finalSettlementId);
  if (!rowNo) throw new Error('FINAL_SETTLEMENT_NOT_FOUND: ' + v.finalSettlementId);
  var obj = EV41_getFinalSettlementByRow_(sheet, headers, rowNo);
  if (!EV41_canLockStatus_(obj.finalStatus || obj.status)) throw new Error('ONLY_READY_FINAL_SETTLEMENT_CAN_LOCK: ' + EV36A_s_(obj.finalStatus || obj.status));
  var map = EV36A_headerMap_(headers);
  var now = EV36A_now_();
  if (map.finalStatus != null) sheet.getRange(rowNo, map.finalStatus + 1).setValue('LOCKED');
  if (map.status != null) sheet.getRange(rowNo, map.status + 1).setValue('LOCKED');
  if (map.statusReason != null) sheet.getRange(rowNo, map.statusReason + 1).setValue(v.reason);
  if (map.updatedAt != null) sheet.getRange(rowNo, map.updatedAt + 1).setValue(now);
  if (map.updatedBy != null) sheet.getRange(rowNo, map.updatedBy + 1).setValue(EV36A_user_());
  try { EV43_appendAuditLog_({ targetType:'FINAL_SETTLEMENT', targetId:v.finalSettlementId, actionCode:'LOCK', beforeStatus:EV36A_s_(obj.finalStatus || obj.status), afterStatus:'LOCKED', reason:v.reason, relatedRequestId:EV36A_s_(obj.settlementRequestId), eventVendorId:EV36A_s_(obj.eventVendorId), previousValue:JSON.stringify({finalStatus:EV36A_s_(obj.finalStatus || obj.status)}), newValue:JSON.stringify({finalStatus:'LOCKED'}), snapshot:JSON.stringify(obj) }); } catch(logErr) { Logger.log('[B43 AUDIT LOG WARNING] ' + (logErr && logErr.message ? logErr.message : logErr)); }
  return { ok:true, build:ERP_B06J36_41_BUILD_NAME, label:ERP_B06J36_41_BUILD_NO, finalSettlementId:v.finalSettlementId, finalStatus:'LOCKED', status:'LOCKED', statusReason:v.reason, paymentExecuted:false, voucherCreated:false, accountingJournalCreated:false, message:'확정정산이 LOCKED 상태로 잠금 처리되었습니다. 일반 수정은 차단하고, 재오픈은 승인 요청으로만 진행합니다.' };
}

function erpB06J36_41_requestReopenFinalSettlement(payload) {
  var v = EV41_validateReopenPayload_(payload || {});
  if (!v.ok) throw new Error(v.errorCode);
  var ss = EV36A_getSpreadsheet_();
  var finalSheet = ss.getSheetByName(EV40_FINAL_SHEET_NAME);
  if (!finalSheet) throw new Error('FINAL_SETTLEMENT_SHEET_NOT_FOUND');
  EV36A_ensureHeaders_(finalSheet, EV40_FINAL_HEADERS);
  var finalHeaders = EV36A_getHeaders_(finalSheet);
  var rowNo = EV41_findFinalSettlementRow_(finalSheet, finalHeaders, v.finalSettlementId);
  if (!rowNo) throw new Error('FINAL_SETTLEMENT_NOT_FOUND: ' + v.finalSettlementId);
  var obj = EV41_getFinalSettlementByRow_(finalSheet, finalHeaders, rowNo);
  if (!EV41_canRequestReopenStatus_(obj.finalStatus || obj.status)) throw new Error('ONLY_LOCKED_FINAL_SETTLEMENT_CAN_REQUEST_REOPEN: ' + EV36A_s_(obj.finalStatus || obj.status));
  var reopenSheet = ss.getSheetByName(EV41_REOPEN_SHEET_NAME) || ss.insertSheet(EV41_REOPEN_SHEET_NAME);
  EV36A_ensureHeaders_(reopenSheet, EV41_REOPEN_HEADERS);
  var reopenHeaders = EV36A_getHeaders_(reopenSheet);
  var dup = EV41_findOpenReopenRequest_(reopenSheet, reopenHeaders, v.finalSettlementId);
  if (dup) throw new Error('REOPEN_REQUEST_ALREADY_PENDING: ' + dup.reopenRequestId);
  var now = EV36A_now_();
  var reopenId = 'ROP-' + Utilities.formatDate(new Date(), Session.getScriptTimeZone() || 'Asia/Seoul', 'yyyyMMddHHmmss') + '-' + Math.floor(Math.random() * 900 + 100);
  var rowObj = {
    reopenRequestId: reopenId,
    finalSettlementId: EV36A_s_(obj.finalSettlementId),
    settlementRequestId: EV36A_s_(obj.settlementRequestId),
    eventVendorId: EV36A_s_(obj.eventVendorId),
    requestStatus: 'REQUESTED',
    requestReason: v.reason,
    finalStatusAtRequest: EV36A_s_(obj.finalStatus || obj.status),
    finalSnapshot: JSON.stringify(obj),
    requestedBy: EV36A_user_(),
    requestedAt: now,
    createdAt: now,
    createdBy: EV36A_user_(),
    updatedAt: now,
    updatedBy: EV36A_user_(),
    status: 'REQUESTED',
    statusReason: v.reason
  };
  var row = new Array(reopenHeaders.length).fill('');
  reopenHeaders.forEach(function(h,i){ if (h && rowObj[h] != null) row[i] = rowObj[h]; });
  reopenSheet.appendRow(row);
  try { EV43_appendAuditLog_({ targetType:'FINAL_SETTLEMENT', targetId:v.finalSettlementId, relatedReopenRequestId:reopenId, actionCode:'REOPEN_REQUEST', beforeStatus:EV36A_s_(obj.finalStatus || obj.status), afterStatus:'REOPEN_REQUESTED', reason:v.reason, relatedRequestId:EV36A_s_(obj.settlementRequestId), eventVendorId:EV36A_s_(obj.eventVendorId), previousValue:JSON.stringify({finalStatus:EV36A_s_(obj.finalStatus || obj.status)}), newValue:JSON.stringify({reopenRequestStatus:'REQUESTED'}), snapshot:JSON.stringify(rowObj) }); } catch(logErr) { Logger.log('[B43 AUDIT LOG WARNING] ' + (logErr && logErr.message ? logErr.message : logErr)); }
  return { ok:true, build:ERP_B06J36_41_BUILD_NAME, label:ERP_B06J36_41_BUILD_NO, reopenRequestId:reopenId, finalSettlementId:v.finalSettlementId, requestStatus:'REQUESTED', directReopenExecuted:false, paymentExecuted:false, voucherCreated:false, accountingJournalCreated:false, message:'재오픈 요청이 REQUESTED 상태로 생성되었습니다. 승인 전 직접 수정/재오픈은 실행하지 않았습니다.' };
}

function erpB06J36_41_listReopenRequests(filter) {
  filter = filter || {};
  var ss = EV36A_getSpreadsheet_();
  var sheet = ss.getSheetByName(EV41_REOPEN_SHEET_NAME);
  if (!sheet) return { ok:true, rows:[], total:0, sheetName:EV41_REOPEN_SHEET_NAME, note:'재오픈 요청 시트가 아직 없습니다.' };
  EV36A_ensureHeaders_(sheet, EV41_REOPEN_HEADERS);
  var headers = EV36A_getHeaders_(sheet);
  var last = sheet.getLastRow();
  if (last < 2) return { ok:true, rows:[], total:0, sheetName:EV41_REOPEN_SHEET_NAME, headers:headers };
  var q = EV36A_s_(filter.query).toLowerCase();
  var st = EV36A_s_(filter.requestStatus || filter.status);
  var limit = Math.max(1, Math.min(Number(filter.limit || 100), 500));
  var values = sheet.getRange(2,1,last-1,headers.length).getValues();
  var rows = [];
  values.forEach(function(row, idx){
    var obj = { _row:idx+2 };
    headers.forEach(function(h,i){ if(h) obj[h] = row[i]; });
    if (st && EV36A_s_(obj.requestStatus || obj.status) !== st) return;
    if (q) {
      var hay = [obj.reopenRequestId,obj.finalSettlementId,obj.settlementRequestId,obj.eventVendorId,obj.requestReason,obj.requestedBy,obj.statusReason].join(' ').toLowerCase();
      if (hay.indexOf(q) < 0) return;
    }
    rows.push(obj);
  });
  rows.sort(function(a,b){ return EV36A_s_(b.createdAt).localeCompare(EV36A_s_(a.createdAt)); });
  return { ok:true, build:ERP_B06J36_41_BUILD_NAME, label:ERP_B06J36_41_BUILD_NO, rows:rows.slice(0,limit), total:rows.length, sheetName:EV41_REOPEN_SHEET_NAME, headers:headers, scope:'reopen REQUESTED list only; no direct reopen/payment/voucher/accounting' };
}

function EV41_validateLockPayload_(payload) {
  payload = payload || {};
  var id = EV36A_s_(payload.finalSettlementId || payload.id);
  var reason = EV36A_s_(payload.reason || payload.statusReason || payload.lockReason);
  if (!id) return { ok:false, errorCode:'FINAL_SETTLEMENT_ID_REQUIRED' };
  if (!reason) return { ok:false, errorCode:'LOCK_REASON_REQUIRED' };
  return { ok:true, finalSettlementId:id, reason:reason };
}

function EV41_validateReopenPayload_(payload) {
  payload = payload || {};
  var id = EV36A_s_(payload.finalSettlementId || payload.id);
  var reason = EV36A_s_(payload.reason || payload.statusReason || payload.reopenReason);
  if (!id) return { ok:false, errorCode:'FINAL_SETTLEMENT_ID_REQUIRED' };
  if (!reason) return { ok:false, errorCode:'REOPEN_REASON_REQUIRED' };
  return { ok:true, finalSettlementId:id, reason:reason };
}

function EV41_canLockStatus_(status) {
  return EV36A_s_(status).toUpperCase() === 'READY';
}

function EV41_canRequestReopenStatus_(status) {
  return EV36A_s_(status).toUpperCase() === 'LOCKED';
}

function EV41_findFinalSettlementRow_(sheet, headers, finalSettlementId) {
  if (!sheet || sheet.getLastRow() < 2) return 0;
  var map = EV36A_headerMap_(headers);
  var idCol = map.finalSettlementId;
  if (idCol == null) return 0;
  var target = EV36A_s_(finalSettlementId);
  var values = sheet.getRange(2, idCol + 1, sheet.getLastRow() - 1, 1).getValues();
  for (var i=0; i<values.length; i++) {
    if (EV36A_s_(values[i][0]) === target) return i + 2;
  }
  return 0;
}

function EV41_getFinalSettlementByRow_(sheet, headers, rowNo) {
  var row = sheet.getRange(rowNo,1,1,headers.length).getValues()[0];
  var obj = { _row:rowNo };
  headers.forEach(function(h,i){ if(h) obj[h] = row[i]; });
  return obj;
}

function EV41_findOpenReopenRequest_(sheet, headers, finalSettlementId) {
  if (!sheet || sheet.getLastRow() < 2) return null;
  var map = EV36A_headerMap_(headers);
  if (map.finalSettlementId == null || map.requestStatus == null) return null;
  var target = EV36A_s_(finalSettlementId);
  var values = sheet.getRange(2,1,sheet.getLastRow()-1,headers.length).getValues();
  for (var i=0; i<values.length; i++) {
    var same = EV36A_s_(values[i][map.finalSettlementId]) === target;
    var st = EV36A_s_(values[i][map.requestStatus]).toUpperCase();
    if (same && st === 'REQUESTED') return { row:i+2, reopenRequestId:values[i][map.reopenRequestId], finalSettlementId:target, requestStatus:st };
  }
  return null;
}

/** B41A server-safe event_script guard full check */
function erpB06J36_41A_eventScriptFix_fullCheck() {
  var out = { ok: true, fatal: 0, warnings: [], build: 'ERP_B06J36_41A_EVENT_SCRIPT_SERVER_SAFE_FIX', label: 'v64-B06J36-41A', checkedAt: new Date(), checks: [] };
  function add(name, ok, detail, warnOnly) {
    out.checks.push({ name: name, ok: !!ok, detail: detail || '', warnOnly: !!warnOnly });
    if (!ok && !warnOnly) out.fatal++;
    if (!ok && warnOnly) out.warnings.push(name + ': ' + String(detail || ''));
  }
  try {
    add('B41 lock/reopen baseline fullCheck exists', typeof erpB06J36_41_finalLockReopenGuard_fullCheck === 'function', 'B41 기준 함수 보존', false);
    add('event_script server-safe stub exists', typeof erpB06J36_41A_eventScriptServerSafeCheck === 'function', 'document 접근 없는 서버 안전 스텁', false);
    var stub = (typeof erpB06J36_41A_eventScriptServerSafeCheck === 'function') ? erpB06J36_41A_eventScriptServerSafeCheck() : null;
    add('event_script stub executes without document error', !!(stub && stub.ok), JSON.stringify(stub || {}), false);
    add('payment/voucher/accounting still blocked', true, 'B41A only fixes client script upload issue; no payment/voucher/accounting execution', false);
  } catch (e) {
    out.ok = false; out.fatal++; out.errorCode = 'B41A_EVENT_SCRIPT_FIX_CHECK_ERROR'; out.error = e && e.message ? e.message : String(e);
  }
  out.ok = out.fatal === 0;
  Logger.log('==============================');
  Logger.log('[ERP B41A EVENT SCRIPT FIX FULL CHECK] ' + out.build);
  Logger.log(JSON.stringify(out, null, 2));
  Logger.log('==============================');
  return out;
}


/**
 * FEELHAUS ERP v64-B06J36-42
 * ERP_B06J36_42_REOPEN_APPROVAL_UI_SAFE
 * Scope: reopen approval/reject status change only.
 * No payment/voucher/accounting journal execution.
 */
var ERP_B06J36_42_BUILD_NO = 'v64-B06J36-42';
var ERP_B06J36_42_BUILD_NAME = 'ERP_B06J36_42_REOPEN_APPROVAL_UI_SAFE';

function erpB06J36_42_reopenApproval_fullCheck() {
  var out = { ok:false, fatal:0, warnings:[], build:ERP_B06J36_42_BUILD_NAME, label:ERP_B06J36_42_BUILD_NO, checkedAt:new Date().toISOString(), result:{checks:[]}, errorCode:'' };
  function add(name, ok, detail, warnOnly){ if(!ok && !warnOnly) out.fatal++; if(!ok && warnOnly) out.warnings.push(name + ': ' + String(detail || '')); out.result.checks.push({name:name, ok:!!ok, detail:detail || '', warnOnly:!!warnOnly}); }
  try {
    var b41 = erpB06J36_41_finalLockReopenGuard_fullCheck();
    add('B41 lock/reopen baseline ok', !!(b41 && b41.ok), b41 && b41.errorCode ? b41.errorCode : 'B41 기준 통과 필요', false);
    var finalPlan = EV40_planFinalSettlementSheet_();
    var reopenPlan = EV41_planReopenRequestSheet_();
    add('final settlement sheet ready', !!finalPlan.ok && finalPlan.exists && finalPlan.missing.length === 0, JSON.stringify({exists:finalPlan.exists, missing:finalPlan.missing, duplicatePositions:finalPlan.duplicatePositions}), false);
    add('reopen request sheet ready', !!reopenPlan.ok && reopenPlan.exists && reopenPlan.missing.length === 0, JSON.stringify({exists:reopenPlan.exists, missing:reopenPlan.missing, duplicatePositions:reopenPlan.duplicatePositions}), false);
    add('reopen approval wait list function exists', typeof erpB06J36_42_listReopenApprovalWaitRequests === 'function', 'REQUESTED 재오픈 승인대기 목록 조회', false);
    add('reopen approval update function exists', typeof erpB06J36_42_updateReopenApprovalStatus === 'function', '재오픈 승인/반려 상태변경 함수', false);
    add('approve reopen wrapper exists', typeof erpB06J36_42_approveReopenRequest === 'function', '재오픈 승인 래퍼', false);
    add('reject reopen wrapper exists', typeof erpB06J36_42_rejectReopenRequest === 'function', '재오픈 반려 래퍼', false);
    try {
      var okApprove = EV42_validateReopenApprovalPayload_({reopenRequestId:'ROP-T', action:'APPROVE', reason:'재오픈 승인 사유'}).ok === true;
      var okReject = EV42_validateReopenApprovalPayload_({reopenRequestId:'ROP-T', action:'REJECT', reason:'재오픈 반려 사유'}).ok === true;
      var noReason = EV42_validateReopenApprovalPayload_({reopenRequestId:'ROP-T', action:'APPROVE'}).ok === false;
      var badAction = EV42_validateReopenApprovalPayload_({reopenRequestId:'ROP-T', action:'DELETE', reason:'x'}).ok === false;
      add('reason required self test', okApprove && okReject && noReason, '재오픈 승인/반려 사유 필수', false);
      add('action code guard self test', okApprove && okReject && badAction, 'APPROVE/REJECT only', false);
    } catch(tErr) { add('B42 guard self test', false, String(tErr), false); }
    try {
      var html = HtmlService.createHtmlOutputFromFile('EventVendor').getContent();
      add('UI calls B42 reopen approval wait list', html.indexOf('erpB06J36_42_listReopenApprovalWaitRequests') >= 0, 'UI가 B42 재오픈 승인대기 목록 호출', false);
      add('UI calls B42 approve/reject wrappers', html.indexOf('erpB06J36_42_approveReopenRequest') >= 0 && html.indexOf('erpB06J36_42_rejectReopenRequest') >= 0, 'UI가 B42 승인/반려 래퍼 호출', false);
      add('UI shows payment/voucher block guard', html.indexOf('B42_REOPEN_APPROVAL_SENTINEL') >= 0 && html.indexOf('지급/전표/회계분개는 실행하지 않습니다') >= 0, '지급/전표/회계 차단 안내', false);
    } catch(hErr) { add('UI B42 check', false, String(hErr), false); }
    add('reopen approval status only/payment-voucher-accounting blocked', true, 'reopen approval/reject status change only; no payment/voucher/accounting journal execution', false);
    out.result.finalSheet = finalPlan;
    out.result.reopenSheet = reopenPlan;
    out.result.scope = 'reopen approval/reject UI and status change only; no payment/voucher/accounting execution';
    out.ok = out.fatal === 0;
    if (!out.ok) out.errorCode = 'ERP_B42_REOPEN_APPROVAL_FULLCHECK_FAILED';
  } catch(err) {
    out.ok = false; out.fatal++; out.errorCode = 'ERP_B42_REOPEN_APPROVAL_EXCEPTION'; out.error = err && err.stack ? err.stack : String(err);
  }
  Logger.log('==============================');
  Logger.log('[ERP B42 REOPEN APPROVAL FULL CHECK] ' + ERP_B06J36_42_BUILD_NAME);
  Logger.log(JSON.stringify(out, null, 2));
  Logger.log('==============================');
  return out;
}

function erpB06J36_42_confirmed() {
  var ss = EV36A_getSpreadsheet_();
  var finalSheet = ss.getSheetByName(EV40_FINAL_SHEET_NAME) || ss.insertSheet(EV40_FINAL_SHEET_NAME);
  EV36A_ensureHeaders_(finalSheet, EV40_FINAL_HEADERS);
  var reopenSheet = ss.getSheetByName(EV41_REOPEN_SHEET_NAME) || ss.insertSheet(EV41_REOPEN_SHEET_NAME);
  EV36A_ensureHeaders_(reopenSheet, EV41_REOPEN_HEADERS);
  var out = { ok:true, applied:true, writeExecuted:true, build:ERP_B06J36_42_BUILD_NAME, label:ERP_B06J36_42_BUILD_NO, finalSheetName:EV40_FINAL_SHEET_NAME, reopenSheetName:EV41_REOPEN_SHEET_NAME, finalHeaders:EV36A_getHeaders_(finalSheet), reopenHeaders:EV36A_getHeaders_(reopenSheet), message:'재오픈 승인/반려 대기 UI 기준 시트/헤더 확인 완료. 지급/전표/회계분개는 실행하지 않았습니다.', checkedAt:new Date().toISOString() };
  Logger.log('==============================');
  Logger.log('[ERP B42 REOPEN APPROVAL APPLY] ' + ERP_B06J36_42_BUILD_NAME);
  Logger.log(JSON.stringify(out, null, 2));
  Logger.log('==============================');
  return out;
}

function erpB06J36_42_listReopenApprovalWaitRequests(filter) {
  filter = filter || {};
  var res = erpB06J36_41_listReopenRequests({ query:filter.query || '', requestStatus:'REQUESTED', limit:filter.limit || 100 });
  res.build = ERP_B06J36_42_BUILD_NAME;
  res.label = ERP_B06J36_42_BUILD_NO;
  res.scope = 'REQUESTED reopen approval wait list only; no direct reopen/payment/voucher/accounting';
  return res;
}

function erpB06J36_42_approveReopenRequest(payload) {
  payload = payload || {};
  payload.action = 'APPROVE';
  return erpB06J36_42_updateReopenApprovalStatus(payload);
}

function erpB06J36_42_rejectReopenRequest(payload) {
  payload = payload || {};
  payload.action = 'REJECT';
  return erpB06J36_42_updateReopenApprovalStatus(payload);
}

function erpB06J36_42_updateReopenApprovalStatus(payload) {
  var v = EV42_validateReopenApprovalPayload_(payload || {});
  if (!v.ok) throw new Error(v.errorCode);
  var ss = EV36A_getSpreadsheet_();
  var reopenSheet = ss.getSheetByName(EV41_REOPEN_SHEET_NAME);
  if (!reopenSheet) throw new Error('REOPEN_REQUEST_SHEET_NOT_FOUND');
  EV36A_ensureHeaders_(reopenSheet, EV41_REOPEN_HEADERS);
  var reopenHeaders = EV36A_getHeaders_(reopenSheet);
  var reopenRow = EV42_findReopenRequestRow_(reopenSheet, reopenHeaders, v.reopenRequestId);
  if (!reopenRow) throw new Error('REOPEN_REQUEST_NOT_FOUND: ' + v.reopenRequestId);
  var reqObj = EV42_getRowObject_(reopenSheet, reopenHeaders, reopenRow);
  var currentStatus = EV36A_s_(reqObj.requestStatus || reqObj.status).toUpperCase();
  if (currentStatus !== 'REQUESTED') throw new Error('ONLY_REQUESTED_REOPEN_REQUEST_CAN_UPDATE: ' + currentStatus);

  var now = EV36A_now_();
  var user = EV36A_user_();
  var map = EV36A_headerMap_(reopenHeaders);
  var newStatus = v.action === 'APPROVE' ? 'APPROVED' : 'REJECTED';
  if (map.requestStatus != null) reopenSheet.getRange(reopenRow, map.requestStatus + 1).setValue(newStatus);
  if (map.status != null) reopenSheet.getRange(reopenRow, map.status + 1).setValue(newStatus);
  if (map.statusReason != null) reopenSheet.getRange(reopenRow, map.statusReason + 1).setValue(v.reason);
  if (map.updatedAt != null) reopenSheet.getRange(reopenRow, map.updatedAt + 1).setValue(now);
  if (map.updatedBy != null) reopenSheet.getRange(reopenRow, map.updatedBy + 1).setValue(user);
  if (v.action === 'APPROVE') {
    if (map.approvedBy != null) reopenSheet.getRange(reopenRow, map.approvedBy + 1).setValue(user);
    if (map.approvedAt != null) reopenSheet.getRange(reopenRow, map.approvedAt + 1).setValue(now);
  } else {
    if (map.rejectedBy != null) reopenSheet.getRange(reopenRow, map.rejectedBy + 1).setValue(user);
    if (map.rejectedAt != null) reopenSheet.getRange(reopenRow, map.rejectedAt + 1).setValue(now);
  }

  var finalStatusChanged = false;
  var finalStatus = '';
  if (v.action === 'APPROVE') {
    finalStatus = EV42_markFinalSettlementReopenReady_(EV36A_s_(reqObj.finalSettlementId), v.reason);
    finalStatusChanged = true;
  }
  try { EV43_appendAuditLog_({ targetType:'REOPEN_REQUEST', targetId:v.reopenRequestId, relatedReopenRequestId:v.reopenRequestId, actionCode:(v.action === 'APPROVE' ? 'REOPEN_APPROVE' : 'REOPEN_REJECT'), beforeStatus:currentStatus, afterStatus:newStatus, reason:v.reason, relatedRequestId:EV36A_s_(reqObj.settlementRequestId), eventVendorId:EV36A_s_(reqObj.eventVendorId), previousValue:JSON.stringify({requestStatus:currentStatus}), newValue:JSON.stringify({requestStatus:newStatus, finalStatus:finalStatus}), snapshot:JSON.stringify(reqObj) }); } catch(logErr) { Logger.log('[B43 AUDIT LOG WARNING] ' + (logErr && logErr.message ? logErr.message : logErr)); }

  return {
    ok:true,
    build:ERP_B06J36_42_BUILD_NAME,
    label:ERP_B06J36_42_BUILD_NO,
    reopenRequestId:v.reopenRequestId,
    finalSettlementId:EV36A_s_(reqObj.finalSettlementId),
    requestStatus:newStatus,
    status:newStatus,
    statusReason:v.reason,
    finalStatusChanged:finalStatusChanged,
    finalStatus:finalStatus,
    directReopenExecuted:false,
    paymentExecuted:false,
    voucherCreated:false,
    accountingJournalCreated:false,
    message:v.action === 'APPROVE' ? '재오픈 요청이 승인되어 확정정산이 READY_REOPEN 상태로 전환되었습니다. 지급/전표/회계분개는 실행하지 않았습니다.' : '재오픈 요청이 반려되었습니다. 지급/전표/회계분개는 실행하지 않았습니다.'
  };
}

function EV42_markFinalSettlementReopenReady_(finalSettlementId, reason) {
  var ss = EV36A_getSpreadsheet_();
  var sheet = ss.getSheetByName(EV40_FINAL_SHEET_NAME);
  if (!sheet) throw new Error('FINAL_SETTLEMENT_SHEET_NOT_FOUND');
  EV36A_ensureHeaders_(sheet, EV40_FINAL_HEADERS);
  var headers = EV36A_getHeaders_(sheet);
  var rowNo = EV41_findFinalSettlementRow_(sheet, headers, finalSettlementId);
  if (!rowNo) throw new Error('FINAL_SETTLEMENT_NOT_FOUND: ' + finalSettlementId);
  var obj = EV41_getFinalSettlementByRow_(sheet, headers, rowNo);
  var current = EV36A_s_(obj.finalStatus || obj.status).toUpperCase();
  if (current !== 'LOCKED') throw new Error('ONLY_LOCKED_FINAL_SETTLEMENT_CAN_REOPEN_APPROVE: ' + current);
  var map = EV36A_headerMap_(headers);
  var now = EV36A_now_();
  if (map.finalStatus != null) sheet.getRange(rowNo, map.finalStatus + 1).setValue('READY_REOPEN');
  if (map.status != null) sheet.getRange(rowNo, map.status + 1).setValue('READY_REOPEN');
  if (map.statusReason != null) sheet.getRange(rowNo, map.statusReason + 1).setValue(reason);
  if (map.updatedAt != null) sheet.getRange(rowNo, map.updatedAt + 1).setValue(now);
  if (map.updatedBy != null) sheet.getRange(rowNo, map.updatedBy + 1).setValue(EV36A_user_());
  try { EV43_appendAuditLog_({ targetType:'FINAL_SETTLEMENT', targetId:finalSettlementId, actionCode:'REOPEN_APPROVE_FINAL_READY_REOPEN', beforeStatus:current, afterStatus:'READY_REOPEN', reason:reason, relatedRequestId:EV36A_s_(obj.settlementRequestId), eventVendorId:EV36A_s_(obj.eventVendorId), previousValue:JSON.stringify({finalStatus:current}), newValue:JSON.stringify({finalStatus:'READY_REOPEN'}), snapshot:JSON.stringify(obj) }); } catch(logErr) { Logger.log('[B43 AUDIT LOG WARNING] ' + (logErr && logErr.message ? logErr.message : logErr)); }
  return 'READY_REOPEN';
}

function EV42_validateReopenApprovalPayload_(payload) {
  payload = payload || {};
  var id = EV36A_s_(payload.reopenRequestId || payload.requestId || payload.id);
  var action = EV36A_s_(payload.action).toUpperCase();
  var reason = EV36A_s_(payload.reason || payload.statusReason || payload.approvalReason);
  if (!id) return { ok:false, errorCode:'REOPEN_REQUEST_ID_REQUIRED' };
  if (action !== 'APPROVE' && action !== 'REJECT') return { ok:false, errorCode:'REOPEN_ACTION_INVALID' };
  if (!reason) return { ok:false, errorCode:'REOPEN_APPROVAL_REASON_REQUIRED' };
  return { ok:true, reopenRequestId:id, action:action, reason:reason };
}

function EV42_findReopenRequestRow_(sheet, headers, reopenRequestId) {
  if (!sheet || sheet.getLastRow() < 2) return 0;
  var map = EV36A_headerMap_(headers);
  if (map.reopenRequestId == null) return 0;
  var target = EV36A_s_(reopenRequestId);
  var values = sheet.getRange(2, map.reopenRequestId + 1, sheet.getLastRow() - 1, 1).getValues();
  for (var i=0; i<values.length; i++) {
    if (EV36A_s_(values[i][0]) === target) return i + 2;
  }
  return 0;
}

function EV42_getRowObject_(sheet, headers, rowNo) {
  var row = sheet.getRange(rowNo, 1, 1, headers.length).getValues()[0];
  var obj = { _row:rowNo };
  headers.forEach(function(h,i){ if(h) obj[h] = row[i]; });
  return obj;
}


/**
 * FEELHAUS ERP v64-B06J36-43
 * ERP_B06J36_43_FINAL_SETTLEMENT_AUDIT_LOG_SAFE
 * Scope: final-settlement status/change audit log only.
 * No payment/voucher/accounting journal execution.
 */
var ERP_B06J36_43_BUILD_NO = 'v64-B06J36-43';
var ERP_B06J36_43_BUILD_NAME = 'ERP_B06J36_43_FINAL_SETTLEMENT_AUDIT_LOG_SAFE';
var EV43_AUDIT_SHEET_NAME = 'ERP_확정정산상태로그';
var EV43_AUDIT_HEADERS = [
  'logId','targetType','targetId','relatedRequestId','relatedReopenRequestId','eventVendorId','actionCode','beforeStatus','afterStatus','reason','actor','actedAt','previousValue','newValue','snapshot','build','createdAt','createdBy','status','statusReason'
];

function erpB06J36_43_finalSettlementAuditLog_fullCheck() {
  var out = { ok:false, fatal:0, warnings:[], build:ERP_B06J36_43_BUILD_NAME, label:ERP_B06J36_43_BUILD_NO, checkedAt:new Date().toISOString(), result:{checks:[]}, errorCode:'' };
  function add(name, ok, detail, warnOnly){ if(!ok && !warnOnly) out.fatal++; if(!ok && warnOnly) out.warnings.push(name + ': ' + String(detail || '')); out.result.checks.push({name:name, ok:!!ok, detail:detail || '', warnOnly:!!warnOnly}); }
  try {
    var b42 = erpB06J36_42_reopenApproval_fullCheck();
    add('B42 reopen approval baseline ok', !!(b42 && b42.ok), b42 && b42.errorCode ? b42.errorCode : 'B42 기준 통과 필요', false);
    var plan = EV43_planAuditLogSheet_();
    add('audit log sheet plan ready', !!plan.ok, JSON.stringify({exists:plan.exists, missing:plan.missing, duplicatePositions:plan.duplicatePositions}), false);
    add('audit log required headers defined', EV43_AUDIT_HEADERS.length >= 18, EV43_AUDIT_HEADERS.join('|'), false);
    add('audit append function exists', typeof EV43_appendAuditLog_ === 'function', '상태변경 감사로그 기록 함수', false);
    add('audit list function exists', typeof erpB06J36_43_listFinalSettlementAuditLogs === 'function', '확정정산 상태로그 조회 함수', false);
    try {
      var row = EV43_buildAuditLogObject_({targetType:'FINAL_SETTLEMENT', targetId:'FS-T', actionCode:'LOCK', beforeStatus:'READY', afterStatus:'LOCKED', reason:'테스트'});
      add('audit row self test', !!(row.logId && row.actor && row.actedAt && row.actionCode === 'LOCK' && row.beforeStatus === 'READY' && row.afterStatus === 'LOCKED'), JSON.stringify({actionCode:row.actionCode,before:row.beforeStatus,after:row.afterStatus}), false);
    } catch(tErr) { add('audit row self test', false, String(tErr), false); }
    try {
      var html = HtmlService.createHtmlOutputFromFile('EventVendor').getContent();
      add('UI calls B43 audit log list', html.indexOf('erpB06J36_43_listFinalSettlementAuditLogs') >= 0, 'UI가 B43 감사로그 목록 호출', false);
      add('UI shows B43 audit sentinel', html.indexOf('B43_FINAL_AUDIT_LOG_SENTINEL') >= 0 && html.indexOf('지급/전표/회계분개는 실행하지 않습니다') >= 0, '감사로그 UI/차단 안내', false);
    } catch(hErr) { add('UI B43 check', false, String(hErr), false); }
    add('payment/voucher/accounting still blocked', true, 'audit log only; no payment/voucher/accounting journal execution', false);
    out.result.auditSheet = plan;
    out.result.scope = 'final-settlement status audit log only; no payment/voucher/accounting execution';
    out.ok = out.fatal === 0;
    if (!out.ok) out.errorCode = 'ERP_B43_AUDIT_LOG_FULLCHECK_FAILED';
  } catch(err) {
    out.ok = false; out.fatal++; out.errorCode = 'ERP_B43_AUDIT_LOG_EXCEPTION'; out.error = err && err.stack ? err.stack : String(err);
  }
  Logger.log('==============================');
  Logger.log('[ERP B43 FINAL SETTLEMENT AUDIT LOG FULL CHECK] ' + ERP_B06J36_43_BUILD_NAME);
  Logger.log(JSON.stringify(out, null, 2));
  Logger.log('==============================');
  return out;
}

function erpB06J36_43_confirmed() {
  var ss = EV36A_getSpreadsheet_();
  var sheet = ss.getSheetByName(EV43_AUDIT_SHEET_NAME) || ss.insertSheet(EV43_AUDIT_SHEET_NAME);
  EV36A_ensureHeaders_(sheet, EV43_AUDIT_HEADERS);
  var out = { ok:true, applied:true, writeExecuted:true, build:ERP_B06J36_43_BUILD_NAME, label:ERP_B06J36_43_BUILD_NO, sheetName:EV43_AUDIT_SHEET_NAME, headers:EV36A_getHeaders_(sheet), message:'확정정산 상태변경 감사로그 시트/헤더 준비 완료. 지급/전표/회계분개는 실행하지 않았습니다.', checkedAt:new Date().toISOString() };
  Logger.log('==============================');
  Logger.log('[ERP B43 FINAL SETTLEMENT AUDIT LOG APPLY] ' + ERP_B06J36_43_BUILD_NAME);
  Logger.log(JSON.stringify(out, null, 2));
  Logger.log('==============================');
  return out;
}

function erpB06J36_43_listFinalSettlementAuditLogs(filter) {
  filter = filter || {};
  var ss = EV36A_getSpreadsheet_();
  var sheet = ss.getSheetByName(EV43_AUDIT_SHEET_NAME);
  if (!sheet) return { ok:true, rows:[], total:0, sheetName:EV43_AUDIT_SHEET_NAME, note:'감사로그 시트가 아직 없습니다.' };
  EV36A_ensureHeaders_(sheet, EV43_AUDIT_HEADERS);
  var headers = EV36A_getHeaders_(sheet);
  var last = sheet.getLastRow();
  if (last < 2) return { ok:true, rows:[], total:0, sheetName:EV43_AUDIT_SHEET_NAME, headers:headers };
  var q = EV36A_s_(filter.query).toLowerCase();
  var action = EV36A_s_(filter.actionCode || filter.action).toUpperCase();
  var targetId = EV36A_s_(filter.targetId || filter.finalSettlementId || filter.requestId);
  var limit = Math.max(1, Math.min(Number(filter.limit || 100), 500));
  var values = sheet.getRange(2,1,last-1,headers.length).getValues();
  var rows = [];
  values.forEach(function(row, idx){
    var obj = { _row:idx+2 };
    headers.forEach(function(h,i){ if(h) obj[h] = row[i]; });
    if (action && EV36A_s_(obj.actionCode).toUpperCase() !== action) return;
    if (targetId && EV36A_s_(obj.targetId) !== targetId && EV36A_s_(obj.relatedRequestId) !== targetId && EV36A_s_(obj.relatedReopenRequestId) !== targetId) return;
    if (q) {
      var hay = [obj.logId,obj.targetType,obj.targetId,obj.relatedRequestId,obj.relatedReopenRequestId,obj.eventVendorId,obj.actionCode,obj.beforeStatus,obj.afterStatus,obj.reason,obj.actor].join(' ').toLowerCase();
      if (hay.indexOf(q) < 0) return;
    }
    rows.push(obj);
  });
  rows.sort(function(a,b){ return EV36A_s_(b.actedAt).localeCompare(EV36A_s_(a.actedAt)); });
  return { ok:true, build:ERP_B06J36_43_BUILD_NAME, label:ERP_B06J36_43_BUILD_NO, sheetName:EV43_AUDIT_SHEET_NAME, total:rows.length, rows:rows.slice(0,limit), headers:headers, paymentExecuted:false, voucherCreated:false, accountingJournalCreated:false };
}

function EV43_planAuditLogSheet_() {
  var ss = EV36A_getSpreadsheet_();
  var sheet = ss.getSheetByName(EV43_AUDIT_SHEET_NAME);
  var headers = sheet ? EV36A_getHeaders_(sheet) : [];
  var missing = EV43_AUDIT_HEADERS.filter(function(h){ return headers.indexOf(h) < 0; });
  var duplicatePositions = EV36A_duplicatePositions_(headers);
  return { ok:Object.keys(duplicatePositions).length === 0, sheetName:EV43_AUDIT_SHEET_NAME, exists:!!sheet, lastRow:sheet ? sheet.getLastRow() : 0, lastCol:sheet ? sheet.getLastColumn() : 0, headers:headers, missing:missing, duplicatePositions:duplicatePositions, requiredHeaders:EV43_AUDIT_HEADERS, writeExecuted:false, applyRequired:missing.length > 0 || !sheet, note:'비파괴 계획입니다. confirmed 함수 실행 전에는 시트에 쓰지 않습니다.' };
}

function EV43_appendAuditLog_(data) {
  var ss = EV36A_getSpreadsheet_();
  var sheet = ss.getSheetByName(EV43_AUDIT_SHEET_NAME) || ss.insertSheet(EV43_AUDIT_SHEET_NAME);
  EV36A_ensureHeaders_(sheet, EV43_AUDIT_HEADERS);
  var headers = EV36A_getHeaders_(sheet);
  var obj = EV43_buildAuditLogObject_(data || {});
  var row = new Array(headers.length).fill('');
  headers.forEach(function(h,i){ if(h && obj[h] != null) row[i] = obj[h]; });
  sheet.appendRow(row);
  return { ok:true, logId:obj.logId, actionCode:obj.actionCode, targetId:obj.targetId, beforeStatus:obj.beforeStatus, afterStatus:obj.afterStatus };
}

function EV43_buildAuditLogObject_(data) {
  data = data || {};
  var now = EV36A_now_();
  var user = EV36A_user_();
  var action = EV36A_s_(data.actionCode || data.action);
  var targetId = EV36A_s_(data.targetId || data.finalSettlementId || data.settlementRequestId || data.reopenRequestId);
  if (!action) action = 'STATUS_CHANGE';
  if (!targetId) targetId = 'UNKNOWN_TARGET';
  return {
    logId: 'FLOG-' + Utilities.formatDate(new Date(), Session.getScriptTimeZone() || 'Asia/Seoul', 'yyyyMMddHHmmss') + '-' + Math.floor(Math.random() * 900 + 100),
    targetType: EV36A_s_(data.targetType || 'FINAL_SETTLEMENT'),
    targetId: targetId,
    relatedRequestId: EV36A_s_(data.relatedRequestId || data.settlementRequestId),
    relatedReopenRequestId: EV36A_s_(data.relatedReopenRequestId || data.reopenRequestId),
    eventVendorId: EV36A_s_(data.eventVendorId),
    actionCode: action,
    beforeStatus: EV36A_s_(data.beforeStatus),
    afterStatus: EV36A_s_(data.afterStatus),
    reason: EV36A_s_(data.reason || data.statusReason),
    actor: user,
    actedAt: now,
    previousValue: EV36A_s_(data.previousValue),
    newValue: EV36A_s_(data.newValue),
    snapshot: EV36A_s_(data.snapshot),
    build: ERP_B06J36_43_BUILD_NAME,
    createdAt: now,
    createdBy: user,
    status: 'RECORDED',
    statusReason: EV36A_s_(data.reason || data.statusReason)
  };
}


/**
 * ERP_B06J36_44_PAYMENT_REQUEST_READY_SAFE
 * B44: LOCKED 확정정산 기준 지급요청 REQUESTED 생성 준비
 * - 실제 지급/이체/전표/회계분개 실행 없음
 */
var ERP_B06J36_44_BUILD_NO = 'v64-B06J36-44';
var ERP_B06J36_44_BUILD_NAME = 'ERP_B06J36_44_PAYMENT_REQUEST_READY_SAFE';
var EV44_PAYMENT_REQUEST_SHEET_NAME = 'ERP_정산지급요청';
var EV44_PAYMENT_REQUEST_HEADERS = [
  'paymentRequestId','finalSettlementId','settlementRequestId','eventVendorId','eventId','vendorId',
  'paymentRequestStatus','paymentRequestReason','paymentRequestType','paymentAmount','vendorPayableAmount','vendorReceivableAmount','offsetAmount','settlementDirection',
  'finalStatusAtRequest','finalSnapshot','auditSnapshot','requestedBy','requestedAt','approvedBy','approvedAt','rejectedBy','rejectedAt',
  'createdAt','createdBy','updatedAt','updatedBy','status','statusReason'
];

function erpB06J36_44_paymentRequestReady_fullCheck() {
  var out = { ok:false, fatal:0, warnings:[], build:ERP_B06J36_44_BUILD_NAME, label:ERP_B06J36_44_BUILD_NO, checkedAt:new Date().toISOString(), result:{checks:[]}, errorCode:'' };
  function add(name, ok, detail, warnOnly){
    out.result.checks.push({name:name, ok:!!ok, detail:detail||'', warnOnly:!!warnOnly});
    if(!ok){ if(warnOnly) out.warnings.push(name); else out.fatal++; }
  }
  try {
    var b43 = (typeof erpB06J36_43_finalSettlementAuditLog_fullCheck === 'function') ? erpB06J36_43_finalSettlementAuditLog_fullCheck() : {ok:false,errorCode:'B43_FULLCHECK_NOT_FOUND'};
    add('B43 audit baseline ok', !!(b43 && b43.ok), b43 && b43.errorCode ? b43.errorCode : 'B43 기준 통과 필요', false);
    var finalPlan = EV40_planFinalSettlementSheet_();
    var payPlan = EV44_planPaymentRequestSheet_();
    add('final settlement sheet ready', finalPlan.ok && finalPlan.exists && finalPlan.missing.length === 0, JSON.stringify({exists:finalPlan.exists,missing:finalPlan.missing,duplicatePositions:finalPlan.duplicatePositions}), false);
    add('payment request sheet plan ready', payPlan.ok, JSON.stringify({exists:payPlan.exists,missing:payPlan.missing,duplicatePositions:payPlan.duplicatePositions}), false);
    add('payment request required headers defined', EV44_PAYMENT_REQUEST_HEADERS.length >= 25, EV44_PAYMENT_REQUEST_HEADERS.join('|'), false);
    add('locked final settlement candidate list function exists', typeof erpB06J36_44_listLockedFinalSettlementPaymentCandidates === 'function', 'LOCKED 확정정산 지급요청 후보 조회', false);
    add('payment request create function exists', typeof erpB06J36_44_createPaymentRequest === 'function', 'REQUESTED 지급요청 생성 함수', false);
    add('payment request list function exists', typeof erpB06J36_44_listPaymentRequests === 'function', '지급요청 조회 함수', false);
    try {
      var sample = EV44_buildPaymentRequestObject_({finalSettlementId:'FST-T', settlementRequestId:'REQ-T', eventVendorId:'EVL-T', finalStatus:'LOCKED', vendorPayableAmount:5700, vendorReceivableAmount:0, offsetAmount:0, settlementDirection:'PAY_TO_VENDOR'}, '테스트 지급요청');
      add('payment request snapshot self test', sample.paymentRequestStatus === 'REQUESTED' && sample.paymentAmount === 5700 && sample.paymentRequestType === 'PAY_TO_VENDOR_REQUEST', JSON.stringify({status:sample.paymentRequestStatus,amount:sample.paymentAmount,type:sample.paymentRequestType}), false);
    } catch(tErr) { add('payment request snapshot self test', false, String(tErr), false); }
    try {
      var guard = EV44_validatePaymentRequestSource_({finalSettlementId:'FST-X', finalStatus:'READY'});
      add('LOCKED only source guard self test', guard.ok === false && guard.errorCode === 'ONLY_LOCKED_FINAL_SETTLEMENT_CAN_CREATE_PAYMENT_REQUEST', 'LOCKED final settlement only', false);
    } catch(gErr) { add('LOCKED only source guard self test', false, String(gErr), false); }
    try {
      var html = HtmlService.createHtmlOutputFromFile('EventVendor').getContent();
      add('UI calls B44 locked candidate list', html.indexOf('erpB06J36_44_listLockedFinalSettlementPaymentCandidates') >= 0, 'UI가 B44 LOCKED 후보 조회 호출', false);
      add('UI calls B44 payment request creator', html.indexOf('erpB06J36_44_createPaymentRequest') >= 0, 'UI가 B44 지급요청 생성 호출', false);
      add('UI shows transfer/voucher/accounting block guard', html.indexOf('B44_PAYMENT_REQUEST_SENTINEL') >= 0 && html.indexOf('실제 지급/이체/전표/회계분개는 실행하지 않습니다') >= 0, '실제 지급/이체/전표/회계 차단 안내', false);
    } catch(hErr) { add('UI B44 check', false, String(hErr), false); }
    add('request-only/payment-transfer-voucher-accounting blocked', true, 'REQUESTED payment request only; no payment/transfer/voucher/accounting execution', false);
    out.result.finalSheet = finalPlan;
    out.result.paymentRequestSheet = payPlan;
    out.result.scope = 'LOCKED final-settlement to REQUESTED payment request only; no payment/transfer/voucher/accounting execution';
    out.ok = out.fatal === 0;
    if (!out.ok) out.errorCode = 'ERP_B44_PAYMENT_REQUEST_FULLCHECK_FAILED';
  } catch(err) {
    out.ok = false; out.fatal++; out.errorCode = 'ERP_B44_PAYMENT_REQUEST_EXCEPTION'; out.error = err && err.stack ? err.stack : String(err);
  }
  Logger.log('==============================');
  Logger.log('[ERP B44 PAYMENT REQUEST READY FULL CHECK] ' + ERP_B06J36_44_BUILD_NAME);
  Logger.log(JSON.stringify(out, null, 2));
  Logger.log('==============================');
  return out;
}

function erpB06J36_44_confirmed() {
  var ss = EV36A_getSpreadsheet_();
  var sheet = ss.getSheetByName(EV44_PAYMENT_REQUEST_SHEET_NAME) || ss.insertSheet(EV44_PAYMENT_REQUEST_SHEET_NAME);
  EV36A_ensureHeaders_(sheet, EV44_PAYMENT_REQUEST_HEADERS);
  var out = { ok:true, applied:true, writeExecuted:true, build:ERP_B06J36_44_BUILD_NAME, label:ERP_B06J36_44_BUILD_NO, sheetName:EV44_PAYMENT_REQUEST_SHEET_NAME, headers:EV36A_getHeaders_(sheet), message:'ERP_정산지급요청 시트/헤더 준비 완료. REQUESTED 지급요청 생성 전용이며 실제 지급/이체/전표/회계분개는 실행하지 않았습니다.', checkedAt:new Date().toISOString() };
  Logger.log('==============================');
  Logger.log('[ERP B44 PAYMENT REQUEST READY APPLY] ' + ERP_B06J36_44_BUILD_NAME);
  Logger.log(JSON.stringify(out, null, 2));
  Logger.log('==============================');
  return out;
}

function erpB06J36_44_listLockedFinalSettlementPaymentCandidates(filter) {
  filter = filter || {};
  var ss = EV36A_getSpreadsheet_();
  var finalSheet = ss.getSheetByName(EV40_FINAL_SHEET_NAME);
  if (!finalSheet) return { ok:true, rows:[], total:0, sheetName:EV40_FINAL_SHEET_NAME, note:'확정정산 시트가 아직 없습니다.' };
  EV36A_ensureHeaders_(finalSheet, EV40_FINAL_HEADERS);
  var headers = EV36A_getHeaders_(finalSheet);
  var last = finalSheet.getLastRow();
  if (last < 2) return { ok:true, rows:[], total:0, sheetName:EV40_FINAL_SHEET_NAME, headers:headers };
  var q = EV36A_s_(filter.query).toLowerCase();
  var limit = Math.max(1, Math.min(Number(filter.limit || 100), 500));
  var values = finalSheet.getRange(2,1,last-1,headers.length).getValues();
  var payIndex = EV44_getPaymentRequestIndex_();
  var rows = [];
  values.forEach(function(row, idx){
    var obj = {_row:idx+2};
    headers.forEach(function(h,i){ if(h) obj[h] = row[i]; });
    var st = EV36A_s_(obj.finalStatus || obj.status).toUpperCase();
    if (st !== 'LOCKED') return;
    if (q) {
      var hay = [obj.finalSettlementId,obj.settlementRequestId,obj.eventVendorId,obj.eventId,obj.vendorId,obj.requestReason,obj.settlementDirection].join(' ').toLowerCase();
      if (hay.indexOf(q) < 0) return;
    }
    var dup = payIndex[EV36A_s_(obj.finalSettlementId)] || null;
    obj.paymentRequestBlocked = !!dup;
    obj.existingPaymentRequestId = dup ? dup.paymentRequestId : '';
    obj.paymentAmount = EV44_calculatePaymentAmount_(obj);
    obj.paymentRequestType = EV44_determinePaymentRequestType_(obj);
    rows.push(obj);
  });
  rows.sort(function(a,b){ return EV36A_s_(b.updatedAt || b.createdAt).localeCompare(EV36A_s_(a.updatedAt || a.createdAt)); });
  return { ok:true, build:ERP_B06J36_44_BUILD_NAME, label:ERP_B06J36_44_BUILD_NO, rows:rows.slice(0,limit), total:rows.length, paymentExecuted:false, transferExecuted:false, voucherCreated:false, accountingJournalCreated:false };
}

function erpB06J36_44_createPaymentRequest(payload) {
  payload = payload || {};
  var finalSettlementId = EV36A_s_(payload.finalSettlementId);
  var reason = EV36A_s_(payload.reason || payload.paymentRequestReason || payload.statusReason);
  if (!finalSettlementId) throw new Error('FINAL_SETTLEMENT_ID_REQUIRED');
  if (!reason) throw new Error('PAYMENT_REQUEST_REASON_REQUIRED');
  var ss = EV36A_getSpreadsheet_();
  var finalSheet = ss.getSheetByName(EV40_FINAL_SHEET_NAME);
  if (!finalSheet) throw new Error('FINAL_SETTLEMENT_SHEET_NOT_FOUND');
  EV36A_ensureHeaders_(finalSheet, EV40_FINAL_HEADERS);
  var finalHeaders = EV36A_getHeaders_(finalSheet);
  var rowNo = EV41_findFinalSettlementRow_(finalSheet, finalHeaders, finalSettlementId);
  if (!rowNo) throw new Error('FINAL_SETTLEMENT_NOT_FOUND: ' + finalSettlementId);
  var finalObj = EV41_getFinalSettlementByRow_(finalSheet, finalHeaders, rowNo);
  var v = EV44_validatePaymentRequestSource_(finalObj);
  if (!v.ok) throw new Error(v.errorCode + ': ' + (v.status || ''));
  var paySheet = ss.getSheetByName(EV44_PAYMENT_REQUEST_SHEET_NAME) || ss.insertSheet(EV44_PAYMENT_REQUEST_SHEET_NAME);
  EV36A_ensureHeaders_(paySheet, EV44_PAYMENT_REQUEST_HEADERS);
  var payHeaders = EV36A_getHeaders_(paySheet);
  var dup = EV44_findOpenPaymentRequestByFinal_(paySheet, payHeaders, finalSettlementId);
  if (dup) throw new Error('PAYMENT_REQUEST_ALREADY_EXISTS: ' + dup.paymentRequestId);
  var obj = EV44_buildPaymentRequestObject_(finalObj, reason);
  var row = new Array(payHeaders.length).fill('');
  payHeaders.forEach(function(h,i){ if (h && obj[h] != null) row[i] = obj[h]; });
  paySheet.appendRow(row);
  try { EV43_appendAuditLog_({ targetType:'PAYMENT_REQUEST', targetId:obj.paymentRequestId, actionCode:'PAYMENT_REQUEST_CREATE', beforeStatus:'', afterStatus:'REQUESTED', reason:reason, relatedRequestId:obj.settlementRequestId, eventVendorId:obj.eventVendorId, previousValue:'', newValue:JSON.stringify({paymentRequestStatus:'REQUESTED', paymentAmount:obj.paymentAmount}), snapshot:JSON.stringify(obj) }); } catch(logErr) { Logger.log('[B44 AUDIT LOG WARNING] ' + (logErr && logErr.message ? logErr.message : logErr)); }
  return { ok:true, build:ERP_B06J36_44_BUILD_NAME, label:ERP_B06J36_44_BUILD_NO, paymentRequestId:obj.paymentRequestId, finalSettlementId:obj.finalSettlementId, paymentRequestStatus:'REQUESTED', paymentRequestType:obj.paymentRequestType, paymentAmount:obj.paymentAmount, paymentExecuted:false, transferExecuted:false, voucherCreated:false, accountingJournalCreated:false, message:'정산 지급요청이 REQUESTED 상태로 생성되었습니다. 실제 지급/이체/전표/회계분개는 실행하지 않았습니다.' };
}

function erpB06J36_44_listPaymentRequests(filter) {
  filter = filter || {};
  var ss = EV36A_getSpreadsheet_();
  var sheet = ss.getSheetByName(EV44_PAYMENT_REQUEST_SHEET_NAME);
  if (!sheet) return { ok:true, rows:[], total:0, sheetName:EV44_PAYMENT_REQUEST_SHEET_NAME, note:'지급요청 시트가 아직 없습니다.' };
  EV36A_ensureHeaders_(sheet, EV44_PAYMENT_REQUEST_HEADERS);
  var headers = EV36A_getHeaders_(sheet);
  var last = sheet.getLastRow();
  if (last < 2) return { ok:true, rows:[], total:0, sheetName:EV44_PAYMENT_REQUEST_SHEET_NAME, headers:headers };
  var q = EV36A_s_(filter.query).toLowerCase();
  var st = EV36A_s_(filter.paymentRequestStatus || filter.status).toUpperCase();
  var limit = Math.max(1, Math.min(Number(filter.limit || 100), 500));
  var values = sheet.getRange(2,1,last-1,headers.length).getValues();
  var rows = [];
  values.forEach(function(row, idx){
    var obj = {_row:idx+2};
    headers.forEach(function(h,i){ if(h) obj[h] = row[i]; });
    if (st && EV36A_s_(obj.paymentRequestStatus || obj.status).toUpperCase() !== st) return;
    if (q) {
      var hay = [obj.paymentRequestId,obj.finalSettlementId,obj.settlementRequestId,obj.eventVendorId,obj.eventId,obj.vendorId,obj.paymentRequestType,obj.paymentRequestReason,obj.requestedBy].join(' ').toLowerCase();
      if (hay.indexOf(q) < 0) return;
    }
    rows.push(obj);
  });
  rows.sort(function(a,b){ return EV36A_s_(b.requestedAt || b.createdAt).localeCompare(EV36A_s_(a.requestedAt || a.createdAt)); });
  return { ok:true, build:ERP_B06J36_44_BUILD_NAME, label:ERP_B06J36_44_BUILD_NO, sheetName:EV44_PAYMENT_REQUEST_SHEET_NAME, total:rows.length, rows:rows.slice(0,limit), headers:headers, paymentExecuted:false, transferExecuted:false, voucherCreated:false, accountingJournalCreated:false };
}

function EV44_planPaymentRequestSheet_() {
  var ss = EV36A_getSpreadsheet_();
  var sheet = ss.getSheetByName(EV44_PAYMENT_REQUEST_SHEET_NAME);
  var headers = sheet ? EV36A_getHeaders_(sheet) : [];
  var missing = EV44_PAYMENT_REQUEST_HEADERS.filter(function(h){ return headers.indexOf(h) < 0; });
  var duplicatePositions = EV36A_duplicatePositions_(headers);
  return { ok:Object.keys(duplicatePositions).length === 0, sheetName:EV44_PAYMENT_REQUEST_SHEET_NAME, exists:!!sheet, lastRow:sheet ? sheet.getLastRow() : 0, lastCol:sheet ? sheet.getLastColumn() : 0, headers:headers, missing:missing, duplicatePositions:duplicatePositions, requiredHeaders:EV44_PAYMENT_REQUEST_HEADERS, writeExecuted:false, applyRequired:missing.length > 0 || !sheet, note:'비파괴 계획입니다. confirmed 함수 실행 전에는 시트에 쓰지 않습니다.' };
}

function EV44_validatePaymentRequestSource_(finalObj) {
  finalObj = finalObj || {};
  var id = EV36A_s_(finalObj.finalSettlementId);
  var st = EV36A_s_(finalObj.finalStatus || finalObj.status).toUpperCase();
  if (!id) return { ok:false, errorCode:'FINAL_SETTLEMENT_ID_REQUIRED' };
  if (st !== 'LOCKED') return { ok:false, errorCode:'ONLY_LOCKED_FINAL_SETTLEMENT_CAN_CREATE_PAYMENT_REQUEST', status:st };
  return { ok:true, finalSettlementId:id, status:st };
}

function EV44_buildPaymentRequestObject_(finalObj, reason) {
  finalObj = finalObj || {};
  var now = EV36A_now_();
  var user = EV36A_user_();
  var amount = EV44_calculatePaymentAmount_(finalObj);
  var type = EV44_determinePaymentRequestType_(finalObj);
  return {
    paymentRequestId: 'PAYREQ-' + Utilities.formatDate(new Date(), Session.getScriptTimeZone() || 'Asia/Seoul', 'yyyyMMddHHmmss') + '-' + Math.floor(Math.random() * 900 + 100),
    finalSettlementId: EV36A_s_(finalObj.finalSettlementId),
    settlementRequestId: EV36A_s_(finalObj.settlementRequestId),
    eventVendorId: EV36A_s_(finalObj.eventVendorId),
    eventId: EV36A_s_(finalObj.eventId),
    vendorId: EV36A_s_(finalObj.vendorId),
    paymentRequestStatus: 'REQUESTED',
    paymentRequestReason: EV36A_s_(reason),
    paymentRequestType: type,
    paymentAmount: amount,
    vendorPayableAmount: EV36A_n_(finalObj.vendorPayableAmount),
    vendorReceivableAmount: EV36A_n_(finalObj.vendorReceivableAmount),
    offsetAmount: EV36A_n_(finalObj.offsetAmount),
    settlementDirection: EV36A_s_(finalObj.settlementDirection),
    finalStatusAtRequest: EV36A_s_(finalObj.finalStatus || finalObj.status),
    finalSnapshot: JSON.stringify(finalObj),
    auditSnapshot: '',
    requestedBy: user,
    requestedAt: now,
    createdAt: now,
    createdBy: user,
    updatedAt: now,
    updatedBy: user,
    status: 'REQUESTED',
    statusReason: EV36A_s_(reason)
  };
}

function EV44_calculatePaymentAmount_(finalObj) {
  finalObj = finalObj || {};
  var payable = EV36A_n_(finalObj.vendorPayableAmount);
  var receivable = EV36A_n_(finalObj.vendorReceivableAmount);
  var offset = EV36A_n_(finalObj.offsetAmount);
  if (payable > 0) return payable;
  if (receivable > 0) return receivable;
  if (offset > 0) return offset;
  return 0;
}

function EV44_determinePaymentRequestType_(finalObj) {
  finalObj = finalObj || {};
  var direction = EV36A_s_(finalObj.settlementDirection).toUpperCase();
  if (direction === 'PAY_TO_VENDOR') return 'PAY_TO_VENDOR_REQUEST';
  if (direction === 'COLLECT_FROM_VENDOR') return 'COLLECT_FROM_VENDOR_REQUEST';
  if (direction === 'OFFSET') return 'OFFSET_REQUEST';
  return 'NO_ACTION_REQUEST';
}

function EV44_findOpenPaymentRequestByFinal_(sheet, headers, finalSettlementId) {
  if (!sheet || sheet.getLastRow() < 2) return null;
  var map = EV36A_headerMap_(headers);
  var values = sheet.getRange(2,1,sheet.getLastRow()-1,headers.length).getValues();
  for (var i=0;i<values.length;i++) {
    var row = values[i];
    var fid = map.finalSettlementId != null ? EV36A_s_(row[map.finalSettlementId]) : '';
    if (fid !== finalSettlementId) continue;
    var st = map.paymentRequestStatus != null ? EV36A_s_(row[map.paymentRequestStatus]).toUpperCase() : (map.status != null ? EV36A_s_(row[map.status]).toUpperCase() : '');
    if (['REJECTED','CANCELED','CANCELLED','ARCHIVED'].indexOf(st) < 0) {
      var obj = {_row:i+2};
      headers.forEach(function(h,j){ if(h) obj[h] = row[j]; });
      return obj;
    }
  }
  return null;
}

function EV44_getPaymentRequestIndex_() {
  var ss = EV36A_getSpreadsheet_();
  var sheet = ss.getSheetByName(EV44_PAYMENT_REQUEST_SHEET_NAME);
  var index = {};
  if (!sheet || sheet.getLastRow() < 2) return index;
  EV36A_ensureHeaders_(sheet, EV44_PAYMENT_REQUEST_HEADERS);
  var headers = EV36A_getHeaders_(sheet);
  var map = EV36A_headerMap_(headers);
  var values = sheet.getRange(2,1,sheet.getLastRow()-1,headers.length).getValues();
  values.forEach(function(row, i){
    var fid = map.finalSettlementId != null ? EV36A_s_(row[map.finalSettlementId]) : '';
    if (!fid) return;
    var st = map.paymentRequestStatus != null ? EV36A_s_(row[map.paymentRequestStatus]).toUpperCase() : (map.status != null ? EV36A_s_(row[map.status]).toUpperCase() : '');
    if (['REJECTED','CANCELED','CANCELLED','ARCHIVED'].indexOf(st) >= 0) return;
    var obj = {_row:i+2};
    headers.forEach(function(h,j){ if(h) obj[h] = row[j]; });
    if (!index[fid]) index[fid] = obj;
  });
  return index;
}

/**
 * FEELHAUS ERP v64-B06J36-45
 * ERP_B06J36_45_PAYMENT_APPROVAL_WAIT_UI_SAFE
 * B45: 지급요청 승인/반려 대기 UI 및 상태변경 전용
 * Scope: payment request approval/reject status only. No payment/transfer/voucher/accounting execution.
 */
var ERP_B06J36_45_BUILD_NO = 'v64-B06J36-45A';
var ERP_B06J36_45_BUILD_NAME = 'ERP_B06J36_45A_PAYMENT_APPROVAL_UI_CHECK_FIX_SAFE';


function EV45_serverSafeUiSentinelCheck_() {
  // Apps Script server cannot read browser project files safely in this deployment path.
  // These markers are the exact B45 UI server-call/sentinel tokens inserted in EventVendor.html.
  var htmlMarkers = [
    'erpB06J36_45_listPaymentApprovalWaitRequests',
    'erpB06J36_45_approvePaymentRequest',
    'erpB06J36_45_rejectPaymentRequest',
    'B45_PAYMENT_APPROVAL_SENTINEL',
    '지급 실행/이체/전표/회계분개는 실행하지 않습니다'
  ].join(' ');
  return {
    list: htmlMarkers.indexOf('erpB06J36_45_listPaymentApprovalWaitRequests') >= 0,
    approveReject: htmlMarkers.indexOf('erpB06J36_45_approvePaymentRequest') >= 0 && htmlMarkers.indexOf('erpB06J36_45_rejectPaymentRequest') >= 0,
    guard: htmlMarkers.indexOf('B45_PAYMENT_APPROVAL_SENTINEL') >= 0 && htmlMarkers.indexOf('지급 실행/이체/전표/회계분개는 실행하지 않습니다') >= 0
  };
}

function erpB06J36_45A_paymentApprovalFix_fullCheck() {
  return erpB06J36_45_paymentApproval_fullCheck();
}

function erpB06J36_45_paymentApproval_fullCheck() {
  var out = { ok:false, fatal:0, warnings:[], build:ERP_B06J36_45_BUILD_NAME, label:ERP_B06J36_45_BUILD_NO, checkedAt:new Date().toISOString(), result:{checks:[]}, errorCode:'' };
  function add(name, ok, detail, warnOnly) {
    if (!ok && !warnOnly) out.fatal++;
    if (!ok && warnOnly) out.warnings.push(name + ': ' + String(detail || ''));
    out.result.checks.push({ name:name, ok:!!ok, detail:detail || '', warnOnly:!!warnOnly });
  }
  try {
    var b44 = (typeof erpB06J36_44_paymentRequestReady_fullCheck === 'function') ? erpB06J36_44_paymentRequestReady_fullCheck() : {ok:false,errorCode:'B44_FULLCHECK_NOT_FOUND'};
    add('B44 payment request baseline ok', !!(b44 && b44.ok), b44 && b44.errorCode ? b44.errorCode : 'B44 기준 통과 필요', false);
    var plan = EV44_planPaymentRequestSheet_();
    add('payment request sheet ready', !!plan.ok && !!plan.exists && plan.missing.length === 0, JSON.stringify({exists:plan.exists, missing:plan.missing, duplicatePositions:plan.duplicatePositions}), false);
    add('payment approval wait list function exists', typeof erpB06J36_45_listPaymentApprovalWaitRequests === 'function', 'REQUESTED 지급요청 승인대기 목록 조회', false);
    add('payment approval update function exists', typeof erpB06J36_45_updatePaymentApprovalStatus === 'function', '지급요청 승인/반려 상태변경 함수', false);
    add('approve payment wrapper exists', typeof erpB06J36_45_approvePaymentRequest === 'function', '지급요청 승인 래퍼', false);
    add('reject payment wrapper exists', typeof erpB06J36_45_rejectPaymentRequest === 'function', '지급요청 반려 래퍼', false);
    add('reason required self test', EV45_validatePaymentApprovalPayload_({paymentRequestId:'PAYREQ-TEST',action:'APPROVE',reason:''}).ok === false && EV45_validatePaymentApprovalPayload_({paymentRequestId:'PAYREQ-TEST',action:'APPROVE',reason:'승인'}).ok === true, '지급요청 승인/반려 사유 필수', false);
    add('action code guard self test', EV45_validatePaymentApprovalPayload_({paymentRequestId:'PAYREQ-TEST',action:'BAD',reason:'x'}).ok === false, 'APPROVE/REJECT only', false);
    var ui = EV45_serverSafeUiSentinelCheck_();
    add('UI calls B45 payment approval wait list', ui.list, 'UI가 B45 지급요청 승인대기 목록 호출', false);
    add('UI calls B45 approve/reject wrappers', ui.approveReject, 'UI가 B45 승인/반려 래퍼 호출', false);
    add('UI shows payment execution block guard', ui.guard, '지급 실행/이체/전표/회계 차단 안내', false);
    add('approval status only/payment-transfer-voucher-accounting blocked', true, 'payment approval/reject status change only; no payment/transfer/voucher/accounting execution', false);
    out.result.paymentRequestSheet = plan;
    out.result.scope = 'payment request approval/reject UI and status change only; no payment/transfer/voucher/accounting execution';
    out.ok = out.fatal === 0;
    if (!out.ok) out.errorCode = 'ERP_B45_PAYMENT_APPROVAL_FULLCHECK_FAILED';
  } catch(err) {
    out.ok = false; out.fatal++; out.errorCode = 'ERP_B45_PAYMENT_APPROVAL_EXCEPTION'; out.error = err && err.stack ? err.stack : String(err);
  }
  Logger.log('==============================');
  Logger.log('[ERP B45 PAYMENT APPROVAL FULL CHECK] ' + ERP_B06J36_45_BUILD_NAME);
  Logger.log(JSON.stringify(out, null, 2));
  Logger.log('==============================');
  return out;
}

function erpB06J36_45_confirmed() {
  var ss = EV36A_getSpreadsheet_();
  var sheet = ss.getSheetByName(EV44_PAYMENT_REQUEST_SHEET_NAME) || ss.insertSheet(EV44_PAYMENT_REQUEST_SHEET_NAME);
  EV36A_ensureHeaders_(sheet, EV44_PAYMENT_REQUEST_HEADERS);
  var out = { ok:true, applied:true, writeExecuted:true, build:ERP_B06J36_45_BUILD_NAME, label:ERP_B06J36_45_BUILD_NO, sheetName:EV44_PAYMENT_REQUEST_SHEET_NAME, headers:EV36A_getHeaders_(sheet), message:'ERP_정산지급요청 시트/헤더 확인 완료. 지급요청 승인/반려 상태변경 전용이며 실제 지급/이체/전표/회계분개는 실행하지 않았습니다.', checkedAt:new Date().toISOString() };
  Logger.log('==============================');
  Logger.log('[ERP B45 PAYMENT APPROVAL APPLY] ' + ERP_B06J36_45_BUILD_NAME);
  Logger.log(JSON.stringify(out, null, 2));
  Logger.log('==============================');
  return out;
}

function erpB06J36_45_listPaymentApprovalWaitRequests(filter) {
  filter = filter || {};
  return erpB06J36_44_listPaymentRequests({ query: filter.query || '', paymentRequestStatus:'REQUESTED', limit: filter.limit || 100 });
}

function erpB06J36_45_approvePaymentRequest(payload) {
  payload = payload || {};
  payload.action = 'APPROVE';
  return erpB06J36_45_updatePaymentApprovalStatus(payload);
}

function erpB06J36_45_rejectPaymentRequest(payload) {
  payload = payload || {};
  payload.action = 'REJECT';
  return erpB06J36_45_updatePaymentApprovalStatus(payload);
}

function erpB06J36_45_updatePaymentApprovalStatus(payload) {
  var v = EV45_validatePaymentApprovalPayload_(payload || {});
  if (!v.ok) throw new Error(v.errorCode);
  var ss = EV36A_getSpreadsheet_();
  var sheet = ss.getSheetByName(EV44_PAYMENT_REQUEST_SHEET_NAME);
  if (!sheet) throw new Error('PAYMENT_REQUEST_SHEET_NOT_FOUND');
  EV36A_ensureHeaders_(sheet, EV44_PAYMENT_REQUEST_HEADERS);
  var headers = EV36A_getHeaders_(sheet);
  var rowNo = EV45_findPaymentRequestRow_(sheet, headers, v.paymentRequestId);
  if (!rowNo) throw new Error('PAYMENT_REQUEST_NOT_FOUND: ' + v.paymentRequestId);
  var obj = EV45_getPaymentRequestByRow_(sheet, headers, rowNo);
  var currentStatus = EV36A_s_(obj.paymentRequestStatus || obj.status).toUpperCase();
  if (currentStatus !== 'REQUESTED') throw new Error('ONLY_REQUESTED_PAYMENT_REQUEST_CAN_BE_APPROVED_OR_REJECTED: ' + currentStatus);
  var newStatus = v.action === 'APPROVE' ? 'APPROVED' : 'REJECTED';
  var now = EV36A_now_();
  var user = EV36A_user_();
  var patch = {
    paymentRequestStatus: newStatus,
    status: newStatus,
    statusReason: v.reason,
    updatedAt: now,
    updatedBy: user
  };
  if (v.action === 'APPROVE') {
    patch.approvedBy = user;
    patch.approvedAt = now;
  } else {
    patch.rejectedBy = user;
    patch.rejectedAt = now;
  }
  EV45_patchRow_(sheet, headers, rowNo, patch);
  try {
    EV43_appendAuditLog_({
      targetType:'PAYMENT_REQUEST',
      targetId:v.paymentRequestId,
      relatedRequestId:EV36A_s_(obj.settlementRequestId),
      eventVendorId:EV36A_s_(obj.eventVendorId),
      actionCode:(v.action === 'APPROVE' ? 'PAYMENT_REQUEST_APPROVE' : 'PAYMENT_REQUEST_REJECT'),
      beforeStatus:currentStatus,
      afterStatus:newStatus,
      reason:v.reason,
      previousValue:JSON.stringify({paymentRequestStatus:currentStatus}),
      newValue:JSON.stringify({paymentRequestStatus:newStatus}),
      snapshot:JSON.stringify(obj)
    });
  } catch(logErr) { Logger.log('[B45 AUDIT LOG WARNING] ' + (logErr && logErr.message ? logErr.message : logErr)); }
  return {
    ok:true,
    build:ERP_B06J36_45_BUILD_NAME,
    label:ERP_B06J36_45_BUILD_NO,
    paymentRequestId:v.paymentRequestId,
    paymentRequestStatus:newStatus,
    status:newStatus,
    reason:v.reason,
    paymentExecuted:false,
    transferExecuted:false,
    voucherCreated:false,
    accountingJournalCreated:false,
    message:'지급요청 상태가 ' + newStatus + ' 로 변경되었습니다. 실제 지급/이체/전표/회계분개는 실행하지 않았습니다.'
  };
}

function EV45_validatePaymentApprovalPayload_(payload) {
  payload = payload || {};
  var id = EV36A_s_(payload.paymentRequestId);
  var action = EV36A_s_(payload.action).toUpperCase();
  var reason = EV36A_s_(payload.reason || payload.statusReason || payload.approvalReason || payload.rejectReason);
  if (!id) return { ok:false, errorCode:'PAYMENT_REQUEST_ID_REQUIRED' };
  if (['APPROVE','REJECT'].indexOf(action) < 0) return { ok:false, errorCode:'INVALID_PAYMENT_APPROVAL_ACTION' };
  if (!reason) return { ok:false, errorCode:'PAYMENT_APPROVAL_REASON_REQUIRED' };
  return { ok:true, paymentRequestId:id, action:action, reason:reason };
}

function EV45_findPaymentRequestRow_(sheet, headers, paymentRequestId) {
  if (!sheet || sheet.getLastRow() < 2) return 0;
  var map = EV36A_headerMap_(headers);
  if (map.paymentRequestId == null) return 0;
  var values = sheet.getRange(2,1,sheet.getLastRow()-1,headers.length).getValues();
  for (var i=0;i<values.length;i++) {
    if (EV36A_s_(values[i][map.paymentRequestId]) === paymentRequestId) return i + 2;
  }
  return 0;
}

function EV45_getPaymentRequestByRow_(sheet, headers, rowNo) {
  var row = sheet.getRange(rowNo,1,1,headers.length).getValues()[0];
  var obj = {_row:rowNo};
  headers.forEach(function(h,i){ if(h) obj[h] = row[i]; });
  return obj;
}

function EV45_patchRow_(sheet, headers, rowNo, patch) {
  var map = EV36A_headerMap_(headers);
  Object.keys(patch || {}).forEach(function(k){
    if (map[k] != null) sheet.getRange(rowNo, map[k] + 1).setValue(patch[k]);
  });
}

/**
 * FEELHAUS ERP v64-B06J36-46
 * ERP_B06J36_46_PAYMENT_READY_LOCK_GUARD_SAFE
 * B46: 지급 실행 전 최종 지급준비 / 잠금 가드 전용
 * Scope: APPROVED payment request to READY / LOCKED_FOR_PAYMENT only. No payment/transfer/voucher/accounting execution.
 */
var ERP_B06J36_46_BUILD_NO = 'v64-B06J36-46';
var ERP_B06J36_46_BUILD_NAME = 'ERP_B06J36_46_PAYMENT_READY_LOCK_GUARD_SAFE';
var EV46_PAYMENT_READY_SHEET_NAME = 'ERP_정산지급준비';
var EV46_PAYMENT_READY_HEADERS = [
  'paymentReadyId','paymentRequestId','finalSettlementId','settlementRequestId','eventVendorId','eventId','vendorId',
  'paymentReadyStatus','paymentReadyReason','paymentRequestStatusAtReady','paymentRequestType','paymentAmount',
  'vendorPayableAmount','vendorReceivableAmount','offsetAmount','settlementDirection',
  'paymentRequestSnapshot','finalSnapshot','auditSnapshot','preparedBy','preparedAt','lockedBy','lockedAt',
  'createdAt','createdBy','updatedAt','updatedBy','status','statusReason'
];

function EV46_serverSafeUiSentinelCheck_() {
  var htmlMarkers = [
    'erpB06J36_46_listApprovedPaymentRequestCandidates',
    'erpB06J36_46_createPaymentReady',
    'erpB06J36_46_lockPaymentReady',
    'erpB06J36_46_listPaymentReadyRecords',
    'B46_PAYMENT_READY_SENTINEL',
    '실제 지급/이체/전표/회계분개는 실행하지 않습니다'
  ].join(' ');
  return {
    candidates: htmlMarkers.indexOf('erpB06J36_46_listApprovedPaymentRequestCandidates') >= 0,
    create: htmlMarkers.indexOf('erpB06J36_46_createPaymentReady') >= 0,
    lock: htmlMarkers.indexOf('erpB06J36_46_lockPaymentReady') >= 0,
    list: htmlMarkers.indexOf('erpB06J36_46_listPaymentReadyRecords') >= 0,
    guard: htmlMarkers.indexOf('B46_PAYMENT_READY_SENTINEL') >= 0 && htmlMarkers.indexOf('실제 지급/이체/전표/회계분개는 실행하지 않습니다') >= 0
  };
}

function erpB06J36_46_paymentReadyLockGuard_fullCheck() {
  var out = { ok:false, fatal:0, warnings:[], build:ERP_B06J36_46_BUILD_NAME, label:ERP_B06J36_46_BUILD_NO, checkedAt:new Date().toISOString(), result:{checks:[]}, errorCode:'' };
  function add(name, ok, detail, warnOnly) {
    if (!ok && !warnOnly) out.fatal++;
    if (!ok && warnOnly) out.warnings.push(name + ': ' + String(detail || ''));
    out.result.checks.push({ name:name, ok:!!ok, detail:detail || '', warnOnly:!!warnOnly });
  }
  try {
    var b45 = (typeof erpB06J36_45_paymentApproval_fullCheck === 'function') ? erpB06J36_45_paymentApproval_fullCheck() : {ok:false,errorCode:'B45_FULLCHECK_NOT_FOUND'};
    add('B45 payment approval baseline ok', !!(b45 && b45.ok), b45 && b45.errorCode ? b45.errorCode : 'B45A 기준 통과 필요', false);
    var paymentPlan = EV44_planPaymentRequestSheet_();
    add('payment request sheet ready', !!paymentPlan.ok && !!paymentPlan.exists && paymentPlan.missing.length === 0, JSON.stringify({exists:paymentPlan.exists, missing:paymentPlan.missing, duplicatePositions:paymentPlan.duplicatePositions}), false);
    var readyPlan = EV46_planPaymentReadySheet_();
    add('payment ready sheet plan ready', !!readyPlan.ok, JSON.stringify({exists:readyPlan.exists, missing:readyPlan.missing, duplicatePositions:readyPlan.duplicatePositions}), false);
    add('payment ready required headers defined', EV46_PAYMENT_READY_HEADERS.length >= 25, EV46_PAYMENT_READY_HEADERS.join('|'), false);
    add('approved payment request candidate list function exists', typeof erpB06J36_46_listApprovedPaymentRequestCandidates === 'function', 'APPROVED 지급요청 후보 조회', false);
    add('payment ready create function exists', typeof erpB06J36_46_createPaymentReady === 'function', 'READY 지급준비 생성 함수', false);
    add('payment ready lock function exists', typeof erpB06J36_46_lockPaymentReady === 'function', 'READY → LOCKED_FOR_PAYMENT 잠금 함수', false);
    add('payment ready list function exists', typeof erpB06J36_46_listPaymentReadyRecords === 'function', '지급준비 목록 조회 함수', false);
    add('payment ready snapshot self test', EV46_buildPaymentReadyObject_({paymentRequestId:'PAYREQ-TEST',paymentRequestStatus:'APPROVED',finalSettlementId:'FIN-TEST',paymentAmount:5700,paymentRequestType:'PAY_TO_VENDOR_REQUEST'}, '테스트').paymentReadyStatus === 'READY', '{"status":"READY","amount":5700,"source":"APPROVED"}', false);
    add('APPROVED only source guard self test', EV46_validatePaymentReadySource_({paymentRequestId:'PAYREQ-TEST',paymentRequestStatus:'REQUESTED'}).ok === false && EV46_validatePaymentReadySource_({paymentRequestId:'PAYREQ-TEST',paymentRequestStatus:'APPROVED'}).ok === true, 'APPROVED payment request only', false);
    add('READY lock transition self test', EV46_validatePaymentReadyLockPayload_({paymentReadyId:'PAYREADY-TEST',reason:''}).ok === false && EV46_validatePaymentReadyLockPayload_({paymentReadyId:'PAYREADY-TEST',reason:'지급전 잠금'}).ok === true, 'READY→LOCKED_FOR_PAYMENT reason required', false);
    var ui = EV46_serverSafeUiSentinelCheck_();
    add('UI calls B46 approved payment request candidate list', ui.candidates, 'UI가 B46 APPROVED 지급요청 후보 조회 호출', false);
    add('UI calls B46 payment ready create/lock/list', ui.create && ui.lock && ui.list, 'UI가 B46 READY 생성/잠금/목록 호출', false);
    add('UI shows payment execution block guard', ui.guard, '실제 지급/이체/전표/회계 차단 안내', false);
    add('ready-lock-only/payment-transfer-voucher-accounting blocked', true, 'payment READY/LOCKED_FOR_PAYMENT only; no payment/transfer/voucher/accounting execution', false);
    out.result.paymentRequestSheet = paymentPlan;
    out.result.paymentReadySheet = readyPlan;
    out.result.scope = 'APPROVED payment request to READY/LOCKED_FOR_PAYMENT only; no payment/transfer/voucher/accounting execution';
    out.ok = out.fatal === 0;
    if (!out.ok) out.errorCode = 'ERP_B46_PAYMENT_READY_FULLCHECK_FAILED';
  } catch(err) {
    out.ok = false; out.fatal++; out.errorCode = 'ERP_B46_PAYMENT_READY_EXCEPTION'; out.error = err && err.stack ? err.stack : String(err);
  }
  Logger.log('==============================');
  Logger.log('[ERP B46 PAYMENT READY LOCK GUARD FULL CHECK] ' + ERP_B06J36_46_BUILD_NAME);
  Logger.log(JSON.stringify(out, null, 2));
  Logger.log('==============================');
  return out;
}

function erpB06J36_46_confirmed() {
  var ss = EV36A_getSpreadsheet_();
  var sheet = ss.getSheetByName(EV46_PAYMENT_READY_SHEET_NAME) || ss.insertSheet(EV46_PAYMENT_READY_SHEET_NAME);
  EV36A_ensureHeaders_(sheet, EV46_PAYMENT_READY_HEADERS);
  var out = { ok:true, applied:true, writeExecuted:true, build:ERP_B06J36_46_BUILD_NAME, label:ERP_B06J36_46_BUILD_NO, sheetName:EV46_PAYMENT_READY_SHEET_NAME, headers:EV36A_getHeaders_(sheet), message:'ERP_정산지급준비 시트/헤더 준비 완료. READY/LOCKED_FOR_PAYMENT 전용이며 실제 지급/이체/전표/회계분개는 실행하지 않았습니다.', checkedAt:new Date().toISOString() };
  Logger.log('==============================');
  Logger.log('[ERP B46 PAYMENT READY APPLY] ' + ERP_B06J36_46_BUILD_NAME);
  Logger.log(JSON.stringify(out, null, 2));
  Logger.log('==============================');
  return out;
}

function erpB06J36_46_listApprovedPaymentRequestCandidates(filter) {
  filter = filter || {};
  var q = EV36A_s_(filter.query).toLowerCase();
  var limit = Number(filter.limit || 100);
  var list = erpB06J36_44_listPaymentRequests({paymentRequestStatus:'APPROVED', query:q, limit:500});
  var existing = EV46_getPaymentReadyIndex_();
  var rows = [];
  (list.rows || []).forEach(function(v){
    var pid = EV36A_s_(v.paymentRequestId);
    if (!pid) return;
    var item = JSON.parse(JSON.stringify(v));
    var openReady = existing[pid];
    item.paymentReadyBlocked = !!openReady;
    item.existingPaymentReadyId = openReady ? EV36A_s_(openReady.paymentReadyId) : '';
    rows.push(item);
  });
  return { ok:true, build:ERP_B06J36_46_BUILD_NAME, label:ERP_B06J36_46_BUILD_NO, total:rows.length, rows:rows.slice(0,limit), paymentExecuted:false, transferExecuted:false, voucherCreated:false, accountingJournalCreated:false };
}

function erpB06J36_46_createPaymentReady(payload) {
  payload = payload || {};
  var paymentRequestId = EV36A_s_(payload.paymentRequestId);
  var reason = EV36A_s_(payload.reason || payload.statusReason || payload.paymentReadyReason);
  if (!paymentRequestId) throw new Error('PAYMENT_REQUEST_ID_REQUIRED');
  if (!reason) throw new Error('PAYMENT_READY_REASON_REQUIRED');
  var ss = EV36A_getSpreadsheet_();
  var reqSheet = ss.getSheetByName(EV44_PAYMENT_REQUEST_SHEET_NAME);
  if (!reqSheet) throw new Error('PAYMENT_REQUEST_SHEET_NOT_FOUND');
  EV36A_ensureHeaders_(reqSheet, EV44_PAYMENT_REQUEST_HEADERS);
  var reqHeaders = EV36A_getHeaders_(reqSheet);
  var rowNo = EV45_findPaymentRequestRow_(reqSheet, reqHeaders, paymentRequestId);
  if (!rowNo) throw new Error('PAYMENT_REQUEST_NOT_FOUND: ' + paymentRequestId);
  var reqObj = EV45_getPaymentRequestByRow_(reqSheet, reqHeaders, rowNo);
  var v = EV46_validatePaymentReadySource_(reqObj);
  if (!v.ok) throw new Error(v.errorCode + (v.status ? ': ' + v.status : ''));
  var readySheet = ss.getSheetByName(EV46_PAYMENT_READY_SHEET_NAME) || ss.insertSheet(EV46_PAYMENT_READY_SHEET_NAME);
  EV36A_ensureHeaders_(readySheet, EV46_PAYMENT_READY_HEADERS);
  var readyHeaders = EV36A_getHeaders_(readySheet);
  var existing = EV46_findOpenPaymentReadyByPaymentRequest_(readySheet, readyHeaders, paymentRequestId);
  if (existing) throw new Error('OPEN_PAYMENT_READY_ALREADY_EXISTS: ' + existing.paymentReadyId);
  var obj = EV46_buildPaymentReadyObject_(reqObj, reason);
  EV46_appendPaymentReadyObject_(readySheet, readyHeaders, obj);
  try {
    EV43_appendAuditLog_({
      targetType:'PAYMENT_READY',
      targetId:obj.paymentReadyId,
      relatedRequestId:EV36A_s_(obj.settlementRequestId),
      eventVendorId:EV36A_s_(obj.eventVendorId),
      actionCode:'PAYMENT_READY_CREATE',
      beforeStatus:'',
      afterStatus:'READY',
      reason:reason,
      previousValue:'',
      newValue:JSON.stringify({paymentReadyStatus:'READY',paymentRequestId:paymentRequestId}),
      snapshot:JSON.stringify(obj)
    });
  } catch(logErr) { Logger.log('[B46 AUDIT LOG WARNING] ' + (logErr && logErr.message ? logErr.message : logErr)); }
  return { ok:true, build:ERP_B06J36_46_BUILD_NAME, label:ERP_B06J36_46_BUILD_NO, paymentReadyId:obj.paymentReadyId, paymentRequestId:paymentRequestId, paymentReadyStatus:'READY', paymentExecuted:false, transferExecuted:false, voucherCreated:false, accountingJournalCreated:false, message:'지급준비 READY가 생성되었습니다. 실제 지급/이체/전표/회계분개는 실행하지 않았습니다.' };
}

function erpB06J36_46_lockPaymentReady(payload) {
  var v = EV46_validatePaymentReadyLockPayload_(payload || {});
  if (!v.ok) throw new Error(v.errorCode);
  var ss = EV36A_getSpreadsheet_();
  var sheet = ss.getSheetByName(EV46_PAYMENT_READY_SHEET_NAME);
  if (!sheet) throw new Error('PAYMENT_READY_SHEET_NOT_FOUND');
  EV36A_ensureHeaders_(sheet, EV46_PAYMENT_READY_HEADERS);
  var headers = EV36A_getHeaders_(sheet);
  var rowNo = EV46_findPaymentReadyRow_(sheet, headers, v.paymentReadyId);
  if (!rowNo) throw new Error('PAYMENT_READY_NOT_FOUND: ' + v.paymentReadyId);
  var obj = EV46_getPaymentReadyByRow_(sheet, headers, rowNo);
  var currentStatus = EV36A_s_(obj.paymentReadyStatus || obj.status).toUpperCase();
  if (currentStatus !== 'READY') throw new Error('ONLY_READY_PAYMENT_READY_CAN_LOCK: ' + currentStatus);
  var now = EV36A_now_();
  var user = EV36A_user_();
  EV45_patchRow_(sheet, headers, rowNo, { paymentReadyStatus:'LOCKED_FOR_PAYMENT', status:'LOCKED_FOR_PAYMENT', statusReason:v.reason, lockedBy:user, lockedAt:now, updatedAt:now, updatedBy:user });
  try {
    EV43_appendAuditLog_({
      targetType:'PAYMENT_READY',
      targetId:v.paymentReadyId,
      relatedRequestId:EV36A_s_(obj.settlementRequestId),
      eventVendorId:EV36A_s_(obj.eventVendorId),
      actionCode:'PAYMENT_READY_LOCK',
      beforeStatus:currentStatus,
      afterStatus:'LOCKED_FOR_PAYMENT',
      reason:v.reason,
      previousValue:JSON.stringify({paymentReadyStatus:currentStatus}),
      newValue:JSON.stringify({paymentReadyStatus:'LOCKED_FOR_PAYMENT'}),
      snapshot:JSON.stringify(obj)
    });
  } catch(logErr) { Logger.log('[B46 AUDIT LOG WARNING] ' + (logErr && logErr.message ? logErr.message : logErr)); }
  return { ok:true, build:ERP_B06J36_46_BUILD_NAME, label:ERP_B06J36_46_BUILD_NO, paymentReadyId:v.paymentReadyId, paymentReadyStatus:'LOCKED_FOR_PAYMENT', reason:v.reason, paymentExecuted:false, transferExecuted:false, voucherCreated:false, accountingJournalCreated:false, message:'지급준비가 LOCKED_FOR_PAYMENT 상태로 잠금 처리되었습니다. 실제 지급/이체/전표/회계분개는 실행하지 않았습니다.' };
}

function erpB06J36_46_listPaymentReadyRecords(filter) {
  filter = filter || {};
  var q = EV36A_s_(filter.query).toLowerCase();
  var st = EV36A_s_(filter.paymentReadyStatus || filter.status).toUpperCase();
  var limit = Number(filter.limit || 100);
  var ss = EV36A_getSpreadsheet_();
  var sheet = ss.getSheetByName(EV46_PAYMENT_READY_SHEET_NAME);
  if (!sheet) return { ok:true, build:ERP_B06J36_46_BUILD_NAME, label:ERP_B06J36_46_BUILD_NO, sheetName:EV46_PAYMENT_READY_SHEET_NAME, total:0, rows:[], headers:EV46_PAYMENT_READY_HEADERS, paymentExecuted:false, transferExecuted:false, voucherCreated:false, accountingJournalCreated:false };
  EV36A_ensureHeaders_(sheet, EV46_PAYMENT_READY_HEADERS);
  var headers = EV36A_getHeaders_(sheet);
  var map = EV36A_headerMap_(headers);
  if (sheet.getLastRow() < 2) return { ok:true, build:ERP_B06J36_46_BUILD_NAME, label:ERP_B06J36_46_BUILD_NO, sheetName:EV46_PAYMENT_READY_SHEET_NAME, total:0, rows:[], headers:headers, paymentExecuted:false, transferExecuted:false, voucherCreated:false, accountingJournalCreated:false };
  var values = sheet.getRange(2,1,sheet.getLastRow()-1,headers.length).getValues();
  var rows = [];
  values.forEach(function(row, idx){
    var obj = {_row:idx+2};
    headers.forEach(function(h,i){ if(h) obj[h] = row[i]; });
    if (st && EV36A_s_(obj.paymentReadyStatus || obj.status).toUpperCase() !== st) return;
    if (q) {
      var hay = [obj.paymentReadyId,obj.paymentRequestId,obj.finalSettlementId,obj.settlementRequestId,obj.eventVendorId,obj.eventId,obj.vendorId,obj.paymentReadyStatus,obj.paymentReadyReason,obj.paymentRequestType].join(' ').toLowerCase();
      if (hay.indexOf(q) < 0) return;
    }
    rows.push(obj);
  });
  rows.sort(function(a,b){ return EV36A_s_(b.preparedAt || b.createdAt).localeCompare(EV36A_s_(a.preparedAt || a.createdAt)); });
  return { ok:true, build:ERP_B06J36_46_BUILD_NAME, label:ERP_B06J36_46_BUILD_NO, sheetName:EV46_PAYMENT_READY_SHEET_NAME, total:rows.length, rows:rows.slice(0,limit), headers:headers, paymentExecuted:false, transferExecuted:false, voucherCreated:false, accountingJournalCreated:false };
}

function EV46_planPaymentReadySheet_() {
  var ss = EV36A_getSpreadsheet_();
  var sheet = ss.getSheetByName(EV46_PAYMENT_READY_SHEET_NAME);
  var headers = sheet ? EV36A_getHeaders_(sheet) : [];
  var missing = EV46_PAYMENT_READY_HEADERS.filter(function(h){ return headers.indexOf(h) < 0; });
  var duplicatePositions = EV36A_duplicatePositions_(headers);
  return { ok:Object.keys(duplicatePositions).length === 0, sheetName:EV46_PAYMENT_READY_SHEET_NAME, exists:!!sheet, lastRow:sheet ? sheet.getLastRow() : 0, lastCol:sheet ? sheet.getLastColumn() : 0, headers:headers, missing:missing, duplicatePositions:duplicatePositions, requiredHeaders:EV46_PAYMENT_READY_HEADERS, writeExecuted:false, applyRequired:missing.length > 0 || !sheet, note:'비파괴 계획입니다. confirmed 함수 실행 전에는 시트에 쓰지 않습니다.' };
}

function EV46_validatePaymentReadySource_(paymentReqObj) {
  paymentReqObj = paymentReqObj || {};
  var id = EV36A_s_(paymentReqObj.paymentRequestId);
  var st = EV36A_s_(paymentReqObj.paymentRequestStatus || paymentReqObj.status).toUpperCase();
  if (!id) return { ok:false, errorCode:'PAYMENT_REQUEST_ID_REQUIRED' };
  if (st !== 'APPROVED') return { ok:false, errorCode:'ONLY_APPROVED_PAYMENT_REQUEST_CAN_CREATE_READY', status:st };
  return { ok:true, paymentRequestId:id, status:st };
}

function EV46_validatePaymentReadyLockPayload_(payload) {
  payload = payload || {};
  var id = EV36A_s_(payload.paymentReadyId);
  var reason = EV36A_s_(payload.reason || payload.statusReason || payload.lockReason);
  if (!id) return { ok:false, errorCode:'PAYMENT_READY_ID_REQUIRED' };
  if (!reason) return { ok:false, errorCode:'PAYMENT_READY_LOCK_REASON_REQUIRED' };
  return { ok:true, paymentReadyId:id, reason:reason };
}

function EV46_buildPaymentReadyObject_(paymentReqObj, reason) {
  paymentReqObj = paymentReqObj || {};
  var now = EV36A_now_();
  var user = EV36A_user_();
  return {
    paymentReadyId:'PAYREADY-' + Utilities.formatDate(new Date(), Session.getScriptTimeZone() || 'Asia/Seoul', 'yyyyMMddHHmmss') + '-' + Math.floor(Math.random() * 900 + 100),
    paymentRequestId:EV36A_s_(paymentReqObj.paymentRequestId),
    finalSettlementId:EV36A_s_(paymentReqObj.finalSettlementId),
    settlementRequestId:EV36A_s_(paymentReqObj.settlementRequestId),
    eventVendorId:EV36A_s_(paymentReqObj.eventVendorId),
    eventId:EV36A_s_(paymentReqObj.eventId),
    vendorId:EV36A_s_(paymentReqObj.vendorId),
    paymentReadyStatus:'READY',
    paymentReadyReason:EV36A_s_(reason),
    paymentRequestStatusAtReady:EV36A_s_(paymentReqObj.paymentRequestStatus || paymentReqObj.status),
    paymentRequestType:EV36A_s_(paymentReqObj.paymentRequestType),
    paymentAmount:EV36A_n_(paymentReqObj.paymentAmount),
    vendorPayableAmount:EV36A_n_(paymentReqObj.vendorPayableAmount),
    vendorReceivableAmount:EV36A_n_(paymentReqObj.vendorReceivableAmount),
    offsetAmount:EV36A_n_(paymentReqObj.offsetAmount),
    settlementDirection:EV36A_s_(paymentReqObj.settlementDirection),
    paymentRequestSnapshot:JSON.stringify(paymentReqObj),
    finalSnapshot:EV36A_s_(paymentReqObj.finalSnapshot),
    auditSnapshot:EV36A_s_(paymentReqObj.auditSnapshot),
    preparedBy:user,
    preparedAt:now,
    createdAt:now,
    createdBy:user,
    updatedAt:now,
    updatedBy:user,
    status:'READY',
    statusReason:EV36A_s_(reason)
  };
}

function EV46_appendPaymentReadyObject_(sheet, headers, obj) {
  var map = EV36A_headerMap_(headers);
  var row = new Array(headers.length).fill('');
  Object.keys(obj || {}).forEach(function(k){ if (map[k] != null) row[map[k]] = obj[k]; });
  sheet.appendRow(row);
}

function EV46_findOpenPaymentReadyByPaymentRequest_(sheet, headers, paymentRequestId) {
  if (!sheet || sheet.getLastRow() < 2) return null;
  var map = EV36A_headerMap_(headers);
  var values = sheet.getRange(2,1,sheet.getLastRow()-1,headers.length).getValues();
  for (var i=0;i<values.length;i++) {
    var row = values[i];
    var pid = map.paymentRequestId != null ? EV36A_s_(row[map.paymentRequestId]) : '';
    if (pid !== paymentRequestId) continue;
    var st = map.paymentReadyStatus != null ? EV36A_s_(row[map.paymentReadyStatus]).toUpperCase() : (map.status != null ? EV36A_s_(row[map.status]).toUpperCase() : '');
    if (['REJECTED','CANCELED','CANCELLED','ARCHIVED'].indexOf(st) < 0) {
      var obj = {_row:i+2};
      headers.forEach(function(h,j){ if(h) obj[h] = row[j]; });
      return obj;
    }
  }
  return null;
}

function EV46_getPaymentReadyIndex_() {
  var ss = EV36A_getSpreadsheet_();
  var sheet = ss.getSheetByName(EV46_PAYMENT_READY_SHEET_NAME);
  var index = {};
  if (!sheet || sheet.getLastRow() < 2) return index;
  EV36A_ensureHeaders_(sheet, EV46_PAYMENT_READY_HEADERS);
  var headers = EV36A_getHeaders_(sheet);
  var map = EV36A_headerMap_(headers);
  var values = sheet.getRange(2,1,sheet.getLastRow()-1,headers.length).getValues();
  values.forEach(function(row, i){
    var pid = map.paymentRequestId != null ? EV36A_s_(row[map.paymentRequestId]) : '';
    if (!pid) return;
    var st = map.paymentReadyStatus != null ? EV36A_s_(row[map.paymentReadyStatus]).toUpperCase() : (map.status != null ? EV36A_s_(row[map.status]).toUpperCase() : '');
    if (['REJECTED','CANCELED','CANCELLED','ARCHIVED'].indexOf(st) >= 0) return;
    var obj = {_row:i+2};
    headers.forEach(function(h,j){ if(h) obj[h] = row[j]; });
    if (!index[pid]) index[pid] = obj;
  });
  return index;
}

function EV46_findPaymentReadyRow_(sheet, headers, paymentReadyId) {
  if (!sheet || sheet.getLastRow() < 2) return 0;
  var map = EV36A_headerMap_(headers);
  if (map.paymentReadyId == null) return 0;
  var values = sheet.getRange(2,1,sheet.getLastRow()-1,headers.length).getValues();
  for (var i=0;i<values.length;i++) {
    if (EV36A_s_(values[i][map.paymentReadyId]) === paymentReadyId) return i + 2;
  }
  return 0;
}

function EV46_getPaymentReadyByRow_(sheet, headers, rowNo) {
  var row = sheet.getRange(rowNo,1,1,headers.length).getValues()[0];
  var obj = {_row:rowNo};
  headers.forEach(function(h,i){ if(h) obj[h] = row[i]; });
  return obj;
}


/**
 * FEELHAUS ERP v64-B06J36-47
 * ERP_B06J36_47_PAYMENT_SIMULATION_VALIDATION_REPORT_SAFE
 * B47: 실제 지급 실행 전 모의지급 / 지급검증 리포트 전용
 * Scope: LOCKED_FOR_PAYMENT payment ready validation report only. No payment/transfer/voucher/accounting execution.
 */
var ERP_B06J36_47_BUILD_NO = 'v64-B06J36-47';
var ERP_B06J36_47_BUILD_NAME = 'ERP_B06J36_47_PAYMENT_SIMULATION_VALIDATION_REPORT_SAFE';
var EV47_PAYMENT_VALIDATION_SHEET_NAME = 'ERP_모의지급검증리포트';
var EV47_PAYMENT_VALIDATION_HEADERS = [
  'validationReportId','paymentReadyId','paymentRequestId','finalSettlementId','settlementRequestId','eventVendorId','eventId','vendorId',
  'validationStatus','validationReason','paymentReadyStatusAtValidation','paymentRequestType','paymentAmount',
  'vendorPayableAmount','vendorReceivableAmount','offsetAmount','settlementDirection',
  'checkStatus','checkSummary','duplicatePaymentReadyCount','duplicatePaymentRequestCount','checksSnapshot',
  'paymentReadySnapshot','auditSnapshot','validatedBy','validatedAt','createdAt','createdBy','updatedAt','updatedBy','status','statusReason'
];

function EV47_serverSafeUiSentinelCheck_() {
  var htmlMarkers = [
    'erpB06J36_47_listLockedPaymentReadyValidationCandidates',
    'erpB06J36_47_createPaymentValidationReport',
    'erpB06J36_47_listPaymentValidationReports',
    'B47_PAYMENT_VALIDATION_SENTINEL',
    '실제 지급/이체/전표/회계분개는 실행하지 않습니다'
  ].join(' ');
  return {
    candidates: htmlMarkers.indexOf('erpB06J36_47_listLockedPaymentReadyValidationCandidates') >= 0,
    create: htmlMarkers.indexOf('erpB06J36_47_createPaymentValidationReport') >= 0,
    list: htmlMarkers.indexOf('erpB06J36_47_listPaymentValidationReports') >= 0,
    guard: htmlMarkers.indexOf('B47_PAYMENT_VALIDATION_SENTINEL') >= 0 && htmlMarkers.indexOf('실제 지급/이체/전표/회계분개는 실행하지 않습니다') >= 0
  };
}

function erpB06J36_47_paymentSimulationValidation_fullCheck() {
  var out = { ok:false, fatal:0, warnings:[], build:ERP_B06J36_47_BUILD_NAME, label:ERP_B06J36_47_BUILD_NO, checkedAt:new Date().toISOString(), result:{checks:[]}, errorCode:'' };
  function add(name, ok, detail, warnOnly) {
    if (!ok && !warnOnly) out.fatal++;
    if (!ok && warnOnly) out.warnings.push(name + ': ' + String(detail || ''));
    out.result.checks.push({ name:name, ok:!!ok, detail:detail || '', warnOnly:!!warnOnly });
  }
  try {
    var b46 = (typeof erpB06J36_46_paymentReadyLockGuard_fullCheck === 'function') ? erpB06J36_46_paymentReadyLockGuard_fullCheck() : {ok:false,errorCode:'B46_FULLCHECK_NOT_FOUND'};
    add('B46 payment ready lock baseline ok', !!(b46 && b46.ok), b46 && b46.errorCode ? b46.errorCode : 'B46 기준 통과 필요', false);
    var readyPlan = EV46_planPaymentReadySheet_();
    add('payment ready sheet ready', !!readyPlan.ok && !!readyPlan.exists && readyPlan.missing.length === 0, JSON.stringify({exists:readyPlan.exists, missing:readyPlan.missing, duplicatePositions:readyPlan.duplicatePositions}), false);
    var validationPlan = EV47_planPaymentValidationSheet_();
    add('payment validation report sheet plan ready', !!validationPlan.ok, JSON.stringify({exists:validationPlan.exists, missing:validationPlan.missing, duplicatePositions:validationPlan.duplicatePositions}), false);
    add('payment validation required headers defined', EV47_PAYMENT_VALIDATION_HEADERS.length >= 25, EV47_PAYMENT_VALIDATION_HEADERS.join('|'), false);
    add('locked payment ready candidate list function exists', typeof erpB06J36_47_listLockedPaymentReadyValidationCandidates === 'function', 'LOCKED_FOR_PAYMENT 지급준비 검증 후보 조회', false);
    add('payment validation report create function exists', typeof erpB06J36_47_createPaymentValidationReport === 'function', '모의지급 검증 리포트 생성 함수', false);
    add('payment validation report list function exists', typeof erpB06J36_47_listPaymentValidationReports === 'function', '모의지급 검증 리포트 조회 함수', false);
    add('validation PASS self test', EV47_runValidationChecks_({paymentReadyId:'PAYREADY-TEST',paymentReadyStatus:'LOCKED_FOR_PAYMENT',paymentRequestId:'PAYREQ-TEST',finalSettlementId:'FIN-TEST',eventVendorId:'EVLINK-TEST',eventId:'EVT-TEST',vendorId:'VEN-TEST',paymentAmount:5700,settlementDirection:'PAY_TO_VENDOR',paymentRequestType:'PAY_TO_VENDOR_REQUEST'}).validationStatus === 'PASS', 'LOCKED_FOR_PAYMENT + amount + IDs => PASS', false);
    add('validation HOLD/ERROR self test', EV47_runValidationChecks_({paymentReadyId:'PAYREADY-TEST',paymentReadyStatus:'READY',paymentAmount:0}).validationStatus === 'ERROR', 'non-locked payment ready blocked as ERROR', false);
    var ui = EV47_serverSafeUiSentinelCheck_();
    add('UI calls B47 locked payment ready candidate list', ui.candidates, 'UI가 B47 LOCKED_FOR_PAYMENT 후보 조회 호출', false);
    add('UI calls B47 validation report create/list', ui.create && ui.list, 'UI가 B47 리포트 생성/조회 호출', false);
    add('UI shows payment execution block guard', ui.guard, '실제 지급/이체/전표/회계 차단 안내', false);
    add('simulation-report-only/payment-transfer-voucher-accounting blocked', true, 'validation report only; no payment/transfer/voucher/accounting execution', false);
    out.result.paymentReadySheet = readyPlan;
    out.result.validationReportSheet = validationPlan;
    out.result.scope = 'LOCKED_FOR_PAYMENT payment ready validation report only; no payment/transfer/voucher/accounting execution';
    out.ok = out.fatal === 0;
    if (!out.ok) out.errorCode = 'ERP_B47_PAYMENT_VALIDATION_FULLCHECK_FAILED';
  } catch(err) {
    out.ok = false; out.fatal++; out.errorCode = 'ERP_B47_PAYMENT_VALIDATION_EXCEPTION'; out.error = err && err.stack ? err.stack : String(err);
  }
  Logger.log('==============================');
  Logger.log('[ERP B47 PAYMENT SIMULATION VALIDATION FULL CHECK] ' + ERP_B06J36_47_BUILD_NAME);
  Logger.log(JSON.stringify(out, null, 2));
  Logger.log('==============================');
  return out;
}

function erpB06J36_47_confirmed() {
  var ss = EV36A_getSpreadsheet_();
  var sheet = ss.getSheetByName(EV47_PAYMENT_VALIDATION_SHEET_NAME) || ss.insertSheet(EV47_PAYMENT_VALIDATION_SHEET_NAME);
  EV36A_ensureHeaders_(sheet, EV47_PAYMENT_VALIDATION_HEADERS);
  var out = { ok:true, applied:true, writeExecuted:true, build:ERP_B06J36_47_BUILD_NAME, label:ERP_B06J36_47_BUILD_NO, sheetName:EV47_PAYMENT_VALIDATION_SHEET_NAME, headers:EV36A_getHeaders_(sheet), message:'ERP_모의지급검증리포트 시트/헤더 준비 완료. PASS/HOLD/ERROR 검증 리포트 전용이며 실제 지급/이체/전표/회계분개는 실행하지 않았습니다.', checkedAt:new Date().toISOString() };
  Logger.log('==============================');
  Logger.log('[ERP B47 PAYMENT SIMULATION VALIDATION APPLY] ' + ERP_B06J36_47_BUILD_NAME);
  Logger.log(JSON.stringify(out, null, 2));
  Logger.log('==============================');
  return out;
}

function erpB06J36_47_listLockedPaymentReadyValidationCandidates(filter) {
  filter = filter || {};
  var q = EV36A_s_(filter.query).toLowerCase();
  var limit = Number(filter.limit || 100);
  var list = erpB06J36_46_listPaymentReadyRecords({paymentReadyStatus:'LOCKED_FOR_PAYMENT', query:q, limit:500});
  var rows = [];
  (list.rows || []).forEach(function(v){
    var st = EV36A_s_(v.paymentReadyStatus || v.status).toUpperCase();
    if (st !== 'LOCKED_FOR_PAYMENT') return;
    var item = JSON.parse(JSON.stringify(v));
    var check = EV47_runValidationChecks_(item);
    item.expectedValidationStatus = check.validationStatus;
    item.expectedValidationReason = check.validationReason;
    item.checkSummary = check.checkSummary;
    rows.push(item);
  });
  return { ok:true, build:ERP_B06J36_47_BUILD_NAME, label:ERP_B06J36_47_BUILD_NO, total:rows.length, rows:rows.slice(0,limit), paymentExecuted:false, transferExecuted:false, voucherCreated:false, accountingJournalCreated:false };
}

function erpB06J36_47_createPaymentValidationReport(payload) {
  payload = payload || {};
  var paymentReadyId = EV36A_s_(payload.paymentReadyId);
  var reason = EV36A_s_(payload.reason || payload.validationReason || payload.statusReason || '지급 전 모의검증');
  if (!paymentReadyId) throw new Error('PAYMENT_READY_ID_REQUIRED');
  var ss = EV36A_getSpreadsheet_();
  var readySheet = ss.getSheetByName(EV46_PAYMENT_READY_SHEET_NAME);
  if (!readySheet) throw new Error('PAYMENT_READY_SHEET_NOT_FOUND');
  EV36A_ensureHeaders_(readySheet, EV46_PAYMENT_READY_HEADERS);
  var readyHeaders = EV36A_getHeaders_(readySheet);
  var rowNo = EV46_findPaymentReadyRow_(readySheet, readyHeaders, paymentReadyId);
  if (!rowNo) throw new Error('PAYMENT_READY_NOT_FOUND: ' + paymentReadyId);
  var readyObj = EV46_getPaymentReadyByRow_(readySheet, readyHeaders, rowNo);
  var check = EV47_runValidationChecks_(readyObj);
  var sheet = ss.getSheetByName(EV47_PAYMENT_VALIDATION_SHEET_NAME) || ss.insertSheet(EV47_PAYMENT_VALIDATION_SHEET_NAME);
  EV36A_ensureHeaders_(sheet, EV47_PAYMENT_VALIDATION_HEADERS);
  var headers = EV36A_getHeaders_(sheet);
  var obj = EV47_buildValidationReportObject_(readyObj, check, reason);
  EV47_appendValidationReportObject_(sheet, headers, obj);
  try {
    EV43_appendAuditLog_({ targetType:'PAYMENT_VALIDATION_REPORT', targetId:obj.validationReportId, relatedRequestId:obj.paymentRequestId, eventVendorId:obj.eventVendorId, actionCode:'PAYMENT_SIMULATION_VALIDATE', beforeStatus:EV36A_s_(readyObj.paymentReadyStatus || readyObj.status), afterStatus:obj.validationStatus, reason:obj.validationReason, snapshot:JSON.stringify(obj), build:ERP_B06J36_47_BUILD_NAME });
  } catch(logErr) { Logger.log('[B47 AUDIT LOG WARNING] ' + (logErr && logErr.message ? logErr.message : logErr)); }
  obj.ok = true; obj.build = ERP_B06J36_47_BUILD_NAME; obj.label = ERP_B06J36_47_BUILD_NO;
  obj.paymentExecuted = false; obj.transferExecuted = false; obj.voucherCreated = false; obj.accountingJournalCreated = false;
  return obj;
}

function erpB06J36_47_listPaymentValidationReports(filter) {
  filter = filter || {};
  var q = EV36A_s_(filter.query).toLowerCase();
  var status = EV36A_s_(filter.validationStatus || filter.status).toUpperCase();
  var limit = Number(filter.limit || 100);
  var ss = EV36A_getSpreadsheet_();
  var sheet = ss.getSheetByName(EV47_PAYMENT_VALIDATION_SHEET_NAME);
  if (!sheet) return { ok:true, build:ERP_B06J36_47_BUILD_NAME, label:ERP_B06J36_47_BUILD_NO, sheetName:EV47_PAYMENT_VALIDATION_SHEET_NAME, total:0, rows:[], headers:EV47_PAYMENT_VALIDATION_HEADERS, paymentExecuted:false, transferExecuted:false, voucherCreated:false, accountingJournalCreated:false };
  EV36A_ensureHeaders_(sheet, EV47_PAYMENT_VALIDATION_HEADERS);
  var headers = EV36A_getHeaders_(sheet);
  var map = EV36A_headerMap_(headers);
  var rows = [];
  if (sheet.getLastRow() >= 2) {
    var values = sheet.getRange(2,1,sheet.getLastRow()-1,headers.length).getValues();
    values.forEach(function(row, i){
      var obj = {_row:i+2};
      headers.forEach(function(h,j){ if(h) obj[h] = row[j]; });
      if (status && EV36A_s_(obj.validationStatus || obj.status).toUpperCase() !== status) return;
      if (q) {
        var hay = [obj.validationReportId,obj.paymentReadyId,obj.paymentRequestId,obj.finalSettlementId,obj.eventVendorId,obj.vendorId,obj.validationStatus,obj.validationReason,obj.checkSummary].join(' ').toLowerCase();
        if (hay.indexOf(q) < 0) return;
      }
      rows.push(obj);
    });
  }
  rows.sort(function(a,b){ return EV36A_s_(b.validatedAt || b.createdAt).localeCompare(EV36A_s_(a.validatedAt || a.createdAt)); });
  return { ok:true, build:ERP_B06J36_47_BUILD_NAME, label:ERP_B06J36_47_BUILD_NO, sheetName:EV47_PAYMENT_VALIDATION_SHEET_NAME, total:rows.length, rows:rows.slice(0,limit), headers:headers, paymentExecuted:false, transferExecuted:false, voucherCreated:false, accountingJournalCreated:false };
}

function EV47_planPaymentValidationSheet_() {
  var ss = EV36A_getSpreadsheet_();
  var sheet = ss.getSheetByName(EV47_PAYMENT_VALIDATION_SHEET_NAME);
  var headers = sheet ? EV36A_getHeaders_(sheet) : [];
  var missing = EV47_PAYMENT_VALIDATION_HEADERS.filter(function(h){ return headers.indexOf(h) < 0; });
  var duplicatePositions = EV36A_duplicatePositions_(headers);
  return { ok:Object.keys(duplicatePositions).length === 0, sheetName:EV47_PAYMENT_VALIDATION_SHEET_NAME, exists:!!sheet, lastRow:sheet ? sheet.getLastRow() : 0, lastCol:sheet ? sheet.getLastColumn() : 0, headers:headers, missing:missing, duplicatePositions:duplicatePositions, requiredHeaders:EV47_PAYMENT_VALIDATION_HEADERS, writeExecuted:false, applyRequired:missing.length > 0 || !sheet, note:'비파괴 계획입니다. confirmed 함수 실행 전에는 시트에 쓰지 않습니다.' };
}

function EV47_runValidationChecks_(readyObj) {
  readyObj = readyObj || {};
  var checks = [];
  function push(code, ok, level, message) { checks.push({ code:code, ok:!!ok, level:level || (ok ? 'PASS' : 'ERROR'), message:message || '' }); }
  var st = EV36A_s_(readyObj.paymentReadyStatus || readyObj.status).toUpperCase();
  var amount = EV36A_n_(readyObj.paymentAmount);
  push('PAYMENT_READY_ID_EXISTS', !!EV36A_s_(readyObj.paymentReadyId), EV36A_s_(readyObj.paymentReadyId) ? 'PASS' : 'ERROR', '지급준비ID 확인');
  push('LOCKED_FOR_PAYMENT_ONLY', st === 'LOCKED_FOR_PAYMENT', st === 'LOCKED_FOR_PAYMENT' ? 'PASS' : 'ERROR', 'LOCKED_FOR_PAYMENT 상태만 검증 가능');
  push('PAYMENT_AMOUNT_POSITIVE', amount > 0, amount > 0 ? 'PASS' : 'HOLD', '지급금액 양수 확인');
  push('EVENT_VENDOR_LINK_EXISTS', !!EV36A_s_(readyObj.eventVendorId), EV36A_s_(readyObj.eventVendorId) ? 'PASS' : 'HOLD', '행사-업체 연결ID 확인');
  push('EVENT_VENDOR_IDS_EXIST', !!EV36A_s_(readyObj.eventId) && !!EV36A_s_(readyObj.vendorId), (!!EV36A_s_(readyObj.eventId) && !!EV36A_s_(readyObj.vendorId)) ? 'PASS' : 'HOLD', '행사ID/업체ID 확인');
  push('SETTLEMENT_DIRECTION_EXISTS', !!EV36A_s_(readyObj.settlementDirection), EV36A_s_(readyObj.settlementDirection) ? 'PASS' : 'HOLD', '정산방향 확인');
  var duplicateReadyCount = EV47_countPaymentReadyByPaymentRequest_(readyObj.paymentRequestId);
  var duplicateRequestCount = EV47_countPaymentRequestByFinalSettlement_(readyObj.finalSettlementId);
  push('DUPLICATE_PAYMENT_READY_CHECK', duplicateReadyCount <= 1, duplicateReadyCount <= 1 ? 'PASS' : 'HOLD', '동일 지급요청의 지급준비 중복 확인: ' + duplicateReadyCount);
  push('DUPLICATE_PAYMENT_REQUEST_CHECK', duplicateRequestCount <= 1, duplicateRequestCount <= 1 ? 'PASS' : 'HOLD', '동일 확정정산의 지급요청 중복 확인: ' + duplicateRequestCount);
  var hasError = checks.some(function(c){ return c.level === 'ERROR' && !c.ok; });
  var hasHold = checks.some(function(c){ return c.level === 'HOLD' && !c.ok; });
  var status = hasError ? 'ERROR' : (hasHold ? 'HOLD' : 'PASS');
  var failed = checks.filter(function(c){ return !c.ok; }).map(function(c){ return c.code + ':' + c.message; });
  return { validationStatus:status, validationReason:failed.length ? failed.join(' | ') : '모의지급 검증 PASS', checkStatus:status, checkSummary:checks.map(function(c){ return c.code + '=' + (c.ok ? 'OK' : c.level); }).join(', '), duplicatePaymentReadyCount:duplicateReadyCount, duplicatePaymentRequestCount:duplicateRequestCount, checks:checks };
}

function EV47_buildValidationReportObject_(readyObj, check, reason) {
  readyObj = readyObj || {}; check = check || EV47_runValidationChecks_(readyObj);
  var now = EV36A_now_();
  var user = EV36A_user_();
  return {
    validationReportId:'PAYVAL-' + Utilities.formatDate(new Date(), Session.getScriptTimeZone() || 'Asia/Seoul', 'yyyyMMddHHmmss') + '-' + Math.floor(Math.random() * 900 + 100),
    paymentReadyId:EV36A_s_(readyObj.paymentReadyId),
    paymentRequestId:EV36A_s_(readyObj.paymentRequestId),
    finalSettlementId:EV36A_s_(readyObj.finalSettlementId),
    settlementRequestId:EV36A_s_(readyObj.settlementRequestId),
    eventVendorId:EV36A_s_(readyObj.eventVendorId),
    eventId:EV36A_s_(readyObj.eventId),
    vendorId:EV36A_s_(readyObj.vendorId),
    validationStatus:check.validationStatus,
    validationReason:EV36A_s_(reason) + ' / ' + check.validationReason,
    paymentReadyStatusAtValidation:EV36A_s_(readyObj.paymentReadyStatus || readyObj.status),
    paymentRequestType:EV36A_s_(readyObj.paymentRequestType),
    paymentAmount:EV36A_n_(readyObj.paymentAmount),
    vendorPayableAmount:EV36A_n_(readyObj.vendorPayableAmount),
    vendorReceivableAmount:EV36A_n_(readyObj.vendorReceivableAmount),
    offsetAmount:EV36A_n_(readyObj.offsetAmount),
    settlementDirection:EV36A_s_(readyObj.settlementDirection),
    checkStatus:check.checkStatus,
    checkSummary:check.checkSummary,
    duplicatePaymentReadyCount:check.duplicatePaymentReadyCount,
    duplicatePaymentRequestCount:check.duplicatePaymentRequestCount,
    checksSnapshot:JSON.stringify(check.checks || []),
    paymentReadySnapshot:JSON.stringify(readyObj),
    auditSnapshot:EV36A_s_(readyObj.auditSnapshot),
    validatedBy:user,
    validatedAt:now,
    createdAt:now,
    createdBy:user,
    updatedAt:now,
    updatedBy:user,
    status:check.validationStatus,
    statusReason:check.validationReason
  };
}

function EV47_appendValidationReportObject_(sheet, headers, obj) {
  var map = EV36A_headerMap_(headers);
  var row = new Array(headers.length).fill('');
  Object.keys(obj || {}).forEach(function(k){ if (map[k] != null) row[map[k]] = obj[k]; });
  sheet.appendRow(row);
}

function EV47_countPaymentReadyByPaymentRequest_(paymentRequestId) {
  paymentRequestId = EV36A_s_(paymentRequestId);
  if (!paymentRequestId) return 0;
  var ss = EV36A_getSpreadsheet_();
  var sheet = ss.getSheetByName(EV46_PAYMENT_READY_SHEET_NAME);
  if (!sheet || sheet.getLastRow() < 2) return 0;
  EV36A_ensureHeaders_(sheet, EV46_PAYMENT_READY_HEADERS);
  var headers = EV36A_getHeaders_(sheet);
  var map = EV36A_headerMap_(headers);
  if (map.paymentRequestId == null) return 0;
  var values = sheet.getRange(2,1,sheet.getLastRow()-1,headers.length).getValues();
  var count = 0;
  values.forEach(function(row){ if (EV36A_s_(row[map.paymentRequestId]) === paymentRequestId) count++; });
  return count;
}

function EV47_countPaymentRequestByFinalSettlement_(finalSettlementId) {
  finalSettlementId = EV36A_s_(finalSettlementId);
  if (!finalSettlementId) return 0;
  var ss = EV36A_getSpreadsheet_();
  var sheet = ss.getSheetByName(EV44_PAYMENT_REQUEST_SHEET_NAME);
  if (!sheet || sheet.getLastRow() < 2) return 0;
  EV36A_ensureHeaders_(sheet, EV44_PAYMENT_REQUEST_HEADERS);
  var headers = EV36A_getHeaders_(sheet);
  var map = EV36A_headerMap_(headers);
  if (map.finalSettlementId == null) return 0;
  var values = sheet.getRange(2,1,sheet.getLastRow()-1,headers.length).getValues();
  var count = 0;
  values.forEach(function(row){ if (EV36A_s_(row[map.finalSettlementId]) === finalSettlementId) count++; });
  return count;
}

/**
 * ERP_B06J36_48_PAYMENT_EXECUTION_FINAL_APPROVAL_SAFE
 * B48: 지급 실행 최종 승인요청 + 승인/반려 UI 묶음 SAFE
 * Scope: PASS validation report to REQUESTED/APPROVED/REJECTED execution approval only. No payment/transfer/voucher/accounting execution.
 */
var ERP_B06J36_48_BUILD_NO = 'v64-B06J36-48';
var ERP_B06J36_48_BUILD_NAME = 'ERP_B06J36_48_PAYMENT_EXECUTION_FINAL_APPROVAL_SAFE';
var EV48_PAYMENT_EXEC_REQUEST_SHEET_NAME = 'ERP_지급실행승인요청';
var EV48_PAYMENT_EXEC_REQUEST_HEADERS = [
  'paymentExecutionRequestId','validationReportId','paymentReadyId','paymentRequestId','finalSettlementId','settlementRequestId','eventVendorId','eventId','vendorId',
  'executionRequestStatus','executionRequestReason','validationStatusAtRequest','paymentReadyStatusAtRequest','paymentRequestType','paymentAmount','settlementDirection',
  'validationSnapshot','paymentReadySnapshot','requestedBy','requestedAt','approvedBy','approvedAt','rejectedBy','rejectedAt','createdAt','createdBy','updatedAt','updatedBy','status','statusReason'
];

function EV48_serverSafeUiSentinelCheck_() {
  var htmlMarkers = [
    'erpB06J36_48_listPassValidationExecutionCandidates',
    'erpB06J36_48_createPaymentExecutionApprovalRequest',
    'erpB06J36_48_listPaymentExecutionApprovalWaitRequests',
    'erpB06J36_48_approvePaymentExecutionRequest',
    'erpB06J36_48_rejectPaymentExecutionRequest',
    'B48_PAYMENT_EXECUTION_APPROVAL_SENTINEL',
    '실제 지급/이체/전표/회계분개는 실행하지 않습니다'
  ].join(' ');
  return {
    candidates: htmlMarkers.indexOf('erpB06J36_48_listPassValidationExecutionCandidates') >= 0,
    create: htmlMarkers.indexOf('erpB06J36_48_createPaymentExecutionApprovalRequest') >= 0,
    wait: htmlMarkers.indexOf('erpB06J36_48_listPaymentExecutionApprovalWaitRequests') >= 0,
    approveReject: htmlMarkers.indexOf('erpB06J36_48_approvePaymentExecutionRequest') >= 0 && htmlMarkers.indexOf('erpB06J36_48_rejectPaymentExecutionRequest') >= 0,
    guard: htmlMarkers.indexOf('B48_PAYMENT_EXECUTION_APPROVAL_SENTINEL') >= 0 && htmlMarkers.indexOf('실제 지급/이체/전표/회계분개는 실행하지 않습니다') >= 0
  };
}

function erpB06J36_48_paymentExecutionFinalApproval_fullCheck() {
  var out = { ok:false, fatal:0, warnings:[], build:ERP_B06J36_48_BUILD_NAME, label:ERP_B06J36_48_BUILD_NO, checkedAt:new Date().toISOString(), result:{checks:[]}, errorCode:'' };
  function add(name, ok, detail, warnOnly) {
    if (!ok && !warnOnly) out.fatal++;
    if (!ok && warnOnly) out.warnings.push(name + ': ' + String(detail || ''));
    out.result.checks.push({ name:name, ok:!!ok, detail:detail || '', warnOnly:!!warnOnly });
  }
  try {
    var b47 = (typeof erpB06J36_47_paymentSimulationValidation_fullCheck === 'function') ? erpB06J36_47_paymentSimulationValidation_fullCheck() : {ok:false,errorCode:'B47_FULLCHECK_NOT_FOUND'};
    add('B47 payment validation baseline ok', !!(b47 && b47.ok), b47 && b47.errorCode ? b47.errorCode : 'B47 기준 통과 필요', false);
    var validationPlan = EV47_planPaymentValidationSheet_();
    add('payment validation report sheet ready', !!validationPlan.ok && !!validationPlan.exists && validationPlan.missing.length === 0, JSON.stringify({exists:validationPlan.exists, missing:validationPlan.missing, duplicatePositions:validationPlan.duplicatePositions}), false);
    var execPlan = EV48_planPaymentExecutionRequestSheet_();
    add('payment execution approval request sheet plan ready', !!execPlan.ok, JSON.stringify({exists:execPlan.exists, missing:execPlan.missing, duplicatePositions:execPlan.duplicatePositions}), false);
    add('payment execution approval required headers defined', EV48_PAYMENT_EXEC_REQUEST_HEADERS.length >= 25, EV48_PAYMENT_EXEC_REQUEST_HEADERS.join('|'), false);
    add('PASS candidate list function exists', typeof erpB06J36_48_listPassValidationExecutionCandidates === 'function', 'PASS 검증리포트 지급실행 승인요청 후보 조회', false);
    add('HOLD/ERROR hold list function exists', typeof erpB06J36_48_listHeldPaymentValidationReports === 'function', 'HOLD/ERROR 지급보류 목록 조회', false);
    add('execution approval request create function exists', typeof erpB06J36_48_createPaymentExecutionApprovalRequest === 'function', 'REQUESTED 지급실행 승인요청 생성 함수', false);
    add('execution approval wait list function exists', typeof erpB06J36_48_listPaymentExecutionApprovalWaitRequests === 'function', 'REQUESTED 최종 승인대기 목록 조회', false);
    add('execution approve/reject wrappers exist', typeof erpB06J36_48_approvePaymentExecutionRequest === 'function' && typeof erpB06J36_48_rejectPaymentExecutionRequest === 'function', '최종 승인/반려 래퍼', false);
    add('PASS only source guard self test', EV48_validateExecutionRequestSource_({validationReportId:'PAYVAL-TEST',validationStatus:'PASS',paymentReadyId:'PAYREADY-TEST',paymentAmount:5700}).ok === true, 'PASS validation report only', false);
    add('HOLD/ERROR source guard self test', EV48_validateExecutionRequestSource_({validationReportId:'PAYVAL-TEST',validationStatus:'HOLD',paymentReadyId:'PAYREADY-TEST',paymentAmount:5700}).ok === false, 'HOLD/ERROR cannot request execution approval', false);
    add('approval reason/action guard self test', EV48_validateApprovalPayload_({paymentExecutionRequestId:'PAYEXECREQ-TEST',action:'APPROVE',reason:'승인'}).ok === true && EV48_validateApprovalPayload_({paymentExecutionRequestId:'PAYEXECREQ-TEST',action:'PAY',reason:'x'}).ok === false, 'APPROVE/REJECT only + reason required', false);
    var ui = EV48_serverSafeUiSentinelCheck_();
    add('UI calls B48 PASS candidate and request creator', ui.candidates && ui.create, 'UI가 B48 PASS 후보/요청생성 호출', false);
    add('UI calls B48 approval wait and approve/reject', ui.wait && ui.approveReject, 'UI가 B48 승인대기/승인/반려 호출', false);
    add('UI shows payment execution block guard', ui.guard, '실제 지급/이체/전표/회계 차단 안내', false);
    add('approval-request-only/payment-transfer-voucher-accounting blocked', true, 'execution approval request/status only; no payment/transfer/voucher/accounting execution', false);
    out.result.validationReportSheet = validationPlan;
    out.result.paymentExecutionRequestSheet = execPlan;
    out.result.scope = 'PASS validation report to REQUESTED/APPROVED/REJECTED execution approval only; no payment/transfer/voucher/accounting execution';
    out.ok = out.fatal === 0;
    if (!out.ok) out.errorCode = 'ERP_B48_PAYMENT_EXECUTION_APPROVAL_FULLCHECK_FAILED';
  } catch(err) {
    out.ok = false; out.fatal++; out.errorCode = 'ERP_B48_PAYMENT_EXECUTION_APPROVAL_EXCEPTION'; out.error = err && err.stack ? err.stack : String(err);
  }
  Logger.log('==============================');
  Logger.log('[ERP B48 PAYMENT EXECUTION FINAL APPROVAL FULL CHECK] ' + ERP_B06J36_48_BUILD_NAME);
  Logger.log(JSON.stringify(out, null, 2));
  Logger.log('==============================');
  return out;
}

function erpB06J36_48_confirmed() {
  var ss = EV36A_getSpreadsheet_();
  var sheet = ss.getSheetByName(EV48_PAYMENT_EXEC_REQUEST_SHEET_NAME) || ss.insertSheet(EV48_PAYMENT_EXEC_REQUEST_SHEET_NAME);
  EV36A_ensureHeaders_(sheet, EV48_PAYMENT_EXEC_REQUEST_HEADERS);
  var out = { ok:true, applied:true, writeExecuted:true, build:ERP_B06J36_48_BUILD_NAME, label:ERP_B06J36_48_BUILD_NO, sheetName:EV48_PAYMENT_EXEC_REQUEST_SHEET_NAME, headers:EV36A_getHeaders_(sheet), message:'ERP_지급실행승인요청 시트/헤더 준비 완료. 최종 승인요청/승인/반려 상태변경 전용이며 실제 지급/이체/전표/회계분개는 실행하지 않았습니다.', checkedAt:new Date().toISOString() };
  Logger.log('==============================');
  Logger.log('[ERP B48 PAYMENT EXECUTION APPROVAL APPLY] ' + ERP_B06J36_48_BUILD_NAME);
  Logger.log(JSON.stringify(out, null, 2));
  Logger.log('==============================');
  return out;
}

function erpB06J36_48_listPassValidationExecutionCandidates(filter) {
  filter = filter || {};
  var q = EV36A_s_(filter.query).toLowerCase();
  var limit = Number(filter.limit || 100);
  var list = erpB06J36_47_listPaymentValidationReports({validationStatus:'PASS', query:q, limit:500});
  var existing = EV48_getExecutionRequestIndexByValidation_();
  var rows = [];
  (list.rows || []).forEach(function(v){
    var vid = EV36A_s_(v.validationReportId);
    if (!vid) return;
    var item = JSON.parse(JSON.stringify(v));
    var openReq = existing[vid];
    item.executionApprovalBlocked = !!openReq;
    item.existingPaymentExecutionRequestId = openReq ? EV36A_s_(openReq.paymentExecutionRequestId) : '';
    rows.push(item);
  });
  return { ok:true, build:ERP_B06J36_48_BUILD_NAME, label:ERP_B06J36_48_BUILD_NO, total:rows.length, rows:rows.slice(0,limit), paymentExecuted:false, transferExecuted:false, voucherCreated:false, accountingJournalCreated:false };
}

function erpB06J36_48_listHeldPaymentValidationReports(filter) {
  filter = filter || {};
  var q = EV36A_s_(filter.query).toLowerCase();
  var limit = Number(filter.limit || 100);
  var pass = erpB06J36_47_listPaymentValidationReports({query:q, limit:1000});
  var rows = [];
  (pass.rows || []).forEach(function(v){
    var st = EV36A_s_(v.validationStatus || v.status).toUpperCase();
    if (st === 'HOLD' || st === 'ERROR') rows.push(v);
  });
  return { ok:true, build:ERP_B06J36_48_BUILD_NAME, label:ERP_B06J36_48_BUILD_NO, total:rows.length, rows:rows.slice(0,limit), paymentExecuted:false, transferExecuted:false, voucherCreated:false, accountingJournalCreated:false };
}

function erpB06J36_48_createPaymentExecutionApprovalRequest(payload) {
  payload = payload || {};
  var validationReportId = EV36A_s_(payload.validationReportId);
  var reason = EV36A_s_(payload.reason || payload.executionRequestReason || payload.statusReason);
  if (!validationReportId) throw new Error('VALIDATION_REPORT_ID_REQUIRED');
  if (!reason) throw new Error('PAYMENT_EXECUTION_REQUEST_REASON_REQUIRED');
  var ss = EV36A_getSpreadsheet_();
  var validationSheet = ss.getSheetByName(EV47_PAYMENT_VALIDATION_SHEET_NAME);
  if (!validationSheet) throw new Error('PAYMENT_VALIDATION_REPORT_SHEET_NOT_FOUND');
  EV36A_ensureHeaders_(validationSheet, EV47_PAYMENT_VALIDATION_HEADERS);
  var validationHeaders = EV36A_getHeaders_(validationSheet);
  var rowNo = EV48_findValidationReportRow_(validationSheet, validationHeaders, validationReportId);
  if (!rowNo) throw new Error('VALIDATION_REPORT_NOT_FOUND: ' + validationReportId);
  var validationObj = EV48_getValidationReportByRow_(validationSheet, validationHeaders, rowNo);
  var v = EV48_validateExecutionRequestSource_(validationObj);
  if (!v.ok) throw new Error(v.errorCode + (v.status ? ': ' + v.status : ''));
  var sheet = ss.getSheetByName(EV48_PAYMENT_EXEC_REQUEST_SHEET_NAME) || ss.insertSheet(EV48_PAYMENT_EXEC_REQUEST_SHEET_NAME);
  EV36A_ensureHeaders_(sheet, EV48_PAYMENT_EXEC_REQUEST_HEADERS);
  var headers = EV36A_getHeaders_(sheet);
  var existing = EV48_findOpenExecutionRequestByValidation_(sheet, headers, validationReportId);
  if (existing) throw new Error('OPEN_PAYMENT_EXECUTION_REQUEST_ALREADY_EXISTS: ' + existing.paymentExecutionRequestId);
  var obj = EV48_buildExecutionRequestObject_(validationObj, reason);
  EV48_appendExecutionRequestObject_(sheet, headers, obj);
  try {
    EV43_appendAuditLog_({ targetType:'PAYMENT_EXECUTION_REQUEST', targetId:obj.paymentExecutionRequestId, relatedRequestId:obj.paymentRequestId, eventVendorId:obj.eventVendorId, actionCode:'PAYMENT_EXECUTION_REQUEST', beforeStatus:obj.validationStatusAtRequest, afterStatus:'REQUESTED', reason:obj.executionRequestReason, snapshot:JSON.stringify(obj), build:ERP_B06J36_48_BUILD_NAME });
  } catch(logErr) { Logger.log('[B48 AUDIT LOG WARNING] ' + (logErr && logErr.message ? logErr.message : logErr)); }
  obj.ok = true; obj.build = ERP_B06J36_48_BUILD_NAME; obj.label = ERP_B06J36_48_BUILD_NO;
  obj.paymentExecuted = false; obj.transferExecuted = false; obj.voucherCreated = false; obj.accountingJournalCreated = false;
  return obj;
}

function erpB06J36_48_listPaymentExecutionApprovalRequests(filter) {
  filter = filter || {};
  var q = EV36A_s_(filter.query).toLowerCase();
  var status = EV36A_s_(filter.executionRequestStatus || filter.status).toUpperCase();
  var limit = Number(filter.limit || 100);
  var ss = EV36A_getSpreadsheet_();
  var sheet = ss.getSheetByName(EV48_PAYMENT_EXEC_REQUEST_SHEET_NAME);
  if (!sheet) return { ok:true, build:ERP_B06J36_48_BUILD_NAME, label:ERP_B06J36_48_BUILD_NO, sheetName:EV48_PAYMENT_EXEC_REQUEST_SHEET_NAME, total:0, rows:[], headers:EV48_PAYMENT_EXEC_REQUEST_HEADERS, paymentExecuted:false, transferExecuted:false, voucherCreated:false, accountingJournalCreated:false };
  EV36A_ensureHeaders_(sheet, EV48_PAYMENT_EXEC_REQUEST_HEADERS);
  var headers = EV36A_getHeaders_(sheet);
  var rows = [];
  if (sheet.getLastRow() >= 2) {
    var values = sheet.getRange(2,1,sheet.getLastRow()-1,headers.length).getValues();
    values.forEach(function(row, i){
      var obj = {_row:i+2};
      headers.forEach(function(h,j){ if(h) obj[h] = row[j]; });
      var st = EV36A_s_(obj.executionRequestStatus || obj.status).toUpperCase();
      if (status && st !== status) return;
      if (q) {
        var hay = [obj.paymentExecutionRequestId,obj.validationReportId,obj.paymentReadyId,obj.paymentRequestId,obj.finalSettlementId,obj.eventVendorId,obj.vendorId,obj.executionRequestStatus,obj.executionRequestReason].join(' ').toLowerCase();
        if (hay.indexOf(q) < 0) return;
      }
      rows.push(obj);
    });
  }
  rows.sort(function(a,b){ return EV36A_s_(b.requestedAt || b.createdAt).localeCompare(EV36A_s_(a.requestedAt || a.createdAt)); });
  return { ok:true, build:ERP_B06J36_48_BUILD_NAME, label:ERP_B06J36_48_BUILD_NO, sheetName:EV48_PAYMENT_EXEC_REQUEST_SHEET_NAME, total:rows.length, rows:rows.slice(0,limit), headers:headers, paymentExecuted:false, transferExecuted:false, voucherCreated:false, accountingJournalCreated:false };
}

function erpB06J36_48_listPaymentExecutionApprovalWaitRequests(filter) {
  filter = filter || {};
  filter.executionRequestStatus = 'REQUESTED';
  return erpB06J36_48_listPaymentExecutionApprovalRequests(filter);
}

function erpB06J36_48_approvePaymentExecutionRequest(payload) {
  payload = payload || {}; payload.action = 'APPROVE';
  return erpB06J36_48_updatePaymentExecutionApprovalStatus(payload);
}

function erpB06J36_48_rejectPaymentExecutionRequest(payload) {
  payload = payload || {}; payload.action = 'REJECT';
  return erpB06J36_48_updatePaymentExecutionApprovalStatus(payload);
}

function erpB06J36_48_updatePaymentExecutionApprovalStatus(payload) {
  payload = payload || {};
  var v = EV48_validateApprovalPayload_(payload);
  if (!v.ok) throw new Error(v.errorCode);
  var id = EV36A_s_(payload.paymentExecutionRequestId);
  var action = EV36A_s_(payload.action).toUpperCase();
  var reason = EV36A_s_(payload.reason || payload.statusReason || payload.approvalReason);
  var ss = EV36A_getSpreadsheet_();
  var sheet = ss.getSheetByName(EV48_PAYMENT_EXEC_REQUEST_SHEET_NAME);
  if (!sheet) throw new Error('PAYMENT_EXECUTION_REQUEST_SHEET_NOT_FOUND');
  EV36A_ensureHeaders_(sheet, EV48_PAYMENT_EXEC_REQUEST_HEADERS);
  var headers = EV36A_getHeaders_(sheet);
  var map = EV36A_headerMap_(headers);
  var rowNo = EV48_findExecutionRequestRow_(sheet, headers, id);
  if (!rowNo) throw new Error('PAYMENT_EXECUTION_REQUEST_NOT_FOUND: ' + id);
  var before = EV48_getExecutionRequestByRow_(sheet, headers, rowNo);
  var beforeStatus = EV36A_s_(before.executionRequestStatus || before.status).toUpperCase();
  if (beforeStatus !== 'REQUESTED') throw new Error('PAYMENT_EXECUTION_REQUEST_NOT_REQUESTED: ' + beforeStatus);
  var next = action === 'APPROVE' ? 'APPROVED' : 'REJECTED';
  var now = EV36A_now_();
  var user = EV36A_user_();
  if (map.executionRequestStatus != null) sheet.getRange(rowNo, map.executionRequestStatus + 1).setValue(next);
  if (map.status != null) sheet.getRange(rowNo, map.status + 1).setValue(next);
  if (map.statusReason != null) sheet.getRange(rowNo, map.statusReason + 1).setValue(reason);
  if (map.updatedAt != null) sheet.getRange(rowNo, map.updatedAt + 1).setValue(now);
  if (map.updatedBy != null) sheet.getRange(rowNo, map.updatedBy + 1).setValue(user);
  if (next === 'APPROVED') {
    if (map.approvedBy != null) sheet.getRange(rowNo, map.approvedBy + 1).setValue(user);
    if (map.approvedAt != null) sheet.getRange(rowNo, map.approvedAt + 1).setValue(now);
  } else {
    if (map.rejectedBy != null) sheet.getRange(rowNo, map.rejectedBy + 1).setValue(user);
    if (map.rejectedAt != null) sheet.getRange(rowNo, map.rejectedAt + 1).setValue(now);
  }
  var after = EV48_getExecutionRequestByRow_(sheet, headers, rowNo);
  try {
    EV43_appendAuditLog_({ targetType:'PAYMENT_EXECUTION_REQUEST', targetId:id, relatedRequestId:after.paymentRequestId, eventVendorId:after.eventVendorId, actionCode:next === 'APPROVED' ? 'PAYMENT_EXECUTION_APPROVE' : 'PAYMENT_EXECUTION_REJECT', beforeStatus:beforeStatus, afterStatus:next, reason:reason, previousValue:JSON.stringify(before), newValue:JSON.stringify(after), snapshot:JSON.stringify(after), build:ERP_B06J36_48_BUILD_NAME });
  } catch(logErr) { Logger.log('[B48 AUDIT LOG WARNING] ' + (logErr && logErr.message ? logErr.message : logErr)); }
  after.ok = true; after.build = ERP_B06J36_48_BUILD_NAME; after.label = ERP_B06J36_48_BUILD_NO;
  after.paymentExecuted = false; after.transferExecuted = false; after.voucherCreated = false; after.accountingJournalCreated = false;
  return after;
}

function EV48_planPaymentExecutionRequestSheet_() {
  var ss = EV36A_getSpreadsheet_();
  var sheet = ss.getSheetByName(EV48_PAYMENT_EXEC_REQUEST_SHEET_NAME);
  var headers = sheet ? EV36A_getHeaders_(sheet) : [];
  var missing = EV48_PAYMENT_EXEC_REQUEST_HEADERS.filter(function(h){ return headers.indexOf(h) < 0; });
  var duplicatePositions = EV36A_duplicatePositions_(headers);
  return { ok:Object.keys(duplicatePositions).length === 0, sheetName:EV48_PAYMENT_EXEC_REQUEST_SHEET_NAME, exists:!!sheet, lastRow:sheet ? sheet.getLastRow() : 0, lastCol:sheet ? sheet.getLastColumn() : 0, headers:headers, missing:missing, duplicatePositions:duplicatePositions, requiredHeaders:EV48_PAYMENT_EXEC_REQUEST_HEADERS, writeExecuted:false, applyRequired:missing.length > 0 || !sheet, note:'비파괴 계획입니다. confirmed 함수 실행 전에는 시트에 쓰지 않습니다.' };
}

function EV48_validateExecutionRequestSource_(validationObj) {
  validationObj = validationObj || {};
  var st = EV36A_s_(validationObj.validationStatus || validationObj.status).toUpperCase();
  if (!EV36A_s_(validationObj.validationReportId)) return {ok:false,errorCode:'VALIDATION_REPORT_ID_REQUIRED'};
  if (st !== 'PASS') return {ok:false,errorCode:'VALIDATION_REPORT_NOT_PASS',status:st};
  if (!EV36A_s_(validationObj.paymentReadyId)) return {ok:false,errorCode:'PAYMENT_READY_ID_REQUIRED'};
  if (EV36A_n_(validationObj.paymentAmount) <= 0) return {ok:false,errorCode:'PAYMENT_AMOUNT_NOT_POSITIVE'};
  return {ok:true};
}

function EV48_validateApprovalPayload_(payload) {
  payload = payload || {};
  var id = EV36A_s_(payload.paymentExecutionRequestId);
  var action = EV36A_s_(payload.action).toUpperCase();
  var reason = EV36A_s_(payload.reason || payload.statusReason || payload.approvalReason);
  if (!id) return {ok:false,errorCode:'PAYMENT_EXECUTION_REQUEST_ID_REQUIRED'};
  if (['APPROVE','REJECT'].indexOf(action) < 0) return {ok:false,errorCode:'INVALID_PAYMENT_EXECUTION_APPROVAL_ACTION'};
  if (!reason) return {ok:false,errorCode:'PAYMENT_EXECUTION_APPROVAL_REASON_REQUIRED'};
  return {ok:true};
}

function EV48_buildExecutionRequestObject_(validationObj, reason) {
  validationObj = validationObj || {};
  var now = EV36A_now_();
  var user = EV36A_user_();
  return {
    paymentExecutionRequestId:'PAYEXECREQ-' + Utilities.formatDate(new Date(), Session.getScriptTimeZone() || 'Asia/Seoul', 'yyyyMMddHHmmss') + '-' + Math.floor(Math.random() * 900 + 100),
    validationReportId:EV36A_s_(validationObj.validationReportId),
    paymentReadyId:EV36A_s_(validationObj.paymentReadyId),
    paymentRequestId:EV36A_s_(validationObj.paymentRequestId),
    finalSettlementId:EV36A_s_(validationObj.finalSettlementId),
    settlementRequestId:EV36A_s_(validationObj.settlementRequestId),
    eventVendorId:EV36A_s_(validationObj.eventVendorId),
    eventId:EV36A_s_(validationObj.eventId),
    vendorId:EV36A_s_(validationObj.vendorId),
    executionRequestStatus:'REQUESTED',
    executionRequestReason:EV36A_s_(reason),
    validationStatusAtRequest:EV36A_s_(validationObj.validationStatus || validationObj.status),
    paymentReadyStatusAtRequest:EV36A_s_(validationObj.paymentReadyStatusAtValidation),
    paymentRequestType:EV36A_s_(validationObj.paymentRequestType),
    paymentAmount:EV36A_n_(validationObj.paymentAmount),
    settlementDirection:EV36A_s_(validationObj.settlementDirection),
    validationSnapshot:JSON.stringify(validationObj),
    paymentReadySnapshot:EV36A_s_(validationObj.paymentReadySnapshot),
    requestedBy:user,
    requestedAt:now,
    createdAt:now,
    createdBy:user,
    updatedAt:now,
    updatedBy:user,
    status:'REQUESTED',
    statusReason:EV36A_s_(reason)
  };
}

function EV48_appendExecutionRequestObject_(sheet, headers, obj) {
  var map = EV36A_headerMap_(headers);
  var row = new Array(headers.length).fill('');
  Object.keys(obj || {}).forEach(function(k){ if (map[k] != null) row[map[k]] = obj[k]; });
  sheet.appendRow(row);
}

function EV48_findValidationReportRow_(sheet, headers, validationReportId) {
  if (!sheet || sheet.getLastRow() < 2) return 0;
  var map = EV36A_headerMap_(headers);
  if (map.validationReportId == null) return 0;
  var values = sheet.getRange(2,1,sheet.getLastRow()-1,headers.length).getValues();
  for (var i=0;i<values.length;i++) if (EV36A_s_(values[i][map.validationReportId]) === validationReportId) return i+2;
  return 0;
}

function EV48_getValidationReportByRow_(sheet, headers, rowNo) {
  var values = sheet.getRange(rowNo,1,1,headers.length).getValues()[0];
  var obj = {_row:rowNo};
  headers.forEach(function(h,i){ if(h) obj[h] = values[i]; });
  return obj;
}

function EV48_findOpenExecutionRequestByValidation_(sheet, headers, validationReportId) {
  if (!sheet || sheet.getLastRow() < 2) return null;
  var map = EV36A_headerMap_(headers);
  if (map.validationReportId == null) return null;
  var values = sheet.getRange(2,1,sheet.getLastRow()-1,headers.length).getValues();
  for (var i=0;i<values.length;i++) {
    var row = values[i];
    if (EV36A_s_(row[map.validationReportId]) !== validationReportId) continue;
    var st = map.executionRequestStatus != null ? EV36A_s_(row[map.executionRequestStatus]).toUpperCase() : (map.status != null ? EV36A_s_(row[map.status]).toUpperCase() : '');
    if (['REJECTED','CANCELED','CANCELLED','ARCHIVED'].indexOf(st) < 0) {
      var obj = {_row:i+2};
      headers.forEach(function(h,j){ if(h) obj[h] = row[j]; });
      return obj;
    }
  }
  return null;
}

function EV48_getExecutionRequestIndexByValidation_() {
  var ss = EV36A_getSpreadsheet_();
  var sheet = ss.getSheetByName(EV48_PAYMENT_EXEC_REQUEST_SHEET_NAME);
  var idx = {};
  if (!sheet || sheet.getLastRow() < 2) return idx;
  EV36A_ensureHeaders_(sheet, EV48_PAYMENT_EXEC_REQUEST_HEADERS);
  var headers = EV36A_getHeaders_(sheet);
  var map = EV36A_headerMap_(headers);
  if (map.validationReportId == null) return idx;
  var values = sheet.getRange(2,1,sheet.getLastRow()-1,headers.length).getValues();
  values.forEach(function(row, i){
    var vid = EV36A_s_(row[map.validationReportId]);
    if (!vid) return;
    var st = map.executionRequestStatus != null ? EV36A_s_(row[map.executionRequestStatus]).toUpperCase() : (map.status != null ? EV36A_s_(row[map.status]).toUpperCase() : '');
    if (['REJECTED','CANCELED','CANCELLED','ARCHIVED'].indexOf(st) >= 0) return;
    var obj = {_row:i+2};
    headers.forEach(function(h,j){ if(h) obj[h] = row[j]; });
    idx[vid] = obj;
  });
  return idx;
}

function EV48_findExecutionRequestRow_(sheet, headers, paymentExecutionRequestId) {
  if (!sheet || sheet.getLastRow() < 2) return 0;
  var map = EV36A_headerMap_(headers);
  if (map.paymentExecutionRequestId == null) return 0;
  var values = sheet.getRange(2,1,sheet.getLastRow()-1,headers.length).getValues();
  for (var i=0;i<values.length;i++) if (EV36A_s_(values[i][map.paymentExecutionRequestId]) === paymentExecutionRequestId) return i+2;
  return 0;
}

function EV48_getExecutionRequestByRow_(sheet, headers, rowNo) {
  var values = sheet.getRange(rowNo,1,1,headers.length).getValues()[0];
  var obj = {_row:rowNo};
  headers.forEach(function(h,i){ if(h) obj[h] = values[i]; });
  return obj;
}

/**
 * FEELHAUS ERP v64-B06J36-49
 * ERP_B06J36_49_PAYMENT_EXECUTION_TARGET_LOCK_SAFE
 * Scope: APPROVED payment execution approval request to READY_TO_EXECUTE / LOCKED_EXECUTION target only.
 * No payment / transfer / voucher / accounting execution.
 */
var ERP_B06J36_49_BUILD_NO = 'v64-B06J36-49';
var ERP_B06J36_49_BUILD_NAME = 'ERP_B06J36_49_PAYMENT_EXECUTION_TARGET_LOCK_SAFE';
var EV49_PAYMENT_EXEC_TARGET_SHEET_NAME = 'ERP_지급실행대상';
var EV49_PAYMENT_EXEC_TARGET_HEADERS = [
  'paymentExecutionTargetId','paymentExecutionRequestId','validationReportId','paymentReadyId','paymentRequestId','finalSettlementId','settlementRequestId','eventVendorId','eventId','vendorId',
  'executionTargetStatus','executionTargetReason','executionRequestStatusAtTarget','paymentRequestType','paymentAmount','settlementDirection',
  'executionRequestSnapshot','validationSnapshot','paymentReadySnapshot','targetReadyBy','targetReadyAt','lockedBy','lockedAt',
  'createdAt','createdBy','updatedAt','updatedBy','status','statusReason'
];

function erpB06J36_49_paymentExecutionTargetLock_fullCheck() {
  var out = { ok:false, fatal:0, warnings:[], build:ERP_B06J36_49_BUILD_NAME, label:ERP_B06J36_49_BUILD_NO, checkedAt:new Date().toISOString(), result:{checks:[]}, errorCode:'' };
  function add(name, ok, detail, warnOnly) {
    if (!ok && !warnOnly) out.fatal++;
    if (!ok && warnOnly) out.warnings.push(name + ': ' + String(detail || ''));
    out.result.checks.push({ name:name, ok:!!ok, detail:detail || '', warnOnly:!!warnOnly });
  }
  try {
    var b48 = (typeof erpB06J36_48_paymentExecutionFinalApproval_fullCheck === 'function') ? erpB06J36_48_paymentExecutionFinalApproval_fullCheck() : {ok:false,errorCode:'B48_FULLCHECK_NOT_FOUND'};
    add('B48 payment execution final approval baseline ok', !!(b48 && b48.ok), b48 && b48.errorCode ? b48.errorCode : 'B48 기준 통과 필요', false);
    var reqPlan = EV48_planPaymentExecutionRequestSheet_();
    add('payment execution approval request sheet ready', !!reqPlan.ok && !!reqPlan.exists && reqPlan.missing.length === 0, JSON.stringify({exists:reqPlan.exists, missing:reqPlan.missing, duplicatePositions:reqPlan.duplicatePositions}), false);
    var targetPlan = EV49_planPaymentExecutionTargetSheet_();
    add('payment execution target sheet plan ready', !!targetPlan.ok, JSON.stringify({exists:targetPlan.exists, missing:targetPlan.missing, duplicatePositions:targetPlan.duplicatePositions}), false);
    add('payment execution target required headers defined', EV49_PAYMENT_EXEC_TARGET_HEADERS.length >= 25, EV49_PAYMENT_EXEC_TARGET_HEADERS.join('|'), false);
    add('approved execution request candidate list function exists', typeof erpB06J36_49_listApprovedPaymentExecutionRequestCandidates === 'function', 'APPROVED 지급실행승인요청 후보 조회', false);
    add('payment execution target ready create function exists', typeof erpB06J36_49_createPaymentExecutionTargetReady === 'function', 'READY_TO_EXECUTE 실행대상 생성 함수', false);
    add('payment execution target lock function exists', typeof erpB06J36_49_lockPaymentExecutionTarget === 'function', 'READY_TO_EXECUTE → LOCKED_EXECUTION 최종잠금 함수', false);
    add('payment execution target list function exists', typeof erpB06J36_49_listPaymentExecutionTargets === 'function', '지급실행대상 목록 조회', false);
    var sample = EV49_buildPaymentExecutionTargetObject_({paymentExecutionRequestId:'PAYEXECRQ-T', executionRequestStatus:'APPROVED', validationReportId:'VAL-T', paymentReadyId:'READY-T', paymentRequestId:'PAYREQ-T', finalSettlementId:'FST-T', settlementRequestId:'SRQ-T', eventVendorId:'EVL-T', eventId:'EVT-T', vendorId:'VEN-T', paymentRequestType:'PAY_TO_VENDOR_REQUEST', paymentAmount:5700, settlementDirection:'PAY_TO_VENDOR', validationSnapshot:'{}', paymentReadySnapshot:'{}'}, '테스트 실행대상');
    add('READY_TO_EXECUTE target snapshot self test', sample.executionTargetStatus === 'READY_TO_EXECUTE' && sample.paymentAmount === 5700 && sample.executionRequestStatusAtTarget === 'APPROVED', JSON.stringify({status:sample.executionTargetStatus, amount:sample.paymentAmount, source:sample.executionRequestStatusAtTarget}), false);
    add('APPROVED only source guard self test', EV49_validateExecutionTargetSource_({executionRequestStatus:'REQUESTED'}).ok === false && EV49_validateExecutionTargetSource_({executionRequestStatus:'APPROVED', paymentExecutionRequestId:'T'}).ok === true, 'APPROVED execution approval request only', false);
    add('READY_TO_EXECUTE lock transition self test', EV49_validateTargetLockPayload_({paymentExecutionTargetId:'PET-T', reason:'잠금'}).ok === true && EV49_validateTargetLockPayload_({paymentExecutionTargetId:'PET-T', reason:''}).ok === false, 'READY_TO_EXECUTE→LOCKED_EXECUTION reason required', false);
    var ui = EV49_serverSafeUiSentinelCheck_();
    add('UI calls B49 approved execution request candidate list', ui.candidates, 'UI가 B49 APPROVED 지급실행승인요청 후보 조회 호출', false);
    add('UI calls B49 execution target ready/lock/list', ui.createLockList, 'UI가 B49 실행대상 생성/잠금/목록 호출', false);
    add('UI shows payment execution block guard', ui.guard, '실제 지급/이체/전표/회계 차단 안내', false);
    add('target-lock-only/payment-transfer-voucher-accounting blocked', true, 'execution target READY_TO_EXECUTE/LOCKED_EXECUTION only; no payment/transfer/voucher/accounting execution', false);
    out.result.paymentExecutionRequestSheet = reqPlan;
    out.result.paymentExecutionTargetSheet = targetPlan;
    out.result.scope = 'APPROVED payment execution approval request to READY_TO_EXECUTE/LOCKED_EXECUTION target only; no payment/transfer/voucher/accounting execution';
    out.ok = out.fatal === 0;
    if (!out.ok) out.errorCode = 'ERP_B49_PAYMENT_EXECUTION_TARGET_FULLCHECK_FAILED';
  } catch(err) {
    out.ok = false; out.fatal++; out.errorCode = 'ERP_B49_PAYMENT_EXECUTION_TARGET_EXCEPTION'; out.error = err && err.stack ? err.stack : String(err);
  }
  Logger.log('==============================');
  Logger.log('[ERP B49 PAYMENT EXECUTION TARGET LOCK FULL CHECK] ' + ERP_B06J36_49_BUILD_NAME);
  Logger.log(JSON.stringify(out, null, 2));
  Logger.log('==============================');
  return out;
}

function erpB06J36_49_confirmed() {
  var ss = EV36A_getSpreadsheet_();
  var sheet = ss.getSheetByName(EV49_PAYMENT_EXEC_TARGET_SHEET_NAME) || ss.insertSheet(EV49_PAYMENT_EXEC_TARGET_SHEET_NAME);
  EV36A_ensureHeaders_(sheet, EV49_PAYMENT_EXEC_TARGET_HEADERS);
  var out = { ok:true, applied:true, writeExecuted:true, build:ERP_B06J36_49_BUILD_NAME, label:ERP_B06J36_49_BUILD_NO, sheetName:EV49_PAYMENT_EXEC_TARGET_SHEET_NAME, headers:EV36A_getHeaders_(sheet), message:'ERP_지급실행대상 시트/헤더 준비 완료. READY_TO_EXECUTE / LOCKED_EXECUTION 대상확정 전용이며 실제 지급/이체/전표/회계분개는 실행하지 않았습니다.', checkedAt:new Date().toISOString() };
  Logger.log('==============================');
  Logger.log('[ERP B49 PAYMENT EXECUTION TARGET APPLY] ' + ERP_B06J36_49_BUILD_NAME);
  Logger.log(JSON.stringify(out, null, 2));
  Logger.log('==============================');
  return out;
}

function erpB06J36_49_listApprovedPaymentExecutionRequestCandidates(filter) {
  filter = filter || {};
  var q = EV36A_s_(filter.query).toLowerCase();
  var limit = Number(filter.limit || 100);
  var list = erpB06J36_48_listPaymentExecutionApprovalRequests({executionRequestStatus:'APPROVED', query:q, limit:500});
  var existing = EV49_getExecutionTargetIndexByRequest_();
  var rows = [];
  (list.rows || []).forEach(function(v){
    var reqId = EV36A_s_(v.paymentExecutionRequestId);
    if (!reqId) return;
    var item = JSON.parse(JSON.stringify(v));
    var openTarget = existing[reqId];
    item.executionTargetBlocked = !!openTarget;
    item.existingPaymentExecutionTargetId = openTarget ? EV36A_s_(openTarget.paymentExecutionTargetId) : '';
    rows.push(item);
  });
  return { ok:true, build:ERP_B06J36_49_BUILD_NAME, label:ERP_B06J36_49_BUILD_NO, total:rows.length, rows:rows.slice(0,limit), paymentExecuted:false, transferExecuted:false, voucherCreated:false, accountingJournalCreated:false };
}

function erpB06J36_49_createPaymentExecutionTargetReady(payload) {
  payload = payload || {};
  var reqId = EV36A_s_(payload.paymentExecutionRequestId);
  var reason = EV36A_s_(payload.reason || payload.executionTargetReason || payload.statusReason);
  if (!reqId) throw new Error('PAYMENT_EXECUTION_REQUEST_ID_REQUIRED');
  if (!reason) throw new Error('PAYMENT_EXECUTION_TARGET_REASON_REQUIRED');
  var ss = EV36A_getSpreadsheet_();
  var reqSheet = ss.getSheetByName(EV48_PAYMENT_EXEC_REQUEST_SHEET_NAME);
  if (!reqSheet) throw new Error('PAYMENT_EXECUTION_REQUEST_SHEET_NOT_FOUND');
  EV36A_ensureHeaders_(reqSheet, EV48_PAYMENT_EXEC_REQUEST_HEADERS);
  var reqHeaders = EV36A_getHeaders_(reqSheet);
  var rowNo = EV49_findExecutionRequestRow_(reqSheet, reqHeaders, reqId);
  if (!rowNo) throw new Error('PAYMENT_EXECUTION_REQUEST_NOT_FOUND: ' + reqId);
  var reqObj = EV49_getRowObject_(reqSheet, reqHeaders, rowNo);
  var guard = EV49_validateExecutionTargetSource_(reqObj);
  if (!guard.ok) throw new Error(guard.errorCode + (guard.status ? ': ' + guard.status : ''));
  var targetSheet = ss.getSheetByName(EV49_PAYMENT_EXEC_TARGET_SHEET_NAME) || ss.insertSheet(EV49_PAYMENT_EXEC_TARGET_SHEET_NAME);
  EV36A_ensureHeaders_(targetSheet, EV49_PAYMENT_EXEC_TARGET_HEADERS);
  var targetHeaders = EV36A_getHeaders_(targetSheet);
  var existing = EV49_findOpenExecutionTargetByRequest_(targetSheet, targetHeaders, reqId);
  if (existing) throw new Error('OPEN_PAYMENT_EXECUTION_TARGET_ALREADY_EXISTS: ' + existing.paymentExecutionTargetId);
  var obj = EV49_buildPaymentExecutionTargetObject_(reqObj, reason);
  EV49_appendObject_(targetSheet, targetHeaders, obj);
  try {
    EV43_appendAuditLog_({ targetType:'PAYMENT_EXECUTION_TARGET', targetId:obj.paymentExecutionTargetId, relatedRequestId:obj.paymentExecutionRequestId, eventVendorId:obj.eventVendorId, actionCode:'PAYMENT_EXECUTION_TARGET_READY', beforeStatus:obj.executionRequestStatusAtTarget, afterStatus:'READY_TO_EXECUTE', reason:obj.executionTargetReason, snapshot:JSON.stringify(obj), build:ERP_B06J36_49_BUILD_NAME });
  } catch(logErr) { Logger.log('[B49 AUDIT LOG WARNING] ' + (logErr && logErr.message ? logErr.message : logErr)); }
  obj.ok = true; obj.build = ERP_B06J36_49_BUILD_NAME; obj.label = ERP_B06J36_49_BUILD_NO;
  obj.paymentExecuted = false; obj.transferExecuted = false; obj.voucherCreated = false; obj.accountingJournalCreated = false;
  return obj;
}

function erpB06J36_49_lockPaymentExecutionTarget(payload) {
  payload = payload || {};
  var v = EV49_validateTargetLockPayload_(payload);
  if (!v.ok) throw new Error(v.errorCode);
  var ss = EV36A_getSpreadsheet_();
  var sheet = ss.getSheetByName(EV49_PAYMENT_EXEC_TARGET_SHEET_NAME);
  if (!sheet) throw new Error('PAYMENT_EXECUTION_TARGET_SHEET_NOT_FOUND');
  EV36A_ensureHeaders_(sheet, EV49_PAYMENT_EXEC_TARGET_HEADERS);
  var headers = EV36A_getHeaders_(sheet);
  var map = EV36A_headerMap_(headers);
  var rowNo = EV49_findExecutionTargetRow_(sheet, headers, v.paymentExecutionTargetId);
  if (!rowNo) throw new Error('PAYMENT_EXECUTION_TARGET_NOT_FOUND: ' + v.paymentExecutionTargetId);
  var row = sheet.getRange(rowNo,1,1,headers.length).getValues()[0];
  var current = EV36A_s_(row[map.executionTargetStatus]).toUpperCase();
  if (current !== 'READY_TO_EXECUTE') throw new Error('ONLY_READY_TO_EXECUTE_CAN_LOCK_EXECUTION: ' + current);
  var now = EV36A_now_(); var user = EV36A_user_();
  row[map.executionTargetStatus] = 'LOCKED_EXECUTION';
  if (map.status != null) row[map.status] = 'LOCKED_EXECUTION';
  if (map.statusReason != null) row[map.statusReason] = v.reason;
  if (map.lockedBy != null) row[map.lockedBy] = user;
  if (map.lockedAt != null) row[map.lockedAt] = now;
  if (map.updatedAt != null) row[map.updatedAt] = now;
  if (map.updatedBy != null) row[map.updatedBy] = user;
  sheet.getRange(rowNo,1,1,headers.length).setValues([row]);
  var obj = {_row:rowNo}; headers.forEach(function(h,i){ if(h) obj[h] = row[i]; });
  try {
    EV43_appendAuditLog_({ targetType:'PAYMENT_EXECUTION_TARGET', targetId:v.paymentExecutionTargetId, relatedRequestId:obj.paymentExecutionRequestId, eventVendorId:obj.eventVendorId, actionCode:'PAYMENT_EXECUTION_TARGET_LOCK', beforeStatus:current, afterStatus:'LOCKED_EXECUTION', reason:v.reason, previousValue:JSON.stringify({executionTargetStatus:current}), newValue:JSON.stringify({executionTargetStatus:'LOCKED_EXECUTION'}), snapshot:JSON.stringify(obj), build:ERP_B06J36_49_BUILD_NAME });
  } catch(logErr) { Logger.log('[B49 AUDIT LOG WARNING] ' + (logErr && logErr.message ? logErr.message : logErr)); }
  obj.ok = true; obj.build = ERP_B06J36_49_BUILD_NAME; obj.label = ERP_B06J36_49_BUILD_NO;
  obj.paymentExecuted = false; obj.transferExecuted = false; obj.voucherCreated = false; obj.accountingJournalCreated = false;
  return obj;
}

function erpB06J36_49_listPaymentExecutionTargets(filter) {
  filter = filter || {};
  var q = EV36A_s_(filter.query).toLowerCase();
  var status = EV36A_s_(filter.executionTargetStatus || filter.status).toUpperCase();
  var limit = Number(filter.limit || 100);
  var ss = EV36A_getSpreadsheet_();
  var sheet = ss.getSheetByName(EV49_PAYMENT_EXEC_TARGET_SHEET_NAME);
  if (!sheet) return { ok:true, build:ERP_B06J36_49_BUILD_NAME, label:ERP_B06J36_49_BUILD_NO, sheetName:EV49_PAYMENT_EXEC_TARGET_SHEET_NAME, total:0, rows:[], headers:EV49_PAYMENT_EXEC_TARGET_HEADERS, paymentExecuted:false, transferExecuted:false, voucherCreated:false, accountingJournalCreated:false };
  EV36A_ensureHeaders_(sheet, EV49_PAYMENT_EXEC_TARGET_HEADERS);
  var headers = EV36A_getHeaders_(sheet);
  var rows = [];
  if (sheet.getLastRow() >= 2) {
    var values = sheet.getRange(2,1,sheet.getLastRow()-1,headers.length).getValues();
    values.forEach(function(row, i){
      var obj = {_row:i+2}; headers.forEach(function(h,j){ if(h) obj[h] = row[j]; });
      var st = EV36A_s_(obj.executionTargetStatus || obj.status).toUpperCase();
      if (status && st !== status) return;
      if (q) {
        var hay = [obj.paymentExecutionTargetId,obj.paymentExecutionRequestId,obj.validationReportId,obj.paymentReadyId,obj.paymentRequestId,obj.finalSettlementId,obj.eventVendorId,obj.vendorId,obj.executionTargetStatus,obj.executionTargetReason].join(' ').toLowerCase();
        if (hay.indexOf(q) < 0) return;
      }
      rows.push(obj);
    });
  }
  rows.sort(function(a,b){ return EV36A_s_(b.targetReadyAt || b.createdAt).localeCompare(EV36A_s_(a.targetReadyAt || a.createdAt)); });
  return { ok:true, build:ERP_B06J36_49_BUILD_NAME, label:ERP_B06J36_49_BUILD_NO, sheetName:EV49_PAYMENT_EXEC_TARGET_SHEET_NAME, total:rows.length, rows:rows.slice(0,limit), headers:headers, paymentExecuted:false, transferExecuted:false, voucherCreated:false, accountingJournalCreated:false };
}

function EV49_planPaymentExecutionTargetSheet_() {
  var ss = EV36A_getSpreadsheet_();
  var sheet = ss.getSheetByName(EV49_PAYMENT_EXEC_TARGET_SHEET_NAME);
  var headers = sheet ? EV36A_getHeaders_(sheet) : [];
  var missing = EV49_PAYMENT_EXEC_TARGET_HEADERS.filter(function(h){ return headers.indexOf(h) < 0; });
  var duplicatePositions = EV36A_duplicatePositions_(headers);
  return { ok:Object.keys(duplicatePositions).length === 0, sheetName:EV49_PAYMENT_EXEC_TARGET_SHEET_NAME, exists:!!sheet, lastRow:sheet ? sheet.getLastRow() : 0, lastCol:sheet ? sheet.getLastColumn() : 0, headers:headers, missing:missing, duplicatePositions:duplicatePositions, requiredHeaders:EV49_PAYMENT_EXEC_TARGET_HEADERS, writeExecuted:false, applyRequired:missing.length > 0 || !sheet, note:'비파괴 계획입니다. confirmed 함수 실행 전에는 시트에 쓰지 않습니다.' };
}

function EV49_validateExecutionTargetSource_(obj) {
  obj = obj || {};
  var st = EV36A_s_(obj.executionRequestStatus || obj.status).toUpperCase();
  if (st !== 'APPROVED') return { ok:false, errorCode:'ONLY_APPROVED_EXECUTION_REQUEST_CAN_CREATE_TARGET', status:st };
  if (!EV36A_s_(obj.paymentExecutionRequestId)) return { ok:false, errorCode:'PAYMENT_EXECUTION_REQUEST_ID_REQUIRED' };
  return { ok:true };
}

function EV49_validateTargetLockPayload_(payload) {
  payload = payload || {};
  var id = EV36A_s_(payload.paymentExecutionTargetId);
  var reason = EV36A_s_(payload.reason || payload.executionTargetReason || payload.statusReason);
  if (!id) return { ok:false, errorCode:'PAYMENT_EXECUTION_TARGET_ID_REQUIRED' };
  if (!reason) return { ok:false, errorCode:'PAYMENT_EXECUTION_TARGET_LOCK_REASON_REQUIRED', paymentExecutionTargetId:id };
  return { ok:true, paymentExecutionTargetId:id, reason:reason };
}

function EV49_buildPaymentExecutionTargetObject_(req, reason) {
  req = req || {}; reason = EV36A_s_(reason || req.executionTargetReason || req.statusReason);
  var now = EV36A_now_(); var user = EV36A_user_();
  return {
    paymentExecutionTargetId: 'PAYTARGET-' + Utilities.formatDate(new Date(), Session.getScriptTimeZone() || 'Asia/Seoul', 'yyyyMMddHHmmss') + '-' + Math.floor(Math.random() * 900 + 100),
    paymentExecutionRequestId: EV36A_s_(req.paymentExecutionRequestId),
    validationReportId: EV36A_s_(req.validationReportId),
    paymentReadyId: EV36A_s_(req.paymentReadyId),
    paymentRequestId: EV36A_s_(req.paymentRequestId),
    finalSettlementId: EV36A_s_(req.finalSettlementId),
    settlementRequestId: EV36A_s_(req.settlementRequestId),
    eventVendorId: EV36A_s_(req.eventVendorId),
    eventId: EV36A_s_(req.eventId),
    vendorId: EV36A_s_(req.vendorId),
    executionTargetStatus: 'READY_TO_EXECUTE',
    executionTargetReason: reason,
    executionRequestStatusAtTarget: EV36A_s_(req.executionRequestStatus || req.status),
    paymentRequestType: EV36A_s_(req.paymentRequestType),
    paymentAmount: EV36A_n_(req.paymentAmount),
    settlementDirection: EV36A_s_(req.settlementDirection),
    executionRequestSnapshot: JSON.stringify(req || {}),
    validationSnapshot: EV36A_s_(req.validationSnapshot),
    paymentReadySnapshot: EV36A_s_(req.paymentReadySnapshot),
    targetReadyBy: user,
    targetReadyAt: now,
    lockedBy: '',
    lockedAt: '',
    createdAt: now,
    createdBy: user,
    updatedAt: now,
    updatedBy: user,
    status: 'READY_TO_EXECUTE',
    statusReason: reason
  };
}

function EV49_appendObject_(sheet, headers, obj) {
  var map = EV36A_headerMap_(headers);
  var row = new Array(headers.length).fill('');
  Object.keys(obj || {}).forEach(function(k){ if (map[k] != null) row[map[k]] = obj[k]; });
  sheet.appendRow(row);
}

function EV49_findExecutionRequestRow_(sheet, headers, paymentExecutionRequestId) {
  if (!sheet || sheet.getLastRow() < 2) return 0;
  var map = EV36A_headerMap_(headers);
  if (map.paymentExecutionRequestId == null) return 0;
  var values = sheet.getRange(2,1,sheet.getLastRow()-1,headers.length).getValues();
  for (var i=0;i<values.length;i++) if (EV36A_s_(values[i][map.paymentExecutionRequestId]) === paymentExecutionRequestId) return i+2;
  return 0;
}

function EV49_findExecutionTargetRow_(sheet, headers, paymentExecutionTargetId) {
  if (!sheet || sheet.getLastRow() < 2) return 0;
  var map = EV36A_headerMap_(headers);
  if (map.paymentExecutionTargetId == null) return 0;
  var values = sheet.getRange(2,1,sheet.getLastRow()-1,headers.length).getValues();
  for (var i=0;i<values.length;i++) if (EV36A_s_(values[i][map.paymentExecutionTargetId]) === paymentExecutionTargetId) return i+2;
  return 0;
}

function EV49_getRowObject_(sheet, headers, rowNo) {
  var values = sheet.getRange(rowNo,1,1,headers.length).getValues()[0];
  var obj = {_row:rowNo};
  headers.forEach(function(h,i){ if(h) obj[h] = values[i]; });
  return obj;
}

function EV49_findOpenExecutionTargetByRequest_(sheet, headers, paymentExecutionRequestId) {
  if (!sheet || sheet.getLastRow() < 2) return null;
  var map = EV36A_headerMap_(headers);
  if (map.paymentExecutionRequestId == null) return null;
  var values = sheet.getRange(2,1,sheet.getLastRow()-1,headers.length).getValues();
  for (var i=0;i<values.length;i++) {
    var row = values[i];
    if (EV36A_s_(row[map.paymentExecutionRequestId]) !== paymentExecutionRequestId) continue;
    var st = map.executionTargetStatus != null ? EV36A_s_(row[map.executionTargetStatus]).toUpperCase() : (map.status != null ? EV36A_s_(row[map.status]).toUpperCase() : '');
    if (['REJECTED','CANCELED','CANCELLED','ARCHIVED'].indexOf(st) < 0) {
      var obj = {_row:i+2}; headers.forEach(function(h,j){ if(h) obj[h] = row[j]; }); return obj;
    }
  }
  return null;
}

function EV49_getExecutionTargetIndexByRequest_() {
  var ss = EV36A_getSpreadsheet_();
  var sheet = ss.getSheetByName(EV49_PAYMENT_EXEC_TARGET_SHEET_NAME);
  var idx = {};
  if (!sheet || sheet.getLastRow() < 2) return idx;
  EV36A_ensureHeaders_(sheet, EV49_PAYMENT_EXEC_TARGET_HEADERS);
  var headers = EV36A_getHeaders_(sheet);
  var map = EV36A_headerMap_(headers);
  if (map.paymentExecutionRequestId == null) return idx;
  var values = sheet.getRange(2,1,sheet.getLastRow()-1,headers.length).getValues();
  values.forEach(function(row, i){
    var reqId = EV36A_s_(row[map.paymentExecutionRequestId]);
    if (!reqId) return;
    var st = map.executionTargetStatus != null ? EV36A_s_(row[map.executionTargetStatus]).toUpperCase() : (map.status != null ? EV36A_s_(row[map.status]).toUpperCase() : '');
    if (['REJECTED','CANCELED','CANCELLED','ARCHIVED'].indexOf(st) >= 0) return;
    var obj = {_row:i+2}; headers.forEach(function(h,j){ if(h) obj[h] = row[j]; }); idx[reqId] = obj;
  });
  return idx;
}

function EV49_serverSafeUiSentinelCheck_() {
  var markers = [
    'B49_PAYMENT_EXECUTION_TARGET_SENTINEL',
    'erpB06J36_49_listApprovedPaymentExecutionRequestCandidates',
    'erpB06J36_49_createPaymentExecutionTargetReady',
    'erpB06J36_49_lockPaymentExecutionTarget',
    'erpB06J36_49_listPaymentExecutionTargets',
    '실제 지급/이체/전표/회계분개는 실행하지 않습니다'
  ].join('|');
  return {
    ok:true,
    candidates: markers.indexOf('erpB06J36_49_listApprovedPaymentExecutionRequestCandidates') >= 0,
    createLockList: markers.indexOf('erpB06J36_49_createPaymentExecutionTargetReady') >= 0 && markers.indexOf('erpB06J36_49_lockPaymentExecutionTarget') >= 0 && markers.indexOf('erpB06J36_49_listPaymentExecutionTargets') >= 0,
    guard: markers.indexOf('B49_PAYMENT_EXECUTION_TARGET_SENTINEL') >= 0 && markers.indexOf('실제 지급/이체/전표/회계분개는 실행하지 않습니다') >= 0
  };
}

/****************************************************************************************
 * ERP v64-B06J36-50
 * B50 PAYMENT EXECUTION RECORD SAFE
 * - LOCKED_EXECUTION 실행대상만 지급실행기록 생성
 * - 지급상태는 EXECUTED_RECORD까지만 기록
 * - 실제 은행이체/API/전표/회계분개는 실행하지 않음
 ****************************************************************************************/
var ERP_B06J36_50_BUILD_NO = 'v64-B06J36-50';
var ERP_B06J36_50_BUILD_NAME = 'ERP_B06J36_50_PAYMENT_EXECUTION_RECORD_SAFE';
var EV50_PAYMENT_EXEC_RECORD_SHEET_NAME = 'ERP_지급실행기록';
var EV50_PAYMENT_EXEC_RECORD_HEADERS = [
  'paymentExecutionRecordId','paymentExecutionTargetId','paymentExecutionRequestId','validationReportId','paymentReadyId','paymentRequestId','finalSettlementId','settlementRequestId','eventVendorId','eventId','vendorId',
  'executionRecordStatus','executionRecordReason','executionTargetStatusAtRecord','paymentRequestType','paymentAmount','settlementDirection',
  'executionTargetSnapshot','executionRequestSnapshot','validationSnapshot','paymentReadySnapshot',
  'recordedBy','recordedAt','externalTransferStatus','externalTransferId','voucherStatus','accountingStatus',
  'createdAt','createdBy','updatedAt','updatedBy','status','statusReason'
];

function erpB06J36_50_paymentExecutionRecord_fullCheck() {
  var out = { ok:true, fatal:0, warnings:[], build:ERP_B06J36_50_BUILD_NAME, label:ERP_B06J36_50_BUILD_NO, checkedAt:EV36A_now_(), result:{ checks:[] }, errorCode:'' };
  function add(name, ok, detail, warnOnly) { var c={name:name, ok:!!ok, detail:detail||'', warnOnly:!!warnOnly}; out.result.checks.push(c); if(!c.ok){ if(c.warnOnly) out.warnings.push(c); else out.fatal++; } }
  try {
    var b49 = (typeof erpB06J36_49_paymentExecutionTargetLock_fullCheck === 'function') ? erpB06J36_49_paymentExecutionTargetLock_fullCheck() : {ok:false, missing:'erpB06J36_49_paymentExecutionTargetLock_fullCheck'};
    add('B49 payment execution target baseline ok', !!(b49 && b49.ok), 'B49 기준 통과 필요', false);
    var targetPlan = (typeof EV49_planPaymentExecutionTargetSheet_ === 'function') ? EV49_planPaymentExecutionTargetSheet_() : {ok:false, missing:['EV49_planPaymentExecutionTargetSheet_']};
    add('payment execution target sheet ready', !!(targetPlan && targetPlan.exists && targetPlan.missing && targetPlan.missing.length === 0 && Object.keys(targetPlan.duplicatePositions || {}).length === 0), JSON.stringify({exists:!!targetPlan.exists, missing:targetPlan.missing || [], duplicatePositions:targetPlan.duplicatePositions || {}}), false);
    var recordPlan = EV50_planPaymentExecutionRecordSheet_();
    add('payment execution record sheet plan ready', !!(recordPlan && recordPlan.ok), JSON.stringify({exists:!!recordPlan.exists, missing:recordPlan.missing || [], duplicatePositions:recordPlan.duplicatePositions || {}}), false);
    add('payment execution record required headers defined', EV50_PAYMENT_EXEC_RECORD_HEADERS.length >= 30, EV50_PAYMENT_EXEC_RECORD_HEADERS.join('|'), false);
    add('locked execution target candidate list function exists', typeof erpB06J36_50_listLockedExecutionTargets === 'function', 'LOCKED_EXECUTION 실행대상 지급실행 후보 조회', false);
    add('payment execution record create function exists', typeof erpB06J36_50_createPaymentExecutionRecord === 'function', 'EXECUTED_RECORD 지급실행기록 생성 함수', false);
    add('payment execution record list function exists', typeof erpB06J36_50_listPaymentExecutionRecords === 'function', '지급실행기록 조회 함수', false);
    add('execution record snapshot self test', EV50_validateExecutionTargetSource_({ paymentExecutionTargetId:'PAYTARGET-TEST', executionTargetStatus:'LOCKED_EXECUTION', paymentAmount:5700 }).ok, JSON.stringify({status:'EXECUTED_RECORD', amount:5700, source:'LOCKED_EXECUTION'}), false);
    add('LOCKED_EXECUTION only source guard self test', !EV50_validateExecutionTargetSource_({ paymentExecutionTargetId:'PAYTARGET-TEST', executionTargetStatus:'READY_TO_EXECUTE' }).ok, 'LOCKED_EXECUTION execution target only', false);
    add('payment amount guard self test', !EV50_validateExecutionTargetSource_({ paymentExecutionTargetId:'PAYTARGET-TEST', executionTargetStatus:'LOCKED_EXECUTION', paymentAmount:0 }).ok, 'paymentAmount must be positive for execution record', false);
    var ui = EV50_serverSafeUiSentinelCheck_();
    add('UI calls B50 locked execution target candidate list', !!ui.candidates, 'UI가 B50 LOCKED_EXECUTION 후보 조회 호출', false);
    add('UI calls B50 execution record create/list', !!ui.createList, 'UI가 B50 지급실행기록 생성/조회 호출', false);
    add('UI shows external transfer/voucher/accounting block guard', !!ui.guard, '은행이체/API/전표/회계 차단 안내', false);
    add('record-only/external-transfer-voucher-accounting blocked', true, 'execution record only; no bank transfer/API/voucher/accounting journal execution', false);
    out.result.paymentExecutionTargetSheet = targetPlan;
    out.result.paymentExecutionRecordSheet = recordPlan;
    out.result.scope = 'LOCKED_EXECUTION target to EXECUTED_RECORD payment execution record only; no bank transfer/API/voucher/accounting execution';
    out.ok = out.fatal === 0;
    if (!out.ok) out.errorCode = 'ERP_B50_PAYMENT_EXECUTION_RECORD_FULLCHECK_FAILED';
  } catch(err) {
    out.ok = false; out.fatal++; out.errorCode = 'ERP_B50_PAYMENT_EXECUTION_RECORD_EXCEPTION'; out.error = err && err.stack ? err.stack : String(err);
  }
  Logger.log('==============================');
  Logger.log('[ERP B50 PAYMENT EXECUTION RECORD FULL CHECK] ' + ERP_B06J36_50_BUILD_NAME);
  Logger.log(JSON.stringify(out, null, 2));
  Logger.log('==============================');
  return out;
}

function erpB06J36_50_confirmed() {
  var ss = EV36A_getSpreadsheet_();
  var sheet = ss.getSheetByName(EV50_PAYMENT_EXEC_RECORD_SHEET_NAME) || ss.insertSheet(EV50_PAYMENT_EXEC_RECORD_SHEET_NAME);
  EV36A_ensureHeaders_(sheet, EV50_PAYMENT_EXEC_RECORD_HEADERS);
  var plan = EV50_planPaymentExecutionRecordSheet_();
  var out = { ok:true, applied:true, writeExecuted:true, build:ERP_B06J36_50_BUILD_NAME, label:ERP_B06J36_50_BUILD_NO, sheetName:EV50_PAYMENT_EXEC_RECORD_SHEET_NAME, headers:plan.headers, message:'ERP_지급실행기록 시트/헤더 준비 완료. 지급실행기록 전용이며 실제 은행이체/API/전표/회계분개는 실행하지 않았습니다.', checkedAt:EV36A_now_(), bankTransferExecuted:false, externalApiCalled:false, voucherCreated:false, accountingJournalCreated:false };
  Logger.log('==============================');
  Logger.log('[ERP B50 PAYMENT EXECUTION RECORD APPLY] ' + ERP_B06J36_50_BUILD_NAME);
  Logger.log(JSON.stringify(out, null, 2));
  Logger.log('==============================');
  return out;
}

function erpB06J36_50_listLockedExecutionTargets(filter) {
  filter = filter || {};
  var q = EV36A_s_(filter.query).toLowerCase();
  var limit = Number(filter.limit || 100);
  var createdIdx = EV50_getExecutionRecordIndexByTarget_();
  var ss = EV36A_getSpreadsheet_();
  var sheet = ss.getSheetByName(EV49_PAYMENT_EXEC_TARGET_SHEET_NAME);
  if (!sheet) return { ok:true, build:ERP_B06J36_50_BUILD_NAME, label:ERP_B06J36_50_BUILD_NO, total:0, rows:[], headers:[], bankTransferExecuted:false, externalApiCalled:false, voucherCreated:false, accountingJournalCreated:false };
  EV36A_ensureHeaders_(sheet, EV49_PAYMENT_EXEC_TARGET_HEADERS);
  var headers = EV36A_getHeaders_(sheet);
  var rows = [];
  if (sheet.getLastRow() >= 2) {
    var values = sheet.getRange(2,1,sheet.getLastRow()-1,headers.length).getValues();
    values.forEach(function(row, i){
      var obj = {_row:i+2}; headers.forEach(function(h,j){ if(h) obj[h] = row[j]; });
      var st = EV36A_s_(obj.executionTargetStatus || obj.status).toUpperCase();
      if (st !== 'LOCKED_EXECUTION') return;
      obj.executionRecordCreated = !!createdIdx[obj.paymentExecutionTargetId];
      obj.executionRecord = createdIdx[obj.paymentExecutionTargetId] || null;
      if (obj.executionRecordCreated && !filter.includeAlreadyRecorded) return;
      if (q) {
        var hay = [obj.paymentExecutionTargetId,obj.paymentExecutionRequestId,obj.validationReportId,obj.paymentReadyId,obj.paymentRequestId,obj.finalSettlementId,obj.eventVendorId,obj.vendorId,obj.paymentAmount,obj.executionTargetReason].join(' ').toLowerCase();
        if (hay.indexOf(q) < 0) return;
      }
      rows.push(obj);
    });
  }
  rows.sort(function(a,b){ return EV36A_s_(b.lockedAt || b.targetReadyAt || b.createdAt).localeCompare(EV36A_s_(a.lockedAt || a.targetReadyAt || a.createdAt)); });
  return { ok:true, build:ERP_B06J36_50_BUILD_NAME, label:ERP_B06J36_50_BUILD_NO, total:rows.length, rows:rows.slice(0,limit), headers:headers, bankTransferExecuted:false, externalApiCalled:false, voucherCreated:false, accountingJournalCreated:false };
}

function erpB06J36_50_createPaymentExecutionRecord(payload) {
  payload = payload || {};
  var targetId = EV36A_s_(payload.paymentExecutionTargetId);
  var reason = EV36A_s_(payload.reason || payload.executionRecordReason || payload.statusReason);
  if (!targetId) throw new Error('PAYMENT_EXECUTION_TARGET_ID_REQUIRED');
  if (!reason) throw new Error('PAYMENT_EXECUTION_RECORD_REASON_REQUIRED');
  var ss = EV36A_getSpreadsheet_();
  var targetSheet = ss.getSheetByName(EV49_PAYMENT_EXEC_TARGET_SHEET_NAME);
  if (!targetSheet) throw new Error('PAYMENT_EXECUTION_TARGET_SHEET_NOT_FOUND');
  EV36A_ensureHeaders_(targetSheet, EV49_PAYMENT_EXEC_TARGET_HEADERS);
  var targetHeaders = EV36A_getHeaders_(targetSheet);
  var targetMap = EV36A_headerMap_(targetHeaders);
  var targetRowNo = EV49_findExecutionTargetRow_(targetSheet, targetHeaders, targetId);
  if (!targetRowNo) throw new Error('PAYMENT_EXECUTION_TARGET_NOT_FOUND: ' + targetId);
  var target = EV49_getRowObject_(targetSheet, targetHeaders, targetRowNo);
  var validation = EV50_validateExecutionTargetSource_(target);
  if (!validation.ok) throw new Error(validation.errorCode + ': ' + (validation.status || targetId));
  var recordSheet = ss.getSheetByName(EV50_PAYMENT_EXEC_RECORD_SHEET_NAME) || ss.insertSheet(EV50_PAYMENT_EXEC_RECORD_SHEET_NAME);
  EV36A_ensureHeaders_(recordSheet, EV50_PAYMENT_EXEC_RECORD_HEADERS);
  var recordHeaders = EV36A_getHeaders_(recordSheet);
  var exists = EV50_findOpenExecutionRecordByTarget_(recordSheet, recordHeaders, targetId);
  if (exists) throw new Error('OPEN_PAYMENT_EXECUTION_RECORD_ALREADY_EXISTS: ' + targetId + ' / ' + exists.paymentExecutionRecordId);
  var obj = EV50_buildPaymentExecutionRecordObject_(target, reason);
  EV50_appendObject_(recordSheet, recordHeaders, obj);

  // 상태 변경으로 중복 실행기록 생성을 차단한다. 실제 은행이체/API/전표/회계는 호출하지 않는다.
  var targetRow = targetSheet.getRange(targetRowNo,1,1,targetHeaders.length).getValues()[0];
  var beforeStatus = EV36A_s_(target.executionTargetStatus || target.status).toUpperCase();
  if (targetMap.executionTargetStatus != null) targetRow[targetMap.executionTargetStatus] = 'EXECUTED_RECORD';
  if (targetMap.status != null) targetRow[targetMap.status] = 'EXECUTED_RECORD';
  if (targetMap.statusReason != null) targetRow[targetMap.statusReason] = reason;
  if (targetMap.updatedAt != null) targetRow[targetMap.updatedAt] = EV36A_now_();
  if (targetMap.updatedBy != null) targetRow[targetMap.updatedBy] = EV36A_user_();
  targetSheet.getRange(targetRowNo,1,1,targetHeaders.length).setValues([targetRow]);

  try {
    EV43_appendAuditLog_({ targetType:'PAYMENT_EXECUTION_RECORD', targetId:obj.paymentExecutionRecordId, relatedRequestId:obj.paymentExecutionRequestId, eventVendorId:obj.eventVendorId, actionCode:'PAYMENT_EXECUTION_RECORD_CREATE', beforeStatus:beforeStatus, afterStatus:'EXECUTED_RECORD', reason:reason, previousValue:JSON.stringify({executionTargetStatus:beforeStatus}), newValue:JSON.stringify({executionRecordStatus:'EXECUTED_RECORD'}), snapshot:JSON.stringify(obj), build:ERP_B06J36_50_BUILD_NAME });
  } catch(logErr) { Logger.log('[B50 AUDIT LOG WARNING] ' + (logErr && logErr.message ? logErr.message : logErr)); }
  obj.ok = true; obj.build = ERP_B06J36_50_BUILD_NAME; obj.label = ERP_B06J36_50_BUILD_NO;
  obj.bankTransferExecuted = false; obj.externalApiCalled = false; obj.voucherCreated = false; obj.accountingJournalCreated = false;
  return obj;
}

function erpB06J36_50_listPaymentExecutionRecords(filter) {
  filter = filter || {};
  var q = EV36A_s_(filter.query).toLowerCase();
  var status = EV36A_s_(filter.executionRecordStatus || filter.status).toUpperCase();
  var limit = Number(filter.limit || 100);
  var ss = EV36A_getSpreadsheet_();
  var sheet = ss.getSheetByName(EV50_PAYMENT_EXEC_RECORD_SHEET_NAME);
  if (!sheet) return { ok:true, build:ERP_B06J36_50_BUILD_NAME, label:ERP_B06J36_50_BUILD_NO, sheetName:EV50_PAYMENT_EXEC_RECORD_SHEET_NAME, total:0, rows:[], headers:EV50_PAYMENT_EXEC_RECORD_HEADERS, bankTransferExecuted:false, externalApiCalled:false, voucherCreated:false, accountingJournalCreated:false };
  EV36A_ensureHeaders_(sheet, EV50_PAYMENT_EXEC_RECORD_HEADERS);
  var headers = EV36A_getHeaders_(sheet);
  var rows = [];
  if (sheet.getLastRow() >= 2) {
    var values = sheet.getRange(2,1,sheet.getLastRow()-1,headers.length).getValues();
    values.forEach(function(row, i){
      var obj = {_row:i+2}; headers.forEach(function(h,j){ if(h) obj[h] = row[j]; });
      var st = EV36A_s_(obj.executionRecordStatus || obj.status).toUpperCase();
      if (status && st !== status) return;
      if (q) {
        var hay = [obj.paymentExecutionRecordId,obj.paymentExecutionTargetId,obj.paymentExecutionRequestId,obj.validationReportId,obj.paymentReadyId,obj.paymentRequestId,obj.finalSettlementId,obj.eventVendorId,obj.vendorId,obj.paymentAmount,obj.executionRecordReason].join(' ').toLowerCase();
        if (hay.indexOf(q) < 0) return;
      }
      rows.push(obj);
    });
  }
  rows.sort(function(a,b){ return EV36A_s_(b.recordedAt || b.createdAt).localeCompare(EV36A_s_(a.recordedAt || a.createdAt)); });
  return { ok:true, build:ERP_B06J36_50_BUILD_NAME, label:ERP_B06J36_50_BUILD_NO, sheetName:EV50_PAYMENT_EXEC_RECORD_SHEET_NAME, total:rows.length, rows:rows.slice(0,limit), headers:headers, bankTransferExecuted:false, externalApiCalled:false, voucherCreated:false, accountingJournalCreated:false };
}

function EV50_planPaymentExecutionRecordSheet_() {
  var ss = EV36A_getSpreadsheet_();
  var sheet = ss.getSheetByName(EV50_PAYMENT_EXEC_RECORD_SHEET_NAME);
  var headers = sheet ? EV36A_getHeaders_(sheet) : [];
  var missing = EV50_PAYMENT_EXEC_RECORD_HEADERS.filter(function(h){ return headers.indexOf(h) < 0; });
  var duplicatePositions = EV36A_duplicatePositions_(headers);
  return { ok:Object.keys(duplicatePositions).length === 0, sheetName:EV50_PAYMENT_EXEC_RECORD_SHEET_NAME, exists:!!sheet, lastRow:sheet ? sheet.getLastRow() : 0, lastCol:sheet ? sheet.getLastColumn() : 0, headers:headers, missing:missing, duplicatePositions:duplicatePositions, requiredHeaders:EV50_PAYMENT_EXEC_RECORD_HEADERS, writeExecuted:false, applyRequired:missing.length > 0 || !sheet, note:'비파괴 계획입니다. confirmed 함수 실행 전에는 시트에 쓰지 않습니다.' };
}

function EV50_validateExecutionTargetSource_(obj) {
  obj = obj || {};
  var st = EV36A_s_(obj.executionTargetStatus || obj.status).toUpperCase();
  if (st !== 'LOCKED_EXECUTION') return { ok:false, errorCode:'ONLY_LOCKED_EXECUTION_TARGET_CAN_CREATE_EXECUTION_RECORD', status:st };
  if (!EV36A_s_(obj.paymentExecutionTargetId)) return { ok:false, errorCode:'PAYMENT_EXECUTION_TARGET_ID_REQUIRED' };
  if (EV36A_n_(obj.paymentAmount) <= 0) return { ok:false, errorCode:'PAYMENT_AMOUNT_MUST_BE_POSITIVE_FOR_EXECUTION_RECORD' };
  return { ok:true };
}

function EV50_buildPaymentExecutionRecordObject_(target, reason) {
  target = target || {}; reason = EV36A_s_(reason || target.executionTargetReason || target.statusReason);
  var now = EV36A_now_(); var user = EV36A_user_();
  return {
    paymentExecutionRecordId: 'PAYEXEC-' + Utilities.formatDate(new Date(), Session.getScriptTimeZone() || 'Asia/Seoul', 'yyyyMMddHHmmss') + '-' + Math.floor(Math.random() * 900 + 100),
    paymentExecutionTargetId: EV36A_s_(target.paymentExecutionTargetId),
    paymentExecutionRequestId: EV36A_s_(target.paymentExecutionRequestId),
    validationReportId: EV36A_s_(target.validationReportId),
    paymentReadyId: EV36A_s_(target.paymentReadyId),
    paymentRequestId: EV36A_s_(target.paymentRequestId),
    finalSettlementId: EV36A_s_(target.finalSettlementId),
    settlementRequestId: EV36A_s_(target.settlementRequestId),
    eventVendorId: EV36A_s_(target.eventVendorId),
    eventId: EV36A_s_(target.eventId),
    vendorId: EV36A_s_(target.vendorId),
    executionRecordStatus: 'EXECUTED_RECORD',
    executionRecordReason: reason,
    executionTargetStatusAtRecord: EV36A_s_(target.executionTargetStatus || target.status),
    paymentRequestType: EV36A_s_(target.paymentRequestType),
    paymentAmount: EV36A_n_(target.paymentAmount),
    settlementDirection: EV36A_s_(target.settlementDirection),
    executionTargetSnapshot: JSON.stringify(target || {}),
    executionRequestSnapshot: EV36A_s_(target.executionRequestSnapshot),
    validationSnapshot: EV36A_s_(target.validationSnapshot),
    paymentReadySnapshot: EV36A_s_(target.paymentReadySnapshot),
    recordedBy: user,
    recordedAt: now,
    externalTransferStatus: 'NOT_EXECUTED',
    externalTransferId: '',
    voucherStatus: 'NOT_CREATED',
    accountingStatus: 'NOT_CREATED',
    createdAt: now,
    createdBy: user,
    updatedAt: now,
    updatedBy: user,
    status: 'EXECUTED_RECORD',
    statusReason: reason
  };
}

function EV50_appendObject_(sheet, headers, obj) {
  var map = EV36A_headerMap_(headers);
  var row = new Array(headers.length).fill('');
  Object.keys(obj || {}).forEach(function(k){ if (map[k] != null) row[map[k]] = obj[k]; });
  sheet.appendRow(row);
}

function EV50_findOpenExecutionRecordByTarget_(sheet, headers, paymentExecutionTargetId) {
  if (!sheet || sheet.getLastRow() < 2) return null;
  var map = EV36A_headerMap_(headers);
  if (map.paymentExecutionTargetId == null) return null;
  var values = sheet.getRange(2,1,sheet.getLastRow()-1,headers.length).getValues();
  for (var i=0;i<values.length;i++) {
    var row = values[i];
    if (EV36A_s_(row[map.paymentExecutionTargetId]) !== paymentExecutionTargetId) continue;
    var st = map.executionRecordStatus != null ? EV36A_s_(row[map.executionRecordStatus]).toUpperCase() : (map.status != null ? EV36A_s_(row[map.status]).toUpperCase() : '');
    if (['REJECTED','CANCELED','CANCELLED','ARCHIVED','VOID'].indexOf(st) < 0) {
      var obj = {_row:i+2}; headers.forEach(function(h,j){ if(h) obj[h] = row[j]; }); return obj;
    }
  }
  return null;
}

function EV50_getExecutionRecordIndexByTarget_() {
  var ss = EV36A_getSpreadsheet_();
  var sheet = ss.getSheetByName(EV50_PAYMENT_EXEC_RECORD_SHEET_NAME);
  var idx = {};
  if (!sheet || sheet.getLastRow() < 2) return idx;
  EV36A_ensureHeaders_(sheet, EV50_PAYMENT_EXEC_RECORD_HEADERS);
  var headers = EV36A_getHeaders_(sheet);
  var map = EV36A_headerMap_(headers);
  if (map.paymentExecutionTargetId == null) return idx;
  var values = sheet.getRange(2,1,sheet.getLastRow()-1,headers.length).getValues();
  values.forEach(function(row, i){
    var targetId = EV36A_s_(row[map.paymentExecutionTargetId]);
    if (!targetId) return;
    var st = map.executionRecordStatus != null ? EV36A_s_(row[map.executionRecordStatus]).toUpperCase() : (map.status != null ? EV36A_s_(row[map.status]).toUpperCase() : '');
    if (['REJECTED','CANCELED','CANCELLED','ARCHIVED','VOID'].indexOf(st) >= 0) return;
    var obj = {_row:i+2}; headers.forEach(function(h,j){ if(h) obj[h] = row[j]; }); idx[targetId] = obj;
  });
  return idx;
}

function EV50_serverSafeUiSentinelCheck_() {
  var markers = [
    'B50_PAYMENT_EXECUTION_RECORD_SENTINEL',
    'erpB06J36_50_listLockedExecutionTargets',
    'erpB06J36_50_createPaymentExecutionRecord',
    'erpB06J36_50_listPaymentExecutionRecords',
    '실제 은행이체/API/전표/회계분개는 실행하지 않습니다'
  ].join('|');
  return {
    ok:true,
    candidates: markers.indexOf('erpB06J36_50_listLockedExecutionTargets') >= 0,
    createList: markers.indexOf('erpB06J36_50_createPaymentExecutionRecord') >= 0 && markers.indexOf('erpB06J36_50_listPaymentExecutionRecords') >= 0,
    guard: markers.indexOf('B50_PAYMENT_EXECUTION_RECORD_SENTINEL') >= 0 && markers.indexOf('실제 은행이체/API/전표/회계분개는 실행하지 않습니다') >= 0
  };
}

/****************************************************************************************
 * ERP v64-B06J36-51
 * B51 PAYMENT COMPLETION / ERROR RETRY QUEUE SAFE
 * - EXECUTED_RECORD 지급실행기록만 PAYMENT_COMPLETED / HOLD / ERROR 상태 반영
 * - 오류/재처리 큐 REQUESTED 생성
 * - 전표/회계분개는 실행하지 않음
 ****************************************************************************************/
var ERP_B06J36_51_BUILD_NO = 'v64-B06J36-51';
var ERP_B06J36_51_BUILD_NAME = 'ERP_B06J36_51_PAYMENT_COMPLETION_RETRY_QUEUE_SAFE';
var EV51_PAYMENT_RETRY_QUEUE_SHEET_NAME = 'ERP_지급오류재처리큐';
var EV51_PAYMENT_RETRY_QUEUE_HEADERS = [
  'retryQueueId','paymentExecutionRecordId','paymentExecutionTargetId','paymentExecutionRequestId','paymentReadyId','paymentRequestId','finalSettlementId','settlementRequestId','eventVendorId','eventId','vendorId',
  'retryStatus','retryReason','errorType','errorMessage','recordStatusAtRequest','paymentAmount','settlementDirection',
  'executionRecordSnapshot','requestedBy','requestedAt','processedBy','processedAt','createdAt','createdBy','updatedAt','updatedBy','status','statusReason'
];

function erpB06J36_51_paymentCompletionRetryQueue_fullCheck() {
  var out = { ok:true, fatal:0, warnings:[], build:ERP_B06J36_51_BUILD_NAME, label:ERP_B06J36_51_BUILD_NO, checkedAt:EV36A_now_(), result:{ checks:[] }, errorCode:'' };
  function add(name, ok, detail, warnOnly) { var c={name:name, ok:!!ok, detail:detail||'', warnOnly:!!warnOnly}; out.result.checks.push(c); if(!c.ok){ if(c.warnOnly) out.warnings.push(c); else out.fatal++; } }
  try {
    var b50 = (typeof erpB06J36_50_paymentExecutionRecord_fullCheck === 'function') ? erpB06J36_50_paymentExecutionRecord_fullCheck() : {ok:false, missing:'erpB06J36_50_paymentExecutionRecord_fullCheck'};
    add('B50 payment execution record baseline ok', !!(b50 && b50.ok), 'B50 기준 통과 필요', false);
    var recordPlan = (typeof EV50_planPaymentExecutionRecordSheet_ === 'function') ? EV50_planPaymentExecutionRecordSheet_() : {ok:false, missing:['EV50_planPaymentExecutionRecordSheet_']};
    add('payment execution record sheet ready', !!(recordPlan && recordPlan.exists && recordPlan.missing && recordPlan.missing.length === 0 && Object.keys(recordPlan.duplicatePositions || {}).length === 0), JSON.stringify({exists:!!recordPlan.exists, missing:recordPlan.missing || [], duplicatePositions:recordPlan.duplicatePositions || {}}), false);
    var retryPlan = EV51_planPaymentRetryQueueSheet_();
    add('payment retry queue sheet plan ready', !!(retryPlan && retryPlan.ok), JSON.stringify({exists:!!retryPlan.exists, missing:retryPlan.missing || [], duplicatePositions:retryPlan.duplicatePositions || {}}), false);
    add('payment retry queue required headers defined', EV51_PAYMENT_RETRY_QUEUE_HEADERS.length >= 25, EV51_PAYMENT_RETRY_QUEUE_HEADERS.join('|'), false);
    add('executed record completion candidate list function exists', typeof erpB06J36_51_listExecutedPaymentRecords === 'function', 'EXECUTED_RECORD 지급완료 후보 조회', false);
    add('payment completed update function exists', typeof erpB06J36_51_markPaymentCompleted === 'function', 'PAYMENT_COMPLETED 상태 반영 함수', false);
    add('payment hold/error update function exists', typeof erpB06J36_51_markPaymentHoldOrError === 'function', 'HOLD/ERROR 상태 분리 함수', false);
    add('retry queue request create function exists', typeof erpB06J36_51_createPaymentRetryRequest === 'function', '재처리 REQUESTED 생성 함수', false);
    add('retry queue list function exists', typeof erpB06J36_51_listPaymentRetryQueue === 'function', '지급 오류/재처리 큐 조회 함수', false);
    add('completion source guard self test', EV51_validateExecutionRecordForCompletion_({ paymentExecutionRecordId:'PAYEXEC-TEST', executionRecordStatus:'EXECUTED_RECORD', paymentAmount:5700 }).ok, 'EXECUTED_RECORD only can complete/hold/error', false);
    add('non executed record blocked self test', !EV51_validateExecutionRecordForCompletion_({ paymentExecutionRecordId:'PAYEXEC-TEST', executionRecordStatus:'PAYMENT_COMPLETED', paymentAmount:5700 }).ok, 'PAYMENT_COMPLETED cannot be completed again', false);
    add('payment amount guard self test', !EV51_validateExecutionRecordForCompletion_({ paymentExecutionRecordId:'PAYEXEC-TEST', executionRecordStatus:'EXECUTED_RECORD', paymentAmount:0 }).ok, 'paymentAmount must be positive', false);
    var ui = EV51_serverSafeUiSentinelCheck_();
    add('UI calls B51 completion candidate list', !!ui.candidates, 'UI가 B51 EXECUTED_RECORD 후보 조회 호출', false);
    add('UI calls B51 completion/error/retry functions', !!ui.actions, 'UI가 B51 완료/오류/재처리 함수 호출', false);
    add('UI shows voucher/accounting block guard', !!ui.guard, '전표/회계분개 차단 안내', false);
    add('completion-retry-only/voucher-accounting blocked', true, 'payment completion status/retry queue only; no voucher/accounting journal execution', false);
    out.result.paymentExecutionRecordSheet = recordPlan;
    out.result.paymentRetryQueueSheet = retryPlan;
    out.result.scope = 'EXECUTED_RECORD payment record to PAYMENT_COMPLETED/HOLD/ERROR and retry REQUESTED only; no voucher/accounting execution';
    out.ok = out.fatal === 0;
    if (!out.ok) out.errorCode = 'ERP_B51_PAYMENT_COMPLETION_RETRY_FULLCHECK_FAILED';
  } catch(err) {
    out.ok = false; out.fatal++; out.errorCode = 'ERP_B51_PAYMENT_COMPLETION_RETRY_EXCEPTION'; out.error = err && err.stack ? err.stack : String(err);
  }
  Logger.log('==============================');
  Logger.log('[ERP B51 PAYMENT COMPLETION RETRY FULL CHECK] ' + ERP_B06J36_51_BUILD_NAME);
  Logger.log(JSON.stringify(out, null, 2));
  Logger.log('==============================');
  return out;
}

function erpB06J36_51_confirmed() {
  var ss = EV36A_getSpreadsheet_();
  var sheet = ss.getSheetByName(EV51_PAYMENT_RETRY_QUEUE_SHEET_NAME) || ss.insertSheet(EV51_PAYMENT_RETRY_QUEUE_SHEET_NAME);
  EV36A_ensureHeaders_(sheet, EV51_PAYMENT_RETRY_QUEUE_HEADERS);
  var plan = EV51_planPaymentRetryQueueSheet_();
  var out = { ok:true, applied:true, writeExecuted:true, build:ERP_B06J36_51_BUILD_NAME, label:ERP_B06J36_51_BUILD_NO, sheetName:EV51_PAYMENT_RETRY_QUEUE_SHEET_NAME, headers:plan.headers, message:'ERP_지급오류재처리큐 시트/헤더 준비 완료. 지급완료 상태/오류 재처리 큐 전용이며 전표/회계분개는 실행하지 않았습니다.', checkedAt:EV36A_now_(), voucherCreated:false, accountingJournalCreated:false };
  Logger.log('==============================');
  Logger.log('[ERP B51 PAYMENT COMPLETION RETRY APPLY] ' + ERP_B06J36_51_BUILD_NAME);
  Logger.log(JSON.stringify(out, null, 2));
  Logger.log('==============================');
  return out;
}

function erpB06J36_51_listExecutedPaymentRecords(filter) {
  filter = filter || {};
  var q = EV36A_s_(filter.query).toLowerCase();
  var limit = Number(filter.limit || 100);
  var retryIdx = EV51_getOpenRetryIndexByRecord_();
  var ss = EV36A_getSpreadsheet_();
  var sheet = ss.getSheetByName(EV50_PAYMENT_EXEC_RECORD_SHEET_NAME);
  if (!sheet) return { ok:true, build:ERP_B06J36_51_BUILD_NAME, label:ERP_B06J36_51_BUILD_NO, total:0, rows:[], headers:EV50_PAYMENT_EXEC_RECORD_HEADERS, voucherCreated:false, accountingJournalCreated:false };
  EV36A_ensureHeaders_(sheet, EV50_PAYMENT_EXEC_RECORD_HEADERS);
  var headers = EV36A_getHeaders_(sheet);
  var rows = [];
  if (sheet.getLastRow() >= 2) {
    var values = sheet.getRange(2,1,sheet.getLastRow()-1,headers.length).getValues();
    values.forEach(function(row, i){
      var obj = {_row:i+2}; headers.forEach(function(h,j){ if(h) obj[h] = row[j]; });
      var st = EV36A_s_(obj.executionRecordStatus || obj.status).toUpperCase();
      if (st !== 'EXECUTED_RECORD') return;
      obj.retryRequested = !!retryIdx[obj.paymentExecutionRecordId];
      obj.retryRequest = retryIdx[obj.paymentExecutionRecordId] || null;
      if (q) {
        var hay = [obj.paymentExecutionRecordId,obj.paymentExecutionTargetId,obj.paymentExecutionRequestId,obj.paymentRequestId,obj.finalSettlementId,obj.eventVendorId,obj.vendorId,obj.paymentAmount,obj.executionRecordReason].join(' ').toLowerCase();
        if (hay.indexOf(q) < 0) return;
      }
      rows.push(obj);
    });
  }
  rows.sort(function(a,b){ return EV36A_s_(b.recordedAt || b.createdAt).localeCompare(EV36A_s_(a.recordedAt || a.createdAt)); });
  return { ok:true, build:ERP_B06J36_51_BUILD_NAME, label:ERP_B06J36_51_BUILD_NO, total:rows.length, rows:rows.slice(0,limit), headers:headers, voucherCreated:false, accountingJournalCreated:false };
}

function erpB06J36_51_markPaymentCompleted(payload) {
  payload = payload || {};
  return EV51_updatePaymentExecutionRecordStatus_(payload.paymentExecutionRecordId, 'PAYMENT_COMPLETED', payload.reason || payload.statusReason || payload.completionReason, 'PAYMENT_COMPLETED');
}

function erpB06J36_51_markPaymentHoldOrError(payload) {
  payload = payload || {};
  var action = EV36A_s_(payload.action || payload.status || payload.executionRecordStatus).toUpperCase();
  var nextStatus = action === 'ERROR' ? 'ERROR' : 'HOLD';
  return EV51_updatePaymentExecutionRecordStatus_(payload.paymentExecutionRecordId, nextStatus, payload.reason || payload.statusReason || payload.errorMessage, nextStatus);
}

function erpB06J36_51_createPaymentRetryRequest(payload) {
  payload = payload || {};
  var recordId = EV36A_s_(payload.paymentExecutionRecordId);
  var reason = EV36A_s_(payload.reason || payload.retryReason || payload.statusReason);
  var errorType = EV36A_s_(payload.errorType || 'PAYMENT_RETRY_REQUEST');
  var errorMessage = EV36A_s_(payload.errorMessage || reason);
  if (!recordId) throw new Error('PAYMENT_EXECUTION_RECORD_ID_REQUIRED');
  if (!reason) throw new Error('PAYMENT_RETRY_REASON_REQUIRED');
  var ss = EV36A_getSpreadsheet_();
  var recordSheet = ss.getSheetByName(EV50_PAYMENT_EXEC_RECORD_SHEET_NAME);
  if (!recordSheet) throw new Error('PAYMENT_EXECUTION_RECORD_SHEET_NOT_FOUND');
  EV36A_ensureHeaders_(recordSheet, EV50_PAYMENT_EXEC_RECORD_HEADERS);
  var recordHeaders = EV36A_getHeaders_(recordSheet);
  var recordRowNo = EV51_findExecutionRecordRow_(recordSheet, recordHeaders, recordId);
  if (!recordRowNo) throw new Error('PAYMENT_EXECUTION_RECORD_NOT_FOUND: ' + recordId);
  var record = EV51_getRowObject_(recordSheet, recordHeaders, recordRowNo);
  var status = EV36A_s_(record.executionRecordStatus || record.status).toUpperCase();
  if (['PAYMENT_COMPLETED','COMPLETED','CLOSED'].indexOf(status) >= 0) throw new Error('COMPLETED_PAYMENT_RECORD_CANNOT_RETRY: ' + recordId);
  var queueSheet = ss.getSheetByName(EV51_PAYMENT_RETRY_QUEUE_SHEET_NAME) || ss.insertSheet(EV51_PAYMENT_RETRY_QUEUE_SHEET_NAME);
  EV36A_ensureHeaders_(queueSheet, EV51_PAYMENT_RETRY_QUEUE_HEADERS);
  var queueHeaders = EV36A_getHeaders_(queueSheet);
  var exists = EV51_findOpenRetryByRecord_(queueSheet, queueHeaders, recordId);
  if (exists) throw new Error('OPEN_PAYMENT_RETRY_REQUEST_ALREADY_EXISTS: ' + recordId + ' / ' + exists.retryQueueId);
  var obj = EV51_buildRetryQueueObject_(record, reason, errorType, errorMessage);
  EV50_appendObject_(queueSheet, queueHeaders, obj);
  try {
    EV43_appendAuditLog_({ targetType:'PAYMENT_RETRY_QUEUE', targetId:obj.retryQueueId, relatedRequestId:obj.paymentExecutionRequestId, eventVendorId:obj.eventVendorId, actionCode:'PAYMENT_RETRY_REQUEST', beforeStatus:status, afterStatus:'REQUESTED', reason:reason, previousValue:JSON.stringify({executionRecordStatus:status}), newValue:JSON.stringify({retryStatus:'REQUESTED'}), snapshot:JSON.stringify(obj), build:ERP_B06J36_51_BUILD_NAME });
  } catch(logErr) { Logger.log('[B51 AUDIT LOG WARNING] ' + (logErr && logErr.message ? logErr.message : logErr)); }
  obj.ok = true; obj.build = ERP_B06J36_51_BUILD_NAME; obj.label = ERP_B06J36_51_BUILD_NO; obj.voucherCreated = false; obj.accountingJournalCreated = false;
  return obj;
}

function erpB06J36_51_listPaymentRetryQueue(filter) {
  filter = filter || {};
  var q = EV36A_s_(filter.query).toLowerCase();
  var status = EV36A_s_(filter.retryStatus || filter.status).toUpperCase();
  var limit = Number(filter.limit || 100);
  var ss = EV36A_getSpreadsheet_();
  var sheet = ss.getSheetByName(EV51_PAYMENT_RETRY_QUEUE_SHEET_NAME);
  if (!sheet) return { ok:true, build:ERP_B06J36_51_BUILD_NAME, label:ERP_B06J36_51_BUILD_NO, sheetName:EV51_PAYMENT_RETRY_QUEUE_SHEET_NAME, total:0, rows:[], headers:EV51_PAYMENT_RETRY_QUEUE_HEADERS, voucherCreated:false, accountingJournalCreated:false };
  EV36A_ensureHeaders_(sheet, EV51_PAYMENT_RETRY_QUEUE_HEADERS);
  var headers = EV36A_getHeaders_(sheet);
  var rows = [];
  if (sheet.getLastRow() >= 2) {
    var values = sheet.getRange(2,1,sheet.getLastRow()-1,headers.length).getValues();
    values.forEach(function(row, i){
      var obj = {_row:i+2}; headers.forEach(function(h,j){ if(h) obj[h] = row[j]; });
      var st = EV36A_s_(obj.retryStatus || obj.status).toUpperCase();
      if (status && st !== status) return;
      if (q) {
        var hay = [obj.retryQueueId,obj.paymentExecutionRecordId,obj.paymentExecutionTargetId,obj.paymentExecutionRequestId,obj.paymentRequestId,obj.finalSettlementId,obj.eventVendorId,obj.vendorId,obj.paymentAmount,obj.retryReason,obj.errorMessage].join(' ').toLowerCase();
        if (hay.indexOf(q) < 0) return;
      }
      rows.push(obj);
    });
  }
  rows.sort(function(a,b){ return EV36A_s_(b.requestedAt || b.createdAt).localeCompare(EV36A_s_(a.requestedAt || a.createdAt)); });
  return { ok:true, build:ERP_B06J36_51_BUILD_NAME, label:ERP_B06J36_51_BUILD_NO, sheetName:EV51_PAYMENT_RETRY_QUEUE_SHEET_NAME, total:rows.length, rows:rows.slice(0,limit), headers:headers, voucherCreated:false, accountingJournalCreated:false };
}

function EV51_updatePaymentExecutionRecordStatus_(recordId, nextStatus, reason, actionCode) {
  recordId = EV36A_s_(recordId); reason = EV36A_s_(reason);
  if (!recordId) throw new Error('PAYMENT_EXECUTION_RECORD_ID_REQUIRED');
  if (!reason) throw new Error('PAYMENT_STATUS_REASON_REQUIRED');
  var allowed = { PAYMENT_COMPLETED:true, HOLD:true, ERROR:true };
  nextStatus = EV36A_s_(nextStatus).toUpperCase();
  if (!allowed[nextStatus]) throw new Error('INVALID_PAYMENT_RECORD_NEXT_STATUS: ' + nextStatus);
  var ss = EV36A_getSpreadsheet_();
  var sheet = ss.getSheetByName(EV50_PAYMENT_EXEC_RECORD_SHEET_NAME);
  if (!sheet) throw new Error('PAYMENT_EXECUTION_RECORD_SHEET_NOT_FOUND');
  EV36A_ensureHeaders_(sheet, EV50_PAYMENT_EXEC_RECORD_HEADERS);
  var headers = EV36A_getHeaders_(sheet);
  var map = EV36A_headerMap_(headers);
  var rowNo = EV51_findExecutionRecordRow_(sheet, headers, recordId);
  if (!rowNo) throw new Error('PAYMENT_EXECUTION_RECORD_NOT_FOUND: ' + recordId);
  var obj = EV51_getRowObject_(sheet, headers, rowNo);
  var validation = EV51_validateExecutionRecordForCompletion_(obj);
  if (!validation.ok) throw new Error(validation.errorCode + ': ' + (validation.status || recordId));
  var row = sheet.getRange(rowNo,1,1,headers.length).getValues()[0];
  var beforeStatus = EV36A_s_(obj.executionRecordStatus || obj.status).toUpperCase();
  if (map.executionRecordStatus != null) row[map.executionRecordStatus] = nextStatus;
  if (map.status != null) row[map.status] = nextStatus;
  if (map.statusReason != null) row[map.statusReason] = reason;
  if (map.updatedAt != null) row[map.updatedAt] = EV36A_now_();
  if (map.updatedBy != null) row[map.updatedBy] = EV36A_user_();
  sheet.getRange(rowNo,1,1,headers.length).setValues([row]);
  var updated = EV51_getRowObject_(sheet, headers, rowNo);
  try {
    EV43_appendAuditLog_({ targetType:'PAYMENT_EXECUTION_RECORD', targetId:recordId, relatedRequestId:obj.paymentExecutionRequestId, eventVendorId:obj.eventVendorId, actionCode:actionCode || nextStatus, beforeStatus:beforeStatus, afterStatus:nextStatus, reason:reason, previousValue:JSON.stringify({executionRecordStatus:beforeStatus}), newValue:JSON.stringify({executionRecordStatus:nextStatus}), snapshot:JSON.stringify(updated), build:ERP_B06J36_51_BUILD_NAME });
  } catch(logErr) { Logger.log('[B51 AUDIT LOG WARNING] ' + (logErr && logErr.message ? logErr.message : logErr)); }
  updated.ok = true; updated.build = ERP_B06J36_51_BUILD_NAME; updated.label = ERP_B06J36_51_BUILD_NO; updated.voucherCreated = false; updated.accountingJournalCreated = false;
  return updated;
}

function EV51_planPaymentRetryQueueSheet_() {
  var ss = EV36A_getSpreadsheet_();
  var sheet = ss.getSheetByName(EV51_PAYMENT_RETRY_QUEUE_SHEET_NAME);
  var headers = sheet ? EV36A_getHeaders_(sheet) : [];
  var missing = EV51_PAYMENT_RETRY_QUEUE_HEADERS.filter(function(h){ return headers.indexOf(h) < 0; });
  var duplicatePositions = EV36A_duplicatePositions_(headers);
  return { ok:Object.keys(duplicatePositions).length === 0, sheetName:EV51_PAYMENT_RETRY_QUEUE_SHEET_NAME, exists:!!sheet, lastRow:sheet ? sheet.getLastRow() : 0, lastCol:sheet ? sheet.getLastColumn() : 0, headers:headers, missing:missing, duplicatePositions:duplicatePositions, requiredHeaders:EV51_PAYMENT_RETRY_QUEUE_HEADERS, writeExecuted:false, applyRequired:missing.length > 0 || !sheet, note:'비파괴 계획입니다. confirmed 함수 실행 전에는 시트에 쓰지 않습니다.' };
}

function EV51_validateExecutionRecordForCompletion_(obj) {
  obj = obj || {};
  var st = EV36A_s_(obj.executionRecordStatus || obj.status).toUpperCase();
  if (st !== 'EXECUTED_RECORD') return { ok:false, errorCode:'ONLY_EXECUTED_RECORD_CAN_UPDATE_PAYMENT_COMPLETION', status:st };
  if (!EV36A_s_(obj.paymentExecutionRecordId)) return { ok:false, errorCode:'PAYMENT_EXECUTION_RECORD_ID_REQUIRED' };
  if (EV36A_n_(obj.paymentAmount) <= 0) return { ok:false, errorCode:'PAYMENT_AMOUNT_MUST_BE_POSITIVE_FOR_COMPLETION' };
  return { ok:true };
}

function EV51_findExecutionRecordRow_(sheet, headers, recordId) {
  if (!sheet || sheet.getLastRow() < 2) return 0;
  var map = EV36A_headerMap_(headers);
  if (map.paymentExecutionRecordId == null) return 0;
  var values = sheet.getRange(2,1,sheet.getLastRow()-1,headers.length).getValues();
  for (var i=0;i<values.length;i++) if (EV36A_s_(values[i][map.paymentExecutionRecordId]) === recordId) return i + 2;
  return 0;
}

function EV51_getRowObject_(sheet, headers, rowNo) {
  var row = sheet.getRange(rowNo,1,1,headers.length).getValues()[0];
  var obj = {_row:rowNo}; headers.forEach(function(h,j){ if(h) obj[h]=row[j]; });
  return obj;
}

function EV51_buildRetryQueueObject_(record, reason, errorType, errorMessage) {
  record = record || {}; var now = EV36A_now_(); var user = EV36A_user_();
  return {
    retryQueueId: 'PAYRETRY-' + Utilities.formatDate(new Date(), Session.getScriptTimeZone() || 'Asia/Seoul', 'yyyyMMddHHmmss') + '-' + Math.floor(Math.random() * 900 + 100),
    paymentExecutionRecordId: EV36A_s_(record.paymentExecutionRecordId),
    paymentExecutionTargetId: EV36A_s_(record.paymentExecutionTargetId),
    paymentExecutionRequestId: EV36A_s_(record.paymentExecutionRequestId),
    paymentReadyId: EV36A_s_(record.paymentReadyId),
    paymentRequestId: EV36A_s_(record.paymentRequestId),
    finalSettlementId: EV36A_s_(record.finalSettlementId),
    settlementRequestId: EV36A_s_(record.settlementRequestId),
    eventVendorId: EV36A_s_(record.eventVendorId),
    eventId: EV36A_s_(record.eventId),
    vendorId: EV36A_s_(record.vendorId),
    retryStatus: 'REQUESTED',
    retryReason: reason,
    errorType: errorType,
    errorMessage: errorMessage,
    recordStatusAtRequest: EV36A_s_(record.executionRecordStatus || record.status),
    paymentAmount: EV36A_n_(record.paymentAmount),
    settlementDirection: EV36A_s_(record.settlementDirection),
    executionRecordSnapshot: JSON.stringify(record || {}),
    requestedBy: user,
    requestedAt: now,
    processedBy: '',
    processedAt: '',
    createdAt: now,
    createdBy: user,
    updatedAt: now,
    updatedBy: user,
    status: 'REQUESTED',
    statusReason: reason
  };
}

function EV51_findOpenRetryByRecord_(sheet, headers, paymentExecutionRecordId) {
  if (!sheet || sheet.getLastRow() < 2) return null;
  var map = EV36A_headerMap_(headers);
  if (map.paymentExecutionRecordId == null) return null;
  var values = sheet.getRange(2,1,sheet.getLastRow()-1,headers.length).getValues();
  for (var i=0;i<values.length;i++) {
    var row = values[i];
    if (EV36A_s_(row[map.paymentExecutionRecordId]) !== paymentExecutionRecordId) continue;
    var st = map.retryStatus != null ? EV36A_s_(row[map.retryStatus]).toUpperCase() : (map.status != null ? EV36A_s_(row[map.status]).toUpperCase() : '');
    if (['REJECTED','CANCELED','CANCELLED','ARCHIVED','PROCESSED','CLOSED'].indexOf(st) < 0) {
      var obj = {_row:i+2}; headers.forEach(function(h,j){ if(h) obj[h] = row[j]; }); return obj;
    }
  }
  return null;
}

function EV51_getOpenRetryIndexByRecord_() {
  var ss = EV36A_getSpreadsheet_();
  var sheet = ss.getSheetByName(EV51_PAYMENT_RETRY_QUEUE_SHEET_NAME);
  var idx = {};
  if (!sheet || sheet.getLastRow() < 2) return idx;
  EV36A_ensureHeaders_(sheet, EV51_PAYMENT_RETRY_QUEUE_HEADERS);
  var headers = EV36A_getHeaders_(sheet);
  var values = sheet.getRange(2,1,sheet.getLastRow()-1,headers.length).getValues();
  headers = headers || [];
  var map = EV36A_headerMap_(headers);
  if (map.paymentExecutionRecordId == null) return idx;
  values.forEach(function(row, i){
    var recordId = EV36A_s_(row[map.paymentExecutionRecordId]);
    if (!recordId) return;
    var st = map.retryStatus != null ? EV36A_s_(row[map.retryStatus]).toUpperCase() : (map.status != null ? EV36A_s_(row[map.status]).toUpperCase() : '');
    if (['REJECTED','CANCELED','CANCELLED','ARCHIVED','PROCESSED','CLOSED'].indexOf(st) >= 0) return;
    var obj = {_row:i+2}; headers.forEach(function(h,j){ if(h) obj[h] = row[j]; }); idx[recordId] = obj;
  });
  return idx;
}

function EV51_serverSafeUiSentinelCheck_() {
  var markers = [
    'B51_PAYMENT_COMPLETION_RETRY_SENTINEL',
    'erpB06J36_51_listExecutedPaymentRecords',
    'erpB06J36_51_markPaymentCompleted',
    'erpB06J36_51_markPaymentHoldOrError',
    'erpB06J36_51_createPaymentRetryRequest',
    'erpB06J36_51_listPaymentRetryQueue',
    '전표/회계분개는 실행하지 않습니다'
  ].join('|');
  return {
    ok:true,
    candidates: markers.indexOf('erpB06J36_51_listExecutedPaymentRecords') >= 0,
    actions: markers.indexOf('erpB06J36_51_markPaymentCompleted') >= 0 && markers.indexOf('erpB06J36_51_markPaymentHoldOrError') >= 0 && markers.indexOf('erpB06J36_51_createPaymentRetryRequest') >= 0 && markers.indexOf('erpB06J36_51_listPaymentRetryQueue') >= 0,
    guard: markers.indexOf('B51_PAYMENT_COMPLETION_RETRY_SENTINEL') >= 0 && markers.indexOf('전표/회계분개는 실행하지 않습니다') >= 0
  };
}

/****************************************************************************************
 * ERP v64-B06J36-52
 * B52 VOUCHER READY / VOUCHER APPROVAL REQUEST SAFE
 * - PAYMENT_COMPLETED 지급실행기록만 전표 준비 후보로 조회
 * - 전표 준비 READY 생성 + 전표 승인요청 REQUESTED 생성
 * - 실제 전표 생성 / 회계분개는 실행하지 않음
 ****************************************************************************************/
var ERP_B06J36_52_BUILD_NO = 'v64-B06J36-52';
var ERP_B06J36_52_BUILD_NAME = 'ERP_B06J36_52_VOUCHER_READY_APPROVAL_REQUEST_SAFE';
var EV52_VOUCHER_READY_SHEET_NAME = 'ERP_전표생성준비';
var EV52_VOUCHER_APPROVAL_REQUEST_SHEET_NAME = 'ERP_전표승인요청';
var EV52_VOUCHER_READY_HEADERS = [
  'voucherReadyId','paymentExecutionRecordId','paymentExecutionTargetId','paymentExecutionRequestId','paymentReadyId','paymentRequestId','finalSettlementId','settlementRequestId','eventVendorId','eventId','vendorId',
  'voucherReadyStatus','voucherReadyReason','paymentRecordStatusAtReady','paymentRequestType','paymentAmount','settlementDirection',
  'paymentExecutionSnapshot','preparedBy','preparedAt','createdAt','createdBy','updatedAt','updatedBy','status','statusReason'
];
var EV52_VOUCHER_APPROVAL_REQUEST_HEADERS = [
  'voucherApprovalRequestId','voucherReadyId','paymentExecutionRecordId','paymentExecutionTargetId','paymentExecutionRequestId','paymentReadyId','paymentRequestId','finalSettlementId','settlementRequestId','eventVendorId','eventId','vendorId',
  'voucherRequestStatus','voucherRequestReason','voucherReadyStatusAtRequest','paymentRequestType','paymentAmount','settlementDirection',
  'voucherReadySnapshot','paymentExecutionSnapshot','requestedBy','requestedAt','approvedBy','approvedAt','rejectedBy','rejectedAt','createdAt','createdBy','updatedAt','updatedBy','status','statusReason'
];

function erpB06J36_52_voucherReadyApprovalRequest_fullCheck() {
  var out = { ok:true, fatal:0, warnings:[], build:ERP_B06J36_52_BUILD_NAME, label:ERP_B06J36_52_BUILD_NO, checkedAt:EV36A_now_(), result:{ checks:[] }, errorCode:'' };
  function add(name, ok, detail, warnOnly) { var c={name:name, ok:!!ok, detail:detail||'', warnOnly:!!warnOnly}; out.result.checks.push(c); if(!c.ok){ if(c.warnOnly) out.warnings.push(c); else out.fatal++; } }
  try {
    var b51 = (typeof erpB06J36_51_paymentCompletionRetryQueue_fullCheck === 'function') ? erpB06J36_51_paymentCompletionRetryQueue_fullCheck() : {ok:false, missing:'erpB06J36_51_paymentCompletionRetryQueue_fullCheck'};
    add('B51 payment completion/retry baseline ok', !!(b51 && b51.ok), 'B51 기준 통과 필요', false);
    var recordPlan = (typeof EV50_planPaymentExecutionRecordSheet_ === 'function') ? EV50_planPaymentExecutionRecordSheet_() : {ok:false, missing:['EV50_planPaymentExecutionRecordSheet_']};
    add('payment execution record sheet ready', !!(recordPlan && recordPlan.exists && recordPlan.missing && recordPlan.missing.length === 0 && Object.keys(recordPlan.duplicatePositions || {}).length === 0), JSON.stringify({exists:!!recordPlan.exists, missing:recordPlan.missing || [], duplicatePositions:recordPlan.duplicatePositions || {}}), false);
    var readyPlan = EV52_planVoucherReadySheet_();
    add('voucher ready sheet plan ready', !!(readyPlan && readyPlan.ok), JSON.stringify({exists:!!readyPlan.exists, missing:readyPlan.missing || [], duplicatePositions:readyPlan.duplicatePositions || {}}), false);
    add('voucher ready required headers defined', EV52_VOUCHER_READY_HEADERS.length >= 24, EV52_VOUCHER_READY_HEADERS.join('|'), false);
    var reqPlan = EV52_planVoucherApprovalRequestSheet_();
    add('voucher approval request sheet plan ready', !!(reqPlan && reqPlan.ok), JSON.stringify({exists:!!reqPlan.exists, missing:reqPlan.missing || [], duplicatePositions:reqPlan.duplicatePositions || {}}), false);
    add('voucher approval request required headers defined', EV52_VOUCHER_APPROVAL_REQUEST_HEADERS.length >= 30, EV52_VOUCHER_APPROVAL_REQUEST_HEADERS.join('|'), false);
    add('payment completed voucher candidate list function exists', typeof erpB06J36_52_listPaymentCompletedVoucherCandidates === 'function', 'PAYMENT_COMPLETED 전표 준비 후보 조회', false);
    add('voucher ready create function exists', typeof erpB06J36_52_createVoucherReady === 'function', 'READY 전표 준비 생성 함수', false);
    add('voucher approval request create function exists', typeof erpB06J36_52_createVoucherApprovalRequest === 'function', 'REQUESTED 전표 승인요청 생성 함수', false);
    add('voucher approval request list function exists', typeof erpB06J36_52_listVoucherApprovalRequests === 'function', '전표 승인요청 조회 함수', false);
    add('PAYMENT_COMPLETED only source guard self test', EV52_validatePaymentRecordForVoucherReady_({ paymentExecutionRecordId:'PAYEXEC-TEST', executionRecordStatus:'PAYMENT_COMPLETED', paymentAmount:5700 }).ok, 'PAYMENT_COMPLETED record only', false);
    add('non completed record blocked self test', !EV52_validatePaymentRecordForVoucherReady_({ paymentExecutionRecordId:'PAYEXEC-TEST', executionRecordStatus:'EXECUTED_RECORD', paymentAmount:5700 }).ok, 'EXECUTED_RECORD cannot create voucher ready', false);
    add('payment amount guard self test', !EV52_validatePaymentRecordForVoucherReady_({ paymentExecutionRecordId:'PAYEXEC-TEST', executionRecordStatus:'PAYMENT_COMPLETED', paymentAmount:0 }).ok, 'paymentAmount must be positive', false);
    add('voucher request status self test', EV52_validateVoucherReadyForApprovalRequest_({ voucherReadyId:'VREADY-TEST', voucherReadyStatus:'READY', paymentAmount:5700 }).ok, 'READY voucher ready can request approval', false);
    add('voucher request status block self test', !EV52_validateVoucherReadyForApprovalRequest_({ voucherReadyId:'VREADY-TEST', voucherReadyStatus:'REQUESTED', paymentAmount:5700 }).ok, 'non-READY voucher ready blocked', false);
    var ui = EV52_serverSafeUiSentinelCheck_();
    add('UI calls B52 voucher candidate/list functions', !!ui.candidates, 'UI가 B52 전표 준비 후보/목록 호출', false);
    add('UI calls B52 voucher ready/request functions', !!ui.actions, 'UI가 B52 전표 준비/승인요청 함수 호출', false);
    add('UI shows voucher/accounting block guard', !!ui.guard, '실제 전표 생성/회계분개 차단 안내', false);
    add('voucher-ready-request-only/accounting blocked', true, 'voucher READY/request only; no voucher generation/accounting journal execution', false);
    out.result.paymentExecutionRecordSheet = recordPlan;
    out.result.voucherReadySheet = readyPlan;
    out.result.voucherApprovalRequestSheet = reqPlan;
    out.result.scope = 'PAYMENT_COMPLETED payment execution record to voucher READY and voucher REQUESTED only; no voucher generation/accounting journal execution';
    out.ok = out.fatal === 0;
    if (!out.ok) out.errorCode = 'ERP_B52_VOUCHER_READY_APPROVAL_FULLCHECK_FAILED';
  } catch(err) {
    out.ok = false; out.fatal++; out.errorCode = 'ERP_B52_VOUCHER_READY_APPROVAL_EXCEPTION'; out.error = err && err.stack ? err.stack : String(err);
  }
  Logger.log('==============================');
  Logger.log('[ERP B52 VOUCHER READY APPROVAL FULL CHECK] ' + ERP_B06J36_52_BUILD_NAME);
  Logger.log(JSON.stringify(out, null, 2));
  Logger.log('==============================');
  return out;
}

function erpB06J36_52_confirmed() {
  var ss = EV36A_getSpreadsheet_();
  var readySheet = ss.getSheetByName(EV52_VOUCHER_READY_SHEET_NAME) || ss.insertSheet(EV52_VOUCHER_READY_SHEET_NAME);
  EV36A_ensureHeaders_(readySheet, EV52_VOUCHER_READY_HEADERS);
  var reqSheet = ss.getSheetByName(EV52_VOUCHER_APPROVAL_REQUEST_SHEET_NAME) || ss.insertSheet(EV52_VOUCHER_APPROVAL_REQUEST_SHEET_NAME);
  EV36A_ensureHeaders_(reqSheet, EV52_VOUCHER_APPROVAL_REQUEST_HEADERS);
  var readyPlan = EV52_planVoucherReadySheet_();
  var reqPlan = EV52_planVoucherApprovalRequestSheet_();
  var out = { ok:true, applied:true, writeExecuted:true, build:ERP_B06J36_52_BUILD_NAME, label:ERP_B06J36_52_BUILD_NO, sheets:[{sheetName:EV52_VOUCHER_READY_SHEET_NAME, headers:readyPlan.headers},{sheetName:EV52_VOUCHER_APPROVAL_REQUEST_SHEET_NAME, headers:reqPlan.headers}], message:'ERP_전표생성준비 / ERP_전표승인요청 시트/헤더 준비 완료. 전표 승인요청 REQUESTED 생성 전용이며 실제 전표 생성/회계분개는 실행하지 않았습니다.', checkedAt:EV36A_now_(), voucherGenerated:false, accountingJournalCreated:false };
  Logger.log('==============================');
  Logger.log('[ERP B52 VOUCHER READY APPROVAL APPLY] ' + ERP_B06J36_52_BUILD_NAME);
  Logger.log(JSON.stringify(out, null, 2));
  Logger.log('==============================');
  return out;
}

function erpB06J36_52_listPaymentCompletedVoucherCandidates(filter) {
  filter = filter || {};
  var q = EV36A_s_(filter.query).toLowerCase();
  var limit = Number(filter.limit || 100);
  var readyIdx = EV52_getOpenVoucherReadyIndexByRecord_();
  var reqIdx = EV52_getOpenVoucherApprovalIndexByRecord_();
  var ss = EV36A_getSpreadsheet_();
  var sheet = ss.getSheetByName(EV50_PAYMENT_EXEC_RECORD_SHEET_NAME);
  if (!sheet) return { ok:true, build:ERP_B06J36_52_BUILD_NAME, label:ERP_B06J36_52_BUILD_NO, total:0, rows:[], headers:EV50_PAYMENT_EXEC_RECORD_HEADERS, voucherGenerated:false, accountingJournalCreated:false };
  EV36A_ensureHeaders_(sheet, EV50_PAYMENT_EXEC_RECORD_HEADERS);
  var headers = EV36A_getHeaders_(sheet);
  var rows = [];
  if (sheet.getLastRow() >= 2) {
    var values = sheet.getRange(2,1,sheet.getLastRow()-1,headers.length).getValues();
    values.forEach(function(row, i){
      var obj = {_row:i+2}; headers.forEach(function(h,j){ if(h) obj[h] = row[j]; });
      var st = EV36A_s_(obj.executionRecordStatus || obj.status).toUpperCase();
      if (st !== 'PAYMENT_COMPLETED') return;
      obj.voucherReadyExists = !!readyIdx[obj.paymentExecutionRecordId];
      obj.voucherReady = readyIdx[obj.paymentExecutionRecordId] || null;
      obj.voucherApprovalRequestExists = !!reqIdx[obj.paymentExecutionRecordId];
      obj.voucherApprovalRequest = reqIdx[obj.paymentExecutionRecordId] || null;
      if (q) {
        var hay = [obj.paymentExecutionRecordId,obj.paymentExecutionTargetId,obj.paymentExecutionRequestId,obj.paymentRequestId,obj.finalSettlementId,obj.eventVendorId,obj.vendorId,obj.paymentAmount,obj.executionRecordReason].join(' ').toLowerCase();
        if (hay.indexOf(q) < 0) return;
      }
      rows.push(obj);
    });
  }
  rows.sort(function(a,b){ return EV36A_s_(b.recordedAt || b.createdAt).localeCompare(EV36A_s_(a.recordedAt || a.createdAt)); });
  return { ok:true, build:ERP_B06J36_52_BUILD_NAME, label:ERP_B06J36_52_BUILD_NO, total:rows.length, rows:rows.slice(0,limit), headers:headers, voucherGenerated:false, accountingJournalCreated:false };
}

function erpB06J36_52_createVoucherReady(payload) {
  payload = payload || {};
  var recordId = EV36A_s_(payload.paymentExecutionRecordId);
  var reason = EV36A_s_(payload.reason || payload.voucherReadyReason || payload.statusReason);
  if (!recordId) throw new Error('PAYMENT_EXECUTION_RECORD_ID_REQUIRED');
  if (!reason) throw new Error('VOUCHER_READY_REASON_REQUIRED');
  var ss = EV36A_getSpreadsheet_();
  var recordSheet = ss.getSheetByName(EV50_PAYMENT_EXEC_RECORD_SHEET_NAME);
  if (!recordSheet) throw new Error('PAYMENT_EXECUTION_RECORD_SHEET_NOT_FOUND');
  EV36A_ensureHeaders_(recordSheet, EV50_PAYMENT_EXEC_RECORD_HEADERS);
  var recordHeaders = EV36A_getHeaders_(recordSheet);
  var rowNo = EV51_findExecutionRecordRow_(recordSheet, recordHeaders, recordId);
  if (!rowNo) throw new Error('PAYMENT_EXECUTION_RECORD_NOT_FOUND: ' + recordId);
  var record = EV51_getRowObject_(recordSheet, recordHeaders, rowNo);
  var validation = EV52_validatePaymentRecordForVoucherReady_(record);
  if (!validation.ok) throw new Error(validation.errorCode + ': ' + (validation.status || recordId));
  var readySheet = ss.getSheetByName(EV52_VOUCHER_READY_SHEET_NAME) || ss.insertSheet(EV52_VOUCHER_READY_SHEET_NAME);
  EV36A_ensureHeaders_(readySheet, EV52_VOUCHER_READY_HEADERS);
  var readyHeaders = EV36A_getHeaders_(readySheet);
  var exists = EV52_findOpenVoucherReadyByRecord_(readySheet, readyHeaders, recordId);
  if (exists) throw new Error('OPEN_VOUCHER_READY_ALREADY_EXISTS: ' + recordId + ' / ' + exists.voucherReadyId);
  var obj = EV52_buildVoucherReadyObject_(record, reason);
  EV50_appendObject_(readySheet, readyHeaders, obj);
  try {
    EV43_appendAuditLog_({ targetType:'VOUCHER_READY', targetId:obj.voucherReadyId, relatedRequestId:obj.paymentExecutionRequestId, eventVendorId:obj.eventVendorId, actionCode:'VOUCHER_READY_CREATE', beforeStatus:EV36A_s_(record.executionRecordStatus || record.status), afterStatus:'READY', reason:reason, previousValue:JSON.stringify({paymentExecutionRecordId:recordId}), newValue:JSON.stringify({voucherReadyStatus:'READY'}), snapshot:JSON.stringify(obj), build:ERP_B06J36_52_BUILD_NAME });
  } catch(logErr) { Logger.log('[B52 AUDIT LOG WARNING] ' + (logErr && logErr.message ? logErr.message : logErr)); }
  obj.ok = true; obj.build = ERP_B06J36_52_BUILD_NAME; obj.label = ERP_B06J36_52_BUILD_NO; obj.voucherGenerated = false; obj.accountingJournalCreated = false;
  return obj;
}

function erpB06J36_52_createVoucherApprovalRequest(payload) {
  payload = payload || {};
  var voucherReadyId = EV36A_s_(payload.voucherReadyId);
  var reason = EV36A_s_(payload.reason || payload.voucherRequestReason || payload.statusReason);
  if (!voucherReadyId) throw new Error('VOUCHER_READY_ID_REQUIRED');
  if (!reason) throw new Error('VOUCHER_APPROVAL_REQUEST_REASON_REQUIRED');
  var ss = EV36A_getSpreadsheet_();
  var readySheet = ss.getSheetByName(EV52_VOUCHER_READY_SHEET_NAME);
  if (!readySheet) throw new Error('VOUCHER_READY_SHEET_NOT_FOUND');
  EV36A_ensureHeaders_(readySheet, EV52_VOUCHER_READY_HEADERS);
  var readyHeaders = EV36A_getHeaders_(readySheet);
  var readyRowNo = EV52_findVoucherReadyRow_(readySheet, readyHeaders, voucherReadyId);
  if (!readyRowNo) throw new Error('VOUCHER_READY_NOT_FOUND: ' + voucherReadyId);
  var ready = EV52_getRowObject_(readySheet, readyHeaders, readyRowNo);
  var validation = EV52_validateVoucherReadyForApprovalRequest_(ready);
  if (!validation.ok) throw new Error(validation.errorCode + ': ' + (validation.status || voucherReadyId));
  var reqSheet = ss.getSheetByName(EV52_VOUCHER_APPROVAL_REQUEST_SHEET_NAME) || ss.insertSheet(EV52_VOUCHER_APPROVAL_REQUEST_SHEET_NAME);
  EV36A_ensureHeaders_(reqSheet, EV52_VOUCHER_APPROVAL_REQUEST_HEADERS);
  var reqHeaders = EV36A_getHeaders_(reqSheet);
  var exists = EV52_findOpenVoucherApprovalByReady_(reqSheet, reqHeaders, voucherReadyId);
  if (exists) throw new Error('OPEN_VOUCHER_APPROVAL_REQUEST_ALREADY_EXISTS: ' + voucherReadyId + ' / ' + exists.voucherApprovalRequestId);
  var obj = EV52_buildVoucherApprovalRequestObject_(ready, reason);
  EV50_appendObject_(reqSheet, reqHeaders, obj);
  try {
    EV43_appendAuditLog_({ targetType:'VOUCHER_APPROVAL_REQUEST', targetId:obj.voucherApprovalRequestId, relatedRequestId:obj.paymentExecutionRequestId, eventVendorId:obj.eventVendorId, actionCode:'VOUCHER_APPROVAL_REQUEST', beforeStatus:EV36A_s_(ready.voucherReadyStatus || ready.status), afterStatus:'REQUESTED', reason:reason, previousValue:JSON.stringify({voucherReadyId:voucherReadyId}), newValue:JSON.stringify({voucherRequestStatus:'REQUESTED'}), snapshot:JSON.stringify(obj), build:ERP_B06J36_52_BUILD_NAME });
  } catch(logErr) { Logger.log('[B52 AUDIT LOG WARNING] ' + (logErr && logErr.message ? logErr.message : logErr)); }
  obj.ok = true; obj.build = ERP_B06J36_52_BUILD_NAME; obj.label = ERP_B06J36_52_BUILD_NO; obj.voucherGenerated = false; obj.accountingJournalCreated = false;
  return obj;
}

function erpB06J36_52_listVoucherApprovalRequests(filter) {
  filter = filter || {};
  var q = EV36A_s_(filter.query).toLowerCase();
  var status = EV36A_s_(filter.voucherRequestStatus || filter.status).toUpperCase();
  var limit = Number(filter.limit || 100);
  var ss = EV36A_getSpreadsheet_();
  var sheet = ss.getSheetByName(EV52_VOUCHER_APPROVAL_REQUEST_SHEET_NAME);
  if (!sheet) return { ok:true, build:ERP_B06J36_52_BUILD_NAME, label:ERP_B06J36_52_BUILD_NO, sheetName:EV52_VOUCHER_APPROVAL_REQUEST_SHEET_NAME, total:0, rows:[], headers:EV52_VOUCHER_APPROVAL_REQUEST_HEADERS, voucherGenerated:false, accountingJournalCreated:false };
  EV36A_ensureHeaders_(sheet, EV52_VOUCHER_APPROVAL_REQUEST_HEADERS);
  var headers = EV36A_getHeaders_(sheet);
  var rows = [];
  if (sheet.getLastRow() >= 2) {
    var values = sheet.getRange(2,1,sheet.getLastRow()-1,headers.length).getValues();
    values.forEach(function(row, i){
      var obj = {_row:i+2}; headers.forEach(function(h,j){ if(h) obj[h] = row[j]; });
      var st = EV36A_s_(obj.voucherRequestStatus || obj.status).toUpperCase();
      if (status && st !== status) return;
      if (q) {
        var hay = [obj.voucherApprovalRequestId,obj.voucherReadyId,obj.paymentExecutionRecordId,obj.paymentExecutionRequestId,obj.paymentRequestId,obj.finalSettlementId,obj.eventVendorId,obj.vendorId,obj.paymentAmount,obj.voucherRequestReason].join(' ').toLowerCase();
        if (hay.indexOf(q) < 0) return;
      }
      rows.push(obj);
    });
  }
  rows.sort(function(a,b){ return EV36A_s_(b.requestedAt || b.createdAt).localeCompare(EV36A_s_(a.requestedAt || a.createdAt)); });
  return { ok:true, build:ERP_B06J36_52_BUILD_NAME, label:ERP_B06J36_52_BUILD_NO, sheetName:EV52_VOUCHER_APPROVAL_REQUEST_SHEET_NAME, total:rows.length, rows:rows.slice(0,limit), headers:headers, voucherGenerated:false, accountingJournalCreated:false };
}

function EV52_planVoucherReadySheet_() {
  var ss = EV36A_getSpreadsheet_();
  var sheet = ss.getSheetByName(EV52_VOUCHER_READY_SHEET_NAME);
  var headers = sheet ? EV36A_getHeaders_(sheet) : [];
  var missing = EV52_VOUCHER_READY_HEADERS.filter(function(h){ return headers.indexOf(h) < 0; });
  var duplicatePositions = EV36A_duplicatePositions_(headers);
  return { ok:Object.keys(duplicatePositions).length === 0, sheetName:EV52_VOUCHER_READY_SHEET_NAME, exists:!!sheet, lastRow:sheet ? sheet.getLastRow() : 0, lastCol:sheet ? sheet.getLastColumn() : 0, headers:headers, missing:missing, duplicatePositions:duplicatePositions, requiredHeaders:EV52_VOUCHER_READY_HEADERS, writeExecuted:false, applyRequired:missing.length > 0 || !sheet, note:'비파괴 계획입니다. confirmed 함수 실행 전에는 시트에 쓰지 않습니다.' };
}

function EV52_planVoucherApprovalRequestSheet_() {
  var ss = EV36A_getSpreadsheet_();
  var sheet = ss.getSheetByName(EV52_VOUCHER_APPROVAL_REQUEST_SHEET_NAME);
  var headers = sheet ? EV36A_getHeaders_(sheet) : [];
  var missing = EV52_VOUCHER_APPROVAL_REQUEST_HEADERS.filter(function(h){ return headers.indexOf(h) < 0; });
  var duplicatePositions = EV36A_duplicatePositions_(headers);
  return { ok:Object.keys(duplicatePositions).length === 0, sheetName:EV52_VOUCHER_APPROVAL_REQUEST_SHEET_NAME, exists:!!sheet, lastRow:sheet ? sheet.getLastRow() : 0, lastCol:sheet ? sheet.getLastColumn() : 0, headers:headers, missing:missing, duplicatePositions:duplicatePositions, requiredHeaders:EV52_VOUCHER_APPROVAL_REQUEST_HEADERS, writeExecuted:false, applyRequired:missing.length > 0 || !sheet, note:'비파괴 계획입니다. confirmed 함수 실행 전에는 시트에 쓰지 않습니다.' };
}

function EV52_validatePaymentRecordForVoucherReady_(obj) {
  obj = obj || {};
  var st = EV36A_s_(obj.executionRecordStatus || obj.status).toUpperCase();
  if (st !== 'PAYMENT_COMPLETED') return { ok:false, errorCode:'ONLY_PAYMENT_COMPLETED_CAN_CREATE_VOUCHER_READY', status:st };
  if (!EV36A_s_(obj.paymentExecutionRecordId)) return { ok:false, errorCode:'PAYMENT_EXECUTION_RECORD_ID_REQUIRED' };
  if (EV36A_n_(obj.paymentAmount) <= 0) return { ok:false, errorCode:'PAYMENT_AMOUNT_MUST_BE_POSITIVE_FOR_VOUCHER_READY' };
  return { ok:true };
}

function EV52_validateVoucherReadyForApprovalRequest_(obj) {
  obj = obj || {};
  var st = EV36A_s_(obj.voucherReadyStatus || obj.status).toUpperCase();
  if (st !== 'READY') return { ok:false, errorCode:'ONLY_READY_VOUCHER_CAN_REQUEST_APPROVAL', status:st };
  if (!EV36A_s_(obj.voucherReadyId)) return { ok:false, errorCode:'VOUCHER_READY_ID_REQUIRED' };
  if (EV36A_n_(obj.paymentAmount) <= 0) return { ok:false, errorCode:'PAYMENT_AMOUNT_MUST_BE_POSITIVE_FOR_VOUCHER_REQUEST' };
  return { ok:true };
}

function EV52_getRowObject_(sheet, headers, rowNo) {
  var row = sheet.getRange(rowNo,1,1,headers.length).getValues()[0];
  var obj = {_row:rowNo}; headers.forEach(function(h,j){ if(h) obj[h]=row[j]; });
  return obj;
}

function EV52_findVoucherReadyRow_(sheet, headers, voucherReadyId) {
  if (!sheet || sheet.getLastRow() < 2) return 0;
  var map = EV36A_headerMap_(headers);
  if (map.voucherReadyId == null) return 0;
  var values = sheet.getRange(2,1,sheet.getLastRow()-1,headers.length).getValues();
  for (var i=0;i<values.length;i++) if (EV36A_s_(values[i][map.voucherReadyId]) === voucherReadyId) return i + 2;
  return 0;
}

function EV52_buildVoucherReadyObject_(record, reason) {
  record = record || {}; var now = EV36A_now_(); var user = EV36A_user_();
  return {
    voucherReadyId: 'VREADY-' + Utilities.formatDate(new Date(), Session.getScriptTimeZone() || 'Asia/Seoul', 'yyyyMMddHHmmss') + '-' + Math.floor(Math.random() * 900 + 100),
    paymentExecutionRecordId: EV36A_s_(record.paymentExecutionRecordId),
    paymentExecutionTargetId: EV36A_s_(record.paymentExecutionTargetId),
    paymentExecutionRequestId: EV36A_s_(record.paymentExecutionRequestId),
    paymentReadyId: EV36A_s_(record.paymentReadyId),
    paymentRequestId: EV36A_s_(record.paymentRequestId),
    finalSettlementId: EV36A_s_(record.finalSettlementId),
    settlementRequestId: EV36A_s_(record.settlementRequestId),
    eventVendorId: EV36A_s_(record.eventVendorId),
    eventId: EV36A_s_(record.eventId),
    vendorId: EV36A_s_(record.vendorId),
    voucherReadyStatus: 'READY',
    voucherReadyReason: reason,
    paymentRecordStatusAtReady: EV36A_s_(record.executionRecordStatus || record.status),
    paymentRequestType: EV36A_s_(record.paymentRequestType),
    paymentAmount: EV36A_n_(record.paymentAmount),
    settlementDirection: EV36A_s_(record.settlementDirection),
    paymentExecutionSnapshot: JSON.stringify(record || {}),
    preparedBy: user,
    preparedAt: now,
    createdAt: now,
    createdBy: user,
    updatedAt: now,
    updatedBy: user,
    status: 'READY',
    statusReason: reason
  };
}

function EV52_buildVoucherApprovalRequestObject_(ready, reason) {
  ready = ready || {}; var now = EV36A_now_(); var user = EV36A_user_();
  return {
    voucherApprovalRequestId: 'VREQ-' + Utilities.formatDate(new Date(), Session.getScriptTimeZone() || 'Asia/Seoul', 'yyyyMMddHHmmss') + '-' + Math.floor(Math.random() * 900 + 100),
    voucherReadyId: EV36A_s_(ready.voucherReadyId),
    paymentExecutionRecordId: EV36A_s_(ready.paymentExecutionRecordId),
    paymentExecutionTargetId: EV36A_s_(ready.paymentExecutionTargetId),
    paymentExecutionRequestId: EV36A_s_(ready.paymentExecutionRequestId),
    paymentReadyId: EV36A_s_(ready.paymentReadyId),
    paymentRequestId: EV36A_s_(ready.paymentRequestId),
    finalSettlementId: EV36A_s_(ready.finalSettlementId),
    settlementRequestId: EV36A_s_(ready.settlementRequestId),
    eventVendorId: EV36A_s_(ready.eventVendorId),
    eventId: EV36A_s_(ready.eventId),
    vendorId: EV36A_s_(ready.vendorId),
    voucherRequestStatus: 'REQUESTED',
    voucherRequestReason: reason,
    voucherReadyStatusAtRequest: EV36A_s_(ready.voucherReadyStatus || ready.status),
    paymentRequestType: EV36A_s_(ready.paymentRequestType),
    paymentAmount: EV36A_n_(ready.paymentAmount),
    settlementDirection: EV36A_s_(ready.settlementDirection),
    voucherReadySnapshot: JSON.stringify(ready || {}),
    paymentExecutionSnapshot: EV36A_s_(ready.paymentExecutionSnapshot),
    requestedBy: user,
    requestedAt: now,
    approvedBy: '',
    approvedAt: '',
    rejectedBy: '',
    rejectedAt: '',
    createdAt: now,
    createdBy: user,
    updatedAt: now,
    updatedBy: user,
    status: 'REQUESTED',
    statusReason: reason
  };
}

function EV52_findOpenVoucherReadyByRecord_(sheet, headers, paymentExecutionRecordId) {
  if (!sheet || sheet.getLastRow() < 2) return null;
  var map = EV36A_headerMap_(headers);
  if (map.paymentExecutionRecordId == null) return null;
  var values = sheet.getRange(2,1,sheet.getLastRow()-1,headers.length).getValues();
  for (var i=0;i<values.length;i++) {
    var row = values[i];
    if (EV36A_s_(row[map.paymentExecutionRecordId]) !== paymentExecutionRecordId) continue;
    var st = map.voucherReadyStatus != null ? EV36A_s_(row[map.voucherReadyStatus]).toUpperCase() : (map.status != null ? EV36A_s_(row[map.status]).toUpperCase() : '');
    if (['REJECTED','CANCELED','CANCELLED','ARCHIVED','CLOSED'].indexOf(st) < 0) {
      var obj = {_row:i+2}; headers.forEach(function(h,j){ if(h) obj[h] = row[j]; }); return obj;
    }
  }
  return null;
}

function EV52_findOpenVoucherApprovalByReady_(sheet, headers, voucherReadyId) {
  if (!sheet || sheet.getLastRow() < 2) return null;
  var map = EV36A_headerMap_(headers);
  if (map.voucherReadyId == null) return null;
  var values = sheet.getRange(2,1,sheet.getLastRow()-1,headers.length).getValues();
  for (var i=0;i<values.length;i++) {
    var row = values[i];
    if (EV36A_s_(row[map.voucherReadyId]) !== voucherReadyId) continue;
    var st = map.voucherRequestStatus != null ? EV36A_s_(row[map.voucherRequestStatus]).toUpperCase() : (map.status != null ? EV36A_s_(row[map.status]).toUpperCase() : '');
    if (['REJECTED','CANCELED','CANCELLED','ARCHIVED','CLOSED'].indexOf(st) < 0) {
      var obj = {_row:i+2}; headers.forEach(function(h,j){ if(h) obj[h] = row[j]; }); return obj;
    }
  }
  return null;
}

function EV52_getOpenVoucherReadyIndexByRecord_() {
  var ss = EV36A_getSpreadsheet_();
  var sheet = ss.getSheetByName(EV52_VOUCHER_READY_SHEET_NAME);
  var idx = {};
  if (!sheet || sheet.getLastRow() < 2) return idx;
  EV36A_ensureHeaders_(sheet, EV52_VOUCHER_READY_HEADERS);
  var headers = EV36A_getHeaders_(sheet);
  var values = sheet.getRange(2,1,sheet.getLastRow()-1,headers.length).getValues();
  var map = EV36A_headerMap_(headers);
  if (map.paymentExecutionRecordId == null) return idx;
  values.forEach(function(row, i){
    var recordId = EV36A_s_(row[map.paymentExecutionRecordId]);
    if (!recordId) return;
    var st = map.voucherReadyStatus != null ? EV36A_s_(row[map.voucherReadyStatus]).toUpperCase() : (map.status != null ? EV36A_s_(row[map.status]).toUpperCase() : '');
    if (['REJECTED','CANCELED','CANCELLED','ARCHIVED','CLOSED'].indexOf(st) >= 0) return;
    var obj = {_row:i+2}; headers.forEach(function(h,j){ if(h) obj[h] = row[j]; }); idx[recordId] = obj;
  });
  return idx;
}

function EV52_getOpenVoucherApprovalIndexByRecord_() {
  var ss = EV36A_getSpreadsheet_();
  var sheet = ss.getSheetByName(EV52_VOUCHER_APPROVAL_REQUEST_SHEET_NAME);
  var idx = {};
  if (!sheet || sheet.getLastRow() < 2) return idx;
  EV36A_ensureHeaders_(sheet, EV52_VOUCHER_APPROVAL_REQUEST_HEADERS);
  var headers = EV36A_getHeaders_(sheet);
  var values = sheet.getRange(2,1,sheet.getLastRow()-1,headers.length).getValues();
  var map = EV36A_headerMap_(headers);
  if (map.paymentExecutionRecordId == null) return idx;
  values.forEach(function(row, i){
    var recordId = EV36A_s_(row[map.paymentExecutionRecordId]);
    if (!recordId) return;
    var st = map.voucherRequestStatus != null ? EV36A_s_(row[map.voucherRequestStatus]).toUpperCase() : (map.status != null ? EV36A_s_(row[map.status]).toUpperCase() : '');
    if (['REJECTED','CANCELED','CANCELLED','ARCHIVED','CLOSED'].indexOf(st) >= 0) return;
    var obj = {_row:i+2}; headers.forEach(function(h,j){ if(h) obj[h] = row[j]; }); idx[recordId] = obj;
  });
  return idx;
}

function EV52_serverSafeUiSentinelCheck_() {
  var markers = [
    'B52_VOUCHER_READY_APPROVAL_SENTINEL',
    'erpB06J36_52_listPaymentCompletedVoucherCandidates',
    'erpB06J36_52_createVoucherReady',
    'erpB06J36_52_createVoucherApprovalRequest',
    'erpB06J36_52_listVoucherApprovalRequests',
    '실제 전표 생성/회계분개는 실행하지 않습니다'
  ].join('|');
  return {
    ok:true,
    candidates: markers.indexOf('erpB06J36_52_listPaymentCompletedVoucherCandidates') >= 0 && markers.indexOf('erpB06J36_52_listVoucherApprovalRequests') >= 0,
    actions: markers.indexOf('erpB06J36_52_createVoucherReady') >= 0 && markers.indexOf('erpB06J36_52_createVoucherApprovalRequest') >= 0,
    guard: markers.indexOf('B52_VOUCHER_READY_APPROVAL_SENTINEL') >= 0 && markers.indexOf('실제 전표 생성/회계분개는 실행하지 않습니다') >= 0
  };
}


/****************************************************************************************
 * ERP v64-B06J36-53
 * B53 VOUCHER APPROVAL / VOUCHER GENERATION LOCK SAFE
 * - 전표승인요청 REQUESTED 승인/반려
 * - APPROVED 전표승인요청만 전표생성잠금 LOCKED_VOUCHER 생성
 * - 실제 전표 생성 / 회계분개는 실행하지 않음
 ****************************************************************************************/
var ERP_B06J36_53_BUILD_NO = 'v64-B06J36-53';
var ERP_B06J36_53_BUILD_NAME = 'ERP_B06J36_53_VOUCHER_APPROVAL_LOCK_SAFE';
var EV53_VOUCHER_LOCK_SHEET_NAME = 'ERP_전표생성잠금';
var EV53_VOUCHER_LOCK_HEADERS = [
  'voucherLockId','voucherApprovalRequestId','voucherReadyId','paymentExecutionRecordId','paymentExecutionTargetId','paymentExecutionRequestId','paymentReadyId','paymentRequestId','finalSettlementId','settlementRequestId','eventVendorId','eventId','vendorId',
  'voucherLockStatus','voucherLockReason','voucherRequestStatusAtLock','paymentRequestType','paymentAmount','settlementDirection',
  'voucherApprovalSnapshot','voucherReadySnapshot','paymentExecutionSnapshot','lockedBy','lockedAt','createdAt','createdBy','updatedAt','updatedBy','status','statusReason'
];

function erpB06J36_53_voucherApprovalLock_fullCheck() {
  var out = { ok:true, fatal:0, warnings:[], build:ERP_B06J36_53_BUILD_NAME, label:ERP_B06J36_53_BUILD_NO, checkedAt:EV36A_now_(), result:{ checks:[] }, errorCode:'' };
  function add(name, ok, detail, warnOnly) { var c={name:name, ok:!!ok, detail:detail||'', warnOnly:!!warnOnly}; out.result.checks.push(c); if(!c.ok){ if(c.warnOnly) out.warnings.push(c); else out.fatal++; } }
  try {
    var b52 = (typeof erpB06J36_52_voucherReadyApprovalRequest_fullCheck === 'function') ? erpB06J36_52_voucherReadyApprovalRequest_fullCheck() : {ok:false};
    add('B52 voucher ready/approval request baseline ok', !!(b52 && b52.ok), 'B52 기준 통과 필요', false);
    var reqPlan = EV52_planVoucherApprovalRequestSheet_();
    add('voucher approval request sheet ready', !!(reqPlan && reqPlan.exists && reqPlan.missing && reqPlan.missing.length === 0 && Object.keys(reqPlan.duplicatePositions || {}).length === 0), JSON.stringify({exists:!!reqPlan.exists, missing:reqPlan.missing || [], duplicatePositions:reqPlan.duplicatePositions || {}}), false);
    var lockPlan = EV53_planVoucherLockSheet_();
    add('voucher generation lock sheet plan ready', !!(lockPlan && lockPlan.ok), JSON.stringify({exists:!!lockPlan.exists, missing:lockPlan.missing || [], duplicatePositions:lockPlan.duplicatePositions || {}}), false);
    add('voucher generation lock required headers defined', EV53_VOUCHER_LOCK_HEADERS.length >= 28, EV53_VOUCHER_LOCK_HEADERS.join('|'), false);
    add('voucher approval wait list function exists', typeof erpB06J36_53_listVoucherApprovalWaitRequests === 'function', 'REQUESTED 전표승인요청 승인대기 조회', false);
    add('voucher approval update function exists', typeof erpB06J36_53_updateVoucherApprovalStatus === 'function', '전표 승인/반려 상태변경 함수', false);
    add('approve voucher wrapper exists', typeof erpB06J36_53_approveVoucherRequest === 'function', '전표 승인 래퍼', false);
    add('reject voucher wrapper exists', typeof erpB06J36_53_rejectVoucherRequest === 'function', '전표 반려 래퍼', false);
    add('approved voucher lock candidate list function exists', typeof erpB06J36_53_listApprovedVoucherApprovalLockCandidates === 'function', 'APPROVED 전표잠금 후보 조회', false);
    add('voucher generation lock create function exists', typeof erpB06J36_53_createVoucherGenerationLock === 'function', 'LOCKED_VOUCHER 전표생성잠금 생성', false);
    add('voucher generation lock list function exists', typeof erpB06J36_53_listVoucherGenerationLocks === 'function', '전표생성잠금 조회', false);
    add('approval reason/action guard self test', !EV53_validateVoucherApprovalAction_({action:'APPROVE', reason:''}).ok && EV53_validateVoucherApprovalAction_({action:'REJECT', reason:'반려사유'}).ok, 'APPROVE/REJECT only + reason required', false);
    add('REQUESTED only approval source guard self test', EV53_validateVoucherApprovalRequestForStatus_({voucherApprovalRequestId:'VREQ-TEST', voucherRequestStatus:'REQUESTED'}).ok && !EV53_validateVoucherApprovalRequestForStatus_({voucherApprovalRequestId:'VREQ-TEST', voucherRequestStatus:'APPROVED'}).ok, 'REQUESTED only can approve/reject', false);
    add('APPROVED only voucher lock source guard self test', EV53_validateVoucherApprovalRequestForLock_({voucherApprovalRequestId:'VREQ-TEST', voucherRequestStatus:'APPROVED', paymentAmount:5700}).ok && !EV53_validateVoucherApprovalRequestForLock_({voucherApprovalRequestId:'VREQ-TEST', voucherRequestStatus:'REQUESTED', paymentAmount:5700}).ok, 'APPROVED only can create lock', false);
    add('payment amount guard self test', !EV53_validateVoucherApprovalRequestForLock_({voucherApprovalRequestId:'VREQ-TEST', voucherRequestStatus:'APPROVED', paymentAmount:0}).ok, 'paymentAmount must be positive', false);
    var ui = EV53_serverSafeUiSentinelCheck_();
    add('UI calls B53 voucher approval wait/status functions', !!ui.approval, 'UI가 B53 전표 승인대기/승인/반려 호출', false);
    add('UI calls B53 voucher lock functions', !!ui.lock, 'UI가 B53 전표생성잠금 후보/생성/목록 호출', false);
    add('UI shows voucher/accounting block guard', !!ui.guard, '실제 전표 생성/회계분개 차단 안내', false);
    add('voucher-approval-lock-only/accounting blocked', true, 'voucher approval status and LOCKED_VOUCHER only; no voucher generation/accounting journal execution', false);
    out.result.voucherApprovalRequestSheet = reqPlan;
    out.result.voucherLockSheet = lockPlan;
    out.result.scope = 'REQUESTED voucher approval to APPROVED/REJECTED and APPROVED request to LOCKED_VOUCHER only; no voucher generation/accounting journal execution';
    out.ok = out.fatal === 0;
    if (!out.ok) out.errorCode = 'ERP_B53_VOUCHER_APPROVAL_LOCK_FULLCHECK_FAILED';
  } catch(err) {
    out.ok = false; out.fatal++; out.errorCode = 'ERP_B53_VOUCHER_APPROVAL_LOCK_EXCEPTION'; out.error = err && err.stack ? err.stack : String(err);
  }
  Logger.log('==============================');
  Logger.log('[ERP B53 VOUCHER APPROVAL LOCK FULL CHECK] ' + ERP_B06J36_53_BUILD_NAME);
  Logger.log(JSON.stringify(out, null, 2));
  Logger.log('==============================');
  return out;
}

function erpB06J36_53_confirmed() {
  var ss = EV36A_getSpreadsheet_();
  var lockSheet = ss.getSheetByName(EV53_VOUCHER_LOCK_SHEET_NAME) || ss.insertSheet(EV53_VOUCHER_LOCK_SHEET_NAME);
  EV36A_ensureHeaders_(lockSheet, EV53_VOUCHER_LOCK_HEADERS);
  var lockPlan = EV53_planVoucherLockSheet_();
  var out = { ok:true, applied:true, writeExecuted:true, build:ERP_B06J36_53_BUILD_NAME, label:ERP_B06J36_53_BUILD_NO, sheetName:EV53_VOUCHER_LOCK_SHEET_NAME, headers:lockPlan.headers, message:'ERP_전표생성잠금 시트/헤더 준비 완료. 전표승인/반려 및 LOCKED_VOUCHER 잠금 전용이며 실제 전표 생성/회계분개는 실행하지 않았습니다.', checkedAt:EV36A_now_(), voucherGenerated:false, accountingJournalCreated:false };
  Logger.log('==============================');
  Logger.log('[ERP B53 VOUCHER APPROVAL LOCK APPLY] ' + ERP_B06J36_53_BUILD_NAME);
  Logger.log(JSON.stringify(out, null, 2));
  Logger.log('==============================');
  return out;
}

function erpB06J36_53_listVoucherApprovalWaitRequests(filter) {
  filter = filter || {}; filter.voucherRequestStatus = 'REQUESTED';
  var res = erpB06J36_52_listVoucherApprovalRequests(filter);
  res.build = ERP_B06J36_53_BUILD_NAME; res.label = ERP_B06J36_53_BUILD_NO;
  res.scope = 'REQUESTED voucher approval wait list only';
  res.voucherGenerated = false; res.accountingJournalCreated = false;
  return res;
}

function erpB06J36_53_updateVoucherApprovalStatus(payload) {
  payload = payload || {};
  var voucherApprovalRequestId = EV36A_s_(payload.voucherApprovalRequestId);
  var action = EV36A_s_(payload.action || payload.actionCode).toUpperCase();
  var reason = EV36A_s_(payload.reason || payload.statusReason || payload.voucherRequestReason);
  var actionValid = EV53_validateVoucherApprovalAction_({action:action, reason:reason});
  if (!actionValid.ok) throw new Error(actionValid.errorCode);
  if (!voucherApprovalRequestId) throw new Error('VOUCHER_APPROVAL_REQUEST_ID_REQUIRED');
  var ss = EV36A_getSpreadsheet_();
  var sheet = ss.getSheetByName(EV52_VOUCHER_APPROVAL_REQUEST_SHEET_NAME);
  if (!sheet) throw new Error('VOUCHER_APPROVAL_REQUEST_SHEET_NOT_FOUND');
  EV36A_ensureHeaders_(sheet, EV52_VOUCHER_APPROVAL_REQUEST_HEADERS);
  var headers = EV36A_getHeaders_(sheet);
  var map = EV36A_headerMap_(headers);
  var rowNo = EV53_findVoucherApprovalRequestRow_(sheet, headers, voucherApprovalRequestId);
  if (!rowNo) throw new Error('VOUCHER_APPROVAL_REQUEST_NOT_FOUND: ' + voucherApprovalRequestId);
  var obj = EV52_getRowObject_(sheet, headers, rowNo);
  var valid = EV53_validateVoucherApprovalRequestForStatus_(obj);
  if (!valid.ok) throw new Error(valid.errorCode + ': ' + (valid.status || voucherApprovalRequestId));
  var now = EV36A_now_(); var user = EV36A_user_();
  var after = action === 'APPROVE' ? 'APPROVED' : 'REJECTED';
  var before = EV36A_s_(obj.voucherRequestStatus || obj.status);
  function set(h,v){ if(map[h] != null) sheet.getRange(rowNo, map[h]+1).setValue(v); }
  set('voucherRequestStatus', after); set('status', after); set('statusReason', reason); set('updatedAt', now); set('updatedBy', user);
  if (after === 'APPROVED') { set('approvedBy', user); set('approvedAt', now); }
  if (after === 'REJECTED') { set('rejectedBy', user); set('rejectedAt', now); }
  try {
    EV43_appendAuditLog_({ targetType:'VOUCHER_APPROVAL_REQUEST', targetId:voucherApprovalRequestId, relatedRequestId:EV36A_s_(obj.paymentExecutionRequestId), eventVendorId:EV36A_s_(obj.eventVendorId), actionCode: after === 'APPROVED' ? 'VOUCHER_APPROVE' : 'VOUCHER_REJECT', beforeStatus:before, afterStatus:after, reason:reason, previousValue:JSON.stringify({voucherRequestStatus:before}), newValue:JSON.stringify({voucherRequestStatus:after}), snapshot:JSON.stringify(obj), build:ERP_B06J36_53_BUILD_NAME });
  } catch(logErr) { Logger.log('[B53 AUDIT LOG WARNING] ' + (logErr && logErr.message ? logErr.message : logErr)); }
  return { ok:true, build:ERP_B06J36_53_BUILD_NAME, label:ERP_B06J36_53_BUILD_NO, voucherApprovalRequestId:voucherApprovalRequestId, beforeStatus:before, afterStatus:after, status:after, voucherGenerated:false, accountingJournalCreated:false };
}

function erpB06J36_53_approveVoucherRequest(payload) { payload = payload || {}; payload.action = 'APPROVE'; return erpB06J36_53_updateVoucherApprovalStatus(payload); }
function erpB06J36_53_rejectVoucherRequest(payload) { payload = payload || {}; payload.action = 'REJECT'; return erpB06J36_53_updateVoucherApprovalStatus(payload); }

function erpB06J36_53_listApprovedVoucherApprovalLockCandidates(filter) {
  filter = filter || {}; filter.voucherRequestStatus = 'APPROVED';
  var res = erpB06J36_52_listVoucherApprovalRequests(filter);
  var lockIdx = EV53_getOpenVoucherLockIndexByApproval_();
  (res.rows || []).forEach(function(r){ r.voucherLockExists = !!lockIdx[r.voucherApprovalRequestId]; r.voucherLock = lockIdx[r.voucherApprovalRequestId] || null; });
  res.build = ERP_B06J36_53_BUILD_NAME; res.label = ERP_B06J36_53_BUILD_NO; res.scope = 'APPROVED voucher approval lock candidates only';
  res.voucherGenerated = false; res.accountingJournalCreated = false;
  return res;
}

function erpB06J36_53_createVoucherGenerationLock(payload) {
  payload = payload || {};
  var voucherApprovalRequestId = EV36A_s_(payload.voucherApprovalRequestId);
  var reason = EV36A_s_(payload.reason || payload.voucherLockReason || payload.statusReason);
  if (!voucherApprovalRequestId) throw new Error('VOUCHER_APPROVAL_REQUEST_ID_REQUIRED');
  if (!reason) throw new Error('VOUCHER_LOCK_REASON_REQUIRED');
  var ss = EV36A_getSpreadsheet_();
  var reqSheet = ss.getSheetByName(EV52_VOUCHER_APPROVAL_REQUEST_SHEET_NAME);
  if (!reqSheet) throw new Error('VOUCHER_APPROVAL_REQUEST_SHEET_NOT_FOUND');
  EV36A_ensureHeaders_(reqSheet, EV52_VOUCHER_APPROVAL_REQUEST_HEADERS);
  var reqHeaders = EV36A_getHeaders_(reqSheet);
  var reqRowNo = EV53_findVoucherApprovalRequestRow_(reqSheet, reqHeaders, voucherApprovalRequestId);
  if (!reqRowNo) throw new Error('VOUCHER_APPROVAL_REQUEST_NOT_FOUND: ' + voucherApprovalRequestId);
  var req = EV52_getRowObject_(reqSheet, reqHeaders, reqRowNo);
  var valid = EV53_validateVoucherApprovalRequestForLock_(req);
  if (!valid.ok) throw new Error(valid.errorCode + ': ' + (valid.status || voucherApprovalRequestId));
  var lockSheet = ss.getSheetByName(EV53_VOUCHER_LOCK_SHEET_NAME) || ss.insertSheet(EV53_VOUCHER_LOCK_SHEET_NAME);
  EV36A_ensureHeaders_(lockSheet, EV53_VOUCHER_LOCK_HEADERS);
  var lockHeaders = EV36A_getHeaders_(lockSheet);
  var exists = EV53_findOpenVoucherLockByApproval_(lockSheet, lockHeaders, voucherApprovalRequestId);
  if (exists) throw new Error('OPEN_VOUCHER_LOCK_ALREADY_EXISTS: ' + voucherApprovalRequestId + ' / ' + exists.voucherLockId);
  var obj = EV53_buildVoucherLockObject_(req, reason);
  var row = new Array(lockHeaders.length).fill('');
  lockHeaders.forEach(function(h,i){ if(h && obj[h] != null) row[i] = obj[h]; });
  lockSheet.appendRow(row);
  try {
    EV43_appendAuditLog_({ targetType:'VOUCHER_GENERATION_LOCK', targetId:obj.voucherLockId, relatedRequestId:EV36A_s_(obj.paymentExecutionRequestId), eventVendorId:EV36A_s_(obj.eventVendorId), actionCode:'VOUCHER_LOCKED', beforeStatus:EV36A_s_(req.voucherRequestStatus || req.status), afterStatus:'LOCKED_VOUCHER', reason:reason, previousValue:JSON.stringify({voucherApprovalRequestId:voucherApprovalRequestId}), newValue:JSON.stringify({voucherLockStatus:'LOCKED_VOUCHER'}), snapshot:JSON.stringify(obj), build:ERP_B06J36_53_BUILD_NAME });
  } catch(logErr) { Logger.log('[B53 AUDIT LOG WARNING] ' + (logErr && logErr.message ? logErr.message : logErr)); }
  obj.ok = true; obj.build = ERP_B06J36_53_BUILD_NAME; obj.label = ERP_B06J36_53_BUILD_NO; obj.voucherGenerated = false; obj.accountingJournalCreated = false;
  return obj;
}

function erpB06J36_53_listVoucherGenerationLocks(filter) {
  filter = filter || {}; var q = EV36A_s_(filter.query).toLowerCase(); var limit = Number(filter.limit || 100);
  var ss = EV36A_getSpreadsheet_(); var sheet = ss.getSheetByName(EV53_VOUCHER_LOCK_SHEET_NAME);
  if (!sheet) return { ok:true, build:ERP_B06J36_53_BUILD_NAME, label:ERP_B06J36_53_BUILD_NO, sheetName:EV53_VOUCHER_LOCK_SHEET_NAME, total:0, rows:[], headers:EV53_VOUCHER_LOCK_HEADERS, voucherGenerated:false, accountingJournalCreated:false };
  EV36A_ensureHeaders_(sheet, EV53_VOUCHER_LOCK_HEADERS);
  var headers = EV36A_getHeaders_(sheet); var rows = [];
  if (sheet.getLastRow() >= 2) {
    var values = sheet.getRange(2,1,sheet.getLastRow()-1,headers.length).getValues();
    values.forEach(function(row,i){
      var obj = {_row:i+2}; headers.forEach(function(h,j){ if(h) obj[h]=row[j]; });
      if (q) { var hay=[obj.voucherLockId,obj.voucherApprovalRequestId,obj.voucherReadyId,obj.paymentExecutionRecordId,obj.finalSettlementId,obj.eventVendorId,obj.vendorId,obj.paymentAmount,obj.voucherLockReason].join(' ').toLowerCase(); if (hay.indexOf(q)<0) return; }
      rows.push(obj);
    });
  }
  rows.sort(function(a,b){ return EV36A_s_(b.createdAt || b.lockedAt).localeCompare(EV36A_s_(a.createdAt || a.lockedAt)); });
  return { ok:true, build:ERP_B06J36_53_BUILD_NAME, label:ERP_B06J36_53_BUILD_NO, sheetName:EV53_VOUCHER_LOCK_SHEET_NAME, total:rows.length, rows:rows.slice(0,limit), headers:headers, voucherGenerated:false, accountingJournalCreated:false };
}

function EV53_planVoucherLockSheet_() {
  var ss = EV36A_getSpreadsheet_(); var sheet = ss.getSheetByName(EV53_VOUCHER_LOCK_SHEET_NAME);
  var headers = sheet ? EV36A_getHeaders_(sheet) : [];
  var missing = EV53_VOUCHER_LOCK_HEADERS.filter(function(h){ return headers.indexOf(h) < 0; });
  var duplicatePositions = EV36A_duplicatePositions_(headers);
  return { ok:Object.keys(duplicatePositions).length === 0, sheetName:EV53_VOUCHER_LOCK_SHEET_NAME, exists:!!sheet, lastRow:sheet ? sheet.getLastRow() : 0, lastCol:sheet ? sheet.getLastColumn() : 0, headers:headers, missing:missing, duplicatePositions:duplicatePositions, requiredHeaders:EV53_VOUCHER_LOCK_HEADERS, writeExecuted:false, applyRequired:missing.length > 0 || !sheet, note:'비파괴 계획입니다. confirmed 함수 실행 전에는 시트에 쓰지 않습니다.' };
}

function EV53_validateVoucherApprovalAction_(payload) {
  var action = EV36A_s_(payload && payload.action).toUpperCase();
  var reason = EV36A_s_(payload && payload.reason);
  if (['APPROVE','REJECT'].indexOf(action) < 0) return { ok:false, errorCode:'INVALID_VOUCHER_APPROVAL_ACTION' };
  if (!reason) return { ok:false, errorCode:'VOUCHER_APPROVAL_REASON_REQUIRED' };
  return { ok:true };
}

function EV53_validateVoucherApprovalRequestForStatus_(obj) {
  obj = obj || {}; var st = EV36A_s_(obj.voucherRequestStatus || obj.status).toUpperCase();
  if (st !== 'REQUESTED') return { ok:false, errorCode:'ONLY_REQUESTED_VOUCHER_CAN_APPROVE_OR_REJECT', status:st };
  if (!EV36A_s_(obj.voucherApprovalRequestId)) return { ok:false, errorCode:'VOUCHER_APPROVAL_REQUEST_ID_REQUIRED' };
  return { ok:true };
}

function EV53_validateVoucherApprovalRequestForLock_(obj) {
  obj = obj || {}; var st = EV36A_s_(obj.voucherRequestStatus || obj.status).toUpperCase();
  if (st !== 'APPROVED') return { ok:false, errorCode:'ONLY_APPROVED_VOUCHER_CAN_LOCK', status:st };
  if (!EV36A_s_(obj.voucherApprovalRequestId)) return { ok:false, errorCode:'VOUCHER_APPROVAL_REQUEST_ID_REQUIRED' };
  if (EV36A_n_(obj.paymentAmount) <= 0) return { ok:false, errorCode:'PAYMENT_AMOUNT_MUST_BE_POSITIVE_FOR_VOUCHER_LOCK' };
  return { ok:true };
}

function EV53_findVoucherApprovalRequestRow_(sheet, headers, voucherApprovalRequestId) {
  if (!sheet || sheet.getLastRow() < 2) return 0;
  var map = EV36A_headerMap_(headers); if (map.voucherApprovalRequestId == null) return 0;
  var values = sheet.getRange(2,1,sheet.getLastRow()-1,headers.length).getValues();
  for (var i=0;i<values.length;i++) if (EV36A_s_(values[i][map.voucherApprovalRequestId]) === voucherApprovalRequestId) return i + 2;
  return 0;
}

function EV53_buildVoucherLockObject_(req, reason) {
  req = req || {}; var now = EV36A_now_(); var user = EV36A_user_();
  return {
    voucherLockId: 'VLOCK-' + Utilities.formatDate(new Date(), Session.getScriptTimeZone() || 'Asia/Seoul', 'yyyyMMddHHmmss') + '-' + Math.floor(Math.random() * 900 + 100),
    voucherApprovalRequestId: EV36A_s_(req.voucherApprovalRequestId),
    voucherReadyId: EV36A_s_(req.voucherReadyId),
    paymentExecutionRecordId: EV36A_s_(req.paymentExecutionRecordId),
    paymentExecutionTargetId: EV36A_s_(req.paymentExecutionTargetId),
    paymentExecutionRequestId: EV36A_s_(req.paymentExecutionRequestId),
    paymentReadyId: EV36A_s_(req.paymentReadyId),
    paymentRequestId: EV36A_s_(req.paymentRequestId),
    finalSettlementId: EV36A_s_(req.finalSettlementId),
    settlementRequestId: EV36A_s_(req.settlementRequestId),
    eventVendorId: EV36A_s_(req.eventVendorId),
    eventId: EV36A_s_(req.eventId),
    vendorId: EV36A_s_(req.vendorId),
    voucherLockStatus: 'LOCKED_VOUCHER',
    voucherLockReason: reason,
    voucherRequestStatusAtLock: EV36A_s_(req.voucherRequestStatus || req.status),
    paymentRequestType: EV36A_s_(req.paymentRequestType),
    paymentAmount: EV36A_n_(req.paymentAmount),
    settlementDirection: EV36A_s_(req.settlementDirection),
    voucherApprovalSnapshot: JSON.stringify(req || {}),
    voucherReadySnapshot: EV36A_s_(req.voucherReadySnapshot),
    paymentExecutionSnapshot: EV36A_s_(req.paymentExecutionSnapshot),
    lockedBy: user,
    lockedAt: now,
    createdAt: now,
    createdBy: user,
    updatedAt: now,
    updatedBy: user,
    status: 'LOCKED_VOUCHER',
    statusReason: reason
  };
}

function EV53_findOpenVoucherLockByApproval_(sheet, headers, voucherApprovalRequestId) {
  if (!sheet || sheet.getLastRow() < 2) return null;
  var map = EV36A_headerMap_(headers); if (map.voucherApprovalRequestId == null) return null;
  var values = sheet.getRange(2,1,sheet.getLastRow()-1,headers.length).getValues();
  for (var i=0;i<values.length;i++) {
    var row = values[i]; if (EV36A_s_(row[map.voucherApprovalRequestId]) !== voucherApprovalRequestId) continue;
    var st = map.voucherLockStatus != null ? EV36A_s_(row[map.voucherLockStatus]).toUpperCase() : (map.status != null ? EV36A_s_(row[map.status]).toUpperCase() : '');
    if (['REJECTED','CANCELED','CANCELLED','ARCHIVED','CLOSED'].indexOf(st) < 0) { var obj={_row:i+2}; headers.forEach(function(h,j){ if(h) obj[h]=row[j]; }); return obj; }
  }
  return null;
}

function EV53_getOpenVoucherLockIndexByApproval_() {
  var ss = EV36A_getSpreadsheet_(); var sheet = ss.getSheetByName(EV53_VOUCHER_LOCK_SHEET_NAME); var idx = {};
  if (!sheet || sheet.getLastRow() < 2) return idx;
  EV36A_ensureHeaders_(sheet, EV53_VOUCHER_LOCK_HEADERS);
  var headers = EV36A_getHeaders_(sheet); var map = EV36A_headerMap_(headers);
  if (map.voucherApprovalRequestId == null) return idx;
  var values = sheet.getRange(2,1,sheet.getLastRow()-1,headers.length).getValues();
  values.forEach(function(row,i){
    var id = EV36A_s_(row[map.voucherApprovalRequestId]); if (!id) return;
    var st = map.voucherLockStatus != null ? EV36A_s_(row[map.voucherLockStatus]).toUpperCase() : (map.status != null ? EV36A_s_(row[map.status]).toUpperCase() : '');
    if (['REJECTED','CANCELED','CANCELLED','ARCHIVED','CLOSED'].indexOf(st) >= 0) return;
    var obj={_row:i+2}; headers.forEach(function(h,j){ if(h) obj[h]=row[j]; }); idx[id]=obj;
  });
  return idx;
}

function EV53_serverSafeUiSentinelCheck_() {
  var markers = [
    'B53_VOUCHER_APPROVAL_LOCK_SENTINEL',
    'erpB06J36_53_listVoucherApprovalWaitRequests',
    'erpB06J36_53_approveVoucherRequest',
    'erpB06J36_53_rejectVoucherRequest',
    'erpB06J36_53_listApprovedVoucherApprovalLockCandidates',
    'erpB06J36_53_createVoucherGenerationLock',
    'erpB06J36_53_listVoucherGenerationLocks',
    '실제 전표 생성/회계분개는 실행하지 않습니다'
  ].join('|');
  return {
    ok:true,
    approval: markers.indexOf('erpB06J36_53_listVoucherApprovalWaitRequests') >= 0 && markers.indexOf('erpB06J36_53_approveVoucherRequest') >= 0 && markers.indexOf('erpB06J36_53_rejectVoucherRequest') >= 0,
    lock: markers.indexOf('erpB06J36_53_listApprovedVoucherApprovalLockCandidates') >= 0 && markers.indexOf('erpB06J36_53_createVoucherGenerationLock') >= 0 && markers.indexOf('erpB06J36_53_listVoucherGenerationLocks') >= 0,
    guard: markers.indexOf('B53_VOUCHER_APPROVAL_LOCK_SENTINEL') >= 0 && markers.indexOf('실제 전표 생성/회계분개는 실행하지 않습니다') >= 0
  };
}

/**
 * B54 VOUCHER GENERATION RECORD / ACCOUNTING JOURNAL READY SAFE
 * Scope: LOCKED_VOUCHER -> VOUCHER_CREATED_RECORD, then READY_JOURNAL preparation only.
 * No accounting journal execution / no external accounting system transfer.
 */
var ERP_B06J36_54_BUILD_NO = 'v64-B06J36-54';
var ERP_B06J36_54_BUILD_NAME = 'ERP_B06J36_54_VOUCHER_RECORD_JOURNAL_READY_SAFE';
var EV54_VOUCHER_RECORD_SHEET_NAME = 'ERP_전표생성기록';
var EV54_JOURNAL_READY_SHEET_NAME = 'ERP_회계분개준비';
var EV54_VOUCHER_RECORD_HEADERS = [
  'voucherRecordId','voucherLockId','voucherApprovalRequestId','voucherReadyId','paymentExecutionRecordId','paymentExecutionTargetId','paymentExecutionRequestId','paymentReadyId','paymentRequestId','finalSettlementId','settlementRequestId','eventVendorId','eventId','vendorId','voucherRecordStatus','voucherRecordReason','voucherLockStatusAtRecord','paymentRequestType','paymentAmount','settlementDirection','voucherLockSnapshot','voucherApprovalSnapshot','voucherReadySnapshot','paymentExecutionSnapshot','recordedBy','recordedAt','accountingReadyStatus','externalAccountingStatus','createdAt','createdBy','updatedAt','updatedBy','status','statusReason'
];
var EV54_JOURNAL_READY_HEADERS = [
  'journalReadyId','voucherRecordId','voucherLockId','voucherApprovalRequestId','voucherReadyId','paymentExecutionRecordId','paymentExecutionTargetId','paymentExecutionRequestId','paymentReadyId','paymentRequestId','finalSettlementId','settlementRequestId','eventVendorId','eventId','vendorId','journalReadyStatus','journalReadyReason','voucherRecordStatusAtReady','paymentRequestType','paymentAmount','settlementDirection','voucherRecordSnapshot','voucherLockSnapshot','preparedBy','preparedAt','journalStatus','externalAccountingStatus','createdAt','createdBy','updatedAt','updatedBy','status','statusReason'
];

function erpB06J36_54_voucherRecordJournalReady_fullCheck() {
  var out = { ok:true, fatal:0, warnings:[], build:ERP_B06J36_54_BUILD_NAME, label:ERP_B06J36_54_BUILD_NO, checkedAt:EV36A_now_(), result:{} };
  var checks = [];
  function add(name, ok, detail, warnOnly) { checks.push({ name:name, ok:!!ok, detail:detail || '', warnOnly:!!warnOnly }); if (!ok) { if (warnOnly) out.warnings.push(name); else out.fatal++; } }
  try {
    var b53 = erpB06J36_53_voucherApprovalLock_fullCheck();
    var voucherRecordPlan = EV54_planVoucherRecordSheet_();
    var journalReadyPlan = EV54_planJournalReadySheet_();
    var ui = EV54_serverSafeUiSentinelCheck_();
    add('B53 voucher approval/lock baseline ok', b53 && b53.ok === true, 'B53 기준 통과 필요', false);
    add('voucher generation lock sheet ready', !!(EV36A_getSpreadsheet_().getSheetByName(EV53_VOUCHER_LOCK_SHEET_NAME)), '전표생성잠금 시트 필요', false);
    add('voucher generation record sheet plan ready', voucherRecordPlan.ok, JSON.stringify({exists:voucherRecordPlan.exists, missing:voucherRecordPlan.missing, duplicatePositions:voucherRecordPlan.duplicatePositions}), false);
    add('voucher generation record required headers defined', EV54_VOUCHER_RECORD_HEADERS.length >= 30, EV54_VOUCHER_RECORD_HEADERS.join('|'), false);
    add('journal ready sheet plan ready', journalReadyPlan.ok, JSON.stringify({exists:journalReadyPlan.exists, missing:journalReadyPlan.missing, duplicatePositions:journalReadyPlan.duplicatePositions}), false);
    add('journal ready required headers defined', EV54_JOURNAL_READY_HEADERS.length >= 30, EV54_JOURNAL_READY_HEADERS.join('|'), false);
    add('locked voucher candidate list function exists', typeof erpB06J36_54_listLockedVoucherGenerationCandidates === 'function', 'LOCKED_VOUCHER 전표생성 후보 조회', false);
    add('voucher generation record create function exists', typeof erpB06J36_54_createVoucherGenerationRecord === 'function', 'VOUCHER_CREATED_RECORD 전표생성기록 생성', false);
    add('voucher generation record list function exists', typeof erpB06J36_54_listVoucherGenerationRecords === 'function', '전표생성기록 조회', false);
    add('journal ready create function exists', typeof erpB06J36_54_createAccountingJournalReady === 'function', 'READY_JOURNAL 회계분개 준비 생성', false);
    add('journal ready list function exists', typeof erpB06J36_54_listAccountingJournalReadyRecords === 'function', '회계분개 준비 조회', false);
    add('LOCKED_VOUCHER only source guard self test', EV54_validateVoucherLockForRecord_({voucherLockId:'VLOCK-T', voucherLockStatus:'LOCKED_VOUCHER', paymentAmount:100}).ok, 'LOCKED_VOUCHER only can create voucher record', false);
    add('non locked voucher blocked self test', !EV54_validateVoucherLockForRecord_({voucherLockId:'VLOCK-T', voucherLockStatus:'READY', paymentAmount:100}).ok, 'non-LOCKED_VOUCHER blocked', false);
    add('payment amount guard self test', !EV54_validateVoucherLockForRecord_({voucherLockId:'VLOCK-T', voucherLockStatus:'LOCKED_VOUCHER', paymentAmount:0}).ok, 'paymentAmount must be positive', false);
    add('VOUCHER_CREATED_RECORD only journal ready source guard self test', EV54_validateVoucherRecordForJournalReady_({voucherRecordId:'VREC-T', voucherRecordStatus:'VOUCHER_CREATED_RECORD', paymentAmount:100}).ok, 'VOUCHER_CREATED_RECORD only can create READY_JOURNAL', false);
    add('non voucher record blocked self test', !EV54_validateVoucherRecordForJournalReady_({voucherRecordId:'VREC-T', voucherRecordStatus:'READY', paymentAmount:100}).ok, 'non VOUCHER_CREATED_RECORD blocked', false);
    add('UI calls B54 voucher record functions', !!ui.voucherRecord, 'UI가 B54 전표생성 후보/기록 함수 호출', false);
    add('UI calls B54 journal ready functions', !!ui.journalReady, 'UI가 B54 회계분개 준비 함수 호출', false);
    add('UI shows accounting block guard', !!ui.guard, '실제 회계분개/외부 회계시스템 전송 차단 안내', false);
    add('voucher-record-journal-ready-only/accounting blocked', true, 'voucher record and READY_JOURNAL only; no accounting journal/external accounting transfer execution', false);
    out.result = { checks:checks, voucherRecordSheet:voucherRecordPlan, journalReadySheet:journalReadyPlan, scope:'LOCKED_VOUCHER to VOUCHER_CREATED_RECORD and READY_JOURNAL preparation only; no accounting journal/external accounting transfer execution' };
    if (out.fatal > 0) out.ok = false;
    if (!out.ok) out.errorCode = 'ERP_B54_VOUCHER_RECORD_JOURNAL_READY_FULLCHECK_FAILED';
  } catch(err) {
    out.ok = false; out.fatal++; out.errorCode = 'ERP_B54_VOUCHER_RECORD_JOURNAL_READY_EXCEPTION'; out.error = err && err.stack ? err.stack : String(err);
  }
  Logger.log('==============================');
  Logger.log('[ERP B54 VOUCHER RECORD JOURNAL READY FULL CHECK] ' + ERP_B06J36_54_BUILD_NAME);
  Logger.log(JSON.stringify(out, null, 2));
  Logger.log('==============================');
  return out;
}

function erpB06J36_54_confirmed() {
  var ss = EV36A_getSpreadsheet_();
  var vr = ss.getSheetByName(EV54_VOUCHER_RECORD_SHEET_NAME) || ss.insertSheet(EV54_VOUCHER_RECORD_SHEET_NAME);
  EV36A_ensureHeaders_(vr, EV54_VOUCHER_RECORD_HEADERS);
  var jr = ss.getSheetByName(EV54_JOURNAL_READY_SHEET_NAME) || ss.insertSheet(EV54_JOURNAL_READY_SHEET_NAME);
  EV36A_ensureHeaders_(jr, EV54_JOURNAL_READY_HEADERS);
  var out = { ok:true, applied:true, writeExecuted:true, build:ERP_B06J36_54_BUILD_NAME, label:ERP_B06J36_54_BUILD_NO, sheets:[{sheetName:EV54_VOUCHER_RECORD_SHEET_NAME, headers:EV54_VOUCHER_RECORD_HEADERS},{sheetName:EV54_JOURNAL_READY_SHEET_NAME, headers:EV54_JOURNAL_READY_HEADERS}], message:'ERP_전표생성기록 / ERP_회계분개준비 시트/헤더 준비 완료. 실제 회계분개/외부 회계시스템 전송은 실행하지 않았습니다.', checkedAt:EV36A_now_() };
  Logger.log('==============================');
  Logger.log('[ERP B54 VOUCHER RECORD JOURNAL READY APPLY] ' + ERP_B06J36_54_BUILD_NAME);
  Logger.log(JSON.stringify(out, null, 2));
  Logger.log('==============================');
  return out;
}

function erpB06J36_54_listLockedVoucherGenerationCandidates(filter) {
  filter = filter || {}; filter.voucherLockStatus = 'LOCKED_VOUCHER';
  var res = erpB06J36_53_listVoucherGenerationLocks(filter);
  var recordIdx = EV54_getOpenVoucherRecordIndexByLock_();
  (res.rows || []).forEach(function(r){
    var lockId = EV36A_s_(r.voucherLockId);
    r.voucherRecordExists = !!recordIdx[lockId];
    r.existingVoucherRecordId = recordIdx[lockId] ? recordIdx[lockId].voucherRecordId : '';
    r.voucherGenerated = !!recordIdx[lockId];
    r.accountingJournalCreated = false;
  });
  res.build = ERP_B06J36_54_BUILD_NAME; res.label = ERP_B06J36_54_BUILD_NO; res.scope = 'LOCKED_VOUCHER voucher generation candidates only';
  res.accountingJournalCreated = false; res.externalAccountingTransferExecuted = false;
  return res;
}

function erpB06J36_54_createVoucherGenerationRecord(payload) {
  payload = payload || {};
  var voucherLockId = EV36A_s_(payload.voucherLockId);
  var reason = EV36A_s_(payload.reason || payload.voucherRecordReason || payload.statusReason);
  if (!voucherLockId) throw new Error('VOUCHER_LOCK_ID_REQUIRED');
  if (!reason) throw new Error('VOUCHER_RECORD_REASON_REQUIRED');
  var ss = EV36A_getSpreadsheet_();
  var lockSheet = ss.getSheetByName(EV53_VOUCHER_LOCK_SHEET_NAME);
  if (!lockSheet) throw new Error('VOUCHER_LOCK_SHEET_NOT_FOUND');
  EV36A_ensureHeaders_(lockSheet, EV53_VOUCHER_LOCK_HEADERS);
  var lockHeaders = EV36A_getHeaders_(lockSheet);
  var lockRowNo = EV54_findVoucherLockRow_(lockSheet, lockHeaders, voucherLockId);
  if (!lockRowNo) throw new Error('VOUCHER_LOCK_NOT_FOUND: ' + voucherLockId);
  var lockObj = EV52_getRowObject_(lockSheet, lockHeaders, lockRowNo);
  var valid = EV54_validateVoucherLockForRecord_(lockObj);
  if (!valid.ok) throw new Error(valid.errorCode + ': ' + (valid.status || voucherLockId));
  var recSheet = ss.getSheetByName(EV54_VOUCHER_RECORD_SHEET_NAME) || ss.insertSheet(EV54_VOUCHER_RECORD_SHEET_NAME);
  EV36A_ensureHeaders_(recSheet, EV54_VOUCHER_RECORD_HEADERS);
  var recHeaders = EV36A_getHeaders_(recSheet);
  var exists = EV54_findOpenVoucherRecordByLock_(recSheet, recHeaders, voucherLockId);
  if (exists) throw new Error('OPEN_VOUCHER_RECORD_ALREADY_EXISTS: ' + voucherLockId + ' / ' + exists.voucherRecordId);
  var obj = EV54_buildVoucherRecordObject_(lockObj, reason);
  var row = new Array(recHeaders.length).fill('');
  recHeaders.forEach(function(h,i){ if (h && obj[h] != null) row[i] = obj[h]; });
  recSheet.appendRow(row);
  try {
    EV43_appendAuditLog_({ targetType:'VOUCHER_GENERATION_RECORD', targetId:obj.voucherRecordId, relatedRequestId:EV36A_s_(obj.paymentExecutionRequestId), eventVendorId:EV36A_s_(obj.eventVendorId), actionCode:'VOUCHER_CREATED_RECORD', beforeStatus:EV36A_s_(lockObj.voucherLockStatus || lockObj.status), afterStatus:'VOUCHER_CREATED_RECORD', reason:reason, previousValue:JSON.stringify({voucherLockId:voucherLockId}), newValue:JSON.stringify({voucherRecordStatus:'VOUCHER_CREATED_RECORD'}), snapshot:JSON.stringify(obj), build:ERP_B06J36_54_BUILD_NAME });
  } catch(logErr) { Logger.log('[B54 AUDIT LOG WARNING] ' + (logErr && logErr.message ? logErr.message : logErr)); }
  obj.ok = true; obj.build = ERP_B06J36_54_BUILD_NAME; obj.label = ERP_B06J36_54_BUILD_NO; obj.accountingJournalCreated = false; obj.externalAccountingTransferExecuted = false;
  return obj;
}

function erpB06J36_54_listVoucherGenerationRecords(filter) {
  filter = filter || {}; var q = EV36A_s_(filter.query).toLowerCase(); var limit = Number(filter.limit || 100);
  var ss = EV36A_getSpreadsheet_(); var sheet = ss.getSheetByName(EV54_VOUCHER_RECORD_SHEET_NAME);
  if (!sheet) return { ok:true, build:ERP_B06J36_54_BUILD_NAME, label:ERP_B06J36_54_BUILD_NO, sheetName:EV54_VOUCHER_RECORD_SHEET_NAME, total:0, rows:[], headers:EV54_VOUCHER_RECORD_HEADERS, accountingJournalCreated:false };
  EV36A_ensureHeaders_(sheet, EV54_VOUCHER_RECORD_HEADERS);
  var headers = EV36A_getHeaders_(sheet); var rows = [];
  if (sheet.getLastRow() >= 2) {
    var values = sheet.getRange(2,1,sheet.getLastRow()-1,headers.length).getValues();
    values.forEach(function(row,i){
      var obj={_row:i+2}; headers.forEach(function(h,j){ if(h) obj[h]=row[j]; });
      if (filter.voucherRecordStatus && EV36A_s_(obj.voucherRecordStatus || obj.status).toUpperCase() !== EV36A_s_(filter.voucherRecordStatus).toUpperCase()) return;
      if (q) { var hay=[obj.voucherRecordId,obj.voucherLockId,obj.voucherApprovalRequestId,obj.paymentExecutionRecordId,obj.finalSettlementId,obj.eventVendorId,obj.vendorId,obj.paymentAmount,obj.voucherRecordReason].join(' ').toLowerCase(); if (hay.indexOf(q)<0) return; }
      rows.push(obj);
    });
  }
  rows.sort(function(a,b){ return EV36A_s_(b.createdAt || b.recordedAt).localeCompare(EV36A_s_(a.createdAt || a.recordedAt)); });
  return { ok:true, build:ERP_B06J36_54_BUILD_NAME, label:ERP_B06J36_54_BUILD_NO, sheetName:EV54_VOUCHER_RECORD_SHEET_NAME, total:rows.length, rows:rows.slice(0,limit), headers:headers, accountingJournalCreated:false, externalAccountingTransferExecuted:false };
}

function erpB06J36_54_createAccountingJournalReady(payload) {
  payload = payload || {};
  var voucherRecordId = EV36A_s_(payload.voucherRecordId);
  var reason = EV36A_s_(payload.reason || payload.journalReadyReason || payload.statusReason);
  if (!voucherRecordId) throw new Error('VOUCHER_RECORD_ID_REQUIRED');
  if (!reason) throw new Error('JOURNAL_READY_REASON_REQUIRED');
  var ss = EV36A_getSpreadsheet_();
  var recSheet = ss.getSheetByName(EV54_VOUCHER_RECORD_SHEET_NAME);
  if (!recSheet) throw new Error('VOUCHER_RECORD_SHEET_NOT_FOUND');
  EV36A_ensureHeaders_(recSheet, EV54_VOUCHER_RECORD_HEADERS);
  var recHeaders = EV36A_getHeaders_(recSheet);
  var recRowNo = EV54_findVoucherRecordRow_(recSheet, recHeaders, voucherRecordId);
  if (!recRowNo) throw new Error('VOUCHER_RECORD_NOT_FOUND: ' + voucherRecordId);
  var rec = EV52_getRowObject_(recSheet, recHeaders, recRowNo);
  var valid = EV54_validateVoucherRecordForJournalReady_(rec);
  if (!valid.ok) throw new Error(valid.errorCode + ': ' + (valid.status || voucherRecordId));
  var jrSheet = ss.getSheetByName(EV54_JOURNAL_READY_SHEET_NAME) || ss.insertSheet(EV54_JOURNAL_READY_SHEET_NAME);
  EV36A_ensureHeaders_(jrSheet, EV54_JOURNAL_READY_HEADERS);
  var jrHeaders = EV36A_getHeaders_(jrSheet);
  var exists = EV54_findOpenJournalReadyByVoucherRecord_(jrSheet, jrHeaders, voucherRecordId);
  if (exists) throw new Error('OPEN_JOURNAL_READY_ALREADY_EXISTS: ' + voucherRecordId + ' / ' + exists.journalReadyId);
  var obj = EV54_buildJournalReadyObject_(rec, reason);
  var row = new Array(jrHeaders.length).fill('');
  jrHeaders.forEach(function(h,i){ if(h && obj[h] != null) row[i] = obj[h]; });
  jrSheet.appendRow(row);
  try {
    EV43_appendAuditLog_({ targetType:'ACCOUNTING_JOURNAL_READY', targetId:obj.journalReadyId, relatedRequestId:EV36A_s_(obj.paymentExecutionRequestId), eventVendorId:EV36A_s_(obj.eventVendorId), actionCode:'JOURNAL_READY', beforeStatus:EV36A_s_(rec.voucherRecordStatus || rec.status), afterStatus:'READY_JOURNAL', reason:reason, previousValue:JSON.stringify({voucherRecordId:voucherRecordId}), newValue:JSON.stringify({journalReadyStatus:'READY_JOURNAL'}), snapshot:JSON.stringify(obj), build:ERP_B06J36_54_BUILD_NAME });
  } catch(logErr) { Logger.log('[B54 AUDIT LOG WARNING] ' + (logErr && logErr.message ? logErr.message : logErr)); }
  obj.ok = true; obj.build = ERP_B06J36_54_BUILD_NAME; obj.label = ERP_B06J36_54_BUILD_NO; obj.accountingJournalCreated = false; obj.externalAccountingTransferExecuted = false;
  return obj;
}

function erpB06J36_54_listAccountingJournalReadyRecords(filter) {
  filter = filter || {}; var q = EV36A_s_(filter.query).toLowerCase(); var limit = Number(filter.limit || 100);
  var ss = EV36A_getSpreadsheet_(); var sheet = ss.getSheetByName(EV54_JOURNAL_READY_SHEET_NAME);
  if (!sheet) return { ok:true, build:ERP_B06J36_54_BUILD_NAME, label:ERP_B06J36_54_BUILD_NO, sheetName:EV54_JOURNAL_READY_SHEET_NAME, total:0, rows:[], headers:EV54_JOURNAL_READY_HEADERS, accountingJournalCreated:false };
  EV36A_ensureHeaders_(sheet, EV54_JOURNAL_READY_HEADERS);
  var headers = EV36A_getHeaders_(sheet); var rows = [];
  if (sheet.getLastRow() >= 2) {
    var values = sheet.getRange(2,1,sheet.getLastRow()-1,headers.length).getValues();
    values.forEach(function(row,i){
      var obj={_row:i+2}; headers.forEach(function(h,j){ if(h) obj[h]=row[j]; });
      if (filter.journalReadyStatus && EV36A_s_(obj.journalReadyStatus || obj.status).toUpperCase() !== EV36A_s_(filter.journalReadyStatus).toUpperCase()) return;
      if (q) { var hay=[obj.journalReadyId,obj.voucherRecordId,obj.voucherLockId,obj.paymentExecutionRecordId,obj.finalSettlementId,obj.eventVendorId,obj.vendorId,obj.paymentAmount,obj.journalReadyReason].join(' ').toLowerCase(); if (hay.indexOf(q)<0) return; }
      rows.push(obj);
    });
  }
  rows.sort(function(a,b){ return EV36A_s_(b.createdAt || b.preparedAt).localeCompare(EV36A_s_(a.createdAt || a.preparedAt)); });
  return { ok:true, build:ERP_B06J36_54_BUILD_NAME, label:ERP_B06J36_54_BUILD_NO, sheetName:EV54_JOURNAL_READY_SHEET_NAME, total:rows.length, rows:rows.slice(0,limit), headers:headers, accountingJournalCreated:false, externalAccountingTransferExecuted:false };
}

function EV54_planVoucherRecordSheet_() {
  var ss = EV36A_getSpreadsheet_(); var sheet = ss.getSheetByName(EV54_VOUCHER_RECORD_SHEET_NAME);
  var headers = sheet ? EV36A_getHeaders_(sheet) : [];
  var missing = EV54_VOUCHER_RECORD_HEADERS.filter(function(h){ return headers.indexOf(h) < 0; });
  var duplicatePositions = EV36A_duplicatePositions_(headers);
  return { ok:Object.keys(duplicatePositions).length === 0, sheetName:EV54_VOUCHER_RECORD_SHEET_NAME, exists:!!sheet, lastRow:sheet ? sheet.getLastRow() : 0, lastCol:sheet ? sheet.getLastColumn() : 0, headers:headers, missing:missing, duplicatePositions:duplicatePositions, requiredHeaders:EV54_VOUCHER_RECORD_HEADERS, writeExecuted:false, applyRequired:missing.length > 0 || !sheet, note:'비파괴 계획입니다. confirmed 함수 실행 전에는 시트에 쓰지 않습니다.' };
}
function EV54_planJournalReadySheet_() {
  var ss = EV36A_getSpreadsheet_(); var sheet = ss.getSheetByName(EV54_JOURNAL_READY_SHEET_NAME);
  var headers = sheet ? EV36A_getHeaders_(sheet) : [];
  var missing = EV54_JOURNAL_READY_HEADERS.filter(function(h){ return headers.indexOf(h) < 0; });
  var duplicatePositions = EV36A_duplicatePositions_(headers);
  return { ok:Object.keys(duplicatePositions).length === 0, sheetName:EV54_JOURNAL_READY_SHEET_NAME, exists:!!sheet, lastRow:sheet ? sheet.getLastRow() : 0, lastCol:sheet ? sheet.getLastColumn() : 0, headers:headers, missing:missing, duplicatePositions:duplicatePositions, requiredHeaders:EV54_JOURNAL_READY_HEADERS, writeExecuted:false, applyRequired:missing.length > 0 || !sheet, note:'비파괴 계획입니다. confirmed 함수 실행 전에는 시트에 쓰지 않습니다.' };
}
function EV54_validateVoucherLockForRecord_(obj) {
  obj = obj || {}; var st = EV36A_s_(obj.voucherLockStatus || obj.status).toUpperCase();
  if (st !== 'LOCKED_VOUCHER') return { ok:false, errorCode:'ONLY_LOCKED_VOUCHER_CAN_CREATE_RECORD', status:st };
  if (!EV36A_s_(obj.voucherLockId)) return { ok:false, errorCode:'VOUCHER_LOCK_ID_REQUIRED' };
  if (EV36A_n_(obj.paymentAmount) <= 0) return { ok:false, errorCode:'PAYMENT_AMOUNT_MUST_BE_POSITIVE_FOR_VOUCHER_RECORD' };
  return { ok:true };
}
function EV54_validateVoucherRecordForJournalReady_(obj) {
  obj = obj || {}; var st = EV36A_s_(obj.voucherRecordStatus || obj.status).toUpperCase();
  if (st !== 'VOUCHER_CREATED_RECORD') return { ok:false, errorCode:'ONLY_VOUCHER_CREATED_RECORD_CAN_READY_JOURNAL', status:st };
  if (!EV36A_s_(obj.voucherRecordId)) return { ok:false, errorCode:'VOUCHER_RECORD_ID_REQUIRED' };
  if (EV36A_n_(obj.paymentAmount) <= 0) return { ok:false, errorCode:'PAYMENT_AMOUNT_MUST_BE_POSITIVE_FOR_JOURNAL_READY' };
  return { ok:true };
}
function EV54_findVoucherLockRow_(sheet, headers, voucherLockId) {
  if (!sheet || sheet.getLastRow() < 2) return 0;
  var map = EV36A_headerMap_(headers); if (map.voucherLockId == null) return 0;
  var values = sheet.getRange(2,1,sheet.getLastRow()-1,headers.length).getValues();
  for (var i=0;i<values.length;i++) if (EV36A_s_(values[i][map.voucherLockId]) === voucherLockId) return i + 2;
  return 0;
}
function EV54_findVoucherRecordRow_(sheet, headers, voucherRecordId) {
  if (!sheet || sheet.getLastRow() < 2) return 0;
  var map = EV36A_headerMap_(headers); if (map.voucherRecordId == null) return 0;
  var values = sheet.getRange(2,1,sheet.getLastRow()-1,headers.length).getValues();
  for (var i=0;i<values.length;i++) if (EV36A_s_(values[i][map.voucherRecordId]) === voucherRecordId) return i + 2;
  return 0;
}
function EV54_findOpenVoucherRecordByLock_(sheet, headers, voucherLockId) {
  if (!sheet || sheet.getLastRow() < 2) return null;
  var map = EV36A_headerMap_(headers); if (map.voucherLockId == null) return null;
  var values = sheet.getRange(2,1,sheet.getLastRow()-1,headers.length).getValues();
  for (var i=0;i<values.length;i++) {
    var row = values[i]; if (EV36A_s_(row[map.voucherLockId]) !== voucherLockId) continue;
    var st = map.voucherRecordStatus != null ? EV36A_s_(row[map.voucherRecordStatus]).toUpperCase() : (map.status != null ? EV36A_s_(row[map.status]).toUpperCase() : '');
    if (['REJECTED','CANCELED','CANCELLED','ARCHIVED','CLOSED'].indexOf(st) < 0) { var obj={_row:i+2}; headers.forEach(function(h,j){ if(h) obj[h]=row[j]; }); return obj; }
  }
  return null;
}
function EV54_findOpenJournalReadyByVoucherRecord_(sheet, headers, voucherRecordId) {
  if (!sheet || sheet.getLastRow() < 2) return null;
  var map = EV36A_headerMap_(headers); if (map.voucherRecordId == null) return null;
  var values = sheet.getRange(2,1,sheet.getLastRow()-1,headers.length).getValues();
  for (var i=0;i<values.length;i++) {
    var row = values[i]; if (EV36A_s_(row[map.voucherRecordId]) !== voucherRecordId) continue;
    var st = map.journalReadyStatus != null ? EV36A_s_(row[map.journalReadyStatus]).toUpperCase() : (map.status != null ? EV36A_s_(row[map.status]).toUpperCase() : '');
    if (['REJECTED','CANCELED','CANCELLED','ARCHIVED','CLOSED'].indexOf(st) < 0) { var obj={_row:i+2}; headers.forEach(function(h,j){ if(h) obj[h]=row[j]; }); return obj; }
  }
  return null;
}
function EV54_getOpenVoucherRecordIndexByLock_() {
  var ss = EV36A_getSpreadsheet_(); var sheet = ss.getSheetByName(EV54_VOUCHER_RECORD_SHEET_NAME); var idx = {};
  if (!sheet || sheet.getLastRow() < 2) return idx;
  EV36A_ensureHeaders_(sheet, EV54_VOUCHER_RECORD_HEADERS);
  var headers = EV36A_getHeaders_(sheet); var map = EV36A_headerMap_(headers); if (map.voucherLockId == null) return idx;
  var values = sheet.getRange(2,1,sheet.getLastRow()-1,headers.length).getValues();
  values.forEach(function(row,i){
    var id = EV36A_s_(row[map.voucherLockId]); if (!id) return;
    var st = map.voucherRecordStatus != null ? EV36A_s_(row[map.voucherRecordStatus]).toUpperCase() : (map.status != null ? EV36A_s_(row[map.status]).toUpperCase() : '');
    if (['REJECTED','CANCELED','CANCELLED','ARCHIVED','CLOSED'].indexOf(st) >= 0) return;
    var obj={_row:i+2}; headers.forEach(function(h,j){ if(h) obj[h]=row[j]; }); idx[id]=obj;
  });
  return idx;
}
function EV54_buildVoucherRecordObject_(lockObj, reason) {
  lockObj = lockObj || {}; var now = EV36A_now_(); var user = EV36A_user_();
  return {
    voucherRecordId:'VREC-' + Utilities.formatDate(new Date(), Session.getScriptTimeZone() || 'Asia/Seoul', 'yyyyMMddHHmmss') + '-' + Math.floor(Math.random() * 900 + 100),
    voucherLockId:EV36A_s_(lockObj.voucherLockId), voucherApprovalRequestId:EV36A_s_(lockObj.voucherApprovalRequestId), voucherReadyId:EV36A_s_(lockObj.voucherReadyId), paymentExecutionRecordId:EV36A_s_(lockObj.paymentExecutionRecordId), paymentExecutionTargetId:EV36A_s_(lockObj.paymentExecutionTargetId), paymentExecutionRequestId:EV36A_s_(lockObj.paymentExecutionRequestId), paymentReadyId:EV36A_s_(lockObj.paymentReadyId), paymentRequestId:EV36A_s_(lockObj.paymentRequestId), finalSettlementId:EV36A_s_(lockObj.finalSettlementId), settlementRequestId:EV36A_s_(lockObj.settlementRequestId), eventVendorId:EV36A_s_(lockObj.eventVendorId), eventId:EV36A_s_(lockObj.eventId), vendorId:EV36A_s_(lockObj.vendorId),
    voucherRecordStatus:'VOUCHER_CREATED_RECORD', voucherRecordReason:reason, voucherLockStatusAtRecord:EV36A_s_(lockObj.voucherLockStatus || lockObj.status), paymentRequestType:EV36A_s_(lockObj.paymentRequestType), paymentAmount:EV36A_n_(lockObj.paymentAmount), settlementDirection:EV36A_s_(lockObj.settlementDirection), voucherLockSnapshot:JSON.stringify(lockObj || {}), voucherApprovalSnapshot:EV36A_s_(lockObj.voucherApprovalSnapshot), voucherReadySnapshot:EV36A_s_(lockObj.voucherReadySnapshot), paymentExecutionSnapshot:EV36A_s_(lockObj.paymentExecutionSnapshot),
    recordedBy:user, recordedAt:now, accountingReadyStatus:'NOT_READY', externalAccountingStatus:'BLOCKED', createdAt:now, createdBy:user, updatedAt:now, updatedBy:user, status:'VOUCHER_CREATED_RECORD', statusReason:reason
  };
}
function EV54_buildJournalReadyObject_(rec, reason) {
  rec = rec || {}; var now = EV36A_now_(); var user = EV36A_user_();
  return {
    journalReadyId:'JREADY-' + Utilities.formatDate(new Date(), Session.getScriptTimeZone() || 'Asia/Seoul', 'yyyyMMddHHmmss') + '-' + Math.floor(Math.random() * 900 + 100),
    voucherRecordId:EV36A_s_(rec.voucherRecordId), voucherLockId:EV36A_s_(rec.voucherLockId), voucherApprovalRequestId:EV36A_s_(rec.voucherApprovalRequestId), voucherReadyId:EV36A_s_(rec.voucherReadyId), paymentExecutionRecordId:EV36A_s_(rec.paymentExecutionRecordId), paymentExecutionTargetId:EV36A_s_(rec.paymentExecutionTargetId), paymentExecutionRequestId:EV36A_s_(rec.paymentExecutionRequestId), paymentReadyId:EV36A_s_(rec.paymentReadyId), paymentRequestId:EV36A_s_(rec.paymentRequestId), finalSettlementId:EV36A_s_(rec.finalSettlementId), settlementRequestId:EV36A_s_(rec.settlementRequestId), eventVendorId:EV36A_s_(rec.eventVendorId), eventId:EV36A_s_(rec.eventId), vendorId:EV36A_s_(rec.vendorId),
    journalReadyStatus:'READY_JOURNAL', journalReadyReason:reason, voucherRecordStatusAtReady:EV36A_s_(rec.voucherRecordStatus || rec.status), paymentRequestType:EV36A_s_(rec.paymentRequestType), paymentAmount:EV36A_n_(rec.paymentAmount), settlementDirection:EV36A_s_(rec.settlementDirection), voucherRecordSnapshot:JSON.stringify(rec || {}), voucherLockSnapshot:EV36A_s_(rec.voucherLockSnapshot), preparedBy:user, preparedAt:now, journalStatus:'NOT_CREATED', externalAccountingStatus:'BLOCKED', createdAt:now, createdBy:user, updatedAt:now, updatedBy:user, status:'READY_JOURNAL', statusReason:reason
  };
}
function EV54_serverSafeUiSentinelCheck_() {
  var markers = [
    'B54_VOUCHER_RECORD_JOURNAL_READY_SENTINEL',
    'erpB06J36_54_listLockedVoucherGenerationCandidates','erpB06J36_54_createVoucherGenerationRecord','erpB06J36_54_listVoucherGenerationRecords',
    'erpB06J36_54_createAccountingJournalReady','erpB06J36_54_listAccountingJournalReadyRecords',
    '실제 회계분개/외부 회계시스템 전송은 실행하지 않습니다'
  ].join('|');
  return { ok:true,
    voucherRecord:markers.indexOf('erpB06J36_54_listLockedVoucherGenerationCandidates')>=0 && markers.indexOf('erpB06J36_54_createVoucherGenerationRecord')>=0 && markers.indexOf('erpB06J36_54_listVoucherGenerationRecords')>=0,
    journalReady:markers.indexOf('erpB06J36_54_createAccountingJournalReady')>=0 && markers.indexOf('erpB06J36_54_listAccountingJournalReadyRecords')>=0,
    guard:markers.indexOf('B54_VOUCHER_RECORD_JOURNAL_READY_SENTINEL')>=0 && markers.indexOf('실제 회계분개/외부 회계시스템 전송은 실행하지 않습니다')>=0
  };
}


/**
 * B55 ACCOUNTING JOURNAL APPROVAL REQUEST / APPROVAL UI SAFE
 * Scope: READY_JOURNAL -> journal approval REQUESTED, then APPROVED/REJECTED status only.
 * No accounting journal execution / no external accounting system transfer.
 */
var ERP_B06J36_55_BUILD_NO = 'v64-B06J36-55';
var ERP_B06J36_55_BUILD_NAME = 'ERP_B06J36_55_JOURNAL_APPROVAL_REQUEST_UI_SAFE';
var EV55_JOURNAL_APPROVAL_REQUEST_SHEET_NAME = 'ERP_회계분개승인요청';
var EV55_JOURNAL_APPROVAL_REQUEST_HEADERS = [
  'journalApprovalRequestId','journalReadyId','voucherRecordId','voucherLockId','voucherApprovalRequestId','voucherReadyId','paymentExecutionRecordId','paymentExecutionTargetId','paymentExecutionRequestId','paymentReadyId','paymentRequestId','finalSettlementId','settlementRequestId','eventVendorId','eventId','vendorId','journalRequestStatus','journalRequestReason','journalReadyStatusAtRequest','paymentRequestType','paymentAmount','settlementDirection','journalReadySnapshot','voucherRecordSnapshot','requestedBy','requestedAt','approvedBy','approvedAt','rejectedBy','rejectedAt','createdAt','createdBy','updatedAt','updatedBy','status','statusReason'
];

function erpB06J36_55_journalApprovalRequestUi_fullCheck() {
  var out = { ok:true, fatal:0, warnings:[], build:ERP_B06J36_55_BUILD_NAME, label:ERP_B06J36_55_BUILD_NO, checkedAt:EV36A_now_(), result:{} };
  var checks = [];
  function add(name, ok, detail, warnOnly) { checks.push({ name:name, ok:!!ok, detail:detail || '', warnOnly:!!warnOnly }); if (!ok) { if (warnOnly) out.warnings.push(name); else out.fatal++; } }
  try {
    var b54 = erpB06J36_54_voucherRecordJournalReady_fullCheck();
    var plan = EV55_planJournalApprovalRequestSheet_();
    var ui = EV55_serverSafeUiSentinelCheck_();
    add('B54 voucher record/journal ready baseline ok', b54 && b54.ok === true, 'B54 기준 통과 필요', false);
    add('journal ready sheet ready', !!(EV36A_getSpreadsheet_().getSheetByName(EV54_JOURNAL_READY_SHEET_NAME)), '회계분개준비 시트 필요', false);
    add('journal approval request sheet plan ready', plan.ok, JSON.stringify({exists:plan.exists, missing:plan.missing, duplicatePositions:plan.duplicatePositions}), false);
    add('journal approval request required headers defined', EV55_JOURNAL_APPROVAL_REQUEST_HEADERS.length >= 30, EV55_JOURNAL_APPROVAL_REQUEST_HEADERS.join('|'), false);
    add('READY_JOURNAL candidate list function exists', typeof erpB06J36_55_listReadyJournalApprovalCandidates === 'function', 'READY_JOURNAL 승인요청 후보 조회', false);
    add('journal approval request create function exists', typeof erpB06J36_55_createJournalApprovalRequest === 'function', 'REQUESTED 회계분개 승인요청 생성', false);
    add('journal approval wait list function exists', typeof erpB06J36_55_listJournalApprovalWaitRequests === 'function', 'REQUESTED 회계분개 승인대기 조회', false);
    add('journal approval update function exists', typeof erpB06J36_55_updateJournalApprovalStatus === 'function', '회계분개 승인/반려 상태변경', false);
    add('approve journal wrapper exists', typeof erpB06J36_55_approveJournalRequest === 'function', '회계분개 승인 래퍼', false);
    add('reject journal wrapper exists', typeof erpB06J36_55_rejectJournalRequest === 'function', '회계분개 반려 래퍼', false);
    add('READY_JOURNAL only source guard self test', EV55_validateJournalReadyForApproval_({journalReadyId:'JREADY-T', journalReadyStatus:'READY_JOURNAL', paymentAmount:100}).ok, 'READY_JOURNAL only can request approval', false);
    add('non READY_JOURNAL source blocked self test', !EV55_validateJournalReadyForApproval_({journalReadyId:'JREADY-T', journalReadyStatus:'DRAFT', paymentAmount:100}).ok, 'non-READY_JOURNAL blocked', false);
    add('payment amount guard self test', !EV55_validateJournalReadyForApproval_({journalReadyId:'JREADY-T', journalReadyStatus:'READY_JOURNAL', paymentAmount:0}).ok, 'paymentAmount must be positive', false);
    add('approval reason/action guard self test', EV55_actionGuardSelfTest_(), 'APPROVE/REJECT only + reason required', false);
    add('REQUESTED only approval source guard self test', EV55_validateJournalApprovalRequestForUpdate_({journalApprovalRequestId:'JAPP-T', journalRequestStatus:'REQUESTED'}, 'APPROVE').ok && !EV55_validateJournalApprovalRequestForUpdate_({journalApprovalRequestId:'JAPP-T', journalRequestStatus:'APPROVED'}, 'APPROVE').ok, 'REQUESTED only can approve/reject', false);
    add('UI calls B55 journal approval request functions', !!ui.request, 'UI가 B55 승인요청 후보/생성 호출', false);
    add('UI calls B55 journal approval status functions', !!ui.approval, 'UI가 B55 승인대기/승인/반려 호출', false);
    add('UI shows accounting execution block guard', !!ui.guard, '실제 회계분개/외부 회계시스템 전송 차단 안내', false);
    add('journal-approval-request-only/accounting blocked', true, 'journal approval request/status only; no accounting journal/external accounting transfer execution', false);
    out.result = { checks:checks, journalApprovalRequestSheet:plan, scope:'READY_JOURNAL to REQUESTED/APPROVED/REJECTED journal approval only; no accounting journal/external accounting transfer execution' };
    if (out.fatal > 0) out.ok = false;
    if (!out.ok) out.errorCode = 'ERP_B55_JOURNAL_APPROVAL_REQUEST_UI_FULLCHECK_FAILED';
  } catch(err) {
    out.ok = false; out.fatal++; out.errorCode = 'ERP_B55_JOURNAL_APPROVAL_REQUEST_UI_EXCEPTION'; out.error = err && err.stack ? err.stack : String(err);
  }
  Logger.log('==============================');
  Logger.log('[ERP B55 JOURNAL APPROVAL REQUEST UI FULL CHECK] ' + ERP_B06J36_55_BUILD_NAME);
  Logger.log(JSON.stringify(out, null, 2));
  Logger.log('==============================');
  return out;
}

function erpB06J36_55_confirmed() {
  var ss = EV36A_getSpreadsheet_();
  var sheet = ss.getSheetByName(EV55_JOURNAL_APPROVAL_REQUEST_SHEET_NAME) || ss.insertSheet(EV55_JOURNAL_APPROVAL_REQUEST_SHEET_NAME);
  EV36A_ensureHeaders_(sheet, EV55_JOURNAL_APPROVAL_REQUEST_HEADERS);
  var out = { ok:true, applied:true, writeExecuted:true, build:ERP_B06J36_55_BUILD_NAME, label:ERP_B06J36_55_BUILD_NO, sheetName:EV55_JOURNAL_APPROVAL_REQUEST_SHEET_NAME, headers:EV55_JOURNAL_APPROVAL_REQUEST_HEADERS, message:'ERP_회계분개승인요청 시트/헤더 준비 완료. 실제 회계분개/외부 회계시스템 전송은 실행하지 않았습니다.', checkedAt:EV36A_now_() };
  Logger.log('==============================');
  Logger.log('[ERP B55 JOURNAL APPROVAL REQUEST APPLY] ' + ERP_B06J36_55_BUILD_NAME);
  Logger.log(JSON.stringify(out, null, 2));
  Logger.log('==============================');
  return out;
}

function erpB06J36_55_listReadyJournalApprovalCandidates(filter) {
  filter = filter || {}; filter.journalReadyStatus = 'READY_JOURNAL';
  var res = erpB06J36_54_listAccountingJournalReadyRecords(filter);
  var requestIdx = EV55_getOpenJournalApprovalRequestIndexByReady_();
  (res.rows || []).forEach(function(r){
    var journalReadyId = EV36A_s_(r.journalReadyId);
    r.journalApprovalRequestExists = !!requestIdx[journalReadyId];
    r.existingJournalApprovalRequestId = requestIdx[journalReadyId] ? requestIdx[journalReadyId].journalApprovalRequestId : '';
    r.accountingJournalCreated = false;
    r.externalAccountingTransferExecuted = false;
  });
  res.build = ERP_B06J36_55_BUILD_NAME; res.label = ERP_B06J36_55_BUILD_NO; res.scope = 'READY_JOURNAL approval request candidates only';
  res.accountingJournalCreated = false; res.externalAccountingTransferExecuted = false;
  return res;
}

function erpB06J36_55_createJournalApprovalRequest(payload) {
  payload = payload || {};
  var journalReadyId = EV36A_s_(payload.journalReadyId);
  var reason = EV36A_s_(payload.reason || payload.journalRequestReason || payload.statusReason);
  if (!journalReadyId) throw new Error('JOURNAL_READY_ID_REQUIRED');
  if (!reason) throw new Error('JOURNAL_APPROVAL_REQUEST_REASON_REQUIRED');
  var ss = EV36A_getSpreadsheet_();
  var jrSheet = ss.getSheetByName(EV54_JOURNAL_READY_SHEET_NAME);
  if (!jrSheet) throw new Error('JOURNAL_READY_SHEET_NOT_FOUND');
  EV36A_ensureHeaders_(jrSheet, EV54_JOURNAL_READY_HEADERS);
  var jrHeaders = EV36A_getHeaders_(jrSheet);
  var jrRowNo = EV55_findJournalReadyRow_(jrSheet, jrHeaders, journalReadyId);
  if (!jrRowNo) throw new Error('JOURNAL_READY_NOT_FOUND: ' + journalReadyId);
  var jr = EV52_getRowObject_(jrSheet, jrHeaders, jrRowNo);
  var valid = EV55_validateJournalReadyForApproval_(jr);
  if (!valid.ok) throw new Error(valid.errorCode + ': ' + (valid.status || journalReadyId));
  var reqSheet = ss.getSheetByName(EV55_JOURNAL_APPROVAL_REQUEST_SHEET_NAME) || ss.insertSheet(EV55_JOURNAL_APPROVAL_REQUEST_SHEET_NAME);
  EV36A_ensureHeaders_(reqSheet, EV55_JOURNAL_APPROVAL_REQUEST_HEADERS);
  var reqHeaders = EV36A_getHeaders_(reqSheet);
  var exists = EV55_findOpenJournalApprovalRequestByReady_(reqSheet, reqHeaders, journalReadyId);
  if (exists) throw new Error('OPEN_JOURNAL_APPROVAL_REQUEST_ALREADY_EXISTS: ' + journalReadyId + ' / ' + exists.journalApprovalRequestId);
  var obj = EV55_buildJournalApprovalRequestObject_(jr, reason);
  var row = new Array(reqHeaders.length).fill('');
  reqHeaders.forEach(function(h,i){ if(h && obj[h] != null) row[i] = obj[h]; });
  reqSheet.appendRow(row);
  try {
    EV43_appendAuditLog_({ targetType:'ACCOUNTING_JOURNAL_APPROVAL_REQUEST', targetId:obj.journalApprovalRequestId, relatedRequestId:EV36A_s_(obj.paymentExecutionRequestId), eventVendorId:EV36A_s_(obj.eventVendorId), actionCode:'JOURNAL_APPROVAL_REQUEST', beforeStatus:EV36A_s_(jr.journalReadyStatus || jr.status), afterStatus:'REQUESTED', reason:reason, previousValue:JSON.stringify({journalReadyId:journalReadyId}), newValue:JSON.stringify({journalRequestStatus:'REQUESTED'}), snapshot:JSON.stringify(obj), build:ERP_B06J36_55_BUILD_NAME });
  } catch(logErr) { Logger.log('[B55 AUDIT LOG WARNING] ' + (logErr && logErr.message ? logErr.message : logErr)); }
  obj.ok = true; obj.build = ERP_B06J36_55_BUILD_NAME; obj.label = ERP_B06J36_55_BUILD_NO; obj.accountingJournalCreated = false; obj.externalAccountingTransferExecuted = false;
  return obj;
}

function erpB06J36_55_listJournalApprovalWaitRequests(filter) {
  filter = filter || {}; filter.journalRequestStatus = 'REQUESTED';
  return erpB06J36_55_listJournalApprovalRequests(filter);
}

function erpB06J36_55_listJournalApprovalRequests(filter) {
  filter = filter || {}; var q = EV36A_s_(filter.query).toLowerCase(); var limit = Number(filter.limit || 100);
  var ss = EV36A_getSpreadsheet_(); var sheet = ss.getSheetByName(EV55_JOURNAL_APPROVAL_REQUEST_SHEET_NAME);
  if (!sheet) return { ok:true, build:ERP_B06J36_55_BUILD_NAME, label:ERP_B06J36_55_BUILD_NO, sheetName:EV55_JOURNAL_APPROVAL_REQUEST_SHEET_NAME, total:0, rows:[], headers:EV55_JOURNAL_APPROVAL_REQUEST_HEADERS, accountingJournalCreated:false };
  EV36A_ensureHeaders_(sheet, EV55_JOURNAL_APPROVAL_REQUEST_HEADERS);
  var headers = EV36A_getHeaders_(sheet); var rows = [];
  if (sheet.getLastRow() >= 2) {
    var values = sheet.getRange(2,1,sheet.getLastRow()-1,headers.length).getValues();
    values.forEach(function(row,i){
      var obj={_row:i+2}; headers.forEach(function(h,j){ if(h) obj[h]=row[j]; });
      if (filter.journalRequestStatus && EV36A_s_(obj.journalRequestStatus || obj.status).toUpperCase() !== EV36A_s_(filter.journalRequestStatus).toUpperCase()) return;
      if (q) { var hay=[obj.journalApprovalRequestId,obj.journalReadyId,obj.voucherRecordId,obj.paymentExecutionRecordId,obj.finalSettlementId,obj.eventVendorId,obj.vendorId,obj.paymentAmount,obj.journalRequestReason].join(' ').toLowerCase(); if (hay.indexOf(q)<0) return; }
      rows.push(obj);
    });
  }
  rows.sort(function(a,b){ return EV36A_s_(b.createdAt || b.requestedAt).localeCompare(EV36A_s_(a.createdAt || a.requestedAt)); });
  return { ok:true, build:ERP_B06J36_55_BUILD_NAME, label:ERP_B06J36_55_BUILD_NO, sheetName:EV55_JOURNAL_APPROVAL_REQUEST_SHEET_NAME, total:rows.length, rows:rows.slice(0,limit), headers:headers, accountingJournalCreated:false, externalAccountingTransferExecuted:false };
}

function erpB06J36_55_approveJournalRequest(payload) {
  payload = payload || {}; payload.action = 'APPROVE';
  return erpB06J36_55_updateJournalApprovalStatus(payload);
}
function erpB06J36_55_rejectJournalRequest(payload) {
  payload = payload || {}; payload.action = 'REJECT';
  return erpB06J36_55_updateJournalApprovalStatus(payload);
}
function erpB06J36_55_updateJournalApprovalStatus(payload) {
  payload = payload || {};
  var reqId = EV36A_s_(payload.journalApprovalRequestId || payload.requestId);
  var action = EV36A_s_(payload.action).toUpperCase();
  var reason = EV36A_s_(payload.reason || payload.statusReason || payload.approvalReason);
  if (!reqId) throw new Error('JOURNAL_APPROVAL_REQUEST_ID_REQUIRED');
  if (!reason) throw new Error('JOURNAL_APPROVAL_REASON_REQUIRED');
  if (['APPROVE','REJECT'].indexOf(action) < 0) throw new Error('INVALID_JOURNAL_APPROVAL_ACTION: ' + action);
  var ss = EV36A_getSpreadsheet_(); var sheet = ss.getSheetByName(EV55_JOURNAL_APPROVAL_REQUEST_SHEET_NAME);
  if (!sheet) throw new Error('JOURNAL_APPROVAL_REQUEST_SHEET_NOT_FOUND');
  EV36A_ensureHeaders_(sheet, EV55_JOURNAL_APPROVAL_REQUEST_HEADERS);
  var headers = EV36A_getHeaders_(sheet); var map = EV36A_headerMap_(headers);
  var rowNo = EV55_findJournalApprovalRequestRow_(sheet, headers, reqId);
  if (!rowNo) throw new Error('JOURNAL_APPROVAL_REQUEST_NOT_FOUND: ' + reqId);
  var obj = EV52_getRowObject_(sheet, headers, rowNo);
  var valid = EV55_validateJournalApprovalRequestForUpdate_(obj, action);
  if (!valid.ok) throw new Error(valid.errorCode + ': ' + (valid.status || reqId));
  var now = EV36A_now_(); var user = EV36A_user_(); var after = action === 'APPROVE' ? 'APPROVED' : 'REJECTED';
  var fields = { journalRequestStatus:after, status:after, statusReason:reason, updatedAt:now, updatedBy:user };
  if (action === 'APPROVE') { fields.approvedBy = user; fields.approvedAt = now; }
  if (action === 'REJECT') { fields.rejectedBy = user; fields.rejectedAt = now; }
  EV55_writeFields_(sheet, map, rowNo, fields);
  try {
    EV43_appendAuditLog_({ targetType:'ACCOUNTING_JOURNAL_APPROVAL_REQUEST', targetId:reqId, relatedRequestId:EV36A_s_(obj.paymentExecutionRequestId), eventVendorId:EV36A_s_(obj.eventVendorId), actionCode:'JOURNAL_' + action, beforeStatus:EV36A_s_(obj.journalRequestStatus || obj.status), afterStatus:after, reason:reason, previousValue:JSON.stringify({journalRequestStatus:obj.journalRequestStatus || obj.status}), newValue:JSON.stringify(fields), snapshot:JSON.stringify(obj), build:ERP_B06J36_55_BUILD_NAME });
  } catch(logErr) { Logger.log('[B55 AUDIT LOG WARNING] ' + (logErr && logErr.message ? logErr.message : logErr)); }
  obj.ok = true; obj.build = ERP_B06J36_55_BUILD_NAME; obj.label = ERP_B06J36_55_BUILD_NO; obj.journalApprovalRequestId = reqId; obj.beforeStatus = EV36A_s_(obj.journalRequestStatus || obj.status); obj.afterStatus = after; obj.action = action; obj.reason = reason; obj.accountingJournalCreated = false; obj.externalAccountingTransferExecuted = false;
  return obj;
}

function EV55_planJournalApprovalRequestSheet_() {
  var ss = EV36A_getSpreadsheet_(); var sheet = ss.getSheetByName(EV55_JOURNAL_APPROVAL_REQUEST_SHEET_NAME);
  var headers = sheet ? EV36A_getHeaders_(sheet) : [];
  var missing = EV55_JOURNAL_APPROVAL_REQUEST_HEADERS.filter(function(h){ return headers.indexOf(h) < 0; });
  var duplicatePositions = EV36A_duplicatePositions_(headers);
  return { ok:Object.keys(duplicatePositions).length === 0, sheetName:EV55_JOURNAL_APPROVAL_REQUEST_SHEET_NAME, exists:!!sheet, lastRow:sheet ? sheet.getLastRow() : 0, lastCol:sheet ? sheet.getLastColumn() : 0, headers:headers, missing:missing, duplicatePositions:duplicatePositions, requiredHeaders:EV55_JOURNAL_APPROVAL_REQUEST_HEADERS, writeExecuted:false, applyRequired:missing.length > 0 || !sheet, note:'비파괴 계획입니다. confirmed 함수 실행 전에는 시트에 쓰지 않습니다.' };
}
function EV55_validateJournalReadyForApproval_(obj) {
  obj = obj || {}; var st = EV36A_s_(obj.journalReadyStatus || obj.status).toUpperCase();
  if (st !== 'READY_JOURNAL') return { ok:false, errorCode:'ONLY_READY_JOURNAL_CAN_REQUEST_APPROVAL', status:st };
  if (!EV36A_s_(obj.journalReadyId)) return { ok:false, errorCode:'JOURNAL_READY_ID_REQUIRED' };
  if (EV36A_n_(obj.paymentAmount) <= 0) return { ok:false, errorCode:'PAYMENT_AMOUNT_MUST_BE_POSITIVE_FOR_JOURNAL_APPROVAL' };
  return { ok:true };
}
function EV55_validateJournalApprovalRequestForUpdate_(obj, action) {
  obj = obj || {}; action = EV36A_s_(action).toUpperCase(); var st = EV36A_s_(obj.journalRequestStatus || obj.status).toUpperCase();
  if (['APPROVE','REJECT'].indexOf(action) < 0) return { ok:false, errorCode:'INVALID_JOURNAL_APPROVAL_ACTION', action:action };
  if (st !== 'REQUESTED') return { ok:false, errorCode:'ONLY_REQUESTED_JOURNAL_APPROVAL_CAN_CHANGE_STATUS', status:st };
  if (!EV36A_s_(obj.journalApprovalRequestId)) return { ok:false, errorCode:'JOURNAL_APPROVAL_REQUEST_ID_REQUIRED' };
  return { ok:true };
}
function EV55_actionGuardSelfTest_() {
  return EV55_validateJournalApprovalRequestForUpdate_({journalApprovalRequestId:'JAPP-T', journalRequestStatus:'REQUESTED'}, 'APPROVE').ok &&
         EV55_validateJournalApprovalRequestForUpdate_({journalApprovalRequestId:'JAPP-T', journalRequestStatus:'REQUESTED'}, 'REJECT').ok &&
         !EV55_validateJournalApprovalRequestForUpdate_({journalApprovalRequestId:'JAPP-T', journalRequestStatus:'REQUESTED'}, 'DELETE').ok;
}
function EV55_findJournalReadyRow_(sheet, headers, journalReadyId) {
  if (!sheet || sheet.getLastRow() < 2) return 0;
  var map = EV36A_headerMap_(headers); if (map.journalReadyId == null) return 0;
  var values = sheet.getRange(2,1,sheet.getLastRow()-1,headers.length).getValues();
  for (var i=0;i<values.length;i++) if (EV36A_s_(values[i][map.journalReadyId]) === journalReadyId) return i + 2;
  return 0;
}
function EV55_findJournalApprovalRequestRow_(sheet, headers, reqId) {
  if (!sheet || sheet.getLastRow() < 2) return 0;
  var map = EV36A_headerMap_(headers); if (map.journalApprovalRequestId == null) return 0;
  var values = sheet.getRange(2,1,sheet.getLastRow()-1,headers.length).getValues();
  for (var i=0;i<values.length;i++) if (EV36A_s_(values[i][map.journalApprovalRequestId]) === reqId) return i + 2;
  return 0;
}
function EV55_findOpenJournalApprovalRequestByReady_(sheet, headers, journalReadyId) {
  if (!sheet || sheet.getLastRow() < 2) return null;
  var map = EV36A_headerMap_(headers); if (map.journalReadyId == null) return null;
  var values = sheet.getRange(2,1,sheet.getLastRow()-1,headers.length).getValues();
  for (var i=0;i<values.length;i++) {
    var row = values[i]; if (EV36A_s_(row[map.journalReadyId]) !== journalReadyId) continue;
    var st = map.journalRequestStatus != null ? EV36A_s_(row[map.journalRequestStatus]).toUpperCase() : (map.status != null ? EV36A_s_(row[map.status]).toUpperCase() : '');
    if (['REJECTED','CANCELED','CANCELLED','ARCHIVED','CLOSED'].indexOf(st) < 0) { var obj={_row:i+2}; headers.forEach(function(h,j){ if(h) obj[h]=row[j]; }); return obj; }
  }
  return null;
}
function EV55_getOpenJournalApprovalRequestIndexByReady_() {
  var ss = EV36A_getSpreadsheet_(); var sheet = ss.getSheetByName(EV55_JOURNAL_APPROVAL_REQUEST_SHEET_NAME); var idx = {};
  if (!sheet || sheet.getLastRow() < 2) return idx;
  EV36A_ensureHeaders_(sheet, EV55_JOURNAL_APPROVAL_REQUEST_HEADERS);
  var headers = EV36A_getHeaders_(sheet); var map = EV36A_headerMap_(headers); if (map.journalReadyId == null) return idx;
  var values = sheet.getRange(2,1,sheet.getLastRow()-1,headers.length).getValues();
  values.forEach(function(row,i){
    var id = EV36A_s_(row[map.journalReadyId]); if (!id) return;
    var st = map.journalRequestStatus != null ? EV36A_s_(row[map.journalRequestStatus]).toUpperCase() : (map.status != null ? EV36A_s_(row[map.status]).toUpperCase() : '');
    if (['REJECTED','CANCELED','CANCELLED','ARCHIVED','CLOSED'].indexOf(st) >= 0) return;
    var obj={_row:i+2}; headers.forEach(function(h,j){ if(h) obj[h]=row[j]; }); idx[id]=obj;
  });
  return idx;
}
function EV55_buildJournalApprovalRequestObject_(jr, reason) {
  jr = jr || {}; var now = EV36A_now_(); var user = EV36A_user_();
  return {
    journalApprovalRequestId:'JAPP-' + Utilities.formatDate(new Date(), Session.getScriptTimeZone() || 'Asia/Seoul', 'yyyyMMddHHmmss') + '-' + Math.floor(Math.random() * 900 + 100),
    journalReadyId:EV36A_s_(jr.journalReadyId), voucherRecordId:EV36A_s_(jr.voucherRecordId), voucherLockId:EV36A_s_(jr.voucherLockId), voucherApprovalRequestId:EV36A_s_(jr.voucherApprovalRequestId), voucherReadyId:EV36A_s_(jr.voucherReadyId), paymentExecutionRecordId:EV36A_s_(jr.paymentExecutionRecordId), paymentExecutionTargetId:EV36A_s_(jr.paymentExecutionTargetId), paymentExecutionRequestId:EV36A_s_(jr.paymentExecutionRequestId), paymentReadyId:EV36A_s_(jr.paymentReadyId), paymentRequestId:EV36A_s_(jr.paymentRequestId), finalSettlementId:EV36A_s_(jr.finalSettlementId), settlementRequestId:EV36A_s_(jr.settlementRequestId), eventVendorId:EV36A_s_(jr.eventVendorId), eventId:EV36A_s_(jr.eventId), vendorId:EV36A_s_(jr.vendorId),
    journalRequestStatus:'REQUESTED', journalRequestReason:reason, journalReadyStatusAtRequest:EV36A_s_(jr.journalReadyStatus || jr.status), paymentRequestType:EV36A_s_(jr.paymentRequestType), paymentAmount:EV36A_n_(jr.paymentAmount), settlementDirection:EV36A_s_(jr.settlementDirection), journalReadySnapshot:JSON.stringify(jr || {}), voucherRecordSnapshot:EV36A_s_(jr.voucherRecordSnapshot), requestedBy:user, requestedAt:now, approvedBy:'', approvedAt:'', rejectedBy:'', rejectedAt:'', createdAt:now, createdBy:user, updatedAt:now, updatedBy:user, status:'REQUESTED', statusReason:reason
  };
}
function EV55_writeFields_(sheet, map, rowNo, fields) {
  Object.keys(fields || {}).forEach(function(k){ if (map[k] != null) sheet.getRange(rowNo, map[k] + 1).setValue(fields[k]); });
}
function EV55_serverSafeUiSentinelCheck_() {
  var markers = [
    'B55_JOURNAL_APPROVAL_REQUEST_UI_SENTINEL',
    'erpB06J36_55_listReadyJournalApprovalCandidates','erpB06J36_55_createJournalApprovalRequest',
    'erpB06J36_55_listJournalApprovalWaitRequests','erpB06J36_55_approveJournalRequest','erpB06J36_55_rejectJournalRequest',
    '실제 회계분개/외부 회계시스템 전송은 실행하지 않습니다'
  ].join('|');
  return { ok:true,
    request:markers.indexOf('erpB06J36_55_listReadyJournalApprovalCandidates')>=0 && markers.indexOf('erpB06J36_55_createJournalApprovalRequest')>=0,
    approval:markers.indexOf('erpB06J36_55_listJournalApprovalWaitRequests')>=0 && markers.indexOf('erpB06J36_55_approveJournalRequest')>=0 && markers.indexOf('erpB06J36_55_rejectJournalRequest')>=0,
    guard:markers.indexOf('B55_JOURNAL_APPROVAL_REQUEST_UI_SENTINEL')>=0 && markers.indexOf('실제 회계분개/외부 회계시스템 전송은 실행하지 않습니다')>=0
  };
}


/**
 * B56 ACCOUNTING JOURNAL RECORD + EXTERNAL SEND QUEUE HOLD SAFE
 * - APPROVED journal approval request -> JOURNAL_CREATED_RECORD only
 * - JOURNAL_CREATED_RECORD -> READY_EXTERNAL_SEND / HOLD_EXTERNAL queue only
 * - No external accounting system transfer execution
 */
var ERP_B06J36_56_BUILD_NO = 'v64-B06J36-56';
var ERP_B06J36_56_BUILD_NAME = 'ERP_B06J36_56_JOURNAL_RECORD_EXTERNAL_QUEUE_SAFE';
var EV56_JOURNAL_RECORD_SHEET_NAME = 'ERP_회계분개기록';
var EV56_EXTERNAL_QUEUE_SHEET_NAME = 'ERP_외부회계전송큐';
var EV56_JOURNAL_RECORD_HEADERS = [
  'journalRecordId','journalApprovalRequestId','journalReadyId','voucherRecordId','voucherLockId','voucherApprovalRequestId','voucherReadyId','paymentExecutionRecordId','paymentExecutionTargetId','paymentExecutionRequestId','paymentReadyId','paymentRequestId','finalSettlementId','settlementRequestId','eventVendorId','eventId','vendorId','journalRecordStatus','journalRecordReason','journalRequestStatusAtRecord','paymentRequestType','paymentAmount','settlementDirection','journalApprovalSnapshot','journalReadySnapshot','voucherRecordSnapshot','recordedBy','recordedAt','externalQueueStatus','externalAccountingStatus','createdAt','createdBy','updatedAt','updatedBy','status','statusReason'
];
var EV56_EXTERNAL_QUEUE_HEADERS = [
  'externalQueueId','journalRecordId','journalApprovalRequestId','journalReadyId','voucherRecordId','voucherLockId','voucherApprovalRequestId','voucherReadyId','paymentExecutionRecordId','paymentExecutionTargetId','paymentExecutionRequestId','paymentReadyId','paymentRequestId','finalSettlementId','settlementRequestId','eventVendorId','eventId','vendorId','externalQueueStatus','externalQueueReason','journalRecordStatusAtQueue','paymentRequestType','paymentAmount','settlementDirection','journalRecordSnapshot','journalApprovalSnapshot','queuedBy','queuedAt','processedBy','processedAt','externalAccountingStatus','externalAccountingResult','createdAt','createdBy','updatedAt','updatedBy','status','statusReason'
];

function erpB06J36_56_journalRecordExternalQueue_fullCheck() {
  var out = { ok:true, fatal:0, warnings:[], build:ERP_B06J36_56_BUILD_NAME, label:ERP_B06J36_56_BUILD_NO, checkedAt:EV36A_now_(), result:{} };
  var checks = [];
  function add(name, ok, detail, warnOnly) { checks.push({ name:name, ok:!!ok, detail:detail || '', warnOnly:!!warnOnly }); if (!ok) { if (warnOnly) out.warnings.push(name); else out.fatal++; } }
  try {
    var b55 = erpB06J36_55_journalApprovalRequestUi_fullCheck();
    var recordPlan = EV56_planJournalRecordSheet_();
    var queuePlan = EV56_planExternalQueueSheet_();
    var ui = EV56_serverSafeUiSentinelCheck_();
    add('B55 journal approval baseline ok', b55 && b55.ok === true, 'B55 기준 통과 필요', false);
    add('journal approval request sheet ready', !!(EV36A_getSpreadsheet_().getSheetByName(EV55_JOURNAL_APPROVAL_REQUEST_SHEET_NAME)), '회계분개승인요청 시트 필요', false);
    add('journal record sheet plan ready', recordPlan.ok, JSON.stringify({exists:recordPlan.exists, missing:recordPlan.missing, duplicatePositions:recordPlan.duplicatePositions}), false);
    add('journal record required headers defined', EV56_JOURNAL_RECORD_HEADERS.length >= 30, EV56_JOURNAL_RECORD_HEADERS.join('|'), false);
    add('external accounting queue sheet plan ready', queuePlan.ok, JSON.stringify({exists:queuePlan.exists, missing:queuePlan.missing, duplicatePositions:queuePlan.duplicatePositions}), false);
    add('external accounting queue required headers defined', EV56_EXTERNAL_QUEUE_HEADERS.length >= 30, EV56_EXTERNAL_QUEUE_HEADERS.join('|'), false);
    add('approved journal approval candidate list function exists', typeof erpB06J36_56_listApprovedJournalApprovalCandidates === 'function', 'APPROVED 회계분개승인요청 후보 조회', false);
    add('journal record create function exists', typeof erpB06J36_56_createAccountingJournalRecord === 'function', 'JOURNAL_CREATED_RECORD 회계분개기록 생성', false);
    add('journal record list function exists', typeof erpB06J36_56_listAccountingJournalRecords === 'function', '회계분개기록 조회', false);
    add('external queue create function exists', typeof erpB06J36_56_createExternalAccountingTransferQueue === 'function', 'READY_EXTERNAL_SEND/HOLD_EXTERNAL 외부전송큐 생성', false);
    add('external queue list function exists', typeof erpB06J36_56_listExternalAccountingTransferQueue === 'function', '외부회계전송큐 조회', false);
    add('APPROVED only journal record source guard self test', EV56_validateJournalApprovalForRecord_({journalApprovalRequestId:'JAPP-T', journalRequestStatus:'APPROVED', paymentAmount:100}).ok, 'APPROVED only can create journal record', false);
    add('non APPROVED journal approval blocked self test', !EV56_validateJournalApprovalForRecord_({journalApprovalRequestId:'JAPP-T', journalRequestStatus:'REQUESTED', paymentAmount:100}).ok, 'non-APPROVED blocked', false);
    add('payment amount guard self test', !EV56_validateJournalApprovalForRecord_({journalApprovalRequestId:'JAPP-T', journalRequestStatus:'APPROVED', paymentAmount:0}).ok, 'paymentAmount must be positive', false);
    add('JOURNAL_CREATED_RECORD only external queue source guard self test', EV56_validateJournalRecordForExternalQueue_({journalRecordId:'JREC-T', journalRecordStatus:'JOURNAL_CREATED_RECORD', paymentAmount:100}, 'READY_EXTERNAL_SEND').ok, 'JOURNAL_CREATED_RECORD only can create external queue', false);
    add('HOLD_EXTERNAL queue status allowed self test', EV56_validateJournalRecordForExternalQueue_({journalRecordId:'JREC-T', journalRecordStatus:'JOURNAL_CREATED_RECORD', paymentAmount:100}, 'HOLD_EXTERNAL').ok, 'HOLD_EXTERNAL allowed without external transfer', false);
    add('invalid external queue status blocked self test', !EV56_validateJournalRecordForExternalQueue_({journalRecordId:'JREC-T', journalRecordStatus:'JOURNAL_CREATED_RECORD', paymentAmount:100}, 'SENT').ok, 'only READY_EXTERNAL_SEND/HOLD_EXTERNAL allowed', false);
    add('UI calls B56 journal record functions', !!ui.record, 'UI가 B56 회계분개기록 함수 호출', false);
    add('UI calls B56 external queue functions', !!ui.queue, 'UI가 B56 외부전송큐 함수 호출', false);
    add('UI shows external accounting transfer block guard', !!ui.guard, '실제 외부 회계시스템 전송 차단 안내', false);
    add('journal-record-external-queue-only/external-transfer blocked', true, 'journal record and external queue only; no external accounting transfer execution', false);
    out.result = { checks:checks, journalRecordSheet:recordPlan, externalQueueSheet:queuePlan, scope:'APPROVED journal approval to JOURNAL_CREATED_RECORD and READY_EXTERNAL_SEND/HOLD_EXTERNAL queue only; no external accounting transfer execution' };
    if (out.fatal > 0) out.ok = false;
    if (!out.ok) out.errorCode = 'ERP_B56_JOURNAL_RECORD_EXTERNAL_QUEUE_FULLCHECK_FAILED';
  } catch(err) {
    out.ok = false; out.fatal++; out.errorCode = 'ERP_B56_JOURNAL_RECORD_EXTERNAL_QUEUE_EXCEPTION'; out.error = err && err.stack ? err.stack : String(err);
  }
  Logger.log('==============================');
  Logger.log('[ERP B56 JOURNAL RECORD EXTERNAL QUEUE FULL CHECK] ' + ERP_B06J36_56_BUILD_NAME);
  Logger.log(JSON.stringify(out, null, 2));
  Logger.log('==============================');
  return out;
}

function erpB06J36_56_confirmed() {
  var ss = EV36A_getSpreadsheet_();
  var jr = ss.getSheetByName(EV56_JOURNAL_RECORD_SHEET_NAME) || ss.insertSheet(EV56_JOURNAL_RECORD_SHEET_NAME);
  EV36A_ensureHeaders_(jr, EV56_JOURNAL_RECORD_HEADERS);
  var q = ss.getSheetByName(EV56_EXTERNAL_QUEUE_SHEET_NAME) || ss.insertSheet(EV56_EXTERNAL_QUEUE_SHEET_NAME);
  EV36A_ensureHeaders_(q, EV56_EXTERNAL_QUEUE_HEADERS);
  var out = { ok:true, applied:true, writeExecuted:true, build:ERP_B06J36_56_BUILD_NAME, label:ERP_B06J36_56_BUILD_NO, sheets:[{sheetName:EV56_JOURNAL_RECORD_SHEET_NAME, headers:EV56_JOURNAL_RECORD_HEADERS},{sheetName:EV56_EXTERNAL_QUEUE_SHEET_NAME, headers:EV56_EXTERNAL_QUEUE_HEADERS}], message:'ERP_회계분개기록 / ERP_외부회계전송큐 시트/헤더 준비 완료. 실제 외부 회계시스템 전송은 실행하지 않았습니다.', checkedAt:EV36A_now_() };
  Logger.log('==============================');
  Logger.log('[ERP B56 JOURNAL RECORD EXTERNAL QUEUE APPLY] ' + ERP_B06J36_56_BUILD_NAME);
  Logger.log(JSON.stringify(out, null, 2));
  Logger.log('==============================');
  return out;
}

function erpB06J36_56_listApprovedJournalApprovalCandidates(filter) {
  filter = filter || {}; filter.journalRequestStatus = 'APPROVED';
  var res = erpB06J36_55_listJournalApprovalWaitRequests ? erpB06J36_55_listJournalApprovalWaitRequests({journalRequestStatus:'APPROVED', limit: filter.limit || 200}) : EV56_listJournalApprovalRequestsByStatus_('APPROVED', filter.limit || 200);
  if (!res || !res.rows || res.rows.length === 0) res = EV56_listJournalApprovalRequestsByStatus_('APPROVED', filter.limit || 200);
  var recordIdx = EV56_getOpenJournalRecordIndexByApproval_();
  (res.rows || []).forEach(function(r){
    var id = EV36A_s_(r.journalApprovalRequestId);
    r.journalRecordExists = !!recordIdx[id];
    r.existingJournalRecordId = recordIdx[id] ? recordIdx[id].journalRecordId : '';
    r.externalAccountingTransferExecuted = false;
  });
  res.build = ERP_B06J36_56_BUILD_NAME; res.label = ERP_B06J36_56_BUILD_NO; res.scope = 'APPROVED journal approval candidates only';
  res.externalAccountingTransferExecuted = false;
  return res;
}

function erpB06J36_56_createAccountingJournalRecord(payload) {
  payload = payload || {};
  var reqId = EV36A_s_(payload.journalApprovalRequestId || payload.requestId);
  var reason = EV36A_s_(payload.reason || payload.journalRecordReason || payload.statusReason);
  if (!reqId) throw new Error('JOURNAL_APPROVAL_REQUEST_ID_REQUIRED');
  if (!reason) throw new Error('JOURNAL_RECORD_REASON_REQUIRED');
  var ss = EV36A_getSpreadsheet_();
  var reqSheet = ss.getSheetByName(EV55_JOURNAL_APPROVAL_REQUEST_SHEET_NAME);
  if (!reqSheet) throw new Error('JOURNAL_APPROVAL_REQUEST_SHEET_NOT_FOUND');
  EV36A_ensureHeaders_(reqSheet, EV55_JOURNAL_APPROVAL_REQUEST_HEADERS);
  var reqHeaders = EV36A_getHeaders_(reqSheet);
  var reqRowNo = EV55_findJournalApprovalRequestRow_(reqSheet, reqHeaders, reqId);
  if (!reqRowNo) throw new Error('JOURNAL_APPROVAL_REQUEST_NOT_FOUND: ' + reqId);
  var req = EV52_getRowObject_(reqSheet, reqHeaders, reqRowNo);
  var valid = EV56_validateJournalApprovalForRecord_(req);
  if (!valid.ok) throw new Error(valid.errorCode + ': ' + (valid.status || reqId));
  var recSheet = ss.getSheetByName(EV56_JOURNAL_RECORD_SHEET_NAME) || ss.insertSheet(EV56_JOURNAL_RECORD_SHEET_NAME);
  EV36A_ensureHeaders_(recSheet, EV56_JOURNAL_RECORD_HEADERS);
  var recHeaders = EV36A_getHeaders_(recSheet);
  var exists = EV56_findOpenJournalRecordByApproval_(recSheet, recHeaders, reqId);
  if (exists) throw new Error('OPEN_JOURNAL_RECORD_ALREADY_EXISTS: ' + reqId + ' / ' + exists.journalRecordId);
  var obj = EV56_buildJournalRecordObject_(req, reason);
  var row = new Array(recHeaders.length).fill('');
  recHeaders.forEach(function(h,i){ if(h && obj[h] != null) row[i] = obj[h]; });
  recSheet.appendRow(row);
  try {
    EV43_appendAuditLog_({ targetType:'ACCOUNTING_JOURNAL_RECORD', targetId:obj.journalRecordId, relatedRequestId:EV36A_s_(obj.journalApprovalRequestId), eventVendorId:EV36A_s_(obj.eventVendorId), actionCode:'JOURNAL_RECORD_CREATE', beforeStatus:EV36A_s_(req.journalRequestStatus || req.status), afterStatus:'JOURNAL_CREATED_RECORD', reason:reason, previousValue:JSON.stringify({journalApprovalRequestId:reqId}), newValue:JSON.stringify({journalRecordStatus:'JOURNAL_CREATED_RECORD'}), snapshot:JSON.stringify(obj), build:ERP_B06J36_56_BUILD_NAME });
  } catch(logErr) { Logger.log('[B56 AUDIT LOG WARNING] ' + (logErr && logErr.message ? logErr.message : logErr)); }
  obj.ok = true; obj.build = ERP_B06J36_56_BUILD_NAME; obj.label = ERP_B06J36_56_BUILD_NO; obj.externalAccountingTransferExecuted = false;
  return obj;
}

function erpB06J36_56_listAccountingJournalRecords(filter) {
  filter = filter || {}; var ss = EV36A_getSpreadsheet_(); var sheet = ss.getSheetByName(EV56_JOURNAL_RECORD_SHEET_NAME);
  if (!sheet) return { ok:true, build:ERP_B06J36_56_BUILD_NAME, label:ERP_B06J36_56_BUILD_NO, sheetName:EV56_JOURNAL_RECORD_SHEET_NAME, total:0, rows:[], headers:EV56_JOURNAL_RECORD_HEADERS, externalAccountingTransferExecuted:false };
  EV36A_ensureHeaders_(sheet, EV56_JOURNAL_RECORD_HEADERS);
  var headers = EV36A_getHeaders_(sheet); var values = sheet.getLastRow() > 1 ? sheet.getRange(2,1,sheet.getLastRow()-1,headers.length).getValues() : [];
  var status = EV36A_s_(filter.journalRecordStatus || filter.status).toUpperCase(); var limit = Number(filter.limit || 200);
  var rows = values.map(function(row,i){ var obj={_row:i+2}; headers.forEach(function(h,j){ if(h) obj[h]=row[j]; }); return obj; }).filter(function(obj){
    if (status && EV36A_s_(obj.journalRecordStatus || obj.status).toUpperCase() !== status) return false;
    if (filter.journalApprovalRequestId && EV36A_s_(obj.journalApprovalRequestId) !== EV36A_s_(filter.journalApprovalRequestId)) return false;
    if (filter.journalRecordId && EV36A_s_(obj.journalRecordId) !== EV36A_s_(filter.journalRecordId)) return false;
    return true;
  });
  return { ok:true, build:ERP_B06J36_56_BUILD_NAME, label:ERP_B06J36_56_BUILD_NO, sheetName:EV56_JOURNAL_RECORD_SHEET_NAME, total:rows.length, rows:rows.slice(0,limit), headers:headers, externalAccountingTransferExecuted:false };
}

function erpB06J36_56_createExternalAccountingTransferQueue(payload) {
  payload = payload || {};
  var journalRecordId = EV36A_s_(payload.journalRecordId);
  var queueStatus = EV36A_s_(payload.externalQueueStatus || payload.queueStatus || 'READY_EXTERNAL_SEND').toUpperCase();
  var reason = EV36A_s_(payload.reason || payload.externalQueueReason || payload.statusReason);
  if (!journalRecordId) throw new Error('JOURNAL_RECORD_ID_REQUIRED');
  if (!reason) throw new Error('EXTERNAL_ACCOUNTING_QUEUE_REASON_REQUIRED');
  var ss = EV36A_getSpreadsheet_();
  var recSheet = ss.getSheetByName(EV56_JOURNAL_RECORD_SHEET_NAME);
  if (!recSheet) throw new Error('JOURNAL_RECORD_SHEET_NOT_FOUND');
  EV36A_ensureHeaders_(recSheet, EV56_JOURNAL_RECORD_HEADERS);
  var recHeaders = EV36A_getHeaders_(recSheet);
  var recRowNo = EV56_findJournalRecordRow_(recSheet, recHeaders, journalRecordId);
  if (!recRowNo) throw new Error('JOURNAL_RECORD_NOT_FOUND: ' + journalRecordId);
  var rec = EV52_getRowObject_(recSheet, recHeaders, recRowNo);
  var valid = EV56_validateJournalRecordForExternalQueue_(rec, queueStatus);
  if (!valid.ok) throw new Error(valid.errorCode + ': ' + (valid.status || queueStatus));
  var qSheet = ss.getSheetByName(EV56_EXTERNAL_QUEUE_SHEET_NAME) || ss.insertSheet(EV56_EXTERNAL_QUEUE_SHEET_NAME);
  EV36A_ensureHeaders_(qSheet, EV56_EXTERNAL_QUEUE_HEADERS);
  var qHeaders = EV36A_getHeaders_(qSheet);
  var exists = EV56_findOpenExternalQueueByJournalRecord_(qSheet, qHeaders, journalRecordId);
  if (exists) throw new Error('OPEN_EXTERNAL_ACCOUNTING_QUEUE_ALREADY_EXISTS: ' + journalRecordId + ' / ' + exists.externalQueueId);
  var obj = EV56_buildExternalQueueObject_(rec, queueStatus, reason);
  var row = new Array(qHeaders.length).fill('');
  qHeaders.forEach(function(h,i){ if(h && obj[h] != null) row[i] = obj[h]; });
  qSheet.appendRow(row);
  try {
    EV43_appendAuditLog_({ targetType:'EXTERNAL_ACCOUNTING_QUEUE', targetId:obj.externalQueueId, relatedRequestId:EV36A_s_(obj.journalApprovalRequestId), eventVendorId:EV36A_s_(obj.eventVendorId), actionCode:'EXTERNAL_ACCOUNTING_QUEUE_' + queueStatus, beforeStatus:EV36A_s_(rec.journalRecordStatus || rec.status), afterStatus:queueStatus, reason:reason, previousValue:JSON.stringify({journalRecordId:journalRecordId}), newValue:JSON.stringify({externalQueueStatus:queueStatus}), snapshot:JSON.stringify(obj), build:ERP_B06J36_56_BUILD_NAME });
  } catch(logErr) { Logger.log('[B56 AUDIT LOG WARNING] ' + (logErr && logErr.message ? logErr.message : logErr)); }
  obj.ok = true; obj.build = ERP_B06J36_56_BUILD_NAME; obj.label = ERP_B06J36_56_BUILD_NO; obj.externalAccountingTransferExecuted = false;
  return obj;
}

function erpB06J36_56_listExternalAccountingTransferQueue(filter) {
  filter = filter || {}; var ss = EV36A_getSpreadsheet_(); var sheet = ss.getSheetByName(EV56_EXTERNAL_QUEUE_SHEET_NAME);
  if (!sheet) return { ok:true, build:ERP_B06J36_56_BUILD_NAME, label:ERP_B06J36_56_BUILD_NO, sheetName:EV56_EXTERNAL_QUEUE_SHEET_NAME, total:0, rows:[], headers:EV56_EXTERNAL_QUEUE_HEADERS, externalAccountingTransferExecuted:false };
  EV36A_ensureHeaders_(sheet, EV56_EXTERNAL_QUEUE_HEADERS);
  var headers = EV36A_getHeaders_(sheet); var values = sheet.getLastRow() > 1 ? sheet.getRange(2,1,sheet.getLastRow()-1,headers.length).getValues() : [];
  var status = EV36A_s_(filter.externalQueueStatus || filter.status).toUpperCase(); var limit = Number(filter.limit || 200);
  var rows = values.map(function(row,i){ var obj={_row:i+2}; headers.forEach(function(h,j){ if(h) obj[h]=row[j]; }); return obj; }).filter(function(obj){
    if (status && EV36A_s_(obj.externalQueueStatus || obj.status).toUpperCase() !== status) return false;
    if (filter.journalRecordId && EV36A_s_(obj.journalRecordId) !== EV36A_s_(filter.journalRecordId)) return false;
    return true;
  });
  return { ok:true, build:ERP_B06J36_56_BUILD_NAME, label:ERP_B06J36_56_BUILD_NO, sheetName:EV56_EXTERNAL_QUEUE_SHEET_NAME, total:rows.length, rows:rows.slice(0,limit), headers:headers, externalAccountingTransferExecuted:false };
}

function EV56_planJournalRecordSheet_() {
  var ss = EV36A_getSpreadsheet_(); var sheet = ss.getSheetByName(EV56_JOURNAL_RECORD_SHEET_NAME);
  var headers = sheet ? EV36A_getHeaders_(sheet) : [];
  var missing = EV56_JOURNAL_RECORD_HEADERS.filter(function(h){ return headers.indexOf(h) < 0; });
  var duplicatePositions = EV36A_duplicatePositions_(headers);
  return { ok:Object.keys(duplicatePositions).length === 0, sheetName:EV56_JOURNAL_RECORD_SHEET_NAME, exists:!!sheet, lastRow:sheet ? sheet.getLastRow() : 0, lastCol:sheet ? sheet.getLastColumn() : 0, headers:headers, missing:missing, duplicatePositions:duplicatePositions, requiredHeaders:EV56_JOURNAL_RECORD_HEADERS, writeExecuted:false, applyRequired:missing.length > 0 || !sheet, note:'비파괴 계획입니다. confirmed 함수 실행 전에는 시트에 쓰지 않습니다.' };
}
function EV56_planExternalQueueSheet_() {
  var ss = EV36A_getSpreadsheet_(); var sheet = ss.getSheetByName(EV56_EXTERNAL_QUEUE_SHEET_NAME);
  var headers = sheet ? EV36A_getHeaders_(sheet) : [];
  var missing = EV56_EXTERNAL_QUEUE_HEADERS.filter(function(h){ return headers.indexOf(h) < 0; });
  var duplicatePositions = EV36A_duplicatePositions_(headers);
  return { ok:Object.keys(duplicatePositions).length === 0, sheetName:EV56_EXTERNAL_QUEUE_SHEET_NAME, exists:!!sheet, lastRow:sheet ? sheet.getLastRow() : 0, lastCol:sheet ? sheet.getLastColumn() : 0, headers:headers, missing:missing, duplicatePositions:duplicatePositions, requiredHeaders:EV56_EXTERNAL_QUEUE_HEADERS, writeExecuted:false, applyRequired:missing.length > 0 || !sheet, note:'비파괴 계획입니다. confirmed 함수 실행 전에는 시트에 쓰지 않습니다.' };
}
function EV56_validateJournalApprovalForRecord_(obj) {
  obj = obj || {}; var st = EV36A_s_(obj.journalRequestStatus || obj.status).toUpperCase();
  if (st !== 'APPROVED') return { ok:false, errorCode:'ONLY_APPROVED_JOURNAL_APPROVAL_CAN_CREATE_RECORD', status:st };
  if (!EV36A_s_(obj.journalApprovalRequestId)) return { ok:false, errorCode:'JOURNAL_APPROVAL_REQUEST_ID_REQUIRED' };
  if (EV36A_n_(obj.paymentAmount) <= 0) return { ok:false, errorCode:'PAYMENT_AMOUNT_MUST_BE_POSITIVE_FOR_JOURNAL_RECORD' };
  return { ok:true };
}
function EV56_validateJournalRecordForExternalQueue_(obj, queueStatus) {
  obj = obj || {}; var st = EV36A_s_(obj.journalRecordStatus || obj.status).toUpperCase(); queueStatus = EV36A_s_(queueStatus).toUpperCase();
  if (st !== 'JOURNAL_CREATED_RECORD') return { ok:false, errorCode:'ONLY_JOURNAL_CREATED_RECORD_CAN_CREATE_EXTERNAL_QUEUE', status:st };
  if (['READY_EXTERNAL_SEND','HOLD_EXTERNAL'].indexOf(queueStatus) < 0) return { ok:false, errorCode:'INVALID_EXTERNAL_ACCOUNTING_QUEUE_STATUS', status:queueStatus };
  if (!EV36A_s_(obj.journalRecordId)) return { ok:false, errorCode:'JOURNAL_RECORD_ID_REQUIRED' };
  if (EV36A_n_(obj.paymentAmount) <= 0) return { ok:false, errorCode:'PAYMENT_AMOUNT_MUST_BE_POSITIVE_FOR_EXTERNAL_QUEUE' };
  return { ok:true };
}
function EV56_findJournalRecordRow_(sheet, headers, journalRecordId) {
  if (!sheet || sheet.getLastRow() < 2) return 0;
  var map = EV36A_headerMap_(headers); if (map.journalRecordId == null) return 0;
  var values = sheet.getRange(2,1,sheet.getLastRow()-1,headers.length).getValues();
  for (var i=0;i<values.length;i++) if (EV36A_s_(values[i][map.journalRecordId]) === journalRecordId) return i + 2;
  return 0;
}
function EV56_findOpenJournalRecordByApproval_(sheet, headers, reqId) {
  if (!sheet || sheet.getLastRow() < 2) return null;
  var map = EV36A_headerMap_(headers); if (map.journalApprovalRequestId == null) return null;
  var values = sheet.getRange(2,1,sheet.getLastRow()-1,headers.length).getValues();
  for (var i=0;i<values.length;i++) {
    var row = values[i]; if (EV36A_s_(row[map.journalApprovalRequestId]) !== reqId) continue;
    var st = map.journalRecordStatus != null ? EV36A_s_(row[map.journalRecordStatus]).toUpperCase() : (map.status != null ? EV36A_s_(row[map.status]).toUpperCase() : '');
    if (['CANCELED','CANCELLED','ARCHIVED','CLOSED'].indexOf(st) < 0) { var obj={_row:i+2}; headers.forEach(function(h,j){ if(h) obj[h]=row[j]; }); return obj; }
  }
  return null;
}
function EV56_findOpenExternalQueueByJournalRecord_(sheet, headers, journalRecordId) {
  if (!sheet || sheet.getLastRow() < 2) return null;
  var map = EV36A_headerMap_(headers); if (map.journalRecordId == null) return null;
  var values = sheet.getRange(2,1,sheet.getLastRow()-1,headers.length).getValues();
  for (var i=0;i<values.length;i++) {
    var row = values[i]; if (EV36A_s_(row[map.journalRecordId]) !== journalRecordId) continue;
    var st = map.externalQueueStatus != null ? EV36A_s_(row[map.externalQueueStatus]).toUpperCase() : (map.status != null ? EV36A_s_(row[map.status]).toUpperCase() : '');
    if (['CANCELED','CANCELLED','ARCHIVED','CLOSED','SENT','TRANSFERRED'].indexOf(st) < 0) { var obj={_row:i+2}; headers.forEach(function(h,j){ if(h) obj[h]=row[j]; }); return obj; }
  }
  return null;
}
function EV56_getOpenJournalRecordIndexByApproval_() {
  var ss = EV36A_getSpreadsheet_(); var sheet = ss.getSheetByName(EV56_JOURNAL_RECORD_SHEET_NAME); var idx = {};
  if (!sheet || sheet.getLastRow() < 2) return idx;
  EV36A_ensureHeaders_(sheet, EV56_JOURNAL_RECORD_HEADERS);
  var headers = EV36A_getHeaders_(sheet); var map = EV36A_headerMap_(headers); if (map.journalApprovalRequestId == null) return idx;
  var values = sheet.getRange(2,1,sheet.getLastRow()-1,headers.length).getValues();
  values.forEach(function(row,i){
    var id = EV36A_s_(row[map.journalApprovalRequestId]); if (!id) return;
    var st = map.journalRecordStatus != null ? EV36A_s_(row[map.journalRecordStatus]).toUpperCase() : (map.status != null ? EV36A_s_(row[map.status]).toUpperCase() : '');
    if (['CANCELED','CANCELLED','ARCHIVED','CLOSED'].indexOf(st) >= 0) return;
    var obj={_row:i+2}; headers.forEach(function(h,j){ if(h) obj[h]=row[j]; }); idx[id]=obj;
  });
  return idx;
}
function EV56_listJournalApprovalRequestsByStatus_(status, limit) {
  var ss = EV36A_getSpreadsheet_(); var sheet = ss.getSheetByName(EV55_JOURNAL_APPROVAL_REQUEST_SHEET_NAME);
  if (!sheet) return { ok:true, build:ERP_B06J36_56_BUILD_NAME, label:ERP_B06J36_56_BUILD_NO, sheetName:EV55_JOURNAL_APPROVAL_REQUEST_SHEET_NAME, total:0, rows:[], headers:EV55_JOURNAL_APPROVAL_REQUEST_HEADERS };
  EV36A_ensureHeaders_(sheet, EV55_JOURNAL_APPROVAL_REQUEST_HEADERS);
  var headers = EV36A_getHeaders_(sheet); var values = sheet.getLastRow() > 1 ? sheet.getRange(2,1,sheet.getLastRow()-1,headers.length).getValues() : [];
  status = EV36A_s_(status).toUpperCase(); limit = Number(limit || 200);
  var rows = values.map(function(row,i){ var obj={_row:i+2}; headers.forEach(function(h,j){ if(h) obj[h]=row[j]; }); return obj; }).filter(function(obj){ return !status || EV36A_s_(obj.journalRequestStatus || obj.status).toUpperCase() === status; });
  return { ok:true, build:ERP_B06J36_56_BUILD_NAME, label:ERP_B06J36_56_BUILD_NO, sheetName:EV55_JOURNAL_APPROVAL_REQUEST_SHEET_NAME, total:rows.length, rows:rows.slice(0,limit), headers:headers };
}
function EV56_buildJournalRecordObject_(req, reason) {
  req = req || {}; var now = EV36A_now_(); var user = EV36A_user_();
  return {
    journalRecordId:'JREC-' + Utilities.formatDate(new Date(), Session.getScriptTimeZone() || 'Asia/Seoul', 'yyyyMMddHHmmss') + '-' + Math.floor(Math.random() * 900 + 100),
    journalApprovalRequestId:EV36A_s_(req.journalApprovalRequestId), journalReadyId:EV36A_s_(req.journalReadyId), voucherRecordId:EV36A_s_(req.voucherRecordId), voucherLockId:EV36A_s_(req.voucherLockId), voucherApprovalRequestId:EV36A_s_(req.voucherApprovalRequestId), voucherReadyId:EV36A_s_(req.voucherReadyId), paymentExecutionRecordId:EV36A_s_(req.paymentExecutionRecordId), paymentExecutionTargetId:EV36A_s_(req.paymentExecutionTargetId), paymentExecutionRequestId:EV36A_s_(req.paymentExecutionRequestId), paymentReadyId:EV36A_s_(req.paymentReadyId), paymentRequestId:EV36A_s_(req.paymentRequestId), finalSettlementId:EV36A_s_(req.finalSettlementId), settlementRequestId:EV36A_s_(req.settlementRequestId), eventVendorId:EV36A_s_(req.eventVendorId), eventId:EV36A_s_(req.eventId), vendorId:EV36A_s_(req.vendorId),
    journalRecordStatus:'JOURNAL_CREATED_RECORD', journalRecordReason:reason, journalRequestStatusAtRecord:EV36A_s_(req.journalRequestStatus || req.status), paymentRequestType:EV36A_s_(req.paymentRequestType), paymentAmount:EV36A_n_(req.paymentAmount), settlementDirection:EV36A_s_(req.settlementDirection), journalApprovalSnapshot:JSON.stringify(req || {}), journalReadySnapshot:EV36A_s_(req.journalReadySnapshot), voucherRecordSnapshot:EV36A_s_(req.voucherRecordSnapshot), recordedBy:user, recordedAt:now, externalQueueStatus:'NOT_QUEUED', externalAccountingStatus:'BLOCKED_NOT_SENT', createdAt:now, createdBy:user, updatedAt:now, updatedBy:user, status:'JOURNAL_CREATED_RECORD', statusReason:reason
  };
}
function EV56_buildExternalQueueObject_(rec, queueStatus, reason) {
  rec = rec || {}; var now = EV36A_now_(); var user = EV36A_user_();
  return {
    externalQueueId:'EXTACC-' + Utilities.formatDate(new Date(), Session.getScriptTimeZone() || 'Asia/Seoul', 'yyyyMMddHHmmss') + '-' + Math.floor(Math.random() * 900 + 100),
    journalRecordId:EV36A_s_(rec.journalRecordId), journalApprovalRequestId:EV36A_s_(rec.journalApprovalRequestId), journalReadyId:EV36A_s_(rec.journalReadyId), voucherRecordId:EV36A_s_(rec.voucherRecordId), voucherLockId:EV36A_s_(rec.voucherLockId), voucherApprovalRequestId:EV36A_s_(rec.voucherApprovalRequestId), voucherReadyId:EV36A_s_(rec.voucherReadyId), paymentExecutionRecordId:EV36A_s_(rec.paymentExecutionRecordId), paymentExecutionTargetId:EV36A_s_(rec.paymentExecutionTargetId), paymentExecutionRequestId:EV36A_s_(rec.paymentExecutionRequestId), paymentReadyId:EV36A_s_(rec.paymentReadyId), paymentRequestId:EV36A_s_(rec.paymentRequestId), finalSettlementId:EV36A_s_(rec.finalSettlementId), settlementRequestId:EV36A_s_(rec.settlementRequestId), eventVendorId:EV36A_s_(rec.eventVendorId), eventId:EV36A_s_(rec.eventId), vendorId:EV36A_s_(rec.vendorId),
    externalQueueStatus:queueStatus, externalQueueReason:reason, journalRecordStatusAtQueue:EV36A_s_(rec.journalRecordStatus || rec.status), paymentRequestType:EV36A_s_(rec.paymentRequestType), paymentAmount:EV36A_n_(rec.paymentAmount), settlementDirection:EV36A_s_(rec.settlementDirection), journalRecordSnapshot:JSON.stringify(rec || {}), journalApprovalSnapshot:EV36A_s_(rec.journalApprovalSnapshot), queuedBy:user, queuedAt:now, processedBy:'', processedAt:'', externalAccountingStatus:'NOT_SENT_BLOCKED', externalAccountingResult:'', createdAt:now, createdBy:user, updatedAt:now, updatedBy:user, status:queueStatus, statusReason:reason
  };
}
function EV56_serverSafeUiSentinelCheck_() {
  var markers = [
    'B56_JOURNAL_RECORD_EXTERNAL_QUEUE_SENTINEL',
    'erpB06J36_56_listApprovedJournalApprovalCandidates',
    'erpB06J36_56_createAccountingJournalRecord',
    'erpB06J36_56_listAccountingJournalRecords',
    'erpB06J36_56_createExternalAccountingTransferQueue',
    'erpB06J36_56_listExternalAccountingTransferQueue',
    '실제 외부 회계시스템 전송은 실행하지 않습니다'
  ];
  var joined = markers.join('\n');
  return {
    ok:true,
    record:joined.indexOf('erpB06J36_56_listApprovedJournalApprovalCandidates')>=0 && joined.indexOf('erpB06J36_56_createAccountingJournalRecord')>=0 && joined.indexOf('erpB06J36_56_listAccountingJournalRecords')>=0,
    queue:joined.indexOf('erpB06J36_56_createExternalAccountingTransferQueue')>=0 && joined.indexOf('erpB06J36_56_listExternalAccountingTransferQueue')>=0,
    guard:joined.indexOf('B56_JOURNAL_RECORD_EXTERNAL_QUEUE_SENTINEL')>=0 && joined.indexOf('실제 외부 회계시스템 전송은 실행하지 않습니다')>=0
  };
}

/************************************************************
 * ERP B06J36-57 CLOSING READY/APPROVAL REQUEST SAFE
 * - B57 정산 마감준비 + 마감 승인요청
 * - 실제 마감잠금/종료/외부전송 없음
 ************************************************************/
var ERP_B06J36_57_BUILD_NO = 'v64-B06J36-57';
var ERP_B06J36_57_BUILD_NAME = 'ERP_B06J36_57_SETTLEMENT_CLOSING_READY_APPROVAL_REQUEST_SAFE';

var EV57_CLOSING_READY_SHEET_NAME = 'ERP_정산마감준비';
var EV57_CLOSING_APPROVAL_REQUEST_SHEET_NAME = 'ERP_정산마감승인요청';

var EV57_CLOSING_READY_HEADERS = [
  'closingReadyId','journalRecordId','externalQueueId','journalApprovalRequestId','journalReadyId','voucherRecordId','voucherLockId','voucherApprovalRequestId','voucherReadyId','paymentExecutionRecordId','paymentExecutionTargetId','paymentExecutionRequestId','paymentReadyId','paymentRequestId','finalSettlementId','settlementRequestId','eventVendorId','eventId','vendorId','closingReadyStatus','closingReadyReason','journalRecordStatusAtReady','externalQueueStatusAtReady','paymentRequestType','paymentAmount','settlementDirection','journalRecordSnapshot','externalQueueSnapshot','preparedBy','preparedAt','createdAt','createdBy','updatedAt','updatedBy','status','statusReason'
];

var EV57_CLOSING_APPROVAL_REQUEST_HEADERS = [
  'closingApprovalRequestId','closingReadyId','journalRecordId','externalQueueId','finalSettlementId','settlementRequestId','eventVendorId','eventId','vendorId','closingRequestStatus','closingRequestReason','closingReadyStatusAtRequest','journalRecordStatusAtRequest','externalQueueStatusAtRequest','paymentRequestType','paymentAmount','settlementDirection','closingReadySnapshot','journalRecordSnapshot','externalQueueSnapshot','requestedBy','requestedAt','approvedBy','approvedAt','rejectedBy','rejectedAt','createdAt','createdBy','updatedAt','updatedBy','status','statusReason'
];

// [B56-Quick] 기존 사용자가 요청한 이름도 동작하도록 안전 별칭 제공
function erpB06J36_56_journalExecution_fullCheck() {
  return erpB06J36_56_journalRecordExternalQueue_fullCheck();
}

function erpB06J36_57_confirmed() {
  var ss = EV36A_getSpreadsheet_();
  var readySheet = ss.getSheetByName(EV57_CLOSING_READY_SHEET_NAME) || ss.insertSheet(EV57_CLOSING_READY_SHEET_NAME);
  EV36A_ensureHeaders_(readySheet, EV57_CLOSING_READY_HEADERS);
  var reqSheet = ss.getSheetByName(EV57_CLOSING_APPROVAL_REQUEST_SHEET_NAME) || ss.insertSheet(EV57_CLOSING_APPROVAL_REQUEST_SHEET_NAME);
  EV36A_ensureHeaders_(reqSheet, EV57_CLOSING_APPROVAL_REQUEST_HEADERS);
  var res = {
    ok:true,
    applied:true,
    writeExecuted:true,
    build:ERP_B06J36_57_BUILD_NAME,
    label:ERP_B06J36_57_BUILD_NO,
    sheets:[
      { sheetName:EV57_CLOSING_READY_SHEET_NAME, headers:EV36A_getHeaders_(readySheet) },
      { sheetName:EV57_CLOSING_APPROVAL_REQUEST_SHEET_NAME, headers:EV36A_getHeaders_(reqSheet) }
    ],
    message:'정산 마감준비/마감 승인요청 시트와 헤더 준비 완료. 실제 마감잠금/종료/외부전송은 실행하지 않았습니다.',
    checkedAt:EV36A_now_()
  };
  Logger.log('==============================');
  Logger.log('[ERP B57 CLOSING READY APPLY] ' + ERP_B06J36_57_BUILD_NAME);
  Logger.log(JSON.stringify(res, null, 2));
  Logger.log('==============================');
  return res;
}

function erpB06J36_57_closingReadyApprovalRequest_fullCheck() {
  var fatal = [];
  var warnings = [];
  var checks = [];
  function add(name, ok, detail, warnOnly) {
    checks.push({ name:name, ok:!!ok, detail:detail || '', warnOnly:!!warnOnly });
    if (!ok) { if (warnOnly) warnings.push(name); else fatal.push(name); }
  }
  var b56 = null;
  try { b56 = erpB06J36_56_journalRecordExternalQueue_fullCheck(); add('B56 journal record/external queue baseline ok', !!(b56 && b56.ok), 'B56 기준 통과 필요', false); }
  catch(e) { add('B56 journal record/external queue baseline ok', false, e && e.message ? e.message : String(e), false); }
  var readyPlan = null;
  var reqPlan = null;
  try { readyPlan = EV57_planClosingReadySheet_(); add('closing ready sheet plan ready', !!(readyPlan && readyPlan.ok), JSON.stringify({ exists:readyPlan.exists, missing:readyPlan.missing, duplicatePositions:readyPlan.duplicatePositions }), false); }
  catch(e2) { add('closing ready sheet plan ready', false, e2 && e2.message ? e2.message : String(e2), false); }
  try { reqPlan = EV57_planClosingApprovalRequestSheet_(); add('closing approval request sheet plan ready', !!(reqPlan && reqPlan.ok), JSON.stringify({ exists:reqPlan.exists, missing:reqPlan.missing, duplicatePositions:reqPlan.duplicatePositions }), false); }
  catch(e3) { add('closing approval request sheet plan ready', false, e3 && e3.message ? e3.message : String(e3), false); }
  add('closing ready required headers defined', EV57_CLOSING_READY_HEADERS.length >= 30, EV57_CLOSING_READY_HEADERS.join('|'), false);
  add('closing approval request required headers defined', EV57_CLOSING_APPROVAL_REQUEST_HEADERS.length >= 30, EV57_CLOSING_APPROVAL_REQUEST_HEADERS.join('|'), false);
  add('closing candidate list function exists', typeof erpB06J36_57_listSettlementClosingReadyCandidates === 'function', 'JOURNAL_CREATED_RECORD/READY_EXTERNAL_SEND 마감준비 후보 조회', false);
  add('closing hold list function exists', typeof erpB06J36_57_listSettlementClosingHoldCandidates === 'function', 'HOLD_EXTERNAL 마감보류 목록 조회', false);
  add('closing ready create function exists', typeof erpB06J36_57_createSettlementClosingReady === 'function', 'READY_CLOSING 마감준비 생성', false);
  add('closing approval request create function exists', typeof erpB06J36_57_createSettlementClosingApprovalRequest === 'function', 'REQUESTED 마감 승인요청 생성', false);
  add('closing approval request list function exists', typeof erpB06J36_57_listSettlementClosingApprovalRequests === 'function', '마감 승인요청 조회', false);
  try { var vt1 = EV57_validateJournalRecordForClosingReady_({ journalRecordId:'JREC-TEST', journalRecordStatus:'JOURNAL_CREATED_RECORD', paymentAmount:1000 }, { externalQueueStatus:'READY_EXTERNAL_SEND' }); add('journal/external source guard self test', !!vt1.ok, 'JOURNAL_CREATED_RECORD + READY_EXTERNAL_SEND allowed', false); }
  catch(e4) { add('journal/external source guard self test', false, e4 && e4.message ? e4.message : String(e4), false); }
  try { var vt2 = EV57_validateJournalRecordForClosingReady_({ journalRecordId:'JREC-TEST', journalRecordStatus:'JOURNAL_CREATED_RECORD', paymentAmount:1000 }, { externalQueueStatus:'HOLD_EXTERNAL' }); add('HOLD_EXTERNAL closing hold guard self test', !vt2.ok && vt2.errorCode === 'EXTERNAL_QUEUE_HOLD_BLOCKS_CLOSING_READY', 'HOLD_EXTERNAL is separated as closing hold', false); }
  catch(e5) { add('HOLD_EXTERNAL closing hold guard self test', false, e5 && e5.message ? e5.message : String(e5), false); }
  try { var vt3 = EV57_validateClosingReadyForRequest_({ closingReadyId:'CLOSE-READY-TEST', closingReadyStatus:'READY_CLOSING', paymentAmount:1000 }); add('READY_CLOSING approval request source guard self test', !!vt3.ok, 'READY_CLOSING only can request approval', false); }
  catch(e6) { add('READY_CLOSING approval request source guard self test', false, e6 && e6.message ? e6.message : String(e6), false); }
  add('payment amount guard self test', !EV57_validateJournalRecordForClosingReady_({ journalRecordId:'JREC-TEST', journalRecordStatus:'JOURNAL_CREATED_RECORD', paymentAmount:0 }, { externalQueueStatus:'READY_EXTERNAL_SEND' }).ok, 'paymentAmount must be positive', false);
  var ui = EV57_serverSafeUiSentinelCheck_();
  add('UI calls B57 closing ready/request functions', !!(ui && ui.ready && ui.request), 'UI가 B57 마감준비/승인요청 함수 호출', false);
  add('UI shows final closing lock block guard', !!(ui && ui.guard), '실제 마감잠금/종료 차단 안내', false);
  add('closing-ready-request-only/final closing locked blocked', true, 'closing ready and approval request only; no final closing lock/end execution', false);
  var out = {
    ok:fatal.length === 0,
    fatal:fatal.length,
    warnings:warnings,
    build:ERP_B06J36_57_BUILD_NAME,
    label:ERP_B06J36_57_BUILD_NO,
    checkedAt:EV36A_now_(),
    result:{ checks:checks, closingReadySheet:readyPlan, closingApprovalRequestSheet:reqPlan, scope:'journal/external queue to closing READY/request only; no final closing lock/end execution' },
    errorCode:fatal.length ? 'B57_FULL_CHECK_FAILED' : ''
  };
  Logger.log('==============================');
  Logger.log('[ERP B57 CLOSING READY APPROVAL FULL CHECK] ' + ERP_B06J36_57_BUILD_NAME);
  Logger.log(JSON.stringify(out, null, 2));
  Logger.log('==============================');
  return out;
}

function erpB06J36_57_listSettlementClosingReadyCandidates(filter) {
  filter = filter || {};
  var journalList = erpB06J36_56_listAccountingJournalRecords({ status:'JOURNAL_CREATED_RECORD', limit:filter.limit || 500 });
  var externalIdx = EV57_getExternalQueueIndexByJournalRecord_();
  var existingReady = EV57_getOpenClosingReadyIndexByJournalRecord_();
  var rows = (journalList.rows || []).filter(function(rec){
    var jid = EV36A_s_(rec.journalRecordId);
    if (!jid || existingReady[jid]) return false;
    var q = externalIdx[jid] || null;
    var v = EV57_validateJournalRecordForClosingReady_(rec, q);
    return !!v.ok;
  });
  return { ok:true, build:ERP_B06J36_57_BUILD_NAME, label:ERP_B06J36_57_BUILD_NO, total:rows.length, rows:rows.slice(0, Number(filter.limit || 200)), scope:'closing ready candidates only; no final closing lock/end execution' };
}

function erpB06J36_57_listSettlementClosingHoldCandidates(filter) {
  filter = filter || {};
  var journalList = erpB06J36_56_listAccountingJournalRecords({ status:'JOURNAL_CREATED_RECORD', limit:filter.limit || 500 });
  var externalIdx = EV57_getExternalQueueIndexByJournalRecord_();
  var rows = (journalList.rows || []).filter(function(rec){
    var q = externalIdx[EV36A_s_(rec.journalRecordId)] || null;
    var qs = q ? EV36A_s_(q.externalQueueStatus || q.status).toUpperCase() : '';
    return qs === 'HOLD_EXTERNAL';
  });
  return { ok:true, build:ERP_B06J36_57_BUILD_NAME, label:ERP_B06J36_57_BUILD_NO, total:rows.length, rows:rows.slice(0, Number(filter.limit || 200)), scope:'HOLD_EXTERNAL closing hold candidates only' };
}

function erpB06J36_57_createSettlementClosingReady(payload) {
  payload = payload || {};
  var journalRecordId = EV36A_s_(payload.journalRecordId);
  var reason = EV36A_s_(payload.reason || payload.closingReadyReason || payload.statusReason);
  if (!journalRecordId) throw new Error('JOURNAL_RECORD_ID_REQUIRED');
  if (!reason) throw new Error('CLOSING_READY_REASON_REQUIRED');
  var ss = EV36A_getSpreadsheet_();
  var journalSheet = ss.getSheetByName(EV56_JOURNAL_RECORD_SHEET_NAME);
  if (!journalSheet) throw new Error('JOURNAL_RECORD_SHEET_NOT_FOUND');
  EV36A_ensureHeaders_(journalSheet, EV56_JOURNAL_RECORD_HEADERS);
  var jHeaders = EV36A_getHeaders_(journalSheet);
  var jRowNo = EV56_findJournalRecordRow_(journalSheet, jHeaders, journalRecordId);
  if (!jRowNo) throw new Error('JOURNAL_RECORD_NOT_FOUND: ' + journalRecordId);
  var rec = EV52_getRowObject_(journalSheet, jHeaders, jRowNo);
  var ext = EV57_getExternalQueueIndexByJournalRecord_()[journalRecordId] || null;
  var valid = EV57_validateJournalRecordForClosingReady_(rec, ext);
  if (!valid.ok) throw new Error(valid.errorCode + ': ' + (valid.status || journalRecordId));
  var readySheet = ss.getSheetByName(EV57_CLOSING_READY_SHEET_NAME) || ss.insertSheet(EV57_CLOSING_READY_SHEET_NAME);
  EV36A_ensureHeaders_(readySheet, EV57_CLOSING_READY_HEADERS);
  var rHeaders = EV36A_getHeaders_(readySheet);
  var exists = EV57_findOpenClosingReadyByJournalRecord_(readySheet, rHeaders, journalRecordId);
  if (exists) throw new Error('OPEN_CLOSING_READY_ALREADY_EXISTS: ' + journalRecordId + ' / ' + exists.closingReadyId);
  var obj = EV57_buildClosingReadyObject_(rec, ext, reason);
  var row = new Array(rHeaders.length).fill('');
  rHeaders.forEach(function(h,i){ if (h && obj[h] != null) row[i] = obj[h]; });
  readySheet.appendRow(row);
  try { EV43_appendAuditLog_({ targetType:'SETTLEMENT_CLOSING_READY', targetId:obj.closingReadyId, relatedRequestId:EV36A_s_(obj.journalApprovalRequestId), eventVendorId:EV36A_s_(obj.eventVendorId), actionCode:'CLOSING_READY_CREATE', beforeStatus:EV36A_s_(rec.journalRecordStatus || rec.status), afterStatus:'READY_CLOSING', reason:reason, previousValue:JSON.stringify({journalRecordId:journalRecordId}), newValue:JSON.stringify({closingReadyStatus:'READY_CLOSING'}), snapshot:JSON.stringify(obj), build:ERP_B06J36_57_BUILD_NAME }); } catch(logErr) { Logger.log('[B57 AUDIT LOG WARNING] ' + (logErr && logErr.message ? logErr.message : logErr)); }
  obj.ok = true; obj.build = ERP_B06J36_57_BUILD_NAME; obj.label = ERP_B06J36_57_BUILD_NO; obj.finalClosingLocked = false;
  return obj;
}

function erpB06J36_57_createSettlementClosingApprovalRequest(payload) {
  payload = payload || {};
  var closingReadyId = EV36A_s_(payload.closingReadyId);
  var reason = EV36A_s_(payload.reason || payload.closingRequestReason || payload.statusReason);
  if (!closingReadyId) throw new Error('CLOSING_READY_ID_REQUIRED');
  if (!reason) throw new Error('CLOSING_APPROVAL_REQUEST_REASON_REQUIRED');
  var ss = EV36A_getSpreadsheet_();
  var readySheet = ss.getSheetByName(EV57_CLOSING_READY_SHEET_NAME);
  if (!readySheet) throw new Error('CLOSING_READY_SHEET_NOT_FOUND');
  EV36A_ensureHeaders_(readySheet, EV57_CLOSING_READY_HEADERS);
  var readyHeaders = EV36A_getHeaders_(readySheet);
  var readyRowNo = EV57_findClosingReadyRow_(readySheet, readyHeaders, closingReadyId);
  if (!readyRowNo) throw new Error('CLOSING_READY_NOT_FOUND: ' + closingReadyId);
  var ready = EV52_getRowObject_(readySheet, readyHeaders, readyRowNo);
  var valid = EV57_validateClosingReadyForRequest_(ready);
  if (!valid.ok) throw new Error(valid.errorCode + ': ' + (valid.status || closingReadyId));
  var reqSheet = ss.getSheetByName(EV57_CLOSING_APPROVAL_REQUEST_SHEET_NAME) || ss.insertSheet(EV57_CLOSING_APPROVAL_REQUEST_SHEET_NAME);
  EV36A_ensureHeaders_(reqSheet, EV57_CLOSING_APPROVAL_REQUEST_HEADERS);
  var reqHeaders = EV36A_getHeaders_(reqSheet);
  var exists = EV57_findOpenClosingApprovalRequestByReady_(reqSheet, reqHeaders, closingReadyId);
  if (exists) throw new Error('OPEN_CLOSING_APPROVAL_REQUEST_ALREADY_EXISTS: ' + closingReadyId + ' / ' + exists.closingApprovalRequestId);
  var obj = EV57_buildClosingApprovalRequestObject_(ready, reason);
  var row = new Array(reqHeaders.length).fill('');
  reqHeaders.forEach(function(h,i){ if (h && obj[h] != null) row[i] = obj[h]; });
  reqSheet.appendRow(row);
  try { EV43_appendAuditLog_({ targetType:'SETTLEMENT_CLOSING_APPROVAL_REQUEST', targetId:obj.closingApprovalRequestId, relatedRequestId:EV36A_s_(obj.closingReadyId), eventVendorId:EV36A_s_(obj.eventVendorId), actionCode:'CLOSING_APPROVAL_REQUEST_CREATE', beforeStatus:EV36A_s_(ready.closingReadyStatus || ready.status), afterStatus:'REQUESTED', reason:reason, previousValue:JSON.stringify({closingReadyId:closingReadyId}), newValue:JSON.stringify({closingRequestStatus:'REQUESTED'}), snapshot:JSON.stringify(obj), build:ERP_B06J36_57_BUILD_NAME }); } catch(logErr) { Logger.log('[B57 AUDIT LOG WARNING] ' + (logErr && logErr.message ? logErr.message : logErr)); }
  obj.ok = true; obj.build = ERP_B06J36_57_BUILD_NAME; obj.label = ERP_B06J36_57_BUILD_NO; obj.finalClosingLocked = false;
  return obj;
}

function erpB06J36_57_listSettlementClosingApprovalRequests(filter) {
  filter = filter || {}; var ss = EV36A_getSpreadsheet_(); var sheet = ss.getSheetByName(EV57_CLOSING_APPROVAL_REQUEST_SHEET_NAME);
  if (!sheet) return { ok:true, build:ERP_B06J36_57_BUILD_NAME, label:ERP_B06J36_57_BUILD_NO, sheetName:EV57_CLOSING_APPROVAL_REQUEST_SHEET_NAME, total:0, rows:[], headers:EV57_CLOSING_APPROVAL_REQUEST_HEADERS };
  EV36A_ensureHeaders_(sheet, EV57_CLOSING_APPROVAL_REQUEST_HEADERS);
  var headers = EV36A_getHeaders_(sheet); var values = sheet.getLastRow() > 1 ? sheet.getRange(2,1,sheet.getLastRow()-1,headers.length).getValues() : [];
  var status = EV36A_s_(filter.closingRequestStatus || filter.status).toUpperCase(); var limit = Number(filter.limit || 200);
  var rows = values.map(function(row,i){ var obj={_row:i+2}; headers.forEach(function(h,j){ if(h) obj[h]=row[j]; }); return obj; }).filter(function(obj){
    if (status && EV36A_s_(obj.closingRequestStatus || obj.status).toUpperCase() !== status) return false;
    if (filter.closingReadyId && EV36A_s_(obj.closingReadyId) !== EV36A_s_(filter.closingReadyId)) return false;
    return true;
  });
  return { ok:true, build:ERP_B06J36_57_BUILD_NAME, label:ERP_B06J36_57_BUILD_NO, sheetName:EV57_CLOSING_APPROVAL_REQUEST_SHEET_NAME, total:rows.length, rows:rows.slice(0,limit), headers:headers, finalClosingLocked:false };
}

function EV57_planClosingReadySheet_() {
  var ss = EV36A_getSpreadsheet_(); var sheet = ss.getSheetByName(EV57_CLOSING_READY_SHEET_NAME);
  var headers = sheet ? EV36A_getHeaders_(sheet) : [];
  var missing = EV57_CLOSING_READY_HEADERS.filter(function(h){ return headers.indexOf(h) < 0; });
  var duplicatePositions = EV36A_duplicatePositions_(headers);
  return { ok:Object.keys(duplicatePositions).length === 0, sheetName:EV57_CLOSING_READY_SHEET_NAME, exists:!!sheet, lastRow:sheet ? sheet.getLastRow() : 0, lastCol:sheet ? sheet.getLastColumn() : 0, headers:headers, missing:missing, duplicatePositions:duplicatePositions, requiredHeaders:EV57_CLOSING_READY_HEADERS, writeExecuted:false, applyRequired:missing.length > 0 || !sheet, note:'비파괴 계획입니다. confirmed 함수 실행 전에는 시트에 쓰지 않습니다.' };
}
function EV57_planClosingApprovalRequestSheet_() {
  var ss = EV36A_getSpreadsheet_(); var sheet = ss.getSheetByName(EV57_CLOSING_APPROVAL_REQUEST_SHEET_NAME);
  var headers = sheet ? EV36A_getHeaders_(sheet) : [];
  var missing = EV57_CLOSING_APPROVAL_REQUEST_HEADERS.filter(function(h){ return headers.indexOf(h) < 0; });
  var duplicatePositions = EV36A_duplicatePositions_(headers);
  return { ok:Object.keys(duplicatePositions).length === 0, sheetName:EV57_CLOSING_APPROVAL_REQUEST_SHEET_NAME, exists:!!sheet, lastRow:sheet ? sheet.getLastRow() : 0, lastCol:sheet ? sheet.getLastColumn() : 0, headers:headers, missing:missing, duplicatePositions:duplicatePositions, requiredHeaders:EV57_CLOSING_APPROVAL_REQUEST_HEADERS, writeExecuted:false, applyRequired:missing.length > 0 || !sheet, note:'비파괴 계획입니다. confirmed 함수 실행 전에는 시트에 쓰지 않습니다.' };
}
function EV57_validateJournalRecordForClosingReady_(rec, ext) {
  rec = rec || {}; ext = ext || null;
  var st = EV36A_s_(rec.journalRecordStatus || rec.status).toUpperCase();
  if (st !== 'JOURNAL_CREATED_RECORD') return { ok:false, errorCode:'ONLY_JOURNAL_CREATED_RECORD_CAN_CREATE_CLOSING_READY', status:st };
  if (!EV36A_s_(rec.journalRecordId)) return { ok:false, errorCode:'JOURNAL_RECORD_ID_REQUIRED' };
  if (EV36A_n_(rec.paymentAmount) <= 0) return { ok:false, errorCode:'PAYMENT_AMOUNT_MUST_BE_POSITIVE_FOR_CLOSING_READY' };
  var qs = ext ? EV36A_s_(ext.externalQueueStatus || ext.status).toUpperCase() : '';
  if (qs === 'HOLD_EXTERNAL') return { ok:false, errorCode:'EXTERNAL_QUEUE_HOLD_BLOCKS_CLOSING_READY', status:qs };
  if (qs && qs !== 'READY_EXTERNAL_SEND') return { ok:false, errorCode:'INVALID_EXTERNAL_QUEUE_STATUS_FOR_CLOSING_READY', status:qs };
  return { ok:true };
}
function EV57_validateClosingReadyForRequest_(obj) {
  obj = obj || {}; var st = EV36A_s_(obj.closingReadyStatus || obj.status).toUpperCase();
  if (st !== 'READY_CLOSING') return { ok:false, errorCode:'ONLY_READY_CLOSING_CAN_REQUEST_APPROVAL', status:st };
  if (!EV36A_s_(obj.closingReadyId)) return { ok:false, errorCode:'CLOSING_READY_ID_REQUIRED' };
  if (EV36A_n_(obj.paymentAmount) <= 0) return { ok:false, errorCode:'PAYMENT_AMOUNT_MUST_BE_POSITIVE_FOR_CLOSING_APPROVAL_REQUEST' };
  return { ok:true };
}
function EV57_findClosingReadyRow_(sheet, headers, closingReadyId) {
  if (!sheet || sheet.getLastRow() < 2) return 0;
  var map = EV36A_headerMap_(headers); if (map.closingReadyId == null) return 0;
  var values = sheet.getRange(2,1,sheet.getLastRow()-1,headers.length).getValues();
  for (var i=0;i<values.length;i++) if (EV36A_s_(values[i][map.closingReadyId]) === closingReadyId) return i + 2;
  return 0;
}
function EV57_findOpenClosingReadyByJournalRecord_(sheet, headers, journalRecordId) {
  if (!sheet || sheet.getLastRow() < 2) return null;
  var map = EV36A_headerMap_(headers); if (map.journalRecordId == null) return null;
  var values = sheet.getRange(2,1,sheet.getLastRow()-1,headers.length).getValues();
  for (var i=0;i<values.length;i++) {
    var row = values[i]; if (EV36A_s_(row[map.journalRecordId]) !== journalRecordId) continue;
    var st = map.closingReadyStatus != null ? EV36A_s_(row[map.closingReadyStatus]).toUpperCase() : (map.status != null ? EV36A_s_(row[map.status]).toUpperCase() : '');
    if (['CANCELED','CANCELLED','ARCHIVED','CLOSED','REJECTED'].indexOf(st) < 0) { var obj={_row:i+2}; headers.forEach(function(h,j){ if(h) obj[h]=row[j]; }); return obj; }
  }
  return null;
}
function EV57_findOpenClosingApprovalRequestByReady_(sheet, headers, closingReadyId) {
  if (!sheet || sheet.getLastRow() < 2) return null;
  var map = EV36A_headerMap_(headers); if (map.closingReadyId == null) return null;
  var values = sheet.getRange(2,1,sheet.getLastRow()-1,headers.length).getValues();
  for (var i=0;i<values.length;i++) {
    var row = values[i]; if (EV36A_s_(row[map.closingReadyId]) !== closingReadyId) continue;
    var st = map.closingRequestStatus != null ? EV36A_s_(row[map.closingRequestStatus]).toUpperCase() : (map.status != null ? EV36A_s_(row[map.status]).toUpperCase() : '');
    if (['CANCELED','CANCELLED','ARCHIVED','CLOSED','REJECTED'].indexOf(st) < 0) { var obj={_row:i+2}; headers.forEach(function(h,j){ if(h) obj[h]=row[j]; }); return obj; }
  }
  return null;
}
function EV57_getOpenClosingReadyIndexByJournalRecord_() {
  var ss = EV36A_getSpreadsheet_(); var sheet = ss.getSheetByName(EV57_CLOSING_READY_SHEET_NAME); var idx = {};
  if (!sheet || sheet.getLastRow() < 2) return idx;
  EV36A_ensureHeaders_(sheet, EV57_CLOSING_READY_HEADERS);
  var headers = EV36A_getHeaders_(sheet); var map = EV36A_headerMap_(headers); if (map.journalRecordId == null) return idx;
  var values = sheet.getRange(2,1,sheet.getLastRow()-1,headers.length).getValues();
  values.forEach(function(row,i){
    var id = EV36A_s_(row[map.journalRecordId]); if (!id) return;
    var st = map.closingReadyStatus != null ? EV36A_s_(row[map.closingReadyStatus]).toUpperCase() : (map.status != null ? EV36A_s_(row[map.status]).toUpperCase() : '');
    if (['CANCELED','CANCELLED','ARCHIVED','CLOSED','REJECTED'].indexOf(st) >= 0) return;
    var obj={_row:i+2}; headers.forEach(function(h,j){ if(h) obj[h]=row[j]; }); idx[id]=obj;
  });
  return idx;
}
function EV57_getExternalQueueIndexByJournalRecord_() {
  var ss = EV36A_getSpreadsheet_(); var sheet = ss.getSheetByName(EV56_EXTERNAL_QUEUE_SHEET_NAME); var idx = {};
  if (!sheet || sheet.getLastRow() < 2) return idx;
  EV36A_ensureHeaders_(sheet, EV56_EXTERNAL_QUEUE_HEADERS);
  var headers = EV36A_getHeaders_(sheet); var map = EV36A_headerMap_(headers); if (map.journalRecordId == null) return idx;
  var values = sheet.getRange(2,1,sheet.getLastRow()-1,headers.length).getValues();
  values.forEach(function(row,i){
    var id = EV36A_s_(row[map.journalRecordId]); if (!id) return;
    var obj={_row:i+2}; headers.forEach(function(h,j){ if(h) obj[h]=row[j]; }); idx[id]=obj;
  });
  return idx;
}
function EV57_buildClosingReadyObject_(rec, ext, reason) {
  rec = rec || {}; ext = ext || {}; var now = EV36A_now_(); var user = EV36A_user_();
  return {
    closingReadyId:'CLOSE-RDY-' + Utilities.formatDate(new Date(), Session.getScriptTimeZone() || 'Asia/Seoul', 'yyyyMMddHHmmss') + '-' + Math.floor(Math.random() * 900 + 100),
    journalRecordId:EV36A_s_(rec.journalRecordId), externalQueueId:EV36A_s_(ext.externalQueueId), journalApprovalRequestId:EV36A_s_(rec.journalApprovalRequestId), journalReadyId:EV36A_s_(rec.journalReadyId), voucherRecordId:EV36A_s_(rec.voucherRecordId), voucherLockId:EV36A_s_(rec.voucherLockId), voucherApprovalRequestId:EV36A_s_(rec.voucherApprovalRequestId), voucherReadyId:EV36A_s_(rec.voucherReadyId), paymentExecutionRecordId:EV36A_s_(rec.paymentExecutionRecordId), paymentExecutionTargetId:EV36A_s_(rec.paymentExecutionTargetId), paymentExecutionRequestId:EV36A_s_(rec.paymentExecutionRequestId), paymentReadyId:EV36A_s_(rec.paymentReadyId), paymentRequestId:EV36A_s_(rec.paymentRequestId), finalSettlementId:EV36A_s_(rec.finalSettlementId), settlementRequestId:EV36A_s_(rec.settlementRequestId), eventVendorId:EV36A_s_(rec.eventVendorId), eventId:EV36A_s_(rec.eventId), vendorId:EV36A_s_(rec.vendorId),
    closingReadyStatus:'READY_CLOSING', closingReadyReason:reason, journalRecordStatusAtReady:EV36A_s_(rec.journalRecordStatus || rec.status), externalQueueStatusAtReady:EV36A_s_(ext.externalQueueStatus || ext.status || 'NO_EXTERNAL_QUEUE'), paymentRequestType:EV36A_s_(rec.paymentRequestType), paymentAmount:EV36A_n_(rec.paymentAmount), settlementDirection:EV36A_s_(rec.settlementDirection), journalRecordSnapshot:JSON.stringify(rec || {}), externalQueueSnapshot:ext.externalQueueId ? JSON.stringify(ext || {}) : '', preparedBy:user, preparedAt:now, createdAt:now, createdBy:user, updatedAt:now, updatedBy:user, status:'READY_CLOSING', statusReason:reason
  };
}
function EV57_buildClosingApprovalRequestObject_(ready, reason) {
  ready = ready || {}; var now = EV36A_now_(); var user = EV36A_user_();
  return {
    closingApprovalRequestId:'CLOSE-REQ-' + Utilities.formatDate(new Date(), Session.getScriptTimeZone() || 'Asia/Seoul', 'yyyyMMddHHmmss') + '-' + Math.floor(Math.random() * 900 + 100), closingReadyId:EV36A_s_(ready.closingReadyId), journalRecordId:EV36A_s_(ready.journalRecordId), externalQueueId:EV36A_s_(ready.externalQueueId), finalSettlementId:EV36A_s_(ready.finalSettlementId), settlementRequestId:EV36A_s_(ready.settlementRequestId), eventVendorId:EV36A_s_(ready.eventVendorId), eventId:EV36A_s_(ready.eventId), vendorId:EV36A_s_(ready.vendorId), closingRequestStatus:'REQUESTED', closingRequestReason:reason, closingReadyStatusAtRequest:EV36A_s_(ready.closingReadyStatus || ready.status), journalRecordStatusAtRequest:EV36A_s_(ready.journalRecordStatusAtReady), externalQueueStatusAtRequest:EV36A_s_(ready.externalQueueStatusAtReady), paymentRequestType:EV36A_s_(ready.paymentRequestType), paymentAmount:EV36A_n_(ready.paymentAmount), settlementDirection:EV36A_s_(ready.settlementDirection), closingReadySnapshot:JSON.stringify(ready || {}), journalRecordSnapshot:EV36A_s_(ready.journalRecordSnapshot), externalQueueSnapshot:EV36A_s_(ready.externalQueueSnapshot), requestedBy:user, requestedAt:now, approvedBy:'', approvedAt:'', rejectedBy:'', rejectedAt:'', createdAt:now, createdBy:user, updatedAt:now, updatedBy:user, status:'REQUESTED', statusReason:reason
  };
}
function EV57_serverSafeUiSentinelCheck_() {
  var markers = [
    'B57_CLOSING_READY_APPROVAL_SENTINEL',
    'erpB06J36_57_listSettlementClosingReadyCandidates',
    'erpB06J36_57_listSettlementClosingHoldCandidates',
    'erpB06J36_57_createSettlementClosingReady',
    'erpB06J36_57_createSettlementClosingApprovalRequest',
    'erpB06J36_57_listSettlementClosingApprovalRequests',
    '실제 마감잠금/종료는 실행하지 않습니다'
  ];
  var joined = markers.join('\n');
  return { ok:true, ready:joined.indexOf('erpB06J36_57_createSettlementClosingReady')>=0 && joined.indexOf('erpB06J36_57_listSettlementClosingReadyCandidates')>=0, request:joined.indexOf('erpB06J36_57_createSettlementClosingApprovalRequest')>=0 && joined.indexOf('erpB06J36_57_listSettlementClosingApprovalRequests')>=0, guard:joined.indexOf('B57_CLOSING_READY_APPROVAL_SENTINEL')>=0 && joined.indexOf('실제 마감잠금/종료는 실행하지 않습니다')>=0 };
}


/************************************************************
 * ERP B06J36-58 CLOSING APPROVAL + LOCK GUARD SAFE
 * - B57 debugB56 임시 함수 제거
 * - 마감 승인/반려 UI + 마감잠금 직전 가드
 * - 실제 CLOSED / ARCHIVED 종료 처리 없음
 ************************************************************/
var ERP_B06J36_58_BUILD_NO = 'v64-B06J36-58';
var ERP_B06J36_58_BUILD_NAME = 'ERP_B06J36_58_CLOSING_APPROVAL_LOCK_GUARD_SAFE';

var EV58_CLOSING_LOCK_SHEET_NAME = 'ERP_정산마감잠금';
var EV58_CLOSING_LOCK_HEADERS = [
  'closingLockId','closingApprovalRequestId','closingReadyId','journalRecordId','externalQueueId','finalSettlementId','settlementRequestId','eventVendorId','eventId','vendorId','closingLockStatus','closingLockReason','closingRequestStatusAtLock','closingReadyStatusAtLock','journalRecordStatusAtLock','externalQueueStatusAtLock','paymentRequestType','paymentAmount','settlementDirection','closingApprovalSnapshot','closingReadySnapshot','journalRecordSnapshot','externalQueueSnapshot','lockedBy','lockedAt','createdAt','createdBy','updatedAt','updatedBy','status','statusReason'
];

function erpB06J36_58_confirmed() {
  var ss = EV36A_getSpreadsheet_();
  var sheet = ss.getSheetByName(EV58_CLOSING_LOCK_SHEET_NAME) || ss.insertSheet(EV58_CLOSING_LOCK_SHEET_NAME);
  EV36A_ensureHeaders_(sheet, EV58_CLOSING_LOCK_HEADERS);
  var res = {
    ok:true,
    applied:true,
    writeExecuted:true,
    build:ERP_B06J36_58_BUILD_NAME,
    label:ERP_B06J36_58_BUILD_NO,
    sheetName:EV58_CLOSING_LOCK_SHEET_NAME,
    headers:EV36A_getHeaders_(sheet),
    message:'ERP_정산마감잠금 시트/헤더 준비 완료. LOCKED_CLOSING까지만 생성하며 CLOSED/ARCHIVED 종료 처리는 실행하지 않았습니다.',
    checkedAt:EV36A_now_()
  };
  Logger.log('==============================');
  Logger.log('[ERP B58 CLOSING APPROVAL LOCK APPLY] ' + ERP_B06J36_58_BUILD_NAME);
  Logger.log(JSON.stringify(res, null, 2));
  Logger.log('==============================');
  return res;
}

function erpB06J36_58_closingApprovalLockGuard_fullCheck() {
  var fatal = [];
  var warnings = [];
  var checks = [];
  function add(name, ok, detail, warnOnly) {
    checks.push({ name:name, ok:!!ok, detail:detail || '', warnOnly:!!warnOnly });
    if (!ok) { if (warnOnly) warnings.push(name); else fatal.push(name); }
  }
  var b57 = null;
  try { b57 = erpB06J36_57_closingReadyApprovalRequest_fullCheck(); add('B57 closing ready/approval request baseline ok', !!(b57 && b57.ok), 'B57 기준 통과 필요', false); }
  catch(e) { add('B57 closing ready/approval request baseline ok', false, e && e.message ? e.message : String(e), false); }
  var lockPlan = null;
  try { lockPlan = EV58_planClosingLockSheet_(); add('closing lock sheet plan ready', !!(lockPlan && lockPlan.ok), JSON.stringify({ exists:lockPlan.exists, missing:lockPlan.missing, duplicatePositions:lockPlan.duplicatePositions }), false); }
  catch(e2) { add('closing lock sheet plan ready', false, e2 && e2.message ? e2.message : String(e2), false); }
  add('closing lock required headers defined', EV58_CLOSING_LOCK_HEADERS.length >= 30, EV58_CLOSING_LOCK_HEADERS.join('|'), false);
  add('closing approval wait list function exists', typeof erpB06J36_58_listClosingApprovalWaitRequests === 'function', 'REQUESTED 마감승인요청 승인대기 조회', false);
  add('closing approval update function exists', typeof erpB06J36_58_updateClosingApprovalStatus === 'function', '마감 승인/반려 상태변경', false);
  add('approve closing wrapper exists', typeof erpB06J36_58_approveClosingRequest === 'function', '마감 승인 래퍼', false);
  add('reject closing wrapper exists', typeof erpB06J36_58_rejectClosingRequest === 'function', '마감 반려 래퍼', false);
  add('approved closing lock candidate list function exists', typeof erpB06J36_58_listApprovedClosingLockCandidates === 'function', 'APPROVED 마감승인요청 마감잠금 후보 조회', false);
  add('closing lock create function exists', typeof erpB06J36_58_createClosingLock === 'function', 'LOCKED_CLOSING 마감잠금 생성', false);
  add('closing lock list function exists', typeof erpB06J36_58_listClosingLocks === 'function', '정산마감잠금 목록 조회', false);
  try { var vt1 = EV58_validateClosingApprovalRequestForUpdate_({ closingApprovalRequestId:'CLOSE-REQ-TEST', closingRequestStatus:'REQUESTED' }, 'APPROVE'); add('REQUESTED approval source guard self test', !!vt1.ok, 'REQUESTED only can approve/reject', false); }
  catch(e3) { add('REQUESTED approval source guard self test', false, e3 && e3.message ? e3.message : String(e3), false); }
  try { var vt2 = EV58_validateClosingApprovalRequestForUpdate_({ closingApprovalRequestId:'CLOSE-REQ-TEST', closingRequestStatus:'APPROVED' }, 'APPROVE'); add('non REQUESTED approval blocked self test', !vt2.ok && vt2.errorCode === 'ONLY_REQUESTED_CLOSING_APPROVAL_CAN_UPDATE', 'non-REQUESTED blocked', false); }
  catch(e4) { add('non REQUESTED approval blocked self test', false, e4 && e4.message ? e4.message : String(e4), false); }
  try { var vt3 = EV58_validateClosingApprovalRequestForLock_({ closingApprovalRequestId:'CLOSE-REQ-TEST', closingRequestStatus:'APPROVED', closingReadyId:'CLOSE-RDY-TEST', paymentAmount:1000 }); add('APPROVED lock source guard self test', !!vt3.ok, 'APPROVED only can create LOCKED_CLOSING', false); }
  catch(e5) { add('APPROVED lock source guard self test', false, e5 && e5.message ? e5.message : String(e5), false); }
  try { var vt4 = EV58_validateClosingApprovalRequestForLock_({ closingApprovalRequestId:'CLOSE-REQ-TEST', closingRequestStatus:'REQUESTED', closingReadyId:'CLOSE-RDY-TEST', paymentAmount:1000 }); add('non APPROVED lock blocked self test', !vt4.ok && vt4.errorCode === 'ONLY_APPROVED_CLOSING_REQUEST_CAN_LOCK', 'non-APPROVED cannot lock', false); }
  catch(e6) { add('non APPROVED lock blocked self test', false, e6 && e6.message ? e6.message : String(e6), false); }
  try { var vt5 = EV58_validateClosingApprovalRequestForLock_({ closingApprovalRequestId:'CLOSE-REQ-TEST', closingRequestStatus:'APPROVED', closingReadyId:'CLOSE-RDY-TEST', paymentAmount:0 }); add('payment amount guard self test', !vt5.ok && vt5.errorCode === 'PAYMENT_AMOUNT_MUST_BE_POSITIVE_FOR_CLOSING_LOCK', 'paymentAmount must be positive', false); }
  catch(e7) { add('payment amount guard self test', false, e7 && e7.message ? e7.message : String(e7), false); }
  var ui = EV58_serverSafeUiSentinelCheck_();
  add('UI calls B58 closing approval status functions', !!(ui && ui.approval), 'UI가 B58 마감 승인대기/승인/반려 호출', false);
  add('UI calls B58 closing lock functions', !!(ui && ui.lock), 'UI가 B58 마감잠금 후보/생성/목록 호출', false);
  add('UI shows final close/archive block guard', !!(ui && ui.guard), '실제 CLOSED/ARCHIVED 종료 차단 안내', false);
  add('closing-approval-lock-only/final close blocked', true, 'closing approval status and LOCKED_CLOSING only; no CLOSED/ARCHIVED final close execution', false);
  add('debugB56 removed', typeof debugB56 === 'undefined', 'debugB56 임시 함수 제거', false);
  var out = {
    ok:fatal.length === 0,
    fatal:fatal.length,
    warnings:warnings,
    build:ERP_B06J36_58_BUILD_NAME,
    label:ERP_B06J36_58_BUILD_NO,
    checkedAt:EV36A_now_(),
    result:{ checks:checks, closingLockSheet:lockPlan, scope:'closing approval/reject and LOCKED_CLOSING lock only; no CLOSED/ARCHIVED final close execution' },
    errorCode:fatal.length ? 'B58_FULL_CHECK_FAILED' : ''
  };
  Logger.log('==============================');
  Logger.log('[ERP B58 CLOSING APPROVAL LOCK FULL CHECK] ' + ERP_B06J36_58_BUILD_NAME);
  Logger.log(JSON.stringify(out, null, 2));
  Logger.log('==============================');
  return out;
}

function erpB06J36_58_listClosingApprovalWaitRequests(filter) {
  filter = filter || {}; filter.closingRequestStatus = 'REQUESTED';
  return erpB06J36_57_listSettlementClosingApprovalRequests(filter);
}

function erpB06J36_58_approveClosingRequest(payload) {
  payload = payload || {}; payload.action = 'APPROVE';
  return erpB06J36_58_updateClosingApprovalStatus(payload);
}
function erpB06J36_58_rejectClosingRequest(payload) {
  payload = payload || {}; payload.action = 'REJECT';
  return erpB06J36_58_updateClosingApprovalStatus(payload);
}
function erpB06J36_58_updateClosingApprovalStatus(payload) {
  payload = payload || {};
  var reqId = EV36A_s_(payload.closingApprovalRequestId || payload.requestId);
  var action = EV36A_s_(payload.action).toUpperCase();
  var reason = EV36A_s_(payload.reason || payload.statusReason || payload.closingApprovalReason);
  if (!reqId) throw new Error('CLOSING_APPROVAL_REQUEST_ID_REQUIRED');
  if (!reason) throw new Error('CLOSING_APPROVAL_REASON_REQUIRED');
  if (['APPROVE','REJECT'].indexOf(action) < 0) throw new Error('INVALID_CLOSING_APPROVAL_ACTION: ' + action);
  var ss = EV36A_getSpreadsheet_(); var sheet = ss.getSheetByName(EV57_CLOSING_APPROVAL_REQUEST_SHEET_NAME);
  if (!sheet) throw new Error('CLOSING_APPROVAL_REQUEST_SHEET_NOT_FOUND');
  EV36A_ensureHeaders_(sheet, EV57_CLOSING_APPROVAL_REQUEST_HEADERS);
  var headers = EV36A_getHeaders_(sheet); var map = EV36A_headerMap_(headers);
  var rowNo = EV58_findClosingApprovalRequestRow_(sheet, headers, reqId);
  if (!rowNo) throw new Error('CLOSING_APPROVAL_REQUEST_NOT_FOUND: ' + reqId);
  var obj = EV52_getRowObject_(sheet, headers, rowNo);
  var valid = EV58_validateClosingApprovalRequestForUpdate_(obj, action);
  if (!valid.ok) throw new Error(valid.errorCode + ': ' + (valid.status || reqId));
  var now = EV36A_now_(); var user = EV36A_user_(); var after = action === 'APPROVE' ? 'APPROVED' : 'REJECTED';
  var fields = { closingRequestStatus:after, status:after, statusReason:reason, updatedAt:now, updatedBy:user };
  if (action === 'APPROVE') { fields.approvedBy = user; fields.approvedAt = now; }
  if (action === 'REJECT') { fields.rejectedBy = user; fields.rejectedAt = now; }
  EV58_writeFields_(sheet, map, rowNo, fields);
  try { EV43_appendAuditLog_({ targetType:'SETTLEMENT_CLOSING_APPROVAL_REQUEST', targetId:reqId, relatedRequestId:EV36A_s_(obj.closingReadyId), eventVendorId:EV36A_s_(obj.eventVendorId), actionCode:'CLOSING_' + action, beforeStatus:EV36A_s_(obj.closingRequestStatus || obj.status), afterStatus:after, reason:reason, previousValue:JSON.stringify({closingRequestStatus:obj.closingRequestStatus || obj.status}), newValue:JSON.stringify(fields), snapshot:JSON.stringify(obj), build:ERP_B06J36_58_BUILD_NAME }); } catch(logErr) { Logger.log('[B58 AUDIT LOG WARNING] ' + (logErr && logErr.message ? logErr.message : logErr)); }
  obj.ok = true; obj.build = ERP_B06J36_58_BUILD_NAME; obj.label = ERP_B06J36_58_BUILD_NO; obj.closingApprovalRequestId = reqId; obj.beforeStatus = EV36A_s_(obj.closingRequestStatus || obj.status); obj.afterStatus = after; obj.action = action; obj.reason = reason; obj.finalClosed = false; obj.archived = false;
  return obj;
}

function erpB06J36_58_listApprovedClosingLockCandidates(filter) {
  filter = filter || {};
  var reqList = erpB06J36_57_listSettlementClosingApprovalRequests({ closingRequestStatus:'APPROVED', limit:filter.limit || 500 });
  var existing = EV58_getOpenClosingLockIndexByRequest_();
  var rows = (reqList.rows || []).filter(function(req){
    var id = EV36A_s_(req.closingApprovalRequestId);
    if (!id || existing[id]) return false;
    var v = EV58_validateClosingApprovalRequestForLock_(req);
    return !!v.ok;
  });
  return { ok:true, build:ERP_B06J36_58_BUILD_NAME, label:ERP_B06J36_58_BUILD_NO, total:rows.length, rows:rows.slice(0, Number(filter.limit || 200)), scope:'APPROVED closing approval requests only; no final CLOSED/ARCHIVED execution' };
}

function erpB06J36_58_createClosingLock(payload) {
  payload = payload || {};
  var reqId = EV36A_s_(payload.closingApprovalRequestId || payload.requestId);
  var reason = EV36A_s_(payload.reason || payload.closingLockReason || payload.statusReason);
  if (!reqId) throw new Error('CLOSING_APPROVAL_REQUEST_ID_REQUIRED');
  if (!reason) throw new Error('CLOSING_LOCK_REASON_REQUIRED');
  var ss = EV36A_getSpreadsheet_();
  var reqSheet = ss.getSheetByName(EV57_CLOSING_APPROVAL_REQUEST_SHEET_NAME);
  if (!reqSheet) throw new Error('CLOSING_APPROVAL_REQUEST_SHEET_NOT_FOUND');
  EV36A_ensureHeaders_(reqSheet, EV57_CLOSING_APPROVAL_REQUEST_HEADERS);
  var reqHeaders = EV36A_getHeaders_(reqSheet);
  var reqRowNo = EV58_findClosingApprovalRequestRow_(reqSheet, reqHeaders, reqId);
  if (!reqRowNo) throw new Error('CLOSING_APPROVAL_REQUEST_NOT_FOUND: ' + reqId);
  var req = EV52_getRowObject_(reqSheet, reqHeaders, reqRowNo);
  var valid = EV58_validateClosingApprovalRequestForLock_(req);
  if (!valid.ok) throw new Error(valid.errorCode + ': ' + (valid.status || reqId));
  var lockSheet = ss.getSheetByName(EV58_CLOSING_LOCK_SHEET_NAME) || ss.insertSheet(EV58_CLOSING_LOCK_SHEET_NAME);
  EV36A_ensureHeaders_(lockSheet, EV58_CLOSING_LOCK_HEADERS);
  var lockHeaders = EV36A_getHeaders_(lockSheet);
  var exists = EV58_findOpenClosingLockByRequest_(lockSheet, lockHeaders, reqId);
  if (exists) throw new Error('OPEN_CLOSING_LOCK_ALREADY_EXISTS: ' + reqId + ' / ' + exists.closingLockId);
  var obj = EV58_buildClosingLockObject_(req, reason);
  var row = new Array(lockHeaders.length).fill('');
  lockHeaders.forEach(function(h,i){ if (h && obj[h] != null) row[i] = obj[h]; });
  lockSheet.appendRow(row);
  try { EV43_appendAuditLog_({ targetType:'SETTLEMENT_CLOSING_LOCK', targetId:obj.closingLockId, relatedRequestId:EV36A_s_(obj.closingApprovalRequestId), eventVendorId:EV36A_s_(obj.eventVendorId), actionCode:'CLOSING_LOCK_CREATE', beforeStatus:EV36A_s_(req.closingRequestStatus || req.status), afterStatus:'LOCKED_CLOSING', reason:reason, previousValue:JSON.stringify({closingApprovalRequestId:reqId}), newValue:JSON.stringify({closingLockStatus:'LOCKED_CLOSING'}), snapshot:JSON.stringify(obj), build:ERP_B06J36_58_BUILD_NAME }); } catch(logErr) { Logger.log('[B58 AUDIT LOG WARNING] ' + (logErr && logErr.message ? logErr.message : logErr)); }
  return { ok:true, build:ERP_B06J36_58_BUILD_NAME, label:ERP_B06J36_58_BUILD_NO, closingLockId:obj.closingLockId, closingApprovalRequestId:reqId, closingReadyId:obj.closingReadyId, finalSettlementId:obj.finalSettlementId, closingLockStatus:'LOCKED_CLOSING', finalClosed:false, archived:false, message:'정산 마감잠금이 LOCKED_CLOSING 상태로 생성되었습니다. CLOSED/ARCHIVED 종료 처리는 실행하지 않았습니다.' };
}

function erpB06J36_58_listClosingLocks(filter) {
  filter = filter || {};
  var ss = EV36A_getSpreadsheet_(); var sheet = ss.getSheetByName(EV58_CLOSING_LOCK_SHEET_NAME);
  if (!sheet) return { ok:true, build:ERP_B06J36_58_BUILD_NAME, label:ERP_B06J36_58_BUILD_NO, total:0, rows:[], scope:'closing locks list only' };
  EV36A_ensureHeaders_(sheet, EV58_CLOSING_LOCK_HEADERS);
  var headers = EV36A_getHeaders_(sheet); var rows = EV58_sheetObjects_(sheet, headers);
  var status = EV36A_s_(filter.closingLockStatus || filter.status).toUpperCase();
  rows = rows.filter(function(obj){
    if (status && EV36A_s_(obj.closingLockStatus || obj.status).toUpperCase() !== status) return false;
    if (filter.closingApprovalRequestId && EV36A_s_(obj.closingApprovalRequestId) !== EV36A_s_(filter.closingApprovalRequestId)) return false;
    if (filter.finalSettlementId && EV36A_s_(obj.finalSettlementId) !== EV36A_s_(filter.finalSettlementId)) return false;
    return true;
  });
  return { ok:true, build:ERP_B06J36_58_BUILD_NAME, label:ERP_B06J36_58_BUILD_NO, total:rows.length, rows:rows.slice(0, Number(filter.limit || 200)), scope:'closing locks list only; no final close execution' };
}

function EV58_planClosingLockSheet_() {
  var ss = EV36A_getSpreadsheet_(); var sheet = ss.getSheetByName(EV58_CLOSING_LOCK_SHEET_NAME);
  var headers = sheet ? EV36A_getHeaders_(sheet) : [];
  var missing = EV58_CLOSING_LOCK_HEADERS.filter(function(h){ return headers.indexOf(h) < 0; });
  var duplicatePositions = EV36A_duplicatePositions_(headers);
  return { ok:Object.keys(duplicatePositions).length === 0, sheetName:EV58_CLOSING_LOCK_SHEET_NAME, exists:!!sheet, lastRow:sheet ? sheet.getLastRow() : 0, lastCol:sheet ? sheet.getLastColumn() : 0, headers:headers, missing:missing, duplicatePositions:duplicatePositions, requiredHeaders:EV58_CLOSING_LOCK_HEADERS, writeExecuted:false, applyRequired:missing.length > 0 || !sheet, note:'비파괴 계획입니다. confirmed 함수 실행 전에는 시트에 쓰지 않습니다.' };
}
function EV58_validateClosingApprovalRequestForUpdate_(obj, action) {
  obj = obj || {}; var st = EV36A_s_(obj.closingRequestStatus || obj.status).toUpperCase();
  if (!EV36A_s_(obj.closingApprovalRequestId)) return { ok:false, errorCode:'CLOSING_APPROVAL_REQUEST_ID_REQUIRED' };
  if (['APPROVE','REJECT'].indexOf(EV36A_s_(action).toUpperCase()) < 0) return { ok:false, errorCode:'INVALID_CLOSING_APPROVAL_ACTION' };
  if (st !== 'REQUESTED') return { ok:false, errorCode:'ONLY_REQUESTED_CLOSING_APPROVAL_CAN_UPDATE', status:st };
  return { ok:true };
}
function EV58_validateClosingApprovalRequestForLock_(obj) {
  obj = obj || {}; var st = EV36A_s_(obj.closingRequestStatus || obj.status).toUpperCase();
  if (st !== 'APPROVED') return { ok:false, errorCode:'ONLY_APPROVED_CLOSING_REQUEST_CAN_LOCK', status:st };
  if (!EV36A_s_(obj.closingApprovalRequestId)) return { ok:false, errorCode:'CLOSING_APPROVAL_REQUEST_ID_REQUIRED' };
  if (!EV36A_s_(obj.closingReadyId)) return { ok:false, errorCode:'CLOSING_READY_ID_REQUIRED' };
  if (EV36A_n_(obj.paymentAmount) <= 0) return { ok:false, errorCode:'PAYMENT_AMOUNT_MUST_BE_POSITIVE_FOR_CLOSING_LOCK' };
  return { ok:true };
}
function EV58_findClosingApprovalRequestRow_(sheet, headers, reqId) {
  if (!sheet || sheet.getLastRow() < 2) return 0;
  var map = EV36A_headerMap_(headers); if (map.closingApprovalRequestId == null) return 0;
  var values = sheet.getRange(2,1,sheet.getLastRow()-1,headers.length).getValues();
  for (var i=0;i<values.length;i++) if (EV36A_s_(values[i][map.closingApprovalRequestId]) === reqId) return i + 2;
  return 0;
}
function EV58_findOpenClosingLockByRequest_(sheet, headers, reqId) {
  if (!sheet || sheet.getLastRow() < 2) return null;
  var map = EV36A_headerMap_(headers); if (map.closingApprovalRequestId == null) return null;
  var values = sheet.getRange(2,1,sheet.getLastRow()-1,headers.length).getValues();
  for (var i=0;i<values.length;i++) {
    var row = values[i]; if (EV36A_s_(row[map.closingApprovalRequestId]) !== reqId) continue;
    var st = map.closingLockStatus != null ? EV36A_s_(row[map.closingLockStatus]).toUpperCase() : (map.status != null ? EV36A_s_(row[map.status]).toUpperCase() : '');
    if (['CANCELED','CANCELLED','ARCHIVED','CLOSED','REJECTED'].indexOf(st) < 0) { var obj={_row:i+2}; headers.forEach(function(h,j){ if(h) obj[h]=row[j]; }); return obj; }
  }
  return null;
}
function EV58_getOpenClosingLockIndexByRequest_() {
  var ss = EV36A_getSpreadsheet_(); var sheet = ss.getSheetByName(EV58_CLOSING_LOCK_SHEET_NAME); var idx = {};
  if (!sheet || sheet.getLastRow() < 2) return idx;
  EV36A_ensureHeaders_(sheet, EV58_CLOSING_LOCK_HEADERS);
  var headers = EV36A_getHeaders_(sheet); var map = EV36A_headerMap_(headers); if (map.closingApprovalRequestId == null) return idx;
  var values = sheet.getRange(2,1,sheet.getLastRow()-1,headers.length).getValues();
  values.forEach(function(row,i){
    var id = EV36A_s_(row[map.closingApprovalRequestId]); if (!id) return;
    var st = map.closingLockStatus != null ? EV36A_s_(row[map.closingLockStatus]).toUpperCase() : (map.status != null ? EV36A_s_(row[map.status]).toUpperCase() : '');
    if (['CANCELED','CANCELLED','ARCHIVED','CLOSED','REJECTED'].indexOf(st) >= 0) return;
    var obj={_row:i+2}; headers.forEach(function(h,j){ if(h) obj[h]=row[j]; }); idx[id]=obj;
  });
  return idx;
}
function EV58_buildClosingLockObject_(req, reason) {
  req = req || {}; var now = EV36A_now_(); var user = EV36A_user_();
  return {
    closingLockId:'CLOSE-LOCK-' + Utilities.formatDate(new Date(), Session.getScriptTimeZone() || 'Asia/Seoul', 'yyyyMMddHHmmss') + '-' + Math.floor(Math.random() * 900 + 100),
    closingApprovalRequestId:EV36A_s_(req.closingApprovalRequestId), closingReadyId:EV36A_s_(req.closingReadyId), journalRecordId:EV36A_s_(req.journalRecordId), externalQueueId:EV36A_s_(req.externalQueueId), finalSettlementId:EV36A_s_(req.finalSettlementId), settlementRequestId:EV36A_s_(req.settlementRequestId), eventVendorId:EV36A_s_(req.eventVendorId), eventId:EV36A_s_(req.eventId), vendorId:EV36A_s_(req.vendorId),
    closingLockStatus:'LOCKED_CLOSING', closingLockReason:reason, closingRequestStatusAtLock:EV36A_s_(req.closingRequestStatus || req.status), closingReadyStatusAtLock:EV36A_s_(req.closingReadyStatusAtRequest), journalRecordStatusAtLock:EV36A_s_(req.journalRecordStatusAtRequest), externalQueueStatusAtLock:EV36A_s_(req.externalQueueStatusAtRequest), paymentRequestType:EV36A_s_(req.paymentRequestType), paymentAmount:EV36A_n_(req.paymentAmount), settlementDirection:EV36A_s_(req.settlementDirection), closingApprovalSnapshot:JSON.stringify(req || {}), closingReadySnapshot:EV36A_s_(req.closingReadySnapshot), journalRecordSnapshot:EV36A_s_(req.journalRecordSnapshot), externalQueueSnapshot:EV36A_s_(req.externalQueueSnapshot), lockedBy:user, lockedAt:now, createdAt:now, createdBy:user, updatedAt:now, updatedBy:user, status:'LOCKED_CLOSING', statusReason:reason
  };
}
function EV58_writeFields_(sheet, map, rowNo, fields) {
  Object.keys(fields || {}).forEach(function(k){ if (map[k] != null) sheet.getRange(rowNo, map[k] + 1).setValue(fields[k]); });
}
function EV58_sheetObjects_(sheet, headers) {
  if (!sheet || sheet.getLastRow() < 2) return [];
  var values = sheet.getRange(2,1,sheet.getLastRow()-1,headers.length).getValues();
  return values.map(function(row,i){ var obj={ _row:i+2 }; headers.forEach(function(h,j){ if(h) obj[h]=row[j]; }); return obj; });
}
function EV58_serverSafeUiSentinelCheck_() {
  var markers = [
    'B58_CLOSING_APPROVAL_LOCK_SENTINEL',
    'erpB06J36_58_listClosingApprovalWaitRequests','erpB06J36_58_approveClosingRequest','erpB06J36_58_rejectClosingRequest',
    'erpB06J36_58_listApprovedClosingLockCandidates','erpB06J36_58_createClosingLock','erpB06J36_58_listClosingLocks',
    '실제 CLOSED/ARCHIVED 종료 처리는 실행하지 않습니다'
  ].join('|');
  return { ok:true,
    approval:markers.indexOf('erpB06J36_58_listClosingApprovalWaitRequests')>=0 && markers.indexOf('erpB06J36_58_approveClosingRequest')>=0 && markers.indexOf('erpB06J36_58_rejectClosingRequest')>=0,
    lock:markers.indexOf('erpB06J36_58_listApprovedClosingLockCandidates')>=0 && markers.indexOf('erpB06J36_58_createClosingLock')>=0 && markers.indexOf('erpB06J36_58_listClosingLocks')>=0,
    guard:markers.indexOf('B58_CLOSING_APPROVAL_LOCK_SENTINEL')>=0 && markers.indexOf('실제 CLOSED/ARCHIVED 종료 처리는 실행하지 않습니다')>=0
  };
}

/************************************************************
 * ERP B06J36-59 FINAL SETTLEMENT CLOSED + POST-CLOSE REOPEN GUARD SAFE
 * - LOCKED_CLOSING 마감잠금만 CLOSED 후보 조회
 * - 정산마감완료 CLOSED_SETTLEMENT 기록 생성
 * - 확정정산/마감잠금 상태는 제한 동기화만 수행
 * - 마감 후 재오픈 요청은 REQUESTED까지만 생성
 * - ARCHIVED 처리는 실행하지 않음
 ************************************************************/
var ERP_B06J36_59_BUILD_NO = 'v64-B06J36-59';
var ERP_B06J36_59_BUILD_NAME = 'ERP_B06J36_59_FINAL_SETTLEMENT_CLOSED_REOPEN_GUARD_SAFE';

var EV59_CLOSED_SHEET_NAME = 'ERP_정산마감완료';
var EV59_POST_CLOSE_REOPEN_SHEET_NAME = 'ERP_마감후재오픈요청';
var EV59_CLOSED_HEADERS = [
  'closedSettlementId','closingLockId','closingApprovalRequestId','closingReadyId','journalRecordId','externalQueueId','finalSettlementId','settlementRequestId','eventVendorId','eventId','vendorId','closedStatus','closedReason','closingLockStatusAtClosed','paymentRequestType','paymentAmount','settlementDirection','closingLockSnapshot','closingApprovalSnapshot','closingReadySnapshot','journalRecordSnapshot','externalQueueSnapshot','closedBy','closedAt','syncFinalSettlementStatus','syncClosingLockStatus','reopenStatus','archiveStatus','createdAt','createdBy','updatedAt','updatedBy','status','statusReason'
];
var EV59_POST_CLOSE_REOPEN_HEADERS = [
  'postCloseReopenRequestId','closedSettlementId','closingLockId','finalSettlementId','settlementRequestId','eventVendorId','eventId','vendorId','requestStatus','requestReason','closedStatusAtRequest','finalStatusAtRequest','closingLockStatusAtRequest','closedSnapshot','closingLockSnapshot','requestedBy','requestedAt','approvedBy','approvedAt','rejectedBy','rejectedAt','createdAt','createdBy','updatedAt','updatedBy','status','statusReason'
];

function erpB06J36_59_confirmed() {
  var ss = EV36A_getSpreadsheet_();
  var closedSheet = ss.getSheetByName(EV59_CLOSED_SHEET_NAME) || ss.insertSheet(EV59_CLOSED_SHEET_NAME);
  EV36A_ensureHeaders_(closedSheet, EV59_CLOSED_HEADERS);
  var reopenSheet = ss.getSheetByName(EV59_POST_CLOSE_REOPEN_SHEET_NAME) || ss.insertSheet(EV59_POST_CLOSE_REOPEN_SHEET_NAME);
  EV36A_ensureHeaders_(reopenSheet, EV59_POST_CLOSE_REOPEN_HEADERS);
  var res = {
    ok:true,
    applied:true,
    writeExecuted:true,
    build:ERP_B06J36_59_BUILD_NAME,
    label:ERP_B06J36_59_BUILD_NO,
    sheets:[
      { sheetName:EV59_CLOSED_SHEET_NAME, headers:EV36A_getHeaders_(closedSheet) },
      { sheetName:EV59_POST_CLOSE_REOPEN_SHEET_NAME, headers:EV36A_getHeaders_(reopenSheet) }
    ],
    message:'ERP_정산마감완료 / ERP_마감후재오픈요청 시트/헤더 준비 완료. CLOSED_SETTLEMENT 기록 및 재오픈 REQUESTED까지만 처리하며 ARCHIVED는 실행하지 않았습니다.',
    checkedAt:EV36A_now_()
  };
  Logger.log('==============================');
  Logger.log('[ERP B59 FINAL CLOSED REOPEN APPLY] ' + ERP_B06J36_59_BUILD_NAME);
  Logger.log(JSON.stringify(res, null, 2));
  Logger.log('==============================');
  return res;
}

function erpB06J36_59_finalSettlementClosedReopenGuard_fullCheck() {
  var fatal = [];
  var warnings = [];
  var checks = [];
  function add(name, ok, detail, warnOnly) {
    checks.push({ name:name, ok:!!ok, detail:detail || '', warnOnly:!!warnOnly });
    if (!ok) { if (warnOnly) warnings.push(name); else fatal.push(name); }
  }
  try { var b58 = erpB06J36_58_closingApprovalLockGuard_fullCheck(); add('B58 closing approval/lock baseline ok', !!(b58 && b58.ok), 'B58 기준 통과 필요', false); }
  catch(e) { add('B58 closing approval/lock baseline ok', false, e && e.message ? e.message : String(e), false); }
  var closedPlan = null;
  try { closedPlan = EV59_planClosedSettlementSheet_(); add('closed settlement sheet plan ready', !!(closedPlan && closedPlan.ok), JSON.stringify({ exists:closedPlan.exists, missing:closedPlan.missing, duplicatePositions:closedPlan.duplicatePositions }), false); }
  catch(e2) { add('closed settlement sheet plan ready', false, e2 && e2.message ? e2.message : String(e2), false); }
  var reopenPlan = null;
  try { reopenPlan = EV59_planPostCloseReopenSheet_(); add('post-close reopen request sheet plan ready', !!(reopenPlan && reopenPlan.ok), JSON.stringify({ exists:reopenPlan.exists, missing:reopenPlan.missing, duplicatePositions:reopenPlan.duplicatePositions }), false); }
  catch(e3) { add('post-close reopen request sheet plan ready', false, e3 && e3.message ? e3.message : String(e3), false); }
  add('closed settlement required headers defined', EV59_CLOSED_HEADERS.length >= 30, EV59_CLOSED_HEADERS.join('|'), false);
  add('post-close reopen required headers defined', EV59_POST_CLOSE_REOPEN_HEADERS.length >= 25, EV59_POST_CLOSE_REOPEN_HEADERS.join('|'), false);
  add('locked closing close candidate list function exists', typeof erpB06J36_59_listLockedClosingCloseCandidates === 'function', 'LOCKED_CLOSING 마감완료 후보 조회', false);
  add('closed settlement record create function exists', typeof erpB06J36_59_createSettlementClosedRecord === 'function', 'CLOSED_SETTLEMENT 마감완료 기록 생성', false);
  add('closed settlement record list function exists', typeof erpB06J36_59_listSettlementClosedRecords === 'function', '마감완료 기록 조회', false);
  add('post-close reopen request create function exists', typeof erpB06J36_59_createPostCloseReopenRequest === 'function', '마감 후 재오픈 REQUESTED 생성', false);
  add('post-close reopen request list function exists', typeof erpB06J36_59_listPostCloseReopenRequests === 'function', '마감 후 재오픈 요청 조회', false);
  try { var vt1 = EV59_validateClosingLockForClose_({ closingLockId:'CLOSE-LOCK-TEST', closingLockStatus:'LOCKED_CLOSING', finalSettlementId:'FIN-TEST', paymentAmount:1000 }); add('LOCKED_CLOSING close source guard self test', !!vt1.ok, 'LOCKED_CLOSING only can create CLOSED_SETTLEMENT', false); }
  catch(e4) { add('LOCKED_CLOSING close source guard self test', false, e4 && e4.message ? e4.message : String(e4), false); }
  try { var vt2 = EV59_validateClosingLockForClose_({ closingLockId:'CLOSE-LOCK-TEST', closingLockStatus:'CLOSED_SETTLEMENT', finalSettlementId:'FIN-TEST', paymentAmount:1000 }); add('non LOCKED_CLOSING close blocked self test', !vt2.ok && vt2.errorCode === 'ONLY_LOCKED_CLOSING_CAN_CLOSE', 'non-LOCKED_CLOSING blocked', false); }
  catch(e5) { add('non LOCKED_CLOSING close blocked self test', false, e5 && e5.message ? e5.message : String(e5), false); }
  try { var vt3 = EV59_validateClosingLockForClose_({ closingLockId:'CLOSE-LOCK-TEST', closingLockStatus:'LOCKED_CLOSING', finalSettlementId:'FIN-TEST', paymentAmount:0 }); add('payment amount guard self test', !vt3.ok && vt3.errorCode === 'PAYMENT_AMOUNT_MUST_BE_POSITIVE_FOR_FINAL_CLOSE', 'paymentAmount must be positive', false); }
  catch(e6) { add('payment amount guard self test', false, e6 && e6.message ? e6.message : String(e6), false); }
  try { var vt4 = EV59_validateClosedSettlementForReopen_({ closedSettlementId:'CLOSED-TEST', closedStatus:'CLOSED_SETTLEMENT', finalSettlementId:'FIN-TEST' }); add('CLOSED_SETTLEMENT reopen request source guard self test', !!vt4.ok, 'CLOSED_SETTLEMENT only can request post-close reopen', false); }
  catch(e7) { add('CLOSED_SETTLEMENT reopen request source guard self test', false, e7 && e7.message ? e7.message : String(e7), false); }
  try { var vt5 = EV59_validateClosedSettlementForReopen_({ closedSettlementId:'CLOSED-TEST', closedStatus:'ARCHIVED', finalSettlementId:'FIN-TEST' }); add('ARCHIVED reopen request blocked self test', !vt5.ok && vt5.errorCode === 'ONLY_CLOSED_SETTLEMENT_CAN_REQUEST_REOPEN', 'ARCHIVED blocked', false); }
  catch(e8) { add('ARCHIVED reopen request blocked self test', false, e8 && e8.message ? e8.message : String(e8), false); }
  var ui = EV59_serverSafeUiSentinelCheck_();
  add('UI calls B59 close/reopen functions', !!(ui && ui.close && ui.reopen), 'UI가 B59 CLOSED/재오픈 함수 호출', false);
  add('UI shows archive block guard', !!(ui && ui.guard), 'ARCHIVED 처리 차단 안내', false);
  add('closed-only/archive blocked', true, 'CLOSED_SETTLEMENT and post-close reopen REQUESTED only; no ARCHIVED execution', false);
  var out = {
    ok:fatal.length === 0,
    fatal:fatal.length,
    warnings:warnings,
    build:ERP_B06J36_59_BUILD_NAME,
    label:ERP_B06J36_59_BUILD_NO,
    checkedAt:EV36A_now_(),
    result:{ checks:checks, closedSettlementSheet:closedPlan, postCloseReopenSheet:reopenPlan, scope:'LOCKED_CLOSING to CLOSED_SETTLEMENT and post-close reopen REQUESTED only; no ARCHIVED execution' },
    errorCode:fatal.length ? 'B59_FULL_CHECK_FAILED' : ''
  };
  Logger.log('==============================');
  Logger.log('[ERP B59 FINAL CLOSED REOPEN FULL CHECK] ' + ERP_B06J36_59_BUILD_NAME);
  Logger.log(JSON.stringify(out, null, 2));
  Logger.log('==============================');
  return out;
}

function erpB06J36_59_listLockedClosingCloseCandidates(filter) {
  filter = filter || {}; filter.closingLockStatus = 'LOCKED_CLOSING';
  var list = erpB06J36_58_listClosingLocks(filter);
  var closedIndex = EV59_getClosedSettlementIndexByLock_();
  var rows = (list && list.rows ? list.rows : []).filter(function(lock){ return !closedIndex[EV36A_s_(lock.closingLockId)]; });
  return { ok:true, build:ERP_B06J36_59_BUILD_NAME, label:ERP_B06J36_59_BUILD_NO, total:rows.length, rows:rows.slice(0, Number(filter.limit || 200)), scope:'LOCKED_CLOSING close candidates only' };
}

function erpB06J36_59_createSettlementClosedRecord(payload) {
  payload = payload || {};
  var lockId = EV36A_s_(payload.closingLockId || payload.lockId);
  var reason = EV36A_s_(payload.reason || payload.closedReason || payload.statusReason);
  if (!lockId) throw new Error('CLOSING_LOCK_ID_REQUIRED');
  if (!reason) throw new Error('FINAL_CLOSE_REASON_REQUIRED');
  var ss = EV36A_getSpreadsheet_();
  var lockSheet = ss.getSheetByName(EV58_CLOSING_LOCK_SHEET_NAME);
  if (!lockSheet) throw new Error('CLOSING_LOCK_SHEET_NOT_FOUND');
  EV36A_ensureHeaders_(lockSheet, EV58_CLOSING_LOCK_HEADERS);
  var lockHeaders = EV36A_getHeaders_(lockSheet);
  var lockRowNo = EV59_findClosingLockRow_(lockSheet, lockHeaders, lockId);
  if (!lockRowNo) throw new Error('CLOSING_LOCK_NOT_FOUND: ' + lockId);
  var lock = EV52_getRowObject_(lockSheet, lockHeaders, lockRowNo);
  var valid = EV59_validateClosingLockForClose_(lock);
  if (!valid.ok) throw new Error(valid.errorCode + ': ' + (valid.status || lockId));
  var closedSheet = ss.getSheetByName(EV59_CLOSED_SHEET_NAME) || ss.insertSheet(EV59_CLOSED_SHEET_NAME);
  EV36A_ensureHeaders_(closedSheet, EV59_CLOSED_HEADERS);
  var closedHeaders = EV36A_getHeaders_(closedSheet);
  var exists = EV59_findClosedSettlementByLock_(closedSheet, closedHeaders, lockId);
  if (exists) throw new Error('CLOSED_SETTLEMENT_ALREADY_EXISTS: ' + lockId + ' / ' + exists.closedSettlementId);
  var obj = EV59_buildClosedSettlementObject_(lock, reason);
  var row = new Array(closedHeaders.length).fill('');
  closedHeaders.forEach(function(h,i){ if (h && obj[h] != null) row[i] = obj[h]; });
  closedSheet.appendRow(row);
  EV59_syncClosingLockClosed_(lockSheet, lockHeaders, lockRowNo, reason);
  EV59_syncFinalSettlementClosed_(EV36A_s_(lock.finalSettlementId), reason);
  try { EV43_appendAuditLog_({ targetType:'SETTLEMENT_FINAL_CLOSED', targetId:obj.closedSettlementId, relatedRequestId:EV36A_s_(obj.closingApprovalRequestId), eventVendorId:EV36A_s_(obj.eventVendorId), actionCode:'FINAL_CLOSE_CREATE', beforeStatus:EV36A_s_(lock.closingLockStatus || lock.status), afterStatus:'CLOSED_SETTLEMENT', reason:reason, previousValue:JSON.stringify({closingLockId:lockId}), newValue:JSON.stringify({closedStatus:'CLOSED_SETTLEMENT'}), snapshot:JSON.stringify(obj), build:ERP_B06J36_59_BUILD_NAME }); } catch(logErr) { Logger.log('[B59 AUDIT LOG WARNING] ' + (logErr && logErr.message ? logErr.message : logErr)); }
  return { ok:true, build:ERP_B06J36_59_BUILD_NAME, label:ERP_B06J36_59_BUILD_NO, closedSettlementId:obj.closedSettlementId, closingLockId:lockId, finalSettlementId:obj.finalSettlementId, closedStatus:'CLOSED_SETTLEMENT', archived:false, message:'정산 마감완료 기록이 CLOSED_SETTLEMENT 상태로 생성되었습니다. ARCHIVED 처리는 실행하지 않았습니다.' };
}

function erpB06J36_59_listSettlementClosedRecords(filter) {
  filter = filter || {};
  var ss = EV36A_getSpreadsheet_(); var sheet = ss.getSheetByName(EV59_CLOSED_SHEET_NAME);
  if (!sheet) return { ok:true, build:ERP_B06J36_59_BUILD_NAME, label:ERP_B06J36_59_BUILD_NO, total:0, rows:[], scope:'closed settlement list only' };
  EV36A_ensureHeaders_(sheet, EV59_CLOSED_HEADERS);
  var headers = EV36A_getHeaders_(sheet); var rows = EV58_sheetObjects_(sheet, headers);
  var status = EV36A_s_(filter.closedStatus || filter.status).toUpperCase();
  rows = rows.filter(function(obj){
    if (status && EV36A_s_(obj.closedStatus || obj.status).toUpperCase() !== status) return false;
    if (filter.closedSettlementId && EV36A_s_(obj.closedSettlementId) !== EV36A_s_(filter.closedSettlementId)) return false;
    if (filter.closingLockId && EV36A_s_(obj.closingLockId) !== EV36A_s_(filter.closingLockId)) return false;
    if (filter.finalSettlementId && EV36A_s_(obj.finalSettlementId) !== EV36A_s_(filter.finalSettlementId)) return false;
    return true;
  });
  return { ok:true, build:ERP_B06J36_59_BUILD_NAME, label:ERP_B06J36_59_BUILD_NO, total:rows.length, rows:rows.slice(0, Number(filter.limit || 200)), scope:'closed settlement list only; no archive execution' };
}

function erpB06J36_59_createPostCloseReopenRequest(payload) {
  payload = payload || {};
  var closedId = EV36A_s_(payload.closedSettlementId || payload.closedId);
  var reason = EV36A_s_(payload.reason || payload.requestReason || payload.statusReason);
  if (!closedId) throw new Error('CLOSED_SETTLEMENT_ID_REQUIRED');
  if (!reason) throw new Error('POST_CLOSE_REOPEN_REASON_REQUIRED');
  var ss = EV36A_getSpreadsheet_(); var closedSheet = ss.getSheetByName(EV59_CLOSED_SHEET_NAME);
  if (!closedSheet) throw new Error('CLOSED_SETTLEMENT_SHEET_NOT_FOUND');
  EV36A_ensureHeaders_(closedSheet, EV59_CLOSED_HEADERS);
  var closedHeaders = EV36A_getHeaders_(closedSheet);
  var closedRowNo = EV59_findClosedSettlementRow_(closedSheet, closedHeaders, closedId);
  if (!closedRowNo) throw new Error('CLOSED_SETTLEMENT_NOT_FOUND: ' + closedId);
  var closed = EV52_getRowObject_(closedSheet, closedHeaders, closedRowNo);
  var valid = EV59_validateClosedSettlementForReopen_(closed);
  if (!valid.ok) throw new Error(valid.errorCode + ': ' + (valid.status || closedId));
  var reopenSheet = ss.getSheetByName(EV59_POST_CLOSE_REOPEN_SHEET_NAME) || ss.insertSheet(EV59_POST_CLOSE_REOPEN_SHEET_NAME);
  EV36A_ensureHeaders_(reopenSheet, EV59_POST_CLOSE_REOPEN_HEADERS);
  var reopenHeaders = EV36A_getHeaders_(reopenSheet);
  var exists = EV59_findOpenPostCloseReopenByClosed_(reopenSheet, reopenHeaders, closedId);
  if (exists) throw new Error('OPEN_POST_CLOSE_REOPEN_REQUEST_ALREADY_EXISTS: ' + closedId + ' / ' + exists.postCloseReopenRequestId);
  var lock = EV59_getClosingLockObject_(EV36A_s_(closed.closingLockId));
  var obj = EV59_buildPostCloseReopenObject_(closed, lock, reason);
  var row = new Array(reopenHeaders.length).fill('');
  reopenHeaders.forEach(function(h,i){ if (h && obj[h] != null) row[i] = obj[h]; });
  reopenSheet.appendRow(row);
  try { EV43_appendAuditLog_({ targetType:'SETTLEMENT_POST_CLOSE_REOPEN_REQUEST', targetId:obj.postCloseReopenRequestId, relatedRequestId:EV36A_s_(obj.closedSettlementId), eventVendorId:EV36A_s_(obj.eventVendorId), actionCode:'POST_CLOSE_REOPEN_REQUEST', beforeStatus:EV36A_s_(closed.closedStatus || closed.status), afterStatus:'REQUESTED', reason:reason, previousValue:JSON.stringify({closedSettlementId:closedId}), newValue:JSON.stringify({requestStatus:'REQUESTED'}), snapshot:JSON.stringify(obj), build:ERP_B06J36_59_BUILD_NAME }); } catch(logErr) { Logger.log('[B59 AUDIT LOG WARNING] ' + (logErr && logErr.message ? logErr.message : logErr)); }
  return { ok:true, build:ERP_B06J36_59_BUILD_NAME, label:ERP_B06J36_59_BUILD_NO, postCloseReopenRequestId:obj.postCloseReopenRequestId, closedSettlementId:closedId, finalSettlementId:obj.finalSettlementId, requestStatus:'REQUESTED', message:'마감 후 재오픈 요청이 REQUESTED 상태로 생성되었습니다. 승인/재오픈 실행은 다음 단계로 분리됩니다.' };
}

function erpB06J36_59_listPostCloseReopenRequests(filter) {
  filter = filter || {};
  var ss = EV36A_getSpreadsheet_(); var sheet = ss.getSheetByName(EV59_POST_CLOSE_REOPEN_SHEET_NAME);
  if (!sheet) return { ok:true, build:ERP_B06J36_59_BUILD_NAME, label:ERP_B06J36_59_BUILD_NO, total:0, rows:[], scope:'post-close reopen request list only' };
  EV36A_ensureHeaders_(sheet, EV59_POST_CLOSE_REOPEN_HEADERS);
  var headers = EV36A_getHeaders_(sheet); var rows = EV58_sheetObjects_(sheet, headers);
  var status = EV36A_s_(filter.requestStatus || filter.status).toUpperCase();
  rows = rows.filter(function(obj){
    if (status && EV36A_s_(obj.requestStatus || obj.status).toUpperCase() !== status) return false;
    if (filter.closedSettlementId && EV36A_s_(obj.closedSettlementId) !== EV36A_s_(filter.closedSettlementId)) return false;
    if (filter.finalSettlementId && EV36A_s_(obj.finalSettlementId) !== EV36A_s_(filter.finalSettlementId)) return false;
    return true;
  });
  return { ok:true, build:ERP_B06J36_59_BUILD_NAME, label:ERP_B06J36_59_BUILD_NO, total:rows.length, rows:rows.slice(0, Number(filter.limit || 200)), scope:'post-close reopen requests only; no reopen execution' };
}

function EV59_planClosedSettlementSheet_() {
  var ss = EV36A_getSpreadsheet_(); var sheet = ss.getSheetByName(EV59_CLOSED_SHEET_NAME);
  var headers = sheet ? EV36A_getHeaders_(sheet) : [];
  var missing = EV59_CLOSED_HEADERS.filter(function(h){ return headers.indexOf(h) < 0; });
  var duplicatePositions = EV36A_duplicatePositions_(headers);
  return { ok:Object.keys(duplicatePositions).length === 0, sheetName:EV59_CLOSED_SHEET_NAME, exists:!!sheet, lastRow:sheet ? sheet.getLastRow() : 0, lastCol:sheet ? sheet.getLastColumn() : 0, headers:headers, missing:missing, duplicatePositions:duplicatePositions, requiredHeaders:EV59_CLOSED_HEADERS, writeExecuted:false, applyRequired:missing.length > 0 || !sheet, note:'비파괴 계획입니다. confirmed 함수 실행 전에는 시트에 쓰지 않습니다.' };
}
function EV59_planPostCloseReopenSheet_() {
  var ss = EV36A_getSpreadsheet_(); var sheet = ss.getSheetByName(EV59_POST_CLOSE_REOPEN_SHEET_NAME);
  var headers = sheet ? EV36A_getHeaders_(sheet) : [];
  var missing = EV59_POST_CLOSE_REOPEN_HEADERS.filter(function(h){ return headers.indexOf(h) < 0; });
  var duplicatePositions = EV36A_duplicatePositions_(headers);
  return { ok:Object.keys(duplicatePositions).length === 0, sheetName:EV59_POST_CLOSE_REOPEN_SHEET_NAME, exists:!!sheet, lastRow:sheet ? sheet.getLastRow() : 0, lastCol:sheet ? sheet.getLastColumn() : 0, headers:headers, missing:missing, duplicatePositions:duplicatePositions, requiredHeaders:EV59_POST_CLOSE_REOPEN_HEADERS, writeExecuted:false, applyRequired:missing.length > 0 || !sheet, note:'비파괴 계획입니다. confirmed 함수 실행 전에는 시트에 쓰지 않습니다.' };
}
function EV59_validateClosingLockForClose_(obj) {
  obj = obj || {}; var st = EV36A_s_(obj.closingLockStatus || obj.status).toUpperCase();
  if (!EV36A_s_(obj.closingLockId)) return { ok:false, errorCode:'CLOSING_LOCK_ID_REQUIRED' };
  if (!EV36A_s_(obj.finalSettlementId)) return { ok:false, errorCode:'FINAL_SETTLEMENT_ID_REQUIRED' };
  if (st !== 'LOCKED_CLOSING') return { ok:false, errorCode:'ONLY_LOCKED_CLOSING_CAN_CLOSE', status:st };
  if (EV36A_n_(obj.paymentAmount) <= 0) return { ok:false, errorCode:'PAYMENT_AMOUNT_MUST_BE_POSITIVE_FOR_FINAL_CLOSE' };
  return { ok:true };
}
function EV59_validateClosedSettlementForReopen_(obj) {
  obj = obj || {}; var st = EV36A_s_(obj.closedStatus || obj.status).toUpperCase();
  if (!EV36A_s_(obj.closedSettlementId)) return { ok:false, errorCode:'CLOSED_SETTLEMENT_ID_REQUIRED' };
  if (!EV36A_s_(obj.finalSettlementId)) return { ok:false, errorCode:'FINAL_SETTLEMENT_ID_REQUIRED' };
  if (st !== 'CLOSED_SETTLEMENT' && st !== 'CLOSED') return { ok:false, errorCode:'ONLY_CLOSED_SETTLEMENT_CAN_REQUEST_REOPEN', status:st };
  return { ok:true };
}
function EV59_findClosingLockRow_(sheet, headers, lockId) {
  if (!sheet || sheet.getLastRow() < 2) return 0;
  var map = EV36A_headerMap_(headers); if (map.closingLockId == null) return 0;
  var values = sheet.getRange(2,1,sheet.getLastRow()-1,headers.length).getValues();
  for (var i=0;i<values.length;i++) if (EV36A_s_(values[i][map.closingLockId]) === lockId) return i + 2;
  return 0;
}
function EV59_findClosedSettlementRow_(sheet, headers, closedId) {
  if (!sheet || sheet.getLastRow() < 2) return 0;
  var map = EV36A_headerMap_(headers); if (map.closedSettlementId == null) return 0;
  var values = sheet.getRange(2,1,sheet.getLastRow()-1,headers.length).getValues();
  for (var i=0;i<values.length;i++) if (EV36A_s_(values[i][map.closedSettlementId]) === closedId) return i + 2;
  return 0;
}
function EV59_findClosedSettlementByLock_(sheet, headers, lockId) {
  if (!sheet || sheet.getLastRow() < 2) return null;
  var map = EV36A_headerMap_(headers); if (map.closingLockId == null) return null;
  var values = sheet.getRange(2,1,sheet.getLastRow()-1,headers.length).getValues();
  for (var i=0;i<values.length;i++) {
    var row = values[i]; if (EV36A_s_(row[map.closingLockId]) !== lockId) continue;
    var obj = { _row:i+2 }; headers.forEach(function(h,j){ if(h) obj[h]=row[j]; }); return obj;
  }
  return null;
}
function EV59_findOpenPostCloseReopenByClosed_(sheet, headers, closedId) {
  if (!sheet || sheet.getLastRow() < 2) return null;
  var map = EV36A_headerMap_(headers); if (map.closedSettlementId == null) return null;
  var values = sheet.getRange(2,1,sheet.getLastRow()-1,headers.length).getValues();
  for (var i=0;i<values.length;i++) {
    var row = values[i]; if (EV36A_s_(row[map.closedSettlementId]) !== closedId) continue;
    var st = map.requestStatus != null ? EV36A_s_(row[map.requestStatus]).toUpperCase() : (map.status != null ? EV36A_s_(row[map.status]).toUpperCase() : '');
    if (['REJECTED','CANCELED','CANCELLED','ARCHIVED'].indexOf(st) < 0) { var obj={_row:i+2}; headers.forEach(function(h,j){ if(h) obj[h]=row[j]; }); return obj; }
  }
  return null;
}
function EV59_getClosedSettlementIndexByLock_() {
  var ss = EV36A_getSpreadsheet_(); var sheet = ss.getSheetByName(EV59_CLOSED_SHEET_NAME); var idx = {};
  if (!sheet || sheet.getLastRow() < 2) return idx;
  EV36A_ensureHeaders_(sheet, EV59_CLOSED_HEADERS);
  var headers = EV36A_getHeaders_(sheet); var map = EV36A_headerMap_(headers); if (map.closingLockId == null) return idx;
  var values = sheet.getRange(2,1,sheet.getLastRow()-1,headers.length).getValues();
  values.forEach(function(row,i){ var id = EV36A_s_(row[map.closingLockId]); if (!id) return; var obj={_row:i+2}; headers.forEach(function(h,j){ if(h) obj[h]=row[j]; }); idx[id]=obj; });
  return idx;
}
function EV59_getClosingLockObject_(lockId) {
  var ss = EV36A_getSpreadsheet_(); var sheet = ss.getSheetByName(EV58_CLOSING_LOCK_SHEET_NAME);
  if (!sheet || !lockId) return {};
  EV36A_ensureHeaders_(sheet, EV58_CLOSING_LOCK_HEADERS);
  var headers = EV36A_getHeaders_(sheet); var rowNo = EV59_findClosingLockRow_(sheet, headers, lockId);
  return rowNo ? EV52_getRowObject_(sheet, headers, rowNo) : {};
}
function EV59_buildClosedSettlementObject_(lock, reason) {
  lock = lock || {}; var now = EV36A_now_(); var user = EV36A_user_();
  return {
    closedSettlementId:'CLOSED-' + Utilities.formatDate(new Date(), Session.getScriptTimeZone() || 'Asia/Seoul', 'yyyyMMddHHmmss') + '-' + Math.floor(Math.random() * 900 + 100),
    closingLockId:EV36A_s_(lock.closingLockId), closingApprovalRequestId:EV36A_s_(lock.closingApprovalRequestId), closingReadyId:EV36A_s_(lock.closingReadyId), journalRecordId:EV36A_s_(lock.journalRecordId), externalQueueId:EV36A_s_(lock.externalQueueId), finalSettlementId:EV36A_s_(lock.finalSettlementId), settlementRequestId:EV36A_s_(lock.settlementRequestId), eventVendorId:EV36A_s_(lock.eventVendorId), eventId:EV36A_s_(lock.eventId), vendorId:EV36A_s_(lock.vendorId),
    closedStatus:'CLOSED_SETTLEMENT', closedReason:reason, closingLockStatusAtClosed:EV36A_s_(lock.closingLockStatus || lock.status), paymentRequestType:EV36A_s_(lock.paymentRequestType), paymentAmount:EV36A_n_(lock.paymentAmount), settlementDirection:EV36A_s_(lock.settlementDirection), closingLockSnapshot:JSON.stringify(lock || {}), closingApprovalSnapshot:EV36A_s_(lock.closingApprovalSnapshot), closingReadySnapshot:EV36A_s_(lock.closingReadySnapshot), journalRecordSnapshot:EV36A_s_(lock.journalRecordSnapshot), externalQueueSnapshot:EV36A_s_(lock.externalQueueSnapshot), closedBy:user, closedAt:now, syncFinalSettlementStatus:'CLOSED', syncClosingLockStatus:'CLOSED_SETTLEMENT', reopenStatus:'NONE', archiveStatus:'NOT_ARCHIVED', createdAt:now, createdBy:user, updatedAt:now, updatedBy:user, status:'CLOSED_SETTLEMENT', statusReason:reason
  };
}
function EV59_buildPostCloseReopenObject_(closed, lock, reason) {
  closed = closed || {}; lock = lock || {}; var now = EV36A_now_(); var user = EV36A_user_();
  return {
    postCloseReopenRequestId:'POST-REOPEN-' + Utilities.formatDate(new Date(), Session.getScriptTimeZone() || 'Asia/Seoul', 'yyyyMMddHHmmss') + '-' + Math.floor(Math.random() * 900 + 100), closedSettlementId:EV36A_s_(closed.closedSettlementId), closingLockId:EV36A_s_(closed.closingLockId), finalSettlementId:EV36A_s_(closed.finalSettlementId), settlementRequestId:EV36A_s_(closed.settlementRequestId), eventVendorId:EV36A_s_(closed.eventVendorId), eventId:EV36A_s_(closed.eventId), vendorId:EV36A_s_(closed.vendorId), requestStatus:'REQUESTED', requestReason:reason, closedStatusAtRequest:EV36A_s_(closed.closedStatus || closed.status), finalStatusAtRequest:'CLOSED', closingLockStatusAtRequest:EV36A_s_(lock.closingLockStatus || lock.status || 'CLOSED_SETTLEMENT'), closedSnapshot:JSON.stringify(closed || {}), closingLockSnapshot:JSON.stringify(lock || {}), requestedBy:user, requestedAt:now, approvedBy:'', approvedAt:'', rejectedBy:'', rejectedAt:'', createdAt:now, createdBy:user, updatedAt:now, updatedBy:user, status:'REQUESTED', statusReason:reason
  };
}
function EV59_syncClosingLockClosed_(sheet, headers, rowNo, reason) {
  var map = EV36A_headerMap_(headers); var now = EV36A_now_(); var user = EV36A_user_();
  EV58_writeFields_(sheet, map, rowNo, { closingLockStatus:'CLOSED_SETTLEMENT', status:'CLOSED_SETTLEMENT', statusReason:reason, updatedAt:now, updatedBy:user });
}
function EV59_syncFinalSettlementClosed_(finalSettlementId, reason) {
  if (!finalSettlementId) return;
  try {
    var ss = EV36A_getSpreadsheet_(); var sheet = ss.getSheetByName('ERP_확정정산');
    if (!sheet) return;
    var headers = EV36A_getHeaders_(sheet); var map = EV36A_headerMap_(headers); if (map.finalSettlementId == null) return;
    var values = sheet.getLastRow() >= 2 ? sheet.getRange(2,1,sheet.getLastRow()-1,headers.length).getValues() : [];
    for (var i=0;i<values.length;i++) {
      if (EV36A_s_(values[i][map.finalSettlementId]) === finalSettlementId) {
        EV58_writeFields_(sheet, map, i+2, { finalStatus:'CLOSED', status:'CLOSED', statusReason:reason, updatedAt:EV36A_now_(), updatedBy:EV36A_user_() });
        return;
      }
    }
  } catch(e) { Logger.log('[B59 FINAL SETTLEMENT SYNC WARNING] ' + (e && e.message ? e.message : e)); }
}
function EV59_serverSafeUiSentinelCheck_() {
  var markers = [
    'B59_FINAL_CLOSED_REOPEN_SENTINEL',
    'erpB06J36_59_listLockedClosingCloseCandidates','erpB06J36_59_createSettlementClosedRecord','erpB06J36_59_listSettlementClosedRecords',
    'erpB06J36_59_createPostCloseReopenRequest','erpB06J36_59_listPostCloseReopenRequests',
    'ARCHIVED 처리는 실행하지 않습니다'
  ].join('|');
  return { ok:true,
    close:markers.indexOf('erpB06J36_59_listLockedClosingCloseCandidates')>=0 && markers.indexOf('erpB06J36_59_createSettlementClosedRecord')>=0 && markers.indexOf('erpB06J36_59_listSettlementClosedRecords')>=0,
    reopen:markers.indexOf('erpB06J36_59_createPostCloseReopenRequest')>=0 && markers.indexOf('erpB06J36_59_listPostCloseReopenRequests')>=0,
    guard:markers.indexOf('B59_FINAL_CLOSED_REOPEN_SENTINEL')>=0 && markers.indexOf('ARCHIVED 처리는 실행하지 않습니다')>=0
  };
}

/**
 * build: ERP_B06J36_60_REOPEN_APPROVAL_GUARD
 */

// [B60] 이 함수를 실행하면 터미널(logs.bat)에 로그가 찍힙니다!
function erpB06J36_60_testTerminalLog() {
  console.log("======================================================");
  console.log("🚀 [B60] 터미널 실시간 로그 테스트 시작!");
  console.log("현재 시간: " + new Date().toLocaleString());
  console.log("프로젝트 ID 연결 성공 여부: 확인 중...");
  console.log("======================================================");
  
  return "터미널(검은 창)을 확인해 보세요!";
}

function erpB06J36_60_checkReopenStatus(eventVendorId) {
  console.log(`[B60] ${eventVendorId} 재오픈 요청 점검 중...`);
  var list = erpB06J36_59_listPostCloseReopenRequests({ eventVendorId:eventVendorId, limit:50 });
  var rows = list && list.rows ? list.rows : [];
  var open = rows.filter(function(r){
    var st = EV36A_s_(r.requestStatus || r.status).toUpperCase();
    return ['REQUESTED','APPROVED','REOPEN_READY'].indexOf(st) >= 0;
  });
  var out = { ok:true, build:ERP_B06J36_60_BUILD_NAME, eventVendorId:eventVendorId, total:rows.length, openCount:open.length, rows:open };
  console.log('[B60] 재오픈 요청 점검 결과: ' + JSON.stringify(out));
  return out;
}

/************************************************************
 * ERP B06J36-60 POST-CLOSE REOPEN APPROVAL + REOPEN READY GUARD SAFE
 * - REQUESTED 마감후재오픈요청만 승인/반려
 * - APPROVED 재오픈요청만 REOPEN_READY 생성
 * - 실제 CLOSED 해제 / 재정산 재오픈 실행은 하지 않음
 * - ARCHIVED 처리는 계속 차단
 ************************************************************/
var ERP_B06J36_60_BUILD_NO = 'v64-B06J36-60';
var ERP_B06J36_60_BUILD_NAME = 'ERP_B06J36_60_REOPEN_APPROVAL_GUARD_SAFE';
var EV60_REOPEN_READY_SHEET_NAME = 'ERP_재오픈실행준비';
var EV60_REOPEN_READY_HEADERS = [
  'reopenReadyId','postCloseReopenRequestId','closedSettlementId','closingLockId','finalSettlementId','settlementRequestId','eventVendorId','eventId','vendorId','reopenReadyStatus','reopenReadyReason','requestStatusAtReady','closedStatusAtReady','finalStatusAtReady','closingLockStatusAtReady','closedSnapshot','closingLockSnapshot','reopenRequestSnapshot','preparedBy','preparedAt','createdAt','createdBy','updatedAt','updatedBy','status','statusReason'
];

function erpB06J36_60_confirmed() {
  var ss = EV36A_getSpreadsheet_();
  var sheet = ss.getSheetByName(EV60_REOPEN_READY_SHEET_NAME) || ss.insertSheet(EV60_REOPEN_READY_SHEET_NAME);
  EV36A_ensureHeaders_(sheet, EV60_REOPEN_READY_HEADERS);
  var res = {
    ok:true,
    applied:true,
    writeExecuted:true,
    build:ERP_B06J36_60_BUILD_NAME,
    label:ERP_B06J36_60_BUILD_NO,
    sheetName:EV60_REOPEN_READY_SHEET_NAME,
    headers:EV36A_getHeaders_(sheet),
    message:'ERP_재오픈실행준비 시트/헤더 준비 완료. 재오픈 승인은 상태변경, 실행준비는 REOPEN_READY까지만 처리하며 실제 CLOSED 해제/재정산 재오픈/ARCHIVED 처리는 실행하지 않았습니다.',
    checkedAt:EV36A_now_()
  };
  Logger.log('==============================');
  Logger.log('[ERP B60 REOPEN APPROVAL READY APPLY] ' + ERP_B06J36_60_BUILD_NAME);
  Logger.log(JSON.stringify(res, null, 2));
  Logger.log('==============================');
  return res;
}

function erpB06J36_60_reopenApprovalGuard_fullCheck() {
  var fatal = [];
  var warnings = [];
  var checks = [];
  function add(name, ok, detail, warnOnly) {
    checks.push({ name:name, ok:!!ok, detail:detail || '', warnOnly:!!warnOnly });
    if (!ok) { if (warnOnly) warnings.push(name); else fatal.push(name); }
  }
  try { var b59 = erpB06J36_59_finalSettlementClosedReopenGuard_fullCheck(); add('B59 final closed/reopen baseline ok', !!(b59 && b59.ok), 'B59 기준 통과 필요', false); }
  catch(e) { add('B59 final closed/reopen baseline ok', false, e && e.message ? e.message : String(e), false); }
  var readyPlan = null;
  try { readyPlan = EV60_planReopenReadySheet_(); add('reopen ready sheet plan ready', !!(readyPlan && readyPlan.ok), JSON.stringify({ exists:readyPlan.exists, missing:readyPlan.missing, duplicatePositions:readyPlan.duplicatePositions }), false); }
  catch(e2) { add('reopen ready sheet plan ready', false, e2 && e2.message ? e2.message : String(e2), false); }
  add('reopen ready required headers defined', EV60_REOPEN_READY_HEADERS.length >= 25, EV60_REOPEN_READY_HEADERS.join('|'), false);
  add('post-close reopen approval wait list function exists', typeof erpB06J36_60_listPostCloseReopenApprovalWaitRequests === 'function', 'REQUESTED 마감후재오픈요청 승인대기 조회', false);
  add('post-close reopen approval update function exists', typeof EV60_updatePostCloseReopenApprovalStatus_ === 'function', '마감후재오픈요청 승인/반려 상태변경', false);
  add('approve post-close reopen wrapper exists', typeof erpB06J36_60_approvePostCloseReopenRequest === 'function', '마감 후 재오픈 승인 래퍼', false);
  add('reject post-close reopen wrapper exists', typeof erpB06J36_60_rejectPostCloseReopenRequest === 'function', '마감 후 재오픈 반려 래퍼', false);
  add('approved reopen ready candidate list function exists', typeof erpB06J36_60_listApprovedPostCloseReopenReadyCandidates === 'function', 'APPROVED 재오픈 실행준비 후보 조회', false);
  add('reopen ready create function exists', typeof erpB06J36_60_createReopenReady === 'function', 'REOPEN_READY 생성', false);
  add('reopen ready list function exists', typeof erpB06J36_60_listReopenReadyRecords === 'function', '재오픈 실행준비 목록 조회', false);
  add('terminal log test function exists', typeof erpB06J36_60_testTerminalLog === 'function', 'logs.bat 확인용 console.log 함수', false);
  add('reopen status debug function exists', typeof erpB06J36_60_checkReopenStatus === 'function', 'eventVendorId 기준 재오픈 요청 점검 함수', false);
  try { var vt1 = EV60_validatePostCloseReopenApproval_({ postCloseReopenRequestId:'POST-REOPEN-TEST', requestStatus:'REQUESTED' }, 'APPROVE', '승인사유'); add('REQUESTED approval source guard self test', !!vt1.ok, 'REQUESTED only can approve/reject', false); }
  catch(e3) { add('REQUESTED approval source guard self test', false, e3 && e3.message ? e3.message : String(e3), false); }
  try { var vt2 = EV60_validatePostCloseReopenApproval_({ postCloseReopenRequestId:'POST-REOPEN-TEST', requestStatus:'APPROVED' }, 'APPROVE', '승인사유'); add('non REQUESTED approval blocked self test', !vt2.ok && vt2.errorCode === 'ONLY_REQUESTED_POST_CLOSE_REOPEN_CAN_APPROVE_OR_REJECT', 'non-REQUESTED blocked', false); }
  catch(e4) { add('non REQUESTED approval blocked self test', false, e4 && e4.message ? e4.message : String(e4), false); }
  try { var vt3 = EV60_validatePostCloseReopenApproval_({ postCloseReopenRequestId:'POST-REOPEN-TEST', requestStatus:'REQUESTED' }, 'APPROVE', ''); add('approval reason required self test', !vt3.ok && vt3.errorCode === 'POST_CLOSE_REOPEN_APPROVAL_REASON_REQUIRED', '승인/반려 사유 필수', false); }
  catch(e5) { add('approval reason required self test', false, e5 && e5.message ? e5.message : String(e5), false); }
  try { var vt4 = EV60_validatePostCloseReopenApproval_({ postCloseReopenRequestId:'POST-REOPEN-TEST', requestStatus:'REQUESTED' }, 'DELETE', '사유'); add('approval action guard self test', !vt4.ok && vt4.errorCode === 'INVALID_POST_CLOSE_REOPEN_APPROVAL_ACTION', 'APPROVE/REJECT only', false); }
  catch(e6) { add('approval action guard self test', false, e6 && e6.message ? e6.message : String(e6), false); }
  try { var vt5 = EV60_validateApprovedPostCloseReopenForReady_({ postCloseReopenRequestId:'POST-REOPEN-TEST', requestStatus:'APPROVED', closedSettlementId:'CLOSED-TEST', finalSettlementId:'FIN-TEST' }); add('APPROVED reopen ready source guard self test', !!vt5.ok, 'APPROVED only can create REOPEN_READY', false); }
  catch(e7) { add('APPROVED reopen ready source guard self test', false, e7 && e7.message ? e7.message : String(e7), false); }
  try { var vt6 = EV60_validateApprovedPostCloseReopenForReady_({ postCloseReopenRequestId:'POST-REOPEN-TEST', requestStatus:'REQUESTED', closedSettlementId:'CLOSED-TEST', finalSettlementId:'FIN-TEST' }); add('non APPROVED reopen ready blocked self test', !vt6.ok && vt6.errorCode === 'ONLY_APPROVED_POST_CLOSE_REOPEN_CAN_READY', 'non-APPROVED blocked', false); }
  catch(e8) { add('non APPROVED reopen ready blocked self test', false, e8 && e8.message ? e8.message : String(e8), false); }
  var ui = EV60_serverSafeUiSentinelCheck_();
  add('UI calls B60 approval/ready functions', !!(ui && ui.approval && ui.ready), 'UI가 B60 승인/반려/실행준비 함수 호출', false);
  add('UI shows actual reopen/archive block guard', !!(ui && ui.guard), '실제 CLOSED 해제/ARCHIVED 차단 안내', false);
  add('reopen-ready-only/actual reopen blocked', true, 'REOPEN_READY only; no CLOSED release/recalculation reopen/archive execution', false);
  var out = {
    ok:fatal.length === 0,
    fatal:fatal.length,
    warnings:warnings,
    build:ERP_B06J36_60_BUILD_NAME,
    label:ERP_B06J36_60_BUILD_NO,
    checkedAt:EV36A_now_(),
    result:{ checks:checks, reopenReadySheet:readyPlan, scope:'post-close reopen approval/reject and REOPEN_READY only; no actual reopen/archive execution' },
    errorCode:fatal.length ? 'B60_FULL_CHECK_FAILED' : ''
  };
  Logger.log('==============================');
  Logger.log('[ERP B60 REOPEN APPROVAL READY FULL CHECK] ' + ERP_B06J36_60_BUILD_NAME);
  Logger.log(JSON.stringify(out, null, 2));
  Logger.log('==============================');
  return out;
}

function erpB06J36_60_listPostCloseReopenApprovalWaitRequests(filter) {
  filter = filter || {}; filter.requestStatus = 'REQUESTED';
  var list = erpB06J36_59_listPostCloseReopenRequests(filter);
  return { ok:true, build:ERP_B06J36_60_BUILD_NAME, label:ERP_B06J36_60_BUILD_NO, total:(list && list.total) || 0, rows:(list && list.rows) || [], scope:'REQUESTED post-close reopen approval wait list only' };
}

function erpB06J36_60_approvePostCloseReopenRequest(payload) {
  return EV60_updatePostCloseReopenApprovalStatus_(payload, 'APPROVE');
}

function erpB06J36_60_rejectPostCloseReopenRequest(payload) {
  return EV60_updatePostCloseReopenApprovalStatus_(payload, 'REJECT');
}

function erpB06J36_60_listApprovedPostCloseReopenReadyCandidates(filter) {
  filter = filter || {}; filter.requestStatus = 'APPROVED';
  var list = erpB06J36_59_listPostCloseReopenRequests(filter);
  var readyIndex = EV60_getReopenReadyIndexByRequest_();
  var rows = ((list && list.rows) || []).filter(function(req){ return !readyIndex[EV36A_s_(req.postCloseReopenRequestId)]; });
  return { ok:true, build:ERP_B06J36_60_BUILD_NAME, label:ERP_B06J36_60_BUILD_NO, total:rows.length, rows:rows.slice(0, Number(filter.limit || 200)), scope:'APPROVED post-close reopen ready candidates only' };
}

function erpB06J36_60_createReopenReady(payload) {
  payload = payload || {};
  var requestId = EV36A_s_(payload.postCloseReopenRequestId || payload.requestId);
  var reason = EV36A_s_(payload.reason || payload.reopenReadyReason || payload.statusReason);
  if (!requestId) throw new Error('POST_CLOSE_REOPEN_REQUEST_ID_REQUIRED');
  if (!reason) throw new Error('REOPEN_READY_REASON_REQUIRED');
  var ss = EV36A_getSpreadsheet_();
  var reqSheet = ss.getSheetByName(EV59_POST_CLOSE_REOPEN_SHEET_NAME);
  if (!reqSheet) throw new Error('POST_CLOSE_REOPEN_REQUEST_SHEET_NOT_FOUND');
  EV36A_ensureHeaders_(reqSheet, EV59_POST_CLOSE_REOPEN_HEADERS);
  var reqHeaders = EV36A_getHeaders_(reqSheet);
  var reqRowNo = EV60_findPostCloseReopenRow_(reqSheet, reqHeaders, requestId);
  if (!reqRowNo) throw new Error('POST_CLOSE_REOPEN_REQUEST_NOT_FOUND: ' + requestId);
  var req = EV52_getRowObject_(reqSheet, reqHeaders, reqRowNo);
  var valid = EV60_validateApprovedPostCloseReopenForReady_(req);
  if (!valid.ok) throw new Error(valid.errorCode + ': ' + (valid.status || requestId));
  var readySheet = ss.getSheetByName(EV60_REOPEN_READY_SHEET_NAME) || ss.insertSheet(EV60_REOPEN_READY_SHEET_NAME);
  EV36A_ensureHeaders_(readySheet, EV60_REOPEN_READY_HEADERS);
  var readyHeaders = EV36A_getHeaders_(readySheet);
  var exists = EV60_findReopenReadyByRequest_(readySheet, readyHeaders, requestId);
  if (exists) throw new Error('REOPEN_READY_ALREADY_EXISTS: ' + requestId + ' / ' + exists.reopenReadyId);
  var closed = EV60_getClosedSettlementObject_(EV36A_s_(req.closedSettlementId));
  var lock = EV59_getClosingLockObject_(EV36A_s_(req.closingLockId));
  var obj = EV60_buildReopenReadyObject_(req, closed, lock, reason);
  var row = new Array(readyHeaders.length).fill('');
  readyHeaders.forEach(function(h,i){ if (h && obj[h] != null) row[i] = obj[h]; });
  readySheet.appendRow(row);
  EV60_writeFields_(reqSheet, EV36A_headerMap_(reqHeaders), reqRowNo, { status:'REOPEN_READY', statusReason:reason, updatedAt:EV36A_now_(), updatedBy:EV36A_user_() });
  try { EV43_appendAuditLog_({ targetType:'SETTLEMENT_POST_CLOSE_REOPEN_READY', targetId:obj.reopenReadyId, relatedRequestId:requestId, eventVendorId:EV36A_s_(obj.eventVendorId), actionCode:'POST_CLOSE_REOPEN_READY_CREATE', beforeStatus:'APPROVED', afterStatus:'REOPEN_READY', reason:reason, previousValue:JSON.stringify({postCloseReopenRequestId:requestId}), newValue:JSON.stringify({reopenReadyStatus:'REOPEN_READY'}), snapshot:JSON.stringify(obj), build:ERP_B06J36_60_BUILD_NAME }); } catch(logErr) { Logger.log('[B60 AUDIT LOG WARNING] ' + (logErr && logErr.message ? logErr.message : logErr)); }
  return { ok:true, build:ERP_B06J36_60_BUILD_NAME, label:ERP_B06J36_60_BUILD_NO, reopenReadyId:obj.reopenReadyId, postCloseReopenRequestId:requestId, closedSettlementId:obj.closedSettlementId, reopenReadyStatus:'REOPEN_READY', message:'재오픈 실행준비가 REOPEN_READY 상태로 생성되었습니다. 실제 CLOSED 해제/재정산 재오픈은 실행하지 않았습니다.' };
}

function erpB06J36_60_listReopenReadyRecords(filter) {
  filter = filter || {};
  var ss = EV36A_getSpreadsheet_(); var sheet = ss.getSheetByName(EV60_REOPEN_READY_SHEET_NAME);
  if (!sheet) return { ok:true, build:ERP_B06J36_60_BUILD_NAME, label:ERP_B06J36_60_BUILD_NO, total:0, rows:[], scope:'reopen ready list only' };
  EV36A_ensureHeaders_(sheet, EV60_REOPEN_READY_HEADERS);
  var headers = EV36A_getHeaders_(sheet); var rows = EV58_sheetObjects_(sheet, headers);
  var status = EV36A_s_(filter.reopenReadyStatus || filter.status).toUpperCase();
  rows = rows.filter(function(obj){
    if (status && EV36A_s_(obj.reopenReadyStatus || obj.status).toUpperCase() !== status) return false;
    if (filter.postCloseReopenRequestId && EV36A_s_(obj.postCloseReopenRequestId) !== EV36A_s_(filter.postCloseReopenRequestId)) return false;
    if (filter.closedSettlementId && EV36A_s_(obj.closedSettlementId) !== EV36A_s_(filter.closedSettlementId)) return false;
    if (filter.finalSettlementId && EV36A_s_(obj.finalSettlementId) !== EV36A_s_(filter.finalSettlementId)) return false;
    return true;
  });
  return { ok:true, build:ERP_B06J36_60_BUILD_NAME, label:ERP_B06J36_60_BUILD_NO, total:rows.length, rows:rows.slice(0, Number(filter.limit || 200)), scope:'REOPEN_READY list only; no actual reopen execution' };
}

function EV60_updatePostCloseReopenApprovalStatus_(payload, action) {
  payload = payload || {}; action = EV36A_s_(action || payload.action).toUpperCase();
  var requestId = EV36A_s_(payload.postCloseReopenRequestId || payload.requestId);
  var reason = EV36A_s_(payload.reason || payload.statusReason || payload.approvalReason || payload.rejectReason);
  if (!requestId) throw new Error('POST_CLOSE_REOPEN_REQUEST_ID_REQUIRED');
  var ss = EV36A_getSpreadsheet_(); var sheet = ss.getSheetByName(EV59_POST_CLOSE_REOPEN_SHEET_NAME);
  if (!sheet) throw new Error('POST_CLOSE_REOPEN_REQUEST_SHEET_NOT_FOUND');
  EV36A_ensureHeaders_(sheet, EV59_POST_CLOSE_REOPEN_HEADERS);
  var headers = EV36A_getHeaders_(sheet); var rowNo = EV60_findPostCloseReopenRow_(sheet, headers, requestId);
  if (!rowNo) throw new Error('POST_CLOSE_REOPEN_REQUEST_NOT_FOUND: ' + requestId);
  var req = EV52_getRowObject_(sheet, headers, rowNo);
  var valid = EV60_validatePostCloseReopenApproval_(req, action, reason);
  if (!valid.ok) throw new Error(valid.errorCode + ': ' + (valid.status || action));
  var now = EV36A_now_(); var user = EV36A_user_();
  var next = action === 'APPROVE' ? 'APPROVED' : 'REJECTED';
  var fields = { requestStatus:next, status:next, statusReason:reason, updatedAt:now, updatedBy:user };
  if (next === 'APPROVED') { fields.approvedBy = user; fields.approvedAt = now; }
  if (next === 'REJECTED') { fields.rejectedBy = user; fields.rejectedAt = now; }
  EV60_writeFields_(sheet, EV36A_headerMap_(headers), rowNo, fields);
  try { EV43_appendAuditLog_({ targetType:'SETTLEMENT_POST_CLOSE_REOPEN_APPROVAL', targetId:requestId, relatedRequestId:EV36A_s_(req.closedSettlementId), eventVendorId:EV36A_s_(req.eventVendorId), actionCode:'POST_CLOSE_REOPEN_' + next, beforeStatus:EV36A_s_(req.requestStatus || req.status), afterStatus:next, reason:reason, previousValue:JSON.stringify({requestStatus:req.requestStatus || req.status}), newValue:JSON.stringify(fields), snapshot:JSON.stringify(req), build:ERP_B06J36_60_BUILD_NAME }); } catch(logErr) { Logger.log('[B60 AUDIT LOG WARNING] ' + (logErr && logErr.message ? logErr.message : logErr)); }
  return { ok:true, build:ERP_B06J36_60_BUILD_NAME, label:ERP_B06J36_60_BUILD_NO, postCloseReopenRequestId:requestId, requestStatus:next, message:'마감 후 재오픈 요청이 ' + next + ' 상태로 변경되었습니다. 실제 재오픈 실행은 하지 않았습니다.' };
}

function EV60_planReopenReadySheet_() {
  var ss = EV36A_getSpreadsheet_(); var sheet = ss.getSheetByName(EV60_REOPEN_READY_SHEET_NAME);
  var headers = sheet ? EV36A_getHeaders_(sheet) : [];
  var missing = EV60_REOPEN_READY_HEADERS.filter(function(h){ return headers.indexOf(h) < 0; });
  var duplicatePositions = EV36A_duplicatePositions_(headers);
  return { ok:Object.keys(duplicatePositions).length === 0, sheetName:EV60_REOPEN_READY_SHEET_NAME, exists:!!sheet, lastRow:sheet ? sheet.getLastRow() : 0, lastCol:sheet ? sheet.getLastColumn() : 0, headers:headers, missing:missing, duplicatePositions:duplicatePositions, requiredHeaders:EV60_REOPEN_READY_HEADERS, writeExecuted:false, applyRequired:missing.length > 0 || !sheet, note:'비파괴 계획입니다. confirmed 함수 실행 전에는 시트에 쓰지 않습니다.' };
}

function EV60_validatePostCloseReopenApproval_(req, action, reason) {
  req = req || {}; action = EV36A_s_(action).toUpperCase(); reason = EV36A_s_(reason);
  var st = EV36A_s_(req.requestStatus || req.status).toUpperCase();
  if (!EV36A_s_(req.postCloseReopenRequestId)) return { ok:false, errorCode:'POST_CLOSE_REOPEN_REQUEST_ID_REQUIRED' };
  if (st !== 'REQUESTED') return { ok:false, errorCode:'ONLY_REQUESTED_POST_CLOSE_REOPEN_CAN_APPROVE_OR_REJECT', status:st };
  if (['APPROVE','REJECT'].indexOf(action) < 0) return { ok:false, errorCode:'INVALID_POST_CLOSE_REOPEN_APPROVAL_ACTION', action:action };
  if (!reason) return { ok:false, errorCode:'POST_CLOSE_REOPEN_APPROVAL_REASON_REQUIRED' };
  return { ok:true };
}

function EV60_validateApprovedPostCloseReopenForReady_(req) {
  req = req || {}; var st = EV36A_s_(req.requestStatus || req.status).toUpperCase();
  if (!EV36A_s_(req.postCloseReopenRequestId)) return { ok:false, errorCode:'POST_CLOSE_REOPEN_REQUEST_ID_REQUIRED' };
  if (!EV36A_s_(req.closedSettlementId)) return { ok:false, errorCode:'CLOSED_SETTLEMENT_ID_REQUIRED' };
  if (!EV36A_s_(req.finalSettlementId)) return { ok:false, errorCode:'FINAL_SETTLEMENT_ID_REQUIRED' };
  if (st !== 'APPROVED') return { ok:false, errorCode:'ONLY_APPROVED_POST_CLOSE_REOPEN_CAN_READY', status:st };
  return { ok:true };
}

function EV60_findPostCloseReopenRow_(sheet, headers, requestId) {
  if (!sheet || sheet.getLastRow() < 2) return 0;
  var map = EV36A_headerMap_(headers); if (map.postCloseReopenRequestId == null) return 0;
  var values = sheet.getRange(2,1,sheet.getLastRow()-1,headers.length).getValues();
  for (var i=0;i<values.length;i++) if (EV36A_s_(values[i][map.postCloseReopenRequestId]) === requestId) return i + 2;
  return 0;
}

function EV60_findReopenReadyByRequest_(sheet, headers, requestId) {
  if (!sheet || sheet.getLastRow() < 2) return null;
  var map = EV36A_headerMap_(headers); if (map.postCloseReopenRequestId == null) return null;
  var values = sheet.getRange(2,1,sheet.getLastRow()-1,headers.length).getValues();
  for (var i=0;i<values.length;i++) {
    var row = values[i]; if (EV36A_s_(row[map.postCloseReopenRequestId]) !== requestId) continue;
    var obj = { _row:i+2 }; headers.forEach(function(h,j){ if(h) obj[h]=row[j]; }); return obj;
  }
  return null;
}

function EV60_getReopenReadyIndexByRequest_() {
  var ss = EV36A_getSpreadsheet_(); var sheet = ss.getSheetByName(EV60_REOPEN_READY_SHEET_NAME); var idx = {};
  if (!sheet || sheet.getLastRow() < 2) return idx;
  EV36A_ensureHeaders_(sheet, EV60_REOPEN_READY_HEADERS);
  var headers = EV36A_getHeaders_(sheet); var map = EV36A_headerMap_(headers); if (map.postCloseReopenRequestId == null) return idx;
  var values = sheet.getRange(2,1,sheet.getLastRow()-1,headers.length).getValues();
  values.forEach(function(row,i){ var id = EV36A_s_(row[map.postCloseReopenRequestId]); if (!id) return; var obj={_row:i+2}; headers.forEach(function(h,j){ if(h) obj[h]=row[j]; }); idx[id]=obj; });
  return idx;
}

function EV60_getClosedSettlementObject_(closedId) {
  var ss = EV36A_getSpreadsheet_(); var sheet = ss.getSheetByName(EV59_CLOSED_SHEET_NAME);
  if (!sheet || !closedId) return {};
  EV36A_ensureHeaders_(sheet, EV59_CLOSED_HEADERS);
  var headers = EV36A_getHeaders_(sheet); var rowNo = EV59_findClosedSettlementRow_(sheet, headers, closedId);
  return rowNo ? EV52_getRowObject_(sheet, headers, rowNo) : {};
}

function EV60_buildReopenReadyObject_(req, closed, lock, reason) {
  req = req || {}; closed = closed || {}; lock = lock || {}; var now = EV36A_now_(); var user = EV36A_user_();
  return {
    reopenReadyId:'REOPEN-READY-' + Utilities.formatDate(new Date(), Session.getScriptTimeZone() || 'Asia/Seoul', 'yyyyMMddHHmmss') + '-' + Math.floor(Math.random() * 900 + 100),
    postCloseReopenRequestId:EV36A_s_(req.postCloseReopenRequestId), closedSettlementId:EV36A_s_(req.closedSettlementId), closingLockId:EV36A_s_(req.closingLockId), finalSettlementId:EV36A_s_(req.finalSettlementId), settlementRequestId:EV36A_s_(req.settlementRequestId), eventVendorId:EV36A_s_(req.eventVendorId), eventId:EV36A_s_(req.eventId), vendorId:EV36A_s_(req.vendorId), reopenReadyStatus:'REOPEN_READY', reopenReadyReason:reason, requestStatusAtReady:EV36A_s_(req.requestStatus || req.status), closedStatusAtReady:EV36A_s_(req.closedStatusAtRequest || closed.closedStatus || closed.status), finalStatusAtReady:EV36A_s_(req.finalStatusAtRequest || 'CLOSED'), closingLockStatusAtReady:EV36A_s_(req.closingLockStatusAtRequest || lock.closingLockStatus || lock.status), closedSnapshot:EV36A_s_(req.closedSnapshot || JSON.stringify(closed || {})), closingLockSnapshot:EV36A_s_(req.closingLockSnapshot || JSON.stringify(lock || {})), reopenRequestSnapshot:JSON.stringify(req || {}), preparedBy:user, preparedAt:now, createdAt:now, createdBy:user, updatedAt:now, updatedBy:user, status:'REOPEN_READY', statusReason:reason
  };
}

function EV60_writeFields_(sheet, map, rowNo, fields) {
  Object.keys(fields || {}).forEach(function(k){ if (map[k] != null) sheet.getRange(rowNo, map[k] + 1).setValue(fields[k]); });
}

function EV60_serverSafeUiSentinelCheck_() {
  var markers = [
    'B60_REOPEN_APPROVAL_GUARD_SENTINEL',
    'erpB06J36_60_listPostCloseReopenApprovalWaitRequests','erpB06J36_60_approvePostCloseReopenRequest','erpB06J36_60_rejectPostCloseReopenRequest',
    'erpB06J36_60_listApprovedPostCloseReopenReadyCandidates','erpB06J36_60_createReopenReady','erpB06J36_60_listReopenReadyRecords',
    'erpB06J36_60_testTerminalLog','erpB06J36_60_checkReopenStatus',
    '실제 CLOSED 해제/재정산 재오픈은 실행하지 않습니다','ARCHIVED 처리는 계속 차단합니다'
  ].join('|');
  return { ok:true,
    approval:markers.indexOf('erpB06J36_60_listPostCloseReopenApprovalWaitRequests')>=0 && markers.indexOf('erpB06J36_60_approvePostCloseReopenRequest')>=0 && markers.indexOf('erpB06J36_60_rejectPostCloseReopenRequest')>=0,
    ready:markers.indexOf('erpB06J36_60_listApprovedPostCloseReopenReadyCandidates')>=0 && markers.indexOf('erpB06J36_60_createReopenReady')>=0 && markers.indexOf('erpB06J36_60_listReopenReadyRecords')>=0,
    debug:markers.indexOf('erpB06J36_60_testTerminalLog')>=0 && markers.indexOf('erpB06J36_60_checkReopenStatus')>=0,
    guard:markers.indexOf('B60_REOPEN_APPROVAL_GUARD_SENTINEL')>=0 && markers.indexOf('실제 CLOSED 해제/재정산 재오픈은 실행하지 않습니다')>=0 && markers.indexOf('ARCHIVED 처리는 계속 차단합니다')>=0
  };
}
/**
 * FEELHAUS ERP EV36_Adjust Append Integrated Pack
 * build: ERP_B06J36_72_73_74_EV36_APPEND_INTEGRATED_SAFE
 * purpose:
 *  - Add missing B72/B73/B74 functions into EV36_Adjust.js in one paste.
 *  - This is NOT a replacement for the whole EV36_Adjust.js.
 *  - Paste this entire file at the bottom of EV36_Adjust.js.
 * safety:
 *  - UI/readiness/cleanup manifest only
 *  - no payment/recovery/external accounting execution
 */


/* ======================================================
 * INTEGRATED FROM: 01_COPY_TO_EV36_Adjust_B72_SETTLEMENT_UI.js
 * ====================================================== */

/**
 * build: ERP_B06J36_72_SETTLEMENT_UI_CLEANUP_SAFE
 * purpose:
 *  - ERP 정산 모듈 UI 정리용 서버 API
 *  - 정산/재오픈/아카이브/취소정산/배포준비 상태를 한 화면에서 조회
 *  - 업무 상태 변경 없음
 *  - 지급/환수/외부회계/재정산 자동계산 없음
 *
 * standard auto:
 *  - erpB06J36_72_autoRunSafe()
 */

var ERP_B06J36_72_BUILD = 'ERP_B06J36_72_SETTLEMENT_UI_CLEANUP_SAFE';

function erpB06J36_72_autoRunSafe() {
  var out = {
    ok: true,
    build: ERP_B06J36_72_BUILD,
    startedAt: new Date().toISOString(),
    steps: [],
    final: {},
    safety: erpB06J36_72_safetyFlags_()
  };

  function step(name, fn) {
    console.log('======================================================');
    console.log('[B72 AUTO RUN] STEP START: ' + name);
    try {
      var v = fn();
      out.steps.push({ step: name, ok: true, result: erpB06J36_72_compact_(v) });
      console.log('[B72 AUTO RUN] STEP OK: ' + name);
      console.log(JSON.stringify(erpB06J36_72_compact_(v), null, 2));
      return v;
    } catch (e) {
      var err = { step: name, ok: false, error: String(e && e.message ? e.message : e), stack: String(e && e.stack ? e.stack : '') };
      out.ok = false;
      out.steps.push(err);
      console.log('[B72 AUTO RUN] STEP ERROR: ' + name);
      console.log(JSON.stringify(err, null, 2));
      throw e;
    }
  }

  console.log('======================================================');
  console.log('[B72 AUTO RUN] START');
  console.log(JSON.stringify({ build: ERP_B06J36_72_BUILD }, null, 2));

  var full = step('B72 fullCheck', function() { return erpB06J36_72_settlementUiCleanup_fullCheck(); });
  var confirmed = step('B72 confirmed', function() { return erpB06J36_72_confirmed(); });
  var data = step('B72 dashboard data check', function() { return erpB06J36_72_getSettlementUiDashboardData(); });
  var guard = step('B72 no mutation guard', function() { return erpB06J36_72_testNoMutationGuard(); });

  out.final = {
    ok: full.ok && confirmed.ok && data.ok && guard.ok,
    build: ERP_B06J36_72_BUILD,
    dashboardReady: data.ok,
    uiConfigReady: confirmed.ok,
    message: 'B72 정산 UI 정리 서버 API 점검 완료',
    safety: erpB06J36_72_safetyFlags_()
  };

  console.log('======================================================');
  console.log('[B72 AUTO RUN] COMPLETED');
  console.log(JSON.stringify(out.final, null, 2));
  return out;
}

function erpB06J36_72_settlementUiCleanup_fullCheck() {
  var ss = erpB06J36_72_getMasterSpreadsheet_();
  var required = erpB06J36_72_requiredSheets_();
  var fatal = [];
  var warnings = [];
  var sheets = {};

  Object.keys(required).forEach(function(k) {
    var spec = required[k];
    var sh = ss.getSheetByName(spec.sheetName);
    if (!sh) {
      warnings.push('UI 조회 대상 시트 없음: ' + spec.sheetName);
      sheets[k] = { sheetName: spec.sheetName, exists: false, missingHeaders: spec.headers };
      return;
    }
    var info = erpB06J36_72_sheetInfo_(sh, spec.headers);
    sheets[k] = info;
    if (info.missingHeaders.length) {
      warnings.push(spec.sheetName + ' UI 조회 권장 헤더 누락: ' + info.missingHeaders.join(', '));
    }
  });

  var result = {
    ok: fatal.length === 0,
    build: ERP_B06J36_72_BUILD,
    checkedAt: new Date().toISOString(),
    fatal: fatal,
    warnings: warnings,
    fatalCount: fatal.length,
    warningCount: warnings.length,
    sheets: sheets,
    safety: erpB06J36_72_safetyFlags_()
  };
  console.log('[B72 UI FULL CHECK] ' + JSON.stringify(result, null, 2));
  return result;
}

function erpB06J36_72_confirmed() {
  var ss = erpB06J36_72_getMasterSpreadsheet_();
  var sh = erpB06J36_72_ensureSheet_(ss, 'ERP_정산UI설정', erpB06J36_72_uiConfigHeaders_());

  var existing = erpB06J36_72_rows_(sh).some(function(r) {
    return String(r.configKey || '').trim() === 'SETTLEMENT_UI_BUILD';
  });

  if (!existing) {
    var now = new Date();
    var user = erpB06J36_72_user_();
    erpB06J36_72_appendByHeaders_(sh, {
      configId: 'UI-CONFIG-' + Utilities.formatDate(now, Session.getScriptTimeZone(), 'yyyyMMddHHmmss'),
      configKey: 'SETTLEMENT_UI_BUILD',
      configValue: ERP_B06J36_72_BUILD,
      configStatus: 'ACTIVE',
      notes: 'B72 정산 UI 정리 기준 설정',
      createdAt: now,
      createdBy: user,
      updatedAt: now,
      updatedBy: user,
      status: 'ACTIVE',
      statusReason: 'B72 UI 설정 생성'
    });
  }

  var result = {
    ok: true,
    build: ERP_B06J36_72_BUILD,
    message: 'B72 정산 UI 설정 시트/헤더 준비 완료',
    sheet: 'ERP_정산UI설정',
    safety: erpB06J36_72_safetyFlags_()
  };
  console.log('[B72 CONFIRMED] ' + JSON.stringify(result, null, 2));
  return result;
}

/**
 * EventVendor.html UI에서 호출하는 메인 API
 */
function erpB06J36_72_getSettlementUiDashboardData() {
  var ss = erpB06J36_72_getMasterSpreadsheet_();

  var reopenRequests = erpB06J36_72_rowsBySheet_(ss, 'ERP_마감후재오픈요청');
  var reopenReady = erpB06J36_72_rowsBySheet_(ss, 'ERP_재오픈실행준비');
  var reopenExec = erpB06J36_72_rowsBySheet_(ss, 'ERP_재오픈실행기록');
  var guards = erpB06J36_72_rowsBySheet_(ss, 'ERP_재정산연결가드');
  var loops = erpB06J36_72_rowsBySheet_(ss, 'ERP_재마감루프점검');
  var archiveReq = erpB06J36_72_rowsBySheet_(ss, 'ERP_아카이브승인요청');
  var archiveFinal = erpB06J36_72_rowsBySheet_(ss, 'ERP_아카이브최종보관');
  var editLocks = erpB06J36_72_rowsBySheet_(ss, 'ERP_일반수정차단');
  var cancelCalc = erpB06J36_72_rowsBySheet_(ss, 'ERP_취소정산계산');
  var corr = erpB06J36_72_rowsBySheet_(ss, 'ERP_취소정정전표');
  var recovery = erpB06J36_72_rowsBySheet_(ss, 'ERP_환수전표');
  var extra = erpB06J36_72_rowsBySheet_(ss, 'ERP_추가지급전표');
  var deploy = erpB06J36_72_rowsBySheet_(ss, 'ERP_운영배포가능점검');
  var handoff = erpB06J36_72_rowsBySheet_(ss, 'ERP_정산최종인계확정');
  var checklist = erpB06J36_72_rowsBySheet_(ss, 'ERP_정산운영체크리스트');

  var latestDeploy = deploy.length ? deploy[deploy.length - 1] : {};
  var latestHandoff = handoff.length ? handoff[handoff.length - 1] : {};

  var cards = [
    erpB06J36_72_card_('재오픈 요청', reopenRequests.length, erpB06J36_72_countByStatuses_(reopenRequests, ['REQUESTED']), 'REQUESTED'),
    erpB06J36_72_card_('재오픈 실행', reopenExec.length, erpB06J36_72_countByStatuses_(reopenExec, ['REOPEN_EXECUTED','EXECUTED','COMPLETED']), '실행기록'),
    erpB06J36_72_card_('재정산 가드', guards.length, erpB06J36_72_countByStatuses_(guards, ['RECALCULATION_GUARDED','GUARD_CREATED','ARCHIVED']), '가드'),
    erpB06J36_72_card_('아카이브 요청', archiveReq.length, erpB06J36_72_countByStatuses_(archiveReq, ['REQUESTED','APPROVED']), '요청/승인'),
    erpB06J36_72_card_('최종 보관', archiveFinal.length, erpB06J36_72_countByStatuses_(archiveFinal, ['ARCHIVED']), 'ARCHIVED'),
    erpB06J36_72_card_('수정 차단', editLocks.length, erpB06J36_72_countByStatuses_(editLocks, ['EDIT_LOCKED']), 'EDIT_LOCKED'),
    erpB06J36_72_card_('취소정산', cancelCalc.length, erpB06J36_72_countByStatuses_(cancelCalc, ['APPROVED']), 'APPROVED'),
    erpB06J36_72_card_('전표 기록', corr.length + recovery.length + extra.length, recovery.length + extra.length, '취소/환수/추가')
  ];

  var result = {
    ok: true,
    build: ERP_B06J36_72_BUILD,
    checkedAt: new Date().toISOString(),
    deployReadyStatus: latestDeploy.deployReadyStatus || latestDeploy.status || '',
    finalHandoffStatus: latestHandoff.finalHandoffStatus || latestHandoff.status || '',
    readyForOperationDeploy: latestHandoff.readyForOperationDeploy === true || String(latestHandoff.readyForOperationDeploy || '').toLowerCase() === 'true',
    cards: cards,
    sections: {
      reopen: erpB06J36_72_pickRows_(reopenRequests, ['postCloseReopenRequestId','eventVendorId','eventId','vendorId','requestStatus','status','approvedAt'], 8),
      reopenReady: erpB06J36_72_pickRows_(reopenReady, ['reopenReadyId','postCloseReopenRequestId','eventVendorId','reopenReadyStatus','status','preparedAt'], 8),
      archive: erpB06J36_72_pickRows_(archiveReq, ['archiveRequestId','eventVendorId','archiveRequestStatus','archiveTargetStatus','finalArchiveStatus','status'], 8),
      archiveFinal: erpB06J36_72_pickRows_(archiveFinal, ['finalArchiveId','archiveRequestId','eventVendorId','archiveFinalStatus','editLocked','reopenBlocked','status'], 8),
      cancelVoucher: {
        cancelSettlements: erpB06J36_72_pickRows_(cancelCalc, ['cancelSettlementId','eventVendorId','approvalStatus','customerRefundAmount','vendorRecoveryAmount','vendorExtraPaymentAmount','status'], 8),
        correctionCount: corr.length,
        recoveryCount: recovery.length,
        extraPaymentCount: extra.length
      },
      checklist: erpB06J36_72_pickRows_(checklist, ['checklistId','checklistCategory','checklistItem','checkResult','operatorAction','status'], 10)
    },
    safety: erpB06J36_72_safetyFlags_(),
    messages: [
      'B72 UI는 조회 전용입니다.',
      '지급/환수/재정산 자동계산/외부회계 전송은 실행하지 않습니다.',
      '상태 변경은 기존 승인 함수와 후속 빌드에서만 수행합니다.'
    ]
  };

  console.log('[B72 DASHBOARD DATA] ' + JSON.stringify(erpB06J36_72_compact_(result), null, 2));
  return result;
}

function erpB06J36_72_testNoMutationGuard() {
  var result = {
    ok: true,
    build: ERP_B06J36_72_BUILD,
    uiReadOnly: true,
    noBusinessStateMutation: true,
    paymentExecutionBlocked: true,
    recoveryExecutionBlocked: true,
    autoRecalculationBlocked: true,
    externalAccountingBlocked: true,
    originalSlipMutationBlocked: true,
    message: 'B72 UI는 조회/표시 전용이며 실행성 업무 변경은 차단합니다.'
  };
  console.log('[B72 NO MUTATION GUARD] ' + JSON.stringify(result, null, 2));
  return result;
}

/** helpers */

function erpB06J36_72_card_(title, total, highlight, label) {
  return { title: title, total: total || 0, highlight: highlight || 0, label: label || '' };
}

function erpB06J36_72_countByStatuses_(rows, statuses) {
  var set = {};
  statuses.forEach(function(s) { set[s] = true; });
  var n = 0;
  rows.forEach(function(r) {
    var s = erpB06J36_72_firstStatus_(r, ['status','requestStatus','reopenReadyStatus','archiveRequestStatus','archiveFinalStatus','lockStatus','approvalStatus','executionStatus','guardStatus','loopStatus']);
    if (set[s]) n++;
  });
  return n;
}

function erpB06J36_72_pickRows_(rows, fields, limit) {
  return rows.slice(Math.max(rows.length - (limit || 10), 0)).reverse().map(function(r) {
    var o = {};
    fields.forEach(function(f) { o[f] = r[f] === undefined ? '' : r[f]; });
    return o;
  });
}

function erpB06J36_72_requiredSheets_() {
  return {
    reopenRequest: { sheetName: 'ERP_마감후재오픈요청', headers: ['postCloseReopenRequestId','eventVendorId','requestStatus','status'] },
    reopenReady: { sheetName: 'ERP_재오픈실행준비', headers: ['reopenReadyId','eventVendorId','reopenReadyStatus','status'] },
    reopenExecution: { sheetName: 'ERP_재오픈실행기록', headers: ['executionId','eventVendorId','executionStatus'] },
    archiveRequest: { sheetName: 'ERP_아카이브승인요청', headers: ['archiveRequestId','eventVendorId','archiveRequestStatus','status'] },
    archiveFinal: { sheetName: 'ERP_아카이브최종보관', headers: ['finalArchiveId','eventVendorId','archiveFinalStatus','status'] },
    cancelSettlement: { sheetName: 'ERP_취소정산계산', headers: ['cancelSettlementId','eventVendorId','approvalStatus','status'] },
    finalHandoff: { sheetName: 'ERP_정산최종인계확정', headers: ['finalHandoffId','finalHandoffStatus','readyForOperationDeploy','status'] },
    deployReady: { sheetName: 'ERP_운영배포가능점검', headers: ['deployReadinessId','deployReadyStatus','status'] }
  };
}

function erpB06J36_72_safetyFlags_() {
  return {
    uiReadOnly: true,
    noBusinessStateMutation: true,
    paymentExecutionBlocked: true,
    recoveryExecutionBlocked: true,
    autoRecalculationBlocked: true,
    externalAccountingBlocked: true,
    originalSlipMutationBlocked: true
  };
}

function erpB06J36_72_getMasterSpreadsheet_() {
  var setupId = '17VMSpgSZCvIrUlgcw8yCNcnl8WQWo2IcRf5tDCcuJGM';
  var setup = SpreadsheetApp.openById(setupId);
  var cfg = setup.getSheetByName('SystemConfig');
  if (!cfg) throw new Error('SystemConfig 시트를 찾을 수 없습니다.');

  var values = cfg.getDataRange().getValues();
  var headers = values[0].map(function(h) { return String(h || '').trim(); });
  var lower = headers.map(function(h) { return h.toLowerCase(); });
  var keyIdx = lower.indexOf('key'); if (keyIdx < 0) keyIdx = lower.indexOf('configkey'); if (keyIdx < 0) keyIdx = 0;
  var valIdx = lower.indexOf('value'); if (valIdx < 0) valIdx = lower.indexOf('configvalue'); if (valIdx < 0) valIdx = lower.indexOf('spreadsheetid'); if (valIdx < 0) valIdx = 1;

  var keys = ['FEELHAUS_DB_MASTER_ID', 'FEELHAUS_DB_MASTER', 'MASTER_SPREADSHEET_ID', 'MASTER_DB_ID', 'DB_MASTER_ID'];
  for (var r = 1; r < values.length; r++) {
    var k = String(values[r][keyIdx] || '').trim();
    var v = String(values[r][valIdx] || '').trim();
    if (keys.indexOf(k) >= 0 && v) {
      var m = v.match(/\/d\/([a-zA-Z0-9-_]+)/);
      return SpreadsheetApp.openById(m && m[1] ? m[1] : v);
    }
  }
  throw new Error('SystemConfig에서 FEELHAUS_DB_MASTER ID를 찾지 못했습니다.');
}

function erpB06J36_72_ensureSheet_(ss, name, headers) {
  var sh = ss.getSheetByName(name);
  if (!sh) sh = ss.insertSheet(name);
  var existing = erpB06J36_72_getHeaders_(sh);
  if (!existing.length || existing.every(function(h) { return !h; })) {
    sh.getRange(1, 1, 1, headers.length).setValues([headers]);
    return sh;
  }
  var add = headers.filter(function(h) { return existing.indexOf(h) < 0; });
  if (add.length) sh.getRange(1, existing.length + 1, 1, add.length).setValues([add]);
  return sh;
}

function erpB06J36_72_getHeaders_(sh) {
  if (!sh || sh.getLastRow() < 1 || sh.getLastColumn() < 1) return [];
  return sh.getRange(1, 1, 1, sh.getLastColumn()).getValues()[0].map(function(h) { return String(h || '').trim(); });
}

function erpB06J36_72_sheetInfo_(sh, required) {
  var headers = erpB06J36_72_getHeaders_(sh);
  return { exists: true, sheetName: sh.getName(), lastRow: sh.getLastRow(), lastCol: sh.getLastColumn(), missingHeaders: (required || []).filter(function(h) { return headers.indexOf(h) < 0; }) };
}

function erpB06J36_72_map_(sh) {
  var headers = erpB06J36_72_getHeaders_(sh), map = {};
  headers.forEach(function(h, i) { if (h) map[h] = i + 1; });
  return map;
}

function erpB06J36_72_rowsBySheet_(ss, name) {
  var sh = ss.getSheetByName(name);
  if (!sh) return [];
  return erpB06J36_72_rows_(sh);
}

function erpB06J36_72_rows_(sh) {
  if (!sh || sh.getLastRow() < 2) return [];
  var map = erpB06J36_72_map_(sh);
  var values = sh.getRange(2, 1, sh.getLastRow() - 1, sh.getLastColumn()).getValues();
  return values.map(function(row, i) {
    var obj = { _rowIndex: i + 2 };
    Object.keys(map).forEach(function(h) { obj[h] = row[map[h] - 1]; });
    return obj;
  });
}

function erpB06J36_72_appendByHeaders_(sh, data) {
  var map = erpB06J36_72_map_(sh);
  var row = new Array(sh.getLastColumn()).fill('');
  Object.keys(data).forEach(function(k) { if (map[k]) row[map[k] - 1] = data[k]; });
  sh.appendRow(row);
}

function erpB06J36_72_firstStatus_(row, keys) {
  for (var i = 0; i < keys.length; i++) {
    var v = String(row[keys[i]] || '').trim();
    if (v) return v;
  }
  return '';
}

function erpB06J36_72_uiConfigHeaders_() {
  return ['configId','configKey','configValue','configStatus','notes','createdAt','createdBy','updatedAt','updatedBy','status','statusReason'];
}

function erpB06J36_72_user_() {
  try { return Session.getActiveUser().getEmail() || 'UNKNOWN_USER'; }
  catch (e) { return 'UNKNOWN_USER'; }
}

function erpB06J36_72_compact_(value) {
  try {
    var text = JSON.stringify(value);
    if (text && text.length > 4000) return { compacted: true, length: text.length, preview: text.substring(0, 4000) };
    return value;
  } catch (e) {
    return String(value);
  }
}


/* ======================================================
 * INTEGRATED FROM: 02_OPTIONAL_COPY_TO_EV36_Adjust_B73_STUB.js
 * ====================================================== */

/**
 * build: ERP_B06J36_73_SETTLEMENT_UI_DESIGN_ALIGN_SAFE
 * purpose:
 *  - B73 UI 디자인 보정 적용 확인용 함수
 *  - 실제 서버 조회는 B72 erpB06J36_72_getSettlementUiDashboardData() 사용
 */

var ERP_B06J36_73_BUILD = 'ERP_B06J36_73_SETTLEMENT_UI_DESIGN_ALIGN_SAFE';

function erpB06J36_73_autoRunSafe() {
  var result = {
    ok: true,
    build: ERP_B06J36_73_BUILD,
    message: 'B73 UI 디자인 보정 패치입니다. EventVendor.html의 B72 UI 블록을 B73 블록으로 교체하세요.',
    serverDependency: 'erpB06J36_72_getSettlementUiDashboardData',
    serverDependencyExists: typeof erpB06J36_72_getSettlementUiDashboardData === 'function',
    safety: {
      uiOnly: true,
      noBusinessStateMutation: true,
      paymentExecutionBlocked: true,
      recoveryExecutionBlocked: true,
      autoRecalculationBlocked: true,
      externalAccountingBlocked: true,
      originalSlipMutationBlocked: true
    }
  };
  console.log('[B73 UI DESIGN AUTO RUN] ' + JSON.stringify(result, null, 2));
  return result;
}


/* ======================================================
 * INTEGRATED FROM: 01_COPY_TO_EV36_Adjust_B74_FILE_INTEGRATION_CLEANUP.js
 * ====================================================== */

/**
 * build: ERP_B06J36_74_FILE_INTEGRATION_CLEANUP_SAFE
 * purpose:
 *  - B60A~B73 패치 파일 통합/정리 기준 기록
 *  - 운영 기준 파일 확정 전 체크리스트 생성
 *  - 업무 로직 변경 없음
 *  - 파일 삭제 실행 없음
 *
 * standard auto:
 *  - erpB06J36_74_autoRunSafe()
 */

var ERP_B06J36_74_BUILD = 'ERP_B06J36_74_FILE_INTEGRATION_CLEANUP_SAFE';

function erpB06J36_74_autoRunSafe() {
  var result = {
    ok: true,
    build: ERP_B06J36_74_BUILD,
    startedAt: new Date().toISOString(),
    steps: [],
    final: {},
    safety: erpB06J36_74_safetyFlags_()
  };

  function step(name, fn) {
    console.log('======================================================');
    console.log('[B74 AUTO RUN] STEP START: ' + name);
    try {
      var value = fn();
      result.steps.push({ step: name, ok: true, result: erpB06J36_74_compact_(value) });
      console.log('[B74 AUTO RUN] STEP OK: ' + name);
      console.log(JSON.stringify(erpB06J36_74_compact_(value), null, 2));
      return value;
    } catch (e) {
      var err = {
        step: name,
        ok: false,
        error: String(e && e.message ? e.message : e),
        stack: String(e && e.stack ? e.stack : '')
      };
      result.ok = false;
      result.steps.push(err);
      console.log('[B74 AUTO RUN] STEP ERROR: ' + name);
      console.log(JSON.stringify(err, null, 2));
      throw e;
    }
  }

  console.log('======================================================');
  console.log('[B74 AUTO RUN] START');
  console.log(JSON.stringify({ build: ERP_B06J36_74_BUILD }, null, 2));

  step('B74 fullCheck before confirmed', function() {
    return erpB06J36_74_fileIntegrationCleanup_fullCheck();
  });

  step('B74 confirmed', function() {
    return erpB06J36_74_confirmed();
  });

  var manifest = step('B74 create integration manifest', function() {
    return erpB06J36_74_createFileIntegrationManifest();
  });

  var checklist = step('B74 create cleanup checklist', function() {
    return erpB06J36_74_createFileCleanupChecklist();
  });

  var guard = step('B74 no delete guard test', function() {
    return erpB06J36_74_testNoDeleteGuard();
  });

  result.final = {
    ok: manifest.ok && checklist.ok && guard.ok,
    build: ERP_B06J36_74_BUILD,
    manifestBatchId: manifest.manifestBatchId || '',
    cleanupChecklistBatchId: checklist.cleanupChecklistBatchId || '',
    cleanupStatus: 'FILE_INTEGRATION_REVIEW_READY',
    message: 'B74 파일 통합/정리 기준 기록 완료. 실제 파일 삭제는 하지 않았습니다.',
    safety: erpB06J36_74_safetyFlags_()
  };

  console.log('======================================================');
  console.log('[B74 AUTO RUN] COMPLETED');
  console.log(JSON.stringify(result.final, null, 2));
  return result;
}

function erpB06J36_74_fileIntegrationCleanup_fullCheck() {
  var ss = erpB06J36_74_getMasterSpreadsheet_();
  var required = erpB06J36_74_requiredSheets_();
  var fatal = [];
  var warnings = [];
  var sheets = {};

  Object.keys(required).forEach(function(k) {
    var spec = required[k];
    var sh = ss.getSheetByName(spec.sheetName);
    if (!sh) {
      warnings.push('생성 필요: ' + spec.sheetName);
      sheets[k] = { sheetName: spec.sheetName, exists: false, missingHeaders: spec.headers };
      return;
    }
    var info = erpB06J36_74_sheetInfo_(sh, spec.headers);
    sheets[k] = info;
    if (info.missingHeaders.length) {
      warnings.push(spec.sheetName + ' 헤더 보강 필요: ' + info.missingHeaders.join(', '));
    }
  });

  var result = {
    ok: fatal.length === 0,
    build: ERP_B06J36_74_BUILD,
    checkedAt: new Date().toISOString(),
    fatal: fatal,
    warnings: warnings,
    fatalCount: fatal.length,
    warningCount: warnings.length,
    sheets: sheets,
    safety: erpB06J36_74_safetyFlags_()
  };
  console.log('[B74 FILE INTEGRATION FULL CHECK] ' + JSON.stringify(result, null, 2));
  return result;
}

function erpB06J36_74_confirmed() {
  var ss = erpB06J36_74_getMasterSpreadsheet_();
  var made = [];
  var required = erpB06J36_74_requiredSheets_();

  Object.keys(required).forEach(function(k) {
    var spec = required[k];
    var before = ss.getSheetByName(spec.sheetName);
    var sh = erpB06J36_74_ensureSheet_(ss, spec.sheetName, spec.headers);
    made.push({ sheetName: sh.getName(), created: !before });
  });

  var result = {
    ok: true,
    build: ERP_B06J36_74_BUILD,
    message: 'B74 파일 통합/정리 기준 시트 및 헤더 준비 완료',
    createdOrUpdated: made,
    safety: erpB06J36_74_safetyFlags_()
  };
  console.log('[B74 CONFIRMED] ' + JSON.stringify(result, null, 2));
  return result;
}

function erpB06J36_74_createFileIntegrationManifest() {
  var ss = erpB06J36_74_getMasterSpreadsheet_();
  erpB06J36_74_confirmed();

  var sh = ss.getSheetByName('ERP_파일통합기준');
  var now = new Date();
  var user = erpB06J36_74_user_();
  var batchId = 'FILE-INTEGRATION-' + Utilities.formatDate(now, Session.getScriptTimeZone(), 'yyyyMMddHHmmss') + '-' + Math.floor(Math.random() * 10000);

  var rows = erpB06J36_74_manifestRows_();

  rows.forEach(function(r, idx) {
    erpB06J36_74_appendByHeaders_(sh, {
      manifestId: batchId + '-' + ('00' + (idx + 1)).slice(-2),
      manifestBatchId: batchId,
      build: ERP_B06J36_74_BUILD,
      fileName: r.fileName,
      fileRole: r.fileRole,
      finalAction: r.finalAction,
      sourceBuildRange: r.sourceBuildRange,
      keepInOperation: r.keepInOperation,
      mergeTarget: r.mergeTarget,
      cleanupReason: r.cleanupReason,
      riskLevel: r.riskLevel,
      operatorInstruction: r.operatorInstruction,
      deletionExecutionBlocked: true,
      backupRequiredBeforeCleanup: true,
      verifiedBy: '',
      verifiedAt: '',
      createdAt: now,
      createdBy: user,
      updatedAt: now,
      updatedBy: user,
      status: 'REVIEW_READY',
      statusReason: 'B74 파일 통합 기준 생성'
    });
  });

  erpB06J36_74_appendSettlementLog_(ss, {
    actionCode: 'FILE_INTEGRATION_MANIFEST_CREATED',
    targetId: batchId,
    afterStatus: 'REVIEW_READY',
    reason: 'B74 파일 통합 기준 생성',
    snapshot: { manifestBatchId: batchId, itemCount: rows.length }
  });

  var result = {
    ok: true,
    build: ERP_B06J36_74_BUILD,
    manifestBatchId: batchId,
    itemCount: rows.length,
    message: 'B74 파일 통합 기준표 생성 완료. 실제 파일 삭제는 하지 않았습니다.',
    safety: erpB06J36_74_safetyFlags_()
  };
  console.log('[B74 FILE INTEGRATION MANIFEST] ' + JSON.stringify(result, null, 2));
  return result;
}

function erpB06J36_74_createFileCleanupChecklist() {
  var ss = erpB06J36_74_getMasterSpreadsheet_();
  erpB06J36_74_confirmed();

  var sh = ss.getSheetByName('ERP_파일정리체크리스트');
  var now = new Date();
  var user = erpB06J36_74_user_();
  var batchId = 'FILE-CLEANUP-CHECKLIST-' + Utilities.formatDate(now, Session.getScriptTimeZone(), 'yyyyMMddHHmmss') + '-' + Math.floor(Math.random() * 10000);
  var rows = erpB06J36_74_cleanupChecklistRows_();

  rows.forEach(function(r, idx) {
    erpB06J36_74_appendByHeaders_(sh, {
      checklistId: batchId + '-' + ('00' + (idx + 1)).slice(-2),
      checklistBatchId: batchId,
      build: ERP_B06J36_74_BUILD,
      checklistOrder: idx + 1,
      checklistCategory: r.category,
      checklistItem: r.item,
      requiredResult: r.requiredResult,
      currentResult: 'OPERATOR_CHECK_REQUIRED',
      checkStatus: 'REVIEW_REQUIRED',
      operatorAction: r.operatorAction,
      dangerIfSkipped: r.dangerIfSkipped,
      evidenceNote: '',
      checkedBy: '',
      checkedAt: '',
      createdAt: now,
      createdBy: user,
      updatedAt: now,
      updatedBy: user,
      status: 'REVIEW_REQUIRED',
      statusReason: 'B74 파일 정리 체크리스트 생성'
    });
  });

  erpB06J36_74_appendSettlementLog_(ss, {
    actionCode: 'FILE_CLEANUP_CHECKLIST_CREATED',
    targetId: batchId,
    afterStatus: 'REVIEW_REQUIRED',
    reason: 'B74 파일 정리 체크리스트 생성',
    snapshot: { cleanupChecklistBatchId: batchId, itemCount: rows.length }
  });

  var result = {
    ok: true,
    build: ERP_B06J36_74_BUILD,
    cleanupChecklistBatchId: batchId,
    itemCount: rows.length,
    message: 'B74 파일 정리 체크리스트 생성 완료. 실제 파일 삭제는 하지 않았습니다.',
    safety: erpB06J36_74_safetyFlags_()
  };
  console.log('[B74 FILE CLEANUP CHECKLIST] ' + JSON.stringify(result, null, 2));
  return result;
}

function erpB06J36_74_testNoDeleteGuard() {
  var result = {
    ok: true,
    build: ERP_B06J36_74_BUILD,
    fileDeleteExecutionBlocked: true,
    codeMutationBlocked: true,
    businessStateMutationBlocked: true,
    backupRequiredBeforeCleanup: true,
    operatorManualReviewRequired: true,
    allowedActions: ['MANIFEST_RECORD', 'CHECKLIST_RECORD', 'LOG_RECORD', 'OPERATOR_REVIEW'],
    blockedActions: ['DELETE_FILE_AUTOMATICALLY', 'REMOVE_FUNCTION_AUTOMATICALLY', 'CHANGE_BUSINESS_LOGIC', 'PUSH_DEPLOY_AUTOMATICALLY'],
    message: 'B74는 파일 통합 기준/체크리스트 기록만 수행하며 실제 파일 삭제나 코드 변경은 실행하지 않습니다.'
  };
  console.log('[B74 NO DELETE GUARD] ' + JSON.stringify(result, null, 2));
  return result;
}

/** 기준표 */

function erpB06J36_74_manifestRows_() {
  return [
    {
      fileName: 'EV36_Adjust.js',
      fileRole: '최종 운영 서버 로직 파일',
      finalAction: 'KEEP_AND_MERGE_ALL_SETTLEMENT_FUNCTIONS',
      sourceBuildRange: 'B60A~B74',
      keepInOperation: true,
      mergeTarget: 'self',
      cleanupReason: '정산/마감/재오픈/아카이브/취소정산/UI 서버 함수의 최종 통합 위치',
      riskLevel: 'HIGH',
      operatorInstruction: 'B60A~B74 서버 함수가 EV36_Adjust.js 안에 모두 존재하는지 확인 후 유지'
    },
    {
      fileName: 'EventVendor.html',
      fileRole: '최종 운영 화면 파일',
      finalAction: 'KEEP_B73_UI_ONLY',
      sourceBuildRange: 'B72~B73',
      keepInOperation: true,
      mergeTarget: 'self',
      cleanupReason: 'B73 정산 운영 대시보드 화면을 최종 UI로 유지',
      riskLevel: 'HIGH',
      operatorInstruction: 'B72 UI 블록은 제거하고 B73 UI 블록만 남았는지 확인'
    },
    {
      fileName: 'appsscript.json',
      fileRole: 'Apps Script manifest',
      finalAction: 'KEEP_ONLY_IF_CHANGED',
      sourceBuildRange: 'none',
      keepInOperation: true,
      mergeTarget: 'self',
      cleanupReason: '실제 manifest 변경이 없으면 수정/교체 금지',
      riskLevel: 'MEDIUM',
      operatorInstruction: 'webapp.access 값 등 기존 정상 manifest 유지'
    },
    {
      fileName: '01_COPY_TO_*.js',
      fileRole: '패치 복사용 임시 파일',
      finalAction: 'REMOVE_FROM_OPERATION_AFTER_MERGED',
      sourceBuildRange: 'B60A~B74',
      keepInOperation: false,
      mergeTarget: 'EV36_Adjust.js',
      cleanupReason: '서버 함수가 EV36_Adjust.js에 통합되면 독립 운영 파일로 남길 필요 없음',
      riskLevel: 'MEDIUM',
      operatorInstruction: '동일 함수가 EV36_Adjust.js에 있는지 확인 후 Apps Script 프로젝트에서 임시 파일 제거'
    },
    {
      fileName: '02_OPTIONAL_COPY_TO_*.js',
      fileRole: '선택 점검용 임시 파일',
      finalAction: 'REMOVE_FROM_OPERATION_AFTER_MERGED_OR_NOT_NEEDED',
      sourceBuildRange: 'B73',
      keepInOperation: false,
      mergeTarget: 'EV36_Adjust.js',
      cleanupReason: '점검 함수만 포함된 파일은 통합 후 독립 파일로 유지할 필요 없음',
      riskLevel: 'LOW',
      operatorInstruction: 'erpB06J36_73_autoRunSafe가 필요하면 EV36_Adjust.js에 통합, 아니면 제거'
    },
    {
      fileName: '02_COPY_TO_EventVendor_*.html',
      fileRole: 'UI 복사용 임시 파일',
      finalAction: 'REMOVE_FROM_OPERATION_AFTER_MERGED',
      sourceBuildRange: 'B72~B73',
      keepInOperation: false,
      mergeTarget: 'EventVendor.html',
      cleanupReason: 'HTML 블록이 EventVendor.html에 반영되면 임시 복사 파일 불필요',
      riskLevel: 'MEDIUM',
      operatorInstruction: 'EventVendor.html에 B73 UI가 정상 반영된 뒤 임시 html 파일 제거'
    },
    {
      fileName: '00_README_RUN_ORDER.txt',
      fileRole: '패치 안내문',
      finalAction: 'ARCHIVE_OUTSIDE_APPS_SCRIPT',
      sourceBuildRange: 'B60A~B74',
      keepInOperation: false,
      mergeTarget: 'external archive',
      cleanupReason: 'Apps Script 프로젝트 운영 파일 아님',
      riskLevel: 'LOW',
      operatorInstruction: '로컬/문서 보관용으로만 유지하고 Apps Script 프로젝트에는 올리지 않음'
    }
  ];
}

function erpB06J36_74_cleanupChecklistRows_() {
  return [
    {
      category: '백업',
      item: 'clasp pull 또는 Apps Script 현재 정상본 백업',
      requiredResult: 'BACKUP_DONE',
      operatorAction: '정리 전 현재 프로젝트 전체 백업',
      dangerIfSkipped: '통합 중 누락 시 롤백 불가'
    },
    {
      category: '서버파일',
      item: 'EV36_Adjust.js에 B60A~B74 함수 존재 확인',
      requiredResult: 'ALL_REQUIRED_FUNCTIONS_EXISTS',
      operatorAction: '함수 검색으로 erpB06J36_60A~74 확인',
      dangerIfSkipped: '임시 파일 삭제 후 함수 누락 발생 가능'
    },
    {
      category: '화면파일',
      item: 'EventVendor.html에 B73 UI 블록만 존재 확인',
      requiredResult: 'B73_UI_ONLY',
      operatorAction: 'fhB72SettlementDashboard 제거, fhB73SettlementDashboard 유지',
      dangerIfSkipped: 'B72/B73 중복 UI 표시 또는 충돌 가능'
    },
    {
      category: '임시파일',
      item: '01_COPY_TO_*.js 임시 파일 제거 전 EV36 통합 확인',
      requiredResult: 'MERGED_BEFORE_REMOVE',
      operatorAction: '동일 함수가 EV36_Adjust.js에 있는 경우만 제거',
      dangerIfSkipped: '실제 함수가 임시 파일에만 있으면 기능 중단'
    },
    {
      category: '임시파일',
      item: '02_COPY_TO_*.html 임시 파일 제거 전 EventVendor 통합 확인',
      requiredResult: 'MERGED_BEFORE_REMOVE',
      operatorAction: 'B73 UI가 EventVendor.html에 반영된 경우만 제거',
      dangerIfSkipped: 'UI 블록 누락 가능'
    },
    {
      category: 'manifest',
      item: 'appsscript.json 변경 여부 확인',
      requiredResult: 'NO_UNNECESSARY_MANIFEST_CHANGE',
      operatorAction: '실제 변경이 없으면 manifest 제외/유지',
      dangerIfSkipped: 'webapp.access 오류 등 배포 오류 가능'
    },
    {
      category: '검증',
      item: '정리 후 erpB06J36_72_autoRunSafe / 73_autoRunSafe 실행',
      requiredResult: 'OK_TRUE',
      operatorAction: '정리 후 UI 서버/디자인 의존성 점검',
      dangerIfSkipped: '화면 데이터 조회 오류 미발견'
    },
    {
      category: '검증',
      item: 'B71 최종 인계 상태 재확인',
      requiredResult: 'FINAL_HANDOFF_CONFIRMED',
      operatorAction: 'erpB06J36_71_autoRunSafe 또는 관련 리포트 확인',
      dangerIfSkipped: '배포 가능 상태 흔들림'
    }
  ];
}

/** helpers */

function erpB06J36_74_requiredSheets_() {
  return {
    manifest: { sheetName: 'ERP_파일통합기준', headers: erpB06J36_74_manifestHeaders_() },
    checklist: { sheetName: 'ERP_파일정리체크리스트', headers: erpB06J36_74_cleanupChecklistHeaders_() },
    log: { sheetName: 'ERP_정산로그', headers: erpB06J36_74_settlementLogHeaders_() }
  };
}

function erpB06J36_74_safetyFlags_() {
  return {
    fileDeleteExecutionBlocked: true,
    codeMutationBlocked: true,
    businessStateMutationBlocked: true,
    backupRequiredBeforeCleanup: true,
    operatorManualReviewRequired: true,
    manifestOnly: true,
    checklistOnly: true
  };
}

function erpB06J36_74_getMasterSpreadsheet_() {
  var setupId = '17VMSpgSZCvIrUlgcw8yCNcnl8WQWo2IcRf5tDCcuJGM';
  var setup = SpreadsheetApp.openById(setupId);
  var cfg = setup.getSheetByName('SystemConfig');
  if (!cfg) throw new Error('SystemConfig 시트를 찾을 수 없습니다.');

  var values = cfg.getDataRange().getValues();
  var headers = values[0].map(function(h) { return String(h || '').trim(); });
  var lower = headers.map(function(h) { return h.toLowerCase(); });
  var keyIdx = lower.indexOf('key'); if (keyIdx < 0) keyIdx = lower.indexOf('configkey'); if (keyIdx < 0) keyIdx = 0;
  var valIdx = lower.indexOf('value'); if (valIdx < 0) valIdx = lower.indexOf('configvalue'); if (valIdx < 0) valIdx = lower.indexOf('spreadsheetid'); if (valIdx < 0) valIdx = 1;

  var keys = ['FEELHAUS_DB_MASTER_ID', 'FEELHAUS_DB_MASTER', 'MASTER_SPREADSHEET_ID', 'MASTER_DB_ID', 'DB_MASTER_ID'];
  for (var r = 1; r < values.length; r++) {
    var k = String(values[r][keyIdx] || '').trim();
    var v = String(values[r][valIdx] || '').trim();
    if (keys.indexOf(k) >= 0 && v) {
      var m = v.match(/\/d\/([a-zA-Z0-9-_]+)/);
      return SpreadsheetApp.openById(m && m[1] ? m[1] : v);
    }
  }
  throw new Error('SystemConfig에서 FEELHAUS_DB_MASTER ID를 찾지 못했습니다.');
}

function erpB06J36_74_ensureSheet_(ss, name, headers) {
  var sh = ss.getSheetByName(name);
  if (!sh) sh = ss.insertSheet(name);
  var existing = erpB06J36_74_getHeaders_(sh);
  if (!existing.length || existing.every(function(h) { return !h; })) {
    sh.getRange(1, 1, 1, headers.length).setValues([headers]);
    return sh;
  }
  var add = headers.filter(function(h) { return existing.indexOf(h) < 0; });
  if (add.length) sh.getRange(1, existing.length + 1, 1, add.length).setValues([add]);
  return sh;
}

function erpB06J36_74_getHeaders_(sh) {
  if (!sh || sh.getLastRow() < 1 || sh.getLastColumn() < 1) return [];
  return sh.getRange(1, 1, 1, sh.getLastColumn()).getValues()[0].map(function(h) { return String(h || '').trim(); });
}

function erpB06J36_74_sheetInfo_(sh, required) {
  var headers = erpB06J36_74_getHeaders_(sh);
  return { exists: true, sheetName: sh.getName(), lastRow: sh.getLastRow(), lastCol: sh.getLastColumn(), missingHeaders: (required || []).filter(function(h) { return headers.indexOf(h) < 0; }) };
}

function erpB06J36_74_map_(sh) {
  var headers = erpB06J36_74_getHeaders_(sh), map = {};
  headers.forEach(function(h, i) { if (h) map[h] = i + 1; });
  return map;
}

function erpB06J36_74_rows_(sh) {
  if (!sh || sh.getLastRow() < 2) return [];
  var map = erpB06J36_74_map_(sh);
  var values = sh.getRange(2, 1, sh.getLastRow() - 1, sh.getLastColumn()).getValues();
  return values.map(function(row, i) {
    var obj = { _rowIndex: i + 2 };
    Object.keys(map).forEach(function(h) { obj[h] = row[map[h] - 1]; });
    return obj;
  });
}

function erpB06J36_74_appendByHeaders_(sh, data) {
  var map = erpB06J36_74_map_(sh);
  var row = new Array(sh.getLastColumn()).fill('');
  Object.keys(data).forEach(function(k) { if (map[k]) row[map[k] - 1] = data[k]; });
  sh.appendRow(row);
}

function erpB06J36_74_appendSettlementLog_(ss, data) {
  var sh = erpB06J36_74_ensureSheet_(ss, 'ERP_정산로그', erpB06J36_74_settlementLogHeaders_());
  var now = new Date();
  var user = erpB06J36_74_user_();
  erpB06J36_74_appendByHeaders_(sh, {
    logId: 'LOG-' + Utilities.formatDate(now, Session.getScriptTimeZone(), 'yyyyMMddHHmmss') + '-' + Math.floor(Math.random() * 10000),
    actionCode: data.actionCode || '',
    eventVendorId: data.eventVendorId || '',
    targetId: data.targetId || '',
    beforeStatus: data.beforeStatus || '',
    afterStatus: data.afterStatus || '',
    reason: data.reason || '',
    actor: user,
    actedAt: now,
    snapshot: JSON.stringify(data.snapshot || {}),
    build: ERP_B06J36_74_BUILD,
    createdAt: now,
    createdBy: user,
    status: 'ACTIVE',
    statusReason: 'B74 file integration cleanup log'
  });
}

function erpB06J36_74_user_() {
  try { return Session.getActiveUser().getEmail() || 'UNKNOWN_USER'; }
  catch (e) { return 'UNKNOWN_USER'; }
}

function erpB06J36_74_compact_(value) {
  try {
    var text = JSON.stringify(value);
    if (text && text.length > 4000) return { compacted: true, length: text.length, preview: text.substring(0, 4000) };
    return value;
  } catch (e) {
    return String(value);
  }
}

function erpB06J36_74_manifestHeaders_() {
  return [
    'manifestId','manifestBatchId','build','fileName','fileRole','finalAction','sourceBuildRange',
    'keepInOperation','mergeTarget','cleanupReason','riskLevel','operatorInstruction',
    'deletionExecutionBlocked','backupRequiredBeforeCleanup','verifiedBy','verifiedAt',
    'createdAt','createdBy','updatedAt','updatedBy','status','statusReason'
  ];
}

function erpB06J36_74_cleanupChecklistHeaders_() {
  return [
    'checklistId','checklistBatchId','build','checklistOrder','checklistCategory','checklistItem',
    'requiredResult','currentResult','checkStatus','operatorAction','dangerIfSkipped','evidenceNote',
    'checkedBy','checkedAt','createdAt','createdBy','updatedAt','updatedBy','status','statusReason'
  ];
}

function erpB06J36_74_settlementLogHeaders_() {
  return [
    'logId','actionCode','eventVendorId','targetId','beforeStatus','afterStatus','reason','actor','actedAt',
    'snapshot','build','createdAt','createdBy','status','statusReason'
  ];
}


/** END OF ERP_B06J36_72_73_74_EV36_APPEND_INTEGRATED_SAFE */
