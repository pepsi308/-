
/**
 * FEELHAUS ERP - Vendor Request Center Compat Build
 * - 기존 Index / Code 구조 유지
 * - 보조 페이지 추가형
 * - EventVendor / SetupPatch 방식과 동일한 route helper 사용
 */

function renderVendorRequestCenterPage_() {
  return HtmlService.createHtmlOutputFromFile('VendorRequestCenter')
    .setTitle('ERP_vendor_request_center')
    .setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL);
}

function tryHandleVendorRequestRoute_(e) {
  var page = '';
  try {
    page = String((e && e.parameter && e.parameter.page) ? e.parameter.page : '').trim();
  } catch (err) {
    page = '';
  }
  if (page !== 'vendorRequestCenter') return null;
  return renderVendorRequestCenterPage_();
}

function VRC_s_(v) { return String(v === null || v === undefined ? '' : v).trim(); }
function VRC_n_(v) { return Number(String(v === null || v === undefined ? '' : v).replace(/,/g, '').trim()) || 0; }
function VRC_now_() {
  return Utilities.formatDate(new Date(), Session.getScriptTimeZone() || 'Asia/Seoul', 'yyyy-MM-dd HH:mm:ss');
}
function VRC_openDb_() {
  var props = PropertiesService.getScriptProperties();
  var id = props.getProperty('DB_SPREADSHEET_ID') || props.getProperty('DB_MASTER_ID') || props.getProperty('SPREADSHEET_ID');
  if (!id) throw new Error('DB_SPREADSHEET_ID / DB_MASTER_ID / SPREADSHEET_ID 값이 없습니다.');
  return SpreadsheetApp.openById(id);
}
function VRC_getSheetObjects_(sheetName) {
  var ss = VRC_openDb_();
  var sh = ss.getSheetByName(sheetName);
  if (!sh) return [];
  var vals = sh.getDataRange().getDisplayValues();
  if (!vals || vals.length < 2) return [];
  var headers = vals[0].map(VRC_s_);
  return vals.slice(1).filter(function(r){ return r.join('').trim() !== ''; }).map(function(r){
    var o = {};
    headers.forEach(function(h, i){ o[h] = r[i]; });
    return o;
  });
}
function VRC_filterMaster_(rows, filters) {
  filters = filters || {};
  return (rows || []).filter(function(v){
    if (filters.eventId && VRC_s_(v.eventId || v['eventId']) !== VRC_s_(filters.eventId)) return false;
    if (filters.status && VRC_s_(v.status) !== VRC_s_(filters.status)) return false;
    if (filters.approvalStatus && VRC_s_(v.approvalStatus) !== VRC_s_(filters.approvalStatus)) return false;
    if (filters.matchStatus && VRC_s_(v.matchStatus) !== VRC_s_(filters.matchStatus)) return false;
    var q = VRC_s_(filters.query).toLowerCase();
    if (q) {
      var hay = [v.vendorName, v.phone, v.eventName, v.requestId].join(' ').toLowerCase();
      if (hay.indexOf(q) === -1) return false;
    }
    return true;
  });
}
function VRC_getFallbackData_() {
  var events = [
    { eventId: 'EVT-20260420-001', eventName: '디에이치 방배 입주박람회' },
    { eventId: 'EVT-20260515-002', eventName: '래미안 수원 입주박람회' },
    { eventId: 'EVT-20260601-003', eventName: '힐스테이트 평택 입주박람회' }
  ];
  var raw = [
    { requestId:'REQ-20260418-001', eventId:'EVT-20260420-001', sourceSheetName:'디에이치 방배 입주박람회', sourceFormUrl:'https://forms.gle/example-feelhaus-vendor-entry', sourceRowNo:'2', submittedAt:'2026-04-18 11:00:00', vendorNameRaw:'브리즈에어', ownerNameRaw:'김대표', phoneRaw:'010-2001-1001', productCategoryRaw:'에어컨', expoFeeRaw:'525000', specialNoteRaw:'레거시 비고 1', status:'RECEIVED' },
    { requestId:'REQ-20260418-003', eventId:'EVT-20260601-003', sourceSheetName:'힐스테이트 평택 입주박람회', sourceFormUrl:'https://forms.gle/example-feelhaus-vendor-entry', sourceRowNo:'4', submittedAt:'2026-04-18 13:00:00', vendorNameRaw:'리빙앤슬립', ownerNameRaw:'박대표', phoneRaw:'010-2003-1003', productCategoryRaw:'침구', expoFeeRaw:'575000', specialNoteRaw:'레거시 비고 3', status:'RECEIVED' },
    { requestId:'REQ-20260418-004', eventId:'EVT-20260420-001', sourceSheetName:'디에이치 방배 입주박람회', sourceFormUrl:'https://forms.gle/example-feelhaus-vendor-entry', sourceRowNo:'5', submittedAt:'2026-04-18 15:00:00', vendorNameRaw:'홈클린랩', ownerNameRaw:'최대표', phoneRaw:'010-2004-1004', productCategoryRaw:'청소', expoFeeRaw:'600000', specialNoteRaw:'레거시 비고 4', status:'PARSED' },
    { requestId:'REQ-20260418-009', eventId:'EVT-20260601-003', sourceSheetName:'힐스테이트 평택 입주박람회', sourceFormUrl:'https://forms.gle/example-feelhaus-vendor-entry', sourceRowNo:'10', submittedAt:'2026-04-18 20:00:00', vendorNameRaw:'아트조명', ownerNameRaw:'임대표', phoneRaw:'010-2009-1009', productCategoryRaw:'조명', expoFeeRaw:'725000', specialNoteRaw:'행사명 검토 필요', status:'ERROR' }
  ];
  var master = [
    { requestId:'REQ-20260418-001', rawRequestId:'REQ-20260418-001', eventId:'EVT-20260420-001', matchedEventId:'EVT-20260420-001', eventName:'디에이치 방배 입주박람회', vendorId:'VND-2026-0011', matchedVendorId:'VND-2026-0011', vendorName:'브리즈에어', ownerName:'김대표', phone:'010-2001-1001', region:'서울', vendorType:'입점업체', productCategory:'에어컨', participationStatus:'참여확정', expoFee:'525000', vatAmount:'52500', giftType:'상품권 2만원', matchStatus:'MATCHED', approvalStatus:'APPROVED', approvedBy:'hq_manager@feelhaus.co.kr', approvedAt:'2026-04-19 09:00:00', status:'APPROVED', statusReason:'' },
    { requestId:'REQ-20260418-003', rawRequestId:'REQ-20260418-003', eventId:'EVT-20260601-003', matchedEventId:'EVT-20260601-003', eventName:'힐스테이트 평택 입주박람회', vendorId:'', matchedVendorId:'', vendorName:'리빙앤슬립', ownerName:'박대표', phone:'010-2003-1003', region:'경기', vendorType:'입점업체', productCategory:'침구', participationStatus:'보류', expoFee:'575000', vatAmount:'57500', giftType:'사은품', matchStatus:'NEW_VENDOR_CANDIDATE', approvalStatus:'PENDING', approvedBy:'', approvedAt:'', status:'PENDING', statusReason:'신규 업체 후보' },
    { requestId:'REQ-20260418-004', rawRequestId:'REQ-20260418-004', eventId:'EVT-20260420-001', matchedEventId:'EVT-20260420-001', eventName:'디에이치 방배 입주박람회', vendorId:'VND-2026-0024', matchedVendorId:'VND-2026-0024', vendorName:'홈클린랩', ownerName:'최대표', phone:'010-2004-1004', region:'서울', vendorType:'입점업체', productCategory:'청소', participationStatus:'취소', expoFee:'600000', vatAmount:'60000', giftType:'없음', matchStatus:'REVIEW_REQUIRED', approvalStatus:'PENDING', approvedBy:'', approvedAt:'', status:'REVIEWING', statusReason:'업체 상태 검토 필요' },
    { requestId:'REQ-20260418-009', rawRequestId:'REQ-20260418-009', eventId:'EVT-20260601-003', matchedEventId:'', eventName:'힐스테이트 평택 입주박람회', vendorId:'VND-2026-0099', matchedVendorId:'VND-2026-0099', vendorName:'아트조명', ownerName:'임대표', phone:'010-2009-1009', region:'인천', vendorType:'입점업체', productCategory:'조명', participationStatus:'참여예정', expoFee:'725000', vatAmount:'72500', giftType:'없음', matchStatus:'REVIEW_REQUIRED', approvalStatus:'REJECTED', approvedBy:'hq_manager@feelhaus.co.kr', approvedAt:'2026-04-19 11:30:00', status:'REJECTED', statusReason:'행사 재매칭 필요' }
  ];
  var links = [
    { linkId:'LNK-20260418-001', eventId:'EVT-20260420-001', vendorId:'VND-2026-0011', requestId:'REQ-20260418-001', eventName:'디에이치 방배 입주박람회', vendorName:'브리즈에어', participationStatus:'참여확정', status:'ACTIVE', linkedAt:'2026-04-19 09:10:00' }
  ];
  var logs = [
    { requestId:'REQ-20260418-001', actionType:'MATCH', createdBy:'hq_manager', beforeValue:'REVIEW_REQUIRED', afterValue:'MATCHED', reason:'전화번호 일치', createdAt:'2026-04-18 10:22:00' },
    { requestId:'REQ-20260418-001', actionType:'APPROVE', createdBy:'hq_manager', beforeValue:'PENDING', afterValue:'APPROVED', reason:'입점 승인 완료', createdAt:'2026-04-18 10:25:00' },
    { requestId:'REQ-20260418-001', actionType:'LINK_CREATE', createdBy:'erp_operator', beforeValue:'-', afterValue:'LNK-20260418-001', reason:'행사-업체 연결 생성', createdAt:'2026-04-18 10:28:00' },
    { requestId:'REQ-20260418-003', actionType:'RECEIVE', createdBy:'legacy-form-bot', beforeValue:'-', afterValue:'RECEIVED', reason:'원본 접수', createdAt:'2026-04-18 13:00:00' },
    { requestId:'REQ-20260418-004', actionType:'REVIEW', createdBy:'hq_manager', beforeValue:'PENDING', afterValue:'REVIEWING', reason:'업체 상태 검토 필요', createdAt:'2026-04-18 16:00:00' },
    { requestId:'REQ-20260418-009', actionType:'REJECT', createdBy:'hq_manager', beforeValue:'REVIEW_REQUIRED', afterValue:'REJECTED', reason:'행사 재매칭 필요', createdAt:'2026-04-19 11:30:00' }
  ];
  var vendorCandidates = [
    { vendorId:'VND-2026-0011', vendorName:'브리즈에어', phone:'010-2001-1001' },
    { vendorId:'VND-2026-0199', vendorName:'브리즈에어 수원점', phone:'010-2001-8899' },
    { vendorId:'VND-2026-0024', vendorName:'홈클린랩', phone:'010-2004-1004' },
    { vendorId:'VND-2026-0099', vendorName:'아트조명', phone:'010-2009-1009' }
  ];
  return { events:events, raw:raw, master:master, links:links, logs:logs, eventCandidates:events, vendorCandidates:vendorCandidates };
}
function VRC_tryRealData_() {
  var rawRows = VRC_getSheetObjects_('ERP_입점업체신청_RAW');
  var masterRows = VRC_getSheetObjects_('ERP_입점업체신청_MASTER');
  var linkRows = VRC_getSheetObjects_('ERP_행사업체연결');
  var logRows = VRC_getSheetObjects_('ERP_입점업체신청_LOG');
  if (!masterRows.length && !rawRows.length) return null;
  var eventCandidates = VRC_getSheetObjects_('ERP_행사관리').map(function(v){ return { eventId: VRC_s_(v.eventId || v['행사ID']), eventName: VRC_s_(v.eventName || v['행사명']), status: VRC_s_(v.status || v['상태값']) }; }).filter(function(v){ return v.eventId || v.eventName; });
  var vendorCandidates = VRC_getSheetObjects_('ERP_업체관리').map(function(v){ return { vendorId: VRC_s_(v.vendorId || v['업체ID']), vendorName: VRC_s_(v.vendorName || v['업체명']), phone: VRC_s_(v.phone || v['연락처']), status: VRC_s_(v.status || v['상태값']) }; }).filter(function(v){ return v.vendorId || v.vendorName; });
  return {
    events: eventCandidates,
    raw: rawRows.map(function(v){ return {
      requestId: VRC_s_(v.requestId), eventId: VRC_s_(v.eventId), sourceSheetName: VRC_s_(v.sourceSheetName), sourceFormUrl: VRC_s_(v.sourceFormUrl), sourceRowNo: VRC_s_(v.sourceRowNo), submittedAt: VRC_s_(v.submittedAt),
      vendorNameRaw: VRC_s_(v.vendorNameRaw), ownerNameRaw: VRC_s_(v.ownerNameRaw), phoneRaw: VRC_s_(v.phoneRaw), productCategoryRaw: VRC_s_(v.productCategoryRaw), expoFeeRaw: VRC_s_(v.expoFeeRaw), specialNoteRaw: VRC_s_(v.specialNoteRaw), status: VRC_s_(v.status)
    }; }),
    master: masterRows.map(function(v){ return {
      requestId: VRC_s_(v.requestId), rawRequestId: VRC_s_(v.rawRequestId || v.requestId), eventId: VRC_s_(v.eventId), matchedEventId: VRC_s_(v.matchedEventId), eventName: VRC_s_(v.eventName), vendorId: VRC_s_(v.vendorId), matchedVendorId: VRC_s_(v.matchedVendorId || v.vendorId),
      vendorName: VRC_s_(v.vendorName), ownerName: VRC_s_(v.ownerName), phone: VRC_s_(v.phone), region: VRC_s_(v.region), vendorType: VRC_s_(v.vendorType), productCategory: VRC_s_(v.productCategory), participationStatus: VRC_s_(v.participationStatus), expoFee: VRC_s_(v.expoFee), vatAmount: VRC_s_(v.vatAmount), giftType: VRC_s_(v.giftType),
      matchStatus: VRC_s_(v.matchStatus), approvalStatus: VRC_s_(v.approvalStatus), approvedBy: VRC_s_(v.approvedBy), approvedAt: VRC_s_(v.approvedAt), status: VRC_s_(v.status), statusReason: VRC_s_(v.statusReason)
    }; }),
    links: linkRows.map(function(v){ return {
      linkId: VRC_s_(v.linkId || v['연결ID']), eventId: VRC_s_(v.eventId || v['행사ID']), vendorId: VRC_s_(v.vendorId || v['업체ID']), requestId: VRC_s_(v.requestId), eventName: VRC_s_(v.eventName || v['행사명']), vendorName: VRC_s_(v.vendorName || v['업체명']),
      participationStatus: VRC_s_(v.participationStatus || v['상태값']), status: VRC_s_(v.status || v['상태값']), linkedAt: VRC_s_(v.linkedAt || v['생성일시'])
    }; }),
    logs: logRows.map(function(v){ return {
      requestId: VRC_s_(v.requestId), actionType: VRC_s_(v.actionType), createdBy: VRC_s_(v.createdBy), beforeValue: VRC_s_(v.beforeValue), afterValue: VRC_s_(v.afterValue), reason: VRC_s_(v.reason), createdAt: VRC_s_(v.createdAt)
    }; }),
    eventCandidates: eventCandidates,
    vendorCandidates: vendorCandidates
  };
}
function getVendorRequestCenterBootstrap(filters) {
  var data;
  try {
    data = VRC_tryRealData_();
  } catch (e) {
    data = null;
  }
  if (!data) data = VRC_getFallbackData_();
  var filteredMaster = VRC_filterMaster_(data.master || [], filters || {});
  var allowedIds = {};
  filteredMaster.forEach(function(v){ allowedIds[VRC_s_(v.requestId)] = true; });
  var filteredRaw = (data.raw || []).filter(function(v){ return !Object.keys(allowedIds).length || allowedIds[VRC_s_(v.requestId)]; });
  var filteredLinks = (data.links || []).filter(function(v){ return !Object.keys(allowedIds).length || allowedIds[VRC_s_(v.requestId)]; });
  var filteredLogs = (data.logs || []).filter(function(v){ return !Object.keys(allowedIds).length || allowedIds[VRC_s_(v.requestId)]; });
  var kpis = {
    total: filteredMaster.length,
    pending: filteredMaster.filter(function(v){ return VRC_s_(v.approvalStatus) === 'PENDING'; }).length,
    newVendor: filteredMaster.filter(function(v){ return VRC_s_(v.matchStatus) === 'NEW_VENDOR_CANDIDATE'; }).length,
    reviewRequired: filteredMaster.filter(function(v){ return VRC_s_(v.matchStatus) === 'REVIEW_REQUIRED'; }).length,
    approved: filteredMaster.filter(function(v){ return VRC_s_(v.approvalStatus) === 'APPROVED'; }).length,
    linked: filteredLinks.length,
    unmatchedEvent: filteredMaster.filter(function(v){ return !VRC_s_(v.matchedEventId); }).length,
    unlinked: filteredMaster.filter(function(v){ return VRC_s_(v.approvalStatus) === 'APPROVED' && !filteredLinks.some(function(l){ return VRC_s_(l.requestId) === VRC_s_(v.requestId); }); }).length
  };
  return {
    ok: true,
    checkedAt: VRC_now_(),
    events: data.events || [],
    raw: filteredRaw,
    master: filteredMaster,
    links: filteredLinks,
    logs: filteredLogs,
    eventCandidates: data.eventCandidates || [],
    vendorCandidates: data.vendorCandidates || [],
    kpis: kpis,
    mode: data === VRC_getFallbackData_ ? 'fallback' : 'connected'
  };
}
