/**
 * 입점업체 신청센터 진입용 추가 파일
 * 기존 Code.gs 수정 없이 추가해서 사용 가능
 */

/**
 * 가장 쉬운 실행용
 * - 함수 실행 드롭다운에서 openVendorRequestCenterTest_ 선택 후 실행
 * - 팝업으로 신청센터 화면 표시
 */
function openVendorRequestCenterTest_() {
  var html = renderVendorRequestCenterPage_()
    .setWidth(1600)
    .setHeight(900);
  SpreadsheetApp.getUi().showModalDialog(html, '입점업체 신청센터');
}

/**
 * 메뉴 수동 설치용
 * - 함수 실행 드롭다운에서 installVendorRequestCenterMenu_ 1회 실행
 * - 이후 시트 새로고침
 */
function installVendorRequestCenterMenu_() {
  var ui = SpreadsheetApp.getUi();
  ui.createMenu('입점업체센터')
    .addItem('입점업체 신청센터 열기', 'openVendorRequestCenterTest_')
    .addToUi();
  ui.alert('상단 메뉴에 "입점업체센터"가 추가되었습니다. 시트를 새로고침한 뒤 사용하세요.');
}

/**
 * 별도 onOpen 헬퍼
 * - 기존 onOpen 충돌이 걱정될 때 직접 이 함수만 실행 가능
 */
function onOpenVendorRequestCenter_() {
  SpreadsheetApp.getUi()
    .createMenu('입점업체센터')
    .addItem('입점업체 신청센터 열기', 'openVendorRequestCenterTest_')
    .addToUi();
}
