var FH_ERP_SIGN_BRIDGE = (function () {
  var SETUP_DB_ID = '17VMSpgSZCvIrUlgcw8yCNcnl8WQWo2IcRf5tDCcuJGM';
  var CONFIG_SHEET_NAME = 'SystemConfig';
  var MASTER_KEY = 'DB_MASTER_ID';
  var WEBAPP_KEY = 'SIGN_WEBAPP_URL';

  var SHEETS = {
    sales: 'Sales',
    contracts: 'Contracts',
    installs: 'Installs',
    settlements: 'Settlements',
    documents: 'SIGN_Documents',
    logs: 'SIGN_Document_Logs'
  };

  var DOC_TYPES = {
    contract: { type: 'CONTRACT', template: 'PDF_CONTRACT', title: '계약서' },
    install: { type: 'INSTALL_CONFIRM', template: 'PDF_INSTALL_CONFIRM', title: '설치확인서' },
    settlement: { type: 'SETTLEMENT_CONFIRM', template: 'PDF_SETTLEMENT_CONFIRM', title: '정산 확인서' }
  };

  function runCreateContractSignFromSale(saleId) {
    return createContractSignFromSale(saleId);
  }

  function runCreateInstallConfirmSignFromInstall(installId) {
    return createInstallConfirmSignFromInstall(installId);
  }

  function runCreateSettlementConfirmSignFromSettlement(settlementId) {
    return createSettlementConfirmSignFromSettlement(settlementId);
  }

  function createContractSignFromSale(saleId) {
    if (!saleId) throw new Error('saleId is required');
    var master = getMaster_();
    var sale = getRowById_(master, SHEETS.sales, 'saleId', saleId);
    var contract = getOptionalRowById_(master, SHEETS.contracts, 'saleId', saleId);
    var source = mergeObjects_(sale, contract || {});
    return createSignDocument_(master, {
      documentType: DOC_TYPES.contract.type,
      templateCode: DOC_TYPES.contract.template,
      title: DOC_TYPES.contract.title,
      eventId: source.eventId,
      vendorId: source.vendorId,
      customerId: source.customerId,
      saleId: saleId,
      contractId: source.contractId || '',
      sourceType: 'ERP_SALE',
      sourceId: saleId
    });
  }

  function createInstallConfirmSignFromInstall(installId) {
    if (!installId) throw new Error('installId is required');
    var master = getMaster_();
    var install = getRowById_(master, SHEETS.installs, 'installId', installId);
    return createSignDocument_(master, {
      documentType: DOC_TYPES.install.type,
      templateCode: DOC_TYPES.install.template,
      title: DOC_TYPES.install.title,
      eventId: install.eventId,
      vendorId: install.vendorId,
      customerId: install.customerId,
      saleId: install.saleId,
      contractId: install.contractId,
      installId: installId,
      sourceType: 'ERP_INSTALL',
      sourceId: installId
    });
  }

  function createSettlementConfirmSignFromSettlement(settlementId) {
    if (!settlementId) throw new Error('settlementId is required');
    var master = getMaster_();
    var settlement = getRowById_(master, SHEETS.settlements, 'settlementId', settlementId);
    return createSignDocument_(master, {
      documentType: DOC_TYPES.settlement.type,
      templateCode: DOC_TYPES.settlement.template,
      title: DOC_TYPES.settlement.title,
      eventId: settlement.eventId,
      vendorId: settlement.vendorId,
      customerId: settlement.customerId || '',
      saleId: settlement.saleId,
      contractId: settlement.contractId || '',
      settlementId: settlementId,
      approvalId: settlement.approvalId || '',
      sourceType: 'ERP_SETTLEMENT',
      sourceId: settlementId
    });
  }

  function createSignDocument_(master, data) {
    validateRequired_(data, ['documentType', 'templateCode', 'eventId', 'vendorId']);
    if (data.documentType === 'CONTRACT') validateRequired_(data, ['customerId', 'saleId']);
    if (data.documentType === 'INSTALL_CONFIRM') validateRequired_(data, ['customerId', 'installId']);
    if (data.documentType === 'SETTLEMENT_CONFIRM') validateRequired_(data, ['settlementId']);

    var sheet = getSheet_(master, SHEETS.documents);
    var map = getHeaderMap_(sheet);
    ensureHeaders_(map, ['documentId', 'documentNo', 'documentType', 'status', 'statusReason', 'eventId', 'vendorId', 'customerId', 'saleId', 'contractId', 'installId', 'settlementId', 'approvalId', 'title', 'templateCode', 'signMethod', 'signUrl', 'qrUrl', 'createdAt', 'createdBy', 'updatedAt', 'updatedBy', 'notes']);

    var duplicate = findDuplicateDocument_(sheet, map, data);
    if (duplicate) {
      return buildResponse_(true, '이미 생성된 SIGN 문서가 있습니다.', duplicate, 'ERP_SIGN_DUPLICATE_REUSED');
    }

    var now = new Date();
    var user = getUser_();
    var documentId = createId_('DOC');
    var documentNo = createDocumentNo_(sheet, map, now);
    var signUrl = buildSignUrl_(documentId);
    var row = new Array(sheet.getLastColumn()).fill('');

    setByHeader_(row, map, 'documentId', documentId);
    setByHeader_(row, map, 'documentNo', documentNo);
    setByHeader_(row, map, 'documentType', data.documentType);
    setByHeader_(row, map, 'status', 'READY_TO_SIGN');
    setByHeader_(row, map, 'statusReason', 'ERP 자동 생성');
    setByHeader_(row, map, 'eventId', data.eventId || '');
    setByHeader_(row, map, 'vendorId', data.vendorId || '');
    setByHeader_(row, map, 'customerId', data.customerId || '');
    setByHeader_(row, map, 'saleId', data.saleId || '');
    setByHeader_(row, map, 'contractId', data.contractId || '');
    setByHeader_(row, map, 'installId', data.installId || '');
    setByHeader_(row, map, 'settlementId', data.settlementId || '');
    setByHeader_(row, map, 'approvalId', data.approvalId || '');
    setByHeader_(row, map, 'title', data.title || data.documentType);
    setByHeader_(row, map, 'templateCode', data.templateCode);
    setByHeader_(row, map, 'signMethod', 'QR');
    setByHeader_(row, map, 'signUrl', signUrl);
    setByHeader_(row, map, 'qrUrl', signUrl);
    setByHeader_(row, map, 'createdAt', now);
    setByHeader_(row, map, 'createdBy', user);
    setByHeader_(row, map, 'updatedAt', now);
    setByHeader_(row, map, 'updatedBy', user);
    setByHeader_(row, map, 'notes', 'ERP_SIGN_BRIDGE sourceType=' + data.sourceType + ' sourceId=' + data.sourceId);

    sheet.appendRow(row);
    appendLog_(master, documentId, 'CREATE_FROM_ERP', '', 'READY_TO_SIGN', data.sourceType + ':' + data.sourceId, user, now);

    return buildResponse_(true, 'SIGN 문서 자동 생성 완료', {
      documentId: documentId,
      documentNo: documentNo,
      documentType: data.documentType,
      status: 'READY_TO_SIGN',
      signUrl: signUrl
    });
  }

  function findDuplicateDocument_(sheet, map, data) {
    var values = sheet.getDataRange().getValues();
    for (var r = 1; r < values.length; r++) {
      var row = values[r];
      if (getByHeader_(row, map, 'documentType') !== data.documentType) continue;
      if (data.saleId && getByHeader_(row, map, 'saleId') === data.saleId) return rowToObject_(row, map);
      if (data.installId && getByHeader_(row, map, 'installId') === data.installId) return rowToObject_(row, map);
      if (data.settlementId && getByHeader_(row, map, 'settlementId') === data.settlementId) return rowToObject_(row, map);
    }
    return null;
  }

  function getMaster_() {
    var setup = SpreadsheetApp.openById(SETUP_DB_ID);
    var cfg = getSheet_(setup, CONFIG_SHEET_NAME);
    var rows = cfg.getDataRange().getValues();
    var keyCol = 0;
    var valueCol = 1;
    var masterId = '';
    for (var i = 1; i < rows.length; i++) {
      if (String(rows[i][keyCol]).trim() === MASTER_KEY) masterId = String(rows[i][valueCol]).trim();
    }
    if (!masterId) throw new Error('DB_MASTER_ID 설정값이 없습니다.');
    return SpreadsheetApp.openById(masterId);
  }

  function getSignWebAppUrl_() {
    var setup = SpreadsheetApp.openById(SETUP_DB_ID);
    var cfg = getSheet_(setup, CONFIG_SHEET_NAME);
    var rows = cfg.getDataRange().getValues();
    var url = '';
    for (var i = 1; i < rows.length; i++) {
      if (String(rows[i][0]).trim() === WEBAPP_KEY) url = String(rows[i][1]).trim();
    }
    if (!url) throw new Error('SIGN_WEBAPP_URL 설정값이 없습니다.');
    return url;
  }

  function buildSignUrl_(documentId) {
    return getSignWebAppUrl_() + '?mode=sign&documentId=' + encodeURIComponent(documentId);
  }

  function getRowById_(book, sheetName, idHeader, idValue) {
    var row = getOptionalRowById_(book, sheetName, idHeader, idValue);
    if (!row) throw new Error(sheetName + '에서 ' + idHeader + '=' + idValue + ' 값을 찾지 못했습니다.');
    return row;
  }

  function getOptionalRowById_(book, sheetName, idHeader, idValue) {
    var sheet = getSheet_(book, sheetName);
    var map = getHeaderMap_(sheet);
    ensureHeaders_(map, [idHeader]);
    var values = sheet.getDataRange().getValues();
    for (var r = 1; r < values.length; r++) {
      if (String(getByHeader_(values[r], map, idHeader)) === String(idValue)) return rowToObject_(values[r], map);
    }
    return null;
  }

  function appendLog_(book, documentId, actionType, beforeValue, afterValue, reason, user, now) {
    var sheet = getSheet_(book, SHEETS.logs);
    var map = getHeaderMap_(sheet);
    var row = new Array(sheet.getLastColumn()).fill('');
    setIfHeader_(row, map, 'logId', createId_('LOG'));
    setIfHeader_(row, map, 'documentId', documentId);
    setIfHeader_(row, map, 'actionType', actionType);
    setIfHeader_(row, map, 'beforeValue', beforeValue);
    setIfHeader_(row, map, 'afterValue', afterValue);
    setIfHeader_(row, map, 'reason', reason);
    setIfHeader_(row, map, 'createdAt', now);
    setIfHeader_(row, map, 'createdBy', user);
    sheet.appendRow(row);
  }

  function getSheet_(book, name) {
    var sheet = book.getSheetByName(name);
    if (!sheet) throw new Error('필수 시트 없음: ' + name);
    return sheet;
  }

  function getHeaderMap_(sheet) {
    var headers = sheet.getRange(1, 1, 1, sheet.getLastColumn()).getValues()[0];
    var map = {};
    for (var i = 0; i < headers.length; i++) {
      var key = String(headers[i]).trim();
      if (key && !map[key]) map[key] = i + 1;
    }
    return map;
  }

  function ensureHeaders_(map, required) {
    var missing = [];
    required.forEach(function (h) { if (!map[h]) missing.push(h); });
    if (missing.length) throw new Error('필수 헤더 누락: ' + missing.join(', '));
  }

  function setByHeader_(row, map, header, value) {
    if (!map[header]) throw new Error('필수 헤더 누락: ' + header);
    row[map[header] - 1] = value;
  }

  function setIfHeader_(row, map, header, value) {
    if (map[header]) row[map[header] - 1] = value;
  }

  function getByHeader_(row, map, header) {
    return map[header] ? row[map[header] - 1] : '';
  }

  function rowToObject_(row, map) {
    var obj = {};
    Object.keys(map).forEach(function (key) { obj[key] = row[map[key] - 1]; });
    return obj;
  }

  function validateRequired_(data, fields) {
    var missing = [];
    fields.forEach(function (f) { if (!data[f]) missing.push(f); });
    if (missing.length) throw new Error('필수값 누락: ' + missing.join(', '));
  }

  function mergeObjects_(a, b) {
    var out = {};
    Object.keys(a || {}).forEach(function (k) { out[k] = a[k]; });
    Object.keys(b || {}).forEach(function (k) { if (b[k] !== '' && b[k] !== null && typeof b[k] !== 'undefined') out[k] = b[k]; });
    return out;
  }

  function createId_(prefix) {
    return prefix + '_' + Utilities.getUuid().replace(/-/g, '').slice(0, 12).toUpperCase();
  }

  function createDocumentNo_(sheet, map, now) {
    var tz = Session.getScriptTimeZone() || 'Asia/Seoul';
    var date = Utilities.formatDate(now, tz, 'yyyyMMdd');
    var values = sheet.getDataRange().getValues();
    var maxSeq = 0;
    for (var r = 1; r < values.length; r++) {
      var no = String(getByHeader_(values[r], map, 'documentNo') || '');
      if (no.indexOf('DOC-' + date + '-') === 0) {
        var seq = Number(no.split('-').pop());
        if (seq > maxSeq) maxSeq = seq;
      }
    }
    return 'DOC-' + date + '-' + ('000' + (maxSeq + 1)).slice(-3);
  }

  function getUser_() {
    try { return Session.getActiveUser().getEmail() || 'system'; } catch (err) { return 'system'; }
  }

  function buildResponse_(ok, message, data, code) {
    return { ok: ok, message: message, data: data || null, errorCode: ok ? '' : (code || 'ERP_SIGN_ERROR'), meta: { source: 'ERP_SIGN_BRIDGE', timestamp: new Date() } };
  }

  return {
    runCreateContractSignFromSale: runCreateContractSignFromSale,
    runCreateInstallConfirmSignFromInstall: runCreateInstallConfirmSignFromInstall,
    runCreateSettlementConfirmSignFromSettlement: runCreateSettlementConfirmSignFromSettlement,
    createContractSignFromSale: createContractSignFromSale,
    createInstallConfirmSignFromInstall: createInstallConfirmSignFromInstall,
    createSettlementConfirmSignFromSettlement: createSettlementConfirmSignFromSettlement
  };
})();

function runCreateContractSignFromSale(saleId) {
  return FH_ERP_SIGN_BRIDGE.runCreateContractSignFromSale(saleId);
}

function runCreateInstallConfirmSignFromInstall(installId) {
  return FH_ERP_SIGN_BRIDGE.runCreateInstallConfirmSignFromInstall(installId);
}

function runCreateSettlementConfirmSignFromSettlement(settlementId) {
  return FH_ERP_SIGN_BRIDGE.runCreateSettlementConfirmSignFromSettlement(settlementId);
}

/****************************************************
 * ERP ↔ SIGN 자동 트리거 연결 v1
 * - 기존 수동 생성 함수는 유지
 * - ERP 저장/상태변경 로직 마지막에서 호출하는 안전 래퍼
 * - 중복 문서는 기존 브릿지의 중복 방지 로직으로 재사용
 ****************************************************/

function onErpSaleSaved_CreateContractSign(saleId) {
  if (!saleId) throw new Error('saleId is required');
  return runCreateContractSignFromSale(saleId);
}

function onErpInstallCompleted_CreateInstallConfirmSign(installId) {
  if (!installId) throw new Error('installId is required');
  return runCreateInstallConfirmSignFromInstall(installId);
}

function onErpSettlementConfirmed_CreateSettlementConfirmSign(settlementId) {
  if (!settlementId) throw new Error('settlementId is required');
  return runCreateSettlementConfirmSignFromSettlement(settlementId);
}

/****************************************************
 * ERP 본체에 붙일 호출 예시
 * 실제 저장/상태변경 성공 이후에만 호출
 ****************************************************/

function exampleAfterSaleSaveHook_(saleId) {
  // 판매 저장 성공 후 호출
  return onErpSaleSaved_CreateContractSign(saleId);
}

function exampleAfterInstallDoneHook_(installId) {
  // 설치 상태가 DONE/설치완료로 변경된 뒤 호출
  return onErpInstallCompleted_CreateInstallConfirmSign(installId);
}

function exampleAfterSettlementConfirmHook_(settlementId) {
  // 정산 상태가 CONFIRMED/확정으로 변경된 뒤 호출
  return onErpSettlementConfirmed_CreateSettlementConfirmSign(settlementId);
}

/****************************************************
 * 테스트 실행 예제
 * 현재 검증에 사용한 실제 ID 기준
 ****************************************************/

function testAutoCreateContractSignFromSale() {
  return onErpSaleSaved_CreateContractSign('TEST-SALE-0001');
}

function testAutoCreateInstallConfirmSignFromInstall() {
  return onErpInstallCompleted_CreateInstallConfirmSign('INS-0001');
}

function testAutoCreateSettlementConfirmSignFromSettlement() {
  return onErpSettlementConfirmed_CreateSettlementConfirmSign('SET-0001');
}
