ERP_LIGHTWEIGHT_PHASE1_CHANGED_ONLY

목적:
- ERP 본체를 직접 업무 실행 본체가 아니라 이관 안내/브릿지 화면으로 낮추는 1차 안전 경량화입니다.
- 새 기능 개발은 포함하지 않았습니다.

변경 파일:
- ERP/Index.html
- ERP/EventVendor.html
- ERP/erp_ops_ui_view.html
- ERP/Code_EventVendor_WorksheetLink.js

주요 변경:
- Index.html에 ERP_LIGHTWEIGHT_PHASE1_SHIELD 삽입
- 일반 화면에서 위험 실행 버튼 숨김: 정산 실행, SIGN/PDF/Drive 직접 실행, FORM 자동등록, CONTROL 복구/배포/점검, 테스트/더미/샘플
- EventVendor.html과 erp_ops_ui_view.html은 구 V300 행사관리 실행 화면 대신 EVENT_CENTER 이관 안내 브릿지 화면으로 전환
- V300/CLEAN REBASE 문구 제거
- Code_EventVendor_WorksheetLink.js에서 getEventVendorCleanRebaseSummaryV300 제거
- V80~V232 실무시트 읽기전용 미러 함수는 유지

보호:
- SystemConfig, MASTER DB, 공통 ID, 권한, 상태전이, 감사로그, 실무시트 원본미러 원칙은 건드리지 않았습니다.
- Code.js, Code_EventVendor.js, OpsUI.js, EV36_Adjust.js, SignBridge.js는 1차에서 수정하지 않았습니다.

주의:
- 이 빌드는 업무센터 완성본이 아니라 ERP 본체 위험 실행 차단/브릿지화 단계입니다.
- 최종 이관 전까지 조회 함수와 보호 엔진은 유지해야 합니다.
