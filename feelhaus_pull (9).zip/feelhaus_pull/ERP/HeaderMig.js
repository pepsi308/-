/**
 * FEELHAUS ERP - Header Migration Helper
 * 목적:
 * - ERP DB 시트 헤더를 영문 camelCase 표준으로 통일
 * - 타 프로젝트와 공통 ID / 상태 / 로그 구조 호환 준비
 *
 * 사용 순서:
 * 1) previewErpHeaderMigration()
 * 2) migrateErpHeadersToEnglish()
 * 3) previewErpHeaderMigration() 재확인
 */

var FH_ERP_HEADER_STANDARD = {
  'ERP_행사관리': {
    sheetName: 'ERP_행사관리',
    headers: ['eventId','eventName','eventType','startDate','endDate','eventPlace','manager','status','memo','createdAt','updatedAt','baseEventId','eventUid'],
    aliases: {
      '행사ID':'eventId','eventId':'eventId',
      '행사명':'eventName','eventName':'eventName',
      '행사구분':'eventType','eventType':'eventType',
      '시작일':'startDate','startDate':'startDate',
      '종료일':'endDate','endDate':'endDate',
      '행사장소':'eventPlace','eventPlace':'eventPlace',
      '담당자':'manager','manager':'manager',
      '상태값':'status','status':'status',
      '메모':'memo','memo':'memo',
      '생성일시':'createdAt','createdAt':'createdAt',
      '수정일시':'updatedAt','updatedAt':'updatedAt',
      '기준행사ID':'baseEventId','baseEventId':'baseEventId',
      'eventUid':'eventUid'
    }
  },
  'ERP_업체관리': {
    sheetName: 'ERP_업체관리',
    headers: ['vendorId','vendorName','ownerName','phone','region','manager','status','memo','createdAt','updatedAt','baseVendorId','vendorUid'],
    aliases: {
      '업체ID':'vendorId','vendorId':'vendorId',
      '업체명':'vendorName','vendorName':'vendorName',
      '대표자':'ownerName','ownerName':'ownerName',
      '연락처':'phone','phone':'phone',
      '지역':'region','region':'region',
      '담당자':'manager','manager':'manager',
      '상태값':'status','status':'status',
      '메모':'memo','memo':'memo',
      '생성일시':'createdAt','createdAt':'createdAt',
      '수정일시':'updatedAt','updatedAt':'updatedAt',
      '기준업체ID':'baseVendorId','baseVendorId':'baseVendorId',
      'vendorUid':'vendorUid'
    }
  },
  'ERP_행사업체연결': {
    sheetName: 'ERP_행사업체연결',
    headers: ['linkId','eventId','eventName','vendorId','vendorName','status','approvalStatus','statusReason','rejectReason','memo','approvedBy','approvedAt','createdAt','updatedAt'],
    aliases: {
      '연결ID':'linkId','linkId':'linkId',
      '행사ID':'eventId','eventId':'eventId',
      '행사명':'eventName','eventName':'eventName',
      '업체ID':'vendorId','vendorId':'vendorId',
      '업체명':'vendorName','vendorName':'vendorName',
      '상태값':'status','status':'status',
      '승인상태':'approvalStatus','approvalStatus':'approvalStatus',
      'statusReason':'statusReason','상태변경사유':'statusReason',
      'rejectReason':'rejectReason','반려사유':'rejectReason',
      '메모':'memo','memo':'memo',
      '승인자':'approvedBy','approvedBy':'approvedBy',
      '승인일시':'approvedAt','approvedAt':'approvedAt',
      '생성일시':'createdAt','createdAt':'createdAt',
      '수정일시':'updatedAt','updatedAt':'updatedAt'
    }
  },
  'ERP_행사업체로그': {
    sheetName: 'ERP_행사업체로그',
    headers: ['logId','logType','actionType','targetKey','targetName','beforeValue','afterValue','reason','approvedBy','relatedDocumentNo','message','createdAt','actor'],
    aliases: {
      '로그ID':'logId','logId':'logId',
      '구분':'logType','logType':'logType',
      'actionType':'actionType',
      '대상키':'targetKey','targetKey':'targetKey',
      '대상명':'targetName','targetName':'targetName',
      '이전값':'beforeValue','beforeValue':'beforeValue',
      '변경값':'afterValue','afterValue':'afterValue',
      '사유':'reason','reason':'reason',
      '승인자':'approvedBy','approvedBy':'approvedBy',
      '관련문서번호':'relatedDocumentNo','relatedDocumentNo':'relatedDocumentNo',
      '내용':'message','message':'message',
      '생성일시':'createdAt','createdAt':'createdAt',
      '사용자':'actor','actor':'actor'
    }
  }
};

function FH_ERP_getActiveSs_() {
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  if (!ss) throw new Error('활성 스프레드시트를 찾지 못했습니다.');
  return ss;
}
function FH_ERP_trim_(v) { return String(v === null || v === undefined ? '' : v).trim(); }

function previewErpHeaderMigration() {
  var ss = FH_ERP_getActiveSs_();
  var result = [];
  Object.keys(FH_ERP_HEADER_STANDARD).forEach(function(sheetName) {
    var cfg = FH_ERP_HEADER_STANDARD[sheetName];
    var sh = ss.getSheetByName(sheetName);
    if (!sh) {
      result.push({sheetName: sheetName, exists: false, missingHeaders: cfg.headers.slice(), extraHeaders: [], currentHeaders: []});
      return;
    }
    var currentHeaders = sh.getLastColumn() ? sh.getRange(1,1,1,sh.getLastColumn()).getDisplayValues()[0].map(FH_ERP_trim_) : [];
    var normalized = currentHeaders.map(function(h){ return cfg.aliases[h] || h; });
    var missing = cfg.headers.filter(function(h){ return normalized.indexOf(h) === -1; });
    var extra = normalized.filter(function(h){ return cfg.headers.indexOf(h) === -1; });
    result.push({sheetName: sheetName, exists: true, currentHeaders: currentHeaders, normalizedHeaders: normalized, missingHeaders: missing, extraHeaders: extra});
  });
  return {ok:true, checkedAt:new Date(), sheets:result};
}

function migrateErpHeadersToEnglish() {
  var ss = FH_ERP_getActiveSs_();
  var summary = [];
  Object.keys(FH_ERP_HEADER_STANDARD).forEach(function(sheetName) {
    var cfg = FH_ERP_HEADER_STANDARD[sheetName];
    var sh = ss.getSheetByName(sheetName);
    if (!sh) {
      sh = ss.insertSheet(sheetName);
      sh.getRange(1,1,1,cfg.headers.length).setValues([cfg.headers]);
      summary.push({sheetName: sheetName, status:'CREATED', headers: cfg.headers});
      return;
    }
    var values = sh.getDataRange().getDisplayValues();
    var currentHeaders = values.length ? values[0].map(FH_ERP_trim_) : [];
    var normalizedHeaders = currentHeaders.map(function(h){ return cfg.aliases[h] || h; });
    var rowObjects = (values.length > 1 ? values.slice(1) : []).filter(function(r){ return r.join('').trim() !== ''; }).map(function(row){
      var obj = {};
      for (var i=0;i<normalizedHeaders.length;i++) obj[normalizedHeaders[i]] = row[i];
      return obj;
    });
    sh.clearContents();
    sh.getRange(1,1,1,cfg.headers.length).setValues([cfg.headers]);
    if (rowObjects.length) {
      var rows = rowObjects.map(function(obj){
        return cfg.headers.map(function(h){ return obj[h] || ''; });
      });
      sh.getRange(2,1,rows.length,cfg.headers.length).setValues(rows);
    }
    summary.push({sheetName: sheetName, status:'MIGRATED', beforeHeaders: currentHeaders, afterHeaders: cfg.headers, rowCount: rowObjects.length});
  });
  return {ok:true, migratedAt:new Date(), sheets:summary};
}
