@echo off
setlocal EnableExtensions
title FEELHAUS DOWNLOAD ERP
if not exist "D:\pepsi308\OneDrive\feelhaus_pull\ERP" mkdir "D:\pepsi308\OneDrive\feelhaus_pull\ERP"
cd /d D:\pepsi308\OneDrive\feelhaus_pull\ERP
if exist ".clasp.json" (
  echo [ERP] clasp pull
  clasp.cmd pull
) else (
  echo [ERP] clasp clone
  clasp.cmd clone 1elqO6_-DzBe4NgbLkGagWAtyvVVdshr2D53_ByAa9sYHbiT9hDqJ-AX6
)
pause
