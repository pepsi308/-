/**
 * FEELHAUS ERP - Header Map Utility
 * - 헤더 순서 변경 허용
 * - 헤더명 기준 자동 추적
 * - 한글 헤더는 alias로만 읽기 호환
 */

var FH_HEADER_STANDARD = {
  'ERP_행사관리': ['eventId','eventName','eventType','startDate','endDate','eventPlace','manager','status','memo','createdAt','updatedAt','baseEventId','eventUid'],
  'ERP_업체관리': ['vendorId','vendorName','ownerName','phone','region','manager','status','memo','createdAt','updatedAt','baseVendorId','vendorUid'],
  'ERP_행사업체연결': ['linkId','eventId','eventName','vendorId','vendorName','status','approvalStatus','statusReason','rejectReason','memo','approvedBy','approvedAt','createdAt','updatedAt'],
  'ERP_행사업체로그': ['logId','logType','actionType','targetKey','targetName','beforeValue','afterValue','reason','approvedBy','relatedDocumentNo','message','createdAt','actor'],
  'ERP_입점업체신청_RAW': ['requestId','eventId','sourceSheetName','sourceFormUrl','sourceRowNo','submittedAt','vendorNameRaw','ownerNameRaw','phoneRaw','productCategoryRaw','expoFeeRaw','specialNoteRaw','status'],
  'ERP_입점업체신청_MASTER': ['requestId','rawRequestId','eventId','matchedEventId','eventName','vendorId','matchedVendorId','vendorName','ownerName','phone','region','vendorType','productCategory','participationStatus','expoFee','vatAmount','giftType','matchStatus','approvalStatus','approvedBy','approvedAt','status','statusReason'],
  'ERP_입점업체신청_LOG': ['requestId','actionType','createdBy','beforeValue','afterValue','reason','createdAt']
};

var FH_HEADER_ALIAS = {
  '행사ID': 'eventId', '행사명': 'eventName', '행사구분': 'eventType', '시작일': 'startDate', '종료일': 'endDate', '행사장소': 'eventPlace', '담당자': 'manager', '상태값': 'status', '메모': 'memo', '생성일시': 'createdAt', '수정일시': 'updatedAt', '기준행사ID': 'baseEventId', '행사UID': 'eventUid',
  '업체ID': 'vendorId', '업체명': 'vendorName', '대표자': 'ownerName', '연락처': 'phone', '지역': 'region', '기준업체ID': 'baseVendorId', '업체UID': 'vendorUid',
  '연결ID': 'linkId', '승인상태': 'approvalStatus', '상태변경사유': 'statusReason', '반려사유': 'rejectReason', '승인자': 'approvedBy', '승인일시': 'approvedAt',
  '로그ID': 'logId', '로그유형': 'logType', '대상키': 'targetKey', '대상명': 'targetName', '이전값': 'beforeValue', '변경값': 'afterValue', '사유': 'reason', '관련문서번호': 'relatedDocumentNo', '메시지': 'message', '사용자': 'actor', '작업자': 'actor'
};

function FH_trim_(v) { return String(v == null ? '' : v).trim(); }
function FH_normHeader_(h) { var v = FH_trim_(h); return FH_HEADER_ALIAS[v] || v; }
function FH_now_() { return Utilities.formatDate(new Date(), Session.getScriptTimeZone() || 'Asia/Seoul', 'yyyy-MM-dd HH:mm:ss'); }

function FH_openERPSpreadsheet_() {
  try {
    var active = SpreadsheetApp.getActiveSpreadsheet();
    if (active) return active;
  } catch (e) {}
  var props = PropertiesService.getScriptProperties();
  var ids = [
    props.getProperty('ERP_DB_SPREADSHEET_ID'),
    props.getProperty('DB_SPREADSHEET_ID'),
    props.getProperty('SPREADSHEET_ID')
  ].filter(function(v){ return !!FH_trim_(v); });
  for (var i = 0; i < ids.length; i += 1) {
    try { return SpreadsheetApp.openById(ids[i]); } catch (e2) {}
  }
  throw new Error('ERP 스프레드시트를 찾지 못했습니다. Script Properties에 ERP_DB_SPREADSHEET_ID 또는 DB_SPREADSHEET_ID를 설정하세요.');
}

function FH_getSheet_(sheetName) {
  var ss = FH_openERPSpreadsheet_();
  return ss.getSheetByName(sheetName) || ss.insertSheet(sheetName);
}

function FH_getHeaderMap_(sheet) {
  var lastCol = Math.max(sheet.getLastColumn(), 1);
  var headers = sheet.getRange(1, 1, 1, lastCol).getDisplayValues()[0].map(FH_normHeader_);
  var map = {};
  headers.forEach(function(h, idx) { if (FH_trim_(h) && map[h] == null) map[h] = idx + 1; });
  return map;
}

function FH_getHeaders_(sheet) {
  var lastCol = sheet.getLastColumn();
  if (!lastCol) return [];
  return sheet.getRange(1,1,1,lastCol).getDisplayValues()[0].map(FH_normHeader_);
}

function FH_deleteDuplicateMeaningColumns_(sheet) {
  var headersRaw = sheet.getLastColumn() ? sheet.getRange(1,1,1,sheet.getLastColumn()).getDisplayValues()[0] : [];
  var seen = {};
  var deleteCols = [];
  headersRaw.forEach(function(h, idx){
    var n = FH_normHeader_(h);
    if (!FH_trim_(n)) return;
    if (seen[n]) deleteCols.push(idx + 1);
    else seen[n] = true;
  });
  deleteCols.sort(function(a,b){return b-a;}).forEach(function(c){ sheet.deleteColumn(c); });
  return deleteCols;
}

function FH_ensureStandardSheet_(sheetName) {
  var standard = FH_HEADER_STANDARD[sheetName];
  if (!standard) return FH_getSheet_(sheetName);
  var sh = FH_getSheet_(sheetName);
  FH_deleteDuplicateMeaningColumns_(sh);
  if (sh.getMaxColumns() < standard.length) {
    sh.insertColumnsAfter(sh.getMaxColumns(), standard.length - sh.getMaxColumns());
  }
  sh.getRange(1,1,1,standard.length).setValues([standard]);
  if (sh.getLastColumn() > standard.length) {
    var tail = sh.getRange(1, standard.length + 1, 1, sh.getLastColumn() - standard.length).getDisplayValues()[0];
    if (tail.some(function(v){ return FH_trim_(v) !== ''; })) {
      sh.deleteColumns(standard.length + 1, sh.getLastColumn() - standard.length);
    }
  }
  return sh;
}

function FH_rows_(sheetName) {
  var sh = FH_getSheet_(sheetName);
  var values = sh.getDataRange().getDisplayValues();
  if (!values || values.length < 2) return [];
  var headerMap = FH_getHeaderMap_(sh);
  return values.slice(1).map(function(row, idx){
    var obj = { __rowNum: idx + 2 };
    Object.keys(headerMap).forEach(function(h){ obj[h] = row[headerMap[h]-1] || ''; });
    return obj;
  }).filter(function(r){
    return Object.keys(r).some(function(k){ return k !== '__rowNum' && FH_trim_(r[k]) !== ''; });
  });
}

function FH_appendObject_(sheetName, dataObj) {
  var sh = FH_getSheet_(sheetName);
  var headerMap = FH_getHeaderMap_(sh);
  var headers = Object.keys(headerMap).sort(function(a,b){ return headerMap[a]-headerMap[b]; });
  var row = headers.map(function(h){ return dataObj[h] != null ? dataObj[h] : ''; });
  sh.getRange(sh.getLastRow()+1,1,1,row.length).setValues([row]);
}

function FH_updateObject_(sheetName, rowNum, dataObj) {
  var sh = FH_getSheet_(sheetName);
  var headerMap = FH_getHeaderMap_(sh);
  Object.keys(dataObj).forEach(function(h){
    if (headerMap[h] != null) sh.getRange(rowNum, headerMap[h]).setValue(dataObj[h]);
  });
}

function FH_findById_(sheetName, idHeader, idValue) {
  var rows = FH_rows_(sheetName);
  for (var i = 0; i < rows.length; i += 1) {
    if (FH_trim_(rows[i][idHeader]) === FH_trim_(idValue)) return rows[i];
  }
  return null;
}

function FH_json_(obj) {
  try { return JSON.stringify(obj || {}); } catch (e) { return '{}'; }
}

function FH_logTypeFromAction_(actionType) {
  var a = FH_trim_(actionType).toUpperCase();
  if (a.indexOf('EVENT_') === 0) return 'EVENT';
  if (a.indexOf('VENDOR_') === 0) return 'VENDOR';
  return 'LINK';
}
