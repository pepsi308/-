/**
 * FEELHAUS EVENT VENDOR - Worksheet readonly link V80
 * Purpose: Read SystemConfig WORK_* spreadsheet settings and return readonly source status.
 * Note: Read-only only. No write, no sync, no ERP master update.
 */
var FH_EV_WORKSHEET_LINK_V80_BUILD = 'EVENT_VENDOR_WORKSHEET_READONLY_V80_20260522';
var FH_EV_WORKSHEET_SETUP_DB_ID_V80 = '17VMSpgSZCvIrUlgcw8yCNcnl8WQWo2IcRf5tDCcuJGM';
var FH_EV_WORKSHEET_CONFIG_SHEET_NAME_V80 = 'SystemConfig';

function fhEvWorksheetGetConfigMapV80_() {
  var ss = SpreadsheetApp.openById(FH_EV_WORKSHEET_SETUP_DB_ID_V80);
  var sh = ss.getSheetByName(FH_EV_WORKSHEET_CONFIG_SHEET_NAME_V80);
  if (!sh) throw new Error('SystemConfig 시트를 찾을 수 없습니다.');
  var values = sh.getDataRange().getValues();
  if (!values || values.length < 2) return {};
  var headers = values[0].map(function(h){ return String(h || '').trim(); });
  var keyIdx = headers.indexOf('CONFIG_KEY');
  var valueIdx = headers.indexOf('VALUE');
  var statusIdx = headers.indexOf('status');
  if (keyIdx < 0 || valueIdx < 0) throw new Error('SystemConfig CONFIG_KEY/VALUE 헤더가 필요합니다.');
  var map = {};
  values.slice(1).forEach(function(row) {
    var key = String(row[keyIdx] || '').trim();
    if (!key) return;
    var status = statusIdx >= 0 ? String(row[statusIdx] || '').trim() : '';
    if (status && status !== 'ACTIVE') return;
    map[key] = String(row[valueIdx] || '').trim();
  });
  return map;
}

function fhEvWorksheetDescribeSourceV80_(label, idKey, urlKey, cfg) {
  var id = cfg[idKey] || '';
  var url = cfg[urlKey] || '';
  var item = {
    label: label,
    idKey: idKey,
    urlKey: urlKey,
    spreadsheetId: id,
    url: url,
    ok: false,
    sheetCount: 0,
    sheets: [],
    message: ''
  };
  if (!id) {
    item.message = 'SystemConfig에 ' + idKey + ' 값이 없습니다.';
    return item;
  }
  try {
    var ss = SpreadsheetApp.openById(id);
    var sheets = ss.getSheets();
    item.ok = true;
    item.sheetCount = sheets.length;
    item.title = ss.getName();
    item.sheets = sheets.slice(0, 20).map(function(sh) {
      return {
        name: sh.getName(),
        sheetId: sh.getSheetId(),
        lastRow: sh.getLastRow(),
        lastColumn: sh.getLastColumn()
      };
    });
    item.message = '읽기전용 연결 확인 완료';
  } catch (err) {
    item.ok = false;
    item.message = '읽기 실패: ' + String(err && err.message ? err.message : err);
  }
  return item;
}

function getEventVendorWorksheetLinkSummaryV80() {
  var report = {
    ok: true,
    build: FH_EV_WORKSHEET_LINK_V80_BUILD,
    checkedAt: new Date().toISOString(),
    syncMode: '',
    ownerModule: '',
    sources: [],
    warnings: [],
    fatal: []
  };
  try {
    var cfg = fhEvWorksheetGetConfigMapV80_();
    report.syncMode = cfg.WORK_SHEET_SYNC_MODE || '';
    report.ownerModule = cfg.WORK_SHEET_OWNER_MODULE || '';
    report.sources.push(fhEvWorksheetDescribeSourceV80_('입주캘린더(제안서)', 'WORK_CALENDAR_SPREADSHEET_ID', 'WORK_CALENDAR_SPREADSHEET_URL', cfg));
    report.sources.push(fhEvWorksheetDescribeSourceV80_('입주박람회 진행', 'WORK_PROGRESS_SPREADSHEET_ID', 'WORK_PROGRESS_SPREADSHEET_URL', cfg));
    report.sources.forEach(function(src) {
      if (!src.ok) {
        report.ok = false;
        report.warnings.push({ name: src.label, message: src.message });
      }
    });
  } catch (err) {
    report.ok = false;
    report.fatal.push({ name: 'exception', message: String(err && err.message ? err.message : err) });
  }
  return report;
}



/**
 * FEELHAUS EVENT VENDOR - Worksheet classify V92
 * Purpose: classify readonly worksheet tabs into business buckets.
 * Note: Read-only only. No write, no sync, no ERP master update.
 */
var FH_EV_WORKSHEET_CLASSIFY_V92_BUILD = 'EVENT_VENDOR_WORKSHEET_CLASSIFY_V92_20260522';

function fhEvWorksheetClassifyNameV92_(name) {
  var n = String(name || '').toLowerCase();
  var raw = String(name || '');

  function hasAny(arr) {
    return arr.some(function(k) { return n.indexOf(String(k).toLowerCase()) >= 0 || raw.indexOf(k) >= 0; });
  }

  if (hasAny(['as', 'a/s', '접수', '하자', '보수', '블랙', 'blacklist'])) return 'AS';
  if (hasAny(['정산', '입금', '미수', '계산', '지급', '환수', '전표', '금액'])) return 'SETTLEMENT';
  if (hasAny(['업체', '협력', '신청', '입점', '참여', 'vendor'])) return 'VENDOR';
  if (hasAny(['캘린더', '일정', '달력', 'calendar'])) return 'SCHEDULE';
  if (hasAny(['행사', '박람회', '입주', '제안서', '프로세스', '목차'])) return 'EVENT';
  if (hasAny(['설문', '조사', '만족', '응답'])) return 'SURVEY';
  if (hasAny(['계정', '설정', 'template', '템플릿', '양식'])) return 'CONFIG';
  return 'ETC';
}

function getEventVendorWorksheetClassifySummaryV92() {
  var base = getEventVendorWorksheetLinkSummaryV80();
  var report = {
    ok: !!(base && base.ok),
    build: FH_EV_WORKSHEET_CLASSIFY_V92_BUILD,
    checkedAt: new Date().toISOString(),
    syncMode: base && base.syncMode || '',
    ownerModule: base && base.ownerModule || '',
    sources: [],
    summary: {},
    warnings: base && base.warnings || [],
    fatal: base && base.fatal || []
  };

  function addBucket(map, bucket, sheet) {
    if (!map[bucket]) map[bucket] = { bucket: bucket, count: 0, sheets: [] };
    map[bucket].count++;
    if (map[bucket].sheets.length < 12) map[bucket].sheets.push(sheet);
  }

  (base.sources || []).forEach(function(src) {
    var sourceOut = {
      label: src.label,
      ok: src.ok,
      sheetCount: src.sheetCount || 0,
      url: src.url || '',
      buckets: {},
      topBuckets: []
    };

    (src.sheets || []).forEach(function(sh) {
      var bucket = fhEvWorksheetClassifyNameV92_(sh.name);
      addBucket(sourceOut.buckets, bucket, sh);
      if (!report.summary[bucket]) report.summary[bucket] = 0;
      report.summary[bucket]++;
    });

    sourceOut.topBuckets = Object.keys(sourceOut.buckets).map(function(k) {
      return sourceOut.buckets[k];
    }).sort(function(a, b) {
      return b.count - a.count;
    });

    report.sources.push(sourceOut);
  });

  return report;
}



/**
 * FEELHAUS EVENT VENDOR - Worksheet event match V93~V96
 * Purpose: extract event candidate sheets and prepare readonly eventId mapping candidates.
 * Note: Read-only only. No write, no sync, no ERP master update.
 */
var FH_EV_WORKSHEET_EVENT_MATCH_V96_BUILD = 'EVENT_VENDOR_WORKSHEET_EVENT_MATCH_V96_20260522';

function fhEvWorksheetNormalizeEventNameV96_(name) {
  return String(name || '')
    .replace(/[★☆◆◇■□●○▶▷\[\]\(\)]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

function fhEvWorksheetExtractYearV96_(name) {
  var s = String(name || '');
  var m = s.match(/(20[0-9]{2}|[0-9]{2})\s*년?/);
  if (!m) return '';
  var y = m[1];
  if (y.length === 2) y = '20' + y;
  return y;
}

function fhEvWorksheetGuessEventCandidateScoreV96_(name, bucket) {
  var raw = String(name || '');
  var n = raw.toLowerCase();
  var score = 0;
  if (bucket === 'EVENT') score += 40;
  if (bucket === 'SCHEDULE') score += 20;
  if (n.indexOf('입주') >= 0) score += 20;
  if (n.indexOf('박람회') >= 0) score += 20;
  if (n.indexOf('행사') >= 0) score += 15;
  if (n.indexOf('캘린더') >= 0 || n.indexOf('calendar') >= 0) score += 10;
  if (n.indexOf('목차') >= 0 || n.indexOf('프로세스') >= 0) score += 8;
  if (n.indexOf('테스트') >= 0 || n.indexOf('test') >= 0) score -= 25;
  if (n.indexOf('계정') >= 0 || n.indexOf('설정') >= 0) score -= 20;
  if (n.indexOf('양식') >= 0 || n.indexOf('템플릿') >= 0) score -= 12;
  return score;
}

function getEventVendorWorksheetEventCandidatesV96() {
  var classified = getEventVendorWorksheetClassifySummaryV92();
  var report = {
    ok: !!(classified && classified.ok),
    build: FH_EV_WORKSHEET_EVENT_MATCH_V96_BUILD,
    checkedAt: new Date().toISOString(),
    mode: 'READONLY_EVENT_CANDIDATE',
    sources: [],
    candidates: [],
    summary: { totalCandidates: 0, strongCandidates: 0, needsReview: 0 },
    warnings: classified && classified.warnings || [],
    fatal: classified && classified.fatal || []
  };

  (classified.sources || []).forEach(function(src) {
    var sourceOut = {
      label: src.label,
      sheetCount: src.sheetCount,
      url: src.url,
      candidates: []
    };

    (src.topBuckets || []).forEach(function(bucketObj) {
      var bucket = bucketObj.bucket;
      (bucketObj.sheets || []).forEach(function(sh) {
        var score = fhEvWorksheetGuessEventCandidateScoreV96_(sh.name, bucket);
        if (score < 20) return;
        var cand = {
          sourceLabel: src.label,
          sourceUrl: src.url,
          sheetName: sh.name,
          sheetId: sh.sheetId,
          lastRow: sh.lastRow,
          lastColumn: sh.lastColumn,
          bucket: bucket,
          score: score,
          yearHint: fhEvWorksheetExtractYearV96_(sh.name),
          eventNameHint: fhEvWorksheetNormalizeEventNameV96_(sh.name),
          matchStatus: score >= 55 ? 'STRONG_CANDIDATE' : 'NEEDS_REVIEW',
          eventId: '',
          note: '읽기전용 후보입니다. 자동 저장/매핑하지 않습니다.'
        };
        sourceOut.candidates.push(cand);
        report.candidates.push(cand);
      });
    });

    sourceOut.candidates.sort(function(a, b) { return b.score - a.score; });
    report.sources.push(sourceOut);
  });

  report.candidates.sort(function(a, b) { return b.score - a.score; });
  report.summary.totalCandidates = report.candidates.length;
  report.summary.strongCandidates = report.candidates.filter(function(c) { return c.matchStatus === 'STRONG_CANDIDATE'; }).length;
  report.summary.needsReview = report.candidates.filter(function(c) { return c.matchStatus !== 'STRONG_CANDIDATE'; }).length;

  return report;
}

function getEventVendorWorksheetSelectedEventPreviewV96(eventId) {
  var candidates = getEventVendorWorksheetEventCandidatesV96();
  var out = {
    ok: candidates.ok,
    build: FH_EV_WORKSHEET_EVENT_MATCH_V96_BUILD,
    checkedAt: new Date().toISOString(),
    eventId: String(eventId || ''),
    mode: 'READONLY_SELECTED_EVENT_PREVIEW',
    matched: [],
    message: ''
  };
  // 아직 실무시트에 eventId가 없으므로 자동 확정 매칭은 하지 않는다.
  out.matched = (candidates.candidates || []).slice(0, 10);
  out.message = out.eventId
    ? 'eventId 기준 확정 매칭 전 단계입니다. 현재는 후보 상위 10건만 표시합니다.'
    : '행사 선택 전 단계입니다. 후보 상위 10건만 표시합니다.';
  return out;
}



/**
 * FEELHAUS EVENT VENDOR - Selected event worksheet link V97~V100
 * Purpose: show readonly worksheet candidate summary for selected/current event context.
 * Note: Read-only only. No write, no sync, no ERP master update.
 */
var FH_EV_SELECTED_EVENT_LINK_V100_BUILD = 'EVENT_VENDOR_SELECTED_EVENT_LINK_V100_20260522';

function fhEvWorksheetGetTopCandidatesForSelectedV100_(limit) {
  var report = getEventVendorWorksheetEventCandidatesV96();
  var max = Math.max(1, Number(limit || 8));
  return (report.candidates || []).slice(0, max);
}

function getEventVendorSelectedEventWorksheetSummaryV100(eventId, eventName) {
  var eid = String(eventId || '').trim();
  var ename = String(eventName || '').trim();
  var candidates = getEventVendorWorksheetEventCandidatesV96();
  var list = (candidates.candidates || []).slice(0, 12);

  var scoreBoosted = list.map(function(c) {
    var score = Number(c.score || 0);
    var hint = String(c.eventNameHint || c.sheetName || '');
    if (ename && hint.indexOf(ename) >= 0) score += 30;
    if (eid && hint.indexOf(eid) >= 0) score += 60;
    return {
      sourceLabel: c.sourceLabel,
      sourceUrl: c.sourceUrl,
      sheetName: c.sheetName,
      sheetId: c.sheetId,
      lastRow: c.lastRow,
      lastColumn: c.lastColumn,
      bucket: c.bucket,
      baseScore: c.score,
      score: score,
      yearHint: c.yearHint,
      eventNameHint: c.eventNameHint,
      matchStatus: score >= 70 ? 'MATCH_CANDIDATE' : c.matchStatus,
      eventId: eid,
      note: '읽기전용 미리보기입니다. 자동 저장/매핑하지 않습니다.'
    };
  }).sort(function(a, b) { return b.score - a.score; });

  return {
    ok: !!candidates.ok,
    build: FH_EV_SELECTED_EVENT_LINK_V100_BUILD,
    checkedAt: new Date().toISOString(),
    mode: 'READONLY_SELECTED_EVENT_LINK_PREVIEW',
    eventId: eid,
    eventName: ename,
    candidates: scoreBoosted.slice(0, 8),
    summary: {
      totalBaseCandidates: candidates.summary && candidates.summary.totalCandidates || 0,
      previewCount: Math.min(8, scoreBoosted.length),
      matchCandidates: scoreBoosted.filter(function(c){ return c.matchStatus === 'MATCH_CANDIDATE'; }).length
    },
    message: eid || ename
      ? '선택 행사 기준 실무시트 후보를 읽기전용으로 표시합니다.'
      : '행사 선택 전 단계입니다. 실무시트 상위 후보를 표시합니다.',
    warnings: candidates.warnings || [],
    fatal: candidates.fatal || []
  };
}



/**
 * FEELHAUS EVENT VENDOR - Selected event worksheet summary V101~V105
 * Purpose: provide compact readonly summary cards for selected event worksheet candidates.
 * Note: Read-only only. No write, no sync, no ERP master update.
 */
var FH_EV_SELECTED_EVENT_SUMMARY_V105_BUILD = 'EVENT_VENDOR_SELECTED_EVENT_SUMMARY_V105_20260522';

function getEventVendorSelectedEventWorksheetCardsV105(eventId, eventName) {
  var preview = getEventVendorSelectedEventWorksheetSummaryV100(eventId, eventName);
  var cards = (preview.candidates || []).slice(0, 3).map(function(c, idx) {
    return {
      rank: idx + 1,
      title: c.eventNameHint || c.sheetName || '',
      sourceLabel: c.sourceLabel || '',
      sheetName: c.sheetName || '',
      score: c.score || 0,
      status: c.matchStatus || '',
      yearHint: c.yearHint || '',
      lastRow: c.lastRow || 0,
      lastColumn: c.lastColumn || 0,
      url: c.sourceUrl || '',
      note: '읽기전용 후보 요약입니다.'
    };
  });

  return {
    ok: !!preview.ok,
    build: FH_EV_SELECTED_EVENT_SUMMARY_V105_BUILD,
    checkedAt: new Date().toISOString(),
    eventId: String(eventId || ''),
    eventName: String(eventName || ''),
    cards: cards,
    summary: {
      totalBaseCandidates: preview.summary && preview.summary.totalBaseCandidates || 0,
      previewCount: preview.summary && preview.summary.previewCount || 0,
      matchCandidates: preview.summary && preview.summary.matchCandidates || 0,
      cardCount: cards.length
    },
    message: '선택 행사 기준 실무시트 후보 상위 3건을 요약 표시합니다. 저장하지 않습니다.',
    warnings: preview.warnings || [],
    fatal: preview.fatal || []
  };
}



/**
 * FEELHAUS EVENT VENDOR - Worktab worksheet summary V106~V110
 * Purpose: group readonly worksheet candidates by event operation worktabs.
 * Note: Read-only only. No write, no sync, no ERP master update.
 */
var FH_EV_WORKTAB_SUMMARY_V110_BUILD = 'EVENT_VENDOR_WORKTAB_SUMMARY_V110_20260522';

function fhEvWorktabFromBucketV110_(bucket, sheetName) {
  var b = String(bucket || '');
  var n = String(sheetName || '').toLowerCase();
  if (n.indexOf('대관') >= 0 || n.indexOf('장소') >= 0 || n.indexOf('부스') >= 0 || n.indexOf('세팅') >= 0 || n.indexOf('셋팅') >= 0) return 'VENUE';
  if (b === 'SCHEDULE' || n.indexOf('일정') >= 0 || n.indexOf('캘린더') >= 0 || n.indexOf('calendar') >= 0) return 'SCHEDULE';
  if (b === 'VENDOR' || n.indexOf('업체') >= 0 || n.indexOf('입점') >= 0 || n.indexOf('협력') >= 0) return 'VENDOR';
  if (b === 'SETTLEMENT' || n.indexOf('정산') >= 0 || n.indexOf('입금') >= 0 || n.indexOf('미수') >= 0) return 'SETTLEMENT';
  if (b === 'AS') return 'AS';
  if (b === 'EVENT') return 'EVENT';
  return 'ETC';
}

function getEventVendorWorktabWorksheetSummaryV110(eventId, eventName) {
  var preview = getEventVendorSelectedEventWorksheetSummaryV100(eventId, eventName);
  var tabs = {
    EVENT: { code: 'EVENT', label: '행사 기본', count: 0, items: [] },
    VENUE: { code: 'VENUE', label: '대관/장소', count: 0, items: [] },
    SCHEDULE: { code: 'SCHEDULE', label: '일정/캘린더', count: 0, items: [] },
    VENDOR: { code: 'VENDOR', label: '업체/입점', count: 0, items: [] },
    SETTLEMENT: { code: 'SETTLEMENT', label: '정산/입금', count: 0, items: [] },
    AS: { code: 'AS', label: 'A/S/접수', count: 0, items: [] },
    ETC: { code: 'ETC', label: '기타', count: 0, items: [] }
  };

  (preview.candidates || []).forEach(function(c) {
    var tab = fhEvWorktabFromBucketV110_(c.bucket, c.sheetName);
    if (!tabs[tab]) tab = 'ETC';
    tabs[tab].count++;
    if (tabs[tab].items.length < 6) {
      tabs[tab].items.push({
        title: c.eventNameHint || c.sheetName || '',
        sourceLabel: c.sourceLabel || '',
        sheetName: c.sheetName || '',
        score: c.score || 0,
        status: c.matchStatus || '',
        yearHint: c.yearHint || '',
        lastRow: c.lastRow || 0,
        lastColumn: c.lastColumn || 0,
        url: c.sourceUrl || '',
        note: '읽기전용 업무탭 후보입니다.'
      });
    }
  });

  var ordered = ['EVENT','VENUE','SCHEDULE','VENDOR','SETTLEMENT','AS','ETC'].map(function(k){ return tabs[k]; });
  return {
    ok: !!preview.ok,
    build: FH_EV_WORKTAB_SUMMARY_V110_BUILD,
    checkedAt: new Date().toISOString(),
    eventId: String(eventId || ''),
    eventName: String(eventName || ''),
    tabs: ordered,
    summary: {
      tabCount: ordered.length,
      totalItems: ordered.reduce(function(sum, t){ return sum + t.count; }, 0),
      visibleItems: ordered.reduce(function(sum, t){ return sum + t.items.length; }, 0)
    },
    message: '실무시트 후보를 행사관리 업무탭별로 읽기전용 요약했습니다. 저장하지 않습니다.',
    warnings: preview.warnings || [],
    fatal: preview.fatal || []
  };
}



/**
 * FEELHAUS EVENT VENDOR - Workflow connect V111~V115
 * Purpose: provide readonly workflow connection summary between EventVendor tabs and worksheet candidates.
 * Note: Read-only only. No write, no sync, no ERP master update.
 */
var FH_EV_WORKFLOW_CONNECT_V115_BUILD = 'EVENT_VENDOR_WORKFLOW_CONNECT_V115_20260522';

function getEventVendorWorkflowConnectSummaryV115(eventId, eventName) {
  var worktab = getEventVendorWorktabWorksheetSummaryV110(eventId, eventName);
  var map = {};
  (worktab.tabs || []).forEach(function(t) {
    map[t.code] = t;
  });

  var steps = [
    { step: 1, code: 'EVENT', label: '행사 선택', action: '행사 기본정보 확인', tabLabel: '행사 기본', count: map.EVENT ? map.EVENT.count : 0 },
    { step: 2, code: 'VENUE', label: '대관/장소', action: '장소, 부스, 셋팅 후보 확인', tabLabel: '대관/장소', count: map.VENUE ? map.VENUE.count : 0 },
    { step: 3, code: 'SCHEDULE', label: '일정', action: '캘린더/운영 일정 후보 확인', tabLabel: '일정/캘린더', count: map.SCHEDULE ? map.SCHEDULE.count : 0 },
    { step: 4, code: 'VENDOR', label: '업체/입점', action: '입점업체/협력업체 후보 확인', tabLabel: '업체/입점', count: map.VENDOR ? map.VENDOR.count : 0 },
    { step: 5, code: 'SETTLEMENT', label: '정산/입금', action: '정산/미수/입금 관련 원본 후보 확인', tabLabel: '정산/입금', count: map.SETTLEMENT ? map.SETTLEMENT.count : 0 },
    { step: 6, code: 'AS', label: 'A/S/접수', action: '접수/A/S 원본 후보 확인', tabLabel: 'A/S/접수', count: map.AS ? map.AS.count : 0 }
  ];

  return {
    ok: !!worktab.ok,
    build: FH_EV_WORKFLOW_CONNECT_V115_BUILD,
    checkedAt: new Date().toISOString(),
    eventId: String(eventId || ''),
    eventName: String(eventName || ''),
    steps: steps,
    summary: {
      totalSteps: steps.length,
      linkedSteps: steps.filter(function(s){ return s.count > 0; }).length,
      totalCandidates: steps.reduce(function(sum, s){ return sum + s.count; }, 0)
    },
    message: '행사관리 업무 흐름과 실무시트 후보를 읽기전용으로 연결 표시합니다. 저장하지 않습니다.',
    warnings: worktab.warnings || [],
    fatal: worktab.fatal || []
  };
}



/**
 * FEELHAUS EVENT VENDOR - Workflow report V116~V120
 * Purpose: create readonly handoff/report text from worksheet workflow candidates.
 * Note: Read-only only. No write, no sync, no ERP master update.
 */
var FH_EV_WORKFLOW_REPORT_V120_BUILD = 'EVENT_VENDOR_WORKFLOW_REPORT_V120_20260522';

function getEventVendorWorkflowReportV120(eventId, eventName) {
  var workflow = getEventVendorWorkflowConnectSummaryV115(eventId, eventName);
  var worktab = getEventVendorWorktabWorksheetSummaryV110(eventId, eventName);
  var lines = [];
  lines.push('[필하우스 행사관리 실무시트 연결 리포트]');
  lines.push('생성시각: ' + new Date().toISOString());
  lines.push('eventId: ' + (String(eventId || '').trim() || '-'));
  lines.push('eventName: ' + (String(eventName || '').trim() || '-'));
  lines.push('');
  lines.push('운영 원칙: 기존 실무시트는 원본으로 유지하고 ERP 행사관리는 읽기전용 연결/요약부터 진행합니다.');
  lines.push('');

  lines.push('업무 흐름별 후보 현황');
  (workflow.steps || []).forEach(function(s) {
    lines.push('- ' + s.step + '. ' + s.label + ' / 후보 ' + s.count + '건 / ' + s.action);
  });

  lines.push('');
  lines.push('업무탭별 주요 후보');
  (worktab.tabs || []).forEach(function(t) {
    lines.push('[' + t.label + '] 후보 ' + t.count + '건');
    (t.items || []).slice(0, 3).forEach(function(it) {
      lines.push('  - ' + it.sheetName + ' / ' + it.sourceLabel + ' / score ' + it.score);
    });
  });

  lines.push('');
  lines.push('주의: 이 리포트는 읽기전용 후보 리포트입니다. eventId 자동 저장, ERP 원장 반영, 정산 실행을 하지 않습니다.');

  return {
    ok: !!workflow.ok,
    build: FH_EV_WORKFLOW_REPORT_V120_BUILD,
    checkedAt: new Date().toISOString(),
    eventId: String(eventId || ''),
    eventName: String(eventName || ''),
    workflowSummary: workflow.summary || {},
    reportText: lines.join('\n'),
    steps: workflow.steps || [],
    tabs: worktab.tabs || [],
    message: '실무시트 연결 후보를 리포트/인계문 형태로 생성했습니다. 저장하지 않습니다.',
    warnings: (workflow.warnings || []).concat(worktab.warnings || []),
    fatal: (workflow.fatal || []).concat(worktab.fatal || [])
  };
}



/**
 * FEELHAUS EVENT VENDOR - ERP event readonly match V121~V125
 * Purpose: compare worksheet event candidates with ERP_행사관리 readonly rows.
 * Note: Read-only only. No write, no sync, no ERP master update.
 */
var FH_EV_ERP_EVENT_MATCH_V125_BUILD = 'EVENT_VENDOR_ERP_EVENT_MATCH_V125_20260522';

function fhEvGetDbMasterIdV125_() {
  try {
    var cfg = fhEvWorksheetGetConfigMapV80_();
    return cfg.FEELHAUS_DB_MASTER_ID || cfg.FEELHAUS_DB_MASTER || cfg.DB_MASTER_ID || cfg.SPREADSHEET_ID || '';
  } catch (err) {
    return '';
  }
}

function fhEvHeaderMapV125_(headers) {
  var map = {};
  (headers || []).forEach(function(h, i) {
    var k = String(h || '').trim();
    if (k) map[k] = i;
  });
  return map;
}

function fhEvCellV125_(row, map, keys) {
  for (var i = 0; i < keys.length; i++) {
    if (map[keys[i]] != null) return row[map[keys[i]]];
  }
  return '';
}

function fhEvNormalizeTextV125_(v) {
  return String(v || '')
    .toLowerCase()
    .replace(/[^\w가-힣0-9]+/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

function fhEvSimilarityScoreV125_(a, b) {
  var aa = fhEvNormalizeTextV125_(a);
  var bb = fhEvNormalizeTextV125_(b);
  if (!aa || !bb) return 0;
  if (aa === bb) return 100;
  var score = 0;
  if (aa.indexOf(bb) >= 0 || bb.indexOf(aa) >= 0) score += 55;
  var at = aa.split(' ').filter(Boolean);
  var bt = bb.split(' ').filter(Boolean);
  var common = 0;
  at.forEach(function(t) { if (t.length >= 2 && bt.indexOf(t) >= 0) common++; });
  if (at.length && bt.length) score += Math.round((common / Math.max(at.length, bt.length)) * 45);
  return Math.min(100, score);
}

function getEventVendorErpEventRowsV125(limit) {
  var max = Math.max(1, Number(limit || 80));
  var dbId = fhEvGetDbMasterIdV125_();
  var out = {
    ok: true,
    build: FH_EV_ERP_EVENT_MATCH_V125_BUILD,
    checkedAt: new Date().toISOString(),
    dbId: dbId,
    sheetName: 'ERP_행사관리',
    rows: [],
    warnings: [],
    fatal: []
  };

  if (!dbId) {
    out.ok = false;
    out.fatal.push({ name: 'DB_MASTER_ID missing', message: 'SystemConfig에서 FEELHAUS_DB_MASTER_ID/DB_MASTER_ID를 찾을 수 없습니다.' });
    return out;
  }

  try {
    var ss = SpreadsheetApp.openById(dbId);
    var sh = ss.getSheetByName('ERP_행사관리');
    if (!sh) {
      out.ok = false;
      out.fatal.push({ name: 'sheet missing', message: 'ERP_행사관리 시트를 찾을 수 없습니다.' });
      return out;
    }
    var values = sh.getDataRange().getValues();
    if (!values || values.length < 2) return out;
    var headers = values[0].map(function(h){ return String(h || '').trim(); });
    var map = fhEvHeaderMapV125_(headers);
    values.slice(1, max + 1).forEach(function(row) {
      var eventId = String(fhEvCellV125_(row, map, ['eventId','EVENT_ID','행사ID']) || '').trim();
      var eventName = String(fhEvCellV125_(row, map, ['eventName','name','title','행사명']) || '').trim();
      var venue = String(fhEvCellV125_(row, map, ['venue','place','location','장소']) || '').trim();
      var status = String(fhEvCellV125_(row, map, ['status','상태']) || '').trim();
      var startDate = String(fhEvCellV125_(row, map, ['startDate','eventStartDate','시작일']) || '').trim();
      var endDate = String(fhEvCellV125_(row, map, ['endDate','eventEndDate','종료일']) || '').trim();
      if (!eventId && !eventName) return;
      out.rows.push({
        eventId: eventId,
        eventName: eventName,
        venue: venue,
        status: status,
        startDate: startDate,
        endDate: endDate
      });
    });
  } catch (err) {
    out.ok = false;
    out.fatal.push({ name: 'exception', message: String(err && err.message ? err.message : err) });
  }
  return out;
}

function getEventVendorErpEventMatchCandidatesV125() {
  var worksheet = getEventVendorWorksheetEventCandidatesV96();
  var erp = getEventVendorErpEventRowsV125(120);
  var matches = [];

  (worksheet.candidates || []).slice(0, 40).forEach(function(w) {
    var best = null;
    (erp.rows || []).forEach(function(e) {
      var s1 = fhEvSimilarityScoreV125_(w.eventNameHint || w.sheetName, e.eventName);
      var s2 = fhEvSimilarityScoreV125_(w.sheetName, e.venue);
      var score = Math.max(s1, Math.round((s1 * 0.8) + (s2 * 0.2)));
      if (!best || score > best.matchScore) {
        best = {
          worksheetTitle: w.eventNameHint || w.sheetName,
          worksheetSheetName: w.sheetName,
          worksheetSourceLabel: w.sourceLabel,
          worksheetScore: w.score,
          eventId: e.eventId,
          eventName: e.eventName,
          venue: e.venue,
          status: e.status,
          startDate: e.startDate,
          endDate: e.endDate,
          matchScore: score,
          matchStatus: score >= 70 ? 'LIKELY_MATCH' : (score >= 40 ? 'NEEDS_REVIEW' : 'LOW_CONFIDENCE'),
          note: '읽기전용 대조 후보입니다. eventId를 자동 저장하지 않습니다.'
        };
      }
    });
    if (best) matches.push(best);
  });

  matches.sort(function(a, b) { return b.matchScore - a.matchScore; });

  return {
    ok: !!(worksheet.ok && erp.ok),
    build: FH_EV_ERP_EVENT_MATCH_V125_BUILD,
    checkedAt: new Date().toISOString(),
    worksheetCandidateCount: worksheet.candidates ? worksheet.candidates.length : 0,
    erpEventCount: erp.rows ? erp.rows.length : 0,
    matches: matches.slice(0, 30),
    summary: {
      likely: matches.filter(function(m){ return m.matchStatus === 'LIKELY_MATCH'; }).length,
      review: matches.filter(function(m){ return m.matchStatus === 'NEEDS_REVIEW'; }).length,
      low: matches.filter(function(m){ return m.matchStatus === 'LOW_CONFIDENCE'; }).length
    },
    warnings: (worksheet.warnings || []).concat(erp.warnings || []),
    fatal: (worksheet.fatal || []).concat(erp.fatal || [])
  };
}



/**
 * FEELHAUS EVENT VENDOR - Approval link candidate V126~V130
 * Purpose: convert readonly ERP event match candidates into approval-review packages.
 * Note: Read-only only. No write, no sync, no ERP master update.
 */
var FH_EV_APPROVAL_LINK_CANDIDATE_V130_BUILD = 'EVENT_VENDOR_APPROVAL_LINK_CANDIDATE_V130_20260522';

function getEventVendorApprovalLinkCandidatesV130() {
  var match = getEventVendorErpEventMatchCandidatesV125();
  var likely = [];
  var review = [];
  var low = [];

  (match.matches || []).forEach(function(m) {
    var item = {
      worksheetTitle: m.worksheetTitle || '',
      worksheetSheetName: m.worksheetSheetName || '',
      worksheetSourceLabel: m.worksheetSourceLabel || '',
      eventId: m.eventId || '',
      eventName: m.eventName || '',
      venue: m.venue || '',
      status: m.status || '',
      startDate: m.startDate || '',
      endDate: m.endDate || '',
      matchScore: m.matchScore || 0,
      matchStatus: m.matchStatus || '',
      approvalStatus: 'WAITING_REVIEW',
      requiredChecks: [
        '행사명/단지명 육안 확인',
        '일정/장소 교차 확인',
        '중복 eventId 연결 여부 확인',
        '승인자 확인 후 연결 확정'
      ],
      note: '승인 전 읽기전용 연결 후보입니다. 자동 저장하지 않습니다.'
    };

    if (m.matchStatus === 'LIKELY_MATCH') likely.push(item);
    else if (m.matchStatus === 'NEEDS_REVIEW') review.push(item);
    else low.push(item);
  });

  var lines = [];
  lines.push('[필하우스 eventId 연결 후보 검토함]');
  lines.push('생성시각: ' + new Date().toISOString());
  lines.push('');
  lines.push('유력 후보: ' + likely.length + '건');
  likely.slice(0, 10).forEach(function(x, i) {
    lines.push((i+1) + '. ' + x.worksheetTitle + ' → ' + x.eventName + ' / ' + x.eventId + ' / score ' + x.matchScore);
  });
  lines.push('');
  lines.push('검토 필요: ' + review.length + '건');
  review.slice(0, 10).forEach(function(x, i) {
    lines.push((i+1) + '. ' + x.worksheetTitle + ' → ' + x.eventName + ' / ' + x.eventId + ' / score ' + x.matchScore);
  });
  lines.push('');
  lines.push('주의: 본 결과는 승인 전 후보입니다. ERP 원장, 실무시트, eventId를 자동 저장하지 않습니다.');

  return {
    ok: !!match.ok,
    build: FH_EV_APPROVAL_LINK_CANDIDATE_V130_BUILD,
    checkedAt: new Date().toISOString(),
    summary: {
      likely: likely.length,
      review: review.length,
      low: low.length,
      total: likely.length + review.length + low.length
    },
    likely: likely,
    review: review,
    low: low,
    handoffText: lines.join('\n'),
    message: 'ERP 행사 대조 결과를 승인 기반 연결 후보로 정리했습니다. 저장하지 않습니다.',
    warnings: match.warnings || [],
    fatal: match.fatal || []
  };
}



/**
 * FEELHAUS EVENT VENDOR - Link queue simulation V131~V135
 * Purpose: create readonly pending link queue and simulation before any approved write.
 * Note: Read-only only. No write, no sync, no ERP master update.
 */
var FH_EV_LINK_QUEUE_SIM_V135_BUILD = 'EVENT_VENDOR_LINK_QUEUE_SIM_V135_20260522';

function getEventVendorLinkQueueSimulationV135() {
  var approval = getEventVendorApprovalLinkCandidatesV130();
  var queue = [];
  var seenEvent = {};
  var seenSheet = {};
  var conflicts = [];

  (approval.likely || []).concat(approval.review || []).forEach(function(x) {
    var eventKey = String(x.eventId || '').trim();
    var sheetKey = String(x.worksheetSourceLabel || '') + '::' + String(x.worksheetSheetName || '');
    var conflictFlags = [];

    if (eventKey && seenEvent[eventKey]) conflictFlags.push('DUPLICATE_EVENT_ID_CANDIDATE');
    if (sheetKey && seenSheet[sheetKey]) conflictFlags.push('DUPLICATE_WORKSHEET_CANDIDATE');

    seenEvent[eventKey] = true;
    seenSheet[sheetKey] = true;

    if (conflictFlags.length) {
      conflicts.push({
        eventId: x.eventId,
        worksheetSheetName: x.worksheetSheetName,
        flags: conflictFlags
      });
    }

    queue.push({
      queueId: 'EVQLINK-' + Utilities.formatDate(new Date(), 'Asia/Seoul', 'yyyyMMddHHmmss') + '-' + (queue.length + 1),
      eventId: x.eventId || '',
      eventName: x.eventName || '',
      worksheetTitle: x.worksheetTitle || '',
      worksheetSheetName: x.worksheetSheetName || '',
      worksheetSourceLabel: x.worksheetSourceLabel || '',
      matchScore: x.matchScore || 0,
      matchStatus: x.matchStatus || '',
      approvalStatus: 'WAITING_APPROVAL',
      simulationStatus: conflictFlags.length ? 'CHECK_REQUIRED' : 'READY_TO_REVIEW',
      conflictFlags: conflictFlags,
      writePlan: [
        '승인 전: 저장 없음',
        '승인 후: 연결 큐 기록',
        '검증 후: eventId 매핑 반영 여부 별도 결정'
      ],
      note: '시뮬레이션 큐입니다. 실제 저장하지 않습니다.'
    });
  });

  var lines = [];
  lines.push('[필하우스 실무시트 연결 예정 큐 시뮬레이션]');
  lines.push('생성시각: ' + new Date().toISOString());
  lines.push('');
  lines.push('대상 큐: ' + queue.length + '건');
  lines.push('충돌/중복 확인 필요: ' + conflicts.length + '건');
  lines.push('');
  queue.slice(0, 20).forEach(function(q, i) {
    lines.push((i + 1) + '. ' + q.worksheetTitle + ' -> ' + q.eventName + ' / ' + q.eventId + ' / ' + q.simulationStatus);
  });
  lines.push('');
  lines.push('주의: 본 큐는 시뮬레이션입니다. 실무시트/ERP/eventId를 저장하지 않습니다.');

  return {
    ok: !!approval.ok,
    build: FH_EV_LINK_QUEUE_SIM_V135_BUILD,
    checkedAt: new Date().toISOString(),
    queue: queue,
    conflicts: conflicts,
    summary: {
      totalQueue: queue.length,
      ready: queue.filter(function(q){ return q.simulationStatus === 'READY_TO_REVIEW'; }).length,
      checkRequired: queue.filter(function(q){ return q.simulationStatus === 'CHECK_REQUIRED'; }).length,
      conflicts: conflicts.length
    },
    simulationText: lines.join('\n'),
    message: '승인 전 연결 예정 큐를 시뮬레이션으로 생성했습니다. 저장하지 않습니다.',
    warnings: approval.warnings || [],
    fatal: approval.fatal || []
  };
}



/**
 * FEELHAUS EVENT VENDOR - CONTROL handoff V136~V140
 * Purpose: create readonly CONTROL diagnostic/audit handoff from link queue simulation.
 * Note: Read-only only. No write, no sync, no ERP master update.
 */
var FH_EV_CONTROL_HANDOFF_V140_BUILD = 'EVENT_VENDOR_CONTROL_HANDOFF_V140_20260522';

function getEventVendorControlHandoffV140() {
  var queue = getEventVendorLinkQueueSimulationV135();
  var diagnostics = [];
  var auditDraft = [];

  diagnostics.push({
    code: 'QUEUE_TOTAL',
    level: queue.summary && queue.summary.totalQueue > 0 ? 'INFO' : 'WARN',
    message: '연결 예정 큐 ' + ((queue.summary && queue.summary.totalQueue) || 0) + '건',
    action: '승인 전 후보 검토'
  });

  diagnostics.push({
    code: 'QUEUE_CONFLICT',
    level: queue.summary && queue.summary.conflicts > 0 ? 'WARN' : 'OK',
    message: '충돌/중복 후보 ' + ((queue.summary && queue.summary.conflicts) || 0) + '건',
    action: 'CHECK_REQUIRED 후보 수동 확인'
  });

  (queue.queue || []).slice(0, 20).forEach(function(q) {
    auditDraft.push({
      logType: 'EVENT_VENDOR_WORKSHEET_LINK_QUEUE',
      action: 'SIMULATE_LINK',
      approvalStatus: 'WAITING_APPROVAL',
      eventId: q.eventId || '',
      targetName: q.eventName || '',
      sourceName: q.worksheetSourceLabel || '',
      sourceSheet: q.worksheetSheetName || '',
      simulationStatus: q.simulationStatus || '',
      note: '읽기전용 시뮬레이션. 저장/원장반영 없음.'
    });
  });

  var lines = [];
  lines.push('[CONTROL 이관 인계문 - 실무시트 연결 큐]');
  lines.push('빌드: ' + FH_EV_CONTROL_HANDOFF_V140_BUILD);
  lines.push('생성시각: ' + new Date().toISOString());
  lines.push('');
  lines.push('1. 현 단계');
  lines.push('- 실무시트 읽기전용 연결 완료');
  lines.push('- ERP 행사 대조 후보 생성 완료');
  lines.push('- 승인 기반 연결 후보/큐 시뮬레이션 완료');
  lines.push('');
  lines.push('2. CONTROL 점검 대상');
  diagnostics.forEach(function(d) {
    lines.push('- [' + d.level + '] ' + d.code + ': ' + d.message + ' / 조치: ' + d.action);
  });
  lines.push('');
  lines.push('3. 보호 원칙');
  lines.push('- 실무시트 쓰기 금지');
  lines.push('- ERP 원장 자동 반영 금지');
  lines.push('- eventId 자동 저장 금지');
  lines.push('- 승인 전 상태변경 금지');
  lines.push('');
  lines.push('4. 다음 단계');
  lines.push('- CONTROL에서 큐/충돌/승인상태 진단');
  lines.push('- 승인자 확인 후 별도 저장 빌드 진행');

  return {
    ok: !!queue.ok,
    build: FH_EV_CONTROL_HANDOFF_V140_BUILD,
    checkedAt: new Date().toISOString(),
    diagnostics: diagnostics,
    auditDraft: auditDraft,
    handoffText: lines.join('\n'),
    summary: {
      queueTotal: queue.summary && queue.summary.totalQueue || 0,
      ready: queue.summary && queue.summary.ready || 0,
      checkRequired: queue.summary && queue.summary.checkRequired || 0,
      conflicts: queue.summary && queue.summary.conflicts || 0,
      auditDraftRows: auditDraft.length
    },
    message: 'CONTROL 진단/감사로그 이관용 읽기전용 인계 데이터를 생성했습니다. 저장하지 않습니다.',
    warnings: queue.warnings || [],
    fatal: queue.fatal || []
  };
}



/**
 * FEELHAUS EVENT VENDOR - CONTROL schema draft V141~V145
 * Purpose: draft CONTROL receiving sheet/schema structure for diagnostics, audit, approval queue.
 * Note: Read-only only. No write, no sync, no ERP master update.
 */
var FH_EV_CONTROL_SCHEMA_V145_BUILD = 'EVENT_VENDOR_CONTROL_SCHEMA_V145_20260522';

function getEventVendorControlSchemaDraftV145() {
  var handoff = getEventVendorControlHandoffV140();

  var sheets = [
    {
      sheetName: 'CONTROL_EventVendor_Diagnostics',
      purpose: '행사관리 실무시트 연결 큐 진단 수신',
      protected: true,
      headers: ['logId','checkedAt','build','sourceModule','diagnosticCode','level','message','action','eventId','status','createdAt','createdBy']
    },
    {
      sheetName: 'CONTROL_EventVendor_AuditDraft',
      purpose: '감사로그 저장 전 검토 초안',
      protected: true,
      headers: ['logId','createdAt','sourceModule','logType','action','approvalStatus','eventId','targetName','sourceName','sourceSheet','simulationStatus','note','createdBy']
    },
    {
      sheetName: 'CONTROL_EventVendor_ApprovalQueue',
      purpose: '승인/반려/보류 후보 큐',
      protected: true,
      headers: ['approvalId','requestId','createdAt','sourceModule','eventId','eventName','sourceSheet','matchScore','approvalStatus','requestedBy','approvedBy','approvedAt','statusReason']
    },
    {
      sheetName: 'CONTROL_EventVendor_RollbackMemo',
      purpose: '연결 후보 반영 전후 롤백/복구 메모',
      protected: true,
      headers: ['rollbackId','createdAt','build','targetModule','eventId','rollbackPoint','rollbackReason','restoreAction','status','createdBy']
    }
  ];

  var lines = [];
  lines.push('[CONTROL 수신 시트 구조 초안]');
  lines.push('빌드: ' + FH_EV_CONTROL_SCHEMA_V145_BUILD);
  lines.push('생성시각: ' + new Date().toISOString());
  lines.push('');
  sheets.forEach(function(s, i) {
    lines.push((i + 1) + '. ' + s.sheetName);
    lines.push('- 목적: ' + s.purpose);
    lines.push('- 보호: ' + (s.protected ? 'Y' : 'N'));
    lines.push('- 헤더: ' + s.headers.join(', '));
    lines.push('');
  });
  lines.push('주의: 본 구조는 CONTROL 이관용 초안입니다. 현재 ERP/실무시트에 쓰기 작업을 하지 않습니다.');

  return {
    ok: !!handoff.ok,
    build: FH_EV_CONTROL_SCHEMA_V145_BUILD,
    checkedAt: new Date().toISOString(),
    sheets: sheets,
    schemaText: lines.join('\n'),
    sourceSummary: handoff.summary || {},
    message: 'CONTROL 수신용 진단/감사/승인/롤백 시트 구조 초안을 생성했습니다. 저장하지 않습니다.',
    warnings: handoff.warnings || [],
    fatal: handoff.fatal || []
  };
}



/**
 * FEELHAUS EVENT VENDOR - CONTROL brief V146~V150
 * Purpose: create CONTROL project handoff/build criteria based on readonly schema draft.
 * Note: Read-only only. No write, no sync, no ERP master update.
 */
var FH_EV_CONTROL_BRIEF_V150_BUILD = 'EVENT_VENDOR_CONTROL_BRIEF_V150_20260522';

function getEventVendorControlBriefV150() {
  var schema = getEventVendorControlSchemaDraftV145();

  var sections = [
    {
      title: '1. 현재 완료 상태',
      lines: [
        '실무시트 원본 링크 등록 완료',
        '실무시트 서버 읽기전용 연결 확인 완료',
        '실무시트 업무분류/행사 후보/선택행사 요약 구현',
        'ERP 행사 대조/연결 검토함/큐 시뮬레이션 구현',
        'CONTROL 수신 구조 초안 생성 완료'
      ]
    },
    {
      title: '2. CONTROL 보호 대상',
      lines: [
        'SystemConfig 자동 읽기',
        'FEELHAUS_DB_MASTER 연결',
        'eventId / vendorId / customerId 등 공통 ID',
        '감사로그/승인큐/진단결과',
        '롤백/복구 메모',
        '정산/취소정산/환수/추가지급 흐름'
      ]
    },
    {
      title: '3. CONTROL 테스트 체크리스트',
      lines: [
        '수신 시트 헤더 존재 여부',
        '중복 eventId 후보 감지 여부',
        '승인 전 저장 차단 여부',
        '감사로그 초안 생성 여부',
        '롤백 기준점 생성 여부',
        'ERP 원장/실무시트 쓰기 차단 여부'
      ]
    },
    {
      title: '4. ERP와 CONTROL 책임 분리',
      lines: [
        'ERP: 행사관리 화면, 실무시트 읽기전용 후보 표시',
        'ERP: 사용자 검토/후보 인계문 생성',
        'CONTROL: 진단, 승인큐, 감사로그, 롤백/복구 기준 관리',
        'CONTROL: 승인 후 저장 가능 여부 판정',
        'SIGN/PORTAL/FORM: 본 단계에서 변경 없음'
      ]
    }
  ];

  var lines = [];
  lines.push('[필하우스 CONTROL 프로젝트 인계문]');
  lines.push('빌드: ' + FH_EV_CONTROL_BRIEF_V150_BUILD);
  lines.push('생성시각: ' + new Date().toISOString());
  lines.push('');
  sections.forEach(function(sec) {
    lines.push(sec.title);
    sec.lines.forEach(function(line) { lines.push('- ' + line); });
    lines.push('');
  });
  lines.push('CONTROL 수신 시트 초안:');
  (schema.sheets || []).forEach(function(s) {
    lines.push('- ' + s.sheetName + ' / ' + s.purpose);
  });
  lines.push('');
  lines.push('주의: 본 인계문은 빌드 기준입니다. 현재 단계에서는 CONTROL 시트 생성/ERP 저장/실무시트 쓰기를 하지 않습니다.');

  return {
    ok: !!schema.ok,
    build: FH_EV_CONTROL_BRIEF_V150_BUILD,
    checkedAt: new Date().toISOString(),
    sections: sections,
    schemaSheets: schema.sheets || [],
    briefText: lines.join('\n'),
    message: 'CONTROL 프로젝트 인계문/빌드 기준을 생성했습니다. 저장하지 않습니다.',
    warnings: schema.warnings || [],
    fatal: schema.fatal || []
  };
}



/**
 * FEELHAUS EVENT VENDOR - Phase1 stabilize V151~V155
 * Purpose: provide phase-1 completion summary for worksheet readonly integration.
 * Note: Read-only only. No write, no sync, no ERP master update.
 */
var FH_EV_PHASE1_STABILIZE_V155_BUILD = 'EVENT_VENDOR_PHASE1_STABILIZE_V155_20260522';

function getEventVendorPhase1StabilizeSummaryV155() {
  var brief = getEventVendorControlBriefV150();
  var summary = {
    ok: !!brief.ok,
    build: FH_EV_PHASE1_STABILIZE_V155_BUILD,
    checkedAt: new Date().toISOString(),
    phase: 'EVENT_VENDOR_WORKSHEET_READONLY_PHASE1',
    completed: [
      'SystemConfig WORK_* 실무시트 키 등록',
      '실무시트 원본 링크 연결',
      '서버 읽기전용 접근 확인',
      '시트 업무분류',
      '행사 후보 추출',
      '선택행사 후보/요약',
      '업무탭별 요약',
      'ERP 행사 대조',
      '승인 기반 연결 후보',
      '연결 큐 시뮬레이션',
      'CONTROL 이관/구조/인계문'
    ],
    hold: [
      '실무시트 쓰기',
      'ERP 원장 자동 반영',
      'eventId 자동 저장',
      '감사로그 실제 저장',
      '승인 큐 실제 저장',
      '정산 실행'
    ],
    next: [
      'CONTROL 프로젝트에서 수신 구조 검토',
      '승인 큐/감사로그/진단 시트 실제 생성 여부 결정',
      '승인 후 저장 빌드 별도 진행',
      '행사관리 UI는 기능 안정화 후 통합 정리'
    ],
    message: '행사관리 실무시트 읽기전용 연결 1차 안정판입니다. 저장 기능은 아직 열지 않습니다.',
    warnings: brief.warnings || [],
    fatal: brief.fatal || []
  };

  var lines = [];
  lines.push('[필하우스 행사관리 실무시트 연결 1차 안정판]');
  lines.push('빌드: ' + FH_EV_PHASE1_STABILIZE_V155_BUILD);
  lines.push('생성시각: ' + summary.checkedAt);
  lines.push('');
  lines.push('완료 기능');
  summary.completed.forEach(function(x) { lines.push('- ' + x); });
  lines.push('');
  lines.push('아직 잠금/보류');
  summary.hold.forEach(function(x) { lines.push('- ' + x); });
  lines.push('');
  lines.push('다음 개발 경로');
  summary.next.forEach(function(x) { lines.push('- ' + x); });

  summary.phaseText = lines.join('\n');
  return summary;
}



/**
 * FEELHAUS EVENT VENDOR - UI menu light V156~V160
 * Purpose: readonly UI/menu light mode summary.
 * Note: UI organization only. No write, no sync, no ERP master update.
 */
var FH_EV_UI_MENU_LIGHT_V160_BUILD = 'EVENT_VENDOR_UI_MENU_LIGHT_V160_20260522';

function getEventVendorUiMenuLightSummaryV160() {
  return {
    ok: true,
    build: FH_EV_UI_MENU_LIGHT_V160_BUILD,
    checkedAt: new Date().toISOString(),
    mode: 'UI_MENU_LIGHT_PHASE',
    visibleBasic: [
      '행사관리',
      '실무시트 확인',
      '업무탭 요약',
      '연결 리포트',
      '1차 안정판'
    ],
    hiddenAdvanced: [
      '시트 업무분류',
      '행사 후보',
      '선택행사 연결',
      '선택행사 요약',
      '업무흐름 연결',
      'ERP 행사 대조',
      '연결 검토함',
      '연결 큐',
      'CONTROL 인계',
      'CONTROL 구조',
      'CONTROL 인계문'
    ],
    message: 'UI/메뉴 경량화 기준입니다. 기능은 삭제하지 않고 고급 메뉴로 접습니다.',
    warnings: [],
    fatal: []
  };
}



/**
 * FEELHAUS EVENT VENDOR - Field compact V161~V165
 * Purpose: compact default field operation screen by closing advanced panels on load.
 * Note: UI organization only. No write, no sync, no ERP master update.
 */
var FH_EV_FIELD_COMPACT_V165_BUILD = 'EVENT_VENDOR_FIELD_COMPACT_V165_20260522';

function getEventVendorFieldCompactSummaryV165() {
  return {
    ok: true,
    build: FH_EV_FIELD_COMPACT_V165_BUILD,
    checkedAt: new Date().toISOString(),
    mode: 'FIELD_COMPACT_DEFAULT',
    visible: ['행사관리', '실무시트 확인', '업무탭 요약', '연결 리포트', '1차 안정판', '고급 기능'],
    collapsedPanels: [
      '실무시트 업무분류 V92',
      '실무시트 행사 후보 V93~V96',
      '선택 행사 실무시트 연결 V97~V100',
      '선택 행사 실무시트 요약 V101~V105',
      '업무탭별 실무시트 요약 V106~V110',
      '행사관리 업무 흐름 연결 V111~V115',
      '실무시트 연결 리포트 V116~V120',
      'ERP 행사 대조 V121~V125',
      '승인 기반 연결 후보 V126~V130',
      '연결 예정 큐 시뮬레이션 V131~V135',
      'CONTROL 이관 준비 V136~V140',
      'CONTROL 수신 구조 V141~V145',
      'CONTROL 인계문 V146~V150'
    ],
    message: '현장 운영 기본화면은 고급 패널을 모두 접고 필요한 버튼만 노출합니다.',
    warnings: [],
    fatal: []
  };
}



/**
 * FEELHAUS EVENT VENDOR - Emergency rollback V221
 * Purpose: remove accumulated UI overlays and restore stable legacy event/vendor screen.
 * Note: UI rollback only. No write, no sync, no ERP master update.
 */
var FH_EV_EMERGENCY_ROLLBACK_V221_BUILD = 'V221 ROLLBACK';

function getEventVendorEmergencyRollbackSummaryV221() {
  return {
    ok: true,
    build: FH_EV_EMERGENCY_ROLLBACK_V221_BUILD,
    checkedAt: new Date().toISOString(),
    mode: 'EMERGENCY_ROLLBACK_STABLE_UI',
    source: "EVENT_VENDOR_FIELD_COMPACT_BATCH_V161_TO_V165.zip::_ROLLBACK/V165",
    message: 'V170~V220 overlay UI removed. Minimal rollback badge only.',
    warnings: [],
    fatal: []
  };
}



/**
 * FEELHAUS EVENT VENDOR - Worksheet and width restore V231
 * Purpose: restore V80 readonly worksheet client action and harden bottom width overflow.
 * Note: UI/client call restore only. No write, no sync, no ERP master update.
 */
var FH_EV_WORKSHEET_WIDTH_FIX_V231_BUILD = 'V231 실무시트/폭복구';

function getEventVendorWorksheetWidthFixSummaryV231() {
  return {
    ok: true,
    build: FH_EV_WORKSHEET_WIDTH_FIX_V231_BUILD,
    checkedAt: new Date().toISOString(),
    mode: 'WORKSHEET_V80_AND_WIDTH_FIX',
    fixed: ['FH_EV_WORKSHEET_V80_loadSummary 우선 호출', 'getEventVendorWorksheetLinkSummaryV80 서버 직접 호출 fallback', '하단 기능점검판 좌우폭 안정'],
    message: '기존 실무시트 연결 기능을 살리고 하단 가로폭 터짐을 정리합니다.',
    warnings: [],
    fatal: []
  };
}



/**
 * FEELHAUS EVENT VENDOR - Worksheet raw mirror V232
 * Purpose: mirror original worksheet headers/rows into ERP event screen as readonly paged tables.
 * Note: Read-only only. No write, no sync, no ERP master update.
 */
var FH_EV_WORKSHEET_MIRROR_V232_BUILD = 'V232 실무시트원본미러';

function fhEvWorksheetMirrorToDisplayV232_(v) {
  if (v === null || typeof v === 'undefined') return '';
  if (Object.prototype.toString.call(v) === '[object Date]') {
    try {
      return Utilities.formatDate(v, Session.getScriptTimeZone(), 'yyyy-MM-dd HH:mm');
    } catch (e) {
      return String(v);
    }
  }
  return String(v);
}

function fhEvWorksheetMirrorSourcesV232_() {
  var cfg = fhEvWorksheetGetConfigMapV80_();
  return [
    {
      sourceKey: 'WORK_CALENDAR',
      label: '입주캘린더(제안서)',
      spreadsheetId: cfg.WORK_CALENDAR_SPREADSHEET_ID || '',
      url: cfg.WORK_CALENDAR_SPREADSHEET_URL || ''
    },
    {
      sourceKey: 'WORK_PROGRESS',
      label: '입주박람회 진행',
      spreadsheetId: cfg.WORK_PROGRESS_SPREADSHEET_ID || '',
      url: cfg.WORK_PROGRESS_SPREADSHEET_URL || ''
    }
  ];
}

function getEventVendorWorksheetMirrorIndexV232() {
  var report = {
    ok: true,
    build: FH_EV_WORKSHEET_MIRROR_V232_BUILD,
    checkedAt: new Date().toISOString(),
    sources: [],
    warnings: [],
    fatal: []
  };

  try {
    fhEvWorksheetMirrorSourcesV232_().forEach(function(src) {
      var item = {
        sourceKey: src.sourceKey,
        label: src.label,
        spreadsheetId: src.spreadsheetId,
        url: src.url,
        ok: false,
        title: '',
        sheetCount: 0,
        sheets: [],
        message: ''
      };

      if (!src.spreadsheetId) {
        item.message = 'SystemConfig에 원본 스프레드시트 ID가 없습니다.';
        report.warnings.push({ sourceKey: src.sourceKey, message: item.message });
        report.sources.push(item);
        return;
      }

      try {
        var ss = SpreadsheetApp.openById(src.spreadsheetId);
        item.ok = true;
        item.title = ss.getName();
        item.sheets = ss.getSheets().map(function(sh) {
          return {
            name: sh.getName(),
            sheetId: sh.getSheetId(),
            lastRow: sh.getLastRow(),
            lastColumn: sh.getLastColumn(),
            frozenRows: sh.getFrozenRows()
          };
        });
        item.sheetCount = item.sheets.length;
        item.message = '원본 시트 목록 조회 완료';
      } catch (err) {
        item.message = '원본 접근 실패: ' + String(err && err.message ? err.message : err);
        report.ok = false;
        report.warnings.push({ sourceKey: src.sourceKey, message: item.message });
      }
      report.sources.push(item);
    });
  } catch (err) {
    report.ok = false;
    report.fatal.push({ name: 'exception', message: String(err && err.message ? err.message : err) });
  }

  return report;
}

function getEventVendorWorksheetRawRowsV232(request) {
  request = request || {};
  var sourceKey = String(request.sourceKey || '').trim() || 'WORK_CALENDAR';
  var sheetName = String(request.sheetName || '').trim();
  var startRow = Math.max(1, Number(request.startRow || 1));
  var limit = Math.max(1, Math.min(Number(request.limit || 100), 300));

  var report = {
    ok: true,
    build: FH_EV_WORKSHEET_MIRROR_V232_BUILD,
    checkedAt: new Date().toISOString(),
    sourceKey: sourceKey,
    sheetName: sheetName,
    startRow: startRow,
    limit: limit,
    totalRows: 0,
    totalColumns: 0,
    headerRow: 1,
    headers: [],
    rows: [],
    nextStartRow: 0,
    sourceTitle: '',
    sourceLabel: '',
    message: '',
    warnings: [],
    fatal: []
  };

  try {
    var sources = fhEvWorksheetMirrorSourcesV232_();
    var src = null;
    sources.forEach(function(s) {
      if (s.sourceKey === sourceKey) src = s;
    });
    if (!src) throw new Error('알 수 없는 sourceKey: ' + sourceKey);
    if (!src.spreadsheetId) throw new Error('SystemConfig에 ' + sourceKey + ' 스프레드시트 ID가 없습니다.');

    var ss = SpreadsheetApp.openById(src.spreadsheetId);
    report.sourceTitle = ss.getName();
    report.sourceLabel = src.label;

    var sh = sheetName ? ss.getSheetByName(sheetName) : ss.getSheets()[0];
    if (!sh) throw new Error('원본 시트를 찾을 수 없습니다: ' + sheetName);

    report.sheetName = sh.getName();
    report.totalRows = sh.getLastRow();
    report.totalColumns = sh.getLastColumn();

    if (report.totalRows < 1 || report.totalColumns < 1) {
      report.message = '원본 시트에 표시할 데이터가 없습니다.';
      return report;
    }

    var headerValues = sh.getRange(1, 1, 1, report.totalColumns).getValues()[0];
    report.headers = headerValues.map(function(h, i) {
      var label = fhEvWorksheetMirrorToDisplayV232_(h).trim();
      return label || ('COL_' + (i + 1));
    });

    var safeStart = Math.min(startRow, report.totalRows);
    var rowCount = Math.max(0, Math.min(limit, report.totalRows - safeStart + 1));
    if (rowCount > 0) {
      var values = sh.getRange(safeStart, 1, rowCount, report.totalColumns).getValues();
      report.rows = values.map(function(row, rIdx) {
        return {
          rowNumber: safeStart + rIdx,
          values: row.map(fhEvWorksheetMirrorToDisplayV232_)
        };
      });
    }

    report.nextStartRow = (safeStart + rowCount <= report.totalRows) ? safeStart + rowCount : 0;
    report.message = '원본 행/열을 읽기전용으로 ERP 화면에 표시합니다. 저장하지 않습니다.';
  } catch (err) {
    report.ok = false;
    report.fatal.push({ name: 'exception', message: String(err && err.message ? err.message : err) });
    report.message = '원본 행/열 조회 실패';
  }

  return report;
}

function getEventVendorWorksheetMirrorSummaryV232() {
  return {
    ok: true,
    build: FH_EV_WORKSHEET_MIRROR_V232_BUILD,
    checkedAt: new Date().toISOString(),
    mode: 'WORKSHEET_RAW_ROWS_READONLY_MIRROR',
    functions: [
      'getEventVendorWorksheetMirrorIndexV232',
      'getEventVendorWorksheetRawRowsV232'
    ],
    message: '실무시트 원본 행/열을 ERP 행사관리 화면에 읽기전용으로 미러링합니다.',
    warnings: [],
    fatal: []
  };
}


