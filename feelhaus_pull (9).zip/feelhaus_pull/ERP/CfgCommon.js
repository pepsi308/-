var FH_CFG = (function () {
  var SETUP_DB_ID = '17VMSpgSZCvIrUlgcw8yCNcnl8WQWo2IcRf5tDCcuJGM';
  var CONFIG_SHEET_NAME = 'SystemConfig';
  var CACHE_SEC = 120;

  function getSetupSs_() {
    return SpreadsheetApp.openById(SETUP_DB_ID);
  }

  function getConfigSheet_() {
    return getSetupSs_().getSheetByName(CONFIG_SHEET_NAME);
  }

  function toMap_() {
    var cache = CacheService.getScriptCache();
    var cached = cache.get('FH_CFG_MAP');
    if (cached) return JSON.parse(cached);
    var sh = getConfigSheet_();
    if (!sh) throw new Error('SystemConfig 시트를 찾을 수 없습니다.');
    var values = sh.getDataRange().getValues();
    if (values.length < 2) return {};
    var head = values[0];
    var k = head.indexOf('CONFIG_KEY');
    var v = head.indexOf('VALUE');
    var s = head.indexOf('status');
    if (k < 0 || v < 0) throw new Error('SystemConfig 헤더 CONFIG_KEY/VALUE 누락');
    var map = {};
    for (var i = 1; i < values.length; i++) {
      var row = values[i];
      var key = String(row[k] || '').trim();
      var val = row[v];
      var status = s >= 0 ? String(row[s] || '').trim().toUpperCase() : 'ACTIVE';
      if (!key) continue;
      if (status && status !== 'ACTIVE') continue;
      map[key] = val;
    }
    cache.put('FH_CFG_MAP', JSON.stringify(map), CACHE_SEC);
    return map;
  }

  function get(key, fallback) {
    var map = toMap_();
    if (Object.prototype.hasOwnProperty.call(map, key)) return map[key];
    var aliases = {
      FEELHAUS_SETUP_DB_ID: ['SETUP_DB_ID'],
      FEELHAUS_DB_MASTER_ID: ['DB_MASTER_ID', 'SPREADSHEET_ID'],
      SIGN_SPREADSHEET_ID: ['SIGN_DB_ID'],
      BACKUP_FOLDER_ID: [],
      ROOT_FOLDER_ID: []
    };
    var arr = aliases[key] || [];
    for (var i = 0; i < arr.length; i++) {
      if (Object.prototype.hasOwnProperty.call(map, arr[i])) return map[arr[i]];
    }
    return fallback;
  }

  function require(key) {
    var value = get(key, '');
    if (value === '' || value === null || typeof value === 'undefined') {
      throw new Error('필수 설정 누락: ' + key);
    }
    return value;
  }

  function openMaster() {
    return SpreadsheetApp.openById(require('FEELHAUS_DB_MASTER_ID'));
  }

  function openSignDb() {
    return SpreadsheetApp.openById(require('SIGN_SPREADSHEET_ID'));
  }

  function dump() {
    return toMap_();
  }

  return {
    get: get,
    require: require,
    openMaster: openMaster,
    openSignDb: openSignDb,
    dump: dump
  };
})();
