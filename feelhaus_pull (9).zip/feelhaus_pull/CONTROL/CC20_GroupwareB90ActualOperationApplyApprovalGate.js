/**
 * FEELHAUS CONTROL - GROUPWARE B90 ACTUAL OPERATION APPLY APPROVAL GATE
 * Build: CONTROL_GROUPWARE_B90_ACTUAL_OPERATION_APPLY_APPROVAL_V01
 * Progress: [07/10] 70%
 * Target baseline: GROUPWARE_B90_FINAL_STABLE_AFTER_B70_B90_RUNALL
 * Execution function: runControlGroupwareB90ActualOperationApplyApprovalGateV01
 *
 * Safety:
 * - Diagnostic only
 * - Sheet read only
 * - No sheet creation
 * - No header mutation
 * - No approval writing
 * - No audit log writing
 * - No backup/deploy/recovery/rollback execution
 * - No GROUPWARE production save
 * - No field use open execution
 * - No real apply execution
 */
var CC20_BUILD = 'CONTROL_GROUPWARE_B90_ACTUAL_OPERATION_APPLY_APPROVAL_V01';
var CC20_MODE = 'GROUPWARE_B90_ACTUAL_OPERATION_APPLY_APPROVAL_DIAGNOSTIC_ONLY_NO_UPDATE';
var CC20_PROGRESS = { current: 7, total: 10, percent: 70 };
var CC20_SETUP_DB_ID = '17VMSpgSZCvIrUlgcw8yCNcnl8WQWo2IcRf5tDCcuJGM';
var CC20_CONFIG_SHEET_NAME = 'SystemConfig';
var CC20_SOURCE_DB = 'FEELHAUS_SETUP_DB';
var CC20_TARGET = {
  projectCode: 'GROUPWARE',
  moduleCode: 'GROUPWARE_PORTAL_HR_MAIL_CALENDAR',
  buildRange: 'B70~B90',
  currentBuildNo: 'B90',
  finalBuildNo: 'B90',
  buildProgress: '90 / 90',
  progressPercent: 100,
  runAllStatus: 'GROUPWARE_B70_TO_B90_RUNALL_PASS',
  protectedBaseline: 'B70~B89',
  finalStableName: 'GROUPWARE_B90_FINAL_STABLE',
  fieldUseOpenDecisionGateBuild: 'CONTROL_GROUPWARE_B90_FIELD_USE_OPEN_DECISION_V01',
  requiredApprovalType: 'GROUPWARE_B90_ACTUAL_OPERATION_APPLY_APPROVAL',
  requiredApprovalScope: 'GROUPWARE_B90_ACTUAL_OPERATION_APPLY',
  requiredTargetAction: 'GROUPWARE_B90_ACTUAL_OPERATION_APPLY',
  relatedBuild: 'GROUPWARE_B90_FINAL_STABLE'
};

function runControlGroupwareB90ActualOperationApplyApprovalGateV01() {
  var result = diagnoseControlGroupwareB90ActualOperationApplyApprovalGateV01_();
  CC20_logCompactResult_(result);
  return result;
}

function runGroupwareB90ActualOperationApplyApprovalGateV01() {
  var result = diagnoseControlGroupwareB90ActualOperationApplyApprovalGateV01_();
  CC20_logCompactResult_(result);
  return result;
}

function getControlGroupwareB90ActualOperationApplyApprovalGateData() {
  var result = diagnoseControlGroupwareB90ActualOperationApplyApprovalGateV01_();
  CC20_logCompactResult_(result);
  return result;
}

function controlGroupwareB90ActualOperationApplyApprovalGateV01() {
  var result = diagnoseControlGroupwareB90ActualOperationApplyApprovalGateV01_();
  CC20_logCompactResult_(result);
  return result;
}

function diagnoseControlGroupwareB90ActualOperationApplyApprovalGateV01_() {
  var started = new Date();
  var fatal = [];
  var hold = [];
  var warnings = [];
  var details = {};
  var summary = CC20_defaultSummary_();

  try {
    details.setup = CC20_readSystemConfig_();
    summary.configOk = details.setup.ok === true;
    summary.systemConfigAutoReadOk = details.setup.ok === true;
  } catch (e1) {
    fatal.push('SystemConfig 자동 읽기 실패: ' + CC20_errorMessage_(e1));
    details.setup = { ok: false, error: CC20_errorMessage_(e1), config: {} };
  }

  try {
    var cfg = details.setup && details.setup.config ? details.setup.config : {};
    details.master = CC20_openMasterDb_(cfg);
    summary.masterOk = details.master.ok === true;
    summary.masterConnectedOk = details.master.ok === true;
  } catch (e2) {
    fatal.push('FEELHAUS_DB_MASTER 연결 실패: ' + CC20_errorMessage_(e2));
    details.master = { ok: false, error: CC20_errorMessage_(e2) };
  }

  details.fieldUseOpenDecisionGate = CC20_checkFieldUseOpenDecisionGate_();
  summary.fieldUseOpenDecisionGatePassed = details.fieldUseOpenDecisionGate.passed === true;
  summary.fieldUseOpenDecisionOk = details.fieldUseOpenDecisionGate.fieldUseOpenDecisionOk === true;
  summary.fieldUseOpenAllowed = details.fieldUseOpenDecisionGate.fieldUseOpenAllowed === true;
  summary.deployAllowed = details.fieldUseOpenDecisionGate.deployAllowed === true;

  try {
    details.approval = CC20_findActualOperationApplyApproval_(details.master && details.master.ss);
    summary.approvalSheetReadableOk = details.approval.sheetReadableOk === true;
    summary.actualOperationApplyApprovalEvidenceOk = details.approval.approvalEvidenceOk === true;
    summary.actualOperationApplyApprovalScopeOk = details.approval.approvalScopeOk === true;
    summary.actualOperationApplyApprovalStatusOk = details.approval.approvalStatusOk === true;
    summary.actualOperationApplyApprovalActorOk = details.approval.approvalActorOk === true;
    summary.actualOperationApplyApprovalGateOk = summary.actualOperationApplyApprovalEvidenceOk && summary.actualOperationApplyApprovalScopeOk && summary.actualOperationApplyApprovalStatusOk && summary.actualOperationApplyApprovalActorOk;
  } catch (e3) {
    fatal.push('ApprovalLog 실제 운영 반영 승인 증빙 확인 실패: ' + CC20_errorMessage_(e3));
    details.approval = { sheetReadableOk: false, error: CC20_errorMessage_(e3) };
  }

  details.operationBlock = CC20_operationBlock_();
  summary.productionSaveAllowed = false;
  summary.realApplyAllowed = false;
  summary.actualExecutionBlocked = true;
  summary.actualDeployAllowed = false;
  summary.actualFieldUseOpenAllowed = false;
  summary.actualRealApplyAllowed = false;
  summary.diagnosticOnly = true;
  summary.dryRunOnly = true;

  if (!summary.fieldUseOpenDecisionGatePassed) hold.push('[06/10] CONTROL_GROUPWARE_B90_FIELD_USE_OPEN_DECISION_V01 PASS 확인 필요');
  if (!summary.fieldUseOpenDecisionOk) hold.push('[06/10] field use open decision OK 확인 필요');
  if (!summary.approvalSheetReadableOk) hold.push('ApprovalLog 시트 읽기 확인 필요');
  if (!summary.actualOperationApplyApprovalEvidenceOk) hold.push('GROUPWARE B90 실제 운영 반영 승인 증빙 행 추가 필요: ' + CC20_TARGET.requiredApprovalType);
  if (summary.actualOperationApplyApprovalEvidenceOk && !summary.actualOperationApplyApprovalScopeOk) hold.push('GROUPWARE B90 실제 운영 반영 승인 scope 확인 필요: ' + CC20_TARGET.requiredApprovalScope);
  if (summary.actualOperationApplyApprovalEvidenceOk && !summary.actualOperationApplyApprovalStatusOk) hold.push('GROUPWARE B90 실제 운영 반영 승인 상태 APPROVED 확인 필요');
  if (summary.actualOperationApplyApprovalEvidenceOk && !summary.actualOperationApplyApprovalActorOk) hold.push('GROUPWARE B90 실제 운영 반영 승인자/승인시각 확인 필요');

  var passConditions = [
    summary.configOk,
    summary.masterOk,
    summary.fieldUseOpenDecisionGatePassed,
    summary.fieldUseOpenDecisionOk,
    summary.deployAllowed,
    summary.fieldUseOpenAllowed,
    summary.approvalSheetReadableOk,
    summary.actualOperationApplyApprovalEvidenceOk,
    summary.actualOperationApplyApprovalScopeOk,
    summary.actualOperationApplyApprovalStatusOk,
    summary.actualOperationApplyApprovalActorOk,
    summary.actualOperationApplyApprovalGateOk,
    summary.actualExecutionBlocked,
    summary.actualDeployAllowed === false,
    summary.actualFieldUseOpenAllowed === false,
    summary.actualRealApplyAllowed === false,
    summary.productionSaveAllowed === false,
    summary.realApplyAllowed === false
  ];

  var allPass = fatal.length === 0 && hold.length === 0 && CC20_allTrue_(passConditions);
  var judgement = fatal.length > 0 ? 'BLOCK' : (allPass ? 'PASS' : 'HOLD');
  summary.actualOperationApplyReadinessOk = judgement === 'PASS';
  summary.actualOperationApplyAllowedCandidate = judgement === 'PASS';
  summary.judgement = judgement;

  return {
    ok: judgement === 'PASS',
    build: CC20_BUILD,
    progress: CC20_PROGRESS,
    mode: CC20_MODE,
    checkedAt: CC20_now_(),
    judgement: judgement,
    targetBaseline: CC20_TARGET,
    summary: summary,
    evidence: {
      setupDbId: CC20_SETUP_DB_ID,
      configSheetName: CC20_CONFIG_SHEET_NAME,
      sourceDb: CC20_SOURCE_DB,
      setupDbName: details.setup && details.setup.setupDbName || '',
      masterDbIdMasked: CC20_maskId_(details.master && details.master.masterDbId || ''),
      masterDbName: details.master && details.master.masterDbName || '',
      fieldUseOpenDecisionGate: details.fieldUseOpenDecisionGate || {},
      approvalSheetName: details.approval && details.approval.sheetName || 'ApprovalLog',
      actualOperationApplyApprovalCandidateCount: details.approval && details.approval.approvalCandidateCount || 0,
      approvedActualOperationApplyCount: details.approval && details.approval.approvedGroupwareB90ActualApplyCount || 0,
      latestActualOperationApplyApproval: details.approval && details.approval.latestGroupwareB90ActualApplyApproval || null,
      requiredApprovalType: CC20_TARGET.requiredApprovalType,
      requiredApprovalScope: CC20_TARGET.requiredApprovalScope,
      requiredTargetAction: CC20_TARGET.requiredTargetAction,
      relatedBuild: CC20_TARGET.relatedBuild,
      readinessReason: judgement === 'PASS' ? '[07/10] Actual operation apply approval PASS. Field use open decision PASS and approval evidence were confirmed. This gate still executes no production change.' : '',
      actualBackupAllowed: false,
      actualDeployAllowed: false,
      actualRecoveryAllowed: false,
      actualRollbackAllowed: false,
      actualProductionSaveAllowed: false,
      actualFieldUseOpenAllowed: false,
      actualRealApplyAllowed: false,
      operationBlock: details.operationBlock || {},
      elapsedMs: new Date().getTime() - started.getTime()
    },
    warnings: warnings,
    hold: hold,
    fatal: fatal,
    nextAction: judgement === 'PASS'
      ? '[07/10] GROUPWARE B90 actual operation apply approval gate PASS. Next step is [08/10] actual execution ready gate. This gate executed no production change.'
      : '[07/10] GROUPWARE B90 actual operation apply approval gate is not PASS. Add actual apply approval evidence to ApprovalLog, then rerun.'
  };
}

function CC20_defaultSummary_() {
  return {
    baselineOk: true,
    configOk: false,
    masterOk: false,
    systemConfigAutoReadOk: false,
    masterConnectedOk: false,
    fieldUseOpenDecisionGatePassed: false,
    fieldUseOpenDecisionOk: false,
    deployAllowed: false,
    fieldUseOpenAllowed: false,
    approvalSheetReadableOk: false,
    actualOperationApplyApprovalEvidenceOk: false,
    actualOperationApplyApprovalScopeOk: false,
    actualOperationApplyApprovalStatusOk: false,
    actualOperationApplyApprovalActorOk: false,
    actualOperationApplyApprovalGateOk: false,
    actualOperationApplyReadinessOk: false,
    actualOperationApplyAllowedCandidate: false,
    productionSaveAllowed: false,
    realApplyAllowed: false,
    actualExecutionBlocked: true,
    actualDeployAllowed: false,
    actualFieldUseOpenAllowed: false,
    actualRealApplyAllowed: false,
    diagnosticOnly: true,
    dryRunOnly: true,
    sheetWriteExecuted: false,
    sheetCreateExecuted: false,
    headerAutoAddExecuted: false,
    approvalWriteExecuted: false,
    auditLogWriteExecuted: false,
    backupExecuted: false,
    deployExecuted: false,
    recoveryExecuted: false,
    rollbackExecuted: false,
    realApplyExecuted: false,
    productionDataMutationExecuted: false
  };
}

function CC20_readSystemConfig_() {
  var ss = SpreadsheetApp.openById(CC20_SETUP_DB_ID);
  var sheet = ss.getSheetByName(CC20_CONFIG_SHEET_NAME);
  if (!sheet) throw new Error('SystemConfig sheet not found: ' + CC20_CONFIG_SHEET_NAME);
  var values = sheet.getDataRange().getValues();
  var config = {};
  for (var i = 1; i < values.length; i++) {
    var key = String(values[i][0] || '').trim();
    var value = values[i][1];
    if (key) config[key] = value;
  }
  return { ok: true, setupDbId: CC20_SETUP_DB_ID, setupDbName: ss.getName(), sourceDb: CC20_SOURCE_DB, sheetName: CC20_CONFIG_SHEET_NAME, config: config };
}

function CC20_openMasterDb_(config) {
  config = config || {};
  var id = String(config.FEELHAUS_DB_MASTER_ID || config.FEELHAUS_DB_MASTER || config.DB_MASTER_ID || config.MASTER_DB_ID || '').trim();
  if (!id) throw new Error('FEELHAUS_DB_MASTER_ID is missing in SystemConfig');
  var ss = SpreadsheetApp.openById(id);
  return { ok: true, masterDbId: id, masterDbName: ss.getName(), ss: ss };
}

function CC20_checkFieldUseOpenDecisionGate_() {
  var out = { checked: false, available: false, passed: false, build: CC20_TARGET.fieldUseOpenDecisionGateBuild, judgement: '', fieldUseOpenDecisionOk: false, fieldUseOpenAllowed: false, deployAllowed: false };
  try {
    if (typeof runControlGroupwareB90FieldUseOpenDecisionGateV01 === 'function') {
      out.checked = true;
      out.available = true;
      var res = runControlGroupwareB90FieldUseOpenDecisionGateV01();
      out.judgement = res && res.judgement || '';
      out.passed = res && res.ok === true && res.judgement === 'PASS';
      out.fieldUseOpenDecisionOk = res && res.summary && res.summary.fieldUseOpenDecisionOk === true;
      out.fieldUseOpenAllowed = res && res.summary && res.summary.fieldUseOpenAllowed === true;
      out.deployAllowed = res && res.summary && res.summary.deployAllowed === true;
      out.latestGroupwareB90Approval = res && res.evidence && res.evidence.latestGroupwareB90Approval || null;
    } else {
      out.checked = true;
      out.available = false;
      out.note = 'runControlGroupwareB90FieldUseOpenDecisionGateV01 function not found in project runtime';
    }
  } catch (e) {
    out.checked = true;
    out.available = true;
    out.error = CC20_errorMessage_(e);
  }
  return out;
}

function CC20_findActualOperationApplyApproval_(masterSs) {
  var out = {
    sheetReadableOk: false,
    sheetName: 'ApprovalLog',
    approvalCandidateCount: 0,
    approvedGroupwareB90ActualApplyCount: 0,
    latestGroupwareB90ActualApplyApproval: null,
    approvalEvidenceOk: false,
    approvalScopeOk: false,
    approvalStatusOk: false,
    approvalActorOk: false
  };
  if (!masterSs) return out;
  var sheet = masterSs.getSheetByName('ApprovalLog') || masterSs.getSheetByName('CONTROL_ApprovalLog') || masterSs.getSheetByName('Approval_Log');
  if (!sheet) return out;
  out.sheetReadableOk = true;
  out.sheetName = sheet.getName();
  var values = sheet.getDataRange().getValues();
  if (!values || values.length < 2) return out;
  var header = CC20_headerMap_(values[0]);
  var candidates = [];
  for (var i = 1; i < values.length; i++) {
    var row = values[i];
    var approvalType = CC20_cell_(row, header, ['approvalType', 'type']);
    var approvalScope = CC20_cell_(row, header, ['approvalScope', 'scope']);
    var approvalStatus = CC20_cell_(row, header, ['approvalStatus', 'status']);
    var targetAction = CC20_cell_(row, header, ['targetAction', 'action']);
    var relatedBuild = CC20_cell_(row, header, ['relatedBuild', 'build', 'buildNo']);
    var status = CC20_cell_(row, header, ['status']);
    var approvedBy = CC20_cell_(row, header, ['approvedBy', 'approver', 'updatedBy']);
    var approvedAt = CC20_cell_(row, header, ['approvedAt', 'approvedDate', 'updatedAt']);
    var projectCode = CC20_cell_(row, header, ['projectCode', 'project']);
    var approvalId = CC20_cell_(row, header, ['approvalId', 'id']);
    var typeMatch = approvalType === CC20_TARGET.requiredApprovalType || targetAction === CC20_TARGET.requiredTargetAction;
    var buildMatch = relatedBuild === CC20_TARGET.relatedBuild || relatedBuild === CC20_TARGET.finalStableName || relatedBuild === CC20_TARGET.currentBuildNo || relatedBuild === CC20_TARGET.finalBuildNo;
    var projectMatch = !projectCode || projectCode === CC20_TARGET.projectCode;
    if (typeMatch && buildMatch && projectMatch) {
      candidates.push({
        approvalId: approvalId,
        approvalType: approvalType,
        approvalScope: approvalScope,
        approvalStatus: approvalStatus,
        approvedBy: approvedBy,
        approvedAt: CC20_normalizeDateValue_(approvedAt),
        targetAction: targetAction,
        relatedBuild: relatedBuild,
        status: status,
        rowNumber: i + 1
      });
    }
  }
  candidates.sort(CC20_sortApprovalDesc_);
  out.approvalCandidateCount = candidates.length;
  out.latestGroupwareB90ActualApplyApproval = candidates.length ? candidates[0] : null;
  if (out.latestGroupwareB90ActualApplyApproval) {
    var latest = out.latestGroupwareB90ActualApplyApproval;
    out.approvalEvidenceOk = true;
    out.approvalScopeOk = latest.approvalScope === CC20_TARGET.requiredApprovalScope;
    out.approvalStatusOk = latest.approvalStatus === 'APPROVED' && (!latest.status || latest.status === 'APPROVED');
    out.approvalActorOk = !!latest.approvedBy && !!latest.approvedAt;
    out.approvedGroupwareB90ActualApplyCount = out.approvalScopeOk && out.approvalStatusOk && out.approvalActorOk ? 1 : 0;
  }
  return out;
}

function CC20_headerMap_(headerRow) {
  var map = {};
  for (var i = 0; i < headerRow.length; i++) {
    var key = String(headerRow[i] || '').trim();
    if (key) map[key] = i;
  }
  return map;
}

function CC20_cell_(row, header, keys) {
  for (var i = 0; i < keys.length; i++) {
    if (Object.prototype.hasOwnProperty.call(header, keys[i])) return String(row[header[keys[i]]] || '').trim();
  }
  return '';
}

function CC20_sortApprovalDesc_(a, b) {
  var ax = String(a && a.approvedAt || '');
  var bx = String(b && b.approvedAt || '');
  if (ax < bx) return 1;
  if (ax > bx) return -1;
  return 0;
}

function CC20_normalizeDateValue_(value) {
  if (Object.prototype.toString.call(value) === '[object Date]' && !isNaN(value.getTime())) return CC20_formatDate_(value);
  return String(value || '').trim();
}

function CC20_operationBlock_() {
  return {
    productionSaveAllowed: false,
    fieldUseOpenAllowed: false,
    deployAllowed: false,
    realApplyAllowed: false,
    actualExecutionBlocked: true,
    sheetWriteExecuted: false,
    sheetCreateExecuted: false,
    headerAutoAddExecuted: false,
    approvalWriteExecuted: false,
    auditLogWriteExecuted: false,
    backupExecuted: false,
    deployExecuted: false,
    recoveryExecuted: false,
    rollbackExecuted: false,
    realApplyExecuted: false,
    productionDataMutationExecuted: false
  };
}

function CC20_logCompactResult_(result) {
  Logger.log('JSON_COMPACT_RESULT: ' + JSON.stringify(CC20_compactResult_(result)));
}

function CC20_compactResult_(result) {
  result = result || {};
  var summary = result.summary || {};
  var evidence = result.evidence || {};
  return {
    ok: result.ok === true,
    build: result.build || CC20_BUILD,
    progress: CC20_PROGRESS,
    mode: result.mode || CC20_MODE,
    checkedAt: result.checkedAt || '',
    judgement: result.judgement || 'BLOCK',
    targetBaseline: CC20_TARGET,
    summary: {
      baselineOk: summary.baselineOk === true,
      configOk: summary.configOk === true,
      masterOk: summary.masterOk === true,
      systemConfigAutoReadOk: summary.systemConfigAutoReadOk === true,
      masterConnectedOk: summary.masterConnectedOk === true,
      fieldUseOpenDecisionGatePassed: summary.fieldUseOpenDecisionGatePassed === true,
      fieldUseOpenDecisionOk: summary.fieldUseOpenDecisionOk === true,
      deployAllowed: summary.deployAllowed === true,
      fieldUseOpenAllowed: summary.fieldUseOpenAllowed === true,
      approvalSheetReadableOk: summary.approvalSheetReadableOk === true,
      actualOperationApplyApprovalEvidenceOk: summary.actualOperationApplyApprovalEvidenceOk === true,
      actualOperationApplyApprovalScopeOk: summary.actualOperationApplyApprovalScopeOk === true,
      actualOperationApplyApprovalStatusOk: summary.actualOperationApplyApprovalStatusOk === true,
      actualOperationApplyApprovalActorOk: summary.actualOperationApplyApprovalActorOk === true,
      actualOperationApplyApprovalGateOk: summary.actualOperationApplyApprovalGateOk === true,
      actualOperationApplyReadinessOk: summary.actualOperationApplyReadinessOk === true,
      actualOperationApplyAllowedCandidate: summary.actualOperationApplyAllowedCandidate === true,
      productionSaveAllowed: summary.productionSaveAllowed === true,
      realApplyAllowed: summary.realApplyAllowed === true,
      actualExecutionBlocked: summary.actualExecutionBlocked !== false,
      actualDeployAllowed: summary.actualDeployAllowed === true,
      actualFieldUseOpenAllowed: summary.actualFieldUseOpenAllowed === true,
      actualRealApplyAllowed: summary.actualRealApplyAllowed === true,
      diagnosticOnly: summary.diagnosticOnly === true,
      dryRunOnly: summary.dryRunOnly === true,
      sheetWriteExecuted: summary.sheetWriteExecuted === true,
      sheetCreateExecuted: summary.sheetCreateExecuted === true,
      headerAutoAddExecuted: summary.headerAutoAddExecuted === true,
      approvalWriteExecuted: summary.approvalWriteExecuted === true,
      auditLogWriteExecuted: summary.auditLogWriteExecuted === true,
      backupExecuted: summary.backupExecuted === true,
      deployExecuted: summary.deployExecuted === true,
      recoveryExecuted: summary.recoveryExecuted === true,
      rollbackExecuted: summary.rollbackExecuted === true,
      realApplyExecuted: summary.realApplyExecuted === true,
      productionDataMutationExecuted: summary.productionDataMutationExecuted === true
    },
    evidence: {
      setupDbId: evidence.setupDbId || CC20_SETUP_DB_ID,
      configSheetName: evidence.configSheetName || CC20_CONFIG_SHEET_NAME,
      sourceDb: evidence.sourceDb || CC20_SOURCE_DB,
      setupDbName: evidence.setupDbName || '',
      masterDbIdMasked: evidence.masterDbIdMasked || '',
      masterDbName: evidence.masterDbName || '',
      fieldUseOpenDecisionGate: evidence.fieldUseOpenDecisionGate || {},
      approvalSheetName: evidence.approvalSheetName || 'ApprovalLog',
      actualOperationApplyApprovalCandidateCount: evidence.actualOperationApplyApprovalCandidateCount || 0,
      approvedActualOperationApplyCount: evidence.approvedActualOperationApplyCount || 0,
      latestActualOperationApplyApproval: evidence.latestActualOperationApplyApproval || null,
      requiredApprovalType: evidence.requiredApprovalType || CC20_TARGET.requiredApprovalType,
      requiredApprovalScope: evidence.requiredApprovalScope || CC20_TARGET.requiredApprovalScope,
      requiredTargetAction: evidence.requiredTargetAction || CC20_TARGET.requiredTargetAction,
      relatedBuild: evidence.relatedBuild || CC20_TARGET.relatedBuild,
      readinessReason: evidence.readinessReason || '',
      actualBackupAllowed: false,
      actualDeployAllowed: false,
      actualRecoveryAllowed: false,
      actualRollbackAllowed: false,
      actualProductionSaveAllowed: false,
      actualFieldUseOpenAllowed: false,
      actualRealApplyAllowed: false,
      operationBlock: evidence.operationBlock || {},
      elapsedMs: evidence.elapsedMs || 0
    },
    warnings: result.warnings || [],
    hold: result.hold || [],
    fatal: result.fatal || [],
    nextAction: result.nextAction || ''
  };
}

function CC20_allTrue_(items) {
  for (var i = 0; i < items.length; i++) {
    if (items[i] !== true) return false;
  }
  return true;
}

function CC20_maskId_(id) {
  id = String(id || '');
  if (!id) return '';
  if (id.length <= 8) return '***';
  return id.substring(0, 4) + '***' + id.substring(id.length - 4);
}

function CC20_now_() {
  var tz = 'Asia/Seoul';
  try { tz = Session.getScriptTimeZone() || tz; } catch (e) {}
  return Utilities.formatDate(new Date(), tz, "yyyy-MM-dd'T'HH:mm:ssXXX");
}

function CC20_formatDate_(date) {
  var tz = 'Asia/Seoul';
  try { tz = Session.getScriptTimeZone() || tz; } catch (e) {}
  return Utilities.formatDate(date, tz, "yyyy-MM-dd'T'HH:mm:ssXXX");
}

function CC20_errorMessage_(err) {
  if (!err) return 'unknown error';
  return err.message || String(err);
}
