/**
 * FEELHAUS CONTROL - GROUPWARE B90 ACTUAL EXECUTION READY GATE
 * Build: CONTROL_GROUPWARE_B90_ACTUAL_EXECUTION_READY_V01
 * Progress: [08/10] 80%
 * Target baseline: GROUPWARE_B90_FINAL_STABLE_AFTER_B70_B90_RUNALL
 * Execution function: runControlGroupwareB90ActualExecutionReadyGateV01
 *
 * Safety:
 * - Diagnostic only
 * - Sheet read only
 * - No sheet creation
 * - No header mutation
 * - No approval writing
 * - No audit log writing
 * - No backup/deploy/recovery/rollback execution
 * - No GROUPWARE production save
 * - No field use open execution
 * - No real apply execution
 */
var CC21_BUILD = 'CONTROL_GROUPWARE_B90_ACTUAL_EXECUTION_READY_V01';
var CC21_MODE = 'GROUPWARE_B90_ACTUAL_EXECUTION_READY_DIAGNOSTIC_ONLY_NO_UPDATE';
var CC21_PROGRESS = { current: 8, total: 10, percent: 80 };
var CC21_SETUP_DB_ID = '17VMSpgSZCvIrUlgcw8yCNcnl8WQWo2IcRf5tDCcuJGM';
var CC21_CONFIG_SHEET_NAME = 'SystemConfig';
var CC21_SOURCE_DB = 'FEELHAUS_SETUP_DB';
var CC21_TARGET = {
  projectCode: 'GROUPWARE',
  moduleCode: 'GROUPWARE_PORTAL_HR_MAIL_CALENDAR',
  buildRange: 'B70~B90',
  currentBuildNo: 'B90',
  finalBuildNo: 'B90',
  buildProgress: '90 / 90',
  progressPercent: 100,
  runAllStatus: 'GROUPWARE_B70_TO_B90_RUNALL_PASS',
  protectedBaseline: 'B70~B89',
  finalStableName: 'GROUPWARE_B90_FINAL_STABLE',
  actualOperationApplyApprovalGateBuild: 'CONTROL_GROUPWARE_B90_ACTUAL_OPERATION_APPLY_APPROVAL_V01',
  backupEvidenceFile: 'BACKUP_GROUPWARE_B90_FINAL_STABLE_20260611.zip',
  rollbackBaselineFile: 'ROLLBACK_BASELINE_GROUPWARE_B90_BEFORE_APPLY_20260611.zip'
};

function runControlGroupwareB90ActualExecutionReadyGateV01() {
  var result = diagnoseControlGroupwareB90ActualExecutionReadyGateV01_();
  CC21_logCompactResult_(result);
  return result;
}

function runGroupwareB90ActualExecutionReadyGateV01() {
  var result = diagnoseControlGroupwareB90ActualExecutionReadyGateV01_();
  CC21_logCompactResult_(result);
  return result;
}

function getControlGroupwareB90ActualExecutionReadyGateData() {
  var result = diagnoseControlGroupwareB90ActualExecutionReadyGateV01_();
  CC21_logCompactResult_(result);
  return result;
}

function controlGroupwareB90ActualExecutionReadyGateV01() {
  var result = diagnoseControlGroupwareB90ActualExecutionReadyGateV01_();
  CC21_logCompactResult_(result);
  return result;
}

function diagnoseControlGroupwareB90ActualExecutionReadyGateV01_() {
  var started = new Date();
  var fatal = [];
  var hold = [];
  var warnings = [];
  var summary = CC21_defaultSummary_();
  var evidence = {};
  var config = {};
  var master = { ok: false };

  try {
    var setup = CC21_readSystemConfig_();
    config = setup.config || {};
    summary.configOk = setup.ok === true;
    summary.systemConfigAutoReadOk = setup.ok === true;
    evidence.setupDbName = setup.setupDbName || '';
  } catch (e1) {
    fatal.push('SystemConfig 자동 읽기 실패: ' + CC21_errorMessage_(e1));
  }

  try {
    master = CC21_openMasterDb_(config);
    summary.masterOk = master.ok === true;
    summary.masterConnectedOk = master.ok === true;
    evidence.masterDbIdMasked = CC21_maskId_(master.masterDbId || '');
    evidence.masterDbName = master.masterDbName || '';
  } catch (e2) {
    fatal.push('FEELHAUS_DB_MASTER 연결 실패: ' + CC21_errorMessage_(e2));
  }

  evidence.actualOperationApplyApprovalGate = CC21_checkActualOperationApplyApprovalGate_();
  summary.actualOperationApplyApprovalGatePassed = evidence.actualOperationApplyApprovalGate.passed === true;
  summary.actualOperationApplyReadinessOk = evidence.actualOperationApplyApprovalGate.actualOperationApplyReadinessOk === true;
  summary.actualOperationApplyAllowedCandidate = evidence.actualOperationApplyApprovalGate.actualOperationApplyAllowedCandidate === true;
  summary.approvedActualOperationApplyCount = evidence.actualOperationApplyApprovalGate.approvedActualOperationApplyCount || 0;

  evidence.files = CC21_findEvidenceFiles_(config);
  summary.backupEvidenceFileOk = evidence.files.backupEvidenceFileOk === true;
  summary.rollbackBaselineFileOk = evidence.files.rollbackBaselineFileOk === true;
  summary.executionFilesReadyOk = summary.backupEvidenceFileOk && summary.rollbackBaselineFileOk;

  summary.productionSaveAllowed = false;
  summary.fieldUseOpenAllowed = false;
  summary.deployAllowed = false;
  summary.realApplyAllowed = false;
  summary.actualExecutionBlocked = true;
  summary.actualDeployAllowed = false;
  summary.actualFieldUseOpenAllowed = false;
  summary.actualRealApplyAllowed = false;
  summary.diagnosticOnly = true;
  summary.dryRunOnly = true;

  if (!summary.actualOperationApplyApprovalGatePassed) hold.push('[07/10] CONTROL_GROUPWARE_B90_ACTUAL_OPERATION_APPLY_APPROVAL_V01 PASS 확인 필요');
  if (!summary.actualOperationApplyReadinessOk) hold.push('[07/10] actual operation apply readiness PASS 확인 필요');
  if (!summary.actualOperationApplyAllowedCandidate) hold.push('[07/10] actual operation apply allowed candidate 확인 필요');
  if (!summary.backupEvidenceFileOk) hold.push('GROUPWARE B90 백업 증빙 파일 확인 필요: ' + CC21_TARGET.backupEvidenceFile);
  if (!summary.rollbackBaselineFileOk) hold.push('GROUPWARE B90 롤백 baseline 파일 확인 필요: ' + CC21_TARGET.rollbackBaselineFile);

  var passConditions = [
    summary.configOk,
    summary.masterOk,
    summary.actualOperationApplyApprovalGatePassed,
    summary.actualOperationApplyReadinessOk,
    summary.actualOperationApplyAllowedCandidate,
    summary.executionFilesReadyOk,
    summary.actualExecutionBlocked,
    summary.actualDeployAllowed === false,
    summary.actualFieldUseOpenAllowed === false,
    summary.actualRealApplyAllowed === false,
    summary.productionSaveAllowed === false,
    summary.fieldUseOpenAllowed === false,
    summary.deployAllowed === false,
    summary.realApplyAllowed === false
  ];

  var allPass = fatal.length === 0 && hold.length === 0 && CC21_allTrue_(passConditions);
  var judgement = fatal.length > 0 ? 'BLOCK' : (allPass ? 'PASS' : 'HOLD');
  summary.actualExecutionReadyOk = judgement === 'PASS';
  summary.actualExecutionAllowedCandidate = judgement === 'PASS';
  summary.judgement = judgement;

  return {
    ok: judgement === 'PASS',
    build: CC21_BUILD,
    progress: CC21_PROGRESS,
    mode: CC21_MODE,
    checkedAt: CC21_now_(),
    judgement: judgement,
    targetBaseline: CC21_TARGET,
    summary: summary,
    evidence: {
      setupDbId: CC21_SETUP_DB_ID,
      configSheetName: CC21_CONFIG_SHEET_NAME,
      sourceDb: CC21_SOURCE_DB,
      setupDbName: evidence.setupDbName || '',
      masterDbIdMasked: evidence.masterDbIdMasked || '',
      masterDbName: evidence.masterDbName || '',
      actualOperationApplyApprovalGate: evidence.actualOperationApplyApprovalGate || {},
      approvedActualOperationApplyCount: summary.approvedActualOperationApplyCount,
      scannedFolderCount: evidence.files.scannedFolderCount || 0,
      readableFolderCount: evidence.files.readableFolderCount || 0,
      scannedFolders: evidence.files.scannedFolders || [],
      backupEvidenceFileCount: evidence.files.backupEvidenceFileCount || 0,
      rollbackBaselineFileCount: evidence.files.rollbackBaselineFileCount || 0,
      latestBackupEvidenceFile: evidence.files.latestBackupEvidenceFile || null,
      latestRollbackBaselineFile: evidence.files.latestRollbackBaselineFile || null,
      readinessReason: judgement === 'PASS' ? '[08/10] Actual execution ready PASS. Actual operation apply approval and required backup/rollback evidence files were confirmed. This gate still executes no production change.' : '',
      actualBackupAllowed: false,
      actualDeployAllowed: false,
      actualRecoveryAllowed: false,
      actualRollbackAllowed: false,
      actualProductionSaveAllowed: false,
      actualFieldUseOpenAllowed: false,
      actualRealApplyAllowed: false,
      operationBlock: CC21_operationBlock_(),
      elapsedMs: new Date().getTime() - started.getTime()
    },
    warnings: warnings,
    hold: hold,
    fatal: fatal,
    nextAction: judgement === 'PASS'
      ? '[08/10] GROUPWARE B90 actual execution ready gate PASS. Next step is [09/10] actual operation execution gate. This gate executed no production change.'
      : '[08/10] GROUPWARE B90 actual execution ready gate is not PASS. Resolve hold items, then rerun.'
  };
}

function CC21_defaultSummary_() {
  return {
    baselineOk: true,
    configOk: false,
    masterOk: false,
    systemConfigAutoReadOk: false,
    masterConnectedOk: false,
    actualOperationApplyApprovalGatePassed: false,
    actualOperationApplyReadinessOk: false,
    actualOperationApplyAllowedCandidate: false,
    approvedActualOperationApplyCount: 0,
    backupEvidenceFileOk: false,
    rollbackBaselineFileOk: false,
    executionFilesReadyOk: false,
    actualExecutionReadyOk: false,
    actualExecutionAllowedCandidate: false,
    productionSaveAllowed: false,
    fieldUseOpenAllowed: false,
    deployAllowed: false,
    realApplyAllowed: false,
    actualExecutionBlocked: true,
    actualDeployAllowed: false,
    actualFieldUseOpenAllowed: false,
    actualRealApplyAllowed: false,
    diagnosticOnly: true,
    dryRunOnly: true,
    sheetWriteExecuted: false,
    sheetCreateExecuted: false,
    headerAutoAddExecuted: false,
    approvalWriteExecuted: false,
    auditLogWriteExecuted: false,
    backupExecuted: false,
    deployExecuted: false,
    recoveryExecuted: false,
    rollbackExecuted: false,
    realApplyExecuted: false,
    productionDataMutationExecuted: false
  };
}

function CC21_checkActualOperationApplyApprovalGate_() {
  var result = { checked: false, available: false, passed: false };
  try {
    if (typeof runControlGroupwareB90ActualOperationApplyApprovalGateV01 !== 'function') {
      result.error = 'runControlGroupwareB90ActualOperationApplyApprovalGateV01 함수 없음';
      return result;
    }
    var r = runControlGroupwareB90ActualOperationApplyApprovalGateV01();
    result.checked = true;
    result.available = true;
    result.passed = r && r.judgement === 'PASS';
    result.build = r && r.build || '';
    result.judgement = r && r.judgement || '';
    result.actualOperationApplyReadinessOk = r && r.summary && r.summary.actualOperationApplyReadinessOk === true;
    result.actualOperationApplyAllowedCandidate = r && r.summary && r.summary.actualOperationApplyAllowedCandidate === true;
    result.approvedActualOperationApplyCount = r && r.evidence && r.evidence.approvedActualOperationApplyCount || 0;
    result.latestActualOperationApplyApproval = r && r.evidence && r.evidence.latestActualOperationApplyApproval || null;
  } catch (e) {
    result.checked = true;
    result.available = false;
    result.error = CC21_errorMessage_(e);
  }
  return result;
}

function CC21_findEvidenceFiles_(config) {
  var keys = ['BACKUP_GROUPWARE_FOLDER_ID', 'BACKUP_PORTAL_FOLDER_ID'];
  var scanned = [];
  var backupFiles = [];
  var rollbackFiles = [];
  for (var i = 0; i < keys.length; i++) {
    var key = keys[i];
    var folderId = String(config[key] || '').trim();
    if (!folderId) continue;
    var item = { folderKey: key, folderIdMasked: CC21_maskId_(folderId), readable: false, fileCount: 0, error: '', folderName: '' };
    try {
      var folder = DriveApp.getFolderById(folderId);
      item.readable = true;
      item.folderName = folder.getName();
      var files = folder.getFiles();
      while (files.hasNext()) {
        var f = files.next();
        item.fileCount++;
        var name = f.getName();
        if (name === CC21_TARGET.backupEvidenceFile) backupFiles.push(CC21_fileInfo_(f, key));
        if (name === CC21_TARGET.rollbackBaselineFile) rollbackFiles.push(CC21_fileInfo_(f, key));
      }
    } catch (e) {
      item.error = CC21_errorMessage_(e);
    }
    scanned.push(item);
  }
  backupFiles.sort(CC21_sortByUpdatedDesc_);
  rollbackFiles.sort(CC21_sortByUpdatedDesc_);
  return {
    scannedFolderCount: scanned.length,
    readableFolderCount: scanned.filter(function(x){ return x.readable; }).length,
    scannedFolders: scanned,
    backupEvidenceFileCount: backupFiles.length,
    rollbackBaselineFileCount: rollbackFiles.length,
    backupEvidenceFileOk: backupFiles.length > 0,
    rollbackBaselineFileOk: rollbackFiles.length > 0,
    latestBackupEvidenceFile: backupFiles.length ? backupFiles[0] : null,
    latestRollbackBaselineFile: rollbackFiles.length ? rollbackFiles[0] : null
  };
}

function CC21_fileInfo_(file, folderKey) {
  return {
    folderKey: folderKey,
    fileId: file.getId(),
    fileName: file.getName(),
    mimeType: file.getMimeType(),
    updatedAt: CC21_formatDate_(file.getLastUpdated()),
    urlMasked: 'https://drive.google.com/file/d/***/view'
  };
}

function CC21_sortByUpdatedDesc_(a, b) {
  return String(b.updatedAt || '').localeCompare(String(a.updatedAt || ''));
}

function CC21_readSystemConfig_() {
  var ss = SpreadsheetApp.openById(CC21_SETUP_DB_ID);
  var sh = ss.getSheetByName(CC21_CONFIG_SHEET_NAME);
  if (!sh) throw new Error('SystemConfig 시트 없음');
  var values = sh.getDataRange().getValues();
  var cfg = {};
  for (var r = 1; r < values.length; r++) {
    var k = String(values[r][0] || '').trim();
    if (!k) continue;
    cfg[k] = values[r][1];
  }
  return { ok: true, setupDbName: ss.getName(), config: cfg };
}

function CC21_openMasterDb_(cfg) {
  var id = String(cfg.FEELHAUS_DB_MASTER_ID || cfg.FEELHAUS_DB_MASTER || cfg.MASTER_DB_ID || '').trim();
  if (!id) throw new Error('FEELHAUS_DB_MASTER_ID 누락');
  var ss = SpreadsheetApp.openById(id);
  return { ok: true, ss: ss, masterDbId: id, masterDbName: ss.getName() };
}

function CC21_operationBlock_() {
  return {
    productionSaveAllowed: false,
    fieldUseOpenAllowed: false,
    deployAllowed: false,
    realApplyAllowed: false,
    actualExecutionBlocked: true,
    actualDeployAllowed: false,
    actualFieldUseOpenAllowed: false,
    actualRealApplyAllowed: false,
    sheetWriteExecuted: false,
    sheetCreateExecuted: false,
    headerAutoAddExecuted: false,
    approvalWriteExecuted: false,
    auditLogWriteExecuted: false,
    backupExecuted: false,
    deployExecuted: false,
    recoveryExecuted: false,
    rollbackExecuted: false,
    realApplyExecuted: false,
    productionDataMutationExecuted: false
  };
}

function CC21_logCompactResult_(obj) {
  try {
    Logger.log('JSON_COMPACT_RESULT: ' + JSON.stringify(obj));
  } catch (e) {
    Logger.log('JSON_COMPACT_RESULT: ' + String(obj));
  }
}

function CC21_allTrue_(arr) {
  for (var i = 0; i < arr.length; i++) if (arr[i] !== true) return false;
  return true;
}

function CC21_now_() {
  return CC21_formatDate_(new Date());
}

function CC21_formatDate_(date) {
  try {
    return Utilities.formatDate(date, Session.getScriptTimeZone() || 'Asia/Seoul', "yyyy-MM-dd'T'HH:mm:ssXXX");
  } catch (e) {
    return new Date(date).toISOString();
  }
}

function CC21_maskId_(id) {
  id = String(id || '');
  if (id.length <= 8) return id ? '***' : '';
  return id.substring(0, 4) + '***' + id.substring(id.length - 4);
}

function CC21_errorMessage_(e) {
  return e && e.message ? e.message : String(e);
}
