/**
 * CONTROL ERP_CORE 941_1000 FINAL APPROVAL CLOSE REPORT SAFE
 * Safe-only config. No sheet creation, no DB injection, no deploy.
 */
const CCEF_BUILD = 'CONTROL_B06J41_941_1000_ERP_CORE_FINAL_APPROVAL_CLOSE_REPORT_SAFE';
const CCEF_PREVIOUS_CONTROL_BUILDS = [
  'CONTROL_B06J41_081_160_ERP_CORE_MISSING_SHEET_APPROVAL_SAFE',
  'CONTROL_B06J41_161_360_ERP_CORE_CREATE_DEPLOY_GUARD_BUNDLE_SAFE',
  'CONTROL_B06J41_361_560_ERP_CORE_FINAL_CLOSE_REPORT_SAFE',
  'CONTROL_B06J41_761_940_ERP_CORE_CREATE_APPROVAL_FINAL_GATE_SAFE'
];
const CCEF_PREVIOUS_ERP_CORE_BUILD = 'ERP_CORE_CLEAN_B06J41_1641_1780_FINAL_PRE_CREATE_APPROVAL_REPORT_SAFE';
const CCEF_FINAL_STATUS = 'CONTROL_ERP_CORE_FINAL_APPROVAL_CLOSE_REPORT_941_1000_PASSED__CREATE_DEPLOY_STILL_BLOCKED';

function ccef941_1000_buildInfo_() {
  return {
    build: CCEF_BUILD,
    previousControlBuilds: CCEF_PREVIOUS_CONTROL_BUILDS,
    previousErpCoreBuild: CCEF_PREVIOUS_ERP_CORE_BUILD,
    projectCode: 'ERP_CORE',
    controlProjectCode: 'CONTROL',
    sourceDb: 'FEELHAUS_SETUP_DB',
    setupDbId: '17VMSpgSZCvIrUlgcw8yCNcnl8WQWo2IcRf5tDCcuJGM',
    configSheetName: 'SystemConfig',
    deployAllowed: false,
    actualCreateConfirm: false,
    actualExecutionBlocked: true
  };
}

function ccef941_1000_safety_() {
  return {
    dryRunOnly: true,
    finalCloseReportOnly: true,
    approvalRequired: true,
    deployAllowed: false,
    actualCreateConfirm: false,
    actualDeployConfirm: false,
    actualCreateGlobalEnabled: false,
    actualDeployGlobalEnabled: false,
    actualDbInjectionGlobalEnabled: false,
    noSheetCreate: true,
    noSheetWrite: true,
    noHeaderAutoAdd: true,
    noDbInjection: true,
    noPolicyWrite: true,
    noApprovalWrite: true,
    noCustomerSave: true,
    noSaleSave: true,
    noContractCreate: true,
    noSignDocumentCreate: true,
    noInstallAsSave: true,
    noSettlementExecution: true,
    noCancelSettlementConfirm: true,
    noPaymentRecoveryOffset: true,
    noDepositReturnExecution: true,
    noBenefitPayoutExecution: true,
    noFundExecution: true,
    noStaffCreate: true,
    noRoleMutation: true,
    noFormAutoRegister: true,
    noPortalStatusMutation: true,
    noAuditLogWrite: true,
    noStatusMutation: true,
    noActualDeploy: true,
    noActualBackup: true,
    noActualRecovery: true,
    noActualRollback: true,
    noProtectedSheetDelete: true,
    noArchiveByNewSheetReason: true,
    actualExecutionBlocked: true
  };
}

function ccef941_1000_readSystemConfig_() {
  const info = ccef941_1000_buildInfo_();
  try {
    const ss = SpreadsheetApp.openById(info.setupDbId);
    const sh = ss.getSheetByName(info.configSheetName);
    if (!sh) {
      return { ok:false, setupDbId:info.setupDbId, sourceDb:info.sourceDb, sheetName:info.configSheetName, message:'SystemConfig 시트를 찾을 수 없습니다.' };
    }
    const values = sh.getDataRange().getValues();
    const config = {};
    if (values.length > 1) {
      const header = values[0].map(String);
      const keyIdx = header.indexOf('CONFIG_KEY') >= 0 ? header.indexOf('CONFIG_KEY') : 0;
      const valIdx = header.indexOf('VALUE') >= 0 ? header.indexOf('VALUE') : 1;
      for (let i=1;i<values.length;i++) {
        const key = values[i][keyIdx];
        if (key) config[String(key)] = values[i][valIdx];
      }
    }
    return { ok:true, setupDbId:info.setupDbId, setupDbName:ss.getName(), sourceDb:info.sourceDb, sheetName:info.configSheetName, config:config, message:'SystemConfig 읽기 완료' };
  } catch (err) {
    return { ok:false, setupDbId:info.setupDbId, sourceDb:info.sourceDb, sheetName:info.configSheetName, error:String(err), message:'SystemConfig 읽기 실패' };
  }
}

function ccef941_1000_openMasterDb_(configResult) {
  const cfg = (configResult && configResult.config) || {};
  const masterId = String(cfg.FEELHAUS_DB_MASTER_ID || cfg.DB_MASTER_ID || cfg.SPREADSHEET_ID || '').trim();
  if (!masterId) {
    return {
      ok: false,
      masterDbId: '',
      message: 'FEELHAUS_DB_MASTER_ID / DB_MASTER_ID / SPREADSHEET_ID 설정이 없습니다. SystemConfig 기준 연결만 허용합니다.'
    };
  }
  try {
    const ss = SpreadsheetApp.openById(masterId);
    return { ok:true, masterDbId:masterId, masterDbName:ss.getName(), message:'FEELHAUS_DB_MASTER 연결 확인 완료' };
  } catch (err) {
    return { ok:false, masterDbId:masterId, error:String(err), message:'FEELHAUS_DB_MASTER 연결 실패' };
  }
}
