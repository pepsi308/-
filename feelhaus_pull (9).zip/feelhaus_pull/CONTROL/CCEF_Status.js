function ccef941_1000_erpCoreFinalStatus_() {
  return {
    ok: true,
    erpCoreCleanBuild: 'ERP_CORE_CLEAN_B06J41_1641_PRE_FINAL_SIMPLE_SAFE',
    erpCoreFinalReportBuild: 'ERP_CORE_CLEAN_B06J41_1641_1780_FINAL_PRE_CREATE_APPROVAL_REPORT_SAFE',
    erpCoreFinalStatus: 'ERP_CORE_CLEAN_FINAL_REPORT_1641_1780_PASSED__CREATE_DEPLOY_STILL_BLOCKED',
    cleanPassed: true,
    finalReportPassed: true,
    routeSmokeTest: 'PASS',
    selfTest: 'PASS',
    fatalErrorCount: 0,
    warningCount: 0,
    missingSheetCount: 6,
    headerPolicyCandidateCount: 67,
    sheetPolicyCandidateCount: 6,
    approvalItemCount: 7,
    pendingCount: 7,
    blockedCount: 7,
    blockedExecutionCount: 24,
    protection: {
      qrInitialEntryTargetSearchProtected: true,
      directRegularMemberLink: false,
      noOriginalSlipMutation: true
    },
    message: 'ERP_CORE CLEAN + 1641~1780 최종 리포트 상태 수신 완료'
  };
}

function ccef941_1000_previousControlSummary_() {
  return [
    { build:'CONTROL_B06J41_081_160_ERP_CORE_MISSING_SHEET_APPROVAL_SAFE', status:'PASSED__CREATE_STILL_BLOCKED' },
    { build:'CONTROL_B06J41_161_360_ERP_CORE_CREATE_DEPLOY_GUARD_BUNDLE_SAFE', status:'PASSED__EXECUTION_STILL_BLOCKED' },
    { build:'CONTROL_B06J41_361_560_ERP_CORE_FINAL_CLOSE_REPORT_SAFE', status:'PASSED__CREATE_DEPLOY_STILL_BLOCKED' },
    { build:'CONTROL_B06J41_761_940_ERP_CORE_CREATE_APPROVAL_FINAL_GATE_SAFE', status:'PASSED__CREATE_DEPLOY_STILL_BLOCKED' }
  ];
}
