/**
 * CONTROL_B06J41_361_560_ERP_CORE_FINAL_CLOSE_REPORT_SAFE
 * Config / constants. Safe report only. No writes, no creates, no deploy.
 */
var CCE3_BUILD = 'CONTROL_B06J41_361_560_ERP_CORE_FINAL_CLOSE_REPORT_SAFE';
var CCE3_PREVIOUS_BUILD = 'CONTROL_B06J41_161_360_ERP_CORE_CREATE_DEPLOY_GUARD_BUNDLE_SAFE';
var CCE3_PREVIOUS_ERP_CORE_BUILD = 'ERP_CORE_B06J41_161_240_PRE_DEPLOY_UI_FUNCTION_AUDIT_SAFE';
var CCE3_FINAL_STATUS = 'CONTROL_ERP_CORE_FINAL_CLOSE_REPORT_361_560_PASSED__CREATE_DEPLOY_STILL_BLOCKED';

var CCE3_SETUP_DB_ID = '17VMSpgSZCvIrUlgcw8yCNcnl8WQWo2IcRf5tDCcuJGM';
var CCE3_CONFIG_SHEET_NAME = 'SystemConfig';
var CCE3_SOURCE_DB = 'FEELHAUS_SETUP_DB';

function getControlErpCoreB06J41_361_560_BuildInfo_() {
  return {
    ok: true,
    build: CCE3_BUILD,
    previousBuild: CCE3_PREVIOUS_BUILD,
    previousErpCoreBuild: CCE3_PREVIOUS_ERP_CORE_BUILD,
    finalStatus: CCE3_FINAL_STATUS,
    sourceDb: CCE3_SOURCE_DB,
    setupDbId: CCE3_SETUP_DB_ID,
    configSheetName: CCE3_CONFIG_SHEET_NAME,
    dryRunOnly: true,
    finalCloseReportOnly: true,
    deployAllowed: false,
    actualCreateConfirm: false,
    actualExecutionBlocked: true
  };
}

function getControlErpCoreB06J41_361_560_Safety_() {
  return {
    dryRunOnly: true,
    finalCloseReportOnly: true,
    approvalRequired: true,
    deployAllowed: false,
    actualCreateConfirm: false,
    actualDeployConfirm: false,
    actualCreateGlobalEnabled: false,
    actualDeployGlobalEnabled: false,
    noSheetCreate: true,
    noSheetWrite: true,
    noHeaderAutoAdd: true,
    noDbInjection: true,
    noPolicyWrite: true,
    noApprovalWrite: true,
    noActualDeploy: true,
    noActualRecovery: true,
    noActualRollback: true,
    noSettlementExecution: true,
    noPaymentExecution: true,
    noRecoveryExecution: true,
    noRoleMutation: true,
    noProtectedSheetDelete: true,
    noArchiveByNewSheetReason: true,
    actualExecutionBlocked: true
  };
}

function readControlErpCoreB06J41_361_560_SystemConfig_() {
  var result = {
    ok: false,
    setupDbId: CCE3_SETUP_DB_ID,
    setupDbName: CCE3_SOURCE_DB,
    sourceDb: CCE3_SOURCE_DB,
    sheetName: CCE3_CONFIG_SHEET_NAME,
    config: {},
    message: ''
  };

  var ss = SpreadsheetApp.openById(CCE3_SETUP_DB_ID);
  var sh = ss.getSheetByName(CCE3_CONFIG_SHEET_NAME);
  if (!sh) {
    result.message = 'SystemConfig 시트를 찾을 수 없습니다.';
    return result;
  }

  var values = sh.getDataRange().getValues();
  if (!values || values.length < 2) {
    result.ok = true;
    result.message = 'SystemConfig 데이터가 비어 있습니다. 기본 설정으로 점검합니다.';
    return result;
  }

  var header = values[0].map(function (v) { return String(v || '').trim(); });
  var keyIdx = header.indexOf('CONFIG_KEY');
  var valueIdx = header.indexOf('VALUE');
  if (keyIdx < 0) keyIdx = header.indexOf('key');
  if (valueIdx < 0) valueIdx = header.indexOf('value');
  if (keyIdx < 0) keyIdx = 0;
  if (valueIdx < 0) valueIdx = 1;

  for (var i = 1; i < values.length; i++) {
    var k = String(values[i][keyIdx] || '').trim();
    var v = values[i][valueIdx];
    if (k) result.config[k] = v;
  }
  result.ok = true;
  result.message = 'SystemConfig 읽기 완료';
  return result;
}

function openControlErpCoreB06J41_361_560_MasterDb_(config) {
  var cfg = config || {};
  var masterId = String(cfg.FEELHAUS_DB_MASTER_ID || cfg.DB_MASTER_ID || cfg.SPREADSHEET_ID || '').trim();
  if (!masterId) {
    return {
      ok: false,
      masterDbId: '',
      message: 'FEELHAUS_DB_MASTER_ID / DB_MASTER_ID / SPREADSHEET_ID 설정이 없습니다. SystemConfig 기준 연결만 허용합니다.'
    };
  }
  try {
    var ss = SpreadsheetApp.openById(masterId);
    return {
      ok: true,
      masterDbId: masterId,
      masterDbName: ss.getName(),
      spreadsheet: ss,
      message: 'FEELHAUS_DB_MASTER 연결 확인 완료'
    };
  } catch (err) {
    return { ok: false, masterDbId: masterId, error: String(err), message: 'FEELHAUS_DB_MASTER 연결 실패' };
  }
}
