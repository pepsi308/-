
/**
 * FEELHAUS CONTROL - Backup / Deploy / Recovery Log Policy Create
 * Build: CONTROL_BACKUP_DEPLOY_RECOVERY_LOG_POLICY_CREATE_SAFE
 * Purpose:
 *  - Create BackupLog / DeployLog / RecoveryLog sheets with protected header rows.
 *  - Upsert HeaderPolicy / SheetPolicy metadata for the 3 CONTROL log sheets.
 *  - Keep deployment and business data writes blocked.
 * Safety:
 *  - approval-code gated
 *  - no ERP business data writes
 *  - no deploy execution
 *  - no role mutation
 */
var CCBL_BUILD = 'CONTROL_BACKUP_DEPLOY_RECOVERY_LOG_POLICY_CREATE_SAFE';
var CCBL_SETUP_DB_ID = '17VMSpgSZCvIrUlgcw8yCNcnl8WQWo2IcRf5tDCcuJGM';
var CCBL_CONFIG_SHEET_NAME = 'SystemConfig';
var CCBL_APPROVAL_CODE = 'CONTROL_LOG_POLICY_CREATE_APPROVED_3_LOG_SHEETS_ONLY';
var CCBL_POLICY_HEADERS = ['policyId','sheetName','headerName','policyType','required','protected','status','createdAt','createdBy','updatedAt','updatedBy'];
var CCBL_SHEET_POLICY_HEADERS = ['policyId','sheetName','sheetRole','protectionLevel','createRequired','deleteCandidate','archiveCandidate','status','createdAt','createdBy','updatedAt','updatedBy'];
var CCBL_LOG_SHEETS = [
  {
    sheetName: 'BackupLog',
    sheetRole: '백업 실행/결과/스냅샷 추적 로그',
    protectionLevel: 'CRITICAL_LOG_PROTECTED',
    headers: ['logId','backupId','sourceProject','sourceDbId','backupType','backupStatus','backupStartedAt','backupCompletedAt','backupFileId','backupFileUrl','status','statusReason','createdAt','createdBy','updatedAt','updatedBy']
  },
  {
    sheetName: 'DeployLog',
    sheetRole: '배포 승인/실행/결과 추적 로그',
    protectionLevel: 'CRITICAL_LOG_PROTECTED',
    headers: ['logId','deployId','buildName','projectName','deployStatus','deployAllowed','approvalId','approvedBy','approvedAt','deployedAt','version','status','statusReason','createdAt','createdBy','updatedAt','updatedBy']
  },
  {
    sheetName: 'RecoveryLog',
    sheetRole: '복구/롤백 요청/승인/결과 추적 로그',
    protectionLevel: 'CRITICAL_LOG_PROTECTED',
    headers: ['logId','recoveryId','backupId','recoveryType','recoveryStatus','rollbackTarget','requestedBy','approvedBy','recoveredAt','status','statusReason','createdAt','createdBy','updatedAt','updatedBy']
  }
];

function controlLogPolicyCreate_safety_() {
  return {
    build: CCBL_BUILD,
    logPolicyCreateOnly: true,
    approvalRequired: true,
    noBusinessDataWrite: true,
    noCustomerSave: true,
    noSaleSave: true,
    noContractCreate: true,
    noInstallAsSave: true,
    noSettlementExecution: true,
    noCancelSettlementConfirm: true,
    noSignDocumentCreate: true,
    noFormAutoRegister: true,
    noRoleMutation: true,
    noDeployExecution: true,
    deployAllowed: false,
    actualDeployExecution: false,
    noDeleteSheet: true,
    noExistingDataClear: true,
    headerMapRequired: true,
    idBasedConnectionRequired: true,
    upsertPolicyOnly: true,
    targetSheets: ['BackupLog','DeployLog','RecoveryLog'],
    vendorBranchUserGroup: true,
    qrInitialEntryTargetSearchProtected: true,
    directRegularMemberLink: false,
    noOriginalSlipMutation: true
  };
}

function controlLogPolicyCreate_dryRun() {
  var result = {
    ok: true,
    build: CCBL_BUILD,
    mode: 'DRY_RUN_ONLY',
    message: 'BackupLog / DeployLog / RecoveryLog 생성 및 정책 등록 계획만 확인합니다. 실제 쓰기는 없습니다.',
    expectedLogSheetCount: 3,
    targetSheets: CCBL_LOG_SHEETS.map(function(p){ return { sheetName: p.sheetName, headerCount: p.headers.length, protectionLevel: p.protectionLevel }; }),
    fatal: [],
    warnings: [],
    safety: controlLogPolicyCreate_safety_()
  };
  Logger.log('[CONTROL LOG POLICY CREATE DRY RUN] ' + JSON.stringify(result));
  return result;
}

function controlLogPolicyCreate_execute(ctx) {
  ctx = ctx || {};
  var guard = controlLogPolicyCreate_checkGuard_(ctx);
  if (!guard.ok) {
    var blocked = {
      ok: false,
      blocked: true,
      build: CCBL_BUILD,
      action: 'CREATE_3_LOG_SHEETS_AND_POLICY_ONLY',
      reason: guard.reason,
      required: {
        logPolicyCreateConfirm: true,
        approvalCode: CCBL_APPROVAL_CODE,
        businessDataWriteAllowed: false,
        deployAllowed: false
      },
      safety: controlLogPolicyCreate_safety_()
    };
    Logger.log('[CONTROL LOG POLICY CREATE BLOCKED] ' + JSON.stringify(blocked));
    return blocked;
  }

  var cfg = controlLogPolicyCreate_readSystemConfig_();
  var fatal = [];
  var warnings = [];
  if (!cfg.ok) fatal.push('SystemConfig 읽기 실패: ' + (cfg.error || ''));
  var master = cfg.ok ? controlLogPolicyCreate_openMasterDb_(cfg.config) : { ok:false, error:'SystemConfig 실패' };
  if (!master.ok) fatal.push('FEELHAUS_DB_MASTER 연결 실패: ' + (master.error || ''));
  if (fatal.length) {
    return {
      ok: false,
      build: CCBL_BUILD,
      action: 'CREATE_3_LOG_SHEETS_AND_POLICY_ONLY',
      fatal: fatal,
      warnings: warnings,
      systemConfig: { ok: cfg.ok, error: cfg.error || '' },
      master: { ok: master.ok, error: master.error || '' },
      businessDataWrite: false,
      deployAllowed: false,
      safety: controlLogPolicyCreate_safety_()
    };
  }

  var ss = master.spreadsheet;
  var createdSheets = [];
  var existingSheets = [];
  var headerWrites = [];
  for (var i = 0; i < CCBL_LOG_SHEETS.length; i++) {
    var p = CCBL_LOG_SHEETS[i];
    var sh = ss.getSheetByName(p.sheetName);
    if (!sh) {
      sh = ss.insertSheet(p.sheetName);
      createdSheets.push(p.sheetName);
    } else {
      existingSheets.push(p.sheetName);
    }
    sh.getRange(1, 1, 1, p.headers.length).setValues([p.headers]);
    headerWrites.push({ sheetName: p.sheetName, mode: 'SET_HEADER_ROW', count: p.headers.length });
  }

  var headerPolicyResult = controlLogPolicyCreate_upsertHeaderPolicy_(ss);
  var sheetPolicyResult = controlLogPolicyCreate_upsertSheetPolicy_(ss);
  var post = controlLogPolicyCreate_postCreateCheck();
  var result = {
    ok: post.ok && headerPolicyResult.ok && sheetPolicyResult.ok,
    build: CCBL_BUILD,
    action: 'CREATE_3_LOG_SHEETS_AND_POLICY_ONLY',
    createdSheets: createdSheets,
    existingSheets: existingSheets,
    headerWrites: headerWrites,
    headerPolicy: headerPolicyResult,
    sheetPolicy: sheetPolicyResult,
    fatal: [].concat(headerPolicyResult.fatal || [], sheetPolicyResult.fatal || [], post.fatal || []),
    warnings: warnings.concat(post.warnings || []),
    postCreateCheck: post,
    businessDataWrite: false,
    deployAllowed: false,
    actualDeployExecution: false,
    safety: controlLogPolicyCreate_safety_()
  };
  Logger.log('[CONTROL LOG POLICY CREATE EXECUTE RESULT] ' + JSON.stringify(result));
  return result;
}

function controlLogPolicyCreate_postCreateCheck() {
  var cfg = controlLogPolicyCreate_readSystemConfig_();
  var fatal = [];
  var warnings = [];
  if (!cfg.ok) fatal.push('SystemConfig 읽기 실패: ' + (cfg.error || ''));
  var master = cfg.ok ? controlLogPolicyCreate_openMasterDb_(cfg.config) : { ok:false, error:'SystemConfig 실패' };
  if (!master.ok) fatal.push('FEELHAUS_DB_MASTER 연결 실패: ' + (master.error || ''));
  var checks = [];
  var policyMeta = {};
  if (master.ok) {
    for (var i = 0; i < CCBL_LOG_SHEETS.length; i++) {
      checks.push(controlLogPolicyCreate_checkLogSheet_(master.spreadsheet, CCBL_LOG_SHEETS[i]));
    }
    policyMeta.headerPolicy = controlLogPolicyCreate_checkPolicy_(master.spreadsheet, 'HeaderPolicy', controlLogPolicyCreate_expectedHeaderPolicyIds_());
    policyMeta.sheetPolicy = controlLogPolicyCreate_checkPolicy_(master.spreadsheet, 'SheetPolicy', controlLogPolicyCreate_expectedSheetPolicyIds_());
  }
  for (var c = 0; c < checks.length; c++) if (!checks[c].ok) fatal.push('로그 시트 점검 실패: ' + checks[c].sheetName);
  if (policyMeta.headerPolicy && !policyMeta.headerPolicy.ok) fatal.push('로그 HeaderPolicy 점검 실패');
  if (policyMeta.sheetPolicy && !policyMeta.sheetPolicy.ok) fatal.push('로그 SheetPolicy 점검 실패');
  var result = {
    ok: fatal.length === 0,
    build: CCBL_BUILD,
    mode: 'LOG_POLICY_POST_CREATE_CHECK',
    checkedAt: new Date().toISOString(),
    fatal: fatal,
    warnings: warnings,
    logSheets: checks,
    policyMeta: policyMeta,
    businessDataWrite: false,
    deployAllowed: false,
    safety: controlLogPolicyCreate_safety_()
  };
  Logger.log('[CONTROL LOG POLICY POST CREATE CHECK] ' + JSON.stringify(result));
  return result;
}

function controlLogPolicyCreate_selfTest() {
  var fatal = [];
  if (CCBL_LOG_SHEETS.length !== 3) fatal.push('로그 시트 후보 수 불일치');
  for (var i = 0; i < CCBL_LOG_SHEETS.length; i++) {
    var p = CCBL_LOG_SHEETS[i];
    if (!p.sheetName || !p.headers || !p.headers.length) fatal.push('로그 시트 정의 불완전: ' + p.sheetName);
    var dup = controlLogPolicyCreate_duplicates_(p.headers || []);
    if (dup.length) fatal.push('중복 헤더: ' + p.sheetName + ' / ' + dup.join(','));
    var missingAudit = controlLogPolicyCreate_missing_(['status','statusReason','createdAt','createdBy','updatedAt','updatedBy'], p.headers || []);
    if (missingAudit.length) fatal.push('감사/상태 헤더 누락: ' + p.sheetName + ' / ' + missingAudit.join(','));
  }
  var result = {
    ok: fatal.length === 0,
    build: CCBL_BUILD,
    fatal: fatal,
    warnings: [],
    expected: { logSheetCount: 3, headerPolicyRows: controlLogPolicyCreate_expectedHeaderPolicyIds_().length, sheetPolicyRows: 3 },
    safety: controlLogPolicyCreate_safety_()
  };
  Logger.log('[CONTROL LOG POLICY CREATE SELFTEST] ' + JSON.stringify(result));
  return result;
}

function controlLogPolicyCreate_checkGuard_(ctx) {
  if (ctx.logPolicyCreateConfirm !== true) return { ok: false, reason: 'logPolicyCreateConfirm=true 승인이 없습니다.' };
  if (String(ctx.approvalCode || '') !== CCBL_APPROVAL_CODE) return { ok: false, reason: '승인코드가 일치하지 않습니다.' };
  if (ctx.businessDataWriteAllowed !== false) return { ok: false, reason: 'businessDataWriteAllowed=false 상태여야 합니다.' };
  if (ctx.deployAllowed !== false) return { ok: false, reason: 'deployAllowed=false 상태여야 합니다.' };
  return { ok: true };
}

function controlLogPolicyCreate_readSystemConfig_() {
  if (typeof ccef941_1000_readSystemConfig_ === 'function') {
    return ccef941_1000_readSystemConfig_();
  }
  try {
    var ss = SpreadsheetApp.openById(CCBL_SETUP_DB_ID);
    var sh = ss.getSheetByName(CCBL_CONFIG_SHEET_NAME);
    if (!sh) return { ok: false, setupDbId: CCBL_SETUP_DB_ID, sheetName: CCBL_CONFIG_SHEET_NAME, config: {}, error: 'SystemConfig 시트를 찾을 수 없습니다.' };
    var values = sh.getDataRange().getValues();
    var config = {};
    if (values.length) {
      var header = values[0].map(function(v){ return String(v || '').trim(); });
      var keyIdx = header.indexOf('CONFIG_KEY');
      var valueIdx = header.indexOf('VALUE');
      if (keyIdx < 0) keyIdx = header.indexOf('configKey');
      if (valueIdx < 0) valueIdx = header.indexOf('value');
      if (keyIdx < 0 || valueIdx < 0) return { ok: false, setupDbId: CCBL_SETUP_DB_ID, sheetName: CCBL_CONFIG_SHEET_NAME, config: {}, error: 'CONFIG_KEY / VALUE 헤더를 찾을 수 없습니다.' };
      for (var r = 1; r < values.length; r++) {
        var k = String(values[r][keyIdx] || '').trim();
        if (k) config[k] = values[r][valueIdx];
      }
    }
    return { ok: true, setupDbId: CCBL_SETUP_DB_ID, sheetName: CCBL_CONFIG_SHEET_NAME, config: config, message: 'SystemConfig 읽기 완료' };
  } catch (e) {
    return { ok: false, setupDbId: CCBL_SETUP_DB_ID, sheetName: CCBL_CONFIG_SHEET_NAME, config: {}, error: String(e && e.message ? e.message : e) };
  }
}

function controlLogPolicyCreate_openMasterDb_(config) {
  try {
    var masterId = String((config && (config.FEELHAUS_DB_MASTER_ID || config.DB_MASTER_ID || config.SPREADSHEET_ID)) || '').trim();
    if (!masterId) return { ok: false, masterDbId: '', error: 'FEELHAUS_DB_MASTER_ID / DB_MASTER_ID / SPREADSHEET_ID 설정이 없습니다.' };
    var ss = SpreadsheetApp.openById(masterId);
    return { ok: true, masterDbId: masterId, masterDbName: ss.getName(), spreadsheet: ss, message: 'FEELHAUS_DB_MASTER 연결 확인 완료' };
  } catch (e) {
    return { ok: false, masterDbId: '', error: String(e && e.message ? e.message : e) };
  }
}

function controlLogPolicyCreate_upsertHeaderPolicy_(ss) {
  var rows = [];
  var now = new Date().toISOString();
  var user = Session.getActiveUser().getEmail() || 'SYSTEM';
  for (var i = 0; i < CCBL_LOG_SHEETS.length; i++) {
    var p = CCBL_LOG_SHEETS[i];
    for (var h = 0; h < p.headers.length; h++) {
      var headerName = p.headers[h];
      rows.push({
        policyId: 'HEADER|' + p.sheetName + '|' + headerName,
        sheetName: p.sheetName,
        headerName: headerName,
        policyType: 'CONTROL_LOG_HEADER',
        required: true,
        protected: true,
        status: 'ACTIVE',
        createdAt: now,
        createdBy: user,
        updatedAt: now,
        updatedBy: user
      });
    }
  }
  return controlLogPolicyCreate_upsertRows_(ss, 'HeaderPolicy', CCBL_POLICY_HEADERS, rows);
}

function controlLogPolicyCreate_upsertSheetPolicy_(ss) {
  var rows = [];
  var now = new Date().toISOString();
  var user = Session.getActiveUser().getEmail() || 'SYSTEM';
  for (var i = 0; i < CCBL_LOG_SHEETS.length; i++) {
    var p = CCBL_LOG_SHEETS[i];
    rows.push({
      policyId: 'SHEET|' + p.sheetName + '|',
      sheetName: p.sheetName,
      sheetRole: p.sheetRole,
      protectionLevel: p.protectionLevel,
      createRequired: true,
      deleteCandidate: false,
      archiveCandidate: false,
      status: 'ACTIVE',
      createdAt: now,
      createdBy: user,
      updatedAt: now,
      updatedBy: user
    });
  }
  return controlLogPolicyCreate_upsertRows_(ss, 'SheetPolicy', CCBL_SHEET_POLICY_HEADERS, rows);
}

function controlLogPolicyCreate_upsertRows_(ss, sheetName, headers, objects) {
  var sh = ss.getSheetByName(sheetName);
  var created = false;
  if (!sh) {
    sh = ss.insertSheet(sheetName);
    created = true;
  }
  var lastCol = Math.max(sh.getLastColumn(), headers.length);
  var currentHeaders = [];
  if (sh.getLastRow() >= 1 && sh.getLastColumn() >= 1) {
    currentHeaders = sh.getRange(1, 1, 1, lastCol).getValues()[0].map(function(v){ return String(v || '').trim(); });
  }
  var needHeader = created || currentHeaders.indexOf('policyId') < 0;
  if (needHeader) sh.getRange(1, 1, 1, headers.length).setValues([headers]);
  var header = sh.getRange(1, 1, 1, Math.max(sh.getLastColumn(), headers.length)).getValues()[0].map(function(v){ return String(v || '').trim(); });
  var idx = {};
  for (var h = 0; h < header.length; h++) if (header[h]) idx[header[h]] = h;
  for (var ah = 0; ah < headers.length; ah++) {
    if (idx[headers[ah]] === undefined) {
      var col = header.length + 1;
      sh.getRange(1, col).setValue(headers[ah]);
      idx[headers[ah]] = col - 1;
      header.push(headers[ah]);
    }
  }
  var pidIdx = idx.policyId;
  var rowByPolicyId = {};
  if (sh.getLastRow() >= 2) {
    var values = sh.getRange(2, 1, sh.getLastRow() - 1, sh.getLastColumn()).getValues();
    for (var r = 0; r < values.length; r++) {
      var pid = String(values[r][pidIdx] || '').trim();
      if (pid) rowByPolicyId[pid] = r + 2;
    }
  }
  var inserted = 0, updated = 0;
  for (var o = 0; o < objects.length; o++) {
    var obj = objects[o];
    var row = [];
    for (var c = 0; c < header.length; c++) row.push('');
    for (var k in obj) if (idx[k] !== undefined) row[idx[k]] = obj[k];
    var rowNum = rowByPolicyId[obj.policyId];
    if (rowNum) {
      sh.getRange(rowNum, 1, 1, row.length).setValues([row]);
      updated++;
    } else {
      sh.appendRow(row);
      inserted++;
    }
  }
  return { ok: true, sheetName: sheetName, inserted: inserted, updated: updated, total: objects.length, fatal: [], createdSheet: created };
}

function controlLogPolicyCreate_checkLogSheet_(ss, policy) {
  var sh = ss.getSheetByName(policy.sheetName);
  if (!sh) return { ok:false, sheetName: policy.sheetName, exists:false, expectedHeaderCount: policy.headers.length, actualHeaderCount: 0, missingHeaders: policy.headers, duplicateHeaders: [], fatal: ['로그 시트 없음'] };
  var lastCol = Math.max(sh.getLastColumn(), policy.headers.length);
  var headers = sh.getRange(1, 1, 1, lastCol).getValues()[0].map(function(v){ return String(v || '').trim(); }).filter(String);
  var missing = controlLogPolicyCreate_missing_(policy.headers, headers);
  var dup = controlLogPolicyCreate_duplicates_(headers);
  return { ok: missing.length === 0 && dup.length === 0, sheetName: policy.sheetName, exists: true, expectedHeaderCount: policy.headers.length, actualHeaderCount: headers.length, missingHeaders: missing, duplicateHeaders: dup, fatal: missing.length || dup.length ? ['로그 시트 헤더 점검 실패'] : [] };
}

function controlLogPolicyCreate_checkPolicy_(ss, sheetName, expectedIds) {
  var sh = ss.getSheetByName(sheetName);
  if (!sh) return { ok:false, sheetName: sheetName, exists:false, expectedRowCount: expectedIds.length, foundRowCount: 0, missingPolicyIds: expectedIds, duplicatePolicyIds: [], missingHeaders: [], fatal: ['정책 시트 없음'] };
  var values = sh.getDataRange().getValues();
  if (!values.length) return { ok:false, sheetName: sheetName, exists:true, expectedRowCount: expectedIds.length, foundRowCount: 0, missingPolicyIds: expectedIds, duplicatePolicyIds: [], missingHeaders: ['policyId'], fatal: ['정책 시트 비어 있음'] };
  var header = values[0].map(function(v){ return String(v || '').trim(); });
  var pidIdx = header.indexOf('policyId');
  var missingHeaders = pidIdx < 0 ? ['policyId'] : [];
  var found = {}, dup = [];
  if (pidIdx >= 0) {
    for (var r = 1; r < values.length; r++) {
      var pid = String(values[r][pidIdx] || '').trim();
      if (!pid) continue;
      if (found[pid] && dup.indexOf(pid) < 0) dup.push(pid);
      found[pid] = true;
    }
  }
  var missing = [];
  for (var e = 0; e < expectedIds.length; e++) if (!found[expectedIds[e]]) missing.push(expectedIds[e]);
  var fatal = [];
  if (missingHeaders.length) fatal.push('policyId 헤더 누락');
  if (missing.length) fatal.push('policyId 누락');
  if (dup.length) fatal.push('policyId 중복');
  return { ok: fatal.length === 0, sheetName: sheetName, exists: true, expectedRowCount: expectedIds.length, foundRowCount: expectedIds.length - missing.length, missingPolicyIds: missing, duplicatePolicyIds: dup, missingHeaders: missingHeaders, fatal: fatal };
}

function controlLogPolicyCreate_expectedHeaderPolicyIds_() {
  var ids = [];
  for (var i = 0; i < CCBL_LOG_SHEETS.length; i++) {
    var p = CCBL_LOG_SHEETS[i];
    for (var h = 0; h < p.headers.length; h++) ids.push('HEADER|' + p.sheetName + '|' + p.headers[h]);
  }
  return ids;
}

function controlLogPolicyCreate_expectedSheetPolicyIds_() {
  var ids = [];
  for (var i = 0; i < CCBL_LOG_SHEETS.length; i++) ids.push('SHEET|' + CCBL_LOG_SHEETS[i].sheetName + '|');
  return ids;
}

function controlLogPolicyCreate_missing_(expected, actual) {
  var set = {};
  for (var i = 0; i < actual.length; i++) set[actual[i]] = true;
  var missing = [];
  for (var e = 0; e < expected.length; e++) if (!set[expected[e]]) missing.push(expected[e]);
  return missing;
}

function controlLogPolicyCreate_duplicates_(arr) {
  var seen = {}, dup = [];
  for (var i = 0; i < arr.length; i++) {
    var v = String(arr[i] || '').trim();
    if (!v) continue;
    if (seen[v] && dup.indexOf(v) < 0) dup.push(v);
    seen[v] = true;
  }
  return dup;
}
