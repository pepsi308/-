/** Runner functions for CONTROL_ERP_CORE_ACTUAL_DEPLOY_EXECUTION_SAFE */
function runStep1_ControlActualDeployExecutionDryRun() {
  var result = ccedx_dryRun({ runner: 'runStep1_ControlActualDeployExecutionDryRun' });
  Logger.log('[CONTROL ERP_CORE ACTUAL DEPLOY EXECUTION STEP1 DRY RUN RESULT] ' + JSON.stringify(result, null, 2));
  return result;
}

function runStep2_BlockedControlActualDeployExecutionTest() {
  var result = ccedx_execute({
    actualDeployConfirm: false,
    approvalCode: '',
    deployAllowed: true,
    actualDeployApprovalReady: true,
    deployLogWriteAllowed: true,
    businessDataWriteAllowed: false,
    operationalUrlMutationAllowed: false,
    versionSwitchAllowed: false
  });
  Logger.log('[CONTROL ERP_CORE ACTUAL DEPLOY EXECUTION STEP2 BLOCKED TEST RESULT] ' + JSON.stringify(result, null, 2));
  return result;
}

function runStep3_ApprovedControlActualDeployExecution() {
  var result = ccedx_execute({
    actualDeployConfirm: true,
    approvalCode: 'CONTROL_ERP_CORE_ACTUAL_DEPLOY_EXECUTE_APPROVED_FINAL_ONLY',
    deployAllowed: true,
    actualDeployApprovalReady: true,
    deployLogWriteAllowed: true,
    businessDataWriteAllowed: false,
    operationalUrlMutationAllowed: false,
    versionSwitchAllowed: false
  });
  try { if (result && result.deployId) PropertiesService.getScriptProperties().setProperty('LAST_CCEDX_DEPLOY_ID', result.deployId); } catch (e) {}
  Logger.log('[CONTROL ERP_CORE ACTUAL DEPLOY EXECUTION STEP3 APPROVED RESULT] ' + JSON.stringify(result, null, 2));
  return result;
}

function runStep4_ControlActualDeployExecutionPostCheck() {
  var deployId = '';
  try {
    var props = PropertiesService.getScriptProperties();
    deployId = props.getProperty('LAST_CCEDX_DEPLOY_ID') || '';
  } catch (e) {}
  var result = ccedx_postExecutionCheck({ deployId: deployId });
  Logger.log('[CONTROL ERP_CORE ACTUAL DEPLOY EXECUTION STEP4 POST CHECK RESULT] ' + JSON.stringify(result, null, 2));
  return result;
}

function runStep5_ControlActualDeployExecutionSelfTest() {
  var result = ccedx_selfTest();
  Logger.log('[CONTROL ERP_CORE ACTUAL DEPLOY EXECUTION STEP5 SELFTEST RESULT] ' + JSON.stringify(result, null, 2));
  return result;
}
