/**
 * FEELHAUS CONTROL - GROUPWARE B90 FIELD USE OPEN DECISION GATE
 * Build: CONTROL_GROUPWARE_B90_FIELD_USE_OPEN_DECISION_V01
 * Progress: [06/10] 60%
 * Target baseline: GROUPWARE_B90_FINAL_STABLE_AFTER_B70_B90_RUNALL
 * Execution function: runControlGroupwareB90FieldUseOpenDecisionGateV01
 *
 * Safety:
 * - Diagnostic only
 * - Sheet read only
 * - No sheet creation
 * - No header mutation
 * - No approval writing
 * - No audit log writing
 * - No backup/deploy/recovery/rollback execution
 * - No GROUPWARE production save
 * - No field use open execution
 * - No real apply execution
 */
var CC19_BUILD = 'CONTROL_GROUPWARE_B90_FIELD_USE_OPEN_DECISION_V01';
var CC19_MODE = 'GROUPWARE_B90_FIELD_USE_OPEN_DECISION_DIAGNOSTIC_ONLY_NO_UPDATE';
var CC19_PROGRESS = { current: 6, total: 10, percent: 60 };
var CC19_SETUP_DB_ID = '17VMSpgSZCvIrUlgcw8yCNcnl8WQWo2IcRf5tDCcuJGM';
var CC19_CONFIG_SHEET_NAME = 'SystemConfig';
var CC19_SOURCE_DB = 'FEELHAUS_SETUP_DB';
var CC19_TARGET = {
  projectCode: 'GROUPWARE',
  moduleCode: 'GROUPWARE_PORTAL_HR_MAIL_CALENDAR',
  buildRange: 'B70~B90',
  currentBuildNo: 'B90',
  finalBuildNo: 'B90',
  buildProgress: '90 / 90',
  progressPercent: 100,
  runAllStatus: 'GROUPWARE_B70_TO_B90_RUNALL_PASS',
  protectedBaseline: 'B70~B89',
  finalStableName: 'GROUPWARE_B90_FINAL_STABLE',
  preDeployGateBuild: 'CONTROL_GROUPWARE_B90_PREDEPLOY_GATE_V01',
  backupRollbackGateBuild: 'CONTROL_GROUPWARE_B90_BACKUP_ROLLBACK_EVIDENCE_V01',
  approvalGateBuild: 'CONTROL_GROUPWARE_B90_APPROVAL_GATE_V01',
  deployAllowedGateBuild: 'CONTROL_GROUPWARE_B90_DEPLOY_ALLOWED_GATE_V01',
  requiredApprovalType: 'GROUPWARE_B90_PREDEPLOY_APPROVAL',
  requiredApprovalScope: 'GROUPWARE_B90_DEPLOY',
  requiredTargetAction: 'GROUPWARE_B90_DEPLOY_ALLOWED_GATE',
  relatedBuild: 'GROUPWARE_B90_FINAL_STABLE'
};

function runControlGroupwareB90FieldUseOpenDecisionGateV01() {
  var result = diagnoseControlGroupwareB90FieldUseOpenDecisionGateV01_();
  CC19_logCompactResult_(result);
  return result;
}

function runGroupwareB90FieldUseOpenDecisionGateV01() {
  var result = diagnoseControlGroupwareB90FieldUseOpenDecisionGateV01_();
  CC19_logCompactResult_(result);
  return result;
}

function getControlGroupwareB90FieldUseOpenDecisionGateData() {
  var result = diagnoseControlGroupwareB90FieldUseOpenDecisionGateV01_();
  CC19_logCompactResult_(result);
  return result;
}

function controlGroupwareB90FieldUseOpenDecisionGateV01() {
  var result = diagnoseControlGroupwareB90FieldUseOpenDecisionGateV01_();
  CC19_logCompactResult_(result);
  return result;
}

function diagnoseControlGroupwareB90FieldUseOpenDecisionGateV01_() {
  var started = new Date();
  var fatal = [];
  var hold = [];
  var warnings = [];
  var details = {};
  var summary = CC19_defaultSummary_();

  try {
    details.setup = CC19_readSystemConfig_();
    summary.configOk = details.setup.ok === true;
    summary.systemConfigAutoReadOk = details.setup.ok === true;
  } catch (e1) {
    fatal.push('SystemConfig auto read failed: ' + CC19_errorMessage_(e1));
    details.setup = { ok: false, error: CC19_errorMessage_(e1), config: {} };
  }

  try {
    var cfg = details.setup && details.setup.config ? details.setup.config : {};
    details.master = CC19_openMasterDb_(cfg);
    summary.masterOk = details.master.ok === true;
    summary.masterConnectedOk = details.master.ok === true;
  } catch (e2) {
    fatal.push('FEELHAUS_DB_MASTER open failed: ' + CC19_errorMessage_(e2));
    details.master = { ok: false, error: CC19_errorMessage_(e2) };
  }

  details.deployAllowedGate = CC19_checkDeployAllowedGate_();
  summary.deployAllowedGatePassed = details.deployAllowedGate.passed === true;
  summary.deployAllowedGateOk = details.deployAllowedGate.deployAllowedGateOk === true;
  summary.deployAllowedCandidate = details.deployAllowedGate.deployAllowed === true;
  summary.approvalGatePassed = details.deployAllowedGate.approvalGatePassed === true;
  summary.approvalEvidenceOk = details.deployAllowedGate.approvalEvidenceOk === true;
  summary.backupRollbackGatePassed = details.deployAllowedGate.backupRollbackGatePassed === true;
  summary.backupRollbackEvidenceOk = details.deployAllowedGate.backupRollbackEvidenceOk === true;

  details.operationBlock = CC19_operationBlock_();
  summary.productionSaveAllowed = false;
  summary.deployAllowed = summary.deployAllowedCandidate === true;
  summary.fieldUseOpenAllowed = summary.configOk && summary.masterOk && summary.deployAllowedGatePassed && summary.deployAllowedGateOk && summary.deployAllowedCandidate;
  summary.realApplyAllowed = false;
  summary.actualExecutionBlocked = true;
  summary.actualDeployAllowed = false;
  summary.actualFieldUseOpenAllowed = false;
  summary.diagnosticOnly = true;
  summary.dryRunOnly = true;

  if (!summary.deployAllowedGatePassed) hold.push('[05/10] CONTROL_GROUPWARE_B90_DEPLOY_ALLOWED_GATE_V01 PASS check required');
  if (!summary.deployAllowedGateOk) hold.push('[05/10] deploy allowed gate OK check required');
  if (!summary.deployAllowedCandidate) hold.push('GROUPWARE B90 deployAllowed candidate is not ready');
  if (!summary.fieldUseOpenAllowed) hold.push('GROUPWARE B90 field use open candidate is not ready');

  var passConditions = [
    summary.configOk,
    summary.masterOk,
    summary.deployAllowedGatePassed,
    summary.deployAllowedGateOk,
    summary.deployAllowedCandidate,
    summary.approvalGatePassed,
    summary.approvalEvidenceOk,
    summary.backupRollbackGatePassed,
    summary.backupRollbackEvidenceOk,
    summary.fieldUseOpenAllowed,
    summary.actualExecutionBlocked,
    summary.actualDeployAllowed === false,
    summary.actualFieldUseOpenAllowed === false,
    summary.productionSaveAllowed === false,
    summary.realApplyAllowed === false
  ];

  var allPass = fatal.length === 0 && hold.length === 0 && CC19_allTrue_(passConditions);
  var judgement = fatal.length > 0 ? 'BLOCK' : (allPass ? 'PASS' : 'HOLD');
  summary.fieldUseOpenDecisionOk = judgement === 'PASS';
  summary.judgement = judgement;

  return {
    ok: judgement === 'PASS',
    build: CC19_BUILD,
    progress: CC19_PROGRESS,
    mode: CC19_MODE,
    checkedAt: CC19_now_(),
    judgement: judgement,
    targetBaseline: CC19_TARGET,
    summary: summary,
    evidence: {
      setupDbId: CC19_SETUP_DB_ID,
      configSheetName: CC19_CONFIG_SHEET_NAME,
      sourceDb: CC19_SOURCE_DB,
      setupDbName: details.setup && details.setup.setupDbName || '',
      masterDbIdMasked: CC19_maskId_(details.master && details.master.masterDbId || ''),
      masterDbName: details.master && details.master.masterDbName || '',
      deployAllowedGate: details.deployAllowedGate || {},
      latestGroupwareB90Approval: details.deployAllowedGate && details.deployAllowedGate.latestGroupwareB90Approval || null,
      fieldUseOpenReason: summary.fieldUseOpenAllowed ? '[06/10] Field use open decision PASS. Deploy allowed candidate and safety blocks were confirmed. This gate still executes no production change.' : '',
      actualBackupAllowed: false,
      actualDeployAllowed: false,
      actualRecoveryAllowed: false,
      actualRollbackAllowed: false,
      actualProductionSaveAllowed: false,
      actualFieldUseOpenAllowed: false,
      actualRealApplyAllowed: false,
      operationBlock: details.operationBlock || {},
      elapsedMs: new Date().getTime() - started.getTime()
    },
    warnings: warnings,
    hold: hold,
    fatal: fatal,
    nextAction: judgement === 'PASS'
      ? '[06/10] GROUPWARE B90 field use open decision gate PASS. Next step is [07/10] actual operation apply approval gate. This gate executed no production change.'
      : '[06/10] GROUPWARE B90 field use open decision gate is not PASS. Fix hold items, then rerun.'
  };
}

function CC19_defaultSummary_() {
  return {
    baselineOk: true,
    configOk: false,
    masterOk: false,
    systemConfigAutoReadOk: false,
    masterConnectedOk: false,
    deployAllowedGatePassed: false,
    deployAllowedGateOk: false,
    deployAllowedCandidate: false,
    approvalGatePassed: false,
    approvalEvidenceOk: false,
    backupRollbackGatePassed: false,
    backupRollbackEvidenceOk: false,
    fieldUseOpenDecisionOk: false,
    productionSaveAllowed: false,
    fieldUseOpenAllowed: false,
    deployAllowed: false,
    realApplyAllowed: false,
    actualExecutionBlocked: true,
    actualDeployAllowed: false,
    actualFieldUseOpenAllowed: false,
    diagnosticOnly: true,
    dryRunOnly: true,
    sheetWriteExecuted: false,
    sheetCreateExecuted: false,
    headerAutoAddExecuted: false,
    approvalWriteExecuted: false,
    auditLogWriteExecuted: false,
    backupExecuted: false,
    deployExecuted: false,
    recoveryExecuted: false,
    rollbackExecuted: false,
    realApplyExecuted: false,
    productionDataMutationExecuted: false
  };
}

function CC19_checkDeployAllowedGate_() {
  var out = { checked: false, available: false, passed: false };
  try {
    if (typeof runControlGroupwareB90DeployAllowedGateV01 !== 'function') {
      out.error = 'runControlGroupwareB90DeployAllowedGateV01 not found';
      return out;
    }
    var result = runControlGroupwareB90DeployAllowedGateV01();
    out.checked = true;
    out.available = true;
    out.passed = result && result.judgement === 'PASS' && result.ok === true;
    out.build = result && result.build || '';
    out.judgement = result && result.judgement || '';
    var s = result && result.summary || {};
    var e = result && result.evidence || {};
    out.deployAllowedGateOk = s.deployAllowedGateOk === true;
    out.deployAllowed = s.deployAllowed === true;
    out.approvalGatePassed = s.approvalGatePassed === true;
    out.approvalEvidenceOk = s.approvalEvidenceOk === true;
    out.backupRollbackGatePassed = s.backupRollbackGatePassed === true;
    out.backupRollbackEvidenceOk = s.backupRollbackEvidenceOk === true;
    out.latestGroupwareB90Approval = e.latestGroupwareB90Approval || null;
  } catch (e) {
    out.checked = true;
    out.available = false;
    out.passed = false;
    out.error = CC19_errorMessage_(e);
  }
  return out;
}

function CC19_readSystemConfig_() {
  var ss = SpreadsheetApp.openById(CC19_SETUP_DB_ID);
  var sheet = ss.getSheetByName(CC19_CONFIG_SHEET_NAME);
  if (!sheet) throw new Error('SystemConfig sheet not found: ' + CC19_CONFIG_SHEET_NAME);
  var values = sheet.getDataRange().getValues();
  var config = {};
  for (var i = 1; i < values.length; i++) {
    var key = String(values[i][0] || '').trim();
    var value = values[i][1];
    if (key) config[key] = value;
  }
  return { ok: true, setupDbId: CC19_SETUP_DB_ID, setupDbName: ss.getName(), sourceDb: CC19_SOURCE_DB, sheetName: CC19_CONFIG_SHEET_NAME, config: config };
}

function CC19_openMasterDb_(config) {
  config = config || {};
  var id = String(config.FEELHAUS_DB_MASTER_ID || config.FEELHAUS_DB_MASTER || config.DB_MASTER_ID || config.MASTER_DB_ID || '').trim();
  if (!id) throw new Error('FEELHAUS_DB_MASTER_ID is missing in SystemConfig');
  var ss = SpreadsheetApp.openById(id);
  return { ok: true, masterDbId: id, masterDbName: ss.getName(), ss: ss };
}

function CC19_operationBlock_() {
  return {
    productionSaveAllowed: false,
    fieldUseOpenAllowedCandidateOnly: true,
    deployAllowedCandidateOnly: true,
    actualDeployAllowed: false,
    realApplyAllowed: false,
    actualExecutionBlocked: true,
    actualFieldUseOpenAllowed: false,
    sheetWriteExecuted: false,
    sheetCreateExecuted: false,
    headerAutoAddExecuted: false,
    approvalWriteExecuted: false,
    auditLogWriteExecuted: false,
    backupExecuted: false,
    deployExecuted: false,
    recoveryExecuted: false,
    rollbackExecuted: false,
    realApplyExecuted: false,
    productionDataMutationExecuted: false
  };
}

function CC19_logCompactResult_(obj) {
  try {
    Logger.log('JSON_COMPACT_RESULT: ' + JSON.stringify(obj));
  } catch (e) {
    Logger.log('JSON_COMPACT_RESULT_LOG_FAILED: ' + CC19_errorMessage_(e));
  }
}

function CC19_allTrue_(arr) {
  for (var i = 0; i < arr.length; i++) if (arr[i] !== true) return false;
  return true;
}

function CC19_now_() {
  return Utilities.formatDate(new Date(), 'Asia/Seoul', "yyyy-MM-dd'T'HH:mm:ssXXX");
}

function CC19_maskId_(id) {
  id = String(id || '');
  if (!id) return '';
  if (id.length <= 8) return '***';
  return id.substring(0, 4) + '***' + id.substring(id.length - 4);
}

function CC19_errorMessage_(err) {
  return err && err.message ? err.message : String(err || 'unknown error');
}
