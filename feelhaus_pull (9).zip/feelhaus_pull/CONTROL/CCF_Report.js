function buildControlFinal9411000CloseReport_() {
  var buildInfo = getControlFinal9411000BuildInfo_();
  var safety = getControlFinal9411000Safety_();
  var setup = readControlFinal9411000SystemConfig_();
  var master = openControlFinal9411000MasterDb_(setup.config);
  var sheetStatus = getControlFinal9411000SheetStatus_(master.ss);
  var passedBuilds = getControlFinal9411000PassedBuilds_();
  var execution = getControlFinal9411000ExecutionSummary_();
  var remainingApprovals = [
    'ApprovalLog 생성/헤더 추가 승인',
    'BackupLog 생성/헤더 추가 승인',
    'RecoveryLog 생성/헤더 추가 승인',
    'DeployLog 생성/헤더 추가 승인',
    'BackupLog / RecoveryLog / DeployLog 실제 기록 승인',
    '실제 백업 실행 승인',
    '실제 배포 실행 승인',
    '실제 롤백 실행 승인',
    'deployAllowed=true 전환 승인',
    '각 actual*GlobalEnabled=true 전환 승인',
    '각 actual*Confirm=true 승인'
  ];
  var ok = setup.ok && master.ok && safety.actualExecutionBlocked === true && safety.deployAllowed === false;
  return {
    ok: ok,
    build: buildInfo.build,
    previousBuild: buildInfo.previousBuild,
    finalStatus: ok ? 'CONTROL_CENTER_FINAL_DEPLOY_CONTROL_CLOSE_REPORT_PASSED__EXECUTION_BLOCKED' : 'CONTROL_CENTER_FINAL_DEPLOY_CONTROL_CLOSE_REPORT_FAILED',
    setupDb: setup,
    masterDb: {
      ok: master.ok,
      masterDbId: master.masterDbId,
      masterDbName: master.masterDbName,
      message: master.message
    },
    passedBuilds: passedBuilds,
    passedBuildCount: passedBuilds.length,
    sheetStatus: sheetStatus,
    executionSummary: execution,
    remainingApprovals: remainingApprovals,
    remainingApprovalCount: remainingApprovals.length,
    safety: safety,
    summary: {
      missingSheets: sheetStatus.missingSheets,
      totalMissingHeaders: sheetStatus.totalMissingHeaders,
      actualBackupExecuted: false,
      actualDeployExecuted: false,
      actualRollbackExecuted: false,
      deployAllowed: false,
      actualExecutionBlocked: true,
      finalStatus: ok ? 'CONTROL_CENTER_FINAL_DEPLOY_CONTROL_CLOSE_REPORT_PASSED__EXECUTION_BLOCKED' : 'CONTROL_CENTER_FINAL_DEPLOY_CONTROL_CLOSE_REPORT_FAILED'
    }
  };
}

function testControlCenterB06J41_941_1000_All() {
  var report = buildControlFinal9411000CloseReport_();
  Logger.log('[CONTROL FINAL 941_1000 TEST] ' + JSON.stringify(report));
  return report;
}
