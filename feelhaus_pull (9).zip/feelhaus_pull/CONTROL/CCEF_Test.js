/**
 * Test entry wrappers.
 * Main functions are implemented in CCEF_Report.js.
 */
function ccef941_1000_listEntrypoints() {
  return [
    'testControlErpCoreB06J41_941_1000_Smoke',
    'testControlErpCoreB06J41_941_1000_All'
  ];
}
