function ccb701_760_approvalTemplate_() {
  return {
    approvalId: 'APR-CONTROL-ACTUAL-BACKUP-YYYYMMDD-001',
    approvalStatus: 'APPROVED',
    approvalType: 'BACKUP_EXECUTION',
    approvalScope: 'CONTROL_FULL_BACKUP_PRECHECK',
    projectCode: 'CONTROL',
    controlProjectCode: 'CONTROL',
    approvedBy: Session.getActiveUser().getEmail() || 'admin@example.com',
    approvedAt: ccb701_760_now_(),
    reason: 'CONTROL 전체 Safe 기준본 실제 백업 승인 전 PreCheck',
    actualBackupRequested: true,
    actualBackupConfirm: true
  };
}

function ccb701_760_validateBackupApproval_(approval) {
  approval = approval || {};
  var reasons = [];
  if (!approval.approvalId) reasons.push('MISSING_APPROVAL_ID');
  if (!approval.approvedBy) reasons.push('MISSING_APPROVED_BY');
  if (!approval.approvedAt) reasons.push('MISSING_APPROVED_AT');
  if (approval.approvalStatus !== 'APPROVED') reasons.push('APPROVAL_STATUS_NOT_APPROVED');
  if (approval.approvalType !== 'BACKUP_EXECUTION') reasons.push('INVALID_APPROVAL_TYPE');
  if (approval.approvalScope !== 'CONTROL_FULL_BACKUP_PRECHECK') reasons.push('INVALID_APPROVAL_SCOPE');
  if (approval.projectCode !== 'CONTROL') reasons.push('INVALID_PROJECT_CODE');
  if (approval.controlProjectCode !== 'CONTROL') reasons.push('INVALID_CONTROL_PROJECT_CODE');
  if (approval.actualBackupRequested !== true) reasons.push('NO_ACTUAL_BACKUP_REQUEST');
  if (approval.actualBackupConfirm !== true) reasons.push('NO_ACTUAL_BACKUP_CONFIRM');
  if (CCB_BUILD.deployAllowed !== true) reasons.push('DEPLOY_STILL_BLOCKED');
  if (CCB_BUILD.actualBackupGlobalEnabled !== true) reasons.push('GLOBAL_ACTUAL_BACKUP_FLAG_OFF');
  var blocked = reasons.length > 0;
  return {
    ok: !blocked,
    blocked: blocked,
    blockReasons: reasons,
    gateWouldAllowIfGlobalFlagsEnabled: reasons.filter(function(r) { return r !== 'DEPLOY_STILL_BLOCKED' && r !== 'GLOBAL_ACTUAL_BACKUP_FLAG_OFF'; }).length === 0,
    actualBackupAllowed: false,
    message: blocked ? ('백업 승인 게이트 차단: ' + reasons.join(', ')) : '승인 구조는 통과 가능하지만 Safe 빌드에서는 실제 백업 차단'
  };
}

function ccb701_760_runApprovalGateTests_() {
  var invalidGate = ccb701_760_validateBackupApproval_({});
  var validShapeGate = ccb701_760_validateBackupApproval_(ccb701_760_approvalTemplate_());
  return {
    ok: true,
    invalidGate: invalidGate,
    validShapeGate: validShapeGate,
    invalidGateBlocked: invalidGate.blocked === true,
    validShapeGateBlocked: validShapeGate.blocked === true,
    gateWouldAllowIfGlobalFlagsEnabled: validShapeGate.gateWouldAllowIfGlobalFlagsEnabled === true,
    actualBackupAllowed: false,
    safety: ccb701_760_safety_()
  };
}
