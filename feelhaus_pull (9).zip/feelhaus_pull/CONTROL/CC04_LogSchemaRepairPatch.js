/**
 * FEELHAUS CONTROL LOG SCHEMA REPAIR PATCH V01
 * Build: CONTROL_LOG_SCHEMA_REPAIR_PATCH_V01
 * Purpose: Approved log schema repair only.
 * Scope:
 * - Create ApprovalLog sheet if missing.
 * - Add missing headers to ApprovalLog, BackupLog, DeployLog, RecoveryLog.
 * Safety:
 * - No row data update/delete.
 * - No backup/deploy/recovery/rollback execution.
 * - No permission/status/settlement mutation.
 */

var CC04_LOG_SCHEMA_REPAIR_BUILD = 'CONTROL_LOG_SCHEMA_REPAIR_PATCH_V01';
var CC04_LOG_SCHEMA_REPAIR_MODE = 'APPROVED_LOG_SCHEMA_REPAIR_HEADER_ONLY';
var CC04_SETUP_DB_ID = '17VMSpgSZCvIrUlgcw8yCNcnl8WQWo2IcRf5tDCcuJGM';
var CC04_CONFIG_SHEET_NAME = 'SystemConfig';

function runControlLogSchemaRepairPatchV01() {
  return CC04_runLogSchemaRepairPatch_(false);
}

function controlLogSchemaRepairPatchV01() {
  return CC04_runLogSchemaRepairPatch_(false);
}

function controlLogSchemaRepairPreviewV01() {
  return CC04_runLogSchemaRepairPatch_(true);
}

function getControl04DashboardData() {
  return runControlLogSchemaRepairPatchV01();
}

function control04SmokeTest() {
  return controlLogSchemaRepairPreviewV01();
}

function CC04_runLogSchemaRepairPatch_(previewOnly) {
  var fatal = [];
  var warnings = [];
  var actions = [];
  var flags = CC04_baseFlags_(previewOnly);
  var details = {
    setupDbId: CC04_SETUP_DB_ID,
    configSheetName: CC04_CONFIG_SHEET_NAME,
    sourceDb: 'FEELHAUS_SETUP_DB',
    masterDbName: 'FEELHAUS_DB_MASTER',
    masterDbId: '',
    mode: CC04_LOG_SCHEMA_REPAIR_MODE,
    previewOnly: !!previewOnly,
    schemas: CC04_getSchemas_(),
    results: [],
    guidance: CC04_guidance_(),
    safety: CC04_safety_(previewOnly)
  };

  try {
    var setupSs = SpreadsheetApp.openById(CC04_SETUP_DB_ID);
    var configSheet = setupSs.getSheetByName(CC04_CONFIG_SHEET_NAME);
    flags.configOk = !!configSheet;
    if (!configSheet) {
      fatal.push('SystemConfig 시트를 찾지 못했습니다.');
      return CC04_result_(flags, fatal, warnings, actions, details);
    }

    var masterId = CC04_findMasterDbId_(configSheet);
    details.masterDbId = masterId;
    flags.masterOk = !!masterId;
    if (!masterId) {
      fatal.push('SystemConfig에서 FEELHAUS_DB_MASTER ID를 찾지 못했습니다.');
      return CC04_result_(flags, fatal, warnings, actions, details);
    }

    var masterSs = SpreadsheetApp.openById(masterId);
    var schemas = details.schemas;
    for (var i = 0; i < schemas.length; i++) {
      var schema = schemas[i];
      var sheet = masterSs.getSheetByName(schema.sheetName);
      var existedBefore = !!sheet;
      var createdNow = false;
      var result = {
        sheetName: schema.sheetName,
        existedBefore: existedBefore,
        createdNow: false,
        headersBefore: [],
        missingBefore: [],
        addedHeaders: [],
        headersAfter: [],
        ok: false,
        previewOnly: !!previewOnly
      };

      if (!sheet) {
        result.missingBefore = schema.headers.slice();
        if (schema.createIfMissing) {
          if (previewOnly) {
            actions.push('PREVIEW_CREATE_SHEET: ' + schema.sheetName);
            warnings.push(schema.sheetName + ' 시트가 없어 생성 후보입니다. previewOnly라 실제 생성하지 않았습니다.');
          } else {
            sheet = masterSs.insertSheet(schema.sheetName);
            createdNow = true;
            flags.sheetCreateExecuted = true;
            actions.push('CREATE_SHEET: ' + schema.sheetName);
          }
        } else {
          warnings.push(schema.sheetName + ' 시트를 찾지 못했습니다. 생성 대상이 아니므로 건너뜁니다.');
        }
      }

      if (sheet) {
        result.createdNow = createdNow;
        result.headersBefore = CC04_getHeaderRow_(sheet);
        var missing = CC04_missingHeaders_(result.headersBefore, schema.headers);
        result.missingBefore = missing.slice();

        if (missing.length > 0) {
          if (previewOnly) {
            actions.push('PREVIEW_ADD_HEADERS: ' + schema.sheetName + ' => ' + missing.join(', '));
          } else {
            CC04_appendHeaders_(sheet, result.headersBefore, missing);
            flags.headerAddExecuted = true;
            flags.sheetWriteExecuted = true;
            result.addedHeaders = missing.slice();
            actions.push('ADD_HEADERS: ' + schema.sheetName + ' => ' + missing.join(', '));
          }
        }

        result.headersAfter = previewOnly ? result.headersBefore.concat(missing) : CC04_getHeaderRow_(sheet);
        result.ok = CC04_missingHeaders_(result.headersAfter, schema.headers).length === 0;
      } else {
        result.ok = false;
      }

      details.results.push(result);
    }

    flags.approvalLogOk = CC04_findResult_(details.results, 'ApprovalLog').ok;
    flags.backupLogOk = CC04_findResult_(details.results, 'BackupLog').ok;
    flags.deployLogOk = CC04_findResult_(details.results, 'DeployLog').ok;
    flags.recoveryLogOk = CC04_findResult_(details.results, 'RecoveryLog').ok;
    flags.logSchemaRepairOk = flags.approvalLogOk && flags.backupLogOk && flags.deployLogOk && flags.recoveryLogOk;
    flags.ok = flags.configOk && flags.masterOk && flags.logSchemaRepairOk;

    return CC04_result_(flags, fatal, warnings, actions, details);
  } catch (err) {
    fatal.push('CONTROL 로그 구조 보정 중 예외: ' + (err && err.message ? err.message : err));
    return CC04_result_(flags, fatal, warnings, actions, details);
  }
}

function CC04_getSchemas_() {
  return [
    {
      sheetName: 'ApprovalLog',
      createIfMissing: true,
      headers: [
        'approvalId','projectCode','controlProjectCode','approvalType','approvalScope','approvalStatus','approvedBy','approvedAt','requestedBy','requestedAt','targetSheetName','targetAction','relatedBuild','relatedDeployId','reason','status','statusReason','createdAt','createdBy','updatedAt','updatedBy','notes'
      ]
    },
    {
      sheetName: 'BackupLog',
      createIfMissing: false,
      headers: [
        'backupId','projectCode','buildRange','sourceDb','targetDb','backupScope','backupStatus','backupStartedAt','backupCompletedAt','executedBy','relatedDeployId','rollbackBaselineId','status','statusReason','createdAt','createdBy','updatedAt','updatedBy','notes'
      ]
    },
    {
      sheetName: 'DeployLog',
      createIfMissing: false,
      headers: [
        'deployId','projectCode','buildNo','deployLevel','deployStatus','approvalId','approvedBy','startedAt','completedAt','result','backupId','rollbackBaselineId','status','statusReason','createdAt','createdBy','updatedAt','updatedBy','notes'
      ]
    },
    {
      sheetName: 'RecoveryLog',
      createIfMissing: false,
      headers: [
        'recoveryId','rollbackBaselineId','projectCode','baselineBuild','rollbackScope','rollbackAllowed','reason','recoveryStatus','createdAt','createdBy','approvedBy','approvedAt','status','statusReason','updatedAt','updatedBy','notes'
      ]
    }
  ];
}

function CC04_baseFlags_(previewOnly) {
  return {
    ok: false,
    configOk: false,
    masterOk: false,
    logSchemaRepairOk: false,
    approvalLogOk: false,
    backupLogOk: false,
    deployLogOk: false,
    recoveryLogOk: false,
    approvedPatch: true,
    previewOnly: !!previewOnly,
    diagnosticOnly: !!previewOnly,
    schemaRepairOnly: true,
    sheetCreateExecuted: false,
    headerAddExecuted: false,
    sheetWriteExecuted: false,
    rowDataMutationExecuted: false,
    productionDataMutationExecuted: false,
    permissionMutationExecuted: false,
    statusTransitionExecuted: false,
    backupExecuted: false,
    deployExecuted: false,
    recoveryExecuted: false,
    rollbackExecuted: false,
    approvalWriteExecuted: false,
    auditLogWriteExecuted: false,
    existingDataDeleted: false,
    existingHeaderRenamed: false,
    deployAllowed: false,
    actualExecutionBlocked: true
  };
}

function CC04_safety_(previewOnly) {
  return {
    approvedHeaderRepairOnly: true,
    previewOnly: !!previewOnly,
    noRowDataMutation: true,
    noExistingHeaderRename: true,
    noExistingDataDelete: true,
    noPermissionMutation: true,
    noStatusTransition: true,
    noActualBackup: true,
    noActualDeploy: true,
    noActualRecovery: true,
    noActualRollback: true,
    noApprovalWrite: true,
    noAuditLogWrite: true,
    deployAllowed: false,
    actualExecutionBlocked: true
  };
}

function CC04_guidance_() {
  return {
    pageTitle: 'CONTROL 로그 구조 보정 패치 V01',
    mainStatusText: '승인된 범위 내에서 ApprovalLog 생성 및 BackupLog/DeployLog/RecoveryLog 부족 헤더만 보정합니다.',
    readonlyText: '기존 데이터 삭제/수정, 상태전이, 권한변경, 백업/복구/롤백/배포 실행은 하지 않습니다.',
    successText: 'CONTROL 로그 구조 보정이 완료되었습니다. CONTROL 03 재진단을 실행하세요.',
    emptyText: 'MASTER 연결 또는 대상 로그 시트를 확인해 주세요.',
    errorText: '로그 구조 보정 중 문제가 발생했습니다. SystemConfig와 MASTER 권한을 확인해 주세요.',
    nextAfterSuccess: 'CONTROL 03 백업/배포/복구 게이트 재진단'
  };
}

function CC04_result_(flags, fatal, warnings, actions, details) {
  return {
    ok: fatal.length === 0 && flags.ok,
    build: CC04_LOG_SCHEMA_REPAIR_BUILD,
    mode: CC04_LOG_SCHEMA_REPAIR_MODE,
    checkedAt: new Date().toISOString(),
    fatal: fatal,
    warnings: warnings,
    actions: actions,
    summary: flags,
    details: details,
    nextAction: fatal.length === 0 && flags.ok ? 'CONTROL_LOG_SCHEMA_REPAIR_PATCH_V01 완료. CONTROL 03을 재실행해 BackupLog/DeployLog/RecoveryLog 게이트 경고 해소 여부를 확인하세요.' : 'fatal/warnings 확인 후 SystemConfig, MASTER 권한, 로그 시트 상태를 확인하세요.'
  };
}

function CC04_findMasterDbId_(configSheet) {
  var values = configSheet.getDataRange().getValues();
  if (!values || values.length === 0) return '';
  var candidates = ['FEELHAUS_DB_MASTER_ID', 'FEELHAUS_DB_MASTER', 'DB_MASTER_ID', 'SPREADSHEET_ID', 'CUSTOMER_DB_SPREADSHEET_ID'];
  var header = values[0].map(function (v) { return String(v || '').trim(); });
  var keyCol = CC04_indexOfAny_(header, ['key', 'configKey', 'name', 'configName', 'item', 'code']);
  var valueCol = CC04_indexOfAny_(header, ['value', 'configValue', 'spreadsheetId', 'sheetId', 'id']);
  if (keyCol >= 0 && valueCol >= 0) {
    for (var r = 1; r < values.length; r++) {
      var k = String(values[r][keyCol] || '').trim();
      if (CC04_containsAny_(k, candidates)) return String(values[r][valueCol] || '').trim();
    }
  }
  for (var i = 0; i < values.length; i++) {
    for (var j = 0; j < values[i].length; j++) {
      var cell = String(values[i][j] || '').trim();
      if (CC04_containsAny_(cell, candidates)) {
        for (var c = j + 1; c < values[i].length; c++) {
          var possible = String(values[i][c] || '').trim();
          if (possible.length > 20) return possible;
        }
        if (i + 1 < values.length) {
          var below = String(values[i + 1][j] || '').trim();
          if (below.length > 20) return below;
        }
      }
    }
  }
  return '';
}

function CC04_getHeaderRow_(sheet) {
  var lastCol = sheet.getLastColumn();
  if (lastCol < 1) return [];
  return sheet.getRange(1, 1, 1, lastCol).getValues()[0].map(function (v) { return String(v || '').trim(); });
}

function CC04_missingHeaders_(headers, required) {
  var existing = {};
  for (var i = 0; i < headers.length; i++) {
    if (headers[i]) existing[headers[i]] = true;
  }
  var missing = [];
  for (var j = 0; j < required.length; j++) {
    if (!existing[required[j]]) missing.push(required[j]);
  }
  return missing;
}

function CC04_appendHeaders_(sheet, headersBefore, missing) {
  if (!missing || missing.length === 0) return;
  var startCol = headersBefore.length + 1;
  if (startCol < 1) startCol = 1;
  sheet.getRange(1, startCol, 1, missing.length).setValues([missing]);
}

function CC04_findResult_(results, sheetName) {
  for (var i = 0; i < results.length; i++) {
    if (results[i].sheetName === sheetName) return results[i];
  }
  return { ok: false };
}

function CC04_indexOfAny_(arr, names) {
  for (var i = 0; i < arr.length; i++) {
    for (var j = 0; j < names.length; j++) {
      if (String(arr[i]).trim() === names[j]) return i;
    }
  }
  return -1;
}

function CC04_containsAny_(text, candidates) {
  for (var i = 0; i < candidates.length; i++) {
    if (String(text).indexOf(candidates[i]) >= 0) return true;
  }
  return false;
}
