/**
 * FEELHAUS CONTROL CENTER - SIGN fixed operations v1
 * SIGN은 FEELHAUS_DB_MASTER 안의 SIGN_* 시트 기준으로만 진단한다.
 */
function runWriteControlSignDiagnostics() {
  return ccWriteSignDiagnostics_('CONTROL_SIGN_DIAGNOSTICS');
}

function runWriteControlSignDiagnosticsV2() {
  return ccWriteSignDiagnostics_('CONTROL_SIGN_DIAGNOSTICS_V2');
}

function ccWriteSignDiagnostics_(sheetName) {
  var masterId = ccResolveDbMasterId_();
  if (!masterId) throw new Error('DB_MASTER ID를 찾을 수 없습니다.');
  var ss = ccOpenSpreadsheet_(masterId, 'DB_MASTER');
  var sheets = ss.getSheets().map(function (s) { return s.getName(); });
  var signSheets = sheets.filter(function (n) { return /^SIGN_/i.test(n) || n === 'Documents' || n === 'DocumentLogs'; });
  var rows = [];
  rows.push(['diagnosticId', 'checkedAt', 'status', 'warningCount', 'criticalCount', 'message']);
  var critical = signSheets.length === 0 ? 1 : 0;
  var warning = 0;
  rows.push(['DIAG-' + Utilities.getUuid(), ccNow_(), critical === 0 ? 'PASS' : 'CHECK_REQUIRED', warning, critical, critical === 0 ? 'DB_MASTER 기준 SIGN 구조 확인' : 'SIGN 관련 시트 확인 필요']);
  var targetId = masterId;
  if (!ccIsValidSpreadsheetIdCandidate_(targetId)) throw new Error('SIGN 진단 기록 대상 DB_MASTER ID가 올바르지 않습니다.');
  var sh = ccGetOrCreateSheet_(targetId, sheetName);
  sh.clear();
  sh.getRange(1, 1, rows.length, rows[0].length).setValues(rows);
  ccAppendLog_('CONTROL_SIGN_DIAGNOSTIC', sheetName, '', 'PASS_CHECK', 'SIGN DB_MASTER 기준 진단', '');
  return { status: critical === 0 ? 'PASS' : 'CHECK_REQUIRED', warningCount: warning, criticalCount: critical, signSheets: signSheets };
}

function getControlPassStatus() {
  var p = ccRunControlPreflight_();
  return { status: p.status, warningCount: p.warningCount, criticalCount: p.criticalCount, build: p.build };
}
