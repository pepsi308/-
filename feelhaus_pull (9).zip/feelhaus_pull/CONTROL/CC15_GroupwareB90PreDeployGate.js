/**
 * FEELHAUS CONTROL - GROUPWARE B90 PREDEPLOY DIAGNOSTIC GATE
 * Build: CONTROL_GROUPWARE_B90_PREDEPLOY_GATE_V01
 * Progress: [02/10] 20%
 * Target baseline: GROUPWARE_B90_FINAL_STABLE_AFTER_B70_B90_RUNALL
 * Execution function: runControlGroupwareB90PreDeployGateV01
 *
 * Safety:
 * - Diagnostic only
 * - No sheet creation
 * - No header mutation
 * - No approval writing
 * - No audit log writing
 * - No backup/deploy/recovery/rollback execution
 * - No GROUPWARE production save
 * - No field open execution
 * - No real apply execution
 */
var CC15_BUILD = 'CONTROL_GROUPWARE_B90_PREDEPLOY_GATE_V01';
var CC15_MODE = 'GROUPWARE_B90_PREDEPLOY_DIAGNOSTIC_ONLY_NO_UPDATE';
var CC15_PROGRESS = { current: 2, total: 10, percent: 20 };
var CC15_SETUP_DB_ID = '17VMSpgSZCvIrUlgcw8yCNcnl8WQWo2IcRf5tDCcuJGM';
var CC15_CONFIG_SHEET_NAME = 'SystemConfig';
var CC15_SOURCE_DB = 'FEELHAUS_SETUP_DB';
var CC15_TARGET = {
  projectCode: 'GROUPWARE',
  moduleCode: 'GROUPWARE_PORTAL_HR_MAIL_CALENDAR',
  buildRange: 'B70~B90',
  currentBuildNo: 'B90',
  finalBuildNo: 'B90',
  buildProgress: '90 / 90',
  progressPercent: 100,
  runAllStatus: 'GROUPWARE_B70_TO_B90_RUNALL_PASS',
  runAllOk: true,
  runAllFatalCount: 0,
  protectedBaseline: 'B70~B89',
  finalStableName: 'GROUPWARE_B90_FINAL_STABLE',
  expectedFlags: {
    productionSaveAllowed: false,
    fieldUseOpenAllowed: false,
    deployAllowed: false,
    realApplyAllowed: false
  }
};

function runControlGroupwareB90PreDeployGateV01() {
  var result = diagnoseControlGroupwareB90PreDeployGateV01_();
  CC15_logCompactResult_(result);
  return result;
}

function runGroupwareB90PreDeployGateV01() {
  var result = diagnoseControlGroupwareB90PreDeployGateV01_();
  CC15_logCompactResult_(result);
  return result;
}

function getControlGroupwareB90PreDeployGateData() {
  var result = diagnoseControlGroupwareB90PreDeployGateV01_();
  CC15_logCompactResult_(result);
  return result;
}

function controlGroupwareB90PreDeployGateV01() {
  var result = diagnoseControlGroupwareB90PreDeployGateV01_();
  CC15_logCompactResult_(result);
  return result;
}

function diagnoseControlGroupwareB90PreDeployGateV01_() {
  var started = new Date();
  var fatal = [];
  var hold = [];
  var warnings = [];
  var details = {};
  var summary = CC15_defaultSummary_();

  try {
    details.setup = CC15_readSystemConfig_();
    summary.configOk = details.setup.ok === true;
    summary.systemConfigAutoReadOk = details.setup.ok === true;
  } catch (e1) {
    fatal.push('SystemConfig 자동 읽기 실패: ' + CC15_errorMessage_(e1));
    details.setup = { ok: false, error: CC15_errorMessage_(e1) };
  }

  try {
    var cfg = details.setup && details.setup.config ? details.setup.config : {};
    details.master = CC15_openMasterDb_(cfg);
    summary.masterOk = details.master.ok === true;
    summary.masterConnectedOk = details.master.ok === true;
  } catch (e2) {
    fatal.push('FEELHAUS_DB_MASTER 연결 실패: ' + CC15_errorMessage_(e2));
    details.master = { ok: false, error: CC15_errorMessage_(e2) };
  }

  if (details.master && details.master.ss) {
    details.sheetGroups = CC15_checkSheetGroups_(details.master.ss);
    summary.requiredGateSheetsOk = details.sheetGroups.requiredOk === true;
    summary.groupwareFoundationSheetsOk = details.sheetGroups.groupwareFoundationOk === true;
    summary.permissionSheetsOk = details.sheetGroups.permissionOk === true;
    summary.auditSheetsOk = details.sheetGroups.auditOk === true;
    summary.controlGateSheetsOk = details.sheetGroups.controlGateOk === true;
    summary.mobileAndCalendarBridgeSheetsOk = details.sheetGroups.mobileCalendarBridgeOk === true;

    details.headerGroups = CC15_checkHeaderGroups_(details.master.ss, details.sheetGroups);
    summary.requiredGateHeadersOk = details.headerGroups.requiredOk === true;
    summary.headerMapTrackingOk = details.headerGroups.headerMapTrackingOk === true;

    details.baselineProtection = CC15_checkBaselineProtection_(details.sheetGroups, details.headerGroups);
    summary.b70ToB89ProtectionOk = details.baselineProtection.ok === true;
  } else {
    hold.push('FEELHAUS_DB_MASTER 연결 확인 전이라 시트/헤더 진단 생략');
  }

  details.runAllEvidence = CC15_buildRunAllEvidence_();
  summary.groupwareB90RunAllPassed = details.runAllEvidence.ok === true;
  summary.groupwareB90FatalZero = details.runAllEvidence.fatalCount === 0;
  summary.b70ToB90FinalStableOk = summary.groupwareB90RunAllPassed && summary.groupwareB90FatalZero;

  details.operationBlock = CC15_operationBlock_();
  summary.productionSaveAllowed = false;
  summary.fieldUseOpenAllowed = false;
  summary.deployAllowed = false;
  summary.realApplyAllowed = false;
  summary.actualExecutionBlocked = true;
  summary.diagnosticOnly = true;
  summary.dryRunOnly = true;

  if (!summary.groupwareFoundationSheetsOk) hold.push('GROUPWARE 기반 시트 확인 필요');
  if (!summary.permissionSheetsOk) hold.push('권한 시트 확인 필요');
  if (!summary.auditSheetsOk) hold.push('감사로그 시트 확인 필요');
  if (!summary.controlGateSheetsOk) hold.push('CONTROL 게이트/승인/백업 로그 시트 확인 필요');
  if (!summary.mobileAndCalendarBridgeSheetsOk) hold.push('모바일 안정화 또는 메일센터 캘린더 브릿지 시트 확인 필요');
  if (!summary.requiredGateHeadersOk) hold.push('필수 헤더맵 확인 필요');

  var passConditions = [
    summary.configOk,
    summary.masterOk,
    summary.groupwareB90RunAllPassed,
    summary.groupwareB90FatalZero,
    summary.requiredGateSheetsOk,
    summary.requiredGateHeadersOk,
    summary.b70ToB89ProtectionOk,
    summary.actualExecutionBlocked,
    !summary.productionSaveAllowed,
    !summary.fieldUseOpenAllowed,
    !summary.deployAllowed,
    !summary.realApplyAllowed
  ];

  var allPass = fatal.length === 0 && hold.length === 0 && CC15_allTrue_(passConditions);
  var judgement = fatal.length > 0 ? 'BLOCK' : (allPass ? 'PASS' : 'HOLD');
  summary.preDeployDiagnosticOk = judgement === 'PASS';
  summary.judgement = judgement;

  var result = {
    ok: judgement === 'PASS',
    build: CC15_BUILD,
    progress: CC15_PROGRESS,
    mode: CC15_MODE,
    checkedAt: CC15_now_(),
    judgement: judgement,
    targetBaseline: CC15_TARGET,
    summary: summary,
    evidence: {
      setupDbId: CC15_SETUP_DB_ID,
      configSheetName: CC15_CONFIG_SHEET_NAME,
      sourceDb: CC15_SOURCE_DB,
      setupDbName: details.setup && details.setup.setupDbName || '',
      masterDbIdMasked: CC15_maskId_(details.master && details.master.masterDbId || ''),
      masterDbName: details.master && details.master.masterDbName || '',
      sheetGroups: details.sheetGroups || {},
      headerGroups: details.headerGroups || {},
      baselineProtection: details.baselineProtection || {},
      runAllEvidence: details.runAllEvidence || {},
      operationBlock: details.operationBlock || {},
      elapsedMs: new Date().getTime() - started.getTime()
    },
    warnings: warnings,
    hold: hold,
    fatal: fatal,
    nextAction: judgement === 'PASS'
      ? '[02/10] GROUPWARE B90 CONTROL predeploy diagnostic PASS. Next step is [03/10] backup and rollback evidence gate. This gate executed no production change.'
      : '[02/10] GROUPWARE B90 CONTROL predeploy diagnostic is not PASS. Resolve hold/fatal items before backup/rollback evidence gate.'
  };
  return result;
}

function CC15_defaultSummary_() {
  return {
    baselineOk: true,
    configOk: false,
    masterOk: false,
    systemConfigAutoReadOk: false,
    masterConnectedOk: false,
    groupwareB90RunAllPassed: false,
    groupwareB90FatalZero: false,
    b70ToB90FinalStableOk: false,
    b70ToB89ProtectionOk: false,
    requiredGateSheetsOk: false,
    requiredGateHeadersOk: false,
    groupwareFoundationSheetsOk: false,
    permissionSheetsOk: false,
    auditSheetsOk: false,
    controlGateSheetsOk: false,
    mobileAndCalendarBridgeSheetsOk: false,
    headerMapTrackingOk: false,
    preDeployDiagnosticOk: false,
    productionSaveAllowed: false,
    fieldUseOpenAllowed: false,
    deployAllowed: false,
    realApplyAllowed: false,
    actualExecutionBlocked: true,
    diagnosticOnly: true,
    dryRunOnly: true,
    sheetWriteExecuted: false,
    sheetCreateExecuted: false,
    headerAutoAddExecuted: false,
    approvalWriteExecuted: false,
    auditLogWriteExecuted: false,
    backupExecuted: false,
    deployExecuted: false,
    recoveryExecuted: false,
    rollbackExecuted: false,
    realApplyExecuted: false,
    productionDataMutationExecuted: false
  };
}

function CC15_readSystemConfig_() {
  var ss = SpreadsheetApp.openById(CC15_SETUP_DB_ID);
  var sheet = ss.getSheetByName(CC15_CONFIG_SHEET_NAME);
  if (!sheet) throw new Error('SystemConfig sheet not found: ' + CC15_CONFIG_SHEET_NAME);
  var values = sheet.getDataRange().getValues();
  var config = {};
  for (var i = 1; i < values.length; i++) {
    var key = String(values[i][0] || '').trim();
    var value = values[i][1];
    if (key) config[key] = value;
  }
  return {
    ok: true,
    setupDbId: CC15_SETUP_DB_ID,
    setupDbName: ss.getName(),
    sourceDb: CC15_SOURCE_DB,
    sheetName: CC15_CONFIG_SHEET_NAME,
    config: config
  };
}

function CC15_openMasterDb_(config) {
  config = config || {};
  var id = String(config.FEELHAUS_DB_MASTER_ID || config.FEELHAUS_DB_MASTER || config.DB_MASTER_ID || config.MASTER_DB_ID || '').trim();
  if (!id) throw new Error('FEELHAUS_DB_MASTER_ID is missing in SystemConfig');
  var ss = SpreadsheetApp.openById(id);
  return { ok: true, masterDbId: id, masterDbName: ss.getName(), ss: ss };
}

function CC15_checkSheetGroups_(ss) {
  var names = ss.getSheets().map(function(s) { return s.getName(); });
  var exists = function(candidates) { return CC15_firstExisting_(names, candidates); };
  var groupware = {
    users: exists(['PortalUsers', 'PortalUsers_OLD_20260513', 'Users']),
    approvals: exists(['Portal_Approvals', 'ApprovalLog', 'ERP_승인큐', 'ERP_ApprovalRequests']),
    portalLog: exists(['Portal_Log', 'Portal_AuditLog', 'Portal_ActionLog', 'Portal_TaskLog']),
    employee: exists(['EmployeeAuth', 'EmployeeSessions', 'Employees'])
  };
  var permission = {
    role: exists(['UserRoles', 'RolePolicies', 'ERP_권한관리', 'MailCenter_UserPermissions']),
    requests: exists(['PermissionRequests', 'EmployeeRoleRequests', 'SensitiveAccessRequests']),
    sessions: exists(['EmployeeSessions', 'EmployeeAuth'])
  };
  var audit = {
    auditLog: exists(['AuditLogs', 'AuditLog', 'ERP_감사로그', 'Portal_AuditLog', 'MailCenter_AuditLogs']),
    timeline: exists(['Timelines', 'FORM_TIMELINE', 'SystemLogs']),
    security: exists(['SecurityEvents', 'DiagnosticsLog', 'CONTROL_DiagnosticLog'])
  };
  var control = {
    diagnostic: exists(['CONTROL_DiagnosticLog', 'DiagnosticsLog', 'SystemLogs']),
    approval: exists(['ApprovalLog', 'ApprovalAudit', 'Portal_Approvals', 'CONTROL_C52_INSPECTION']),
    backup: exists(['CONTROL_BackupLog', 'BackupLog', 'BackupHistory']),
    deploy: exists(['DeployLog', 'CONTROL_RecoveryLog', 'RecoveryLog'])
  };
  var bridge = {
    mailCenter: exists(['MailCenter_OpenLock', 'MailCenter_Accounts', 'MailCenter_AuditLogs', 'MAILCENTER_CalendarEvents']),
    calendar: exists(['CalendarEvents', 'PORTAL_CalendarEvents', 'MAILCENTER_CalendarEvents']),
    mobile: exists(['PortalUsers', 'EmployeeSessions', 'MailCenter_OpenLock'])
  };
  var missing = [];
  CC15_collectMissing_(missing, 'groupware.users', groupware.users);
  CC15_collectMissing_(missing, 'groupware.approvals', groupware.approvals);
  CC15_collectMissing_(missing, 'groupware.portalLog', groupware.portalLog);
  CC15_collectMissing_(missing, 'groupware.employee', groupware.employee);
  CC15_collectMissing_(missing, 'permission.role', permission.role);
  CC15_collectMissing_(missing, 'permission.requests', permission.requests);
  CC15_collectMissing_(missing, 'audit.auditLog', audit.auditLog);
  CC15_collectMissing_(missing, 'control.diagnostic', control.diagnostic);
  CC15_collectMissing_(missing, 'control.approval', control.approval);
  CC15_collectMissing_(missing, 'control.backup', control.backup);
  CC15_collectMissing_(missing, 'bridge.mailCenter', bridge.mailCenter);
  CC15_collectMissing_(missing, 'bridge.calendar', bridge.calendar);
  return {
    totalSheets: names.length,
    missing: missing,
    groupware: groupware,
    permission: permission,
    audit: audit,
    control: control,
    bridge: bridge,
    groupwareFoundationOk: !!(groupware.users && groupware.approvals && groupware.portalLog && groupware.employee),
    permissionOk: !!(permission.role && permission.requests && permission.sessions),
    auditOk: !!(audit.auditLog && audit.timeline && audit.security),
    controlGateOk: !!(control.diagnostic && control.approval && control.backup && control.deploy),
    mobileCalendarBridgeOk: !!(bridge.mailCenter && bridge.calendar && bridge.mobile),
    requiredOk: missing.length === 0
  };
}

function CC15_checkHeaderGroups_(ss, sheetGroups) {
  var checks = [];
  CC15_addHeaderCheck_(checks, ss, sheetGroups.groupware.users, ['userId', 'roleCode'], ['status']);
  CC15_addHeaderCheck_(checks, ss, sheetGroups.groupware.approvals, ['approvalId', 'approvalStatus'], ['approvedBy', 'approvedAt', 'status']);
  CC15_addHeaderCheck_(checks, ss, sheetGroups.audit.auditLog, ['createdAt'], ['logId', 'createdBy', 'status']);
  CC15_addHeaderCheck_(checks, ss, sheetGroups.control.backup, ['createdAt'], ['backupId', 'buildNo', 'status']);
  CC15_addHeaderCheck_(checks, ss, sheetGroups.bridge.calendar, ['eventId'], ['calendarId', 'status', 'updatedAt']);
  var missing = [];
  for (var i = 0; i < checks.length; i++) {
    if (!checks[i].ok) missing.push(checks[i]);
  }
  return {
    checks: checks,
    missing: missing,
    requiredOk: missing.length === 0,
    headerMapTrackingOk: checks.length >= 5 && missing.length === 0
  };
}

function CC15_addHeaderCheck_(checks, ss, sheetName, requiredAny, optionalAny) {
  var result = { sheetName: sheetName || '', ok: false, foundRequired: [], foundOptional: [], missingRequiredAny: requiredAny || [] };
  if (!sheetName) {
    checks.push(result);
    return;
  }
  var sheet = ss.getSheetByName(sheetName);
  if (!sheet || sheet.getLastColumn() < 1) {
    checks.push(result);
    return;
  }
  var headers = sheet.getRange(1, 1, 1, sheet.getLastColumn()).getValues()[0].map(function(h) { return String(h || '').trim(); });
  result.foundRequired = CC15_intersection_(headers, requiredAny || []);
  result.foundOptional = CC15_intersection_(headers, optionalAny || []);
  result.ok = result.foundRequired.length > 0;
  checks.push(result);
}

function CC15_checkBaselineProtection_(sheetGroups, headerGroups) {
  var protectedItems = [
    'SystemConfig 자동 읽기',
    'FEELHAUS_DB_MASTER 연결',
    'B70~B89 기준 보호',
    '권한 시트 보호',
    '감사로그 보호',
    'CONTROL 게이트 보호',
    '모바일 안정화 보호',
    '메일센터 캘린더 읽기전용 브릿지 보호'
  ];
  return {
    ok: sheetGroups.requiredOk === true && headerGroups.requiredOk === true,
    protectedItems: protectedItems,
    deleteCandidateTouched: false,
    independentDbCreated: false,
    vendorIndependentAppCreated: false,
    productionMutationAllowed: false
  };
}

function CC15_buildRunAllEvidence_() {
  return {
    ok: true,
    source: 'USER_PROVIDED_GROUPWARE_B70_B90_RUNALL_RESULT',
    buildRange: CC15_TARGET.buildRange,
    currentBuildNo: CC15_TARGET.currentBuildNo,
    finalBuildNo: CC15_TARGET.finalBuildNo,
    runAllOk: true,
    fatalCount: 0,
    protectedBaseline: CC15_TARGET.protectedBaseline,
    note: 'GROUPWARE B70~B90 최종 안정화 RunAll 통과 및 B90 ok true/fatalCount 0 기준으로 CONTROL 사전배포 진단 수행'
  };
}

function CC15_operationBlock_() {
  return {
    productionSaveAllowed: false,
    fieldUseOpenAllowed: false,
    deployAllowed: false,
    realApplyAllowed: false,
    actualExecutionBlocked: true,
    sheetWriteExecuted: false,
    sheetCreateExecuted: false,
    headerAutoAddExecuted: false,
    approvalWriteExecuted: false,
    auditLogWriteExecuted: false,
    backupExecuted: false,
    deployExecuted: false,
    recoveryExecuted: false,
    rollbackExecuted: false,
    realApplyExecuted: false,
    productionDataMutationExecuted: false
  };
}

function CC15_logCompactResult_(result) {
  Logger.log('JSON_COMPACT_RESULT: ' + JSON.stringify(CC15_compactResult_(result)));
}

function CC15_compactResult_(result) {
  result = result || {};
  var summary = result.summary || {};
  var evidence = result.evidence || {};
  return {
    ok: result.ok === true,
    build: result.build || CC15_BUILD,
    progress: CC15_PROGRESS,
    mode: result.mode || CC15_MODE,
    checkedAt: result.checkedAt || '',
    judgement: result.judgement || 'BLOCK',
    targetBaseline: {
      projectCode: CC15_TARGET.projectCode,
      moduleCode: CC15_TARGET.moduleCode,
      buildRange: CC15_TARGET.buildRange,
      currentBuildNo: CC15_TARGET.currentBuildNo,
      finalBuildNo: CC15_TARGET.finalBuildNo,
      buildProgress: CC15_TARGET.buildProgress,
      progressPercent: CC15_TARGET.progressPercent,
      runAllStatus: CC15_TARGET.runAllStatus,
      protectedBaseline: CC15_TARGET.protectedBaseline
    },
    summary: {
      baselineOk: summary.baselineOk === true,
      configOk: summary.configOk === true,
      masterOk: summary.masterOk === true,
      systemConfigAutoReadOk: summary.systemConfigAutoReadOk === true,
      masterConnectedOk: summary.masterConnectedOk === true,
      groupwareB90RunAllPassed: summary.groupwareB90RunAllPassed === true,
      groupwareB90FatalZero: summary.groupwareB90FatalZero === true,
      b70ToB90FinalStableOk: summary.b70ToB90FinalStableOk === true,
      b70ToB89ProtectionOk: summary.b70ToB89ProtectionOk === true,
      requiredGateSheetsOk: summary.requiredGateSheetsOk === true,
      requiredGateHeadersOk: summary.requiredGateHeadersOk === true,
      groupwareFoundationSheetsOk: summary.groupwareFoundationSheetsOk === true,
      permissionSheetsOk: summary.permissionSheetsOk === true,
      auditSheetsOk: summary.auditSheetsOk === true,
      controlGateSheetsOk: summary.controlGateSheetsOk === true,
      mobileAndCalendarBridgeSheetsOk: summary.mobileAndCalendarBridgeSheetsOk === true,
      headerMapTrackingOk: summary.headerMapTrackingOk === true,
      preDeployDiagnosticOk: summary.preDeployDiagnosticOk === true,
      productionSaveAllowed: summary.productionSaveAllowed === true,
      fieldUseOpenAllowed: summary.fieldUseOpenAllowed === true,
      deployAllowed: summary.deployAllowed === true,
      realApplyAllowed: summary.realApplyAllowed === true,
      actualExecutionBlocked: summary.actualExecutionBlocked !== false,
      diagnosticOnly: summary.diagnosticOnly === true,
      dryRunOnly: summary.dryRunOnly === true,
      sheetWriteExecuted: summary.sheetWriteExecuted === true,
      sheetCreateExecuted: summary.sheetCreateExecuted === true,
      headerAutoAddExecuted: summary.headerAutoAddExecuted === true,
      approvalWriteExecuted: summary.approvalWriteExecuted === true,
      auditLogWriteExecuted: summary.auditLogWriteExecuted === true,
      backupExecuted: summary.backupExecuted === true,
      deployExecuted: summary.deployExecuted === true,
      recoveryExecuted: summary.recoveryExecuted === true,
      rollbackExecuted: summary.rollbackExecuted === true,
      realApplyExecuted: summary.realApplyExecuted === true,
      productionDataMutationExecuted: summary.productionDataMutationExecuted === true
    },
    evidence: {
      setupDbId: evidence.setupDbId || CC15_SETUP_DB_ID,
      configSheetName: evidence.configSheetName || CC15_CONFIG_SHEET_NAME,
      sourceDb: evidence.sourceDb || CC15_SOURCE_DB,
      setupDbName: evidence.setupDbName || '',
      masterDbIdMasked: evidence.masterDbIdMasked || '',
      masterDbName: evidence.masterDbName || '',
      totalSheets: evidence.sheetGroups && evidence.sheetGroups.totalSheets || 0,
      missingSheetsOrGroups: evidence.sheetGroups && evidence.sheetGroups.missing || [],
      missingHeaderChecks: evidence.headerGroups && evidence.headerGroups.missing || [],
      protectedItems: evidence.baselineProtection && evidence.baselineProtection.protectedItems || [],
      runAllEvidence: evidence.runAllEvidence || {},
      elapsedMs: evidence.elapsedMs || 0
    },
    warnings: result.warnings || [],
    hold: result.hold || [],
    fatal: result.fatal || [],
    nextAction: result.nextAction || ''
  };
}

function CC15_firstExisting_(names, candidates) {
  candidates = candidates || [];
  for (var i = 0; i < candidates.length; i++) {
    if (names.indexOf(candidates[i]) >= 0) return candidates[i];
  }
  return '';
}

function CC15_collectMissing_(missing, key, value) {
  if (!value) missing.push(key);
}

function CC15_intersection_(headers, candidates) {
  var out = [];
  candidates = candidates || [];
  for (var i = 0; i < candidates.length; i++) {
    if (headers.indexOf(candidates[i]) >= 0) out.push(candidates[i]);
  }
  return out;
}

function CC15_allTrue_(items) {
  for (var i = 0; i < items.length; i++) {
    if (items[i] !== true) return false;
  }
  return true;
}

function CC15_maskId_(id) {
  id = String(id || '');
  if (!id) return '';
  if (id.length <= 8) return '***';
  return id.substring(0, 4) + '***' + id.substring(id.length - 4);
}

function CC15_now_() {
  var tz = 'Asia/Seoul';
  try { tz = Session.getScriptTimeZone() || tz; } catch (e) {}
  return Utilities.formatDate(new Date(), tz, "yyyy-MM-dd'T'HH:mm:ssXXX");
}

function CC15_errorMessage_(err) {
  if (!err) return 'unknown error';
  return err.message || String(err);
}
