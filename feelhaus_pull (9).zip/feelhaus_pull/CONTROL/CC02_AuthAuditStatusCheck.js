/**
 * FEELHAUS CONTROL 02 - AUTH / AUDIT / STATUS CHECK LOCK
 * Build: CONTROL_02_AUTH_AUDIT_STATUS_LOCK
 * Purpose: roleCode auth, audit log, status transition, lock/edit-block and approval-gate diagnostics only.
 * Safety: No auth change, no status transition, no approval/log write, no sheet/header mutation.
 */
var CC02_BUILD = 'CONTROL_02_AUTH_AUDIT_STATUS_LOCK';
var CC02_MODE = 'AUTH_AUDIT_STATUS_DIAGNOSTIC_ONLY_NO_UPDATE';

function runControl02() {
  return diagnoseControl02AuthAuditStatus();
}

function getControl02DashboardData() {
  return diagnoseControl02AuthAuditStatus();
}

function control02SmokeTest() {
  var result = diagnoseControl02AuthAuditStatus();
  Logger.log(JSON.stringify(result, null, 2));
  return result;
}

function diagnoseControl02AuthAuditStatus() {
  var fatal = [];
  var warnings = [];
  var summary = CC02_baseSummary_();
  var details = {
    build: CC02_BUILD,
    mode: CC02_MODE,
    sourceDb: CC_SOURCE_DB,
    setupDbId: CC_SETUP_DB_ID,
    configSheetName: CC_CONFIG_SHEET_NAME,
    masterDbId: '',
    masterDbName: '',
    requiredRoles: CC02_requiredRoles_(),
    authPolicy: {},
    auditPolicy: {},
    statusPolicy: {},
    lockPolicy: {},
    approvalPolicy: {},
    safety: CC_getSafety_(),
    guidance: CC02_guidance_()
  };

  try {
    var master = CC_openMasterDb_();
    summary.configOk = true;
    summary.masterOk = !!master && !!master.ss;
    details.masterDbId = master.masterDbId;
    details.masterDbName = master.masterDbName;

    details.authPolicy = CC02_checkAuthPolicy_(master.ss);
    details.auditPolicy = CC02_checkAuditPolicy_(master.ss);
    details.statusPolicy = CC02_checkStatusPolicy_(master.ss);
    details.lockPolicy = CC02_checkLockPolicy_(master.ss);
    details.approvalPolicy = CC02_checkApprovalPolicy_(master.ss);

    summary.authPolicyOk = details.authPolicy.ok === true;
    summary.roleSeparationOk = details.authPolicy.roleSeparationOk === true;
    summary.auditLogPolicyOk = details.auditPolicy.ok === true;
    summary.statusTransitionPolicyOk = details.statusPolicy.ok === true;
    summary.lockEditBlockPolicyOk = details.lockPolicy.ok === true;
    summary.approvalGatePolicyOk = details.approvalPolicy.ok === true;

    if (!summary.authPolicyOk) warnings.push('권한 정책 시트/헤더 일부가 부족합니다. roleCode 기반 권한 진단 후보를 확인하세요.');
    if (!summary.auditLogPolicyOk) warnings.push('감사로그 기준 일부가 부족합니다. 중요 작업 추적 시트/헤더 후보를 확인하세요.');
    if (!summary.statusTransitionPolicyOk) warnings.push('상태전이 정책 기준 일부가 부족합니다. 허용 전이/승인필수 헤더 후보를 확인하세요.');
    if (!summary.lockEditBlockPolicyOk) warnings.push('완료/잠금/종료 후 수정차단 기준 일부가 부족합니다. 차단 정책 후보를 확인하세요.');
    if (!summary.approvalGatePolicyOk) warnings.push('승인 게이트 기준 일부가 부족합니다. 승인요청/승인감사 후보를 확인하세요.');

    summary.diagnosticOnly = true;
    summary.productionDataMutationExecuted = false;
    summary.authMutationExecuted = false;
    summary.approvalWriteExecuted = false;
    summary.auditLogWriteExecuted = false;
    summary.statusTransitionExecuted = false;
    summary.created = false;
    summary.updated = false;
    summary.deleted = false;
    summary.sheetWriteExecuted = false;
    summary.headerAutoAddExecuted = false;

    summary.ok = fatal.length === 0 && summary.configOk && summary.masterOk && summary.roleSeparationOk;
    return CC02_result_(summary, fatal, warnings, details);
  } catch (err) {
    fatal.push('CONTROL 02 진단 중 예외: ' + (err && err.message ? err.message : err));
    return CC02_result_(summary, fatal, warnings, details);
  }
}

function CC02_baseSummary_() {
  return {
    ok: false,
    configOk: false,
    masterOk: false,
    authPolicyOk: false,
    roleSeparationOk: false,
    auditLogPolicyOk: false,
    statusTransitionPolicyOk: false,
    lockEditBlockPolicyOk: false,
    approvalGatePolicyOk: false,
    diagnosticOnly: true,
    productionDataMutationExecuted: false,
    authMutationExecuted: false,
    approvalWriteExecuted: false,
    auditLogWriteExecuted: false,
    statusTransitionExecuted: false,
    created: false,
    updated: false,
    deleted: false,
    sheetWriteExecuted: false,
    headerAutoAddExecuted: false
  };
}

function CC02_requiredRoles_() {
  return ['STAFF', 'ADMIN', 'HQ_ADMIN', 'DEV', 'SUPER_ADMIN'];
}

function CC02_checkAuthPolicy_(ss) {
  var candidates = [
    { sheetName: 'ERP_권한관리', headers: { roleCode: ['roleCode'], vendorId: ['vendorId'], eventId: ['eventId'], status: ['status'], canView: ['canView'], canEdit: ['canEdit'], canDownload: ['canDownload'], sensitiveAccess: ['sensitiveAccess'], approvalRequired: ['approvalRequired'] } },
    { sheetName: 'RolePolicies', headers: { roleCode: ['roleCode'], status: ['status'], permissionScope: ['permissionScope', 'scope'], approvalRequired: ['approvalRequired'] } },
    { sheetName: 'EmployeeAuth', headers: { employeeId: ['employeeId', 'userId'], roleCode: ['roleCode'], status: ['status'], vendorId: ['vendorId'], eventId: ['eventId'] } },
    { sheetName: 'ERP_사용자관리', headers: { userId: ['userId', 'employeeId'], roleCode: ['roleCode'], status: ['status'], vendorId: ['vendorId'], eventId: ['eventId'] } }
  ];
  var checked = CC02_checkSheetCandidates_(ss, candidates);
  var roleRows = [];
  checked.forEach(function (item) {
    if (!item.exists || item.roleCodeColumn < 0) return;
    roleRows = roleRows.concat(CC02_collectRoleCodes_(ss.getSheetByName(item.sheetName), item.roleCodeColumn));
  });
  var foundRoles = CC02_unique_(roleRows);
  var roleSeparationOk = foundRoles.length > 0 || checked.some(function (item) { return item.sheetName === 'ERP_권한관리' && item.exists && item.headersOk; });
  return {
    ok: checked.some(function (item) { return item.exists && item.headersOk; }),
    roleSeparationOk: roleSeparationOk,
    requiredRoles: CC02_requiredRoles_(),
    foundRoles: foundRoles,
    checkedSheets: checked,
    policy: 'roleCode, vendorId, eventId, employeeId 기준 권한 분리 후보 진단. 실제 권한 변경은 차단.'
  };
}

function CC02_checkAuditPolicy_(ss) {
  var candidates = [
    { sheetName: 'ERP_정산로그', headers: { logId: ['logId'], targetId: ['targetId', 'settlementId'], action: ['action', 'actionCode'], createdAt: ['createdAt', 'actedAt'] } },
    { sheetName: 'PORTAL_Log', headers: { logId: ['logId'], action: ['action', 'actionCode'], createdAt: ['createdAt'] } },
    { sheetName: 'SystemLogs', headers: { logId: ['logId'], action: ['action', 'actionCode'], createdAt: ['createdAt'] } },
    { sheetName: 'DiagnosticsLog', headers: { logId: ['logId'], status: ['status'], createdAt: ['createdAt'] } },
    { sheetName: 'ApprovalAudit', headers: { approvalId: ['approvalId'], action: ['action', 'actionCode'], createdAt: ['createdAt'] } }
  ];
  var checked = CC02_checkSheetCandidates_(ss, candidates);
  return {
    ok: checked.some(function (item) { return item.exists && item.headersOk; }),
    checkedSheets: checked,
    requiredActions: ['권한 변경', '상태전이', '잠금해제', '재오픈', '정산수정', '취소정산', '환수', '추가지급', '구조변경'],
    policy: '중요 작업은 감사로그 기준으로 추적. CONTROL 02는 로그를 쓰지 않고 존재/헤더만 진단.'
  };
}

function CC02_checkStatusPolicy_(ss) {
  var candidates = [
    { sheetName: 'ERP_상태전이정책', headers: { fromStatus: ['fromStatus'], toStatus: ['toStatus'], roleCode: ['roleCode'], approvalRequired: ['approvalRequired'], status: ['status'], domain: ['domain'] } },
    { sheetName: 'HeaderPolicy', headers: { policyId: ['policyId'], sheetName: ['sheetName'], headerName: ['headerName'], protected: ['protected'], status: ['status', 'policyStatus'] } },
    { sheetName: 'SheetPolicy', headers: { policyId: ['policyId'], sheetName: ['sheetName'], protectionLevel: ['protectionLevel'], headerMapRequired: ['headerMapRequired'], status: ['status', 'policyStatus'] } }
  ];
  var checked = CC02_checkSheetCandidates_(ss, candidates);
  return {
    ok: checked.some(function (item) { return item.sheetName === 'ERP_상태전이정책' && item.exists && item.headersOk; }),
    checkedSheets: checked,
    lockedStatuses: ['ARCHIVE_COMPLETED', 'CONFIRMED', 'COMPLETED', 'LOCKED', 'CLOSED', 'ARCHIVED'],
    forbiddenPolicy: '상태값 자유입력 금지, 허용된 전이만 가능, 예외 전이/재오픈은 승인 기반.',
    actualTransitionBlocked: true
  };
}

function CC02_checkLockPolicy_(ss) {
  var candidates = [
    { sheetName: 'ERP_일반수정차단', headers: { status: ['status'], targetId: ['targetId', 'saleId', 'contractId', 'settlementId'], reason: ['reason', 'statusReason'], createdAt: ['createdAt'] } },
    { sheetName: 'ERP_정산마감잠금', headers: { settlementId: ['settlementId'], status: ['status'], lockedAt: ['lockedAt', 'createdAt'], lockedBy: ['lockedBy', 'createdBy'] } },
    { sheetName: 'ERP_아카이브최종보관', headers: { documentId: ['documentId'], status: ['status'], archiveStatus: ['archiveStatus'], createdAt: ['createdAt'] } },
    { sheetName: 'SIGN_Documents', headers: { documentId: ['documentId'], status: ['status'], archiveStatus: ['archiveStatus', 'driveArchiveStatus'], signStatus: ['signStatus'], pdfStatus: ['pdfStatus'] } },
    { sheetName: 'ERP_정산관리', headers: { settlementId: ['settlementId'], status: ['status', 'settlementStatus'], approvalId: ['approvalId'] } }
  ];
  var checked = CC02_checkSheetCandidates_(ss, candidates);
  return {
    ok: checked.some(function (item) { return item.exists && item.headersOk; }),
    checkedSheets: checked,
    editBlockedAfter: ['완료', '잠금', '종료', '확정', '보관완료'],
    actualUpdateDeleteBlocked: true,
    policy: '완료/잠금/종료/확정/보관완료 후 일반 수정 금지. CONTROL 02는 차단 기준만 진단.'
  };
}

function CC02_checkApprovalPolicy_(ss) {
  var candidates = [
    { sheetName: 'ApprovalLog', headers: { approvalId: ['approvalId'], approvalType: ['approvalType'], approvalStatus: ['approvalStatus'], requestedBy: ['requestedBy'], approvedBy: ['approvedBy'], createdAt: ['createdAt', 'requestedAt'] } },
    { sheetName: 'ERP_ApprovalRequests', headers: { approvalId: ['approvalId'], approvalType: ['approvalType'], approvalStatus: ['approvalStatus', 'status'], requestedBy: ['requestedBy'], approvedBy: ['approvedBy'] } },
    { sheetName: 'FORM_APPROVAL', headers: { approvalId: ['approvalId'], requestId: ['requestId'], approvalType: ['approvalType'], approvalStatus: ['approvalStatus'], requestedBy: ['requestedBy'], approvedBy: ['approvedBy'] } },
    { sheetName: 'SensitiveAccessRequests', headers: { requestId: ['requestId'], approvalId: ['approvalId'], status: ['status', 'approvalStatus'], requestedBy: ['requestedBy'] } },
    { sheetName: 'PermissionRequests', headers: { requestId: ['requestId'], approvalId: ['approvalId'], status: ['status', 'approvalStatus'], requestedBy: ['requestedBy'] } }
  ];
  var checked = CC02_checkSheetCandidates_(ss, candidates);
  return {
    ok: checked.some(function (item) { return item.exists && item.headersOk; }),
    checkedSheets: checked,
    approvalRequiredActions: ['민감권한', '정산수정', '취소정산', '환수', '추가지급', '구조변경', '잠금해제', '재오픈'],
    actualApprovalWriteBlocked: true,
    policy: '승인 필요한 작업 목록은 후보 진단만 수행. 실제 승인 기록 생성은 차단.'
  };
}

function CC02_checkSheetCandidates_(ss, candidates) {
  return candidates.map(function (candidate) {
    var sheet = ss.getSheetByName(candidate.sheetName);
    var headerMap = CC_headerMap_(sheet);
    var missing = [];
    var resolved = {};
    for (var logical in candidate.headers) {
      if (!candidate.headers.hasOwnProperty(logical)) continue;
      var aliases = candidate.headers[logical];
      var hit = CC02_firstHeaderHit_(headerMap, aliases);
      if (!hit) missing.push(logical + '(' + aliases.join('|') + ')');
      resolved[logical] = hit;
    }
    return {
      sheetName: candidate.sheetName,
      exists: !!sheet,
      rowCount: sheet ? CC_countRows_(sheet) : 0,
      headersOk: !!sheet && missing.length === 0,
      missingHeaders: missing,
      resolvedHeaders: resolved,
      roleCodeColumn: resolved.roleCode ? headerMap[resolved.roleCode] : -1,
      actualWriteBlocked: true,
      actualCreateBlocked: true,
      actualHeaderAddBlocked: true
    };
  });
}

function CC02_firstHeaderHit_(headerMap, aliases) {
  for (var i = 0; i < aliases.length; i++) {
    if (headerMap.hasOwnProperty(aliases[i])) return aliases[i];
  }
  return '';
}

function CC02_collectRoleCodes_(sheet, colIndex) {
  if (!sheet || colIndex < 1 || sheet.getLastRow() < 2) return [];
  var values = sheet.getRange(2, colIndex, sheet.getLastRow() - 1, 1).getValues();
  return values.map(function (row) { return String(row[0] || '').trim(); }).filter(function (v) { return !!v; });
}

function CC02_unique_(arr) {
  var seen = {};
  var out = [];
  arr.forEach(function (v) {
    if (!seen[v]) {
      seen[v] = true;
      out.push(v);
    }
  });
  return out;
}

function CC02_guidance_() {
  return {
    pageTitle: 'CONTROL 02 권한/감사로그/상태전이 진단',
    mainStatusText: 'roleCode 권한, 감사로그, 상태전이, 잠금 후 수정차단, 승인 게이트 기준을 점검합니다.',
    readonlyText: 'CONTROL 02는 조회/진단 전용이며 권한 변경, 상태변경, 로그쓰기, 승인기록 생성을 하지 않습니다.',
    successText: 'CONTROL 02 권한/감사로그/상태전이 진단을 통과했습니다.',
    emptyText: '진단 대상 정책 시트를 찾지 못했습니다. MASTER 연결과 정책 시트 구성을 확인해 주세요.',
    errorText: 'CONTROL 02 진단 중 문제가 발생했습니다. 권한/상태/감사로그/승인 정책 기준을 확인해 주세요.'
  };
}

function CC02_result_(summary, fatal, warnings, details) {
  return {
    ok: fatal.length === 0 && summary.ok === true,
    build: CC02_BUILD,
    checkedAt: CC_now_(),
    mode: CC02_MODE,
    fatal: fatal,
    warnings: warnings,
    summary: summary,
    details: details,
    nextAction: fatal.length === 0 && summary.ok === true ? 'CONTROL 02 통과. CONTROL 03 백업/배포/복구/롤백 게이트 진단으로 진행 가능.' : 'fatal/warnings 확인 후 권한, 감사로그, 상태전이, 승인 게이트 정책을 보정하세요.'
  };
}
