/**
 * CONTROL_ERP_CORE_DEPLOY_ALLOWED_GATE_SAFE_V2
 * Purpose: Validate and gate deployAllowed=true review for ERP_CORE.
 * This build DOES NOT execute actual deployment.
 */

const CONTROL_ERP_CORE_DEPLOY_ALLOWED_GATE_BUILD = 'CONTROL_ERP_CORE_DEPLOY_ALLOWED_GATE_SAFE_V2';
const CONTROL_ERP_CORE_DEPLOY_ALLOWED_APPROVAL_CODE = 'CONTROL_ERP_CORE_DEPLOY_ALLOWED_APPROVED_GATE_ONLY';

function ccedag_safety_() {
  return {
    build: CONTROL_ERP_CORE_DEPLOY_ALLOWED_GATE_BUILD,
    gateOnly: true,
    deployAllowedDefault: false,
    actualDeployExecution: false,
    noActualDeployExecution: true,
    noSheetCreate: true,
    noHeaderAutoAdd: true,
    noPolicyWrite: true,
    noDbInjection: true,
    noBusinessDataWrite: true,
    noCustomerSave: true,
    noSaleSave: true,
    noContractCreate: true,
    noInstallAsSave: true,
    noSettlementExecution: true,
    noCancelSettlementConfirm: true,
    noSignDocumentCreate: true,
    noFormAutoRegister: true,
    noRoleMutation: true,
    noDeleteSheet: true,
    noExistingDataClear: true,
    headerMapRequired: true,
    idBasedConnectionRequired: true,
    vendorBranchUserGroup: true,
    qrInitialEntryTargetSearchProtected: true,
    directRegularMemberLink: false,
    noOriginalSlipMutation: true,
    backupRollbackConfirmationRequired: true
  };
}

function ccedag_expected_() {
  return {
    sheetCount: 6,
    headerPolicyCount: 67,
    sheetPolicyCount: 6,
    requiredLogSheets: ['BackupLog', 'DeployLog', 'RecoveryLog'],
    requiredFinalGateBuild: 'CONTROL_ERP_CORE_DEPLOY_FINAL_GATE_BUNDLE_SAFE'
  };
}

function ccedag_dryRun(ctx) {
  return {
    ok: true,
    build: CONTROL_ERP_CORE_DEPLOY_ALLOWED_GATE_BUILD,
    mode: 'DRY_RUN_ONLY',
    message: 'deployAllowed 전환 게이트 계획만 확인합니다. 실제 배포 실행은 없습니다.',
    expected: ccedag_expected_(),
    fatal: [],
    warnings: [],
    safety: ccedag_safety_(),
    ctx: ctx || {}
  };
}

function ccedag_checkGatePrerequisites_(ctx) {
  const fatal = [];
  const warnings = [];

  // V2: connect to the actual final-gate bundle function name used by
  // CONTROL_ERP_CORE_DEPLOY_FINAL_GATE_BUNDLE_SAFE.
  let finalGate = null;
  try {
    if (typeof controlErpCoreDeployFinalGateBundle_runAllReadOnly === 'function') {
      finalGate = controlErpCoreDeployFinalGateBundle_runAllReadOnly({ from: CONTROL_ERP_CORE_DEPLOY_ALLOWED_GATE_BUILD });
    } else if (typeof ccepdg_allReadOnlyBundle === 'function') {
      // Backward-compatible alias if a prior build exposes it.
      finalGate = ccepdg_allReadOnlyBundle({ from: CONTROL_ERP_CORE_DEPLOY_ALLOWED_GATE_BUILD });
    } else if (typeof runStep7_ControlDeployFinalGateAllReadOnly === 'function') {
      // Runner returns result in the current runner build, so use it when the internal function is unavailable.
      finalGate = runStep7_ControlDeployFinalGateAllReadOnly();
    } else {
      fatal.push('CONTROL 최종 게이트 전체 점검 함수를 찾을 수 없습니다: controlErpCoreDeployFinalGateBundle_runAllReadOnly');
    }
  } catch (err) {
    fatal.push('CONTROL 최종 게이트 재점검 실패: ' + (err && err.message ? err.message : err));
  }

  if (finalGate && finalGate.ok !== true) {
    fatal.push('CONTROL 최종 게이트 결과가 PASS가 아닙니다.');
  }
  if (finalGate && finalGate.warnings && finalGate.warnings.length) {
    warnings.push.apply(warnings, finalGate.warnings);
  }

  const logSheets = ccedag_checkRequiredLogSheets_();
  if (!logSheets.ok) fatal.push('BackupLog / DeployLog / RecoveryLog 확인 실패');

  return {
    ok: fatal.length === 0,
    build: CONTROL_ERP_CORE_DEPLOY_ALLOWED_GATE_BUILD,
    checkedAt: new Date().toISOString(),
    fatal: fatal,
    warnings: warnings,
    finalGate: finalGate,
    logSheets: logSheets,
    expected: ccedag_expected_(),
    safety: ccedag_safety_()
  };
}

function ccedag_checkRequiredLogSheets_() {
  const names = ccedag_expected_().requiredLogSheets;
  const result = { ok: true, sheets: [], fatal: [] };
  let ss = null;

  try {
    ss = ccedag_openMaster_();
  } catch (err) {
    result.ok = false;
    result.fatal.push('MASTER 열기 실패: ' + (err && err.message ? err.message : err));
    return result;
  }

  names.forEach(function(name) {
    const exists = !!ss.getSheetByName(name);
    result.sheets.push({ sheetName: name, exists: exists, mode: 'READ_ONLY_CHECK' });
    if (!exists) {
      result.ok = false;
      result.fatal.push(name + ' 시트가 없습니다.');
    }
  });
  return result;
}

function ccedag_openMaster_() {
  // Try project-provided helpers first.
  if (typeof ccef_getMasterSpreadsheet === 'function') {
    const ss = ccef_getMasterSpreadsheet();
    if (ss && typeof ss.getSheetByName === 'function') return ss;
  }
  if (typeof cce3_getMasterSpreadsheet === 'function') {
    const ss2 = cce3_getMasterSpreadsheet();
    if (ss2 && typeof ss2.getSheetByName === 'function') return ss2;
  }

  // Safe SystemConfig fallback: read setup DB, then master id from key/value.
  const setupDbId = '17VMSpgSZCvIrUlgcw8yCNcnl8WQWo2IcRf5tDCcuJGM';
  const setup = SpreadsheetApp.openById(setupDbId);
  const sh = setup.getSheetByName('SystemConfig');
  if (!sh) throw new Error('SystemConfig 시트를 찾을 수 없습니다.');
  const values = sh.getDataRange().getValues();
  if (!values || values.length < 2) throw new Error('SystemConfig 데이터가 비어 있습니다.');
  const headers = values[0].map(String);
  const keyIdx = headers.indexOf('CONFIG_KEY') >= 0 ? headers.indexOf('CONFIG_KEY') : headers.indexOf('key');
  const valIdx = headers.indexOf('VALUE') >= 0 ? headers.indexOf('VALUE') : headers.indexOf('value');
  if (keyIdx < 0 || valIdx < 0) throw new Error('SystemConfig CONFIG_KEY/VALUE 헤더를 찾을 수 없습니다.');
  const cfg = {};
  for (let i = 1; i < values.length; i++) {
    const k = String(values[i][keyIdx] || '').trim();
    const v = String(values[i][valIdx] || '').trim();
    if (k) cfg[k] = v;
  }
  const masterId = String(cfg.FEELHAUS_DB_MASTER_ID || cfg.DB_MASTER_ID || cfg.SPREADSHEET_ID || '').trim();
  if (!masterId) throw new Error('FEELHAUS_DB_MASTER_ID / DB_MASTER_ID / SPREADSHEET_ID 설정이 없습니다.');
  return SpreadsheetApp.openById(masterId);
}

function ccedag_execute(ctx) {
  ctx = ctx || {};
  const required = {
    deployAllowedConfirm: true,
    approvalCode: CONTROL_ERP_CORE_DEPLOY_ALLOWED_APPROVAL_CODE,
    actualDeployExecution: false,
    businessDataWriteAllowed: false
  };

  if (ctx.deployAllowedConfirm !== true) {
    return ccedag_blocked_('deployAllowedConfirm=true 승인이 없습니다.', required);
  }
  if (ctx.approvalCode !== CONTROL_ERP_CORE_DEPLOY_ALLOWED_APPROVAL_CODE) {
    return ccedag_blocked_('승인코드가 일치하지 않습니다.', required);
  }
  if (ctx.actualDeployExecution !== false) {
    return ccedag_blocked_('actualDeployExecution=false 상태만 허용합니다.', required);
  }
  if (ctx.businessDataWriteAllowed !== false) {
    return ccedag_blocked_('businessDataWriteAllowed=false 상태만 허용합니다.', required);
  }

  const prereq = ccedag_checkGatePrerequisites_(ctx);
  if (!prereq.ok) {
    return {
      ok: false,
      blocked: true,
      build: CONTROL_ERP_CORE_DEPLOY_ALLOWED_GATE_BUILD,
      action: 'DEPLOY_ALLOWED_GATE_ONLY',
      reason: 'deployAllowed 전환 전제조건 미충족',
      prerequisites: prereq,
      deployAllowedReviewReady: false,
      deployAllowed: false,
      actualDeployExecution: false,
      businessDataWrite: false,
      safety: ccedag_safety_()
    };
  }

  return {
    ok: true,
    build: CONTROL_ERP_CORE_DEPLOY_ALLOWED_GATE_BUILD,
    action: 'DEPLOY_ALLOWED_GATE_ONLY',
    message: 'deployAllowed=true 전환 검토 조건을 통과했습니다. 실제 배포 실행은 하지 않았습니다.',
    deployAllowedReviewReady: true,
    deployAllowed: true,
    actualDeployExecution: false,
    businessDataWrite: false,
    prerequisites: prereq,
    nextRequired: [
      'CONTROL_ERP_CORE_ACTUAL_DEPLOY_APPROVAL_SAFE',
      'actualDeployExecution 승인코드 별도 확인',
      '운영 URL/버전 전환 전 최종 백업 실행 확인'
    ],
    fatal: [],
    warnings: prereq.warnings || [],
    safety: ccedag_safety_()
  };
}

function ccedag_blocked_(reason, required) {
  return {
    ok: false,
    blocked: true,
    build: CONTROL_ERP_CORE_DEPLOY_ALLOWED_GATE_BUILD,
    action: 'DEPLOY_ALLOWED_GATE_ONLY',
    reason: reason,
    required: required,
    deployAllowedReviewReady: false,
    deployAllowed: false,
    actualDeployExecution: false,
    businessDataWrite: false,
    safety: ccedag_safety_()
  };
}

function ccedag_selfTest() {
  return {
    ok: true,
    build: CONTROL_ERP_CORE_DEPLOY_ALLOWED_GATE_BUILD,
    fatal: [],
    warnings: [],
    expected: ccedag_expected_(),
    approvalCode: CONTROL_ERP_CORE_DEPLOY_ALLOWED_APPROVAL_CODE,
    safety: ccedag_safety_()
  };
}
