/**
 * FEELHAUS CONTROL - PORTAL EVENT B50 FIELD OPEN DECISION GATE
 * Build: CONTROL_PORTAL_EVENT_B50_FIELD_OPEN_DECISION_V01
 * Target baseline: PORTAL_EVENT_B50_FINAL_STABLE_READONLY_20260611
 * Execution function: runControlPortalEventB50FieldOpenDecisionV01
 *
 * Safety:
 * - Diagnostic only
 * - No sheet creation
 * - No header mutation
 * - No log writing
 * - No approval writing
 * - No backup/deploy/recovery/rollback execution
 * - No PORTAL operation save
 * - No ERP apply
 * - No field open execution
 */
var CC10_BUILD = 'CONTROL_PORTAL_EVENT_B50_FIELD_OPEN_DECISION_V01';
var CC10_MODE = 'PORTAL_EVENT_B50_FIELD_OPEN_DECISION_DIAGNOSTIC_ONLY_NO_UPDATE';
var CC10_TARGET = {
  projectCode: 'PORTAL_EVENT',
  moduleCode: 'PORTAL_EVENT_MANAGEMENT',
  buildNo: 'PORTAL_EVENT_B50_FINAL_STABLE_READONLY_20260611',
  buildProgress: '50 / 50',
  progressPercent: 100,
  runFunction: 'portalEventB50RunAll',
  changedOnlyFile: 'PORTAL_EVENT_B50_CHANGED_ONLY.zip',
  requiredDeployAllowedBuild: 'CONTROL_PORTAL_EVENT_B50_DEPLOY_ALLOWED_GATE_V01',
  actualExecutionForbiddenInThisGate: true
};

function runControlPortalEventB50FieldOpenDecisionV01() {
  var result = diagnoseControlPortalEventB50FieldOpenDecisionV01_();
  CC10_logCompactResult_(result);
  return result;
}

function runPortalEventB50FieldOpenDecisionV01() {
  var result = diagnoseControlPortalEventB50FieldOpenDecisionV01_();
  CC10_logCompactResult_(result);
  return result;
}

function getControlPortalEventB50FieldOpenDecisionData() {
  var result = diagnoseControlPortalEventB50FieldOpenDecisionV01_();
  CC10_logCompactResult_(result);
  return result;
}

function controlPortalEventB50FieldOpenDecisionV01() {
  var result = diagnoseControlPortalEventB50FieldOpenDecisionV01_();
  CC10_logCompactResult_(result);
  return result;
}

function CC10_logCompactResult_(result) {
  Logger.log('JSON_COMPACT_RESULT: ' + JSON.stringify(CC10_compactResult_(result)));
}

function CC10_compactResult_(result) {
  result = result || {};
  var summary = result.summary || {};
  var details = result.details || {};
  var schema = details.schema || {};
  var deployGate = details.deployAllowedGate || {};
  var operationBlock = details.operationBlock || {};
  return {
    ok: result.ok === true,
    build: result.build || CC10_BUILD,
    mode: result.mode || CC10_MODE,
    checkedAt: result.checkedAt || '',
    judgement: result.judgement || summary.judgement || 'BLOCK',
    targetBaseline: {
      projectCode: CC10_TARGET.projectCode,
      moduleCode: CC10_TARGET.moduleCode,
      buildNo: CC10_TARGET.buildNo,
      buildProgress: CC10_TARGET.buildProgress,
      progressPercent: CC10_TARGET.progressPercent,
      runFunction: CC10_TARGET.runFunction,
      changedOnlyFile: CC10_TARGET.changedOnlyFile
    },
    summary: {
      baselineOk: summary.baselineOk === true,
      configOk: summary.configOk === true,
      masterOk: summary.masterOk === true,
      requiredGateSheetsOk: summary.requiredGateSheetsOk === true,
      requiredGateHeadersOk: summary.requiredGateHeadersOk === true,
      deployAllowedGatePassed: summary.deployAllowedGatePassed === true,
      deployReadinessOk: summary.deployReadinessOk === true,
      deployAllowed: summary.deployAllowed === true,
      fieldOpenReadinessOk: summary.fieldOpenReadinessOk === true,
      fieldOpenDecisionOk: summary.fieldOpenDecisionOk === true,
      fieldOpenAllowed: summary.fieldOpenAllowed === true,
      actualExecutionBlocked: summary.actualExecutionBlocked !== false,
      actualDeployAllowed: summary.actualDeployAllowed === true,
      actualPortalSaveAllowed: summary.actualPortalSaveAllowed === true,
      actualErpApplyAllowed: summary.actualErpApplyAllowed === true,
      actualFieldOpenAllowed: summary.actualFieldOpenAllowed === true,
      operationSaveBlocked: summary.operationSaveBlocked !== false,
      erpApplyBlocked: summary.erpApplyBlocked !== false,
      fieldOpenBlocked: summary.fieldOpenBlocked !== false,
      diagnosticOnly: summary.diagnosticOnly === true,
      dryRunOnly: summary.dryRunOnly === true,
      sheetWriteExecuted: summary.sheetWriteExecuted === true,
      sheetCreateExecuted: summary.sheetCreateExecuted === true,
      headerAutoAddExecuted: summary.headerAutoAddExecuted === true,
      approvalWriteExecuted: summary.approvalWriteExecuted === true,
      auditLogWriteExecuted: summary.auditLogWriteExecuted === true,
      backupExecuted: summary.backupExecuted === true,
      deployExecuted: summary.deployExecuted === true,
      recoveryExecuted: summary.recoveryExecuted === true,
      rollbackExecuted: summary.rollbackExecuted === true,
      erpApplyExecuted: summary.erpApplyExecuted === true,
      actualOpenExecuted: summary.actualOpenExecuted === true,
      productionDataMutationExecuted: summary.productionDataMutationExecuted === true
    },
    evidence: {
      missingSheets: schema.missingSheets || [],
      totalMissingHeaders: schema.totalMissingHeaders || 0,
      deployAllowedBuild: deployGate.build || '',
      deployAllowedJudgement: deployGate.judgement || '',
      deployAllowedGatePassed: deployGate.ok === true,
      deployGateDeployAllowed: deployGate.deployAllowed === true,
      deployGateActualDeployAllowed: deployGate.actualDeployAllowed === true,
      readinessReason: details.readinessReason || '',
      decisionReason: details.decisionReason || '',
      actualBackupAllowed: operationBlock.actualBackupAllowed === true,
      actualDeployAllowed: operationBlock.actualDeployAllowed === true,
      actualRecoveryAllowed: operationBlock.actualRecoveryAllowed === true,
      actualRollbackAllowed: operationBlock.actualRollbackAllowed === true,
      actualPortalSaveAllowed: operationBlock.actualPortalSaveAllowed === true,
      actualErpApplyAllowed: operationBlock.actualErpApplyAllowed === true,
      actualFieldOpenAllowed: operationBlock.actualFieldOpenAllowed === true
    },
    warnings: result.warnings || [],
    hold: result.hold || [],
    fatal: result.fatal || [],
    nextAction: result.nextAction || ''
  };
}

function diagnoseControlPortalEventB50FieldOpenDecisionV01_() {
  var fatal = [];
  var warnings = [];
  var hold = [];
  var details = {
    build: CC10_BUILD,
    mode: CC10_MODE,
    checkedAt: (typeof CC_now_ === 'function') ? CC_now_() : new Date().toISOString(),
    sourceDb: (typeof CC_SOURCE_DB !== 'undefined') ? CC_SOURCE_DB : 'FEELHAUS_SETUP_DB',
    setupDbId: (typeof CC_SETUP_DB_ID !== 'undefined') ? CC_SETUP_DB_ID : '17VMSpgSZCvIrUlgcw8yCNcnl8WQWo2IcRf5tDCcuJGM',
    configSheetName: (typeof CC_CONFIG_SHEET_NAME !== 'undefined') ? CC_CONFIG_SHEET_NAME : 'SystemConfig',
    targetBaseline: CC10_TARGET,
    safety: CC10_safety_(),
    config: null,
    master: null,
    schema: null,
    deployAllowedGate: null,
    operationBlock: null,
    readinessReason: '',
    decisionReason: ''
  };
  var summary = CC10_baseSummary_();

  try {
    var cfgResult = (typeof CC_readSystemConfig_ === 'function') ? CC_readSystemConfig_() : null;
    summary.configOk = !!(cfgResult && cfgResult.ok);
    details.config = {
      ok: summary.configOk,
      message: cfgResult && cfgResult.message ? cfgResult.message : '',
      sourceDb: details.sourceDb,
      setupDbId: details.setupDbId,
      configSheetName: details.configSheetName
    };
    if (!summary.configOk) fatal.push('SystemConfig 자동 읽기 실패');

    var config = cfgResult && cfgResult.config ? cfgResult.config : {};
    var masterId = (typeof CC_resolveMasterDbId_ === 'function') ? CC_resolveMasterDbId_(config) : '';
    if (!masterId) {
      summary.masterOk = false;
      fatal.push('FEELHAUS_DB_MASTER ID를 SystemConfig에서 찾지 못했습니다.');
      return CC10_result_(summary, fatal, warnings, hold, details);
    }
    var masterSs = SpreadsheetApp.openById(masterId);
    summary.masterOk = !!masterSs;
    details.master = {
      ok: summary.masterOk,
      masterDbId: masterId,
      masterDbName: masterSs ? masterSs.getName() : ''
    };
    if (!summary.masterOk) fatal.push('FEELHAUS_DB_MASTER 연결 실패');

    details.schema = (typeof CC09_checkGateSchemas_ === 'function') ? CC09_checkGateSchemas_(masterSs) : CC10_emptySchema_();
    summary.requiredGateSheetsOk = details.schema.ok && details.schema.missingSheets.length === 0;
    summary.requiredGateHeadersOk = details.schema.totalMissingHeaders === 0;
    if (!summary.requiredGateSheetsOk) fatal.push('현장 오픈 결정 게이트 필수 로그 시트 누락: ' + details.schema.missingSheets.join(', '));
    if (!summary.requiredGateHeadersOk) fatal.push('현장 오픈 결정 게이트 필수 헤더 누락 합계: ' + details.schema.totalMissingHeaders);

    details.deployAllowedGate = CC10_checkDeployAllowedGatePass_();
    summary.deployAllowedGatePassed = details.deployAllowedGate.ok === true;
    summary.deployReadinessOk = details.deployAllowedGate.deployReadinessOk === true;
    summary.deployAllowed = details.deployAllowedGate.deployAllowed === true;
    if (!summary.deployAllowedGatePassed) hold.push('PORTAL_EVENT_B50 배포 허용 최종 게이트 PASS 결과가 확인되지 않았습니다.');
    if (!summary.deployAllowed) hold.push('PORTAL_EVENT_B50 deployAllowed=true 상태가 확인되지 않았습니다.');

    details.operationBlock = CC10_checkOperationBlock_();
    summary.actualExecutionBlocked = details.operationBlock.actualExecutionBlocked !== false;
    summary.actualDeployAllowed = details.operationBlock.actualDeployAllowed === true;
    summary.actualPortalSaveAllowed = details.operationBlock.actualPortalSaveAllowed === true;
    summary.actualErpApplyAllowed = details.operationBlock.actualErpApplyAllowed === true;
    summary.actualFieldOpenAllowed = details.operationBlock.actualFieldOpenAllowed === true;
    summary.operationSaveBlocked = details.operationBlock.actualPortalSaveAllowed !== true;
    summary.erpApplyBlocked = details.operationBlock.actualErpApplyAllowed !== true;
    summary.fieldOpenBlocked = details.operationBlock.actualFieldOpenAllowed !== true;
    if (!summary.actualExecutionBlocked || summary.actualDeployAllowed || summary.actualPortalSaveAllowed || summary.actualErpApplyAllowed || summary.actualFieldOpenAllowed) {
      fatal.push('현장 오픈 결정 게이트에서 실제 운영 실행 차단 기준이 깨졌습니다.');
    }

    summary.baselineOk = CC10_checkBaseline_().ok;
    if (!summary.baselineOk) fatal.push('PORTAL_EVENT_B50 기준선 값 불일치');

    summary.fieldOpenReadinessOk = fatal.length === 0 && hold.length === 0 &&
      summary.baselineOk && summary.configOk && summary.masterOk &&
      summary.requiredGateSheetsOk && summary.requiredGateHeadersOk &&
      summary.deployAllowedGatePassed && summary.deployReadinessOk && summary.deployAllowed &&
      summary.actualExecutionBlocked && summary.operationSaveBlocked && summary.erpApplyBlocked && summary.fieldOpenBlocked;
    summary.fieldOpenDecisionOk = summary.fieldOpenReadinessOk === true;
    summary.fieldOpenAllowed = summary.fieldOpenDecisionOk === true;
    details.readinessReason = summary.fieldOpenReadinessOk ?
      '배포 허용 최종 게이트 PASS + deployAllowed=true + 실제 실행 차단 유지가 모두 확인되어 현장 오픈 결정 후보 상태입니다.' :
      '현장 오픈 결정 조건 중 미충족 항목이 있어 HOLD 또는 BLOCK 상태입니다.';
    details.decisionReason = summary.fieldOpenDecisionOk ?
      'PORTAL_EVENT_B50은 현장 오픈 결정 게이트 PASS입니다. 단, 이 게이트는 실제 운영 저장/ERP 반영/현장 오픈을 실행하지 않습니다.' :
      'PORTAL_EVENT_B50 현장 오픈 결정 게이트 미통과입니다. 미충족 항목을 보완해야 합니다.';

    return CC10_result_(summary, fatal, warnings, hold, details);
  } catch (err) {
    fatal.push(String(err && err.message ? err.message : err));
    return CC10_result_(summary, fatal, warnings, hold, details);
  }
}

function CC10_baseSummary_() {
  return {
    ok: false,
    judgement: 'BLOCK',
    baselineOk: false,
    configOk: false,
    masterOk: false,
    requiredGateSheetsOk: false,
    requiredGateHeadersOk: false,
    deployAllowedGatePassed: false,
    deployReadinessOk: false,
    deployAllowed: false,
    fieldOpenReadinessOk: false,
    fieldOpenDecisionOk: false,
    fieldOpenAllowed: false,
    actualExecutionBlocked: true,
    actualDeployAllowed: false,
    actualPortalSaveAllowed: false,
    actualErpApplyAllowed: false,
    actualFieldOpenAllowed: false,
    operationSaveBlocked: true,
    erpApplyBlocked: true,
    fieldOpenBlocked: true,
    diagnosticOnly: true,
    dryRunOnly: true,
    sheetWriteExecuted: false,
    sheetCreateExecuted: false,
    headerAutoAddExecuted: false,
    approvalWriteExecuted: false,
    auditLogWriteExecuted: false,
    backupExecuted: false,
    deployExecuted: false,
    recoveryExecuted: false,
    rollbackExecuted: false,
    erpApplyExecuted: false,
    actualOpenExecuted: false,
    productionDataMutationExecuted: false
  };
}

function CC10_safety_() {
  return {
    diagnosticOnly: true,
    dryRunOnly: true,
    actualExecutionBlocked: true,
    noSheetWrite: true,
    noSheetCreate: true,
    noHeaderAutoAdd: true,
    noApprovalWrite: true,
    noAuditLogWrite: true,
    noBackupExecution: true,
    noDeployExecution: true,
    noRecoveryExecution: true,
    noRollbackExecution: true,
    noPortalOperationSave: true,
    noErpApply: true,
    noFieldOpenExecution: true
  };
}

function CC10_checkBaseline_() {
  var b = CC10_TARGET;
  return {
    ok: b.projectCode === 'PORTAL_EVENT' &&
      b.moduleCode === 'PORTAL_EVENT_MANAGEMENT' &&
      b.buildNo === 'PORTAL_EVENT_B50_FINAL_STABLE_READONLY_20260611' &&
      b.progressPercent === 100 &&
      b.runFunction === 'portalEventB50RunAll' &&
      b.changedOnlyFile === 'PORTAL_EVENT_B50_CHANGED_ONLY.zip',
    targetBaseline: b,
    actualWriteExecuted: false
  };
}

function CC10_checkDeployAllowedGatePass_() {
  var compact = null;
  var full = null;
  if (typeof diagnoseControlPortalEventB50DeployAllowedGateV01_ === 'function') {
    full = diagnoseControlPortalEventB50DeployAllowedGateV01_();
    if (typeof CC09_compactResult_ === 'function') compact = CC09_compactResult_(full);
  }
  compact = compact || {};
  var summary = compact.summary || {};
  return {
    ok: compact.judgement === 'PASS' && summary.deployReadinessOk === true && summary.deployAllowed === true,
    build: compact.build || '',
    judgement: compact.judgement || '',
    deployReadinessOk: summary.deployReadinessOk === true,
    deployAllowed: summary.deployAllowed === true,
    actualExecutionBlocked: summary.actualExecutionBlocked !== false,
    actualDeployAllowed: summary.actualDeployAllowed === true,
    fatal: compact.fatal || [],
    hold: compact.hold || [],
    actualWriteExecuted: false
  };
}

function CC10_checkOperationBlock_() {
  return {
    actualExecutionBlocked: true,
    actualBackupAllowed: false,
    actualDeployAllowed: false,
    actualRecoveryAllowed: false,
    actualRollbackAllowed: false,
    actualPortalSaveAllowed: false,
    actualErpApplyAllowed: false,
    actualFieldOpenAllowed: false,
    sheetWriteExecuted: false,
    sheetCreateExecuted: false,
    headerAutoAddExecuted: false,
    approvalWriteExecuted: false,
    auditLogWriteExecuted: false,
    backupExecuted: false,
    deployExecuted: false,
    recoveryExecuted: false,
    rollbackExecuted: false,
    erpApplyExecuted: false,
    actualOpenExecuted: false,
    productionDataMutationExecuted: false
  };
}

function CC10_emptySchema_() {
  return {
    ok: true,
    missingSheets: [],
    totalMissingHeaders: 0,
    sheets: [],
    actualCreateBlocked: true,
    actualHeaderAddBlocked: true,
    actualWriteBlocked: true
  };
}

function CC10_result_(summary, fatal, warnings, hold, details) {
  var judgement = 'BLOCK';
  if (fatal.length === 0 && hold.length === 0 && summary.fieldOpenDecisionOk === true) judgement = 'PASS';
  else if (fatal.length === 0) judgement = 'HOLD';
  summary.ok = fatal.length === 0;
  summary.judgement = judgement;
  summary.diagnosticOnly = true;
  summary.dryRunOnly = true;
  summary.actualExecutionBlocked = true;
  summary.actualDeployAllowed = false;
  summary.actualPortalSaveAllowed = false;
  summary.actualErpApplyAllowed = false;
  summary.actualFieldOpenAllowed = false;
  summary.operationSaveBlocked = true;
  summary.erpApplyBlocked = true;
  summary.fieldOpenBlocked = true;
  summary.sheetWriteExecuted = false;
  summary.sheetCreateExecuted = false;
  summary.headerAutoAddExecuted = false;
  summary.approvalWriteExecuted = false;
  summary.auditLogWriteExecuted = false;
  summary.backupExecuted = false;
  summary.deployExecuted = false;
  summary.recoveryExecuted = false;
  summary.rollbackExecuted = false;
  summary.erpApplyExecuted = false;
  summary.actualOpenExecuted = false;
  summary.productionDataMutationExecuted = false;
  return {
    ok: fatal.length === 0,
    build: CC10_BUILD,
    mode: CC10_MODE,
    checkedAt: details.checkedAt || ((typeof CC_now_ === 'function') ? CC_now_() : new Date().toISOString()),
    judgement: judgement,
    targetBaseline: CC10_TARGET,
    summary: summary,
    details: details,
    warnings: warnings,
    hold: hold,
    fatal: fatal,
    nextAction: CC10_nextAction_(judgement)
  };
}

function CC10_nextAction_(judgement) {
  if (judgement === 'PASS') {
    return 'PORTAL_EVENT_B50 현장 오픈 결정 게이트 PASS. 단, 이 게이트는 실제 운영 저장/ERP 반영/현장 오픈을 실행하지 않았습니다.';
  }
  if (judgement === 'HOLD') {
    return 'PORTAL_EVENT_B50 현장 오픈 결정 게이트 HOLD. 배포 허용 최종 게이트 PASS 및 실행 차단 상태를 확인하세요.';
  }
  return 'PORTAL_EVENT_B50 현장 오픈 결정 게이트 BLOCK. SystemConfig/MASTER/로그 구조 또는 실행 차단 오류를 먼저 복구하세요.';
}
