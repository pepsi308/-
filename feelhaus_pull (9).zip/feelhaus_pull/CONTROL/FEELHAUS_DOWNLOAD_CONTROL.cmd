@echo off
setlocal EnableExtensions
title FEELHAUS DOWNLOAD CONTROL

if not exist "D:\pepsi308\OneDrive\feelhaus_pull\CONTROL" mkdir "D:\pepsi308\OneDrive\feelhaus_pull\CONTROL"
cd /d D:\pepsi308\OneDrive\feelhaus_pull\CONTROL

if exist ".clasp.json" (
  echo [CONTROL] clasp pull
  clasp.cmd pull
) else (
  echo [CONTROL] clasp clone
  clasp.cmd clone 1gORhotjFZvH-m7GYh5gcU1KZy2M3cxh0y9Q8zMTOvDF2fDQ2zqAktLId
)

pause
