/**
 * FEELHAUS CONTROL - GROUPWARE B90 BACKUP / ROLLBACK EVIDENCE GATE
 * Build: CONTROL_GROUPWARE_B90_BACKUP_ROLLBACK_EVIDENCE_V01
 * Progress: [03/10] 30%
 * Target baseline: GROUPWARE_B90_FINAL_STABLE_AFTER_B70_B90_RUNALL
 * Execution function: runControlGroupwareB90BackupRollbackEvidenceGateV01
 *
 * Safety:
 * - Diagnostic only
 * - Drive read/list only
 * - No file creation
 * - No sheet creation
 * - No header mutation
 * - No approval writing
 * - No audit log writing
 * - No backup/deploy/recovery/rollback execution
 * - No GROUPWARE production save
 * - No field open execution
 * - No real apply execution
 */
var CC16_BUILD = 'CONTROL_GROUPWARE_B90_BACKUP_ROLLBACK_EVIDENCE_V01';
var CC16_MODE = 'GROUPWARE_B90_BACKUP_ROLLBACK_EVIDENCE_DIAGNOSTIC_ONLY_NO_UPDATE';
var CC16_PROGRESS = { current: 3, total: 10, percent: 30 };
var CC16_SETUP_DB_ID = '17VMSpgSZCvIrUlgcw8yCNcnl8WQWo2IcRf5tDCcuJGM';
var CC16_CONFIG_SHEET_NAME = 'SystemConfig';
var CC16_SOURCE_DB = 'FEELHAUS_SETUP_DB';
var CC16_TARGET = {
  projectCode: 'GROUPWARE',
  moduleCode: 'GROUPWARE_PORTAL_HR_MAIL_CALENDAR',
  buildRange: 'B70~B90',
  currentBuildNo: 'B90',
  finalBuildNo: 'B90',
  buildProgress: '90 / 90',
  progressPercent: 100,
  runAllStatus: 'GROUPWARE_B70_TO_B90_RUNALL_PASS',
  protectedBaseline: 'B70~B89',
  finalStableName: 'GROUPWARE_B90_FINAL_STABLE',
  preDeployGateBuild: 'CONTROL_GROUPWARE_B90_PREDEPLOY_GATE_V01',
  suggestedBackupFile: 'BACKUP_GROUPWARE_B90_FINAL_STABLE_20260611.zip',
  suggestedRollbackFile: 'ROLLBACK_BASELINE_GROUPWARE_B90_BEFORE_APPLY_20260611.zip'
};

function runControlGroupwareB90BackupRollbackEvidenceGateV01() {
  var result = diagnoseControlGroupwareB90BackupRollbackEvidenceGateV01_();
  CC16_logCompactResult_(result);
  return result;
}

function runGroupwareB90BackupRollbackEvidenceGateV01() {
  var result = diagnoseControlGroupwareB90BackupRollbackEvidenceGateV01_();
  CC16_logCompactResult_(result);
  return result;
}

function getControlGroupwareB90BackupRollbackEvidenceGateData() {
  var result = diagnoseControlGroupwareB90BackupRollbackEvidenceGateV01_();
  CC16_logCompactResult_(result);
  return result;
}

function controlGroupwareB90BackupRollbackEvidenceGateV01() {
  var result = diagnoseControlGroupwareB90BackupRollbackEvidenceGateV01_();
  CC16_logCompactResult_(result);
  return result;
}

function diagnoseControlGroupwareB90BackupRollbackEvidenceGateV01_() {
  var started = new Date();
  var fatal = [];
  var hold = [];
  var warnings = [];
  var details = {};
  var summary = CC16_defaultSummary_();

  try {
    details.setup = CC16_readSystemConfig_();
    summary.configOk = details.setup.ok === true;
    summary.systemConfigAutoReadOk = details.setup.ok === true;
  } catch (e1) {
    fatal.push('SystemConfig 자동 읽기 실패: ' + CC16_errorMessage_(e1));
    details.setup = { ok: false, error: CC16_errorMessage_(e1), config: {} };
  }

  try {
    var cfg = details.setup && details.setup.config ? details.setup.config : {};
    details.master = CC16_openMasterDb_(cfg);
    summary.masterOk = details.master.ok === true;
    summary.masterConnectedOk = details.master.ok === true;
  } catch (e2) {
    fatal.push('FEELHAUS_DB_MASTER 연결 실패: ' + CC16_errorMessage_(e2));
    details.master = { ok: false, error: CC16_errorMessage_(e2) };
  }

  details.preDeployGate = CC16_checkPreDeployGate_();
  summary.preDeployGatePassed = details.preDeployGate.passed === true;
  summary.preDeployDiagnosticOk = details.preDeployGate.preDeployDiagnosticOk === true;

  try {
    details.folderScan = CC16_scanBackupFolders_(details.setup && details.setup.config || {});
    summary.backupFolderReadableOk = details.folderScan.readableFolderCount > 0;
    summary.rollbackFolderReadableOk = details.folderScan.readableFolderCount > 0;
    summary.backupEvidenceOk = details.folderScan.backupEvidenceFileCount > 0;
    summary.rollbackEvidenceOk = details.folderScan.rollbackBaselineFileCount > 0;
    summary.backupRollbackEvidenceOk = summary.backupEvidenceOk && summary.rollbackEvidenceOk;
  } catch (e3) {
    fatal.push('백업/롤백 Drive 증빙 스캔 실패: ' + CC16_errorMessage_(e3));
    details.folderScan = { ok: false, error: CC16_errorMessage_(e3) };
  }

  details.operationBlock = CC16_operationBlock_();
  summary.actualExecutionBlocked = true;
  summary.diagnosticOnly = true;
  summary.dryRunOnly = true;

  if (!summary.preDeployGatePassed) hold.push('[02/10] CONTROL_GROUPWARE_B90_PREDEPLOY_GATE_V01 PASS 확인 필요');
  if (!summary.backupFolderReadableOk) hold.push('SystemConfig에서 GROUPWARE 백업 폴더 ID 확인 필요');
  if (!summary.backupEvidenceOk) hold.push('GROUPWARE B90 백업 zip 증빙 파일 업로드 필요: ' + CC16_TARGET.suggestedBackupFile);
  if (!summary.rollbackEvidenceOk) hold.push('GROUPWARE B90 롤백 baseline zip 증빙 파일 업로드 필요: ' + CC16_TARGET.suggestedRollbackFile);

  var passConditions = [
    summary.configOk,
    summary.masterOk,
    summary.preDeployGatePassed,
    summary.preDeployDiagnosticOk,
    summary.backupFolderReadableOk,
    summary.rollbackFolderReadableOk,
    summary.backupEvidenceOk,
    summary.rollbackEvidenceOk,
    summary.backupRollbackEvidenceOk,
    summary.actualExecutionBlocked
  ];

  var allPass = fatal.length === 0 && hold.length === 0 && CC16_allTrue_(passConditions);
  var judgement = fatal.length > 0 ? 'BLOCK' : (allPass ? 'PASS' : 'HOLD');
  summary.backupRollbackGateOk = judgement === 'PASS';
  summary.judgement = judgement;

  return {
    ok: judgement === 'PASS',
    build: CC16_BUILD,
    progress: CC16_PROGRESS,
    mode: CC16_MODE,
    checkedAt: CC16_now_(),
    judgement: judgement,
    targetBaseline: CC16_TARGET,
    summary: summary,
    evidence: {
      setupDbId: CC16_SETUP_DB_ID,
      configSheetName: CC16_CONFIG_SHEET_NAME,
      sourceDb: CC16_SOURCE_DB,
      setupDbName: details.setup && details.setup.setupDbName || '',
      masterDbIdMasked: CC16_maskId_(details.master && details.master.masterDbId || ''),
      masterDbName: details.master && details.master.masterDbName || '',
      preDeployGate: details.preDeployGate || {},
      scannedFolderCount: details.folderScan && details.folderScan.scannedFolderCount || 0,
      readableFolderCount: details.folderScan && details.folderScan.readableFolderCount || 0,
      scannedFolders: details.folderScan && details.folderScan.scannedFolders || [],
      backupEvidenceFileCount: details.folderScan && details.folderScan.backupEvidenceFileCount || 0,
      rollbackBaselineFileCount: details.folderScan && details.folderScan.rollbackBaselineFileCount || 0,
      latestBackupEvidenceFile: details.folderScan && details.folderScan.latestBackupEvidenceFile || null,
      latestRollbackBaselineFile: details.folderScan && details.folderScan.latestRollbackBaselineFile || null,
      suggestedBackupFile: CC16_TARGET.suggestedBackupFile,
      suggestedRollbackFile: CC16_TARGET.suggestedRollbackFile,
      operationBlock: details.operationBlock || {},
      elapsedMs: new Date().getTime() - started.getTime()
    },
    warnings: warnings,
    hold: hold,
    fatal: fatal,
    nextAction: judgement === 'PASS'
      ? '[03/10] GROUPWARE B90 backup/rollback evidence gate PASS. Next step is [04/10] CONTROL approval gate. This gate executed no production change.'
      : '[03/10] GROUPWARE B90 backup/rollback evidence gate is not PASS. Upload backup and rollback baseline evidence zip files, then rerun.'
  };
}

function CC16_defaultSummary_() {
  return {
    baselineOk: true,
    configOk: false,
    masterOk: false,
    systemConfigAutoReadOk: false,
    masterConnectedOk: false,
    preDeployGatePassed: false,
    preDeployDiagnosticOk: false,
    backupFolderReadableOk: false,
    rollbackFolderReadableOk: false,
    backupEvidenceOk: false,
    rollbackEvidenceOk: false,
    backupRollbackEvidenceOk: false,
    backupRollbackGateOk: false,
    productionSaveAllowed: false,
    fieldUseOpenAllowed: false,
    deployAllowed: false,
    realApplyAllowed: false,
    actualExecutionBlocked: true,
    diagnosticOnly: true,
    dryRunOnly: true,
    sheetWriteExecuted: false,
    sheetCreateExecuted: false,
    headerAutoAddExecuted: false,
    approvalWriteExecuted: false,
    auditLogWriteExecuted: false,
    backupExecuted: false,
    deployExecuted: false,
    recoveryExecuted: false,
    rollbackExecuted: false,
    realApplyExecuted: false,
    productionDataMutationExecuted: false
  };
}

function CC16_readSystemConfig_() {
  var ss = SpreadsheetApp.openById(CC16_SETUP_DB_ID);
  var sheet = ss.getSheetByName(CC16_CONFIG_SHEET_NAME);
  if (!sheet) throw new Error('SystemConfig sheet not found: ' + CC16_CONFIG_SHEET_NAME);
  var values = sheet.getDataRange().getValues();
  var config = {};
  for (var i = 1; i < values.length; i++) {
    var key = String(values[i][0] || '').trim();
    var value = values[i][1];
    if (key) config[key] = value;
  }
  return { ok: true, setupDbId: CC16_SETUP_DB_ID, setupDbName: ss.getName(), sourceDb: CC16_SOURCE_DB, sheetName: CC16_CONFIG_SHEET_NAME, config: config };
}

function CC16_openMasterDb_(config) {
  config = config || {};
  var id = String(config.FEELHAUS_DB_MASTER_ID || config.FEELHAUS_DB_MASTER || config.DB_MASTER_ID || config.MASTER_DB_ID || '').trim();
  if (!id) throw new Error('FEELHAUS_DB_MASTER_ID is missing in SystemConfig');
  var ss = SpreadsheetApp.openById(id);
  return { ok: true, masterDbId: id, masterDbName: ss.getName(), ss: ss };
}

function CC16_checkPreDeployGate_() {
  var out = { checked: false, available: false, passed: false, build: CC16_TARGET.preDeployGateBuild, judgement: '', preDeployDiagnosticOk: false };
  try {
    if (typeof runControlGroupwareB90PreDeployGateV01 === 'function') {
      out.checked = true;
      out.available = true;
      var res = runControlGroupwareB90PreDeployGateV01();
      out.judgement = res && res.judgement || '';
      out.passed = res && res.ok === true && res.judgement === 'PASS';
      out.preDeployDiagnosticOk = res && res.summary && res.summary.preDeployDiagnosticOk === true;
    } else {
      out.checked = true;
      out.available = false;
      out.note = 'runControlGroupwareB90PreDeployGateV01 function not found in project runtime';
    }
  } catch (e) {
    out.checked = true;
    out.available = true;
    out.error = CC16_errorMessage_(e);
  }
  return out;
}

function CC16_scanBackupFolders_(config) {
  var folderIds = CC16_collectFolderIds_(config || {});
  var scan = {
    ok: true,
    scannedFolderCount: folderIds.length,
    readableFolderCount: 0,
    scannedFolders: [],
    backupEvidenceFiles: [],
    rollbackBaselineFiles: [],
    backupEvidenceFileCount: 0,
    rollbackBaselineFileCount: 0,
    latestBackupEvidenceFile: null,
    latestRollbackBaselineFile: null
  };
  for (var i = 0; i < folderIds.length; i++) {
    var entry = folderIds[i];
    var folderResult = { folderKey: entry.key, folderIdMasked: CC16_maskId_(entry.id), readable: false, fileCount: 0, error: '' };
    try {
      var folder = DriveApp.getFolderById(entry.id);
      folderResult.readable = true;
      folderResult.folderName = folder.getName();
      scan.readableFolderCount++;
      var files = folder.getFiles();
      while (files.hasNext()) {
        var file = files.next();
        folderResult.fileCount++;
        var item = CC16_driveFileInfo_(entry.key, file);
        if (CC16_isBackupEvidenceFile_(item.fileName)) scan.backupEvidenceFiles.push(item);
        if (CC16_isRollbackEvidenceFile_(item.fileName)) scan.rollbackBaselineFiles.push(item);
      }
    } catch (e) {
      folderResult.error = CC16_errorMessage_(e);
    }
    scan.scannedFolders.push(folderResult);
  }
  scan.backupEvidenceFiles.sort(CC16_sortFileDesc_);
  scan.rollbackBaselineFiles.sort(CC16_sortFileDesc_);
  scan.backupEvidenceFileCount = scan.backupEvidenceFiles.length;
  scan.rollbackBaselineFileCount = scan.rollbackBaselineFiles.length;
  scan.latestBackupEvidenceFile = scan.backupEvidenceFiles.length ? scan.backupEvidenceFiles[0] : null;
  scan.latestRollbackBaselineFile = scan.rollbackBaselineFiles.length ? scan.rollbackBaselineFiles[0] : null;
  return scan;
}

function CC16_collectFolderIds_(config) {
  var keys = [
    'BACKUP_GROUPWARE_FOLDER_ID',
    'GROUPWARE_BACKUP_FOLDER_ID',
    'BACKUP_PORTAL_GROUPWARE_FOLDER_ID',
    'BACKUP_GROUPWARE_PORTAL_FOLDER_ID',
    'BACKUP_PORTAL_FOLDER_ID',
    'BACKUP_ROOT_FOLDER_ID',
    'CONTROL_BACKUP_FOLDER_ID'
  ];
  var out = [];
  var seen = {};
  for (var i = 0; i < keys.length; i++) {
    var id = String(config[keys[i]] || '').trim();
    if (id && !seen[id]) {
      seen[id] = true;
      out.push({ key: keys[i], id: id });
    }
  }
  return out;
}

function CC16_driveFileInfo_(folderKey, file) {
  var updated = null;
  try { updated = file.getLastUpdated(); } catch (e) {}
  return {
    folderKey: folderKey,
    fileId: file.getId(),
    fileName: file.getName(),
    mimeType: file.getMimeType(),
    updatedAt: updated ? CC16_formatDate_(updated) : '',
    urlMasked: 'https://drive.google.com/file/d/***/view'
  };
}

function CC16_isBackupEvidenceFile_(name) {
  var n = String(name || '').toUpperCase();
  if (n.indexOf('GROUPWARE') < 0) return false;
  if (n.indexOf('B90') < 0 && n.indexOf('B70') < 0) return false;
  if (n.indexOf('BACKUP') < 0) return false;
  if (n.indexOf('.ZIP') < 0) return false;
  return true;
}

function CC16_isRollbackEvidenceFile_(name) {
  var n = String(name || '').toUpperCase();
  if (n.indexOf('GROUPWARE') < 0) return false;
  if (n.indexOf('B90') < 0 && n.indexOf('B70') < 0) return false;
  if (n.indexOf('ROLLBACK') < 0 && n.indexOf('RESTORE') < 0 && n.indexOf('BASELINE') < 0) return false;
  if (n.indexOf('.ZIP') < 0) return false;
  return true;
}

function CC16_operationBlock_() {
  return {
    productionSaveAllowed: false,
    fieldUseOpenAllowed: false,
    deployAllowed: false,
    realApplyAllowed: false,
    actualExecutionBlocked: true,
    sheetWriteExecuted: false,
    sheetCreateExecuted: false,
    headerAutoAddExecuted: false,
    approvalWriteExecuted: false,
    auditLogWriteExecuted: false,
    backupExecuted: false,
    deployExecuted: false,
    recoveryExecuted: false,
    rollbackExecuted: false,
    realApplyExecuted: false,
    productionDataMutationExecuted: false
  };
}

function CC16_logCompactResult_(result) {
  Logger.log('JSON_COMPACT_RESULT: ' + JSON.stringify(CC16_compactResult_(result)));
}

function CC16_compactResult_(result) {
  result = result || {};
  var summary = result.summary || {};
  var evidence = result.evidence || {};
  return {
    ok: result.ok === true,
    build: result.build || CC16_BUILD,
    progress: CC16_PROGRESS,
    mode: result.mode || CC16_MODE,
    checkedAt: result.checkedAt || '',
    judgement: result.judgement || 'BLOCK',
    targetBaseline: CC16_TARGET,
    summary: {
      baselineOk: summary.baselineOk === true,
      configOk: summary.configOk === true,
      masterOk: summary.masterOk === true,
      systemConfigAutoReadOk: summary.systemConfigAutoReadOk === true,
      masterConnectedOk: summary.masterConnectedOk === true,
      preDeployGatePassed: summary.preDeployGatePassed === true,
      preDeployDiagnosticOk: summary.preDeployDiagnosticOk === true,
      backupFolderReadableOk: summary.backupFolderReadableOk === true,
      rollbackFolderReadableOk: summary.rollbackFolderReadableOk === true,
      backupEvidenceOk: summary.backupEvidenceOk === true,
      rollbackEvidenceOk: summary.rollbackEvidenceOk === true,
      backupRollbackEvidenceOk: summary.backupRollbackEvidenceOk === true,
      backupRollbackGateOk: summary.backupRollbackGateOk === true,
      productionSaveAllowed: summary.productionSaveAllowed === true,
      fieldUseOpenAllowed: summary.fieldUseOpenAllowed === true,
      deployAllowed: summary.deployAllowed === true,
      realApplyAllowed: summary.realApplyAllowed === true,
      actualExecutionBlocked: summary.actualExecutionBlocked !== false,
      diagnosticOnly: summary.diagnosticOnly === true,
      dryRunOnly: summary.dryRunOnly === true,
      sheetWriteExecuted: summary.sheetWriteExecuted === true,
      sheetCreateExecuted: summary.sheetCreateExecuted === true,
      headerAutoAddExecuted: summary.headerAutoAddExecuted === true,
      approvalWriteExecuted: summary.approvalWriteExecuted === true,
      auditLogWriteExecuted: summary.auditLogWriteExecuted === true,
      backupExecuted: summary.backupExecuted === true,
      deployExecuted: summary.deployExecuted === true,
      recoveryExecuted: summary.recoveryExecuted === true,
      rollbackExecuted: summary.rollbackExecuted === true,
      realApplyExecuted: summary.realApplyExecuted === true,
      productionDataMutationExecuted: summary.productionDataMutationExecuted === true
    },
    evidence: {
      setupDbId: evidence.setupDbId || CC16_SETUP_DB_ID,
      configSheetName: evidence.configSheetName || CC16_CONFIG_SHEET_NAME,
      sourceDb: evidence.sourceDb || CC16_SOURCE_DB,
      setupDbName: evidence.setupDbName || '',
      masterDbIdMasked: evidence.masterDbIdMasked || '',
      masterDbName: evidence.masterDbName || '',
      preDeployGate: evidence.preDeployGate || {},
      scannedFolderCount: evidence.scannedFolderCount || 0,
      readableFolderCount: evidence.readableFolderCount || 0,
      scannedFolders: evidence.scannedFolders || [],
      backupEvidenceFileCount: evidence.backupEvidenceFileCount || 0,
      rollbackBaselineFileCount: evidence.rollbackBaselineFileCount || 0,
      latestBackupEvidenceFile: evidence.latestBackupEvidenceFile || null,
      latestRollbackBaselineFile: evidence.latestRollbackBaselineFile || null,
      suggestedBackupFile: evidence.suggestedBackupFile || CC16_TARGET.suggestedBackupFile,
      suggestedRollbackFile: evidence.suggestedRollbackFile || CC16_TARGET.suggestedRollbackFile,
      elapsedMs: evidence.elapsedMs || 0
    },
    warnings: result.warnings || [],
    hold: result.hold || [],
    fatal: result.fatal || [],
    nextAction: result.nextAction || ''
  };
}

function CC16_sortFileDesc_(a, b) {
  var ax = String(a && a.updatedAt || '');
  var bx = String(b && b.updatedAt || '');
  if (ax < bx) return 1;
  if (ax > bx) return -1;
  return 0;
}

function CC16_allTrue_(items) {
  for (var i = 0; i < items.length; i++) {
    if (items[i] !== true) return false;
  }
  return true;
}

function CC16_maskId_(id) {
  id = String(id || '');
  if (!id) return '';
  if (id.length <= 8) return '***';
  return id.substring(0, 4) + '***' + id.substring(id.length - 4);
}

function CC16_now_() {
  var tz = 'Asia/Seoul';
  try { tz = Session.getScriptTimeZone() || tz; } catch (e) {}
  return Utilities.formatDate(new Date(), tz, "yyyy-MM-dd'T'HH:mm:ssXXX");
}

function CC16_formatDate_(date) {
  var tz = 'Asia/Seoul';
  try { tz = Session.getScriptTimeZone() || tz; } catch (e) {}
  return Utilities.formatDate(date, tz, "yyyy-MM-dd'T'HH:mm:ssXXX");
}

function CC16_errorMessage_(err) {
  if (!err) return 'unknown error';
  return err.message || String(err);
}
