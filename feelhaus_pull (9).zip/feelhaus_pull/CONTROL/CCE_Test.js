function testControlErpCoreB06J41_081_160_Smoke() {
  var result = {
    ok: true,
    build: CCE_B06J41_081_160.BUILD,
    previousErpCoreBuild: CCE_B06J41_081_160.PREVIOUS_ERP_CORE_BUILD,
    functions: [
      'testControlErpCoreB06J41_081_160_All',
      'testControlErpCoreB06J41_081_160_Smoke',
      'checkControlErpCoreB06J41_081_160_Status',
      'checkControlErpCoreB06J41_081_160_MissingSheets',
      'checkControlErpCoreB06J41_081_160_PolicyJudge',
      'assertControlErpCoreB06J41_081_160_Block'
    ],
    safety: cceB06J41_081_160_getSafety_(),
    message: 'Smoke test completed. Actual create/deploy remains blocked.'
  };
  Logger.log('[CONTROL ERP_CORE 081_160 SMOKE] ' + JSON.stringify(result));
  return result;
}

function testControlErpCoreB06J41_081_160_All() {
  var status = checkControlErpCoreB06J41_081_160_Status();
  var missing = checkControlErpCoreB06J41_081_160_MissingSheets();
  var policy = checkControlErpCoreB06J41_081_160_PolicyJudge();
  var block = assertControlErpCoreB06J41_081_160_Block();
  var ok = !!(status.ok && missing.ok && policy.ok && block.ok);
  var result = {
    ok: ok,
    build: CCE_B06J41_081_160.BUILD,
    previousErpCoreBuild: CCE_B06J41_081_160.PREVIOUS_ERP_CORE_BUILD,
    finalStatus: ok ? 'CONTROL_ERP_CORE_MISSING_SHEET_APPROVAL_081_160_PASSED__CREATE_STILL_BLOCKED' : 'CONTROL_ERP_CORE_MISSING_SHEET_APPROVAL_081_160_FAILED',
    summary: {
      erpCoreAuditStatus: status.erpCoreAudit ? status.erpCoreAudit.status : 'UNKNOWN',
      fatalErrorCount: status.erpCoreAudit ? status.erpCoreAudit.fatalErrorCount : null,
      warningCount: status.erpCoreAudit ? status.erpCoreAudit.warningCount : null,
      readySheetCount: status.erpCoreAudit ? status.erpCoreAudit.readySheetCount : null,
      missingSheetCount: missing.missingSheetCount,
      missingSheets: missing.missingSheets,
      totalMissingHeaders: missing.totalMissingHeaders,
      sheetPolicyCandidateCount: policy.sheetPolicyCandidateCount,
      headerPolicyCandidateCount: policy.headerPolicyCandidateCount,
      approvalRequired: true,
      actualSheetCreateAllowed: false,
      actualHeaderAddAllowed: false,
      actualDbInjectionAllowed: false,
      actualDeployAllowed: false,
      deployAllowed: false,
      actualCreateConfirm: false,
      actualExecutionBlocked: true
    },
    checks: {
      status: status,
      missing: missing,
      policy: policy,
      block: block
    }
  };
  Logger.log('[CONTROL ERP_CORE 081_160 TEST] ' + JSON.stringify(result));
  return result;
}
