/**
 * FEELHAUS CONTROL 03 - BACKUP / DEPLOY / RECOVERY GATE LOCK
 * Build: CONTROL_03_BACKUP_DEPLOY_RECOVERY_LOCK
 * Purpose: backup, deploy, recovery, rollback gate diagnostics only.
 * Safety: No actual backup, deploy, rollback, recovery, sheet/header/log mutation.
 */
var CC03_BUILD = 'CONTROL_03_BACKUP_DEPLOY_RECOVERY_LOCK';
var CC03_MODE = 'BACKUP_DEPLOY_RECOVERY_GATE_DIAGNOSTIC_ONLY_NO_UPDATE';

function runControl03() {
  return diagnoseControl03BackupDeployRecoveryGate();
}

function getControl03DashboardData() {
  return diagnoseControl03BackupDeployRecoveryGate();
}

function control03SmokeTest() {
  var result = diagnoseControl03BackupDeployRecoveryGate();
  Logger.log(JSON.stringify(result, null, 2));
  return result;
}

function diagnoseControl03BackupDeployRecoveryGate() {
  var fatal = [];
  var warnings = [];
  var summary = CC03_baseSummary_();
  var details = {
    build: CC03_BUILD,
    mode: CC03_MODE,
    sourceDb: CC_SOURCE_DB,
    setupDbId: CC_SETUP_DB_ID,
    configSheetName: CC_CONFIG_SHEET_NAME,
    masterDbId: '',
    masterDbName: '',
    backupGate: {},
    deployGate: {},
    recoveryGate: {},
    rollbackGate: {},
    preDeployChecklist: {},
    incidentGuide: CC03_incidentGuide_(),
    finalControlSummary: {},
    safety: CC_getSafety_(),
    guidance: CC03_guidance_()
  };

  try {
    var master = CC_openMasterDb_();
    summary.configOk = true;
    summary.masterOk = !!master && !!master.ss;
    details.masterDbId = master.masterDbId;
    details.masterDbName = master.masterDbName;

    details.backupGate = CC03_checkLogGate_(master.ss, 'BackupLog', CC03_backupHeaders_(), '백업 게이트');
    details.deployGate = CC03_checkLogGate_(master.ss, 'DeployLog', CC03_deployHeaders_(), '배포 게이트');
    details.recoveryGate = CC03_checkLogGate_(master.ss, 'RecoveryLog', CC03_recoveryHeaders_(), '복구 게이트');
    details.rollbackGate = CC03_checkRollbackGate_(master.ss);
    details.preDeployChecklist = CC03_checkPreDeployChecklist_(master.ss);
    details.finalControlSummary = CC03_finalSummary_(details);

    summary.backupGateOk = details.backupGate.ok === true;
    summary.deployGateOk = details.deployGate.ok === true;
    summary.recoveryGateOk = details.recoveryGate.ok === true;
    summary.rollbackGateOk = details.rollbackGate.ok === true;
    summary.preDeployChecklistOk = details.preDeployChecklist.ok === true;
    summary.incidentGuideOk = true;
    summary.finalControlSummaryOk = details.finalControlSummary.ok === true;

    if (!summary.backupGateOk) warnings.push('BackupLog 게이트 헤더 일부가 부족합니다. 실제 헤더 추가는 차단 상태입니다.');
    if (!summary.deployGateOk) warnings.push('DeployLog 게이트 헤더 일부가 부족합니다. 실제 헤더 추가는 차단 상태입니다.');
    if (!summary.recoveryGateOk) warnings.push('RecoveryLog 게이트 헤더 일부가 부족합니다. 실제 헤더 추가는 차단 상태입니다.');
    if (!summary.rollbackGateOk) warnings.push('롤백 기준 헤더/시트 일부가 부족합니다. 실제 롤백은 차단 상태입니다.');
    if (!summary.preDeployChecklistOk) warnings.push('배포 전 점검표 후보 일부가 부족합니다. 실제 배포는 차단 상태입니다.');

    summary.diagnosticOnly = true;
    summary.dryRunOnly = true;
    summary.actualExecutionBlocked = true;
    summary.deployAllowed = false;
    summary.backupExecuted = false;
    summary.deployExecuted = false;
    summary.recoveryExecuted = false;
    summary.rollbackExecuted = false;
    summary.sheetCreateExecuted = false;
    summary.sheetWriteExecuted = false;
    summary.headerAutoAddExecuted = false;
    summary.approvalWriteExecuted = false;
    summary.auditLogWriteExecuted = false;
    summary.productionDataMutationExecuted = false;
    summary.created = false;
    summary.updated = false;
    summary.deleted = false;

    summary.ok = fatal.length === 0 && summary.configOk && summary.masterOk && summary.actualExecutionBlocked && summary.dryRunOnly;
    return CC03_result_(summary, fatal, warnings, details);
  } catch (err) {
    fatal.push('CONTROL 03 진단 중 예외: ' + (err && err.message ? err.message : err));
    return CC03_result_(summary, fatal, warnings, details);
  }
}

function CC03_baseSummary_() {
  return {
    ok: false,
    configOk: false,
    masterOk: false,
    backupGateOk: false,
    deployGateOk: false,
    recoveryGateOk: false,
    rollbackGateOk: false,
    preDeployChecklistOk: false,
    incidentGuideOk: false,
    finalControlSummaryOk: false,
    diagnosticOnly: true,
    dryRunOnly: true,
    deployAllowed: false,
    actualExecutionBlocked: true,
    backupExecuted: false,
    deployExecuted: false,
    recoveryExecuted: false,
    rollbackExecuted: false,
    sheetCreateExecuted: false,
    sheetWriteExecuted: false,
    headerAutoAddExecuted: false,
    approvalWriteExecuted: false,
    auditLogWriteExecuted: false,
    productionDataMutationExecuted: false,
    created: false,
    updated: false,
    deleted: false
  };
}

function CC03_backupHeaders_() {
  return {
    backupId: ['backupId'],
    projectCode: ['projectCode'],
    buildRange: ['buildRange'],
    sourceDb: ['sourceDb'],
    targetDb: ['targetDb'],
    backupScope: ['backupScope'],
    backupStatus: ['backupStatus', 'status'],
    backupStartedAt: ['backupStartedAt', 'startedAt', 'createdAt'],
    executedBy: ['executedBy', 'createdBy'],
    rollbackBaselineId: ['rollbackBaselineId'],
    notes: ['notes']
  };
}

function CC03_deployHeaders_() {
  return {
    deployId: ['deployId'],
    projectCode: ['projectCode'],
    buildNo: ['buildNo', 'build'],
    deployLevel: ['deployLevel'],
    deployStatus: ['deployStatus', 'status'],
    approvalId: ['approvalId'],
    backupId: ['backupId'],
    rollbackBaselineId: ['rollbackBaselineId'],
    startedAt: ['startedAt', 'createdAt'],
    completedAt: ['completedAt', 'updatedAt'],
    result: ['result', 'deployResult'],
    notes: ['notes']
  };
}

function CC03_recoveryHeaders_() {
  return {
    recoveryId: ['recoveryId'],
    rollbackBaselineId: ['rollbackBaselineId'],
    projectCode: ['projectCode'],
    baselineBuild: ['baselineBuild'],
    rollbackScope: ['rollbackScope', 'recoveryScope'],
    rollbackAllowed: ['rollbackAllowed'],
    reason: ['reason', 'statusReason'],
    createdAt: ['createdAt'],
    createdBy: ['createdBy']
  };
}

function CC03_checkLogGate_(ss, sheetName, spec, label) {
  var sheet = ss.getSheetByName(sheetName);
  var headerMap = CC_headerMap_(sheet);
  var missing = CC03_missingHeaders_(headerMap, spec);
  return {
    ok: !!sheet && missing.length === 0,
    label: label,
    sheetName: sheetName,
    exists: !!sheet,
    rowCount: CC_countRows_(sheet),
    missingHeaders: missing,
    missingHeaderCount: missing.length,
    resolvedHeaders: CC03_resolvedHeaders_(headerMap, spec),
    actualCreateBlocked: true,
    actualHeaderAddBlocked: true,
    actualWriteBlocked: true,
    actualExecutionBlocked: true,
    dryRunOnly: true,
    policy: label + ' 후보만 점검합니다. 실제 실행/쓰기/생성은 차단합니다.'
  };
}

function CC03_checkRollbackGate_(ss) {
  var recovery = CC03_checkLogGate_(ss, 'RecoveryLog', CC03_recoveryHeaders_(), '롤백 기준 게이트');
  var deploy = CC03_checkLogGate_(ss, 'DeployLog', { rollbackBaselineId: ['rollbackBaselineId'], approvalId: ['approvalId'], deployStatus: ['deployStatus', 'status'] }, '롤백 연결 게이트');
  return {
    ok: recovery.exists && deploy.exists,
    recoveryLogOk: recovery.ok,
    deployLogExists: deploy.exists,
    recoveryLog: recovery,
    deployLog: deploy,
    rollbackAllowed: false,
    actualRollbackBlocked: true,
    requiredApproval: true,
    policy: '롤백은 승인 기반 게이트 통과 전 실행 금지. CONTROL 03은 후보 진단만 수행.'
  };
}

function CC03_checkPreDeployChecklist_(ss) {
  var checks = [
    CC03_checkLogGate_(ss, 'ApprovalLog', { approvalId: ['approvalId'], approvalStatus: ['approvalStatus', 'status'], approvedBy: ['approvedBy'], approvedAt: ['approvedAt'] }, '승인 확인'),
    CC03_checkLogGate_(ss, 'BackupLog', { backupId: ['backupId'], backupStatus: ['backupStatus', 'status'], rollbackBaselineId: ['rollbackBaselineId'] }, '백업 확인'),
    CC03_checkLogGate_(ss, 'DeployLog', { deployId: ['deployId'], deployStatus: ['deployStatus', 'status'], buildNo: ['buildNo', 'build'] }, '배포 로그 확인'),
    CC03_checkLogGate_(ss, 'RecoveryLog', { recoveryId: ['recoveryId'], rollbackBaselineId: ['rollbackBaselineId'] }, '복구 기준 확인')
  ];
  return {
    ok: checks.some(function (item) { return item.exists; }),
    checks: checks,
    deployAllowed: false,
    actualDeployBlocked: true,
    checklist: [
      'SystemConfig 자동 읽기 확인',
      'FEELHAUS_DB_MASTER 연결 확인',
      '필수 시트/헤더 확인',
      '권한/상태전이/감사로그 확인',
      '백업 후보/롤백 기준 확인',
      '승인 게이트 확인',
      '장애 대응 안내 확인'
    ],
    policy: '배포 전 점검표는 진단 전용입니다. 실제 배포 허용값은 항상 false입니다.'
  };
}

function CC03_finalSummary_(details) {
  var control01 = 'CONTROL 01 설정/DB 진단 통과 기준 유지';
  var control02 = 'CONTROL 02 권한/감사/상태 진단 통과 기준 유지';
  var control03 = 'CONTROL 03 백업/배포/복구/롤백 게이트 진단 수행';
  return {
    ok: true,
    control01: control01,
    control02: control02,
    control03: control03,
    deployAllowed: false,
    actualExecutionBlocked: true,
    dryRunOnly: true,
    finalStatus: 'CONTROL_01_02_03_DIAGNOSTIC_GATE_READY__EXECUTION_BLOCKED',
    nextAction: 'CONTROL 최종 게이트 통과 여부 확인 후, 실제 실행은 별도 승인 기반으로만 진행하세요.'
  };
}

function CC03_incidentGuide_() {
  return {
    pageTitle: 'CONTROL 03 백업/배포/복구/롤백 게이트',
    mainStatusText: '백업, 배포, 복구, 롤백 기준을 DryRun으로 점검합니다.',
    readonlyText: 'CONTROL 03은 조회/진단 전용이며 실제 백업/복구/롤백/배포를 실행하지 않습니다.',
    successText: 'CONTROL 03 게이트 진단을 완료했습니다.',
    emptyText: '점검 대상 로그 또는 게이트 기준을 찾지 못했습니다. SystemConfig와 MASTER 연결을 확인해 주세요.',
    errorText: 'CONTROL 03 진단 중 문제가 발생했습니다. 백업/배포/복구/롤백 로그 정책을 확인해 주세요.',
    incidentSteps: [
      '1. CONTROL 01 설정/DB 진단 상태 확인',
      '2. CONTROL 02 권한/감사/상태 진단 상태 확인',
      '3. BackupLog / DeployLog / RecoveryLog 후보 상태 확인',
      '4. 승인 필요 작업은 메인 개발자 승인 후 별도 단계로 분리',
      '5. 실제 복구/롤백/배포는 CONTROL 03에서 즉시 실행하지 않음'
    ]
  };
}

function CC03_guidance_() {
  return CC03_incidentGuide_();
}

function CC03_missingHeaders_(headerMap, spec) {
  var missing = [];
  for (var logical in spec) {
    if (spec.hasOwnProperty(logical) && CC03_resolveHeader_(headerMap, spec[logical]) === '') {
      missing.push(logical + '(' + spec[logical].join('|') + ')');
    }
  }
  return missing;
}

function CC03_resolvedHeaders_(headerMap, spec) {
  var resolved = {};
  for (var logical in spec) {
    if (spec.hasOwnProperty(logical)) resolved[logical] = CC03_resolveHeader_(headerMap, spec[logical]);
  }
  return resolved;
}

function CC03_resolveHeader_(headerMap, aliases) {
  for (var i = 0; i < aliases.length; i++) {
    if (headerMap.hasOwnProperty(aliases[i])) return aliases[i];
  }
  return '';
}

function CC03_result_(summary, fatal, warnings, details) {
  return {
    ok: fatal.length === 0 && summary.ok === true,
    build: CC03_BUILD,
    checkedAt: CC_now_(),
    mode: CC03_MODE,
    fatal: fatal,
    warnings: warnings,
    summary: summary,
    details: details,
    nextAction: fatal.length === 0 ? 'CONTROL 03 통과. CONTROL 01~03 최종 진단 게이트 요약 가능.' : 'fatal 확인 후 CONTROL 03 게이트 기준을 재확인하세요.'
  };
}
