/** Missing sheet/header candidates for ERP_CORE. */
function getControlErpCoreB06J41_361_560_MissingSheetDefinitions_() {
  var common = ['eventId','vendorId','customerId','status','statusReason','createdAt','createdBy','updatedAt','updatedBy'];
  return [
    { sheetName: 'ERP_판매관리', workArea: '판매관리', extra: ['saleId'] },
    { sheetName: 'ERP_계약관리', workArea: '계약관리', extra: ['contractId','saleId'] },
    { sheetName: 'ERP_설치관리', workArea: '설치관리', extra: ['installId','saleId','contractId'] },
    { sheetName: 'ERP_AS관리', workArea: 'A/S관리', extra: ['asId','saleId'] },
    { sheetName: 'ERP_정산관리', workArea: '정산관리', extra: ['settlementId','saleId','contractId'] },
    { sheetName: 'ERP_사용자관리', workArea: '사용자관리', extra: ['userId','roleCode'] }
  ].map(function (d) {
    d.projectCode = 'ERP_CORE';
    d.requiredHeaders = common.concat(d.extra);
    return d;
  });
}

function checkControlErpCoreB06J41_361_560_Candidates() {
  var cfg = readControlErpCoreB06J41_361_560_SystemConfig_();
  var master = openControlErpCoreB06J41_361_560_MasterDb_(cfg.config || {});
  var ss = master.spreadsheet;
  var defs = getControlErpCoreB06J41_361_560_MissingSheetDefinitions_();
  var candidates = [];
  var totalMissingHeaders = 0;

  defs.forEach(function (d) {
    var sh = ss.getSheetByName(d.sheetName);
    var headers = [];
    if (sh && sh.getLastColumn() > 0) {
      headers = sh.getRange(1, 1, 1, sh.getLastColumn()).getValues()[0].map(function (v) { return String(v || '').trim(); });
    }
    var missingHeaders = d.requiredHeaders.filter(function (h) { return headers.indexOf(h) < 0; });
    totalMissingHeaders += missingHeaders.length;
    candidates.push({
      sheetName: d.sheetName,
      workArea: d.workArea,
      projectCode: d.projectCode,
      exists: !!sh,
      missing: !sh,
      currentHeaderCount: headers.length,
      requiredHeaders: d.requiredHeaders,
      requiredHeaderCount: d.requiredHeaders.length,
      missingHeaders: missingHeaders,
      missingHeaderCount: missingHeaders.length,
      actionType: !sh ? 'SHEET_CREATE_CANDIDATE_ONLY' : (missingHeaders.length ? 'HEADER_REVIEW_CANDIDATE_ONLY' : 'NO_ACTION_REQUIRED'),
      actualSheetCreateBlocked: true,
      actualHeaderAddBlocked: true,
      approvalRequired: !sh || missingHeaders.length > 0,
      deleteCandidate: false,
      archiveCandidate: false,
      protected: true,
      message: !sh ? '누락 시트입니다. 생성 필요 후보로만 표시합니다.' : '시트가 존재합니다. 헤더만 검토합니다.'
    });
  });

  return {
    ok: true,
    build: CCE3_BUILD,
    masterDbName: master.masterDbName,
    missingSheetCount: candidates.filter(function (c) { return c.missing; }).length,
    missingSheets: candidates.filter(function (c) { return c.missing; }).map(function (c) { return c.sheetName; }),
    totalMissingHeaders: totalMissingHeaders,
    candidates: candidates,
    safety: getControlErpCoreB06J41_361_560_Safety_(),
    message: 'ERP_CORE 생성 필요 후보와 헤더 후보를 최종 마감 리포트용으로 집계했습니다.'
  };
}
