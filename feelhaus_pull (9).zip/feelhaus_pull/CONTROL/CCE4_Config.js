var CCE4_BUILD='CONTROL_B06J41_761_940_ERP_CORE_CREATE_APPROVAL_FINAL_GATE_SAFE';
var CCE4_PREVIOUS_CONTROL_BUILD='CONTROL_B06J41_361_560_ERP_CORE_FINAL_CLOSE_REPORT_SAFE';
var CCE4_PREVIOUS_ERP_CORE_BUILD='ERP_CORE_CLEAN_B06J41_1641_1780_FINAL_PRE_CREATE_APPROVAL_REPORT_SAFE';
var CCE4_ERP_CORE_FINAL_STATUS='ERP_CORE_CLEAN_FINAL_REPORT_1641_1780_PASSED__CREATE_DEPLOY_STILL_BLOCKED';
var CCE4_SETUP_DB_ID='17VMSpgSZCvIrUlgcw8yCNcnl8WQWo2IcRf5tDCcuJGM';
var CCE4_CONFIG_SHEET_NAME='SystemConfig';
var CCE4_SOURCE_DB='FEELHAUS_SETUP_DB';

function cce4Now_(){return Utilities.formatDate(new Date(),'Asia/Seoul',"yyyy-MM-dd'T'HH:mm:ssXXX");}

function cce4Safety_(){
  return {
    dryRunOnly:true, finalGateOnly:true, approvalRequired:true,
    deployAllowed:false, actualCreateConfirm:false, actualDeployConfirm:false,
    actualCreateGlobalEnabled:false, actualDeployGlobalEnabled:false, actualDbInjectionGlobalEnabled:false,
    noSheetCreate:true, noSheetWrite:true, noHeaderAutoAdd:true, noDbInjection:true, noPolicyWrite:true, noApprovalWrite:true,
    noCustomerSave:true, noSaleSave:true, noContractCreate:true, noSignDocumentCreate:true, noInstallAsSave:true,
    noSettlementExecution:true, noCancelSettlementConfirm:true, noPaymentRecoveryOffset:true,
    noDepositReturnExecution:true, noBenefitPayoutExecution:true, noFundExecution:true,
    noStaffCreate:true, noRoleMutation:true, noFormAutoRegister:true, noPortalStatusMutation:true,
    noAuditLogWrite:true, noStatusMutation:true, noActualDeploy:true, noActualBackup:true, noActualRecovery:true, noActualRollback:true,
    noProtectedSheetDelete:true, noArchiveByNewSheetReason:true, actualExecutionBlocked:true
  };
}

function cce4OpenSetup_(){
  try{
    var ss=SpreadsheetApp.openById(CCE4_SETUP_DB_ID);
    var sh=ss.getSheetByName(CCE4_CONFIG_SHEET_NAME);
    if(!sh) return {ok:false,setupDbId:CCE4_SETUP_DB_ID,sourceDb:CCE4_SOURCE_DB,sheetName:CCE4_CONFIG_SHEET_NAME,message:'SystemConfig 시트를 찾을 수 없습니다.'};
    var values=sh.getDataRange().getValues();
    var headers=values.length?values[0].map(String):[];
    var keyIdx=headers.indexOf('CONFIG_KEY'); if(keyIdx<0) keyIdx=headers.indexOf('configKey');
    var valIdx=headers.indexOf('VALUE'); if(valIdx<0) valIdx=headers.indexOf('value');
    var config={};
    if(keyIdx>=0 && valIdx>=0){
      for(var i=1;i<values.length;i++){var k=values[i][keyIdx]; if(k!==''&&k!=null) config[String(k)]=values[i][valIdx];}
    }
    return {ok:true,setupDbId:CCE4_SETUP_DB_ID,setupDbName:ss.getName(),sourceDb:CCE4_SOURCE_DB,sheetName:CCE4_CONFIG_SHEET_NAME,config:config,message:'SystemConfig 읽기 완료'};
  }catch(err){return {ok:false,setupDbId:CCE4_SETUP_DB_ID,sourceDb:CCE4_SOURCE_DB,sheetName:CCE4_CONFIG_SHEET_NAME,error:String(err),message:'SystemConfig 읽기 실패'};}
}

function cce4OpenMaster_(setup){
  try{
    var config=setup&&setup.config?setup.config:{};
    var masterId=config.FEELHAUS_DB_MASTER_ID||config.DB_MASTER_ID||config.SPREADSHEET_ID||config.CUSTOMER_DB_SPREADSHEET_ID;
    if(!masterId) return {ok:false,message:'FEELHAUS_DB_MASTER ID를 찾을 수 없습니다.'};
    var ss=SpreadsheetApp.openById(String(masterId));
    return {ok:true,masterDbId:String(masterId),masterDbName:ss.getName(),message:'FEELHAUS_DB_MASTER 연결 확인 완료'};
  }catch(err){return {ok:false,error:String(err),message:'FEELHAUS_DB_MASTER 연결 실패'};}
}

function cce4BaseContext_(){
  var setup=cce4OpenSetup_();
  var master=cce4OpenMaster_(setup);
  return {ok:!!(setup.ok&&master.ok),build:CCE4_BUILD,previousControlBuild:CCE4_PREVIOUS_CONTROL_BUILD,previousErpCoreBuild:CCE4_PREVIOUS_ERP_CORE_BUILD,erpCoreFinalStatus:CCE4_ERP_CORE_FINAL_STATUS,setupDb:setup,masterDb:master,safety:cce4Safety_(),createdAt:cce4Now_()};
}

function cce4RequiredSheetCandidates_(){
  var common=['eventId','vendorId','customerId','status','statusReason','createdAt','createdBy','updatedAt','updatedBy'];
  return [
    {sheetName:'ERP_판매관리',workArea:'판매관리',requiredHeaders:common.concat(['saleId'])},
    {sheetName:'ERP_계약관리',workArea:'계약관리',requiredHeaders:common.concat(['contractId','saleId'])},
    {sheetName:'ERP_설치관리',workArea:'설치관리',requiredHeaders:common.concat(['installId','saleId','contractId'])},
    {sheetName:'ERP_AS관리',workArea:'A/S관리',requiredHeaders:common.concat(['asId','saleId'])},
    {sheetName:'ERP_정산관리',workArea:'정산관리',requiredHeaders:common.concat(['settlementId','saleId','contractId'])},
    {sheetName:'ERP_사용자관리',workArea:'사용자관리',requiredHeaders:common.concat(['userId','roleCode'])}
  ];
}

function cce4ApprovalItems_(){
  return ['ERP_CORE 누락 시트 6개 생성 승인','HeaderPolicy 67개 확정 승인','SheetPolicy 6개 등록 승인','actualCreateConfirm=true 전환 승인','deployAllowed=true 전환 승인','실제 DB 주입 승인','실제 배포 실행 승인'];
}
