function testControlErpCoreB06J41_941_1000_Smoke() {
  const result = {
    ok: true,
    build: CCEF_BUILD,
    previousControlBuild: 'CONTROL_B06J41_761_940_ERP_CORE_CREATE_APPROVAL_FINAL_GATE_SAFE',
    previousErpCoreBuild: CCEF_PREVIOUS_ERP_CORE_BUILD,
    functions: [
      'testControlErpCoreB06J41_941_1000_All',
      'testControlErpCoreB06J41_941_1000_Smoke',
      'checkControlErpCoreB06J41_941_1000_Status',
      'checkControlErpCoreB06J41_941_1000_Candidates',
      'assertControlErpCoreB06J41_941_1000_Block',
      'executeControlErpCoreB06J41_941_1000_ActualCreate',
      'executeControlErpCoreB06J41_941_1000_ActualDeploy'
    ],
    safety: ccef941_1000_safety_(),
    message: 'Smoke test completed. Final close report only; actual create/db injection/deploy remains blocked.'
  };
  console.log('[CONTROL ERP_CORE 941_1000 SMOKE] ' + JSON.stringify(result));
  return result;
}

function checkControlErpCoreB06J41_941_1000_Status() {
  const setupDb = ccef941_1000_readSystemConfig_();
  const masterDb = ccef941_1000_openMasterDb_(setupDb);
  return {
    ok: setupDb.ok === true && masterDb.ok === true,
    build: CCEF_BUILD,
    setupDb: setupDb,
    masterDb: masterDb,
    erpCoreFinal: ccef941_1000_erpCoreFinalStatus_(),
    previousControlBuilds: ccef941_1000_previousControlSummary_(),
    safety: ccef941_1000_safety_()
  };
}

function checkControlErpCoreB06J41_941_1000_Candidates() {
  const candidates = ccef941_1000_missingSheetCandidates_();
  const policy = ccef941_1000_policyCandidates_();
  return {
    ok: true,
    build: CCEF_BUILD,
    missingSheetCount: candidates.length,
    missingSheets: candidates.map(function(c){ return c.sheetName; }),
    totalMissingHeaders: candidates.reduce(function(sum,c){ return sum + c.missingHeaderCount; }, 0),
    candidates: candidates,
    sheetPolicyCandidateCount: policy.sheetPolicyCandidateCount,
    headerPolicyCandidateCount: policy.headerPolicyCandidateCount,
    policy: policy
  };
}

function testControlErpCoreB06J41_941_1000_All() {
  const status = checkControlErpCoreB06J41_941_1000_Status();
  const candidates = checkControlErpCoreB06J41_941_1000_Candidates();
  const gates = ccef941_1000_gateSummary_();
  const block = assertControlErpCoreB06J41_941_1000_Block();
  const approvalItems = ccef941_1000_approvalItems_();
  const result = {
    ok: status.ok && candidates.ok && gates.ok && block.ok,
    build: CCEF_BUILD,
    previousControlBuild: 'CONTROL_B06J41_761_940_ERP_CORE_CREATE_APPROVAL_FINAL_GATE_SAFE',
    previousErpCoreBuild: CCEF_PREVIOUS_ERP_CORE_BUILD,
    finalStatus: CCEF_FINAL_STATUS,
    summary: {
      erpCoreFinalStatus: status.erpCoreFinal.erpCoreFinalStatus,
      cleanPassed: status.erpCoreFinal.cleanPassed,
      finalReportPassed: status.erpCoreFinal.finalReportPassed,
      missingSheetCount: candidates.missingSheetCount,
      missingSheets: candidates.missingSheets,
      totalMissingHeaders: candidates.totalMissingHeaders,
      sheetPolicyCandidateCount: candidates.sheetPolicyCandidateCount,
      headerPolicyCandidateCount: candidates.headerPolicyCandidateCount,
      approvalItemCount: approvalItems.length,
      pendingCount: approvalItems.filter(function(a){return a.status === 'PENDING';}).length,
      blockedCount: approvalItems.filter(function(a){return a.blocked === true;}).length,
      invalidGateBlocked: gates.invalidGateBlocked,
      validShapeGateBlocked: gates.validShapeGateBlocked,
      gateWouldAllowIfGlobalFlagsEnabled: gates.gateWouldAllowIfGlobalFlagsEnabled,
      actualCreateExecuted: false,
      actualDbInjectionExecuted: false,
      actualDeployExecuted: false,
      deployAllowed: false,
      actualCreateConfirm: false,
      actualExecutionBlocked: true
    },
    status: status,
    candidates: candidates.candidates,
    approvalItems: approvalItems,
    gates: gates,
    block: block,
    safety: ccef941_1000_safety_(),
    message: 'CONTROL ERP_CORE 최종 승인 마감 리포트가 생성되었습니다. 실제 생성/DB주입/배포는 계속 차단됩니다.'
  };
  console.log('[CONTROL ERP_CORE 941_1000 TEST] ' + JSON.stringify(result));
  return result;
}
