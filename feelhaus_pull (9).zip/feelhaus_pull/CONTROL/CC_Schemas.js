/** FEELHAUS CONTROL CENTER - Schemas */
function CC_requiredSchemas_() {
  return {
    ApprovalLog: [
      'approvalId','projectCode','controlProjectCode','approvalType','approvalScope','approvalStatus','approvedBy','approvedAt','requestedBy','requestedAt','targetSheetName','targetAction','relatedBuild','relatedDeployId','reason','status','statusReason','createdAt','createdBy','updatedAt','updatedBy','notes'
    ],
    BackupLog: [
      'backupId','projectCode','buildRange','sourceDb','targetDb','backupScope','backupStatus','backupStartedAt','backupCompletedAt','executedBy','relatedDeployId','rollbackBaselineId','notes'
    ],
    RecoveryLog: [
      'recoveryId','rollbackBaselineId','projectCode','baselineBuild','rollbackScope','rollbackAllowed','createdAt','createdBy','reason'
    ],
    DeployLog: [
      'deployId','projectCode','buildNo','deployLevel','deployStatus','approvedBy','approvalId','backupId','rollbackBaselineId','startedAt','completedAt','result','notes'
    ]
  };
}

function CC_checkLogSchemas_() {
  var master = CC_openMasterDb_();
  var schemas = CC_requiredSchemas_();
  var results = [];
  var missingSheets = [];
  var totalMissingHeaders = 0;
  Object.keys(schemas).forEach(function (name) {
    var sheet = master.ss.getSheetByName(name);
    var exists = !!sheet;
    var hmap = CC_headerMap_(sheet);
    var missing = schemas[name].filter(function (h) { return !hmap[h]; });
    if (!exists) missingSheets.push(name);
    totalMissingHeaders += missing.length;
    results.push({
      sheetName: name,
      exists: exists,
      ok: exists && missing.length === 0,
      requiredHeaderCount: schemas[name].length,
      currentHeaderCount: Object.keys(hmap).length,
      missingHeaderCount: missing.length,
      missingHeaders: missing,
      targetAction: exists ? (missing.length ? 'ADD_HEADERS_CANDIDATE_ONLY' : 'NONE') : 'CREATE_SHEET_AND_HEADERS_CANDIDATE_ONLY',
      actualCreateBlocked: true,
      actualHeaderAddBlocked: true
    });
  });
  return {
    ok: true,
    masterDbName: master.masterDbName,
    sheets: results,
    missingSheets: missingSheets,
    totalMissingHeaders: totalMissingHeaders,
    safety: CC_getSafety_(),
    message: '로그 구조 후보만 점검했습니다. 실제 시트 생성/헤더 추가는 차단 상태입니다.'
  };
}

function CC_createPlan_() {
  var checked = CC_checkLogSchemas_();
  var plan = checked.sheets.filter(function (s) { return !s.ok; }).map(function (s) {
    return {
      sheetName: s.sheetName,
      exists: s.exists,
      requiredHeaderCount: s.requiredHeaderCount,
      missingHeaderCount: s.missingHeaderCount,
      missingHeaders: s.missingHeaders,
      targetAction: s.targetAction,
      actualCreateBlocked: true,
      actualHeaderAddBlocked: true
    };
  });
  return { ok: true, createPlanCount: plan.length, createPlan: plan, checked: checked };
}
