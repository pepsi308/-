function testControlCenterB06J41_701_760_All() {
  var setup = ccb701_760_readSystemConfig_();
  var master = ccb701_760_openMasterDb_();
  var logReadiness = ccb701_760_checkLogSheetReadiness_();
  var folders = ccb701_760_checkBackupFolders_();
  var backupPlan = ccb701_760_buildBackupPlanCandidate_();
  var gates = ccb701_760_runApprovalGateTests_();
  var guard = ccb701_760_runExecuteGuardTests_();
  var ok = !!(setup.ok && master.ok && logReadiness.ok && backupPlan.ok && gates.ok && guard.ok && guard.actualBackupExecuted === false);
  var result = {
    ok: ok,
    build: CCB_BUILD.build,
    previousBuild: CCB_BUILD.previousBuild,
    finalStatus: ok ? CCB_BUILD.finalExpectedStatus : 'CONTROL_CENTER_ACTUAL_BACKUP_APPROVAL_PRECHECK_FAILED',
    deployAllowed: false,
    actualExecutionBlocked: true,
    dryRun: true,
    actualBackupApprovalPrecheck: true,
    summary: {
      setupOk: !!setup.ok,
      masterOk: !!master.ok,
      missingSheets: logReadiness.missingSheets || [],
      totalMissingHeaders: logReadiness.totalMissingHeaders || 0,
      backupFolderCheckOk: !!folders.ok,
      backupPlanCreated: !!backupPlan.ok,
      invalidGateBlocked: !!gates.invalidGateBlocked,
      validShapeGateBlocked: !!gates.validShapeGateBlocked,
      gateWouldAllowIfGlobalFlagsEnabled: !!gates.gateWouldAllowIfGlobalFlagsEnabled,
      actualBackupAllowed: false,
      actualBackupExecuted: false,
      finalStatus: ok ? CCB_BUILD.finalExpectedStatus : 'CONTROL_CENTER_ACTUAL_BACKUP_APPROVAL_PRECHECK_FAILED'
    },
    checks: {
      setupDb: setup,
      masterDb: master.ok ? { ok: true, masterDbId: master.masterDbId, masterDbName: master.masterDbName, message: master.message } : master,
      logReadiness: logReadiness,
      backupFolders: folders,
      backupPlan: backupPlan,
      gates: gates,
      guard: guard,
      safety: ccb701_760_safety_()
    }
  };
  Logger.log('[CONTROL BACKUP 701_760 TEST] ' + JSON.stringify(result));
  return result;
}
