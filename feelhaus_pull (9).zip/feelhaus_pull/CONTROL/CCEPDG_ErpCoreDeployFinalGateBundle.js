
/**
 * FEELHAUS CONTROL - ERP_CORE Deploy Final Gate Bundle
 * Build: CONTROL_ERP_CORE_DEPLOY_FINAL_GATE_BUNDLE_SAFE
 * Purpose:
 *  - Final read-only gate before deploy approval review.
 *  - Re-check ERP_CORE 6 sheets, 67 HeaderPolicy rows, 6 SheetPolicy rows.
 *  - Simulate UI route smoke, permission filter smoke, state transition, backup/rollback confirmation.
 * Safety:
 *  - read-only / simulation only
 *  - no deploy execution
 *  - no business data write
 *  - no sheet/header/policy mutation
 */
var CCEPDG_BUILD = 'CONTROL_ERP_CORE_DEPLOY_FINAL_GATE_BUNDLE_SAFE';
var CCEPDG_SETUP_DB_ID = '17VMSpgSZCvIrUlgcw8yCNcnl8WQWo2IcRf5tDCcuJGM';
var CCEPDG_CONFIG_SHEET_NAME = 'SystemConfig';
var CCEPDG_EXPECTED = {
  sheetCount: 6,
  headerPolicyCount: 67,
  sheetPolicyCount: 6,
  expectedTestRunIdPrefix: 'TEST_',
  createdTestStatus: 'TEST_SAVED'
};
var CCEPDG_CORE_SHEETS = [
  { key: 'sales', sheetName: 'ERP_판매관리', primaryId: 'saleId', headers: ['eventId','vendorId','customerId','status','statusReason','createdAt','createdBy','updatedAt','updatedBy','saleId'], links: ['eventId','vendorId','customerId'] },
  { key: 'contracts', sheetName: 'ERP_계약관리', primaryId: 'contractId', headers: ['eventId','vendorId','customerId','status','statusReason','createdAt','createdBy','updatedAt','updatedBy','contractId','saleId'], links: ['saleId','eventId','vendorId','customerId'] },
  { key: 'installs', sheetName: 'ERP_설치관리', primaryId: 'installId', headers: ['eventId','vendorId','customerId','status','statusReason','createdAt','createdBy','updatedAt','updatedBy','installId','saleId','contractId'], links: ['contractId','saleId','eventId','vendorId','customerId'] },
  { key: 'as', sheetName: 'ERP_AS관리', primaryId: 'asId', headers: ['eventId','vendorId','customerId','status','statusReason','createdAt','createdBy','updatedAt','updatedBy','asId','saleId'], links: ['saleId','eventId','vendorId','customerId'] },
  { key: 'settlements', sheetName: 'ERP_정산관리', primaryId: 'settlementId', headers: ['eventId','vendorId','customerId','status','statusReason','createdAt','createdBy','updatedAt','updatedBy','settlementId','saleId','contractId'], links: ['saleId','contractId','eventId','vendorId','customerId'] },
  { key: 'users', sheetName: 'ERP_사용자관리', primaryId: 'userId', headers: ['eventId','vendorId','customerId','status','statusReason','createdAt','createdBy','updatedAt','updatedBy','userId','roleCode'], links: ['vendorId','roleCode'] }
];
var CCEPDG_POLICY_SHEETS = {
  headerPolicySheetName: 'HeaderPolicy',
  sheetPolicySheetName: 'SheetPolicy'
};
var CCEPDG_UI_ROUTES = [
  { route: 'ERP_HOME', label: 'ERP 홈', requiredRole: 'HQ_OR_VENDOR', expected: 'ROUTE_DEFINED' },
  { route: 'ERP_SALES', label: '판매관리', requiredRole: 'SALES_OR_HQ', expected: 'ROUTE_DEFINED' },
  { route: 'ERP_CONTRACTS', label: '계약관리', requiredRole: 'SALES_OR_HQ', expected: 'ROUTE_DEFINED' },
  { route: 'ERP_INSTALLS', label: '설치관리', requiredRole: 'INSTALL_OR_HQ', expected: 'ROUTE_DEFINED' },
  { route: 'ERP_AS', label: 'A/S관리', requiredRole: 'AS_OR_HQ', expected: 'ROUTE_DEFINED' },
  { route: 'ERP_SETTLEMENTS', label: '정산관리', requiredRole: 'SETTLEMENT_APPROVED_OR_HQ', expected: 'ROUTE_DEFINED' },
  { route: 'ERP_USERS', label: '사용자관리', requiredRole: 'HQ_OR_VENDOR_ADMIN', expected: 'ROUTE_DEFINED' }
];
var CCEPDG_PERMISSION_SCENARIOS = [
  { roleCode: 'HQ_ADMIN', vendorId: '', eventId: '', canSeeAll: true, canEditSettlement: false, canDeploy: false },
  { roleCode: 'VENDOR_REP', vendorId: 'VENDOR_TEST_SAFE', eventId: 'EVT_TEST_SAFE', canSeeAll: false, canEditSettlement: false, canDeploy: false },
  { roleCode: 'SALES_STAFF', vendorId: 'VENDOR_TEST_SAFE', eventId: 'EVT_TEST_SAFE', canSeeAll: false, canEditSettlement: false, canDeploy: false },
  { roleCode: 'SETTLEMENT_APPROVER', vendorId: '', eventId: '', canSeeAll: true, canEditSettlement: true, canDeploy: false }
];
var CCEPDG_STATE_TRANSITIONS = [
  { domain: 'sale', from: 'DRAFT', to: 'TEST_SAVED', allowed: true },
  { domain: 'sale', from: 'TEST_SAVED', to: 'LOCKED', allowed: true },
  { domain: 'contract', from: 'TEST_SAVED', to: 'SIGNED', allowed: true },
  { domain: 'install', from: 'TEST_SAVED', to: 'COMPLETED', allowed: true },
  { domain: 'settlement', from: 'COMPLETED', to: 'MUTATED_ORIGINAL_SLIP', allowed: false },
  { domain: 'settlement', from: 'COMPLETED', to: 'CANCEL_ADJUSTMENT_SLIP', allowed: true, approvalRequired: true },
  { domain: 'closed', from: 'LOCKED', to: 'GENERAL_EDIT', allowed: false }
];

function controlErpCoreDeployFinalGateBundle_safety_() {
  return {
    build: CCEPDG_BUILD,
    readOnly: true,
    simulationOnly: true,
    noSheetCreate: true,
    noHeaderAutoAdd: true,
    noPolicyWrite: true,
    noDbInjection: true,
    noDeployExecution: true,
    deployAllowed: false,
    actualDeployExecution: false,
    noBusinessDataWrite: true,
    noCustomerSave: true,
    noSaleSave: true,
    noContractCreate: true,
    noInstallAsSave: true,
    noSettlementExecution: true,
    noCancelSettlementConfirm: true,
    noSignDocumentCreate: true,
    noFormAutoRegister: true,
    noRoleMutation: true,
    noDeleteSheet: true,
    noExistingDataClear: true,
    headerMapRequired: true,
    idBasedConnectionRequired: true,
    vendorBranchUserGroup: true,
    qrInitialEntryTargetSearchProtected: true,
    directRegularMemberLink: false,
    noOriginalSlipMutation: true,
    backupRollbackConfirmationRequired: true
  };
}

function controlErpCoreDeployFinalGateBundle_dryRun() {
  var result = {
    ok: true,
    build: CCEPDG_BUILD,
    mode: 'DRY_RUN_ONLY',
    message: 'CONTROL 배포 전 최종 게이트 계획만 확인합니다. 실제 쓰기/배포는 없습니다.',
    stages: ['FINAL_READ_ONLY_CHECK','UI_ROUTE_SMOKE_SIMULATION','PERMISSION_FILTER_SMOKE_SIMULATION','STATE_TRANSITION_SIMULATION','BACKUP_ROLLBACK_CONFIRMATION','DEPLOY_APPROVAL_REVIEW_ONLY'],
    expected: CCEPDG_EXPECTED,
    fatal: [],
    warnings: [],
    safety: controlErpCoreDeployFinalGateBundle_safety_()
  };
  Logger.log('[CONTROL ERP_CORE DEPLOY FINAL GATE DRY RUN] ' + JSON.stringify(result));
  return result;
}

function controlErpCoreDeployFinalGateBundle_runFinalReadOnlyCheck() {
  var sync = controlErpCoreDeployFinalGateBundle_runSyncCheck_();
  var fatal = [];
  var warnings = [];
  if (!sync.ok) fatal.push('ERP_CORE 생성/정책메타 동기화 점검 실패');
  var result = {
    ok: fatal.length === 0,
    build: CCEPDG_BUILD,
    mode: 'FINAL_READ_ONLY_CHECK',
    checkedAt: new Date().toISOString(),
    fatal: fatal.concat(sync.fatal || []),
    warnings: warnings.concat(sync.warnings || []),
    syncCheck: sync,
    businessDataWrite: false,
    deployAllowed: false,
    safety: controlErpCoreDeployFinalGateBundle_safety_()
  };
  Logger.log('[CONTROL ERP_CORE DEPLOY FINAL READ ONLY CHECK] ' + JSON.stringify(result));
  return result;
}

function controlErpCoreDeployFinalGateBundle_runUiRouteSmoke() {
  var checks = [];
  var fatal = [];
  for (var i = 0; i < CCEPDG_UI_ROUTES.length; i++) {
    var r = CCEPDG_UI_ROUTES[i];
    var ok = !!r.route && !!r.requiredRole && r.expected === 'ROUTE_DEFINED';
    if (!ok) fatal.push('UI route 정의 실패: ' + r.route);
    checks.push({ ok: ok, route: r.route, label: r.label, requiredRole: r.requiredRole, mode: 'SIMULATION_ONLY', actualNavigation: false, blankPageDetected: false });
  }
  var result = {
    ok: fatal.length === 0,
    build: CCEPDG_BUILD,
    mode: 'UI_ROUTE_SMOKE_SIMULATION',
    checkedAt: new Date().toISOString(),
    fatal: fatal,
    warnings: [],
    checks: checks,
    routeCount: checks.length,
    actualUiOpen: false,
    blankPageDetected: false,
    businessDataWrite: false,
    deployAllowed: false,
    safety: controlErpCoreDeployFinalGateBundle_safety_()
  };
  Logger.log('[CONTROL ERP_CORE UI ROUTE SMOKE RESULT] ' + JSON.stringify(result));
  return result;
}

function controlErpCoreDeployFinalGateBundle_runPermissionFilterSmoke() {
  var checks = [];
  var fatal = [];
  for (var i = 0; i < CCEPDG_PERMISSION_SCENARIOS.length; i++) {
    var sc = CCEPDG_PERMISSION_SCENARIOS[i];
    var ok = sc.canDeploy === false;
    if (sc.roleCode === 'VENDOR_REP' || sc.roleCode === 'SALES_STAFF') {
      ok = ok && sc.canSeeAll === false && !!sc.vendorId;
    }
    if (sc.canEditSettlement && sc.roleCode !== 'SETTLEMENT_APPROVER') ok = false;
    if (!ok) fatal.push('권한 필터 시뮬레이션 실패: ' + sc.roleCode);
    checks.push({
      ok: ok,
      roleCode: sc.roleCode,
      vendorScoped: !sc.canSeeAll,
      vendorId: sc.vendorId,
      eventId: sc.eventId,
      canSeeAll: sc.canSeeAll,
      canEditSettlement: sc.canEditSettlement,
      canDeploy: sc.canDeploy,
      actualRoleMutation: false,
      mode: 'SIMULATION_ONLY'
    });
  }
  var result = {
    ok: fatal.length === 0,
    build: CCEPDG_BUILD,
    mode: 'PERMISSION_FILTER_SMOKE_SIMULATION',
    checkedAt: new Date().toISOString(),
    fatal: fatal,
    warnings: [],
    checks: checks,
    businessDataWrite: false,
    deployAllowed: false,
    safety: controlErpCoreDeployFinalGateBundle_safety_()
  };
  Logger.log('[CONTROL ERP_CORE PERMISSION FILTER SMOKE RESULT] ' + JSON.stringify(result));
  return result;
}

function controlErpCoreDeployFinalGateBundle_runStateTransitionSimulation() {
  var checks = [];
  var fatal = [];
  for (var i = 0; i < CCEPDG_STATE_TRANSITIONS.length; i++) {
    var t = CCEPDG_STATE_TRANSITIONS[i];
    var protectedCaseOk = true;
    if (t.to === 'MUTATED_ORIGINAL_SLIP' && t.allowed !== false) protectedCaseOk = false;
    if (t.to === 'GENERAL_EDIT' && t.allowed !== false) protectedCaseOk = false;
    if (t.to === 'CANCEL_ADJUSTMENT_SLIP' && t.approvalRequired !== true) protectedCaseOk = false;
    if (!protectedCaseOk) fatal.push('상태전이 보호 실패: ' + t.domain + ' ' + t.from + ' → ' + t.to);
    checks.push({
      ok: protectedCaseOk,
      domain: t.domain,
      from: t.from,
      to: t.to,
      allowed: t.allowed,
      approvalRequired: !!t.approvalRequired,
      actualStateMutation: false,
      mode: 'SIMULATION_ONLY'
    });
  }
  var result = {
    ok: fatal.length === 0,
    build: CCEPDG_BUILD,
    mode: 'STATE_TRANSITION_SIMULATION',
    checkedAt: new Date().toISOString(),
    fatal: fatal,
    warnings: [],
    checks: checks,
    noOriginalSlipMutation: true,
    lockedGeneralEditBlocked: true,
    actualStateMutation: false,
    businessDataWrite: false,
    deployAllowed: false,
    safety: controlErpCoreDeployFinalGateBundle_safety_()
  };
  Logger.log('[CONTROL ERP_CORE STATE TRANSITION SIMULATION RESULT] ' + JSON.stringify(result));
  return result;
}

function controlErpCoreDeployFinalGateBundle_runBackupRollbackConfirmation() {
  var cfg = controlErpCoreDeployFinalGateBundle_readSystemConfig_();
  var fatal = [];
  var warnings = [];
  if (!cfg.ok) fatal.push('SystemConfig 확인 실패');
  var expectedLogSheets = ['BackupLog','DeployLog','RecoveryLog'];
  var master = cfg.ok ? controlErpCoreDeployFinalGateBundle_openMasterDb_(cfg.config) : { ok: false };
  if (!master.ok) fatal.push('FEELHAUS_DB_MASTER 연결 실패');
  var logChecks = [];
  if (master.ok && master.spreadsheet) {
    for (var i = 0; i < expectedLogSheets.length; i++) {
      var sh = master.spreadsheet.getSheetByName(expectedLogSheets[i]);
      var exists = !!sh;
      if (!exists) warnings.push(expectedLogSheets[i] + ' 시트가 없습니다. 배포 승인 전 생성/정책 확정 필요');
      logChecks.push({ sheetName: expectedLogSheets[i], exists: exists, mode: 'READ_ONLY_CHECK' });
    }
  }
  var result = {
    ok: fatal.length === 0,
    build: CCEPDG_BUILD,
    mode: 'BACKUP_ROLLBACK_CONFIRMATION_READ_ONLY',
    checkedAt: new Date().toISOString(),
    fatal: fatal,
    warnings: warnings,
    systemConfig: { ok: cfg.ok, setupDbId: cfg.setupDbId, sheetName: cfg.sheetName, error: cfg.error || '' },
    master: { ok: master.ok, masterDbId: master.masterDbId || '', masterDbName: master.masterDbName || '', error: master.error || '' },
    logSheets: logChecks,
    backupRequiredBeforeDeploy: true,
    rollbackRequiredBeforeDeploy: true,
    actualBackupRun: false,
    actualRollbackRun: false,
    businessDataWrite: false,
    deployAllowed: false,
    safety: controlErpCoreDeployFinalGateBundle_safety_()
  };
  Logger.log('[CONTROL ERP_CORE BACKUP ROLLBACK CONFIRMATION RESULT] ' + JSON.stringify(result));
  return result;
}

function controlErpCoreDeployFinalGateBundle_runAllReadOnly() {
  var finalRead = controlErpCoreDeployFinalGateBundle_runFinalReadOnlyCheck();
  var ui = controlErpCoreDeployFinalGateBundle_runUiRouteSmoke();
  var perm = controlErpCoreDeployFinalGateBundle_runPermissionFilterSmoke();
  var state = controlErpCoreDeployFinalGateBundle_runStateTransitionSimulation();
  var backup = controlErpCoreDeployFinalGateBundle_runBackupRollbackConfirmation();
  var fatal = [];
  var warnings = [];
  var stages = [finalRead, ui, perm, state, backup];
  for (var i = 0; i < stages.length; i++) {
    if (!stages[i].ok) fatal.push('최종 게이트 단계 실패: ' + stages[i].mode);
    if (stages[i].fatal && stages[i].fatal.length) fatal = fatal.concat(stages[i].fatal);
    if (stages[i].warnings && stages[i].warnings.length) warnings = warnings.concat(stages[i].warnings);
  }
  var result = {
    ok: fatal.length === 0,
    build: CCEPDG_BUILD,
    mode: 'ALL_FINAL_GATE_READ_ONLY_BUNDLE',
    checkedAt: new Date().toISOString(),
    fatal: fatal,
    warnings: warnings,
    stages: {
      finalReadOnlyCheck: finalRead,
      uiRouteSmoke: ui,
      permissionFilterSmoke: perm,
      stateTransitionSimulation: state,
      backupRollbackConfirmation: backup
    },
    deployPreApproval: {
      readyForDeployApprovalReview: fatal.length === 0,
      deployAllowed: false,
      actualDeployExecution: false,
      decision: fatal.length === 0 ? 'READY_FOR_DEPLOY_APPROVAL_REVIEW_ONLY' : 'NOT_READY'
    },
    businessDataWrite: false,
    deployAllowed: false,
    safety: controlErpCoreDeployFinalGateBundle_safety_()
  };
  Logger.log('[CONTROL ERP_CORE DEPLOY FINAL GATE ALL RESULT] ' + JSON.stringify(result));
  return result;
}

function controlErpCoreDeployFinalGateBundle_selfTest() {
  var fatal = [];
  if (CCEPDG_CORE_SHEETS.length !== 6) fatal.push('CORE sheet count expected 6');
  var headerCount = 0;
  for (var i = 0; i < CCEPDG_CORE_SHEETS.length; i++) headerCount += CCEPDG_CORE_SHEETS[i].headers.length;
  if (headerCount !== 67) fatal.push('Header count expected 67 but got ' + headerCount);
  if (CCEPDG_UI_ROUTES.length < 6) fatal.push('UI route smoke scenarios too small');
  if (CCEPDG_PERMISSION_SCENARIOS.length < 4) fatal.push('Permission scenarios too small');
  if (CCEPDG_STATE_TRANSITIONS.length < 5) fatal.push('State transition scenarios too small');
  var result = {
    ok: fatal.length === 0,
    build: CCEPDG_BUILD,
    fatal: fatal,
    warnings: [],
    expected: CCEPDG_EXPECTED,
    safety: controlErpCoreDeployFinalGateBundle_safety_()
  };
  Logger.log('[CONTROL ERP_CORE DEPLOY FINAL GATE SELFTEST] ' + JSON.stringify(result));
  return result;
}

function controlErpCoreDeployFinalGateBundle_runSyncCheck_() {
  if (typeof controlErpCorePostCreatePolicyMetaSyncCheck_run === 'function') {
    return controlErpCorePostCreatePolicyMetaSyncCheck_run();
  }
  return controlErpCoreDeployFinalGateBundle_localSyncCheck_();
}

function controlErpCoreDeployFinalGateBundle_localSyncCheck_() {
  var fatal = [];
  var warnings = [];
  var cfg = controlErpCoreDeployFinalGateBundle_readSystemConfig_();
  if (!cfg.ok) fatal.push('SystemConfig 읽기 실패');
  var master = cfg.ok ? controlErpCoreDeployFinalGateBundle_openMasterDb_(cfg.config) : { ok: false };
  if (!master.ok) fatal.push('FEELHAUS_DB_MASTER 연결 실패');
  var sheetChecks = [];
  var policyMeta = { headerPolicy: {}, sheetPolicy: {} };
  if (master.ok) {
    for (var i = 0; i < CCEPDG_CORE_SHEETS.length; i++) sheetChecks.push(controlErpCoreDeployFinalGateBundle_checkSheet_(master.spreadsheet, CCEPDG_CORE_SHEETS[i]));
    policyMeta.headerPolicy = controlErpCoreDeployFinalGateBundle_checkPolicy_(master.spreadsheet, 'HeaderPolicy', controlErpCoreDeployFinalGateBundle_expectedHeaderPolicyIds_());
    policyMeta.sheetPolicy = controlErpCoreDeployFinalGateBundle_checkPolicy_(master.spreadsheet, 'SheetPolicy', controlErpCoreDeployFinalGateBundle_expectedSheetPolicyIds_());
  }
  for (var s = 0; s < sheetChecks.length; s++) if (!sheetChecks[s].ok) fatal.push('시트 점검 실패: ' + sheetChecks[s].sheetName);
  if (policyMeta.headerPolicy && !policyMeta.headerPolicy.ok) fatal.push('HeaderPolicy 점검 실패');
  if (policyMeta.sheetPolicy && !policyMeta.sheetPolicy.ok) fatal.push('SheetPolicy 점검 실패');
  return {
    ok: fatal.length === 0,
    build: CCEPDG_BUILD,
    checkedAt: new Date().toISOString(),
    fatal: fatal,
    warnings: warnings,
    systemConfig: { ok: cfg.ok, setupDbId: cfg.setupDbId, sheetName: cfg.sheetName, error: cfg.error || '' },
    master: { ok: master.ok, masterDbId: master.masterDbId || '', masterDbName: master.masterDbName || '', error: master.error || '' },
    expected: CCEPDG_EXPECTED,
    coreSheets: sheetChecks,
    policyMeta: policyMeta,
    businessDataWrite: false,
    deployAllowed: false,
    safety: controlErpCoreDeployFinalGateBundle_safety_()
  };
}

function controlErpCoreDeployFinalGateBundle_readSystemConfig_() {
  if (typeof ccef941_1000_readSystemConfig_ === 'function') {
    return ccef941_1000_readSystemConfig_();
  }
  try {
    var ss = SpreadsheetApp.openById(CCEPDG_SETUP_DB_ID);
    var sh = ss.getSheetByName(CCEPDG_CONFIG_SHEET_NAME);
    if (!sh) return { ok: false, setupDbId: CCEPDG_SETUP_DB_ID, sheetName: CCEPDG_CONFIG_SHEET_NAME, config: {}, error: 'SystemConfig 시트를 찾을 수 없습니다.' };
    var values = sh.getDataRange().getValues();
    var config = {};
    if (values.length) {
      var header = values[0].map(function(v){ return String(v || '').trim(); });
      var keyIdx = header.indexOf('CONFIG_KEY');
      var valueIdx = header.indexOf('VALUE');
      if (keyIdx < 0) keyIdx = header.indexOf('configKey');
      if (valueIdx < 0) valueIdx = header.indexOf('value');
      if (keyIdx < 0 || valueIdx < 0) return { ok: false, setupDbId: CCEPDG_SETUP_DB_ID, sheetName: CCEPDG_CONFIG_SHEET_NAME, config: {}, error: 'CONFIG_KEY / VALUE 헤더를 찾을 수 없습니다.' };
      for (var r = 1; r < values.length; r++) {
        var k = String(values[r][keyIdx] || '').trim();
        if (k) config[k] = values[r][valueIdx];
      }
    }
    return { ok: true, setupDbId: CCEPDG_SETUP_DB_ID, sheetName: CCEPDG_CONFIG_SHEET_NAME, config: config, message: 'SystemConfig 읽기 완료' };
  } catch (e) {
    return { ok: false, setupDbId: CCEPDG_SETUP_DB_ID, sheetName: CCEPDG_CONFIG_SHEET_NAME, config: {}, error: String(e && e.message ? e.message : e) };
  }
}

function controlErpCoreDeployFinalGateBundle_openMasterDb_(config) {
  try {
    var masterId = String((config && (config.FEELHAUS_DB_MASTER_ID || config.DB_MASTER_ID || config.SPREADSHEET_ID)) || '').trim();
    if (!masterId) return { ok: false, masterDbId: '', error: 'FEELHAUS_DB_MASTER_ID / DB_MASTER_ID / SPREADSHEET_ID 설정이 없습니다.' };
    var ss = SpreadsheetApp.openById(masterId);
    return { ok: true, masterDbId: masterId, masterDbName: ss.getName(), spreadsheet: ss, message: 'FEELHAUS_DB_MASTER 연결 확인 완료' };
  } catch (e) {
    return { ok: false, masterDbId: '', error: String(e && e.message ? e.message : e) };
  }
}

function controlErpCoreDeployFinalGateBundle_checkSheet_(ss, policy) {
  var sh = ss.getSheetByName(policy.sheetName);
  if (!sh) return { ok: false, sheetName: policy.sheetName, exists: false, fatal: ['시트 없음'] };
  var lastCol = Math.max(sh.getLastColumn(), policy.headers.length);
  var headers = sh.getRange(1, 1, 1, lastCol).getValues()[0].map(function(v){ return String(v || '').trim(); }).filter(String);
  var missing = controlErpCoreDeployFinalGateBundle_missing_(policy.headers, headers);
  var dup = controlErpCoreDeployFinalGateBundle_duplicates_(headers);
  return { ok: missing.length === 0 && dup.length === 0, sheetName: policy.sheetName, exists: true, expectedHeaderCount: policy.headers.length, actualHeaderCount: headers.length, missingHeaders: missing, duplicateHeaders: dup, headerMapBuild: missing.length === 0 && dup.length === 0 ? 'PASS' : 'FAIL', fatal: missing.length || dup.length ? ['헤더 점검 실패'] : [] };
}

function controlErpCoreDeployFinalGateBundle_checkPolicy_(ss, sheetName, expectedIds) {
  var sh = ss.getSheetByName(sheetName);
  if (!sh) return { ok: false, sheetName: sheetName, exists: false, expectedRowCount: expectedIds.length, foundRowCount: 0, missingPolicyIds: expectedIds, duplicatePolicyIds: [], missingHeaders: [], fatal: ['정책 시트 없음'] };
  var values = sh.getDataRange().getValues();
  if (!values.length) return { ok: false, sheetName: sheetName, exists: true, expectedRowCount: expectedIds.length, foundRowCount: 0, missingPolicyIds: expectedIds, duplicatePolicyIds: [], missingHeaders: ['policyId'], fatal: ['정책 시트 비어 있음'] };
  var header = values[0].map(function(v){ return String(v || '').trim(); });
  var pidIdx = header.indexOf('policyId');
  var missingHeaders = pidIdx < 0 ? ['policyId'] : [];
  var found = {};
  var dup = [];
  if (pidIdx >= 0) {
    for (var i = 1; i < values.length; i++) {
      var pid = String(values[i][pidIdx] || '').trim();
      if (!pid) continue;
      if (found[pid]) dup.push(pid);
      found[pid] = true;
    }
  }
  var missing = [];
  for (var e = 0; e < expectedIds.length; e++) if (!found[expectedIds[e]]) missing.push(expectedIds[e]);
  var fatal = [];
  if (missingHeaders.length) fatal.push('policyId 헤더 누락');
  if (missing.length) fatal.push('policyId 누락');
  if (dup.length) fatal.push('policyId 중복');
  return { ok: fatal.length === 0, sheetName: sheetName, exists: true, expectedRowCount: expectedIds.length, foundRowCount: expectedIds.length - missing.length, missingPolicyIds: missing, duplicatePolicyIds: dup, missingHeaders: missingHeaders, fatal: fatal };
}

function controlErpCoreDeployFinalGateBundle_expectedHeaderPolicyIds_() {
  var ids = [];
  for (var i = 0; i < CCEPDG_CORE_SHEETS.length; i++) {
    var p = CCEPDG_CORE_SHEETS[i];
    for (var h = 0; h < p.headers.length; h++) ids.push('HEADER|' + p.sheetName + '|' + p.headers[h]);
  }
  return ids;
}

function controlErpCoreDeployFinalGateBundle_expectedSheetPolicyIds_() {
  var ids = [];
  for (var i = 0; i < CCEPDG_CORE_SHEETS.length; i++) ids.push('SHEET|' + CCEPDG_CORE_SHEETS[i].sheetName + '|');
  return ids;
}

function controlErpCoreDeployFinalGateBundle_missing_(expected, actual) {
  var set = {};
  for (var i = 0; i < actual.length; i++) set[actual[i]] = true;
  var missing = [];
  for (var e = 0; e < expected.length; e++) if (!set[expected[e]]) missing.push(expected[e]);
  return missing;
}

function controlErpCoreDeployFinalGateBundle_duplicates_(arr) {
  var seen = {}, dup = [];
  for (var i = 0; i < arr.length; i++) {
    var v = String(arr[i] || '').trim();
    if (!v) continue;
    if (seen[v] && dup.indexOf(v) < 0) dup.push(v);
    seen[v] = true;
  }
  return dup;
}
