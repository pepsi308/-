@echo off
setlocal EnableExtensions
title FEELHAUS UPLOAD CONTROL

cd /d D:\pepsi308\OneDrive\feelhaus_pull\CONTROL
if errorlevel 1 (
  echo [ERROR] CONTROL folder not found.
  pause
  exit /b 1
)

if not exist ".clasp.json" (
  echo [ERROR] .clasp.json not found in CONTROL.
  pause
  exit /b 1
)

echo ==========================================
echo CONTROL upload start
echo Current folder:
cd
echo ==========================================
echo.

clasp.cmd push 
set RC=%ERRORLEVEL%

echo.
echo ==========================================
if %RC%==0 (
  echo [OK] CONTROL upload complete
) else (
  echo [ERROR] CONTROL upload failed
  echo ERRORLEVEL=%RC%
)
echo ==========================================
echo.

pause
