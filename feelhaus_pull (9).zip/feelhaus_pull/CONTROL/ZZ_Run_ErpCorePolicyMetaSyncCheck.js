/**
 * CONTROL runner functions for ERP_CORE post-create / policy meta sync check.
 * Execute these from CONTROL Apps Script project.
 */
function runStep1_ControlErpCorePolicyMetaSyncDryRun() {
  var result = controlErpCorePostCreatePolicyMetaSyncCheck_dryRun();
  Logger.log('[CONTROL ERP_CORE POLICY META SYNC DRY RUN RESULT] ' + JSON.stringify(result, null, 2));
  return result;
}

function runStep2_ControlErpCorePolicyMetaSyncCheck() {
  var result = controlErpCorePostCreatePolicyMetaSyncCheck_run();
  Logger.log('[CONTROL ERP_CORE POLICY META SYNC CHECK RESULT] ' + JSON.stringify(result, null, 2));
  return result;
}

function runStep3_ControlErpCorePolicyMetaSyncSelfTest() {
  var result = controlErpCorePostCreatePolicyMetaSyncCheck_selfTest();
  Logger.log('[CONTROL ERP_CORE POLICY META SYNC SELFTEST RESULT] ' + JSON.stringify(result, null, 2));
  return result;
}
