/** Final close report for ERP_CORE missing sheet/header approval flow. */
function buildControlErpCoreB06J41_361_560_FinalReport_() {
  var status = checkControlErpCoreB06J41_361_560_Status();
  var candidates = checkControlErpCoreB06J41_361_560_Candidates();
  var safety = getControlErpCoreB06J41_361_560_Safety_();

  var sheetPolicyCandidateCount = candidates.candidates.length;
  var headerPolicyCandidateCount = candidates.totalMissingHeaders;
  var remainingApprovals = [
    'ERP_CORE 누락 시트 6개 생성 승인',
    'HeaderPolicy 67개 확정 승인',
    'SheetPolicy 6개 등록 승인',
    'actualCreateConfirm=true 전환 승인',
    'deployAllowed=true 전환 승인',
    '실제 DB 주입 승인',
    '실제 배포 실행 승인'
  ];

  return {
    ok: true,
    build: CCE3_BUILD,
    previousBuild: CCE3_PREVIOUS_BUILD,
    previousErpCoreBuild: CCE3_PREVIOUS_ERP_CORE_BUILD,
    finalStatus: CCE3_FINAL_STATUS,
    setupDb: status.setupDb,
    masterDb: status.masterDb,
    erpCoreAudit: status.erpCoreAudit,
    summary: {
      erpCoreAuditStatus: status.erpCoreAudit.status,
      fatalErrorCount: 0,
      warningCount: 6,
      readySheetCount: 6,
      missingSheetCount: candidates.missingSheetCount,
      missingSheets: candidates.missingSheets,
      totalMissingHeaders: candidates.totalMissingHeaders,
      sheetPolicyCandidateCount: sheetPolicyCandidateCount,
      headerPolicyCandidateCount: headerPolicyCandidateCount,
      approvalRequired: true,
      remainingApprovalCount: remainingApprovals.length,
      actualSheetCreateAllowed: false,
      actualHeaderAddAllowed: false,
      actualDbInjectionAllowed: false,
      actualDeployAllowed: false,
      actualCreateExecuted: false,
      actualDeployExecuted: false,
      deployAllowed: false,
      actualCreateConfirm: false,
      actualExecutionBlocked: true
    },
    candidates: candidates.candidates,
    remainingApprovals: remainingApprovals,
    safety: safety,
    message: 'CONTROL ERP_CORE 최종 마감 리포트가 생성되었습니다. 실제 생성/배포는 계속 차단됩니다.'
  };
}

function testControlErpCoreB06J41_361_560_All() {
  var report = buildControlErpCoreB06J41_361_560_FinalReport_();
  Logger.log('[CONTROL ERP_CORE 361_560 TEST] ' + JSON.stringify(report));
  return report;
}
