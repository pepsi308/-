/** Smoke and helper tests. */
function testControlErpCoreB06J41_361_560_Smoke() {
  var result = {
    ok: true,
    build: CCE3_BUILD,
    previousBuild: CCE3_PREVIOUS_BUILD,
    previousErpCoreBuild: CCE3_PREVIOUS_ERP_CORE_BUILD,
    functions: [
      'testControlErpCoreB06J41_361_560_All',
      'testControlErpCoreB06J41_361_560_Smoke',
      'checkControlErpCoreB06J41_361_560_Status',
      'checkControlErpCoreB06J41_361_560_Candidates',
      'assertControlErpCoreB06J41_361_560_Block'
    ],
    safety: getControlErpCoreB06J41_361_560_Safety_(),
    message: 'Smoke test completed. Final close report only; actual create/deploy remains blocked.'
  };
  Logger.log('[CONTROL ERP_CORE 361_560 SMOKE] ' + JSON.stringify(result));
  return result;
}
