// 테스트 진입 파일입니다.
// 먼저 testControlErpCoreB06J41_761_940_Smoke()
// 이후 testControlErpCoreB06J41_761_940_All() 실행
