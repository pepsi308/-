/** CONTROL CENTER B06J41 761_940 - Execute guards */
function executeControlCenterB06J41_761_940_ActualBackup(approval) {
  return ccgBlockedExecutionResult_('BACKUP', approval);
}
function executeControlCenterB06J41_761_940_ActualDeploy(approval) {
  return ccgBlockedExecutionResult_('DEPLOY', approval);
}
function executeControlCenterB06J41_761_940_ActualRollback(approval) {
  return ccgBlockedExecutionResult_('ROLLBACK', approval);
}

function ccgBlockedExecutionResult_(executionType, approval) {
  const gate = ccgValidateExecutionGate_(approval || {}, executionType);
  return {
    ok: true,
    build: CONTROL_GUARD_BUNDLE_BUILD,
    executionType,
    gate,
    actualBackupExecuted: false,
    actualDeployExecuted: false,
    actualRollbackExecuted: false,
    actualExecutionAllowed: false,
    actualExecutionBlocked: true,
    safety: ccgSafety_(),
    message: executionType + ' 실제 실행은 Safe 기준에서 차단되었습니다.'
  };
}

function checkControlCenterB06J41_761_940_ExecuteGuards() {
  const results = {
    backup: executeControlCenterB06J41_761_940_ActualBackup(ccgApprovalTemplate_('ACTUAL_BACKUP')),
    deploy: executeControlCenterB06J41_761_940_ActualDeploy(ccgApprovalTemplate_('ACTUAL_DEPLOY')),
    rollback: executeControlCenterB06J41_761_940_ActualRollback(ccgApprovalTemplate_('ACTUAL_ROLLBACK'))
  };
  return {
    ok: true,
    build: CONTROL_GUARD_BUNDLE_BUILD,
    results,
    actualBackupExecuted: false,
    actualDeployExecuted: false,
    actualRollbackExecuted: false,
    actualExecutionBlocked: true,
    safety: ccgSafety_()
  };
}
