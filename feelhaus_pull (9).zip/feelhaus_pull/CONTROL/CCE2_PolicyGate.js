/** SheetPolicy / HeaderPolicy candidates and approval gate checks. */
function checkControlErpCoreB06J41_161_360_PolicyCandidates() {
  var pre = checkControlErpCoreB06J41_161_360_Precheck();
  var sheetCandidates = [];
  var headerCandidates = [];
  (pre.sheets || []).forEach(function (s) {
    if (s.approvalRequired) {
      sheetCandidates.push({
        projectCode: CONTROL_ERP_CORE_161_360_PROJECT_CODE,
        sheetName: s.sheetName,
        workArea: s.workArea,
        policyStatus: 'CREATE_REVIEW_REQUIRED__ACTUAL_CREATE_BLOCKED',
        sheetType: 'ERP_WORK_MASTER_CANDIDATE',
        protected: true,
        deleteCandidate: false,
        archiveCandidate: false,
        approvalRequired: true,
        reason: 'ERP_CORE 실무 본체 핵심 작업 시트 후보. 새 시트라는 이유로 삭제/아카이브 금지.',
        actualPolicyWriteBlocked: true
      });
      (s.missingHeaders || []).forEach(function (h) {
        headerCandidates.push({
          projectCode: CONTROL_ERP_CORE_161_360_PROJECT_CODE,
          sheetName: s.sheetName,
          headerName: h,
          required: true,
          protected: true,
          idKey: /Id$/.test(h) || h === 'userId',
          statusKey: h === 'status' || h === 'statusReason',
          headerPolicyStatus: 'HEADER_REVIEW_REQUIRED__ACTUAL_HEADER_ADD_BLOCKED',
          actualPolicyWriteBlocked: true,
          actualHeaderAddBlocked: true
        });
      });
    }
  });
  return {
    ok: true,
    build: CONTROL_ERP_CORE_161_360_BUILD,
    sheetPolicyCandidateCount: sheetCandidates.length,
    headerPolicyCandidateCount: headerCandidates.length,
    sheetPolicyCandidates: sheetCandidates,
    headerPolicyCandidates: headerCandidates,
    safety: getControlErpCoreB06J41_161_360_Safety_(),
    message: 'SheetPolicy / HeaderPolicy 후보만 생성했습니다. 실제 정책 기록은 차단 상태입니다.'
  };
}

function evaluateControlErpCoreB06J41_161_360_Gate_(approval, mode) {
  approval = approval || {};
  mode = mode || 'CREATE';
  var reasons = [];
  if (!approval.approvalId) reasons.push('MISSING_APPROVAL_ID');
  if (!approval.approvedBy) reasons.push('MISSING_APPROVED_BY');
  if (!approval.approvedAt) reasons.push('MISSING_APPROVED_AT');
  if (approval.approvalStatus !== 'APPROVED') reasons.push('APPROVAL_STATUS_NOT_APPROVED');
  if (approval.approvalType !== 'STRUCTURE_CHANGE') reasons.push('INVALID_APPROVAL_TYPE');
  if (approval.approvalScope !== 'ERP_CORE_MISSING_SHEET_CREATE_AND_DEPLOY_PRECHECK') reasons.push('INVALID_APPROVAL_SCOPE');
  if (approval.projectCode !== CONTROL_ERP_CORE_161_360_PROJECT_CODE) reasons.push('INVALID_PROJECT_CODE');
  if (approval.controlProjectCode !== CONTROL_ERP_CORE_161_360_CONTROL_PROJECT_CODE) reasons.push('INVALID_CONTROL_PROJECT_CODE');
  if (mode === 'CREATE') {
    if (!approval.actualCreateRequested) reasons.push('NO_ACTUAL_CREATE_REQUEST');
    if (!approval.actualCreateConfirm) reasons.push('NO_ACTUAL_CREATE_CONFIRM');
    reasons.push('DEPLOY_STILL_BLOCKED');
    reasons.push('GLOBAL_ACTUAL_CREATE_FLAG_OFF');
  }
  if (mode === 'DEPLOY') {
    if (!approval.actualDeployRequested) reasons.push('NO_ACTUAL_DEPLOY_REQUEST');
    if (!approval.actualDeployConfirm) reasons.push('NO_ACTUAL_DEPLOY_CONFIRM');
    reasons.push('DEPLOY_STILL_BLOCKED');
    reasons.push('GLOBAL_ACTUAL_DEPLOY_FLAG_OFF');
  }
  var shapeReasons = reasons.filter(function (r) {
    return r !== 'DEPLOY_STILL_BLOCKED' && r !== 'GLOBAL_ACTUAL_CREATE_FLAG_OFF' && r !== 'GLOBAL_ACTUAL_DEPLOY_FLAG_OFF';
  });
  return {
    ok: false,
    blocked: true,
    mode: mode,
    blockReasons: reasons,
    gateWouldAllowIfGlobalFlagsEnabled: shapeReasons.length === 0,
    actualExecutionAllowed: false,
    message: '승인 게이트 차단: ' + reasons.join(', ')
  };
}

function checkControlErpCoreB06J41_161_360_Gates() {
  var invalid = {};
  var validShape = {};
  var tpl = getControlErpCoreB06J41_161_360_ApprovalTemplate_();
  invalid.CREATE = evaluateControlErpCoreB06J41_161_360_Gate_({}, 'CREATE');
  invalid.DEPLOY = evaluateControlErpCoreB06J41_161_360_Gate_({}, 'DEPLOY');
  validShape.CREATE = evaluateControlErpCoreB06J41_161_360_Gate_(tpl, 'CREATE');
  validShape.DEPLOY = evaluateControlErpCoreB06J41_161_360_Gate_(tpl, 'DEPLOY');
  return {
    ok: true,
    build: CONTROL_ERP_CORE_161_360_BUILD,
    invalidGateBlocked: invalid.CREATE.blocked && invalid.DEPLOY.blocked,
    validShapeGateBlocked: validShape.CREATE.blocked && validShape.DEPLOY.blocked,
    gateWouldAllowIfGlobalFlagsEnabled: validShape.CREATE.gateWouldAllowIfGlobalFlagsEnabled && validShape.DEPLOY.gateWouldAllowIfGlobalFlagsEnabled,
    actualCreateAllowed: false,
    actualDeployAllowed: false,
    invalid: invalid,
    validShape: validShape,
    safety: getControlErpCoreB06J41_161_360_Safety_()
  };
}
