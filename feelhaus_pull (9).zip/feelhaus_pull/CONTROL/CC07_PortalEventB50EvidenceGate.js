/**
 * FEELHAUS CONTROL - PORTAL EVENT B50 BACKUP/ROLLBACK EVIDENCE GATE
 * Build: CONTROL_PORTAL_EVENT_B50_BACKUP_ROLLBACK_EVIDENCE_V01
 * Target baseline: PORTAL_EVENT_B50_FINAL_STABLE_READONLY_20260611
 * Execution function: runControlPortalEventB50BackupRollbackEvidenceV01
 *
 * Safety:
 * - Diagnostic only
 * - Read-only evidence scan
 * - No sheet creation
 * - No header mutation
 * - No sheet/log/approval writing
 * - No backup/deploy/recovery/rollback execution
 * - No PORTAL save / ERP apply / field open mutation
 * - Always logs JSON_COMPACT_RESULT for Apps Script execution log copy
 */
var CC07_BUILD = 'CONTROL_PORTAL_EVENT_B50_BACKUP_ROLLBACK_EVIDENCE_V01';
var CC07_MODE = 'PORTAL_EVENT_B50_BACKUP_ROLLBACK_EVIDENCE_DIAGNOSTIC_ONLY_NO_UPDATE';
var CC07_TARGET = {
  projectCode: 'PORTAL_EVENT',
  moduleCode: 'PORTAL_EVENT_MANAGEMENT',
  buildNo: 'PORTAL_EVENT_B50_FINAL_STABLE_READONLY_20260611',
  runFunction: 'portalEventB50RunAll',
  changedOnlyFile: 'PORTAL_EVENT_B50_CHANGED_ONLY.zip',
  progress: '50 / 50',
  percent: 100
};

function runControlPortalEventB50BackupRollbackEvidenceV01() {
  var result = diagnoseControlPortalEventB50BackupRollbackEvidenceV01_();
  CC07_logCompactResult_(result);
  return result;
}

function getControlPortalEventB50BackupRollbackEvidenceData() {
  var result = diagnoseControlPortalEventB50BackupRollbackEvidenceV01_();
  CC07_logCompactResult_(result);
  return result;
}

function controlPortalEventB50BackupRollbackEvidenceV01() {
  var result = diagnoseControlPortalEventB50BackupRollbackEvidenceV01_();
  CC07_logCompactResult_(result);
  return result;
}

function CC07_logCompactResult_(result) {
  Logger.log('JSON_COMPACT_RESULT: ' + JSON.stringify(CC07_compactResult_(result)));
}

function CC07_compactResult_(result) {
  result = result || {};
  var s = result.summary || {};
  var d = result.details || {};
  var drive = d.driveEvidence || {};
  var logs = d.logEvidence || {};
  return {
    ok: result.ok === true,
    build: result.build || CC07_BUILD,
    mode: result.mode || CC07_MODE,
    checkedAt: result.checkedAt || '',
    judgement: result.judgement || 'BLOCK',
    targetBaseline: CC07_TARGET,
    summary: {
      baselineOk: s.baselineOk === true,
      configOk: s.configOk === true,
      masterOk: s.masterOk === true,
      requiredGateSheetsOk: s.requiredGateSheetsOk === true,
      requiredGateHeadersOk: s.requiredGateHeadersOk === true,
      backupEvidenceOk: s.backupEvidenceOk === true,
      rollbackEvidenceOk: s.rollbackEvidenceOk === true,
      logBackupEvidenceOk: s.logBackupEvidenceOk === true,
      logRollbackEvidenceOk: s.logRollbackEvidenceOk === true,
      driveBackupEvidenceOk: s.driveBackupEvidenceOk === true,
      driveRollbackEvidenceOk: s.driveRollbackEvidenceOk === true,
      diagnosticOnly: s.diagnosticOnly === true,
      dryRunOnly: s.dryRunOnly === true,
      actualExecutionBlocked: s.actualExecutionBlocked !== false,
      deployAllowed: s.deployAllowed === true,
      sheetWriteExecuted: s.sheetWriteExecuted === true,
      sheetCreateExecuted: s.sheetCreateExecuted === true,
      headerAutoAddExecuted: s.headerAutoAddExecuted === true,
      approvalWriteExecuted: s.approvalWriteExecuted === true,
      auditLogWriteExecuted: s.auditLogWriteExecuted === true,
      backupExecuted: s.backupExecuted === true,
      deployExecuted: s.deployExecuted === true,
      recoveryExecuted: s.recoveryExecuted === true,
      rollbackExecuted: s.rollbackExecuted === true,
      erpApplyExecuted: s.erpApplyExecuted === true,
      actualOpenExecuted: s.actualOpenExecuted === true,
      productionDataMutationExecuted: s.productionDataMutationExecuted === true
    },
    evidence: {
      missingSheets: (d.schema && d.schema.missingSheets) || [],
      totalMissingHeaders: (d.schema && d.schema.totalMissingHeaders) || 0,
      backupLogEvidenceCount: logs.backupEvidenceCount || 0,
      recoveryLogEvidenceCount: logs.recoveryEvidenceCount || 0,
      backupLogHasRollbackBaseline: logs.backupHasRollbackBaseline === true,
      driveScannedFolderCount: drive.scannedFolderCount || 0,
      driveBackupFileCount: drive.backupFileCount || 0,
      driveRollbackFileCount: drive.rollbackFileCount || 0,
      latestBackupEvidence: logs.latestBackupEvidence || drive.latestBackupEvidence || null,
      latestRollbackEvidence: logs.latestRollbackEvidence || drive.latestRollbackEvidence || null,
      actualBackupAllowed: false,
      actualDeployAllowed: false,
      actualRecoveryAllowed: false,
      actualRollbackAllowed: false,
      actualPortalSaveAllowed: false,
      actualErpApplyAllowed: false,
      actualFieldOpenAllowed: false
    },
    warnings: result.warnings || [],
    hold: result.hold || [],
    fatal: result.fatal || [],
    nextAction: result.nextAction || ''
  };
}

function diagnoseControlPortalEventB50BackupRollbackEvidenceV01_() {
  var fatal = [];
  var warnings = [];
  var hold = [];
  var summary = CC07_baseSummary_();
  var details = {
    build: CC07_BUILD,
    mode: CC07_MODE,
    checkedAt: CC_now_(),
    targetBaseline: CC07_TARGET,
    sourceDb: CC_SOURCE_DB,
    setupDbId: CC_SETUP_DB_ID,
    configSheetName: CC_CONFIG_SHEET_NAME,
    safety: CC07_safety_(),
    config: null,
    master: null,
    schema: null,
    logEvidence: null,
    driveEvidence: null,
    operationBlock: CC07_operationBlock_(),
    guidance: CC07_guidance_()
  };

  try {
    var cfgResult = CC_readSystemConfig_();
    var config = cfgResult && cfgResult.config ? cfgResult.config : {};
    summary.configOk = !!(cfgResult && cfgResult.ok);
    details.config = {
      ok: summary.configOk,
      sourceDb: CC_SOURCE_DB,
      setupDbId: CC_SETUP_DB_ID,
      configSheetName: CC_CONFIG_SHEET_NAME,
      message: cfgResult && cfgResult.message ? cfgResult.message : ''
    };
    if (!summary.configOk) fatal.push('SystemConfig 자동 읽기 실패');

    var masterId = CC_resolveMasterDbId_(config);
    if (!masterId) {
      summary.masterOk = false;
      fatal.push('FEELHAUS_DB_MASTER ID를 SystemConfig에서 찾지 못했습니다.');
      return CC07_result_(summary, fatal, warnings, hold, details);
    }

    var masterSs = SpreadsheetApp.openById(masterId);
    summary.masterOk = !!masterSs;
    details.master = {
      ok: summary.masterOk,
      masterDbId: masterId,
      masterDbName: masterSs ? masterSs.getName() : ''
    };
    if (!summary.masterOk) fatal.push('FEELHAUS_DB_MASTER 연결 실패');

    summary.baselineOk = CC07_checkBaseline_().ok;
    if (!summary.baselineOk) fatal.push('PORTAL_EVENT_B50 기준선 불일치');

    details.schema = CC07_checkEvidenceSchemas_(masterSs);
    summary.requiredGateSheetsOk = details.schema.ok && details.schema.missingSheets.length === 0;
    summary.requiredGateHeadersOk = details.schema.totalMissingHeaders === 0;
    if (!summary.requiredGateSheetsOk) fatal.push('증빙 게이트 필수 로그 시트 누락: ' + details.schema.missingSheets.join(', '));
    if (!summary.requiredGateHeadersOk) fatal.push('증빙 게이트 필수 헤더 누락 합계: ' + details.schema.totalMissingHeaders);

    details.logEvidence = CC07_scanLogEvidence_(masterSs);
    summary.logBackupEvidenceOk = details.logEvidence.backupEvidenceOk === true;
    summary.logRollbackEvidenceOk = details.logEvidence.rollbackEvidenceOk === true;

    details.driveEvidence = CC07_scanDriveEvidence_(config);
    summary.driveBackupEvidenceOk = details.driveEvidence.backupEvidenceOk === true;
    summary.driveRollbackEvidenceOk = details.driveEvidence.rollbackEvidenceOk === true;

    summary.backupEvidenceOk = summary.logBackupEvidenceOk || summary.driveBackupEvidenceOk;
    summary.rollbackEvidenceOk = summary.logRollbackEvidenceOk || summary.driveRollbackEvidenceOk || details.logEvidence.backupHasRollbackBaseline === true;

    if (!summary.backupEvidenceOk) hold.push('PORTAL_EVENT_B50 배포 전 백업 생성 증빙이 BackupLog 또는 Drive 보관 위치에서 확인되지 않았습니다.');
    if (!summary.rollbackEvidenceOk) hold.push('PORTAL_EVENT_B50 롤백 기준 파일 또는 rollbackBaselineId 증빙이 RecoveryLog/BackupLog/Drive 보관 위치에서 확인되지 않았습니다.');

    return CC07_result_(summary, fatal, warnings, hold, details);
  } catch (err) {
    fatal.push(String(err && err.message ? err.message : err));
    return CC07_result_(summary, fatal, warnings, hold, details);
  }
}

function CC07_baseSummary_() {
  return {
    ok: false,
    judgement: 'BLOCK',
    baselineOk: false,
    configOk: false,
    masterOk: false,
    requiredGateSheetsOk: false,
    requiredGateHeadersOk: false,
    backupEvidenceOk: false,
    rollbackEvidenceOk: false,
    logBackupEvidenceOk: false,
    logRollbackEvidenceOk: false,
    driveBackupEvidenceOk: false,
    driveRollbackEvidenceOk: false,
    diagnosticOnly: true,
    dryRunOnly: true,
    actualExecutionBlocked: true,
    deployAllowed: false,
    sheetWriteExecuted: false,
    sheetCreateExecuted: false,
    headerAutoAddExecuted: false,
    menuRegistryWriteExecuted: false,
    auditLogWriteExecuted: false,
    timelineWriteExecuted: false,
    approvalWriteExecuted: false,
    backupExecuted: false,
    deployExecuted: false,
    recoveryExecuted: false,
    rollbackExecuted: false,
    erpApplyExecuted: false,
    actualOpenExecuted: false,
    productionDataMutationExecuted: false
  };
}

function CC07_safety_() {
  var s = CC_getSafety_();
  s.diagnosticOnly = true;
  s.dryRunOnly = true;
  s.actualExecutionBlocked = true;
  s.deployAllowed = false;
  s.noSheetWrite = true;
  s.noSheetCreate = true;
  s.noHeaderAutoAdd = true;
  s.noApprovalWrite = true;
  s.noAuditLogWrite = true;
  s.noActualBackup = true;
  s.noActualDeploy = true;
  s.noActualRecovery = true;
  s.noActualRollback = true;
  s.noErpApply = true;
  s.noFieldOpenExecution = true;
  return s;
}

function CC07_checkBaseline_() {
  return {
    ok: CC07_TARGET.projectCode === 'PORTAL_EVENT' &&
      CC07_TARGET.buildNo === 'PORTAL_EVENT_B50_FINAL_STABLE_READONLY_20260611' &&
      CC07_TARGET.changedOnlyFile === 'PORTAL_EVENT_B50_CHANGED_ONLY.zip' &&
      CC07_TARGET.percent === 100,
    targetBaseline: CC07_TARGET,
    registeredInDiagnosticResultOnly: true,
    sheetWriteExecuted: false
  };
}

function CC07_checkEvidenceSchemas_(masterSs) {
  var specs = [
    { name: 'ApprovalLog', required: ['approvalId', 'approvalStatus', 'approvedBy', 'approvedAt', 'targetAction', 'relatedBuild', 'status'] },
    { name: 'BackupLog', required: ['backupId', 'projectCode', 'buildRange', 'backupStatus', 'backupStartedAt', 'executedBy', 'rollbackBaselineId', 'status'] },
    { name: 'DeployLog', required: ['deployId', 'projectCode', 'buildNo', 'deployStatus', 'approvalId', 'backupId', 'rollbackBaselineId', 'status'] },
    { name: 'RecoveryLog', required: ['recoveryId', 'rollbackBaselineId', 'projectCode', 'baselineBuild', 'rollbackScope', 'rollbackAllowed', 'reason', 'recoveryStatus', 'status'] }
  ];
  var missingSheets = [];
  var totalMissingHeaders = 0;
  var sheets = [];
  specs.forEach(function (spec) {
    var sheet = masterSs.getSheetByName(spec.name);
    var headerMap = sheet ? CC_headerMap_(sheet) : {};
    var missing = [];
    spec.required.forEach(function (h) { if (!headerMap[h]) missing.push(h); });
    if (!sheet) missingSheets.push(spec.name);
    totalMissingHeaders += missing.length;
    sheets.push({
      sheetName: spec.name,
      exists: !!sheet,
      rowCount: sheet ? CC_countRows_(sheet) : 0,
      requiredHeaderCount: spec.required.length,
      currentHeaderCount: sheet ? sheet.getLastColumn() : 0,
      missingHeaderCount: missing.length,
      missingHeaders: missing,
      ok: !!sheet && missing.length === 0,
      actualCreateBlocked: true,
      actualHeaderAddBlocked: true,
      actualWriteBlocked: true
    });
  });
  return {
    ok: missingSheets.length === 0 && totalMissingHeaders === 0,
    masterDbName: masterSs.getName(),
    missingSheets: missingSheets,
    totalMissingHeaders: totalMissingHeaders,
    sheets: sheets,
    message: '증빙 게이트 필수 로그 구조를 조회만 했습니다. 생성/수정/헤더추가는 차단입니다.'
  };
}

function CC07_scanLogEvidence_(masterSs) {
  var backupRows = CC_getRowsAsObjects_(masterSs.getSheetByName('BackupLog'));
  var recoveryRows = CC_getRowsAsObjects_(masterSs.getSheetByName('RecoveryLog'));
  var backupHits = [];
  var recoveryHits = [];

  backupRows.forEach(function (row) {
    if (CC07_isB50RelatedRow_(row)) backupHits.push(row);
  });
  recoveryRows.forEach(function (row) {
    if (CC07_isB50RelatedRow_(row)) recoveryHits.push(row);
  });

  var backupHasRollbackBaseline = backupHits.some(function (row) { return String(row.rollbackBaselineId || '').trim() !== ''; });
  return {
    ok: backupHits.length > 0 && (recoveryHits.length > 0 || backupHasRollbackBaseline),
    backupEvidenceOk: backupHits.length > 0,
    rollbackEvidenceOk: recoveryHits.length > 0 || backupHasRollbackBaseline,
    backupEvidenceCount: backupHits.length,
    recoveryEvidenceCount: recoveryHits.length,
    backupHasRollbackBaseline: backupHasRollbackBaseline,
    latestBackupEvidence: backupHits.length ? CC07_pickSafeEvidence_(backupHits[backupHits.length - 1]) : null,
    latestRollbackEvidence: recoveryHits.length ? CC07_pickSafeEvidence_(recoveryHits[recoveryHits.length - 1]) : null,
    sheetWriteExecuted: false,
    backupExecutedByThisGate: false,
    rollbackExecutedByThisGate: false,
    message: 'BackupLog/RecoveryLog에서 PORTAL_EVENT_B50 증빙을 조회만 했습니다.'
  };
}

function CC07_scanDriveEvidence_(config) {
  var folderKeys = [
    'BACKUP_PORTAL_FOLDER_ID',
    'BACKUP_FOLDER_ID',
    'BACKUP_DB_FOLDER_ID',
    'BACKUP_ERP_FOLDER_ID',
    'PORTAL_APP_FOLDER_ID',
    'EXPORT_FOLDER_ID'
  ];
  var scannedFolders = [];
  var backupFiles = [];
  var rollbackFiles = [];
  folderKeys.forEach(function (key) {
    var folderId = String(config[key] || '').trim();
    if (!folderId) return;
    var folderInfo = { key: key, folderIdPreview: CC07_previewId_(folderId), ok: false, fileScanCount: 0, error: '' };
    try {
      var folder = DriveApp.getFolderById(folderId);
      folderInfo.ok = true;
      var files = folder.getFiles();
      var scanLimit = 80;
      while (files.hasNext() && folderInfo.fileScanCount < scanLimit) {
        var file = files.next();
        folderInfo.fileScanCount++;
        var name = file.getName();
        var upper = String(name || '').toUpperCase();
        var related = CC07_isB50Text_(upper);
        if (related) {
          var safe = CC07_safeDriveFile_(file, key);
          if (CC07_isBackupFileName_(upper)) backupFiles.push(safe);
          if (CC07_isRollbackFileName_(upper)) rollbackFiles.push(safe);
          if (!CC07_isBackupFileName_(upper) && !CC07_isRollbackFileName_(upper)) backupFiles.push(safe);
        }
      }
    } catch (err) {
      folderInfo.error = String(err && err.message ? err.message : err);
    }
    scannedFolders.push(folderInfo);
  });
  return {
    ok: backupFiles.length > 0 && rollbackFiles.length > 0,
    backupEvidenceOk: backupFiles.length > 0,
    rollbackEvidenceOk: rollbackFiles.length > 0,
    scannedFolderCount: scannedFolders.length,
    backupFileCount: backupFiles.length,
    rollbackFileCount: rollbackFiles.length,
    scannedFolders: scannedFolders,
    latestBackupEvidence: backupFiles.length ? backupFiles[backupFiles.length - 1] : null,
    latestRollbackEvidence: rollbackFiles.length ? rollbackFiles[rollbackFiles.length - 1] : null,
    driveWriteExecuted: false,
    fileCreated: false,
    fileDeleted: false,
    message: 'SystemConfig의 백업/보관 후보 폴더를 DriveApp으로 조회만 했습니다. 파일 생성/삭제/이동은 하지 않습니다.'
  };
}

function CC07_isB50RelatedRow_(row) {
  var text = CC07_rowText_(row);
  return CC07_isB50Text_(text) ||
    String(row.projectCode || row.sourceProject || '').toUpperCase() === 'PORTAL_EVENT' ||
    String(row.projectCode || row.sourceProject || '').toUpperCase() === 'PORTAL_EVENT_MANAGEMENT';
}

function CC07_isB50Text_(text) {
  text = String(text || '').toUpperCase();
  return text.indexOf('PORTAL_EVENT_B50') >= 0 ||
    text.indexOf('B50_FINAL_STABLE') >= 0 ||
    text.indexOf('PORTAL_EVENT_B50_CHANGED_ONLY') >= 0 ||
    text.indexOf('PORTAL_EVENT_MANAGEMENT') >= 0;
}

function CC07_isBackupFileName_(upper) {
  upper = String(upper || '').toUpperCase();
  return upper.indexOf('BACKUP') >= 0 || upper.indexOf('BKP') >= 0 || upper.indexOf('CHANGED_ONLY') >= 0 || upper.indexOf('.ZIP') >= 0;
}

function CC07_isRollbackFileName_(upper) {
  upper = String(upper || '').toUpperCase();
  return upper.indexOf('ROLLBACK') >= 0 || upper.indexOf('BASELINE') >= 0 || upper.indexOf('RESTORE') >= 0 || upper.indexOf('RECOVERY') >= 0;
}

function CC07_safeDriveFile_(file, folderKey) {
  return {
    folderKey: folderKey,
    fileId: file.getId(),
    fileName: file.getName(),
    mimeType: file.getMimeType(),
    updatedAt: file.getLastUpdated ? file.getLastUpdated().toISOString() : '',
    urlMasked: 'https://drive.google.com/file/d/***/view'
  };
}

function CC07_pickSafeEvidence_(row) {
  return {
    approvalId: row.approvalId || '',
    backupId: row.backupId || '',
    deployId: row.deployId || '',
    recoveryId: row.recoveryId || '',
    rollbackBaselineId: row.rollbackBaselineId || '',
    projectCode: row.projectCode || row.sourceProject || '',
    buildNo: row.buildNo || row.buildRange || row.relatedBuild || row.baselineBuild || '',
    status: row.status || row.backupStatus || row.deployStatus || row.recoveryStatus || '',
    createdAt: row.createdAt || row.backupStartedAt || row.startedAt || ''
  };
}

function CC07_rowText_(row) {
  var parts = [];
  Object.keys(row || {}).forEach(function (k) { parts.push(String(k || '')); parts.push(String(row[k] || '')); });
  return parts.join(' ').toUpperCase();
}

function CC07_previewId_(id) {
  id = String(id || '');
  if (id.length <= 10) return id;
  return id.slice(0, 5) + '...' + id.slice(-4);
}

function CC07_operationBlock_() {
  return {
    ok: true,
    actualExecutionBlocked: true,
    deployAllowed: false,
    actualBackupAllowed: false,
    actualDeployAllowed: false,
    actualRecoveryAllowed: false,
    actualRollbackAllowed: false,
    actualPortalSaveAllowed: false,
    actualErpApplyAllowed: false,
    actualFieldOpenAllowed: false,
    policy: '증빙 확인 단계에서도 실제 백업/배포/복구/롤백/운영 저장/ERP 반영/현장 오픈은 모두 차단합니다.'
  };
}

function CC07_result_(summary, fatal, warnings, hold, details) {
  var blocked = fatal && fatal.length > 0;
  var holding = !blocked && hold && hold.length > 0;
  summary.ok = !blocked;
  summary.judgement = blocked ? 'BLOCK' : (holding ? 'HOLD' : 'PASS');
  summary.deployAllowed = false;
  summary.actualExecutionBlocked = true;
  return {
    ok: summary.ok,
    build: CC07_BUILD,
    mode: CC07_MODE,
    checkedAt: CC_now_(),
    judgement: summary.judgement,
    targetBaseline: CC07_TARGET,
    summary: summary,
    warnings: warnings || [],
    hold: hold || [],
    fatal: fatal || [],
    details: details,
    nextAction: CC07_nextAction_(summary.judgement)
  };
}

function CC07_nextAction_(judgement) {
  if (judgement === 'PASS') return 'PORTAL_EVENT_B50 백업/롤백 증빙 확인 PASS. CONTROL B50 배포 전 진단 게이트를 재실행해 PASS 전환 여부를 확인하세요. 실제 운영 실행은 여전히 별도 승인 전까지 금지입니다.';
  if (judgement === 'HOLD') return 'PORTAL_EVENT_B50 백업/롤백 증빙 HOLD. 기준 zip 백업 파일과 롤백 baseline 파일 또는 rollbackBaselineId 증빙을 보관한 뒤 재진단하세요.';
  return 'PORTAL_EVENT_B50 백업/롤백 증빙 BLOCK. SystemConfig, MASTER, 로그 구조 또는 Drive 폴더 권한을 먼저 확인하세요.';
}

function CC07_guidance_() {
  return {
    pageTitle: 'PORTAL 행사관리 B50 백업/롤백 증빙 진단',
    mainStatusText: 'BackupLog/RecoveryLog와 SystemConfig 백업 폴더에서 PORTAL_EVENT_B50 백업 및 롤백 증빙을 조회합니다.',
    successText: '백업/롤백 증빙 진단을 완료했습니다.',
    holdText: '증빙이 부족하면 HOLD를 유지하고 운영 전환하지 않습니다.',
    errorText: '증빙 진단 중 BLOCK 항목이 발생했습니다.',
    readonlyText: '이번 게이트는 조회 전용입니다. 파일 생성, 시트쓰기, 백업/복구/롤백/배포 실행을 하지 않습니다.'
  };
}
