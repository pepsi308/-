function assertControlErpCoreB06J41_081_160_Block() {
  var safety = cceB06J41_081_160_getSafety_();
  var blocked = !!(
    safety.noSheetCreate &&
    safety.noSheetWrite &&
    safety.noHeaderAutoAdd &&
    safety.noDbInjection &&
    safety.noActualDeploy &&
    safety.noActualRecovery &&
    safety.noActualRollback &&
    safety.noSettlementExecution &&
    safety.noPaymentExecution &&
    safety.noRoleMutation &&
    safety.actualExecutionBlocked &&
    safety.deployAllowed === false &&
    safety.actualCreateConfirm === false
  );
  return {
    ok: blocked,
    build: CCE_B06J41_081_160.BUILD,
    deployAllowed: false,
    actualCreateConfirm: false,
    actualExecutionBlocked: true,
    actualSheetCreateAllowed: false,
    actualHeaderAddAllowed: false,
    actualDbInjectionAllowed: false,
    actualDeployAllowed: false,
    actualRecoveryAllowed: false,
    actualRollbackAllowed: false,
    protectedSheetDeleteAllowed: false,
    archiveByNewSheetReasonAllowed: false,
    safety: safety,
    message: blocked ? '실제 생성/헤더추가/DB주입/배포/복구/롤백 차단 정상' : '차단 설정 이상 감지'
  };
}
