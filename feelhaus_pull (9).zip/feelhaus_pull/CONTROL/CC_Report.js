/** FEELHAUS CONTROL CENTER - Report */
function CC_buildLogCandidates_(projectCode) {
  var now = CC_now_();
  return {
    ok: true,
    dryRun: true,
    projectCode: projectCode,
    candidates: {
      backup: {
        backupId: CC_uuid_('BKP-' + projectCode),
        projectCode: projectCode,
        buildRange: projectCode + '_SAFE_BASELINE',
        sourceDb: 'FEELHAUS_SETUP_DB',
        targetDb: 'FEELHAUS_DB_MASTER_BACKUP_CANDIDATE_DRYRUN',
        backupScope: JSON.stringify({ scripts: ['CONTROL CENTER Safe baseline'], sheets: ['ApprovalLog','BackupLog','RecoveryLog','DeployLog'], blockedActions: ['NO_ACTUAL_BACKUP','NO_SHEET_WRITE'] }),
        backupStatus: 'DRYRUN_READY__ACTUAL_BACKUP_BLOCKED',
        backupStartedAt: now,
        backupCompletedAt: '',
        executedBy: Session.getActiveUser().getEmail(),
        relatedDeployId: '',
        rollbackBaselineId: CC_uuid_('BASELINE-' + projectCode),
        notes: 'DryRun only. Actual backup blocked.'
      },
      recovery: {
        recoveryId: CC_uuid_('RCV-' + projectCode),
        rollbackBaselineId: CC_uuid_('BASELINE-' + projectCode),
        projectCode: projectCode,
        baselineBuild: CC_BUILD,
        rollbackScope: JSON.stringify({ scope: ['script baseline','sheet baseline','log baseline'], blockedActions: ['NO_ACTUAL_ROLLBACK'] }),
        rollbackAllowed: false,
        createdAt: now,
        createdBy: Session.getActiveUser().getEmail(),
        reason: 'DryRun rollback baseline candidate.'
      },
      deploy: {
        deployId: CC_uuid_('DPL-' + projectCode),
        projectCode: projectCode,
        buildNo: CC_BUILD,
        deployLevel: 'SAFE_BASELINE_DRYRUN',
        deployStatus: 'DRYRUN_READY__ACTUAL_DEPLOY_BLOCKED',
        approvedBy: '',
        approvalId: '',
        backupId: CC_uuid_('BKP-' + projectCode),
        rollbackBaselineId: CC_uuid_('BASELINE-' + projectCode),
        startedAt: now,
        completedAt: '',
        result: 'NOT_EXECUTED__DRYRUN_ONLY',
        notes: 'Actual deploy blocked.'
      }
    },
    actualWriteAllowed: false,
    actualWriteExecuted: false,
    safety: CC_getSafety_()
  };
}

function testControlCenterFullB06J41_All() {
  var setup, master;
  try {
    setup = CC_readSystemConfig_();
    master = CC_openMasterDb_();
  } catch (err) {
    var fail = { ok: false, build: CC_BUILD, error: String(err && err.message || err), actualExecutionBlocked: true };
    Logger.log('[CONTROL FULL SAFE FAIL] ' + JSON.stringify(fail));
    return fail;
  }
  var schema = CC_checkLogSchemas_();
  var portalErpSignCounts;
  try { portalErpSignCounts = CC_getPortalErpSignCounts_(); } catch (e) { portalErpSignCounts = { ok: false, error: String(e.message || e) }; }
  var result = {
    ok: true,
    build: CC_BUILD,
    finalStatus: 'CONTROL_CENTER_FULL_SAFE_BASELINE_PASSED__EXECUTION_BLOCKED',
    setupDb: setup,
    masterDb: { ok: true, masterDbId: master.masterDbId, masterDbName: master.masterDbName, message: 'FEELHAUS_DB_MASTER 연결 확인 완료' },
    statuses: {
      SIGN: CC_getSignFinalStatus_(),
      PORTAL_SIGN: CC_getPortalSignFinalStatus_(),
      PORTAL_ERP_SIGN: CC_getPortalErpSignFinalStatus_()
    },
    portalErpSignCounts: portalErpSignCounts,
    schema: schema,
    createPlan: CC_createPlan_(),
    gates: {
      SIGN: CC_buildGateCandidate_('SIGN'),
      PORTAL_SIGN: CC_buildGateCandidate_('PORTAL_SIGN'),
      PORTAL_ERP_SIGN: CC_buildGateCandidate_('PORTAL_ERP_SIGN')
    },
    logCandidates: {
      SIGN: CC_buildLogCandidates_('SIGN'),
      PORTAL_SIGN: CC_buildLogCandidates_('PORTAL_SIGN'),
      PORTAL_ERP_SIGN: CC_buildLogCandidates_('PORTAL_ERP_SIGN')
    },
    safeLinks: CC_checkSafeLinks_(),
    safety: CC_getSafety_(),
    summary: {
      missingSheets: schema.missingSheets,
      totalMissingHeaders: schema.totalMissingHeaders,
      deployAllowed: false,
      actualExecutionBlocked: true,
      actualCreateAllowed: false,
      actualBackupAllowed: false,
      actualDeployAllowed: false,
      actualRollbackAllowed: false
    }
  };
  Logger.log('[CONTROL FULL SAFE TEST] ' + JSON.stringify(result));
  return result;
}
