/**
 * CONTROL CENTER B06J41 941_1000 FINAL DEPLOY CONTROL CLOSE REPORT SAFE
 * Safe report only. No sheet write, no backup, no deploy, no rollback.
 */
var CONTROL_FINAL_941_1000_BUILD = 'CONTROL_CENTER_B06J41_941_1000_FINAL_DEPLOY_CONTROL_CLOSE_REPORT_SAFE';
var CONTROL_FINAL_941_1000_PREVIOUS = 'CONTROL_CENTER_B06J41_761_940_BACKUP_DEPLOY_ROLLBACK_GUARD_BUNDLE_SAFE';

function getControlFinal9411000BuildInfo_() {
  return {
    ok: true,
    build: CONTROL_FINAL_941_1000_BUILD,
    previousBuild: CONTROL_FINAL_941_1000_PREVIOUS,
    buildDesc: 'CONTROL CENTER 최종 배포통제 마감 리포트 Safe 빌드',
    sourceDb: 'FEELHAUS_SETUP_DB',
    setupDbId: '17VMSpgSZCvIrUlgcw8yCNcnl8WQWo2IcRf5tDCcuJGM',
    configSheetName: 'SystemConfig',
    deployAllowed: false,
    actualExecutionBlocked: true,
    createdAt: Utilities.formatDate(new Date(), 'Asia/Seoul', "yyyy-MM-dd'T'HH:mm:ssXXX")
  };
}

function getControlFinal9411000Safety_() {
  return {
    dryRunOnly: true,
    finalCloseReportOnly: true,
    deployAllowed: false,
    actualBackupGlobalEnabled: false,
    actualDeployGlobalEnabled: false,
    actualRollbackGlobalEnabled: false,
    noSheetCreate: true,
    noSheetWrite: true,
    noHeaderAutoAdd: true,
    noPolicyWrite: true,
    noApprovalWrite: true,
    noActualBackup: true,
    noActualDeploy: true,
    noActualRollback: true,
    noPortalCardMutation: true,
    noSignDocumentMutation: true,
    noPdfGeneration: true,
    noQrUrlMutation: true,
    noSettlementExecution: true,
    noPaymentExecution: true,
    noRecoveryExecution: true,
    noExternalIntegration: true,
    actualExecutionBlocked: true
  };
}

function openControlFinal9411000SetupDb_() {
  var info = getControlFinal9411000BuildInfo_();
  var ss = SpreadsheetApp.openById(info.setupDbId);
  var sheet = ss.getSheetByName(info.configSheetName);
  if (!sheet) throw new Error('SystemConfig 시트를 찾을 수 없습니다.');
  return { ss: ss, sheet: sheet };
}

function readControlFinal9411000SystemConfig_() {
  var opened = openControlFinal9411000SetupDb_();
  var values = opened.sheet.getDataRange().getValues();
  var config = {};
  for (var r = 1; r < values.length; r++) {
    var key = String(values[r][0] || '').trim();
    var val = values[r][1];
    if (key) config[key] = val;
  }
  return {
    ok: true,
    setupDbId: getControlFinal9411000BuildInfo_().setupDbId,
    setupDbName: opened.ss.getName(),
    sourceDb: 'FEELHAUS_SETUP_DB',
    sheetName: 'SystemConfig',
    config: config,
    message: 'SystemConfig 읽기 완료'
  };
}

function openControlFinal9411000MasterDb_(config) {
  var masterId = config.FEELHAUS_DB_MASTER_ID || config.DB_MASTER_ID || config.SPREADSHEET_ID;
  if (!masterId) throw new Error('FEELHAUS_DB_MASTER_ID / DB_MASTER_ID / SPREADSHEET_ID 설정이 없습니다.');
  var ss = SpreadsheetApp.openById(masterId);
  return {
    ok: true,
    masterDbId: masterId,
    masterDbName: ss.getName(),
    ss: ss,
    message: 'FEELHAUS_DB_MASTER 연결 확인 완료'
  };
}

function getControlFinal9411000HeaderMap_(sheet) {
  if (!sheet) return {};
  var lastCol = sheet.getLastColumn();
  if (lastCol < 1) return {};
  var headers = sheet.getRange(1, 1, 1, lastCol).getValues()[0];
  var map = {};
  headers.forEach(function(h, i) {
    var key = String(h || '').trim();
    if (key) map[key] = i + 1;
  });
  return map;
}
