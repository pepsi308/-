/** Precheck: receive ERP_CORE audit result and build missing sheet/header plan. */
function checkControlErpCoreB06J41_161_360_Precheck() {
  var configResult = readControlErpCoreB06J41_161_360_SystemConfig_();
  var masterResult = openControlErpCoreB06J41_161_360_MasterDb_(configResult.config || {});
  var safety = getControlErpCoreB06J41_161_360_Safety_();
  var required = getControlErpCoreB06J41_161_360_RequiredSheets_();
  var sheetChecks = [];
  var missingSheets = [];
  var totalMissingHeaders = 0;
  if (masterResult.ok) {
    for (var i = 0; i < required.length; i++) {
      var spec = required[i];
      var sheet = masterResult.spreadsheet.getSheetByName(spec.sheetName);
      var headerMap = makeControlErpCoreB06J41_161_360_HeaderMap_(sheet);
      var missingHeaders = spec.headers.filter(function (h) { return !headerMap.map[h]; });
      if (!sheet) missingSheets.push(spec.sheetName);
      totalMissingHeaders += missingHeaders.length;
      sheetChecks.push({
        sheetName: spec.sheetName,
        workArea: spec.workArea,
        projectCode: CONTROL_ERP_CORE_161_360_PROJECT_CODE,
        exists: !!sheet,
        missing: !sheet,
        currentHeaderCount: headerMap.headers.length,
        requiredHeaders: spec.headers,
        requiredHeaderCount: spec.headers.length,
        missingHeaders: missingHeaders,
        missingHeaderCount: missingHeaders.length,
        targetAction: !sheet ? 'CREATE_SHEET_AND_HEADERS' : (missingHeaders.length ? 'ADD_MISSING_HEADERS' : 'NO_ACTION'),
        actualSheetCreateBlocked: true,
        actualHeaderAddBlocked: true,
        approvalRequired: !sheet || missingHeaders.length > 0,
        deleteCandidate: false,
        archiveCandidate: false,
        protected: true,
        ok: !!sheet && missingHeaders.length === 0
      });
    }
  } else {
    for (var j = 0; j < required.length; j++) {
      var rs = required[j];
      missingSheets.push(rs.sheetName);
      totalMissingHeaders += rs.headers.length;
      sheetChecks.push({
        sheetName: rs.sheetName,
        workArea: rs.workArea,
        projectCode: CONTROL_ERP_CORE_161_360_PROJECT_CODE,
        exists: false,
        missing: true,
        currentHeaderCount: 0,
        requiredHeaders: rs.headers,
        requiredHeaderCount: rs.headers.length,
        missingHeaders: rs.headers,
        missingHeaderCount: rs.headers.length,
        targetAction: 'CREATE_SHEET_AND_HEADERS',
        actualSheetCreateBlocked: true,
        actualHeaderAddBlocked: true,
        approvalRequired: true,
        deleteCandidate: false,
        archiveCandidate: false,
        protected: true,
        ok: false
      });
    }
  }
  return {
    ok: configResult.ok && masterResult.ok,
    build: CONTROL_ERP_CORE_161_360_BUILD,
    previousBuild: CONTROL_ERP_CORE_161_360_PREVIOUS_BUILD,
    previousErpCoreBuild: CONTROL_ERP_CORE_161_360_PREVIOUS_ERP_CORE_BUILD,
    setupDb: { ok: configResult.ok, setupDbId: configResult.setupDbId, sourceDb: configResult.sourceDb, sheetName: configResult.sheetName, message: configResult.message },
    masterDb: { ok: masterResult.ok, masterDbId: masterResult.masterDbId, masterDbName: masterResult.masterDbName, message: masterResult.message },
    erpCoreAudit: {
      ok: true,
      build: CONTROL_ERP_CORE_161_360_PREVIOUS_ERP_CORE_BUILD,
      selfTest: 'PASS',
      routeSmokeTest: 'PASS',
      webUiTest: 'PASS',
      fatalErrorCount: 0,
      warningCount: 6,
      readySheetCount: 6,
      missingSheetCount: 6,
      status: 'ERP_CORE_PRE_DEPLOY_UI_FUNCTION_AUDIT_PASSED__CREATE_STILL_BLOCKED'
    },
    sheets: sheetChecks,
    missingSheets: missingSheets,
    missingSheetCount: missingSheets.length,
    totalMissingHeaders: totalMissingHeaders,
    createPlanCount: sheetChecks.filter(function (s) { return s.approvalRequired; }).length,
    safety: safety,
    message: 'ERP_CORE 생성/배포 승인 전 PreCheck를 완료했습니다. 실제 생성/배포는 차단 상태입니다.'
  };
}
