/** FEELHAUS CONTROL CENTER - PORTAL ERP SIGN status */
function CC_getPortalErpSignFinalStatus_() {
  return {
    ok: true,
    projectCode: 'PORTAL_ERP_SIGN',
    sourceBuildRange: 'PORTAL_ERP_SIGN_161_300',
    portalErpSignBuilds: [
      'PORTAL_ERP_SIGN_B06J41_161_200_ADMIN_STATUS_LINK_SAFE',
      'PORTAL_ERP_SIGN_B06J41_201_300_HUB_APPEND_FINAL_CLOSE_SAFE'
    ],
    portalErpSignFinalStatus: 'PORTAL_ERP_SIGN_STATUS_LINK_161_300_FINAL_CLOSE_PASSED__DEPLOY_STILL_BLOCKED',
    deployAllowed: false,
    actualExecutionBlocked: true,
    message: 'PORTAL ERP SIGN 상태 표시 최종 상태 수신 완료. 실제 실행 차단 유지.'
  };
}

function CC_getPortalErpSignCounts_() {
  var master = CC_openMasterDb_();
  var docSheet = master.ss.getSheetByName('SIGN_Documents');
  var queueSheet = master.ss.getSheetByName('SIGN_SettlementHandoffQueue');
  var docs = CC_getRowsAsObjects_(docSheet);
  var queue = CC_getRowsAsObjects_(queueSheet);

  var totalDocs = docs.length;
  var archiveCompleted = 0;
  var reopenCandidates = 0;
  docs.forEach(function (d) {
    var archive = d.archiveStatus || d.status || d.documentStatus || '';
    if (CC_statusEquals_(archive, ['archiveCompleted','ARCHIVE_COMPLETED','보관완료','locked','LOCKED'])) archiveCompleted++;
    var reopen = d.reopenCandidate || d.reopenStatus || d.reopenAllowed || '';
    var statusReason = d.statusReason || '';
    if (CC_statusEquals_(reopen, ['true','Y','YES','candidate','CANDIDATE','재오픈후보']) || String(statusReason).indexOf('재오픈') >= 0) reopenCandidates++;
  });

  var handoffCandidates = 0;
  queue.forEach(function (q) {
    var s = q.status || q.handoffStatus || q.requestStatus || '';
    if (!s || !CC_statusEquals_(s, ['completed','COMPLETED','done','DONE','완료','cancelled','CANCELLED'])) handoffCandidates++;
  });

  return {
    ok: true,
    masterDbName: master.masterDbName,
    sheets: {
      SIGN_Documents: { exists: !!docSheet, rowCount: totalDocs, headerMap: CC_headerMap_(docSheet) },
      SIGN_SettlementHandoffQueue: { exists: !!queueSheet, rowCount: queue.length, headerMap: CC_headerMap_(queueSheet) }
    },
    counts: {
      signDocuments: totalDocs,
      archiveCompleted: archiveCompleted,
      reopenCandidates: reopenCandidates,
      settlementHandoffCandidates: handoffCandidates
    },
    note: 'FEELHAUS_DB_MASTER 실제 조회 기준. 하드코딩하지 않음.'
  };
}

function testControlPortalErpSignB06J41_001_100_All() {
  var result = {
    ok: true,
    build: 'CONTROL_PORTAL_ERP_SIGN_B06J41_001_100_STATUS_BACKUP_GATE_SAFE',
    replacementBuild: CC_BUILD,
    status: CC_getPortalErpSignFinalStatus_(),
    counts: CC_getPortalErpSignCounts_(),
    schema: CC_checkLogSchemas_(),
    links: CC_checkSafeLinks_(),
    gate: CC_buildGateCandidate_('PORTAL_ERP_SIGN'),
    logs: CC_buildLogCandidates_('PORTAL_ERP_SIGN'),
    safety: CC_getSafety_(),
    finalStatus: 'CONTROL_PORTAL_ERP_SIGN_001_100_STATUS_BACKUP_GATE_PASSED__DEPLOY_STILL_BLOCKED'
  };
  Logger.log('[CONTROL PORTAL ERP SIGN SAFE TEST] ' + JSON.stringify(result));
  return result;
}

function executeControlPortalErpSignB06J41_001_100_ActualCreate(approval) {
  return CC_blockedActualExecution_('PORTAL_ERP_SIGN', approval);
}
