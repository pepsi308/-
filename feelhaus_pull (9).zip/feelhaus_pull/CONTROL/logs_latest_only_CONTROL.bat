@echo off
chcp 65001 >nul
setlocal EnableExtensions EnableDelayedExpansion

title [ERP] 실시간 로그 확인 + 최신 파일 1개 저장

REM ======================================================
REM FEELHAUS ERP Apps Script 실시간 로그 저장용 - 1개 파일 방식
REM - 화면 출력 + 파일 저장을 동시에 수행합니다.
REM - 저장 위치: 현재 BAT 파일 위치\logs\CONTROL_latest.log
REM - 실행할 때마다 CONTROL_latest.log 를 새로 덮어씁니다.
REM ======================================================

cd /d "%~dp0"

if not exist "logs" mkdir "logs"

set "LOG_DIR=%CD%\logs"
set "LATEST_FILE=%LOG_DIR%\CONTROL_latest.log"

echo ======================================================
echo [ERP 프로젝트 로그 스트리밍 중...]
echo 최신 로그 파일 1개만 저장: %LATEST_FILE%
echo 실행할 때마다 CONTROL_latest.log 를 새로 덮어씁니다.
echo 중지: Ctrl + C
echo ======================================================
echo.

echo ======================================================> "%LATEST_FILE%"
echo [ERP 최신 로그 시작] %DATE% %TIME%>> "%LATEST_FILE%"
echo 저장 파일: %LATEST_FILE%>> "%LATEST_FILE%"
echo ======================================================>> "%LATEST_FILE%"

REM clasp 위치 확인
where clasp.cmd >nul 2>nul
if errorlevel 1 (
  where clasp >nul 2>nul
  if errorlevel 1 (
    echo [ERROR] clasp 명령을 찾지 못했습니다. Node.js / @google/clasp 설치 또는 PATH를 확인하세요.
    echo [ERROR] clasp 명령을 찾지 못했습니다.>> "%LATEST_FILE%"
    pause
    exit /b 1
  )
)

REM 실시간 출력 + 최신 파일 1개 저장
powershell -NoProfile -ExecutionPolicy Bypass -Command ^
  "$ErrorActionPreference='Continue';" ^
  "$OutputEncoding=[Console]::OutputEncoding=[System.Text.Encoding]::UTF8;" ^
  "$latest='%LATEST_FILE%';" ^
  "& clasp.cmd logs --watch 2>&1 | ForEach-Object {" ^
  "  $line = [string]$_;" ^
  "  Write-Host $line;" ^
  "  Add-Content -Path $latest -Value $line -Encoding UTF8;" ^
  "}"

echo.
echo ======================================================
echo [로그 스트리밍 종료]
echo 최신 로그 파일: %LATEST_FILE%
echo ======================================================
pause
