function checkControlErpCoreB06J41_081_160_PolicyJudge() {
  var missing = checkControlErpCoreB06J41_081_160_MissingSheets();
  var safety = cceB06J41_081_160_getSafety_();
  if (!missing.ok) return { ok: false, build: CCE_B06J41_081_160.BUILD, missing: missing, safety: safety };
  var sheetPolicyCandidates = missing.candidates.map(function (c) {
    return {
      projectCode: CCE_B06J41_081_160.PROJECT_CODE,
      sheetName: c.sheetName,
      workArea: c.workArea,
      policyStatus: 'CREATE_REVIEW_REQUIRED__ACTUAL_CREATE_BLOCKED',
      sheetType: 'ERP_WORK_MASTER_CANDIDATE',
      protected: true,
      deleteCandidate: false,
      archiveCandidate: false,
      approvalRequired: true,
      reason: 'ERP_CORE 실무 본체 핵심 작업 시트 후보. 새 시트라는 이유로 삭제/아카이브 금지.',
      actualPolicyWriteBlocked: true
    };
  });
  var headerPolicyCandidates = [];
  missing.candidates.forEach(function (c) {
    c.requiredHeaders.forEach(function (h) {
      headerPolicyCandidates.push({
        projectCode: CCE_B06J41_081_160.PROJECT_CODE,
        sheetName: c.sheetName,
        headerName: h,
        required: true,
        idKey: /Id$/.test(h) || h === 'userId',
        statusKey: h === 'status' || h === 'statusReason',
        headerPolicyStatus: c.missingHeaders.indexOf(h) >= 0 ? 'HEADER_REVIEW_REQUIRED__ACTUAL_ADD_BLOCKED' : 'HEADER_PRESENT_OR_REVIEWED',
        actualHeaderAddBlocked: true,
        actualPolicyWriteBlocked: true
      });
    });
  });
  return {
    ok: true,
    build: CCE_B06J41_081_160.BUILD,
    sheetPolicyCandidateCount: sheetPolicyCandidates.length,
    headerPolicyCandidateCount: headerPolicyCandidates.length,
    sheetPolicyCandidates: sheetPolicyCandidates,
    headerPolicyCandidates: headerPolicyCandidates,
    protectedSheetDeleteExcluded: true,
    newSheetArchiveExcluded: true,
    approvalRequired: true,
    safety: safety,
    message: 'SheetPolicy / HeaderPolicy 후보만 생성했습니다. 실제 정책 기록은 차단 상태입니다.'
  };
}
