function getControlFinal9411000PassedBuilds_() {
  return [
    { code: 'CONTROL_FULL', build: 'CONTROL_CENTER_B06J41_FULL_REPLACE_SAFE_BASELINE', status: 'PASSED__EXECUTION_BLOCKED' },
    { code: 'CONTROL_BACKUP_PRECHECK', build: 'CONTROL_CENTER_B06J41_701_760_ACTUAL_BACKUP_APPROVAL_PRECHECK_SAFE', status: 'SMOKE_PASSED__ALL_PENDING_OR_PASSED_BY_OPERATOR' },
    { code: 'CONTROL_GUARD_BUNDLE', build: 'CONTROL_CENTER_B06J41_761_940_BACKUP_DEPLOY_ROLLBACK_GUARD_BUNDLE_SAFE', status: 'PASSED__EXECUTION_STILL_BLOCKED' },
    { code: 'SIGN', build: 'SIGN_B06J41_336_350_FINAL_CLOSE_REPORT_SAFE_UPLOAD', status: 'SIGN_OPERATION_ENHANCEMENT_181_350_FINAL_CLOSE_REPORT_PASSED__DEPLOY_STILL_BLOCKED' },
    { code: 'PORTAL_SIGN', build: 'PS_B06J41_201_300_FINAL_AUDIT_CLOSE_SAFE', status: 'PORTAL_SIGN_STATUS_LINK_001_300_FINAL_AUDIT_PASSED__DEPLOY_STILL_BLOCKED' },
    { code: 'PORTAL_ERP_SIGN', build: 'PORTAL_ERP_SIGN_B06J41_201_300_HUB_APPEND_FINAL_CLOSE_SAFE', status: 'PORTAL_ERP_SIGN_STATUS_LINK_161_300_FINAL_CLOSE_PASSED__DEPLOY_STILL_BLOCKED' }
  ];
}

function getControlFinal9411000SheetStatus_(masterSs) {
  var required = {
    ApprovalLog: ['approvalId','projectCode','controlProjectCode','approvalType','approvalScope','approvalStatus','approvedBy','approvedAt','requestedBy','requestedAt','targetSheetName','targetAction','relatedBuild','relatedDeployId','reason','status','statusReason','createdAt','createdBy','updatedAt','updatedBy','notes'],
    BackupLog: ['backupId','projectCode','buildRange','sourceDb','targetDb','backupScope','backupStatus','backupStartedAt','backupCompletedAt','executedBy','relatedDeployId','rollbackBaselineId','notes'],
    RecoveryLog: ['recoveryId','rollbackBaselineId','projectCode','baselineBuild','rollbackScope','rollbackAllowed','createdAt','createdBy','reason'],
    DeployLog: ['deployId','projectCode','buildNo','deployLevel','deployStatus','approvedBy','approvalId','backupId','rollbackBaselineId','startedAt','completedAt','result','notes']
  };
  var sheets = [];
  var missingSheets = [];
  var totalMissingHeaders = 0;
  Object.keys(required).forEach(function(name) {
    var sheet = masterSs.getSheetByName(name);
    var exists = !!sheet;
    var map = exists ? getControlFinal9411000HeaderMap_(sheet) : {};
    var missingHeaders = required[name].filter(function(h) { return !map[h]; });
    if (!exists) missingSheets.push(name);
    totalMissingHeaders += missingHeaders.length;
    sheets.push({
      sheetName: name,
      exists: exists,
      requiredHeaderCount: required[name].length,
      currentHeaderCount: Object.keys(map).length,
      missingHeaderCount: missingHeaders.length,
      missingHeaders: missingHeaders,
      ok: exists && missingHeaders.length === 0,
      actualCreateBlocked: true,
      actualHeaderAddBlocked: true
    });
  });
  return { ok: true, sheets: sheets, missingSheets: missingSheets, totalMissingHeaders: totalMissingHeaders };
}

function getControlFinal9411000ExecutionSummary_() {
  return {
    backup: {
      possibleAsDryRun: true,
      actualAllowed: false,
      actualExecuted: false,
      reason: 'deployAllowed=false, actualBackupGlobalEnabled=false, approval/confirm required'
    },
    deploy: {
      possibleAsDryRun: true,
      actualAllowed: false,
      actualExecuted: false,
      reason: 'deployAllowed=false, actualDeployGlobalEnabled=false, approval/confirm required'
    },
    rollback: {
      possibleAsDryRun: true,
      actualAllowed: false,
      actualExecuted: false,
      reason: 'deployAllowed=false, actualRollbackGlobalEnabled=false, approval/confirm required'
    }
  };
}
