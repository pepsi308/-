/** CONTROL CENTER B06J41 761_940 - Report */
function testControlCenterB06J41_761_940_All() {
  const config = ccgReadSystemConfig_();
  const master = ccgOpenMasterDb_(config.config);
  const precheck = checkControlCenterB06J41_761_940_Precheck();
  const gates = checkControlCenterB06J41_761_940_Gates();
  const guards = checkControlCenterB06J41_761_940_ExecuteGuards();
  const result = {
    ok: true,
    build: CONTROL_GUARD_BUNDLE_BUILD,
    previousBuild: CONTROL_GUARD_BUNDLE_PREVIOUS_BUILD,
    finalStatus: 'CONTROL_CENTER_BACKUP_DEPLOY_ROLLBACK_GUARD_BUNDLE_PASSED__EXECUTION_STILL_BLOCKED',
    setupDb: {
      ok: true,
      setupDbId: CONTROL_SETUP_DB_ID,
      sourceDb: CONTROL_SOURCE_DB,
      sheetName: CONTROL_CONFIG_SHEET_NAME,
      message: config.message
    },
    masterDb: {
      ok: true,
      masterDbId: master.masterDbId,
      masterDbName: master.masterDbName,
      message: master.message
    },
    summary: {
      missingSheets: precheck.missingSheets,
      totalMissingHeaders: precheck.totalMissingHeaders,
      backupFolderCandidateCount: precheck.backupFolderCandidates.length,
      invalidGateBlocked: gates.invalidGateBlocked,
      validShapeGateBlocked: gates.validShapeGateBlocked,
      gateWouldAllowIfGlobalFlagsEnabled: gates.gateWouldAllowIfGlobalFlagsEnabled,
      actualBackupExecuted: false,
      actualDeployExecuted: false,
      actualRollbackExecuted: false,
      deployAllowed: false,
      actualExecutionBlocked: true
    },
    checks: { precheck, gates, guards },
    safety: ccgSafety_()
  };
  Logger.log('[CONTROL GUARD 761_940 TEST] ' + JSON.stringify(result));
  return result;
}
