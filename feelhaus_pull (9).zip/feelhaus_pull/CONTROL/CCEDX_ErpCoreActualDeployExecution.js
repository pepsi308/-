/**
 * CONTROL_ERP_CORE_ACTUAL_DEPLOY_EXECUTION_SAFE
 * Purpose:
 *  - Final safe execution step after deployAllowed and actualDeployApproval gates.
 *  - Records an approved deployment execution event in DeployLog.
 *  - DOES NOT mutate operational URL, does NOT switch Apps Script version,
 *    does NOT write ERP business data, and does NOT change permissions.
 *
 * Important:
 *  Apps Script web-app deployment/version publishing is not performed by this
 *  function. This build creates the CONTROL-side execution record and final
 *  post-execution verification only.
 */
var CCEDX_BUILD = 'CONTROL_ERP_CORE_ACTUAL_DEPLOY_EXECUTION_SAFE';
var CCEDX_APPROVAL_CODE = 'CONTROL_ERP_CORE_ACTUAL_DEPLOY_EXECUTE_APPROVED_FINAL_ONLY';
var CCEDX_REQUIRED_PRE_APPROVAL_CODE = 'CONTROL_ERP_CORE_ACTUAL_DEPLOY_APPROVED_EXECUTION_GATE_ONLY';
var CCEDX_SETUP_DB_ID = '17VMSpgSZCvIrUlgcw8yCNcnl8WQWo2IcRf5tDCcuJGM';
var CCEDX_CONFIG_SHEET_NAME = 'SystemConfig';

function ccedx_safety_() {
  return {
    build: CCEDX_BUILD,
    actualDeployExecutionGate: true,
    deployLogWriteOnly: true,
    allowedWriteSheets: ['DeployLog'],
    noOperationalUrlMutation: true,
    noVersionSwitch: true,
    noAppsScriptPublish: true,
    noSheetCreate: true,
    noHeaderAutoAdd: true,
    noPolicyWrite: true,
    noDbInjection: true,
    noBusinessDataWrite: true,
    noCustomerSave: true,
    noSaleSave: true,
    noContractCreate: true,
    noInstallAsSave: true,
    noSettlementExecution: true,
    noCancelSettlementConfirm: true,
    noSignDocumentCreate: true,
    noFormAutoRegister: true,
    noRoleMutation: true,
    noDeleteSheet: true,
    noExistingDataClear: true,
    headerMapRequired: true,
    idBasedConnectionRequired: true,
    vendorBranchUserGroup: true,
    qrInitialEntryTargetSearchProtected: true,
    directRegularMemberLink: false,
    noOriginalSlipMutation: true,
    backupRollbackConfirmationRequired: true
  };
}

function ccedx_expected_() {
  return {
    requiredLogSheets: ['BackupLog', 'DeployLog', 'RecoveryLog'],
    deployLogRequiredHeaders: ['logId','deployId','buildName','projectName','deployStatus','deployAllowed','approvalId','approvedBy','approvedAt','deployedAt','version','status','statusReason','createdAt','createdBy','updatedAt','updatedBy'],
    requiredApprovalCode: CCEDX_APPROVAL_CODE,
    requiredPreviousApprovalCode: CCEDX_REQUIRED_PRE_APPROVAL_CODE,
    projectName: 'ERP_CORE',
    deployStatus: 'SAFE_EXECUTION_RECORDED_NO_URL_MUTATION'
  };
}

function ccedx_dryRun(ctx) {
  return {
    ok: true,
    build: CCEDX_BUILD,
    mode: 'DRY_RUN_ONLY',
    message: '실제 배포 실행 안전 계획만 확인합니다. 운영 URL/버전 전환/업무 데이터 저장은 없습니다.',
    stages: [
      'VERIFY_ACTUAL_DEPLOY_APPROVAL_GATE',
      'VERIFY_FINAL_GATE_READ_ONLY',
      'VERIFY_LOG_SHEETS',
      'WRITE_DEPLOYLOG_EXECUTION_RECORD_ONLY',
      'POST_EXECUTION_CHECK'
    ],
    expected: ccedx_expected_(),
    fatal: [],
    warnings: [],
    safety: ccedx_safety_(),
    ctx: ctx || {}
  };
}

function ccedx_execute(ctx) {
  ctx = ctx || {};
  var required = {
    actualDeployConfirm: true,
    approvalCode: CCEDX_APPROVAL_CODE,
    deployAllowed: true,
    actualDeployApprovalReady: true,
    deployLogWriteAllowed: true,
    businessDataWriteAllowed: false,
    operationalUrlMutationAllowed: false,
    versionSwitchAllowed: false
  };

  if (ctx.actualDeployConfirm !== true) return ccedx_blocked_('actualDeployConfirm=true 승인이 없습니다.', required);
  if (ctx.approvalCode !== CCEDX_APPROVAL_CODE) return ccedx_blocked_('승인코드가 일치하지 않습니다.', required);
  if (ctx.deployAllowed !== true) return ccedx_blocked_('deployAllowed=true 상태만 허용합니다.', required);
  if (ctx.actualDeployApprovalReady !== true) return ccedx_blocked_('actualDeployApprovalReady=true 상태만 허용합니다.', required);
  if (ctx.deployLogWriteAllowed !== true) return ccedx_blocked_('DeployLog 기록 승인(deployLogWriteAllowed=true)이 없습니다.', required);
  if (ctx.businessDataWriteAllowed !== false) return ccedx_blocked_('businessDataWriteAllowed=false 상태만 허용합니다.', required);
  if (ctx.operationalUrlMutationAllowed !== false) return ccedx_blocked_('운영 URL 변경은 이 빌드에서 금지됩니다.', required);
  if (ctx.versionSwitchAllowed !== false) return ccedx_blocked_('버전 전환은 이 빌드에서 금지됩니다.', required);

  var prereq = ccedx_verifyPrerequisites_(ctx);
  if (!prereq.ok) {
    return {
      ok: false,
      blocked: true,
      build: CCEDX_BUILD,
      action: 'ACTUAL_DEPLOY_EXECUTION_SAFE_RECORD_ONLY',
      reason: '실제 배포 실행 전제조건 미충족',
      prerequisites: prereq,
      actualDeployExecution: false,
      deployAllowed: true,
      businessDataWrite: false,
      operationalUrlMutation: false,
      versionSwitch: false,
      fatal: prereq.fatal || [],
      warnings: prereq.warnings || [],
      safety: ccedx_safety_()
    };
  }

  var logWrite = ccedx_appendDeployLog_(ctx, prereq);
  var post = ccedx_postExecutionCheck({ deployId: logWrite.deployId });
  var fatal = [].concat(logWrite.fatal || [], post.fatal || []);
  var warnings = [].concat(prereq.warnings || [], logWrite.warnings || [], post.warnings || []);

  return {
    ok: fatal.length === 0 && logWrite.ok === true && post.ok === true,
    build: CCEDX_BUILD,
    action: 'ACTUAL_DEPLOY_EXECUTION_SAFE_RECORD_ONLY',
    message: 'CONTROL DeployLog에 안전 배포 실행 기록을 남겼습니다. 운영 URL 변경/버전 전환은 수행하지 않았습니다.',
    deployId: logWrite.deployId,
    logId: logWrite.logId,
    actualDeployExecution: true,
    deployAllowed: true,
    businessDataWrite: false,
    operationalUrlMutation: false,
    versionSwitch: false,
    appsScriptPublish: false,
    deployLogWrite: logWrite,
    postExecutionCheck: post,
    nextRequired: [
      '운영 URL/Apps Script 버전 전환이 필요한 경우 별도 수동 배포 승인 필요',
      '배포 후 실제 UI 진입 스모크',
      '운영 데이터 저장 오픈 전 별도 승인'
    ],
    fatal: fatal,
    warnings: warnings,
    safety: ccedx_safety_()
  };
}

function ccedx_verifyPrerequisites_(ctx) {
  var fatal = [];
  var warnings = [];
  var actualDeployApproval = null;
  var finalGate = null;
  var logs = null;

  try {
    if (typeof cceda_execute === 'function') {
      actualDeployApproval = cceda_execute({
        actualDeployConfirm: true,
        approvalCode: CCEDX_REQUIRED_PRE_APPROVAL_CODE,
        deployAllowed: true,
        actualDeployExecution: false,
        businessDataWriteAllowed: false,
        from: CCEDX_BUILD
      });
    } else {
      fatal.push('실제 배포 승인 게이트 함수(cceda_execute)를 찾을 수 없습니다.');
    }
  } catch (err) {
    fatal.push('실제 배포 승인 게이트 재검증 실패: ' + ccedx_err_(err));
  }

  if (actualDeployApproval && actualDeployApproval.ok !== true) fatal.push('실제 배포 승인 게이트가 PASS가 아닙니다.');
  if (actualDeployApproval && actualDeployApproval.actualDeployApprovalReady !== true) fatal.push('actualDeployApprovalReady=true가 확인되지 않았습니다.');
  if (actualDeployApproval && actualDeployApproval.actualDeployExecution !== false) fatal.push('승인 게이트에서 actualDeployExecution=false가 유지되지 않았습니다.');
  if (actualDeployApproval && actualDeployApproval.warnings && actualDeployApproval.warnings.length) warnings = warnings.concat(actualDeployApproval.warnings);

  try {
    if (typeof controlErpCoreDeployFinalGateBundle_runAllReadOnly === 'function') {
      finalGate = controlErpCoreDeployFinalGateBundle_runAllReadOnly({ from: CCEDX_BUILD });
    } else if (typeof ccepdg_allReadOnlyBundle === 'function') {
      finalGate = ccepdg_allReadOnlyBundle({ from: CCEDX_BUILD });
    } else {
      fatal.push('최종 게이트 전체 점검 함수를 찾을 수 없습니다.');
    }
  } catch (err2) {
    fatal.push('최종 게이트 전체 점검 실패: ' + ccedx_err_(err2));
  }

  if (finalGate && finalGate.ok !== true) fatal.push('CONTROL 최종 게이트가 PASS가 아닙니다.');
  if (finalGate && finalGate.fatal && finalGate.fatal.length) fatal = fatal.concat(finalGate.fatal);
  if (finalGate && finalGate.warnings && finalGate.warnings.length) warnings = warnings.concat(finalGate.warnings);

  logs = ccedx_checkRequiredLogSheets_();
  if (!logs.ok) fatal.push('BackupLog / DeployLog / RecoveryLog 확인 실패');

  return {
    ok: fatal.length === 0,
    build: CCEDX_BUILD,
    checkedAt: new Date().toISOString(),
    fatal: fatal,
    warnings: warnings,
    actualDeployApproval: actualDeployApproval,
    finalGate: finalGate,
    logSheets: logs,
    safety: ccedx_safety_()
  };
}

function ccedx_checkRequiredLogSheets_() {
  var ss = null;
  var fatal = [];
  var sheets = [];
  try {
    ss = ccedx_openMaster_();
  } catch (err) {
    return { ok: false, fatal: ['MASTER 열기 실패: ' + ccedx_err_(err)], sheets: [] };
  }
  ccedx_expected_().requiredLogSheets.forEach(function(name) {
    var sh = ss.getSheetByName(name);
    var exists = !!sh;
    sheets.push({ sheetName: name, exists: exists, mode: 'READ_ONLY_CHECK' });
    if (!exists) fatal.push(name + ' 시트가 없습니다.');
  });
  return { ok: fatal.length === 0, fatal: fatal, sheets: sheets };
}

function ccedx_appendDeployLog_(ctx, prereq) {
  var fatal = [];
  var warnings = [];
  var ss = null;
  var deployId = 'DEPLOY_' + Utilities.formatDate(new Date(), Session.getScriptTimeZone(), 'yyyyMMddHHmmss');
  var logId = 'LOG_' + deployId;
  try {
    ss = ccedx_openMaster_();
  } catch (err) {
    return { ok: false, fatal: ['MASTER 열기 실패: ' + ccedx_err_(err)], warnings: warnings, deployId: deployId, logId: logId };
  }
  var sh = ss.getSheetByName('DeployLog');
  if (!sh) {
    return { ok: false, fatal: ['DeployLog 시트를 찾을 수 없습니다.'], warnings: warnings, deployId: deployId, logId: logId };
  }
  var headers = sh.getRange(1, 1, 1, sh.getLastColumn()).getValues()[0].map(function(v){ return String(v || '').trim(); });
  var required = ccedx_expected_().deployLogRequiredHeaders;
  var missing = required.filter(function(h){ return headers.indexOf(h) < 0; });
  if (missing.length) {
    return { ok: false, fatal: ['DeployLog 필수 헤더 누락: ' + missing.join(', ')], warnings: warnings, deployId: deployId, logId: logId };
  }
  var now = new Date().toISOString();
  var user = '';
  try { user = Session.getActiveUser().getEmail() || ''; } catch (e) { user = ''; }
  var rowObj = {
    logId: logId,
    deployId: deployId,
    buildName: CCEDX_BUILD,
    projectName: 'ERP_CORE',
    deployStatus: 'SAFE_EXECUTION_RECORDED_NO_URL_MUTATION',
    deployAllowed: true,
    approvalId: ctx.approvalCode,
    approvedBy: user,
    approvedAt: now,
    deployedAt: now,
    version: String(ctx.version || 'NO_VERSION_SWITCH_SAFE_RECORD_ONLY'),
    status: 'RECORDED',
    statusReason: 'ACTUAL_DEPLOY_EXECUTION_SAFE_RECORD_ONLY|NO_URL_MUTATION|NO_VERSION_SWITCH',
    createdAt: now,
    createdBy: user,
    updatedAt: now,
    updatedBy: user
  };
  var row = headers.map(function(h){ return rowObj.hasOwnProperty(h) ? rowObj[h] : ''; });
  sh.appendRow(row);
  return {
    ok: true,
    mode: 'APPEND_DEPLOYLOG_RECORD_ONLY',
    sheetName: 'DeployLog',
    deployId: deployId,
    logId: logId,
    rowNumber: sh.getLastRow(),
    operationalUrlMutation: false,
    versionSwitch: false,
    businessDataWrite: false,
    fatal: [],
    warnings: warnings
  };
}

function ccedx_postExecutionCheck(ctx) {
  ctx = ctx || {};
  var fatal = [];
  var warnings = [];
  var ss = null;
  try {
    ss = ccedx_openMaster_();
  } catch (err) {
    return { ok: false, fatal: ['MASTER 열기 실패: ' + ccedx_err_(err)], warnings: warnings };
  }
  var sh = ss.getSheetByName('DeployLog');
  if (!sh) fatal.push('DeployLog 시트를 찾을 수 없습니다.');
  var found = [];
  if (sh && ctx.deployId) {
    var data = sh.getDataRange().getValues();
    var headers = data[0].map(function(v){ return String(v || '').trim(); });
    var deployIdx = headers.indexOf('deployId');
    var statusIdx = headers.indexOf('deployStatus');
    var buildIdx = headers.indexOf('buildName');
    for (var i = 1; i < data.length; i++) {
      if (String(data[i][deployIdx] || '') === String(ctx.deployId)) {
        found.push({
          rowNumber: i + 1,
          deployId: data[i][deployIdx],
          deployStatus: statusIdx >= 0 ? data[i][statusIdx] : '',
          buildName: buildIdx >= 0 ? data[i][buildIdx] : ''
        });
      }
    }
    if (found.length !== 1) fatal.push('DeployLog 기록 수 불일치: ' + found.length);
  }
  return {
    ok: fatal.length === 0,
    build: CCEDX_BUILD,
    mode: 'ACTUAL_DEPLOY_EXECUTION_POST_CHECK',
    checkedAt: new Date().toISOString(),
    deployId: ctx.deployId || '',
    foundCount: found.length,
    records: found,
    fatal: fatal,
    warnings: warnings,
    actualDeployExecution: true,
    operationalUrlMutation: false,
    versionSwitch: false,
    businessDataWrite: false,
    deployAllowed: true,
    safety: ccedx_safety_()
  };
}

function ccedx_openMaster_() {
  if (typeof ccef_getMasterSpreadsheet === 'function') {
    var ss = ccef_getMasterSpreadsheet();
    if (ss && typeof ss.getSheetByName === 'function') return ss;
  }
  if (typeof cce3_getMasterSpreadsheet === 'function') {
    var ss2 = cce3_getMasterSpreadsheet();
    if (ss2 && typeof ss2.getSheetByName === 'function') return ss2;
  }
  if (typeof ccedag_openMaster_ === 'function') {
    var ss3 = ccedag_openMaster_();
    if (ss3 && typeof ss3.getSheetByName === 'function') return ss3;
  }

  var setup = SpreadsheetApp.openById(CCEDX_SETUP_DB_ID);
  var sh = setup.getSheetByName(CCEDX_CONFIG_SHEET_NAME);
  if (!sh) throw new Error('SystemConfig 시트를 찾을 수 없습니다.');
  var values = sh.getDataRange().getValues();
  if (!values || values.length < 2) throw new Error('SystemConfig 데이터가 비어 있습니다.');
  var headers = values[0].map(String);
  var keyIdx = headers.indexOf('CONFIG_KEY') >= 0 ? headers.indexOf('CONFIG_KEY') : headers.indexOf('key');
  var valIdx = headers.indexOf('VALUE') >= 0 ? headers.indexOf('VALUE') : headers.indexOf('value');
  if (keyIdx < 0 || valIdx < 0) throw new Error('SystemConfig CONFIG_KEY/VALUE 헤더를 찾을 수 없습니다.');
  var cfg = {};
  for (var i = 1; i < values.length; i++) {
    var k = String(values[i][keyIdx] || '').trim();
    var v = String(values[i][valIdx] || '').trim();
    if (k) cfg[k] = v;
  }
  var masterId = String(cfg.FEELHAUS_DB_MASTER_ID || cfg.DB_MASTER_ID || cfg.SPREADSHEET_ID || '').trim();
  if (!masterId) throw new Error('FEELHAUS_DB_MASTER_ID / DB_MASTER_ID / SPREADSHEET_ID 설정이 없습니다.');
  return SpreadsheetApp.openById(masterId);
}

function ccedx_blocked_(reason, required) {
  return {
    ok: false,
    blocked: true,
    build: CCEDX_BUILD,
    action: 'ACTUAL_DEPLOY_EXECUTION_SAFE_RECORD_ONLY',
    reason: reason,
    required: required,
    actualDeployExecution: false,
    deployAllowed: false,
    businessDataWrite: false,
    operationalUrlMutation: false,
    versionSwitch: false,
    safety: ccedx_safety_()
  };
}

function ccedx_selfTest() {
  return {
    ok: true,
    build: CCEDX_BUILD,
    fatal: [],
    warnings: [],
    expected: ccedx_expected_(),
    approvalCode: CCEDX_APPROVAL_CODE,
    safety: ccedx_safety_()
  };
}

function ccedx_err_(err) {
  return err && err.message ? err.message : String(err);
}
