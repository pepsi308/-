function checkControlErpCoreB06J41_761_940_FinalGate(){
  var ctx=cce4BaseContext_();
  var invalidApproval={};
  var validShapeApproval={approvalId:'APR-ERP-CORE-CREATE-FINAL-DRYRUN',approvedBy:'MAIN_DEVELOPER',approvedAt:cce4Now_(),approvalStatus:'APPROVED',approvalType:'ERP_CORE_CREATE_DEPLOY_FINAL_GATE',approvalScope:'ERP_CORE_CREATE_DEPLOY',projectCode:'ERP_CORE',controlProjectCode:'CONTROL',actualCreateRequest:true,actualCreateConfirm:true,actualDeployRequest:true,actualDeployConfirm:true,actualDbInjectionRequest:true,actualDbInjectionConfirm:true};
  var invalidGate=cce4EvaluateFinalGate_(invalidApproval,ctx.safety);
  var validShapeGate=cce4EvaluateFinalGate_(validShapeApproval,ctx.safety);
  return {ok:true,build:CCE4_BUILD,invalidGate:invalidGate,validShapeGate:validShapeGate,invalidGateBlocked:invalidGate.blocked===true,validShapeGateBlocked:validShapeGate.blocked===true,gateWouldAllowIfGlobalFlagsEnabled:validShapeGate.gateWouldAllowIfGlobalFlagsEnabled===true,actualCreateAllowed:false,actualDbInjectionAllowed:false,actualDeployAllowed:false,safety:ctx.safety,message:'CONTROL 최종 승인 게이트를 점검했습니다. 승인 형식이 맞아도 deployAllowed/global flags가 false라 실제 실행은 차단됩니다.'};
}

function cce4EvaluateFinalGate_(approval,safety){
  var reasons=[];
  if(!approval||!approval.approvalId) reasons.push('MISSING_APPROVAL_ID');
  if(!approval||!approval.approvedBy) reasons.push('MISSING_APPROVED_BY');
  if(!approval||!approval.approvedAt) reasons.push('MISSING_APPROVED_AT');
  if(!approval||approval.approvalStatus!=='APPROVED') reasons.push('APPROVAL_STATUS_NOT_APPROVED');
  if(!approval||approval.approvalType!=='ERP_CORE_CREATE_DEPLOY_FINAL_GATE') reasons.push('INVALID_APPROVAL_TYPE');
  if(!approval||approval.approvalScope!=='ERP_CORE_CREATE_DEPLOY') reasons.push('INVALID_APPROVAL_SCOPE');
  if(!approval||approval.projectCode!=='ERP_CORE') reasons.push('INVALID_PROJECT_CODE');
  if(!approval||approval.controlProjectCode!=='CONTROL') reasons.push('INVALID_CONTROL_PROJECT_CODE');
  if(!approval||approval.actualCreateRequest!==true) reasons.push('NO_ACTUAL_CREATE_REQUEST');
  if(!approval||approval.actualCreateConfirm!==true) reasons.push('NO_ACTUAL_CREATE_CONFIRM');
  if(!approval||approval.actualDeployRequest!==true) reasons.push('NO_ACTUAL_DEPLOY_REQUEST');
  if(!approval||approval.actualDeployConfirm!==true) reasons.push('NO_ACTUAL_DEPLOY_CONFIRM');
  if(!approval||approval.actualDbInjectionRequest!==true) reasons.push('NO_ACTUAL_DB_INJECTION_REQUEST');
  if(!approval||approval.actualDbInjectionConfirm!==true) reasons.push('NO_ACTUAL_DB_INJECTION_CONFIRM');
  var shapeReasons=reasons.slice();
  if(safety.deployAllowed!==true) reasons.push('DEPLOY_STILL_BLOCKED');
  if(safety.actualCreateGlobalEnabled!==true) reasons.push('GLOBAL_ACTUAL_CREATE_FLAG_OFF');
  if(safety.actualDeployGlobalEnabled!==true) reasons.push('GLOBAL_ACTUAL_DEPLOY_FLAG_OFF');
  if(safety.actualDbInjectionGlobalEnabled!==true) reasons.push('GLOBAL_ACTUAL_DB_INJECTION_FLAG_OFF');
  return {ok:false,blocked:true,blockReasons:reasons,gateWouldAllowIfGlobalFlagsEnabled:shapeReasons.length===0,actualCreateAllowed:false,actualDbInjectionAllowed:false,actualDeployAllowed:false,message:'승인 게이트 차단: '+reasons.join(', ')};
}
