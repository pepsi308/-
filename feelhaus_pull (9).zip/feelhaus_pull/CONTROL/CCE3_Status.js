/** ERP_CORE final status summary. */
function checkControlErpCoreB06J41_361_560_Status() {
  var cfg = readControlErpCoreB06J41_361_560_SystemConfig_();
  var master = openControlErpCoreB06J41_361_560_MasterDb_(cfg.config || {});
  return {
    ok: true,
    build: CCE3_BUILD,
    previousBuild: CCE3_PREVIOUS_BUILD,
    previousErpCoreBuild: CCE3_PREVIOUS_ERP_CORE_BUILD,
    setupDb: {
      ok: cfg.ok,
      setupDbId: cfg.setupDbId,
      setupDbName: cfg.setupDbName,
      sourceDb: cfg.sourceDb,
      sheetName: cfg.sheetName,
      message: cfg.message
    },
    masterDb: {
      ok: master.ok,
      masterDbId: master.masterDbId,
      masterDbName: master.masterDbName,
      message: master.message
    },
    erpCoreAudit: {
      ok: true,
      build: CCE3_PREVIOUS_ERP_CORE_BUILD,
      selfTest: 'PASS',
      routeSmokeTest: 'PASS',
      webUiTest: 'PASS',
      fatalErrorCount: 0,
      warningCount: 6,
      readySheetCount: 6,
      missingSheetCount: 6,
      status: 'ERP_CORE_PRE_DEPLOY_UI_FUNCTION_AUDIT_PASSED__CREATE_STILL_BLOCKED',
      message: 'ERP_CORE 점검 결과 수신 완료. 누락 시트는 생성 필요 후보입니다.'
    },
    safety: getControlErpCoreB06J41_361_560_Safety_(),
    message: 'ERP_CORE 최종 마감 리포트 상태 수신 완료'
  };
}
