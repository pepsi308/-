/**
 * FEELHAUS CONTROL - GROUPWARE B90 ACTUAL OPERATION EXECUTION GATE
 * Build: CONTROL_GROUPWARE_B90_ACTUAL_OPERATION_EXECUTION_V01
 * Progress: [09/10] 90%
 * Target baseline: GROUPWARE_B90_FINAL_STABLE_AFTER_B70_B90_RUNALL
 * Execution function: runControlGroupwareB90ActualOperationExecutionGateV01
 *
 * Safety:
 * - Diagnostic only
 * - Sheet read only
 * - No sheet creation
 * - No header mutation
 * - No approval writing
 * - No audit log writing
 * - No backup/deploy/recovery/rollback execution
 * - No GROUPWARE production save
 * - No field use open execution
 * - No real apply execution
 */
var CC22_BUILD = 'CONTROL_GROUPWARE_B90_ACTUAL_OPERATION_EXECUTION_V01';
var CC22_MODE = 'GROUPWARE_B90_ACTUAL_OPERATION_EXECUTION_DIAGNOSTIC_ONLY_NO_UPDATE';
var CC22_PROGRESS = { current: 9, total: 10, percent: 90 };
var CC22_SETUP_DB_ID = '17VMSpgSZCvIrUlgcw8yCNcnl8WQWo2IcRf5tDCcuJGM';
var CC22_CONFIG_SHEET_NAME = 'SystemConfig';
var CC22_SOURCE_DB = 'FEELHAUS_SETUP_DB';
var CC22_TARGET = {
  projectCode: 'GROUPWARE',
  moduleCode: 'GROUPWARE_PORTAL_HR_MAIL_CALENDAR',
  buildRange: 'B70~B90',
  currentBuildNo: 'B90',
  finalBuildNo: 'B90',
  buildProgress: '90 / 90',
  progressPercent: 100,
  runAllStatus: 'GROUPWARE_B70_TO_B90_RUNALL_PASS',
  protectedBaseline: 'B70~B89',
  finalStableName: 'GROUPWARE_B90_FINAL_STABLE',
  actualExecutionReadyGateBuild: 'CONTROL_GROUPWARE_B90_ACTUAL_EXECUTION_READY_V01',
  nextVerifyGateBuild: 'CONTROL_GROUPWARE_B90_POST_APPLY_VERIFY_LOCK_V01'
};

function runControlGroupwareB90ActualOperationExecutionGateV01() {
  var result = diagnoseControlGroupwareB90ActualOperationExecutionGateV01_();
  CC22_logCompactResult_(result);
  return result;
}

function runGroupwareB90ActualOperationExecutionGateV01() {
  var result = diagnoseControlGroupwareB90ActualOperationExecutionGateV01_();
  CC22_logCompactResult_(result);
  return result;
}

function getControlGroupwareB90ActualOperationExecutionGateData() {
  var result = diagnoseControlGroupwareB90ActualOperationExecutionGateV01_();
  CC22_logCompactResult_(result);
  return result;
}

function controlGroupwareB90ActualOperationExecutionGateV01() {
  var result = diagnoseControlGroupwareB90ActualOperationExecutionGateV01_();
  CC22_logCompactResult_(result);
  return result;
}

function diagnoseControlGroupwareB90ActualOperationExecutionGateV01_() {
  var started = new Date();
  var fatal = [];
  var hold = [];
  var warnings = [];
  var summary = CC22_defaultSummary_();
  var evidence = {};
  var config = {};
  var master = { ok: false };

  try {
    var setup = CC22_readSystemConfig_();
    config = setup.config || {};
    summary.configOk = setup.ok === true;
    summary.systemConfigAutoReadOk = setup.ok === true;
    evidence.setupDbName = setup.setupDbName || '';
  } catch (e1) {
    fatal.push('SystemConfig 자동 읽기 실패: ' + CC22_errorMessage_(e1));
  }

  try {
    master = CC22_openMasterDb_(config);
    summary.masterOk = master.ok === true;
    summary.masterConnectedOk = master.ok === true;
    evidence.masterDbIdMasked = CC22_maskId_(master.masterDbId || '');
    evidence.masterDbName = master.masterDbName || '';
  } catch (e2) {
    fatal.push('FEELHAUS_DB_MASTER 연결 실패: ' + CC22_errorMessage_(e2));
  }

  evidence.actualExecutionReadyGate = CC22_checkActualExecutionReadyGate_();
  summary.actualExecutionReadyGatePassed = evidence.actualExecutionReadyGate.passed === true;
  summary.actualExecutionReadyOk = evidence.actualExecutionReadyGate.actualExecutionReadyOk === true;
  summary.actualExecutionAllowedCandidate = evidence.actualExecutionReadyGate.actualExecutionAllowedCandidate === true;
  summary.executionFilesReadyOk = evidence.actualExecutionReadyGate.executionFilesReadyOk === true;
  summary.backupEvidenceFileOk = evidence.actualExecutionReadyGate.backupEvidenceFileOk === true;
  summary.rollbackBaselineFileOk = evidence.actualExecutionReadyGate.rollbackBaselineFileOk === true;

  summary.productionSaveAllowed = false;
  summary.fieldUseOpenAllowed = false;
  summary.deployAllowed = false;
  summary.realApplyAllowed = false;
  summary.actualExecutionBlocked = true;
  summary.actualBackupAllowed = false;
  summary.actualDeployAllowed = false;
  summary.actualRecoveryAllowed = false;
  summary.actualRollbackAllowed = false;
  summary.actualFieldUseOpenAllowed = false;
  summary.actualRealApplyAllowed = false;
  summary.diagnosticOnly = true;
  summary.dryRunOnly = true;

  if (!summary.actualExecutionReadyGatePassed) hold.push('[08/10] CONTROL_GROUPWARE_B90_ACTUAL_EXECUTION_READY_V01 PASS 확인 필요');
  if (!summary.actualExecutionReadyOk) hold.push('[08/10] actual execution ready PASS 확인 필요');
  if (!summary.actualExecutionAllowedCandidate) hold.push('[08/10] actual execution allowed candidate 확인 필요');
  if (!summary.executionFilesReadyOk) hold.push('[08/10] 백업/롤백 증빙 파일 준비 확인 필요');

  var passConditions = [
    summary.configOk,
    summary.masterOk,
    summary.actualExecutionReadyGatePassed,
    summary.actualExecutionReadyOk,
    summary.actualExecutionAllowedCandidate,
    summary.executionFilesReadyOk,
    summary.actualExecutionBlocked,
    summary.actualBackupAllowed === false,
    summary.actualDeployAllowed === false,
    summary.actualRecoveryAllowed === false,
    summary.actualRollbackAllowed === false,
    summary.actualFieldUseOpenAllowed === false,
    summary.actualRealApplyAllowed === false,
    summary.productionSaveAllowed === false,
    summary.fieldUseOpenAllowed === false,
    summary.deployAllowed === false,
    summary.realApplyAllowed === false
  ];

  var allPass = fatal.length === 0 && hold.length === 0 && CC22_allTrue_(passConditions);
  var judgement = fatal.length > 0 ? 'BLOCK' : (allPass ? 'PASS' : 'HOLD');
  summary.actualOperationExecutionGateOk = judgement === 'PASS';
  summary.actualOperationExecutionDryRunOk = judgement === 'PASS';
  summary.judgement = judgement;

  return {
    ok: judgement === 'PASS',
    build: CC22_BUILD,
    progress: CC22_PROGRESS,
    mode: CC22_MODE,
    checkedAt: CC22_now_(),
    judgement: judgement,
    targetBaseline: CC22_TARGET,
    summary: summary,
    evidence: {
      setupDbId: CC22_SETUP_DB_ID,
      configSheetName: CC22_CONFIG_SHEET_NAME,
      sourceDb: CC22_SOURCE_DB,
      setupDbName: evidence.setupDbName || '',
      masterDbIdMasked: evidence.masterDbIdMasked || '',
      masterDbName: evidence.masterDbName || '',
      actualExecutionReadyGate: evidence.actualExecutionReadyGate || {},
      executionReason: judgement === 'PASS' ? '[09/10] Actual operation execution gate PASS. Actual execution ready was confirmed. This gate still executes no production change.' : '',
      actualBackupAllowed: false,
      actualDeployAllowed: false,
      actualRecoveryAllowed: false,
      actualRollbackAllowed: false,
      actualProductionSaveAllowed: false,
      actualFieldUseOpenAllowed: false,
      actualRealApplyAllowed: false,
      operationBlock: CC22_operationBlock_(),
      elapsedMs: new Date().getTime() - started.getTime()
    },
    warnings: warnings,
    hold: hold,
    fatal: fatal,
    nextAction: judgement === 'PASS'
      ? '[09/10] GROUPWARE B90 actual operation execution gate PASS. Next step is [10/10] post-apply verify and lock gate. This gate executed no production change.'
      : '[09/10] GROUPWARE B90 actual operation execution gate is not PASS. Resolve hold items, then rerun.'
  };
}

function CC22_defaultSummary_() {
  return {
    baselineOk: true,
    configOk: false,
    masterOk: false,
    systemConfigAutoReadOk: false,
    masterConnectedOk: false,
    actualExecutionReadyGatePassed: false,
    actualExecutionReadyOk: false,
    actualExecutionAllowedCandidate: false,
    executionFilesReadyOk: false,
    backupEvidenceFileOk: false,
    rollbackBaselineFileOk: false,
    actualOperationExecutionGateOk: false,
    actualOperationExecutionDryRunOk: false,
    productionSaveAllowed: false,
    fieldUseOpenAllowed: false,
    deployAllowed: false,
    realApplyAllowed: false,
    actualExecutionBlocked: true,
    actualBackupAllowed: false,
    actualDeployAllowed: false,
    actualRecoveryAllowed: false,
    actualRollbackAllowed: false,
    actualFieldUseOpenAllowed: false,
    actualRealApplyAllowed: false,
    diagnosticOnly: true,
    dryRunOnly: true,
    sheetWriteExecuted: false,
    sheetCreateExecuted: false,
    headerAutoAddExecuted: false,
    approvalWriteExecuted: false,
    auditLogWriteExecuted: false,
    backupExecuted: false,
    deployExecuted: false,
    recoveryExecuted: false,
    rollbackExecuted: false,
    realApplyExecuted: false,
    productionDataMutationExecuted: false,
    judgement: 'HOLD'
  };
}

function CC22_checkActualExecutionReadyGate_() {
  var result = { checked: false, available: false, passed: false };
  try {
    if (typeof runControlGroupwareB90ActualExecutionReadyGateV01 !== 'function') {
      result.error = 'runControlGroupwareB90ActualExecutionReadyGateV01 함수 없음';
      return result;
    }
    var r = runControlGroupwareB90ActualExecutionReadyGateV01();
    result.checked = true;
    result.available = true;
    result.passed = r && r.judgement === 'PASS';
    result.build = r && r.build || '';
    result.judgement = r && r.judgement || '';
    result.actualExecutionReadyOk = r && r.summary && r.summary.actualExecutionReadyOk === true;
    result.actualExecutionAllowedCandidate = r && r.summary && r.summary.actualExecutionAllowedCandidate === true;
    result.executionFilesReadyOk = r && r.summary && r.summary.executionFilesReadyOk === true;
    result.backupEvidenceFileOk = r && r.summary && r.summary.backupEvidenceFileOk === true;
    result.rollbackBaselineFileOk = r && r.summary && r.summary.rollbackBaselineFileOk === true;
    result.latestBackupEvidenceFile = r && r.evidence && r.evidence.latestBackupEvidenceFile || null;
    result.latestRollbackBaselineFile = r && r.evidence && r.evidence.latestRollbackBaselineFile || null;
  } catch (e) {
    result.checked = true;
    result.available = false;
    result.error = CC22_errorMessage_(e);
  }
  return result;
}

function CC22_readSystemConfig_() {
  var ss = SpreadsheetApp.openById(CC22_SETUP_DB_ID);
  var sh = ss.getSheetByName(CC22_CONFIG_SHEET_NAME);
  if (!sh) throw new Error('SystemConfig 시트 없음');
  var values = sh.getDataRange().getValues();
  if (!values || values.length < 2) throw new Error('SystemConfig 데이터 없음');
  var headers = values[0].map(function(h){ return String(h || '').trim(); });
  var map = CC22_headerMap_(headers);
  var keyIdx = CC22_pickIndex_(map, ['configKey','key','id','name','code']);
  var valIdx = CC22_pickIndex_(map, ['configValue','value','val']);
  if (keyIdx < 0) keyIdx = 0;
  if (valIdx < 0) valIdx = 1;
  var config = {};
  for (var r = 1; r < values.length; r++) {
    var k = String(values[r][keyIdx] || '').trim();
    if (!k) continue;
    config[k] = values[r][valIdx];
  }
  return { ok: true, config: config, setupDbName: ss.getName() };
}

function CC22_openMasterDb_(config) {
  var masterDbId = String(config.MASTER_DB_ID || config.FEELHAUS_DB_MASTER_ID || config.MASTER_SPREADSHEET_ID || '').trim();
  if (!masterDbId) {
    var masterDbName = String(config.MASTER_DB || config.MASTER_DB_NAME || 'FEELHAUS_DB_MASTER').trim();
    var files = DriveApp.getFilesByName(masterDbName);
    if (files.hasNext()) masterDbId = files.next().getId();
  }
  if (!masterDbId) throw new Error('FEELHAUS_DB_MASTER ID 확인 실패');
  var ss = SpreadsheetApp.openById(masterDbId);
  return { ok: true, masterDbId: masterDbId, masterDbName: ss.getName() };
}

function CC22_headerMap_(headers) {
  var map = {};
  for (var i = 0; i < headers.length; i++) map[String(headers[i] || '').trim()] = i;
  return map;
}

function CC22_pickIndex_(map, keys) {
  for (var i = 0; i < keys.length; i++) {
    if (Object.prototype.hasOwnProperty.call(map, keys[i])) return map[keys[i]];
  }
  return -1;
}

function CC22_operationBlock_() {
  return {
    productionSaveAllowed: false,
    fieldUseOpenAllowed: false,
    deployAllowed: false,
    realApplyAllowed: false,
    actualExecutionBlocked: true,
    actualBackupAllowed: false,
    actualDeployAllowed: false,
    actualRecoveryAllowed: false,
    actualRollbackAllowed: false,
    actualFieldUseOpenAllowed: false,
    actualRealApplyAllowed: false,
    sheetWriteExecuted: false,
    sheetCreateExecuted: false,
    headerAutoAddExecuted: false,
    approvalWriteExecuted: false,
    auditLogWriteExecuted: false,
    backupExecuted: false,
    deployExecuted: false,
    recoveryExecuted: false,
    rollbackExecuted: false,
    realApplyExecuted: false,
    productionDataMutationExecuted: false
  };
}

function CC22_logCompactResult_(result) {
  Logger.log('JSON_COMPACT_RESULT: ' + JSON.stringify(result));
}

function CC22_allTrue_(arr) {
  for (var i = 0; i < arr.length; i++) if (arr[i] !== true) return false;
  return true;
}

function CC22_now_() {
  return CC22_formatDate_(new Date());
}

function CC22_formatDate_(d) {
  return Utilities.formatDate(d, 'Asia/Seoul', "yyyy-MM-dd'T'HH:mm:ssXXX");
}

function CC22_maskId_(id) {
  id = String(id || '');
  if (id.length <= 8) return id ? '***' : '';
  return id.substring(0, 4) + '***' + id.substring(id.length - 4);
}

function CC22_errorMessage_(e) {
  return e && e.message ? e.message : String(e);
}
