/**
 * FEELHAUS CONTROL - GROUPWARE B90 CONTROL APPROVAL GATE
 * Build: CONTROL_GROUPWARE_B90_APPROVAL_GATE_V01
 * Progress: [04/10] 40%
 * Target baseline: GROUPWARE_B90_FINAL_STABLE_AFTER_B70_B90_RUNALL
 * Execution function: runControlGroupwareB90ApprovalGateV01
 *
 * Safety:
 * - Diagnostic only
 * - Sheet read only
 * - Drive read/list only through [03/10] dependency
 * - No sheet creation
 * - No header mutation
 * - No approval writing
 * - No audit log writing
 * - No backup/deploy/recovery/rollback execution
 * - No GROUPWARE production save
 * - No field open execution
 * - No real apply execution
 */
var CC17_BUILD = 'CONTROL_GROUPWARE_B90_APPROVAL_GATE_V01';
var CC17_MODE = 'GROUPWARE_B90_APPROVAL_GATE_DIAGNOSTIC_ONLY_NO_UPDATE';
var CC17_PROGRESS = { current: 4, total: 10, percent: 40 };
var CC17_SETUP_DB_ID = '17VMSpgSZCvIrUlgcw8yCNcnl8WQWo2IcRf5tDCcuJGM';
var CC17_CONFIG_SHEET_NAME = 'SystemConfig';
var CC17_SOURCE_DB = 'FEELHAUS_SETUP_DB';
var CC17_TARGET = {
  projectCode: 'GROUPWARE',
  moduleCode: 'GROUPWARE_PORTAL_HR_MAIL_CALENDAR',
  buildRange: 'B70~B90',
  currentBuildNo: 'B90',
  finalBuildNo: 'B90',
  buildProgress: '90 / 90',
  progressPercent: 100,
  runAllStatus: 'GROUPWARE_B70_TO_B90_RUNALL_PASS',
  protectedBaseline: 'B70~B89',
  finalStableName: 'GROUPWARE_B90_FINAL_STABLE',
  preDeployGateBuild: 'CONTROL_GROUPWARE_B90_PREDEPLOY_GATE_V01',
  backupRollbackGateBuild: 'CONTROL_GROUPWARE_B90_BACKUP_ROLLBACK_EVIDENCE_V01',
  requiredApprovalType: 'GROUPWARE_B90_PREDEPLOY_APPROVAL',
  requiredApprovalScope: 'GROUPWARE_B90_DEPLOY',
  requiredTargetAction: 'GROUPWARE_B90_DEPLOY_ALLOWED_GATE',
  relatedBuild: 'GROUPWARE_B90_FINAL_STABLE'
};

function runControlGroupwareB90ApprovalGateV01() {
  var result = diagnoseControlGroupwareB90ApprovalGateV01_();
  CC17_logCompactResult_(result);
  return result;
}

function runGroupwareB90ApprovalGateV01() {
  var result = diagnoseControlGroupwareB90ApprovalGateV01_();
  CC17_logCompactResult_(result);
  return result;
}

function getControlGroupwareB90ApprovalGateData() {
  var result = diagnoseControlGroupwareB90ApprovalGateV01_();
  CC17_logCompactResult_(result);
  return result;
}

function controlGroupwareB90ApprovalGateV01() {
  var result = diagnoseControlGroupwareB90ApprovalGateV01_();
  CC17_logCompactResult_(result);
  return result;
}

function diagnoseControlGroupwareB90ApprovalGateV01_() {
  var started = new Date();
  var fatal = [];
  var hold = [];
  var warnings = [];
  var details = {};
  var summary = CC17_defaultSummary_();

  try {
    details.setup = CC17_readSystemConfig_();
    summary.configOk = details.setup.ok === true;
    summary.systemConfigAutoReadOk = details.setup.ok === true;
  } catch (e1) {
    fatal.push('SystemConfig 자동 읽기 실패: ' + CC17_errorMessage_(e1));
    details.setup = { ok: false, error: CC17_errorMessage_(e1), config: {} };
  }

  try {
    var cfg = details.setup && details.setup.config ? details.setup.config : {};
    details.master = CC17_openMasterDb_(cfg);
    summary.masterOk = details.master.ok === true;
    summary.masterConnectedOk = details.master.ok === true;
  } catch (e2) {
    fatal.push('FEELHAUS_DB_MASTER 연결 실패: ' + CC17_errorMessage_(e2));
    details.master = { ok: false, error: CC17_errorMessage_(e2) };
  }

  details.backupRollbackGate = CC17_checkBackupRollbackGate_();
  summary.backupRollbackGatePassed = details.backupRollbackGate.passed === true;
  summary.backupRollbackEvidenceOk = details.backupRollbackGate.backupRollbackEvidenceOk === true;

  try {
    details.approval = CC17_findControlApproval_(details.master && details.master.ss);
    summary.approvalSheetReadableOk = details.approval.sheetReadableOk === true;
    summary.approvalEvidenceOk = details.approval.approvalEvidenceOk === true;
    summary.approvalScopeOk = details.approval.approvalScopeOk === true;
    summary.approvalStatusOk = details.approval.approvalStatusOk === true;
    summary.approvalActorOk = details.approval.approvalActorOk === true;
    summary.controlApprovalGateOk = summary.approvalEvidenceOk && summary.approvalScopeOk && summary.approvalStatusOk && summary.approvalActorOk;
  } catch (e3) {
    fatal.push('ApprovalLog 승인 증빙 확인 실패: ' + CC17_errorMessage_(e3));
    details.approval = { sheetReadableOk: false, error: CC17_errorMessage_(e3) };
  }

  details.operationBlock = CC17_operationBlock_();
  summary.actualExecutionBlocked = true;
  summary.diagnosticOnly = true;
  summary.dryRunOnly = true;

  if (!summary.backupRollbackGatePassed) hold.push('[03/10] CONTROL_GROUPWARE_B90_BACKUP_ROLLBACK_EVIDENCE_V01 PASS 확인 필요');
  if (!summary.approvalSheetReadableOk) hold.push('ApprovalLog 시트 읽기 확인 필요');
  if (!summary.approvalEvidenceOk) hold.push('GROUPWARE B90 CONTROL 사전 승인 증빙 행 추가 필요: ' + CC17_TARGET.requiredApprovalType);
  if (summary.approvalEvidenceOk && !summary.approvalScopeOk) hold.push('GROUPWARE B90 승인 scope 확인 필요: ' + CC17_TARGET.requiredApprovalScope);
  if (summary.approvalEvidenceOk && !summary.approvalStatusOk) hold.push('GROUPWARE B90 승인 상태 APPROVED 확인 필요');
  if (summary.approvalEvidenceOk && !summary.approvalActorOk) hold.push('GROUPWARE B90 승인자/승인시각 확인 필요');

  var passConditions = [
    summary.configOk,
    summary.masterOk,
    summary.backupRollbackGatePassed,
    summary.backupRollbackEvidenceOk,
    summary.approvalSheetReadableOk,
    summary.approvalEvidenceOk,
    summary.approvalScopeOk,
    summary.approvalStatusOk,
    summary.approvalActorOk,
    summary.controlApprovalGateOk,
    summary.actualExecutionBlocked
  ];

  var allPass = fatal.length === 0 && hold.length === 0 && CC17_allTrue_(passConditions);
  var judgement = fatal.length > 0 ? 'BLOCK' : (allPass ? 'PASS' : 'HOLD');
  summary.approvalGateOk = judgement === 'PASS';
  summary.judgement = judgement;

  return {
    ok: judgement === 'PASS',
    build: CC17_BUILD,
    progress: CC17_PROGRESS,
    mode: CC17_MODE,
    checkedAt: CC17_now_(),
    judgement: judgement,
    targetBaseline: CC17_TARGET,
    summary: summary,
    evidence: {
      setupDbId: CC17_SETUP_DB_ID,
      configSheetName: CC17_CONFIG_SHEET_NAME,
      sourceDb: CC17_SOURCE_DB,
      setupDbName: details.setup && details.setup.setupDbName || '',
      masterDbIdMasked: CC17_maskId_(details.master && details.master.masterDbId || ''),
      masterDbName: details.master && details.master.masterDbName || '',
      backupRollbackGate: details.backupRollbackGate || {},
      approvalSheetName: details.approval && details.approval.sheetName || 'ApprovalLog',
      approvalCandidateCount: details.approval && details.approval.approvalCandidateCount || 0,
      approvedGroupwareB90Count: details.approval && details.approval.approvedGroupwareB90Count || 0,
      latestGroupwareB90Approval: details.approval && details.approval.latestGroupwareB90Approval || null,
      requiredApprovalType: CC17_TARGET.requiredApprovalType,
      requiredApprovalScope: CC17_TARGET.requiredApprovalScope,
      requiredTargetAction: CC17_TARGET.requiredTargetAction,
      relatedBuild: CC17_TARGET.relatedBuild,
      operationBlock: details.operationBlock || {},
      elapsedMs: new Date().getTime() - started.getTime()
    },
    warnings: warnings,
    hold: hold,
    fatal: fatal,
    nextAction: judgement === 'PASS'
      ? '[04/10] GROUPWARE B90 CONTROL approval gate PASS. Next step is [05/10] deploy allowed gate. This gate executed no production change.'
      : '[04/10] GROUPWARE B90 CONTROL approval gate is not PASS. Add approval evidence to ApprovalLog, then rerun.'
  };
}

function CC17_defaultSummary_() {
  return {
    baselineOk: true,
    configOk: false,
    masterOk: false,
    systemConfigAutoReadOk: false,
    masterConnectedOk: false,
    backupRollbackGatePassed: false,
    backupRollbackEvidenceOk: false,
    approvalSheetReadableOk: false,
    approvalEvidenceOk: false,
    approvalScopeOk: false,
    approvalStatusOk: false,
    approvalActorOk: false,
    controlApprovalGateOk: false,
    approvalGateOk: false,
    productionSaveAllowed: false,
    fieldUseOpenAllowed: false,
    deployAllowed: false,
    realApplyAllowed: false,
    actualExecutionBlocked: true,
    diagnosticOnly: true,
    dryRunOnly: true,
    sheetWriteExecuted: false,
    sheetCreateExecuted: false,
    headerAutoAddExecuted: false,
    approvalWriteExecuted: false,
    auditLogWriteExecuted: false,
    backupExecuted: false,
    deployExecuted: false,
    recoveryExecuted: false,
    rollbackExecuted: false,
    realApplyExecuted: false,
    productionDataMutationExecuted: false
  };
}

function CC17_readSystemConfig_() {
  var ss = SpreadsheetApp.openById(CC17_SETUP_DB_ID);
  var sheet = ss.getSheetByName(CC17_CONFIG_SHEET_NAME);
  if (!sheet) throw new Error('SystemConfig sheet not found: ' + CC17_CONFIG_SHEET_NAME);
  var values = sheet.getDataRange().getValues();
  var config = {};
  for (var i = 1; i < values.length; i++) {
    var key = String(values[i][0] || '').trim();
    var value = values[i][1];
    if (key) config[key] = value;
  }
  return { ok: true, setupDbId: CC17_SETUP_DB_ID, setupDbName: ss.getName(), sourceDb: CC17_SOURCE_DB, sheetName: CC17_CONFIG_SHEET_NAME, config: config };
}

function CC17_openMasterDb_(config) {
  config = config || {};
  var id = String(config.FEELHAUS_DB_MASTER_ID || config.FEELHAUS_DB_MASTER || config.DB_MASTER_ID || config.MASTER_DB_ID || '').trim();
  if (!id) throw new Error('FEELHAUS_DB_MASTER_ID is missing in SystemConfig');
  var ss = SpreadsheetApp.openById(id);
  return { ok: true, masterDbId: id, masterDbName: ss.getName(), ss: ss };
}

function CC17_checkBackupRollbackGate_() {
  var out = { checked: false, available: false, passed: false, build: CC17_TARGET.backupRollbackGateBuild, judgement: '', backupRollbackEvidenceOk: false };
  try {
    if (typeof runControlGroupwareB90BackupRollbackEvidenceGateV01 === 'function') {
      out.checked = true;
      out.available = true;
      var res = runControlGroupwareB90BackupRollbackEvidenceGateV01();
      out.judgement = res && res.judgement || '';
      out.passed = res && res.ok === true && res.judgement === 'PASS';
      out.backupRollbackEvidenceOk = res && res.summary && res.summary.backupRollbackEvidenceOk === true;
    } else {
      out.checked = true;
      out.available = false;
      out.note = 'runControlGroupwareB90BackupRollbackEvidenceGateV01 function not found in project runtime';
    }
  } catch (e) {
    out.checked = true;
    out.available = true;
    out.error = CC17_errorMessage_(e);
  }
  return out;
}

function CC17_findControlApproval_(masterSs) {
  var out = {
    sheetReadableOk: false,
    sheetName: 'ApprovalLog',
    approvalCandidateCount: 0,
    approvedGroupwareB90Count: 0,
    latestGroupwareB90Approval: null,
    approvalEvidenceOk: false,
    approvalScopeOk: false,
    approvalStatusOk: false,
    approvalActorOk: false
  };
  if (!masterSs) return out;
  var sheet = masterSs.getSheetByName('ApprovalLog') || masterSs.getSheetByName('CONTROL_ApprovalLog') || masterSs.getSheetByName('Approval_Log');
  if (!sheet) return out;
  out.sheetReadableOk = true;
  out.sheetName = sheet.getName();
  var values = sheet.getDataRange().getValues();
  if (!values || values.length < 2) return out;
  var header = CC17_headerMap_(values[0]);
  var candidates = [];
  for (var i = 1; i < values.length; i++) {
    var row = values[i];
    var approvalType = CC17_cell_(row, header, ['approvalType', 'type']);
    var approvalScope = CC17_cell_(row, header, ['approvalScope', 'scope']);
    var approvalStatus = CC17_cell_(row, header, ['approvalStatus', 'status']);
    var targetAction = CC17_cell_(row, header, ['targetAction', 'action']);
    var relatedBuild = CC17_cell_(row, header, ['relatedBuild', 'build', 'buildNo']);
    var status = CC17_cell_(row, header, ['status']);
    var approvedBy = CC17_cell_(row, header, ['approvedBy', 'approver', 'updatedBy']);
    var approvedAt = CC17_cell_(row, header, ['approvedAt', 'approvedDate', 'updatedAt']);
    var projectCode = CC17_cell_(row, header, ['projectCode', 'project']);
    var approvalId = CC17_cell_(row, header, ['approvalId', 'id']);
    var typeMatch = approvalType === CC17_TARGET.requiredApprovalType || targetAction === CC17_TARGET.requiredTargetAction;
    var buildMatch = relatedBuild === CC17_TARGET.relatedBuild || relatedBuild === CC17_TARGET.finalStableName || relatedBuild === CC17_TARGET.currentBuildNo || relatedBuild === CC17_TARGET.finalBuildNo;
    var projectMatch = !projectCode || projectCode === CC17_TARGET.projectCode;
    if (typeMatch && buildMatch && projectMatch) {
      var item = {
        approvalId: approvalId,
        approvalType: approvalType,
        approvalScope: approvalScope,
        approvalStatus: approvalStatus,
        approvedBy: approvedBy,
        approvedAt: CC17_normalizeDateValue_(approvedAt),
        targetAction: targetAction,
        relatedBuild: relatedBuild,
        status: status,
        rowNumber: i + 1
      };
      candidates.push(item);
    }
  }
  candidates.sort(CC17_sortApprovalDesc_);
  out.approvalCandidateCount = candidates.length;
  out.latestGroupwareB90Approval = candidates.length ? candidates[0] : null;
  if (out.latestGroupwareB90Approval) {
    var latest = out.latestGroupwareB90Approval;
    out.approvalEvidenceOk = true;
    out.approvalScopeOk = latest.approvalScope === CC17_TARGET.requiredApprovalScope;
    out.approvalStatusOk = latest.approvalStatus === 'APPROVED' && (!latest.status || latest.status === 'APPROVED');
    out.approvalActorOk = !!latest.approvedBy && !!latest.approvedAt;
    out.approvedGroupwareB90Count = out.approvalScopeOk && out.approvalStatusOk && out.approvalActorOk ? 1 : 0;
  }
  return out;
}

function CC17_headerMap_(headerRow) {
  var map = {};
  for (var i = 0; i < headerRow.length; i++) {
    var key = String(headerRow[i] || '').trim();
    if (key) map[key] = i;
  }
  return map;
}

function CC17_cell_(row, header, keys) {
  for (var i = 0; i < keys.length; i++) {
    if (Object.prototype.hasOwnProperty.call(header, keys[i])) return String(row[header[keys[i]]] || '').trim();
  }
  return '';
}

function CC17_sortApprovalDesc_(a, b) {
  var ax = String(a && a.approvedAt || '');
  var bx = String(b && b.approvedAt || '');
  if (ax < bx) return 1;
  if (ax > bx) return -1;
  return 0;
}

function CC17_normalizeDateValue_(value) {
  if (Object.prototype.toString.call(value) === '[object Date]' && !isNaN(value.getTime())) return CC17_formatDate_(value);
  return String(value || '').trim();
}

function CC17_operationBlock_() {
  return {
    productionSaveAllowed: false,
    fieldUseOpenAllowed: false,
    deployAllowed: false,
    realApplyAllowed: false,
    actualExecutionBlocked: true,
    sheetWriteExecuted: false,
    sheetCreateExecuted: false,
    headerAutoAddExecuted: false,
    approvalWriteExecuted: false,
    auditLogWriteExecuted: false,
    backupExecuted: false,
    deployExecuted: false,
    recoveryExecuted: false,
    rollbackExecuted: false,
    realApplyExecuted: false,
    productionDataMutationExecuted: false
  };
}

function CC17_logCompactResult_(result) {
  Logger.log('JSON_COMPACT_RESULT: ' + JSON.stringify(CC17_compactResult_(result)));
}

function CC17_compactResult_(result) {
  result = result || {};
  var summary = result.summary || {};
  var evidence = result.evidence || {};
  return {
    ok: result.ok === true,
    build: result.build || CC17_BUILD,
    progress: CC17_PROGRESS,
    mode: result.mode || CC17_MODE,
    checkedAt: result.checkedAt || '',
    judgement: result.judgement || 'BLOCK',
    targetBaseline: CC17_TARGET,
    summary: {
      baselineOk: summary.baselineOk === true,
      configOk: summary.configOk === true,
      masterOk: summary.masterOk === true,
      systemConfigAutoReadOk: summary.systemConfigAutoReadOk === true,
      masterConnectedOk: summary.masterConnectedOk === true,
      backupRollbackGatePassed: summary.backupRollbackGatePassed === true,
      backupRollbackEvidenceOk: summary.backupRollbackEvidenceOk === true,
      approvalSheetReadableOk: summary.approvalSheetReadableOk === true,
      approvalEvidenceOk: summary.approvalEvidenceOk === true,
      approvalScopeOk: summary.approvalScopeOk === true,
      approvalStatusOk: summary.approvalStatusOk === true,
      approvalActorOk: summary.approvalActorOk === true,
      controlApprovalGateOk: summary.controlApprovalGateOk === true,
      approvalGateOk: summary.approvalGateOk === true,
      productionSaveAllowed: summary.productionSaveAllowed === true,
      fieldUseOpenAllowed: summary.fieldUseOpenAllowed === true,
      deployAllowed: summary.deployAllowed === true,
      realApplyAllowed: summary.realApplyAllowed === true,
      actualExecutionBlocked: summary.actualExecutionBlocked !== false,
      diagnosticOnly: summary.diagnosticOnly === true,
      dryRunOnly: summary.dryRunOnly === true,
      sheetWriteExecuted: summary.sheetWriteExecuted === true,
      sheetCreateExecuted: summary.sheetCreateExecuted === true,
      headerAutoAddExecuted: summary.headerAutoAddExecuted === true,
      approvalWriteExecuted: summary.approvalWriteExecuted === true,
      auditLogWriteExecuted: summary.auditLogWriteExecuted === true,
      backupExecuted: summary.backupExecuted === true,
      deployExecuted: summary.deployExecuted === true,
      recoveryExecuted: summary.recoveryExecuted === true,
      rollbackExecuted: summary.rollbackExecuted === true,
      realApplyExecuted: summary.realApplyExecuted === true,
      productionDataMutationExecuted: summary.productionDataMutationExecuted === true
    },
    evidence: {
      setupDbId: evidence.setupDbId || CC17_SETUP_DB_ID,
      configSheetName: evidence.configSheetName || CC17_CONFIG_SHEET_NAME,
      sourceDb: evidence.sourceDb || CC17_SOURCE_DB,
      setupDbName: evidence.setupDbName || '',
      masterDbIdMasked: evidence.masterDbIdMasked || '',
      masterDbName: evidence.masterDbName || '',
      backupRollbackGate: evidence.backupRollbackGate || {},
      approvalSheetName: evidence.approvalSheetName || 'ApprovalLog',
      approvalCandidateCount: evidence.approvalCandidateCount || 0,
      approvedGroupwareB90Count: evidence.approvedGroupwareB90Count || 0,
      latestGroupwareB90Approval: evidence.latestGroupwareB90Approval || null,
      requiredApprovalType: evidence.requiredApprovalType || CC17_TARGET.requiredApprovalType,
      requiredApprovalScope: evidence.requiredApprovalScope || CC17_TARGET.requiredApprovalScope,
      requiredTargetAction: evidence.requiredTargetAction || CC17_TARGET.requiredTargetAction,
      relatedBuild: evidence.relatedBuild || CC17_TARGET.relatedBuild,
      elapsedMs: evidence.elapsedMs || 0
    },
    warnings: result.warnings || [],
    hold: result.hold || [],
    fatal: result.fatal || [],
    nextAction: result.nextAction || ''
  };
}

function CC17_allTrue_(items) {
  for (var i = 0; i < items.length; i++) {
    if (items[i] !== true) return false;
  }
  return true;
}

function CC17_maskId_(id) {
  id = String(id || '');
  if (!id) return '';
  if (id.length <= 8) return '***';
  return id.substring(0, 4) + '***' + id.substring(id.length - 4);
}

function CC17_now_() {
  var tz = 'Asia/Seoul';
  try { tz = Session.getScriptTimeZone() || tz; } catch (e) {}
  return Utilities.formatDate(new Date(), tz, "yyyy-MM-dd'T'HH:mm:ssXXX");
}

function CC17_formatDate_(date) {
  var tz = 'Asia/Seoul';
  try { tz = Session.getScriptTimeZone() || tz; } catch (e) {}
  return Utilities.formatDate(date, tz, "yyyy-MM-dd'T'HH:mm:ssXXX");
}

function CC17_errorMessage_(err) {
  if (!err) return 'unknown error';
  return err.message || String(err);
}
