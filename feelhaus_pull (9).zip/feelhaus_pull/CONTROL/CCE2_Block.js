/** Final safety block assertion. */
function assertControlErpCoreB06J41_161_360_Block() {
  var s = getControlErpCoreB06J41_161_360_Safety_();
  var ok = s.deployAllowed === false &&
    s.actualCreateConfirm === false &&
    s.actualDeployConfirm === false &&
    s.actualCreateGlobalEnabled === false &&
    s.actualDeployGlobalEnabled === false &&
    s.noSheetCreate === true &&
    s.noSheetWrite === true &&
    s.noHeaderAutoAdd === true &&
    s.noDbInjection === true &&
    s.noActualDeploy === true &&
    s.actualExecutionBlocked === true;
  return {
    ok: ok,
    build: CONTROL_ERP_CORE_161_360_BUILD,
    deployAllowed: false,
    actualCreateConfirm: false,
    actualExecutionBlocked: true,
    actualSheetCreateAllowed: false,
    actualHeaderAddAllowed: false,
    actualDbInjectionAllowed: false,
    actualDeployAllowed: false,
    safety: s,
    message: ok ? '실제 생성/배포 차단 상태 정상' : '안전 차단값 점검 필요'
  };
}
