/**
 * FEELHAUS CONTROL - PORTAL EVENT B50 PRE-DEPLOY DIAGNOSTIC GATE
 * Build: CONTROL_PORTAL_EVENT_B50_PREDEPLOY_GATE_V01
 * Target baseline: PORTAL_EVENT_B50_FINAL_STABLE_READONLY_20260611
 * Execution function: runControlPortalEventB50PreDeployGateV01
 *
 * Safety:
 * - Diagnostic only
 * - No sheet creation
 * - No header mutation
 * - No log writing
 * - No approval writing
 * - No backup/deploy/recovery/rollback execution
 * - No PORTAL/ERP/field open mutation
 */
var CC06_BUILD = 'CONTROL_PORTAL_EVENT_B50_PREDEPLOY_GATE_EVIDENCE_SYNC_PATCH_V01';
var CC06_MODE = 'PORTAL_EVENT_B50_PREDEPLOY_DIAGNOSTIC_ONLY_NO_UPDATE';
var CC06_PORTAL_EVENT_BASELINE = {
  projectCode: 'PORTAL_EVENT',
  moduleCode: 'PORTAL_EVENT_MANAGEMENT',
  buildNo: 'PORTAL_EVENT_B50_FINAL_STABLE_READONLY_20260611',
  buildProgress: '50 / 50',
  progressPercent: 100,
  runFunction: 'portalEventB50RunAll',
  changedOnlyFile: 'PORTAL_EVENT_B50_CHANGED_ONLY.zip',
  expectedOk: true,
  expectedFatalCount: 0,
  expectedWarningCount: 0,
  readonlyStable: true,
  selfTestSafety: {
    noDbWrite: true,
    noSheetCreate: true,
    noHeaderAdd: true,
    noMenuRegistryWrite: true,
    noAuditLogWrite: true,
    noTimelineWrite: true,
    noPdfGeneration: true,
    noDriveUpload: true,
    noReportSave: true,
    noFinalApprovalExecution: true,
    noErpApply: true,
    noFieldOpenExecution: true
  },
  inheritedLocks: [
    'B49 final open candidate maintained',
    'B48 execution block and exception approval review maintained',
    'B47 operator checkpoint maintained',
    'B46 evidence archive report plan maintained',
    'B45 audit log timeline plan maintained',
    'B44 result diff maintained',
    'all save functions locked'
  ]
};

function runControlPortalEventB50PreDeployGateV01() {
  var result = diagnoseControlPortalEventB50PreDeployGateV01_();
  CC06_logCompactResult_(result);
  return result;
}

function getControlPortalEventB50PreDeployGateData() {
  var result = diagnoseControlPortalEventB50PreDeployGateV01_();
  CC06_logCompactResult_(result);
  return result;
}

function controlPortalEventB50PreDeployGateV01() {
  var result = diagnoseControlPortalEventB50PreDeployGateV01_();
  CC06_logCompactResult_(result);
  return result;
}


function CC06_logCompactResult_(result) {
  var compact = CC06_compactResult_(result);
  Logger.log('JSON_COMPACT_RESULT: ' + JSON.stringify(compact));
}

function CC06_compactResult_(result) {
  result = result || {};
  var summary = result.summary || {};
  var details = result.details || {};
  var schema = details.schema || {};
  var backupEvidence = details.backupEvidence || {};
  var rollbackEvidence = details.rollbackEvidence || {};
  var approvalBlock = details.approvalBlock || {};
  var operationBlock = details.operationBlock || {};
  return {
    ok: result.ok === true,
    build: result.build || CC06_BUILD,
    mode: result.mode || CC06_MODE,
    checkedAt: result.checkedAt || '',
    judgement: result.judgement || summary.judgement || 'BLOCK',
    targetBaseline: {
      projectCode: CC06_PORTAL_EVENT_BASELINE.projectCode,
      buildNo: CC06_PORTAL_EVENT_BASELINE.buildNo,
      buildProgress: CC06_PORTAL_EVENT_BASELINE.buildProgress,
      progressPercent: CC06_PORTAL_EVENT_BASELINE.progressPercent,
      runFunction: CC06_PORTAL_EVENT_BASELINE.runFunction,
      changedOnlyFile: CC06_PORTAL_EVENT_BASELINE.changedOnlyFile
    },
    summary: {
      baselineOk: summary.baselineOk === true,
      configOk: summary.configOk === true,
      masterOk: summary.masterOk === true,
      requiredGateSheetsOk: summary.requiredGateSheetsOk === true,
      requiredGateHeadersOk: summary.requiredGateHeadersOk === true,
      preDeployBackupEvidenceOk: summary.preDeployBackupEvidenceOk === true,
      rollbackBaselineEvidenceOk: summary.rollbackBaselineEvidenceOk === true,
      controlApprovalBlockOk: summary.controlApprovalBlockOk === true,
      operationSaveBlocked: summary.operationSaveBlocked !== false,
      erpApplyBlocked: summary.erpApplyBlocked !== false,
      fieldOpenBlocked: summary.fieldOpenBlocked !== false,
      diagnosticOnly: summary.diagnosticOnly === true,
      dryRunOnly: summary.dryRunOnly === true,
      deployAllowed: summary.deployAllowed === true,
      actualExecutionBlocked: summary.actualExecutionBlocked !== false,
      sheetWriteExecuted: summary.sheetWriteExecuted === true,
      sheetCreateExecuted: summary.sheetCreateExecuted === true,
      headerAutoAddExecuted: summary.headerAutoAddExecuted === true,
      auditLogWriteExecuted: summary.auditLogWriteExecuted === true,
      timelineWriteExecuted: summary.timelineWriteExecuted === true,
      approvalWriteExecuted: summary.approvalWriteExecuted === true,
      backupExecuted: summary.backupExecuted === true,
      deployExecuted: summary.deployExecuted === true,
      recoveryExecuted: summary.recoveryExecuted === true,
      rollbackExecuted: summary.rollbackExecuted === true,
      erpApplyExecuted: summary.erpApplyExecuted === true,
      actualOpenExecuted: summary.actualOpenExecuted === true,
      productionDataMutationExecuted: summary.productionDataMutationExecuted === true
    },
    evidence: {
      missingSheets: schema.missingSheets || [],
      totalMissingHeaders: schema.totalMissingHeaders || 0,
      backupEvidenceOk: backupEvidence.ok === true,
      backupEvidenceCount: backupEvidence.evidenceCount || 0,
      rollbackEvidenceOk: rollbackEvidence.ok === true,
      recoveryEvidenceCount: rollbackEvidence.recoveryEvidenceCount || 0,
      backupHasRollbackBaseline: rollbackEvidence.backupHasRollbackBaseline === true,
      driveBackupEvidenceOk: (details.driveEvidence && details.driveEvidence.backupEvidenceOk) === true,
      driveRollbackEvidenceOk: (details.driveEvidence && details.driveEvidence.rollbackEvidenceOk) === true,
      driveBackupFileCount: (details.driveEvidence && details.driveEvidence.backupFileCount) || 0,
      driveRollbackFileCount: (details.driveEvidence && details.driveEvidence.rollbackFileCount) || 0,
      driveScannedFolderCount: (details.driveEvidence && details.driveEvidence.scannedFolderCount) || 0,
      approvedPortalEventB50Count: approvalBlock.approvedPortalEventB50Count || 0,
      actualBackupAllowed: operationBlock.actualBackupAllowed === true,
      actualDeployAllowed: operationBlock.actualDeployAllowed === true,
      actualRecoveryAllowed: operationBlock.actualRecoveryAllowed === true,
      actualRollbackAllowed: operationBlock.actualRollbackAllowed === true,
      actualPortalSaveAllowed: operationBlock.actualPortalSaveAllowed === true,
      actualErpApplyAllowed: operationBlock.actualErpApplyAllowed === true,
      actualFieldOpenAllowed: operationBlock.actualFieldOpenAllowed === true
    },
    warnings: result.warnings || [],
    hold: result.hold || [],
    fatal: result.fatal || [],
    nextAction: result.nextAction || ''
  };
}

function diagnoseControlPortalEventB50PreDeployGateV01_() {
  var fatal = [];
  var warnings = [];
  var hold = [];
  var details = {
    build: CC06_BUILD,
    mode: CC06_MODE,
    checkedAt: CC_now_(),
    sourceDb: CC_SOURCE_DB,
    setupDbId: CC_SETUP_DB_ID,
    configSheetName: CC_CONFIG_SHEET_NAME,
    targetBaseline: CC06_PORTAL_EVENT_BASELINE,
    safety: CC06_safety_(),
    guidance: CC06_guidance_(),
    config: null,
    master: null,
    baselineRegistration: null,
    schema: null,
    backupEvidence: null,
    rollbackEvidence: null,
    driveEvidence: null,
    approvalBlock: null,
    operationBlock: null
  };
  var summary = CC06_baseSummary_();

  try {
    var cfgResult = CC_readSystemConfig_();
    summary.configOk = !!(cfgResult && cfgResult.ok);
    details.config = {
      ok: summary.configOk,
      message: cfgResult && cfgResult.message ? cfgResult.message : '',
      sourceDb: CC_SOURCE_DB,
      setupDbId: CC_SETUP_DB_ID,
      configSheetName: CC_CONFIG_SHEET_NAME
    };
    if (!summary.configOk) fatal.push('SystemConfig 자동 읽기 실패');

    var config = cfgResult && cfgResult.config ? cfgResult.config : {};
    var masterId = CC_resolveMasterDbId_(config);
    if (!masterId) {
      summary.masterOk = false;
      fatal.push('FEELHAUS_DB_MASTER ID를 SystemConfig에서 찾지 못했습니다.');
      details.master = { ok: false, masterDbId: '', masterDbName: '' };
      return CC06_result_(summary, fatal, warnings, hold, details);
    }

    var masterSs = SpreadsheetApp.openById(masterId);
    summary.masterOk = !!masterSs;
    details.master = {
      ok: summary.masterOk,
      masterDbId: masterId,
      masterDbName: masterSs ? masterSs.getName() : ''
    };
    if (!summary.masterOk) fatal.push('FEELHAUS_DB_MASTER 연결 실패');

    details.baselineRegistration = CC06_checkBaselineRegistration_();
    summary.baselineOk = details.baselineRegistration.ok;
    if (!summary.baselineOk) fatal.push('PORTAL_EVENT_B50 기준선 값 불일치');

    details.schema = CC06_checkGateSchemas_(masterSs);
    summary.requiredGateSheetsOk = details.schema.ok && details.schema.missingSheets.length === 0;
    summary.requiredGateHeadersOk = details.schema.totalMissingHeaders === 0;
    if (!summary.requiredGateSheetsOk) fatal.push('배포 전 게이트 필수 로그 시트 누락: ' + details.schema.missingSheets.join(', '));
    if (!summary.requiredGateHeadersOk) fatal.push('배포 전 게이트 필수 헤더 누락 합계: ' + details.schema.totalMissingHeaders);

    details.backupEvidence = CC06_checkBackupEvidence_(masterSs);
    summary.preDeployBackupEvidenceOk = details.backupEvidence.ok;

    details.rollbackEvidence = CC06_checkRollbackEvidence_(masterSs, details.backupEvidence);
    summary.rollbackBaselineEvidenceOk = details.rollbackEvidence.ok;

    details.driveEvidence = CC06_checkDriveEvidenceFromSystemConfig_(config);
    if (!summary.preDeployBackupEvidenceOk && details.driveEvidence.backupEvidenceOk === true) {
      summary.preDeployBackupEvidenceOk = true;
      details.backupEvidence.ok = true;
      details.backupEvidence.driveEvidenceOk = true;
      details.backupEvidence.evidenceCount = (details.backupEvidence.evidenceCount || 0) + (details.driveEvidence.backupFileCount || 0);
      details.backupEvidence.latestEvidence = details.driveEvidence.latestBackupEvidence || details.backupEvidence.latestEvidence;
      details.backupEvidence.message = 'Drive 보관 위치에서 PORTAL_EVENT_B50 백업 zip 증빙이 확인되었습니다.';
    }
    if (!summary.rollbackBaselineEvidenceOk && details.driveEvidence.rollbackEvidenceOk === true) {
      summary.rollbackBaselineEvidenceOk = true;
      details.rollbackEvidence.ok = true;
      details.rollbackEvidence.driveEvidenceOk = true;
      details.rollbackEvidence.recoveryEvidenceCount = (details.rollbackEvidence.recoveryEvidenceCount || 0) + (details.driveEvidence.rollbackFileCount || 0);
      details.rollbackEvidence.latestRecoveryEvidence = details.driveEvidence.latestRollbackEvidence || details.rollbackEvidence.latestRecoveryEvidence;
      details.rollbackEvidence.message = 'Drive 보관 위치에서 PORTAL_EVENT_B50 롤백 baseline zip 증빙이 확인되었습니다.';
    }

    if (!summary.preDeployBackupEvidenceOk) hold.push('PORTAL_EVENT_B50 배포 전 백업 생성 증빙이 아직 확인되지 않았습니다.');
    if (!summary.rollbackBaselineEvidenceOk) hold.push('PORTAL_EVENT_B50 롤백 기준 파일/rollbackBaselineId 보관 증빙이 아직 확인되지 않았습니다.');

    details.approvalBlock = CC06_checkApprovalAndExecutionBlock_(masterSs);
    summary.controlApprovalBlockOk = details.approvalBlock.ok;
    summary.operationSaveBlocked = details.approvalBlock.operationSaveBlocked;
    summary.erpApplyBlocked = details.approvalBlock.erpApplyBlocked;
    summary.fieldOpenBlocked = details.approvalBlock.fieldOpenBlocked;
    if (!summary.controlApprovalBlockOk) fatal.push('CONTROL 승인 없는 운영 저장/ERP 반영/현장 오픈 차단 기준이 불명확합니다.');

    details.operationBlock = CC06_checkOperationBlock_();
    summary.actualExecutionBlocked = details.operationBlock.actualExecutionBlocked;
    summary.deployAllowed = details.operationBlock.deployAllowed;
    summary.actualOpenExecuted = false;
    summary.erpApplyExecuted = false;
    summary.productionDataMutationExecuted = false;

    summary.diagnosticOnly = true;
    summary.sheetWriteExecuted = false;
    summary.sheetCreateExecuted = false;
    summary.headerAutoAddExecuted = false;
    summary.auditLogWriteExecuted = false;
    summary.timelineWriteExecuted = false;
    summary.approvalWriteExecuted = false;
    summary.backupExecuted = false;
    summary.deployExecuted = false;
    summary.recoveryExecuted = false;
    summary.rollbackExecuted = false;

    return CC06_result_(summary, fatal, warnings, hold, details);
  } catch (err) {
    fatal.push(String(err && err.message ? err.message : err));
    return CC06_result_(summary, fatal, warnings, hold, details);
  }
}

function CC06_baseSummary_() {
  return {
    ok: false,
    judgement: 'BLOCK',
    baselineOk: false,
    configOk: false,
    masterOk: false,
    requiredGateSheetsOk: false,
    requiredGateHeadersOk: false,
    preDeployBackupEvidenceOk: false,
    rollbackBaselineEvidenceOk: false,
    controlApprovalBlockOk: false,
    operationSaveBlocked: true,
    erpApplyBlocked: true,
    fieldOpenBlocked: true,
    diagnosticOnly: true,
    dryRunOnly: true,
    deployAllowed: false,
    actualExecutionBlocked: true,
    sheetWriteExecuted: false,
    sheetCreateExecuted: false,
    headerAutoAddExecuted: false,
    menuRegistryWriteExecuted: false,
    auditLogWriteExecuted: false,
    timelineWriteExecuted: false,
    approvalWriteExecuted: false,
    backupExecuted: false,
    deployExecuted: false,
    recoveryExecuted: false,
    rollbackExecuted: false,
    pdfGenerationExecuted: false,
    driveUploadExecuted: false,
    reportSaveExecuted: false,
    finalApprovalExecuted: false,
    erpApplyExecuted: false,
    actualOpenExecuted: false,
    productionDataMutationExecuted: false
  };
}

function CC06_safety_() {
  var s = CC_getSafety_();
  s.noMenuRegistryWrite = true;
  s.noAuditLogWrite = true;
  s.noTimelineWrite = true;
  s.noDriveUpload = true;
  s.noReportSave = true;
  s.noFinalApprovalExecution = true;
  s.noErpApply = true;
  s.noFieldOpenExecution = true;
  s.diagnosticOnly = true;
  s.actualExecutionBlocked = true;
  s.deployAllowed = false;
  return s;
}

function CC06_checkBaselineRegistration_() {
  var b = CC06_PORTAL_EVENT_BASELINE;
  var ok = Boolean(
    b.projectCode === 'PORTAL_EVENT' &&
    b.buildNo === 'PORTAL_EVENT_B50_FINAL_STABLE_READONLY_20260611' &&
    b.progressPercent === 100 &&
    b.runFunction === 'portalEventB50RunAll' &&
    b.changedOnlyFile === 'PORTAL_EVENT_B50_CHANGED_ONLY.zip' &&
    b.readonlyStable === true
  );
  return {
    ok: ok,
    registeredInDiagnosticResultOnly: true,
    sheetWriteExecuted: false,
    targetBaseline: b,
    message: 'PORTAL_EVENT_B50 기준선은 CONTROL 진단 결과 객체에만 등록합니다. 시트 쓰기는 하지 않습니다.'
  };
}

function CC06_checkGateSchemas_(masterSs) {
  var specs = [
    { name: 'ApprovalLog', required: ['approvalId', 'approvalType', 'approvalScope', 'approvalStatus', 'approvedBy', 'approvedAt', 'targetAction', 'relatedBuild', 'status', 'createdAt', 'createdBy'] },
    { name: 'BackupLog', required: ['backupId', 'projectCode', 'buildRange', 'sourceDb', 'targetDb', 'backupScope', 'backupStatus', 'backupStartedAt', 'executedBy', 'rollbackBaselineId', 'status'] },
    { name: 'DeployLog', required: ['deployId', 'projectCode', 'buildNo', 'deployLevel', 'deployStatus', 'approvalId', 'backupId', 'rollbackBaselineId', 'result', 'status'] },
    { name: 'RecoveryLog', required: ['recoveryId', 'rollbackBaselineId', 'projectCode', 'baselineBuild', 'rollbackScope', 'rollbackAllowed', 'reason', 'recoveryStatus', 'createdAt', 'createdBy', 'status'] }
  ];
  var sheets = [];
  var missingSheets = [];
  var totalMissingHeaders = 0;
  specs.forEach(function (spec) {
    var sheet = masterSs.getSheetByName(spec.name);
    var headerMap = sheet ? CC_headerMap_(sheet) : {};
    var missing = [];
    spec.required.forEach(function (h) {
      if (!headerMap[h]) missing.push(h);
    });
    if (!sheet) missingSheets.push(spec.name);
    totalMissingHeaders += missing.length;
    sheets.push({
      sheetName: spec.name,
      exists: !!sheet,
      rowCount: sheet ? CC_countRows_(sheet) : 0,
      requiredHeaderCount: spec.required.length,
      currentHeaderCount: sheet ? sheet.getLastColumn() : 0,
      missingHeaderCount: missing.length,
      missingHeaders: missing,
      ok: !!sheet && missing.length === 0,
      actualCreateBlocked: true,
      actualHeaderAddBlocked: true,
      actualWriteBlocked: true
    });
  });
  return {
    ok: missingSheets.length === 0 && totalMissingHeaders === 0,
    masterDbName: masterSs.getName(),
    missingSheets: missingSheets,
    totalMissingHeaders: totalMissingHeaders,
    sheets: sheets,
    message: 'PORTAL_EVENT_B50 배포 전 게이트 로그 구조를 조회만 했습니다. 생성/헤더추가는 차단입니다.'
  };
}

function CC06_checkBackupEvidence_(masterSs) {
  var sheet = masterSs.getSheetByName('BackupLog');
  var rows = CC_getRowsAsObjects_(sheet);
  var hits = [];
  rows.forEach(function (row) {
    var text = CC06_rowText_(row);
    var projectCode = String(row.projectCode || row.sourceProject || '').toUpperCase();
    var status = String(row.backupStatus || row.status || '').toUpperCase();
    var related = text.indexOf('PORTAL_EVENT_B50') >= 0 || text.indexOf('B50_FINAL_STABLE') >= 0 || text.indexOf('PORTAL_EVENT_B50_CHANGED_ONLY') >= 0;
    var projectMatch = projectCode === 'PORTAL_EVENT' || projectCode === 'PORTAL' || projectCode === 'PORTAL_EVENT_MANAGEMENT';
    var executedOrReady = status.indexOf('COMPLETED') >= 0 || status.indexOf('READY') >= 0 || status.indexOf('BACKUP') >= 0;
    if ((related || projectMatch) && executedOrReady) hits.push(row);
  });
  return {
    ok: hits.length > 0,
    evidenceCount: hits.length,
    sheetName: 'BackupLog',
    searchedBuildNo: CC06_PORTAL_EVENT_BASELINE.buildNo,
    searchedFile: CC06_PORTAL_EVENT_BASELINE.changedOnlyFile,
    latestEvidence: hits.length ? CC06_pickSafeEvidence_(hits[hits.length - 1]) : null,
    backupExecutedByThisGate: false,
    actualWriteExecuted: false,
    message: hits.length ? 'PORTAL_EVENT_B50 관련 백업 증빙 후보가 확인되었습니다.' : 'PORTAL_EVENT_B50 관련 백업 증빙 후보가 아직 없습니다. 배포 전 HOLD 조건입니다.'
  };
}


function CC06_checkDriveEvidenceFromSystemConfig_(config) {
  if (typeof CC07_scanDriveEvidence_ === 'function') {
    var evidence = CC07_scanDriveEvidence_(config || {});
    evidence.source = 'CC07_scanDriveEvidence_';
    evidence.actualWriteExecuted = false;
    evidence.fileCreated = false;
    evidence.fileDeleted = false;
    return evidence;
  }
  var folderKeys = [
    'PORTAL_EVENT_BACKUP_FOLDER_ID',
    'PORTAL_EVENT_ROLLBACK_FOLDER_ID',
    'BACKUP_PORTAL_FOLDER_ID',
    'BACKUP_FOLDER_ID',
    'BACKUP_DB_FOLDER_ID',
    'BACKUP_ERP_FOLDER_ID',
    'PORTAL_APP_FOLDER_ID',
    'EXPORT_FOLDER_ID'
  ];
  var scanned = [];
  var backupFiles = [];
  var rollbackFiles = [];
  folderKeys.forEach(function (key) {
    var folderId = String((config || {})[key] || '').trim();
    if (!folderId) return;
    var info = { key: key, ok: false, fileScanCount: 0, error: '' };
    try {
      var folder = DriveApp.getFolderById(folderId);
      info.ok = true;
      var files = folder.getFiles();
      var limit = 80;
      while (files.hasNext() && info.fileScanCount < limit) {
        var file = files.next();
        info.fileScanCount++;
        var upper = String(file.getName() || '').toUpperCase();
        var related = upper.indexOf('PORTAL_EVENT_B50') >= 0 || upper.indexOf('B50_FINAL_STABLE') >= 0 || upper.indexOf('PORTAL_EVENT_B50_CHANGED_ONLY') >= 0;
        if (!related) continue;
        var safe = { folderKey: key, fileId: file.getId(), fileName: file.getName(), mimeType: file.getMimeType(), updatedAt: file.getLastUpdated ? file.getLastUpdated().toISOString() : '', urlMasked: 'https://drive.google.com/file/d/***/view' };
        if (upper.indexOf('ROLLBACK') >= 0 || upper.indexOf('BASELINE') >= 0 || upper.indexOf('RESTORE') >= 0 || upper.indexOf('RECOVERY') >= 0) rollbackFiles.push(safe);
        if (upper.indexOf('BACKUP') >= 0 || upper.indexOf('CHANGED_ONLY') >= 0 || upper.indexOf('.ZIP') >= 0) backupFiles.push(safe);
      }
    } catch (err) {
      info.error = String(err && err.message ? err.message : err);
    }
    scanned.push(info);
  });
  return {
    ok: backupFiles.length > 0 && rollbackFiles.length > 0,
    backupEvidenceOk: backupFiles.length > 0,
    rollbackEvidenceOk: rollbackFiles.length > 0,
    scannedFolderCount: scanned.length,
    backupFileCount: backupFiles.length,
    rollbackFileCount: rollbackFiles.length,
    scannedFolders: scanned,
    latestBackupEvidence: backupFiles.length ? backupFiles[backupFiles.length - 1] : null,
    latestRollbackEvidence: rollbackFiles.length ? rollbackFiles[rollbackFiles.length - 1] : null,
    source: 'CC06_INTERNAL_DRIVE_SCAN_FALLBACK',
    actualWriteExecuted: false,
    fileCreated: false,
    fileDeleted: false,
    message: 'SystemConfig 백업/롤백 후보 폴더를 조회만 했습니다. 파일 생성/삭제/이동은 하지 않습니다.'
  };
}

function CC06_checkRollbackEvidence_(masterSs, backupEvidence) {
  var recoverySheet = masterSs.getSheetByName('RecoveryLog');
  var recoveryRows = CC_getRowsAsObjects_(recoverySheet);
  var hits = [];
  recoveryRows.forEach(function (row) {
    var text = CC06_rowText_(row);
    var projectCode = String(row.projectCode || '').toUpperCase();
    var related = text.indexOf('PORTAL_EVENT_B50') >= 0 || text.indexOf('B50_FINAL_STABLE') >= 0 || text.indexOf('PORTAL_EVENT_B50_CHANGED_ONLY') >= 0;
    var projectMatch = projectCode === 'PORTAL_EVENT' || projectCode === 'PORTAL' || projectCode === 'PORTAL_EVENT_MANAGEMENT';
    if (related || projectMatch) hits.push(row);
  });
  var backupHasRollbackBaseline = Boolean(backupEvidence && backupEvidence.latestEvidence && backupEvidence.latestEvidence.rollbackBaselineId);
  return {
    ok: hits.length > 0 || backupHasRollbackBaseline,
    recoveryEvidenceCount: hits.length,
    backupHasRollbackBaseline: backupHasRollbackBaseline,
    latestRecoveryEvidence: hits.length ? CC06_pickSafeEvidence_(hits[hits.length - 1]) : null,
    rollbackExecutedByThisGate: false,
    actualWriteExecuted: false,
    message: (hits.length > 0 || backupHasRollbackBaseline) ? 'PORTAL_EVENT_B50 롤백 기준 증빙 후보가 확인되었습니다.' : 'PORTAL_EVENT_B50 롤백 기준 파일/rollbackBaselineId 증빙이 아직 없습니다. 배포 전 HOLD 조건입니다.'
  };
}

function CC06_checkApprovalAndExecutionBlock_(masterSs) {
  var sheet = masterSs.getSheetByName('ApprovalLog');
  var rows = CC_getRowsAsObjects_(sheet);
  var approvedHits = [];
  rows.forEach(function (row) {
    var status = String(row.approvalStatus || '').toUpperCase();
    var active = String(row.status || '').toUpperCase();
    var action = String(row.targetAction || '').toUpperCase();
    var scope = String(row.approvalScope || '').toUpperCase();
    var related = CC06_rowText_(row).indexOf('PORTAL_EVENT_B50') >= 0 || CC06_rowText_(row).indexOf('PORTAL_EVENT_B50_FINAL_STABLE_READONLY_20260611') >= 0;
    if (status === 'APPROVED' && active !== 'CANCELLED' && active !== 'EXPIRED' && related && (action || scope)) {
      approvedHits.push(row);
    }
  });
  return {
    ok: true,
    approvalSheetExists: !!sheet,
    approvedPortalEventB50Count: approvedHits.length,
    approvalRequiredBeforeActualExecution: true,
    operationSaveBlocked: true,
    erpApplyBlocked: true,
    fieldOpenBlocked: true,
    finalApprovalExecuted: false,
    approvalWriteExecuted: false,
    policy: 'CONTROL 승인, 백업, 롤백 기준 확인 전에는 운영 저장/ERP 반영/현장 오픈 실행을 허용하지 않습니다.',
    message: approvedHits.length ? '승인 후보는 조회만 했습니다. 이 게이트는 실제 실행을 열지 않습니다.' : 'PORTAL_EVENT_B50 실제 운영 전환 승인은 아직 조회되지 않았으며, 실행은 차단됩니다.'
  };
}

function CC06_checkOperationBlock_() {
  return {
    ok: true,
    diagnosticOnly: true,
    dryRunOnly: true,
    actualExecutionBlocked: true,
    deployAllowed: false,
    actualBackupAllowed: false,
    actualDeployAllowed: false,
    actualRecoveryAllowed: false,
    actualRollbackAllowed: false,
    actualPortalSaveAllowed: false,
    actualErpApplyAllowed: false,
    actualFieldOpenAllowed: false,
    policy: '이번 CONTROL 게이트는 배포 전 진단만 수행합니다. 실제 운영 오픈 실행은 별도 승인/백업/롤백 확인 전까지 금지입니다.'
  };
}

function CC06_rowText_(row) {
  var parts = [];
  Object.keys(row || {}).forEach(function (k) {
    parts.push(String(k || ''));
    parts.push(String(row[k] || ''));
  });
  return parts.join(' ').toUpperCase();
}

function CC06_pickSafeEvidence_(row) {
  return {
    approvalId: row.approvalId || '',
    backupId: row.backupId || '',
    deployId: row.deployId || '',
    recoveryId: row.recoveryId || '',
    rollbackBaselineId: row.rollbackBaselineId || '',
    projectCode: row.projectCode || row.sourceProject || '',
    buildNo: row.buildNo || row.buildRange || row.relatedBuild || '',
    status: row.status || row.backupStatus || row.deployStatus || row.recoveryStatus || '',
    createdAt: row.createdAt || row.backupStartedAt || row.startedAt || ''
  };
}

function CC06_result_(summary, fatal, warnings, hold, details) {
  var blocked = fatal && fatal.length > 0;
  var holding = !blocked && hold && hold.length > 0;
  summary.ok = !blocked;
  summary.judgement = blocked ? 'BLOCK' : (holding ? 'HOLD' : 'PASS');
  summary.deployAllowed = false;
  summary.actualExecutionBlocked = true;
  return {
    ok: summary.ok,
    build: CC06_BUILD,
    mode: CC06_MODE,
    checkedAt: CC_now_(),
    judgement: summary.judgement,
    summary: summary,
    warnings: warnings || [],
    hold: hold || [],
    fatal: fatal || [],
    details: details,
    nextAction: CC06_nextAction_(summary.judgement)
  };
}

function CC06_nextAction_(judgement) {
  if (judgement === 'PASS') {
    return 'PORTAL_EVENT_B50 배포 전 진단 PASS. 단, 실제 운영 저장/ERP 반영/현장 오픈은 CONTROL 별도 승인 단계 전까지 계속 금지입니다.';
  }
  if (judgement === 'HOLD') {
    return 'PORTAL_EVENT_B50 배포 전 진단 HOLD. 백업 생성 증빙과 롤백 기준 파일 보관 증빙을 확인한 뒤 재진단하세요.';
  }
  return 'PORTAL_EVENT_B50 배포 전 진단 BLOCK. fatal 항목을 해결하기 전 운영 전환하지 마세요.';
}

function CC06_guidance_() {
  return {
    pageTitle: 'PORTAL 행사관리 B50 배포 전 진단 게이트',
    mainStatusText: 'PORTAL_EVENT_B50 기준선, SystemConfig, MASTER, 백업/롤백 증빙, CONTROL 승인 차단 상태를 진단합니다.',
    successText: 'PORTAL_EVENT_B50 배포 전 진단을 완료했습니다.',
    holdText: '백업/롤백 증빙이 없으면 HOLD로 멈추고 운영 전환하지 않습니다.',
    errorText: 'PORTAL_EVENT_B50 배포 전 진단 중 BLOCK 항목이 발생했습니다.',
    readonlyText: '이번 게이트는 조회/진단 전용이며 운영 저장, ERP 반영, 현장 오픈, 백업/복구/롤백/배포를 실행하지 않습니다.'
  };
}
