function assertControlFinal9411000Blocked_() {
  var safety = getControlFinal9411000Safety_();
  var blocked = safety.noActualBackup && safety.noActualDeploy && safety.noActualRollback && safety.actualExecutionBlocked;
  return {
    ok: blocked,
    build: CONTROL_FINAL_941_1000_BUILD,
    deployAllowed: safety.deployAllowed,
    actualExecutionBlocked: safety.actualExecutionBlocked,
    noActualBackup: safety.noActualBackup,
    noActualDeploy: safety.noActualDeploy,
    noActualRollback: safety.noActualRollback,
    message: blocked ? '실제 백업/배포/롤백 차단 정상' : '차단값 이상'
  };
}
