/**
 * FEELHAUS CONTROL - GROUPWARE B90 DEPLOY ALLOWED GATE
 * Build: CONTROL_GROUPWARE_B90_DEPLOY_ALLOWED_GATE_V01
 * Progress: [05/10] 50%
 * Target baseline: GROUPWARE_B90_FINAL_STABLE_AFTER_B70_B90_RUNALL
 * Execution function: runControlGroupwareB90DeployAllowedGateV01
 *
 * Safety:
 * - Diagnostic only
 * - Sheet read only
 * - No sheet creation
 * - No header mutation
 * - No approval writing
 * - No audit log writing
 * - No backup/deploy/recovery/rollback execution
 * - No GROUPWARE production save
 * - No field open execution
 * - No real apply execution
 */
var CC18_BUILD = 'CONTROL_GROUPWARE_B90_DEPLOY_ALLOWED_GATE_V01';
var CC18_MODE = 'GROUPWARE_B90_DEPLOY_ALLOWED_GATE_DIAGNOSTIC_ONLY_NO_UPDATE';
var CC18_PROGRESS = { current: 5, total: 10, percent: 50 };
var CC18_SETUP_DB_ID = '17VMSpgSZCvIrUlgcw8yCNcnl8WQWo2IcRf5tDCcuJGM';
var CC18_CONFIG_SHEET_NAME = 'SystemConfig';
var CC18_SOURCE_DB = 'FEELHAUS_SETUP_DB';
var CC18_TARGET = {
  projectCode: 'GROUPWARE',
  moduleCode: 'GROUPWARE_PORTAL_HR_MAIL_CALENDAR',
  buildRange: 'B70~B90',
  currentBuildNo: 'B90',
  finalBuildNo: 'B90',
  buildProgress: '90 / 90',
  progressPercent: 100,
  runAllStatus: 'GROUPWARE_B70_TO_B90_RUNALL_PASS',
  protectedBaseline: 'B70~B89',
  finalStableName: 'GROUPWARE_B90_FINAL_STABLE',
  preDeployGateBuild: 'CONTROL_GROUPWARE_B90_PREDEPLOY_GATE_V01',
  backupRollbackGateBuild: 'CONTROL_GROUPWARE_B90_BACKUP_ROLLBACK_EVIDENCE_V01',
  approvalGateBuild: 'CONTROL_GROUPWARE_B90_APPROVAL_GATE_V01',
  requiredApprovalType: 'GROUPWARE_B90_PREDEPLOY_APPROVAL',
  requiredApprovalScope: 'GROUPWARE_B90_DEPLOY',
  requiredTargetAction: 'GROUPWARE_B90_DEPLOY_ALLOWED_GATE',
  relatedBuild: 'GROUPWARE_B90_FINAL_STABLE'
};

function runControlGroupwareB90DeployAllowedGateV01() {
  var result = diagnoseControlGroupwareB90DeployAllowedGateV01_();
  CC18_logCompactResult_(result);
  return result;
}

function runGroupwareB90DeployAllowedGateV01() {
  var result = diagnoseControlGroupwareB90DeployAllowedGateV01_();
  CC18_logCompactResult_(result);
  return result;
}

function getControlGroupwareB90DeployAllowedGateData() {
  var result = diagnoseControlGroupwareB90DeployAllowedGateV01_();
  CC18_logCompactResult_(result);
  return result;
}

function controlGroupwareB90DeployAllowedGateV01() {
  var result = diagnoseControlGroupwareB90DeployAllowedGateV01_();
  CC18_logCompactResult_(result);
  return result;
}

function diagnoseControlGroupwareB90DeployAllowedGateV01_() {
  var started = new Date();
  var fatal = [];
  var hold = [];
  var warnings = [];
  var details = {};
  var summary = CC18_defaultSummary_();

  try {
    details.setup = CC18_readSystemConfig_();
    summary.configOk = details.setup.ok === true;
    summary.systemConfigAutoReadOk = details.setup.ok === true;
  } catch (e1) {
    fatal.push('SystemConfig auto read failed: ' + CC18_errorMessage_(e1));
    details.setup = { ok: false, error: CC18_errorMessage_(e1), config: {} };
  }

  try {
    var cfg = details.setup && details.setup.config ? details.setup.config : {};
    details.master = CC18_openMasterDb_(cfg);
    summary.masterOk = details.master.ok === true;
    summary.masterConnectedOk = details.master.ok === true;
  } catch (e2) {
    fatal.push('FEELHAUS_DB_MASTER open failed: ' + CC18_errorMessage_(e2));
    details.master = { ok: false, error: CC18_errorMessage_(e2) };
  }

  details.approvalGate = CC18_checkApprovalGate_();
  summary.approvalGatePassed = details.approvalGate.passed === true;
  summary.approvalEvidenceOk = details.approvalGate.approvalEvidenceOk === true;
  summary.approvalScopeOk = details.approvalGate.approvalScopeOk === true;
  summary.approvalStatusOk = details.approvalGate.approvalStatusOk === true;
  summary.approvalActorOk = details.approvalGate.approvalActorOk === true;
  summary.backupRollbackGatePassed = details.approvalGate.backupRollbackGatePassed === true;
  summary.backupRollbackEvidenceOk = details.approvalGate.backupRollbackEvidenceOk === true;

  details.operationBlock = CC18_operationBlock_();
  summary.productionSaveAllowed = false;
  summary.fieldUseOpenAllowed = false;
  summary.deployAllowed = summary.configOk && summary.masterOk && summary.approvalGatePassed && summary.backupRollbackGatePassed && summary.backupRollbackEvidenceOk && summary.approvalEvidenceOk && summary.approvalScopeOk && summary.approvalStatusOk && summary.approvalActorOk;
  summary.realApplyAllowed = false;
  summary.actualExecutionBlocked = true;
  summary.actualDeployAllowed = false;
  summary.diagnosticOnly = true;
  summary.dryRunOnly = true;

  if (!summary.approvalGatePassed) hold.push('[04/10] CONTROL_GROUPWARE_B90_APPROVAL_GATE_V01 PASS check required');
  if (!summary.backupRollbackGatePassed) hold.push('[03/10] backup/rollback evidence PASS check required');
  if (!summary.approvalEvidenceOk) hold.push('GROUPWARE B90 predeploy approval evidence required');
  if (!summary.deployAllowed) hold.push('GROUPWARE B90 deployAllowed candidate is not ready');

  var passConditions = [
    summary.configOk,
    summary.masterOk,
    summary.approvalGatePassed,
    summary.backupRollbackGatePassed,
    summary.backupRollbackEvidenceOk,
    summary.approvalEvidenceOk,
    summary.approvalScopeOk,
    summary.approvalStatusOk,
    summary.approvalActorOk,
    summary.deployAllowed,
    summary.actualExecutionBlocked,
    summary.actualDeployAllowed === false,
    summary.productionSaveAllowed === false,
    summary.fieldUseOpenAllowed === false,
    summary.realApplyAllowed === false
  ];

  var allPass = fatal.length === 0 && hold.length === 0 && CC18_allTrue_(passConditions);
  var judgement = fatal.length > 0 ? 'BLOCK' : (allPass ? 'PASS' : 'HOLD');
  summary.deployAllowedGateOk = judgement === 'PASS';
  summary.judgement = judgement;

  return {
    ok: judgement === 'PASS',
    build: CC18_BUILD,
    progress: CC18_PROGRESS,
    mode: CC18_MODE,
    checkedAt: CC18_now_(),
    judgement: judgement,
    targetBaseline: CC18_TARGET,
    summary: summary,
    evidence: {
      setupDbId: CC18_SETUP_DB_ID,
      configSheetName: CC18_CONFIG_SHEET_NAME,
      sourceDb: CC18_SOURCE_DB,
      setupDbName: details.setup && details.setup.setupDbName || '',
      masterDbIdMasked: CC18_maskId_(details.master && details.master.masterDbId || ''),
      masterDbName: details.master && details.master.masterDbName || '',
      approvalGate: details.approvalGate || {},
      latestGroupwareB90Approval: details.approvalGate && details.approvalGate.latestGroupwareB90Approval || null,
      deployAllowedReason: summary.deployAllowed ? '[05/10] Deploy allowed candidate PASS. Previous gates and approval evidence were confirmed. This gate still executes no production change.' : '',
      actualBackupAllowed: false,
      actualDeployAllowed: false,
      actualRecoveryAllowed: false,
      actualRollbackAllowed: false,
      actualProductionSaveAllowed: false,
      actualFieldUseOpenAllowed: false,
      actualRealApplyAllowed: false,
      operationBlock: details.operationBlock || {},
      elapsedMs: new Date().getTime() - started.getTime()
    },
    warnings: warnings,
    hold: hold,
    fatal: fatal,
    nextAction: judgement === 'PASS'
      ? '[05/10] GROUPWARE B90 deploy allowed gate PASS. Next step is [06/10] field use open decision gate. This gate executed no production change.'
      : '[05/10] GROUPWARE B90 deploy allowed gate is not PASS. Fix hold items, then rerun.'
  };
}

function CC18_defaultSummary_() {
  return {
    baselineOk: true,
    configOk: false,
    masterOk: false,
    systemConfigAutoReadOk: false,
    masterConnectedOk: false,
    backupRollbackGatePassed: false,
    backupRollbackEvidenceOk: false,
    approvalGatePassed: false,
    approvalEvidenceOk: false,
    approvalScopeOk: false,
    approvalStatusOk: false,
    approvalActorOk: false,
    deployAllowedGateOk: false,
    productionSaveAllowed: false,
    fieldUseOpenAllowed: false,
    deployAllowed: false,
    realApplyAllowed: false,
    actualExecutionBlocked: true,
    actualDeployAllowed: false,
    diagnosticOnly: true,
    dryRunOnly: true,
    sheetWriteExecuted: false,
    sheetCreateExecuted: false,
    headerAutoAddExecuted: false,
    approvalWriteExecuted: false,
    auditLogWriteExecuted: false,
    backupExecuted: false,
    deployExecuted: false,
    recoveryExecuted: false,
    rollbackExecuted: false,
    realApplyExecuted: false,
    productionDataMutationExecuted: false
  };
}

function CC18_checkApprovalGate_() {
  var out = { checked: false, available: false, passed: false };
  try {
    if (typeof runControlGroupwareB90ApprovalGateV01 !== 'function') {
      out.error = 'runControlGroupwareB90ApprovalGateV01 not found';
      return out;
    }
    var result = runControlGroupwareB90ApprovalGateV01();
    out.checked = true;
    out.available = true;
    out.passed = result && result.judgement === 'PASS' && result.ok === true;
    out.build = result && result.build || '';
    out.judgement = result && result.judgement || '';
    var s = result && result.summary || {};
    var e = result && result.evidence || {};
    out.backupRollbackGatePassed = s.backupRollbackGatePassed === true;
    out.backupRollbackEvidenceOk = s.backupRollbackEvidenceOk === true;
    out.approvalEvidenceOk = s.approvalEvidenceOk === true;
    out.approvalScopeOk = s.approvalScopeOk === true;
    out.approvalStatusOk = s.approvalStatusOk === true;
    out.approvalActorOk = s.approvalActorOk === true;
    out.latestGroupwareB90Approval = e.latestGroupwareB90Approval || null;
  } catch (e) {
    out.checked = true;
    out.available = false;
    out.passed = false;
    out.error = CC18_errorMessage_(e);
  }
  return out;
}

function CC18_readSystemConfig_() {
  var ss = SpreadsheetApp.openById(CC18_SETUP_DB_ID);
  var sheet = ss.getSheetByName(CC18_CONFIG_SHEET_NAME);
  if (!sheet) throw new Error('SystemConfig sheet not found: ' + CC18_CONFIG_SHEET_NAME);
  var values = sheet.getDataRange().getValues();
  var config = {};
  for (var i = 1; i < values.length; i++) {
    var key = String(values[i][0] || '').trim();
    var value = values[i][1];
    if (key) config[key] = value;
  }
  return { ok: true, setupDbId: CC18_SETUP_DB_ID, setupDbName: ss.getName(), sourceDb: CC18_SOURCE_DB, sheetName: CC18_CONFIG_SHEET_NAME, config: config };
}

function CC18_openMasterDb_(config) {
  config = config || {};
  var id = String(config.FEELHAUS_DB_MASTER_ID || config.FEELHAUS_DB_MASTER || config.DB_MASTER_ID || config.MASTER_DB_ID || '').trim();
  if (!id) throw new Error('FEELHAUS_DB_MASTER_ID is missing in SystemConfig');
  var ss = SpreadsheetApp.openById(id);
  return { ok: true, masterDbId: id, masterDbName: ss.getName(), ss: ss };
}

function CC18_operationBlock_() {
  return {
    productionSaveAllowed: false,
    fieldUseOpenAllowed: false,
    deployAllowedCandidateOnly: true,
    actualDeployAllowed: false,
    realApplyAllowed: false,
    actualExecutionBlocked: true,
    sheetWriteExecuted: false,
    sheetCreateExecuted: false,
    headerAutoAddExecuted: false,
    approvalWriteExecuted: false,
    auditLogWriteExecuted: false,
    backupExecuted: false,
    deployExecuted: false,
    recoveryExecuted: false,
    rollbackExecuted: false,
    realApplyExecuted: false,
    productionDataMutationExecuted: false
  };
}

function CC18_logCompactResult_(obj) {
  try {
    Logger.log('JSON_COMPACT_RESULT: ' + JSON.stringify(obj));
  } catch (e) {
    Logger.log('JSON_COMPACT_RESULT_LOG_FAILED: ' + CC18_errorMessage_(e));
  }
}

function CC18_allTrue_(arr) {
  for (var i = 0; i < arr.length; i++) if (arr[i] !== true) return false;
  return true;
}

function CC18_now_() {
  return Utilities.formatDate(new Date(), 'Asia/Seoul', "yyyy-MM-dd'T'HH:mm:ssXXX");
}

function CC18_maskId_(id) {
  id = String(id || '');
  if (!id) return '';
  if (id.length <= 8) return '***';
  return id.substring(0, 4) + '***' + id.substring(id.length - 4);
}

function CC18_errorMessage_(err) {
  return err && err.message ? err.message : String(err || 'unknown error');
}
