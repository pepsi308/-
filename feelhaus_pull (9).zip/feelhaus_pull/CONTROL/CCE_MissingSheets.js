function checkControlErpCoreB06J41_081_160_MissingSheets() {
  var master = cceB06J41_081_160_openMasterDb_();
  var definitions = cceB06J41_081_160_getMissingSheetDefinitions_();
  var safety = cceB06J41_081_160_getSafety_();
  if (!master.ok) {
    return { ok: false, build: CCE_B06J41_081_160.BUILD, masterDb: master, candidates: [], safety: safety };
  }
  var ss = master.spreadsheet;
  var candidates = definitions.map(function (def) {
    var sheet = ss.getSheetByName(def.sheetName);
    var exists = !!sheet;
    var headerMap = exists ? cceB06J41_081_160_getHeaderMap_(sheet) : {};
    var currentHeaders = Object.keys(headerMap);
    var missingHeaders = def.requiredHeaders.filter(function (h) { return !headerMap[h]; });
    return {
      sheetName: def.sheetName,
      workArea: def.workArea,
      projectCode: def.projectCode,
      exists: exists,
      missing: !exists,
      currentHeaderCount: currentHeaders.length,
      requiredHeaders: def.requiredHeaders,
      requiredHeaderCount: def.requiredHeaders.length,
      missingHeaders: missingHeaders,
      missingHeaderCount: missingHeaders.length,
      actionType: exists ? (missingHeaders.length ? 'HEADER_REVIEW_CANDIDATE_ONLY' : 'READY') : 'SHEET_CREATE_CANDIDATE_ONLY',
      actualSheetCreateBlocked: true,
      actualHeaderAddBlocked: true,
      approvalRequired: true,
      deleteCandidate: false,
      archiveCandidate: false,
      message: exists ? '시트가 존재합니다. 헤더만 검토합니다.' : '누락 시트입니다. 생성 필요 후보로만 표시합니다.'
    };
  });
  var missingSheets = candidates.filter(function (c) { return c.missing; }).map(function (c) { return c.sheetName; });
  var totalMissingHeaders = candidates.reduce(function (sum, c) { return sum + c.missingHeaderCount; }, 0);
  return {
    ok: true,
    build: CCE_B06J41_081_160.BUILD,
    masterDbName: master.masterDbName,
    missingSheetCount: missingSheets.length,
    missingSheets: missingSheets,
    totalMissingHeaders: totalMissingHeaders,
    candidates: candidates,
    safety: safety,
    message: '누락 시트/헤더 후보를 생성하지 않고 승인 전 검토 목록으로 표시했습니다.'
  };
}
