
/**
 * CONTROL runner functions for Backup/Deploy/Recovery log policy creation.
 */
function runStep1_ControlLogPolicyCreateDryRun() {
  var result = controlLogPolicyCreate_dryRun();
  Logger.log('[CONTROL LOG POLICY CREATE STEP1 DRY RUN RESULT] ' + JSON.stringify(result, null, 2));
  return result;
}

function runStep2_BlockedControlLogPolicyCreateTest() {
  var result = controlLogPolicyCreate_execute({
    logPolicyCreateConfirm: false,
    approvalCode: '',
    businessDataWriteAllowed: false,
    deployAllowed: false
  });
  Logger.log('[CONTROL LOG POLICY CREATE STEP2 BLOCKED TEST RESULT] ' + JSON.stringify(result, null, 2));
  return result;
}

function runStep3_ApprovedControlLogPolicyCreate() {
  var result = controlLogPolicyCreate_execute({
    logPolicyCreateConfirm: true,
    approvalCode: 'CONTROL_LOG_POLICY_CREATE_APPROVED_3_LOG_SHEETS_ONLY',
    businessDataWriteAllowed: false,
    deployAllowed: false
  });
  Logger.log('[CONTROL LOG POLICY CREATE STEP3 APPROVED RESULT] ' + JSON.stringify(result, null, 2));
  return result;
}

function runStep4_ControlLogPolicyPostCreateCheck() {
  var result = controlLogPolicyCreate_postCreateCheck();
  Logger.log('[CONTROL LOG POLICY CREATE STEP4 POST CREATE CHECK RESULT] ' + JSON.stringify(result, null, 2));
  return result;
}

function runStep5_ControlLogPolicyCreateSelfTest() {
  var result = controlLogPolicyCreate_selfTest();
  Logger.log('[CONTROL LOG POLICY CREATE STEP5 SELFTEST RESULT] ' + JSON.stringify(result, null, 2));
  return result;
}

function runStep6_ControlDeployFinalGateAllReadOnlyAfterLogCreate() {
  if (typeof controlErpCoreDeployFinalGateBundle_runAllReadOnly !== 'function') {
    var missing = { ok: false, fatal: ['controlErpCoreDeployFinalGateBundle_runAllReadOnly 함수가 없습니다. 최종 게이트 번들을 먼저 반영하세요.'] };
    Logger.log('[CONTROL LOG POLICY CREATE STEP6 FINAL GATE RECHECK RESULT] ' + JSON.stringify(missing, null, 2));
    return missing;
  }
  var result = controlErpCoreDeployFinalGateBundle_runAllReadOnly();
  Logger.log('[CONTROL LOG POLICY CREATE STEP6 FINAL GATE RECHECK RESULT] ' + JSON.stringify(result, null, 2));
  return result;
}
