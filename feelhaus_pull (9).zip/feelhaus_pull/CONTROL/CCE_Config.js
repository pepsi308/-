/**
 * CONTROL_B06J41_081_160_ERP_CORE_MISSING_SHEET_APPROVAL_SAFE
 * Safe/DryRun only. No sheet create, no header add, no deploy.
 */
var CCE_B06J41_081_160 = CCE_B06J41_081_160 || {};

CCE_B06J41_081_160.BUILD = 'CONTROL_B06J41_081_160_ERP_CORE_MISSING_SHEET_APPROVAL_SAFE';
CCE_B06J41_081_160.PREVIOUS_ERP_CORE_BUILD = 'ERP_CORE_B06J41_161_240_PRE_DEPLOY_UI_FUNCTION_AUDIT_SAFE';
CCE_B06J41_081_160.SETUP_DB_ID = '17VMSpgSZCvIrUlgcw8yCNcnl8WQWo2IcRf5tDCcuJGM';
CCE_B06J41_081_160.CONFIG_SHEET_NAME = 'SystemConfig';
CCE_B06J41_081_160.SOURCE_DB = 'FEELHAUS_SETUP_DB';
CCE_B06J41_081_160.PROJECT_CODE = 'ERP_CORE';
CCE_B06J41_081_160.CONTROL_PROJECT_CODE = 'CONTROL';

function cceB06J41_081_160_getBuildInfo_() {
  return {
    ok: true,
    build: CCE_B06J41_081_160.BUILD,
    previousErpCoreBuild: CCE_B06J41_081_160.PREVIOUS_ERP_CORE_BUILD,
    projectCode: CCE_B06J41_081_160.PROJECT_CODE,
    controlProjectCode: CCE_B06J41_081_160.CONTROL_PROJECT_CODE,
    sourceDb: CCE_B06J41_081_160.SOURCE_DB,
    setupDbId: CCE_B06J41_081_160.SETUP_DB_ID,
    configSheetName: CCE_B06J41_081_160.CONFIG_SHEET_NAME,
    deployAllowed: false,
    actualCreateConfirm: false,
    actualExecutionBlocked: true
  };
}

function cceB06J41_081_160_getSafety_() {
  return {
    dryRunOnly: true,
    approvalPrecheckOnly: true,
    deployAllowed: false,
    actualCreateConfirm: false,
    noSheetCreate: true,
    noSheetWrite: true,
    noHeaderAutoAdd: true,
    noDbInjection: true,
    noActualDeploy: true,
    noActualRecovery: true,
    noActualRollback: true,
    noSettlementExecution: true,
    noPaymentExecution: true,
    noRecoveryExecution: true,
    noRoleMutation: true,
    noProtectedSheetDelete: true,
    noArchiveByNewSheetReason: true,
    actualExecutionBlocked: true
  };
}

function cceB06J41_081_160_getErpCoreAuditSummary_() {
  return {
    ok: true,
    build: CCE_B06J41_081_160.PREVIOUS_ERP_CORE_BUILD,
    selfTest: 'PASS',
    routeSmokeTest: 'PASS',
    webUiTest: 'PASS',
    fatalErrorCount: 0,
    warningCount: 6,
    readySheetCount: 6,
    missingSheetCount: 6,
    status: 'ERP_CORE_PRE_DEPLOY_UI_FUNCTION_AUDIT_PASSED__CREATE_STILL_BLOCKED',
    message: 'ERP_CORE 점검 결과 수신 완료. 누락 시트는 오류가 아니라 생성 필요 후보입니다.'
  };
}

function cceB06J41_081_160_openSetupDb_() {
  try {
    var ss = SpreadsheetApp.openById(CCE_B06J41_081_160.SETUP_DB_ID);
    return {
      ok: true,
      setupDbId: CCE_B06J41_081_160.SETUP_DB_ID,
      setupDbName: ss.getName(),
      sourceDb: CCE_B06J41_081_160.SOURCE_DB,
      sheetName: CCE_B06J41_081_160.CONFIG_SHEET_NAME,
      spreadsheet: ss
    };
  } catch (err) {
    return {
      ok: false,
      setupDbId: CCE_B06J41_081_160.SETUP_DB_ID,
      sourceDb: CCE_B06J41_081_160.SOURCE_DB,
      sheetName: CCE_B06J41_081_160.CONFIG_SHEET_NAME,
      error: String(err && err.message ? err.message : err)
    };
  }
}

function cceB06J41_081_160_readSystemConfig_() {
  var opened = cceB06J41_081_160_openSetupDb_();
  if (!opened.ok) return opened;
  var sheet = opened.spreadsheet.getSheetByName(CCE_B06J41_081_160.CONFIG_SHEET_NAME);
  if (!sheet) {
    return {
      ok: false,
      setupDbId: CCE_B06J41_081_160.SETUP_DB_ID,
      setupDbName: opened.setupDbName,
      sheetName: CCE_B06J41_081_160.CONFIG_SHEET_NAME,
      error: 'SystemConfig 시트를 찾을 수 없습니다.'
    };
  }
  var values = sheet.getDataRange().getValues();
  var config = {};
  if (values.length) {
    var header = values[0].map(function (h) { return String(h || '').trim(); });
    var keyIdx = header.indexOf('CONFIG_KEY');
    var valueIdx = header.indexOf('VALUE');
    if (keyIdx < 0) keyIdx = header.indexOf('configKey');
    if (valueIdx < 0) valueIdx = header.indexOf('configValue');
    if (keyIdx < 0) keyIdx = 0;
    if (valueIdx < 0) valueIdx = 1;
    for (var r = 1; r < values.length; r++) {
      var key = String(values[r][keyIdx] || '').trim();
      if (key) config[key] = values[r][valueIdx];
    }
  }
  return {
    ok: true,
    setupDbId: CCE_B06J41_081_160.SETUP_DB_ID,
    setupDbName: opened.setupDbName,
    sourceDb: CCE_B06J41_081_160.SOURCE_DB,
    sheetName: CCE_B06J41_081_160.CONFIG_SHEET_NAME,
    config: config,
    message: 'SystemConfig 읽기 완료'
  };
}

function cceB06J41_081_160_resolveMasterDbId_(configResult) {
  var config = configResult && configResult.config ? configResult.config : {};
  return String(config.FEELHAUS_DB_MASTER_ID || config.DB_MASTER_ID || config.SPREADSHEET_ID || '').trim();
}

function cceB06J41_081_160_openMasterDb_() {
  var configResult = cceB06J41_081_160_readSystemConfig_();
  if (!configResult.ok) return { ok: false, config: configResult, error: 'SystemConfig 읽기 실패' };
  var masterDbId = cceB06J41_081_160_resolveMasterDbId_(configResult);
  if (!masterDbId) return { ok: false, config: configResult, error: 'FEELHAUS_DB_MASTER_ID를 찾을 수 없습니다.' };
  try {
    var ss = SpreadsheetApp.openById(masterDbId);
    return {
      ok: true,
      masterDbId: masterDbId,
      masterDbName: ss.getName(),
      spreadsheet: ss,
      config: configResult,
      message: 'FEELHAUS_DB_MASTER 연결 확인 완료'
    };
  } catch (err) {
    return {
      ok: false,
      masterDbId: masterDbId,
      config: configResult,
      error: String(err && err.message ? err.message : err)
    };
  }
}

function cceB06J41_081_160_getHeaderMap_(sheet) {
  if (!sheet || sheet.getLastColumn() < 1) return {};
  var values = sheet.getRange(1, 1, 1, sheet.getLastColumn()).getValues()[0];
  var map = {};
  values.forEach(function (h, i) {
    var key = String(h || '').trim();
    if (key && !map[key]) map[key] = i + 1;
  });
  return map;
}

function cceB06J41_081_160_getCommonHeaders_() {
  return ['eventId', 'vendorId', 'customerId', 'status', 'statusReason', 'createdAt', 'createdBy', 'updatedAt', 'updatedBy'];
}

function cceB06J41_081_160_getMissingSheetDefinitions_() {
  var common = cceB06J41_081_160_getCommonHeaders_();
  return [
    { sheetName: 'ERP_판매관리', workArea: '판매관리', extendedHeaders: ['saleId'] },
    { sheetName: 'ERP_계약관리', workArea: '계약관리', extendedHeaders: ['contractId', 'saleId'] },
    { sheetName: 'ERP_설치관리', workArea: '설치관리', extendedHeaders: ['installId', 'saleId', 'contractId'] },
    { sheetName: 'ERP_AS관리', workArea: 'A/S관리', extendedHeaders: ['asId', 'customerId', 'saleId'] },
    { sheetName: 'ERP_정산관리', workArea: '정산관리', extendedHeaders: ['settlementId', 'saleId', 'contractId', 'vendorId'] },
    { sheetName: 'ERP_사용자관리', workArea: '사용자관리', extendedHeaders: ['userId', 'vendorId', 'roleCode'] }
  ].map(function (item) {
    var headers = common.slice();
    item.extendedHeaders.forEach(function (h) { if (headers.indexOf(h) < 0) headers.push(h); });
    item.requiredHeaders = headers;
    item.projectCode = CCE_B06J41_081_160.PROJECT_CODE;
    item.approvalRequired = true;
    item.actualCreateBlocked = true;
    return item;
  });
}
