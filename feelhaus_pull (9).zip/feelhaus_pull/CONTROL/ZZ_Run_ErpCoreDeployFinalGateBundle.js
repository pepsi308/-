
/**
 * CONTROL runner functions for ERP_CORE deploy final gate bundle.
 * Execute these from CONTROL Apps Script project.
 */
function runStep1_ControlDeployFinalGateDryRun() {
  var result = controlErpCoreDeployFinalGateBundle_dryRun();
  Logger.log('[CONTROL ERP_CORE DEPLOY FINAL GATE STEP1 DRY RUN RESULT] ' + JSON.stringify(result, null, 2));
  return result;
}

function runStep2_ControlFinalReadOnlyCheck() {
  var result = controlErpCoreDeployFinalGateBundle_runFinalReadOnlyCheck();
  Logger.log('[CONTROL ERP_CORE DEPLOY FINAL GATE STEP2 FINAL READ ONLY CHECK RESULT] ' + JSON.stringify(result, null, 2));
  return result;
}

function runStep3_ControlUiRouteSmoke() {
  var result = controlErpCoreDeployFinalGateBundle_runUiRouteSmoke();
  Logger.log('[CONTROL ERP_CORE DEPLOY FINAL GATE STEP3 UI ROUTE SMOKE RESULT] ' + JSON.stringify(result, null, 2));
  return result;
}

function runStep4_ControlPermissionFilterSmoke() {
  var result = controlErpCoreDeployFinalGateBundle_runPermissionFilterSmoke();
  Logger.log('[CONTROL ERP_CORE DEPLOY FINAL GATE STEP4 PERMISSION FILTER SMOKE RESULT] ' + JSON.stringify(result, null, 2));
  return result;
}

function runStep5_ControlStateTransitionSimulation() {
  var result = controlErpCoreDeployFinalGateBundle_runStateTransitionSimulation();
  Logger.log('[CONTROL ERP_CORE DEPLOY FINAL GATE STEP5 STATE TRANSITION SIMULATION RESULT] ' + JSON.stringify(result, null, 2));
  return result;
}

function runStep6_ControlBackupRollbackConfirmation() {
  var result = controlErpCoreDeployFinalGateBundle_runBackupRollbackConfirmation();
  Logger.log('[CONTROL ERP_CORE DEPLOY FINAL GATE STEP6 BACKUP ROLLBACK CONFIRMATION RESULT] ' + JSON.stringify(result, null, 2));
  return result;
}

function runStep7_ControlDeployFinalGateAllReadOnly() {
  var result = controlErpCoreDeployFinalGateBundle_runAllReadOnly();
  Logger.log('[CONTROL ERP_CORE DEPLOY FINAL GATE STEP7 ALL READ ONLY RESULT] ' + JSON.stringify(result, null, 2));
  return result;
}

function runStep8_ControlDeployFinalGateSelfTest() {
  var result = controlErpCoreDeployFinalGateBundle_selfTest();
  Logger.log('[CONTROL ERP_CORE DEPLOY FINAL GATE STEP8 SELFTEST RESULT] ' + JSON.stringify(result, null, 2));
  return result;
}
