function ccb701_760_requiredLogSheets_() {
  return [
    { sheetName: 'ApprovalLog', requiredHeaders: ['approvalId','projectCode','controlProjectCode','approvalType','approvalScope','approvalStatus','approvedBy','approvedAt','requestedBy','requestedAt','targetSheetName','targetAction','relatedBuild','relatedDeployId','reason','status','statusReason','createdAt','createdBy','updatedAt','updatedBy','notes'] },
    { sheetName: 'BackupLog', requiredHeaders: ['backupId','projectCode','buildRange','sourceDb','targetDb','backupScope','backupStatus','backupStartedAt','backupCompletedAt','executedBy','relatedDeployId','rollbackBaselineId','notes'] },
    { sheetName: 'RecoveryLog', requiredHeaders: ['recoveryId','rollbackBaselineId','projectCode','baselineBuild','rollbackScope','rollbackAllowed','createdAt','createdBy','reason'] },
    { sheetName: 'DeployLog', requiredHeaders: ['deployId','projectCode','buildNo','deployLevel','deployStatus','approvedBy','approvalId','backupId','rollbackBaselineId','startedAt','completedAt','result','notes'] }
  ];
}

function ccb701_760_checkLogSheetReadiness_() {
  var master = ccb701_760_openMasterDb_();
  if (!master.ok) return { ok: false, master: master, safety: ccb701_760_safety_() };
  var result = [];
  var missingSheets = [];
  var totalMissingHeaders = 0;
  ccb701_760_requiredLogSheets_().forEach(function(def) {
    var sheet = master.spreadsheet.getSheetByName(def.sheetName);
    var exists = !!sheet;
    var headerMap = exists ? ccb701_760_headerMap_(sheet) : {};
    var missingHeaders = def.requiredHeaders.filter(function(h) { return !headerMap[h]; });
    if (!exists) missingSheets.push(def.sheetName);
    totalMissingHeaders += missingHeaders.length;
    result.push({
      sheetName: def.sheetName,
      exists: exists,
      requiredHeaderCount: def.requiredHeaders.length,
      currentHeaderCount: Object.keys(headerMap).length,
      missingHeaderCount: missingHeaders.length,
      missingHeaders: missingHeaders,
      targetAction: exists && missingHeaders.length ? 'ADD_HEADERS_CANDIDATE_ONLY' : (!exists ? 'CREATE_SHEET_AND_HEADERS_CANDIDATE_ONLY' : 'NO_ACTION'),
      actualSheetCreateBlocked: true,
      actualHeaderAddBlocked: true,
      ok: exists && missingHeaders.length === 0
    });
  });
  return {
    ok: true,
    masterDbName: master.masterDbName,
    sheets: result,
    missingSheets: missingSheets,
    totalMissingHeaders: totalMissingHeaders,
    safety: ccb701_760_safety_(),
    message: '로그 시트 구조를 점검했습니다. 실제 생성/헤더 추가는 차단 상태입니다.'
  };
}

function ccb701_760_checkBackupFolders_() {
  var master = ccb701_760_openMasterDb_();
  if (!master.ok) return { ok: false, master: master, safety: ccb701_760_safety_() };
  var config = master.config || {};
  var keys = ['BACKUP_DB_FOLDER_ID','BACKUP_SIGN_FOLDER_ID','BACKUP_PORTAL_FOLDER_ID','BACKUP_ERP_FOLDER_ID','SIGN_BACKUP_FOLDER_ID','LOG_REPORT_FOLDER_ID'];
  var folders = keys.map(function(key) {
    var id = config[key];
    if (!id) return { key: key, existsInConfig: false, accessible: false, message: '설정값 없음' };
    try {
      var folder = DriveApp.getFolderById(String(id));
      return { key: key, folderId: id, existsInConfig: true, accessible: true, folderName: folder.getName(), message: '접근 확인 완료' };
    } catch (err) {
      return { key: key, folderId: id, existsInConfig: true, accessible: false, message: String(err && err.message || err) };
    }
  });
  return {
    ok: folders.every(function(f) { return f.existsInConfig && f.accessible; }),
    dryRun: true,
    folders: folders,
    actualBackupAllowed: false,
    actualBackupExecuted: false,
    safety: ccb701_760_safety_(),
    message: '백업 폴더 접근 가능 여부만 점검했습니다. 실제 백업은 실행하지 않습니다.'
  };
}

function ccb701_760_buildBackupPlanCandidate_() {
  var now = ccb701_760_now_();
  return {
    ok: true,
    dryRun: true,
    backupPlanId: 'BKP-PRECHECK-CC-B06J41-' + Utilities.getUuid().slice(0, 8).toUpperCase(),
    projectCode: 'CONTROL',
    backupScope: {
      setupDb: 'FEELHAUS_SETUP_DB SystemConfig',
      masterDb: 'FEELHAUS_DB_MASTER read-only baseline',
      projects: ['SIGN','PORTAL_SIGN','PORTAL_ERP_SIGN','CONTROL'],
      logs: ['ApprovalLog','BackupLog','RecoveryLog','DeployLog'],
      blockedActions: ['NO_ACTUAL_BACKUP','NO_SHEET_WRITE','NO_HEADER_ADD','NO_DEPLOY','NO_ROLLBACK']
    },
    createdAt: now,
    backupAllowed: false,
    backupExecuted: false,
    safety: ccb701_760_safety_(),
    message: '백업 계획 후보만 생성했습니다. 실제 백업은 차단 상태입니다.'
  };
}
