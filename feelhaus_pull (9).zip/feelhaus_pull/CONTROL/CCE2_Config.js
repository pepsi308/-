/**
 * CONTROL_B06J41_161_360_ERP_CORE_CREATE_DEPLOY_GUARD_BUNDLE_SAFE
 * Config / constants / common helpers
 * Safe build: no actual create, no header add, no DB injection, no deploy.
 */
var CONTROL_ERP_CORE_161_360_BUILD = 'CONTROL_B06J41_161_360_ERP_CORE_CREATE_DEPLOY_GUARD_BUNDLE_SAFE';
var CONTROL_ERP_CORE_161_360_PREVIOUS_BUILD = 'CONTROL_B06J41_081_160_ERP_CORE_MISSING_SHEET_APPROVAL_SAFE';
var CONTROL_ERP_CORE_161_360_PREVIOUS_ERP_CORE_BUILD = 'ERP_CORE_B06J41_161_240_PRE_DEPLOY_UI_FUNCTION_AUDIT_SAFE';
var CONTROL_ERP_CORE_161_360_FINAL_STATUS = 'CONTROL_ERP_CORE_CREATE_DEPLOY_GUARD_BUNDLE_PASSED__EXECUTION_STILL_BLOCKED';

var CONTROL_ERP_CORE_161_360_SETUP_DB_ID = '17VMSpgSZCvIrUlgcw8yCNcnl8WQWo2IcRf5tDCcuJGM';
var CONTROL_ERP_CORE_161_360_CONFIG_SHEET_NAME = 'SystemConfig';
var CONTROL_ERP_CORE_161_360_SOURCE_DB = 'FEELHAUS_SETUP_DB';
var CONTROL_ERP_CORE_161_360_PROJECT_CODE = 'ERP_CORE';
var CONTROL_ERP_CORE_161_360_CONTROL_PROJECT_CODE = 'CONTROL';

function getControlErpCoreB06J41_161_360_Safety_() {
  return {
    dryRunOnly: true,
    guardBundleOnly: true,
    approvalRequired: true,
    deployAllowed: false,
    actualCreateConfirm: false,
    actualDeployConfirm: false,
    actualCreateGlobalEnabled: false,
    actualDeployGlobalEnabled: false,
    noSheetCreate: true,
    noSheetWrite: true,
    noHeaderAutoAdd: true,
    noDbInjection: true,
    noPolicyWrite: true,
    noApprovalWrite: true,
    noActualDeploy: true,
    noActualRecovery: true,
    noActualRollback: true,
    noSettlementExecution: true,
    noPaymentExecution: true,
    noRecoveryExecution: true,
    noRoleMutation: true,
    noProtectedSheetDelete: true,
    noArchiveByNewSheetReason: true,
    actualExecutionBlocked: true
  };
}

function getControlErpCoreB06J41_161_360_BuildInfo_() {
  return {
    ok: true,
    build: CONTROL_ERP_CORE_161_360_BUILD,
    previousBuild: CONTROL_ERP_CORE_161_360_PREVIOUS_BUILD,
    previousErpCoreBuild: CONTROL_ERP_CORE_161_360_PREVIOUS_ERP_CORE_BUILD,
    projectCode: CONTROL_ERP_CORE_161_360_PROJECT_CODE,
    controlProjectCode: CONTROL_ERP_CORE_161_360_CONTROL_PROJECT_CODE,
    sourceDb: CONTROL_ERP_CORE_161_360_SOURCE_DB,
    setupDbId: CONTROL_ERP_CORE_161_360_SETUP_DB_ID,
    configSheetName: CONTROL_ERP_CORE_161_360_CONFIG_SHEET_NAME,
    deployAllowed: false,
    actualCreateConfirm: false,
    actualExecutionBlocked: true,
    finalStatus: CONTROL_ERP_CORE_161_360_FINAL_STATUS
  };
}

function readControlErpCoreB06J41_161_360_SystemConfig_() {
  var result = {
    ok: false,
    setupDbId: CONTROL_ERP_CORE_161_360_SETUP_DB_ID,
    sourceDb: CONTROL_ERP_CORE_161_360_SOURCE_DB,
    sheetName: CONTROL_ERP_CORE_161_360_CONFIG_SHEET_NAME,
    config: {},
    message: ''
  };
  try {
    var ss = SpreadsheetApp.openById(CONTROL_ERP_CORE_161_360_SETUP_DB_ID);
    var sheet = ss.getSheetByName(CONTROL_ERP_CORE_161_360_CONFIG_SHEET_NAME);
    if (!sheet) {
      result.message = 'SystemConfig 시트를 찾을 수 없습니다.';
      return result;
    }
    var values = sheet.getDataRange().getValues();
    if (!values || values.length < 2) {
      result.ok = true;
      result.setupDbName = ss.getName();
      result.message = 'SystemConfig 데이터가 비어 있습니다. 기본값 후보만 사용합니다.';
      return result;
    }
    var headers = values[0].map(function (h) { return String(h || '').trim(); });
    var keyIdx = headers.indexOf('CONFIG_KEY');
    var valueIdx = headers.indexOf('VALUE');
    if (keyIdx < 0) keyIdx = headers.indexOf('key');
    if (valueIdx < 0) valueIdx = headers.indexOf('value');
    if (keyIdx < 0) keyIdx = 0;
    if (valueIdx < 0) valueIdx = 1;
    for (var i = 1; i < values.length; i++) {
      var k = String(values[i][keyIdx] || '').trim();
      if (k) result.config[k] = values[i][valueIdx];
    }
    result.ok = true;
    result.setupDbName = ss.getName();
    result.message = 'SystemConfig 읽기 완료';
    return result;
  } catch (err) {
    result.message = 'SystemConfig 읽기 실패: ' + err.message;
    return result;
  }
}

function resolveControlErpCoreB06J41_161_360_MasterDbId_(config) {
  config = config || {};
  return String(config.FEELHAUS_DB_MASTER_ID || config.DB_MASTER_ID || config.SPREADSHEET_ID || '').trim();
}

function openControlErpCoreB06J41_161_360_MasterDb_(config) {
  var id = resolveControlErpCoreB06J41_161_360_MasterDbId_(config);
  var result = { ok: false, masterDbId: id, masterDbName: '', message: '' };
  if (!id) {
    result.message = 'FEELHAUS_DB_MASTER ID를 찾을 수 없습니다.';
    return result;
  }
  try {
    var ss = SpreadsheetApp.openById(id);
    result.ok = true;
    result.masterDbName = ss.getName();
    result.message = 'FEELHAUS_DB_MASTER 연결 확인 완료';
    result.spreadsheet = ss;
    return result;
  } catch (err) {
    result.message = 'FEELHAUS_DB_MASTER 연결 실패: ' + err.message;
    return result;
  }
}

function getControlErpCoreB06J41_161_360_RequiredSheets_() {
  var common = ['eventId','vendorId','customerId','status','statusReason','createdAt','createdBy','updatedAt','updatedBy'];
  return [
    { sheetName: 'ERP_판매관리', workArea: '판매관리', headers: common.concat(['saleId']) },
    { sheetName: 'ERP_계약관리', workArea: '계약관리', headers: common.concat(['contractId','saleId']) },
    { sheetName: 'ERP_설치관리', workArea: '설치관리', headers: common.concat(['installId','saleId','contractId']) },
    { sheetName: 'ERP_AS관리', workArea: 'A/S관리', headers: common.concat(['asId','saleId']) },
    { sheetName: 'ERP_정산관리', workArea: '정산관리', headers: common.concat(['settlementId','saleId','contractId']) },
    { sheetName: 'ERP_사용자관리', workArea: '사용자관리', headers: common.concat(['userId','roleCode']) }
  ];
}

function makeControlErpCoreB06J41_161_360_HeaderMap_(sheet) {
  var result = { headers: [], map: {} };
  if (!sheet || sheet.getLastColumn() < 1) return result;
  var values = sheet.getRange(1, 1, 1, sheet.getLastColumn()).getValues()[0];
  for (var i = 0; i < values.length; i++) {
    var h = String(values[i] || '').trim();
    if (h) {
      result.headers.push(h);
      result.map[h] = i + 1;
    }
  }
  return result;
}

function getControlErpCoreB06J41_161_360_ApprovalTemplate_() {
  return {
    approvalId: 'APR-ERP-CORE-CREATE-DEPLOY-YYYYMMDD-001',
    approvalStatus: 'APPROVED',
    approvalType: 'STRUCTURE_CHANGE',
    approvalScope: 'ERP_CORE_MISSING_SHEET_CREATE_AND_DEPLOY_PRECHECK',
    projectCode: CONTROL_ERP_CORE_161_360_PROJECT_CODE,
    controlProjectCode: CONTROL_ERP_CORE_161_360_CONTROL_PROJECT_CODE,
    approvedBy: 'feelhouse06@gmail.com',
    approvedAt: Utilities.formatDate(new Date(), 'Asia/Seoul', "yyyy-MM-dd'T'HH:mm:ssXXX"),
    actualCreateRequested: true,
    actualCreateConfirm: true,
    actualDeployRequested: true,
    actualDeployConfirm: true,
    reason: 'ERP_CORE 누락 시트/헤더 생성 및 배포 승인 전 검토'
  };
}
