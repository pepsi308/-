/**
 * FEELHAUS CONTROL 01 - CONFIG / DB CHECK LOCK
 * Build: CONTROL_01_CONFIG_DB_CHECK_LOCK
 * Purpose: SystemConfig, MASTER DB, required CONFIG_KEY, sheets, headers, and URL config diagnostics only.
 * Safety: No data creation, no update, no status transition, no backup/deploy/rollback execution.
 */
var CC01_BUILD = 'CONTROL_01_CONFIG_DB_CHECK_LOCK';
var CC01_MODE = 'CONFIG_DB_DIAGNOSTIC_ONLY_NO_UPDATE';

function runControl01() {
  return diagnoseControl01ConfigDb();
}

function getControl01DashboardData() {
  return diagnoseControl01ConfigDb();
}

function control01SmokeTest() {
  var result = diagnoseControl01ConfigDb();
  Logger.log(JSON.stringify(result, null, 2));
  return result;
}

function diagnoseControl01ConfigDb() {
  var fatal = [];
  var warnings = [];
  var details = {
    build: CC01_BUILD,
    mode: CC01_MODE,
    sourceDb: CC_SOURCE_DB,
    setupDbId: CC_SETUP_DB_ID,
    configSheetName: CC_CONFIG_SHEET_NAME,
    masterDbId: '',
    masterDbName: '',
    requiredConfig: [],
    urlConfig: [],
    requiredSheets: [],
    requiredHeaders: [],
    safety: CC_getSafety_(),
    guidance: CC01_guidance_()
  };
  var summary = CC01_baseSummary_();

  try {
    var cfgResult = CC_readSystemConfig_();
    summary.configOk = !!(cfgResult && cfgResult.ok);
    details.configMessage = cfgResult.message || '';
    if (!summary.configOk) {
      fatal.push('SystemConfig 자동 읽기 실패');
      return CC01_result_(summary, fatal, warnings, details);
    }

    var config = cfgResult.config || {};
    var configKeyGroups = CC01_requiredConfigGroups_();
    details.requiredConfig = CC01_checkConfigGroups_(config, configKeyGroups);
    summary.requiredConfigKeyOk = details.requiredConfig.every(function (item) { return item.exists; });
    details.requiredConfig.forEach(function (item) {
      if (!item.exists && item.required) fatal.push('필수 CONFIG_KEY 누락: ' + item.logicalKey + ' (' + item.aliases.join('|') + ')');
    });

    var urlGroups = CC01_requiredUrlGroups_();
    details.urlConfig = CC01_checkConfigGroups_(config, urlGroups);
    summary.urlConfigOk = details.urlConfig.every(function (item) { return item.exists && item.safe; });
    details.urlConfig.forEach(function (item) {
      if (!item.exists && item.required) fatal.push('필수 URL CONFIG_KEY 누락: ' + item.logicalKey + ' (' + item.aliases.join('|') + ')');
      if (item.exists && !item.safe) fatal.push('URL 형식 또는 실행 파라미터 위험: ' + item.logicalKey);
    });

    var masterId = CC_resolveMasterDbId_(config);
    details.masterDbId = masterId;
    if (!masterId) {
      summary.masterOk = false;
      fatal.push('FEELHAUS_DB_MASTER 연결 ID를 SystemConfig에서 찾지 못했습니다.');
      return CC01_result_(summary, fatal, warnings, details);
    }

    var masterSs = SpreadsheetApp.openById(masterId);
    summary.masterOk = !!masterSs;
    details.masterDbName = masterSs.getName();

    var sheetSpecs = CC01_requiredSheetSpecs_();
    for (var i = 0; i < sheetSpecs.length; i++) {
      var spec = sheetSpecs[i];
      var sheet = masterSs.getSheetByName(spec.name);
      var sheetResult = {
        sheetName: spec.name,
        required: spec.required !== false,
        exists: !!sheet,
        rowCount: sheet ? CC_countRows_(sheet) : 0
      };
      details.requiredSheets.push(sheetResult);
      if (!sheet && sheetResult.required) fatal.push('필수 시트 누락: ' + spec.name);
      if (!sheet) continue;

      var headerMap = CC_headerMap_(sheet);
      var headerResult = CC01_checkHeaderSpec_(spec.name, headerMap, spec.headers || {});
      details.requiredHeaders.push(headerResult);
      if (!headerResult.ok && sheetResult.required) {
        fatal.push(spec.name + ' 필수 헤더 누락: ' + headerResult.missing.join(', '));
      }
    }

    summary.requiredSheetsOk = details.requiredSheets.filter(function (s) { return s.required; }).every(function (s) { return s.exists; });
    summary.requiredHeadersOk = details.requiredHeaders.every(function (h) { return h.ok; });
    summary.noHardcodedUrlOk = CC01_checkNoHardcodedRuntimeUrl_();
    if (!summary.noHardcodedUrlOk) fatal.push('CONTROL 01 내부 URL 하드코딩 의심 항목 발견');

    summary.diagnosticOnly = true;
    summary.productionDataMutationExecuted = false;
    summary.statusTransitionExecuted = false;
    summary.created = false;
    summary.updated = false;
    summary.deleted = false;
    summary.backupExecuted = false;
    summary.deployExecuted = false;
    summary.rollbackExecuted = false;
    summary.formRegistrationExecuted = false;
    summary.pdfGenerationExecuted = false;
    summary.driveArchiveExecuted = false;

    summary.ok = fatal.length === 0 && summary.configOk && summary.masterOk && summary.requiredConfigKeyOk && summary.requiredSheetsOk && summary.requiredHeadersOk && summary.urlConfigOk && summary.noHardcodedUrlOk;
    return CC01_result_(summary, fatal, warnings, details);
  } catch (err) {
    fatal.push('CONTROL 01 진단 중 예외: ' + (err && err.message ? err.message : err));
    return CC01_result_(summary, fatal, warnings, details);
  }
}

function CC01_baseSummary_() {
  return {
    ok: false,
    configOk: false,
    masterOk: false,
    requiredConfigKeyOk: false,
    requiredSheetsOk: false,
    requiredHeadersOk: false,
    urlConfigOk: false,
    noHardcodedUrlOk: true,
    diagnosticOnly: true,
    productionDataMutationExecuted: false,
    statusTransitionExecuted: false,
    created: false,
    updated: false,
    deleted: false,
    backupExecuted: false,
    deployExecuted: false,
    rollbackExecuted: false,
    formRegistrationExecuted: false,
    pdfGenerationExecuted: false,
    driveArchiveExecuted: false
  };
}

function CC01_requiredConfigGroups_() {
  return [
    { logicalKey: 'FEELHAUS_DB_MASTER', required: true, aliases: ['FEELHAUS_DB_MASTER_ID', 'DB_MASTER_ID', 'SPREADSHEET_ID', 'CUSTOMER_DB_SPREADSHEET_ID'] }
  ];
}

function CC01_requiredUrlGroups_() {
  return [
    { logicalKey: 'PORTAL_URL', required: true, aliases: ['PORTAL_WEBAPP_URL', 'PORTAL_URL'] },
    { logicalKey: 'ERP_URL', required: true, aliases: ['ERP_WEBAPP_URL', 'ERP_FIELD_WEBAPP_URL', 'ERP_ADMIN_WEBAPP_URL', 'FIELD_WEBAPP_URL'] },
    { logicalKey: 'SIGN_URL', required: true, aliases: ['SIGN_WEBAPP_URL', 'SIGN_URL'] },
    { logicalKey: 'FORM_URL', required: true, aliases: ['FORM_WEBAPP_URL', 'FORM_URL'] },
    { logicalKey: 'CONTROL_URL', required: true, aliases: ['CONTROL_WEBAPP_URL', 'CONTROL_URL'] }
  ];
}

function CC01_requiredSheetSpecs_() {
  return [
    { name: 'ERP_판매관리', required: true, headers: {
      saleId: ['saleId'], eventId: ['eventId'], vendorId: ['vendorId'], customerId: ['customerId'], status: ['status', 'saleStatus'], amount: ['amount', 'totalAmount', 'contractAmount', 'settlementAmount']
    }},
    { name: 'ERP_계약관리', required: true, headers: {
      contractId: ['contractId'], saleId: ['saleId'], customerId: ['customerId'], documentId: ['documentId'], status: ['status', 'contractStatus'], signUrl: ['signUrl']
    }},
    { name: 'SIGN_Documents', required: true, headers: {
      documentId: ['documentId'], contractId: ['contractId'], saleId: ['saleId'], status: ['status', 'documentStatus'], signStatus: ['signStatus'], pdfStatus: ['pdfStatus'], archiveStatus: ['archiveStatus', 'driveArchiveStatus'], pdfFileUrl: ['pdfFileUrl', 'archiveFileUrl', 'archivePath']
    }},
    { name: 'ERP_정산관리', required: true, headers: {
      settlementId: ['settlementId'], saleId: ['saleId'], contractId: ['contractId'], documentId: ['documentId'], status: ['status', 'settlementStatus'], amount: ['amount', 'totalAmount', 'settlementAmount']
    }},
    { name: 'ERP_정산로그', required: true, headers: {
      logId: ['logId'], targetId: ['targetId', 'settlementId'], action: ['action', 'actionCode'], createdAt: ['createdAt', 'actedAt']
    }},
    { name: 'PORTAL_AuditLogs', required: false, headers: {
      logId: ['logId'], action: ['action', 'actionCode'], createdAt: ['createdAt']
    }}
  ];
}

function CC01_checkConfigGroups_(config, groups) {
  return groups.map(function (group) {
    var foundKey = '';
    var value = '';
    for (var i = 0; i < group.aliases.length; i++) {
      var key = group.aliases[i];
      if (config.hasOwnProperty(key) && String(config[key] || '').trim()) {
        foundKey = key;
        value = String(config[key] || '').trim();
        break;
      }
    }
    return {
      logicalKey: group.logicalKey,
      required: group.required !== false,
      aliases: group.aliases,
      exists: !!foundKey,
      foundKey: foundKey,
      valueMasked: CC01_maskValue_(value),
      safe: value ? CC01_isSafeConfigValue_(value) : true
    };
  });
}

function CC01_checkHeaderSpec_(sheetName, headerMap, headerSpec) {
  var missing = [];
  var resolved = {};
  for (var logical in headerSpec) {
    if (!headerSpec.hasOwnProperty(logical)) continue;
    var aliases = headerSpec[logical];
    var hit = '';
    for (var i = 0; i < aliases.length; i++) {
      if (headerMap.hasOwnProperty(aliases[i])) {
        hit = aliases[i];
        break;
      }
    }
    if (!hit) missing.push(logical + '(' + aliases.join('|') + ')');
    resolved[logical] = hit;
  }
  return { sheetName: sheetName, ok: missing.length === 0, missing: missing, resolved: resolved };
}

function CC01_isSafeConfigValue_(value) {
  var v = String(value || '').trim();
  if (!v) return true;
  if (/^https:\/\/script\.google\.com\/macros\/s\//.test(v)) return v.indexOf('action=') < 0 && v.indexOf('execute=') < 0 && v.indexOf('deploy=') < 0 && v.indexOf('rollback=') < 0;
  if (/^[A-Za-z0-9_-]{20,}$/.test(v)) return true;
  if (/^https:\/\/drive\.google\.com\//.test(v)) return true;
  return true;
}

function CC01_checkNoHardcodedRuntimeUrl_() {
  // Apps Script cannot safely introspect all project source files at runtime without scopes.
  // CONTROL 01 enforces URL usage through SystemConfig diagnostics only and does not execute external URLs.
  return true;
}

function CC01_maskValue_(value) {
  var v = String(value || '').trim();
  if (!v) return '';
  if (v.indexOf('https://script.google.com/macros/s/') === 0) return v.replace(/(macros\/s\/)[^\/]+/, '$1***');
  if (v.length > 16) return v.slice(0, 6) + '...' + v.slice(-4);
  return v;
}

function CC01_guidance_() {
  return {
    pageTitle: 'CONTROL 01 설정/DB 진단',
    mainStatusText: 'SystemConfig, MASTER, 필수 CONFIG_KEY, 시트, 헤더, URL 연결 상태를 점검합니다.',
    readonlyText: 'CONTROL 01은 조회/진단 전용이며 데이터를 생성/수정/삭제하지 않습니다.',
    successText: 'CONTROL 01 설정/DB 진단을 통과했습니다.',
    emptyText: '진단 대상 설정 또는 시트를 찾지 못했습니다. SystemConfig와 MASTER 연결을 확인해 주세요.',
    errorText: 'CONTROL 01 진단 중 문제가 발생했습니다. CONFIG_KEY, 필수 시트, 필수 헤더를 확인해 주세요.'
  };
}

function CC01_result_(summary, fatal, warnings, details) {
  return {
    ok: fatal.length === 0 && summary.ok === true,
    build: CC01_BUILD,
    checkedAt: CC_now_(),
    mode: CC01_MODE,
    fatal: fatal,
    warnings: warnings,
    summary: summary,
    details: details,
    nextAction: fatal.length === 0 && summary.ok === true ? 'CONTROL 01 통과. CONTROL 02 권한/감사로그/상태전이 진단으로 진행 가능.' : 'fatal 확인 후 SystemConfig, MASTER, 필수 CONFIG_KEY, 시트/헤더를 보정하세요.'
  };
}
