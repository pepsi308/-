/** FEELHAUS CONTROL CENTER - Gates */
function CC_checkSafeLinks_() {
  var cfg = CC_readSystemConfig_().config || {};
  var keys = ['ERP_FIELD_WEBAPP_URL','ERP_ADMIN_WEBAPP_URL','SIGN_WEBAPP_URL','CONTROL_WEBAPP_URL','PORTAL_WEBAPP_URL'];
  var links = keys.map(function (k) {
    var url = String(cfg[k] || '').trim();
    return {
      key: k,
      exists: !!url,
      urlMasked: url ? url.replace(/(macros\/s\/)[^\/]+/, '$1***') : '',
      safeNavOnly: true,
      actionParamsBlocked: true
    };
  });
  return { ok: true, links: links, safeLinkCount: links.filter(function (l) { return l.exists; }).length, safety: CC_getSafety_() };
}

function CC_buildGateCandidate_(projectCode) {
  return {
    ok: true,
    dryRun: true,
    projectCode: projectCode,
    gateId: CC_uuid_('GATE-' + projectCode),
    gateStatus: 'DRYRUN_READY__EXECUTION_BLOCKED',
    deployAllowed: false,
    actualBackupAllowed: false,
    actualDeployAllowed: false,
    actualRollbackAllowed: false,
    safeNavOnly: true,
    notes: 'CONTROL gate candidate only. No execution.'
  };
}

function CC_validateActualCreateApproval_(approval) {
  approval = approval || {};
  var reasons = [];
  if (!approval.approvalId) reasons.push('MISSING_APPROVAL_ID');
  if (!approval.approvedBy) reasons.push('MISSING_APPROVED_BY');
  if (!approval.approvedAt) reasons.push('MISSING_APPROVED_AT');
  if (approval.approvalStatus !== 'APPROVED') reasons.push('APPROVAL_STATUS_NOT_APPROVED');
  if (approval.approvalType !== 'STRUCTURE_CHANGE') reasons.push('INVALID_APPROVAL_TYPE');
  if (approval.approvalScope !== 'LOG_SHEET_CREATE') reasons.push('INVALID_APPROVAL_SCOPE');
  if (!approval.projectCode) reasons.push('INVALID_PROJECT_CODE');
  if (approval.controlProjectCode !== 'CONTROL') reasons.push('INVALID_CONTROL_PROJECT_CODE');
  if (approval.actualCreateRequested !== true) reasons.push('NO_ACTUAL_CREATE_REQUEST');
  if (approval.actualCreateConfirm !== true) reasons.push('NO_ACTUAL_CREATE_CONFIRM');
  reasons.push('DEPLOY_STILL_BLOCKED');
  reasons.push('GLOBAL_ACTUAL_CREATE_FLAG_OFF');
  return {
    ok: false,
    blocked: true,
    approval: approval,
    blockReasons: reasons,
    gateWouldAllowIfGlobalFlagsEnabled: reasons.filter(function (r) { return r !== 'DEPLOY_STILL_BLOCKED' && r !== 'GLOBAL_ACTUAL_CREATE_FLAG_OFF'; }).length === 0,
    actualCreateAllowed: false,
    actualCreateExecuted: false,
    message: '승인 게이트 차단: ' + reasons.join(', ')
  };
}

function CC_blockedActualExecution_(projectCode, approval) {
  var gate = CC_validateActualCreateApproval_(approval || {});
  return {
    ok: true,
    projectCode: projectCode,
    requestedAt: CC_now_(),
    gate: gate,
    actualCreateAllowed: false,
    actualHeaderAddAllowed: false,
    actualCreateExecuted: false,
    actualExecutionBlocked: true,
    safety: CC_getSafety_(),
    message: 'Safe 기준본에서는 실제 생성/기록/백업/배포/롤백을 실행하지 않습니다.'
  };
}
