/** Main report for 161_360 bundle. */
function testControlErpCoreB06J41_161_360_All() {
  var pre = checkControlErpCoreB06J41_161_360_Precheck();
  var policy = checkControlErpCoreB06J41_161_360_PolicyCandidates();
  var gates = checkControlErpCoreB06J41_161_360_Gates();
  var guard = checkControlErpCoreB06J41_161_360_ExecuteGuard();
  var block = assertControlErpCoreB06J41_161_360_Block();
  var summary = {
    erpCoreAuditStatus: pre.erpCoreAudit.status,
    fatalErrorCount: pre.erpCoreAudit.fatalErrorCount,
    warningCount: pre.erpCoreAudit.warningCount,
    missingSheetCount: pre.missingSheetCount,
    missingSheets: pre.missingSheets,
    totalMissingHeaders: pre.totalMissingHeaders,
    sheetPolicyCandidateCount: policy.sheetPolicyCandidateCount,
    headerPolicyCandidateCount: policy.headerPolicyCandidateCount,
    invalidGateBlocked: gates.invalidGateBlocked,
    validShapeGateBlocked: gates.validShapeGateBlocked,
    gateWouldAllowIfGlobalFlagsEnabled: gates.gateWouldAllowIfGlobalFlagsEnabled,
    actualCreateExecuted: false,
    actualDeployExecuted: false,
    actualSheetCreateAllowed: false,
    actualHeaderAddAllowed: false,
    actualDbInjectionAllowed: false,
    actualDeployAllowed: false,
    deployAllowed: false,
    actualCreateConfirm: false,
    actualExecutionBlocked: true
  };
  var ok = pre.ok && policy.ok && gates.ok && guard.ok && block.ok &&
    summary.missingSheetCount === 6 &&
    summary.totalMissingHeaders === 67 &&
    summary.actualCreateExecuted === false &&
    summary.actualDeployExecuted === false &&
    summary.deployAllowed === false &&
    summary.actualCreateConfirm === false &&
    summary.actualExecutionBlocked === true;
  var result = {
    ok: ok,
    build: CONTROL_ERP_CORE_161_360_BUILD,
    previousBuild: CONTROL_ERP_CORE_161_360_PREVIOUS_BUILD,
    previousErpCoreBuild: CONTROL_ERP_CORE_161_360_PREVIOUS_ERP_CORE_BUILD,
    finalStatus: ok ? CONTROL_ERP_CORE_161_360_FINAL_STATUS : 'CONTROL_ERP_CORE_CREATE_DEPLOY_GUARD_BUNDLE_FAILED__REVIEW_REQUIRED',
    summary: summary,
    checks: {
      precheck: pre,
      policy: policy,
      gates: gates,
      guard: guard,
      block: block
    }
  };
  Logger.log('[CONTROL ERP_CORE 161_360 TEST] ' + JSON.stringify(result));
  return result;
}
