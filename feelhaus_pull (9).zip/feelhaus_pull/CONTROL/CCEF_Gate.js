function ccef941_1000_approvalItems_() {
  return [
    'ERP_CORE 누락 시트 6개 생성 승인',
    'HeaderPolicy 67개 확정 승인',
    'SheetPolicy 6개 등록 승인',
    'actualCreateConfirm=true 전환 승인',
    'deployAllowed=true 전환 승인',
    '실제 DB 주입 승인',
    '실제 배포 실행 승인'
  ].map(function(label, idx) {
    return {
      approvalNo: idx + 1,
      title: label,
      status: 'PENDING',
      blocked: true,
      approvalRequired: true
    };
  });
}

function ccef941_1000_gateCheck_(approval) {
  const reasons = [];
  const a = approval || {};
  if (!a.approvalId) reasons.push('MISSING_APPROVAL_ID');
  if (!a.approvedBy) reasons.push('MISSING_APPROVED_BY');
  if (!a.approvedAt) reasons.push('MISSING_APPROVED_AT');
  if (a.approvalStatus !== 'APPROVED') reasons.push('APPROVAL_STATUS_NOT_APPROVED');
  if (a.projectCode !== 'ERP_CORE') reasons.push('INVALID_PROJECT_CODE');
  if (a.controlProjectCode !== 'CONTROL') reasons.push('INVALID_CONTROL_PROJECT_CODE');
  if (a.approvalScope !== 'ERP_CORE_CREATE_DEPLOY_FINAL') reasons.push('INVALID_APPROVAL_SCOPE');
  if (a.actualCreateConfirm !== true) reasons.push('NO_ACTUAL_CREATE_CONFIRM');
  if (a.actualDeployConfirm !== true) reasons.push('NO_ACTUAL_DEPLOY_CONFIRM');
  reasons.push('DEPLOY_STILL_BLOCKED');
  reasons.push('GLOBAL_ACTUAL_CREATE_FLAG_OFF');
  reasons.push('GLOBAL_ACTUAL_DEPLOY_FLAG_OFF');
  reasons.push('GLOBAL_DB_INJECTION_FLAG_OFF');
  return {
    ok: false,
    blocked: true,
    blockReasons: reasons,
    gateWouldAllowIfGlobalFlagsEnabled: reasons.filter(function(r){return ['DEPLOY_STILL_BLOCKED','GLOBAL_ACTUAL_CREATE_FLAG_OFF','GLOBAL_ACTUAL_DEPLOY_FLAG_OFF','GLOBAL_DB_INJECTION_FLAG_OFF'].indexOf(r) < 0;}).length === 0,
    actualCreateAllowed: false,
    actualDbInjectionAllowed: false,
    actualDeployAllowed: false,
    message: '승인 게이트 차단: ' + reasons.join(', ')
  };
}

function ccef941_1000_gateSummary_() {
  const invalidGate = ccef941_1000_gateCheck_({});
  const validShapeGate = ccef941_1000_gateCheck_({
    approvalId:'APPROVAL-SHAPE-ONLY',
    approvedBy:'main.developer',
    approvedAt:new Date().toISOString(),
    approvalStatus:'APPROVED',
    projectCode:'ERP_CORE',
    controlProjectCode:'CONTROL',
    approvalScope:'ERP_CORE_CREATE_DEPLOY_FINAL',
    actualCreateConfirm:true,
    actualDeployConfirm:true
  });
  return {
    ok: true,
    invalidGateBlocked: invalidGate.blocked === true,
    validShapeGateBlocked: validShapeGate.blocked === true,
    gateWouldAllowIfGlobalFlagsEnabled: validShapeGate.gateWouldAllowIfGlobalFlagsEnabled === true,
    actualCreateAllowed: false,
    actualDbInjectionAllowed: false,
    actualDeployAllowed: false,
    invalidGate: invalidGate,
    validShapeGate: validShapeGate
  };
}
