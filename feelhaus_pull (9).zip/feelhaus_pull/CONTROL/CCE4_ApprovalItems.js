function checkControlErpCoreB06J41_761_940_ApprovalItems(){
  var ctx=cce4BaseContext_();
  var candidates=cce4RequiredSheetCandidates_().map(function(c){
    return {sheetName:c.sheetName,workArea:c.workArea,projectCode:'ERP_CORE',exists:false,missing:true,requiredHeaders:c.requiredHeaders,requiredHeaderCount:c.requiredHeaders.length,missingHeaders:c.requiredHeaders,missingHeaderCount:c.requiredHeaders.length,policyStatus:'CREATE_REVIEW_REQUIRED__ACTUAL_CREATE_BLOCKED',sheetType:'ERP_WORK_MASTER_CANDIDATE',protected:true,deleteCandidate:false,archiveCandidate:false,approvalRequired:true,actualSheetCreateBlocked:true,actualHeaderAddBlocked:true,actualDbInjectionBlocked:true,actualDeployBlocked:true,message:'ERP_CORE 실무 본체 핵심 작업 시트 후보입니다. 실제 생성은 CONTROL 최종 승인 전까지 차단합니다.'};
  });
  var totalHeaders=candidates.reduce(function(sum,c){return sum+c.missingHeaderCount;},0);
  var approvals=cce4ApprovalItems_().map(function(name,idx){return {approvalNo:idx+1,item:name,status:'PENDING',blocked:true,approvalRequired:true};});
  return {ok:ctx.ok,build:CCE4_BUILD,missingSheetCount:candidates.length,missingSheets:candidates.map(function(c){return c.sheetName;}),totalMissingHeaders:totalHeaders,sheetPolicyCandidateCount:candidates.length,headerPolicyCandidateCount:totalHeaders,approvalItemCount:approvals.length,pendingCount:approvals.length,blockedCount:approvals.length,candidates:candidates,approvals:approvals,safety:ctx.safety,message:'ERP_CORE 생성 승인 대기 항목을 CONTROL 최종 승인 게이트 후보로 표시했습니다.'};
}
