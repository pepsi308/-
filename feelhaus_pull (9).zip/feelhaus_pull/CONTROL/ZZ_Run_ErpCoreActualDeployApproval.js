/** Runner functions for CONTROL_ERP_CORE_ACTUAL_DEPLOY_APPROVAL_SAFE */
function runStep1_ControlActualDeployApprovalDryRun() {
  const result = cceda_dryRun({ runner: 'runStep1_ControlActualDeployApprovalDryRun' });
  Logger.log('[CONTROL ERP_CORE ACTUAL DEPLOY APPROVAL DRY RUN] ' + JSON.stringify(result, null, 2));
  return result;
}

function runStep2_BlockedControlActualDeployApprovalTest() {
  const result = cceda_execute({
    actualDeployConfirm: false,
    approvalCode: '',
    deployAllowed: true,
    actualDeployExecution: false,
    businessDataWriteAllowed: false
  });
  Logger.log('[CONTROL ERP_CORE ACTUAL DEPLOY APPROVAL BLOCKED TEST] ' + JSON.stringify(result, null, 2));
  return result;
}

function runStep3_ApprovedControlActualDeployApprovalGate() {
  const result = cceda_execute({
    actualDeployConfirm: true,
    approvalCode: 'CONTROL_ERP_CORE_ACTUAL_DEPLOY_APPROVED_EXECUTION_GATE_ONLY',
    deployAllowed: true,
    actualDeployExecution: false,
    businessDataWriteAllowed: false
  });
  Logger.log('[CONTROL ERP_CORE ACTUAL DEPLOY APPROVAL GATE RESULT] ' + JSON.stringify(result, null, 2));
  return result;
}

function runStep4_ControlActualDeployApprovalSelfTest() {
  const result = cceda_selfTest();
  Logger.log('[CONTROL ERP_CORE ACTUAL DEPLOY APPROVAL SELFTEST] ' + JSON.stringify(result, null, 2));
  return result;
}
