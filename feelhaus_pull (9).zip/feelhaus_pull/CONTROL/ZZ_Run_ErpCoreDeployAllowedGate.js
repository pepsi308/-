/** Runner functions for CONTROL_ERP_CORE_DEPLOY_ALLOWED_GATE_SAFE_V2 */
function runStep1_ControlDeployAllowedGateDryRun() {
  const result = ccedag_dryRun({ runner: 'runStep1_ControlDeployAllowedGateDryRun' });
  Logger.log('[CONTROL ERP_CORE DEPLOY ALLOWED GATE DRY RUN] ' + JSON.stringify(result, null, 2));
  return result;
}

function runStep2_BlockedControlDeployAllowedGateTest() {
  const result = ccedag_execute({
    deployAllowedConfirm: false,
    approvalCode: '',
    actualDeployExecution: false,
    businessDataWriteAllowed: false
  });
  Logger.log('[CONTROL ERP_CORE DEPLOY ALLOWED GATE BLOCKED TEST] ' + JSON.stringify(result, null, 2));
  return result;
}

function runStep3_ApprovedControlDeployAllowedGate() {
  const result = ccedag_execute({
    deployAllowedConfirm: true,
    approvalCode: 'CONTROL_ERP_CORE_DEPLOY_ALLOWED_APPROVED_GATE_ONLY',
    actualDeployExecution: false,
    businessDataWriteAllowed: false
  });
  Logger.log('[CONTROL ERP_CORE DEPLOY ALLOWED GATE APPROVED RESULT] ' + JSON.stringify(result, null, 2));
  return result;
}

function runStep4_ControlDeployAllowedGateSelfTest() {
  const result = ccedag_selfTest();
  Logger.log('[CONTROL ERP_CORE DEPLOY ALLOWED GATE SELFTEST] ' + JSON.stringify(result, null, 2));
  return result;
}
