@echo off
setlocal EnableExtensions EnableDelayedExpansion
title FEELHAUS DIAGNOSE APPSCRIPT JSON V04

set "BASE=%~dp0"
set "PROJECTS=SIGN PORTAL FORM ERP_FIELD ERP_CORE ERP_ADMIN ERP CONTROL"

echo ======================================================
echo FEELHAUS DIAGNOSE APPSCRIPT JSON V04
echo BASE=%BASE%
echo This version avoids node -e quote issues.
echo ======================================================
echo.

where node >nul 2>nul
if errorlevel 1 (
  echo [ERROR] node not found
  pause
  exit /b 1
)


set "CHECKJS=%TEMP%\feelhaus_check_appsscript_json_v04.js"
> "%CHECKJS%" echo const fs = require('fs'^);
>> "%CHECKJS%" echo const path = process.argv[2] ^|^| 'appsscript.json';
>> "%CHECKJS%" echo try {
>> "%CHECKJS%" echo   const s = fs.readFileSync(path, 'utf8'^);
>> "%CHECKJS%" echo   JSON.parse(s^);
>> "%CHECKJS%" echo   console.log('[OK] JSON valid length=' + s.length^);
>> "%CHECKJS%" echo } catch (e^) {
>> "%CHECKJS%" echo   console.error('[FAIL] ' + e.message^);
>> "%CHECKJS%" echo   console.error('FILE: ' + path^);
>> "%CHECKJS%" echo   try {
>> "%CHECKJS%" echo     const s = fs.readFileSync(path, 'utf8'^);
>> "%CHECKJS%" echo     console.error('length=' + s.length^);
>> "%CHECKJS%" echo     const m = String(e.message^).match(/position (\d+)/^);
>> "%CHECKJS%" echo     if (m^) {
>> "%CHECKJS%" echo       const pos = Number(m[1]^);
>> "%CHECKJS%" echo       console.error('--- around error ---'^);
>> "%CHECKJS%" echo       console.error(s.slice(Math.max(0, pos - 180^), pos + 180^)^);
>> "%CHECKJS%" echo     }
>> "%CHECKJS%" echo     console.error('--- first 30 lines ---'^);
>> "%CHECKJS%" echo     s.split(/\r?\n/^).slice(0, 30^).forEach((l, i^) =^> console.error(String(i + 1^).padStart(3, ' '^)+': '+l^)^);
>> "%CHECKJS%" echo   } catch (e2^) {}
>> "%CHECKJS%" echo   process.exit(1^);
>> "%CHECKJS%" echo }


set /a FAIL=0

for %%P in (%PROJECTS%) do (
  set "FILE=%BASE%%%P\appsscript.json"
  echo ------------------------------------------------------
  echo [%%P] !FILE!
  if not exist "!FILE!" (
    echo [FAIL] missing appsscript.json
    set /a FAIL+=1
  ) else (
    node "%CHECKJS%" "!FILE!"
    if errorlevel 1 set /a FAIL+=1
  )
)

echo.
echo ======================================================
if "%FAIL%"=="0" (
  echo [OK] all appsscript.json files are valid
) else (
  echo [FAIL] invalid or missing files: %FAIL%
)
echo ======================================================
pause
exit /b %FAIL%
