/** CONTROL CENTER B06J41 761_940 - Config */
const CONTROL_GUARD_BUNDLE_BUILD = 'CONTROL_CENTER_B06J41_761_940_BACKUP_DEPLOY_ROLLBACK_GUARD_BUNDLE_SAFE';
const CONTROL_GUARD_BUNDLE_PREVIOUS_BUILD = 'CONTROL_CENTER_B06J41_701_760_ACTUAL_BACKUP_APPROVAL_PRECHECK_SAFE';
const CONTROL_SETUP_DB_ID = '17VMSpgSZCvIrUlgcw8yCNcnl8WQWo2IcRf5tDCcuJGM';
const CONTROL_CONFIG_SHEET_NAME = 'SystemConfig';
const CONTROL_SOURCE_DB = 'FEELHAUS_SETUP_DB';

function ccgBuildInfo_() {
  return {
    ok: true,
    build: CONTROL_GUARD_BUNDLE_BUILD,
    previousBuild: CONTROL_GUARD_BUNDLE_PREVIOUS_BUILD,
    projectCode: 'CONTROL',
    sourceDb: CONTROL_SOURCE_DB,
    setupDbId: CONTROL_SETUP_DB_ID,
    configSheetName: CONTROL_CONFIG_SHEET_NAME,
    deployAllowed: false,
    actualExecutionBlocked: true,
    createdAt: Utilities.formatDate(new Date(), Session.getScriptTimeZone() || 'Asia/Seoul', "yyyy-MM-dd'T'HH:mm:ssXXX")
  };
}

function ccgSafety_() {
  return {
    dryRunOnly: true,
    guardBundleOnly: true,
    deployAllowed: false,
    actualBackupGlobalEnabled: false,
    actualDeployGlobalEnabled: false,
    actualRollbackGlobalEnabled: false,
    actualBackupConfirmRequired: true,
    actualDeployConfirmRequired: true,
    actualRollbackConfirmRequired: true,
    noSheetCreate: true,
    noSheetWrite: true,
    noHeaderAutoAdd: true,
    noPolicyWrite: true,
    noApprovalWrite: true,
    noActualBackup: true,
    noActualDeploy: true,
    noActualRollback: true,
    noPortalCardMutation: true,
    noSignDocumentMutation: true,
    noPdfGeneration: true,
    noQrUrlMutation: true,
    noSettlementExecution: true,
    noPaymentExecution: true,
    noRecoveryExecution: true,
    noExternalIntegration: true,
    actualExecutionBlocked: true
  };
}

function ccgOpenSetupDb_() {
  const ss = SpreadsheetApp.openById(CONTROL_SETUP_DB_ID);
  const sheet = ss.getSheetByName(CONTROL_CONFIG_SHEET_NAME);
  if (!sheet) throw new Error('SystemConfig sheet not found: ' + CONTROL_CONFIG_SHEET_NAME);
  return { ss, sheet };
}

function ccgReadSystemConfig_() {
  const opened = ccgOpenSetupDb_();
  const values = opened.sheet.getDataRange().getValues();
  const config = {};
  for (let i = 1; i < values.length; i++) {
    const key = String(values[i][0] || '').trim();
    const value = values[i][1];
    if (key) config[key] = value;
  }
  return {
    ok: true,
    setupDbId: CONTROL_SETUP_DB_ID,
    setupDbName: opened.ss.getName(),
    sourceDb: CONTROL_SOURCE_DB,
    sheetName: CONTROL_CONFIG_SHEET_NAME,
    config,
    message: 'SystemConfig 읽기 완료'
  };
}

function ccgResolveMasterDbId_(config) {
  return String(config.FEELHAUS_DB_MASTER_ID || config.DB_MASTER_ID || config.SPREADSHEET_ID || '').trim();
}

function ccgOpenMasterDb_(config) {
  const masterDbId = ccgResolveMasterDbId_(config);
  if (!masterDbId) throw new Error('FEELHAUS_DB_MASTER_ID is missing in SystemConfig');
  const ss = SpreadsheetApp.openById(masterDbId);
  return { ok: true, masterDbId, masterDbName: ss.getName(), ss, message: 'FEELHAUS_DB_MASTER 연결 확인 완료' };
}

function ccgHeaderMap_(sheet) {
  if (!sheet || sheet.getLastColumn() < 1) return {};
  const headers = sheet.getRange(1, 1, 1, sheet.getLastColumn()).getValues()[0];
  return headers.reduce(function(acc, h, idx) {
    const key = String(h || '').trim();
    if (key) acc[key] = idx + 1;
    return acc;
  }, {});
}
