/**
 * FEELHAUS CONTROL - PORTAL EVENT B50 ACTUAL APPLY EXECUTION READY GATE
 * Build: CONTROL_PORTAL_EVENT_B50_ACTUAL_APPLY_EXECUTION_READY_V01
 * Progress: [08/10] 80%
 * Target baseline: PORTAL_EVENT_B50_FINAL_STABLE_READONLY_20260611
 * Execution function: runControlPortalEventB50ActualApplyExecutionReadyV01
 *
 * Safety:
 * - Diagnostic only
 * - No sheet creation
 * - No header mutation
 * - No approval writing
 * - No audit log writing
 * - No backup/deploy/recovery/rollback execution
 * - No PORTAL operation save
 * - No ERP apply
 * - No field open execution
 */
var CC12_BUILD = 'CONTROL_PORTAL_EVENT_B50_ACTUAL_APPLY_EXECUTION_READY_V01';
var CC12_MODE = 'PORTAL_EVENT_B50_ACTUAL_APPLY_EXECUTION_READY_DIAGNOSTIC_ONLY_NO_UPDATE';
var CC12_PROGRESS = { current: 8, total: 10, percent: 80 };
var CC12_TARGET = {
  projectCode: 'PORTAL_EVENT',
  moduleCode: 'PORTAL_EVENT_MANAGEMENT',
  buildNo: 'PORTAL_EVENT_B50_FINAL_STABLE_READONLY_20260611',
  buildProgress: '50 / 50',
  progressPercent: 100,
  runFunction: 'portalEventB50RunAll',
  changedOnlyFile: 'PORTAL_EVENT_B50_CHANGED_ONLY.zip',
  backupEvidenceFile: 'BACKUP_PORTAL_EVENT_B50_CHANGED_ONLY_20260611.zip',
  rollbackBaselineFile: 'ROLLBACK_BASELINE_PORTAL_EVENT_B50_FINAL_STABLE_READONLY_20260611.zip',
  requiredActualApplyApprovalBuild: 'CONTROL_PORTAL_EVENT_B50_ACTUAL_APPLY_APPROVAL_V01'
};

function runControlPortalEventB50ActualApplyExecutionReadyV01() {
  var result = diagnoseControlPortalEventB50ActualApplyExecutionReadyV01_();
  CC12_logCompactResult_(result);
  return result;
}

function runPortalEventB50ActualApplyExecutionReadyV01() {
  var result = diagnoseControlPortalEventB50ActualApplyExecutionReadyV01_();
  CC12_logCompactResult_(result);
  return result;
}

function getControlPortalEventB50ActualApplyExecutionReadyData() {
  var result = diagnoseControlPortalEventB50ActualApplyExecutionReadyV01_();
  CC12_logCompactResult_(result);
  return result;
}

function controlPortalEventB50ActualApplyExecutionReadyV01() {
  var result = diagnoseControlPortalEventB50ActualApplyExecutionReadyV01_();
  CC12_logCompactResult_(result);
  return result;
}

function CC12_logCompactResult_(result) {
  Logger.log('JSON_COMPACT_RESULT: ' + JSON.stringify(CC12_compactResult_(result)));
}

function CC12_compactResult_(result) {
  result = result || {};
  var summary = result.summary || {};
  var details = result.details || {};
  var schema = details.schema || {};
  var approvalGate = details.actualApplyApprovalGate || {};
  var files = details.executionFiles || {};
  var op = details.operationBlock || {};
  return {
    ok: result.ok === true,
    build: result.build || CC12_BUILD,
    progress: CC12_PROGRESS,
    mode: result.mode || CC12_MODE,
    checkedAt: result.checkedAt || '',
    judgement: result.judgement || summary.judgement || 'BLOCK',
    targetBaseline: {
      projectCode: CC12_TARGET.projectCode,
      moduleCode: CC12_TARGET.moduleCode,
      buildNo: CC12_TARGET.buildNo,
      buildProgress: CC12_TARGET.buildProgress,
      progressPercent: CC12_TARGET.progressPercent,
      runFunction: CC12_TARGET.runFunction,
      changedOnlyFile: CC12_TARGET.changedOnlyFile,
      backupEvidenceFile: CC12_TARGET.backupEvidenceFile,
      rollbackBaselineFile: CC12_TARGET.rollbackBaselineFile
    },
    summary: {
      baselineOk: summary.baselineOk === true,
      configOk: summary.configOk === true,
      masterOk: summary.masterOk === true,
      requiredGateSheetsOk: summary.requiredGateSheetsOk === true,
      requiredGateHeadersOk: summary.requiredGateHeadersOk === true,
      actualApplyApprovalGatePassed: summary.actualApplyApprovalGatePassed === true,
      actualApplyReadinessOk: summary.actualApplyReadinessOk === true,
      actualApplyAllowedCandidate: summary.actualApplyAllowedCandidate === true,
      changedOnlyFileOk: summary.changedOnlyFileOk === true,
      backupEvidenceFileOk: summary.backupEvidenceFileOk === true,
      rollbackBaselineFileOk: summary.rollbackBaselineFileOk === true,
      executionFilesReadyOk: summary.executionFilesReadyOk === true,
      executionReadyOk: summary.executionReadyOk === true,
      executionAllowedCandidate: summary.executionAllowedCandidate === true,
      actualExecutionBlocked: summary.actualExecutionBlocked !== false,
      actualDeployAllowed: summary.actualDeployAllowed === true,
      actualPortalSaveAllowed: summary.actualPortalSaveAllowed === true,
      actualErpApplyAllowed: summary.actualErpApplyAllowed === true,
      actualFieldOpenAllowed: summary.actualFieldOpenAllowed === true,
      diagnosticOnly: summary.diagnosticOnly === true,
      dryRunOnly: summary.dryRunOnly === true,
      sheetWriteExecuted: summary.sheetWriteExecuted === true,
      sheetCreateExecuted: summary.sheetCreateExecuted === true,
      headerAutoAddExecuted: summary.headerAutoAddExecuted === true,
      approvalWriteExecuted: summary.approvalWriteExecuted === true,
      auditLogWriteExecuted: summary.auditLogWriteExecuted === true,
      backupExecuted: summary.backupExecuted === true,
      deployExecuted: summary.deployExecuted === true,
      recoveryExecuted: summary.recoveryExecuted === true,
      rollbackExecuted: summary.rollbackExecuted === true,
      erpApplyExecuted: summary.erpApplyExecuted === true,
      actualOpenExecuted: summary.actualOpenExecuted === true,
      productionDataMutationExecuted: summary.productionDataMutationExecuted === true
    },
    evidence: {
      missingSheets: schema.missingSheets || [],
      totalMissingHeaders: schema.totalMissingHeaders || 0,
      actualApplyApprovalBuild: approvalGate.build || '',
      actualApplyApprovalJudgement: approvalGate.judgement || '',
      actualApplyApprovalGatePassed: approvalGate.ok === true,
      approvedActualApplyCount: approvalGate.approvedActualApplyCount || 0,
      latestActualApplyApproval: approvalGate.latestActualApplyApproval || null,
      scannedFolderCount: files.scannedFolderCount || 0,
      changedOnlyFileCount: files.changedOnlyFileCount || 0,
      backupEvidenceFileCount: files.backupEvidenceFileCount || 0,
      rollbackBaselineFileCount: files.rollbackBaselineFileCount || 0,
      latestChangedOnlyFile: files.latestChangedOnlyFile || null,
      latestBackupEvidenceFile: files.latestBackupEvidenceFile || null,
      latestRollbackBaselineFile: files.latestRollbackBaselineFile || null,
      readinessReason: details.readinessReason || '',
      actualBackupAllowed: op.actualBackupAllowed === true,
      actualDeployAllowed: op.actualDeployAllowed === true,
      actualRecoveryAllowed: op.actualRecoveryAllowed === true,
      actualRollbackAllowed: op.actualRollbackAllowed === true,
      actualPortalSaveAllowed: op.actualPortalSaveAllowed === true,
      actualErpApplyAllowed: op.actualErpApplyAllowed === true,
      actualFieldOpenAllowed: op.actualFieldOpenAllowed === true
    },
    warnings: result.warnings || [],
    hold: result.hold || [],
    fatal: result.fatal || [],
    nextAction: result.nextAction || ''
  };
}

function diagnoseControlPortalEventB50ActualApplyExecutionReadyV01_() {
  var fatal = [];
  var warnings = [];
  var hold = [];
  var details = {
    build: CC12_BUILD,
    mode: CC12_MODE,
    progress: CC12_PROGRESS,
    checkedAt: (typeof CC_now_ === 'function') ? CC_now_() : new Date().toISOString(),
    sourceDb: (typeof CC_SOURCE_DB !== 'undefined') ? CC_SOURCE_DB : 'FEELHAUS_SETUP_DB',
    setupDbId: (typeof CC_SETUP_DB_ID !== 'undefined') ? CC_SETUP_DB_ID : '17VMSpgSZCvIrUlgcw8yCNcnl8WQWo2IcRf5tDCcuJGM',
    configSheetName: (typeof CC_CONFIG_SHEET_NAME !== 'undefined') ? CC_CONFIG_SHEET_NAME : 'SystemConfig',
    targetBaseline: CC12_TARGET,
    safety: CC12_safety_(),
    config: null,
    master: null,
    schema: null,
    actualApplyApprovalGate: null,
    executionFiles: null,
    operationBlock: null,
    readinessReason: ''
  };
  var summary = CC12_baseSummary_();

  try {
    var cfgResult = (typeof CC_readSystemConfig_ === 'function') ? CC_readSystemConfig_() : null;
    summary.configOk = !!(cfgResult && cfgResult.ok);
    details.config = {
      ok: summary.configOk,
      message: cfgResult && cfgResult.message ? cfgResult.message : '',
      sourceDb: details.sourceDb,
      setupDbId: details.setupDbId,
      configSheetName: details.configSheetName
    };
    if (!summary.configOk) fatal.push('SystemConfig read failed');

    var config = cfgResult && cfgResult.config ? cfgResult.config : {};
    var masterId = (typeof CC_resolveMasterDbId_ === 'function') ? CC_resolveMasterDbId_(config) : '';
    if (!masterId) {
      summary.masterOk = false;
      fatal.push('FEELHAUS_DB_MASTER id not found');
      return CC12_result_(summary, fatal, warnings, hold, details);
    }
    var masterSs = SpreadsheetApp.openById(masterId);
    summary.masterOk = !!masterSs;
    details.master = { ok: summary.masterOk, masterDbId: masterId, masterDbName: masterSs ? masterSs.getName() : '' };
    if (!summary.masterOk) fatal.push('FEELHAUS_DB_MASTER open failed');

    details.schema = (typeof CC09_checkGateSchemas_ === 'function') ? CC09_checkGateSchemas_(masterSs) : CC12_emptySchema_();
    summary.requiredGateSheetsOk = details.schema.ok && details.schema.missingSheets.length === 0;
    summary.requiredGateHeadersOk = details.schema.totalMissingHeaders === 0;
    if (!summary.requiredGateSheetsOk) fatal.push('Required gate sheets missing: ' + details.schema.missingSheets.join(', '));
    if (!summary.requiredGateHeadersOk) fatal.push('Required gate headers missing: ' + details.schema.totalMissingHeaders);

    details.actualApplyApprovalGate = CC12_checkActualApplyApprovalGatePass_();
    summary.actualApplyApprovalGatePassed = details.actualApplyApprovalGate.ok === true;
    summary.actualApplyReadinessOk = details.actualApplyApprovalGate.actualApplyReadinessOk === true;
    summary.actualApplyAllowedCandidate = details.actualApplyApprovalGate.actualApplyAllowedCandidate === true;
    if (!summary.actualApplyApprovalGatePassed) hold.push('PORTAL_EVENT_B50 actual apply approval gate PASS was not confirmed');
    if (!summary.actualApplyAllowedCandidate) hold.push('PORTAL_EVENT_B50 actual apply allowed candidate was not confirmed');

    details.executionFiles = CC12_findExecutionFiles_(config);
    summary.changedOnlyFileOk = details.executionFiles.changedOnlyFileOk === true;
    summary.backupEvidenceFileOk = details.executionFiles.backupEvidenceFileOk === true;
    summary.rollbackBaselineFileOk = details.executionFiles.rollbackBaselineFileOk === true;
    summary.executionFilesReadyOk = summary.changedOnlyFileOk && summary.backupEvidenceFileOk && summary.rollbackBaselineFileOk;
    if (!summary.changedOnlyFileOk) hold.push('PORTAL_EVENT_B50 changed-only zip evidence was not found in scanned Drive folders');
    if (!summary.backupEvidenceFileOk) hold.push('PORTAL_EVENT_B50 backup evidence zip was not found in scanned Drive folders');
    if (!summary.rollbackBaselineFileOk) hold.push('PORTAL_EVENT_B50 rollback baseline zip was not found in scanned Drive folders');

    details.operationBlock = CC12_checkOperationBlock_();
    summary.actualExecutionBlocked = details.operationBlock.actualExecutionBlocked !== false;
    summary.actualDeployAllowed = details.operationBlock.actualDeployAllowed === true;
    summary.actualPortalSaveAllowed = details.operationBlock.actualPortalSaveAllowed === true;
    summary.actualErpApplyAllowed = details.operationBlock.actualErpApplyAllowed === true;
    summary.actualFieldOpenAllowed = details.operationBlock.actualFieldOpenAllowed === true;
    if (!summary.actualExecutionBlocked || summary.actualDeployAllowed || summary.actualPortalSaveAllowed || summary.actualErpApplyAllowed || summary.actualFieldOpenAllowed) {
      fatal.push('Actual execution block policy is broken in execution-ready gate');
    }

    summary.baselineOk = CC12_checkBaseline_().ok;
    if (!summary.baselineOk) fatal.push('Target baseline mismatch');

    summary.executionReadyOk = fatal.length === 0 && hold.length === 0 &&
      summary.baselineOk && summary.configOk && summary.masterOk &&
      summary.requiredGateSheetsOk && summary.requiredGateHeadersOk &&
      summary.actualApplyApprovalGatePassed && summary.actualApplyReadinessOk && summary.actualApplyAllowedCandidate &&
      summary.executionFilesReadyOk && summary.actualExecutionBlocked;
    summary.executionAllowedCandidate = summary.executionReadyOk === true;
    details.readinessReason = summary.executionReadyOk ?
      '[08/10] Actual apply execution ready PASS. Required approvals and execution files were confirmed. This gate still executes no production change.' :
      '[08/10] Actual apply execution ready HOLD/BLOCK. Fix missing approval, file evidence, schema, or safety-block items first.';

    return CC12_result_(summary, fatal, warnings, hold, details);
  } catch (err) {
    fatal.push(String(err && err.message ? err.message : err));
    return CC12_result_(summary, fatal, warnings, hold, details);
  }
}

function CC12_baseSummary_() {
  return {
    ok: false,
    judgement: 'BLOCK',
    baselineOk: false,
    configOk: false,
    masterOk: false,
    requiredGateSheetsOk: false,
    requiredGateHeadersOk: false,
    actualApplyApprovalGatePassed: false,
    actualApplyReadinessOk: false,
    actualApplyAllowedCandidate: false,
    changedOnlyFileOk: false,
    backupEvidenceFileOk: false,
    rollbackBaselineFileOk: false,
    executionFilesReadyOk: false,
    executionReadyOk: false,
    executionAllowedCandidate: false,
    actualExecutionBlocked: true,
    actualDeployAllowed: false,
    actualPortalSaveAllowed: false,
    actualErpApplyAllowed: false,
    actualFieldOpenAllowed: false,
    diagnosticOnly: true,
    dryRunOnly: true,
    sheetWriteExecuted: false,
    sheetCreateExecuted: false,
    headerAutoAddExecuted: false,
    approvalWriteExecuted: false,
    auditLogWriteExecuted: false,
    backupExecuted: false,
    deployExecuted: false,
    recoveryExecuted: false,
    rollbackExecuted: false,
    erpApplyExecuted: false,
    actualOpenExecuted: false,
    productionDataMutationExecuted: false
  };
}

function CC12_safety_() {
  return {
    diagnosticOnly: true,
    dryRunOnly: true,
    actualExecutionBlocked: true,
    noSheetWrite: true,
    noSheetCreate: true,
    noHeaderAutoAdd: true,
    noApprovalWrite: true,
    noAuditLogWrite: true,
    noBackupExecution: true,
    noDeployExecution: true,
    noRecoveryExecution: true,
    noRollbackExecution: true,
    noPortalOperationSave: true,
    noErpApply: true,
    noFieldOpenExecution: true
  };
}

function CC12_checkBaseline_() {
  var b = CC12_TARGET;
  return {
    ok: b.projectCode === 'PORTAL_EVENT' &&
      b.moduleCode === 'PORTAL_EVENT_MANAGEMENT' &&
      b.buildNo === 'PORTAL_EVENT_B50_FINAL_STABLE_READONLY_20260611' &&
      b.progressPercent === 100 &&
      b.runFunction === 'portalEventB50RunAll' &&
      b.changedOnlyFile === 'PORTAL_EVENT_B50_CHANGED_ONLY.zip',
    targetBaseline: b,
    actualWriteExecuted: false
  };
}

function CC12_checkActualApplyApprovalGatePass_() {
  var compact = null;
  var full = null;
  if (typeof diagnoseControlPortalEventB50ActualApplyApprovalV01_ === 'function') {
    full = diagnoseControlPortalEventB50ActualApplyApprovalV01_();
    if (typeof CC11_compactResult_ === 'function') compact = CC11_compactResult_(full);
  }
  compact = compact || {};
  var summary = compact.summary || {};
  var evidence = compact.evidence || {};
  return {
    ok: compact.judgement === 'PASS' && summary.actualApplyReadinessOk === true && summary.actualApplyAllowedCandidate === true,
    build: compact.build || '',
    judgement: compact.judgement || '',
    actualApplyReadinessOk: summary.actualApplyReadinessOk === true,
    actualApplyAllowedCandidate: summary.actualApplyAllowedCandidate === true,
    approvedActualApplyCount: evidence.approvedActualApplyCount || 0,
    latestActualApplyApproval: evidence.latestActualApplyApproval || null,
    actualExecutionBlocked: summary.actualExecutionBlocked !== false,
    fatal: compact.fatal || [],
    hold: compact.hold || [],
    actualWriteExecuted: false
  };
}

function CC12_findExecutionFiles_(config) {
  var result = {
    ok: false,
    scannedFolderCount: 0,
    changedOnlyFileOk: false,
    backupEvidenceFileOk: false,
    rollbackBaselineFileOk: false,
    changedOnlyFileCount: 0,
    backupEvidenceFileCount: 0,
    rollbackBaselineFileCount: 0,
    latestChangedOnlyFile: null,
    latestBackupEvidenceFile: null,
    latestRollbackBaselineFile: null,
    scannedFolders: []
  };
  var folderIds = CC12_candidateFolderIds_(config || {});
  for (var i = 0; i < folderIds.length; i++) {
    var key = folderIds[i].key;
    var folderId = folderIds[i].folderId;
    if (!folderId) continue;
    try {
      var folder = DriveApp.getFolderById(folderId);
      result.scannedFolderCount++;
      result.scannedFolders.push({ key: key, folderId: folderId, folderName: folder.getName() });
      var files = folder.getFiles();
      while (files.hasNext()) {
        var file = files.next();
        var name = file.getName();
        if (name === CC12_TARGET.changedOnlyFile) {
          result.changedOnlyFileCount++;
          result.latestChangedOnlyFile = CC12_fileMeta_(key, file);
        }
        if (name === CC12_TARGET.backupEvidenceFile) {
          result.backupEvidenceFileCount++;
          result.latestBackupEvidenceFile = CC12_fileMeta_(key, file);
        }
        if (name === CC12_TARGET.rollbackBaselineFile) {
          result.rollbackBaselineFileCount++;
          result.latestRollbackBaselineFile = CC12_fileMeta_(key, file);
        }
      }
    } catch (err) {
      result.scannedFolders.push({ key: key, folderId: folderId, error: String(err && err.message ? err.message : err) });
    }
  }
  result.changedOnlyFileOk = result.changedOnlyFileCount > 0 || result.backupEvidenceFileCount > 0;
  result.backupEvidenceFileOk = result.backupEvidenceFileCount > 0;
  result.rollbackBaselineFileOk = result.rollbackBaselineFileCount > 0;
  result.ok = result.changedOnlyFileOk && result.backupEvidenceFileOk && result.rollbackBaselineFileOk;
  return result;
}

function CC12_candidateFolderIds_(config) {
  var candidates = [];
  var keys = [
    'PORTAL_EVENT_BACKUP_FOLDER_ID',
    'PORTAL_EVENT_ROLLBACK_FOLDER_ID',
    'BACKUP_PORTAL_FOLDER_ID',
    'BACKUP_FOLDER_ID',
    'BACKUP_DB_FOLDER_ID',
    'ROOT_FOLDER_ID'
  ];
  for (var i = 0; i < keys.length; i++) {
    if (config && config[keys[i]]) candidates.push({ key: keys[i], folderId: String(config[keys[i]] || '').trim() });
  }
  var seen = {};
  var unique = [];
  for (var j = 0; j < candidates.length; j++) {
    if (!candidates[j].folderId || seen[candidates[j].folderId]) continue;
    seen[candidates[j].folderId] = true;
    unique.push(candidates[j]);
  }
  return unique;
}

function CC12_fileMeta_(folderKey, file) {
  return {
    folderKey: folderKey,
    fileId: file.getId(),
    fileName: file.getName(),
    mimeType: file.getMimeType(),
    updatedAt: file.getLastUpdated ? file.getLastUpdated().toISOString() : '',
    urlMasked: 'https://drive.google.com/file/d/***/view'
  };
}

function CC12_checkOperationBlock_() {
  return {
    actualExecutionBlocked: true,
    actualBackupAllowed: false,
    actualDeployAllowed: false,
    actualRecoveryAllowed: false,
    actualRollbackAllowed: false,
    actualPortalSaveAllowed: false,
    actualErpApplyAllowed: false,
    actualFieldOpenAllowed: false,
    sheetWriteExecuted: false,
    sheetCreateExecuted: false,
    headerAutoAddExecuted: false,
    approvalWriteExecuted: false,
    auditLogWriteExecuted: false,
    backupExecuted: false,
    deployExecuted: false,
    recoveryExecuted: false,
    rollbackExecuted: false,
    erpApplyExecuted: false,
    actualOpenExecuted: false,
    productionDataMutationExecuted: false
  };
}

function CC12_emptySchema_() {
  return {
    ok: true,
    missingSheets: [],
    totalMissingHeaders: 0,
    sheets: [],
    actualCreateBlocked: true,
    actualHeaderAddBlocked: true,
    actualWriteBlocked: true
  };
}

function CC12_result_(summary, fatal, warnings, hold, details) {
  var judgement = 'BLOCK';
  if (fatal.length === 0 && hold.length === 0 && summary.executionReadyOk === true) judgement = 'PASS';
  else if (fatal.length === 0) judgement = 'HOLD';
  summary.ok = fatal.length === 0;
  summary.judgement = judgement;
  summary.diagnosticOnly = true;
  summary.dryRunOnly = true;
  summary.actualExecutionBlocked = true;
  summary.actualDeployAllowed = false;
  summary.actualPortalSaveAllowed = false;
  summary.actualErpApplyAllowed = false;
  summary.actualFieldOpenAllowed = false;
  summary.sheetWriteExecuted = false;
  summary.sheetCreateExecuted = false;
  summary.headerAutoAddExecuted = false;
  summary.approvalWriteExecuted = false;
  summary.auditLogWriteExecuted = false;
  summary.backupExecuted = false;
  summary.deployExecuted = false;
  summary.recoveryExecuted = false;
  summary.rollbackExecuted = false;
  summary.erpApplyExecuted = false;
  summary.actualOpenExecuted = false;
  summary.productionDataMutationExecuted = false;
  return {
    ok: fatal.length === 0,
    build: CC12_BUILD,
    progress: CC12_PROGRESS,
    mode: CC12_MODE,
    checkedAt: details.checkedAt || ((typeof CC_now_ === 'function') ? CC_now_() : new Date().toISOString()),
    judgement: judgement,
    targetBaseline: CC12_TARGET,
    summary: summary,
    details: details,
    warnings: warnings,
    hold: hold,
    fatal: fatal,
    nextAction: CC12_nextAction_(judgement)
  };
}

function CC12_nextAction_(judgement) {
  if (judgement === 'PASS') {
    return '[08/10] PORTAL_EVENT_B50 actual apply execution ready gate PASS. Next step is [09/10] actual apply execution gate. This gate executed no production change.';
  }
  if (judgement === 'HOLD') {
    return '[08/10] PORTAL_EVENT_B50 actual apply execution ready gate HOLD. Confirm actual apply approval, changed-only zip, backup zip, and rollback baseline zip.';
  }
  return '[08/10] PORTAL_EVENT_B50 actual apply execution ready gate BLOCK. Fix SystemConfig/MASTER/schema or safety block issue first.';
}
