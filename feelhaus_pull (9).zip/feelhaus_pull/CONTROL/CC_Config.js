/** FEELHAUS CONTROL CENTER - Config */
var CC_SETUP_DB_ID = '17VMSpgSZCvIrUlgcw8yCNcnl8WQWo2IcRf5tDCcuJGM';
var CC_CONFIG_SHEET_NAME = 'SystemConfig';
var CC_SOURCE_DB = 'FEELHAUS_SETUP_DB';
var CC_BUILD = 'CONTROL_CENTER_B06J41_FULL_REPLACE_SAFE_BASELINE';
var CC_TIMEZONE = 'Asia/Seoul';

function CC_getBuildInfo_() {
  return {
    ok: true,
    build: CC_BUILD,
    buildDesc: 'CONTROL CENTER 전체 교체용 Safe 기준본',
    sourceDb: CC_SOURCE_DB,
    setupDbId: CC_SETUP_DB_ID,
    configSheetName: CC_CONFIG_SHEET_NAME,
    deployAllowed: false,
    actualExecutionBlocked: true,
    createdAt: CC_now_()
  };
}

function CC_now_() {
  return Utilities.formatDate(new Date(), CC_TIMEZONE, "yyyy-MM-dd'T'HH:mm:ssXXX");
}

function CC_uuid_(prefix) {
  return prefix + '-' + Utilities.formatDate(new Date(), CC_TIMEZONE, 'yyyyMMdd-HHmmss') + '-' + Utilities.getUuid().slice(0, 8).toUpperCase();
}

function CC_getSafety_() {
  return {
    dryRunOnly: true,
    deployAllowed: false,
    safeNavOnly: true,
    noSheetCreate: true,
    noSheetWrite: true,
    noHeaderAutoAdd: true,
    noPolicyWrite: true,
    noApprovalWrite: true,
    noActualBackup: true,
    noActualDeploy: true,
    noActualRollback: true,
    noPortalCardMutation: true,
    noSignDocumentMutation: true,
    noPdfGeneration: true,
    noQrUrlMutation: true,
    noSettlementExecution: true,
    noPaymentExecution: true,
    noRecoveryExecution: true,
    noExternalIntegration: true,
    actualExecutionBlocked: true
  };
}

function CC_openSetupDb_() {
  var ss = SpreadsheetApp.openById(CC_SETUP_DB_ID);
  var sheet = ss.getSheetByName(CC_CONFIG_SHEET_NAME);
  if (!sheet) throw new Error('SystemConfig 시트를 찾을 수 없습니다: ' + CC_CONFIG_SHEET_NAME);
  return { ss: ss, sheet: sheet };
}

function CC_readSystemConfig_() {
  var opened = CC_openSetupDb_();
  var values = opened.sheet.getDataRange().getValues();
  var config = {};
  if (values.length < 2) {
    return { ok: true, config: config, message: 'SystemConfig 데이터가 비어 있습니다.' };
  }
  var headers = values[0].map(function (h) { return String(h || '').trim(); });
  var keyIdx = headers.indexOf('CONFIG_KEY');
  var valueIdx = headers.indexOf('VALUE');
  if (keyIdx < 0) keyIdx = headers.indexOf('key');
  if (valueIdx < 0) valueIdx = headers.indexOf('value');
  if (keyIdx < 0) keyIdx = 0;
  if (valueIdx < 0) valueIdx = 1;
  for (var r = 1; r < values.length; r++) {
    var k = String(values[r][keyIdx] || '').trim();
    var v = values[r][valueIdx];
    if (k) config[k] = v;
  }
  return {
    ok: true,
    setupDbId: CC_SETUP_DB_ID,
    setupDbName: opened.ss.getName(),
    sourceDb: CC_SOURCE_DB,
    sheetName: CC_CONFIG_SHEET_NAME,
    config: config,
    message: 'SystemConfig 읽기 완료'
  };
}

function CC_resolveMasterDbId_(config) {
  return String(
    config.FEELHAUS_DB_MASTER_ID ||
    config.DB_MASTER_ID ||
    config.SPREADSHEET_ID ||
    config.CUSTOMER_DB_SPREADSHEET_ID ||
    ''
  ).trim();
}

function CC_openMasterDb_() {
  var cfg = CC_readSystemConfig_();
  var masterId = CC_resolveMasterDbId_(cfg.config || {});
  if (!masterId) throw new Error('FEELHAUS_DB_MASTER ID를 SystemConfig에서 찾을 수 없습니다.');
  var ss = SpreadsheetApp.openById(masterId);
  return { ok: true, ss: ss, masterDbId: masterId, masterDbName: ss.getName(), configResult: cfg };
}

function CC_headerMap_(sheet) {
  if (!sheet) return {};
  var lastCol = sheet.getLastColumn();
  if (lastCol < 1) return {};
  var headers = sheet.getRange(1, 1, 1, lastCol).getValues()[0];
  var map = {};
  headers.forEach(function (h, i) {
    var key = String(h || '').trim();
    if (key && !map[key]) map[key] = i + 1;
  });
  return map;
}

function CC_countRows_(sheet) {
  if (!sheet) return 0;
  return Math.max(0, sheet.getLastRow() - 1);
}

function CC_getRowsAsObjects_(sheet) {
  if (!sheet || sheet.getLastRow() < 2 || sheet.getLastColumn() < 1) return [];
  var values = sheet.getDataRange().getValues();
  var headers = values[0].map(function (h) { return String(h || '').trim(); });
  var out = [];
  for (var r = 1; r < values.length; r++) {
    var obj = {};
    headers.forEach(function (h, c) { if (h) obj[h] = values[r][c]; });
    out.push(obj);
  }
  return out;
}

function CC_statusEquals_(value, targets) {
  var s = String(value || '').trim().toLowerCase();
  return targets.some(function (t) { return s === String(t).toLowerCase(); });
}
