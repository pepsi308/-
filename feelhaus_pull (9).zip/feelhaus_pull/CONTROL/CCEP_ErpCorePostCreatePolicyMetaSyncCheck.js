/**
 * FEELHAUS CONTROL - ERP_CORE Post Create / Policy Meta Sync Check
 * Build: CONTROL_ERP_CORE_POST_CREATE_POLICY_META_SYNC_CHECK_SAFE
 * Purpose:
 *  - CONTROL reads FEELHAUS_SETUP_DB > SystemConfig.
 *  - CONTROL opens FEELHAUS_DB_MASTER by CONFIG_KEY / VALUE only.
 *  - CONTROL verifies ERP_CORE 6 created sheets, 67 core headers,
 *    HeaderPolicy 67 policy rows, and SheetPolicy 6 policy rows.
 * Safety:
 *  - read-only check only
 *  - no sheet creation
 *  - no header mutation
 *  - no policy write
 *  - no DB injection
 *  - no deploy
 */
var CCEP_SYNC_BUILD = 'CONTROL_ERP_CORE_POST_CREATE_POLICY_META_SYNC_CHECK_SAFE_V3';
var CCEP_SYNC_SETUP_DB_ID = '17VMSpgSZCvIrUlgcw8yCNcnl8WQWo2IcRf5tDCcuJGM';
var CCEP_SYNC_CONFIG_SHEET_NAME = 'SystemConfig';

var CCEP_SYNC_EXPECTED_SHEETS = [
  { order: 1, sheetName: 'ERP_판매관리', protectionLevel: 'CORE_PROTECTED', headers: ['eventId','vendorId','customerId','status','statusReason','createdAt','createdBy','updatedAt','updatedBy','saleId'] },
  { order: 2, sheetName: 'ERP_계약관리', protectionLevel: 'CORE_PROTECTED', headers: ['eventId','vendorId','customerId','status','statusReason','createdAt','createdBy','updatedAt','updatedBy','contractId','saleId'] },
  { order: 3, sheetName: 'ERP_설치관리', protectionLevel: 'CORE_PROTECTED', headers: ['eventId','vendorId','customerId','status','statusReason','createdAt','createdBy','updatedAt','updatedBy','installId','saleId','contractId'] },
  { order: 4, sheetName: 'ERP_AS관리', protectionLevel: 'CORE_PROTECTED', headers: ['eventId','vendorId','customerId','status','statusReason','createdAt','createdBy','updatedAt','updatedBy','asId','saleId'] },
  { order: 5, sheetName: 'ERP_정산관리', protectionLevel: 'CRITICAL_PROTECTED', headers: ['eventId','vendorId','customerId','status','statusReason','createdAt','createdBy','updatedAt','updatedBy','settlementId','saleId','contractId'] },
  { order: 6, sheetName: 'ERP_사용자관리', protectionLevel: 'CRITICAL_PROTECTED', headers: ['eventId','vendorId','customerId','status','statusReason','createdAt','createdBy','updatedAt','updatedBy','userId','roleCode'] }
];

var CCEP_SYNC_POLICY_SHEETS = {
  headerPolicySheetName: 'HeaderPolicy',
  sheetPolicySheetName: 'SheetPolicy'
};

function controlErpCorePostCreatePolicyMetaSyncCheck_safety_() {
  return {
    build: CCEP_SYNC_BUILD,
    readOnly: true,
    noSheetCreate: true,
    noHeaderAutoAdd: true,
    noPolicyWrite: true,
    noDbInjection: true,
    noDeployExecution: true,
    noBusinessDataWrite: true,
    noCustomerSave: true,
    noSaleSave: true,
    noContractCreate: true,
    noInstallAsSave: true,
    noSettlementExecution: true,
    noCancelSettlementConfirm: true,
    noSignDocumentCreate: true,
    noFormAutoRegister: true,
    noRoleMutation: true,
    noDeleteSheet: true,
    noExistingDataClear: true,
    headerMapRequired: true,
    idBasedConnectionRequired: true,
    vendorBranchUserGroup: true,
    qrInitialEntryTargetSearchProtected: true,
    directRegularMemberLink: false,
    noOriginalSlipMutation: true
  };
}

function controlErpCorePostCreatePolicyMetaSyncCheck_dryRun() {
  var plan = controlErpCorePostCreatePolicyMetaSyncCheck_expectedPlan_();
  var result = {
    ok: plan.ok,
    build: CCEP_SYNC_BUILD,
    mode: 'DRY_RUN_ONLY',
    message: 'CONTROL에서 ERP_CORE 생성/정책메타 동기화 점검 계획만 확인했습니다. 실제 쓰기는 없습니다.',
    expectedSheetCount: plan.expectedSheetCount,
    expectedHeaderPolicyCount: plan.expectedHeaderPolicyCount,
    expectedSheetPolicyCount: plan.expectedSheetPolicyCount,
    fatal: plan.fatal,
    warnings: plan.warnings,
    safety: controlErpCorePostCreatePolicyMetaSyncCheck_safety_()
  };
  Logger.log('[CONTROL ERP_CORE POLICY META SYNC DRY RUN] ' + JSON.stringify(result));
  return result;
}

function controlErpCorePostCreatePolicyMetaSyncCheck_run() {
  var fatal = [];
  var warnings = [];
  var plan = controlErpCorePostCreatePolicyMetaSyncCheck_expectedPlan_();
  if (!plan.ok) fatal = fatal.concat(plan.fatal);

  var cfgResult = controlErpCorePostCreatePolicyMetaSyncCheck_readSystemConfig_();
  if (!cfgResult.ok) fatal.push('SystemConfig 읽기 실패: ' + (cfgResult.message || cfgResult.error || 'unknown'));

  var masterResult = cfgResult.ok ? controlErpCorePostCreatePolicyMetaSyncCheck_openMasterDb_(cfgResult.config) : { ok: false, message: 'SystemConfig 실패로 MASTER 연결 생략' };
  if (!masterResult.ok) fatal.push('FEELHAUS_DB_MASTER 연결 실패: ' + (masterResult.message || masterResult.error || 'unknown'));

  var sheetChecks = [];
  var policyChecks = {
    headerPolicy: { ok: false, sheetName: CCEP_SYNC_POLICY_SHEETS.headerPolicySheetName, expectedRowCount: plan.expectedHeaderPolicyCount, foundRowCount: 0, missingPolicyIds: [], duplicatePolicyIds: [], missingHeaders: [], fatal: [] },
    sheetPolicy: { ok: false, sheetName: CCEP_SYNC_POLICY_SHEETS.sheetPolicySheetName, expectedRowCount: plan.expectedSheetPolicyCount, foundRowCount: 0, missingPolicyIds: [], duplicatePolicyIds: [], missingHeaders: [], fatal: [] }
  };

  if (masterResult.ok) {
    var ss = masterResult.spreadsheet;
    if (!ss || typeof ss.getSheetByName !== 'function') {
      fatal.push('FEELHAUS_DB_MASTER 객체가 유효하지 않습니다: spreadsheet handle missing');
    } else {
      for (var i = 0; i < CCEP_SYNC_EXPECTED_SHEETS.length; i++) {
      sheetChecks.push(controlErpCorePostCreatePolicyMetaSyncCheck_checkCoreSheet_(ss, CCEP_SYNC_EXPECTED_SHEETS[i]));
    }
      policyChecks.headerPolicy = controlErpCorePostCreatePolicyMetaSyncCheck_checkPolicySheet_(
        ss,
        CCEP_SYNC_POLICY_SHEETS.headerPolicySheetName,
        plan.expectedHeaderPolicyHeaders,
        plan.expectedHeaderPolicyIds
      );
      policyChecks.sheetPolicy = controlErpCorePostCreatePolicyMetaSyncCheck_checkPolicySheet_(
        ss,
        CCEP_SYNC_POLICY_SHEETS.sheetPolicySheetName,
        plan.expectedSheetPolicyHeaders,
        plan.expectedSheetPolicyIds
      );
    }
  }

  for (var s = 0; s < sheetChecks.length; s++) {
    if (!sheetChecks[s].ok) fatal.push('ERP_CORE 시트 점검 실패: ' + sheetChecks[s].sheetName);
  }
  if (!policyChecks.headerPolicy.ok) fatal.push('HeaderPolicy 정책 메타 점검 실패');
  if (!policyChecks.sheetPolicy.ok) fatal.push('SheetPolicy 정책 메타 점검 실패');

  var result = {
    ok: fatal.length === 0,
    build: CCEP_SYNC_BUILD,
    checkedAt: new Date().toISOString(),
    fatal: fatal,
    warnings: warnings,
    systemConfig: {
      ok: cfgResult.ok,
      setupDbId: cfgResult.setupDbId,
      sheetName: cfgResult.sheetName,
      message: cfgResult.message || '',
      error: cfgResult.error || ''
    },
    master: {
      ok: masterResult.ok,
      masterDbId: masterResult.masterDbId || '',
      masterDbName: masterResult.masterDbName || '',
      message: masterResult.message || '',
      error: masterResult.error || ''
    },
    expected: {
      sheetCount: plan.expectedSheetCount,
      headerPolicyCount: plan.expectedHeaderPolicyCount,
      sheetPolicyCount: plan.expectedSheetPolicyCount
    },
    coreSheets: sheetChecks,
    policyMeta: policyChecks,
    businessDataWrite: false,
    deployAllowed: false,
    safety: controlErpCorePostCreatePolicyMetaSyncCheck_safety_()
  };
  Logger.log('[CONTROL ERP_CORE POST CREATE POLICY META SYNC CHECK] ' + JSON.stringify(result));
  return result;
}

function controlErpCorePostCreatePolicyMetaSyncCheck_selfTest() {
  var plan = controlErpCorePostCreatePolicyMetaSyncCheck_expectedPlan_();
  var fatal = [];
  if (!plan.ok) fatal = fatal.concat(plan.fatal);
  if (plan.expectedSheetCount !== 6) fatal.push('expectedSheetCount must be 6');
  if (plan.expectedHeaderPolicyCount !== 67) fatal.push('expectedHeaderPolicyCount must be 67');
  if (plan.expectedSheetPolicyCount !== 6) fatal.push('expectedSheetPolicyCount must be 6');
  var result = {
    ok: fatal.length === 0,
    build: CCEP_SYNC_BUILD,
    fatal: fatal,
    warnings: plan.warnings,
    expected: {
      sheetCount: plan.expectedSheetCount,
      headerPolicyCount: plan.expectedHeaderPolicyCount,
      sheetPolicyCount: plan.expectedSheetPolicyCount
    },
    safety: controlErpCorePostCreatePolicyMetaSyncCheck_safety_()
  };
  Logger.log('[CONTROL ERP_CORE POLICY META SYNC SELFTEST] ' + JSON.stringify(result));
  return result;
}

function controlErpCorePostCreatePolicyMetaSyncCheck_expectedPlan_() {
  var fatal = [];
  var warnings = [];
  var expectedHeaderPolicyIds = [];
  var expectedSheetPolicyIds = [];
  var auditHeaders = ['createdAt','createdBy','updatedAt','updatedBy'];
  var headerCount = 0;

  for (var i = 0; i < CCEP_SYNC_EXPECTED_SHEETS.length; i++) {
    var policy = CCEP_SYNC_EXPECTED_SHEETS[i];
    var dup = controlErpCorePostCreatePolicyMetaSyncCheck_findDuplicates_(policy.headers);
    if (dup.length) fatal.push(policy.sheetName + ' 예상 헤더 중복: ' + dup.join(', '));
    for (var a = 0; a < auditHeaders.length; a++) {
      if (policy.headers.indexOf(auditHeaders[a]) < 0) fatal.push(policy.sheetName + ' 감사 헤더 누락: ' + auditHeaders[a]);
    }
    expectedSheetPolicyIds.push(controlErpCorePostCreatePolicyMetaSyncCheck_makePolicyId_('SHEET', policy.sheetName));
    for (var h = 0; h < policy.headers.length; h++) {
      expectedHeaderPolicyIds.push(controlErpCorePostCreatePolicyMetaSyncCheck_makePolicyId_('HEADER', policy.sheetName, policy.headers[h]));
      headerCount++;
    }
  }

  var headerPolicyDup = controlErpCorePostCreatePolicyMetaSyncCheck_findDuplicates_(expectedHeaderPolicyIds);
  var sheetPolicyDup = controlErpCorePostCreatePolicyMetaSyncCheck_findDuplicates_(expectedSheetPolicyIds);
  if (headerPolicyDup.length) fatal.push('예상 HeaderPolicy policyId 중복: ' + headerPolicyDup.join(', '));
  if (sheetPolicyDup.length) fatal.push('예상 SheetPolicy policyId 중복: ' + sheetPolicyDup.join(', '));
  if (CCEP_SYNC_EXPECTED_SHEETS.length !== 6) fatal.push('예상 시트 수 6 불일치: ' + CCEP_SYNC_EXPECTED_SHEETS.length);
  if (headerCount !== 67) fatal.push('예상 HeaderPolicy 수 67 불일치: ' + headerCount);

  return {
    ok: fatal.length === 0,
    expectedSheetCount: CCEP_SYNC_EXPECTED_SHEETS.length,
    expectedHeaderPolicyCount: headerCount,
    expectedSheetPolicyCount: expectedSheetPolicyIds.length,
    expectedHeaderPolicyIds: expectedHeaderPolicyIds,
    expectedSheetPolicyIds: expectedSheetPolicyIds,
    expectedHeaderPolicyHeaders: ['policyId', 'sheetName', 'headerName', 'headerOrder', 'required', 'protected', 'protectionLevel', 'policyStatus', 'sourceBuild', 'createdAt', 'createdBy', 'updatedAt', 'updatedBy'],
    expectedSheetPolicyHeaders: ['policyId', 'sheetName', 'sheetOrder', 'sheetRole', 'protectionLevel', 'createRequired', 'deleteCandidate', 'archiveCandidate', 'headerMapRequired', 'idBasedConnectionRequired', 'policyStatus', 'sourceBuild', 'createdAt', 'createdBy', 'updatedAt', 'updatedBy'],
    fatal: fatal,
    warnings: warnings
  };
}

function controlErpCorePostCreatePolicyMetaSyncCheck_readSystemConfig_() {
  if (typeof ccef941_1000_readSystemConfig_ === 'function') {
    return ccef941_1000_readSystemConfig_();
  }
  try {
    var ss = SpreadsheetApp.openById(CCEP_SYNC_SETUP_DB_ID);
    var sh = ss.getSheetByName(CCEP_SYNC_CONFIG_SHEET_NAME);
    if (!sh) return { ok: false, setupDbId: CCEP_SYNC_SETUP_DB_ID, sheetName: CCEP_SYNC_CONFIG_SHEET_NAME, config: {}, message: 'SystemConfig 시트를 찾을 수 없습니다.' };
    var values = sh.getDataRange().getValues();
    var config = {};
    if (values.length > 1) {
      var header = values[0].map(function(v) { return String(v || '').trim(); });
      var keyIdx = header.indexOf('CONFIG_KEY');
      var valueIdx = header.indexOf('VALUE');
      if (keyIdx < 0) keyIdx = 0;
      if (valueIdx < 0) valueIdx = 1;
      for (var i = 1; i < values.length; i++) {
        var k = String(values[i][keyIdx] || '').trim();
        if (k) config[k] = values[i][valueIdx];
      }
    }
    return { ok: true, setupDbId: CCEP_SYNC_SETUP_DB_ID, setupDbName: ss.getName(), sheetName: CCEP_SYNC_CONFIG_SHEET_NAME, config: config, message: 'SystemConfig 읽기 완료' };
  } catch (err) {
    return { ok: false, setupDbId: CCEP_SYNC_SETUP_DB_ID, sheetName: CCEP_SYNC_CONFIG_SHEET_NAME, config: {}, error: String(err), message: 'SystemConfig 읽기 실패' };
  }
}

function controlErpCorePostCreatePolicyMetaSyncCheck_openMasterDb_(config) {
  var cfg = config || {};
  var masterId = String(cfg.FEELHAUS_DB_MASTER_ID || cfg.DB_MASTER_ID || cfg.SPREADSHEET_ID || '').trim();
  if (!masterId) {
    return { ok: false, masterDbId: '', message: 'FEELHAUS_DB_MASTER_ID / DB_MASTER_ID / SPREADSHEET_ID 설정이 없습니다. SystemConfig 기준 연결만 허용합니다.' };
  }
  try {
    var ss = SpreadsheetApp.openById(masterId);
    return { ok: true, masterDbId: masterId, masterDbName: ss.getName(), spreadsheet: ss, message: 'FEELHAUS_DB_MASTER 연결 확인 완료' };
  } catch (err) {
    return { ok: false, masterDbId: masterId, error: String(err), message: 'FEELHAUS_DB_MASTER 연결 실패' };
  }
}

function controlErpCorePostCreatePolicyMetaSyncCheck_checkCoreSheet_(ss, expected) {
  var sh = ss.getSheetByName(expected.sheetName);
  var out = {
    ok: false,
    sheetName: expected.sheetName,
    exists: !!sh,
    expectedHeaderCount: expected.headers.length,
    actualHeaderCount: 0,
    missingHeaders: [],
    duplicateHeaders: [],
    fatal: []
  };
  if (!sh) {
    out.fatal.push('시트 없음');
    return out;
  }
  var lastCol = Math.max(sh.getLastColumn(), expected.headers.length);
  var headers = sh.getRange(1, 1, 1, lastCol).getValues()[0].map(function(v) { return String(v || '').trim(); }).filter(function(v) { return v; });
  out.actualHeaderCount = headers.length;
  out.duplicateHeaders = controlErpCorePostCreatePolicyMetaSyncCheck_findDuplicates_(headers);
  for (var i = 0; i < expected.headers.length; i++) {
    if (headers.indexOf(expected.headers[i]) < 0) out.missingHeaders.push(expected.headers[i]);
  }
  if (out.actualHeaderCount !== out.expectedHeaderCount) out.fatal.push('헤더 수 불일치');
  if (out.missingHeaders.length) out.fatal.push('필수 헤더 누락');
  if (out.duplicateHeaders.length) out.fatal.push('중복 헤더 존재');
  out.ok = out.fatal.length === 0;
  return out;
}

function controlErpCorePostCreatePolicyMetaSyncCheck_checkPolicySheet_(ss, sheetName, expectedHeaders, expectedPolicyIds) {
  var sh = ss.getSheetByName(sheetName);
  var out = {
    ok: false,
    sheetName: sheetName,
    exists: !!sh,
    expectedRowCount: expectedPolicyIds.length,
    foundRowCount: 0,
    missingPolicyIds: [],
    duplicatePolicyIds: [],
    missingHeaders: [],
    fatal: []
  };
  if (!sh) {
    out.fatal.push('정책 시트 없음');
    return out;
  }
  var values = sh.getDataRange().getValues();
  if (!values || values.length < 1) {
    out.fatal.push('정책 시트 비어 있음');
    return out;
  }
  var headers = values[0].map(function(v) { return String(v || '').trim(); });
  for (var h = 0; h < expectedHeaders.length; h++) {
    if (headers.indexOf(expectedHeaders[h]) < 0) out.missingHeaders.push(expectedHeaders[h]);
  }
  if (out.missingHeaders.length) out.fatal.push('정책 시트 헤더 누락');
  var policyIdIdx = headers.indexOf('policyId');
  if (policyIdIdx < 0) {
    out.fatal.push('policyId 헤더 없음');
    return out;
  }
  var found = [];
  for (var r = 1; r < values.length; r++) {
    var id = String(values[r][policyIdIdx] || '').trim();
    if (id) found.push(id);
  }
  out.duplicatePolicyIds = controlErpCorePostCreatePolicyMetaSyncCheck_findDuplicates_(found);
  var foundMap = {};
  for (var f = 0; f < found.length; f++) foundMap[found[f]] = true;
  for (var e = 0; e < expectedPolicyIds.length; e++) {
    if (!foundMap[expectedPolicyIds[e]]) out.missingPolicyIds.push(expectedPolicyIds[e]);
  }
  var expectedMap = {};
  for (var x = 0; x < expectedPolicyIds.length; x++) expectedMap[expectedPolicyIds[x]] = true;
  var matchedCount = 0;
  for (var y = 0; y < found.length; y++) {
    if (expectedMap[found[y]]) matchedCount++;
  }
  out.foundRowCount = matchedCount;
  if (out.foundRowCount !== out.expectedRowCount) out.fatal.push('정책 row 수 불일치');
  if (out.missingPolicyIds.length) out.fatal.push('policyId 누락');
  if (out.duplicatePolicyIds.length) out.fatal.push('policyId 중복');
  out.ok = out.fatal.length === 0;
  return out;
}


function controlErpCorePostCreatePolicyMetaSyncCheck_makePolicyId_(type, sheetName, headerName) {
  var raw = String(type || '') + '|' + String(sheetName || '') + '|' + String(headerName || '');
  return raw.replace(/\s+/g, '').replace(/[^A-Za-z0-9_가-힣|]/g, '_');
}

function controlErpCorePostCreatePolicyMetaSyncCheck_findDuplicates_(list) {
  var seen = {};
  var dup = [];
  for (var i = 0; i < list.length; i++) {
    var key = String(list[i] || '').trim();
    if (!key) continue;
    if (seen[key] && dup.indexOf(key) < 0) dup.push(key);
    seen[key] = true;
  }
  return dup;
}
