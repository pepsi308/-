/** Smoke and aliases for 161_360 bundle. */
function testControlErpCoreB06J41_161_360_Smoke() {
  var result = {
    ok: true,
    build: CONTROL_ERP_CORE_161_360_BUILD,
    previousBuild: CONTROL_ERP_CORE_161_360_PREVIOUS_BUILD,
    previousErpCoreBuild: CONTROL_ERP_CORE_161_360_PREVIOUS_ERP_CORE_BUILD,
    functions: [
      'testControlErpCoreB06J41_161_360_All',
      'testControlErpCoreB06J41_161_360_Smoke',
      'checkControlErpCoreB06J41_161_360_Precheck',
      'checkControlErpCoreB06J41_161_360_PolicyCandidates',
      'checkControlErpCoreB06J41_161_360_Gates',
      'checkControlErpCoreB06J41_161_360_ExecuteGuard',
      'executeControlErpCoreB06J41_161_360_ActualCreate',
      'executeControlErpCoreB06J41_161_360_ActualDeploy'
    ],
    safety: getControlErpCoreB06J41_161_360_Safety_(),
    message: 'Smoke test completed. Actual create/deploy remains blocked.'
  };
  Logger.log('[CONTROL ERP_CORE 161_360 SMOKE] ' + JSON.stringify(result));
  return result;
}
