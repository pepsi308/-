function ccef941_1000_missingSheetCandidates_() {
  const common = ['eventId','vendorId','customerId','status','statusReason','createdAt','createdBy','updatedAt','updatedBy'];
  const defs = [
    { sheetName:'ERP_판매관리', workArea:'판매관리', extra:['saleId'] },
    { sheetName:'ERP_계약관리', workArea:'계약관리', extra:['contractId','saleId'] },
    { sheetName:'ERP_설치관리', workArea:'설치관리', extra:['installId','saleId','contractId'] },
    { sheetName:'ERP_AS관리', workArea:'A/S관리', extra:['asId','saleId'] },
    { sheetName:'ERP_정산관리', workArea:'정산관리', extra:['settlementId','saleId','contractId'] },
    { sheetName:'ERP_사용자관리', workArea:'사용자관리', extra:['userId','roleCode'] }
  ];
  return defs.map(function(d) {
    const headers = common.concat(d.extra);
    return {
      sheetName: d.sheetName,
      workArea: d.workArea,
      projectCode: 'ERP_CORE',
      exists: false,
      missing: true,
      currentHeaderCount: 0,
      requiredHeaders: headers,
      requiredHeaderCount: headers.length,
      missingHeaders: headers,
      missingHeaderCount: headers.length,
      actionType: 'SHEET_CREATE_CANDIDATE_ONLY',
      actualSheetCreateBlocked: true,
      actualHeaderAddBlocked: true,
      approvalRequired: true,
      deleteCandidate: false,
      archiveCandidate: false,
      protected: true,
      message: '누락 시트입니다. 생성 필요 후보로만 표시합니다.'
    };
  });
}

function ccef941_1000_policyCandidates_() {
  const sheets = ccef941_1000_missingSheetCandidates_();
  const sheetPolicies = sheets.map(function(s) {
    return {
      projectCode: 'ERP_CORE',
      sheetName: s.sheetName,
      workArea: s.workArea,
      policyStatus: 'CREATE_REVIEW_REQUIRED__ACTUAL_CREATE_BLOCKED',
      sheetType: 'ERP_WORK_MASTER_CANDIDATE',
      protected: true,
      deleteCandidate: false,
      archiveCandidate: false,
      approvalRequired: true,
      reason: 'ERP_CORE 실무 본체 핵심 작업 시트 후보. 새 시트라는 이유로 삭제/아카이브 금지.',
      actualPolicyWriteBlocked: true
    };
  });
  const headerPolicies = [];
  sheets.forEach(function(s) {
    s.requiredHeaders.forEach(function(h) {
      headerPolicies.push({
        projectCode:'ERP_CORE',
        sheetName:s.sheetName,
        headerName:h,
        headerStatus:'REVIEW_REQUIRED__ACTUAL_HEADER_ADD_BLOCKED',
        approvalRequired:true,
        actualHeaderAddBlocked:true
      });
    });
  });
  return {
    ok:true,
    sheetPolicyCandidateCount: sheetPolicies.length,
    headerPolicyCandidateCount: headerPolicies.length,
    sheetPolicyCandidates: sheetPolicies,
    headerPolicyCandidates: headerPolicies
  };
}
