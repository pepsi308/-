/**
 * CONTROL_CENTER_B06J41_701_760_ACTUAL_BACKUP_APPROVAL_PRECHECK_SAFE
 * CONTROL actual backup approval precheck only.
 * No sheet writes, no backup, no deploy, no rollback.
 */
var CCB_BUILD = Object.freeze({
  build: 'CONTROL_CENTER_B06J41_701_760_ACTUAL_BACKUP_APPROVAL_PRECHECK_SAFE',
  previousBuild: 'CONTROL_CENTER_B06J41_FULL_REPLACE_SAFE_BASELINE',
  finalExpectedStatus: 'CONTROL_CENTER_ACTUAL_BACKUP_APPROVAL_PRECHECK_PASSED__BACKUP_STILL_BLOCKED',
  setupDbId: '17VMSpgSZCvIrUlgcw8yCNcnl8WQWo2IcRf5tDCcuJGM',
  configSheetName: 'SystemConfig',
  sourceDb: 'FEELHAUS_SETUP_DB',
  masterDbKey: 'FEELHAUS_DB_MASTER_ID',
  deployAllowed: false,
  actualBackupGlobalEnabled: false,
  actualBackupConfirmRequired: true,
  dryRun: true
});

function ccb701_760_safety_() {
  return {
    dryRunOnly: true,
    backupApprovalPrecheckOnly: true,
    deployAllowed: false,
    actualBackupDefaultBlocked: true,
    actualBackupGlobalEnabled: false,
    actualBackupConfirmRequired: true,
    noSheetCreate: true,
    noSheetWrite: true,
    noHeaderAutoAdd: true,
    noPolicyWrite: true,
    noApprovalWrite: true,
    noActualBackup: true,
    noActualDeploy: true,
    noActualRollback: true,
    noPortalCardMutation: true,
    noSignDocumentMutation: true,
    noPdfGeneration: true,
    noQrUrlMutation: true,
    noSettlementExecution: true,
    noPaymentExecution: true,
    noRecoveryExecution: true,
    noExternalIntegration: true,
    actualExecutionBlocked: true
  };
}

function ccb701_760_now_() {
  return Utilities.formatDate(new Date(), 'Asia/Seoul', "yyyy-MM-dd'T'HH:mm:ssXXX");
}

function ccb701_760_openSetupDb_() {
  var ss = SpreadsheetApp.openById(CCB_BUILD.setupDbId);
  var sheet = ss.getSheetByName(CCB_BUILD.configSheetName);
  if (!sheet) {
    return { ok: false, setupDbId: CCB_BUILD.setupDbId, sheetName: CCB_BUILD.configSheetName, message: 'SystemConfig 시트를 찾을 수 없습니다.' };
  }
  return { ok: true, spreadsheet: ss, sheet: sheet };
}

function ccb701_760_readSystemConfig_() {
  var opened = ccb701_760_openSetupDb_();
  if (!opened.ok) return opened;
  var values = opened.sheet.getDataRange().getValues();
  var config = {};
  for (var r = 1; r < values.length; r++) {
    var key = String(values[r][0] || '').trim();
    var value = values[r][1];
    if (key) config[key] = value;
  }
  return {
    ok: true,
    setupDbId: CCB_BUILD.setupDbId,
    setupDbName: opened.spreadsheet.getName(),
    sourceDb: CCB_BUILD.sourceDb,
    sheetName: CCB_BUILD.configSheetName,
    config: config,
    message: 'SystemConfig 읽기 완료'
  };
}

function ccb701_760_openMasterDb_() {
  var cfg = ccb701_760_readSystemConfig_();
  if (!cfg.ok) return { ok: false, config: cfg, message: 'SystemConfig 읽기 실패' };
  var masterId = cfg.config.FEELHAUS_DB_MASTER_ID || cfg.config.DB_MASTER_ID || cfg.config.SPREADSHEET_ID;
  if (!masterId) return { ok: false, config: cfg, message: 'FEELHAUS_DB_MASTER_ID를 찾을 수 없습니다.' };
  var ss = SpreadsheetApp.openById(masterId);
  return { ok: true, masterDbId: masterId, masterDbName: ss.getName(), spreadsheet: ss, config: cfg.config, message: 'FEELHAUS_DB_MASTER 연결 확인 완료' };
}

function ccb701_760_headerMap_(sheet) {
  var lastColumn = sheet.getLastColumn();
  if (!lastColumn) return {};
  var headers = sheet.getRange(1, 1, 1, lastColumn).getValues()[0];
  var map = {};
  headers.forEach(function(h, i) {
    var key = String(h || '').trim();
    if (key && !map[key]) map[key] = i + 1;
  });
  return map;
}
