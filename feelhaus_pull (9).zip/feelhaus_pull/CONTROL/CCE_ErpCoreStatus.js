function checkControlErpCoreB06J41_081_160_Status() {
  var buildInfo = cceB06J41_081_160_getBuildInfo_();
  var audit = cceB06J41_081_160_getErpCoreAuditSummary_();
  var setup = cceB06J41_081_160_readSystemConfig_();
  var master = cceB06J41_081_160_openMasterDb_();
  var safety = cceB06J41_081_160_getSafety_();
  return {
    ok: !!(setup.ok && master.ok && audit.ok),
    build: buildInfo.build,
    previousErpCoreBuild: buildInfo.previousErpCoreBuild,
    setupDb: setup.ok ? {
      ok: true,
      setupDbId: setup.setupDbId,
      setupDbName: setup.setupDbName,
      sourceDb: setup.sourceDb,
      sheetName: setup.sheetName,
      message: setup.message
    } : setup,
    masterDb: master.ok ? {
      ok: true,
      masterDbId: master.masterDbId,
      masterDbName: master.masterDbName,
      message: master.message
    } : master,
    erpCoreAudit: audit,
    safety: safety,
    message: 'ERP_CORE 점검 결과를 CONTROL 승인 전 점검 대상으로 수신했습니다.'
  };
}
