/**
 * CONTROL_ERP_CORE_ACTUAL_DEPLOY_APPROVAL_SAFE
 * Purpose: Final approval gate before actual ERP_CORE deployment execution.
 * This build DOES NOT deploy. It only verifies that actual deploy may move to
 * a separate execution step after explicit approval.
 */

const CONTROL_ERP_CORE_ACTUAL_DEPLOY_APPROVAL_BUILD = 'CONTROL_ERP_CORE_ACTUAL_DEPLOY_APPROVAL_SAFE';
const CONTROL_ERP_CORE_ACTUAL_DEPLOY_APPROVAL_CODE = 'CONTROL_ERP_CORE_ACTUAL_DEPLOY_APPROVED_EXECUTION_GATE_ONLY';

function cceda_safety_() {
  return {
    build: CONTROL_ERP_CORE_ACTUAL_DEPLOY_APPROVAL_BUILD,
    approvalGateOnly: true,
    deployAllowedRequired: true,
    actualDeployExecutionDefault: false,
    actualDeployExecution: false,
    noActualDeployExecution: true,
    noOperationalUrlMutation: true,
    noVersionSwitch: true,
    noSheetCreate: true,
    noHeaderAutoAdd: true,
    noPolicyWrite: true,
    noDbInjection: true,
    noBusinessDataWrite: true,
    noCustomerSave: true,
    noSaleSave: true,
    noContractCreate: true,
    noInstallAsSave: true,
    noSettlementExecution: true,
    noCancelSettlementConfirm: true,
    noSignDocumentCreate: true,
    noFormAutoRegister: true,
    noRoleMutation: true,
    noDeleteSheet: true,
    noExistingDataClear: true,
    headerMapRequired: true,
    idBasedConnectionRequired: true,
    vendorBranchUserGroup: true,
    qrInitialEntryTargetSearchProtected: true,
    directRegularMemberLink: false,
    noOriginalSlipMutation: true,
    backupRollbackConfirmationRequired: true
  };
}

function cceda_expected_() {
  return {
    sheetCount: 6,
    headerPolicyCount: 67,
    sheetPolicyCount: 6,
    requiredLogSheets: ['BackupLog', 'DeployLog', 'RecoveryLog'],
    requiredDeployAllowedBuild: 'CONTROL_ERP_CORE_DEPLOY_ALLOWED_GATE_SAFE_V2',
    requiredApprovalCode: CONTROL_ERP_CORE_ACTUAL_DEPLOY_APPROVAL_CODE
  };
}

function cceda_dryRun(ctx) {
  return {
    ok: true,
    build: CONTROL_ERP_CORE_ACTUAL_DEPLOY_APPROVAL_BUILD,
    mode: 'DRY_RUN_ONLY',
    message: '실제 배포 승인 게이트 계획만 확인합니다. 실제 배포/운영 URL 전환/쓰기 작업은 없습니다.',
    expected: cceda_expected_(),
    fatal: [],
    warnings: [],
    safety: cceda_safety_(),
    ctx: ctx || {}
  };
}

function cceda_verifyDeployAllowedGate_(ctx) {
  const fatal = [];
  const warnings = [];
  let deployAllowedGate = null;

  try {
    if (typeof ccedag_execute === 'function') {
      deployAllowedGate = ccedag_execute({
        deployAllowedConfirm: true,
        approvalCode: 'CONTROL_ERP_CORE_DEPLOY_ALLOWED_APPROVED_GATE_ONLY',
        actualDeployExecution: false,
        businessDataWriteAllowed: false,
        from: CONTROL_ERP_CORE_ACTUAL_DEPLOY_APPROVAL_BUILD
      });
    } else if (typeof runStep3_ApprovedControlDeployAllowedGate === 'function') {
      deployAllowedGate = runStep3_ApprovedControlDeployAllowedGate();
    } else {
      fatal.push('deployAllowed 게이트 함수를 찾을 수 없습니다: ccedag_execute');
    }
  } catch (err) {
    fatal.push('deployAllowed 게이트 재검증 실패: ' + (err && err.message ? err.message : err));
  }

  if (deployAllowedGate && deployAllowedGate.ok !== true) {
    fatal.push('deployAllowed 게이트가 PASS가 아닙니다.');
  }
  if (deployAllowedGate && deployAllowedGate.deployAllowed !== true) {
    fatal.push('deployAllowed=true 상태가 확인되지 않았습니다.');
  }
  if (deployAllowedGate && deployAllowedGate.actualDeployExecution !== false) {
    fatal.push('deployAllowed 게이트에서 actualDeployExecution=false가 유지되지 않았습니다.');
  }
  if (deployAllowedGate && deployAllowedGate.businessDataWrite !== false) {
    fatal.push('deployAllowed 게이트에서 businessDataWrite=false가 유지되지 않았습니다.');
  }
  if (deployAllowedGate && deployAllowedGate.warnings && deployAllowedGate.warnings.length) {
    warnings.push.apply(warnings, deployAllowedGate.warnings);
  }

  const logSheets = cceda_checkRequiredLogSheets_();
  if (!logSheets.ok) {
    fatal.push('BackupLog / DeployLog / RecoveryLog 확인 실패');
  }

  return {
    ok: fatal.length === 0,
    build: CONTROL_ERP_CORE_ACTUAL_DEPLOY_APPROVAL_BUILD,
    checkedAt: new Date().toISOString(),
    fatal: fatal,
    warnings: warnings,
    deployAllowedGate: deployAllowedGate,
    logSheets: logSheets,
    expected: cceda_expected_(),
    safety: cceda_safety_()
  };
}

function cceda_checkRequiredLogSheets_() {
  const names = cceda_expected_().requiredLogSheets;
  const result = { ok: true, sheets: [], fatal: [] };
  let ss = null;
  try {
    ss = cceda_openMaster_();
  } catch (err) {
    result.ok = false;
    result.fatal.push('MASTER 열기 실패: ' + (err && err.message ? err.message : err));
    return result;
  }
  names.forEach(function(name) {
    const exists = !!ss.getSheetByName(name);
    result.sheets.push({ sheetName: name, exists: exists, mode: 'READ_ONLY_CHECK' });
    if (!exists) {
      result.ok = false;
      result.fatal.push(name + ' 시트가 없습니다.');
    }
  });
  return result;
}

function cceda_openMaster_() {
  if (typeof ccef_getMasterSpreadsheet === 'function') {
    const ss = ccef_getMasterSpreadsheet();
    if (ss && typeof ss.getSheetByName === 'function') return ss;
  }
  if (typeof cce3_getMasterSpreadsheet === 'function') {
    const ss2 = cce3_getMasterSpreadsheet();
    if (ss2 && typeof ss2.getSheetByName === 'function') return ss2;
  }
  if (typeof ccedag_openMaster_ === 'function') {
    const ss3 = ccedag_openMaster_();
    if (ss3 && typeof ss3.getSheetByName === 'function') return ss3;
  }

  const setupDbId = '17VMSpgSZCvIrUlgcw8yCNcnl8WQWo2IcRf5tDCcuJGM';
  const setup = SpreadsheetApp.openById(setupDbId);
  const sh = setup.getSheetByName('SystemConfig');
  if (!sh) throw new Error('SystemConfig 시트를 찾을 수 없습니다.');
  const values = sh.getDataRange().getValues();
  if (!values || values.length < 2) throw new Error('SystemConfig 데이터가 비어 있습니다.');
  const headers = values[0].map(String);
  const keyIdx = headers.indexOf('CONFIG_KEY') >= 0 ? headers.indexOf('CONFIG_KEY') : headers.indexOf('key');
  const valIdx = headers.indexOf('VALUE') >= 0 ? headers.indexOf('VALUE') : headers.indexOf('value');
  if (keyIdx < 0 || valIdx < 0) throw new Error('SystemConfig CONFIG_KEY/VALUE 헤더를 찾을 수 없습니다.');
  const cfg = {};
  for (let i = 1; i < values.length; i++) {
    const k = String(values[i][keyIdx] || '').trim();
    const v = String(values[i][valIdx] || '').trim();
    if (k) cfg[k] = v;
  }
  const masterId = String(cfg.FEELHAUS_DB_MASTER_ID || cfg.DB_MASTER_ID || cfg.SPREADSHEET_ID || '').trim();
  if (!masterId) throw new Error('FEELHAUS_DB_MASTER_ID / DB_MASTER_ID / SPREADSHEET_ID 설정이 없습니다.');
  return SpreadsheetApp.openById(masterId);
}

function cceda_execute(ctx) {
  ctx = ctx || {};
  const required = {
    actualDeployConfirm: true,
    approvalCode: CONTROL_ERP_CORE_ACTUAL_DEPLOY_APPROVAL_CODE,
    deployAllowed: true,
    actualDeployExecution: false,
    businessDataWriteAllowed: false
  };

  if (ctx.actualDeployConfirm !== true) {
    return cceda_blocked_('actualDeployConfirm=true 승인이 없습니다.', required);
  }
  if (ctx.approvalCode !== CONTROL_ERP_CORE_ACTUAL_DEPLOY_APPROVAL_CODE) {
    return cceda_blocked_('승인코드가 일치하지 않습니다.', required);
  }
  if (ctx.deployAllowed !== true) {
    return cceda_blocked_('deployAllowed=true 상태만 허용합니다.', required);
  }
  if (ctx.actualDeployExecution !== false) {
    return cceda_blocked_('이 빌드는 실제 배포 실행이 아닙니다. actualDeployExecution=false만 허용합니다.', required);
  }
  if (ctx.businessDataWriteAllowed !== false) {
    return cceda_blocked_('businessDataWriteAllowed=false 상태만 허용합니다.', required);
  }

  const prereq = cceda_verifyDeployAllowedGate_(ctx);
  if (!prereq.ok) {
    return {
      ok: false,
      blocked: true,
      build: CONTROL_ERP_CORE_ACTUAL_DEPLOY_APPROVAL_BUILD,
      action: 'ACTUAL_DEPLOY_APPROVAL_GATE_ONLY',
      reason: '실제 배포 승인 전제조건 미충족',
      prerequisites: prereq,
      actualDeployApprovalReady: false,
      deployAllowed: true,
      actualDeployExecution: false,
      businessDataWrite: false,
      fatal: prereq.fatal || [],
      warnings: prereq.warnings || [],
      safety: cceda_safety_()
    };
  }

  return {
    ok: true,
    build: CONTROL_ERP_CORE_ACTUAL_DEPLOY_APPROVAL_BUILD,
    action: 'ACTUAL_DEPLOY_APPROVAL_GATE_ONLY',
    message: '실제 배포 승인 전제조건을 통과했습니다. 단, 실제 배포 실행은 하지 않았습니다.',
    actualDeployApprovalReady: true,
    deployAllowed: true,
    actualDeployExecution: false,
    businessDataWrite: false,
    operationalUrlMutation: false,
    versionSwitch: false,
    prerequisites: prereq,
    nextRequired: [
      'CONTROL_ERP_CORE_ACTUAL_DEPLOY_EXECUTION_SAFE',
      'actualDeployExecution=true 별도 승인코드',
      '배포 실행 직전 최종 백업 스냅샷 확인',
      '배포 후 운영 URL/버전/진입 스모크 확인'
    ],
    fatal: [],
    warnings: prereq.warnings || [],
    safety: cceda_safety_()
  };
}

function cceda_blocked_(reason, required) {
  return {
    ok: false,
    blocked: true,
    build: CONTROL_ERP_CORE_ACTUAL_DEPLOY_APPROVAL_BUILD,
    action: 'ACTUAL_DEPLOY_APPROVAL_GATE_ONLY',
    reason: reason,
    required: required,
    actualDeployApprovalReady: false,
    deployAllowed: false,
    actualDeployExecution: false,
    businessDataWrite: false,
    safety: cceda_safety_()
  };
}

function cceda_selfTest() {
  return {
    ok: true,
    build: CONTROL_ERP_CORE_ACTUAL_DEPLOY_APPROVAL_BUILD,
    fatal: [],
    warnings: [],
    expected: cceda_expected_(),
    approvalCode: CONTROL_ERP_CORE_ACTUAL_DEPLOY_APPROVAL_CODE,
    safety: cceda_safety_()
  };
}
