/** CONTROL CENTER B06J41 761_940 - Precheck */
function ccgRequiredLogSchemas_() {
  return {
    ApprovalLog: ['approvalId','projectCode','controlProjectCode','approvalType','approvalScope','approvalStatus','approvedBy','approvedAt','requestedBy','requestedAt','targetSheetName','targetAction','relatedBuild','relatedDeployId','reason','status','statusReason','createdAt','createdBy','updatedAt','updatedBy','notes'],
    BackupLog: ['backupId','projectCode','buildRange','sourceDb','targetDb','backupScope','backupStatus','backupStartedAt','backupCompletedAt','executedBy','relatedDeployId','rollbackBaselineId','notes'],
    RecoveryLog: ['recoveryId','rollbackBaselineId','projectCode','baselineBuild','rollbackScope','rollbackAllowed','createdAt','createdBy','reason'],
    DeployLog: ['deployId','projectCode','buildNo','deployLevel','deployStatus','approvedBy','approvalId','backupId','rollbackBaselineId','startedAt','completedAt','result','notes']
  };
}

function checkControlCenterB06J41_761_940_Precheck() {
  const configResult = ccgReadSystemConfig_();
  const master = ccgOpenMasterDb_(configResult.config);
  const schemas = ccgRequiredLogSchemas_();
  const sheets = [];
  let totalMissingHeaders = 0;
  const missingSheets = [];
  Object.keys(schemas).forEach(function(sheetName) {
    const sheet = master.ss.getSheetByName(sheetName);
    const exists = !!sheet;
    const headerMap = exists ? ccgHeaderMap_(sheet) : {};
    const missingHeaders = schemas[sheetName].filter(function(h) { return !headerMap[h]; });
    if (!exists) missingSheets.push(sheetName);
    totalMissingHeaders += missingHeaders.length;
    sheets.push({
      sheetName,
      exists,
      requiredHeaderCount: schemas[sheetName].length,
      currentHeaderCount: Object.keys(headerMap).length,
      missingHeaderCount: missingHeaders.length,
      missingHeaders,
      actualCreateBlocked: true,
      actualHeaderAddBlocked: true,
      ok: exists && missingHeaders.length === 0
    });
  });
  return {
    ok: true,
    build: CONTROL_GUARD_BUNDLE_BUILD,
    masterDbName: master.masterDbName,
    missingSheets,
    totalMissingHeaders,
    sheets,
    backupFolderCandidates: ccgBackupFolderCandidates_(configResult.config),
    safety: ccgSafety_()
  };
}

function ccgBackupFolderCandidates_(config) {
  return [
    { key: 'BACKUP_DB_FOLDER_ID', value: config.BACKUP_DB_FOLDER_ID || '' },
    { key: 'BACKUP_SIGN_FOLDER_ID', value: config.BACKUP_SIGN_FOLDER_ID || '' },
    { key: 'BACKUP_PORTAL_FOLDER_ID', value: config.BACKUP_PORTAL_FOLDER_ID || '' },
    { key: 'BACKUP_FOLDER_ID', value: config.BACKUP_FOLDER_ID || '' }
  ].filter(function(item) { return String(item.value || '').trim(); });
}
