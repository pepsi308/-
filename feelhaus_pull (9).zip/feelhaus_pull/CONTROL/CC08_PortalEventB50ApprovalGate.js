/**
 * FEELHAUS CONTROL - PORTAL EVENT B50 APPROVAL GATE
 * Build: CONTROL_PORTAL_EVENT_B50_APPROVAL_GATE_V01
 * Target baseline: PORTAL_EVENT_B50_FINAL_STABLE_READONLY_20260611
 * Execution function: runControlPortalEventB50ApprovalGateV01
 *
 * Safety:
 * - Diagnostic only
 * - No sheet creation
 * - No header mutation
 * - No log writing
 * - No approval writing
 * - No backup/deploy/recovery/rollback execution
 * - No PORTAL/ERP/field open mutation
 */
var CC08_BUILD = 'CONTROL_PORTAL_EVENT_B50_APPROVAL_GATE_V01';
var CC08_MODE = 'PORTAL_EVENT_B50_APPROVAL_DIAGNOSTIC_ONLY_NO_UPDATE';
var CC08_PORTAL_EVENT_BASELINE = {
  projectCode: 'PORTAL_EVENT',
  moduleCode: 'PORTAL_EVENT_MANAGEMENT',
  buildNo: 'PORTAL_EVENT_B50_FINAL_STABLE_READONLY_20260611',
  buildProgress: '50 / 50',
  progressPercent: 100,
  runFunction: 'portalEventB50RunAll',
  changedOnlyFile: 'PORTAL_EVENT_B50_CHANGED_ONLY.zip',
  requiredPreDeployBuild: 'CONTROL_PORTAL_EVENT_B50_PREDEPLOY_GATE_EVIDENCE_SYNC_PATCH_V01',
  approvalRequired: true,
  actualExecutionForbiddenInThisGate: true
};

function runControlPortalEventB50ApprovalGateV01() {
  var result = diagnoseControlPortalEventB50ApprovalGateV01_();
  CC08_logCompactResult_(result);
  return result;
}

function getControlPortalEventB50ApprovalGateData() {
  var result = diagnoseControlPortalEventB50ApprovalGateV01_();
  CC08_logCompactResult_(result);
  return result;
}

function controlPortalEventB50ApprovalGateV01() {
  var result = diagnoseControlPortalEventB50ApprovalGateV01_();
  CC08_logCompactResult_(result);
  return result;
}

function CC08_logCompactResult_(result) {
  Logger.log('JSON_COMPACT_RESULT: ' + JSON.stringify(CC08_compactResult_(result)));
}

function CC08_compactResult_(result) {
  result = result || {};
  var summary = result.summary || {};
  var details = result.details || {};
  var schema = details.schema || {};
  var preDeploy = details.preDeployGate || {};
  var approval = details.approval || {};
  var operationBlock = details.operationBlock || {};
  return {
    ok: result.ok === true,
    build: result.build || CC08_BUILD,
    mode: result.mode || CC08_MODE,
    checkedAt: result.checkedAt || '',
    judgement: result.judgement || summary.judgement || 'BLOCK',
    targetBaseline: {
      projectCode: CC08_PORTAL_EVENT_BASELINE.projectCode,
      moduleCode: CC08_PORTAL_EVENT_BASELINE.moduleCode,
      buildNo: CC08_PORTAL_EVENT_BASELINE.buildNo,
      buildProgress: CC08_PORTAL_EVENT_BASELINE.buildProgress,
      progressPercent: CC08_PORTAL_EVENT_BASELINE.progressPercent,
      runFunction: CC08_PORTAL_EVENT_BASELINE.runFunction,
      changedOnlyFile: CC08_PORTAL_EVENT_BASELINE.changedOnlyFile
    },
    summary: {
      baselineOk: summary.baselineOk === true,
      configOk: summary.configOk === true,
      masterOk: summary.masterOk === true,
      requiredGateSheetsOk: summary.requiredGateSheetsOk === true,
      requiredGateHeadersOk: summary.requiredGateHeadersOk === true,
      preDeployGatePassed: summary.preDeployGatePassed === true,
      backupEvidenceOk: summary.backupEvidenceOk === true,
      rollbackEvidenceOk: summary.rollbackEvidenceOk === true,
      approvalEvidenceOk: summary.approvalEvidenceOk === true,
      approvalScopeOk: summary.approvalScopeOk === true,
      approvalStatusOk: summary.approvalStatusOk === true,
      approvalActorOk: summary.approvalActorOk === true,
      controlApprovalBlockOk: summary.controlApprovalBlockOk === true,
      operationSaveBlocked: summary.operationSaveBlocked !== false,
      erpApplyBlocked: summary.erpApplyBlocked !== false,
      fieldOpenBlocked: summary.fieldOpenBlocked !== false,
      diagnosticOnly: summary.diagnosticOnly === true,
      dryRunOnly: summary.dryRunOnly === true,
      deployAllowed: summary.deployAllowed === true,
      actualExecutionBlocked: summary.actualExecutionBlocked !== false,
      sheetWriteExecuted: summary.sheetWriteExecuted === true,
      sheetCreateExecuted: summary.sheetCreateExecuted === true,
      headerAutoAddExecuted: summary.headerAutoAddExecuted === true,
      approvalWriteExecuted: summary.approvalWriteExecuted === true,
      auditLogWriteExecuted: summary.auditLogWriteExecuted === true,
      backupExecuted: summary.backupExecuted === true,
      deployExecuted: summary.deployExecuted === true,
      recoveryExecuted: summary.recoveryExecuted === true,
      rollbackExecuted: summary.rollbackExecuted === true,
      erpApplyExecuted: summary.erpApplyExecuted === true,
      actualOpenExecuted: summary.actualOpenExecuted === true,
      productionDataMutationExecuted: summary.productionDataMutationExecuted === true
    },
    evidence: {
      missingSheets: schema.missingSheets || [],
      totalMissingHeaders: schema.totalMissingHeaders || 0,
      preDeployBuild: preDeploy.build || '',
      preDeployJudgement: preDeploy.judgement || '',
      preDeployBackupEvidenceOk: preDeploy.preDeployBackupEvidenceOk === true,
      preDeployRollbackEvidenceOk: preDeploy.rollbackBaselineEvidenceOk === true,
      approvedPortalEventB50Count: approval.approvedPortalEventB50Count || 0,
      approvalCandidateCount: approval.approvalCandidateCount || 0,
      latestApprovalEvidence: approval.latestApprovalEvidence || null,
      actualBackupAllowed: operationBlock.actualBackupAllowed === true,
      actualDeployAllowed: operationBlock.actualDeployAllowed === true,
      actualRecoveryAllowed: operationBlock.actualRecoveryAllowed === true,
      actualRollbackAllowed: operationBlock.actualRollbackAllowed === true,
      actualPortalSaveAllowed: operationBlock.actualPortalSaveAllowed === true,
      actualErpApplyAllowed: operationBlock.actualErpApplyAllowed === true,
      actualFieldOpenAllowed: operationBlock.actualFieldOpenAllowed === true
    },
    warnings: result.warnings || [],
    hold: result.hold || [],
    fatal: result.fatal || [],
    nextAction: result.nextAction || ''
  };
}

function diagnoseControlPortalEventB50ApprovalGateV01_() {
  var fatal = [];
  var warnings = [];
  var hold = [];
  var details = {
    build: CC08_BUILD,
    mode: CC08_MODE,
    checkedAt: CC_now_(),
    sourceDb: CC_SOURCE_DB,
    setupDbId: CC_SETUP_DB_ID,
    configSheetName: CC_CONFIG_SHEET_NAME,
    targetBaseline: CC08_PORTAL_EVENT_BASELINE,
    safety: CC08_safety_(),
    config: null,
    master: null,
    schema: null,
    preDeployGate: null,
    approval: null,
    operationBlock: null
  };
  var summary = CC08_baseSummary_();

  try {
    var cfgResult = CC_readSystemConfig_();
    summary.configOk = !!(cfgResult && cfgResult.ok);
    details.config = {
      ok: summary.configOk,
      message: cfgResult && cfgResult.message ? cfgResult.message : '',
      sourceDb: CC_SOURCE_DB,
      setupDbId: CC_SETUP_DB_ID,
      configSheetName: CC_CONFIG_SHEET_NAME
    };
    if (!summary.configOk) fatal.push('SystemConfig 자동 읽기 실패');

    var config = cfgResult && cfgResult.config ? cfgResult.config : {};
    var masterId = CC_resolveMasterDbId_(config);
    if (!masterId) {
      summary.masterOk = false;
      fatal.push('FEELHAUS_DB_MASTER ID를 SystemConfig에서 찾지 못했습니다.');
      return CC08_result_(summary, fatal, warnings, hold, details);
    }

    var masterSs = SpreadsheetApp.openById(masterId);
    summary.masterOk = !!masterSs;
    details.master = {
      ok: summary.masterOk,
      masterDbId: masterId,
      masterDbName: masterSs ? masterSs.getName() : ''
    };
    if (!summary.masterOk) fatal.push('FEELHAUS_DB_MASTER 연결 실패');

    details.schema = CC08_checkApprovalSchemas_(masterSs);
    summary.requiredGateSheetsOk = details.schema.ok && details.schema.missingSheets.length === 0;
    summary.requiredGateHeadersOk = details.schema.totalMissingHeaders === 0;
    if (!summary.requiredGateSheetsOk) fatal.push('승인 게이트 필수 로그 시트 누락: ' + details.schema.missingSheets.join(', '));
    if (!summary.requiredGateHeadersOk) fatal.push('승인 게이트 필수 헤더 누락 합계: ' + details.schema.totalMissingHeaders);

    details.preDeployGate = CC08_checkPreDeployGatePass_();
    summary.preDeployGatePassed = details.preDeployGate.ok === true;
    summary.backupEvidenceOk = details.preDeployGate.preDeployBackupEvidenceOk === true;
    summary.rollbackEvidenceOk = details.preDeployGate.rollbackBaselineEvidenceOk === true;
    if (!summary.preDeployGatePassed) hold.push('PORTAL_EVENT_B50 배포 전 진단 PASS 결과가 확인되지 않았습니다.');
    if (!summary.backupEvidenceOk) hold.push('PORTAL_EVENT_B50 백업 증빙 PASS 결과가 확인되지 않았습니다.');
    if (!summary.rollbackEvidenceOk) hold.push('PORTAL_EVENT_B50 롤백 증빙 PASS 결과가 확인되지 않았습니다.');

    details.approval = CC08_checkApprovalEvidence_(masterSs);
    summary.approvalEvidenceOk = details.approval.ok === true;
    summary.approvalScopeOk = details.approval.approvalScopeOk === true;
    summary.approvalStatusOk = details.approval.approvalStatusOk === true;
    summary.approvalActorOk = details.approval.approvalActorOk === true;
    if (!summary.approvalEvidenceOk) hold.push('PORTAL_EVENT_B50 CONTROL 승인 증빙이 아직 ApprovalLog에서 확인되지 않았습니다.');
    if (summary.approvalEvidenceOk && !summary.approvalScopeOk) hold.push('PORTAL_EVENT_B50 승인 범위가 배포/운영 저장/ERP 반영/현장 오픈 중 무엇을 허용하는지 불명확합니다.');
    if (summary.approvalEvidenceOk && !summary.approvalActorOk) hold.push('PORTAL_EVENT_B50 승인자 또는 승인 시간이 불명확합니다.');

    details.operationBlock = CC08_checkOperationBlock_();
    summary.controlApprovalBlockOk = details.operationBlock.actualExecutionBlocked === true && details.operationBlock.deployAllowed === false;
    summary.operationSaveBlocked = details.operationBlock.actualPortalSaveAllowed !== true;
    summary.erpApplyBlocked = details.operationBlock.actualErpApplyAllowed !== true;
    summary.fieldOpenBlocked = details.operationBlock.actualFieldOpenAllowed !== true;
    summary.actualExecutionBlocked = details.operationBlock.actualExecutionBlocked !== false;
    summary.deployAllowed = false;
    if (!summary.controlApprovalBlockOk) fatal.push('승인 게이트에서 실제 실행 차단 기준이 깨졌습니다.');

    summary.baselineOk = CC08_checkBaseline_().ok;
    if (!summary.baselineOk) fatal.push('PORTAL_EVENT_B50 기준선 값 불일치');

    return CC08_result_(summary, fatal, warnings, hold, details);
  } catch (err) {
    fatal.push(String(err && err.message ? err.message : err));
    return CC08_result_(summary, fatal, warnings, hold, details);
  }
}

function CC08_baseSummary_() {
  return {
    ok: false,
    judgement: 'BLOCK',
    baselineOk: false,
    configOk: false,
    masterOk: false,
    requiredGateSheetsOk: false,
    requiredGateHeadersOk: false,
    preDeployGatePassed: false,
    backupEvidenceOk: false,
    rollbackEvidenceOk: false,
    approvalEvidenceOk: false,
    approvalScopeOk: false,
    approvalStatusOk: false,
    approvalActorOk: false,
    controlApprovalBlockOk: false,
    operationSaveBlocked: true,
    erpApplyBlocked: true,
    fieldOpenBlocked: true,
    diagnosticOnly: true,
    dryRunOnly: true,
    deployAllowed: false,
    actualExecutionBlocked: true,
    sheetWriteExecuted: false,
    sheetCreateExecuted: false,
    headerAutoAddExecuted: false,
    approvalWriteExecuted: false,
    auditLogWriteExecuted: false,
    backupExecuted: false,
    deployExecuted: false,
    recoveryExecuted: false,
    rollbackExecuted: false,
    erpApplyExecuted: false,
    actualOpenExecuted: false,
    productionDataMutationExecuted: false
  };
}

function CC08_safety_() {
  var s = (typeof CC_getSafety_ === 'function') ? CC_getSafety_() : {};
  s.diagnosticOnly = true;
  s.dryRunOnly = true;
  s.actualExecutionBlocked = true;
  s.deployAllowed = false;
  s.noSheetWrite = true;
  s.noSheetCreate = true;
  s.noHeaderAutoAdd = true;
  s.noApprovalWrite = true;
  s.noAuditLogWrite = true;
  s.noBackupExecution = true;
  s.noDeployExecution = true;
  s.noRecoveryExecution = true;
  s.noRollbackExecution = true;
  s.noErpApply = true;
  s.noFieldOpenExecution = true;
  return s;
}

function CC08_checkBaseline_() {
  var b = CC08_PORTAL_EVENT_BASELINE;
  return {
    ok: b.projectCode === 'PORTAL_EVENT' &&
      b.moduleCode === 'PORTAL_EVENT_MANAGEMENT' &&
      b.buildNo === 'PORTAL_EVENT_B50_FINAL_STABLE_READONLY_20260611' &&
      b.progressPercent === 100 &&
      b.runFunction === 'portalEventB50RunAll' &&
      b.changedOnlyFile === 'PORTAL_EVENT_B50_CHANGED_ONLY.zip',
    targetBaseline: b,
    actualWriteExecuted: false
  };
}

function CC08_checkApprovalSchemas_(masterSs) {
  var specs = [
    { name: 'ApprovalLog', required: ['approvalId', 'approvalType', 'approvalScope', 'approvalStatus', 'approvedBy', 'approvedAt', 'targetAction', 'relatedBuild', 'status', 'createdAt', 'createdBy'] },
    { name: 'BackupLog', required: ['backupId', 'projectCode', 'buildRange', 'sourceDb', 'targetDb', 'backupScope', 'backupStatus', 'backupStartedAt', 'executedBy', 'rollbackBaselineId', 'status'] },
    { name: 'DeployLog', required: ['deployId', 'projectCode', 'buildNo', 'deployLevel', 'deployStatus', 'approvalId', 'backupId', 'rollbackBaselineId', 'result', 'status'] },
    { name: 'RecoveryLog', required: ['recoveryId', 'rollbackBaselineId', 'projectCode', 'baselineBuild', 'rollbackScope', 'rollbackAllowed', 'reason', 'recoveryStatus', 'createdAt', 'createdBy', 'status'] }
  ];
  var missingSheets = [];
  var totalMissingHeaders = 0;
  var sheets = [];
  specs.forEach(function (spec) {
    var sheet = masterSs.getSheetByName(spec.name);
    var headerMap = sheet ? CC_headerMap_(sheet) : {};
    var missing = [];
    spec.required.forEach(function (h) {
      if (!headerMap[h]) missing.push(h);
    });
    if (!sheet) missingSheets.push(spec.name);
    totalMissingHeaders += missing.length;
    sheets.push({
      sheetName: spec.name,
      exists: !!sheet,
      rowCount: sheet ? CC_countRows_(sheet) : 0,
      requiredHeaderCount: spec.required.length,
      missingHeaderCount: missing.length,
      missingHeaders: missing,
      ok: !!sheet && missing.length === 0,
      actualCreateBlocked: true,
      actualHeaderAddBlocked: true,
      actualWriteBlocked: true
    });
  });
  return {
    ok: missingSheets.length === 0 && totalMissingHeaders === 0,
    missingSheets: missingSheets,
    totalMissingHeaders: totalMissingHeaders,
    sheets: sheets,
    actualCreateBlocked: true,
    actualHeaderAddBlocked: true,
    actualWriteBlocked: true
  };
}

function CC08_checkPreDeployGatePass_() {
  var compact = null;
  var full = null;
  if (typeof diagnoseControlPortalEventB50PreDeployGateV01_ === 'function') {
    full = diagnoseControlPortalEventB50PreDeployGateV01_();
    if (typeof CC06_compactResult_ === 'function') compact = CC06_compactResult_(full);
  }
  compact = compact || {};
  var summary = compact.summary || {};
  return {
    ok: compact.judgement === 'PASS' && summary.preDeployBackupEvidenceOk === true && summary.rollbackBaselineEvidenceOk === true,
    build: compact.build || '',
    judgement: compact.judgement || '',
    preDeployBackupEvidenceOk: summary.preDeployBackupEvidenceOk === true,
    rollbackBaselineEvidenceOk: summary.rollbackBaselineEvidenceOk === true,
    fatal: compact.fatal || [],
    hold: compact.hold || [],
    actualWriteExecuted: false,
    message: compact.judgement === 'PASS' ? 'B50 배포 전 진단 PASS 결과를 재확인했습니다.' : 'B50 배포 전 진단 PASS 결과가 아직 확인되지 않았습니다.'
  };
}

function CC08_checkApprovalEvidence_(masterSs) {
  var sheet = masterSs.getSheetByName('ApprovalLog');
  var rows = CC_getRowsAsObjects_(sheet);
  var candidates = [];
  var approved = [];
  rows.forEach(function (row) {
    var text = CC08_rowText_(row);
    var related = text.indexOf('PORTAL_EVENT_B50') >= 0 ||
      text.indexOf('PORTAL_EVENT_B50_FINAL_STABLE_READONLY_20260611') >= 0 ||
      text.indexOf('B50_FINAL_STABLE') >= 0 ||
      text.indexOf('PORTAL_EVENT') >= 0;
    if (!related) return;
    candidates.push(row);
    var approvalStatus = String(row.approvalStatus || row.status || '').toUpperCase();
    var activeStatus = String(row.status || '').toUpperCase();
    var approvedLike = approvalStatus.indexOf('APPROVED') >= 0 || approvalStatus.indexOf('PASS') >= 0 || approvalStatus.indexOf('승인') >= 0;
    var notCancelled = activeStatus.indexOf('CANCEL') < 0 && activeStatus.indexOf('REJECT') < 0 && activeStatus.indexOf('반려') < 0;
    if (approvedLike && notCancelled) approved.push(row);
  });
  var latest = approved.length ? approved[approved.length - 1] : null;
  var scopeText = latest ? String(latest.approvalScope || latest.targetAction || latest.approvalType || '') : '';
  var scopeUpper = scopeText.toUpperCase();
  var approvalScopeOk = latest ? (
    scopeUpper.indexOf('DEPLOY') >= 0 ||
    scopeUpper.indexOf('PREDEPLOY') >= 0 ||
    scopeUpper.indexOf('FIELD_OPEN') >= 0 ||
    scopeUpper.indexOf('ERP_APPLY') >= 0 ||
    scopeUpper.indexOf('PORTAL_EVENT') >= 0 ||
    scopeText.indexOf('배포') >= 0 ||
    scopeText.indexOf('운영') >= 0 ||
    scopeText.indexOf('현장') >= 0 ||
    scopeText.indexOf('승인') >= 0
  ) : false;
  var actorOk = latest ? Boolean(String(latest.approvedBy || latest.createdBy || '').trim() && String(latest.approvedAt || latest.createdAt || '').trim()) : false;
  return {
    ok: approved.length > 0 && approvalScopeOk && actorOk,
    approvalCandidateCount: candidates.length,
    approvedPortalEventB50Count: approved.length,
    approvalStatusOk: approved.length > 0,
    approvalScopeOk: approvalScopeOk,
    approvalActorOk: actorOk,
    latestApprovalEvidence: latest ? CC08_pickSafeApprovalEvidence_(latest) : null,
    approvalWriteExecuted: false,
    actualWriteExecuted: false,
    message: approved.length > 0 ? 'PORTAL_EVENT_B50 승인 후보를 ApprovalLog에서 조회했습니다.' : 'PORTAL_EVENT_B50 승인 증빙이 아직 ApprovalLog에서 확인되지 않았습니다.'
  };
}

function CC08_checkOperationBlock_() {
  return {
    deployAllowed: false,
    actualExecutionBlocked: true,
    actualBackupAllowed: false,
    actualDeployAllowed: false,
    actualRecoveryAllowed: false,
    actualRollbackAllowed: false,
    actualPortalSaveAllowed: false,
    actualErpApplyAllowed: false,
    actualFieldOpenAllowed: false,
    sheetWriteExecuted: false,
    sheetCreateExecuted: false,
    headerAutoAddExecuted: false,
    approvalWriteExecuted: false,
    auditLogWriteExecuted: false,
    backupExecuted: false,
    deployExecuted: false,
    recoveryExecuted: false,
    rollbackExecuted: false,
    erpApplyExecuted: false,
    actualOpenExecuted: false,
    productionDataMutationExecuted: false
  };
}

function CC08_result_(summary, fatal, warnings, hold, details) {
  var judgement = 'BLOCK';
  if (fatal.length === 0 && hold.length === 0) judgement = 'PASS';
  else if (fatal.length === 0) judgement = 'HOLD';
  summary.ok = fatal.length === 0;
  summary.judgement = judgement;
  summary.diagnosticOnly = true;
  summary.dryRunOnly = true;
  summary.deployAllowed = false;
  summary.actualExecutionBlocked = true;
  summary.sheetWriteExecuted = false;
  summary.sheetCreateExecuted = false;
  summary.headerAutoAddExecuted = false;
  summary.approvalWriteExecuted = false;
  summary.auditLogWriteExecuted = false;
  summary.backupExecuted = false;
  summary.deployExecuted = false;
  summary.recoveryExecuted = false;
  summary.rollbackExecuted = false;
  summary.erpApplyExecuted = false;
  summary.actualOpenExecuted = false;
  summary.productionDataMutationExecuted = false;
  return {
    ok: fatal.length === 0,
    build: CC08_BUILD,
    mode: CC08_MODE,
    checkedAt: details.checkedAt || CC_now_(),
    judgement: judgement,
    targetBaseline: CC08_PORTAL_EVENT_BASELINE,
    summary: summary,
    details: details,
    warnings: warnings,
    hold: hold,
    fatal: fatal,
    nextAction: CC08_nextAction_(judgement)
  };
}

function CC08_nextAction_(judgement) {
  if (judgement === 'PASS') {
    return 'PORTAL_EVENT_B50 CONTROL 승인 게이트 PASS. 다음 단계는 배포 허용 최종 게이트입니다. 실제 운영 저장/ERP 반영/현장 오픈은 계속 금지입니다.';
  }
  if (judgement === 'HOLD') {
    return 'PORTAL_EVENT_B50 CONTROL 승인 게이트 HOLD. ApprovalLog 승인 증빙 또는 승인 범위/승인자/승인시간 확인 후 재진단하세요.';
  }
  return 'PORTAL_EVENT_B50 CONTROL 승인 게이트 BLOCK. SystemConfig/MASTER/로그 구조 오류를 먼저 복구하세요.';
}

function CC08_rowText_(row) {
  var parts = [];
  Object.keys(row || {}).forEach(function (k) {
    parts.push(String(row[k] || ''));
  });
  return parts.join(' ').toUpperCase();
}

function CC08_pickSafeApprovalEvidence_(row) {
  return {
    approvalId: row.approvalId || '',
    approvalType: row.approvalType || '',
    approvalScope: row.approvalScope || '',
    approvalStatus: row.approvalStatus || row.status || '',
    approvedBy: row.approvedBy || row.createdBy || '',
    approvedAt: row.approvedAt || row.createdAt || '',
    targetAction: row.targetAction || '',
    relatedBuild: row.relatedBuild || row.buildNo || '',
    status: row.status || ''
  };
}
