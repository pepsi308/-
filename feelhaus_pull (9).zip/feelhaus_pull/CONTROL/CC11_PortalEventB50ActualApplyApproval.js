/**
 * FEELHAUS CONTROL - PORTAL EVENT B50 ACTUAL APPLY APPROVAL GATE
 * Build: CONTROL_PORTAL_EVENT_B50_ACTUAL_APPLY_APPROVAL_V01
 * Target baseline: PORTAL_EVENT_B50_FINAL_STABLE_READONLY_20260611
 * Execution function: runControlPortalEventB50ActualApplyApprovalV01
 *
 * Safety:
 * - Diagnostic only
 * - No sheet creation
 * - No header mutation
 * - No approval writing
 * - No audit log writing
 * - No backup/deploy/recovery/rollback execution
 * - No PORTAL operation save
 * - No ERP apply
 * - No field open execution
 */
var CC11_BUILD = 'CONTROL_PORTAL_EVENT_B50_ACTUAL_APPLY_APPROVAL_V01';
var CC11_MODE = 'PORTAL_EVENT_B50_ACTUAL_APPLY_APPROVAL_DIAGNOSTIC_ONLY_NO_UPDATE';
var CC11_TARGET = {
  projectCode: 'PORTAL_EVENT',
  moduleCode: 'PORTAL_EVENT_MANAGEMENT',
  buildNo: 'PORTAL_EVENT_B50_FINAL_STABLE_READONLY_20260611',
  buildProgress: '50 / 50',
  progressPercent: 100,
  runFunction: 'portalEventB50RunAll',
  changedOnlyFile: 'PORTAL_EVENT_B50_CHANGED_ONLY.zip',
  requiredFieldOpenDecisionBuild: 'CONTROL_PORTAL_EVENT_B50_FIELD_OPEN_DECISION_V01',
  requiredApprovalType: 'PORTAL_EVENT_B50_ACTUAL_APPLY_APPROVAL',
  requiredApprovalScope: 'PORTAL_EVENT_B50_ACTUAL_APPLY',
  requiredTargetAction: 'PORTAL_EVENT_B50_ACTUAL_APPLY'
};

function runControlPortalEventB50ActualApplyApprovalV01() {
  var result = diagnoseControlPortalEventB50ActualApplyApprovalV01_();
  CC11_logCompactResult_(result);
  return result;
}

function runPortalEventB50ActualApplyApprovalV01() {
  var result = diagnoseControlPortalEventB50ActualApplyApprovalV01_();
  CC11_logCompactResult_(result);
  return result;
}

function getControlPortalEventB50ActualApplyApprovalData() {
  var result = diagnoseControlPortalEventB50ActualApplyApprovalV01_();
  CC11_logCompactResult_(result);
  return result;
}

function controlPortalEventB50ActualApplyApprovalV01() {
  var result = diagnoseControlPortalEventB50ActualApplyApprovalV01_();
  CC11_logCompactResult_(result);
  return result;
}

function CC11_logCompactResult_(result) {
  Logger.log('JSON_COMPACT_RESULT: ' + JSON.stringify(CC11_compactResult_(result)));
}

function CC11_compactResult_(result) {
  result = result || {};
  var summary = result.summary || {};
  var details = result.details || {};
  var schema = details.schema || {};
  var fieldGate = details.fieldOpenDecisionGate || {};
  var approval = details.actualApplyApproval || {};
  var op = details.operationBlock || {};
  return {
    ok: result.ok === true,
    build: result.build || CC11_BUILD,
    mode: result.mode || CC11_MODE,
    checkedAt: result.checkedAt || '',
    judgement: result.judgement || summary.judgement || 'BLOCK',
    targetBaseline: {
      projectCode: CC11_TARGET.projectCode,
      moduleCode: CC11_TARGET.moduleCode,
      buildNo: CC11_TARGET.buildNo,
      buildProgress: CC11_TARGET.buildProgress,
      progressPercent: CC11_TARGET.progressPercent,
      runFunction: CC11_TARGET.runFunction,
      changedOnlyFile: CC11_TARGET.changedOnlyFile
    },
    summary: {
      baselineOk: summary.baselineOk === true,
      configOk: summary.configOk === true,
      masterOk: summary.masterOk === true,
      requiredGateSheetsOk: summary.requiredGateSheetsOk === true,
      requiredGateHeadersOk: summary.requiredGateHeadersOk === true,
      fieldOpenDecisionGatePassed: summary.fieldOpenDecisionGatePassed === true,
      fieldOpenDecisionOk: summary.fieldOpenDecisionOk === true,
      fieldOpenAllowed: summary.fieldOpenAllowed === true,
      actualApplyApprovalEvidenceOk: summary.actualApplyApprovalEvidenceOk === true,
      actualApplyApprovalScopeOk: summary.actualApplyApprovalScopeOk === true,
      actualApplyApprovalStatusOk: summary.actualApplyApprovalStatusOk === true,
      actualApplyApprovalActorOk: summary.actualApplyApprovalActorOk === true,
      actualApplyReadinessOk: summary.actualApplyReadinessOk === true,
      actualApplyAllowedCandidate: summary.actualApplyAllowedCandidate === true,
      actualExecutionBlocked: summary.actualExecutionBlocked !== false,
      actualDeployAllowed: summary.actualDeployAllowed === true,
      actualPortalSaveAllowed: summary.actualPortalSaveAllowed === true,
      actualErpApplyAllowed: summary.actualErpApplyAllowed === true,
      actualFieldOpenAllowed: summary.actualFieldOpenAllowed === true,
      diagnosticOnly: summary.diagnosticOnly === true,
      dryRunOnly: summary.dryRunOnly === true,
      sheetWriteExecuted: summary.sheetWriteExecuted === true,
      sheetCreateExecuted: summary.sheetCreateExecuted === true,
      headerAutoAddExecuted: summary.headerAutoAddExecuted === true,
      approvalWriteExecuted: summary.approvalWriteExecuted === true,
      auditLogWriteExecuted: summary.auditLogWriteExecuted === true,
      backupExecuted: summary.backupExecuted === true,
      deployExecuted: summary.deployExecuted === true,
      recoveryExecuted: summary.recoveryExecuted === true,
      rollbackExecuted: summary.rollbackExecuted === true,
      erpApplyExecuted: summary.erpApplyExecuted === true,
      actualOpenExecuted: summary.actualOpenExecuted === true,
      productionDataMutationExecuted: summary.productionDataMutationExecuted === true
    },
    evidence: {
      missingSheets: schema.missingSheets || [],
      totalMissingHeaders: schema.totalMissingHeaders || 0,
      fieldOpenDecisionBuild: fieldGate.build || '',
      fieldOpenDecisionJudgement: fieldGate.judgement || '',
      fieldOpenDecisionGatePassed: fieldGate.ok === true,
      fieldGateFieldOpenAllowed: fieldGate.fieldOpenAllowed === true,
      actualApplyApprovalCandidateCount: approval.candidateCount || 0,
      approvedActualApplyCount: approval.approvedCount || 0,
      latestActualApplyApproval: approval.latest || null,
      readinessReason: details.readinessReason || '',
      actualBackupAllowed: op.actualBackupAllowed === true,
      actualDeployAllowed: op.actualDeployAllowed === true,
      actualRecoveryAllowed: op.actualRecoveryAllowed === true,
      actualRollbackAllowed: op.actualRollbackAllowed === true,
      actualPortalSaveAllowed: op.actualPortalSaveAllowed === true,
      actualErpApplyAllowed: op.actualErpApplyAllowed === true,
      actualFieldOpenAllowed: op.actualFieldOpenAllowed === true
    },
    warnings: result.warnings || [],
    hold: result.hold || [],
    fatal: result.fatal || [],
    nextAction: result.nextAction || ''
  };
}

function diagnoseControlPortalEventB50ActualApplyApprovalV01_() {
  var fatal = [];
  var warnings = [];
  var hold = [];
  var details = {
    build: CC11_BUILD,
    mode: CC11_MODE,
    checkedAt: (typeof CC_now_ === 'function') ? CC_now_() : new Date().toISOString(),
    sourceDb: (typeof CC_SOURCE_DB !== 'undefined') ? CC_SOURCE_DB : 'FEELHAUS_SETUP_DB',
    setupDbId: (typeof CC_SETUP_DB_ID !== 'undefined') ? CC_SETUP_DB_ID : '17VMSpgSZCvIrUlgcw8yCNcnl8WQWo2IcRf5tDCcuJGM',
    configSheetName: (typeof CC_CONFIG_SHEET_NAME !== 'undefined') ? CC_CONFIG_SHEET_NAME : 'SystemConfig',
    targetBaseline: CC11_TARGET,
    safety: CC11_safety_(),
    config: null,
    master: null,
    schema: null,
    fieldOpenDecisionGate: null,
    actualApplyApproval: null,
    operationBlock: null,
    readinessReason: ''
  };
  var summary = CC11_baseSummary_();

  try {
    var cfgResult = (typeof CC_readSystemConfig_ === 'function') ? CC_readSystemConfig_() : null;
    summary.configOk = !!(cfgResult && cfgResult.ok);
    details.config = {
      ok: summary.configOk,
      message: cfgResult && cfgResult.message ? cfgResult.message : '',
      sourceDb: details.sourceDb,
      setupDbId: details.setupDbId,
      configSheetName: details.configSheetName
    };
    if (!summary.configOk) fatal.push('SystemConfig read failed');

    var config = cfgResult && cfgResult.config ? cfgResult.config : {};
    var masterId = (typeof CC_resolveMasterDbId_ === 'function') ? CC_resolveMasterDbId_(config) : '';
    if (!masterId) {
      summary.masterOk = false;
      fatal.push('FEELHAUS_DB_MASTER id not found');
      return CC11_result_(summary, fatal, warnings, hold, details);
    }
    var masterSs = SpreadsheetApp.openById(masterId);
    summary.masterOk = !!masterSs;
    details.master = { ok: summary.masterOk, masterDbId: masterId, masterDbName: masterSs ? masterSs.getName() : '' };
    if (!summary.masterOk) fatal.push('FEELHAUS_DB_MASTER open failed');

    details.schema = (typeof CC09_checkGateSchemas_ === 'function') ? CC09_checkGateSchemas_(masterSs) : CC11_emptySchema_();
    summary.requiredGateSheetsOk = details.schema.ok && details.schema.missingSheets.length === 0;
    summary.requiredGateHeadersOk = details.schema.totalMissingHeaders === 0;
    if (!summary.requiredGateSheetsOk) fatal.push('Required gate sheets missing: ' + details.schema.missingSheets.join(', '));
    if (!summary.requiredGateHeadersOk) fatal.push('Required gate headers missing: ' + details.schema.totalMissingHeaders);

    details.fieldOpenDecisionGate = CC11_checkFieldOpenDecisionGatePass_();
    summary.fieldOpenDecisionGatePassed = details.fieldOpenDecisionGate.ok === true;
    summary.fieldOpenDecisionOk = details.fieldOpenDecisionGate.fieldOpenDecisionOk === true;
    summary.fieldOpenAllowed = details.fieldOpenDecisionGate.fieldOpenAllowed === true;
    if (!summary.fieldOpenDecisionGatePassed) hold.push('PORTAL_EVENT_B50 field open decision gate PASS was not confirmed');
    if (!summary.fieldOpenAllowed) hold.push('PORTAL_EVENT_B50 fieldOpenAllowed=true was not confirmed');

    details.actualApplyApproval = CC11_findActualApplyApproval_(masterSs);
    summary.actualApplyApprovalEvidenceOk = details.actualApplyApproval.ok === true;
    summary.actualApplyApprovalScopeOk = details.actualApplyApproval.scopeOk === true;
    summary.actualApplyApprovalStatusOk = details.actualApplyApproval.statusOk === true;
    summary.actualApplyApprovalActorOk = details.actualApplyApproval.actorOk === true;
    if (!summary.actualApplyApprovalEvidenceOk) hold.push('PORTAL_EVENT_B50 actual apply approval evidence was not found in ApprovalLog');
    if (details.actualApplyApproval.candidateCount > 0 && !summary.actualApplyApprovalEvidenceOk) {
      warnings.push('Actual apply approval candidate exists but scope/status/actor/build did not pass');
    }

    details.operationBlock = CC11_checkOperationBlock_();
    summary.actualExecutionBlocked = details.operationBlock.actualExecutionBlocked !== false;
    summary.actualDeployAllowed = details.operationBlock.actualDeployAllowed === true;
    summary.actualPortalSaveAllowed = details.operationBlock.actualPortalSaveAllowed === true;
    summary.actualErpApplyAllowed = details.operationBlock.actualErpApplyAllowed === true;
    summary.actualFieldOpenAllowed = details.operationBlock.actualFieldOpenAllowed === true;
    if (!summary.actualExecutionBlocked || summary.actualDeployAllowed || summary.actualPortalSaveAllowed || summary.actualErpApplyAllowed || summary.actualFieldOpenAllowed) {
      fatal.push('Actual execution block policy is broken in approval gate');
    }

    summary.baselineOk = CC11_checkBaseline_().ok;
    if (!summary.baselineOk) fatal.push('Target baseline mismatch');

    summary.actualApplyReadinessOk = fatal.length === 0 && hold.length === 0 &&
      summary.baselineOk && summary.configOk && summary.masterOk &&
      summary.requiredGateSheetsOk && summary.requiredGateHeadersOk &&
      summary.fieldOpenDecisionGatePassed && summary.fieldOpenDecisionOk && summary.fieldOpenAllowed &&
      summary.actualApplyApprovalEvidenceOk && summary.actualApplyApprovalScopeOk &&
      summary.actualApplyApprovalStatusOk && summary.actualApplyApprovalActorOk &&
      summary.actualExecutionBlocked;
    summary.actualApplyAllowedCandidate = summary.actualApplyReadinessOk === true;
    details.readinessReason = summary.actualApplyReadinessOk ?
      'Field open decision PASS + actual apply approval PASS were confirmed. This gate still does not execute production changes.' :
      'Actual apply approval gate is not ready. Fix HOLD/BLOCK items first.';

    return CC11_result_(summary, fatal, warnings, hold, details);
  } catch (err) {
    fatal.push(String(err && err.message ? err.message : err));
    return CC11_result_(summary, fatal, warnings, hold, details);
  }
}

function CC11_baseSummary_() {
  return {
    ok: false,
    judgement: 'BLOCK',
    baselineOk: false,
    configOk: false,
    masterOk: false,
    requiredGateSheetsOk: false,
    requiredGateHeadersOk: false,
    fieldOpenDecisionGatePassed: false,
    fieldOpenDecisionOk: false,
    fieldOpenAllowed: false,
    actualApplyApprovalEvidenceOk: false,
    actualApplyApprovalScopeOk: false,
    actualApplyApprovalStatusOk: false,
    actualApplyApprovalActorOk: false,
    actualApplyReadinessOk: false,
    actualApplyAllowedCandidate: false,
    actualExecutionBlocked: true,
    actualDeployAllowed: false,
    actualPortalSaveAllowed: false,
    actualErpApplyAllowed: false,
    actualFieldOpenAllowed: false,
    diagnosticOnly: true,
    dryRunOnly: true,
    sheetWriteExecuted: false,
    sheetCreateExecuted: false,
    headerAutoAddExecuted: false,
    approvalWriteExecuted: false,
    auditLogWriteExecuted: false,
    backupExecuted: false,
    deployExecuted: false,
    recoveryExecuted: false,
    rollbackExecuted: false,
    erpApplyExecuted: false,
    actualOpenExecuted: false,
    productionDataMutationExecuted: false
  };
}

function CC11_safety_() {
  return {
    diagnosticOnly: true,
    dryRunOnly: true,
    actualExecutionBlocked: true,
    noSheetWrite: true,
    noSheetCreate: true,
    noHeaderAutoAdd: true,
    noApprovalWrite: true,
    noAuditLogWrite: true,
    noBackupExecution: true,
    noDeployExecution: true,
    noRecoveryExecution: true,
    noRollbackExecution: true,
    noPortalOperationSave: true,
    noErpApply: true,
    noFieldOpenExecution: true
  };
}

function CC11_checkBaseline_() {
  var b = CC11_TARGET;
  return {
    ok: b.projectCode === 'PORTAL_EVENT' &&
      b.moduleCode === 'PORTAL_EVENT_MANAGEMENT' &&
      b.buildNo === 'PORTAL_EVENT_B50_FINAL_STABLE_READONLY_20260611' &&
      b.progressPercent === 100 &&
      b.runFunction === 'portalEventB50RunAll' &&
      b.changedOnlyFile === 'PORTAL_EVENT_B50_CHANGED_ONLY.zip',
    targetBaseline: b,
    actualWriteExecuted: false
  };
}

function CC11_checkFieldOpenDecisionGatePass_() {
  var compact = null;
  var full = null;
  if (typeof diagnoseControlPortalEventB50FieldOpenDecisionV01_ === 'function') {
    full = diagnoseControlPortalEventB50FieldOpenDecisionV01_();
    if (typeof CC10_compactResult_ === 'function') compact = CC10_compactResult_(full);
  }
  compact = compact || {};
  var summary = compact.summary || {};
  return {
    ok: compact.judgement === 'PASS' && summary.fieldOpenDecisionOk === true && summary.fieldOpenAllowed === true,
    build: compact.build || '',
    judgement: compact.judgement || '',
    fieldOpenDecisionOk: summary.fieldOpenDecisionOk === true,
    fieldOpenAllowed: summary.fieldOpenAllowed === true,
    actualExecutionBlocked: summary.actualExecutionBlocked !== false,
    fatal: compact.fatal || [],
    hold: compact.hold || [],
    actualWriteExecuted: false
  };
}

function CC11_findActualApplyApproval_(masterSs) {
  var result = {
    ok: false,
    scopeOk: false,
    statusOk: false,
    actorOk: false,
    candidateCount: 0,
    approvedCount: 0,
    latest: null
  };
  if (!masterSs) return result;
  var sheet = masterSs.getSheetByName('ApprovalLog');
  if (!sheet) return result;
  var values = sheet.getDataRange().getValues();
  if (!values || values.length < 2) return result;
  var header = CC11_headerMap_(values[0]);
  for (var r = 1; r < values.length; r++) {
    var row = values[r];
    var approvalType = CC11_cell_(row, header, 'approvalType');
    var approvalScope = CC11_cell_(row, header, 'approvalScope');
    var approvalStatus = CC11_cell_(row, header, 'approvalStatus');
    var status = CC11_cell_(row, header, 'status');
    var relatedBuild = CC11_cell_(row, header, 'relatedBuild') || CC11_cell_(row, header, 'buildNo');
    var targetAction = CC11_cell_(row, header, 'targetAction');
    var approvedBy = CC11_cell_(row, header, 'approvedBy') || CC11_cell_(row, header, 'approvedByEmail');
    var approvedAt = CC11_cell_(row, header, 'approvedAt');
    var typeMatch = approvalType === CC11_TARGET.requiredApprovalType || targetAction === CC11_TARGET.requiredTargetAction;
    var buildMatch = relatedBuild === CC11_TARGET.buildNo;
    if (!typeMatch || !buildMatch) continue;
    result.candidateCount++;
    var scopeOk = approvalScope === CC11_TARGET.requiredApprovalScope;
    var statusOk = approvalStatus === 'APPROVED' && (!status || status === 'APPROVED');
    var actorOk = !!approvedBy && !!approvedAt;
    if (scopeOk && statusOk && actorOk) {
      result.approvedCount++;
      result.ok = true;
      result.scopeOk = true;
      result.statusOk = true;
      result.actorOk = true;
      result.latest = {
        approvalId: CC11_cell_(row, header, 'approvalId'),
        approvalType: approvalType,
        approvalScope: approvalScope,
        approvalStatus: approvalStatus,
        approvedBy: approvedBy,
        approvedAt: approvedAt,
        targetAction: targetAction,
        relatedBuild: relatedBuild,
        status: status
      };
    }
  }
  return result;
}

function CC11_headerMap_(headers) {
  var map = {};
  for (var i = 0; i < headers.length; i++) {
    var key = String(headers[i] || '').trim();
    if (key) map[key] = i;
  }
  return map;
}

function CC11_cell_(row, header, key) {
  if (!header || typeof header[key] === 'undefined') return '';
  var value = row[header[key]];
  if (value instanceof Date) {
    return Utilities.formatDate(value, 'Asia/Seoul', "yyyy-MM-dd'T'HH:mm:ssXXX");
  }
  return String(value || '').trim();
}

function CC11_checkOperationBlock_() {
  return {
    actualExecutionBlocked: true,
    actualBackupAllowed: false,
    actualDeployAllowed: false,
    actualRecoveryAllowed: false,
    actualRollbackAllowed: false,
    actualPortalSaveAllowed: false,
    actualErpApplyAllowed: false,
    actualFieldOpenAllowed: false,
    sheetWriteExecuted: false,
    sheetCreateExecuted: false,
    headerAutoAddExecuted: false,
    approvalWriteExecuted: false,
    auditLogWriteExecuted: false,
    backupExecuted: false,
    deployExecuted: false,
    recoveryExecuted: false,
    rollbackExecuted: false,
    erpApplyExecuted: false,
    actualOpenExecuted: false,
    productionDataMutationExecuted: false
  };
}

function CC11_emptySchema_() {
  return {
    ok: true,
    missingSheets: [],
    totalMissingHeaders: 0,
    sheets: [],
    actualCreateBlocked: true,
    actualHeaderAddBlocked: true,
    actualWriteBlocked: true
  };
}

function CC11_result_(summary, fatal, warnings, hold, details) {
  var judgement = 'BLOCK';
  if (fatal.length === 0 && hold.length === 0 && summary.actualApplyReadinessOk === true) judgement = 'PASS';
  else if (fatal.length === 0) judgement = 'HOLD';
  summary.ok = fatal.length === 0;
  summary.judgement = judgement;
  summary.diagnosticOnly = true;
  summary.dryRunOnly = true;
  summary.actualExecutionBlocked = true;
  summary.actualDeployAllowed = false;
  summary.actualPortalSaveAllowed = false;
  summary.actualErpApplyAllowed = false;
  summary.actualFieldOpenAllowed = false;
  summary.sheetWriteExecuted = false;
  summary.sheetCreateExecuted = false;
  summary.headerAutoAddExecuted = false;
  summary.approvalWriteExecuted = false;
  summary.auditLogWriteExecuted = false;
  summary.backupExecuted = false;
  summary.deployExecuted = false;
  summary.recoveryExecuted = false;
  summary.rollbackExecuted = false;
  summary.erpApplyExecuted = false;
  summary.actualOpenExecuted = false;
  summary.productionDataMutationExecuted = false;
  return {
    ok: fatal.length === 0,
    build: CC11_BUILD,
    mode: CC11_MODE,
    checkedAt: details.checkedAt || ((typeof CC_now_ === 'function') ? CC_now_() : new Date().toISOString()),
    judgement: judgement,
    targetBaseline: CC11_TARGET,
    summary: summary,
    details: details,
    warnings: warnings,
    hold: hold,
    fatal: fatal,
    nextAction: CC11_nextAction_(judgement)
  };
}

function CC11_nextAction_(judgement) {
  if (judgement === 'PASS') {
    return 'PORTAL_EVENT_B50 actual apply approval gate PASS. Next gate may prepare real apply execution, but this gate executed no production change.';
  }
  if (judgement === 'HOLD') {
    return 'PORTAL_EVENT_B50 actual apply approval gate HOLD. Add actual apply approval evidence in ApprovalLog and rerun.';
  }
  return 'PORTAL_EVENT_B50 actual apply approval gate BLOCK. Fix SystemConfig/MASTER/schema or safety block issue first.';
}
