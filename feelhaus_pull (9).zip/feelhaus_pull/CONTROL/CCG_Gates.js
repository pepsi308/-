/** CONTROL CENTER B06J41 761_940 - Approval gates */
function ccgApprovalTemplate_(scope) {
  return {
    approvalId: 'APR-CONTROL-' + scope + '-YYYYMMDD-001',
    approvalStatus: 'APPROVED',
    approvalType: 'CONTROL_EXECUTION',
    approvalScope: scope,
    projectCode: 'CONTROL',
    controlProjectCode: 'CONTROL',
    approvedBy: Session.getActiveUser().getEmail() || 'unknown',
    approvedAt: Utilities.formatDate(new Date(), Session.getScriptTimeZone() || 'Asia/Seoul', "yyyy-MM-dd'T'HH:mm:ssXXX"),
    actualBackupRequested: scope === 'ACTUAL_BACKUP',
    actualDeployRequested: scope === 'ACTUAL_DEPLOY',
    actualRollbackRequested: scope === 'ACTUAL_ROLLBACK',
    actualBackupConfirm: false,
    actualDeployConfirm: false,
    actualRollbackConfirm: false,
    reason: 'CONTROL approval gate template only'
  };
}

function ccgValidateExecutionGate_(approval, executionType) {
  const a = approval || {};
  const reasons = [];
  const expectedScope = executionType === 'BACKUP' ? 'ACTUAL_BACKUP' : executionType === 'DEPLOY' ? 'ACTUAL_DEPLOY' : 'ACTUAL_ROLLBACK';
  const requestedKey = executionType === 'BACKUP' ? 'actualBackupRequested' : executionType === 'DEPLOY' ? 'actualDeployRequested' : 'actualRollbackRequested';
  const confirmKey = executionType === 'BACKUP' ? 'actualBackupConfirm' : executionType === 'DEPLOY' ? 'actualDeployConfirm' : 'actualRollbackConfirm';
  const globalFlagOff = executionType === 'BACKUP' ? 'GLOBAL_ACTUAL_BACKUP_FLAG_OFF' : executionType === 'DEPLOY' ? 'GLOBAL_ACTUAL_DEPLOY_FLAG_OFF' : 'GLOBAL_ACTUAL_ROLLBACK_FLAG_OFF';

  if (!a.approvalId) reasons.push('MISSING_APPROVAL_ID');
  if (!a.approvedBy) reasons.push('MISSING_APPROVED_BY');
  if (!a.approvedAt) reasons.push('MISSING_APPROVED_AT');
  if (a.approvalStatus !== 'APPROVED') reasons.push('APPROVAL_STATUS_NOT_APPROVED');
  if (a.approvalType !== 'CONTROL_EXECUTION') reasons.push('INVALID_APPROVAL_TYPE');
  if (a.approvalScope !== expectedScope) reasons.push('INVALID_APPROVAL_SCOPE');
  if (a.projectCode !== 'CONTROL') reasons.push('INVALID_PROJECT_CODE');
  if (a.controlProjectCode !== 'CONTROL') reasons.push('INVALID_CONTROL_PROJECT_CODE');
  if (a[requestedKey] !== true) reasons.push('NO_ACTUAL_' + executionType + '_REQUEST');
  if (a[confirmKey] !== true) reasons.push('NO_ACTUAL_' + executionType + '_CONFIRM');
  reasons.push('DEPLOY_STILL_BLOCKED');
  reasons.push(globalFlagOff);

  const onlyGlobalBlocks = reasons.length === 2 && reasons.indexOf('DEPLOY_STILL_BLOCKED') >= 0 && reasons.indexOf(globalFlagOff) >= 0;
  return {
    ok: false,
    blocked: true,
    executionType,
    blockReasons: reasons,
    gateWouldAllowIfGlobalFlagsEnabled: onlyGlobalBlocks,
    actualExecutionAllowed: false,
    message: '승인 게이트 차단: ' + reasons.join(', ')
  };
}

function checkControlCenterB06J41_761_940_Gates() {
  const invalid = {};
  const validShape = {};
  ['BACKUP','DEPLOY','ROLLBACK'].forEach(function(t) {
    invalid[t] = ccgValidateExecutionGate_({}, t);
    const scope = t === 'BACKUP' ? 'ACTUAL_BACKUP' : t === 'DEPLOY' ? 'ACTUAL_DEPLOY' : 'ACTUAL_ROLLBACK';
    const tpl = ccgApprovalTemplate_(scope);
    tpl.actualBackupConfirm = t === 'BACKUP';
    tpl.actualDeployConfirm = t === 'DEPLOY';
    tpl.actualRollbackConfirm = t === 'ROLLBACK';
    validShape[t] = ccgValidateExecutionGate_(tpl, t);
  });
  return {
    ok: true,
    build: CONTROL_GUARD_BUNDLE_BUILD,
    invalidGateBlocked: Object.keys(invalid).every(function(k){ return invalid[k].blocked; }),
    validShapeGateBlocked: Object.keys(validShape).every(function(k){ return validShape[k].blocked; }),
    gateWouldAllowIfGlobalFlagsEnabled: Object.keys(validShape).every(function(k){ return validShape[k].gateWouldAllowIfGlobalFlagsEnabled; }),
    invalid,
    validShape,
    actualExecutionAllowed: false,
    safety: ccgSafety_()
  };
}
