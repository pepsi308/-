/**
 * FEELHAUS CONTROL CENTER - FULL SAFE BASELINE
 * Build: CONTROL_CENTER_B06J41_FULL_REPLACE_SAFE_BASELINE
 * Upload target: CONTROL CENTER Apps Script project
 *
 * This project is intentionally SAFE by default:
 * - no sheet creation
 * - no header mutation
 * - no log writing
 * - no backup/deploy/rollback execution
 */

function doGet(e) {
  var t = HtmlService.createTemplateFromFile('Index');
  t.buildInfo = CC_getBuildInfo_();
  return t.evaluate()
    .setTitle('FEELHAUS CONTROL CENTER')
    .setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL);
}

function include(filename) {
  return HtmlService.createHtmlOutputFromFile(filename).getContent();
}

function onOpen() {
  SpreadsheetApp.getUi()
    .createMenu('FEELHAUS CONTROL')
    .addItem('CONTROL 01 설정/DB 점검', 'control01SmokeTest')
    .addItem('CONTROL 02 권한/감사/상태 점검', 'control02SmokeTest')
    .addItem('CONTROL 03 백업/배포/복구 게이트', 'control03SmokeTest')
    .addItem('로그 구조 보정 패치 V01', 'controlLogSchemaRepairPatchV01')
    .addItem('PORTAL 행사관리 B50 배포 전 진단', 'controlPortalEventB50PreDeployGateV01')
    .addItem('PORTAL 행사관리 B50 백업/롤백 증빙 진단', 'controlPortalEventB50BackupRollbackEvidenceV01')
    .addItem('PORTAL 행사관리 B50 승인 게이트', 'controlPortalEventB50ApprovalGateV01')
    .addItem('PORTAL 행사관리 B50 배포 허용 최종 게이트', 'controlPortalEventB50DeployAllowedGateV01')
    .addItem('전체 Safe 점검', 'testControlCenterFullB06J41_All')
    .addItem('Smoke 점검', 'testControlCenterFullB06J41_Smoke')
    .addSeparator()
    .addItem('PORTAL ERP SIGN 점검', 'testControlPortalErpSignB06J41_001_100_All')
    .addItem('PORTAL SIGN 점검', 'testControlPortalSignB06J41_651_700_All')
    .addItem('SIGN 점검', 'testControlSignB06J41_431_470_All')
    .addToUi();
}

function getControlCenterDashboardData() {
  return testControlCenterFullB06J41_All();
}
