/**
 * FEELHAUS CONTROL - GROUPWARE B90 POST APPLY VERIFY LOCK GATE
 * Build: CONTROL_GROUPWARE_B90_POST_APPLY_VERIFY_LOCK_V01
 * Progress: [10/10] 100%
 * Target baseline: GROUPWARE_B90_FINAL_STABLE_AFTER_B70_B90_RUNALL
 * Execution function: runControlGroupwareB90PostApplyVerifyLockGateV01
 *
 * Safety:
 * - Diagnostic only
 * - Sheet read only
 * - No sheet creation
 * - No header mutation
 * - No approval writing
 * - No audit log writing
 * - No backup/deploy/recovery/rollback execution
 * - No GROUPWARE production save
 * - No field use open execution
 * - No real apply execution
 */
var CC23_BUILD = 'CONTROL_GROUPWARE_B90_POST_APPLY_VERIFY_LOCK_V01';
var CC23_MODE = 'GROUPWARE_B90_POST_APPLY_VERIFY_LOCK_DIAGNOSTIC_ONLY_NO_UPDATE';
var CC23_PROGRESS = { current: 10, total: 10, percent: 100 };
var CC23_SETUP_DB_ID = '17VMSpgSZCvIrUlgcw8yCNcnl8WQWo2IcRf5tDCcuJGM';
var CC23_CONFIG_SHEET_NAME = 'SystemConfig';
var CC23_SOURCE_DB = 'FEELHAUS_SETUP_DB';
var CC23_TARGET = {
  projectCode: 'GROUPWARE',
  moduleCode: 'GROUPWARE_PORTAL_HR_MAIL_CALENDAR',
  buildRange: 'B70~B90',
  currentBuildNo: 'B90',
  finalBuildNo: 'B90',
  buildProgress: '90 / 90',
  progressPercent: 100,
  runAllStatus: 'GROUPWARE_B70_TO_B90_RUNALL_PASS',
  protectedBaseline: 'B70~B89',
  finalStableName: 'GROUPWARE_B90_FINAL_STABLE',
  actualOperationExecutionGateBuild: 'CONTROL_GROUPWARE_B90_ACTUAL_OPERATION_EXECUTION_V01',
  finalVerifyLockBuild: 'CONTROL_GROUPWARE_B90_POST_APPLY_VERIFY_LOCK_V01'
};

function runControlGroupwareB90PostApplyVerifyLockGateV01() {
  var result = diagnoseControlGroupwareB90PostApplyVerifyLockGateV01_();
  CC23_logCompactResult_(result);
  return result;
}

function runGroupwareB90PostApplyVerifyLockGateV01() {
  var result = diagnoseControlGroupwareB90PostApplyVerifyLockGateV01_();
  CC23_logCompactResult_(result);
  return result;
}

function getControlGroupwareB90PostApplyVerifyLockGateData() {
  var result = diagnoseControlGroupwareB90PostApplyVerifyLockGateV01_();
  CC23_logCompactResult_(result);
  return result;
}

function controlGroupwareB90PostApplyVerifyLockGateV01() {
  var result = diagnoseControlGroupwareB90PostApplyVerifyLockGateV01_();
  CC23_logCompactResult_(result);
  return result;
}

function diagnoseControlGroupwareB90PostApplyVerifyLockGateV01_() {
  var started = new Date();
  var fatal = [];
  var hold = [];
  var warnings = [];
  var summary = CC23_defaultSummary_();
  var evidence = {};
  var config = {};
  var master = { ok: false };

  try {
    var setup = CC23_readSystemConfig_();
    config = setup.config || {};
    summary.configOk = setup.ok === true;
    summary.systemConfigAutoReadOk = setup.ok === true;
    evidence.setupDbName = setup.setupDbName || '';
  } catch (e1) {
    fatal.push('SystemConfig 자동 읽기 실패: ' + CC23_errorMessage_(e1));
  }

  try {
    master = CC23_openMasterDb_(config);
    summary.masterOk = master.ok === true;
    summary.masterConnectedOk = master.ok === true;
    evidence.masterDbIdMasked = CC23_maskId_(master.masterDbId || '');
    evidence.masterDbName = master.masterDbName || '';
  } catch (e2) {
    fatal.push('FEELHAUS_DB_MASTER 연결 실패: ' + CC23_errorMessage_(e2));
  }

  evidence.actualOperationExecutionGate = CC23_checkActualOperationExecutionGate_();
  summary.actualOperationExecutionGatePassed = evidence.actualOperationExecutionGate.passed === true;
  summary.actualOperationExecutionGateOk = evidence.actualOperationExecutionGate.actualOperationExecutionGateOk === true;
  summary.actualOperationExecutionDryRunOk = evidence.actualOperationExecutionGate.actualOperationExecutionDryRunOk === true;
  summary.actualExecutionReadyGatePassed = evidence.actualOperationExecutionGate.actualExecutionReadyGatePassed === true;
  summary.actualExecutionReadyOk = evidence.actualOperationExecutionGate.actualExecutionReadyOk === true;
  summary.executionFilesReadyOk = evidence.actualOperationExecutionGate.executionFilesReadyOk === true;
  summary.backupEvidenceFileOk = evidence.actualOperationExecutionGate.backupEvidenceFileOk === true;
  summary.rollbackBaselineFileOk = evidence.actualOperationExecutionGate.rollbackBaselineFileOk === true;

  summary.postApplyVerifyOk = summary.actualOperationExecutionGatePassed && summary.actualOperationExecutionGateOk;
  summary.finalLockReadyOk = summary.postApplyVerifyOk && summary.executionFilesReadyOk;
  summary.groupwareB90FinalStableLockedCandidate = summary.finalLockReadyOk;
  summary.productionSaveAllowed = false;
  summary.fieldUseOpenAllowed = false;
  summary.deployAllowed = false;
  summary.realApplyAllowed = false;
  summary.actualExecutionBlocked = true;
  summary.actualBackupAllowed = false;
  summary.actualDeployAllowed = false;
  summary.actualRecoveryAllowed = false;
  summary.actualRollbackAllowed = false;
  summary.actualFieldUseOpenAllowed = false;
  summary.actualRealApplyAllowed = false;
  summary.diagnosticOnly = true;
  summary.dryRunOnly = true;

  if (!summary.actualOperationExecutionGatePassed) hold.push('[09/10] CONTROL_GROUPWARE_B90_ACTUAL_OPERATION_EXECUTION_V01 PASS 확인 필요');
  if (!summary.actualOperationExecutionGateOk) hold.push('[09/10] actual operation execution gate PASS 확인 필요');
  if (!summary.actualOperationExecutionDryRunOk) hold.push('[09/10] actual operation execution dry-run PASS 확인 필요');
  if (!summary.executionFilesReadyOk) hold.push('백업/롤백 증빙 파일 재확인 필요');
  if (!summary.finalLockReadyOk) hold.push('GROUPWARE B90 최종 검증/잠금 후보 조건 미충족');

  var passConditions = [
    summary.configOk,
    summary.masterOk,
    summary.actualOperationExecutionGatePassed,
    summary.actualOperationExecutionGateOk,
    summary.actualOperationExecutionDryRunOk,
    summary.actualExecutionReadyGatePassed,
    summary.actualExecutionReadyOk,
    summary.executionFilesReadyOk,
    summary.backupEvidenceFileOk,
    summary.rollbackBaselineFileOk,
    summary.postApplyVerifyOk,
    summary.finalLockReadyOk,
    summary.actualExecutionBlocked,
    summary.actualBackupAllowed === false,
    summary.actualDeployAllowed === false,
    summary.actualRecoveryAllowed === false,
    summary.actualRollbackAllowed === false,
    summary.actualFieldUseOpenAllowed === false,
    summary.actualRealApplyAllowed === false,
    summary.productionSaveAllowed === false,
    summary.fieldUseOpenAllowed === false,
    summary.deployAllowed === false,
    summary.realApplyAllowed === false
  ];

  var allPass = fatal.length === 0 && hold.length === 0 && CC23_allTrue_(passConditions);
  var judgement = fatal.length > 0 ? 'BLOCK' : (allPass ? 'PASS' : 'HOLD');
  summary.postApplyVerifyLockGateOk = judgement === 'PASS';
  summary.finalStabilizationComplete = judgement === 'PASS';
  summary.fieldUseOpenCandidateOnly = judgement === 'PASS';
  summary.judgement = judgement;

  return {
    ok: judgement === 'PASS',
    build: CC23_BUILD,
    progress: CC23_PROGRESS,
    mode: CC23_MODE,
    checkedAt: CC23_now_(),
    judgement: judgement,
    targetBaseline: CC23_TARGET,
    summary: summary,
    evidence: {
      setupDbId: CC23_SETUP_DB_ID,
      configSheetName: CC23_CONFIG_SHEET_NAME,
      sourceDb: CC23_SOURCE_DB,
      setupDbName: evidence.setupDbName || '',
      masterDbIdMasked: evidence.masterDbIdMasked || '',
      masterDbName: evidence.masterDbName || '',
      actualOperationExecutionGate: evidence.actualOperationExecutionGate || {},
      finalVerifyReason: judgement === 'PASS' ? '[10/10] Post-apply verify and lock gate PASS. GROUPWARE B90 final stabilization is verified as a read-only/safety-locked candidate. This gate executed no production change.' : '',
      actualBackupAllowed: false,
      actualDeployAllowed: false,
      actualRecoveryAllowed: false,
      actualRollbackAllowed: false,
      actualProductionSaveAllowed: false,
      actualFieldUseOpenAllowed: false,
      actualRealApplyAllowed: false,
      operationBlock: CC23_operationBlock_(),
      elapsedMs: new Date().getTime() - started.getTime()
    },
    warnings: warnings,
    hold: hold,
    fatal: fatal,
    nextAction: judgement === 'PASS'
      ? '[10/10] GROUPWARE B90 post-apply verify and lock gate PASS. CONTROL pipeline completed. This gate executed no production change.'
      : '[10/10] GROUPWARE B90 post-apply verify and lock gate is not PASS. Resolve hold items, then rerun.'
  };
}

function CC23_defaultSummary_() {
  return {
    baselineOk: true,
    configOk: false,
    masterOk: false,
    systemConfigAutoReadOk: false,
    masterConnectedOk: false,
    actualOperationExecutionGatePassed: false,
    actualOperationExecutionGateOk: false,
    actualOperationExecutionDryRunOk: false,
    actualExecutionReadyGatePassed: false,
    actualExecutionReadyOk: false,
    executionFilesReadyOk: false,
    backupEvidenceFileOk: false,
    rollbackBaselineFileOk: false,
    postApplyVerifyOk: false,
    finalLockReadyOk: false,
    postApplyVerifyLockGateOk: false,
    groupwareB90FinalStableLockedCandidate: false,
    finalStabilizationComplete: false,
    fieldUseOpenCandidateOnly: false,
    productionSaveAllowed: false,
    fieldUseOpenAllowed: false,
    deployAllowed: false,
    realApplyAllowed: false,
    actualExecutionBlocked: true,
    actualBackupAllowed: false,
    actualDeployAllowed: false,
    actualRecoveryAllowed: false,
    actualRollbackAllowed: false,
    actualFieldUseOpenAllowed: false,
    actualRealApplyAllowed: false,
    diagnosticOnly: true,
    dryRunOnly: true,
    sheetWriteExecuted: false,
    sheetCreateExecuted: false,
    headerAutoAddExecuted: false,
    approvalWriteExecuted: false,
    auditLogWriteExecuted: false,
    backupExecuted: false,
    deployExecuted: false,
    recoveryExecuted: false,
    rollbackExecuted: false,
    realApplyExecuted: false,
    productionDataMutationExecuted: false,
    judgement: 'HOLD'
  };
}

function CC23_checkActualOperationExecutionGate_() {
  var result = { checked: false, available: false, passed: false };
  try {
    if (typeof runControlGroupwareB90ActualOperationExecutionGateV01 !== 'function') {
      result.error = 'runControlGroupwareB90ActualOperationExecutionGateV01 함수 없음';
      return result;
    }
    var r = runControlGroupwareB90ActualOperationExecutionGateV01();
    result.checked = true;
    result.available = true;
    result.passed = r && r.judgement === 'PASS';
    result.build = r && r.build || '';
    result.judgement = r && r.judgement || '';
    result.actualOperationExecutionGateOk = r && r.summary && r.summary.actualOperationExecutionGateOk === true;
    result.actualOperationExecutionDryRunOk = r && r.summary && r.summary.actualOperationExecutionDryRunOk === true;
    result.actualExecutionReadyGatePassed = r && r.summary && r.summary.actualExecutionReadyGatePassed === true;
    result.actualExecutionReadyOk = r && r.summary && r.summary.actualExecutionReadyOk === true;
    result.executionFilesReadyOk = r && r.summary && r.summary.executionFilesReadyOk === true;
    result.backupEvidenceFileOk = r && r.summary && r.summary.backupEvidenceFileOk === true;
    result.rollbackBaselineFileOk = r && r.summary && r.summary.rollbackBaselineFileOk === true;
    result.latestBackupEvidenceFile = r && r.evidence && r.evidence.actualExecutionReadyGate && r.evidence.actualExecutionReadyGate.latestBackupEvidenceFile || null;
    result.latestRollbackBaselineFile = r && r.evidence && r.evidence.actualExecutionReadyGate && r.evidence.actualExecutionReadyGate.latestRollbackBaselineFile || null;
  } catch (e) {
    result.checked = true;
    result.available = false;
    result.error = CC23_errorMessage_(e);
  }
  return result;
}

function CC23_readSystemConfig_() {
  var ss = SpreadsheetApp.openById(CC23_SETUP_DB_ID);
  var sh = ss.getSheetByName(CC23_CONFIG_SHEET_NAME);
  if (!sh) throw new Error('SystemConfig 시트 없음');
  var values = sh.getDataRange().getValues();
  if (!values || values.length < 2) throw new Error('SystemConfig 데이터 없음');
  var headers = values[0].map(function(h){ return String(h || '').trim(); });
  var map = CC23_headerMap_(headers);
  var keyIdx = CC23_pickIndex_(map, ['configKey','key','id','name','code']);
  var valIdx = CC23_pickIndex_(map, ['configValue','value','val']);
  if (keyIdx < 0) keyIdx = 0;
  if (valIdx < 0) valIdx = 1;
  var config = {};
  for (var r = 1; r < values.length; r++) {
    var k = String(values[r][keyIdx] || '').trim();
    if (!k) continue;
    config[k] = values[r][valIdx];
  }
  return { ok: true, config: config, setupDbName: ss.getName() };
}

function CC23_openMasterDb_(config) {
  var masterDbId = String(config.MASTER_DB_ID || config.FEELHAUS_DB_MASTER_ID || config.MASTER_SPREADSHEET_ID || '').trim();
  if (!masterDbId) {
    var masterDbName = String(config.MASTER_DB || config.MASTER_DB_NAME || 'FEELHAUS_DB_MASTER').trim();
    var files = DriveApp.getFilesByName(masterDbName);
    if (files.hasNext()) masterDbId = files.next().getId();
  }
  if (!masterDbId) throw new Error('FEELHAUS_DB_MASTER ID 확인 실패');
  var ss = SpreadsheetApp.openById(masterDbId);
  return { ok: true, masterDbId: masterDbId, masterDbName: ss.getName() };
}

function CC23_headerMap_(headers) {
  var map = {};
  for (var i = 0; i < headers.length; i++) map[String(headers[i] || '').trim()] = i;
  return map;
}

function CC23_pickIndex_(map, keys) {
  for (var i = 0; i < keys.length; i++) {
    if (Object.prototype.hasOwnProperty.call(map, keys[i])) return map[keys[i]];
  }
  return -1;
}

function CC23_operationBlock_() {
  return {
    productionSaveAllowed: false,
    fieldUseOpenAllowed: false,
    deployAllowed: false,
    realApplyAllowed: false,
    actualExecutionBlocked: true,
    actualBackupAllowed: false,
    actualDeployAllowed: false,
    actualRecoveryAllowed: false,
    actualRollbackAllowed: false,
    actualFieldUseOpenAllowed: false,
    actualRealApplyAllowed: false,
    sheetWriteExecuted: false,
    sheetCreateExecuted: false,
    headerAutoAddExecuted: false,
    approvalWriteExecuted: false,
    auditLogWriteExecuted: false,
    backupExecuted: false,
    deployExecuted: false,
    recoveryExecuted: false,
    rollbackExecuted: false,
    realApplyExecuted: false,
    productionDataMutationExecuted: false
  };
}

function CC23_logCompactResult_(result) {
  Logger.log('JSON_COMPACT_RESULT: ' + JSON.stringify(result));
}

function CC23_allTrue_(arr) {
  for (var i = 0; i < arr.length; i++) if (arr[i] !== true) return false;
  return true;
}

function CC23_now_() {
  return CC23_formatDate_(new Date());
}

function CC23_formatDate_(d) {
  return Utilities.formatDate(d, 'Asia/Seoul', "yyyy-MM-dd'T'HH:mm:ssXXX");
}

function CC23_maskId_(id) {
  id = String(id || '');
  if (id.length <= 8) return id ? '***' : '';
  return id.substring(0, 4) + '***' + id.substring(id.length - 4);
}

function CC23_errorMessage_(e) {
  return e && e.message ? e.message : String(e);
}
