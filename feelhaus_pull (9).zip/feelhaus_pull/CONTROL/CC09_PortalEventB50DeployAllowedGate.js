/**
 * FEELHAUS CONTROL - PORTAL EVENT B50 DEPLOY ALLOWED GATE
 * Build: CONTROL_PORTAL_EVENT_B50_DEPLOY_ALLOWED_GATE_V01
 * Target baseline: PORTAL_EVENT_B50_FINAL_STABLE_READONLY_20260611
 * Execution function: runControlPortalEventB50DeployAllowedGateV01
 *
 * Safety:
 * - Diagnostic only
 * - No sheet creation
 * - No header mutation
 * - No log writing
 * - No approval writing
 * - No backup/deploy/recovery/rollback execution
 * - No PORTAL/ERP/field open mutation
 */
var CC09_BUILD = 'CONTROL_PORTAL_EVENT_B50_DEPLOY_ALLOWED_GATE_V01';
var CC09_MODE = 'PORTAL_EVENT_B50_DEPLOY_ALLOWED_DIAGNOSTIC_ONLY_NO_UPDATE';
var CC09_TARGET = {
  projectCode: 'PORTAL_EVENT',
  moduleCode: 'PORTAL_EVENT_MANAGEMENT',
  buildNo: 'PORTAL_EVENT_B50_FINAL_STABLE_READONLY_20260611',
  buildProgress: '50 / 50',
  progressPercent: 100,
  runFunction: 'portalEventB50RunAll',
  changedOnlyFile: 'PORTAL_EVENT_B50_CHANGED_ONLY.zip',
  requiredPreDeployBuild: 'CONTROL_PORTAL_EVENT_B50_PREDEPLOY_GATE_EVIDENCE_SYNC_PATCH_V01',
  requiredApprovalBuild: 'CONTROL_PORTAL_EVENT_B50_APPROVAL_GATE_V01',
  actualExecutionForbiddenInThisGate: true
};

function runControlPortalEventB50DeployAllowedGateV01() {
  var result = diagnoseControlPortalEventB50DeployAllowedGateV01_();
  CC09_logCompactResult_(result);
  return result;
}

function getControlPortalEventB50DeployAllowedGateData() {
  var result = diagnoseControlPortalEventB50DeployAllowedGateV01_();
  CC09_logCompactResult_(result);
  return result;
}

function controlPortalEventB50DeployAllowedGateV01() {
  var result = diagnoseControlPortalEventB50DeployAllowedGateV01_();
  CC09_logCompactResult_(result);
  return result;
}

function CC09_logCompactResult_(result) {
  Logger.log('JSON_COMPACT_RESULT: ' + JSON.stringify(CC09_compactResult_(result)));
}

function CC09_compactResult_(result) {
  result = result || {};
  var summary = result.summary || {};
  var details = result.details || {};
  var schema = details.schema || {};
  var preDeploy = details.preDeployGate || {};
  var approvalGate = details.approvalGate || {};
  var approval = details.approvalEvidence || {};
  var operationBlock = details.operationBlock || {};
  return {
    ok: result.ok === true,
    build: result.build || CC09_BUILD,
    mode: result.mode || CC09_MODE,
    checkedAt: result.checkedAt || '',
    judgement: result.judgement || summary.judgement || 'BLOCK',
    targetBaseline: {
      projectCode: CC09_TARGET.projectCode,
      moduleCode: CC09_TARGET.moduleCode,
      buildNo: CC09_TARGET.buildNo,
      buildProgress: CC09_TARGET.buildProgress,
      progressPercent: CC09_TARGET.progressPercent,
      runFunction: CC09_TARGET.runFunction,
      changedOnlyFile: CC09_TARGET.changedOnlyFile
    },
    summary: {
      baselineOk: summary.baselineOk === true,
      configOk: summary.configOk === true,
      masterOk: summary.masterOk === true,
      requiredGateSheetsOk: summary.requiredGateSheetsOk === true,
      requiredGateHeadersOk: summary.requiredGateHeadersOk === true,
      preDeployGatePassed: summary.preDeployGatePassed === true,
      backupEvidenceOk: summary.backupEvidenceOk === true,
      rollbackEvidenceOk: summary.rollbackEvidenceOk === true,
      approvalGatePassed: summary.approvalGatePassed === true,
      approvalEvidenceOk: summary.approvalEvidenceOk === true,
      approvalScopeOk: summary.approvalScopeOk === true,
      approvalStatusOk: summary.approvalStatusOk === true,
      approvalActorOk: summary.approvalActorOk === true,
      deployReadinessOk: summary.deployReadinessOk === true,
      deployAllowed: summary.deployAllowed === true,
      actualExecutionBlocked: summary.actualExecutionBlocked !== false,
      actualDeployAllowed: summary.actualDeployAllowed === true,
      operationSaveBlocked: summary.operationSaveBlocked !== false,
      erpApplyBlocked: summary.erpApplyBlocked !== false,
      fieldOpenBlocked: summary.fieldOpenBlocked !== false,
      diagnosticOnly: summary.diagnosticOnly === true,
      dryRunOnly: summary.dryRunOnly === true,
      sheetWriteExecuted: summary.sheetWriteExecuted === true,
      sheetCreateExecuted: summary.sheetCreateExecuted === true,
      headerAutoAddExecuted: summary.headerAutoAddExecuted === true,
      approvalWriteExecuted: summary.approvalWriteExecuted === true,
      auditLogWriteExecuted: summary.auditLogWriteExecuted === true,
      backupExecuted: summary.backupExecuted === true,
      deployExecuted: summary.deployExecuted === true,
      recoveryExecuted: summary.recoveryExecuted === true,
      rollbackExecuted: summary.rollbackExecuted === true,
      erpApplyExecuted: summary.erpApplyExecuted === true,
      actualOpenExecuted: summary.actualOpenExecuted === true,
      productionDataMutationExecuted: summary.productionDataMutationExecuted === true
    },
    evidence: {
      missingSheets: schema.missingSheets || [],
      totalMissingHeaders: schema.totalMissingHeaders || 0,
      preDeployBuild: preDeploy.build || '',
      preDeployJudgement: preDeploy.judgement || '',
      preDeployBackupEvidenceOk: preDeploy.preDeployBackupEvidenceOk === true,
      preDeployRollbackEvidenceOk: preDeploy.rollbackBaselineEvidenceOk === true,
      approvalGateBuild: approvalGate.build || '',
      approvalGateJudgement: approvalGate.judgement || '',
      approvedPortalEventB50Count: approval.approvedPortalEventB50Count || 0,
      approvalCandidateCount: approval.approvalCandidateCount || 0,
      latestApprovalEvidence: approval.latestApprovalEvidence || null,
      readinessReason: details.readinessReason || '',
      actualBackupAllowed: operationBlock.actualBackupAllowed === true,
      actualDeployAllowed: operationBlock.actualDeployAllowed === true,
      actualRecoveryAllowed: operationBlock.actualRecoveryAllowed === true,
      actualRollbackAllowed: operationBlock.actualRollbackAllowed === true,
      actualPortalSaveAllowed: operationBlock.actualPortalSaveAllowed === true,
      actualErpApplyAllowed: operationBlock.actualErpApplyAllowed === true,
      actualFieldOpenAllowed: operationBlock.actualFieldOpenAllowed === true
    },
    warnings: result.warnings || [],
    hold: result.hold || [],
    fatal: result.fatal || [],
    nextAction: result.nextAction || ''
  };
}

function diagnoseControlPortalEventB50DeployAllowedGateV01_() {
  var fatal = [];
  var warnings = [];
  var hold = [];
  var details = {
    build: CC09_BUILD,
    mode: CC09_MODE,
    checkedAt: CC_now_(),
    sourceDb: CC_SOURCE_DB,
    setupDbId: CC_SETUP_DB_ID,
    configSheetName: CC_CONFIG_SHEET_NAME,
    targetBaseline: CC09_TARGET,
    safety: CC09_safety_(),
    config: null,
    master: null,
    schema: null,
    preDeployGate: null,
    approvalGate: null,
    approvalEvidence: null,
    operationBlock: null,
    readinessReason: ''
  };
  var summary = CC09_baseSummary_();

  try {
    var cfgResult = CC_readSystemConfig_();
    summary.configOk = !!(cfgResult && cfgResult.ok);
    details.config = {
      ok: summary.configOk,
      message: cfgResult && cfgResult.message ? cfgResult.message : '',
      sourceDb: CC_SOURCE_DB,
      setupDbId: CC_SETUP_DB_ID,
      configSheetName: CC_CONFIG_SHEET_NAME
    };
    if (!summary.configOk) fatal.push('SystemConfig 자동 읽기 실패');

    var config = cfgResult && cfgResult.config ? cfgResult.config : {};
    var masterId = CC_resolveMasterDbId_(config);
    if (!masterId) {
      summary.masterOk = false;
      fatal.push('FEELHAUS_DB_MASTER ID를 SystemConfig에서 찾지 못했습니다.');
      return CC09_result_(summary, fatal, warnings, hold, details);
    }
    var masterSs = SpreadsheetApp.openById(masterId);
    summary.masterOk = !!masterSs;
    details.master = {
      ok: summary.masterOk,
      masterDbId: masterId,
      masterDbName: masterSs ? masterSs.getName() : ''
    };
    if (!summary.masterOk) fatal.push('FEELHAUS_DB_MASTER 연결 실패');

    details.schema = (typeof CC08_checkApprovalSchemas_ === 'function') ? CC08_checkApprovalSchemas_(masterSs) : CC09_checkGateSchemas_(masterSs);
    summary.requiredGateSheetsOk = details.schema.ok && details.schema.missingSheets.length === 0;
    summary.requiredGateHeadersOk = details.schema.totalMissingHeaders === 0;
    if (!summary.requiredGateSheetsOk) fatal.push('배포 허용 게이트 필수 로그 시트 누락: ' + details.schema.missingSheets.join(', '));
    if (!summary.requiredGateHeadersOk) fatal.push('배포 허용 게이트 필수 헤더 누락 합계: ' + details.schema.totalMissingHeaders);

    details.preDeployGate = CC09_checkPreDeployGatePass_();
    summary.preDeployGatePassed = details.preDeployGate.ok === true;
    summary.backupEvidenceOk = details.preDeployGate.preDeployBackupEvidenceOk === true;
    summary.rollbackEvidenceOk = details.preDeployGate.rollbackBaselineEvidenceOk === true;
    if (!summary.preDeployGatePassed) hold.push('PORTAL_EVENT_B50 배포 전 최종 진단 PASS 결과가 확인되지 않았습니다.');
    if (!summary.backupEvidenceOk) hold.push('PORTAL_EVENT_B50 백업 증빙 PASS 결과가 확인되지 않았습니다.');
    if (!summary.rollbackEvidenceOk) hold.push('PORTAL_EVENT_B50 롤백 증빙 PASS 결과가 확인되지 않았습니다.');

    details.approvalGate = CC09_checkApprovalGatePass_();
    summary.approvalGatePassed = details.approvalGate.ok === true;
    summary.approvalEvidenceOk = details.approvalGate.approvalEvidenceOk === true;
    summary.approvalScopeOk = details.approvalGate.approvalScopeOk === true;
    summary.approvalStatusOk = details.approvalGate.approvalStatusOk === true;
    summary.approvalActorOk = details.approvalGate.approvalActorOk === true;
    details.approvalEvidence = details.approvalGate.approvalEvidence || {};
    if (!summary.approvalGatePassed) hold.push('PORTAL_EVENT_B50 CONTROL 승인 게이트 PASS 결과가 확인되지 않았습니다.');
    if (!summary.approvalEvidenceOk) hold.push('PORTAL_EVENT_B50 ApprovalLog 승인 증빙이 확인되지 않았습니다.');

    details.operationBlock = CC09_checkOperationBlock_();
    summary.actualExecutionBlocked = details.operationBlock.actualExecutionBlocked !== false;
    summary.actualDeployAllowed = details.operationBlock.actualDeployAllowed === true;
    summary.operationSaveBlocked = details.operationBlock.actualPortalSaveAllowed !== true;
    summary.erpApplyBlocked = details.operationBlock.actualErpApplyAllowed !== true;
    summary.fieldOpenBlocked = details.operationBlock.actualFieldOpenAllowed !== true;
    if (!summary.actualExecutionBlocked || summary.actualDeployAllowed) fatal.push('배포 허용 게이트에서 실제 배포 실행 차단 기준이 깨졌습니다.');

    summary.baselineOk = CC09_checkBaseline_().ok;
    if (!summary.baselineOk) fatal.push('PORTAL_EVENT_B50 기준선 값 불일치');

    summary.deployReadinessOk = fatal.length === 0 && hold.length === 0 &&
      summary.baselineOk && summary.configOk && summary.masterOk &&
      summary.requiredGateSheetsOk && summary.requiredGateHeadersOk &&
      summary.preDeployGatePassed && summary.backupEvidenceOk && summary.rollbackEvidenceOk &&
      summary.approvalGatePassed && summary.approvalEvidenceOk && summary.approvalScopeOk &&
      summary.approvalStatusOk && summary.approvalActorOk && summary.actualExecutionBlocked;
    summary.deployAllowed = summary.deployReadinessOk === true;
    details.readinessReason = summary.deployReadinessOk ?
      '진단 PASS + 백업/롤백 PASS + CONTROL 승인 PASS가 모두 확인되어 배포 허용 후보 상태입니다. 단, 이 게이트는 실제 배포를 실행하지 않습니다.' :
      '배포 허용 후보 조건 중 미충족 항목이 있어 HOLD 또는 BLOCK 상태입니다.';

    return CC09_result_(summary, fatal, warnings, hold, details);
  } catch (err) {
    fatal.push(String(err && err.message ? err.message : err));
    return CC09_result_(summary, fatal, warnings, hold, details);
  }
}

function CC09_baseSummary_() {
  return {
    ok: false,
    judgement: 'BLOCK',
    baselineOk: false,
    configOk: false,
    masterOk: false,
    requiredGateSheetsOk: false,
    requiredGateHeadersOk: false,
    preDeployGatePassed: false,
    backupEvidenceOk: false,
    rollbackEvidenceOk: false,
    approvalGatePassed: false,
    approvalEvidenceOk: false,
    approvalScopeOk: false,
    approvalStatusOk: false,
    approvalActorOk: false,
    deployReadinessOk: false,
    deployAllowed: false,
    actualExecutionBlocked: true,
    actualDeployAllowed: false,
    operationSaveBlocked: true,
    erpApplyBlocked: true,
    fieldOpenBlocked: true,
    diagnosticOnly: true,
    dryRunOnly: true,
    sheetWriteExecuted: false,
    sheetCreateExecuted: false,
    headerAutoAddExecuted: false,
    approvalWriteExecuted: false,
    auditLogWriteExecuted: false,
    backupExecuted: false,
    deployExecuted: false,
    recoveryExecuted: false,
    rollbackExecuted: false,
    erpApplyExecuted: false,
    actualOpenExecuted: false,
    productionDataMutationExecuted: false
  };
}

function CC09_safety_() {
  var s = (typeof CC_getSafety_ === 'function') ? CC_getSafety_() : {};
  s.diagnosticOnly = true;
  s.dryRunOnly = true;
  s.actualExecutionBlocked = true;
  s.noSheetWrite = true;
  s.noSheetCreate = true;
  s.noHeaderAutoAdd = true;
  s.noApprovalWrite = true;
  s.noAuditLogWrite = true;
  s.noBackupExecution = true;
  s.noDeployExecution = true;
  s.noRecoveryExecution = true;
  s.noRollbackExecution = true;
  s.noErpApply = true;
  s.noFieldOpenExecution = true;
  return s;
}

function CC09_checkBaseline_() {
  var b = CC09_TARGET;
  return {
    ok: b.projectCode === 'PORTAL_EVENT' &&
      b.moduleCode === 'PORTAL_EVENT_MANAGEMENT' &&
      b.buildNo === 'PORTAL_EVENT_B50_FINAL_STABLE_READONLY_20260611' &&
      b.progressPercent === 100 &&
      b.runFunction === 'portalEventB50RunAll' &&
      b.changedOnlyFile === 'PORTAL_EVENT_B50_CHANGED_ONLY.zip',
    targetBaseline: b,
    actualWriteExecuted: false
  };
}

function CC09_checkPreDeployGatePass_() {
  var compact = null;
  var full = null;
  if (typeof diagnoseControlPortalEventB50PreDeployGateV01_ === 'function') {
    full = diagnoseControlPortalEventB50PreDeployGateV01_();
    if (typeof CC06_compactResult_ === 'function') compact = CC06_compactResult_(full);
  }
  compact = compact || {};
  var summary = compact.summary || {};
  return {
    ok: compact.judgement === 'PASS' && summary.preDeployBackupEvidenceOk === true && summary.rollbackBaselineEvidenceOk === true,
    build: compact.build || '',
    judgement: compact.judgement || '',
    preDeployBackupEvidenceOk: summary.preDeployBackupEvidenceOk === true,
    rollbackBaselineEvidenceOk: summary.rollbackBaselineEvidenceOk === true,
    fatal: compact.fatal || [],
    hold: compact.hold || [],
    actualWriteExecuted: false
  };
}

function CC09_checkApprovalGatePass_() {
  var compact = null;
  var full = null;
  if (typeof diagnoseControlPortalEventB50ApprovalGateV01_ === 'function') {
    full = diagnoseControlPortalEventB50ApprovalGateV01_();
    if (typeof CC08_compactResult_ === 'function') compact = CC08_compactResult_(full);
  }
  compact = compact || {};
  var summary = compact.summary || {};
  var evidence = compact.evidence || {};
  return {
    ok: compact.judgement === 'PASS' && summary.approvalEvidenceOk === true && summary.approvalScopeOk === true && summary.approvalStatusOk === true && summary.approvalActorOk === true,
    build: compact.build || '',
    judgement: compact.judgement || '',
    approvalEvidenceOk: summary.approvalEvidenceOk === true,
    approvalScopeOk: summary.approvalScopeOk === true,
    approvalStatusOk: summary.approvalStatusOk === true,
    approvalActorOk: summary.approvalActorOk === true,
    approvalEvidence: {
      approvalCandidateCount: evidence.approvalCandidateCount || 0,
      approvedPortalEventB50Count: evidence.approvedPortalEventB50Count || 0,
      latestApprovalEvidence: evidence.latestApprovalEvidence || null
    },
    fatal: compact.fatal || [],
    hold: compact.hold || [],
    actualWriteExecuted: false
  };
}

function CC09_checkOperationBlock_() {
  return {
    actualExecutionBlocked: true,
    actualBackupAllowed: false,
    actualDeployAllowed: false,
    actualRecoveryAllowed: false,
    actualRollbackAllowed: false,
    actualPortalSaveAllowed: false,
    actualErpApplyAllowed: false,
    actualFieldOpenAllowed: false,
    sheetWriteExecuted: false,
    sheetCreateExecuted: false,
    headerAutoAddExecuted: false,
    approvalWriteExecuted: false,
    auditLogWriteExecuted: false,
    backupExecuted: false,
    deployExecuted: false,
    recoveryExecuted: false,
    rollbackExecuted: false,
    erpApplyExecuted: false,
    actualOpenExecuted: false,
    productionDataMutationExecuted: false
  };
}

function CC09_checkGateSchemas_(masterSs) {
  var specs = [
    { name: 'ApprovalLog', required: ['approvalId', 'approvalType', 'approvalScope', 'approvalStatus', 'approvedBy', 'approvedAt', 'targetAction', 'relatedBuild', 'status', 'createdAt', 'createdBy'] },
    { name: 'BackupLog', required: ['backupId', 'projectCode', 'buildRange', 'sourceDb', 'targetDb', 'backupScope', 'backupStatus', 'backupStartedAt', 'executedBy', 'rollbackBaselineId', 'status'] },
    { name: 'DeployLog', required: ['deployId', 'projectCode', 'buildNo', 'deployLevel', 'deployStatus', 'approvalId', 'backupId', 'rollbackBaselineId', 'result', 'status'] },
    { name: 'RecoveryLog', required: ['recoveryId', 'rollbackBaselineId', 'projectCode', 'baselineBuild', 'rollbackScope', 'rollbackAllowed', 'reason', 'recoveryStatus', 'createdAt', 'createdBy', 'status'] }
  ];
  var missingSheets = [];
  var totalMissingHeaders = 0;
  var sheets = [];
  specs.forEach(function (spec) {
    var sheet = masterSs.getSheetByName(spec.name);
    var headerMap = sheet ? CC_headerMap_(sheet) : {};
    var missing = [];
    spec.required.forEach(function (h) {
      if (!headerMap[h]) missing.push(h);
    });
    if (!sheet) missingSheets.push(spec.name);
    totalMissingHeaders += missing.length;
    sheets.push({
      sheetName: spec.name,
      exists: !!sheet,
      rowCount: sheet ? CC_countRows_(sheet) : 0,
      requiredHeaderCount: spec.required.length,
      missingHeaderCount: missing.length,
      missingHeaders: missing,
      ok: !!sheet && missing.length === 0,
      actualCreateBlocked: true,
      actualHeaderAddBlocked: true,
      actualWriteBlocked: true
    });
  });
  return {
    ok: missingSheets.length === 0 && totalMissingHeaders === 0,
    missingSheets: missingSheets,
    totalMissingHeaders: totalMissingHeaders,
    sheets: sheets,
    actualCreateBlocked: true,
    actualHeaderAddBlocked: true,
    actualWriteBlocked: true
  };
}

function CC09_result_(summary, fatal, warnings, hold, details) {
  var judgement = 'BLOCK';
  if (fatal.length === 0 && hold.length === 0 && summary.deployReadinessOk === true) judgement = 'PASS';
  else if (fatal.length === 0) judgement = 'HOLD';
  summary.ok = fatal.length === 0;
  summary.judgement = judgement;
  summary.diagnosticOnly = true;
  summary.dryRunOnly = true;
  summary.actualExecutionBlocked = true;
  summary.actualDeployAllowed = false;
  summary.operationSaveBlocked = true;
  summary.erpApplyBlocked = true;
  summary.fieldOpenBlocked = true;
  summary.sheetWriteExecuted = false;
  summary.sheetCreateExecuted = false;
  summary.headerAutoAddExecuted = false;
  summary.approvalWriteExecuted = false;
  summary.auditLogWriteExecuted = false;
  summary.backupExecuted = false;
  summary.deployExecuted = false;
  summary.recoveryExecuted = false;
  summary.rollbackExecuted = false;
  summary.erpApplyExecuted = false;
  summary.actualOpenExecuted = false;
  summary.productionDataMutationExecuted = false;
  return {
    ok: fatal.length === 0,
    build: CC09_BUILD,
    mode: CC09_MODE,
    checkedAt: details.checkedAt || CC_now_(),
    judgement: judgement,
    targetBaseline: CC09_TARGET,
    summary: summary,
    details: details,
    warnings: warnings,
    hold: hold,
    fatal: fatal,
    nextAction: CC09_nextAction_(judgement)
  };
}

function CC09_nextAction_(judgement) {
  if (judgement === 'PASS') {
    return 'PORTAL_EVENT_B50 배포 허용 최종 게이트 PASS. 다음 단계는 현장 오픈 결정 게이트입니다. 이 게이트는 실제 배포를 실행하지 않았습니다.';
  }
  if (judgement === 'HOLD') {
    return 'PORTAL_EVENT_B50 배포 허용 최종 게이트 HOLD. 배포 전 진단/백업/롤백/승인 PASS 중 미충족 항목을 확인하세요.';
  }
  return 'PORTAL_EVENT_B50 배포 허용 최종 게이트 BLOCK. SystemConfig/MASTER/로그 구조 또는 실행 차단 오류를 먼저 복구하세요.';
}
