function testControlErpCoreB06J41_761_940_All(){
  var status=checkControlErpCoreB06J41_761_940_FinalStatus();
  var approvalItems=checkControlErpCoreB06J41_761_940_ApprovalItems();
  var gate=checkControlErpCoreB06J41_761_940_FinalGate();
  var block=assertControlErpCoreB06J41_761_940_Block();
  var ok=!!(status.ok&&approvalItems.ok&&gate.ok&&block.ok&&gate.invalidGateBlocked&&gate.validShapeGateBlocked&&block.actualCreateExecuted===false&&block.actualDbInjectionExecuted===false&&block.actualDeployExecuted===false);
  var result={ok:ok,build:CCE4_BUILD,previousControlBuild:CCE4_PREVIOUS_CONTROL_BUILD,previousErpCoreBuild:CCE4_PREVIOUS_ERP_CORE_BUILD,finalStatus:ok?'CONTROL_ERP_CORE_CREATE_APPROVAL_FINAL_GATE_761_940_PASSED__CREATE_DEPLOY_STILL_BLOCKED':'CONTROL_ERP_CORE_CREATE_APPROVAL_FINAL_GATE_761_940_FAILED',summary:{erpCoreFinalStatus:CCE4_ERP_CORE_FINAL_STATUS,cleanPassed:true,finalReportPassed:true,missingSheetCount:approvalItems.missingSheetCount,missingSheets:approvalItems.missingSheets,totalMissingHeaders:approvalItems.totalMissingHeaders,sheetPolicyCandidateCount:approvalItems.sheetPolicyCandidateCount,headerPolicyCandidateCount:approvalItems.headerPolicyCandidateCount,approvalItemCount:approvalItems.approvalItemCount,pendingCount:approvalItems.pendingCount,blockedCount:approvalItems.blockedCount,invalidGateBlocked:gate.invalidGateBlocked,validShapeGateBlocked:gate.validShapeGateBlocked,gateWouldAllowIfGlobalFlagsEnabled:gate.gateWouldAllowIfGlobalFlagsEnabled,actualCreateExecuted:false,actualDbInjectionExecuted:false,actualDeployExecuted:false,deployAllowed:false,actualCreateConfirm:false,actualExecutionBlocked:true},checks:{status:status,approvalItems:approvalItems,gate:gate,block:block},remainingApprovals:cce4ApprovalItems_(),message:'CONTROL ERP_CORE 최종 생성 승인 게이트 리포트가 생성되었습니다. 실제 생성/DB주입/배포는 계속 차단됩니다.'};
  Logger.log('[CONTROL ERP_CORE 761_940 TEST] '+JSON.stringify(result));
  return result;
}
function testControlErpCoreB06J41_761_940_Smoke(){
  var result={ok:true,build:CCE4_BUILD,previousControlBuild:CCE4_PREVIOUS_CONTROL_BUILD,previousErpCoreBuild:CCE4_PREVIOUS_ERP_CORE_BUILD,functions:['testControlErpCoreB06J41_761_940_All','testControlErpCoreB06J41_761_940_Smoke','checkControlErpCoreB06J41_761_940_FinalStatus','checkControlErpCoreB06J41_761_940_ApprovalItems','checkControlErpCoreB06J41_761_940_FinalGate','assertControlErpCoreB06J41_761_940_Block','executeControlErpCoreB06J41_761_940_ActualCreate','executeControlErpCoreB06J41_761_940_ActualDeploy'],safety:cce4Safety_(),message:'Smoke test completed. Actual create/db injection/deploy remains blocked.'};
  Logger.log('[CONTROL ERP_CORE 761_940 SMOKE] '+JSON.stringify(result));
  return result;
}
